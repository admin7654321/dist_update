const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3ee2f9,_0x5dd8e6){if(!_0x3ee2f9)throw ht(_0x5dd8e6);},ht=function(_0x12deba){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x12deba);},Hr=function(_0x588092){const _0xa8f6be=[];let _0x5ebd23=0x0;for(let _0x19c481=0x0;_0x19c481<_0x588092['length'];_0x19c481++){let _0x3a002b=_0x588092['charCodeAt'](_0x19c481);_0x3a002b<0x80?_0xa8f6be[_0x5ebd23++]=_0x3a002b:_0x3a002b<0x800?(_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0x6|0xc0,_0xa8f6be[_0x5ebd23++]=_0x3a002b&0x3f|0x80):(_0x3a002b&0xfc00)===0xd800&&_0x19c481+0x1<_0x588092['length']&&(_0x588092['charCodeAt'](_0x19c481+0x1)&0xfc00)===0xdc00?(_0x3a002b=0x10000+((_0x3a002b&0x3ff)<<0xa)+(_0x588092['charCodeAt'](++_0x19c481)&0x3ff),_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0x12|0xf0,_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0xc&0x3f|0x80,_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0x6&0x3f|0x80,_0xa8f6be[_0x5ebd23++]=_0x3a002b&0x3f|0x80):(_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0xc|0xe0,_0xa8f6be[_0x5ebd23++]=_0x3a002b>>0x6&0x3f|0x80,_0xa8f6be[_0x5ebd23++]=_0x3a002b&0x3f|0x80);}return _0xa8f6be;},nc=function(_0x37fb2d){const _0x27c607=[];let _0x5f0eb9=0x0,_0x2b537e=0x0;for(;_0x5f0eb9<_0x37fb2d['length'];){const _0x2d3386=_0x37fb2d[_0x5f0eb9++];if(_0x2d3386<0x80)_0x27c607[_0x2b537e++]=String['fromCharCode'](_0x2d3386);else{if(_0x2d3386>0xbf&&_0x2d3386<0xe0){const _0xb39645=_0x37fb2d[_0x5f0eb9++];_0x27c607[_0x2b537e++]=String['fromCharCode']((_0x2d3386&0x1f)<<0x6|_0xb39645&0x3f);}else{if(_0x2d3386>0xef&&_0x2d3386<0x16d){const _0xee559b=_0x37fb2d[_0x5f0eb9++],_0x9e865b=_0x37fb2d[_0x5f0eb9++],_0x42591d=_0x37fb2d[_0x5f0eb9++],_0x118399=((_0x2d3386&0x7)<<0x12|(_0xee559b&0x3f)<<0xc|(_0x9e865b&0x3f)<<0x6|_0x42591d&0x3f)-0x10000;_0x27c607[_0x2b537e++]=String['fromCharCode'](0xd800+(_0x118399>>0xa)),_0x27c607[_0x2b537e++]=String['fromCharCode'](0xdc00+(_0x118399&0x3ff));}else{const _0x123284=_0x37fb2d[_0x5f0eb9++],_0xb1deb2=_0x37fb2d[_0x5f0eb9++];_0x27c607[_0x2b537e++]=String['fromCharCode']((_0x2d3386&0xf)<<0xc|(_0x123284&0x3f)<<0x6|_0xb1deb2&0x3f);}}}}return _0x27c607['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x50dd3a,_0x4f77d6){if(!Array['isArray'](_0x50dd3a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x10331c=_0x4f77d6?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x291da1=[];for(let _0x18ba9c=0x0;_0x18ba9c<_0x50dd3a['length'];_0x18ba9c+=0x3){const _0x34dc1b=_0x50dd3a[_0x18ba9c],_0x454747=_0x18ba9c+0x1<_0x50dd3a['length'],_0x51feaa=_0x454747?_0x50dd3a[_0x18ba9c+0x1]:0x0,_0x408b1d=_0x18ba9c+0x2<_0x50dd3a['length'],_0x378faa=_0x408b1d?_0x50dd3a[_0x18ba9c+0x2]:0x0,_0x5d499a=_0x34dc1b>>0x2,_0x34ca08=(_0x34dc1b&0x3)<<0x4|_0x51feaa>>0x4;let _0x40266c=(_0x51feaa&0xf)<<0x2|_0x378faa>>0x6,_0xdb7357=_0x378faa&0x3f;_0x408b1d||(_0xdb7357=0x40,_0x454747||(_0x40266c=0x40)),_0x291da1['push'](_0x10331c[_0x5d499a],_0x10331c[_0x34ca08],_0x10331c[_0x40266c],_0x10331c[_0xdb7357]);}return _0x291da1['join']('');},'encodeString'(_0x2fc889,_0x2c9432){return this['HAS_NATIVE_SUPPORT']&&!_0x2c9432?btoa(_0x2fc889):this['encodeByteArray'](Hr(_0x2fc889),_0x2c9432);},'decodeString'(_0x4eda7e,_0x2ef88b){return this['HAS_NATIVE_SUPPORT']&&!_0x2ef88b?atob(_0x4eda7e):nc(this['decodeStringToByteArray'](_0x4eda7e,_0x2ef88b));},'decodeStringToByteArray'(_0x42e260,_0x3f5745){this['init_']();const _0x34abcf=_0x3f5745?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x71cf5b=[];for(let _0x1c9f20=0x0;_0x1c9f20<_0x42e260['length'];){const _0x188c2e=_0x34abcf[_0x42e260['charAt'](_0x1c9f20++)],_0x3973e2=_0x1c9f20<_0x42e260['length']?_0x34abcf[_0x42e260['charAt'](_0x1c9f20)]:0x0;++_0x1c9f20;const _0x31e9f1=_0x1c9f20<_0x42e260['length']?_0x34abcf[_0x42e260['charAt'](_0x1c9f20)]:0x40;++_0x1c9f20;const _0x2ad563=_0x1c9f20<_0x42e260['length']?_0x34abcf[_0x42e260['charAt'](_0x1c9f20)]:0x40;if(++_0x1c9f20,_0x188c2e==null||_0x3973e2==null||_0x31e9f1==null||_0x2ad563==null)throw new ic();const _0x2cb69b=_0x188c2e<<0x2|_0x3973e2>>0x4;if(_0x71cf5b['push'](_0x2cb69b),_0x31e9f1!==0x40){const _0xb90f73=_0x3973e2<<0x4&0xf0|_0x31e9f1>>0x2;if(_0x71cf5b['push'](_0xb90f73),_0x2ad563!==0x40){const _0xcfc11e=_0x31e9f1<<0x6&0xc0|_0x2ad563;_0x71cf5b['push'](_0xcfc11e);}}}return _0x71cf5b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x592b37=0x0;_0x592b37<this['ENCODED_VALS']['length'];_0x592b37++)this['byteToCharMap_'][_0x592b37]=this['ENCODED_VALS']['charAt'](_0x592b37),this['charToByteMap_'][this['byteToCharMap_'][_0x592b37]]=_0x592b37,this['byteToCharMapWebSafe_'][_0x592b37]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x592b37),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x592b37]]=_0x592b37,_0x592b37>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x592b37)]=_0x592b37,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x592b37)]=_0x592b37);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x2064b4){const _0x34a023=Hr(_0x2064b4);return Fi['encodeByteArray'](_0x34a023,!0x0);},dn=function(_0x5b875d){return $r(_0x5b875d)['replace'](/\./g,'');},fn=function(_0x1a7ce0){try{return Fi['decodeString'](_0x1a7ce0,!0x0);}catch(_0x1cf791){console['error']('base64Decode\x20failed:\x20',_0x1cf791);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x18573e){return Gr(void 0x0,_0x18573e);}function Gr(_0x10cd7d,_0x428241){if(!(_0x428241 instanceof Object))return _0x428241;switch(_0x428241['constructor']){case Date:const _0x331e87=_0x428241;return new Date(_0x331e87['getTime']());case Object:_0x10cd7d===void 0x0&&(_0x10cd7d={});break;case Array:_0x10cd7d=[];break;default:return _0x428241;}for(const _0x301f4c in _0x428241)!_0x428241['hasOwnProperty'](_0x301f4c)||!rc(_0x301f4c)||(_0x10cd7d[_0x301f4c]=Gr(_0x10cd7d[_0x301f4c],_0x428241[_0x301f4c]));return _0x10cd7d;}function rc(_0x42b418){return _0x42b418!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x486b88=Ns['__FIREBASE_DEFAULTS__'];if(_0x486b88)return JSON['parse'](_0x486b88);},lc=()=>{if(typeof document>'u')return;let _0x305830;try{_0x305830=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x57a13d=_0x305830&&fn(_0x305830[0x1]);return _0x57a13d&&JSON['parse'](_0x57a13d);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xaa3bbc){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xaa3bbc);return;}},qr=_0x944ee8=>{var _0x4d839c,_0x5d871a;return(_0x5d871a=(_0x4d839c=Ui())==null?void 0x0:_0x4d839c['emulatorHosts'])==null?void 0x0:_0x5d871a[_0x944ee8];},hc=_0x3efbe2=>{const _0x236f9a=qr(_0x3efbe2);if(!_0x236f9a)return;const _0x27e303=_0x236f9a['lastIndexOf'](':');if(_0x27e303<=0x0||_0x27e303+0x1===_0x236f9a['length'])throw new Error('Invalid\x20host\x20'+_0x236f9a+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x482d69=parseInt(_0x236f9a['substring'](_0x27e303+0x1),0xa);return _0x236f9a[0x0]==='['?[_0x236f9a['substring'](0x1,_0x27e303-0x1),_0x482d69]:[_0x236f9a['substring'](0x0,_0x27e303),_0x482d69];},zr=()=>{var _0x1bb073;return(_0x1bb073=Ui())==null?void 0x0:_0x1bb073['config'];},jr=_0x2c2d82=>{var _0x3dfe2c;return(_0x3dfe2c=Ui())==null?void 0x0:_0x3dfe2c['_'+_0x2c2d82];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x530122,_0x5221f9)=>{this['resolve']=_0x530122,this['reject']=_0x5221f9;});}['wrapCallback'](_0x4ef0a6){return(_0x1017aa,_0x22e0ee)=>{_0x1017aa?this['reject'](_0x1017aa):this['resolve'](_0x22e0ee),typeof _0x4ef0a6=='function'&&(this['promise']['catch'](()=>{}),_0x4ef0a6['length']===0x1?_0x4ef0a6(_0x1017aa):_0x4ef0a6(_0x1017aa,_0x22e0ee));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4e138c,_0x3341aa){if(_0x4e138c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x49bfb9={'alg':'none','type':'JWT'},_0x5beb86=_0x3341aa||'demo-project',_0x47f2ff=_0x4e138c['iat']||0x0,_0x196cb8=_0x4e138c['sub']||_0x4e138c['user_id'];if(!_0x196cb8)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5d8032={'iss':'https://securetoken.google.com/'+_0x5beb86,'aud':_0x5beb86,'iat':_0x47f2ff,'exp':_0x47f2ff+0xe10,'auth_time':_0x47f2ff,'sub':_0x196cb8,'user_id':_0x196cb8,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4e138c};return[dn(JSON['stringify'](_0x49bfb9)),dn(JSON['stringify'](_0x5d8032)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x545dd1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x545dd1=='object'&&_0x545dd1['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x142e3d=W();return _0x142e3d['indexOf']('MSIE\x20')>=0x0||_0x142e3d['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2c7592,_0x182173)=>{try{let _0x35c18a=!0x0;const _0x2e883c='validate-browser-context-for-indexeddb-analytics-module',_0x22ae0a=self['indexedDB']['open'](_0x2e883c);_0x22ae0a['onsuccess']=()=>{_0x22ae0a['result']['close'](),_0x35c18a||self['indexedDB']['deleteDatabase'](_0x2e883c),_0x2c7592(!0x0);},_0x22ae0a['onupgradeneeded']=()=>{_0x35c18a=!0x1;},_0x22ae0a['onerror']=()=>{var _0x2a27ac;_0x182173(((_0x2a27ac=_0x22ae0a['error'])==null?void 0x0:_0x2a27ac['message'])||'');};}catch(_0x494cfd){_0x182173(_0x494cfd);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x190b18,_0x36e148,_0x4c1a45){super(_0x36e148),this['code']=_0x190b18,this['customData']=_0x4c1a45,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x57bcbb,_0x299222,_0x1bf7d8){this['service']=_0x57bcbb,this['serviceName']=_0x299222,this['errors']=_0x1bf7d8;}['create'](_0x30ec30,..._0x1c142a){const _0x3644ad=_0x1c142a[0x0]||{},_0x58763a=this['service']+'/'+_0x30ec30,_0x34c8be=this['errors'][_0x30ec30],_0x405a21=_0x34c8be?vc(_0x34c8be,_0x3644ad):'Error',_0x1a52f3=this['serviceName']+':\x20'+_0x405a21+'\x20('+_0x58763a+').';return new Re(_0x58763a,_0x1a52f3,_0x3644ad);}}function vc(_0x47120d,_0x9e2dd2){return _0x47120d['replace'](Ec,(_0x26d050,_0x268063)=>{const _0x154145=_0x9e2dd2[_0x268063];return _0x154145!=null?String(_0x154145):'<'+_0x268063+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x468b81){return JSON['parse'](_0x468b81);}function O(_0x50ad6a){return JSON['stringify'](_0x50ad6a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x56a8c8){let _0x50aaa0={},_0x16072a={},_0x41b45c={},_0x96077f='';try{const _0x48f67d=_0x56a8c8['split']('.');_0x50aaa0=Nt(fn(_0x48f67d[0x0])||''),_0x16072a=Nt(fn(_0x48f67d[0x1])||''),_0x96077f=_0x48f67d[0x2],_0x41b45c=_0x16072a['d']||{},delete _0x16072a['d'];}catch{}return{'header':_0x50aaa0,'claims':_0x16072a,'data':_0x41b45c,'signature':_0x96077f};},Ic=function(_0x37246f){const _0x3ddc5a=Yr(_0x37246f),_0x207593=_0x3ddc5a['claims'];return!!_0x207593&&typeof _0x207593=='object'&&_0x207593['hasOwnProperty']('iat');},wc=function(_0x114bc6){const _0xad9484=Yr(_0x114bc6)['claims'];return typeof _0xad9484=='object'&&_0xad9484['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1067d6,_0x4d7d95){return Object['prototype']['hasOwnProperty']['call'](_0x1067d6,_0x4d7d95);}function Me(_0x164c4b,_0x2e1b1c){if(Object['prototype']['hasOwnProperty']['call'](_0x164c4b,_0x2e1b1c))return _0x164c4b[_0x2e1b1c];}function pn(_0x3cfc9a){for(const _0x51549f in _0x3cfc9a)if(Object['prototype']['hasOwnProperty']['call'](_0x3cfc9a,_0x51549f))return!0x1;return!0x0;}function _n(_0x32597b,_0x4166d0,_0x5d210b){const _0x313ba3={};for(const _0x11c04e in _0x32597b)Object['prototype']['hasOwnProperty']['call'](_0x32597b,_0x11c04e)&&(_0x313ba3[_0x11c04e]=_0x4166d0['call'](_0x5d210b,_0x32597b[_0x11c04e],_0x11c04e,_0x32597b));return _0x313ba3;}function Le(_0x42beda,_0x37671f){if(_0x42beda===_0x37671f)return!0x0;const _0x161500=Object['keys'](_0x42beda),_0x42de03=Object['keys'](_0x37671f);for(const _0x297cce of _0x161500){if(!_0x42de03['includes'](_0x297cce))return!0x1;const _0x5ce7fb=_0x42beda[_0x297cce],_0x239c02=_0x37671f[_0x297cce];if(Ps(_0x5ce7fb)&&Ps(_0x239c02)){if(!Le(_0x5ce7fb,_0x239c02))return!0x1;}else{if(_0x5ce7fb!==_0x239c02)return!0x1;}}for(const _0x4f39ae of _0x42de03)if(!_0x161500['includes'](_0x4f39ae))return!0x1;return!0x0;}function Ps(_0x2f4775){return _0x2f4775!==null&&typeof _0x2f4775=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x589eb0){const _0xbe8d40=[];for(const [_0x5c1173,_0x52ba3a]of Object['entries'](_0x589eb0))Array['isArray'](_0x52ba3a)?_0x52ba3a['forEach'](_0xaaa1c6=>{_0xbe8d40['push'](encodeURIComponent(_0x5c1173)+'='+encodeURIComponent(_0xaaa1c6));}):_0xbe8d40['push'](encodeURIComponent(_0x5c1173)+'='+encodeURIComponent(_0x52ba3a));return _0xbe8d40['length']?'&'+_0xbe8d40['join']('&'):'';}function wt(_0x4b83ab){const _0x58f5e3={};return _0x4b83ab['replace'](/^\?/,'')['split']('&')['forEach'](_0x14e7f5=>{if(_0x14e7f5){const [_0x29653a,_0x28e606]=_0x14e7f5['split']('=');_0x58f5e3[decodeURIComponent(_0x29653a)]=decodeURIComponent(_0x28e606);}}),_0x58f5e3;}function Ct(_0x3bad27){const _0x15c0a3=_0x3bad27['indexOf']('?');if(!_0x15c0a3)return'';const _0x355267=_0x3bad27['indexOf']('#',_0x15c0a3);return _0x3bad27['substring'](_0x15c0a3,_0x355267>0x0?_0x355267:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x40d308=0x1;_0x40d308<this['blockSize'];++_0x40d308)this['pad_'][_0x40d308]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x258ce8,_0x41ebdf){_0x41ebdf||(_0x41ebdf=0x0);const _0x309f86=this['W_'];if(typeof _0x258ce8=='string'){for(let _0x1732e0=0x0;_0x1732e0<0x10;_0x1732e0++)_0x309f86[_0x1732e0]=_0x258ce8['charCodeAt'](_0x41ebdf)<<0x18|_0x258ce8['charCodeAt'](_0x41ebdf+0x1)<<0x10|_0x258ce8['charCodeAt'](_0x41ebdf+0x2)<<0x8|_0x258ce8['charCodeAt'](_0x41ebdf+0x3),_0x41ebdf+=0x4;}else{for(let _0x3ab73f=0x0;_0x3ab73f<0x10;_0x3ab73f++)_0x309f86[_0x3ab73f]=_0x258ce8[_0x41ebdf]<<0x18|_0x258ce8[_0x41ebdf+0x1]<<0x10|_0x258ce8[_0x41ebdf+0x2]<<0x8|_0x258ce8[_0x41ebdf+0x3],_0x41ebdf+=0x4;}for(let _0x572f1f=0x10;_0x572f1f<0x50;_0x572f1f++){const _0x356c7e=_0x309f86[_0x572f1f-0x3]^_0x309f86[_0x572f1f-0x8]^_0x309f86[_0x572f1f-0xe]^_0x309f86[_0x572f1f-0x10];_0x309f86[_0x572f1f]=(_0x356c7e<<0x1|_0x356c7e>>>0x1f)&0xffffffff;}let _0x38145e=this['chain_'][0x0],_0x397407=this['chain_'][0x1],_0x51f30a=this['chain_'][0x2],_0x2a4f22=this['chain_'][0x3],_0x4d84af=this['chain_'][0x4],_0x368efe,_0x26e251;for(let _0x4ddb20=0x0;_0x4ddb20<0x50;_0x4ddb20++){_0x4ddb20<0x28?_0x4ddb20<0x14?(_0x368efe=_0x2a4f22^_0x397407&(_0x51f30a^_0x2a4f22),_0x26e251=0x5a827999):(_0x368efe=_0x397407^_0x51f30a^_0x2a4f22,_0x26e251=0x6ed9eba1):_0x4ddb20<0x3c?(_0x368efe=_0x397407&_0x51f30a|_0x2a4f22&(_0x397407|_0x51f30a),_0x26e251=0x8f1bbcdc):(_0x368efe=_0x397407^_0x51f30a^_0x2a4f22,_0x26e251=0xca62c1d6);const _0x52122f=(_0x38145e<<0x5|_0x38145e>>>0x1b)+_0x368efe+_0x4d84af+_0x26e251+_0x309f86[_0x4ddb20]&0xffffffff;_0x4d84af=_0x2a4f22,_0x2a4f22=_0x51f30a,_0x51f30a=(_0x397407<<0x1e|_0x397407>>>0x2)&0xffffffff,_0x397407=_0x38145e,_0x38145e=_0x52122f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x38145e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x397407&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x51f30a&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2a4f22&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4d84af&0xffffffff;}['update'](_0x13a28f,_0x420f26){if(_0x13a28f==null)return;_0x420f26===void 0x0&&(_0x420f26=_0x13a28f['length']);const _0x74afbc=_0x420f26-this['blockSize'];let _0x9a674e=0x0;const _0x26bf63=this['buf_'];let _0x2f70c8=this['inbuf_'];for(;_0x9a674e<_0x420f26;){if(_0x2f70c8===0x0){for(;_0x9a674e<=_0x74afbc;)this['compress_'](_0x13a28f,_0x9a674e),_0x9a674e+=this['blockSize'];}if(typeof _0x13a28f=='string'){for(;_0x9a674e<_0x420f26;)if(_0x26bf63[_0x2f70c8]=_0x13a28f['charCodeAt'](_0x9a674e),++_0x2f70c8,++_0x9a674e,_0x2f70c8===this['blockSize']){this['compress_'](_0x26bf63),_0x2f70c8=0x0;break;}}else{for(;_0x9a674e<_0x420f26;)if(_0x26bf63[_0x2f70c8]=_0x13a28f[_0x9a674e],++_0x2f70c8,++_0x9a674e,_0x2f70c8===this['blockSize']){this['compress_'](_0x26bf63),_0x2f70c8=0x0;break;}}}this['inbuf_']=_0x2f70c8,this['total_']+=_0x420f26;}['digest'](){const _0x234948=[];let _0x1c69f0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4f29a7=this['blockSize']-0x1;_0x4f29a7>=0x38;_0x4f29a7--)this['buf_'][_0x4f29a7]=_0x1c69f0&0xff,_0x1c69f0/=0x100;this['compress_'](this['buf_']);let _0x46279c=0x0;for(let _0x14d4ec=0x0;_0x14d4ec<0x5;_0x14d4ec++)for(let _0x2e1448=0x18;_0x2e1448>=0x0;_0x2e1448-=0x8)_0x234948[_0x46279c]=this['chain_'][_0x14d4ec]>>_0x2e1448&0xff,++_0x46279c;return _0x234948;}}function Tc(_0x5d57aa,_0x533c31){const _0x20496e=new Sc(_0x5d57aa,_0x533c31);return _0x20496e['subscribe']['bind'](_0x20496e);}class Sc{constructor(_0x3a238a,_0x22db8a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x22db8a,this['task']['then'](()=>{_0x3a238a(this);})['catch'](_0x3f13ea=>{this['error'](_0x3f13ea);});}['next'](_0x1552dc){this['forEachObserver'](_0x19ef27=>{_0x19ef27['next'](_0x1552dc);});}['error'](_0x5aa1a4){this['forEachObserver'](_0x3e5a9c=>{_0x3e5a9c['error'](_0x5aa1a4);}),this['close'](_0x5aa1a4);}['complete'](){this['forEachObserver'](_0x61781a=>{_0x61781a['complete']();}),this['close']();}['subscribe'](_0x1c628e,_0x1061af,_0x23e362){let _0x21913f;if(_0x1c628e===void 0x0&&_0x1061af===void 0x0&&_0x23e362===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1c628e,['next','error','complete'])?_0x21913f=_0x1c628e:_0x21913f={'next':_0x1c628e,'error':_0x1061af,'complete':_0x23e362},_0x21913f['next']===void 0x0&&(_0x21913f['next']=ti),_0x21913f['error']===void 0x0&&(_0x21913f['error']=ti),_0x21913f['complete']===void 0x0&&(_0x21913f['complete']=ti);const _0x3550ac=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x21913f['error'](this['finalError']):_0x21913f['complete']();}catch{}}),this['observers']['push'](_0x21913f),_0x3550ac;}['unsubscribeOne'](_0x12f901){this['observers']===void 0x0||this['observers'][_0x12f901]===void 0x0||(delete this['observers'][_0x12f901],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x121801){if(!this['finalized']){for(let _0x286bdc=0x0;_0x286bdc<this['observers']['length'];_0x286bdc++)this['sendOne'](_0x286bdc,_0x121801);}}['sendOne'](_0x5570c8,_0x1965cf){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5570c8]!==void 0x0)try{_0x1965cf(this['observers'][_0x5570c8]);}catch(_0x4b7e2f){typeof console<'u'&&console['error']&&console['error'](_0x4b7e2f);}});}['close'](_0x59f4a4){this['finalized']||(this['finalized']=!0x0,_0x59f4a4!==void 0x0&&(this['finalError']=_0x59f4a4),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3face8,_0x598fc7){if(typeof _0x3face8!='object'||_0x3face8===null)return!0x1;for(const _0x312a89 of _0x598fc7)if(_0x312a89 in _0x3face8&&typeof _0x3face8[_0x312a89]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x2a74c5,_0x175145){return _0x2a74c5+'\x20failed:\x20'+_0x175145+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x1bb746){const _0x4f43d7=[];let _0x3107d3=0x0;for(let _0x1eb74d=0x0;_0x1eb74d<_0x1bb746['length'];_0x1eb74d++){let _0x26665d=_0x1bb746['charCodeAt'](_0x1eb74d);if(_0x26665d>=0xd800&&_0x26665d<=0xdbff){const _0x287eda=_0x26665d-0xd800;_0x1eb74d++,f(_0x1eb74d<_0x1bb746['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5be1be=_0x1bb746['charCodeAt'](_0x1eb74d)-0xdc00;_0x26665d=0x10000+(_0x287eda<<0xa)+_0x5be1be;}_0x26665d<0x80?_0x4f43d7[_0x3107d3++]=_0x26665d:_0x26665d<0x800?(_0x4f43d7[_0x3107d3++]=_0x26665d>>0x6|0xc0,_0x4f43d7[_0x3107d3++]=_0x26665d&0x3f|0x80):_0x26665d<0x10000?(_0x4f43d7[_0x3107d3++]=_0x26665d>>0xc|0xe0,_0x4f43d7[_0x3107d3++]=_0x26665d>>0x6&0x3f|0x80,_0x4f43d7[_0x3107d3++]=_0x26665d&0x3f|0x80):(_0x4f43d7[_0x3107d3++]=_0x26665d>>0x12|0xf0,_0x4f43d7[_0x3107d3++]=_0x26665d>>0xc&0x3f|0x80,_0x4f43d7[_0x3107d3++]=_0x26665d>>0x6&0x3f|0x80,_0x4f43d7[_0x3107d3++]=_0x26665d&0x3f|0x80);}return _0x4f43d7;},Ln=function(_0x103df7){let _0x38d44a=0x0;for(let _0x22e8e6=0x0;_0x22e8e6<_0x103df7['length'];_0x22e8e6++){const _0x5ed566=_0x103df7['charCodeAt'](_0x22e8e6);_0x5ed566<0x80?_0x38d44a++:_0x5ed566<0x800?_0x38d44a+=0x2:_0x5ed566>=0xd800&&_0x5ed566<=0xdbff?(_0x38d44a+=0x4,_0x22e8e6++):_0x38d44a+=0x3;}return _0x38d44a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x89576e){return _0x89576e&&_0x89576e['_delegate']?_0x89576e['_delegate']:_0x89576e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0xc55d33){try{return(_0xc55d33['startsWith']('http://')||_0xc55d33['startsWith']('https://')?new URL(_0xc55d33)['hostname']:_0xc55d33)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3deea7){return(await fetch(_0x3deea7,{'credentials':'include'}))['ok'];}class xe{constructor(_0x18ee73,_0x40bfed,_0x16748e){this['name']=_0x18ee73,this['instanceFactory']=_0x40bfed,this['type']=_0x16748e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x275ccf){return this['instantiationMode']=_0x275ccf,this;}['setMultipleInstances'](_0x381004){return this['multipleInstances']=_0x381004,this;}['setServiceProps'](_0x2f463f){return this['serviceProps']=_0x2f463f,this;}['setInstanceCreatedCallback'](_0x18eb57){return this['onInstanceCreated']=_0x18eb57,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x265306,_0x5f3aef){this['name']=_0x265306,this['container']=_0x5f3aef,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x17044e){const _0x2e9f03=this['normalizeInstanceIdentifier'](_0x17044e);if(!this['instancesDeferred']['has'](_0x2e9f03)){const _0x4b51eb=new H();if(this['instancesDeferred']['set'](_0x2e9f03,_0x4b51eb),this['isInitialized'](_0x2e9f03)||this['shouldAutoInitialize']())try{const _0x4eabc2=this['getOrInitializeService']({'instanceIdentifier':_0x2e9f03});_0x4eabc2&&_0x4b51eb['resolve'](_0x4eabc2);}catch{}}return this['instancesDeferred']['get'](_0x2e9f03)['promise'];}['getImmediate'](_0x3fd80c){const _0x4477e9=this['normalizeInstanceIdentifier'](_0x3fd80c==null?void 0x0:_0x3fd80c['identifier']),_0x5708ae=(_0x3fd80c==null?void 0x0:_0x3fd80c['optional'])??!0x1;if(this['isInitialized'](_0x4477e9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4477e9});}catch(_0x4884aa){if(_0x5708ae)return null;throw _0x4884aa;}else{if(_0x5708ae)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1d255f){if(_0x1d255f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1d255f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1d255f,!!this['shouldAutoInitialize']()){if(Nc(_0x1d255f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x50486f,_0x5353a5]of this['instancesDeferred']['entries']()){const _0x8ae9f2=this['normalizeInstanceIdentifier'](_0x50486f);try{const _0x122e1b=this['getOrInitializeService']({'instanceIdentifier':_0x8ae9f2});_0x5353a5['resolve'](_0x122e1b);}catch{}}}}['clearInstance'](_0x4942f5=Ne){this['instancesDeferred']['delete'](_0x4942f5),this['instancesOptions']['delete'](_0x4942f5),this['instances']['delete'](_0x4942f5);}async['delete'](){const _0x3ea5fa=Array['from'](this['instances']['values']());await Promise['all']([..._0x3ea5fa['filter'](_0xd3a6af=>'INTERNAL'in _0xd3a6af)['map'](_0x295c98=>_0x295c98['INTERNAL']['delete']()),..._0x3ea5fa['filter'](_0x88304e=>'_delete'in _0x88304e)['map'](_0x31baaa=>_0x31baaa['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1a03a4=Ne){return this['instances']['has'](_0x1a03a4);}['getOptions'](_0x11f6aa=Ne){return this['instancesOptions']['get'](_0x11f6aa)||{};}['initialize'](_0x565bac={}){const {options:_0x12d5b3={}}=_0x565bac,_0x1e5f58=this['normalizeInstanceIdentifier'](_0x565bac['instanceIdentifier']);if(this['isInitialized'](_0x1e5f58))throw Error(this['name']+'('+_0x1e5f58+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3d33a7=this['getOrInitializeService']({'instanceIdentifier':_0x1e5f58,'options':_0x12d5b3});for(const [_0x3fd2f7,_0x215a30]of this['instancesDeferred']['entries']()){const _0x1e00d5=this['normalizeInstanceIdentifier'](_0x3fd2f7);_0x1e5f58===_0x1e00d5&&_0x215a30['resolve'](_0x3d33a7);}return _0x3d33a7;}['onInit'](_0x20196b,_0x393c26){const _0x5035b6=this['normalizeInstanceIdentifier'](_0x393c26),_0x2ba900=this['onInitCallbacks']['get'](_0x5035b6)??new Set();_0x2ba900['add'](_0x20196b),this['onInitCallbacks']['set'](_0x5035b6,_0x2ba900);const _0x532f94=this['instances']['get'](_0x5035b6);return _0x532f94&&_0x20196b(_0x532f94,_0x5035b6),()=>{_0x2ba900['delete'](_0x20196b);};}['invokeOnInitCallbacks'](_0x5002d3,_0x43c1df){const _0x1ce137=this['onInitCallbacks']['get'](_0x43c1df);if(_0x1ce137){for(const _0x2de8b4 of _0x1ce137)try{_0x2de8b4(_0x5002d3,_0x43c1df);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4f69f5,options:_0x6686b9={}}){let _0x46c9b2=this['instances']['get'](_0x4f69f5);if(!_0x46c9b2&&this['component']&&(_0x46c9b2=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4f69f5),'options':_0x6686b9}),this['instances']['set'](_0x4f69f5,_0x46c9b2),this['instancesOptions']['set'](_0x4f69f5,_0x6686b9),this['invokeOnInitCallbacks'](_0x46c9b2,_0x4f69f5),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4f69f5,_0x46c9b2);}catch{}return _0x46c9b2||null;}['normalizeInstanceIdentifier'](_0x58d559=Ne){return this['component']?this['component']['multipleInstances']?_0x58d559:Ne:_0x58d559;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x141654){return _0x141654===Ne?void 0x0:_0x141654;}function Nc(_0x2d3fe8){return _0x2d3fe8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x5929a4){this['name']=_0x5929a4,this['providers']=new Map();}['addComponent'](_0x56c98f){const _0x3a17b5=this['getProvider'](_0x56c98f['name']);if(_0x3a17b5['isComponentSet']())throw new Error('Component\x20'+_0x56c98f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3a17b5['setComponent'](_0x56c98f);}['addOrOverwriteComponent'](_0x1c7809){this['getProvider'](_0x1c7809['name'])['isComponentSet']()&&this['providers']['delete'](_0x1c7809['name']),this['addComponent'](_0x1c7809);}['getProvider'](_0x33c2d0){if(this['providers']['has'](_0x33c2d0))return this['providers']['get'](_0x33c2d0);const _0x129bcd=new Ac(_0x33c2d0,this);return this['providers']['set'](_0x33c2d0,_0x129bcd),_0x129bcd;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3b18e3){_0x3b18e3[_0x3b18e3['DEBUG']=0x0]='DEBUG',_0x3b18e3[_0x3b18e3['VERBOSE']=0x1]='VERBOSE',_0x3b18e3[_0x3b18e3['INFO']=0x2]='INFO',_0x3b18e3[_0x3b18e3['WARN']=0x3]='WARN',_0x3b18e3[_0x3b18e3['ERROR']=0x4]='ERROR',_0x3b18e3[_0x3b18e3['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0xd7db41,_0x3a091f,..._0x2c08a7)=>{if(_0x3a091f<_0xd7db41['logLevel'])return;const _0x301c83=new Date()['toISOString'](),_0x200560=Mc[_0x3a091f];if(_0x200560)console[_0x200560]('['+_0x301c83+']\x20\x20'+_0xd7db41['name']+':',..._0x2c08a7);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3a091f+')');};class Bi{constructor(_0x5b5c53){this['name']=_0x5b5c53,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3388fb){if(!(_0x3388fb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3388fb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3388fb;}['setLogLevel'](_0x5037cd){this['_logLevel']=typeof _0x5037cd=='string'?Oc[_0x5037cd]:_0x5037cd;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1cfe20){if(typeof _0x1cfe20!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1cfe20;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x52882f){this['_userLogHandler']=_0x52882f;}['debug'](..._0x42f0b0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x42f0b0),this['_logHandler'](this,T['DEBUG'],..._0x42f0b0);}['log'](..._0x5a1a84){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5a1a84),this['_logHandler'](this,T['VERBOSE'],..._0x5a1a84);}['info'](..._0x450a98){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x450a98),this['_logHandler'](this,T['INFO'],..._0x450a98);}['warn'](..._0x3181fa){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3181fa),this['_logHandler'](this,T['WARN'],..._0x3181fa);}['error'](..._0x3e600b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3e600b),this['_logHandler'](this,T['ERROR'],..._0x3e600b);}}const xc=(_0x54e9be,_0x33b19f)=>_0x33b19f['some'](_0x494f82=>_0x54e9be instanceof _0x494f82);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x466c1c){const _0x557e79=new Promise((_0x15e907,_0x16ba74)=>{const _0x5c0202=()=>{_0x466c1c['removeEventListener']('success',_0x3e9ef4),_0x466c1c['removeEventListener']('error',_0x1bc9ed);},_0x3e9ef4=()=>{_0x15e907(ge(_0x466c1c['result'])),_0x5c0202();},_0x1bc9ed=()=>{_0x16ba74(_0x466c1c['error']),_0x5c0202();};_0x466c1c['addEventListener']('success',_0x3e9ef4),_0x466c1c['addEventListener']('error',_0x1bc9ed);});return _0x557e79['then'](_0x4d8ac4=>{_0x4d8ac4 instanceof IDBCursor&&Jr['set'](_0x4d8ac4,_0x466c1c);})['catch'](()=>{}),Vi['set'](_0x557e79,_0x466c1c),_0x557e79;}function Bc(_0x2d75a0){if(_i['has'](_0x2d75a0))return;const _0x2f9d67=new Promise((_0x2e1769,_0x2228e3)=>{const _0xa8bacd=()=>{_0x2d75a0['removeEventListener']('complete',_0x34b48e),_0x2d75a0['removeEventListener']('error',_0x57e1dc),_0x2d75a0['removeEventListener']('abort',_0x57e1dc);},_0x34b48e=()=>{_0x2e1769(),_0xa8bacd();},_0x57e1dc=()=>{_0x2228e3(_0x2d75a0['error']||new DOMException('AbortError','AbortError')),_0xa8bacd();};_0x2d75a0['addEventListener']('complete',_0x34b48e),_0x2d75a0['addEventListener']('error',_0x57e1dc),_0x2d75a0['addEventListener']('abort',_0x57e1dc);});_i['set'](_0x2d75a0,_0x2f9d67);}let gi={'get'(_0x3f0cb4,_0xac72e8,_0x3fe6fe){if(_0x3f0cb4 instanceof IDBTransaction){if(_0xac72e8==='done')return _i['get'](_0x3f0cb4);if(_0xac72e8==='objectStoreNames')return _0x3f0cb4['objectStoreNames']||Xr['get'](_0x3f0cb4);if(_0xac72e8==='store')return _0x3fe6fe['objectStoreNames'][0x1]?void 0x0:_0x3fe6fe['objectStore'](_0x3fe6fe['objectStoreNames'][0x0]);}return ge(_0x3f0cb4[_0xac72e8]);},'set'(_0x356846,_0x3c270f,_0x5d9180){return _0x356846[_0x3c270f]=_0x5d9180,!0x0;},'has'(_0x20c25c,_0x355381){return _0x20c25c instanceof IDBTransaction&&(_0x355381==='done'||_0x355381==='store')?!0x0:_0x355381 in _0x20c25c;}};function Vc(_0x483230){gi=_0x483230(gi);}function Hc(_0x4d3adb){return _0x4d3adb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x433e28,..._0x4649e2){const _0x3c783a=_0x4d3adb['call'](ii(this),_0x433e28,..._0x4649e2);return Xr['set'](_0x3c783a,_0x433e28['sort']?_0x433e28['sort']():[_0x433e28]),ge(_0x3c783a);}:Uc()['includes'](_0x4d3adb)?function(..._0x10698f){return _0x4d3adb['apply'](ii(this),_0x10698f),ge(Jr['get'](this));}:function(..._0x3d0881){return ge(_0x4d3adb['apply'](ii(this),_0x3d0881));};}function $c(_0x239cfc){return typeof _0x239cfc=='function'?Hc(_0x239cfc):(_0x239cfc instanceof IDBTransaction&&Bc(_0x239cfc),xc(_0x239cfc,Fc())?new Proxy(_0x239cfc,gi):_0x239cfc);}function ge(_0x19352e){if(_0x19352e instanceof IDBRequest)return Wc(_0x19352e);if(ni['has'](_0x19352e))return ni['get'](_0x19352e);const _0x44c212=$c(_0x19352e);return _0x44c212!==_0x19352e&&(ni['set'](_0x19352e,_0x44c212),Vi['set'](_0x44c212,_0x19352e)),_0x44c212;}const ii=_0x35e8b8=>Vi['get'](_0x35e8b8);function Gc(_0x18131c,_0x30427b,{blocked:_0x36a076,upgrade:_0x3f8911,blocking:_0x1a252a,terminated:_0xd56ab7}={}){const _0x1e67f3=indexedDB['open'](_0x18131c,_0x30427b),_0x490357=ge(_0x1e67f3);return _0x3f8911&&_0x1e67f3['addEventListener']('upgradeneeded',_0x3053fe=>{_0x3f8911(ge(_0x1e67f3['result']),_0x3053fe['oldVersion'],_0x3053fe['newVersion'],ge(_0x1e67f3['transaction']),_0x3053fe);}),_0x36a076&&_0x1e67f3['addEventListener']('blocked',_0xf4013f=>_0x36a076(_0xf4013f['oldVersion'],_0xf4013f['newVersion'],_0xf4013f)),_0x490357['then'](_0x2e8082=>{_0xd56ab7&&_0x2e8082['addEventListener']('close',()=>_0xd56ab7()),_0x1a252a&&_0x2e8082['addEventListener']('versionchange',_0x5059b5=>_0x1a252a(_0x5059b5['oldVersion'],_0x5059b5['newVersion'],_0x5059b5));})['catch'](()=>{}),_0x490357;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x1837b4,_0x412764){if(!(_0x1837b4 instanceof IDBDatabase&&!(_0x412764 in _0x1837b4)&&typeof _0x412764=='string'))return;if(si['get'](_0x412764))return si['get'](_0x412764);const _0x42f780=_0x412764['replace'](/FromIndex$/,''),_0x366ac9=_0x412764!==_0x42f780,_0x1bbb41=zc['includes'](_0x42f780);if(!(_0x42f780 in(_0x366ac9?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1bbb41||qc['includes'](_0x42f780)))return;const _0x380913=async function(_0x33e25e,..._0x27c152){const _0x13dba5=this['transaction'](_0x33e25e,_0x1bbb41?'readwrite':'readonly');let _0x1461e9=_0x13dba5['store'];return _0x366ac9&&(_0x1461e9=_0x1461e9['index'](_0x27c152['shift']())),(await Promise['all']([_0x1461e9[_0x42f780](..._0x27c152),_0x1bbb41&&_0x13dba5['done']]))[0x0];};return si['set'](_0x412764,_0x380913),_0x380913;}Vc(_0x910b72=>({..._0x910b72,'get':(_0x3d961a,_0xc32e9,_0x372287)=>Ms(_0x3d961a,_0xc32e9)||_0x910b72['get'](_0x3d961a,_0xc32e9,_0x372287),'has':(_0x378d9f,_0x417f65)=>!!Ms(_0x378d9f,_0x417f65)||_0x910b72['has'](_0x378d9f,_0x417f65)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x2df9fa){this['container']=_0x2df9fa;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2711b7=>{if(Kc(_0x2711b7)){const _0x56292a=_0x2711b7['getImmediate']();return _0x56292a['library']+'/'+_0x56292a['version'];}else return null;})['filter'](_0x5efbc5=>_0x5efbc5)['join']('\x20');}}function Kc(_0x550986){const _0x278218=_0x550986['getComponent']();return(_0x278218==null?void 0x0:_0x278218['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x20f53b,_0x38392d){try{_0x20f53b['container']['addComponent'](_0x38392d);}catch(_0x134f28){oe['debug']('Component\x20'+_0x38392d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x20f53b['name'],_0x134f28);}}function st(_0x4ff0f1){const _0x6caae6=_0x4ff0f1['name'];if(Ei['has'](_0x6caae6))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x6caae6+'.'),!0x1;Ei['set'](_0x6caae6,_0x4ff0f1);for(const _0x37baa2 of Fe['values']())xs(_0x37baa2,_0x4ff0f1);for(const _0x4ff0af of vi['values']())xs(_0x4ff0af,_0x4ff0f1);return!0x0;}function Hi(_0x58f8b9,_0x31c716){const _0x81c8c4=_0x58f8b9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x81c8c4&&_0x81c8c4['triggerHeartbeat'](),_0x58f8b9['container']['getProvider'](_0x31c716);}function $(_0x3384eb){return _0x3384eb==null?!0x1:_0x3384eb['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x19b150,_0x580ad1,_0x4d8fcd){this['_isDeleted']=!0x1,this['_options']={..._0x19b150},this['_config']={..._0x580ad1},this['_name']=_0x580ad1['name'],this['_automaticDataCollectionEnabled']=_0x580ad1['automaticDataCollectionEnabled'],this['_container']=_0x4d8fcd,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3c6043){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3c6043;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x27a59a){this['_isDeleted']=_0x27a59a;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x30cbe0,_0x353902={}){let _0x63ef7e=_0x30cbe0;typeof _0x353902!='object'&&(_0x353902={'name':_0x353902});const _0x37513b={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x353902},_0x3e77eb=_0x37513b['name'];if(typeof _0x3e77eb!='string'||!_0x3e77eb)throw me['create']('bad-app-name',{'appName':String(_0x3e77eb)});if(_0x63ef7e||(_0x63ef7e=zr()),!_0x63ef7e)throw me['create']('no-options');const _0x298239=Fe['get'](_0x3e77eb);if(_0x298239){if(Le(_0x63ef7e,_0x298239['options'])&&Le(_0x37513b,_0x298239['config']))return _0x298239;throw me['create']('duplicate-app',{'appName':_0x3e77eb});}const _0x10de7c=new Pc(_0x3e77eb);for(const _0x4de2ca of Ei['values']())_0x10de7c['addComponent'](_0x4de2ca);const _0xe14c78=new Tl(_0x63ef7e,_0x37513b,_0x10de7c);return Fe['set'](_0x3e77eb,_0xe14c78),_0xe14c78;}function Zr(_0x2ee7b6=yi){const _0x5c2606=Fe['get'](_0x2ee7b6);if(!_0x5c2606&&_0x2ee7b6===yi&&zr())return Sl();if(!_0x5c2606)throw me['create']('no-app',{'appName':_0x2ee7b6});return _0x5c2606;}function p_(){return Array['from'](Fe['values']());}async function __(_0x2b5450){let _0x6a18fb=!0x1;const _0xe781de=_0x2b5450['name'];Fe['has'](_0xe781de)?(_0x6a18fb=!0x0,Fe['delete'](_0xe781de)):vi['has'](_0xe781de)&&_0x2b5450['decRefCount']()<=0x0&&(vi['delete'](_0xe781de),_0x6a18fb=!0x0),_0x6a18fb&&(await Promise['all'](_0x2b5450['container']['getProviders']()['map'](_0x9d75ee=>_0x9d75ee['delete']())),_0x2b5450['isDeleted']=!0x0);}function ye(_0x1a0b8a,_0x12b5e6,_0x541140){let _0x5b5969=wl[_0x1a0b8a]??_0x1a0b8a;_0x541140&&(_0x5b5969+='-'+_0x541140);const _0x40fdf9=_0x5b5969['match'](/\s|\//),_0x4aeb72=_0x12b5e6['match'](/\s|\//);if(_0x40fdf9||_0x4aeb72){const _0x112b0a=['Unable\x20to\x20register\x20library\x20\x22'+_0x5b5969+'\x22\x20with\x20version\x20\x22'+_0x12b5e6+'\x22:'];_0x40fdf9&&_0x112b0a['push']('library\x20name\x20\x22'+_0x5b5969+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x40fdf9&&_0x4aeb72&&_0x112b0a['push']('and'),_0x4aeb72&&_0x112b0a['push']('version\x20name\x20\x22'+_0x12b5e6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x112b0a['join']('\x20'));return;}st(new xe(_0x5b5969+'-version',()=>({'library':_0x5b5969,'version':_0x12b5e6}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x21121a,_0x24b127)=>{switch(_0x24b127){case 0x0:try{_0x21121a['createObjectStore'](Pt);}catch(_0x49f2c2){console['warn'](_0x49f2c2);}}}})['catch'](_0x2116d8=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2116d8['message']});})),ri;}async function Al(_0x4d8553){try{const _0x120630=(await eo())['transaction'](Pt),_0x34f119=await _0x120630['objectStore'](Pt)['get'](to(_0x4d8553));return await _0x120630['done'],_0x34f119;}catch(_0x3cc192){if(_0x3cc192 instanceof Re)oe['warn'](_0x3cc192['message']);else{const _0x30ed00=me['create']('idb-get',{'originalErrorMessage':_0x3cc192==null?void 0x0:_0x3cc192['message']});oe['warn'](_0x30ed00['message']);}}}async function Fs(_0x3f0280,_0x3d3b37){try{const _0x3f3c02=(await eo())['transaction'](Pt,'readwrite');await _0x3f3c02['objectStore'](Pt)['put'](_0x3d3b37,to(_0x3f0280)),await _0x3f3c02['done'];}catch(_0x383520){if(_0x383520 instanceof Re)oe['warn'](_0x383520['message']);else{const _0x20ba64=me['create']('idb-set',{'originalErrorMessage':_0x383520==null?void 0x0:_0x383520['message']});oe['warn'](_0x20ba64['message']);}}}function to(_0xc3854d){return _0xc3854d['name']+'!'+_0xc3854d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x444678){this['container']=_0x444678,this['_heartbeatsCache']=null;const _0x5abe44=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5abe44),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2aafa5=>(this['_heartbeatsCache']=_0x2aafa5,_0x2aafa5));}async['triggerHeartbeat'](){var _0x407ff6,_0x2e63b6;try{const _0x515aa7=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x410e72=Us();if(((_0x407ff6=this['_heartbeatsCache'])==null?void 0x0:_0x407ff6['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2e63b6=this['_heartbeatsCache'])==null?void 0x0:_0x2e63b6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x410e72||this['_heartbeatsCache']['heartbeats']['some'](_0xabcc10=>_0xabcc10['date']===_0x410e72))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x410e72,'agent':_0x515aa7}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x57d300=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x57d300,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x24266e){oe['warn'](_0x24266e);}}async['getHeartbeatsHeader'](){var _0xe0eefd;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xe0eefd=this['_heartbeatsCache'])==null?void 0x0:_0xe0eefd['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xe7a27b=Us(),{heartbeatsToSend:_0xfc86a8,unsentEntries:_0xf9fcf4}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3ea692=dn(JSON['stringify']({'version':0x2,'heartbeats':_0xfc86a8}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xe7a27b,_0xf9fcf4['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xf9fcf4,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3ea692;}catch(_0x3446f1){return oe['warn'](_0x3446f1),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x3db56f,_0x205dd6=kl){const _0x1cf06c=[];let _0x451b5e=_0x3db56f['slice']();for(const _0x20ca37 of _0x3db56f){const _0x4cc1b2=_0x1cf06c['find'](_0x30a8bc=>_0x30a8bc['agent']===_0x20ca37['agent']);if(_0x4cc1b2){if(_0x4cc1b2['dates']['push'](_0x20ca37['date']),Ws(_0x1cf06c)>_0x205dd6){_0x4cc1b2['dates']['pop']();break;}}else{if(_0x1cf06c['push']({'agent':_0x20ca37['agent'],'dates':[_0x20ca37['date']]}),Ws(_0x1cf06c)>_0x205dd6){_0x1cf06c['pop']();break;}}_0x451b5e=_0x451b5e['slice'](0x1);}return{'heartbeatsToSend':_0x1cf06c,'unsentEntries':_0x451b5e};}class Dl{constructor(_0x3e4dad){this['app']=_0x3e4dad,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x46e9f1=await Al(this['app']);return _0x46e9f1!=null&&_0x46e9f1['heartbeats']?_0x46e9f1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2fcf7d){if(await this['_canUseIndexedDBPromise']){const _0x2144c8=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2fcf7d['lastSentHeartbeatDate']??_0x2144c8['lastSentHeartbeatDate'],'heartbeats':_0x2fcf7d['heartbeats']});}else return;}async['add'](_0x1003e1){if(await this['_canUseIndexedDBPromise']){const _0x41dd16=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1003e1['lastSentHeartbeatDate']??_0x41dd16['lastSentHeartbeatDate'],'heartbeats':[..._0x41dd16['heartbeats'],..._0x1003e1['heartbeats']]});}else return;}}function Ws(_0x46934d){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x46934d}))['length'];}function Ml(_0x3c4e35){if(_0x3c4e35['length']===0x0)return-0x1;let _0xfce2bc=0x0,_0x1b877e=_0x3c4e35[0x0]['date'];for(let _0x1f59ad=0x1;_0x1f59ad<_0x3c4e35['length'];_0x1f59ad++)_0x3c4e35[_0x1f59ad]['date']<_0x1b877e&&(_0x1b877e=_0x3c4e35[_0x1f59ad]['date'],_0xfce2bc=_0x1f59ad);return _0xfce2bc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x463fc7){st(new xe('platform-logger',_0x34b71a=>new jc(_0x34b71a),'PRIVATE')),st(new xe('heartbeat',_0x570ded=>new Pl(_0x570ded),'PRIVATE')),ye(mi,Ls,_0x463fc7),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x4b80ea){no=_0x4b80ea;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x12665b){this['domStorage_']=_0x12665b,this['prefix_']='firebase:';}['set'](_0x1ee5c0,_0x523424){_0x523424==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1ee5c0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1ee5c0),O(_0x523424));}['get'](_0x47e306){const _0x1c3eff=this['domStorage_']['getItem'](this['prefixedName_'](_0x47e306));return _0x1c3eff==null?null:Nt(_0x1c3eff);}['remove'](_0x464c9c){this['domStorage_']['removeItem'](this['prefixedName_'](_0x464c9c));}['prefixedName_'](_0x9fcf8d){return this['prefix_']+_0x9fcf8d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5172ae,_0x15b9ec){_0x15b9ec==null?delete this['cache_'][_0x5172ae]:this['cache_'][_0x5172ae]=_0x15b9ec;}['get'](_0x232d06){return Q(this['cache_'],_0x232d06)?this['cache_'][_0x232d06]:null;}['remove'](_0x1f0ae3){delete this['cache_'][_0x1f0ae3];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x33cd2b){try{if(typeof window<'u'&&typeof window[_0x33cd2b]<'u'){const _0xc6ba12=window[_0x33cd2b];return _0xc6ba12['setItem']('firebase:sentinel','cache'),_0xc6ba12['removeItem']('firebase:sentinel'),new Wl(_0xc6ba12);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x5712d6=0x1;return function(){return _0x5712d6++;};}()),ro=function(_0x2183cf){const _0x38e18f=Rc(_0x2183cf),_0x424d21=new Cc();_0x424d21['update'](_0x38e18f);const _0x298342=_0x424d21['digest']();return Fi['encodeByteArray'](_0x298342);},qt=function(..._0x4c9511){let _0x407025='';for(let _0x8bb5b=0x0;_0x8bb5b<_0x4c9511['length'];_0x8bb5b++){const _0x1f4304=_0x4c9511[_0x8bb5b];Array['isArray'](_0x1f4304)||_0x1f4304&&typeof _0x1f4304=='object'&&typeof _0x1f4304['length']=='number'?_0x407025+=qt['apply'](null,_0x1f4304):typeof _0x1f4304=='object'?_0x407025+=O(_0x1f4304):_0x407025+=_0x1f4304,_0x407025+='\x20';}return _0x407025;};let Tt=null,$s=!0x0;const Hl=function(_0x5bdfd6,_0xee9a8a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0x5c764b){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0xb229d7=qt['apply'](null,_0x5c764b);Tt(_0xb229d7);}},zt=function(_0xa2eb23){return function(..._0x2689d0){L(_0xa2eb23,..._0x2689d0);};},Ii=function(..._0x9eb407){const _0x5766dc='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x9eb407);Ze['error'](_0x5766dc);},ae=function(..._0x16ae8c){const _0x412375='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x16ae8c);throw Ze['error'](_0x412375),new Error(_0x412375);},U=function(..._0x48b4f8){const _0x46a51a='FIREBASE\x20WARNING:\x20'+qt(..._0x48b4f8);Ze['warn'](_0x46a51a);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x137efa){return typeof _0x137efa=='number'&&(_0x137efa!==_0x137efa||_0x137efa===Number['POSITIVE_INFINITY']||_0x137efa===Number['NEGATIVE_INFINITY']);},Gl=function(_0xa8a09c){if(document['readyState']==='complete')_0xa8a09c();else{let _0x4cb217=!0x1;const _0x58b1ec=function(){if(!document['body']){setTimeout(_0x58b1ec,Math['floor'](0xa));return;}_0x4cb217||(_0x4cb217=!0x0,_0xa8a09c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x58b1ec,!0x1),window['addEventListener']('load',_0x58b1ec,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x58b1ec();}),window['attachEvent']('onload',_0x58b1ec));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x18ca1b,_0x1a0d79){if(_0x18ca1b===_0x1a0d79)return 0x0;if(_0x18ca1b===Ue||_0x1a0d79===we)return-0x1;if(_0x1a0d79===Ue||_0x18ca1b===we)return 0x1;{const _0x17071c=Gs(_0x18ca1b),_0x5ea039=Gs(_0x1a0d79);return _0x17071c!==null?_0x5ea039!==null?_0x17071c-_0x5ea039===0x0?_0x18ca1b['length']-_0x1a0d79['length']:_0x17071c-_0x5ea039:-0x1:_0x5ea039!==null?0x1:_0x18ca1b<_0x1a0d79?-0x1:0x1;}},ql=function(_0x105e29,_0x74c0d){return _0x105e29===_0x74c0d?0x0:_0x105e29<_0x74c0d?-0x1:0x1;},yt=function(_0x47cb58,_0x53c9f3){if(_0x53c9f3&&_0x47cb58 in _0x53c9f3)return _0x53c9f3[_0x47cb58];throw new Error('Missing\x20required\x20key\x20('+_0x47cb58+')\x20in\x20object:\x20'+O(_0x53c9f3));},$i=function(_0x2a0c5d){if(typeof _0x2a0c5d!='object'||_0x2a0c5d===null)return O(_0x2a0c5d);const _0x4fa89b=[];for(const _0x120929 in _0x2a0c5d)_0x4fa89b['push'](_0x120929);_0x4fa89b['sort']();let _0x5aed4b='{';for(let _0x5790b0=0x0;_0x5790b0<_0x4fa89b['length'];_0x5790b0++)_0x5790b0!==0x0&&(_0x5aed4b+=','),_0x5aed4b+=O(_0x4fa89b[_0x5790b0]),_0x5aed4b+=':',_0x5aed4b+=$i(_0x2a0c5d[_0x4fa89b[_0x5790b0]]);return _0x5aed4b+='}',_0x5aed4b;},oo=function(_0x37ae40,_0x23ea56){const _0x56ffd3=_0x37ae40['length'];if(_0x56ffd3<=_0x23ea56)return[_0x37ae40];const _0x40a278=[];for(let _0x380891=0x0;_0x380891<_0x56ffd3;_0x380891+=_0x23ea56)_0x380891+_0x23ea56>_0x56ffd3?_0x40a278['push'](_0x37ae40['substring'](_0x380891,_0x56ffd3)):_0x40a278['push'](_0x37ae40['substring'](_0x380891,_0x380891+_0x23ea56));return _0x40a278;};function x(_0x448f2f,_0x1a2a2a){for(const _0x15ae61 in _0x448f2f)_0x448f2f['hasOwnProperty'](_0x15ae61)&&_0x1a2a2a(_0x15ae61,_0x448f2f[_0x15ae61]);}const ao=function(_0x390c04){f(!xn(_0x390c04),'Invalid\x20JSON\x20number');const _0x276dbd=0xb,_0x7c5ede=0x34,_0x4e265f=(0x1<<_0x276dbd-0x1)-0x1;let _0x4b3858,_0x3e72d2,_0x1f68e5,_0x5356d0,_0x2ba445;_0x390c04===0x0?(_0x3e72d2=0x0,_0x1f68e5=0x0,_0x4b3858=0x1/_0x390c04===-0x1/0x0?0x1:0x0):(_0x4b3858=_0x390c04<0x0,_0x390c04=Math['abs'](_0x390c04),_0x390c04>=Math['pow'](0x2,0x1-_0x4e265f)?(_0x5356d0=Math['min'](Math['floor'](Math['log'](_0x390c04)/Math['LN2']),_0x4e265f),_0x3e72d2=_0x5356d0+_0x4e265f,_0x1f68e5=Math['round'](_0x390c04*Math['pow'](0x2,_0x7c5ede-_0x5356d0)-Math['pow'](0x2,_0x7c5ede))):(_0x3e72d2=0x0,_0x1f68e5=Math['round'](_0x390c04/Math['pow'](0x2,0x1-_0x4e265f-_0x7c5ede))));const _0x16cd8d=[];for(_0x2ba445=_0x7c5ede;_0x2ba445;_0x2ba445-=0x1)_0x16cd8d['push'](_0x1f68e5%0x2?0x1:0x0),_0x1f68e5=Math['floor'](_0x1f68e5/0x2);for(_0x2ba445=_0x276dbd;_0x2ba445;_0x2ba445-=0x1)_0x16cd8d['push'](_0x3e72d2%0x2?0x1:0x0),_0x3e72d2=Math['floor'](_0x3e72d2/0x2);_0x16cd8d['push'](_0x4b3858?0x1:0x0),_0x16cd8d['reverse']();const _0x36aa5a=_0x16cd8d['join']('');let _0x5be286='';for(_0x2ba445=0x0;_0x2ba445<0x40;_0x2ba445+=0x8){let _0x289383=parseInt(_0x36aa5a['substr'](_0x2ba445,0x8),0x2)['toString'](0x10);_0x289383['length']===0x1&&(_0x289383='0'+_0x289383),_0x5be286=_0x5be286+_0x289383;}return _0x5be286['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3f0ffe,_0x26ab7c){let _0x36fa00='Unknown\x20Error';_0x3f0ffe==='too_big'?_0x36fa00='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3f0ffe==='permission_denied'?_0x36fa00='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3f0ffe==='unavailable'&&(_0x36fa00='The\x20service\x20is\x20unavailable');const _0x3fc5a9=new Error(_0x3f0ffe+'\x20at\x20'+_0x26ab7c['_path']['toString']()+':\x20'+_0x36fa00);return _0x3fc5a9['code']=_0x3f0ffe['toUpperCase'](),_0x3fc5a9;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x16a69f){if(Yl['test'](_0x16a69f)){const _0x4d832b=Number(_0x16a69f);if(_0x4d832b>=Ql&&_0x4d832b<=Jl)return _0x4d832b;}return null;},ft=function(_0x32085f){try{_0x32085f();}catch(_0x3ca190){setTimeout(()=>{const _0x2bc683=_0x3ca190['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2bc683),_0x3ca190;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x4a5d00,_0x53b064){const _0x10ce1b=setTimeout(_0x4a5d00,_0x53b064);return typeof _0x10ce1b=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x10ce1b):typeof _0x10ce1b=='object'&&_0x10ce1b['unref']&&_0x10ce1b['unref'](),_0x10ce1b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x33a8a6,_0x227a3f){this['appCheckProvider']=_0x227a3f,this['appName']=_0x33a8a6['name'],$(_0x33a8a6)&&_0x33a8a6['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x33a8a6['settings']['appCheckToken']),this['appCheck']=_0x227a3f==null?void 0x0:_0x227a3f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x227a3f==null||_0x227a3f['get']()['then'](_0x5d1f06=>this['appCheck']=_0x5d1f06);}['getToken'](_0x551441){if(this['serverAppAppCheckToken']){if(_0x551441)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x551441):new Promise((_0x3984d,_0x339fcb)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x551441)['then'](_0x3984d,_0x339fcb):_0x3984d(null);},0x0);});}['addTokenChangeListener'](_0x30e377){var _0x166959;(_0x166959=this['appCheckProvider'])==null||_0x166959['get']()['then'](_0x5a6b53=>_0x5a6b53['addTokenListener'](_0x30e377));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x42fa51,_0x3504eb,_0x3fc543){this['appName_']=_0x42fa51,this['firebaseOptions_']=_0x3504eb,this['authProvider_']=_0x3fc543,this['auth_']=null,this['auth_']=_0x3fc543['getImmediate']({'optional':!0x0}),this['auth_']||_0x3fc543['onInit'](_0x49a870=>this['auth_']=_0x49a870);}['getToken'](_0x370203){return this['auth_']?this['auth_']['getToken'](_0x370203)['catch'](_0x486c6a=>_0x486c6a&&_0x486c6a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x486c6a)):new Promise((_0x37db27,_0x2f0a95)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x370203)['then'](_0x37db27,_0x2f0a95):_0x37db27(null);},0x0);});}['addTokenChangeListener'](_0x150809){this['auth_']?this['auth_']['addAuthTokenListener'](_0x150809):this['authProvider_']['get']()['then'](_0x5a56f8=>_0x5a56f8['addAuthTokenListener'](_0x150809));}['removeTokenChangeListener'](_0x4d4c48){this['authProvider_']['get']()['then'](_0x5e0816=>_0x5e0816['removeAuthTokenListener'](_0x4d4c48));}['notifyForInvalidToken'](){let _0x27605b='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x27605b+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x27605b+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x27605b+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x27605b);}}class an{constructor(_0x2cc176){this['accessToken']=_0x2cc176;}['getToken'](_0xf64bda){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x442021){_0x442021(this['accessToken']);}['removeTokenChangeListener'](_0x4efe2a){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x49fd70,_0x4d1ed8,_0x2fd6d6,_0x4d857e,_0x3dccce=!0x1,_0x14d6ca='',_0x26c06a=!0x1,_0x4ceeb3=!0x1,_0x2f7b94=null){this['secure']=_0x4d1ed8,this['namespace']=_0x2fd6d6,this['webSocketOnly']=_0x4d857e,this['nodeAdmin']=_0x3dccce,this['persistenceKey']=_0x14d6ca,this['includeNamespaceInQueryParams']=_0x26c06a,this['isUsingEmulator']=_0x4ceeb3,this['emulatorOptions']=_0x2f7b94,this['_host']=_0x49fd70['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x49fd70)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x558956){_0x558956!==this['internalHost']&&(this['internalHost']=_0x558956,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x203ad5=this['toURLString']();return this['persistenceKey']&&(_0x203ad5+='<'+this['persistenceKey']+'>'),_0x203ad5;}['toURLString'](){const _0x49ec63=this['secure']?'https://':'http://',_0x514252=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x49ec63+this['host']+'/'+_0x514252;}}function th(_0x5bcb68){return _0x5bcb68['host']!==_0x5bcb68['internalHost']||_0x5bcb68['isCustomHost']()||_0x5bcb68['includeNamespaceInQueryParams'];}function vo(_0x4c0c4d,_0xca8b78,_0x1172c6){f(typeof _0xca8b78=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1172c6=='object','typeof\x20params\x20must\x20==\x20object');let _0x13e4ee;if(_0xca8b78===go)_0x13e4ee=(_0x4c0c4d['secure']?'wss://':'ws://')+_0x4c0c4d['internalHost']+'/.ws?';else{if(_0xca8b78===mo)_0x13e4ee=(_0x4c0c4d['secure']?'https://':'http://')+_0x4c0c4d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0xca8b78);}th(_0x4c0c4d)&&(_0x1172c6['ns']=_0x4c0c4d['namespace']);const _0xb51f81=[];return x(_0x1172c6,(_0x385cf0,_0x1edcbe)=>{_0xb51f81['push'](_0x385cf0+'='+_0x1edcbe);}),_0x13e4ee+_0xb51f81['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4b7bfb,_0x5be822=0x1){Q(this['counters_'],_0x4b7bfb)||(this['counters_'][_0x4b7bfb]=0x0),this['counters_'][_0x4b7bfb]+=_0x5be822;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x156bfe){const _0x5d8ba0=_0x156bfe['toString']();return oi[_0x5d8ba0]||(oi[_0x5d8ba0]=new nh()),oi[_0x5d8ba0];}function ih(_0x20387b,_0x309a3c){const _0xf2356e=_0x20387b['toString']();return ai[_0xf2356e]||(ai[_0xf2356e]=_0x309a3c()),ai[_0xf2356e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x51181){this['onMessage_']=_0x51181,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x59965c,_0x3837c2){this['closeAfterResponse']=_0x59965c,this['onClose']=_0x3837c2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x44a456,_0x53c6c3){for(this['pendingResponses'][_0x44a456]=_0x53c6c3;this['pendingResponses'][this['currentResponseNum']];){const _0x29503e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x569baa=0x0;_0x569baa<_0x29503e['length'];++_0x569baa)_0x29503e[_0x569baa]&&ft(()=>{this['onMessage_'](_0x29503e[_0x569baa]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x34a697,_0x3db3a1,_0x23ac3e,_0x1041ca,_0x32c616,_0x2e5741,_0x3b24a5){this['connId']=_0x34a697,this['repoInfo']=_0x3db3a1,this['applicationId']=_0x23ac3e,this['appCheckToken']=_0x1041ca,this['authToken']=_0x32c616,this['transportSessionId']=_0x2e5741,this['lastSessionId']=_0x3b24a5,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x34a697),this['stats_']=qi(_0x3db3a1),this['urlFn']=_0x2c6611=>(this['appCheckToken']&&(_0x2c6611[wi]=this['appCheckToken']),vo(_0x3db3a1,mo,_0x2c6611));}['open'](_0x127a82,_0xe9c8e9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xe9c8e9,this['myPacketOrderer']=new sh(_0x127a82),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x56a307)=>{const [_0x53ab69,_0x16c8d3,_0x322330,_0x449e40,_0x97156a]=_0x56a307;if(this['incrementIncomingBytes_'](_0x56a307),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x53ab69===qs)this['id']=_0x16c8d3,this['password']=_0x322330;else{if(_0x53ab69===rh)_0x16c8d3?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x16c8d3,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x53ab69);}}},(..._0x55f85b)=>{const [_0x30e62b,_0x1b54e9]=_0x55f85b;this['incrementIncomingBytes_'](_0x55f85b),this['myPacketOrderer']['handleResponse'](_0x30e62b,_0x1b54e9);},()=>{this['onClosed_']();},this['urlFn']);const _0x3abb80={};_0x3abb80[qs]='t',_0x3abb80[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3abb80[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3abb80[co]=Gi,this['transportSessionId']&&(_0x3abb80[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3abb80[po]=this['lastSessionId']),this['applicationId']&&(_0x3abb80[_o]=this['applicationId']),this['appCheckToken']&&(_0x3abb80[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3abb80[ho]=uo);const _0x4b2be4=this['urlFn'](_0x3abb80);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4b2be4),this['scriptTagHolder']['addTag'](_0x4b2be4,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x44433e){const _0x5e4c79=O(_0x44433e);this['bytesSent']+=_0x5e4c79['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5e4c79['length']);const _0x46a2e2=$r(_0x5e4c79),_0x3d8a6a=oo(_0x46a2e2,fh);for(let _0x43392d=0x0;_0x43392d<_0x3d8a6a['length'];_0x43392d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3d8a6a['length'],_0x3d8a6a[_0x43392d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x49bc93,_0x4927d3){this['myDisconnFrame']=document['createElement']('iframe');const _0x197399={};_0x197399[dh]='t',_0x197399[Eo]=_0x49bc93,_0x197399[Io]=_0x4927d3,this['myDisconnFrame']['src']=this['urlFn'](_0x197399),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x23c5a2){const _0x2f52df=O(_0x23c5a2)['length'];this['bytesReceived']+=_0x2f52df,this['stats_']['incrementCounter']('bytes_received',_0x2f52df);}}class zi{constructor(_0x5eadbe,_0x5c3bb2,_0x1b855e,_0x2bbf16){this['onDisconnect']=_0x1b855e,this['urlFn']=_0x2bbf16,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5eadbe,window[ah+this['uniqueCallbackIdentifier']]=_0x5c3bb2,this['myIFrame']=zi['createIFrame_']();let _0x27f71b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x27f71b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x359ccf='<html><body>'+_0x27f71b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x359ccf),this['myIFrame']['doc']['close']();}catch(_0x54592d){L('frame\x20writing\x20exception'),_0x54592d['stack']&&L(_0x54592d['stack']),L(_0x54592d);}}}static['createIFrame_'](){const _0x311573=document['createElement']('iframe');if(_0x311573['style']['display']='none',document['body']){document['body']['appendChild'](_0x311573);try{_0x311573['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3bcb94=document['domain'];_0x311573['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3bcb94+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x311573['contentDocument']?_0x311573['doc']=_0x311573['contentDocument']:_0x311573['contentWindow']?_0x311573['doc']=_0x311573['contentWindow']['document']:_0x311573['document']&&(_0x311573['doc']=_0x311573['document']),_0x311573;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1bcc97=this['onDisconnect'];_0x1bcc97&&(this['onDisconnect']=null,_0x1bcc97());}['startLongPoll'](_0x1554ad,_0x227c31){for(this['myID']=_0x1554ad,this['myPW']=_0x227c31,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1cedb5={};_0x1cedb5[Eo]=this['myID'],_0x1cedb5[Io]=this['myPW'],_0x1cedb5[wo]=this['currentSerial'];let _0x20d0da=this['urlFn'](_0x1cedb5),_0x3ad14f='',_0x5edc20=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x3ad14f['length']<=Co;){const _0x4cb105=this['pendingSegs']['shift']();_0x3ad14f=_0x3ad14f+'&'+lh+_0x5edc20+'='+_0x4cb105['seg']+'&'+hh+_0x5edc20+'='+_0x4cb105['ts']+'&'+uh+_0x5edc20+'='+_0x4cb105['d'],_0x5edc20++;}return _0x20d0da=_0x20d0da+_0x3ad14f,this['addLongPollTag_'](_0x20d0da,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x95a5c1,_0x172b56,_0x5128eb){this['pendingSegs']['push']({'seg':_0x95a5c1,'ts':_0x172b56,'d':_0x5128eb}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x24c78a,_0x7a6b4a){this['outstandingRequests']['add'](_0x7a6b4a);const _0x13a730=()=>{this['outstandingRequests']['delete'](_0x7a6b4a),this['newRequest_']();},_0x1f35fe=setTimeout(_0x13a730,Math['floor'](ph)),_0x4781fd=()=>{clearTimeout(_0x1f35fe),_0x13a730();};this['addTag'](_0x24c78a,_0x4781fd);}['addTag'](_0x1e9621,_0x4231a7){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x510c82=this['myIFrame']['doc']['createElement']('script');_0x510c82['type']='text/javascript',_0x510c82['async']=!0x0,_0x510c82['src']=_0x1e9621,_0x510c82['onload']=_0x510c82['onreadystatechange']=function(){const _0x122c95=_0x510c82['readyState'];(!_0x122c95||_0x122c95==='loaded'||_0x122c95==='complete')&&(_0x510c82['onload']=_0x510c82['onreadystatechange']=null,_0x510c82['parentNode']&&_0x510c82['parentNode']['removeChild'](_0x510c82),_0x4231a7());},_0x510c82['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x1e9621),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x510c82);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x545852,_0xdaccd6,_0x51859d,_0x38d6a4,_0x54be66,_0x400df3,_0x526293){this['connId']=_0x545852,this['applicationId']=_0x51859d,this['appCheckToken']=_0x38d6a4,this['authToken']=_0x54be66,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0xdaccd6),this['connURL']=q['connectionURL_'](_0xdaccd6,_0x400df3,_0x526293,_0x38d6a4,_0x51859d),this['nodeAdmin']=_0xdaccd6['nodeAdmin'];}static['connectionURL_'](_0x2ccb21,_0x24e2a2,_0x288e0c,_0x32527e,_0x3bc584){const _0x3dbbc4={};return _0x3dbbc4[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3dbbc4[ho]=uo),_0x24e2a2&&(_0x3dbbc4[lo]=_0x24e2a2),_0x288e0c&&(_0x3dbbc4[po]=_0x288e0c),_0x32527e&&(_0x3dbbc4[wi]=_0x32527e),_0x3bc584&&(_0x3dbbc4[_o]=_0x3bc584),vo(_0x2ccb21,go,_0x3dbbc4);}['open'](_0x418a95,_0x166ca4){this['onDisconnect']=_0x166ca4,this['onMessage']=_0x418a95,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x4f1ef1;_c(),this['mySock']=new gn(this['connURL'],[],_0x4f1ef1);}catch(_0x2854ed){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1535be=_0x2854ed['message']||_0x2854ed['data'];_0x1535be&&this['log_'](_0x1535be),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x14eb95=>{this['handleIncomingFrame'](_0x14eb95);},this['mySock']['onerror']=_0x5670d5=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x15dab6=_0x5670d5['message']||_0x5670d5['data'];_0x15dab6&&this['log_'](_0x15dab6),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x171c6e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x26a606=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xd7cb9b=navigator['userAgent']['match'](_0x26a606);_0xd7cb9b&&_0xd7cb9b['length']>0x1&&parseFloat(_0xd7cb9b[0x1])<4.4&&(_0x171c6e=!0x0);}return!_0x171c6e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5be5bb){if(this['frames']['push'](_0x5be5bb),this['frames']['length']===this['totalFrames']){const _0x16a96a=this['frames']['join']('');this['frames']=null;const _0x54c7c2=Nt(_0x16a96a);this['onMessage'](_0x54c7c2);}}['handleNewFrameCount_'](_0x19b62d){this['totalFrames']=_0x19b62d,this['frames']=[];}['extractFrameCount_'](_0x568e10){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x568e10['length']<=0x6){const _0x1b082e=Number(_0x568e10);if(!isNaN(_0x1b082e))return this['handleNewFrameCount_'](_0x1b082e),null;}return this['handleNewFrameCount_'](0x1),_0x568e10;}['handleIncomingFrame'](_0x537890){if(this['mySock']===null)return;const _0x54adc2=_0x537890['data'];if(this['bytesReceived']+=_0x54adc2['length'],this['stats_']['incrementCounter']('bytes_received',_0x54adc2['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x54adc2);else{const _0x2d07c7=this['extractFrameCount_'](_0x54adc2);_0x2d07c7!==null&&this['appendFrame_'](_0x2d07c7);}}['send'](_0x1df029){this['resetKeepAlive']();const _0x30a2b9=O(_0x1df029);this['bytesSent']+=_0x30a2b9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x30a2b9['length']);const _0x221972=oo(_0x30a2b9,gh);_0x221972['length']>0x1&&this['sendString_'](String(_0x221972['length']));for(let _0x2424a7=0x0;_0x2424a7<_0x221972['length'];_0x2424a7++)this['sendString_'](_0x221972[_0x2424a7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1e6080){try{this['mySock']['send'](_0x1e6080);}catch(_0x4d78bf){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4d78bf['message']||_0x4d78bf['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xdf2b4f){this['initTransports_'](_0xdf2b4f);}['initTransports_'](_0x4ea7d4){const _0x560861=q&&q['isAvailable']();let _0x96c9d8=_0x560861&&!q['previouslyFailed']();if(_0x4ea7d4['webSocketOnly']&&(_0x560861||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x96c9d8=!0x0),_0x96c9d8)this['transports_']=[q];else{const _0x1306be=this['transports_']=[];for(const _0x4931b7 of Ot['ALL_TRANSPORTS'])_0x4931b7&&_0x4931b7['isAvailable']()&&_0x1306be['push'](_0x4931b7);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4ca056,_0x4b8553,_0xeb8092,_0x38198e,_0x533672,_0x9eb4ce,_0x244ed7,_0xc8f7bf,_0x337296,_0x28a990){this['id']=_0x4ca056,this['repoInfo_']=_0x4b8553,this['applicationId_']=_0xeb8092,this['appCheckToken_']=_0x38198e,this['authToken_']=_0x533672,this['onMessage_']=_0x9eb4ce,this['onReady_']=_0x244ed7,this['onDisconnect_']=_0xc8f7bf,this['onKill_']=_0x337296,this['lastSessionId']=_0x28a990,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x4b8553),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x58da6f=this['transportManager_']['initialTransport']();this['conn_']=new _0x58da6f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x58da6f['responsesRequiredToBeHealthy']||0x0;const _0x2f8375=this['connReceiver_'](this['conn_']),_0x49fc5a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2f8375,_0x49fc5a);},Math['floor'](0x0));const _0x219c56=_0x58da6f['healthyTimeout']||0x0;_0x219c56>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x219c56)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x16e4cb){return _0x53a88d=>{_0x16e4cb===this['conn_']?this['onConnectionLost_'](_0x53a88d):_0x16e4cb===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3a2172){return _0x1efdaa=>{this['state_']!==0x2&&(_0x3a2172===this['rx_']?this['onPrimaryMessageReceived_'](_0x1efdaa):_0x3a2172===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1efdaa):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x9770ad){const _0x22e02b={'t':'d','d':_0x9770ad};this['sendData_'](_0x22e02b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x45f80c){if(ci in _0x45f80c){const _0x15d527=_0x45f80c[ci];_0x15d527===Ys?this['upgradeIfSecondaryHealthy_']():_0x15d527===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x15d527===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x521dc1){const _0x742f8=yt('t',_0x521dc1),_0x12f9e3=yt('d',_0x521dc1);if(_0x742f8==='c')this['onSecondaryControl_'](_0x12f9e3);else{if(_0x742f8==='d')this['pendingDataMessages']['push'](_0x12f9e3);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x742f8);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x75eea2){const _0x1b498a=yt('t',_0x75eea2),_0x1c1061=yt('d',_0x75eea2);_0x1b498a==='c'?this['onControl_'](_0x1c1061):_0x1b498a==='d'&&this['onDataMessage_'](_0x1c1061);}['onDataMessage_'](_0x4bc51e){this['onPrimaryResponse_'](),this['onMessage_'](_0x4bc51e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x445755){const _0x7795a7=yt(ci,_0x445755);if(zs in _0x445755){const _0x26fff1=_0x445755[zs];if(_0x7795a7===Th){const _0x5b6a3a={..._0x26fff1};this['repoInfo_']['isUsingEmulator']&&(_0x5b6a3a['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5b6a3a);}else{if(_0x7795a7===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2a182c=0x0;_0x2a182c<this['pendingDataMessages']['length'];++_0x2a182c)this['onDataMessage_'](this['pendingDataMessages'][_0x2a182c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x7795a7===wh?this['onConnectionShutdown_'](_0x26fff1):_0x7795a7===js?this['onReset_'](_0x26fff1):_0x7795a7===Ch?Ii('Server\x20Error:\x20'+_0x26fff1):_0x7795a7===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x7795a7);}}}['onHandshake_'](_0x197075){const _0x298431=_0x197075['ts'],_0x49ce34=_0x197075['v'],_0x2e359b=_0x197075['h'];this['sessionId']=_0x197075['s'],this['repoInfo_']['host']=_0x2e359b,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x298431),Gi!==_0x49ce34&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x564e84=this['transportManager_']['upgradeTransport']();_0x564e84&&this['startUpgrade_'](_0x564e84);}['startUpgrade_'](_0x4d5682){this['secondaryConn_']=new _0x4d5682(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4d5682['responsesRequiredToBeHealthy']||0x0;const _0x3e8a75=this['connReceiver_'](this['secondaryConn_']),_0x3be81a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3e8a75,_0x3be81a),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x56ada7){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x56ada7),this['repoInfo_']['host']=_0x56ada7,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x11b25a,_0x376de8){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x11b25a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x376de8,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x33ccc9=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x33ccc9||this['rx_']===_0x33ccc9)&&this['close']();}['onConnectionLost_'](_0x355285){this['conn_']=null,!_0x355285&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3bae40){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3bae40),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2e444a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2e444a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3caa65,_0x102036,_0x5c0de2,_0x29521f){}['merge'](_0x450a76,_0x51c6b6,_0x432b35,_0x432569){}['refreshAuthToken'](_0x30973d){}['refreshAppCheckToken'](_0x541c37){}['onDisconnectPut'](_0x553de1,_0x2521ca,_0x206585){}['onDisconnectMerge'](_0x50d0fe,_0x7bab98,_0x4084df){}['onDisconnectCancel'](_0xb420f0,_0x52ff00){}['reportStats'](_0x479940){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x35bc2c){this['allowedEvents_']=_0x35bc2c,this['listeners_']={},f(Array['isArray'](_0x35bc2c)&&_0x35bc2c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5c221c,..._0x2a3a82){if(Array['isArray'](this['listeners_'][_0x5c221c])){const _0x2b5277=[...this['listeners_'][_0x5c221c]];for(let _0x26600a=0x0;_0x26600a<_0x2b5277['length'];_0x26600a++)_0x2b5277[_0x26600a]['callback']['apply'](_0x2b5277[_0x26600a]['context'],_0x2a3a82);}}['on'](_0xb39cb3,_0x26184f,_0x40d903){this['validateEventType_'](_0xb39cb3),this['listeners_'][_0xb39cb3]=this['listeners_'][_0xb39cb3]||[],this['listeners_'][_0xb39cb3]['push']({'callback':_0x26184f,'context':_0x40d903});const _0x5a1d7b=this['getInitialEvent'](_0xb39cb3);_0x5a1d7b&&_0x26184f['apply'](_0x40d903,_0x5a1d7b);}['off'](_0x1962a6,_0x20ad4b,_0x314610){this['validateEventType_'](_0x1962a6);const _0x35e686=this['listeners_'][_0x1962a6]||[];for(let _0xd11a43=0x0;_0xd11a43<_0x35e686['length'];_0xd11a43++)if(_0x35e686[_0xd11a43]['callback']===_0x20ad4b&&(!_0x314610||_0x314610===_0x35e686[_0xd11a43]['context'])){_0x35e686['splice'](_0xd11a43,0x1);return;}}['validateEventType_'](_0x14cf89){f(this['allowedEvents_']['find'](_0xbdb901=>_0xbdb901===_0x14cf89),'Unknown\x20event:\x20'+_0x14cf89);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x70d0eb){return f(_0x70d0eb==='online','Unknown\x20event\x20type:\x20'+_0x70d0eb),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x22b9c7,_0x20a899){if(_0x20a899===void 0x0){this['pieces_']=_0x22b9c7['split']('/');let _0x13ca84=0x0;for(let _0x2ba1b3=0x0;_0x2ba1b3<this['pieces_']['length'];_0x2ba1b3++)this['pieces_'][_0x2ba1b3]['length']>0x0&&(this['pieces_'][_0x13ca84]=this['pieces_'][_0x2ba1b3],_0x13ca84++);this['pieces_']['length']=_0x13ca84,this['pieceNum_']=0x0;}else this['pieces_']=_0x22b9c7,this['pieceNum_']=_0x20a899;}['toString'](){let _0x3f5885='';for(let _0x5d4346=this['pieceNum_'];_0x5d4346<this['pieces_']['length'];_0x5d4346++)this['pieces_'][_0x5d4346]!==''&&(_0x3f5885+='/'+this['pieces_'][_0x5d4346]);return _0x3f5885||'/';}}function w(){return new C('');}function y(_0x8525bc){return _0x8525bc['pieceNum_']>=_0x8525bc['pieces_']['length']?null:_0x8525bc['pieces_'][_0x8525bc['pieceNum_']];}function Ce(_0xa5e54f){return _0xa5e54f['pieces_']['length']-_0xa5e54f['pieceNum_'];}function S(_0x382b7d){let _0xdcf825=_0x382b7d['pieceNum_'];return _0xdcf825<_0x382b7d['pieces_']['length']&&_0xdcf825++,new C(_0x382b7d['pieces_'],_0xdcf825);}function ji(_0x2f987f){return _0x2f987f['pieceNum_']<_0x2f987f['pieces_']['length']?_0x2f987f['pieces_'][_0x2f987f['pieces_']['length']-0x1]:null;}function bh(_0x1e5c02){let _0x5353c6='';for(let _0x1a303f=_0x1e5c02['pieceNum_'];_0x1a303f<_0x1e5c02['pieces_']['length'];_0x1a303f++)_0x1e5c02['pieces_'][_0x1a303f]!==''&&(_0x5353c6+='/'+encodeURIComponent(String(_0x1e5c02['pieces_'][_0x1a303f])));return _0x5353c6||'/';}function Dt(_0xe849ff,_0xac820e=0x0){return _0xe849ff['pieces_']['slice'](_0xe849ff['pieceNum_']+_0xac820e);}function Ro(_0x440278){if(_0x440278['pieceNum_']>=_0x440278['pieces_']['length'])return null;const _0x447401=[];for(let _0x5c9a19=_0x440278['pieceNum_'];_0x5c9a19<_0x440278['pieces_']['length']-0x1;_0x5c9a19++)_0x447401['push'](_0x440278['pieces_'][_0x5c9a19]);return new C(_0x447401,0x0);}function k(_0x234bd7,_0x142084){const _0x1f22d3=[];for(let _0x58df6c=_0x234bd7['pieceNum_'];_0x58df6c<_0x234bd7['pieces_']['length'];_0x58df6c++)_0x1f22d3['push'](_0x234bd7['pieces_'][_0x58df6c]);if(_0x142084 instanceof C){for(let _0x40819a=_0x142084['pieceNum_'];_0x40819a<_0x142084['pieces_']['length'];_0x40819a++)_0x1f22d3['push'](_0x142084['pieces_'][_0x40819a]);}else{const _0x29cec9=_0x142084['split']('/');for(let _0x5cf907=0x0;_0x5cf907<_0x29cec9['length'];_0x5cf907++)_0x29cec9[_0x5cf907]['length']>0x0&&_0x1f22d3['push'](_0x29cec9[_0x5cf907]);}return new C(_0x1f22d3,0x0);}function v(_0x31cb8f){return _0x31cb8f['pieceNum_']>=_0x31cb8f['pieces_']['length'];}function F(_0x926918,_0x325ef5){const _0x4eabec=y(_0x926918),_0x40cb4d=y(_0x325ef5);if(_0x4eabec===null)return _0x325ef5;if(_0x4eabec===_0x40cb4d)return F(S(_0x926918),S(_0x325ef5));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x325ef5+')\x20is\x20not\x20within\x20outerPath\x20('+_0x926918+')');}function Rh(_0x2daf0b,_0x562805){const _0x90dd31=Dt(_0x2daf0b,0x0),_0x405c64=Dt(_0x562805,0x0);for(let _0x3fa6fe=0x0;_0x3fa6fe<_0x90dd31['length']&&_0x3fa6fe<_0x405c64['length'];_0x3fa6fe++){const _0x388b68=Ge(_0x90dd31[_0x3fa6fe],_0x405c64[_0x3fa6fe]);if(_0x388b68!==0x0)return _0x388b68;}return _0x90dd31['length']===_0x405c64['length']?0x0:_0x90dd31['length']<_0x405c64['length']?-0x1:0x1;}function Ki(_0x2d79fa,_0x4b6332){if(Ce(_0x2d79fa)!==Ce(_0x4b6332))return!0x1;for(let _0x107172=_0x2d79fa['pieceNum_'],_0x482cf9=_0x4b6332['pieceNum_'];_0x107172<=_0x2d79fa['pieces_']['length'];_0x107172++,_0x482cf9++)if(_0x2d79fa['pieces_'][_0x107172]!==_0x4b6332['pieces_'][_0x482cf9])return!0x1;return!0x0;}function G(_0x5ab042,_0x88da4f){let _0x3a3144=_0x5ab042['pieceNum_'],_0x44c41b=_0x88da4f['pieceNum_'];if(Ce(_0x5ab042)>Ce(_0x88da4f))return!0x1;for(;_0x3a3144<_0x5ab042['pieces_']['length'];){if(_0x5ab042['pieces_'][_0x3a3144]!==_0x88da4f['pieces_'][_0x44c41b])return!0x1;++_0x3a3144,++_0x44c41b;}return!0x0;}class Ah{constructor(_0x1c4b50,_0x362e87){this['errorPrefix_']=_0x362e87,this['parts_']=Dt(_0x1c4b50,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4eaa5b=0x0;_0x4eaa5b<this['parts_']['length'];_0x4eaa5b++)this['byteLength_']+=Ln(this['parts_'][_0x4eaa5b]);Ao(this);}}function kh(_0x55520e,_0xfa8d36){_0x55520e['parts_']['length']>0x0&&(_0x55520e['byteLength_']+=0x1),_0x55520e['parts_']['push'](_0xfa8d36),_0x55520e['byteLength_']+=Ln(_0xfa8d36),Ao(_0x55520e);}function Nh(_0x2f01a8){const _0x13c531=_0x2f01a8['parts_']['pop']();_0x2f01a8['byteLength_']-=Ln(_0x13c531),_0x2f01a8['parts_']['length']>0x0&&(_0x2f01a8['byteLength_']-=0x1);}function Ao(_0x462ef1){if(_0x462ef1['byteLength_']>Zs)throw new Error(_0x462ef1['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x462ef1['byteLength_']+').');if(_0x462ef1['parts_']['length']>Xs)throw new Error(_0x462ef1['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x462ef1));}function Pe(_0x3f405b){return _0x3f405b['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3f405b['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x424bdb,_0x2a1fea;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2a1fea='visibilitychange',_0x424bdb='hidden'):typeof document['mozHidden']<'u'?(_0x2a1fea='mozvisibilitychange',_0x424bdb='mozHidden'):typeof document['msHidden']<'u'?(_0x2a1fea='msvisibilitychange',_0x424bdb='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2a1fea='webkitvisibilitychange',_0x424bdb='webkitHidden')),this['visible_']=!0x0,_0x2a1fea&&document['addEventListener'](_0x2a1fea,()=>{const _0x3a833c=!document[_0x424bdb];_0x3a833c!==this['visible_']&&(this['visible_']=_0x3a833c,this['trigger']('visible',_0x3a833c));},!0x1);}['getInitialEvent'](_0x1eebee){return f(_0x1eebee==='visible','Unknown\x20event\x20type:\x20'+_0x1eebee),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x131fcb,_0x5c13cb,_0x5c8190,_0x5021d0,_0x5686b6,_0x551adb,_0x46d019,_0x12fc32){if(super(),this['repoInfo_']=_0x131fcb,this['applicationId_']=_0x5c13cb,this['onDataUpdate_']=_0x5c8190,this['onConnectStatus_']=_0x5021d0,this['onServerInfoUpdate_']=_0x5686b6,this['authTokenProvider_']=_0x551adb,this['appCheckTokenProvider_']=_0x46d019,this['authOverride_']=_0x12fc32,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x12fc32)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x131fcb['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1a2b9d,_0x241fcf,_0x16b5c3){const _0x1b9f01=++this['requestNumber_'],_0x5d7516={'r':_0x1b9f01,'a':_0x1a2b9d,'b':_0x241fcf};this['log_'](O(_0x5d7516)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5d7516),_0x16b5c3&&(this['requestCBHash_'][_0x1b9f01]=_0x16b5c3);}['get'](_0x438e0c){this['initConnection_']();const _0x5cee63=new H(),_0x10d112={'action':'g','request':{'p':_0x438e0c['_path']['toString'](),'q':_0x438e0c['_queryObject']},'onComplete':_0x920040=>{const _0xc304bf=_0x920040['d'];_0x920040['s']==='ok'?_0x5cee63['resolve'](_0xc304bf):_0x5cee63['reject'](_0xc304bf);}};this['outstandingGets_']['push'](_0x10d112),this['outstandingGetCount_']++;const _0x4dd1f3=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4dd1f3),_0x5cee63['promise'];}['listen'](_0x2b8872,_0x2b5c39,_0x20cd0a,_0x16f8f5){this['initConnection_']();const _0x444d50=_0x2b8872['_queryIdentifier'],_0x38f463=_0x2b8872['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x38f463+'\x20'+_0x444d50),this['listens']['has'](_0x38f463)||this['listens']['set'](_0x38f463,new Map()),f(_0x2b8872['_queryParams']['isDefault']()||!_0x2b8872['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x38f463)['has'](_0x444d50),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x376fa9={'onComplete':_0x16f8f5,'hashFn':_0x2b5c39,'query':_0x2b8872,'tag':_0x20cd0a};this['listens']['get'](_0x38f463)['set'](_0x444d50,_0x376fa9),this['connected_']&&this['sendListen_'](_0x376fa9);}['sendGet_'](_0x3dcc4e){const _0x52ac91=this['outstandingGets_'][_0x3dcc4e];this['sendRequest']('g',_0x52ac91['request'],_0x165379=>{delete this['outstandingGets_'][_0x3dcc4e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x52ac91['onComplete']&&_0x52ac91['onComplete'](_0x165379);});}['sendListen_'](_0x2d155a){const _0x2592c4=_0x2d155a['query'],_0x43e6d3=_0x2592c4['_path']['toString'](),_0x4441d6=_0x2592c4['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x43e6d3+'\x20for\x20'+_0x4441d6);const _0x5c4500={'p':_0x43e6d3},_0x69dc9f='q';_0x2d155a['tag']&&(_0x5c4500['q']=_0x2592c4['_queryObject'],_0x5c4500['t']=_0x2d155a['tag']),_0x5c4500['h']=_0x2d155a['hashFn'](),this['sendRequest'](_0x69dc9f,_0x5c4500,_0x5393bf=>{const _0xdc3993=_0x5393bf['d'],_0x5c8298=_0x5393bf['s'];se['warnOnListenWarnings_'](_0xdc3993,_0x2592c4),(this['listens']['get'](_0x43e6d3)&&this['listens']['get'](_0x43e6d3)['get'](_0x4441d6))===_0x2d155a&&(this['log_']('listen\x20response',_0x5393bf),_0x5c8298!=='ok'&&this['removeListen_'](_0x43e6d3,_0x4441d6),_0x2d155a['onComplete']&&_0x2d155a['onComplete'](_0x5c8298,_0xdc3993));});}static['warnOnListenWarnings_'](_0x322e41,_0x362242){if(_0x322e41&&typeof _0x322e41=='object'&&Q(_0x322e41,'w')){const _0x420d15=Me(_0x322e41,'w');if(Array['isArray'](_0x420d15)&&~_0x420d15['indexOf']('no_index')){const _0x4dca1d='\x22.indexOn\x22:\x20\x22'+_0x362242['_queryParams']['getIndex']()['toString']()+'\x22',_0x460d4f=_0x362242['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4dca1d+'\x20at\x20'+_0x460d4f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x10b45d){this['authToken_']=_0x10b45d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x10b45d);}['reduceReconnectDelayIfAdminCredential_'](_0x1e0269){(_0x1e0269&&_0x1e0269['length']===0x28||wc(_0x1e0269))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x5d7cba){this['appCheckToken_']=_0x5d7cba,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4d40d0=this['authToken_'],_0x2483f7=Ic(_0x4d40d0)?'auth':'gauth',_0xbda2f2={'cred':_0x4d40d0};this['authOverride_']===null?_0xbda2f2['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xbda2f2['authvar']=this['authOverride_']),this['sendRequest'](_0x2483f7,_0xbda2f2,_0x32a11b=>{const _0x5ec843=_0x32a11b['s'],_0x58a6e1=_0x32a11b['d']||'error';this['authToken_']===_0x4d40d0&&(_0x5ec843==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5ec843,_0x58a6e1));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x261453=>{const _0x3f3aca=_0x261453['s'],_0x555a70=_0x261453['d']||'error';_0x3f3aca==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3f3aca,_0x555a70);});}['unlisten'](_0x2eabbe,_0x23d3aa){const _0x4f8de7=_0x2eabbe['_path']['toString'](),_0x9bece0=_0x2eabbe['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4f8de7+'\x20'+_0x9bece0),f(_0x2eabbe['_queryParams']['isDefault']()||!_0x2eabbe['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4f8de7,_0x9bece0)&&this['connected_']&&this['sendUnlisten_'](_0x4f8de7,_0x9bece0,_0x2eabbe['_queryObject'],_0x23d3aa);}['sendUnlisten_'](_0x2f141d,_0x454014,_0x5d50a8,_0x4fac7b){this['log_']('Unlisten\x20on\x20'+_0x2f141d+'\x20for\x20'+_0x454014);const _0x44018b={'p':_0x2f141d},_0x536484='n';_0x4fac7b&&(_0x44018b['q']=_0x5d50a8,_0x44018b['t']=_0x4fac7b),this['sendRequest'](_0x536484,_0x44018b);}['onDisconnectPut'](_0x469ed2,_0xcc63ca,_0x3025c2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x469ed2,_0xcc63ca,_0x3025c2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x469ed2,'action':'o','data':_0xcc63ca,'onComplete':_0x3025c2});}['onDisconnectMerge'](_0x558ce4,_0x356abc,_0x36f343){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x558ce4,_0x356abc,_0x36f343):this['onDisconnectRequestQueue_']['push']({'pathString':_0x558ce4,'action':'om','data':_0x356abc,'onComplete':_0x36f343});}['onDisconnectCancel'](_0x26dcbc,_0x4c14e2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x26dcbc,null,_0x4c14e2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x26dcbc,'action':'oc','data':null,'onComplete':_0x4c14e2});}['sendOnDisconnect_'](_0x5e1158,_0x25b52b,_0x338996,_0x4bd655){const _0x1aefeb={'p':_0x25b52b,'d':_0x338996};this['log_']('onDisconnect\x20'+_0x5e1158,_0x1aefeb),this['sendRequest'](_0x5e1158,_0x1aefeb,_0x2bbea5=>{_0x4bd655&&setTimeout(()=>{_0x4bd655(_0x2bbea5['s'],_0x2bbea5['d']);},Math['floor'](0x0));});}['put'](_0x57c60a,_0x55e2d1,_0x301d74,_0x12bd82){this['putInternal']('p',_0x57c60a,_0x55e2d1,_0x301d74,_0x12bd82);}['merge'](_0x5b4f89,_0x38b58c,_0x2da1f8,_0x36c439){this['putInternal']('m',_0x5b4f89,_0x38b58c,_0x2da1f8,_0x36c439);}['putInternal'](_0x51c287,_0x4300be,_0x36e2fc,_0x37f749,_0x397626){this['initConnection_']();const _0x2506d1={'p':_0x4300be,'d':_0x36e2fc};_0x397626!==void 0x0&&(_0x2506d1['h']=_0x397626),this['outstandingPuts_']['push']({'action':_0x51c287,'request':_0x2506d1,'onComplete':_0x37f749}),this['outstandingPutCount_']++;const _0x19ede0=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x19ede0):this['log_']('Buffering\x20put:\x20'+_0x4300be);}['sendPut_'](_0x382144){const _0x31d5a1=this['outstandingPuts_'][_0x382144]['action'],_0xfe7eb9=this['outstandingPuts_'][_0x382144]['request'],_0x301e7a=this['outstandingPuts_'][_0x382144]['onComplete'];this['outstandingPuts_'][_0x382144]['queued']=this['connected_'],this['sendRequest'](_0x31d5a1,_0xfe7eb9,_0xbe7caf=>{this['log_'](_0x31d5a1+'\x20response',_0xbe7caf),delete this['outstandingPuts_'][_0x382144],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x301e7a&&_0x301e7a(_0xbe7caf['s'],_0xbe7caf['d']);});}['reportStats'](_0x366903){if(this['connected_']){const _0x52cd9e={'c':_0x366903};this['log_']('reportStats',_0x52cd9e),this['sendRequest']('s',_0x52cd9e,_0x56bb46=>{if(_0x56bb46['s']!=='ok'){const _0x177683=_0x56bb46['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x177683);}});}}['onDataMessage_'](_0x2c7ba4){if('r'in _0x2c7ba4){this['log_']('from\x20server:\x20'+O(_0x2c7ba4));const _0xbd252d=_0x2c7ba4['r'],_0x41b39f=this['requestCBHash_'][_0xbd252d];_0x41b39f&&(delete this['requestCBHash_'][_0xbd252d],_0x41b39f(_0x2c7ba4['b']));}else{if('error'in _0x2c7ba4)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2c7ba4['error'];'a'in _0x2c7ba4&&this['onDataPush_'](_0x2c7ba4['a'],_0x2c7ba4['b']);}}['onDataPush_'](_0x453503,_0x4cdf6c){this['log_']('handleServerMessage',_0x453503,_0x4cdf6c),_0x453503==='d'?this['onDataUpdate_'](_0x4cdf6c['p'],_0x4cdf6c['d'],!0x1,_0x4cdf6c['t']):_0x453503==='m'?this['onDataUpdate_'](_0x4cdf6c['p'],_0x4cdf6c['d'],!0x0,_0x4cdf6c['t']):_0x453503==='c'?this['onListenRevoked_'](_0x4cdf6c['p'],_0x4cdf6c['q']):_0x453503==='ac'?this['onAuthRevoked_'](_0x4cdf6c['s'],_0x4cdf6c['d']):_0x453503==='apc'?this['onAppCheckRevoked_'](_0x4cdf6c['s'],_0x4cdf6c['d']):_0x453503==='sd'?this['onSecurityDebugPacket_'](_0x4cdf6c):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x453503)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x456bd8,_0x394569){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x456bd8),this['lastSessionId']=_0x394569,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x50643f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x50643f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x6b2816){_0x6b2816&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x6b2816;}['onOnline_'](_0x4e8f88){_0x4e8f88?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xb49c6b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x45797f=Math['max'](0x0,this['reconnectDelay_']-_0xb49c6b);_0x45797f=Math['random']()*_0x45797f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x45797f+'ms'),this['scheduleConnect_'](_0x45797f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x32f395=this['onDataMessage_']['bind'](this),_0x2180a0=this['onReady_']['bind'](this),_0x373745=this['onRealtimeDisconnect_']['bind'](this),_0x43f7fd=this['id']+':'+se['nextConnectionId_']++,_0x445f71=this['lastSessionId'];let _0x141d5b=!0x1,_0x53d7f0=null;const _0x44ec7a=function(){_0x53d7f0?_0x53d7f0['close']():(_0x141d5b=!0x0,_0x373745());},_0x2dea2e=function(_0x2971b8){f(_0x53d7f0,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x53d7f0['sendRequest'](_0x2971b8);};this['realtime_']={'close':_0x44ec7a,'sendRequest':_0x2dea2e};const _0x4e73e7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4c61ea,_0x539946]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4e73e7),this['appCheckTokenProvider_']['getToken'](_0x4e73e7)]);_0x141d5b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4c61ea&&_0x4c61ea['accessToken'],this['appCheckToken_']=_0x539946&&_0x539946['token'],_0x53d7f0=new Sh(_0x43f7fd,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x32f395,_0x2180a0,_0x373745,_0x1f10f0=>{U(_0x1f10f0+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x445f71));}catch(_0x5b45a6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5b45a6),_0x141d5b||(this['repoInfo_']['nodeAdmin']&&U(_0x5b45a6),_0x44ec7a());}}}['interrupt'](_0x67ee14){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x67ee14),this['interruptReasons_'][_0x67ee14]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x56c7bd){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x56c7bd),delete this['interruptReasons_'][_0x56c7bd],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1a7743){const _0x5331a9=_0x1a7743-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5331a9});}['cancelSentTransactions_'](){for(let _0x42799e=0x0;_0x42799e<this['outstandingPuts_']['length'];_0x42799e++){const _0x1833f9=this['outstandingPuts_'][_0x42799e];_0x1833f9&&'h'in _0x1833f9['request']&&_0x1833f9['queued']&&(_0x1833f9['onComplete']&&_0x1833f9['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x42799e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2b5177,_0x1c1e0f){let _0x1ac6bb;_0x1c1e0f?_0x1ac6bb=_0x1c1e0f['map'](_0x2fc531=>$i(_0x2fc531))['join']('$'):_0x1ac6bb='default';const _0x1eaa01=this['removeListen_'](_0x2b5177,_0x1ac6bb);_0x1eaa01&&_0x1eaa01['onComplete']&&_0x1eaa01['onComplete']('permission_denied');}['removeListen_'](_0x222184,_0x485014){const _0x12e2fd=new C(_0x222184)['toString']();let _0x47ae05;if(this['listens']['has'](_0x12e2fd)){const _0x56f872=this['listens']['get'](_0x12e2fd);_0x47ae05=_0x56f872['get'](_0x485014),_0x56f872['delete'](_0x485014),_0x56f872['size']===0x0&&this['listens']['delete'](_0x12e2fd);}else _0x47ae05=void 0x0;return _0x47ae05;}['onAuthRevoked_'](_0x56db6d,_0x5c0938){L('Auth\x20token\x20revoked:\x20'+_0x56db6d+'/'+_0x5c0938),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x56db6d==='invalid_token'||_0x56db6d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4ec976,_0x46ab74){L('App\x20check\x20token\x20revoked:\x20'+_0x4ec976+'/'+_0x46ab74),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4ec976==='invalid_token'||_0x4ec976==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x545d5e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x545d5e):'msg'in _0x545d5e&&console['log']('FIREBASE:\x20'+_0x545d5e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5a8930 of this['listens']['values']())for(const _0x2e4be2 of _0x5a8930['values']())this['sendListen_'](_0x2e4be2);for(let _0x132b71=0x0;_0x132b71<this['outstandingPuts_']['length'];_0x132b71++)this['outstandingPuts_'][_0x132b71]&&this['sendPut_'](_0x132b71);for(;this['onDisconnectRequestQueue_']['length'];){const _0x10ac6f=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x10ac6f['action'],_0x10ac6f['pathString'],_0x10ac6f['data'],_0x10ac6f['onComplete']);}for(let _0x18f812=0x0;_0x18f812<this['outstandingGets_']['length'];_0x18f812++)this['outstandingGets_'][_0x18f812]&&this['sendGet_'](_0x18f812);}['sendConnectStats_'](){const _0x391788={};let _0x15c189='js';_0x391788['sdk.'+_0x15c189+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x391788['framework.cordova']=0x1:Kr()&&(_0x391788['framework.reactnative']=0x1),this['reportStats'](_0x391788);}['shouldReconnect_'](){const _0x2c2ef0=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x2c2ef0;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5f404b,_0x4afeac){this['name']=_0x5f404b,this['node']=_0x4afeac;}static['Wrap'](_0x1b6d36,_0x1dce0f){return new E(_0x1b6d36,_0x1dce0f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x149053,_0x25e447){const _0x50d25e=new E(Ue,_0x149053),_0x31def5=new E(Ue,_0x25e447);return this['compare'](_0x50d25e,_0x31def5)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x260538){sn=_0x260538;}['compare'](_0x57c719,_0xd7374f){return Ge(_0x57c719['name'],_0xd7374f['name']);}['isDefinedOn'](_0x40ff79){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x38594,_0x530ab6){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x2ea7b7,_0x640e60){return f(typeof _0x2ea7b7=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2ea7b7,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x34d01c,_0x10640a,_0x138b5,_0x4cd4f7,_0x2af009=null){this['isReverse_']=_0x4cd4f7,this['resultGenerator_']=_0x2af009,this['nodeStack_']=[];let _0x494190=0x1;for(;!_0x34d01c['isEmpty']();)if(_0x34d01c=_0x34d01c,_0x494190=_0x10640a?_0x138b5(_0x34d01c['key'],_0x10640a):0x1,_0x4cd4f7&&(_0x494190*=-0x1),_0x494190<0x0)this['isReverse_']?_0x34d01c=_0x34d01c['left']:_0x34d01c=_0x34d01c['right'];else{if(_0x494190===0x0){this['nodeStack_']['push'](_0x34d01c);break;}else this['nodeStack_']['push'](_0x34d01c),this['isReverse_']?_0x34d01c=_0x34d01c['right']:_0x34d01c=_0x34d01c['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4183a5=this['nodeStack_']['pop'](),_0x415aa6;if(this['resultGenerator_']?_0x415aa6=this['resultGenerator_'](_0x4183a5['key'],_0x4183a5['value']):_0x415aa6={'key':_0x4183a5['key'],'value':_0x4183a5['value']},this['isReverse_']){for(_0x4183a5=_0x4183a5['left'];!_0x4183a5['isEmpty']();)this['nodeStack_']['push'](_0x4183a5),_0x4183a5=_0x4183a5['right'];}else{for(_0x4183a5=_0x4183a5['right'];!_0x4183a5['isEmpty']();)this['nodeStack_']['push'](_0x4183a5),_0x4183a5=_0x4183a5['left'];}return _0x415aa6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x8c411d=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x8c411d['key'],_0x8c411d['value']):{'key':_0x8c411d['key'],'value':_0x8c411d['value']};}}class M{constructor(_0x4458c8,_0x3ee77a,_0x2f096e,_0x56883f,_0x5250c5){this['key']=_0x4458c8,this['value']=_0x3ee77a,this['color']=_0x2f096e??M['RED'],this['left']=_0x56883f??B['EMPTY_NODE'],this['right']=_0x5250c5??B['EMPTY_NODE'];}['copy'](_0x4e2432,_0x75a89a,_0x49f444,_0x35aaeb,_0x30cc4a){return new M(_0x4e2432??this['key'],_0x75a89a??this['value'],_0x49f444??this['color'],_0x35aaeb??this['left'],_0x30cc4a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4792cc){return this['left']['inorderTraversal'](_0x4792cc)||!!_0x4792cc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4792cc);}['reverseTraversal'](_0x364ef0){return this['right']['reverseTraversal'](_0x364ef0)||_0x364ef0(this['key'],this['value'])||this['left']['reverseTraversal'](_0x364ef0);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1cf9b5,_0x1e4669,_0x49c507){let _0x2c1db2=this;const _0x4d8062=_0x49c507(_0x1cf9b5,_0x2c1db2['key']);return _0x4d8062<0x0?_0x2c1db2=_0x2c1db2['copy'](null,null,null,_0x2c1db2['left']['insert'](_0x1cf9b5,_0x1e4669,_0x49c507),null):_0x4d8062===0x0?_0x2c1db2=_0x2c1db2['copy'](null,_0x1e4669,null,null,null):_0x2c1db2=_0x2c1db2['copy'](null,null,null,null,_0x2c1db2['right']['insert'](_0x1cf9b5,_0x1e4669,_0x49c507)),_0x2c1db2['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3e83c0=this;return!_0x3e83c0['left']['isRed_']()&&!_0x3e83c0['left']['left']['isRed_']()&&(_0x3e83c0=_0x3e83c0['moveRedLeft_']()),_0x3e83c0=_0x3e83c0['copy'](null,null,null,_0x3e83c0['left']['removeMin_'](),null),_0x3e83c0['fixUp_']();}['remove'](_0x588e53,_0x4a6c20){let _0x1296e2,_0x3dd347;if(_0x1296e2=this,_0x4a6c20(_0x588e53,_0x1296e2['key'])<0x0)!_0x1296e2['left']['isEmpty']()&&!_0x1296e2['left']['isRed_']()&&!_0x1296e2['left']['left']['isRed_']()&&(_0x1296e2=_0x1296e2['moveRedLeft_']()),_0x1296e2=_0x1296e2['copy'](null,null,null,_0x1296e2['left']['remove'](_0x588e53,_0x4a6c20),null);else{if(_0x1296e2['left']['isRed_']()&&(_0x1296e2=_0x1296e2['rotateRight_']()),!_0x1296e2['right']['isEmpty']()&&!_0x1296e2['right']['isRed_']()&&!_0x1296e2['right']['left']['isRed_']()&&(_0x1296e2=_0x1296e2['moveRedRight_']()),_0x4a6c20(_0x588e53,_0x1296e2['key'])===0x0){if(_0x1296e2['right']['isEmpty']())return B['EMPTY_NODE'];_0x3dd347=_0x1296e2['right']['min_'](),_0x1296e2=_0x1296e2['copy'](_0x3dd347['key'],_0x3dd347['value'],null,null,_0x1296e2['right']['removeMin_']());}_0x1296e2=_0x1296e2['copy'](null,null,null,null,_0x1296e2['right']['remove'](_0x588e53,_0x4a6c20));}return _0x1296e2['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x523773=this;return _0x523773['right']['isRed_']()&&!_0x523773['left']['isRed_']()&&(_0x523773=_0x523773['rotateLeft_']()),_0x523773['left']['isRed_']()&&_0x523773['left']['left']['isRed_']()&&(_0x523773=_0x523773['rotateRight_']()),_0x523773['left']['isRed_']()&&_0x523773['right']['isRed_']()&&(_0x523773=_0x523773['colorFlip_']()),_0x523773;}['moveRedLeft_'](){let _0x274e65=this['colorFlip_']();return _0x274e65['right']['left']['isRed_']()&&(_0x274e65=_0x274e65['copy'](null,null,null,null,_0x274e65['right']['rotateRight_']()),_0x274e65=_0x274e65['rotateLeft_'](),_0x274e65=_0x274e65['colorFlip_']()),_0x274e65;}['moveRedRight_'](){let _0x348abc=this['colorFlip_']();return _0x348abc['left']['left']['isRed_']()&&(_0x348abc=_0x348abc['rotateRight_'](),_0x348abc=_0x348abc['colorFlip_']()),_0x348abc;}['rotateLeft_'](){const _0x20fbb8=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x20fbb8,null);}['rotateRight_'](){const _0x4194f1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4194f1);}['colorFlip_'](){const _0x1e0ad8=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x39cc3d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1e0ad8,_0x39cc3d);}['checkMaxDepth_'](){const _0x5e9e9f=this['check_']();return Math['pow'](0x2,_0x5e9e9f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5a417e=this['left']['check_']();if(_0x5a417e!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5a417e+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x3e72c1,_0x33800e,_0x138193,_0x3e28bb,_0xed9d51){return this;}['insert'](_0x43e00e,_0x29da8e,_0x406cc5){return new M(_0x43e00e,_0x29da8e,null);}['remove'](_0x2eedd9,_0x430b76){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x329618){return!0x1;}['reverseTraversal'](_0x391669){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x213f99,_0x37ed7c=B['EMPTY_NODE']){this['comparator_']=_0x213f99,this['root_']=_0x37ed7c;}['insert'](_0x5aaf51,_0x3f3ad5){return new B(this['comparator_'],this['root_']['insert'](_0x5aaf51,_0x3f3ad5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x62aa0c){return new B(this['comparator_'],this['root_']['remove'](_0x62aa0c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1e4f5c){let _0x4143f6,_0x5def1a=this['root_'];for(;!_0x5def1a['isEmpty']();){if(_0x4143f6=this['comparator_'](_0x1e4f5c,_0x5def1a['key']),_0x4143f6===0x0)return _0x5def1a['value'];_0x4143f6<0x0?_0x5def1a=_0x5def1a['left']:_0x4143f6>0x0&&(_0x5def1a=_0x5def1a['right']);}return null;}['getPredecessorKey'](_0x5796d6){let _0x2dfd20,_0xd5352e=this['root_'],_0x1a3952=null;for(;!_0xd5352e['isEmpty']();)if(_0x2dfd20=this['comparator_'](_0x5796d6,_0xd5352e['key']),_0x2dfd20===0x0){if(_0xd5352e['left']['isEmpty']())return _0x1a3952?_0x1a3952['key']:null;for(_0xd5352e=_0xd5352e['left'];!_0xd5352e['right']['isEmpty']();)_0xd5352e=_0xd5352e['right'];return _0xd5352e['key'];}else _0x2dfd20<0x0?_0xd5352e=_0xd5352e['left']:_0x2dfd20>0x0&&(_0x1a3952=_0xd5352e,_0xd5352e=_0xd5352e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4304ec){return this['root_']['inorderTraversal'](_0x4304ec);}['reverseTraversal'](_0x25d6bc){return this['root_']['reverseTraversal'](_0x25d6bc);}['getIterator'](_0x2e311d){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2e311d);}['getIteratorFrom'](_0x1d5d8f,_0xa9c2e3){return new rn(this['root_'],_0x1d5d8f,this['comparator_'],!0x1,_0xa9c2e3);}['getReverseIteratorFrom'](_0x1a33bf,_0x8ea1d){return new rn(this['root_'],_0x1a33bf,this['comparator_'],!0x0,_0x8ea1d);}['getReverseIterator'](_0x387258){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x387258);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x33ef30,_0xe7a031){return Ge(_0x33ef30['name'],_0xe7a031['name']);}function Qi(_0x59fda0,_0x3a63dd){return Ge(_0x59fda0,_0x3a63dd);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4e67ea){Ci=_0x4e67ea;}const No=function(_0x2dd4f9){return typeof _0x2dd4f9=='number'?'number:'+ao(_0x2dd4f9):'string:'+_0x2dd4f9;},Po=function(_0x3bd722){if(_0x3bd722['isLeafNode']()){const _0x580e98=_0x3bd722['val']();f(typeof _0x580e98=='string'||typeof _0x580e98=='number'||typeof _0x580e98=='object'&&Q(_0x580e98,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3bd722===Ci||_0x3bd722['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3bd722===Ci||_0x3bd722['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x9d79f5){nr=_0x9d79f5;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x156e29,_0x479802=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x156e29,this['priorityNode_']=_0x479802,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x20b00f){return new D(this['value_'],_0x20b00f);}['getImmediateChild'](_0x41c65c){return _0x41c65c==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x59f32e){return v(_0x59f32e)?this:y(_0x59f32e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2c1c60,_0x54ca81){return null;}['updateImmediateChild'](_0x2b4521,_0x119166){return _0x2b4521==='.priority'?this['updatePriority'](_0x119166):_0x119166['isEmpty']()&&_0x2b4521!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2b4521,_0x119166)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x39bdff,_0x365669){const _0x526755=y(_0x39bdff);return _0x526755===null?_0x365669:_0x365669['isEmpty']()&&_0x526755!=='.priority'?this:(f(_0x526755!=='.priority'||Ce(_0x39bdff)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x526755,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x39bdff),_0x365669)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x35b2aa,_0x594ce9){return!0x1;}['val'](_0x2abd6a){return _0x2abd6a&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xce3802='';this['priorityNode_']['isEmpty']()||(_0xce3802+='priority:'+No(this['priorityNode_']['val']())+':');const _0x78132a=typeof this['value_'];_0xce3802+=_0x78132a+':',_0x78132a==='number'?_0xce3802+=ao(this['value_']):_0xce3802+=this['value_'],this['lazyHash_']=ro(_0xce3802);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x418d03){return _0x418d03===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x418d03 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x418d03['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x418d03));}['compareToLeafNode_'](_0x214b0f){const _0x50389a=typeof _0x214b0f['value_'],_0x1ca739=typeof this['value_'],_0x8ce681=D['VALUE_TYPE_ORDER']['indexOf'](_0x50389a),_0x39d790=D['VALUE_TYPE_ORDER']['indexOf'](_0x1ca739);return f(_0x8ce681>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x50389a),f(_0x39d790>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1ca739),_0x8ce681===_0x39d790?_0x1ca739==='object'?0x0:this['value_']<_0x214b0f['value_']?-0x1:this['value_']===_0x214b0f['value_']?0x0:0x1:_0x39d790-_0x8ce681;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3d8890){if(_0x3d8890===this)return!0x0;if(_0x3d8890['isLeafNode']()){const _0x32891d=_0x3d8890;return this['value_']===_0x32891d['value_']&&this['priorityNode_']['equals'](_0x32891d['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x40d6f3){Oo=_0x40d6f3;}function Wh(_0x49e1f5){Do=_0x49e1f5;}class Bh extends Fn{['compare'](_0x466d52,_0x34100a){const _0x23bc79=_0x466d52['node']['getPriority'](),_0x299132=_0x34100a['node']['getPriority'](),_0x5c748e=_0x23bc79['compareTo'](_0x299132);return _0x5c748e===0x0?Ge(_0x466d52['name'],_0x34100a['name']):_0x5c748e;}['isDefinedOn'](_0x3d13a5){return!_0x3d13a5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x258dc1,_0x363478){return!_0x258dc1['getPriority']()['equals'](_0x363478['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0xf26fa1,_0x40765c){const _0x414a8b=Oo(_0xf26fa1);return new E(_0x40765c,new D('[PRIORITY-POST]',_0x414a8b));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1cd87a){const _0x5491c4=_0x4511b3=>parseInt(Math['log'](_0x4511b3)/Vh,0xa),_0x541ecc=_0x54676c=>parseInt(Array(_0x54676c+0x1)['join']('1'),0x2);this['count']=_0x5491c4(_0x1cd87a+0x1),this['current_']=this['count']-0x1;const _0x6009d4=_0x541ecc(this['count']);this['bits_']=_0x1cd87a+0x1&_0x6009d4;}['nextBitIsOne'](){const _0x3538e6=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3538e6;}}const yn=function(_0x3b24e7,_0x50b2d5,_0x532c48,_0x3e6dc4){_0x3b24e7['sort'](_0x50b2d5);const _0x573990=function(_0x408421,_0x377a3a){const _0x538c6f=_0x377a3a-_0x408421;let _0x4f9f72,_0x227543;if(_0x538c6f===0x0)return null;if(_0x538c6f===0x1)return _0x4f9f72=_0x3b24e7[_0x408421],_0x227543=_0x532c48?_0x532c48(_0x4f9f72):_0x4f9f72,new M(_0x227543,_0x4f9f72['node'],M['BLACK'],null,null);{const _0x59e28a=parseInt(_0x538c6f/0x2,0xa)+_0x408421,_0x5c0b8f=_0x573990(_0x408421,_0x59e28a),_0x1a8c63=_0x573990(_0x59e28a+0x1,_0x377a3a);return _0x4f9f72=_0x3b24e7[_0x59e28a],_0x227543=_0x532c48?_0x532c48(_0x4f9f72):_0x4f9f72,new M(_0x227543,_0x4f9f72['node'],M['BLACK'],_0x5c0b8f,_0x1a8c63);}},_0x2ea4a1=function(_0x1a9ef8){let _0x8ef6cf=null,_0x298f83=null,_0x533633=_0x3b24e7['length'];const _0x2e06ce=function(_0x537f36,_0x3cc473){const _0x55241b=_0x533633-_0x537f36,_0x1122fe=_0x533633;_0x533633-=_0x537f36;const _0x263913=_0x573990(_0x55241b+0x1,_0x1122fe),_0x165815=_0x3b24e7[_0x55241b],_0x1f24c1=_0x532c48?_0x532c48(_0x165815):_0x165815;_0x9768ef(new M(_0x1f24c1,_0x165815['node'],_0x3cc473,null,_0x263913));},_0x9768ef=function(_0x32ee5b){_0x8ef6cf?(_0x8ef6cf['left']=_0x32ee5b,_0x8ef6cf=_0x32ee5b):(_0x298f83=_0x32ee5b,_0x8ef6cf=_0x32ee5b);};for(let _0x454e52=0x0;_0x454e52<_0x1a9ef8['count'];++_0x454e52){const _0x4967b7=_0x1a9ef8['nextBitIsOne'](),_0x532bc9=Math['pow'](0x2,_0x1a9ef8['count']-(_0x454e52+0x1));_0x4967b7?_0x2e06ce(_0x532bc9,M['BLACK']):(_0x2e06ce(_0x532bc9,M['BLACK']),_0x2e06ce(_0x532bc9,M['RED']));}return _0x298f83;},_0x2ba0cf=new Hh(_0x3b24e7['length']),_0xa1d7a1=_0x2ea4a1(_0x2ba0cf);return new B(_0x3e6dc4||_0x50b2d5,_0xa1d7a1);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x42734f,_0x493d7a){this['indexes_']=_0x42734f,this['indexSet_']=_0x493d7a;}['get'](_0x9876e1){const _0x5b3eb1=Me(this['indexes_'],_0x9876e1);if(!_0x5b3eb1)throw new Error('No\x20index\x20defined\x20for\x20'+_0x9876e1);return _0x5b3eb1 instanceof B?_0x5b3eb1:null;}['hasIndex'](_0xe9e61e){return Q(this['indexSet_'],_0xe9e61e['toString']());}['addIndex'](_0x26e396,_0x22273a){f(_0x26e396!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3d61fc=[];let _0x423ec0=!0x1;const _0x316cb6=_0x22273a['getIterator'](E['Wrap']);let _0x21ccc5=_0x316cb6['getNext']();for(;_0x21ccc5;)_0x423ec0=_0x423ec0||_0x26e396['isDefinedOn'](_0x21ccc5['node']),_0x3d61fc['push'](_0x21ccc5),_0x21ccc5=_0x316cb6['getNext']();let _0x278507;_0x423ec0?_0x278507=yn(_0x3d61fc,_0x26e396['getCompare']()):_0x278507=Qe;const _0xf6d85=_0x26e396['toString'](),_0x23ac28={...this['indexSet_']};_0x23ac28[_0xf6d85]=_0x26e396;const _0x4f9569={...this['indexes_']};return _0x4f9569[_0xf6d85]=_0x278507,new te(_0x4f9569,_0x23ac28);}['addToIndexes'](_0x26abba,_0x45843f){const _0x28a008=_n(this['indexes_'],(_0x3ffaa9,_0x4dd812)=>{const _0x5a867f=Me(this['indexSet_'],_0x4dd812);if(f(_0x5a867f,'Missing\x20index\x20implementation\x20for\x20'+_0x4dd812),_0x3ffaa9===Qe){if(_0x5a867f['isDefinedOn'](_0x26abba['node'])){const _0x164f59=[],_0x27ecf4=_0x45843f['getIterator'](E['Wrap']);let _0x1035e6=_0x27ecf4['getNext']();for(;_0x1035e6;)_0x1035e6['name']!==_0x26abba['name']&&_0x164f59['push'](_0x1035e6),_0x1035e6=_0x27ecf4['getNext']();return _0x164f59['push'](_0x26abba),yn(_0x164f59,_0x5a867f['getCompare']());}else return Qe;}else{const _0x43cd15=_0x45843f['get'](_0x26abba['name']);let _0x3bf9bf=_0x3ffaa9;return _0x43cd15&&(_0x3bf9bf=_0x3bf9bf['remove'](new E(_0x26abba['name'],_0x43cd15))),_0x3bf9bf['insert'](_0x26abba,_0x26abba['node']);}});return new te(_0x28a008,this['indexSet_']);}['removeFromIndexes'](_0x208d01,_0x5d7164){const _0x23523f=_n(this['indexes_'],_0x46552e=>{if(_0x46552e===Qe)return _0x46552e;{const _0x23ce52=_0x5d7164['get'](_0x208d01['name']);return _0x23ce52?_0x46552e['remove'](new E(_0x208d01['name'],_0x23ce52)):_0x46552e;}});return new te(_0x23523f,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x511da0,_0x351e0a,_0x235d05){this['children_']=_0x511da0,this['priorityNode_']=_0x351e0a,this['indexMap_']=_0x235d05,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x16a2f5){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x16a2f5,this['indexMap_']);}['getImmediateChild'](_0xe60405){if(_0xe60405==='.priority')return this['getPriority']();{const _0x4e419e=this['children_']['get'](_0xe60405);return _0x4e419e===null?Et:_0x4e419e;}}['getChild'](_0x3c0021){const _0x322bd9=y(_0x3c0021);return _0x322bd9===null?this:this['getImmediateChild'](_0x322bd9)['getChild'](S(_0x3c0021));}['hasChild'](_0x39988e){return this['children_']['get'](_0x39988e)!==null;}['updateImmediateChild'](_0x58f966,_0xdf960){if(f(_0xdf960,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x58f966==='.priority')return this['updatePriority'](_0xdf960);{const _0x299069=new E(_0x58f966,_0xdf960);let _0x2770e0,_0x301593;_0xdf960['isEmpty']()?(_0x2770e0=this['children_']['remove'](_0x58f966),_0x301593=this['indexMap_']['removeFromIndexes'](_0x299069,this['children_'])):(_0x2770e0=this['children_']['insert'](_0x58f966,_0xdf960),_0x301593=this['indexMap_']['addToIndexes'](_0x299069,this['children_']));const _0x5297bb=_0x2770e0['isEmpty']()?Et:this['priorityNode_'];return new g(_0x2770e0,_0x5297bb,_0x301593);}}['updateChild'](_0x524706,_0x514152){const _0x445f35=y(_0x524706);if(_0x445f35===null)return _0x514152;{f(y(_0x524706)!=='.priority'||Ce(_0x524706)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2d48c1=this['getImmediateChild'](_0x445f35)['updateChild'](S(_0x524706),_0x514152);return this['updateImmediateChild'](_0x445f35,_0x2d48c1);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1cabef){if(this['isEmpty']())return null;const _0x2ab0aa={};let _0xc494ed=0x0,_0x47d41c=0x0,_0x3ae080=!0x0;if(this['forEachChild'](R,(_0x288717,_0x20d2ce)=>{_0x2ab0aa[_0x288717]=_0x20d2ce['val'](_0x1cabef),_0xc494ed++,_0x3ae080&&g['INTEGER_REGEXP_']['test'](_0x288717)?_0x47d41c=Math['max'](_0x47d41c,Number(_0x288717)):_0x3ae080=!0x1;}),!_0x1cabef&&_0x3ae080&&_0x47d41c<0x2*_0xc494ed){const _0x23ed17=[];for(const _0x2c3902 in _0x2ab0aa)_0x23ed17[_0x2c3902]=_0x2ab0aa[_0x2c3902];return _0x23ed17;}else return _0x1cabef&&!this['getPriority']()['isEmpty']()&&(_0x2ab0aa['.priority']=this['getPriority']()['val']()),_0x2ab0aa;}['hash'](){if(this['lazyHash_']===null){let _0x577deb='';this['getPriority']()['isEmpty']()||(_0x577deb+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2e352e,_0x39cd8c)=>{const _0x4a1f9c=_0x39cd8c['hash']();_0x4a1f9c!==''&&(_0x577deb+=':'+_0x2e352e+':'+_0x4a1f9c);}),this['lazyHash_']=_0x577deb===''?'':ro(_0x577deb);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4a1e38,_0x50ba4e,_0x386bae){const _0x5b88f4=this['resolveIndex_'](_0x386bae);if(_0x5b88f4){const _0x1844fa=_0x5b88f4['getPredecessorKey'](new E(_0x4a1e38,_0x50ba4e));return _0x1844fa?_0x1844fa['name']:null;}else return this['children_']['getPredecessorKey'](_0x4a1e38);}['getFirstChildName'](_0x1521e4){const _0x4fb22e=this['resolveIndex_'](_0x1521e4);if(_0x4fb22e){const _0x27e9da=_0x4fb22e['minKey']();return _0x27e9da&&_0x27e9da['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x25941e){const _0x2be283=this['getFirstChildName'](_0x25941e);return _0x2be283?new E(_0x2be283,this['children_']['get'](_0x2be283)):null;}['getLastChildName'](_0x40f667){const _0x270dc5=this['resolveIndex_'](_0x40f667);if(_0x270dc5){const _0x2ff64d=_0x270dc5['maxKey']();return _0x2ff64d&&_0x2ff64d['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x23df99){const _0x2b778c=this['getLastChildName'](_0x23df99);return _0x2b778c?new E(_0x2b778c,this['children_']['get'](_0x2b778c)):null;}['forEachChild'](_0x24922c,_0x31f2a7){const _0xc33fd7=this['resolveIndex_'](_0x24922c);return _0xc33fd7?_0xc33fd7['inorderTraversal'](_0x3e448b=>_0x31f2a7(_0x3e448b['name'],_0x3e448b['node'])):this['children_']['inorderTraversal'](_0x31f2a7);}['getIterator'](_0x197fe2){return this['getIteratorFrom'](_0x197fe2['minPost'](),_0x197fe2);}['getIteratorFrom'](_0xd382bf,_0x3ae10a){const _0x30923d=this['resolveIndex_'](_0x3ae10a);if(_0x30923d)return _0x30923d['getIteratorFrom'](_0xd382bf,_0x1a1a1f=>_0x1a1a1f);{const _0x8beb94=this['children_']['getIteratorFrom'](_0xd382bf['name'],E['Wrap']);let _0x3ee7e6=_0x8beb94['peek']();for(;_0x3ee7e6!=null&&_0x3ae10a['compare'](_0x3ee7e6,_0xd382bf)<0x0;)_0x8beb94['getNext'](),_0x3ee7e6=_0x8beb94['peek']();return _0x8beb94;}}['getReverseIterator'](_0x324066){return this['getReverseIteratorFrom'](_0x324066['maxPost'](),_0x324066);}['getReverseIteratorFrom'](_0x14e500,_0x333a58){const _0x4c1073=this['resolveIndex_'](_0x333a58);if(_0x4c1073)return _0x4c1073['getReverseIteratorFrom'](_0x14e500,_0x971de=>_0x971de);{const _0x38418c=this['children_']['getReverseIteratorFrom'](_0x14e500['name'],E['Wrap']);let _0x13e963=_0x38418c['peek']();for(;_0x13e963!=null&&_0x333a58['compare'](_0x13e963,_0x14e500)>0x0;)_0x38418c['getNext'](),_0x13e963=_0x38418c['peek']();return _0x38418c;}}['compareTo'](_0x5b6888){return this['isEmpty']()?_0x5b6888['isEmpty']()?0x0:-0x1:_0x5b6888['isLeafNode']()||_0x5b6888['isEmpty']()?0x1:_0x5b6888===jt?-0x1:0x0;}['withIndex'](_0x4e44b8){if(_0x4e44b8===ve||this['indexMap_']['hasIndex'](_0x4e44b8))return this;{const _0x37f555=this['indexMap_']['addIndex'](_0x4e44b8,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x37f555);}}['isIndexed'](_0x4b6723){return _0x4b6723===ve||this['indexMap_']['hasIndex'](_0x4b6723);}['equals'](_0x32adff){if(_0x32adff===this)return!0x0;if(_0x32adff['isLeafNode']())return!0x1;{const _0x59a258=_0x32adff;if(this['getPriority']()['equals'](_0x59a258['getPriority']())){if(this['children_']['count']()===_0x59a258['children_']['count']()){const _0x195d42=this['getIterator'](R),_0x11c522=_0x59a258['getIterator'](R);let _0x37cee2=_0x195d42['getNext'](),_0x415061=_0x11c522['getNext']();for(;_0x37cee2&&_0x415061;){if(_0x37cee2['name']!==_0x415061['name']||!_0x37cee2['node']['equals'](_0x415061['node']))return!0x1;_0x37cee2=_0x195d42['getNext'](),_0x415061=_0x11c522['getNext']();}return _0x37cee2===null&&_0x415061===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3c7231){return _0x3c7231===ve?null:this['indexMap_']['get'](_0x3c7231['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x5c3cdd){return _0x5c3cdd===this?0x0:0x1;}['equals'](_0x5a4eb9){return _0x5a4eb9===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2af0b1){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x56196d,_0x33683a=null){if(_0x56196d===null)return g['EMPTY_NODE'];if(typeof _0x56196d=='object'&&'.priority'in _0x56196d&&(_0x33683a=_0x56196d['.priority']),f(_0x33683a===null||typeof _0x33683a=='string'||typeof _0x33683a=='number'||typeof _0x33683a=='object'&&'.sv'in _0x33683a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x33683a),typeof _0x56196d=='object'&&'.value'in _0x56196d&&_0x56196d['.value']!==null&&(_0x56196d=_0x56196d['.value']),typeof _0x56196d!='object'||'.sv'in _0x56196d){const _0x4a307e=_0x56196d;return new D(_0x4a307e,A(_0x33683a));}if(!(_0x56196d instanceof Array)&&Gh){const _0x496d31=[];let _0x466561=!0x1;if(x(_0x56196d,(_0x42f222,_0x6a9a40)=>{if(_0x42f222['substring'](0x0,0x1)!=='.'){const _0x310f8f=A(_0x6a9a40);_0x310f8f['isEmpty']()||(_0x466561=_0x466561||!_0x310f8f['getPriority']()['isEmpty'](),_0x496d31['push'](new E(_0x42f222,_0x310f8f)));}}),_0x496d31['length']===0x0)return g['EMPTY_NODE'];const _0x56c620=yn(_0x496d31,xh,_0x252ff8=>_0x252ff8['name'],Qi);if(_0x466561){const _0x4ca56f=yn(_0x496d31,R['getCompare']());return new g(_0x56c620,A(_0x33683a),new te({'.priority':_0x4ca56f},{'.priority':R}));}else return new g(_0x56c620,A(_0x33683a),te['Default']);}else{let _0x2f5187=g['EMPTY_NODE'];return x(_0x56196d,(_0x5e43e9,_0xbe5344)=>{if(Q(_0x56196d,_0x5e43e9)&&_0x5e43e9['substring'](0x0,0x1)!=='.'){const _0xc12210=A(_0xbe5344);(_0xc12210['isLeafNode']()||!_0xc12210['isEmpty']())&&(_0x2f5187=_0x2f5187['updateImmediateChild'](_0x5e43e9,_0xc12210));}}),_0x2f5187['updatePriority'](A(_0x33683a));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0xa7ce34){super(),this['indexPath_']=_0xa7ce34,f(!v(_0xa7ce34)&&y(_0xa7ce34)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xa67da0){return _0xa67da0['getChild'](this['indexPath_']);}['isDefinedOn'](_0x7d45b1){return!_0x7d45b1['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x378b0c,_0x1278e1){const _0x51be0a=this['extractChild'](_0x378b0c['node']),_0x161325=this['extractChild'](_0x1278e1['node']),_0x44fae8=_0x51be0a['compareTo'](_0x161325);return _0x44fae8===0x0?Ge(_0x378b0c['name'],_0x1278e1['name']):_0x44fae8;}['makePost'](_0x574169,_0x31e88d){const _0x1fcfa7=A(_0x574169),_0x2dd176=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1fcfa7);return new E(_0x31e88d,_0x2dd176);}['maxPost'](){const _0x5b9fc7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x5b9fc7);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x53aebd,_0x37ae5c){const _0x3912f6=_0x53aebd['node']['compareTo'](_0x37ae5c['node']);return _0x3912f6===0x0?Ge(_0x53aebd['name'],_0x37ae5c['name']):_0x3912f6;}['isDefinedOn'](_0x2b0e87){return!0x0;}['indexedValueChanged'](_0x5e6429,_0x591f47){return!_0x5e6429['equals'](_0x591f47);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x17e765,_0x4b897b){const _0x5cdfb6=A(_0x17e765);return new E(_0x4b897b,_0x5cdfb6);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x32a591){return{'type':'value','snapshotNode':_0x32a591};}function rt(_0x1ec63d,_0xa6f9){return{'type':'child_added','snapshotNode':_0xa6f9,'childName':_0x1ec63d};}function Mt(_0x2636ac,_0x4f8a41){return{'type':'child_removed','snapshotNode':_0x4f8a41,'childName':_0x2636ac};}function Lt(_0x51e52f,_0x168fb0,_0x5ad8ae){return{'type':'child_changed','snapshotNode':_0x168fb0,'childName':_0x51e52f,'oldSnap':_0x5ad8ae};}function zh(_0x48a6db,_0x5d798e){return{'type':'child_moved','snapshotNode':_0x5d798e,'childName':_0x48a6db};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x3db004){this['index_']=_0x3db004;}['updateChild'](_0xe8a506,_0x41c6b7,_0x18c709,_0x552977,_0x109b12,_0x5e8865){f(_0xe8a506['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2b299b=_0xe8a506['getImmediateChild'](_0x41c6b7);return _0x2b299b['getChild'](_0x552977)['equals'](_0x18c709['getChild'](_0x552977))&&_0x2b299b['isEmpty']()===_0x18c709['isEmpty']()||(_0x5e8865!=null&&(_0x18c709['isEmpty']()?_0xe8a506['hasChild'](_0x41c6b7)?_0x5e8865['trackChildChange'](Mt(_0x41c6b7,_0x2b299b)):f(_0xe8a506['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2b299b['isEmpty']()?_0x5e8865['trackChildChange'](rt(_0x41c6b7,_0x18c709)):_0x5e8865['trackChildChange'](Lt(_0x41c6b7,_0x18c709,_0x2b299b))),_0xe8a506['isLeafNode']()&&_0x18c709['isEmpty']())?_0xe8a506:_0xe8a506['updateImmediateChild'](_0x41c6b7,_0x18c709)['withIndex'](this['index_']);}['updateFullNode'](_0x4765fd,_0x654cf9,_0x4b3232){return _0x4b3232!=null&&(_0x4765fd['isLeafNode']()||_0x4765fd['forEachChild'](R,(_0x5156b5,_0x163349)=>{_0x654cf9['hasChild'](_0x5156b5)||_0x4b3232['trackChildChange'](Mt(_0x5156b5,_0x163349));}),_0x654cf9['isLeafNode']()||_0x654cf9['forEachChild'](R,(_0x51d22d,_0x3cf359)=>{if(_0x4765fd['hasChild'](_0x51d22d)){const _0x5d0542=_0x4765fd['getImmediateChild'](_0x51d22d);_0x5d0542['equals'](_0x3cf359)||_0x4b3232['trackChildChange'](Lt(_0x51d22d,_0x3cf359,_0x5d0542));}else _0x4b3232['trackChildChange'](rt(_0x51d22d,_0x3cf359));})),_0x654cf9['withIndex'](this['index_']);}['updatePriority'](_0x5aaa04,_0x337414){return _0x5aaa04['isEmpty']()?g['EMPTY_NODE']:_0x5aaa04['updatePriority'](_0x337414);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x64070f){this['indexedFilter_']=new Xi(_0x64070f['getIndex']()),this['index_']=_0x64070f['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x64070f),this['endPost_']=xt['getEndPost_'](_0x64070f),this['startIsInclusive_']=!_0x64070f['startAfterSet_'],this['endIsInclusive_']=!_0x64070f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2c997a){const _0xe92fde=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2c997a)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2c997a)<0x0,_0x4e8aa0=this['endIsInclusive_']?this['index_']['compare'](_0x2c997a,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2c997a,this['getEndPost']())<0x0;return _0xe92fde&&_0x4e8aa0;}['updateChild'](_0x23768e,_0x4491c9,_0x5dba4a,_0x2d3211,_0x5f348e,_0x2a1e91){return this['matches'](new E(_0x4491c9,_0x5dba4a))||(_0x5dba4a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x23768e,_0x4491c9,_0x5dba4a,_0x2d3211,_0x5f348e,_0x2a1e91);}['updateFullNode'](_0x1b73f6,_0x98bb9e,_0x5bb0f9){_0x98bb9e['isLeafNode']()&&(_0x98bb9e=g['EMPTY_NODE']);let _0x25d292=_0x98bb9e['withIndex'](this['index_']);_0x25d292=_0x25d292['updatePriority'](g['EMPTY_NODE']);const _0x3de65d=this;return _0x98bb9e['forEachChild'](R,(_0x31e887,_0x4624bb)=>{_0x3de65d['matches'](new E(_0x31e887,_0x4624bb))||(_0x25d292=_0x25d292['updateImmediateChild'](_0x31e887,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1b73f6,_0x25d292,_0x5bb0f9);}['updatePriority'](_0x573419,_0x2295cd){return _0x573419;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2fdb05){if(_0x2fdb05['hasStart']()){const _0x1fac1e=_0x2fdb05['getIndexStartName']();return _0x2fdb05['getIndex']()['makePost'](_0x2fdb05['getIndexStartValue'](),_0x1fac1e);}else return _0x2fdb05['getIndex']()['minPost']();}static['getEndPost_'](_0x5a56ab){if(_0x5a56ab['hasEnd']()){const _0x3eea22=_0x5a56ab['getIndexEndName']();return _0x5a56ab['getIndex']()['makePost'](_0x5a56ab['getIndexEndValue'](),_0x3eea22);}else return _0x5a56ab['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x14aa46){this['withinDirectionalStart']=_0x54d002=>this['reverse_']?this['withinEndPost'](_0x54d002):this['withinStartPost'](_0x54d002),this['withinDirectionalEnd']=_0x40a3fe=>this['reverse_']?this['withinStartPost'](_0x40a3fe):this['withinEndPost'](_0x40a3fe),this['withinStartPost']=_0x155cec=>{const _0x192e98=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x155cec);return this['startIsInclusive_']?_0x192e98<=0x0:_0x192e98<0x0;},this['withinEndPost']=_0x17ca29=>{const _0x13d6f7=this['index_']['compare'](_0x17ca29,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x13d6f7<=0x0:_0x13d6f7<0x0;},this['rangedFilter_']=new xt(_0x14aa46),this['index_']=_0x14aa46['getIndex'](),this['limit_']=_0x14aa46['getLimit'](),this['reverse_']=!_0x14aa46['isViewFromLeft'](),this['startIsInclusive_']=!_0x14aa46['startAfterSet_'],this['endIsInclusive_']=!_0x14aa46['endBeforeSet_'];}['updateChild'](_0x3cfe1f,_0x56d911,_0x1b6272,_0x44de26,_0x4b4745,_0x3ae47b){return this['rangedFilter_']['matches'](new E(_0x56d911,_0x1b6272))||(_0x1b6272=g['EMPTY_NODE']),_0x3cfe1f['getImmediateChild'](_0x56d911)['equals'](_0x1b6272)?_0x3cfe1f:_0x3cfe1f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x3cfe1f,_0x56d911,_0x1b6272,_0x44de26,_0x4b4745,_0x3ae47b):this['fullLimitUpdateChild_'](_0x3cfe1f,_0x56d911,_0x1b6272,_0x4b4745,_0x3ae47b);}['updateFullNode'](_0x4d94b3,_0x261965,_0x5b6eed){let _0x5e3dfb;if(_0x261965['isLeafNode']()||_0x261965['isEmpty']())_0x5e3dfb=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x261965['numChildren']()&&_0x261965['isIndexed'](this['index_'])){_0x5e3dfb=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x152a3f;this['reverse_']?_0x152a3f=_0x261965['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x152a3f=_0x261965['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xad975a=0x0;for(;_0x152a3f['hasNext']()&&_0xad975a<this['limit_'];){const _0x15f47a=_0x152a3f['getNext']();if(this['withinDirectionalStart'](_0x15f47a)){if(this['withinDirectionalEnd'](_0x15f47a))_0x5e3dfb=_0x5e3dfb['updateImmediateChild'](_0x15f47a['name'],_0x15f47a['node']),_0xad975a++;else break;}else continue;}}else{_0x5e3dfb=_0x261965['withIndex'](this['index_']),_0x5e3dfb=_0x5e3dfb['updatePriority'](g['EMPTY_NODE']);let _0x599392;this['reverse_']?_0x599392=_0x5e3dfb['getReverseIterator'](this['index_']):_0x599392=_0x5e3dfb['getIterator'](this['index_']);let _0x3d6a1e=0x0;for(;_0x599392['hasNext']();){const _0x422192=_0x599392['getNext']();_0x3d6a1e<this['limit_']&&this['withinDirectionalStart'](_0x422192)&&this['withinDirectionalEnd'](_0x422192)?_0x3d6a1e++:_0x5e3dfb=_0x5e3dfb['updateImmediateChild'](_0x422192['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4d94b3,_0x5e3dfb,_0x5b6eed);}['updatePriority'](_0x1d4c7c,_0x2b3746){return _0x1d4c7c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4c59bc,_0x142bd2,_0x228726,_0x5b0bc4,_0x452566){let _0x2d7541;if(this['reverse_']){const _0x1bf27b=this['index_']['getCompare']();_0x2d7541=(_0xd7ffd2,_0x4d3922)=>_0x1bf27b(_0x4d3922,_0xd7ffd2);}else _0x2d7541=this['index_']['getCompare']();const _0x1705da=_0x4c59bc;f(_0x1705da['numChildren']()===this['limit_'],'');const _0x31c502=new E(_0x142bd2,_0x228726),_0x2a29a5=this['reverse_']?_0x1705da['getFirstChild'](this['index_']):_0x1705da['getLastChild'](this['index_']),_0xa6205e=this['rangedFilter_']['matches'](_0x31c502);if(_0x1705da['hasChild'](_0x142bd2)){const _0x594124=_0x1705da['getImmediateChild'](_0x142bd2);let _0x4923d2=_0x5b0bc4['getChildAfterChild'](this['index_'],_0x2a29a5,this['reverse_']);for(;_0x4923d2!=null&&(_0x4923d2['name']===_0x142bd2||_0x1705da['hasChild'](_0x4923d2['name']));)_0x4923d2=_0x5b0bc4['getChildAfterChild'](this['index_'],_0x4923d2,this['reverse_']);const _0x3652eb=_0x4923d2==null?0x1:_0x2d7541(_0x4923d2,_0x31c502);if(_0xa6205e&&!_0x228726['isEmpty']()&&_0x3652eb>=0x0)return _0x452566!=null&&_0x452566['trackChildChange'](Lt(_0x142bd2,_0x228726,_0x594124)),_0x1705da['updateImmediateChild'](_0x142bd2,_0x228726);{_0x452566!=null&&_0x452566['trackChildChange'](Mt(_0x142bd2,_0x594124));const _0x4d573a=_0x1705da['updateImmediateChild'](_0x142bd2,g['EMPTY_NODE']);return _0x4923d2!=null&&this['rangedFilter_']['matches'](_0x4923d2)?(_0x452566!=null&&_0x452566['trackChildChange'](rt(_0x4923d2['name'],_0x4923d2['node'])),_0x4d573a['updateImmediateChild'](_0x4923d2['name'],_0x4923d2['node'])):_0x4d573a;}}else return _0x228726['isEmpty']()?_0x4c59bc:_0xa6205e&&_0x2d7541(_0x2a29a5,_0x31c502)>=0x0?(_0x452566!=null&&(_0x452566['trackChildChange'](Mt(_0x2a29a5['name'],_0x2a29a5['node'])),_0x452566['trackChildChange'](rt(_0x142bd2,_0x228726))),_0x1705da['updateImmediateChild'](_0x142bd2,_0x228726)['updateImmediateChild'](_0x2a29a5['name'],g['EMPTY_NODE'])):_0x4c59bc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x19deff=new Zi();return _0x19deff['limitSet_']=this['limitSet_'],_0x19deff['limit_']=this['limit_'],_0x19deff['startSet_']=this['startSet_'],_0x19deff['startAfterSet_']=this['startAfterSet_'],_0x19deff['indexStartValue_']=this['indexStartValue_'],_0x19deff['startNameSet_']=this['startNameSet_'],_0x19deff['indexStartName_']=this['indexStartName_'],_0x19deff['endSet_']=this['endSet_'],_0x19deff['endBeforeSet_']=this['endBeforeSet_'],_0x19deff['indexEndValue_']=this['indexEndValue_'],_0x19deff['endNameSet_']=this['endNameSet_'],_0x19deff['indexEndName_']=this['indexEndName_'],_0x19deff['index_']=this['index_'],_0x19deff['viewFrom_']=this['viewFrom_'],_0x19deff;}}function Kh(_0x2f6089){return _0x2f6089['loadsAllData']()?new Xi(_0x2f6089['getIndex']()):_0x2f6089['hasLimit']()?new jh(_0x2f6089):new xt(_0x2f6089);}function Yh(_0x41c186,_0x1eaccf,_0x18ec05){const _0x33517f=_0x41c186['copy']();return _0x33517f['startSet_']=!0x0,_0x1eaccf===void 0x0&&(_0x1eaccf=null),_0x33517f['indexStartValue_']=_0x1eaccf,_0x18ec05!=null?(_0x33517f['startNameSet_']=!0x0,_0x33517f['indexStartName_']=_0x18ec05):(_0x33517f['startNameSet_']=!0x1,_0x33517f['indexStartName_']=''),_0x33517f;}function Qh(_0x351c49,_0x423a86,_0x26603a){const _0x3a13f8=_0x351c49['copy']();return _0x3a13f8['endSet_']=!0x0,_0x423a86===void 0x0&&(_0x423a86=null),_0x3a13f8['indexEndValue_']=_0x423a86,_0x26603a!==void 0x0?(_0x3a13f8['endNameSet_']=!0x0,_0x3a13f8['indexEndName_']=_0x26603a):(_0x3a13f8['endNameSet_']=!0x1,_0x3a13f8['indexEndName_']=''),_0x3a13f8;}function xo(_0x3c2fb7,_0xe2edd8){const _0x4d7119=_0x3c2fb7['copy']();return _0x4d7119['index_']=_0xe2edd8,_0x4d7119;}function ir(_0x172ab2){const _0x182667={};if(_0x172ab2['isDefault']())return _0x182667;let _0x78e63f;if(_0x172ab2['index_']===R?_0x78e63f='$priority':_0x172ab2['index_']===Mo?_0x78e63f='$value':_0x172ab2['index_']===ve?_0x78e63f='$key':(f(_0x172ab2['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x78e63f=_0x172ab2['index_']['toString']()),_0x182667['orderBy']=O(_0x78e63f),_0x172ab2['startSet_']){const _0x5b1abf=_0x172ab2['startAfterSet_']?'startAfter':'startAt';_0x182667[_0x5b1abf]=O(_0x172ab2['indexStartValue_']),_0x172ab2['startNameSet_']&&(_0x182667[_0x5b1abf]+=','+O(_0x172ab2['indexStartName_']));}if(_0x172ab2['endSet_']){const _0x173112=_0x172ab2['endBeforeSet_']?'endBefore':'endAt';_0x182667[_0x173112]=O(_0x172ab2['indexEndValue_']),_0x172ab2['endNameSet_']&&(_0x182667[_0x173112]+=','+O(_0x172ab2['indexEndName_']));}return _0x172ab2['limitSet_']&&(_0x172ab2['isViewFromLeft']()?_0x182667['limitToFirst']=_0x172ab2['limit_']:_0x182667['limitToLast']=_0x172ab2['limit_']),_0x182667;}function sr(_0x5618a7){const _0x58a5f9={};if(_0x5618a7['startSet_']&&(_0x58a5f9['sp']=_0x5618a7['indexStartValue_'],_0x5618a7['startNameSet_']&&(_0x58a5f9['sn']=_0x5618a7['indexStartName_']),_0x58a5f9['sin']=!_0x5618a7['startAfterSet_']),_0x5618a7['endSet_']&&(_0x58a5f9['ep']=_0x5618a7['indexEndValue_'],_0x5618a7['endNameSet_']&&(_0x58a5f9['en']=_0x5618a7['indexEndName_']),_0x58a5f9['ein']=!_0x5618a7['endBeforeSet_']),_0x5618a7['limitSet_']){_0x58a5f9['l']=_0x5618a7['limit_'];let _0xcf63c5=_0x5618a7['viewFrom_'];_0xcf63c5===''&&(_0x5618a7['isViewFromLeft']()?_0xcf63c5='l':_0xcf63c5='r'),_0x58a5f9['vf']=_0xcf63c5;}return _0x5618a7['index_']!==R&&(_0x58a5f9['i']=_0x5618a7['index_']['toString']()),_0x58a5f9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x420f43){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2713ac,_0x398f8e){return _0x398f8e!==void 0x0?'tag$'+_0x398f8e:(f(_0x2713ac['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2713ac['_path']['toString']());}constructor(_0x113312,_0x4141eb,_0x222c3a,_0xf5c6ce){super(),this['repoInfo_']=_0x113312,this['onDataUpdate_']=_0x4141eb,this['authTokenProvider_']=_0x222c3a,this['appCheckTokenProvider_']=_0xf5c6ce,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x54c251,_0xa68490,_0x50b22f,_0x103060){const _0x42bf81=_0x54c251['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x42bf81+'\x20'+_0x54c251['_queryIdentifier']);const _0x161798=vn['getListenId_'](_0x54c251,_0x50b22f),_0x126ca7={};this['listens_'][_0x161798]=_0x126ca7;const _0x2857c5=ir(_0x54c251['_queryParams']);this['restRequest_'](_0x42bf81+'.json',_0x2857c5,(_0x567a4c,_0x30b509)=>{let _0x512b0b=_0x30b509;if(_0x567a4c===0x194&&(_0x512b0b=null,_0x567a4c=null),_0x567a4c===null&&this['onDataUpdate_'](_0x42bf81,_0x512b0b,!0x1,_0x50b22f),Me(this['listens_'],_0x161798)===_0x126ca7){let _0x298ae9;_0x567a4c?_0x567a4c===0x191?_0x298ae9='permission_denied':_0x298ae9='rest_error:'+_0x567a4c:_0x298ae9='ok',_0x103060(_0x298ae9,null);}});}['unlisten'](_0x19fbb7,_0x208d73){const _0x178135=vn['getListenId_'](_0x19fbb7,_0x208d73);delete this['listens_'][_0x178135];}['get'](_0x11f545){const _0x2b6fec=ir(_0x11f545['_queryParams']),_0x486b1f=_0x11f545['_path']['toString'](),_0x424723=new H();return this['restRequest_'](_0x486b1f+'.json',_0x2b6fec,(_0x3edb6d,_0x44d4e1)=>{let _0x4ccb01=_0x44d4e1;_0x3edb6d===0x194&&(_0x4ccb01=null,_0x3edb6d=null),_0x3edb6d===null?(this['onDataUpdate_'](_0x486b1f,_0x4ccb01,!0x1,null),_0x424723['resolve'](_0x4ccb01)):_0x424723['reject'](new Error(_0x4ccb01));}),_0x424723['promise'];}['refreshAuthToken'](_0x2157e4){}['restRequest_'](_0x7d48c5,_0x52fe59={},_0x3a2761){return _0x52fe59['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x48aff7,_0x7e835e])=>{_0x48aff7&&_0x48aff7['accessToken']&&(_0x52fe59['auth']=_0x48aff7['accessToken']),_0x7e835e&&_0x7e835e['token']&&(_0x52fe59['ac']=_0x7e835e['token']);const _0x27b088=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x7d48c5+'?ns='+this['repoInfo_']['namespace']+ut(_0x52fe59);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x27b088);const _0x172a13=new XMLHttpRequest();_0x172a13['onreadystatechange']=()=>{if(_0x3a2761&&_0x172a13['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x27b088+'\x20received.\x20status:',_0x172a13['status'],'response:',_0x172a13['responseText']);let _0x418728=null;if(_0x172a13['status']>=0xc8&&_0x172a13['status']<0x12c){try{_0x418728=Nt(_0x172a13['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x27b088+':\x20'+_0x172a13['responseText']);}_0x3a2761(null,_0x418728);}else _0x172a13['status']!==0x191&&_0x172a13['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x27b088+'\x20Status:\x20'+_0x172a13['status']),_0x3a2761(_0x172a13['status']);_0x3a2761=null;}},_0x172a13['open']('GET',_0x27b088,!0x0),_0x172a13['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4c8a30){return this['rootNode_']['getChild'](_0x4c8a30);}['updateSnapshot'](_0x9941bc,_0x51825f){this['rootNode_']=this['rootNode_']['updateChild'](_0x9941bc,_0x51825f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x416cab,_0x4b1432,_0x2c40b7){if(v(_0x4b1432))_0x416cab['value']=_0x2c40b7,_0x416cab['children']['clear']();else{if(_0x416cab['value']!==null)_0x416cab['value']=_0x416cab['value']['updateChild'](_0x4b1432,_0x2c40b7);else{const _0xb8c45c=y(_0x4b1432);_0x416cab['children']['has'](_0xb8c45c)||_0x416cab['children']['set'](_0xb8c45c,En());const _0x30ff6b=_0x416cab['children']['get'](_0xb8c45c);_0x4b1432=S(_0x4b1432),pt(_0x30ff6b,_0x4b1432,_0x2c40b7);}}}function Ti(_0x55893e,_0x3358a8){if(v(_0x3358a8))return _0x55893e['value']=null,_0x55893e['children']['clear'](),!0x0;if(_0x55893e['value']!==null){if(_0x55893e['value']['isLeafNode']())return!0x1;{const _0x1c1a4e=_0x55893e['value'];return _0x55893e['value']=null,_0x1c1a4e['forEachChild'](R,(_0x5bef9c,_0x2f8652)=>{pt(_0x55893e,new C(_0x5bef9c),_0x2f8652);}),Ti(_0x55893e,_0x3358a8);}}else{if(_0x55893e['children']['size']>0x0){const _0x585e34=y(_0x3358a8);return _0x3358a8=S(_0x3358a8),_0x55893e['children']['has'](_0x585e34)&&Ti(_0x55893e['children']['get'](_0x585e34),_0x3358a8)&&_0x55893e['children']['delete'](_0x585e34),_0x55893e['children']['size']===0x0;}else return!0x0;}}function Si(_0x22a100,_0x3087c7,_0x218c2b){_0x22a100['value']!==null?_0x218c2b(_0x3087c7,_0x22a100['value']):Xh(_0x22a100,(_0x44e183,_0x3505de)=>{const _0x8ddcc3=new C(_0x3087c7['toString']()+'/'+_0x44e183);Si(_0x3505de,_0x8ddcc3,_0x218c2b);});}function Xh(_0x39f77d,_0xefb88c){_0x39f77d['children']['forEach']((_0x2019b4,_0x2316f3)=>{_0xefb88c(_0x2316f3,_0x2019b4);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x12b026){this['collection_']=_0x12b026,this['last_']=null;}['get'](){const _0x17429e=this['collection_']['get'](),_0x1491a0={..._0x17429e};return this['last_']&&x(this['last_'],(_0x4aaf36,_0x51bcd8)=>{_0x1491a0[_0x4aaf36]=_0x1491a0[_0x4aaf36]-_0x51bcd8;}),this['last_']=_0x17429e,_0x1491a0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x45066e,_0x237ab1){this['server_']=_0x237ab1,this['statsToReport_']={},this['statsListener_']=new Zh(_0x45066e);const _0x4d76c1=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x4d76c1));}['reportStats_'](){const _0x377beb=this['statsListener_']['get'](),_0x5f0f71={};let _0x157db3=!0x1;x(_0x377beb,(_0x2808c5,_0x104551)=>{_0x104551>0x0&&Q(this['statsToReport_'],_0x2808c5)&&(_0x5f0f71[_0x2808c5]=_0x104551,_0x157db3=!0x0);}),_0x157db3&&this['server_']['reportStats'](_0x5f0f71),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x71faa0){_0x71faa0[_0x71faa0['OVERWRITE']=0x0]='OVERWRITE',_0x71faa0[_0x71faa0['MERGE']=0x1]='MERGE',_0x71faa0[_0x71faa0['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x71faa0[_0x71faa0['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x25782c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x25782c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x529391,_0x279e64,_0x2b2a08){this['path']=_0x529391,this['affectedTree']=_0x279e64,this['revert']=_0x2b2a08,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x4e566b){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x31ffa6=this['affectedTree']['subtree'](new C(_0x4e566b));return new In(w(),_0x31ffa6,this['revert']);}}else return f(y(this['path'])===_0x4e566b,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x3375a1,_0x5d36a8){this['source']=_0x3375a1,this['path']=_0x5d36a8,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1304b7){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x1c471b,_0x44e492,_0x2d2e40){this['source']=_0x1c471b,this['path']=_0x44e492,this['snap']=_0x2d2e40,this['type']=z['OVERWRITE'];}['operationForChild'](_0xffa735){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0xffa735)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x2aa1de,_0x5dbad9,_0x517fb0){this['source']=_0x2aa1de,this['path']=_0x5dbad9,this['children']=_0x517fb0,this['type']=z['MERGE'];}['operationForChild'](_0x393367){if(v(this['path'])){const _0x19986b=this['children']['subtree'](new C(_0x393367));return _0x19986b['isEmpty']()?null:_0x19986b['value']?new We(this['source'],w(),_0x19986b['value']):new ot(this['source'],w(),_0x19986b);}else return f(y(this['path'])===_0x393367,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x52def4,_0x4695f0,_0x502336){this['node_']=_0x52def4,this['fullyInitialized_']=_0x4695f0,this['filtered_']=_0x502336;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x557378){if(v(_0x557378))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4f9535=y(_0x557378);return this['isCompleteForChild'](_0x4f9535);}['isCompleteForChild'](_0x4a42b4){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4a42b4);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0x4b3e2c){this['query_']=_0x4b3e2c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x404fdc,_0x394f4d,_0x3f68a,_0x146d25){const _0x5be47a=[],_0x475e20=[];return _0x394f4d['forEach'](_0xf8d5fe=>{_0xf8d5fe['type']==='child_changed'&&_0x404fdc['index_']['indexedValueChanged'](_0xf8d5fe['oldSnap'],_0xf8d5fe['snapshotNode'])&&_0x475e20['push'](zh(_0xf8d5fe['childName'],_0xf8d5fe['snapshotNode']));}),It(_0x404fdc,_0x5be47a,'child_removed',_0x394f4d,_0x146d25,_0x3f68a),It(_0x404fdc,_0x5be47a,'child_added',_0x394f4d,_0x146d25,_0x3f68a),It(_0x404fdc,_0x5be47a,'child_moved',_0x475e20,_0x146d25,_0x3f68a),It(_0x404fdc,_0x5be47a,'child_changed',_0x394f4d,_0x146d25,_0x3f68a),It(_0x404fdc,_0x5be47a,'value',_0x394f4d,_0x146d25,_0x3f68a),_0x5be47a;}function It(_0x30ef81,_0x52db55,_0xa42768,_0x2cb046,_0x4f6501,_0x2419b8){const _0x13a29e=_0x2cb046['filter'](_0x17923d=>_0x17923d['type']===_0xa42768);_0x13a29e['sort']((_0x63b807,_0x7a4c83)=>ou(_0x30ef81,_0x63b807,_0x7a4c83)),_0x13a29e['forEach'](_0x16c4be=>{const _0x17162f=ru(_0x30ef81,_0x16c4be,_0x2419b8);_0x4f6501['forEach'](_0xa07b2c=>{_0xa07b2c['respondsTo'](_0x16c4be['type'])&&_0x52db55['push'](_0xa07b2c['createEvent'](_0x17162f,_0x30ef81['query_']));});});}function ru(_0x2eecd3,_0x491906,_0x3f3b16){return _0x491906['type']==='value'||_0x491906['type']==='child_removed'||(_0x491906['prevName']=_0x3f3b16['getPredecessorChildName'](_0x491906['childName'],_0x491906['snapshotNode'],_0x2eecd3['index_'])),_0x491906;}function ou(_0x104ce1,_0x5a8e05,_0x37182d){if(_0x5a8e05['childName']==null||_0x37182d['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x4ccae2=new E(_0x5a8e05['childName'],_0x5a8e05['snapshotNode']),_0x52da54=new E(_0x37182d['childName'],_0x37182d['snapshotNode']);return _0x104ce1['index_']['compare'](_0x4ccae2,_0x52da54);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x39dbb3,_0x31c149){return{'eventCache':_0x39dbb3,'serverCache':_0x31c149};}function bt(_0x573479,_0x591c5d,_0x165c48,_0x38cce5){return Un(new Te(_0x591c5d,_0x165c48,_0x38cce5),_0x573479['serverCache']);}function Fo(_0x535a6f,_0x4a7e70,_0x2ff239,_0x5aabd5){return Un(_0x535a6f['eventCache'],new Te(_0x4a7e70,_0x2ff239,_0x5aabd5));}function wn(_0x4772a3){return _0x4772a3['eventCache']['isFullyInitialized']()?_0x4772a3['eventCache']['getNode']():null;}function Be(_0x16115d){return _0x16115d['serverCache']['isFullyInitialized']()?_0x16115d['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x3fea55){let _0x37c662=new b(null);return x(_0x3fea55,(_0x38d3bd,_0x154569)=>{_0x37c662=_0x37c662['set'](new C(_0x38d3bd),_0x154569);}),_0x37c662;}constructor(_0x25514a,_0x4b0f39=au()){this['value']=_0x25514a,this['children']=_0x4b0f39;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1d9e7b,_0x384cb3){if(this['value']!=null&&_0x384cb3(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1d9e7b))return null;{const _0x2c9c56=y(_0x1d9e7b),_0x5eb742=this['children']['get'](_0x2c9c56);if(_0x5eb742!==null){const _0x670918=_0x5eb742['findRootMostMatchingPathAndValue'](S(_0x1d9e7b),_0x384cb3);return _0x670918!=null?{'path':k(new C(_0x2c9c56),_0x670918['path']),'value':_0x670918['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x72f8f4){return this['findRootMostMatchingPathAndValue'](_0x72f8f4,()=>!0x0);}['subtree'](_0x42c53c){if(v(_0x42c53c))return this;{const _0x5c4217=y(_0x42c53c),_0x19afca=this['children']['get'](_0x5c4217);return _0x19afca!==null?_0x19afca['subtree'](S(_0x42c53c)):new b(null);}}['set'](_0x2747a3,_0x153585){if(v(_0x2747a3))return new b(_0x153585,this['children']);{const _0x10920c=y(_0x2747a3),_0x52f80d=(this['children']['get'](_0x10920c)||new b(null))['set'](S(_0x2747a3),_0x153585),_0x4c6b06=this['children']['insert'](_0x10920c,_0x52f80d);return new b(this['value'],_0x4c6b06);}}['remove'](_0x1395ae){if(v(_0x1395ae))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x1f1e36=y(_0x1395ae),_0x120917=this['children']['get'](_0x1f1e36);if(_0x120917){const _0x445c3b=_0x120917['remove'](S(_0x1395ae));let _0x2487fd;return _0x445c3b['isEmpty']()?_0x2487fd=this['children']['remove'](_0x1f1e36):_0x2487fd=this['children']['insert'](_0x1f1e36,_0x445c3b),this['value']===null&&_0x2487fd['isEmpty']()?new b(null):new b(this['value'],_0x2487fd);}else return this;}}['get'](_0x10822e){if(v(_0x10822e))return this['value'];{const _0x58db7f=y(_0x10822e),_0x4052a9=this['children']['get'](_0x58db7f);return _0x4052a9?_0x4052a9['get'](S(_0x10822e)):null;}}['setTree'](_0x296ebb,_0x23120e){if(v(_0x296ebb))return _0x23120e;{const _0x3e6936=y(_0x296ebb),_0x3859a4=(this['children']['get'](_0x3e6936)||new b(null))['setTree'](S(_0x296ebb),_0x23120e);let _0x116c59;return _0x3859a4['isEmpty']()?_0x116c59=this['children']['remove'](_0x3e6936):_0x116c59=this['children']['insert'](_0x3e6936,_0x3859a4),new b(this['value'],_0x116c59);}}['fold'](_0x47dd21){return this['fold_'](w(),_0x47dd21);}['fold_'](_0x1eebd9,_0x26dc82){const _0x185bba={};return this['children']['inorderTraversal']((_0x570cdf,_0x4435a1)=>{_0x185bba[_0x570cdf]=_0x4435a1['fold_'](k(_0x1eebd9,_0x570cdf),_0x26dc82);}),_0x26dc82(_0x1eebd9,this['value'],_0x185bba);}['findOnPath'](_0x37270b,_0x8e4c3){return this['findOnPath_'](_0x37270b,w(),_0x8e4c3);}['findOnPath_'](_0x3dd930,_0x4901c3,_0x550876){const _0x2e9df0=this['value']?_0x550876(_0x4901c3,this['value']):!0x1;if(_0x2e9df0)return _0x2e9df0;if(v(_0x3dd930))return null;{const _0x35f1bd=y(_0x3dd930),_0x263bd7=this['children']['get'](_0x35f1bd);return _0x263bd7?_0x263bd7['findOnPath_'](S(_0x3dd930),k(_0x4901c3,_0x35f1bd),_0x550876):null;}}['foreachOnPath'](_0x9ab276,_0x5a768f){return this['foreachOnPath_'](_0x9ab276,w(),_0x5a768f);}['foreachOnPath_'](_0x14c45d,_0x3cdaa2,_0x42b78){if(v(_0x14c45d))return this;{this['value']&&_0x42b78(_0x3cdaa2,this['value']);const _0x6a11f3=y(_0x14c45d),_0x5c3dde=this['children']['get'](_0x6a11f3);return _0x5c3dde?_0x5c3dde['foreachOnPath_'](S(_0x14c45d),k(_0x3cdaa2,_0x6a11f3),_0x42b78):new b(null);}}['foreach'](_0x44d0bc){this['foreach_'](w(),_0x44d0bc);}['foreach_'](_0x28381c,_0x512c47){this['children']['inorderTraversal']((_0x47babc,_0x2960fb)=>{_0x2960fb['foreach_'](k(_0x28381c,_0x47babc),_0x512c47);}),this['value']&&_0x512c47(_0x28381c,this['value']);}['foreachChild'](_0x3ad623){this['children']['inorderTraversal']((_0x265877,_0x45389a)=>{_0x45389a['value']&&_0x3ad623(_0x265877,_0x45389a['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x433221){this['writeTree_']=_0x433221;}static['empty'](){return new K(new b(null));}}function Rt(_0x1a6b0f,_0x54d9db,_0x35b75f){if(v(_0x54d9db))return new K(new b(_0x35b75f));{const _0x401b0b=_0x1a6b0f['writeTree_']['findRootMostValueAndPath'](_0x54d9db);if(_0x401b0b!=null){const _0x4efbae=_0x401b0b['path'];let _0x1d94d9=_0x401b0b['value'];const _0x45e97e=F(_0x4efbae,_0x54d9db);return _0x1d94d9=_0x1d94d9['updateChild'](_0x45e97e,_0x35b75f),new K(_0x1a6b0f['writeTree_']['set'](_0x4efbae,_0x1d94d9));}else{const _0x30fa4f=new b(_0x35b75f),_0x1b88d2=_0x1a6b0f['writeTree_']['setTree'](_0x54d9db,_0x30fa4f);return new K(_0x1b88d2);}}}function bi(_0x286441,_0x5eea33,_0xaedb9a){let _0x13cd51=_0x286441;return x(_0xaedb9a,(_0x141f50,_0x1755a1)=>{_0x13cd51=Rt(_0x13cd51,k(_0x5eea33,_0x141f50),_0x1755a1);}),_0x13cd51;}function or(_0x130162,_0x71e414){if(v(_0x71e414))return K['empty']();{const _0x1db706=_0x130162['writeTree_']['setTree'](_0x71e414,new b(null));return new K(_0x1db706);}}function Ri(_0x722db5,_0x7f8ea6){return qe(_0x722db5,_0x7f8ea6)!=null;}function qe(_0x34e4c7,_0x2fb1fc){const _0x17c6eb=_0x34e4c7['writeTree_']['findRootMostValueAndPath'](_0x2fb1fc);return _0x17c6eb!=null?_0x34e4c7['writeTree_']['get'](_0x17c6eb['path'])['getChild'](F(_0x17c6eb['path'],_0x2fb1fc)):null;}function ar(_0xa80f96){const _0xd93303=[],_0x178dc1=_0xa80f96['writeTree_']['value'];return _0x178dc1!=null?_0x178dc1['isLeafNode']()||_0x178dc1['forEachChild'](R,(_0x474d24,_0x390d8d)=>{_0xd93303['push'](new E(_0x474d24,_0x390d8d));}):_0xa80f96['writeTree_']['children']['inorderTraversal']((_0x308272,_0x15f501)=>{_0x15f501['value']!=null&&_0xd93303['push'](new E(_0x308272,_0x15f501['value']));}),_0xd93303;}function Ee(_0x9837be,_0x3971f3){if(v(_0x3971f3))return _0x9837be;{const _0x2989fe=qe(_0x9837be,_0x3971f3);return _0x2989fe!=null?new K(new b(_0x2989fe)):new K(_0x9837be['writeTree_']['subtree'](_0x3971f3));}}function Ai(_0x2fdc52){return _0x2fdc52['writeTree_']['isEmpty']();}function at(_0x569d36,_0x49cf3c){return Uo(w(),_0x569d36['writeTree_'],_0x49cf3c);}function Uo(_0x294c62,_0x3e2be8,_0x11c816){if(_0x3e2be8['value']!=null)return _0x11c816['updateChild'](_0x294c62,_0x3e2be8['value']);{let _0x3df885=null;return _0x3e2be8['children']['inorderTraversal']((_0x105784,_0x2de43d)=>{_0x105784==='.priority'?(f(_0x2de43d['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3df885=_0x2de43d['value']):_0x11c816=Uo(k(_0x294c62,_0x105784),_0x2de43d,_0x11c816);}),!_0x11c816['getChild'](_0x294c62)['isEmpty']()&&_0x3df885!==null&&(_0x11c816=_0x11c816['updateChild'](k(_0x294c62,'.priority'),_0x3df885)),_0x11c816;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x47b230,_0xf7aa38){return Ho(_0xf7aa38,_0x47b230);}function cu(_0x2e4865,_0x593e05,_0x55fde0,_0x3323fc,_0x4b1957){f(_0x3323fc>_0x2e4865['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4b1957===void 0x0&&(_0x4b1957=!0x0),_0x2e4865['allWrites']['push']({'path':_0x593e05,'snap':_0x55fde0,'writeId':_0x3323fc,'visible':_0x4b1957}),_0x4b1957&&(_0x2e4865['visibleWrites']=Rt(_0x2e4865['visibleWrites'],_0x593e05,_0x55fde0)),_0x2e4865['lastWriteId']=_0x3323fc;}function lu(_0x1dec6c,_0x10ca57,_0xe5d2b4,_0x29b95a){f(_0x29b95a>_0x1dec6c['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1dec6c['allWrites']['push']({'path':_0x10ca57,'children':_0xe5d2b4,'writeId':_0x29b95a,'visible':!0x0}),_0x1dec6c['visibleWrites']=bi(_0x1dec6c['visibleWrites'],_0x10ca57,_0xe5d2b4),_0x1dec6c['lastWriteId']=_0x29b95a;}function hu(_0x156935,_0x54aedb){for(let _0x5563cd=0x0;_0x5563cd<_0x156935['allWrites']['length'];_0x5563cd++){const _0x5a65f5=_0x156935['allWrites'][_0x5563cd];if(_0x5a65f5['writeId']===_0x54aedb)return _0x5a65f5;}return null;}function uu(_0x36758b,_0x292427){const _0x4614c8=_0x36758b['allWrites']['findIndex'](_0x1d3671=>_0x1d3671['writeId']===_0x292427);f(_0x4614c8>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x57df91=_0x36758b['allWrites'][_0x4614c8];_0x36758b['allWrites']['splice'](_0x4614c8,0x1);let _0x588b03=_0x57df91['visible'],_0x38cb4b=!0x1,_0x2fcd74=_0x36758b['allWrites']['length']-0x1;for(;_0x588b03&&_0x2fcd74>=0x0;){const _0x38be89=_0x36758b['allWrites'][_0x2fcd74];_0x38be89['visible']&&(_0x2fcd74>=_0x4614c8&&du(_0x38be89,_0x57df91['path'])?_0x588b03=!0x1:G(_0x57df91['path'],_0x38be89['path'])&&(_0x38cb4b=!0x0)),_0x2fcd74--;}if(_0x588b03){if(_0x38cb4b)return fu(_0x36758b),!0x0;if(_0x57df91['snap'])_0x36758b['visibleWrites']=or(_0x36758b['visibleWrites'],_0x57df91['path']);else{const _0x21e9b0=_0x57df91['children'];x(_0x21e9b0,_0x5d289c=>{_0x36758b['visibleWrites']=or(_0x36758b['visibleWrites'],k(_0x57df91['path'],_0x5d289c));});}return!0x0;}else return!0x1;}function du(_0x3319ba,_0x137eca){if(_0x3319ba['snap'])return G(_0x3319ba['path'],_0x137eca);for(const _0x378945 in _0x3319ba['children'])if(_0x3319ba['children']['hasOwnProperty'](_0x378945)&&G(k(_0x3319ba['path'],_0x378945),_0x137eca))return!0x0;return!0x1;}function fu(_0x38e33f){_0x38e33f['visibleWrites']=Wo(_0x38e33f['allWrites'],pu,w()),_0x38e33f['allWrites']['length']>0x0?_0x38e33f['lastWriteId']=_0x38e33f['allWrites'][_0x38e33f['allWrites']['length']-0x1]['writeId']:_0x38e33f['lastWriteId']=-0x1;}function pu(_0xc6bb38){return _0xc6bb38['visible'];}function Wo(_0x1710d2,_0x27fdd9,_0x20141f){let _0x3bc0db=K['empty']();for(let _0x464b1a=0x0;_0x464b1a<_0x1710d2['length'];++_0x464b1a){const _0x28de10=_0x1710d2[_0x464b1a];if(_0x27fdd9(_0x28de10)){const _0x4d4c2f=_0x28de10['path'];let _0x2017bf;if(_0x28de10['snap'])G(_0x20141f,_0x4d4c2f)?(_0x2017bf=F(_0x20141f,_0x4d4c2f),_0x3bc0db=Rt(_0x3bc0db,_0x2017bf,_0x28de10['snap'])):G(_0x4d4c2f,_0x20141f)&&(_0x2017bf=F(_0x4d4c2f,_0x20141f),_0x3bc0db=Rt(_0x3bc0db,w(),_0x28de10['snap']['getChild'](_0x2017bf)));else{if(_0x28de10['children']){if(G(_0x20141f,_0x4d4c2f))_0x2017bf=F(_0x20141f,_0x4d4c2f),_0x3bc0db=bi(_0x3bc0db,_0x2017bf,_0x28de10['children']);else{if(G(_0x4d4c2f,_0x20141f)){if(_0x2017bf=F(_0x4d4c2f,_0x20141f),v(_0x2017bf))_0x3bc0db=bi(_0x3bc0db,w(),_0x28de10['children']);else{const _0x30337b=Me(_0x28de10['children'],y(_0x2017bf));if(_0x30337b){const _0x190f19=_0x30337b['getChild'](S(_0x2017bf));_0x3bc0db=Rt(_0x3bc0db,w(),_0x190f19);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3bc0db;}function Bo(_0x3e5d99,_0x155135,_0x39b719,_0x837cbc,_0x598ce2){if(!_0x837cbc&&!_0x598ce2){const _0x2939c1=qe(_0x3e5d99['visibleWrites'],_0x155135);if(_0x2939c1!=null)return _0x2939c1;{const _0x4bf4aa=Ee(_0x3e5d99['visibleWrites'],_0x155135);if(Ai(_0x4bf4aa))return _0x39b719;if(_0x39b719==null&&!Ri(_0x4bf4aa,w()))return null;{const _0x4e25cb=_0x39b719||g['EMPTY_NODE'];return at(_0x4bf4aa,_0x4e25cb);}}}else{const _0xedca4c=Ee(_0x3e5d99['visibleWrites'],_0x155135);if(!_0x598ce2&&Ai(_0xedca4c))return _0x39b719;if(!_0x598ce2&&_0x39b719==null&&!Ri(_0xedca4c,w()))return null;{const _0x547557=function(_0x599138){return(_0x599138['visible']||_0x598ce2)&&(!_0x837cbc||!~_0x837cbc['indexOf'](_0x599138['writeId']))&&(G(_0x599138['path'],_0x155135)||G(_0x155135,_0x599138['path']));},_0x52b586=Wo(_0x3e5d99['allWrites'],_0x547557,_0x155135),_0xdbad8d=_0x39b719||g['EMPTY_NODE'];return at(_0x52b586,_0xdbad8d);}}}function _u(_0x5dd90b,_0x574f3b,_0x1d6fc9){let _0x1920ca=g['EMPTY_NODE'];const _0x1ba586=qe(_0x5dd90b['visibleWrites'],_0x574f3b);if(_0x1ba586)return _0x1ba586['isLeafNode']()||_0x1ba586['forEachChild'](R,(_0xdaff54,_0x491055)=>{_0x1920ca=_0x1920ca['updateImmediateChild'](_0xdaff54,_0x491055);}),_0x1920ca;if(_0x1d6fc9){const _0xfd8aa0=Ee(_0x5dd90b['visibleWrites'],_0x574f3b);return _0x1d6fc9['forEachChild'](R,(_0x9cf34f,_0x20a7a3)=>{const _0x3fbda8=at(Ee(_0xfd8aa0,new C(_0x9cf34f)),_0x20a7a3);_0x1920ca=_0x1920ca['updateImmediateChild'](_0x9cf34f,_0x3fbda8);}),ar(_0xfd8aa0)['forEach'](_0x4a50a0=>{_0x1920ca=_0x1920ca['updateImmediateChild'](_0x4a50a0['name'],_0x4a50a0['node']);}),_0x1920ca;}else{const _0x1a6933=Ee(_0x5dd90b['visibleWrites'],_0x574f3b);return ar(_0x1a6933)['forEach'](_0xb4b9d1=>{_0x1920ca=_0x1920ca['updateImmediateChild'](_0xb4b9d1['name'],_0xb4b9d1['node']);}),_0x1920ca;}}function gu(_0x367816,_0x585533,_0x72bc5f,_0x11a9a3,_0x551326){f(_0x11a9a3||_0x551326,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x6a23d=k(_0x585533,_0x72bc5f);if(Ri(_0x367816['visibleWrites'],_0x6a23d))return null;{const _0x368682=Ee(_0x367816['visibleWrites'],_0x6a23d);return Ai(_0x368682)?_0x551326['getChild'](_0x72bc5f):at(_0x368682,_0x551326['getChild'](_0x72bc5f));}}function mu(_0x5e3a31,_0x34512a,_0x58599c,_0x28e40e){const _0x5a3f54=k(_0x34512a,_0x58599c),_0x4041a4=qe(_0x5e3a31['visibleWrites'],_0x5a3f54);if(_0x4041a4!=null)return _0x4041a4;if(_0x28e40e['isCompleteForChild'](_0x58599c)){const _0x4554fa=Ee(_0x5e3a31['visibleWrites'],_0x5a3f54);return at(_0x4554fa,_0x28e40e['getNode']()['getImmediateChild'](_0x58599c));}else return null;}function yu(_0x6fe220,_0x4c18f5){return qe(_0x6fe220['visibleWrites'],_0x4c18f5);}function vu(_0x1e43fe,_0x3d6cca,_0x43d17c,_0x4d9937,_0x452b31,_0x2acc35,_0x11a06a){let _0xb54446;const _0x32bc08=Ee(_0x1e43fe['visibleWrites'],_0x3d6cca),_0x158e6c=qe(_0x32bc08,w());if(_0x158e6c!=null)_0xb54446=_0x158e6c;else{if(_0x43d17c!=null)_0xb54446=at(_0x32bc08,_0x43d17c);else return[];}if(_0xb54446=_0xb54446['withIndex'](_0x11a06a),!_0xb54446['isEmpty']()&&!_0xb54446['isLeafNode']()){const _0x1802ca=[],_0x540adf=_0x11a06a['getCompare'](),_0x475845=_0x2acc35?_0xb54446['getReverseIteratorFrom'](_0x4d9937,_0x11a06a):_0xb54446['getIteratorFrom'](_0x4d9937,_0x11a06a);let _0x359424=_0x475845['getNext']();for(;_0x359424&&_0x1802ca['length']<_0x452b31;)_0x540adf(_0x359424,_0x4d9937)!==0x0&&_0x1802ca['push'](_0x359424),_0x359424=_0x475845['getNext']();return _0x1802ca;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x3e279f,_0x5b80aa,_0xf89291,_0x393437){return Bo(_0x3e279f['writeTree'],_0x3e279f['treePath'],_0x5b80aa,_0xf89291,_0x393437);}function is(_0x35ea29,_0x4fe930){return _u(_0x35ea29['writeTree'],_0x35ea29['treePath'],_0x4fe930);}function cr(_0x48f8ef,_0x3c8e17,_0x39cee7,_0x1b40c5){return gu(_0x48f8ef['writeTree'],_0x48f8ef['treePath'],_0x3c8e17,_0x39cee7,_0x1b40c5);}function Tn(_0xe9496b,_0x5cc86e){return yu(_0xe9496b['writeTree'],k(_0xe9496b['treePath'],_0x5cc86e));}function Iu(_0xea868d,_0x35c107,_0xe7783c,_0x1d539e,_0x39a2bd,_0x4c4aa6){return vu(_0xea868d['writeTree'],_0xea868d['treePath'],_0x35c107,_0xe7783c,_0x1d539e,_0x39a2bd,_0x4c4aa6);}function ss(_0x15d099,_0x3115f8,_0x1783e2){return mu(_0x15d099['writeTree'],_0x15d099['treePath'],_0x3115f8,_0x1783e2);}function Vo(_0x5116d5,_0x3cf403){return Ho(k(_0x5116d5['treePath'],_0x3cf403),_0x5116d5['writeTree']);}function Ho(_0xa3e8b8,_0x1237df){return{'treePath':_0xa3e8b8,'writeTree':_0x1237df};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x126f5a){const _0x3b1b89=_0x126f5a['type'],_0x48fb29=_0x126f5a['childName'];f(_0x3b1b89==='child_added'||_0x3b1b89==='child_changed'||_0x3b1b89==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x48fb29!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x10c19e=this['changeMap']['get'](_0x48fb29);if(_0x10c19e){const _0x20794a=_0x10c19e['type'];if(_0x3b1b89==='child_added'&&_0x20794a==='child_removed')this['changeMap']['set'](_0x48fb29,Lt(_0x48fb29,_0x126f5a['snapshotNode'],_0x10c19e['snapshotNode']));else{if(_0x3b1b89==='child_removed'&&_0x20794a==='child_added')this['changeMap']['delete'](_0x48fb29);else{if(_0x3b1b89==='child_removed'&&_0x20794a==='child_changed')this['changeMap']['set'](_0x48fb29,Mt(_0x48fb29,_0x10c19e['oldSnap']));else{if(_0x3b1b89==='child_changed'&&_0x20794a==='child_added')this['changeMap']['set'](_0x48fb29,rt(_0x48fb29,_0x126f5a['snapshotNode']));else{if(_0x3b1b89==='child_changed'&&_0x20794a==='child_changed')this['changeMap']['set'](_0x48fb29,Lt(_0x48fb29,_0x126f5a['snapshotNode'],_0x10c19e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x126f5a+'\x20occurred\x20after\x20'+_0x10c19e);}}}}}else this['changeMap']['set'](_0x48fb29,_0x126f5a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x519575){return null;}['getChildAfterChild'](_0x5047b8,_0x11cd5e,_0x3c9000){return null;}}const $o=new Cu();class rs{constructor(_0x4c0de5,_0x24fc66,_0x5012e8=null){this['writes_']=_0x4c0de5,this['viewCache_']=_0x24fc66,this['optCompleteServerCache_']=_0x5012e8;}['getCompleteChild'](_0x4c9481){const _0x1083f5=this['viewCache_']['eventCache'];if(_0x1083f5['isCompleteForChild'](_0x4c9481))return _0x1083f5['getNode']()['getImmediateChild'](_0x4c9481);{const _0x33214a=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x4c9481,_0x33214a);}}['getChildAfterChild'](_0xdf1a4f,_0xdd8096,_0x2731c2){const _0x3887ac=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x32cae3=Iu(this['writes_'],_0x3887ac,_0xdd8096,0x1,_0x2731c2,_0xdf1a4f);return _0x32cae3['length']===0x0?null:_0x32cae3[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x433879){return{'filter':_0x433879};}function Su(_0x529743,_0x618588){f(_0x618588['eventCache']['getNode']()['isIndexed'](_0x529743['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x618588['serverCache']['getNode']()['isIndexed'](_0x529743['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x561157,_0x47d0c2,_0x485172,_0x386367,_0x4232fb){const _0x414a21=new wu();let _0x22ed31,_0x53d54a;if(_0x485172['type']===z['OVERWRITE']){const _0x4c9d1f=_0x485172;_0x4c9d1f['source']['fromUser']?_0x22ed31=ki(_0x561157,_0x47d0c2,_0x4c9d1f['path'],_0x4c9d1f['snap'],_0x386367,_0x4232fb,_0x414a21):(f(_0x4c9d1f['source']['fromServer'],'Unknown\x20source.'),_0x53d54a=_0x4c9d1f['source']['tagged']||_0x47d0c2['serverCache']['isFiltered']()&&!v(_0x4c9d1f['path']),_0x22ed31=Sn(_0x561157,_0x47d0c2,_0x4c9d1f['path'],_0x4c9d1f['snap'],_0x386367,_0x4232fb,_0x53d54a,_0x414a21));}else{if(_0x485172['type']===z['MERGE']){const _0x3e5f49=_0x485172;_0x3e5f49['source']['fromUser']?_0x22ed31=Au(_0x561157,_0x47d0c2,_0x3e5f49['path'],_0x3e5f49['children'],_0x386367,_0x4232fb,_0x414a21):(f(_0x3e5f49['source']['fromServer'],'Unknown\x20source.'),_0x53d54a=_0x3e5f49['source']['tagged']||_0x47d0c2['serverCache']['isFiltered'](),_0x22ed31=Ni(_0x561157,_0x47d0c2,_0x3e5f49['path'],_0x3e5f49['children'],_0x386367,_0x4232fb,_0x53d54a,_0x414a21));}else{if(_0x485172['type']===z['ACK_USER_WRITE']){const _0x136bb3=_0x485172;_0x136bb3['revert']?_0x22ed31=Pu(_0x561157,_0x47d0c2,_0x136bb3['path'],_0x386367,_0x4232fb,_0x414a21):_0x22ed31=ku(_0x561157,_0x47d0c2,_0x136bb3['path'],_0x136bb3['affectedTree'],_0x386367,_0x4232fb,_0x414a21);}else{if(_0x485172['type']===z['LISTEN_COMPLETE'])_0x22ed31=Nu(_0x561157,_0x47d0c2,_0x485172['path'],_0x386367,_0x414a21);else throw ht('Unknown\x20operation\x20type:\x20'+_0x485172['type']);}}}const _0x47eee6=_0x414a21['getChanges']();return Ru(_0x47d0c2,_0x22ed31,_0x47eee6),{'viewCache':_0x22ed31,'changes':_0x47eee6};}function Ru(_0x262edf,_0x1f911d,_0x18a191){const _0x5776aa=_0x1f911d['eventCache'];if(_0x5776aa['isFullyInitialized']()){const _0x41eb68=_0x5776aa['getNode']()['isLeafNode']()||_0x5776aa['getNode']()['isEmpty'](),_0x4cd781=wn(_0x262edf);(_0x18a191['length']>0x0||!_0x262edf['eventCache']['isFullyInitialized']()||_0x41eb68&&!_0x5776aa['getNode']()['equals'](_0x4cd781)||!_0x5776aa['getNode']()['getPriority']()['equals'](_0x4cd781['getPriority']()))&&_0x18a191['push'](Lo(wn(_0x1f911d)));}}function Go(_0x7ba264,_0x30c3dd,_0x4f1d61,_0xbad601,_0x200297,_0x8ebf0a){const _0x41d88e=_0x30c3dd['eventCache'];if(Tn(_0xbad601,_0x4f1d61)!=null)return _0x30c3dd;{let _0x2c64de,_0x213083;if(v(_0x4f1d61)){if(f(_0x30c3dd['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x30c3dd['serverCache']['isFiltered']()){const _0x5b9ce3=Be(_0x30c3dd),_0x2f3910=_0x5b9ce3 instanceof g?_0x5b9ce3:g['EMPTY_NODE'],_0xc3d766=is(_0xbad601,_0x2f3910);_0x2c64de=_0x7ba264['filter']['updateFullNode'](_0x30c3dd['eventCache']['getNode'](),_0xc3d766,_0x8ebf0a);}else{const _0x49283a=Cn(_0xbad601,Be(_0x30c3dd));_0x2c64de=_0x7ba264['filter']['updateFullNode'](_0x30c3dd['eventCache']['getNode'](),_0x49283a,_0x8ebf0a);}}else{const _0x151190=y(_0x4f1d61);if(_0x151190==='.priority'){f(Ce(_0x4f1d61)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1337ae=_0x41d88e['getNode']();_0x213083=_0x30c3dd['serverCache']['getNode']();const _0x351bd1=cr(_0xbad601,_0x4f1d61,_0x1337ae,_0x213083);_0x351bd1!=null?_0x2c64de=_0x7ba264['filter']['updatePriority'](_0x1337ae,_0x351bd1):_0x2c64de=_0x41d88e['getNode']();}else{const _0x4b4c40=S(_0x4f1d61);let _0x549f5b;if(_0x41d88e['isCompleteForChild'](_0x151190)){_0x213083=_0x30c3dd['serverCache']['getNode']();const _0x29daf3=cr(_0xbad601,_0x4f1d61,_0x41d88e['getNode'](),_0x213083);_0x29daf3!=null?_0x549f5b=_0x41d88e['getNode']()['getImmediateChild'](_0x151190)['updateChild'](_0x4b4c40,_0x29daf3):_0x549f5b=_0x41d88e['getNode']()['getImmediateChild'](_0x151190);}else _0x549f5b=ss(_0xbad601,_0x151190,_0x30c3dd['serverCache']);_0x549f5b!=null?_0x2c64de=_0x7ba264['filter']['updateChild'](_0x41d88e['getNode'](),_0x151190,_0x549f5b,_0x4b4c40,_0x200297,_0x8ebf0a):_0x2c64de=_0x41d88e['getNode']();}}return bt(_0x30c3dd,_0x2c64de,_0x41d88e['isFullyInitialized']()||v(_0x4f1d61),_0x7ba264['filter']['filtersNodes']());}}function Sn(_0x14a246,_0x17c209,_0xaf9fa1,_0xbd9eaf,_0x25a896,_0x29e251,_0x491c01,_0x397be2){const _0x29a333=_0x17c209['serverCache'];let _0x5659b0;const _0x1a9b21=_0x491c01?_0x14a246['filter']:_0x14a246['filter']['getIndexedFilter']();if(v(_0xaf9fa1))_0x5659b0=_0x1a9b21['updateFullNode'](_0x29a333['getNode'](),_0xbd9eaf,null);else{if(_0x1a9b21['filtersNodes']()&&!_0x29a333['isFiltered']()){const _0x47bf61=_0x29a333['getNode']()['updateChild'](_0xaf9fa1,_0xbd9eaf);_0x5659b0=_0x1a9b21['updateFullNode'](_0x29a333['getNode'](),_0x47bf61,null);}else{const _0x585b48=y(_0xaf9fa1);if(!_0x29a333['isCompleteForPath'](_0xaf9fa1)&&Ce(_0xaf9fa1)>0x1)return _0x17c209;const _0x21266b=S(_0xaf9fa1),_0x765b81=_0x29a333['getNode']()['getImmediateChild'](_0x585b48)['updateChild'](_0x21266b,_0xbd9eaf);_0x585b48==='.priority'?_0x5659b0=_0x1a9b21['updatePriority'](_0x29a333['getNode'](),_0x765b81):_0x5659b0=_0x1a9b21['updateChild'](_0x29a333['getNode'](),_0x585b48,_0x765b81,_0x21266b,$o,null);}}const _0x14a484=Fo(_0x17c209,_0x5659b0,_0x29a333['isFullyInitialized']()||v(_0xaf9fa1),_0x1a9b21['filtersNodes']()),_0x42c04c=new rs(_0x25a896,_0x14a484,_0x29e251);return Go(_0x14a246,_0x14a484,_0xaf9fa1,_0x25a896,_0x42c04c,_0x397be2);}function ki(_0x1b4e0a,_0x18ef68,_0xde0365,_0x57616b,_0x2fc1c3,_0x28ed92,_0x382c86){const _0x16840d=_0x18ef68['eventCache'];let _0x1fb479,_0x1a3ce8;const _0x2c5c20=new rs(_0x2fc1c3,_0x18ef68,_0x28ed92);if(v(_0xde0365))_0x1a3ce8=_0x1b4e0a['filter']['updateFullNode'](_0x18ef68['eventCache']['getNode'](),_0x57616b,_0x382c86),_0x1fb479=bt(_0x18ef68,_0x1a3ce8,!0x0,_0x1b4e0a['filter']['filtersNodes']());else{const _0xe2bbe9=y(_0xde0365);if(_0xe2bbe9==='.priority')_0x1a3ce8=_0x1b4e0a['filter']['updatePriority'](_0x18ef68['eventCache']['getNode'](),_0x57616b),_0x1fb479=bt(_0x18ef68,_0x1a3ce8,_0x16840d['isFullyInitialized'](),_0x16840d['isFiltered']());else{const _0x53ab25=S(_0xde0365),_0x29d046=_0x16840d['getNode']()['getImmediateChild'](_0xe2bbe9);let _0x294cf4;if(v(_0x53ab25))_0x294cf4=_0x57616b;else{const _0x32634f=_0x2c5c20['getCompleteChild'](_0xe2bbe9);_0x32634f!=null?ji(_0x53ab25)==='.priority'&&_0x32634f['getChild'](Ro(_0x53ab25))['isEmpty']()?_0x294cf4=_0x32634f:_0x294cf4=_0x32634f['updateChild'](_0x53ab25,_0x57616b):_0x294cf4=g['EMPTY_NODE'];}if(_0x29d046['equals'](_0x294cf4))_0x1fb479=_0x18ef68;else{const _0x643500=_0x1b4e0a['filter']['updateChild'](_0x16840d['getNode'](),_0xe2bbe9,_0x294cf4,_0x53ab25,_0x2c5c20,_0x382c86);_0x1fb479=bt(_0x18ef68,_0x643500,_0x16840d['isFullyInitialized'](),_0x1b4e0a['filter']['filtersNodes']());}}}return _0x1fb479;}function lr(_0xecc7ea,_0x1c0b0e){return _0xecc7ea['eventCache']['isCompleteForChild'](_0x1c0b0e);}function Au(_0x2704f4,_0x4e31f2,_0x1575e2,_0x1291e8,_0x121605,_0x54b895,_0x25769e){let _0x129418=_0x4e31f2;return _0x1291e8['foreach']((_0x32b3d7,_0x118bda)=>{const _0x4645af=k(_0x1575e2,_0x32b3d7);lr(_0x4e31f2,y(_0x4645af))&&(_0x129418=ki(_0x2704f4,_0x129418,_0x4645af,_0x118bda,_0x121605,_0x54b895,_0x25769e));}),_0x1291e8['foreach']((_0x38e068,_0x2e67cd)=>{const _0xd386cb=k(_0x1575e2,_0x38e068);lr(_0x4e31f2,y(_0xd386cb))||(_0x129418=ki(_0x2704f4,_0x129418,_0xd386cb,_0x2e67cd,_0x121605,_0x54b895,_0x25769e));}),_0x129418;}function hr(_0x24d218,_0x3cf061,_0x2fbd21){return _0x2fbd21['foreach']((_0x38365d,_0x22facd)=>{_0x3cf061=_0x3cf061['updateChild'](_0x38365d,_0x22facd);}),_0x3cf061;}function Ni(_0x366665,_0x5c34c6,_0x1eae95,_0x51c19a,_0x4c4d74,_0x5503b5,_0x3d8620,_0x15638e){if(_0x5c34c6['serverCache']['getNode']()['isEmpty']()&&!_0x5c34c6['serverCache']['isFullyInitialized']())return _0x5c34c6;let _0x5f261a=_0x5c34c6,_0x3bd4a3;v(_0x1eae95)?_0x3bd4a3=_0x51c19a:_0x3bd4a3=new b(null)['setTree'](_0x1eae95,_0x51c19a);const _0x3b0924=_0x5c34c6['serverCache']['getNode']();return _0x3bd4a3['children']['inorderTraversal']((_0x1d579e,_0x48580f)=>{if(_0x3b0924['hasChild'](_0x1d579e)){const _0x5ea9c8=_0x5c34c6['serverCache']['getNode']()['getImmediateChild'](_0x1d579e),_0x338392=hr(_0x366665,_0x5ea9c8,_0x48580f);_0x5f261a=Sn(_0x366665,_0x5f261a,new C(_0x1d579e),_0x338392,_0x4c4d74,_0x5503b5,_0x3d8620,_0x15638e);}}),_0x3bd4a3['children']['inorderTraversal']((_0x5db74d,_0x3a5a92)=>{const _0x33c09b=!_0x5c34c6['serverCache']['isCompleteForChild'](_0x5db74d)&&_0x3a5a92['value']===null;if(!_0x3b0924['hasChild'](_0x5db74d)&&!_0x33c09b){const _0x41858c=_0x5c34c6['serverCache']['getNode']()['getImmediateChild'](_0x5db74d),_0x27fb39=hr(_0x366665,_0x41858c,_0x3a5a92);_0x5f261a=Sn(_0x366665,_0x5f261a,new C(_0x5db74d),_0x27fb39,_0x4c4d74,_0x5503b5,_0x3d8620,_0x15638e);}}),_0x5f261a;}function ku(_0x46a91a,_0x30e4ac,_0x4847d5,_0x390b9f,_0x5c23a2,_0x897be2,_0x43277c){if(Tn(_0x5c23a2,_0x4847d5)!=null)return _0x30e4ac;const _0x45ee13=_0x30e4ac['serverCache']['isFiltered'](),_0x17db4b=_0x30e4ac['serverCache'];if(_0x390b9f['value']!=null){if(v(_0x4847d5)&&_0x17db4b['isFullyInitialized']()||_0x17db4b['isCompleteForPath'](_0x4847d5))return Sn(_0x46a91a,_0x30e4ac,_0x4847d5,_0x17db4b['getNode']()['getChild'](_0x4847d5),_0x5c23a2,_0x897be2,_0x45ee13,_0x43277c);if(v(_0x4847d5)){let _0x3630e5=new b(null);return _0x17db4b['getNode']()['forEachChild'](ve,(_0x342b94,_0x1fceae)=>{_0x3630e5=_0x3630e5['set'](new C(_0x342b94),_0x1fceae);}),Ni(_0x46a91a,_0x30e4ac,_0x4847d5,_0x3630e5,_0x5c23a2,_0x897be2,_0x45ee13,_0x43277c);}else return _0x30e4ac;}else{let _0x2288c0=new b(null);return _0x390b9f['foreach']((_0x146057,_0xb51d3c)=>{const _0x20f621=k(_0x4847d5,_0x146057);_0x17db4b['isCompleteForPath'](_0x20f621)&&(_0x2288c0=_0x2288c0['set'](_0x146057,_0x17db4b['getNode']()['getChild'](_0x20f621)));}),Ni(_0x46a91a,_0x30e4ac,_0x4847d5,_0x2288c0,_0x5c23a2,_0x897be2,_0x45ee13,_0x43277c);}}function Nu(_0x1e5623,_0x17f239,_0xa7da50,_0x11de9a,_0x3657da){const _0x5116f0=_0x17f239['serverCache'],_0x2fa80e=Fo(_0x17f239,_0x5116f0['getNode'](),_0x5116f0['isFullyInitialized']()||v(_0xa7da50),_0x5116f0['isFiltered']());return Go(_0x1e5623,_0x2fa80e,_0xa7da50,_0x11de9a,$o,_0x3657da);}function Pu(_0x319486,_0x239f7b,_0x3a5b5f,_0x30f911,_0x302816,_0x228264){let _0x2ad7aa;if(Tn(_0x30f911,_0x3a5b5f)!=null)return _0x239f7b;{const _0x3ef123=new rs(_0x30f911,_0x239f7b,_0x302816),_0x65b762=_0x239f7b['eventCache']['getNode']();let _0x1ae2d1;if(v(_0x3a5b5f)||y(_0x3a5b5f)==='.priority'){let _0x793579;if(_0x239f7b['serverCache']['isFullyInitialized']())_0x793579=Cn(_0x30f911,Be(_0x239f7b));else{const _0x58fb7a=_0x239f7b['serverCache']['getNode']();f(_0x58fb7a instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x793579=is(_0x30f911,_0x58fb7a);}_0x793579=_0x793579,_0x1ae2d1=_0x319486['filter']['updateFullNode'](_0x65b762,_0x793579,_0x228264);}else{const _0x1068dd=y(_0x3a5b5f);let _0x18a57b=ss(_0x30f911,_0x1068dd,_0x239f7b['serverCache']);_0x18a57b==null&&_0x239f7b['serverCache']['isCompleteForChild'](_0x1068dd)&&(_0x18a57b=_0x65b762['getImmediateChild'](_0x1068dd)),_0x18a57b!=null?_0x1ae2d1=_0x319486['filter']['updateChild'](_0x65b762,_0x1068dd,_0x18a57b,S(_0x3a5b5f),_0x3ef123,_0x228264):_0x239f7b['eventCache']['getNode']()['hasChild'](_0x1068dd)?_0x1ae2d1=_0x319486['filter']['updateChild'](_0x65b762,_0x1068dd,g['EMPTY_NODE'],S(_0x3a5b5f),_0x3ef123,_0x228264):_0x1ae2d1=_0x65b762,_0x1ae2d1['isEmpty']()&&_0x239f7b['serverCache']['isFullyInitialized']()&&(_0x2ad7aa=Cn(_0x30f911,Be(_0x239f7b)),_0x2ad7aa['isLeafNode']()&&(_0x1ae2d1=_0x319486['filter']['updateFullNode'](_0x1ae2d1,_0x2ad7aa,_0x228264)));}return _0x2ad7aa=_0x239f7b['serverCache']['isFullyInitialized']()||Tn(_0x30f911,w())!=null,bt(_0x239f7b,_0x1ae2d1,_0x2ad7aa,_0x319486['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x11754b,_0x14c04c){this['query_']=_0x11754b,this['eventRegistrations_']=[];const _0x1ddb8e=this['query_']['_queryParams'],_0x320209=new Xi(_0x1ddb8e['getIndex']()),_0x1abe46=Kh(_0x1ddb8e);this['processor_']=Tu(_0x1abe46);const _0x39792d=_0x14c04c['serverCache'],_0x4e4517=_0x14c04c['eventCache'],_0x2480fc=_0x320209['updateFullNode'](g['EMPTY_NODE'],_0x39792d['getNode'](),null),_0x1e1465=_0x1abe46['updateFullNode'](g['EMPTY_NODE'],_0x4e4517['getNode'](),null),_0x523747=new Te(_0x2480fc,_0x39792d['isFullyInitialized'](),_0x320209['filtersNodes']()),_0x76c5d4=new Te(_0x1e1465,_0x4e4517['isFullyInitialized'](),_0x1abe46['filtersNodes']());this['viewCache_']=Un(_0x76c5d4,_0x523747),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0x53abf2){return _0x53abf2['viewCache_']['serverCache']['getNode']();}function Mu(_0x1e8855){return wn(_0x1e8855['viewCache_']);}function Lu(_0x25a167,_0x5a6345){const _0x2067fc=Be(_0x25a167['viewCache_']);return _0x2067fc&&(_0x25a167['query']['_queryParams']['loadsAllData']()||!v(_0x5a6345)&&!_0x2067fc['getImmediateChild'](y(_0x5a6345))['isEmpty']())?_0x2067fc['getChild'](_0x5a6345):null;}function ur(_0x231404){return _0x231404['eventRegistrations_']['length']===0x0;}function xu(_0xaf3b69,_0x5b66cb){_0xaf3b69['eventRegistrations_']['push'](_0x5b66cb);}function dr(_0x3fcddd,_0x5494e9,_0x469df9){const _0x2f7dac=[];if(_0x469df9){f(_0x5494e9==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3355b5=_0x3fcddd['query']['_path'];_0x3fcddd['eventRegistrations_']['forEach'](_0x2e0a99=>{const _0x4ef08c=_0x2e0a99['createCancelEvent'](_0x469df9,_0x3355b5);_0x4ef08c&&_0x2f7dac['push'](_0x4ef08c);});}if(_0x5494e9){let _0x292dc1=[];for(let _0x184e23=0x0;_0x184e23<_0x3fcddd['eventRegistrations_']['length'];++_0x184e23){const _0x448d3c=_0x3fcddd['eventRegistrations_'][_0x184e23];if(!_0x448d3c['matches'](_0x5494e9))_0x292dc1['push'](_0x448d3c);else{if(_0x5494e9['hasAnyCallback']()){_0x292dc1=_0x292dc1['concat'](_0x3fcddd['eventRegistrations_']['slice'](_0x184e23+0x1));break;}}}_0x3fcddd['eventRegistrations_']=_0x292dc1;}else _0x3fcddd['eventRegistrations_']=[];return _0x2f7dac;}function fr(_0x50b6b5,_0x4fec5e,_0x42999b,_0x51d810){_0x4fec5e['type']===z['MERGE']&&_0x4fec5e['source']['queryId']!==null&&(f(Be(_0x50b6b5['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x50b6b5['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4185ab=_0x50b6b5['viewCache_'],_0x57445f=bu(_0x50b6b5['processor_'],_0x4185ab,_0x4fec5e,_0x42999b,_0x51d810);return Su(_0x50b6b5['processor_'],_0x57445f['viewCache']),f(_0x57445f['viewCache']['serverCache']['isFullyInitialized']()||!_0x4185ab['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x50b6b5['viewCache_']=_0x57445f['viewCache'],qo(_0x50b6b5,_0x57445f['changes'],_0x57445f['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x48191d,_0x4813f6){const _0x5b209c=_0x48191d['viewCache_']['eventCache'],_0x3d25de=[];return _0x5b209c['getNode']()['isLeafNode']()||_0x5b209c['getNode']()['forEachChild'](R,(_0x1cd192,_0x255c33)=>{_0x3d25de['push'](rt(_0x1cd192,_0x255c33));}),_0x5b209c['isFullyInitialized']()&&_0x3d25de['push'](Lo(_0x5b209c['getNode']())),qo(_0x48191d,_0x3d25de,_0x5b209c['getNode'](),_0x4813f6);}function qo(_0x2b606c,_0x4707cc,_0x132841,_0x94e63a){const _0x92acc1=_0x94e63a?[_0x94e63a]:_0x2b606c['eventRegistrations_'];return su(_0x2b606c['eventGenerator_'],_0x4707cc,_0x132841,_0x92acc1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x5b95b1){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x5b95b1;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x50180a){return _0x50180a['views']['size']===0x0;}function os(_0xf598b4,_0x37224e,_0x325ee1,_0x570375){const _0x1c8236=_0x37224e['source']['queryId'];if(_0x1c8236!==null){const _0xe9cffe=_0xf598b4['views']['get'](_0x1c8236);return f(_0xe9cffe!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xe9cffe,_0x37224e,_0x325ee1,_0x570375);}else{let _0x21acc6=[];for(const _0x2e1a0d of _0xf598b4['views']['values']())_0x21acc6=_0x21acc6['concat'](fr(_0x2e1a0d,_0x37224e,_0x325ee1,_0x570375));return _0x21acc6;}}function jo(_0x54890b,_0x2611e1,_0x634336,_0x53b0cd,_0x4e1f54){const _0x4aa26e=_0x2611e1['_queryIdentifier'],_0x4cca4b=_0x54890b['views']['get'](_0x4aa26e);if(!_0x4cca4b){let _0x521b08=Cn(_0x634336,_0x4e1f54?_0x53b0cd:null),_0x5251a3=!0x1;_0x521b08?_0x5251a3=!0x0:_0x53b0cd instanceof g?(_0x521b08=is(_0x634336,_0x53b0cd),_0x5251a3=!0x1):(_0x521b08=g['EMPTY_NODE'],_0x5251a3=!0x1);const _0x37829a=Un(new Te(_0x521b08,_0x5251a3,!0x1),new Te(_0x53b0cd,_0x4e1f54,!0x1));return new Ou(_0x2611e1,_0x37829a);}return _0x4cca4b;}function Vu(_0x1975ef,_0x13e3fe,_0x5ad7b2,_0x32cf04,_0x250e8a,_0x14926d){const _0x1746fd=jo(_0x1975ef,_0x13e3fe,_0x32cf04,_0x250e8a,_0x14926d);return _0x1975ef['views']['has'](_0x13e3fe['_queryIdentifier'])||_0x1975ef['views']['set'](_0x13e3fe['_queryIdentifier'],_0x1746fd),xu(_0x1746fd,_0x5ad7b2),Fu(_0x1746fd,_0x5ad7b2);}function Hu(_0xa18453,_0x1a581a,_0x26b21f,_0xe9fc6e){const _0x3ba520=_0x1a581a['_queryIdentifier'],_0x4aad31=[];let _0x5423fd=[];const _0x3cd9b8=Se(_0xa18453);if(_0x3ba520==='default'){for(const [_0x303830,_0x57f7ab]of _0xa18453['views']['entries']())_0x5423fd=_0x5423fd['concat'](dr(_0x57f7ab,_0x26b21f,_0xe9fc6e)),ur(_0x57f7ab)&&(_0xa18453['views']['delete'](_0x303830),_0x57f7ab['query']['_queryParams']['loadsAllData']()||_0x4aad31['push'](_0x57f7ab['query']));}else{const _0x5aabbf=_0xa18453['views']['get'](_0x3ba520);_0x5aabbf&&(_0x5423fd=_0x5423fd['concat'](dr(_0x5aabbf,_0x26b21f,_0xe9fc6e)),ur(_0x5aabbf)&&(_0xa18453['views']['delete'](_0x3ba520),_0x5aabbf['query']['_queryParams']['loadsAllData']()||_0x4aad31['push'](_0x5aabbf['query'])));}return _0x3cd9b8&&!Se(_0xa18453)&&_0x4aad31['push'](new(Wu())(_0x1a581a['_repo'],_0x1a581a['_path'])),{'removed':_0x4aad31,'events':_0x5423fd};}function Ko(_0x2d5b97){const _0x1de102=[];for(const _0x983aa2 of _0x2d5b97['views']['values']())_0x983aa2['query']['_queryParams']['loadsAllData']()||_0x1de102['push'](_0x983aa2);return _0x1de102;}function Ie(_0x227ec6,_0x76d1b0){let _0x4f4c53=null;for(const _0x3bbffb of _0x227ec6['views']['values']())_0x4f4c53=_0x4f4c53||Lu(_0x3bbffb,_0x76d1b0);return _0x4f4c53;}function Yo(_0x23a52e,_0x290415){if(_0x290415['_queryParams']['loadsAllData']())return Bn(_0x23a52e);{const _0x4ca52a=_0x290415['_queryIdentifier'];return _0x23a52e['views']['get'](_0x4ca52a);}}function Qo(_0x6f1640,_0x3918c3){return Yo(_0x6f1640,_0x3918c3)!=null;}function Se(_0x5ee883){return Bn(_0x5ee883)!=null;}function Bn(_0x18809e){for(const _0x3f4715 of _0x18809e['views']['values']())if(_0x3f4715['query']['_queryParams']['loadsAllData']())return _0x3f4715;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x3d43f1){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3d43f1;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x506f95){this['listenProvider_']=_0x506f95,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x27ab7f,_0x28d6e7,_0x3d94fa,_0x54d211,_0x56b647){return cu(_0x27ab7f['pendingWriteTree_'],_0x28d6e7,_0x3d94fa,_0x54d211,_0x56b647),_0x56b647?_t(_0x27ab7f,new We(es(),_0x28d6e7,_0x3d94fa)):[];}function zu(_0xfa826c,_0x3cb8c2,_0x3d3d1a,_0x58ae2f){lu(_0xfa826c['pendingWriteTree_'],_0x3cb8c2,_0x3d3d1a,_0x58ae2f);const _0x22973c=b['fromObject'](_0x3d3d1a);return _t(_0xfa826c,new ot(es(),_0x3cb8c2,_0x22973c));}function _e(_0x492428,_0x5a03a4,_0x265632=!0x1){const _0x584071=hu(_0x492428['pendingWriteTree_'],_0x5a03a4);if(uu(_0x492428['pendingWriteTree_'],_0x5a03a4)){let _0x83899f=new b(null);return _0x584071['snap']!=null?_0x83899f=_0x83899f['set'](w(),!0x0):x(_0x584071['children'],_0x591d88=>{_0x83899f=_0x83899f['set'](new C(_0x591d88),!0x0);}),_t(_0x492428,new In(_0x584071['path'],_0x83899f,_0x265632));}else return[];}function Kt(_0x12a3d1,_0x3aa366,_0x21e0c9){return _t(_0x12a3d1,new We(ts(),_0x3aa366,_0x21e0c9));}function ju(_0xb20f64,_0x35345a,_0x172e8b){const _0x5e7a36=b['fromObject'](_0x172e8b);return _t(_0xb20f64,new ot(ts(),_0x35345a,_0x5e7a36));}function Ku(_0x12bee0,_0x436933){return _t(_0x12bee0,new Ft(ts(),_0x436933));}function Yu(_0x554306,_0x53b1b3,_0x375aa0){const _0x4cc2bc=cs(_0x554306,_0x375aa0);if(_0x4cc2bc){const _0x15857c=ls(_0x4cc2bc),_0x21fbe6=_0x15857c['path'],_0x39b151=_0x15857c['queryId'],_0x3106b9=F(_0x21fbe6,_0x53b1b3),_0x21c20c=new Ft(ns(_0x39b151),_0x3106b9);return hs(_0x554306,_0x21fbe6,_0x21c20c);}else return[];}function An(_0x1c5ddc,_0x4c7f90,_0x4f2185,_0x13da6a,_0x39af0f=!0x1){const _0x1fc761=_0x4c7f90['_path'],_0x586762=_0x1c5ddc['syncPointTree_']['get'](_0x1fc761);let _0x1c6bca=[];if(_0x586762&&(_0x4c7f90['_queryIdentifier']==='default'||Qo(_0x586762,_0x4c7f90))){const _0x589695=Hu(_0x586762,_0x4c7f90,_0x4f2185,_0x13da6a);Bu(_0x586762)&&(_0x1c5ddc['syncPointTree_']=_0x1c5ddc['syncPointTree_']['remove'](_0x1fc761));const _0x92e4cc=_0x589695['removed'];if(_0x1c6bca=_0x589695['events'],!_0x39af0f){const _0x2fd76b=_0x92e4cc['findIndex'](_0x570d50=>_0x570d50['_queryParams']['loadsAllData']())!==-0x1,_0x30c7ea=_0x1c5ddc['syncPointTree_']['findOnPath'](_0x1fc761,(_0x41c25d,_0x57bef1)=>Se(_0x57bef1));if(_0x2fd76b&&!_0x30c7ea){const _0x4caaef=_0x1c5ddc['syncPointTree_']['subtree'](_0x1fc761);if(!_0x4caaef['isEmpty']()){const _0x35c2c6=Xu(_0x4caaef);for(let _0x4e079c=0x0;_0x4e079c<_0x35c2c6['length'];++_0x4e079c){const _0x5af763=_0x35c2c6[_0x4e079c],_0x2173e1=_0x5af763['query'],_0x5a10a0=ea(_0x1c5ddc,_0x5af763);_0x1c5ddc['listenProvider_']['startListening'](At(_0x2173e1),Ut(_0x1c5ddc,_0x2173e1),_0x5a10a0['hashFn'],_0x5a10a0['onComplete']);}}}!_0x30c7ea&&_0x92e4cc['length']>0x0&&!_0x13da6a&&(_0x2fd76b?_0x1c5ddc['listenProvider_']['stopListening'](At(_0x4c7f90),null):_0x92e4cc['forEach'](_0x2af06a=>{const _0x52b993=_0x1c5ddc['queryToTagMap']['get'](Hn(_0x2af06a));_0x1c5ddc['listenProvider_']['stopListening'](At(_0x2af06a),_0x52b993);}));}Zu(_0x1c5ddc,_0x92e4cc);}return _0x1c6bca;}function Jo(_0x43c8b5,_0x109420,_0x8a9dd,_0x39a32f){const _0x1d0467=cs(_0x43c8b5,_0x39a32f);if(_0x1d0467!=null){const _0x27fcbc=ls(_0x1d0467),_0x252d3f=_0x27fcbc['path'],_0x3dd58f=_0x27fcbc['queryId'],_0xb2dd17=F(_0x252d3f,_0x109420),_0x24a2f6=new We(ns(_0x3dd58f),_0xb2dd17,_0x8a9dd);return hs(_0x43c8b5,_0x252d3f,_0x24a2f6);}else return[];}function Qu(_0x25f5c3,_0x185c77,_0x21eee6,_0x4f581c){const _0x389a00=cs(_0x25f5c3,_0x4f581c);if(_0x389a00){const _0x184a68=ls(_0x389a00),_0x56fdb3=_0x184a68['path'],_0xa6c81e=_0x184a68['queryId'],_0x3115e0=F(_0x56fdb3,_0x185c77),_0x2fb4c0=b['fromObject'](_0x21eee6),_0x366064=new ot(ns(_0xa6c81e),_0x3115e0,_0x2fb4c0);return hs(_0x25f5c3,_0x56fdb3,_0x366064);}else return[];}function Pi(_0x3a61b5,_0x47e1e9,_0x43bfb6,_0x5b3180=!0x1){const _0x11212d=_0x47e1e9['_path'];let _0x9880cb=null,_0x1f3f8e=!0x1;_0x3a61b5['syncPointTree_']['foreachOnPath'](_0x11212d,(_0x5610e8,_0x260141)=>{const _0x1ba523=F(_0x5610e8,_0x11212d);_0x9880cb=_0x9880cb||Ie(_0x260141,_0x1ba523),_0x1f3f8e=_0x1f3f8e||Se(_0x260141);});let _0x41a1ed=_0x3a61b5['syncPointTree_']['get'](_0x11212d);_0x41a1ed?(_0x1f3f8e=_0x1f3f8e||Se(_0x41a1ed),_0x9880cb=_0x9880cb||Ie(_0x41a1ed,w())):(_0x41a1ed=new zo(),_0x3a61b5['syncPointTree_']=_0x3a61b5['syncPointTree_']['set'](_0x11212d,_0x41a1ed));let _0x1f706a;_0x9880cb!=null?_0x1f706a=!0x0:(_0x1f706a=!0x1,_0x9880cb=g['EMPTY_NODE'],_0x3a61b5['syncPointTree_']['subtree'](_0x11212d)['foreachChild']((_0x118ec0,_0x111734)=>{const _0x194f4f=Ie(_0x111734,w());_0x194f4f&&(_0x9880cb=_0x9880cb['updateImmediateChild'](_0x118ec0,_0x194f4f));}));const _0x3cfdb5=Qo(_0x41a1ed,_0x47e1e9);if(!_0x3cfdb5&&!_0x47e1e9['_queryParams']['loadsAllData']()){const _0x44e5a2=Hn(_0x47e1e9);f(!_0x3a61b5['queryToTagMap']['has'](_0x44e5a2),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x25e244=ed();_0x3a61b5['queryToTagMap']['set'](_0x44e5a2,_0x25e244),_0x3a61b5['tagToQueryMap']['set'](_0x25e244,_0x44e5a2);}const _0x15e8ba=Wn(_0x3a61b5['pendingWriteTree_'],_0x11212d);let _0x3dea92=Vu(_0x41a1ed,_0x47e1e9,_0x43bfb6,_0x15e8ba,_0x9880cb,_0x1f706a);if(!_0x3cfdb5&&!_0x1f3f8e&&!_0x5b3180){const _0x46d718=Yo(_0x41a1ed,_0x47e1e9);_0x3dea92=_0x3dea92['concat'](td(_0x3a61b5,_0x47e1e9,_0x46d718));}return _0x3dea92;}function Vn(_0x3c1f8f,_0x4aa744,_0x4e3798){const _0x28c9f2=_0x3c1f8f['pendingWriteTree_'],_0xe8096e=_0x3c1f8f['syncPointTree_']['findOnPath'](_0x4aa744,(_0x55baf2,_0x4349ae)=>{const _0x57dacd=F(_0x55baf2,_0x4aa744),_0x19c98a=Ie(_0x4349ae,_0x57dacd);if(_0x19c98a)return _0x19c98a;});return Bo(_0x28c9f2,_0x4aa744,_0xe8096e,_0x4e3798,!0x0);}function Ju(_0x1b6451,_0x38236d){const _0x41932e=_0x38236d['_path'];let _0x2c76bc=null;_0x1b6451['syncPointTree_']['foreachOnPath'](_0x41932e,(_0x16b15c,_0x46042b)=>{const _0x316391=F(_0x16b15c,_0x41932e);_0x2c76bc=_0x2c76bc||Ie(_0x46042b,_0x316391);});let _0x3d5cf8=_0x1b6451['syncPointTree_']['get'](_0x41932e);_0x3d5cf8?_0x2c76bc=_0x2c76bc||Ie(_0x3d5cf8,w()):(_0x3d5cf8=new zo(),_0x1b6451['syncPointTree_']=_0x1b6451['syncPointTree_']['set'](_0x41932e,_0x3d5cf8));const _0x106977=_0x2c76bc!=null,_0x2d629d=_0x106977?new Te(_0x2c76bc,!0x0,!0x1):null,_0x6b0035=Wn(_0x1b6451['pendingWriteTree_'],_0x38236d['_path']),_0xc2ccd=jo(_0x3d5cf8,_0x38236d,_0x6b0035,_0x106977?_0x2d629d['getNode']():g['EMPTY_NODE'],_0x106977);return Mu(_0xc2ccd);}function _t(_0x51d2de,_0x4a627e){return Xo(_0x4a627e,_0x51d2de['syncPointTree_'],null,Wn(_0x51d2de['pendingWriteTree_'],w()));}function Xo(_0x1228cd,_0x274757,_0x11d380,_0x5d0d35){if(v(_0x1228cd['path']))return Zo(_0x1228cd,_0x274757,_0x11d380,_0x5d0d35);{const _0x2c5d84=_0x274757['get'](w());_0x11d380==null&&_0x2c5d84!=null&&(_0x11d380=Ie(_0x2c5d84,w()));let _0x5a0aba=[];const _0x499e5f=y(_0x1228cd['path']),_0x3c09bf=_0x1228cd['operationForChild'](_0x499e5f),_0x510ed6=_0x274757['children']['get'](_0x499e5f);if(_0x510ed6&&_0x3c09bf){const _0xb8992=_0x11d380?_0x11d380['getImmediateChild'](_0x499e5f):null,_0x2c6825=Vo(_0x5d0d35,_0x499e5f);_0x5a0aba=_0x5a0aba['concat'](Xo(_0x3c09bf,_0x510ed6,_0xb8992,_0x2c6825));}return _0x2c5d84&&(_0x5a0aba=_0x5a0aba['concat'](os(_0x2c5d84,_0x1228cd,_0x5d0d35,_0x11d380))),_0x5a0aba;}}function Zo(_0x1c5514,_0x21a65a,_0x15be0a,_0x6f1f62){const _0x1284c4=_0x21a65a['get'](w());_0x15be0a==null&&_0x1284c4!=null&&(_0x15be0a=Ie(_0x1284c4,w()));let _0x2eb0d9=[];return _0x21a65a['children']['inorderTraversal']((_0x47bd8e,_0x314db1)=>{const _0x3b6c37=_0x15be0a?_0x15be0a['getImmediateChild'](_0x47bd8e):null,_0x4cbd2e=Vo(_0x6f1f62,_0x47bd8e),_0x506617=_0x1c5514['operationForChild'](_0x47bd8e);_0x506617&&(_0x2eb0d9=_0x2eb0d9['concat'](Zo(_0x506617,_0x314db1,_0x3b6c37,_0x4cbd2e)));}),_0x1284c4&&(_0x2eb0d9=_0x2eb0d9['concat'](os(_0x1284c4,_0x1c5514,_0x6f1f62,_0x15be0a))),_0x2eb0d9;}function ea(_0x13a50b,_0x2eb346){const _0x41b186=_0x2eb346['query'],_0x578def=Ut(_0x13a50b,_0x41b186);return{'hashFn':()=>(Du(_0x2eb346)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1945bf=>{if(_0x1945bf==='ok')return _0x578def?Yu(_0x13a50b,_0x41b186['_path'],_0x578def):Ku(_0x13a50b,_0x41b186['_path']);{const _0x5a604f=Kl(_0x1945bf,_0x41b186);return An(_0x13a50b,_0x41b186,null,_0x5a604f);}}};}function Ut(_0x30d8e7,_0x176105){const _0x14b1d1=Hn(_0x176105);return _0x30d8e7['queryToTagMap']['get'](_0x14b1d1);}function Hn(_0x55a5a9){return _0x55a5a9['_path']['toString']()+'$'+_0x55a5a9['_queryIdentifier'];}function cs(_0x4e3137,_0x4fdcf3){return _0x4e3137['tagToQueryMap']['get'](_0x4fdcf3);}function ls(_0xfce463){const _0x5454db=_0xfce463['indexOf']('$');return f(_0x5454db!==-0x1&&_0x5454db<_0xfce463['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xfce463['substr'](_0x5454db+0x1),'path':new C(_0xfce463['substr'](0x0,_0x5454db))};}function hs(_0x51b650,_0x44478b,_0x525207){const _0x491828=_0x51b650['syncPointTree_']['get'](_0x44478b);f(_0x491828,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x49dbb8=Wn(_0x51b650['pendingWriteTree_'],_0x44478b);return os(_0x491828,_0x525207,_0x49dbb8,null);}function Xu(_0x27184){return _0x27184['fold']((_0x10b257,_0x1252d8,_0x450092)=>{if(_0x1252d8&&Se(_0x1252d8))return[Bn(_0x1252d8)];{let _0x2fed72=[];return _0x1252d8&&(_0x2fed72=Ko(_0x1252d8)),x(_0x450092,(_0x532e17,_0x20ab21)=>{_0x2fed72=_0x2fed72['concat'](_0x20ab21);}),_0x2fed72;}});}function At(_0x305756){return _0x305756['_queryParams']['loadsAllData']()&&!_0x305756['_queryParams']['isDefault']()?new(Gu())(_0x305756['_repo'],_0x305756['_path']):_0x305756;}function Zu(_0x404fd9,_0x4eaf72){for(let _0x500be2=0x0;_0x500be2<_0x4eaf72['length'];++_0x500be2){const _0x303f3e=_0x4eaf72[_0x500be2];if(!_0x303f3e['_queryParams']['loadsAllData']()){const _0x119cfe=Hn(_0x303f3e),_0x34c88e=_0x404fd9['queryToTagMap']['get'](_0x119cfe);_0x404fd9['queryToTagMap']['delete'](_0x119cfe),_0x404fd9['tagToQueryMap']['delete'](_0x34c88e);}}}function ed(){return qu++;}function td(_0x349e7d,_0x337c90,_0x360627){const _0x550d6a=_0x337c90['_path'],_0x4dddca=Ut(_0x349e7d,_0x337c90),_0x223078=ea(_0x349e7d,_0x360627),_0x3c6661=_0x349e7d['listenProvider_']['startListening'](At(_0x337c90),_0x4dddca,_0x223078['hashFn'],_0x223078['onComplete']),_0x318763=_0x349e7d['syncPointTree_']['subtree'](_0x550d6a);if(_0x4dddca)f(!Se(_0x318763['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3d05de=_0x318763['fold']((_0x37cd31,_0x199265,_0xc056c8)=>{if(!v(_0x37cd31)&&_0x199265&&Se(_0x199265))return[Bn(_0x199265)['query']];{let _0x2620e6=[];return _0x199265&&(_0x2620e6=_0x2620e6['concat'](Ko(_0x199265)['map'](_0x2e5ee5=>_0x2e5ee5['query']))),x(_0xc056c8,(_0x59775b,_0x381a08)=>{_0x2620e6=_0x2620e6['concat'](_0x381a08);}),_0x2620e6;}});for(let _0x1704de=0x0;_0x1704de<_0x3d05de['length'];++_0x1704de){const _0x180148=_0x3d05de[_0x1704de];_0x349e7d['listenProvider_']['stopListening'](At(_0x180148),Ut(_0x349e7d,_0x180148));}}return _0x3c6661;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x299c6a){this['node_']=_0x299c6a;}['getImmediateChild'](_0x5b6081){const _0xaabced=this['node_']['getImmediateChild'](_0x5b6081);return new us(_0xaabced);}['node'](){return this['node_'];}}class ds{constructor(_0x4a49d6,_0x7e88a1){this['syncTree_']=_0x4a49d6,this['path_']=_0x7e88a1;}['getImmediateChild'](_0x22743e){const _0xb996ae=k(this['path_'],_0x22743e);return new ds(this['syncTree_'],_0xb996ae);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0x8b9234){return _0x8b9234=_0x8b9234||{},_0x8b9234['timestamp']=_0x8b9234['timestamp']||new Date()['getTime'](),_0x8b9234;},_r=function(_0x3af676,_0xe12e17,_0x3fe6f6){if(!_0x3af676||typeof _0x3af676!='object')return _0x3af676;if(f('.sv'in _0x3af676,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3af676['.sv']=='string')return id(_0x3af676['.sv'],_0xe12e17,_0x3fe6f6);if(typeof _0x3af676['.sv']=='object')return sd(_0x3af676['.sv'],_0xe12e17);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3af676,null,0x2));},id=function(_0x42de68,_0x549ed4,_0x28b5e8){switch(_0x42de68){case'timestamp':return _0x28b5e8['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x42de68);}},sd=function(_0x272508,_0x378bab,_0x21e211){_0x272508['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x272508,null,0x2));const _0x213d1a=_0x272508['increment'];typeof _0x213d1a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x213d1a);const _0xd781fc=_0x378bab['node']();if(f(_0xd781fc!==null&&typeof _0xd781fc<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xd781fc['isLeafNode']())return _0x213d1a;const _0x53d534=_0xd781fc['getValue']();return typeof _0x53d534!='number'?_0x213d1a:_0x53d534+_0x213d1a;},ta=function(_0x584847,_0x332757,_0x5a51dd,_0x51e435){return ps(_0x332757,new ds(_0x5a51dd,_0x584847),_0x51e435);},fs=function(_0x24d624,_0x4fcd1e,_0x204a9f){return ps(_0x24d624,new us(_0x4fcd1e),_0x204a9f);};function ps(_0x13331b,_0x1c2fcd,_0x1e687f){const _0x303a4f=_0x13331b['getPriority']()['val'](),_0x5a6ae6=_r(_0x303a4f,_0x1c2fcd['getImmediateChild']('.priority'),_0x1e687f);let _0x3d458c;if(_0x13331b['isLeafNode']()){const _0x2671b3=_0x13331b,_0x36d4fa=_r(_0x2671b3['getValue'](),_0x1c2fcd,_0x1e687f);return _0x36d4fa!==_0x2671b3['getValue']()||_0x5a6ae6!==_0x2671b3['getPriority']()['val']()?new D(_0x36d4fa,A(_0x5a6ae6)):_0x13331b;}else{const _0x11dd3e=_0x13331b;return _0x3d458c=_0x11dd3e,_0x5a6ae6!==_0x11dd3e['getPriority']()['val']()&&(_0x3d458c=_0x3d458c['updatePriority'](new D(_0x5a6ae6))),_0x11dd3e['forEachChild'](R,(_0x1ae19a,_0x352c66)=>{const _0x56ac19=ps(_0x352c66,_0x1c2fcd['getImmediateChild'](_0x1ae19a),_0x1e687f);_0x56ac19!==_0x352c66&&(_0x3d458c=_0x3d458c['updateImmediateChild'](_0x1ae19a,_0x56ac19));}),_0x3d458c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x57310b='',_0x3f711c=null,_0x802e27={'children':{},'childCount':0x0}){this['name']=_0x57310b,this['parent']=_0x3f711c,this['node']=_0x802e27;}}function $n(_0x18210f,_0x5827f0){let _0x3ddd20=_0x5827f0 instanceof C?_0x5827f0:new C(_0x5827f0),_0x316523=_0x18210f,_0x2563ac=y(_0x3ddd20);for(;_0x2563ac!==null;){const _0x23dc81=Me(_0x316523['node']['children'],_0x2563ac)||{'children':{},'childCount':0x0};_0x316523=new _s(_0x2563ac,_0x316523,_0x23dc81),_0x3ddd20=S(_0x3ddd20),_0x2563ac=y(_0x3ddd20);}return _0x316523;}function ze(_0x5f5a6b){return _0x5f5a6b['node']['value'];}function gs(_0x2aecb5,_0x46a083){_0x2aecb5['node']['value']=_0x46a083,Oi(_0x2aecb5);}function na(_0x552ff2){return _0x552ff2['node']['childCount']>0x0;}function rd(_0x3ca5d9){return ze(_0x3ca5d9)===void 0x0&&!na(_0x3ca5d9);}function Gn(_0x592bf3,_0x3d3395){x(_0x592bf3['node']['children'],(_0x4dba0f,_0xace126)=>{_0x3d3395(new _s(_0x4dba0f,_0x592bf3,_0xace126));});}function ia(_0x52184c,_0x5441b8,_0x17086c,_0x41c067){_0x17086c&&_0x5441b8(_0x52184c),Gn(_0x52184c,_0x1ffb71=>{ia(_0x1ffb71,_0x5441b8,!0x0);});}function od(_0x2b9b38,_0x2cb475,_0x3b16cd){let _0x321e5e=_0x2b9b38['parent'];for(;_0x321e5e!==null;){if(_0x2cb475(_0x321e5e))return!0x0;_0x321e5e=_0x321e5e['parent'];}return!0x1;}function Yt(_0xe219f6){return new C(_0xe219f6['parent']===null?_0xe219f6['name']:Yt(_0xe219f6['parent'])+'/'+_0xe219f6['name']);}function Oi(_0x443339){_0x443339['parent']!==null&&ad(_0x443339['parent'],_0x443339['name'],_0x443339);}function ad(_0x203114,_0x36e3aa,_0x2f3058){const _0x8f32d5=rd(_0x2f3058),_0xd7ee4a=Q(_0x203114['node']['children'],_0x36e3aa);_0x8f32d5&&_0xd7ee4a?(delete _0x203114['node']['children'][_0x36e3aa],_0x203114['node']['childCount']--,Oi(_0x203114)):!_0x8f32d5&&!_0xd7ee4a&&(_0x203114['node']['children'][_0x36e3aa]=_0x2f3058['node'],_0x203114['node']['childCount']++,Oi(_0x203114));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x45b308){return typeof _0x45b308=='string'&&_0x45b308['length']!==0x0&&!cd['test'](_0x45b308);},sa=function(_0x4ed1fe){return typeof _0x4ed1fe=='string'&&_0x4ed1fe['length']!==0x0&&!ld['test'](_0x4ed1fe);},hd=function(_0x3b0090){return _0x3b0090&&(_0x3b0090=_0x3b0090['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3b0090);},Wt=function(_0x3639e3){return _0x3639e3===null||typeof _0x3639e3=='string'||typeof _0x3639e3=='number'&&!xn(_0x3639e3)||_0x3639e3&&typeof _0x3639e3=='object'&&Q(_0x3639e3,'.sv');},Ve=function(_0x3b6592,_0x4d65a4,_0x3fd4bc,_0x9484fc){_0x9484fc&&_0x4d65a4===void 0x0||Qt(it(_0x3b6592,'value'),_0x4d65a4,_0x3fd4bc);},Qt=function(_0x4aa656,_0x301766,_0x50dc53){const _0x4bb829=_0x50dc53 instanceof C?new Ah(_0x50dc53,_0x4aa656):_0x50dc53;if(_0x301766===void 0x0)throw new Error(_0x4aa656+'contains\x20undefined\x20'+Pe(_0x4bb829));if(typeof _0x301766=='function')throw new Error(_0x4aa656+'contains\x20a\x20function\x20'+Pe(_0x4bb829)+'\x20with\x20contents\x20=\x20'+_0x301766['toString']());if(xn(_0x301766))throw new Error(_0x4aa656+'contains\x20'+_0x301766['toString']()+'\x20'+Pe(_0x4bb829));if(typeof _0x301766=='string'&&_0x301766['length']>ui/0x3&&Ln(_0x301766)>ui)throw new Error(_0x4aa656+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x4bb829)+'\x20(\x27'+_0x301766['substring'](0x0,0x32)+'...\x27)');if(_0x301766&&typeof _0x301766=='object'){let _0x28639f=!0x1,_0x50467b=!0x1;if(x(_0x301766,(_0x488560,_0x161c52)=>{if(_0x488560==='.value')_0x28639f=!0x0;else{if(_0x488560!=='.priority'&&_0x488560!=='.sv'&&(_0x50467b=!0x0,!ms(_0x488560)))throw new Error(_0x4aa656+'\x20contains\x20an\x20invalid\x20key\x20('+_0x488560+')\x20'+Pe(_0x4bb829)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x4bb829,_0x488560),Qt(_0x4aa656,_0x161c52,_0x4bb829),Nh(_0x4bb829);}),_0x28639f&&_0x50467b)throw new Error(_0x4aa656+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x4bb829)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0x6c0dcb,_0x1a6130){let _0x571029,_0x905038;for(_0x571029=0x0;_0x571029<_0x1a6130['length'];_0x571029++){_0x905038=_0x1a6130[_0x571029];const _0x18a7e1=Dt(_0x905038);for(let _0x2ad72f=0x0;_0x2ad72f<_0x18a7e1['length'];_0x2ad72f++)if(!(_0x18a7e1[_0x2ad72f]==='.priority'&&_0x2ad72f===_0x18a7e1['length']-0x1)){if(!ms(_0x18a7e1[_0x2ad72f]))throw new Error(_0x6c0dcb+'contains\x20an\x20invalid\x20key\x20('+_0x18a7e1[_0x2ad72f]+')\x20in\x20path\x20'+_0x905038['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1a6130['sort'](Rh);let _0x259f41=null;for(_0x571029=0x0;_0x571029<_0x1a6130['length'];_0x571029++){if(_0x905038=_0x1a6130[_0x571029],_0x259f41!==null&&G(_0x259f41,_0x905038))throw new Error(_0x6c0dcb+'contains\x20a\x20path\x20'+_0x259f41['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x905038['toString']());_0x259f41=_0x905038;}},ra=function(_0xe20283,_0x5731df,_0x513fd9,_0x4ee245){const _0x44ae60=it(_0xe20283,'values');if(!(_0x5731df&&typeof _0x5731df=='object')||Array['isArray'](_0x5731df))throw new Error(_0x44ae60+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4c0337=[];x(_0x5731df,(_0x3ed343,_0x7aea6b)=>{const _0x82568a=new C(_0x3ed343);if(Qt(_0x44ae60,_0x7aea6b,k(_0x513fd9,_0x82568a)),ji(_0x82568a)==='.priority'&&!Wt(_0x7aea6b))throw new Error(_0x44ae60+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x82568a['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4c0337['push'](_0x82568a);}),ud(_0x44ae60,_0x4c0337);},dd=function(_0x13fbde,_0x3c13cd,_0x2817f7){if(xn(_0x3c13cd))throw new Error(it(_0x13fbde,'priority')+'is\x20'+_0x3c13cd['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x3c13cd))throw new Error(it(_0x13fbde,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xaa8b98,_0x5d8d23,_0x171362,_0x660d1e){if(!sa(_0x171362))throw new Error(it(_0xaa8b98,_0x5d8d23)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x171362+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0x2510e8,_0xfbf61b,_0x15d628,_0x5e5937){_0x15d628&&(_0x15d628=_0x15d628['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x2510e8,_0xfbf61b,_0x15d628);},De=function(_0x288b7b,_0x1f8096){if(y(_0x1f8096)==='.info')throw new Error(_0x288b7b+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x40e591,_0x1c1537){const _0x6a2621=_0x1c1537['path']['toString']();if(typeof _0x1c1537['repoInfo']['host']!='string'||_0x1c1537['repoInfo']['host']['length']===0x0||!ms(_0x1c1537['repoInfo']['namespace'])&&_0x1c1537['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x6a2621['length']!==0x0&&!hd(_0x6a2621))throw new Error(it(_0x40e591,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x22b882,_0x3d9e73){let _0x128c13=null;for(let _0x4d148d=0x0;_0x4d148d<_0x3d9e73['length'];_0x4d148d++){const _0x5e9fed=_0x3d9e73[_0x4d148d],_0x18a8b5=_0x5e9fed['getPath']();_0x128c13!==null&&!Ki(_0x18a8b5,_0x128c13['path'])&&(_0x22b882['eventLists_']['push'](_0x128c13),_0x128c13=null),_0x128c13===null&&(_0x128c13={'events':[],'path':_0x18a8b5}),_0x128c13['events']['push'](_0x5e9fed);}_0x128c13&&_0x22b882['eventLists_']['push'](_0x128c13);}function oa(_0x21f4a2,_0x5bdf4b,_0x4e1afa){qn(_0x21f4a2,_0x4e1afa),aa(_0x21f4a2,_0x3f5901=>Ki(_0x3f5901,_0x5bdf4b));}function V(_0x2bf146,_0x5e47cd,_0x328de1){qn(_0x2bf146,_0x328de1),aa(_0x2bf146,_0x1f7660=>G(_0x1f7660,_0x5e47cd)||G(_0x5e47cd,_0x1f7660));}function aa(_0x43c601,_0x1a4c30){_0x43c601['recursionDepth_']++;let _0x32d4c5=!0x0;for(let _0x51731e=0x0;_0x51731e<_0x43c601['eventLists_']['length'];_0x51731e++){const _0x5e1bea=_0x43c601['eventLists_'][_0x51731e];if(_0x5e1bea){const _0x25df52=_0x5e1bea['path'];_0x1a4c30(_0x25df52)?(gd(_0x43c601['eventLists_'][_0x51731e]),_0x43c601['eventLists_'][_0x51731e]=null):_0x32d4c5=!0x1;}}_0x32d4c5&&(_0x43c601['eventLists_']=[]),_0x43c601['recursionDepth_']--;}function gd(_0x5c6f8f){for(let _0x3a41c2=0x0;_0x3a41c2<_0x5c6f8f['events']['length'];_0x3a41c2++){const _0x4e7399=_0x5c6f8f['events'][_0x3a41c2];if(_0x4e7399!==null){_0x5c6f8f['events'][_0x3a41c2]=null;const _0x3e9600=_0x4e7399['getEventRunner']();Tt&&L('event:\x20'+_0x4e7399['toString']()),ft(_0x3e9600);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x1ed147,_0x3fddd1,_0x57b352,_0x3e62c6){this['repoInfo_']=_0x1ed147,this['forceRestClient_']=_0x3fddd1,this['authTokenProvider_']=_0x57b352,this['appCheckProvider_']=_0x3e62c6,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0x25d2af,_0x34f83a,_0x22ab2f){if(_0x25d2af['stats_']=qi(_0x25d2af['repoInfo_']),_0x25d2af['forceRestClient_']||Xl())_0x25d2af['server_']=new vn(_0x25d2af['repoInfo_'],(_0x2b8694,_0x754870,_0x2d58f7,_0x542daf)=>{gr(_0x25d2af,_0x2b8694,_0x754870,_0x2d58f7,_0x542daf);},_0x25d2af['authTokenProvider_'],_0x25d2af['appCheckProvider_']),setTimeout(()=>mr(_0x25d2af,!0x0),0x0);else{if(typeof _0x22ab2f<'u'&&_0x22ab2f!==null){if(typeof _0x22ab2f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x22ab2f);}catch(_0x11d28f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x11d28f);}}_0x25d2af['persistentConnection_']=new se(_0x25d2af['repoInfo_'],_0x34f83a,(_0x200fe8,_0x2d1b50,_0x3689cc,_0x4fb963)=>{gr(_0x25d2af,_0x200fe8,_0x2d1b50,_0x3689cc,_0x4fb963);},_0x56a156=>{mr(_0x25d2af,_0x56a156);},_0x5ae67a=>{Ed(_0x25d2af,_0x5ae67a);},_0x25d2af['authTokenProvider_'],_0x25d2af['appCheckProvider_'],_0x22ab2f),_0x25d2af['server_']=_0x25d2af['persistentConnection_'];}_0x25d2af['authTokenProvider_']['addTokenChangeListener'](_0x370f67=>{_0x25d2af['server_']['refreshAuthToken'](_0x370f67);}),_0x25d2af['appCheckProvider_']['addTokenChangeListener'](_0x22f9f1=>{_0x25d2af['server_']['refreshAppCheckToken'](_0x22f9f1['token']);}),_0x25d2af['statsReporter_']=ih(_0x25d2af['repoInfo_'],()=>new nu(_0x25d2af['stats_'],_0x25d2af['server_'])),_0x25d2af['infoData_']=new Jh(),_0x25d2af['infoSyncTree_']=new pr({'startListening':(_0x368084,_0x2bcb5e,_0x4f65c9,_0x312d3d)=>{let _0x1d01c4=[];const _0x229a3f=_0x25d2af['infoData_']['getNode'](_0x368084['_path']);return _0x229a3f['isEmpty']()||(_0x1d01c4=Kt(_0x25d2af['infoSyncTree_'],_0x368084['_path'],_0x229a3f),setTimeout(()=>{_0x312d3d('ok');},0x0)),_0x1d01c4;},'stopListening':()=>{}}),vs(_0x25d2af,'connected',!0x1),_0x25d2af['serverSyncTree_']=new pr({'startListening':(_0x1c9620,_0x2bc63a,_0x152fd2,_0x32d2b1)=>(_0x25d2af['server_']['listen'](_0x1c9620,_0x152fd2,_0x2bc63a,(_0x2a9d4f,_0x1699d7)=>{const _0x39e136=_0x32d2b1(_0x2a9d4f,_0x1699d7);V(_0x25d2af['eventQueue_'],_0x1c9620['_path'],_0x39e136);}),[]),'stopListening':(_0x80b6f4,_0x1ce22b)=>{_0x25d2af['server_']['unlisten'](_0x80b6f4,_0x1ce22b);}});}function la(_0xb7dd3b){const _0x34895e=_0xb7dd3b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x34895e;}function Jt(_0x1811d7){return nd({'timestamp':la(_0x1811d7)});}function gr(_0x1edfdb,_0x2945a9,_0x10044b,_0x1d2a56,_0x10fd59){_0x1edfdb['dataUpdateCount']++;const _0x1773d1=new C(_0x2945a9);_0x10044b=_0x1edfdb['interceptServerDataCallback_']?_0x1edfdb['interceptServerDataCallback_'](_0x2945a9,_0x10044b):_0x10044b;let _0x367353=[];if(_0x10fd59){if(_0x1d2a56){const _0x2361ad=_n(_0x10044b,_0x3f5461=>A(_0x3f5461));_0x367353=Qu(_0x1edfdb['serverSyncTree_'],_0x1773d1,_0x2361ad,_0x10fd59);}else{const _0x3034b2=A(_0x10044b);_0x367353=Jo(_0x1edfdb['serverSyncTree_'],_0x1773d1,_0x3034b2,_0x10fd59);}}else{if(_0x1d2a56){const _0x5e07ce=_n(_0x10044b,_0xc1c30c=>A(_0xc1c30c));_0x367353=ju(_0x1edfdb['serverSyncTree_'],_0x1773d1,_0x5e07ce);}else{const _0x2f6978=A(_0x10044b);_0x367353=Kt(_0x1edfdb['serverSyncTree_'],_0x1773d1,_0x2f6978);}}let _0x21b964=_0x1773d1;_0x367353['length']>0x0&&(_0x21b964=ct(_0x1edfdb,_0x1773d1)),V(_0x1edfdb['eventQueue_'],_0x21b964,_0x367353);}function mr(_0x165ece,_0x4f97e8){vs(_0x165ece,'connected',_0x4f97e8),_0x4f97e8===!0x1&&Td(_0x165ece);}function Ed(_0x2643bb,_0x2ecb56){x(_0x2ecb56,(_0x5931f2,_0x582637)=>{vs(_0x2643bb,_0x5931f2,_0x582637);});}function vs(_0x180f1e,_0x36e7e0,_0x2942d5){const _0x332a04=new C('/.info/'+_0x36e7e0),_0x536317=A(_0x2942d5);_0x180f1e['infoData_']['updateSnapshot'](_0x332a04,_0x536317);const _0x1f5bd8=Kt(_0x180f1e['infoSyncTree_'],_0x332a04,_0x536317);V(_0x180f1e['eventQueue_'],_0x332a04,_0x1f5bd8);}function zn(_0x49a32d){return _0x49a32d['nextWriteId_']++;}function Id(_0x56b666,_0x37dc9e,_0x230796){const _0x4aac18=Ju(_0x56b666['serverSyncTree_'],_0x37dc9e);return _0x4aac18!=null?Promise['resolve'](_0x4aac18):_0x56b666['server_']['get'](_0x37dc9e)['then'](_0xc4844c=>{const _0x93910b=A(_0xc4844c)['withIndex'](_0x37dc9e['_queryParams']['getIndex']());Pi(_0x56b666['serverSyncTree_'],_0x37dc9e,_0x230796,!0x0);let _0x5423cd;if(_0x37dc9e['_queryParams']['loadsAllData']())_0x5423cd=Kt(_0x56b666['serverSyncTree_'],_0x37dc9e['_path'],_0x93910b);else{const _0x4f9409=Ut(_0x56b666['serverSyncTree_'],_0x37dc9e);_0x5423cd=Jo(_0x56b666['serverSyncTree_'],_0x37dc9e['_path'],_0x93910b,_0x4f9409);}return V(_0x56b666['eventQueue_'],_0x37dc9e['_path'],_0x5423cd),An(_0x56b666['serverSyncTree_'],_0x37dc9e,_0x230796,null,!0x0),_0x93910b;},_0xfbf54=>(gt(_0x56b666,'get\x20for\x20query\x20'+O(_0x37dc9e)+'\x20failed:\x20'+_0xfbf54),Promise['reject'](new Error(_0xfbf54))));}function wd(_0xeda422,_0x4c5017,_0x140dca,_0x2bcdb0,_0x2bb6ae){gt(_0xeda422,'set',{'path':_0x4c5017['toString'](),'value':_0x140dca,'priority':_0x2bcdb0});const _0x389680=Jt(_0xeda422),_0x1c103a=A(_0x140dca,_0x2bcdb0),_0x4f2acd=Vn(_0xeda422['serverSyncTree_'],_0x4c5017),_0x4f10c2=fs(_0x1c103a,_0x4f2acd,_0x389680),_0x321d54=zn(_0xeda422),_0x2befc4=as(_0xeda422['serverSyncTree_'],_0x4c5017,_0x4f10c2,_0x321d54,!0x0);qn(_0xeda422['eventQueue_'],_0x2befc4),_0xeda422['server_']['put'](_0x4c5017['toString'](),_0x1c103a['val'](!0x0),(_0x154cb0,_0x3b0d0a)=>{const _0x3886ec=_0x154cb0==='ok';_0x3886ec||U('set\x20at\x20'+_0x4c5017+'\x20failed:\x20'+_0x154cb0);const _0x5df0e9=_e(_0xeda422['serverSyncTree_'],_0x321d54,!_0x3886ec);V(_0xeda422['eventQueue_'],_0x4c5017,_0x5df0e9),be(_0xeda422,_0x2bb6ae,_0x154cb0,_0x3b0d0a);});const _0x51c18c=Is(_0xeda422,_0x4c5017);ct(_0xeda422,_0x51c18c),V(_0xeda422['eventQueue_'],_0x51c18c,[]);}function Cd(_0x1c864c,_0x537e4f,_0x12412e,_0x1670a7){gt(_0x1c864c,'update',{'path':_0x537e4f['toString'](),'value':_0x12412e});let _0x264e1a=!0x0;const _0x2c47e9=Jt(_0x1c864c),_0x4fe9a4={};if(x(_0x12412e,(_0x554f8e,_0x4c2748)=>{_0x264e1a=!0x1,_0x4fe9a4[_0x554f8e]=ta(k(_0x537e4f,_0x554f8e),A(_0x4c2748),_0x1c864c['serverSyncTree_'],_0x2c47e9);}),_0x264e1a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1c864c,_0x1670a7,'ok',void 0x0);else{const _0x2f1f14=zn(_0x1c864c),_0x40dcfb=zu(_0x1c864c['serverSyncTree_'],_0x537e4f,_0x4fe9a4,_0x2f1f14);qn(_0x1c864c['eventQueue_'],_0x40dcfb),_0x1c864c['server_']['merge'](_0x537e4f['toString'](),_0x12412e,(_0x58f8d6,_0x2446a7)=>{const _0x367f41=_0x58f8d6==='ok';_0x367f41||U('update\x20at\x20'+_0x537e4f+'\x20failed:\x20'+_0x58f8d6);const _0x38f41c=_e(_0x1c864c['serverSyncTree_'],_0x2f1f14,!_0x367f41),_0x53a4e9=_0x38f41c['length']>0x0?ct(_0x1c864c,_0x537e4f):_0x537e4f;V(_0x1c864c['eventQueue_'],_0x53a4e9,_0x38f41c),be(_0x1c864c,_0x1670a7,_0x58f8d6,_0x2446a7);}),x(_0x12412e,_0xe182b2=>{const _0xd69ee3=Is(_0x1c864c,k(_0x537e4f,_0xe182b2));ct(_0x1c864c,_0xd69ee3);}),V(_0x1c864c['eventQueue_'],_0x537e4f,[]);}}function Td(_0xdd8690){gt(_0xdd8690,'onDisconnectEvents');const _0x1c1c42=Jt(_0xdd8690),_0x4544d5=En();Si(_0xdd8690['onDisconnect_'],w(),(_0x55d6ee,_0x513706)=>{const _0x113a32=ta(_0x55d6ee,_0x513706,_0xdd8690['serverSyncTree_'],_0x1c1c42);pt(_0x4544d5,_0x55d6ee,_0x113a32);});let _0x557de0=[];Si(_0x4544d5,w(),(_0x4e6dd1,_0x22174c)=>{_0x557de0=_0x557de0['concat'](Kt(_0xdd8690['serverSyncTree_'],_0x4e6dd1,_0x22174c));const _0x5a99a3=Is(_0xdd8690,_0x4e6dd1);ct(_0xdd8690,_0x5a99a3);}),_0xdd8690['onDisconnect_']=En(),V(_0xdd8690['eventQueue_'],w(),_0x557de0);}function Sd(_0x229fe1,_0x5b1ac9,_0x60e4cc){_0x229fe1['server_']['onDisconnectCancel'](_0x5b1ac9['toString'](),(_0x2356cb,_0x1b2eeb)=>{_0x2356cb==='ok'&&Ti(_0x229fe1['onDisconnect_'],_0x5b1ac9),be(_0x229fe1,_0x60e4cc,_0x2356cb,_0x1b2eeb);});}function yr(_0x44af2c,_0x525fc2,_0x32de73,_0x3e9dee){const _0x52b1ed=A(_0x32de73);_0x44af2c['server_']['onDisconnectPut'](_0x525fc2['toString'](),_0x52b1ed['val'](!0x0),(_0x2a028a,_0x2ca07d)=>{_0x2a028a==='ok'&&pt(_0x44af2c['onDisconnect_'],_0x525fc2,_0x52b1ed),be(_0x44af2c,_0x3e9dee,_0x2a028a,_0x2ca07d);});}function bd(_0x1d556f,_0x1afce8,_0x123a95,_0x2c8a0c,_0x1783c7){const _0x596187=A(_0x123a95,_0x2c8a0c);_0x1d556f['server_']['onDisconnectPut'](_0x1afce8['toString'](),_0x596187['val'](!0x0),(_0x5c8b04,_0xdb7d46)=>{_0x5c8b04==='ok'&&pt(_0x1d556f['onDisconnect_'],_0x1afce8,_0x596187),be(_0x1d556f,_0x1783c7,_0x5c8b04,_0xdb7d46);});}function Rd(_0x20dae6,_0x41023e,_0x3c6917,_0x319079){if(pn(_0x3c6917)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x20dae6,_0x319079,'ok',void 0x0);return;}_0x20dae6['server_']['onDisconnectMerge'](_0x41023e['toString'](),_0x3c6917,(_0x3b4d80,_0x2c6cae)=>{_0x3b4d80==='ok'&&x(_0x3c6917,(_0x368ec3,_0x490f32)=>{const _0x5af454=A(_0x490f32);pt(_0x20dae6['onDisconnect_'],k(_0x41023e,_0x368ec3),_0x5af454);}),be(_0x20dae6,_0x319079,_0x3b4d80,_0x2c6cae);});}function Ad(_0x38d8a9,_0x371f7e,_0x494b81){let _0x901891;y(_0x371f7e['_path'])==='.info'?_0x901891=Pi(_0x38d8a9['infoSyncTree_'],_0x371f7e,_0x494b81):_0x901891=Pi(_0x38d8a9['serverSyncTree_'],_0x371f7e,_0x494b81),oa(_0x38d8a9['eventQueue_'],_0x371f7e['_path'],_0x901891);}function kd(_0x1e9031,_0x214bf2,_0x4a5971){let _0x44d95f;y(_0x214bf2['_path'])==='.info'?_0x44d95f=An(_0x1e9031['infoSyncTree_'],_0x214bf2,_0x4a5971):_0x44d95f=An(_0x1e9031['serverSyncTree_'],_0x214bf2,_0x4a5971),oa(_0x1e9031['eventQueue_'],_0x214bf2['_path'],_0x44d95f);}function ha(_0x30e3f9){_0x30e3f9['persistentConnection_']&&_0x30e3f9['persistentConnection_']['interrupt'](ca);}function Nd(_0x1fd25e){_0x1fd25e['persistentConnection_']&&_0x1fd25e['persistentConnection_']['resume'](ca);}function gt(_0x33b63a,..._0x3288b8){let _0x1de286='';_0x33b63a['persistentConnection_']&&(_0x1de286=_0x33b63a['persistentConnection_']['id']+':'),L(_0x1de286,..._0x3288b8);}function be(_0x3ca268,_0x587b44,_0x3f151b,_0x3a6681){_0x587b44&&ft(()=>{if(_0x3f151b==='ok')_0x587b44(null);else{const _0x438379=(_0x3f151b||'error')['toUpperCase']();let _0x2ae824=_0x438379;_0x3a6681&&(_0x2ae824+=':\x20'+_0x3a6681);const _0x347478=new Error(_0x2ae824);_0x347478['code']=_0x438379,_0x587b44(_0x347478);}});}function Pd(_0x128721,_0x31dac4,_0x1900d5,_0x248d5,_0x2277d9,_0x53aa25){gt(_0x128721,'transaction\x20on\x20'+_0x31dac4);const _0x2b3919={'path':_0x31dac4,'update':_0x1900d5,'onComplete':_0x248d5,'status':null,'order':so(),'applyLocally':_0x53aa25,'retryCount':0x0,'unwatcher':_0x2277d9,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x168297=Es(_0x128721,_0x31dac4,void 0x0);_0x2b3919['currentInputSnapshot']=_0x168297;const _0x47ff97=_0x2b3919['update'](_0x168297['val']());if(_0x47ff97===void 0x0)_0x2b3919['unwatcher'](),_0x2b3919['currentOutputSnapshotRaw']=null,_0x2b3919['currentOutputSnapshotResolved']=null,_0x2b3919['onComplete']&&_0x2b3919['onComplete'](null,!0x1,_0x2b3919['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x47ff97,_0x2b3919['path']),_0x2b3919['status']=0x0;const _0x22f1d3=$n(_0x128721['transactionQueueTree_'],_0x31dac4),_0x5f2a9e=ze(_0x22f1d3)||[];_0x5f2a9e['push'](_0x2b3919),gs(_0x22f1d3,_0x5f2a9e);let _0x4dc2ac;typeof _0x47ff97=='object'&&_0x47ff97!==null&&Q(_0x47ff97,'.priority')?(_0x4dc2ac=Me(_0x47ff97,'.priority'),f(Wt(_0x4dc2ac),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4dc2ac=(Vn(_0x128721['serverSyncTree_'],_0x31dac4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xc34933=Jt(_0x128721),_0x2084a7=A(_0x47ff97,_0x4dc2ac),_0x14f8e9=fs(_0x2084a7,_0x168297,_0xc34933);_0x2b3919['currentOutputSnapshotRaw']=_0x2084a7,_0x2b3919['currentOutputSnapshotResolved']=_0x14f8e9,_0x2b3919['currentWriteId']=zn(_0x128721);const _0x16df5b=as(_0x128721['serverSyncTree_'],_0x31dac4,_0x14f8e9,_0x2b3919['currentWriteId'],_0x2b3919['applyLocally']);V(_0x128721['eventQueue_'],_0x31dac4,_0x16df5b),jn(_0x128721,_0x128721['transactionQueueTree_']);}}function Es(_0x21dcf5,_0x44f1e6,_0x1e71c0){return Vn(_0x21dcf5['serverSyncTree_'],_0x44f1e6,_0x1e71c0)||g['EMPTY_NODE'];}function jn(_0x11edd7,_0x4274f4=_0x11edd7['transactionQueueTree_']){if(_0x4274f4||Kn(_0x11edd7,_0x4274f4),ze(_0x4274f4)){const _0x5ef8e6=da(_0x11edd7,_0x4274f4);f(_0x5ef8e6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5ef8e6['every'](_0x814166=>_0x814166['status']===0x0)&&Od(_0x11edd7,Yt(_0x4274f4),_0x5ef8e6);}else na(_0x4274f4)&&Gn(_0x4274f4,_0x1d15be=>{jn(_0x11edd7,_0x1d15be);});}function Od(_0x33b08e,_0x1190c8,_0x394d3a){const _0x2e19ab=_0x394d3a['map'](_0x1bdea1=>_0x1bdea1['currentWriteId']),_0x54082f=Es(_0x33b08e,_0x1190c8,_0x2e19ab);let _0x19d1ed=_0x54082f;const _0xff6109=_0x54082f['hash']();for(let _0x25e13a=0x0;_0x25e13a<_0x394d3a['length'];_0x25e13a++){const _0x4a0961=_0x394d3a[_0x25e13a];f(_0x4a0961['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4a0961['status']=0x1,_0x4a0961['retryCount']++;const _0x51ce95=F(_0x1190c8,_0x4a0961['path']);_0x19d1ed=_0x19d1ed['updateChild'](_0x51ce95,_0x4a0961['currentOutputSnapshotRaw']);}const _0x5d9098=_0x19d1ed['val'](!0x0),_0x1ccdaa=_0x1190c8;_0x33b08e['server_']['put'](_0x1ccdaa['toString'](),_0x5d9098,_0x4d113a=>{gt(_0x33b08e,'transaction\x20put\x20response',{'path':_0x1ccdaa['toString'](),'status':_0x4d113a});let _0x5c839b=[];if(_0x4d113a==='ok'){const _0x496c55=[];for(let _0x78c9fc=0x0;_0x78c9fc<_0x394d3a['length'];_0x78c9fc++)_0x394d3a[_0x78c9fc]['status']=0x2,_0x5c839b=_0x5c839b['concat'](_e(_0x33b08e['serverSyncTree_'],_0x394d3a[_0x78c9fc]['currentWriteId'])),_0x394d3a[_0x78c9fc]['onComplete']&&_0x496c55['push'](()=>_0x394d3a[_0x78c9fc]['onComplete'](null,!0x0,_0x394d3a[_0x78c9fc]['currentOutputSnapshotResolved'])),_0x394d3a[_0x78c9fc]['unwatcher']();Kn(_0x33b08e,$n(_0x33b08e['transactionQueueTree_'],_0x1190c8)),jn(_0x33b08e,_0x33b08e['transactionQueueTree_']),V(_0x33b08e['eventQueue_'],_0x1190c8,_0x5c839b);for(let _0x25cf1b=0x0;_0x25cf1b<_0x496c55['length'];_0x25cf1b++)ft(_0x496c55[_0x25cf1b]);}else{if(_0x4d113a==='datastale'){for(let _0x27768e=0x0;_0x27768e<_0x394d3a['length'];_0x27768e++)_0x394d3a[_0x27768e]['status']===0x3?_0x394d3a[_0x27768e]['status']=0x4:_0x394d3a[_0x27768e]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1ccdaa['toString']()+'\x20failed:\x20'+_0x4d113a);for(let _0x3c0d2c=0x0;_0x3c0d2c<_0x394d3a['length'];_0x3c0d2c++)_0x394d3a[_0x3c0d2c]['status']=0x4,_0x394d3a[_0x3c0d2c]['abortReason']=_0x4d113a;}ct(_0x33b08e,_0x1190c8);}},_0xff6109);}function ct(_0x42ac41,_0x14d0a4){const _0x5f4c9f=ua(_0x42ac41,_0x14d0a4),_0x1ec381=Yt(_0x5f4c9f),_0x3e0bc6=da(_0x42ac41,_0x5f4c9f);return Dd(_0x42ac41,_0x3e0bc6,_0x1ec381),_0x1ec381;}function Dd(_0x3133dc,_0x5ae452,_0x562502){if(_0x5ae452['length']===0x0)return;const _0xd53621=[];let _0x41b094=[];const _0x49b686=_0x5ae452['filter'](_0x332b8f=>_0x332b8f['status']===0x0)['map'](_0x18acd0=>_0x18acd0['currentWriteId']);for(let _0x8a537=0x0;_0x8a537<_0x5ae452['length'];_0x8a537++){const _0x4e01ec=_0x5ae452[_0x8a537],_0x466ecb=F(_0x562502,_0x4e01ec['path']);let _0x10e839=!0x1,_0x18b349;if(f(_0x466ecb!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4e01ec['status']===0x4)_0x10e839=!0x0,_0x18b349=_0x4e01ec['abortReason'],_0x41b094=_0x41b094['concat'](_e(_0x3133dc['serverSyncTree_'],_0x4e01ec['currentWriteId'],!0x0));else{if(_0x4e01ec['status']===0x0){if(_0x4e01ec['retryCount']>=md)_0x10e839=!0x0,_0x18b349='maxretry',_0x41b094=_0x41b094['concat'](_e(_0x3133dc['serverSyncTree_'],_0x4e01ec['currentWriteId'],!0x0));else{const _0x25c40e=Es(_0x3133dc,_0x4e01ec['path'],_0x49b686);_0x4e01ec['currentInputSnapshot']=_0x25c40e;const _0x3de33c=_0x5ae452[_0x8a537]['update'](_0x25c40e['val']());if(_0x3de33c!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x3de33c,_0x4e01ec['path']);let _0x11cb06=A(_0x3de33c);typeof _0x3de33c=='object'&&_0x3de33c!=null&&Q(_0x3de33c,'.priority')||(_0x11cb06=_0x11cb06['updatePriority'](_0x25c40e['getPriority']()));const _0x533008=_0x4e01ec['currentWriteId'],_0x2dfac9=Jt(_0x3133dc),_0x26b887=fs(_0x11cb06,_0x25c40e,_0x2dfac9);_0x4e01ec['currentOutputSnapshotRaw']=_0x11cb06,_0x4e01ec['currentOutputSnapshotResolved']=_0x26b887,_0x4e01ec['currentWriteId']=zn(_0x3133dc),_0x49b686['splice'](_0x49b686['indexOf'](_0x533008),0x1),_0x41b094=_0x41b094['concat'](as(_0x3133dc['serverSyncTree_'],_0x4e01ec['path'],_0x26b887,_0x4e01ec['currentWriteId'],_0x4e01ec['applyLocally'])),_0x41b094=_0x41b094['concat'](_e(_0x3133dc['serverSyncTree_'],_0x533008,!0x0));}else _0x10e839=!0x0,_0x18b349='nodata',_0x41b094=_0x41b094['concat'](_e(_0x3133dc['serverSyncTree_'],_0x4e01ec['currentWriteId'],!0x0));}}}V(_0x3133dc['eventQueue_'],_0x562502,_0x41b094),_0x41b094=[],_0x10e839&&(_0x5ae452[_0x8a537]['status']=0x2,function(_0x56d5cd){setTimeout(_0x56d5cd,Math['floor'](0x0));}(_0x5ae452[_0x8a537]['unwatcher']),_0x5ae452[_0x8a537]['onComplete']&&(_0x18b349==='nodata'?_0xd53621['push'](()=>_0x5ae452[_0x8a537]['onComplete'](null,!0x1,_0x5ae452[_0x8a537]['currentInputSnapshot'])):_0xd53621['push'](()=>_0x5ae452[_0x8a537]['onComplete'](new Error(_0x18b349),!0x1,null))));}Kn(_0x3133dc,_0x3133dc['transactionQueueTree_']);for(let _0x3e4ab9=0x0;_0x3e4ab9<_0xd53621['length'];_0x3e4ab9++)ft(_0xd53621[_0x3e4ab9]);jn(_0x3133dc,_0x3133dc['transactionQueueTree_']);}function ua(_0x2269a1,_0x3df118){let _0x4668f0,_0x1f3204=_0x2269a1['transactionQueueTree_'];for(_0x4668f0=y(_0x3df118);_0x4668f0!==null&&ze(_0x1f3204)===void 0x0;)_0x1f3204=$n(_0x1f3204,_0x4668f0),_0x3df118=S(_0x3df118),_0x4668f0=y(_0x3df118);return _0x1f3204;}function da(_0x5c1a5a,_0x550926){const _0x2e0204=[];return fa(_0x5c1a5a,_0x550926,_0x2e0204),_0x2e0204['sort']((_0x27133c,_0x4d68c1)=>_0x27133c['order']-_0x4d68c1['order']),_0x2e0204;}function fa(_0x278e2b,_0x58f184,_0x59df3f){const _0x1a76e6=ze(_0x58f184);if(_0x1a76e6){for(let _0x206e05=0x0;_0x206e05<_0x1a76e6['length'];_0x206e05++)_0x59df3f['push'](_0x1a76e6[_0x206e05]);}Gn(_0x58f184,_0x4861eb=>{fa(_0x278e2b,_0x4861eb,_0x59df3f);});}function Kn(_0x2d9e20,_0x5035ab){const _0x43a2e0=ze(_0x5035ab);if(_0x43a2e0){let _0x475abc=0x0;for(let _0x539c79=0x0;_0x539c79<_0x43a2e0['length'];_0x539c79++)_0x43a2e0[_0x539c79]['status']!==0x2&&(_0x43a2e0[_0x475abc]=_0x43a2e0[_0x539c79],_0x475abc++);_0x43a2e0['length']=_0x475abc,gs(_0x5035ab,_0x43a2e0['length']>0x0?_0x43a2e0:void 0x0);}Gn(_0x5035ab,_0x1f11ae=>{Kn(_0x2d9e20,_0x1f11ae);});}function Is(_0x5c7d67,_0x430724){const _0x4798a8=Yt(ua(_0x5c7d67,_0x430724)),_0x1fc3d5=$n(_0x5c7d67['transactionQueueTree_'],_0x430724);return od(_0x1fc3d5,_0x39256a=>{di(_0x5c7d67,_0x39256a);}),di(_0x5c7d67,_0x1fc3d5),ia(_0x1fc3d5,_0xbb01e0=>{di(_0x5c7d67,_0xbb01e0);}),_0x4798a8;}function di(_0x4debcf,_0x43a5b4){const _0x370f6b=ze(_0x43a5b4);if(_0x370f6b){const _0x26238e=[];let _0x588803=[],_0x13a9cd=-0x1;for(let _0x54f2a3=0x0;_0x54f2a3<_0x370f6b['length'];_0x54f2a3++)_0x370f6b[_0x54f2a3]['status']===0x3||(_0x370f6b[_0x54f2a3]['status']===0x1?(f(_0x13a9cd===_0x54f2a3-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x13a9cd=_0x54f2a3,_0x370f6b[_0x54f2a3]['status']=0x3,_0x370f6b[_0x54f2a3]['abortReason']='set'):(f(_0x370f6b[_0x54f2a3]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x370f6b[_0x54f2a3]['unwatcher'](),_0x588803=_0x588803['concat'](_e(_0x4debcf['serverSyncTree_'],_0x370f6b[_0x54f2a3]['currentWriteId'],!0x0)),_0x370f6b[_0x54f2a3]['onComplete']&&_0x26238e['push'](_0x370f6b[_0x54f2a3]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x13a9cd===-0x1?gs(_0x43a5b4,void 0x0):_0x370f6b['length']=_0x13a9cd+0x1,V(_0x4debcf['eventQueue_'],Yt(_0x43a5b4),_0x588803);for(let _0x2b69cb=0x0;_0x2b69cb<_0x26238e['length'];_0x2b69cb++)ft(_0x26238e[_0x2b69cb]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x6c7389){let _0x2d7be9='';const _0x173eb6=_0x6c7389['split']('/');for(let _0x5c38b2=0x0;_0x5c38b2<_0x173eb6['length'];_0x5c38b2++)if(_0x173eb6[_0x5c38b2]['length']>0x0){let _0x508523=_0x173eb6[_0x5c38b2];try{_0x508523=decodeURIComponent(_0x508523['replace'](/\+/g,'\x20'));}catch{}_0x2d7be9+='/'+_0x508523;}return _0x2d7be9;}function Ld(_0x5f757b){const _0x5a7c71={};_0x5f757b['charAt'](0x0)==='?'&&(_0x5f757b=_0x5f757b['substring'](0x1));for(const _0x56174a of _0x5f757b['split']('&')){if(_0x56174a['length']===0x0)continue;const _0x33f69c=_0x56174a['split']('=');_0x33f69c['length']===0x2?_0x5a7c71[decodeURIComponent(_0x33f69c[0x0])]=decodeURIComponent(_0x33f69c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x56174a+'\x27\x20in\x20query\x20\x27'+_0x5f757b+'\x27');}return _0x5a7c71;}const vr=function(_0x581cb,_0x573374){const _0x5c6d74=xd(_0x581cb),_0x192cfa=_0x5c6d74['namespace'];_0x5c6d74['domain']==='firebase.com'&&ae(_0x5c6d74['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x192cfa||_0x192cfa==='undefined')&&_0x5c6d74['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5c6d74['secure']||$l();const _0x5c3782=_0x5c6d74['scheme']==='ws'||_0x5c6d74['scheme']==='wss';return{'repoInfo':new yo(_0x5c6d74['host'],_0x5c6d74['secure'],_0x192cfa,_0x5c3782,_0x573374,'',_0x192cfa!==_0x5c6d74['subdomain']),'path':new C(_0x5c6d74['pathString'])};},xd=function(_0xb16f61){let _0x4f7612='',_0x360f8f='',_0x46a016='',_0x3bce3a='',_0x58c531='',_0x314e95=!0x0,_0x4cf67c='https',_0x5c1e9d=0x1bb;if(typeof _0xb16f61=='string'){let _0x2418aa=_0xb16f61['indexOf']('//');_0x2418aa>=0x0&&(_0x4cf67c=_0xb16f61['substring'](0x0,_0x2418aa-0x1),_0xb16f61=_0xb16f61['substring'](_0x2418aa+0x2));let _0x453577=_0xb16f61['indexOf']('/');_0x453577===-0x1&&(_0x453577=_0xb16f61['length']);let _0x3b4486=_0xb16f61['indexOf']('?');_0x3b4486===-0x1&&(_0x3b4486=_0xb16f61['length']),_0x4f7612=_0xb16f61['substring'](0x0,Math['min'](_0x453577,_0x3b4486)),_0x453577<_0x3b4486&&(_0x3bce3a=Md(_0xb16f61['substring'](_0x453577,_0x3b4486)));const _0x168bbb=Ld(_0xb16f61['substring'](Math['min'](_0xb16f61['length'],_0x3b4486)));_0x2418aa=_0x4f7612['indexOf'](':'),_0x2418aa>=0x0?(_0x314e95=_0x4cf67c==='https'||_0x4cf67c==='wss',_0x5c1e9d=parseInt(_0x4f7612['substring'](_0x2418aa+0x1),0xa)):_0x2418aa=_0x4f7612['length'];const _0x277512=_0x4f7612['slice'](0x0,_0x2418aa);if(_0x277512['toLowerCase']()==='localhost')_0x360f8f='localhost';else{if(_0x277512['split']('.')['length']<=0x2)_0x360f8f=_0x277512;else{const _0x5e1de9=_0x4f7612['indexOf']('.');_0x46a016=_0x4f7612['substring'](0x0,_0x5e1de9)['toLowerCase'](),_0x360f8f=_0x4f7612['substring'](_0x5e1de9+0x1),_0x58c531=_0x46a016;}}'ns'in _0x168bbb&&(_0x58c531=_0x168bbb['ns']);}return{'host':_0x4f7612,'port':_0x5c1e9d,'domain':_0x360f8f,'subdomain':_0x46a016,'secure':_0x314e95,'scheme':_0x4cf67c,'pathString':_0x3bce3a,'namespace':_0x58c531};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x3a4f9e=0x0;const _0xecdb9d=[];return function(_0xb86bbb){const _0x482280=_0xb86bbb===_0x3a4f9e;_0x3a4f9e=_0xb86bbb;let _0x21357e;const _0x47da58=new Array(0x8);for(_0x21357e=0x7;_0x21357e>=0x0;_0x21357e--)_0x47da58[_0x21357e]=Er['charAt'](_0xb86bbb%0x40),_0xb86bbb=Math['floor'](_0xb86bbb/0x40);f(_0xb86bbb===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2caa5d=_0x47da58['join']('');if(_0x482280){for(_0x21357e=0xb;_0x21357e>=0x0&&_0xecdb9d[_0x21357e]===0x3f;_0x21357e--)_0xecdb9d[_0x21357e]=0x0;_0xecdb9d[_0x21357e]++;}else{for(_0x21357e=0x0;_0x21357e<0xc;_0x21357e++)_0xecdb9d[_0x21357e]=Math['floor'](Math['random']()*0x40);}for(_0x21357e=0x0;_0x21357e<0xc;_0x21357e++)_0x2caa5d+=Er['charAt'](_0xecdb9d[_0x21357e]);return f(_0x2caa5d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2caa5d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0x5fa591,_0xa1fe13,_0x3bc5fe,_0x35055e){this['eventType']=_0x5fa591,this['eventRegistration']=_0xa1fe13,this['snapshot']=_0x3bc5fe,this['prevName']=_0x35055e;}['getPath'](){const _0x1fa255=this['snapshot']['ref'];return this['eventType']==='value'?_0x1fa255['_path']:_0x1fa255['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0x504a0b,_0x74dcfa,_0x446869){this['eventRegistration']=_0x504a0b,this['error']=_0x74dcfa,this['path']=_0x446869;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3664b2,_0xc7a372){this['snapshotCallback']=_0x3664b2,this['cancelCallback']=_0xc7a372;}['onValue'](_0x40f2b8,_0x4449ac){this['snapshotCallback']['call'](null,_0x40f2b8,_0x4449ac);}['onCancel'](_0x1526e2){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1526e2);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2536f5){return this['snapshotCallback']===_0x2536f5['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2536f5['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2536f5['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x1ba8a2,_0x5a856a){this['_repo']=_0x1ba8a2,this['_path']=_0x5a856a;}['cancel'](){const _0x5ca09a=new H();return Sd(this['_repo'],this['_path'],_0x5ca09a['wrapCallback'](()=>{})),_0x5ca09a['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x58180b=new H();return yr(this['_repo'],this['_path'],null,_0x58180b['wrapCallback'](()=>{})),_0x58180b['promise'];}['set'](_0x535032){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x535032,this['_path'],!0x1);const _0x13905d=new H();return yr(this['_repo'],this['_path'],_0x535032,_0x13905d['wrapCallback'](()=>{})),_0x13905d['promise'];}['setWithPriority'](_0x3c0627,_0x5ad1d5){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x3c0627,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x5ad1d5);const _0x3de135=new H();return bd(this['_repo'],this['_path'],_0x3c0627,_0x5ad1d5,_0x3de135['wrapCallback'](()=>{})),_0x3de135['promise'];}['update'](_0x8e04b5){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x8e04b5,this['_path']);const _0x2efd38=new H();return Rd(this['_repo'],this['_path'],_0x8e04b5,_0x2efd38['wrapCallback'](()=>{})),_0x2efd38['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x223163,_0x5af807,_0x284046,_0x323256){this['_repo']=_0x223163,this['_path']=_0x5af807,this['_queryParams']=_0x284046,this['_orderByCalled']=_0x323256;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1d73c6=sr(this['_queryParams']),_0x4e859d=$i(_0x1d73c6);return _0x4e859d==='{}'?'default':_0x4e859d;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x501470){if(_0x501470=N(_0x501470),!(_0x501470 instanceof je))return!0x1;const _0x15694b=this['_repo']===_0x501470['_repo'],_0x25e8ed=Ki(this['_path'],_0x501470['_path']),_0x4d3747=this['_queryIdentifier']===_0x501470['_queryIdentifier'];return _0x15694b&&_0x25e8ed&&_0x4d3747;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x2f5c8e,_0x39338a){if(_0x2f5c8e['_orderByCalled']===!0x0)throw new Error(_0x39338a+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x26213f){let _0x2e0961=null,_0xdc038e=null;if(_0x26213f['hasStart']()&&(_0x2e0961=_0x26213f['getIndexStartValue']()),_0x26213f['hasEnd']()&&(_0xdc038e=_0x26213f['getIndexEndValue']()),_0x26213f['getIndex']()===ve){const _0x10039f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xe94a2d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x26213f['hasStart']()){if(_0x26213f['getIndexStartName']()!==Ue)throw new Error(_0x10039f);if(typeof _0x2e0961!='string')throw new Error(_0xe94a2d);}if(_0x26213f['hasEnd']()){if(_0x26213f['getIndexEndName']()!==we)throw new Error(_0x10039f);if(typeof _0xdc038e!='string')throw new Error(_0xe94a2d);}}else{if(_0x26213f['getIndex']()===R){if(_0x2e0961!=null&&!Wt(_0x2e0961)||_0xdc038e!=null&&!Wt(_0xdc038e))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x26213f['getIndex']()instanceof Ji||_0x26213f['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2e0961!=null&&typeof _0x2e0961=='object'||_0xdc038e!=null&&typeof _0xdc038e=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x806935){if(_0x806935['hasStart']()&&_0x806935['hasEnd']()&&_0x806935['hasLimit']()&&!_0x806935['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0xb5c8f6,_0x1a18dd){super(_0xb5c8f6,_0x1a18dd,new Zi(),!0x1);}get['parent'](){const _0x20b0a4=Ro(this['_path']);return _0x20b0a4===null?null:new ee(this['_repo'],_0x20b0a4);}get['root'](){let _0x5de6fb=this;for(;_0x5de6fb['parent']!==null;)_0x5de6fb=_0x5de6fb['parent'];return _0x5de6fb;}}class lt{constructor(_0x5b0591,_0x5c25f2,_0x6e7094){this['_node']=_0x5b0591,this['ref']=_0x5c25f2,this['_index']=_0x6e7094;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x35c5e0){const _0x40456e=new C(_0x35c5e0),_0x56d657=Bt(this['ref'],_0x35c5e0);return new lt(this['_node']['getChild'](_0x40456e),_0x56d657,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4fc86c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3806f1,_0x2d9408)=>_0x4fc86c(new lt(_0x2d9408,Bt(this['ref'],_0x3806f1),R)));}['hasChild'](_0x16d293){const _0x5d375a=new C(_0x16d293);return!this['_node']['getChild'](_0x5d375a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x2b01a2,_0x422178){return _0x2b01a2=N(_0x2b01a2),_0x2b01a2['_checkNotDeleted']('ref'),_0x422178!==void 0x0?Bt(_0x2b01a2['_root'],_0x422178):_0x2b01a2['_root'];}function Bt(_0x32e229,_0x33baa9){return _0x32e229=N(_0x32e229),y(_0x32e229['_path'])===null?fd('child','path',_0x33baa9):ys('child','path',_0x33baa9),new ee(_0x32e229['_repo'],k(_0x32e229['_path'],_0x33baa9));}function m_(_0x1633cc){return _0x1633cc=N(_0x1633cc),new Bd(_0x1633cc['_repo'],_0x1633cc['_path']);}function y_(_0x57fc60,_0x3adf2a){_0x57fc60=N(_0x57fc60),De('push',_0x57fc60['_path']),Ve('push',_0x3adf2a,_0x57fc60['_path'],!0x0);const _0x3b2cd4=la(_0x57fc60['_repo']),_0x2755a5=Fd(_0x3b2cd4),_0x5c4a41=Bt(_0x57fc60,_0x2755a5),_0x11c06e=Bt(_0x57fc60,_0x2755a5);let _0x30851b;return _0x3adf2a!=null?_0x30851b=Vd(_0x11c06e,_0x3adf2a)['then'](()=>_0x11c06e):_0x30851b=Promise['resolve'](_0x11c06e),_0x5c4a41['then']=_0x30851b['then']['bind'](_0x30851b),_0x5c4a41['catch']=_0x30851b['then']['bind'](_0x30851b,void 0x0),_0x5c4a41;}function Vd(_0x15a904,_0x51b60a){_0x15a904=N(_0x15a904),De('set',_0x15a904['_path']),Ve('set',_0x51b60a,_0x15a904['_path'],!0x1);const _0x3d2092=new H();return wd(_0x15a904['_repo'],_0x15a904['_path'],_0x51b60a,null,_0x3d2092['wrapCallback'](()=>{})),_0x3d2092['promise'];}function v_(_0x3978eb,_0x12e3cc){ra('update',_0x12e3cc,_0x3978eb['_path']);const _0x5c5ae1=new H();return Cd(_0x3978eb['_repo'],_0x3978eb['_path'],_0x12e3cc,_0x5c5ae1['wrapCallback'](()=>{})),_0x5c5ae1['promise'];}function E_(_0xb8c067){_0xb8c067=N(_0xb8c067);const _0x1a8c21=new pa(()=>{}),_0x3a8e0d=new Qn(_0x1a8c21);return Id(_0xb8c067['_repo'],_0xb8c067,_0x3a8e0d)['then'](_0x591eec=>new lt(_0x591eec,new ee(_0xb8c067['_repo'],_0xb8c067['_path']),_0xb8c067['_queryParams']['getIndex']()));}class Qn{constructor(_0x1e7dc6){this['callbackContext']=_0x1e7dc6;}['respondsTo'](_0xec5fd8){return _0xec5fd8==='value';}['createEvent'](_0x1dc8ce,_0x46ee25){const _0x1c5559=_0x46ee25['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x1dc8ce['snapshotNode'],new ee(_0x46ee25['_repo'],_0x46ee25['_path']),_0x1c5559));}['getEventRunner'](_0x362329){return _0x362329['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x362329['error']):()=>this['callbackContext']['onValue'](_0x362329['snapshot'],null);}['createCancelEvent'](_0x2a500f,_0x563653){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x2a500f,_0x563653):null;}['matches'](_0xbcc8ea){return _0xbcc8ea instanceof Qn?!_0xbcc8ea['callbackContext']||!this['callbackContext']?!0x0:_0xbcc8ea['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x273a0a,_0x2b2794,_0x4b3ae3,_0x555f3e,_0x2d2936){const _0x2361f7=new pa(_0x4b3ae3,void 0x0),_0x56706d=new Qn(_0x2361f7);return Ad(_0x273a0a['_repo'],_0x273a0a,_0x56706d),()=>kd(_0x273a0a['_repo'],_0x273a0a,_0x56706d);}function $d(_0x5c0689,_0x175c26,_0x4ff0b3,_0x167395){return Hd(_0x5c0689,'value',_0x175c26);}class Xt{}class ma extends Xt{constructor(_0x3c73d6,_0x458900){super(),this['_value']=_0x3c73d6,this['_key']=_0x458900,this['type']='endAt';}['_apply'](_0x6ce237){Ve('endAt',this['_value'],_0x6ce237['_path'],!0x0);const _0x7130f6=Qh(_0x6ce237['_queryParams'],this['_value'],this['_key']);if(ga(_0x7130f6),Yn(_0x7130f6),_0x6ce237['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x6ce237['_repo'],_0x6ce237['_path'],_0x7130f6,_0x6ce237['_orderByCalled']);}}function I_(_0x1347e4,_0xebef3e){return new ma(_0x1347e4,_0xebef3e);}class ya extends Xt{constructor(_0x696dd1,_0x46bb5b){super(),this['_value']=_0x696dd1,this['_key']=_0x46bb5b,this['type']='startAt';}['_apply'](_0x22093e){Ve('startAt',this['_value'],_0x22093e['_path'],!0x0);const _0x4f02aa=Yh(_0x22093e['_queryParams'],this['_value'],this['_key']);if(ga(_0x4f02aa),Yn(_0x4f02aa),_0x22093e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x22093e['_repo'],_0x22093e['_path'],_0x4f02aa,_0x22093e['_orderByCalled']);}}function w_(_0x1a2549=null,_0x14c16a){return new ya(_0x1a2549,_0x14c16a);}class Gd extends Xt{constructor(_0x2cc143){super(),this['_path']=_0x2cc143,this['type']='orderByChild';}['_apply'](_0x42552f){_a(_0x42552f,'orderByChild');const _0xe2c98c=new C(this['_path']);if(v(_0xe2c98c))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x57d2ea=new Ji(_0xe2c98c),_0x493252=xo(_0x42552f['_queryParams'],_0x57d2ea);return Yn(_0x493252),new je(_0x42552f['_repo'],_0x42552f['_path'],_0x493252,!0x0);}}function C_(_0x5d6d14){if(_0x5d6d14==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5d6d14==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5d6d14==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5d6d14),new Gd(_0x5d6d14);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4517e3){_a(_0x4517e3,'orderByKey');const _0x167949=xo(_0x4517e3['_queryParams'],ve);return Yn(_0x167949),new je(_0x4517e3['_repo'],_0x4517e3['_path'],_0x167949,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0x5d0eae,_0x2d248b){super(),this['_value']=_0x5d0eae,this['_key']=_0x2d248b,this['type']='equalTo';}['_apply'](_0x42fb3c){if(Ve('equalTo',this['_value'],_0x42fb3c['_path'],!0x1),_0x42fb3c['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x42fb3c['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x42fb3c));}}function S_(_0x4da818,_0x532b77){return new zd(_0x4da818,_0x532b77);}function b_(_0x21d53d,..._0x57170f){let _0x5153d2=N(_0x21d53d);for(const _0x4ee98b of _0x57170f)_0x5153d2=_0x4ee98b['_apply'](_0x5153d2);return _0x5153d2;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x594d74,_0x5af46c,_0x4309f4,_0x1e26a7){const _0x2ebfa6=_0x5af46c['lastIndexOf'](':'),_0x1543e7=_0x5af46c['substring'](0x0,_0x2ebfa6),_0x12a5c0=Gt(_0x1543e7);_0x594d74['repoInfo_']=new yo(_0x5af46c,_0x12a5c0,_0x594d74['repoInfo_']['namespace'],_0x594d74['repoInfo_']['webSocketOnly'],_0x594d74['repoInfo_']['nodeAdmin'],_0x594d74['repoInfo_']['persistenceKey'],_0x594d74['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4309f4),_0x1e26a7&&(_0x594d74['authTokenProvider_']=_0x1e26a7);}function Qd(_0x33d32e,_0x367790,_0x1996f4,_0x17711d,_0x58d124){let _0x14eb2b=_0x17711d||_0x33d32e['options']['databaseURL'];_0x14eb2b===void 0x0&&(_0x33d32e['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x33d32e['options']['projectId']),_0x14eb2b=_0x33d32e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x22a8b6=vr(_0x14eb2b,_0x58d124),_0xb56588=_0x22a8b6['repoInfo'],_0x25c38e;typeof process<'u'&&Bs&&(_0x25c38e=Bs[jd]),_0x25c38e?(_0x14eb2b='http://'+_0x25c38e+'?ns='+_0xb56588['namespace'],_0x22a8b6=vr(_0x14eb2b,_0x58d124),_0xb56588=_0x22a8b6['repoInfo']):_0x22a8b6['repoInfo']['secure'];const _0x430fdc=new eh(_0x33d32e['name'],_0x33d32e['options'],_0x367790);pd('Invalid\x20Firebase\x20Database\x20URL',_0x22a8b6),v(_0x22a8b6['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1a77df=Xd(_0xb56588,_0x33d32e,_0x430fdc,new Zl(_0x33d32e,_0x1996f4));return new Zd(_0x1a77df,_0x33d32e);}function Jd(_0x170aae,_0x3f5634){const _0x1c0a91=Di[_0x3f5634];(!_0x1c0a91||_0x1c0a91[_0x170aae['key']]!==_0x170aae)&&ae('Database\x20'+_0x3f5634+'('+_0x170aae['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x170aae),delete _0x1c0a91[_0x170aae['key']];}function Xd(_0x2781e2,_0x4d6509,_0x2dab2f,_0x1455ed){let _0x423015=Di[_0x4d6509['name']];_0x423015||(_0x423015={},Di[_0x4d6509['name']]=_0x423015);let _0x1656d3=_0x423015[_0x2781e2['toURLString']()];return _0x1656d3&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1656d3=new yd(_0x2781e2,Kd,_0x2dab2f,_0x1455ed),_0x423015[_0x2781e2['toURLString']()]=_0x1656d3,_0x1656d3;}class Zd{constructor(_0x4c7a03,_0x16fc2f){this['_repoInternal']=_0x4c7a03,this['app']=_0x16fc2f,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x578058){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x578058+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0xba89da=Zr(),_0x1f07c9){const _0x86a118=Hi(_0xba89da,'database')['getImmediate']({'identifier':_0x1f07c9});if(!_0x86a118['_instanceStarted']){const _0x52b90d=hc('database');_0x52b90d&&ef(_0x86a118,..._0x52b90d);}return _0x86a118;}function ef(_0x242154,_0x18ee33,_0x531fda,_0x262f6f={}){_0x242154=N(_0x242154),_0x242154['_checkNotDeleted']('useEmulator');const _0x5de790=_0x18ee33+':'+_0x531fda,_0x185f16=_0x242154['_repoInternal'];if(_0x242154['_instanceStarted']){if(_0x5de790===_0x242154['_repoInternal']['repoInfo_']['host']&&Le(_0x262f6f,_0x185f16['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x25a26c;if(_0x185f16['repoInfo_']['nodeAdmin'])_0x262f6f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x25a26c=new an(an['OWNER']);else{if(_0x262f6f['mockUserToken']){const _0x1763f7=typeof _0x262f6f['mockUserToken']=='string'?_0x262f6f['mockUserToken']:uc(_0x262f6f['mockUserToken'],_0x242154['app']['options']['projectId']);_0x25a26c=new an(_0x1763f7);}}Gt(_0x18ee33)&&Qr(_0x18ee33),Yd(_0x185f16,_0x5de790,_0x262f6f,_0x25a26c);}function A_(_0x513c9d){_0x513c9d=N(_0x513c9d),_0x513c9d['_checkNotDeleted']('goOffline'),ha(_0x513c9d['_repo']);}function k_(_0x35c69c){_0x35c69c=N(_0x35c69c),_0x35c69c['_checkNotDeleted']('goOnline'),Nd(_0x35c69c['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0x211079){Ul(dt),st(new xe('database',(_0x3e7c2f,{instanceIdentifier:_0x20c175})=>{const _0x30db08=_0x3e7c2f['getProvider']('app')['getImmediate'](),_0x38f7cd=_0x3e7c2f['getProvider']('auth-internal'),_0x1a2fc6=_0x3e7c2f['getProvider']('app-check-internal');return Qd(_0x30db08,_0x38f7cd,_0x1a2fc6,_0x20c175);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x211079),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0x2b9365,_0x20a410){this['committed']=_0x2b9365,this['snapshot']=_0x20a410;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x397444,_0x5d8996,_0x124eb3){if(_0x397444=N(_0x397444),De('Reference.transaction',_0x397444['_path']),_0x397444['key']==='.length'||_0x397444['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x397444['key']+'\x20is\x20a\x20read-only\x20object.';const _0x54e48c=!0x0,_0x23b37f=new H(),_0x2f5faa=(_0x27458c,_0x236f84,_0x31d5c0)=>{let _0x561822=null;_0x27458c?_0x23b37f['reject'](_0x27458c):(_0x561822=new lt(_0x31d5c0,new ee(_0x397444['_repo'],_0x397444['_path']),R),_0x23b37f['resolve'](new sf(_0x236f84,_0x561822)));},_0x4a1952=$d(_0x397444,()=>{});return Pd(_0x397444['_repo'],_0x397444['_path'],_0x5d8996,_0x2f5faa,_0x4a1952,_0x54e48c),_0x23b37f['promise'];}se['prototype']['simpleListen']=function(_0x9cf379,_0x47d162){this['sendRequest']('q',{'p':_0x9cf379},_0x47d162);},se['prototype']['echo']=function(_0x54c66f,_0x18593c){this['sendRequest']('echo',{'d':_0x54c66f},_0x18593c);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0x3d2741,..._0xa0205c){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x3d2741,..._0xa0205c);}function cn(_0x4a9df0,..._0x38dd87){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x4a9df0,..._0x38dd87);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x27b03d,..._0x445b42){throw ws(_0x27b03d,..._0x445b42);}function X(_0xa6c20f,..._0x56b7d4){return ws(_0xa6c20f,..._0x56b7d4);}function Ia(_0x346ae2,_0x51ffac,_0x2ec6a9){const _0x335031={...rf(),[_0x51ffac]:_0x2ec6a9};return new $t('auth','Firebase',_0x335031)['create'](_0x51ffac,{'appName':_0x346ae2['name']});}function re(_0x588a88){return Ia(_0x588a88,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x541233,..._0x2d0ad6){if(typeof _0x541233!='string'){const _0x102833=_0x2d0ad6[0x0],_0x1d6500=[..._0x2d0ad6['slice'](0x1)];return _0x1d6500[0x0]&&(_0x1d6500[0x0]['appName']=_0x541233['name']),_0x541233['_errorFactory']['create'](_0x102833,..._0x1d6500);}return Ea['create'](_0x541233,..._0x2d0ad6);}function m(_0x5de5d3,_0x3f9479,..._0x4d79f1){if(!_0x5de5d3)throw ws(_0x3f9479,..._0x4d79f1);}function ne(_0x10c83d){const _0x39b3d4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x10c83d;throw cn(_0x39b3d4),new Error(_0x39b3d4);}function ce(_0x52f401,_0x487639){_0x52f401||ne(_0x487639);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3efcba;return typeof self<'u'&&((_0x3efcba=self['location'])==null?void 0x0:_0x3efcba['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3e12cf;return typeof self<'u'&&((_0x3e12cf=self['location'])==null?void 0x0:_0x3e12cf['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0x3fe1c3=navigator;return _0x3fe1c3['languages']&&_0x3fe1c3['languages'][0x0]||_0x3fe1c3['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2c302e,_0x346605){this['shortDelay']=_0x2c302e,this['longDelay']=_0x346605,ce(_0x346605>_0x2c302e,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x4ce9f9,_0x7ed00e){ce(_0x4ce9f9['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x55412d}=_0x4ce9f9['emulator'];return _0x7ed00e?''+_0x55412d+(_0x7ed00e['startsWith']('/')?_0x7ed00e['slice'](0x1):_0x7ed00e):_0x55412d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x54666c,_0x107ec9,_0xb4132d){this['fetchImpl']=_0x54666c,_0x107ec9&&(this['headersImpl']=_0x107ec9),_0xb4132d&&(this['responseImpl']=_0xb4132d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x1d2284,_0x225d96){return _0x1d2284['tenantId']&&!_0x225d96['tenantId']?{..._0x225d96,'tenantId':_0x1d2284['tenantId']}:_0x225d96;}async function ke(_0x415080,_0x456c97,_0x32ebf6,_0x568ff3,_0x5e6b95={}){return Ca(_0x415080,_0x5e6b95,async()=>{let _0x35ce24={},_0x16630d={};_0x568ff3&&(_0x456c97==='GET'?_0x16630d=_0x568ff3:_0x35ce24={'body':JSON['stringify'](_0x568ff3)});const _0x3a3466=ut({..._0x16630d,'key':_0x415080['config']['apiKey']})['slice'](0x1),_0x228f5b=await _0x415080['_getAdditionalHeaders']();_0x228f5b['Content-Type']='application/json',_0x415080['languageCode']&&(_0x228f5b['X-Firebase-Locale']=_0x415080['languageCode']);const _0xabb4b={'method':_0x456c97,'headers':_0x228f5b,..._0x35ce24};return dc()||(_0xabb4b['referrerPolicy']='strict-origin-when-cross-origin'),_0x415080['emulatorConfig']&&Gt(_0x415080['emulatorConfig']['host'])&&(_0xabb4b['credentials']='include'),wa['fetch']()(await Ta(_0x415080,_0x415080['config']['apiHost'],_0x32ebf6,_0x3a3466),_0xabb4b);});}async function Ca(_0x2ef560,_0x50bf70,_0x333933){_0x2ef560['_canInitEmulator']=!0x1;const _0x1cc724={...hf,..._0x50bf70};try{const _0x5e34e3=new pf(_0x2ef560),_0x2afca9=await Promise['race']([_0x333933(),_0x5e34e3['promise']]);_0x5e34e3['clearNetworkTimeout']();const _0x365918=await _0x2afca9['json']();if('needConfirmation'in _0x365918)throw on(_0x2ef560,'account-exists-with-different-credential',_0x365918);if(_0x2afca9['ok']&&!('errorMessage'in _0x365918))return _0x365918;{const _0x23b57c=_0x2afca9['ok']?_0x365918['errorMessage']:_0x365918['error']['message'],[_0x19022f,_0x384391]=_0x23b57c['split']('\x20:\x20');if(_0x19022f==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2ef560,'credential-already-in-use',_0x365918);if(_0x19022f==='EMAIL_EXISTS')throw on(_0x2ef560,'email-already-in-use',_0x365918);if(_0x19022f==='USER_DISABLED')throw on(_0x2ef560,'user-disabled',_0x365918);const _0x8837cd=_0x1cc724[_0x19022f]||_0x19022f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x384391)throw Ia(_0x2ef560,_0x8837cd,_0x384391);Y(_0x2ef560,_0x8837cd);}}catch(_0x17053e){if(_0x17053e instanceof Re)throw _0x17053e;Y(_0x2ef560,'network-request-failed',{'message':String(_0x17053e)});}}async function en(_0x1ce4f7,_0x343fd9,_0x3c627f,_0x570785,_0x2b3613={}){const _0x2fe4a9=await ke(_0x1ce4f7,_0x343fd9,_0x3c627f,_0x570785,_0x2b3613);return'mfaPendingCredential'in _0x2fe4a9&&Y(_0x1ce4f7,'multi-factor-auth-required',{'_serverResponse':_0x2fe4a9}),_0x2fe4a9;}async function Ta(_0x5769be,_0x1517c5,_0x29c953,_0x72ca7b){const _0x2a58a9=''+_0x1517c5+_0x29c953+'?'+_0x72ca7b,_0x2c4d74=_0x5769be,_0x115298=_0x2c4d74['config']['emulator']?Cs(_0x5769be['config'],_0x2a58a9):_0x5769be['config']['apiScheme']+'://'+_0x2a58a9;return uf['includes'](_0x29c953)&&(await _0x2c4d74['_persistenceManagerAvailable'],_0x2c4d74['_getPersistenceType']()==='COOKIE')?_0x2c4d74['_getPersistence']()['_getFinalTarget'](_0x115298)['toString']():_0x115298;}function ff(_0x40da13){switch(_0x40da13){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3237f9){this['auth']=_0x3237f9,this['timer']=null,this['promise']=new Promise((_0x171806,_0x1be44c)=>{this['timer']=setTimeout(()=>_0x1be44c(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x36c6cd,_0x10170d,_0x5811ea){const _0x355b20={'appName':_0x36c6cd['name']};_0x5811ea['email']&&(_0x355b20['email']=_0x5811ea['email']),_0x5811ea['phoneNumber']&&(_0x355b20['phoneNumber']=_0x5811ea['phoneNumber']);const _0x146926=X(_0x36c6cd,_0x10170d,_0x355b20);return _0x146926['customData']['_tokenResponse']=_0x5811ea,_0x146926;}function wr(_0x16f180){return _0x16f180!==void 0x0&&_0x16f180['enterprise']!==void 0x0;}class _f{constructor(_0x2e6d71){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2e6d71['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2e6d71['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2e6d71['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x17b8cd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xe5d916 of this['recaptchaEnforcementState'])if(_0xe5d916['provider']&&_0xe5d916['provider']===_0x17b8cd)return ff(_0xe5d916['enforcementState']);return null;}['isProviderEnabled'](_0x2ed941){return this['getProviderEnforcementState'](_0x2ed941)==='ENFORCE'||this['getProviderEnforcementState'](_0x2ed941)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0x3d25d6,_0x3fe7bd){return ke(_0x3d25d6,'GET','/v2/recaptchaConfig',Ae(_0x3d25d6,_0x3fe7bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x4aa7e6,_0x334c2a){return ke(_0x4aa7e6,'POST','/v1/accounts:delete',_0x334c2a);}async function Nn(_0x166410,_0x5313ef){return ke(_0x166410,'POST','/v1/accounts:lookup',_0x5313ef);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x36f776){if(_0x36f776)try{const _0xd961c1=new Date(Number(_0x36f776));if(!isNaN(_0xd961c1['getTime']()))return _0xd961c1['toUTCString']();}catch{}}async function yf(_0xc32f6,_0x324441=!0x1){const _0x4eb133=N(_0xc32f6),_0x3de8df=await _0x4eb133['getIdToken'](_0x324441),_0x53db27=Ts(_0x3de8df);m(_0x53db27&&_0x53db27['exp']&&_0x53db27['auth_time']&&_0x53db27['iat'],_0x4eb133['auth'],'internal-error');const _0x369664=typeof _0x53db27['firebase']=='object'?_0x53db27['firebase']:void 0x0,_0x51807f=_0x369664==null?void 0x0:_0x369664['sign_in_provider'];return{'claims':_0x53db27,'token':_0x3de8df,'authTime':kt(fi(_0x53db27['auth_time'])),'issuedAtTime':kt(fi(_0x53db27['iat'])),'expirationTime':kt(fi(_0x53db27['exp'])),'signInProvider':_0x51807f||null,'signInSecondFactor':(_0x369664==null?void 0x0:_0x369664['sign_in_second_factor'])||null};}function fi(_0x2be707){return Number(_0x2be707)*0x3e8;}function Ts(_0x60e6e0){const [_0x289d40,_0x5ec94e,_0x35f664]=_0x60e6e0['split']('.');if(_0x289d40===void 0x0||_0x5ec94e===void 0x0||_0x35f664===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x141a31=fn(_0x5ec94e);return _0x141a31?JSON['parse'](_0x141a31):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5139b5){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5139b5==null?void 0x0:_0x5139b5['toString']()),null;}}function Cr(_0x4ba920){const _0x45f77d=Ts(_0x4ba920);return m(_0x45f77d,'internal-error'),m(typeof _0x45f77d['exp']<'u','internal-error'),m(typeof _0x45f77d['iat']<'u','internal-error'),Number(_0x45f77d['exp'])-Number(_0x45f77d['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x425f32,_0x2b3a65,_0x5a0648=!0x1){if(_0x5a0648)return _0x2b3a65;try{return await _0x2b3a65;}catch(_0x1ad1c2){throw _0x1ad1c2 instanceof Re&&vf(_0x1ad1c2)&&_0x425f32['auth']['currentUser']===_0x425f32&&await _0x425f32['auth']['signOut'](),_0x1ad1c2;}}function vf({code:_0x5de877}){return _0x5de877==='auth/user-disabled'||_0x5de877==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0x4837f9){this['user']=_0x4837f9,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x28ece1){if(_0x28ece1){const _0x26d848=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x26d848;}else{this['errorBackoff']=0x7530;const _0x341beb=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x341beb);}}['schedule'](_0x454455=!0x1){if(!this['isRunning'])return;const _0x34c6ee=this['getInterval'](_0x454455);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x34c6ee);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x34d40c){(_0x34d40c==null?void 0x0:_0x34d40c['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0xba3ce4,_0x2153e5){this['createdAt']=_0xba3ce4,this['lastLoginAt']=_0x2153e5,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x28d6d5){this['createdAt']=_0x28d6d5['createdAt'],this['lastLoginAt']=_0x28d6d5['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0x38fa3e){var _0x29ec13;const _0x4c96d0=_0x38fa3e['auth'],_0x48aa06=await _0x38fa3e['getIdToken'](),_0x232711=await Vt(_0x38fa3e,Nn(_0x4c96d0,{'idToken':_0x48aa06}));m(_0x232711==null?void 0x0:_0x232711['users']['length'],_0x4c96d0,'internal-error');const _0x1d228f=_0x232711['users'][0x0];_0x38fa3e['_notifyReloadListener'](_0x1d228f);const _0x101388=(_0x29ec13=_0x1d228f['providerUserInfo'])!=null&&_0x29ec13['length']?Sa(_0x1d228f['providerUserInfo']):[],_0x25aae3=wf(_0x38fa3e['providerData'],_0x101388),_0x451e98=_0x38fa3e['isAnonymous'],_0x486bcf=!(_0x38fa3e['email']&&_0x1d228f['passwordHash'])&&!(_0x25aae3!=null&&_0x25aae3['length']),_0x2a157c=_0x451e98?_0x486bcf:!0x1,_0x3bb615={'uid':_0x1d228f['localId'],'displayName':_0x1d228f['displayName']||null,'photoURL':_0x1d228f['photoUrl']||null,'email':_0x1d228f['email']||null,'emailVerified':_0x1d228f['emailVerified']||!0x1,'phoneNumber':_0x1d228f['phoneNumber']||null,'tenantId':_0x1d228f['tenantId']||null,'providerData':_0x25aae3,'metadata':new Li(_0x1d228f['createdAt'],_0x1d228f['lastLoginAt']),'isAnonymous':_0x2a157c};Object['assign'](_0x38fa3e,_0x3bb615);}async function If(_0x4205a5){const _0x520761=N(_0x4205a5);await Pn(_0x520761),await _0x520761['auth']['_persistUserIfCurrent'](_0x520761),_0x520761['auth']['_notifyListenersIfCurrent'](_0x520761);}function wf(_0x33fd83,_0x2a9b5d){return[..._0x33fd83['filter'](_0x591cf7=>!_0x2a9b5d['some'](_0x5584df=>_0x5584df['providerId']===_0x591cf7['providerId'])),..._0x2a9b5d];}function Sa(_0x59a260){return _0x59a260['map'](({providerId:_0x182a00,..._0x158519})=>({'providerId':_0x182a00,'uid':_0x158519['rawId']||'','displayName':_0x158519['displayName']||null,'email':_0x158519['email']||null,'phoneNumber':_0x158519['phoneNumber']||null,'photoURL':_0x158519['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4f90c5,_0x169765){const _0x13af60=await Ca(_0x4f90c5,{},async()=>{const _0xa92f5f=ut({'grant_type':'refresh_token','refresh_token':_0x169765})['slice'](0x1),{tokenApiHost:_0xa50373,apiKey:_0x14e9c9}=_0x4f90c5['config'],_0x2eedce=await Ta(_0x4f90c5,_0xa50373,'/v1/token','key='+_0x14e9c9),_0x429016=await _0x4f90c5['_getAdditionalHeaders']();_0x429016['Content-Type']='application/x-www-form-urlencoded';const _0x269344={'method':'POST','headers':_0x429016,'body':_0xa92f5f};return _0x4f90c5['emulatorConfig']&&Gt(_0x4f90c5['emulatorConfig']['host'])&&(_0x269344['credentials']='include'),wa['fetch']()(_0x2eedce,_0x269344);});return{'accessToken':_0x13af60['access_token'],'expiresIn':_0x13af60['expires_in'],'refreshToken':_0x13af60['refresh_token']};}async function Tf(_0x47b9fb,_0x4523dd){return ke(_0x47b9fb,'POST','/v2/accounts:revokeToken',Ae(_0x47b9fb,_0x4523dd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1ff681){m(_0x1ff681['idToken'],'internal-error'),m(typeof _0x1ff681['idToken']<'u','internal-error'),m(typeof _0x1ff681['refreshToken']<'u','internal-error');const _0x3ba4c4='expiresIn'in _0x1ff681&&typeof _0x1ff681['expiresIn']<'u'?Number(_0x1ff681['expiresIn']):Cr(_0x1ff681['idToken']);this['updateTokensAndExpiration'](_0x1ff681['idToken'],_0x1ff681['refreshToken'],_0x3ba4c4);}['updateFromIdToken'](_0x2adb1c){m(_0x2adb1c['length']!==0x0,'internal-error');const _0x159f79=Cr(_0x2adb1c);this['updateTokensAndExpiration'](_0x2adb1c,null,_0x159f79);}async['getToken'](_0x3c023,_0x144824=!0x1){return!_0x144824&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3c023,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3c023,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1c1947,_0x975c0f){const {accessToken:_0x4852ce,refreshToken:_0x78d117,expiresIn:_0x52bf21}=await Cf(_0x1c1947,_0x975c0f);this['updateTokensAndExpiration'](_0x4852ce,_0x78d117,Number(_0x52bf21));}['updateTokensAndExpiration'](_0x154973,_0x7ebac1,_0x36d6c7){this['refreshToken']=_0x7ebac1||null,this['accessToken']=_0x154973||null,this['expirationTime']=Date['now']()+_0x36d6c7*0x3e8;}static['fromJSON'](_0x351b45,_0x3995f8){const {refreshToken:_0x26fe9b,accessToken:_0x311741,expirationTime:_0x4fd442}=_0x3995f8,_0x483293=new et();return _0x26fe9b&&(m(typeof _0x26fe9b=='string','internal-error',{'appName':_0x351b45}),_0x483293['refreshToken']=_0x26fe9b),_0x311741&&(m(typeof _0x311741=='string','internal-error',{'appName':_0x351b45}),_0x483293['accessToken']=_0x311741),_0x4fd442&&(m(typeof _0x4fd442=='number','internal-error',{'appName':_0x351b45}),_0x483293['expirationTime']=_0x4fd442),_0x483293;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x39a04e){this['accessToken']=_0x39a04e['accessToken'],this['refreshToken']=_0x39a04e['refreshToken'],this['expirationTime']=_0x39a04e['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x54370e,_0x5e46fc){m(typeof _0x54370e=='string'||typeof _0x54370e>'u','internal-error',{'appName':_0x5e46fc});}class j{constructor({uid:_0x4e2738,auth:_0x4af2fb,stsTokenManager:_0x347e4e,..._0x594efc}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4e2738,this['auth']=_0x4af2fb,this['stsTokenManager']=_0x347e4e,this['accessToken']=_0x347e4e['accessToken'],this['displayName']=_0x594efc['displayName']||null,this['email']=_0x594efc['email']||null,this['emailVerified']=_0x594efc['emailVerified']||!0x1,this['phoneNumber']=_0x594efc['phoneNumber']||null,this['photoURL']=_0x594efc['photoURL']||null,this['isAnonymous']=_0x594efc['isAnonymous']||!0x1,this['tenantId']=_0x594efc['tenantId']||null,this['providerData']=_0x594efc['providerData']?[..._0x594efc['providerData']]:[],this['metadata']=new Li(_0x594efc['createdAt']||void 0x0,_0x594efc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5baccc){const _0x3e82a9=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x5baccc));return m(_0x3e82a9,this['auth'],'internal-error'),this['accessToken']!==_0x3e82a9&&(this['accessToken']=_0x3e82a9,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3e82a9;}['getIdTokenResult'](_0x2db382){return yf(this,_0x2db382);}['reload'](){return If(this);}['_assign'](_0x4a2d22){this!==_0x4a2d22&&(m(this['uid']===_0x4a2d22['uid'],this['auth'],'internal-error'),this['displayName']=_0x4a2d22['displayName'],this['photoURL']=_0x4a2d22['photoURL'],this['email']=_0x4a2d22['email'],this['emailVerified']=_0x4a2d22['emailVerified'],this['phoneNumber']=_0x4a2d22['phoneNumber'],this['isAnonymous']=_0x4a2d22['isAnonymous'],this['tenantId']=_0x4a2d22['tenantId'],this['providerData']=_0x4a2d22['providerData']['map'](_0x52da01=>({..._0x52da01})),this['metadata']['_copy'](_0x4a2d22['metadata']),this['stsTokenManager']['_assign'](_0x4a2d22['stsTokenManager']));}['_clone'](_0x46df95){const _0x5520f1=new j({...this,'auth':_0x46df95,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5520f1['metadata']['_copy'](this['metadata']),_0x5520f1;}['_onReload'](_0x252917){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x252917,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x405767){this['reloadListener']?this['reloadListener'](_0x405767):this['reloadUserInfo']=_0x405767;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x567e20,_0x4794db=!0x1){let _0x1ad063=!0x1;_0x567e20['idToken']&&_0x567e20['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x567e20),_0x1ad063=!0x0),_0x4794db&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1ad063&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2b648a=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x2b648a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x490864=>({..._0x490864})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x253755,_0x540570){const _0x2a8345=_0x540570['displayName']??void 0x0,_0x4bad9a=_0x540570['email']??void 0x0,_0x56f8bf=_0x540570['phoneNumber']??void 0x0,_0x3b8e18=_0x540570['photoURL']??void 0x0,_0x3c2b39=_0x540570['tenantId']??void 0x0,_0x388759=_0x540570['_redirectEventId']??void 0x0,_0x4cf28b=_0x540570['createdAt']??void 0x0,_0x1c36a6=_0x540570['lastLoginAt']??void 0x0,{uid:_0x5b900d,emailVerified:_0x278b71,isAnonymous:_0x1959b1,providerData:_0x3677ff,stsTokenManager:_0x3b355e}=_0x540570;m(_0x5b900d&&_0x3b355e,_0x253755,'internal-error');const _0x499128=et['fromJSON'](this['name'],_0x3b355e);m(typeof _0x5b900d=='string',_0x253755,'internal-error'),le(_0x2a8345,_0x253755['name']),le(_0x4bad9a,_0x253755['name']),m(typeof _0x278b71=='boolean',_0x253755,'internal-error'),m(typeof _0x1959b1=='boolean',_0x253755,'internal-error'),le(_0x56f8bf,_0x253755['name']),le(_0x3b8e18,_0x253755['name']),le(_0x3c2b39,_0x253755['name']),le(_0x388759,_0x253755['name']),le(_0x4cf28b,_0x253755['name']),le(_0x1c36a6,_0x253755['name']);const _0x1a9c50=new j({'uid':_0x5b900d,'auth':_0x253755,'email':_0x4bad9a,'emailVerified':_0x278b71,'displayName':_0x2a8345,'isAnonymous':_0x1959b1,'photoURL':_0x3b8e18,'phoneNumber':_0x56f8bf,'tenantId':_0x3c2b39,'stsTokenManager':_0x499128,'createdAt':_0x4cf28b,'lastLoginAt':_0x1c36a6});return _0x3677ff&&Array['isArray'](_0x3677ff)&&(_0x1a9c50['providerData']=_0x3677ff['map'](_0x275cd4=>({..._0x275cd4}))),_0x388759&&(_0x1a9c50['_redirectEventId']=_0x388759),_0x1a9c50;}static async['_fromIdTokenResponse'](_0x96a988,_0x169d20,_0x41b884=!0x1){const _0xd4f394=new et();_0xd4f394['updateFromServerResponse'](_0x169d20);const _0x4d2c6d=new j({'uid':_0x169d20['localId'],'auth':_0x96a988,'stsTokenManager':_0xd4f394,'isAnonymous':_0x41b884});return await Pn(_0x4d2c6d),_0x4d2c6d;}static async['_fromGetAccountInfoResponse'](_0x106142,_0x3c37e2,_0x1660d2){const _0x33ed83=_0x3c37e2['users'][0x0];m(_0x33ed83['localId']!==void 0x0,'internal-error');const _0x2471ee=_0x33ed83['providerUserInfo']!==void 0x0?Sa(_0x33ed83['providerUserInfo']):[],_0x6bd219=!(_0x33ed83['email']&&_0x33ed83['passwordHash'])&&!(_0x2471ee!=null&&_0x2471ee['length']),_0x486c8c=new et();_0x486c8c['updateFromIdToken'](_0x1660d2);const _0x48b0f8=new j({'uid':_0x33ed83['localId'],'auth':_0x106142,'stsTokenManager':_0x486c8c,'isAnonymous':_0x6bd219}),_0x47f282={'uid':_0x33ed83['localId'],'displayName':_0x33ed83['displayName']||null,'photoURL':_0x33ed83['photoUrl']||null,'email':_0x33ed83['email']||null,'emailVerified':_0x33ed83['emailVerified']||!0x1,'phoneNumber':_0x33ed83['phoneNumber']||null,'tenantId':_0x33ed83['tenantId']||null,'providerData':_0x2471ee,'metadata':new Li(_0x33ed83['createdAt'],_0x33ed83['lastLoginAt']),'isAnonymous':!(_0x33ed83['email']&&_0x33ed83['passwordHash'])&&!(_0x2471ee!=null&&_0x2471ee['length'])};return Object['assign'](_0x48b0f8,_0x47f282),_0x48b0f8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3415b0){ce(_0x3415b0 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x602a15=Tr['get'](_0x3415b0);return _0x602a15?(ce(_0x602a15 instanceof _0x3415b0,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x602a15):(_0x602a15=new _0x3415b0(),Tr['set'](_0x3415b0,_0x602a15),_0x602a15);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x13a552,_0x8a3da4){this['storage'][_0x13a552]=_0x8a3da4;}async['_get'](_0x36909d){const _0x116104=this['storage'][_0x36909d];return _0x116104===void 0x0?null:_0x116104;}async['_remove'](_0x2b2275){delete this['storage'][_0x2b2275];}['_addListener'](_0x58f50a,_0x3a2584){}['_removeListener'](_0x4bc49d,_0x153e2b){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x290c7e,_0x576f2d,_0xc41610){return'firebase:'+_0x290c7e+':'+_0x576f2d+':'+_0xc41610;}class tt{constructor(_0x3f200a,_0x38e88c,_0x4b073d){this['persistence']=_0x3f200a,this['auth']=_0x38e88c,this['userKey']=_0x4b073d;const {config:_0x217af4,name:_0x7e6dff}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x217af4['apiKey'],_0x7e6dff),this['fullPersistenceKey']=ln('persistence',_0x217af4['apiKey'],_0x7e6dff),this['boundEventHandler']=_0x38e88c['_onStorageEvent']['bind'](_0x38e88c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x378fee){return this['persistence']['_set'](this['fullUserKey'],_0x378fee['toJSON']());}async['getCurrentUser'](){const _0x274199=await this['persistence']['_get'](this['fullUserKey']);if(!_0x274199)return null;if(typeof _0x274199=='string'){const _0x8aa97f=await Nn(this['auth'],{'idToken':_0x274199})['catch'](()=>{});return _0x8aa97f?j['_fromGetAccountInfoResponse'](this['auth'],_0x8aa97f,_0x274199):null;}return j['_fromJSON'](this['auth'],_0x274199);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x448299){if(this['persistence']===_0x448299)return;const _0x34316a=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x448299,_0x34316a)return this['setCurrentUser'](_0x34316a);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2790f4,_0x1566f1,_0x5c653c='authUser'){if(!_0x1566f1['length'])return new tt(ie(Sr),_0x2790f4,_0x5c653c);const _0x4cd78a=(await Promise['all'](_0x1566f1['map'](async _0x775965=>{if(await _0x775965['_isAvailable']())return _0x775965;})))['filter'](_0x47e1c5=>_0x47e1c5);let _0x338d03=_0x4cd78a[0x0]||ie(Sr);const _0x348e2a=ln(_0x5c653c,_0x2790f4['config']['apiKey'],_0x2790f4['name']);let _0x4b895b=null;for(const _0x20d48d of _0x1566f1)try{const _0x2dec31=await _0x20d48d['_get'](_0x348e2a);if(_0x2dec31){let _0x36b0a1;if(typeof _0x2dec31=='string'){const _0x5abf7b=await Nn(_0x2790f4,{'idToken':_0x2dec31})['catch'](()=>{});if(!_0x5abf7b)break;_0x36b0a1=await j['_fromGetAccountInfoResponse'](_0x2790f4,_0x5abf7b,_0x2dec31);}else _0x36b0a1=j['_fromJSON'](_0x2790f4,_0x2dec31);_0x20d48d!==_0x338d03&&(_0x4b895b=_0x36b0a1),_0x338d03=_0x20d48d;break;}}catch{}const _0x5b8969=_0x4cd78a['filter'](_0x24c5f2=>_0x24c5f2['_shouldAllowMigration']);return!_0x338d03['_shouldAllowMigration']||!_0x5b8969['length']?new tt(_0x338d03,_0x2790f4,_0x5c653c):(_0x338d03=_0x5b8969[0x0],_0x4b895b&&await _0x338d03['_set'](_0x348e2a,_0x4b895b['toJSON']()),await Promise['all'](_0x1566f1['map'](async _0x125f11=>{if(_0x125f11!==_0x338d03)try{await _0x125f11['_remove'](_0x348e2a);}catch{}})),new tt(_0x338d03,_0x2790f4,_0x5c653c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xa9535){const _0x5eb872=_0xa9535['toLowerCase']();if(_0x5eb872['includes']('opera/')||_0x5eb872['includes']('opr/')||_0x5eb872['includes']('opios/'))return'Opera';if(Na(_0x5eb872))return'IEMobile';if(_0x5eb872['includes']('msie')||_0x5eb872['includes']('trident/'))return'IE';if(_0x5eb872['includes']('edge/'))return'Edge';if(Ra(_0x5eb872))return'Firefox';if(_0x5eb872['includes']('silk/'))return'Silk';if(Oa(_0x5eb872))return'Blackberry';if(Da(_0x5eb872))return'Webos';if(Aa(_0x5eb872))return'Safari';if((_0x5eb872['includes']('chrome/')||ka(_0x5eb872))&&!_0x5eb872['includes']('edge/'))return'Chrome';if(Pa(_0x5eb872))return'Android';{const _0x2a0c73=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2345a3=_0xa9535['match'](_0x2a0c73);if((_0x2345a3==null?void 0x0:_0x2345a3['length'])===0x2)return _0x2345a3[0x1];}return'Other';}function Ra(_0x3f7b07=W()){return/firefox\//i['test'](_0x3f7b07);}function Aa(_0x15836e=W()){const _0x2a2368=_0x15836e['toLowerCase']();return _0x2a2368['includes']('safari/')&&!_0x2a2368['includes']('chrome/')&&!_0x2a2368['includes']('crios/')&&!_0x2a2368['includes']('android');}function ka(_0x5f2aa5=W()){return/crios\//i['test'](_0x5f2aa5);}function Na(_0x2228e4=W()){return/iemobile/i['test'](_0x2228e4);}function Pa(_0x4bc023=W()){return/android/i['test'](_0x4bc023);}function Oa(_0x1134bf=W()){return/blackberry/i['test'](_0x1134bf);}function Da(_0x1c58e9=W()){return/webos/i['test'](_0x1c58e9);}function Ss(_0x2b7526=W()){return/iphone|ipad|ipod/i['test'](_0x2b7526)||/macintosh/i['test'](_0x2b7526)&&/mobile/i['test'](_0x2b7526);}function Sf(_0x364bc1=W()){var _0x1d7ba8;return Ss(_0x364bc1)&&!!((_0x1d7ba8=window['navigator'])!=null&&_0x1d7ba8['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x10151c=W()){return Ss(_0x10151c)||Pa(_0x10151c)||Da(_0x10151c)||Oa(_0x10151c)||/windows phone/i['test'](_0x10151c)||Na(_0x10151c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5ed8f8,_0x57b914=[]){let _0x3e2bc3;switch(_0x5ed8f8){case'Browser':_0x3e2bc3=br(W());break;case'Worker':_0x3e2bc3=br(W())+'-'+_0x5ed8f8;break;default:_0x3e2bc3=_0x5ed8f8;}const _0x38b91b=_0x57b914['length']?_0x57b914['join'](','):'FirebaseCore-web';return _0x3e2bc3+'/JsCore/'+dt+'/'+_0x38b91b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x3f3968){this['auth']=_0x3f3968,this['queue']=[];}['pushCallback'](_0x38c660,_0x4f2996){const _0x43bcae=_0xd2b62d=>new Promise((_0x3e7fb8,_0x4545a9)=>{try{const _0x3a6add=_0x38c660(_0xd2b62d);_0x3e7fb8(_0x3a6add);}catch(_0x3e8ec2){_0x4545a9(_0x3e8ec2);}});_0x43bcae['onAbort']=_0x4f2996,this['queue']['push'](_0x43bcae);const _0x266d86=this['queue']['length']-0x1;return()=>{this['queue'][_0x266d86]=()=>Promise['resolve']();};}async['runMiddleware'](_0x155cb7){if(this['auth']['currentUser']===_0x155cb7)return;const _0x4b88d7=[];try{for(const _0x5afe79 of this['queue'])await _0x5afe79(_0x155cb7),_0x5afe79['onAbort']&&_0x4b88d7['push'](_0x5afe79['onAbort']);}catch(_0x40822a){_0x4b88d7['reverse']();for(const _0x4a6b3c of _0x4b88d7)try{_0x4a6b3c();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x40822a==null?void 0x0:_0x40822a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x1d1528,_0x4bb0d4={}){return ke(_0x1d1528,'GET','/v2/passwordPolicy',Ae(_0x1d1528,_0x4bb0d4));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x594b84){var _0xcc6b9b;const _0x4fc09e=_0x594b84['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4fc09e['minPasswordLength']??kf,_0x4fc09e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4fc09e['maxPasswordLength']),_0x4fc09e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4fc09e['containsLowercaseCharacter']),_0x4fc09e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4fc09e['containsUppercaseCharacter']),_0x4fc09e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4fc09e['containsNumericCharacter']),_0x4fc09e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4fc09e['containsNonAlphanumericCharacter']),this['enforcementState']=_0x594b84['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xcc6b9b=_0x594b84['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xcc6b9b['join'](''))??'',this['forceUpgradeOnSignin']=_0x594b84['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x594b84['schemaVersion'];}['validatePassword'](_0x1d4910){const _0x110ba2={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1d4910,_0x110ba2),this['validatePasswordCharacterOptions'](_0x1d4910,_0x110ba2),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['meetsMinPasswordLength']??!0x0),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['meetsMaxPasswordLength']??!0x0),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['containsLowercaseLetter']??!0x0),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['containsUppercaseLetter']??!0x0),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['containsNumericCharacter']??!0x0),_0x110ba2['isValid']&&(_0x110ba2['isValid']=_0x110ba2['containsNonAlphanumericCharacter']??!0x0),_0x110ba2;}['validatePasswordLengthOptions'](_0x46e4cd,_0x3867ac){const _0x2f999d=this['customStrengthOptions']['minPasswordLength'],_0x52c0d4=this['customStrengthOptions']['maxPasswordLength'];_0x2f999d&&(_0x3867ac['meetsMinPasswordLength']=_0x46e4cd['length']>=_0x2f999d),_0x52c0d4&&(_0x3867ac['meetsMaxPasswordLength']=_0x46e4cd['length']<=_0x52c0d4);}['validatePasswordCharacterOptions'](_0x413ca0,_0x117386){this['updatePasswordCharacterOptionsStatuses'](_0x117386,!0x1,!0x1,!0x1,!0x1);let _0x4efbbc;for(let _0x288a37=0x0;_0x288a37<_0x413ca0['length'];_0x288a37++)_0x4efbbc=_0x413ca0['charAt'](_0x288a37),this['updatePasswordCharacterOptionsStatuses'](_0x117386,_0x4efbbc>='a'&&_0x4efbbc<='z',_0x4efbbc>='A'&&_0x4efbbc<='Z',_0x4efbbc>='0'&&_0x4efbbc<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4efbbc));}['updatePasswordCharacterOptionsStatuses'](_0x189d5e,_0x10c160,_0x413922,_0x1d5bd9,_0x547bb5){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x189d5e['containsLowercaseLetter']||(_0x189d5e['containsLowercaseLetter']=_0x10c160)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x189d5e['containsUppercaseLetter']||(_0x189d5e['containsUppercaseLetter']=_0x413922)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x189d5e['containsNumericCharacter']||(_0x189d5e['containsNumericCharacter']=_0x1d5bd9)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x189d5e['containsNonAlphanumericCharacter']||(_0x189d5e['containsNonAlphanumericCharacter']=_0x547bb5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0x22eb72,_0x117cc4,_0x5de8fa,_0x4fb0b4){this['app']=_0x22eb72,this['heartbeatServiceProvider']=_0x117cc4,this['appCheckServiceProvider']=_0x5de8fa,this['config']=_0x4fb0b4,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x22eb72['name'],this['clientVersion']=_0x4fb0b4['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x38b0c=>this['_resolvePersistenceManagerAvailable']=_0x38b0c);}['_initializeWithPersistence'](_0x5a997d,_0x16991b){return _0x16991b&&(this['_popupRedirectResolver']=ie(_0x16991b)),this['_initializationPromise']=this['queue'](async()=>{var _0x16691d,_0x58bced,_0x40afda;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x5a997d),(_0x16691d=this['_resolvePersistenceManagerAvailable'])==null||_0x16691d['call'](this),!this['_deleted'])){if((_0x58bced=this['_popupRedirectResolver'])!=null&&_0x58bced['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x16991b),this['lastNotifiedUid']=((_0x40afda=this['currentUser'])==null?void 0x0:_0x40afda['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x325e2f=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x325e2f)){if(this['currentUser']&&_0x325e2f&&this['currentUser']['uid']===_0x325e2f['uid']){this['_currentUser']['_assign'](_0x325e2f),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x325e2f,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x112862){try{const _0x23a7a9=await Nn(this,{'idToken':_0x112862}),_0x589bc5=await j['_fromGetAccountInfoResponse'](this,_0x23a7a9,_0x112862);await this['directlySetCurrentUser'](_0x589bc5);}catch(_0x429e7b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x429e7b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x51693d){var _0xaa80b8;if($(this['app'])){const _0x4d33f2=this['app']['settings']['authIdToken'];return _0x4d33f2?new Promise(_0x21a9bb=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4d33f2)['then'](_0x21a9bb,_0x21a9bb));}):this['directlySetCurrentUser'](null);}const _0x3013f6=await this['assertedPersistence']['getCurrentUser']();let _0x5204bb=_0x3013f6,_0x5d06b0=!0x1;if(_0x51693d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2f1d81=(_0xaa80b8=this['redirectUser'])==null?void 0x0:_0xaa80b8['_redirectEventId'],_0x16812f=_0x5204bb==null?void 0x0:_0x5204bb['_redirectEventId'],_0x1ae12c=await this['tryRedirectSignIn'](_0x51693d);(!_0x2f1d81||_0x2f1d81===_0x16812f)&&(_0x1ae12c!=null&&_0x1ae12c['user'])&&(_0x5204bb=_0x1ae12c['user'],_0x5d06b0=!0x0);}if(!_0x5204bb)return this['directlySetCurrentUser'](null);if(!_0x5204bb['_redirectEventId']){if(_0x5d06b0)try{await this['beforeStateQueue']['runMiddleware'](_0x5204bb);}catch(_0x4d78a0){_0x5204bb=_0x3013f6,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4d78a0));}return _0x5204bb?this['reloadAndSetCurrentUserOrClear'](_0x5204bb):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5204bb['_redirectEventId']?this['directlySetCurrentUser'](_0x5204bb):this['reloadAndSetCurrentUserOrClear'](_0x5204bb);}async['tryRedirectSignIn'](_0x434056){let _0x30eb92=null;try{_0x30eb92=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x434056,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x30eb92;}async['reloadAndSetCurrentUserOrClear'](_0x4867ea){try{await Pn(_0x4867ea);}catch(_0x2165e5){if((_0x2165e5==null?void 0x0:_0x2165e5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4867ea);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x23dbeb){if($(this['app']))return Promise['reject'](re(this));const _0x35d7ea=_0x23dbeb?N(_0x23dbeb):null;return _0x35d7ea&&m(_0x35d7ea['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x35d7ea&&_0x35d7ea['_clone'](this));}async['_updateCurrentUser'](_0xa29237,_0x449c76=!0x1){if(!this['_deleted'])return _0xa29237&&m(this['tenantId']===_0xa29237['tenantId'],this,'tenant-id-mismatch'),_0x449c76||await this['beforeStateQueue']['runMiddleware'](_0xa29237),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xa29237),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xe79b2b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xe79b2b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x149c63){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x314bac=this['_getPasswordPolicyInternal']();return _0x314bac['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x314bac['validatePassword'](_0x149c63);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x33916d=await Af(this),_0xb59fb4=new Nf(_0x33916d);this['tenantId']===null?this['_projectPasswordPolicy']=_0xb59fb4:this['_tenantPasswordPolicies'][this['tenantId']]=_0xb59fb4;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xfd480f){this['_errorFactory']=new $t('auth','Firebase',_0xfd480f());}['onAuthStateChanged'](_0x47949e,_0x5590f2,_0x3a50bf){return this['registerStateListener'](this['authStateSubscription'],_0x47949e,_0x5590f2,_0x3a50bf);}['beforeAuthStateChanged'](_0x4a5bb9,_0x358926){return this['beforeStateQueue']['pushCallback'](_0x4a5bb9,_0x358926);}['onIdTokenChanged'](_0x12309a,_0x2481a4,_0x8a8c85){return this['registerStateListener'](this['idTokenSubscription'],_0x12309a,_0x2481a4,_0x8a8c85);}['authStateReady'](){return new Promise((_0x1da1e9,_0x490dba)=>{if(this['currentUser'])_0x1da1e9();else{const _0x1b4d91=this['onAuthStateChanged'](()=>{_0x1b4d91(),_0x1da1e9();},_0x490dba);}});}async['revokeAccessToken'](_0x81abc3){if(this['currentUser']){const _0x306529=await this['currentUser']['getIdToken'](),_0xb98169={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x81abc3,'idToken':_0x306529};this['tenantId']!=null&&(_0xb98169['tenantId']=this['tenantId']),await Tf(this,_0xb98169);}}['toJSON'](){var _0x10a77b;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x10a77b=this['_currentUser'])==null?void 0x0:_0x10a77b['toJSON']()};}async['_setRedirectUser'](_0x5c0d12,_0x11e5b3){const _0x144300=await this['getOrInitRedirectPersistenceManager'](_0x11e5b3);return _0x5c0d12===null?_0x144300['removeCurrentUser']():_0x144300['setCurrentUser'](_0x5c0d12);}async['getOrInitRedirectPersistenceManager'](_0x262830){if(!this['redirectPersistenceManager']){const _0x496872=_0x262830&&ie(_0x262830)||this['_popupRedirectResolver'];m(_0x496872,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x496872['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1ae921){var _0x33d216,_0x5de062;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x33d216=this['_currentUser'])==null?void 0x0:_0x33d216['_redirectEventId'])===_0x1ae921?this['_currentUser']:((_0x5de062=this['redirectUser'])==null?void 0x0:_0x5de062['_redirectEventId'])===_0x1ae921?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x585300){if(_0x585300===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x585300));}['_notifyListenersIfCurrent'](_0x1beb41){_0x1beb41===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1d3360;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2724ee=((_0x1d3360=this['currentUser'])==null?void 0x0:_0x1d3360['uid'])??null;this['lastNotifiedUid']!==_0x2724ee&&(this['lastNotifiedUid']=_0x2724ee,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xd0e84c,_0x459f04,_0xa0d91f,_0x37b9de){if(this['_deleted'])return()=>{};const _0x3d3bd2=typeof _0x459f04=='function'?_0x459f04:_0x459f04['next']['bind'](_0x459f04);let _0x560574=!0x1;const _0x8239cf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x8239cf,this,'internal-error'),_0x8239cf['then'](()=>{_0x560574||_0x3d3bd2(this['currentUser']);}),typeof _0x459f04=='function'){const _0x30971d=_0xd0e84c['addObserver'](_0x459f04,_0xa0d91f,_0x37b9de);return()=>{_0x560574=!0x0,_0x30971d();};}else{const _0x669651=_0xd0e84c['addObserver'](_0x459f04);return()=>{_0x560574=!0x0,_0x669651();};}}async['directlySetCurrentUser'](_0x1c5dd9){this['currentUser']&&this['currentUser']!==_0x1c5dd9&&this['_currentUser']['_stopProactiveRefresh'](),_0x1c5dd9&&this['isProactiveRefreshEnabled']&&_0x1c5dd9['_startProactiveRefresh'](),this['currentUser']=_0x1c5dd9,_0x1c5dd9?await this['assertedPersistence']['setCurrentUser'](_0x1c5dd9):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x240417){return this['operations']=this['operations']['then'](_0x240417,_0x240417),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4f5923){!_0x4f5923||this['frameworks']['includes'](_0x4f5923)||(this['frameworks']['push'](_0x4f5923),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x200826;const _0x1eb9de={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1eb9de['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x2847ef=await((_0x200826=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x200826['getHeartbeatsHeader']());_0x2847ef&&(_0x1eb9de['X-Firebase-Client']=_0x2847ef);const _0x44cf9d=await this['_getAppCheckToken']();return _0x44cf9d&&(_0x1eb9de['X-Firebase-AppCheck']=_0x44cf9d),_0x1eb9de;}async['_getAppCheckToken'](){var _0x315263;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1c06ba=await((_0x315263=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x315263['getToken']());return _0x1c06ba!=null&&_0x1c06ba['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1c06ba['error']),_0x1c06ba==null?void 0x0:_0x1c06ba['token'];}}function Ke(_0x48645f){return N(_0x48645f);}class Rr{constructor(_0x4f7cb8){this['auth']=_0x4f7cb8,this['observer']=null,this['addObserver']=Tc(_0x1933f3=>this['observer']=_0x1933f3);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x3030db){Jn=_0x3030db;}function xa(_0x145e5c){return Jn['loadJS'](_0x145e5c);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x1100aa){return'__'+_0x1100aa+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x21a1a1){_0x21a1a1();}['execute'](_0x32fe42,_0x21a2ff){return Promise['resolve']('token');}['render'](_0x325585,_0x9da4ce){return'';}}class Ff{['ready'](_0x2def6e){_0x2def6e();}['execute'](_0x2084b8,_0x337caf){return Promise['resolve']('token');}['render'](_0x396e02,_0x16487f){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x518d43){this['type']=Uf,this['auth']=Ke(_0x518d43);}async['verify'](_0xbe89c3='verify',_0x26a024=!0x1){async function _0x19e80a(_0xa70f26){if(!_0x26a024){if(_0xa70f26['tenantId']==null&&_0xa70f26['_agentRecaptchaConfig']!=null)return _0xa70f26['_agentRecaptchaConfig']['siteKey'];if(_0xa70f26['tenantId']!=null&&_0xa70f26['_tenantRecaptchaConfigs'][_0xa70f26['tenantId']]!==void 0x0)return _0xa70f26['_tenantRecaptchaConfigs'][_0xa70f26['tenantId']]['siteKey'];}return new Promise(async(_0x2473b6,_0x34e71a)=>{gf(_0xa70f26,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x486a14=>{if(_0x486a14['recaptchaKey']===void 0x0)_0x34e71a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xa4562d=new _f(_0x486a14);return _0xa70f26['tenantId']==null?_0xa70f26['_agentRecaptchaConfig']=_0xa4562d:_0xa70f26['_tenantRecaptchaConfigs'][_0xa70f26['tenantId']]=_0xa4562d,_0x2473b6(_0xa4562d['siteKey']);}})['catch'](_0x40db94=>{_0x34e71a(_0x40db94);});});}function _0x19c137(_0x3319d2,_0x3e583a,_0x925432){const _0x44c3fb=window['grecaptcha'];wr(_0x44c3fb)?_0x44c3fb['enterprise']['ready'](()=>{_0x44c3fb['enterprise']['execute'](_0x3319d2,{'action':_0xbe89c3})['then'](_0x2700ab=>{_0x3e583a(_0x2700ab);})['catch'](()=>{_0x3e583a(Fa);});}):_0x925432(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4140b7,_0x2d066b)=>{_0x19e80a(this['auth'])['then'](async _0x18f8c5=>{if(!_0x26a024&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x19c137(_0x18f8c5,_0x4140b7,_0x2d066b);else{if(typeof window>'u'){_0x2d066b(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x40a3bd=Df();_0x40a3bd['length']!==0x0&&(_0x40a3bd+=_0x18f8c5+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x17c57b;(_0x17c57b=he['scriptInjectionDeferred'])==null||_0x17c57b['resolve']();},xa(_0x40a3bd)['then'](()=>{var _0x36b8cb;return(_0x36b8cb=he['scriptInjectionDeferred'])==null?void 0x0:_0x36b8cb['promise'];})['then'](()=>{_0x19c137(_0x18f8c5,_0x4140b7,_0x2d066b);})['catch'](_0x49ab17=>{_0x2d066b(_0x49ab17);});}})['catch'](_0x115d4=>{_0x2d066b(_0x115d4);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x4c70b1,_0x57f586,_0x4dc39f,_0x29caa9=!0x1,_0x1c014b=!0x1){const _0x40c49e=new he(_0x4c70b1);let _0x3ce6ae;if(_0x1c014b)_0x3ce6ae=Fa;else try{_0x3ce6ae=await _0x40c49e['verify'](_0x4dc39f);}catch{_0x3ce6ae=await _0x40c49e['verify'](_0x4dc39f,!0x0);}const _0x22c9e6={..._0x57f586};if(_0x4dc39f==='mfaSmsEnrollment'||_0x4dc39f==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x22c9e6){const _0x467a7b=_0x22c9e6['phoneEnrollmentInfo']['phoneNumber'],_0x3867a4=_0x22c9e6['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x22c9e6,{'phoneEnrollmentInfo':{'phoneNumber':_0x467a7b,'recaptchaToken':_0x3867a4,'captchaResponse':_0x3ce6ae,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x22c9e6){const _0x2858d9=_0x22c9e6['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x22c9e6,{'phoneSignInInfo':{'recaptchaToken':_0x2858d9,'captchaResponse':_0x3ce6ae,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x22c9e6;}return _0x29caa9?Object['assign'](_0x22c9e6,{'captchaResp':_0x3ce6ae}):Object['assign'](_0x22c9e6,{'captchaResponse':_0x3ce6ae}),Object['assign'](_0x22c9e6,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x22c9e6,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x22c9e6;}async function xi(_0x298411,_0x5e3271,_0xf75d10,_0xd484c2,_0x144012){var _0x1a2c58;if((_0x1a2c58=_0x298411['_getRecaptchaConfig']())!=null&&_0x1a2c58['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x24bf38=await kr(_0x298411,_0x5e3271,_0xf75d10,_0xf75d10==='getOobCode');return _0xd484c2(_0x298411,_0x24bf38);}else return _0xd484c2(_0x298411,_0x5e3271)['catch'](async _0xe09c6f=>{if(_0xe09c6f['code']==='auth/missing-recaptcha-token'){console['log'](_0xf75d10+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xb4d0d4=await kr(_0x298411,_0x5e3271,_0xf75d10,_0xf75d10==='getOobCode');return _0xd484c2(_0x298411,_0xb4d0d4);}else return Promise['reject'](_0xe09c6f);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0x14d1d0,_0x3ebbc7){const _0x54beb9=Hi(_0x14d1d0,'auth');if(_0x54beb9['isInitialized']()){const _0x497dcf=_0x54beb9['getImmediate'](),_0x3d9b8e=_0x54beb9['getOptions']();if(Le(_0x3d9b8e,_0x3ebbc7??{}))return _0x497dcf;Y(_0x497dcf,'already-initialized');}return _0x54beb9['initialize']({'options':_0x3ebbc7});}function Bf(_0x1fdfac,_0x36c130){const _0x870957=(_0x36c130==null?void 0x0:_0x36c130['persistence'])||[],_0x4f4f74=(Array['isArray'](_0x870957)?_0x870957:[_0x870957])['map'](ie);_0x36c130!=null&&_0x36c130['errorMap']&&_0x1fdfac['_updateErrorMap'](_0x36c130['errorMap']),_0x1fdfac['_initializeWithPersistence'](_0x4f4f74,_0x36c130==null?void 0x0:_0x36c130['popupRedirectResolver']);}function Vf(_0x58fe7c,_0x3e8630,_0x414c8f){const _0x2ecbab=Ke(_0x58fe7c);m(/^https?:\/\//['test'](_0x3e8630),_0x2ecbab,'invalid-emulator-scheme');const _0x47bef7=!0x1,_0x42064d=Ua(_0x3e8630),{host:_0x256c7a,port:_0x4cc401}=Hf(_0x3e8630),_0x439c28=_0x4cc401===null?'':':'+_0x4cc401,_0x5433b0={'url':_0x42064d+'//'+_0x256c7a+_0x439c28+'/'},_0x492e2f=Object['freeze']({'host':_0x256c7a,'port':_0x4cc401,'protocol':_0x42064d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x47bef7})});if(!_0x2ecbab['_canInitEmulator']){m(_0x2ecbab['config']['emulator']&&_0x2ecbab['emulatorConfig'],_0x2ecbab,'emulator-config-failed'),m(Le(_0x5433b0,_0x2ecbab['config']['emulator'])&&Le(_0x492e2f,_0x2ecbab['emulatorConfig']),_0x2ecbab,'emulator-config-failed');return;}_0x2ecbab['config']['emulator']=_0x5433b0,_0x2ecbab['emulatorConfig']=_0x492e2f,_0x2ecbab['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x256c7a)?Qr(_0x42064d+'//'+_0x256c7a+_0x439c28):$f();}function Ua(_0x3c533d){const _0x4d87d7=_0x3c533d['indexOf'](':');return _0x4d87d7<0x0?'':_0x3c533d['substr'](0x0,_0x4d87d7+0x1);}function Hf(_0x191971){const _0x4ae040=Ua(_0x191971),_0x459964=/(\/\/)?([^?#/]+)/['exec'](_0x191971['substr'](_0x4ae040['length']));if(!_0x459964)return{'host':'','port':null};const _0x120328=_0x459964[0x2]['split']('@')['pop']()||'',_0x507203=/^(\[[^\]]+\])(:|$)/['exec'](_0x120328);if(_0x507203){const _0x242991=_0x507203[0x1];return{'host':_0x242991,'port':Nr(_0x120328['substr'](_0x242991['length']+0x1))};}else{const [_0x126de7,_0x4825e4]=_0x120328['split'](':');return{'host':_0x126de7,'port':Nr(_0x4825e4)};}}function Nr(_0x5540d0){if(!_0x5540d0)return null;const _0x17b0fd=Number(_0x5540d0);return isNaN(_0x17b0fd)?null:_0x17b0fd;}function $f(){function _0x2b07b1(){const _0x3070a1=document['createElement']('p'),_0x339f31=_0x3070a1['style'];_0x3070a1['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x339f31['position']='fixed',_0x339f31['width']='100%',_0x339f31['backgroundColor']='#ffffff',_0x339f31['border']='.1em\x20solid\x20#000000',_0x339f31['color']='#b50000',_0x339f31['bottom']='0px',_0x339f31['left']='0px',_0x339f31['margin']='0px',_0x339f31['zIndex']='10000',_0x339f31['textAlign']='center',_0x3070a1['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3070a1);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2b07b1):_0x2b07b1());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5eee4d,_0x199124){this['providerId']=_0x5eee4d,this['signInMethod']=_0x199124;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4867ac){return ne('not\x20implemented');}['_linkToIdToken'](_0x28b53b,_0x26ab7e){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x229a46){return ne('not\x20implemented');}}async function Gf(_0x1e2db4,_0x46a40c){return ke(_0x1e2db4,'POST','/v1/accounts:signUp',_0x46a40c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x334170,_0x37ad29){return en(_0x334170,'POST','/v1/accounts:signInWithPassword',Ae(_0x334170,_0x37ad29));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x1b81f9,_0x59fdd0){return en(_0x1b81f9,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x1b81f9,_0x59fdd0));}async function jf(_0xa43fa2,_0x1acb1b){return en(_0xa43fa2,'POST','/v1/accounts:signInWithEmailLink',Ae(_0xa43fa2,_0x1acb1b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x1acbc9,_0x351864,_0x91580c,_0x20f112=null){super('password',_0x91580c),this['_email']=_0x1acbc9,this['_password']=_0x351864,this['_tenantId']=_0x20f112;}static['_fromEmailAndPassword'](_0x20b518,_0x9c9ff9){return new Ht(_0x20b518,_0x9c9ff9,'password');}static['_fromEmailAndCode'](_0x2c99e8,_0x3e70be,_0x1cb19a=null){return new Ht(_0x2c99e8,_0x3e70be,'emailLink',_0x1cb19a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3b01bf){const _0x1a8b67=typeof _0x3b01bf=='string'?JSON['parse'](_0x3b01bf):_0x3b01bf;if(_0x1a8b67!=null&&_0x1a8b67['email']&&(_0x1a8b67!=null&&_0x1a8b67['password'])){if(_0x1a8b67['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1a8b67['email'],_0x1a8b67['password']);if(_0x1a8b67['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1a8b67['email'],_0x1a8b67['password'],_0x1a8b67['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1d0361){switch(this['signInMethod']){case'password':const _0x40aa79={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1d0361,_0x40aa79,'signInWithPassword',qf);case'emailLink':return zf(_0x1d0361,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1d0361,'internal-error');}}async['_linkToIdToken'](_0x2366fe,_0x598478){switch(this['signInMethod']){case'password':const _0x166ae5={'idToken':_0x598478,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2366fe,_0x166ae5,'signUpPassword',Gf);case'emailLink':return jf(_0x2366fe,{'idToken':_0x598478,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2366fe,'internal-error');}}['_getReauthenticationResolver'](_0x1aa7bc){return this['_getIdTokenResponse'](_0x1aa7bc);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x5de814,_0x395dff){return en(_0x5de814,'POST','/v1/accounts:signInWithIdp',Ae(_0x5de814,_0x395dff));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x588e86){const _0x3fc1b9=new He(_0x588e86['providerId'],_0x588e86['signInMethod']);return _0x588e86['idToken']||_0x588e86['accessToken']?(_0x588e86['idToken']&&(_0x3fc1b9['idToken']=_0x588e86['idToken']),_0x588e86['accessToken']&&(_0x3fc1b9['accessToken']=_0x588e86['accessToken']),_0x588e86['nonce']&&!_0x588e86['pendingToken']&&(_0x3fc1b9['nonce']=_0x588e86['nonce']),_0x588e86['pendingToken']&&(_0x3fc1b9['pendingToken']=_0x588e86['pendingToken'])):_0x588e86['oauthToken']&&_0x588e86['oauthTokenSecret']?(_0x3fc1b9['accessToken']=_0x588e86['oauthToken'],_0x3fc1b9['secret']=_0x588e86['oauthTokenSecret']):Y('argument-error'),_0x3fc1b9;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1e65e8){const _0x1a33b0=typeof _0x1e65e8=='string'?JSON['parse'](_0x1e65e8):_0x1e65e8,{providerId:_0xfa9625,signInMethod:_0xc15ad6,..._0x2334d0}=_0x1a33b0;if(!_0xfa9625||!_0xc15ad6)return null;const _0xeea2b1=new He(_0xfa9625,_0xc15ad6);return _0xeea2b1['idToken']=_0x2334d0['idToken']||void 0x0,_0xeea2b1['accessToken']=_0x2334d0['accessToken']||void 0x0,_0xeea2b1['secret']=_0x2334d0['secret'],_0xeea2b1['nonce']=_0x2334d0['nonce'],_0xeea2b1['pendingToken']=_0x2334d0['pendingToken']||null,_0xeea2b1;}['_getIdTokenResponse'](_0x430ba8){const _0x588370=this['buildRequest']();return nt(_0x430ba8,_0x588370);}['_linkToIdToken'](_0x2e3319,_0x30cbf1){const _0x2181e3=this['buildRequest']();return _0x2181e3['idToken']=_0x30cbf1,nt(_0x2e3319,_0x2181e3);}['_getReauthenticationResolver'](_0x433b50){const _0x3c6429=this['buildRequest']();return _0x3c6429['autoCreate']=!0x1,nt(_0x433b50,_0x3c6429);}['buildRequest'](){const _0x490fae={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x490fae['pendingToken']=this['pendingToken'];else{const _0x1012b5={};this['idToken']&&(_0x1012b5['id_token']=this['idToken']),this['accessToken']&&(_0x1012b5['access_token']=this['accessToken']),this['secret']&&(_0x1012b5['oauth_token_secret']=this['secret']),_0x1012b5['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1012b5['nonce']=this['nonce']),_0x490fae['postBody']=ut(_0x1012b5);}return _0x490fae;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0x1ca01a){switch(_0x1ca01a){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x45b765){const _0x2d7375=wt(Ct(_0x45b765))['link'],_0x5ceb69=_0x2d7375?wt(Ct(_0x2d7375))['deep_link_id']:null,_0x28c8ca=wt(Ct(_0x45b765))['deep_link_id'];return(_0x28c8ca?wt(Ct(_0x28c8ca))['link']:null)||_0x28c8ca||_0x5ceb69||_0x2d7375||_0x45b765;}class Rs{constructor(_0x528817){const _0x1903bc=wt(Ct(_0x528817)),_0x4d3ea1=_0x1903bc['apiKey']??null,_0x5ad6c3=_0x1903bc['oobCode']??null,_0x397e49=Yf(_0x1903bc['mode']??null);m(_0x4d3ea1&&_0x5ad6c3&&_0x397e49,'argument-error'),this['apiKey']=_0x4d3ea1,this['operation']=_0x397e49,this['code']=_0x5ad6c3,this['continueUrl']=_0x1903bc['continueUrl']??null,this['languageCode']=_0x1903bc['lang']??null,this['tenantId']=_0x1903bc['tenantId']??null;}static['parseLink'](_0x41b842){const _0x5aa4dd=Qf(_0x41b842);try{return new Rs(_0x5aa4dd);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0xc68346,_0x16df8c){return Ht['_fromEmailAndPassword'](_0xc68346,_0x16df8c);}static['credentialWithLink'](_0x42205c,_0x3b090c){const _0x42267e=Rs['parseLink'](_0x3b090c);return m(_0x42267e,'argument-error'),Ht['_fromEmailAndCode'](_0x42205c,_0x42267e['code'],_0x42267e['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2896df){this['providerId']=_0x2896df,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2a2ac3){this['defaultLanguageCode']=_0x2a2ac3;}['setCustomParameters'](_0x552222){return this['customParameters']=_0x552222,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x41b1be){return this['scopes']['includes'](_0x41b1be)||this['scopes']['push'](_0x41b1be),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1db6eb){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1db6eb});}static['credentialFromResult'](_0x594505){return ue['credentialFromTaggedObject'](_0x594505);}static['credentialFromError'](_0xf53976){return ue['credentialFromTaggedObject'](_0xf53976['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4c4234}){if(!_0x4c4234||!('oauthAccessToken'in _0x4c4234)||!_0x4c4234['oauthAccessToken'])return null;try{return ue['credential'](_0x4c4234['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x34aa89,_0x24abb3){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x34aa89,'accessToken':_0x24abb3});}static['credentialFromResult'](_0x5beb81){return de['credentialFromTaggedObject'](_0x5beb81);}static['credentialFromError'](_0x13a0ca){return de['credentialFromTaggedObject'](_0x13a0ca['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2ed7fe}){if(!_0x2ed7fe)return null;const {oauthIdToken:_0x40a9f9,oauthAccessToken:_0x349562}=_0x2ed7fe;if(!_0x40a9f9&&!_0x349562)return null;try{return de['credential'](_0x40a9f9,_0x349562);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x3e9e04){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3e9e04});}static['credentialFromResult'](_0x1dc1b2){return fe['credentialFromTaggedObject'](_0x1dc1b2);}static['credentialFromError'](_0x163b8b){return fe['credentialFromTaggedObject'](_0x163b8b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5da675}){if(!_0x5da675||!('oauthAccessToken'in _0x5da675)||!_0x5da675['oauthAccessToken'])return null;try{return fe['credential'](_0x5da675['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3644c8,_0x4d7600){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3644c8,'oauthTokenSecret':_0x4d7600});}static['credentialFromResult'](_0x478667){return pe['credentialFromTaggedObject'](_0x478667);}static['credentialFromError'](_0x2282fa){return pe['credentialFromTaggedObject'](_0x2282fa['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x57558a}){if(!_0x57558a)return null;const {oauthAccessToken:_0x45a8bb,oauthTokenSecret:_0x53dbf}=_0x57558a;if(!_0x45a8bb||!_0x53dbf)return null;try{return pe['credential'](_0x45a8bb,_0x53dbf);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x464cb2,_0x97f02e){return en(_0x464cb2,'POST','/v1/accounts:signUp',Ae(_0x464cb2,_0x97f02e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x566a45){this['user']=_0x566a45['user'],this['providerId']=_0x566a45['providerId'],this['_tokenResponse']=_0x566a45['_tokenResponse'],this['operationType']=_0x566a45['operationType'];}static async['_fromIdTokenResponse'](_0x183cff,_0x5be8ca,_0x5681da,_0x558a05=!0x1){const _0x32da1c=await j['_fromIdTokenResponse'](_0x183cff,_0x5681da,_0x558a05),_0x8868d1=Pr(_0x5681da);return new $e({'user':_0x32da1c,'providerId':_0x8868d1,'_tokenResponse':_0x5681da,'operationType':_0x5be8ca});}static async['_forOperation'](_0x3a473d,_0x5dd94a,_0x141cef){await _0x3a473d['_updateTokensIfNecessary'](_0x141cef,!0x0);const _0x238258=Pr(_0x141cef);return new $e({'user':_0x3a473d,'providerId':_0x238258,'_tokenResponse':_0x141cef,'operationType':_0x5dd94a});}}function Pr(_0x259e82){return _0x259e82['providerId']?_0x259e82['providerId']:'phoneNumber'in _0x259e82?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x25b56d,_0x41551c,_0x4e5048,_0xbeff8e){super(_0x41551c['code'],_0x41551c['message']),this['operationType']=_0x4e5048,this['user']=_0xbeff8e,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x25b56d['name'],'tenantId':_0x25b56d['tenantId']??void 0x0,'_serverResponse':_0x41551c['customData']['_serverResponse'],'operationType':_0x4e5048};}static['_fromErrorAndOperation'](_0x1a72e7,_0x4dc7d8,_0x1f64e9,_0x114ae4){return new On(_0x1a72e7,_0x4dc7d8,_0x1f64e9,_0x114ae4);}}function Ba(_0x50bd73,_0x509e6e,_0x11ba68,_0x4ba2d2){return(_0x509e6e==='reauthenticate'?_0x11ba68['_getReauthenticationResolver'](_0x50bd73):_0x11ba68['_getIdTokenResponse'](_0x50bd73))['catch'](_0x2f7eb7=>{throw _0x2f7eb7['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x50bd73,_0x2f7eb7,_0x509e6e,_0x4ba2d2):_0x2f7eb7;});}async function Xf(_0x1022d9,_0x21fe04,_0x1df054=!0x1){const _0x454e90=await Vt(_0x1022d9,_0x21fe04['_linkToIdToken'](_0x1022d9['auth'],await _0x1022d9['getIdToken']()),_0x1df054);return $e['_forOperation'](_0x1022d9,'link',_0x454e90);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x46fc56,_0x45dcf5,_0x408c8f=!0x1){const {auth:_0x47fd13}=_0x46fc56;if($(_0x47fd13['app']))return Promise['reject'](re(_0x47fd13));const _0x520a06='reauthenticate';try{const _0xa30b5c=await Vt(_0x46fc56,Ba(_0x47fd13,_0x520a06,_0x45dcf5,_0x46fc56),_0x408c8f);m(_0xa30b5c['idToken'],_0x47fd13,'internal-error');const _0x2275d9=Ts(_0xa30b5c['idToken']);m(_0x2275d9,_0x47fd13,'internal-error');const {sub:_0x378f1b}=_0x2275d9;return m(_0x46fc56['uid']===_0x378f1b,_0x47fd13,'user-mismatch'),$e['_forOperation'](_0x46fc56,_0x520a06,_0xa30b5c);}catch(_0x801b6f){throw(_0x801b6f==null?void 0x0:_0x801b6f['code'])==='auth/user-not-found'&&Y(_0x47fd13,'user-mismatch'),_0x801b6f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x447f13,_0x509a92,_0x588239=!0x1){if($(_0x447f13['app']))return Promise['reject'](re(_0x447f13));const _0x19e8af='signIn',_0x3eef67=await Ba(_0x447f13,_0x19e8af,_0x509a92),_0xaa3f4a=await $e['_fromIdTokenResponse'](_0x447f13,_0x19e8af,_0x3eef67);return _0x588239||await _0x447f13['_updateCurrentUser'](_0xaa3f4a['user']),_0xaa3f4a;}async function ep(_0x51a4cb,_0x1366d4){return Va(Ke(_0x51a4cb),_0x1366d4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x505341){const _0x18ebaa=Ke(_0x505341);_0x18ebaa['_getPasswordPolicyInternal']()&&await _0x18ebaa['_updatePasswordPolicy']();}async function O_(_0x3a6b25,_0x5036ff,_0x10863c){if($(_0x3a6b25['app']))return Promise['reject'](re(_0x3a6b25));const _0x3d6737=Ke(_0x3a6b25),_0x593657=await xi(_0x3d6737,{'returnSecureToken':!0x0,'email':_0x5036ff,'password':_0x10863c,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0x16f09d=>{throw _0x16f09d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3a6b25),_0x16f09d;}),_0x505929=await $e['_fromIdTokenResponse'](_0x3d6737,'signIn',_0x593657);return await _0x3d6737['_updateCurrentUser'](_0x505929['user']),_0x505929;}function D_(_0x2ea4e0,_0x48109a,_0x2a97b6){return $(_0x2ea4e0['app'])?Promise['reject'](re(_0x2ea4e0)):ep(N(_0x2ea4e0),mt['credential'](_0x48109a,_0x2a97b6))['catch'](async _0x129bd8=>{throw _0x129bd8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2ea4e0),_0x129bd8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x28a8f5,_0xe1c761){return N(_0x28a8f5)['setPersistence'](_0xe1c761);}function tp(_0x47dd32,_0x4308c3,_0x5965e4,_0x417eff){return N(_0x47dd32)['onIdTokenChanged'](_0x4308c3,_0x5965e4,_0x417eff);}function np(_0x32e7de,_0x15c68b,_0x3acc8b){return N(_0x32e7de)['beforeAuthStateChanged'](_0x15c68b,_0x3acc8b);}function L_(_0x2fd49b,_0x5218ec,_0x35a695,_0x3c459b){return N(_0x2fd49b)['onAuthStateChanged'](_0x5218ec,_0x35a695,_0x3c459b);}function x_(_0x4cace2){return N(_0x4cace2)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x589314,_0x12e6fe){this['storageRetriever']=_0x589314,this['type']=_0x12e6fe;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x26c940,_0x17ac53){return this['storage']['setItem'](_0x26c940,JSON['stringify'](_0x17ac53)),Promise['resolve']();}['_get'](_0x1300e2){const _0x5cc58e=this['storage']['getItem'](_0x1300e2);return Promise['resolve'](_0x5cc58e?JSON['parse'](_0x5cc58e):null);}['_remove'](_0x25c23f){return this['storage']['removeItem'](_0x25c23f),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3e0dbc,_0x3f4354)=>this['onStorageEvent'](_0x3e0dbc,_0x3f4354),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3f5cc1){for(const _0x3e691e of Object['keys'](this['listeners'])){const _0x59ae2c=this['storage']['getItem'](_0x3e691e),_0x250d2e=this['localCache'][_0x3e691e];_0x59ae2c!==_0x250d2e&&_0x3f5cc1(_0x3e691e,_0x250d2e,_0x59ae2c);}}['onStorageEvent'](_0x3375e2,_0x43c5d9=!0x1){if(!_0x3375e2['key']){this['forAllChangedKeys']((_0x2d2fdc,_0x578b99,_0xe81d59)=>{this['notifyListeners'](_0x2d2fdc,_0xe81d59);});return;}const _0x4390ea=_0x3375e2['key'];_0x43c5d9?this['detachListener']():this['stopPolling']();const _0x23a23d=()=>{const _0x131e77=this['storage']['getItem'](_0x4390ea);!_0x43c5d9&&this['localCache'][_0x4390ea]===_0x131e77||this['notifyListeners'](_0x4390ea,_0x131e77);},_0x93ab57=this['storage']['getItem'](_0x4390ea);bf()&&_0x93ab57!==_0x3375e2['newValue']&&_0x3375e2['newValue']!==_0x3375e2['oldValue']?setTimeout(_0x23a23d,sp):_0x23a23d();}['notifyListeners'](_0x4140be,_0xaab1f5){this['localCache'][_0x4140be]=_0xaab1f5;const _0x3aa28a=this['listeners'][_0x4140be];if(_0x3aa28a){for(const _0x12430d of Array['from'](_0x3aa28a))_0x12430d(_0xaab1f5&&JSON['parse'](_0xaab1f5));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2a8829,_0x5ab075,_0x164d9d)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2a8829,'oldValue':_0x5ab075,'newValue':_0x164d9d}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x56c1f1,_0x4e895b){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x56c1f1]||(this['listeners'][_0x56c1f1]=new Set(),this['localCache'][_0x56c1f1]=this['storage']['getItem'](_0x56c1f1)),this['listeners'][_0x56c1f1]['add'](_0x4e895b);}['_removeListener'](_0x5416d7,_0x3a99e7){this['listeners'][_0x5416d7]&&(this['listeners'][_0x5416d7]['delete'](_0x3a99e7),this['listeners'][_0x5416d7]['size']===0x0&&delete this['listeners'][_0x5416d7]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x39b736,_0x1455e0){await super['_set'](_0x39b736,_0x1455e0),this['localCache'][_0x39b736]=JSON['stringify'](_0x1455e0);}async['_get'](_0x240d4b){const _0x48fabb=await super['_get'](_0x240d4b);return this['localCache'][_0x240d4b]=JSON['stringify'](_0x48fabb),_0x48fabb;}async['_remove'](_0x359711){await super['_remove'](_0x359711),delete this['localCache'][_0x359711];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x456d15,_0xab1b70){}['_removeListener'](_0x4bec63,_0x3bc80e){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x4cd845){return Promise['all'](_0x4cd845['map'](async _0x4a64db=>{try{return{'fulfilled':!0x0,'value':await _0x4a64db};}catch(_0xc78afa){return{'fulfilled':!0x1,'reason':_0xc78afa};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xbe059a){this['eventTarget']=_0xbe059a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x15686e){const _0x253f69=this['receivers']['find'](_0x5674f6=>_0x5674f6['isListeningto'](_0x15686e));if(_0x253f69)return _0x253f69;const _0x424a7e=new Xn(_0x15686e);return this['receivers']['push'](_0x424a7e),_0x424a7e;}['isListeningto'](_0x340c49){return this['eventTarget']===_0x340c49;}async['handleEvent'](_0x1880af){const _0x296d31=_0x1880af,{eventId:_0x4be7ce,eventType:_0x41ce73,data:_0x5dc745}=_0x296d31['data'],_0x320a35=this['handlersMap'][_0x41ce73];if(!(_0x320a35!=null&&_0x320a35['size']))return;_0x296d31['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4be7ce,'eventType':_0x41ce73});const _0x5a3243=Array['from'](_0x320a35)['map'](async _0x442fe4=>_0x442fe4(_0x296d31['origin'],_0x5dc745)),_0x43da69=await op(_0x5a3243);_0x296d31['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4be7ce,'eventType':_0x41ce73,'response':_0x43da69});}['_subscribe'](_0x790d3a,_0x20e9c8){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x790d3a]||(this['handlersMap'][_0x790d3a]=new Set()),this['handlersMap'][_0x790d3a]['add'](_0x20e9c8);}['_unsubscribe'](_0x4fec40,_0x54cb21){this['handlersMap'][_0x4fec40]&&_0x54cb21&&this['handlersMap'][_0x4fec40]['delete'](_0x54cb21),(!_0x54cb21||this['handlersMap'][_0x4fec40]['size']===0x0)&&delete this['handlersMap'][_0x4fec40],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4ad41f='',_0x2bbcd8=0xa){let _0x47b506='';for(let _0x40654b=0x0;_0x40654b<_0x2bbcd8;_0x40654b++)_0x47b506+=Math['floor'](Math['random']()*0xa);return _0x4ad41f+_0x47b506;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0x1a701e){this['target']=_0x1a701e,this['handlers']=new Set();}['removeMessageHandler'](_0x182f30){_0x182f30['messageChannel']&&(_0x182f30['messageChannel']['port1']['removeEventListener']('message',_0x182f30['onMessage']),_0x182f30['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x182f30);}async['_send'](_0x1a9c32,_0x433aba,_0x43c5ba=0x32){const _0x555e9a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x555e9a)throw new Error('connection_unavailable');let _0x28f58e,_0x9520d3;return new Promise((_0x4663f5,_0x20c117)=>{const _0x111af7=As('',0x14);_0x555e9a['port1']['start']();const _0x1cd336=setTimeout(()=>{_0x20c117(new Error('unsupported_event'));},_0x43c5ba);_0x9520d3={'messageChannel':_0x555e9a,'onMessage'(_0x356cd1){const _0x109032=_0x356cd1;if(_0x109032['data']['eventId']===_0x111af7)switch(_0x109032['data']['status']){case'ack':clearTimeout(_0x1cd336),_0x28f58e=setTimeout(()=>{_0x20c117(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x28f58e),_0x4663f5(_0x109032['data']['response']);break;default:clearTimeout(_0x1cd336),clearTimeout(_0x28f58e),_0x20c117(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x9520d3),_0x555e9a['port1']['addEventListener']('message',_0x9520d3['onMessage']),this['target']['postMessage']({'eventType':_0x1a9c32,'eventId':_0x111af7,'data':_0x433aba},[_0x555e9a['port2']]);})['finally'](()=>{_0x9520d3&&this['removeMessageHandler'](_0x9520d3);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0x10cd7e){Z()['location']['href']=_0x10cd7e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x40067d;return((_0x40067d=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x40067d['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x2fe680){this['request']=_0x2fe680;}['toPromise'](){return new Promise((_0x1ad938,_0x46d759)=>{this['request']['addEventListener']('success',()=>{_0x1ad938(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x46d759(this['request']['error']);});});}}function Zn(_0x2f5e65,_0x4a8db2){return _0x2f5e65['transaction']([Mn],_0x4a8db2?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x4556e1=indexedDB['deleteDatabase'](Ka);return new nn(_0x4556e1)['toPromise']();}function Qa(){const _0x29fa03=indexedDB['open'](Ka,dp);return new Promise((_0x3812ea,_0x297ea7)=>{_0x29fa03['addEventListener']('error',()=>{_0x297ea7(_0x29fa03['error']);}),_0x29fa03['addEventListener']('upgradeneeded',()=>{const _0x1b66f7=_0x29fa03['result'];try{_0x1b66f7['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x5ba53c){_0x297ea7(_0x5ba53c);}}),_0x29fa03['addEventListener']('success',async()=>{const _0x2409d7=_0x29fa03['result'];_0x2409d7['objectStoreNames']['contains'](Mn)?_0x3812ea(_0x2409d7):(_0x2409d7['close'](),await fp(),_0x3812ea(await Qa()));});});}async function Or(_0x5b6e50,_0x1e7d2e,_0x2d353f){const _0x165ebf=Zn(_0x5b6e50,!0x0)['put']({[Ya]:_0x1e7d2e,'value':_0x2d353f});return new nn(_0x165ebf)['toPromise']();}async function pp(_0x307ca5,_0x17c1f1){const _0x376cc9=Zn(_0x307ca5,!0x1)['get'](_0x17c1f1),_0x173e0d=await new nn(_0x376cc9)['toPromise']();return _0x173e0d===void 0x0?null:_0x173e0d['value'];}function Dr(_0x5e35f7,_0x20bfd5){const _0x20c074=Zn(_0x5e35f7,!0x0)['delete'](_0x20bfd5);return new nn(_0x20c074)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1ec58f){let _0x1a594d=0x0;for(;;)try{const _0x5aa996=await this['_openDb']();return await _0x1ec58f(_0x5aa996);}catch(_0x30cda4){if(_0x1a594d++>gp)throw _0x30cda4;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0x462409,_0x2dd68c)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2dd68c['key'])})),this['receiver']['_subscribe']('ping',async(_0xcfdddc,_0x14aef0)=>['keyChanged']);}async['initializeSender'](){var _0x2cf362,_0x5b6084;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0x333403=await this['sender']['_send']('ping',{},0x320);_0x333403&&(_0x2cf362=_0x333403[0x0])!=null&&_0x2cf362['fulfilled']&&(_0x5b6084=_0x333403[0x0])!=null&&_0x5b6084['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5bf66d){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5bf66d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x202a07=>{await Or(_0x202a07,Dn,'1'),await Dr(_0x202a07,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5af6f4){this['pendingWrites']++;try{await _0x5af6f4();}finally{this['pendingWrites']--;}}async['_set'](_0x4bc16a,_0x22b449){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xeda40e=>Or(_0xeda40e,_0x4bc16a,_0x22b449)),this['localCache'][_0x4bc16a]=_0x22b449,this['notifyServiceWorker'](_0x4bc16a)));}async['_get'](_0x3acac0){const _0x9c8882=await this['_withRetries'](_0x44ccb9=>pp(_0x44ccb9,_0x3acac0));return this['localCache'][_0x3acac0]=_0x9c8882,_0x9c8882;}async['_remove'](_0x291802){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x360561=>Dr(_0x360561,_0x291802)),delete this['localCache'][_0x291802],this['notifyServiceWorker'](_0x291802)));}async['_poll'](){const _0x12c895=await this['_withRetries'](_0x11fc02=>{const _0x42ecf3=Zn(_0x11fc02,!0x1)['getAll']();return new nn(_0x42ecf3)['toPromise']();});if(!_0x12c895)return[];if(this['pendingWrites']!==0x0)return[];const _0x57853d=[],_0x185364=new Set();if(_0x12c895['length']!==0x0){for(const {fbase_key:_0x5b2927,value:_0x23809d}of _0x12c895)_0x185364['add'](_0x5b2927),JSON['stringify'](this['localCache'][_0x5b2927])!==JSON['stringify'](_0x23809d)&&(this['notifyListeners'](_0x5b2927,_0x23809d),_0x57853d['push'](_0x5b2927));}for(const _0x1543bd of Object['keys'](this['localCache']))this['localCache'][_0x1543bd]&&!_0x185364['has'](_0x1543bd)&&(this['notifyListeners'](_0x1543bd,null),_0x57853d['push'](_0x1543bd));return _0x57853d;}['notifyListeners'](_0x4b3f82,_0x50334f){this['localCache'][_0x4b3f82]=_0x50334f;const _0x7701f6=this['listeners'][_0x4b3f82];if(_0x7701f6){for(const _0x5304a4 of Array['from'](_0x7701f6))_0x5304a4(_0x50334f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2cd433,_0x347f1c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2cd433]||(this['listeners'][_0x2cd433]=new Set(),this['_get'](_0x2cd433)),this['listeners'][_0x2cd433]['add'](_0x347f1c);}['_removeListener'](_0x3e22bd,_0x37ce0a){this['listeners'][_0x3e22bd]&&(this['listeners'][_0x3e22bd]['delete'](_0x37ce0a),this['listeners'][_0x3e22bd]['size']===0x0&&delete this['listeners'][_0x3e22bd]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0x41d491,_0x545b28){return _0x545b28?ie(_0x545b28):(m(_0x41d491['_popupRedirectResolver'],_0x41d491,'argument-error'),_0x41d491['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x33edf3){super('custom','custom'),this['params']=_0x33edf3;}['_getIdTokenResponse'](_0x1651a9){return nt(_0x1651a9,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3993f9,_0x1f8a1d){return nt(_0x3993f9,this['_buildIdpRequest'](_0x1f8a1d));}['_getReauthenticationResolver'](_0x52d677){return nt(_0x52d677,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3e6ea7){const _0x577d3a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3e6ea7&&(_0x577d3a['idToken']=_0x3e6ea7),_0x577d3a;}}function vp(_0x4661c7){return Va(_0x4661c7['auth'],new ks(_0x4661c7),_0x4661c7['bypassAuthState']);}function Ep(_0x2cd74c){const {auth:_0x289cc4,user:_0x4e71f3}=_0x2cd74c;return m(_0x4e71f3,_0x289cc4,'internal-error'),Zf(_0x4e71f3,new ks(_0x2cd74c),_0x2cd74c['bypassAuthState']);}async function Ip(_0xe19b63){const {auth:_0x294b0e,user:_0x245887}=_0xe19b63;return m(_0x245887,_0x294b0e,'internal-error'),Xf(_0x245887,new ks(_0xe19b63),_0xe19b63['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3d62a4,_0xc94c38,_0x192af5,_0x43bdbb,_0x5db9b7=!0x1){this['auth']=_0x3d62a4,this['resolver']=_0x192af5,this['user']=_0x43bdbb,this['bypassAuthState']=_0x5db9b7,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xc94c38)?_0xc94c38:[_0xc94c38];}['execute'](){return new Promise(async(_0x162d6f,_0x1bb755)=>{this['pendingPromise']={'resolve':_0x162d6f,'reject':_0x1bb755};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x381858){this['reject'](_0x381858);}});}async['onAuthEvent'](_0x14f285){const {urlResponse:_0x30dfb9,sessionId:_0x282a85,postBody:_0xa65de8,tenantId:_0x4f0878,error:_0x438975,type:_0x295b31}=_0x14f285;if(_0x438975){this['reject'](_0x438975);return;}const _0x555e2d={'auth':this['auth'],'requestUri':_0x30dfb9,'sessionId':_0x282a85,'tenantId':_0x4f0878||void 0x0,'postBody':_0xa65de8||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x295b31)(_0x555e2d));}catch(_0x47c2b7){this['reject'](_0x47c2b7);}}['onError'](_0x46d326){this['reject'](_0x46d326);}['getIdpTask'](_0x340299){switch(_0x340299){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0x763ee0){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x763ee0),this['unregisterAndCleanUp']();}['reject'](_0x362701){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x362701),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x35d420,_0x3e87fd,_0x234ff9,_0x24e2bd,_0x26ad17){super(_0x35d420,_0x3e87fd,_0x24e2bd,_0x26ad17),this['provider']=_0x234ff9,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x452ea4=await this['execute']();return m(_0x452ea4,this['auth'],'internal-error'),_0x452ea4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xef77ab=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xef77ab),this['authWindow']['associatedEvent']=_0xef77ab,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1e19a4=>{this['reject'](_0x1e19a4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1bcb57=>{_0x1bcb57||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x35e7ba;return((_0x35e7ba=this['authWindow'])==null?void 0x0:_0x35e7ba['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2972b4=()=>{var _0x1efe60,_0xedb60d;if((_0xedb60d=(_0x1efe60=this['authWindow'])==null?void 0x0:_0x1efe60['window'])!=null&&_0xedb60d['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2972b4,wp['get']());};_0x2972b4();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x138f54,_0x3758b9,_0x3cd56c=!0x1){super(_0x138f54,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3758b9,void 0x0,_0x3cd56c),this['eventId']=null;}async['execute'](){let _0x2eceae=hn['get'](this['auth']['_key']());if(!_0x2eceae){try{const _0x2de20f=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0x2eceae=()=>Promise['resolve'](_0x2de20f);}catch(_0x533cae){_0x2eceae=()=>Promise['reject'](_0x533cae);}hn['set'](this['auth']['_key'](),_0x2eceae);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2eceae();}async['onAuthEvent'](_0x53764d){if(_0x53764d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x53764d);if(_0x53764d['type']==='unknown'){this['resolve'](null);return;}if(_0x53764d['eventId']){const _0x4cbbf0=await this['auth']['_redirectUserForId'](_0x53764d['eventId']);if(_0x4cbbf0)return this['user']=_0x4cbbf0,super['onAuthEvent'](_0x53764d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0x364409,_0x53aba8){const _0x616da3=Ap(_0x53aba8),_0x3b9a30=Rp(_0x364409);if(!await _0x3b9a30['_isAvailable']())return!0x1;const _0x459f2a=await _0x3b9a30['_get'](_0x616da3)==='true';return await _0x3b9a30['_remove'](_0x616da3),_0x459f2a;}function bp(_0x2197b5,_0x35e05a){hn['set'](_0x2197b5['_key'](),_0x35e05a);}function Rp(_0x592bfe){return ie(_0x592bfe['_redirectPersistence']);}function Ap(_0x29c0d4){return ln(Cp,_0x29c0d4['config']['apiKey'],_0x29c0d4['name']);}async function kp(_0x27f40b,_0x12662d,_0x15b162=!0x1){if($(_0x27f40b['app']))return Promise['reject'](re(_0x27f40b));const _0x80cba8=Ke(_0x27f40b),_0x17f910=yp(_0x80cba8,_0x12662d),_0x3e3ca1=await new Tp(_0x80cba8,_0x17f910,_0x15b162)['execute']();return _0x3e3ca1&&!_0x15b162&&(delete _0x3e3ca1['user']['_redirectEventId'],await _0x80cba8['_persistUserIfCurrent'](_0x3e3ca1['user']),await _0x80cba8['_setRedirectUser'](null,_0x12662d)),_0x3e3ca1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x1dbe97){this['auth']=_0x1dbe97,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1c173a){this['consumers']['add'](_0x1c173a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1c173a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1c173a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5a4874){this['consumers']['delete'](_0x5a4874);}['onEvent'](_0x82967a){if(this['hasEventBeenHandled'](_0x82967a))return!0x1;let _0x4fb560=!0x1;return this['consumers']['forEach'](_0x1be593=>{this['isEventForConsumer'](_0x82967a,_0x1be593)&&(_0x4fb560=!0x0,this['sendToConsumer'](_0x82967a,_0x1be593),this['saveEventToCache'](_0x82967a));}),this['hasHandledPotentialRedirect']||!Op(_0x82967a)||(this['hasHandledPotentialRedirect']=!0x0,_0x4fb560||(this['queuedRedirectEvent']=_0x82967a,_0x4fb560=!0x0)),_0x4fb560;}['sendToConsumer'](_0x2a95a6,_0x5164e4){var _0x22b541;if(_0x2a95a6['error']&&!Za(_0x2a95a6)){const _0x51143d=((_0x22b541=_0x2a95a6['error']['code'])==null?void 0x0:_0x22b541['split']('auth/')[0x1])||'internal-error';_0x5164e4['onError'](X(this['auth'],_0x51143d));}else _0x5164e4['onAuthEvent'](_0x2a95a6);}['isEventForConsumer'](_0x23c258,_0x17dda3){const _0x218296=_0x17dda3['eventId']===null||!!_0x23c258['eventId']&&_0x23c258['eventId']===_0x17dda3['eventId'];return _0x17dda3['filter']['includes'](_0x23c258['type'])&&_0x218296;}['hasEventBeenHandled'](_0x43d70f){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x43d70f));}['saveEventToCache'](_0xb89e1c){this['cachedEventUids']['add'](Mr(_0xb89e1c)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x11b19b){return[_0x11b19b['type'],_0x11b19b['eventId'],_0x11b19b['sessionId'],_0x11b19b['tenantId']]['filter'](_0x53b0f0=>_0x53b0f0)['join']('-');}function Za({type:_0x3709ea,error:_0x2f695b}){return _0x3709ea==='unknown'&&(_0x2f695b==null?void 0x0:_0x2f695b['code'])==='auth/no-auth-event';}function Op(_0x5c19e4){switch(_0x5c19e4['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x5c19e4);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x28d26b,_0x56dd3e={}){return ke(_0x28d26b,'GET','/v1/projects',_0x56dd3e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x33dcbb){if(_0x33dcbb['config']['emulator'])return;const {authorizedDomains:_0x40ff47}=await Dp(_0x33dcbb);for(const _0x32b3a3 of _0x40ff47)try{if(Fp(_0x32b3a3))return;}catch{}Y(_0x33dcbb,'unauthorized-domain');}function Fp(_0x163a1c){const _0x8428ab=Mi(),{protocol:_0x3dcd06,hostname:_0x2f890d}=new URL(_0x8428ab);if(_0x163a1c['startsWith']('chrome-extension://')){const _0x12f172=new URL(_0x163a1c);return _0x12f172['hostname']===''&&_0x2f890d===''?_0x3dcd06==='chrome-extension:'&&_0x163a1c['replace']('chrome-extension://','')===_0x8428ab['replace']('chrome-extension://',''):_0x3dcd06==='chrome-extension:'&&_0x12f172['hostname']===_0x2f890d;}if(!Lp['test'](_0x3dcd06))return!0x1;if(Mp['test'](_0x163a1c))return _0x2f890d===_0x163a1c;const _0x542563=_0x163a1c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x542563+'|'+_0x542563+')$','i')['test'](_0x2f890d);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0xcf4bfa=Z()['___jsl'];if(_0xcf4bfa!=null&&_0xcf4bfa['H']){for(const _0x5cbc65 of Object['keys'](_0xcf4bfa['H']))if(_0xcf4bfa['H'][_0x5cbc65]['r']=_0xcf4bfa['H'][_0x5cbc65]['r']||[],_0xcf4bfa['H'][_0x5cbc65]['L']=_0xcf4bfa['H'][_0x5cbc65]['L']||[],_0xcf4bfa['H'][_0x5cbc65]['r']=[..._0xcf4bfa['H'][_0x5cbc65]['L']],_0xcf4bfa['CP']){for(let _0x3c7236=0x0;_0x3c7236<_0xcf4bfa['CP']['length'];_0x3c7236++)_0xcf4bfa['CP'][_0x3c7236]=null;}}}function Wp(_0x1e222f){return new Promise((_0x2dde37,_0x40cf19)=>{var _0x2b93fe,_0x1e5215,_0x4095d0;function _0x4a614c(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2dde37(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x40cf19(X(_0x1e222f,'network-request-failed'));},'timeout':Up['get']()});}if((_0x1e5215=(_0x2b93fe=Z()['gapi'])==null?void 0x0:_0x2b93fe['iframes'])!=null&&_0x1e5215['Iframe'])_0x2dde37(gapi['iframes']['getContext']());else{if((_0x4095d0=Z()['gapi'])!=null&&_0x4095d0['load'])_0x4a614c();else{const _0x1dddd0=Lf('iframefcb');return Z()[_0x1dddd0]=()=>{gapi['load']?_0x4a614c():_0x40cf19(X(_0x1e222f,'network-request-failed'));},xa(Mf()+'?onload='+_0x1dddd0)['catch'](_0xe1b420=>_0x40cf19(_0xe1b420));}}})['catch'](_0x23395a=>{throw un=null,_0x23395a;});}let un=null;function Bp(_0x2cc4ae){return un=un||Wp(_0x2cc4ae),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0x5f579c){const _0x12cae3=_0x5f579c['config'];m(_0x12cae3['authDomain'],_0x5f579c,'auth-domain-config-required');const _0x1e94b3=_0x12cae3['emulator']?Cs(_0x12cae3,$p):'https://'+_0x5f579c['config']['authDomain']+'/'+Hp,_0x2f377f={'apiKey':_0x12cae3['apiKey'],'appName':_0x5f579c['name'],'v':dt},_0x182127=qp['get'](_0x5f579c['config']['apiHost']);_0x182127&&(_0x2f377f['eid']=_0x182127);const _0x2ec7a7=_0x5f579c['_getFrameworks']();return _0x2ec7a7['length']&&(_0x2f377f['fw']=_0x2ec7a7['join'](',')),_0x1e94b3+'?'+ut(_0x2f377f)['slice'](0x1);}async function jp(_0x4b5f67){const _0x597539=await Bp(_0x4b5f67),_0x1e20f3=Z()['gapi'];return m(_0x1e20f3,_0x4b5f67,'internal-error'),_0x597539['open']({'where':document['body'],'url':zp(_0x4b5f67),'messageHandlersFilter':_0x1e20f3['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0x3e49e8=>new Promise(async(_0x398eb4,_0x4f1b4d)=>{await _0x3e49e8['restyle']({'setHideOnLeave':!0x1});const _0x5a88e0=X(_0x4b5f67,'network-request-failed'),_0x2b289c=Z()['setTimeout'](()=>{_0x4f1b4d(_0x5a88e0);},Vp['get']());function _0xe9a95b(){Z()['clearTimeout'](_0x2b289c),_0x398eb4(_0x3e49e8);}_0x3e49e8['ping'](_0xe9a95b)['then'](_0xe9a95b,()=>{_0x4f1b4d(_0x5a88e0);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x1542f7){this['window']=_0x1542f7,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x3ffbde,_0x3a3344,_0x387d54,_0x3c1d18=Yp,_0x359f7e=Qp){const _0x38e262=Math['max']((window['screen']['availHeight']-_0x359f7e)/0x2,0x0)['toString'](),_0xd2f1a6=Math['max']((window['screen']['availWidth']-_0x3c1d18)/0x2,0x0)['toString']();let _0x9b4c0d='';const _0x53aee7={...Kp,'width':_0x3c1d18['toString'](),'height':_0x359f7e['toString'](),'top':_0x38e262,'left':_0xd2f1a6},_0x2b6a94=W()['toLowerCase']();_0x387d54&&(_0x9b4c0d=ka(_0x2b6a94)?Jp:_0x387d54),Ra(_0x2b6a94)&&(_0x3a3344=_0x3a3344||Xp,_0x53aee7['scrollbars']='yes');const _0x30f6c1=Object['entries'](_0x53aee7)['reduce']((_0x27f18d,[_0xce751c,_0xeff063])=>''+_0x27f18d+_0xce751c+'='+_0xeff063+',','');if(Sf(_0x2b6a94)&&_0x9b4c0d!=='_self')return e_(_0x3a3344||'',_0x9b4c0d),new xr(null);const _0x1d2de2=window['open'](_0x3a3344||'',_0x9b4c0d,_0x30f6c1);m(_0x1d2de2,_0x3ffbde,'popup-blocked');try{_0x1d2de2['focus']();}catch{}return new xr(_0x1d2de2);}function e_(_0x4717cd,_0x2cea0a){const _0x42d288=document['createElement']('a');_0x42d288['href']=_0x4717cd,_0x42d288['target']=_0x2cea0a;const _0x102e03=document['createEvent']('MouseEvent');_0x102e03['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x42d288['dispatchEvent'](_0x102e03);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0x468e9c,_0xc91306,_0x50b92e,_0x5ef879,_0x5c94bf,_0x1b6942){m(_0x468e9c['config']['authDomain'],_0x468e9c,'auth-domain-config-required'),m(_0x468e9c['config']['apiKey'],_0x468e9c,'invalid-api-key');const _0x193df3={'apiKey':_0x468e9c['config']['apiKey'],'appName':_0x468e9c['name'],'authType':_0x50b92e,'redirectUrl':_0x5ef879,'v':dt,'eventId':_0x5c94bf};if(_0xc91306 instanceof Wa){_0xc91306['setDefaultLanguage'](_0x468e9c['languageCode']),_0x193df3['providerId']=_0xc91306['providerId']||'',pn(_0xc91306['getCustomParameters']())||(_0x193df3['customParameters']=JSON['stringify'](_0xc91306['getCustomParameters']()));for(const [_0x2d62be,_0x651ba7]of Object['entries']({}))_0x193df3[_0x2d62be]=_0x651ba7;}if(_0xc91306 instanceof tn){const _0x37facd=_0xc91306['getScopes']()['filter'](_0xb0451e=>_0xb0451e!=='');_0x37facd['length']>0x0&&(_0x193df3['scopes']=_0x37facd['join'](','));}_0x468e9c['tenantId']&&(_0x193df3['tid']=_0x468e9c['tenantId']);const _0x15f00e=_0x193df3;for(const _0x56e663 of Object['keys'](_0x15f00e))_0x15f00e[_0x56e663]===void 0x0&&delete _0x15f00e[_0x56e663];const _0x4f3f98=await _0x468e9c['_getAppCheckToken'](),_0x3380b0=_0x4f3f98?'#'+i_+'='+encodeURIComponent(_0x4f3f98):'';return s_(_0x468e9c)+'?'+ut(_0x15f00e)['slice'](0x1)+_0x3380b0;}function s_({config:_0x225e8b}){return _0x225e8b['emulator']?Cs(_0x225e8b,n_):'https://'+_0x225e8b['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x2befd2,_0x55b1d7,_0x492453,_0x10bdbb){var _0x2455aa;ce((_0x2455aa=this['eventManagers'][_0x2befd2['_key']()])==null?void 0x0:_0x2455aa['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2d7a1c=await Fr(_0x2befd2,_0x55b1d7,_0x492453,Mi(),_0x10bdbb);return Zp(_0x2befd2,_0x2d7a1c,As());}async['_openRedirect'](_0x55ad67,_0x452306,_0x53f083,_0x5cfc4d){await this['_originValidation'](_0x55ad67);const _0x56f309=await Fr(_0x55ad67,_0x452306,_0x53f083,Mi(),_0x5cfc4d);return cp(_0x56f309),new Promise(()=>{});}['_initialize'](_0x52ed07){const _0x4d59de=_0x52ed07['_key']();if(this['eventManagers'][_0x4d59de]){const {manager:_0xb9f2f9,promise:_0x1156a4}=this['eventManagers'][_0x4d59de];return _0xb9f2f9?Promise['resolve'](_0xb9f2f9):(ce(_0x1156a4,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1156a4);}const _0x288d93=this['initAndGetManager'](_0x52ed07);return this['eventManagers'][_0x4d59de]={'promise':_0x288d93},_0x288d93['catch'](()=>{delete this['eventManagers'][_0x4d59de];}),_0x288d93;}async['initAndGetManager'](_0x3ffe65){const _0x38010b=await jp(_0x3ffe65),_0x354b52=new Pp(_0x3ffe65);return _0x38010b['register']('authEvent',_0x142957=>(m(_0x142957==null?void 0x0:_0x142957['authEvent'],_0x3ffe65,'invalid-auth-event'),{'status':_0x354b52['onEvent'](_0x142957['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3ffe65['_key']()]={'manager':_0x354b52},this['iframes'][_0x3ffe65['_key']()]=_0x38010b,_0x354b52;}['_isIframeWebStorageSupported'](_0xace77c,_0x52479f){this['iframes'][_0xace77c['_key']()]['send'](pi,{'type':pi},_0x4c8ec0=>{var _0x299dbf;const _0x5a1bca=(_0x299dbf=_0x4c8ec0==null?void 0x0:_0x4c8ec0[0x0])==null?void 0x0:_0x299dbf[pi];_0x5a1bca!==void 0x0&&_0x52479f(!!_0x5a1bca),Y(_0xace77c,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4a0392){const _0x3b86b1=_0x4a0392['_key']();return this['originValidationPromises'][_0x3b86b1]||(this['originValidationPromises'][_0x3b86b1]=xp(_0x4a0392)),this['originValidationPromises'][_0x3b86b1];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0x3bebbc){this['auth']=_0x3bebbc,this['internalListeners']=new Map();}['getUid'](){var _0x597e26;return this['assertAuthConfigured'](),((_0x597e26=this['auth']['currentUser'])==null?void 0x0:_0x597e26['uid'])||null;}async['getToken'](_0x2c8d78){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2c8d78)}:null;}['addAuthTokenListener'](_0x5560f2){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5560f2))return;const _0x4bfe80=this['auth']['onIdTokenChanged'](_0x5697c1=>{_0x5560f2((_0x5697c1==null?void 0x0:_0x5697c1['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5560f2,_0x4bfe80),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5aff7d){this['assertAuthConfigured']();const _0x26a251=this['internalListeners']['get'](_0x5aff7d);_0x26a251&&(this['internalListeners']['delete'](_0x5aff7d),_0x26a251(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x50094b){switch(_0x50094b){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x51f7cc){st(new xe('auth',(_0x32d46a,{options:_0x5e2608})=>{const _0x717414=_0x32d46a['getProvider']('app')['getImmediate'](),_0x5b7238=_0x32d46a['getProvider']('heartbeat'),_0x3001ee=_0x32d46a['getProvider']('app-check-internal'),{apiKey:_0x4600c4,authDomain:_0x45ee1c}=_0x717414['options'];m(_0x4600c4&&!_0x4600c4['includes'](':'),'invalid-api-key',{'appName':_0x717414['name']});const _0x111f92={'apiKey':_0x4600c4,'authDomain':_0x45ee1c,'clientPlatform':_0x51f7cc,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x51f7cc)},_0x587aa2=new Pf(_0x717414,_0x5b7238,_0x3001ee,_0x111f92);return Bf(_0x587aa2,_0x5e2608),_0x587aa2;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x517403,_0x2c0ee8,_0x17a454)=>{_0x517403['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x41f28f=>{const _0x45eace=Ke(_0x41f28f['getProvider']('auth')['getImmediate']());return(_0x1e8a4f=>new a_(_0x1e8a4f))(_0x45eace);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x51f7cc)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x16f40c=>async _0x26717b=>{const _0x5541d6=_0x26717b&&await _0x26717b['getIdTokenResult'](),_0x238f27=_0x5541d6&&(new Date()['getTime']()-Date['parse'](_0x5541d6['issuedAtTime']))/0x3e8;if(_0x238f27&&_0x238f27>u_)return;const _0x21076e=_0x5541d6==null?void 0x0:_0x5541d6['token'];Br!==_0x21076e&&(Br=_0x21076e,await fetch(_0x16f40c,{'method':_0x21076e?'POST':'DELETE','headers':_0x21076e?{'Authorization':'Bearer\x20'+_0x21076e}:{}}));};function F_(_0x252f22=Zr()){const _0x4a494f=Hi(_0x252f22,'auth');if(_0x4a494f['isInitialized']())return _0x4a494f['getImmediate']();const _0x1982b1=Wf(_0x252f22,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0x26f89d=jr('authTokenSyncURL');if(_0x26f89d&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x128f0f=new URL(_0x26f89d,location['origin']);if(location['origin']===_0x128f0f['origin']){const _0x1d5609=d_(_0x128f0f['toString']());np(_0x1982b1,_0x1d5609,()=>_0x1d5609(_0x1982b1['currentUser'])),tp(_0x1982b1,_0xbaa275=>_0x1d5609(_0xbaa275));}}const _0x4c7790=qr('auth');return _0x4c7790&&Vf(_0x1982b1,'http://'+_0x4c7790),_0x1982b1;}function f_(){var _0x4a05d7;return((_0x4a05d7=document['getElementsByTagName']('head'))==null?void 0x0:_0x4a05d7[0x0])??document;}Of({'loadJS'(_0x2a732c){return new Promise((_0x229035,_0x512a80)=>{const _0x2108d4=document['createElement']('script');_0x2108d4['setAttribute']('src',_0x2a732c),_0x2108d4['onload']=_0x229035,_0x2108d4['onerror']=_0x714a36=>{const _0x2a165d=X('internal-error');_0x2a165d['customData']=_0x714a36,_0x512a80(_0x2a165d);},_0x2108d4['type']='text/javascript',_0x2108d4['charset']='UTF-8',f_()['appendChild'](_0x2108d4);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{x_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,__ as h,Sl as i,Vd as j,N_ as k,$d as l,A_ as m,L_ as n,m_ as o,k_ as p,b_ as q,g_ as r,M_ as s,C_ as t,v_ as u,S_ as v,Bt as w,y_ as x,P_ as y,O_ as z};