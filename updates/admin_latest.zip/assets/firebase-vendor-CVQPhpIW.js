const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x19eff7,_0x172953){if(!_0x19eff7)throw ht(_0x172953);},ht=function(_0x4cb3c1){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4cb3c1);},Hr=function(_0x22295d){const _0x348c55=[];let _0x33aff1=0x0;for(let _0x342242=0x0;_0x342242<_0x22295d['length'];_0x342242++){let _0xd49f76=_0x22295d['charCodeAt'](_0x342242);_0xd49f76<0x80?_0x348c55[_0x33aff1++]=_0xd49f76:_0xd49f76<0x800?(_0x348c55[_0x33aff1++]=_0xd49f76>>0x6|0xc0,_0x348c55[_0x33aff1++]=_0xd49f76&0x3f|0x80):(_0xd49f76&0xfc00)===0xd800&&_0x342242+0x1<_0x22295d['length']&&(_0x22295d['charCodeAt'](_0x342242+0x1)&0xfc00)===0xdc00?(_0xd49f76=0x10000+((_0xd49f76&0x3ff)<<0xa)+(_0x22295d['charCodeAt'](++_0x342242)&0x3ff),_0x348c55[_0x33aff1++]=_0xd49f76>>0x12|0xf0,_0x348c55[_0x33aff1++]=_0xd49f76>>0xc&0x3f|0x80,_0x348c55[_0x33aff1++]=_0xd49f76>>0x6&0x3f|0x80,_0x348c55[_0x33aff1++]=_0xd49f76&0x3f|0x80):(_0x348c55[_0x33aff1++]=_0xd49f76>>0xc|0xe0,_0x348c55[_0x33aff1++]=_0xd49f76>>0x6&0x3f|0x80,_0x348c55[_0x33aff1++]=_0xd49f76&0x3f|0x80);}return _0x348c55;},nc=function(_0x3a2f7d){const _0x4d71f0=[];let _0x15ae27=0x0,_0x561c6a=0x0;for(;_0x15ae27<_0x3a2f7d['length'];){const _0xec694d=_0x3a2f7d[_0x15ae27++];if(_0xec694d<0x80)_0x4d71f0[_0x561c6a++]=String['fromCharCode'](_0xec694d);else{if(_0xec694d>0xbf&&_0xec694d<0xe0){const _0x12cadc=_0x3a2f7d[_0x15ae27++];_0x4d71f0[_0x561c6a++]=String['fromCharCode']((_0xec694d&0x1f)<<0x6|_0x12cadc&0x3f);}else{if(_0xec694d>0xef&&_0xec694d<0x16d){const _0x10da27=_0x3a2f7d[_0x15ae27++],_0x1ad16d=_0x3a2f7d[_0x15ae27++],_0x2b2610=_0x3a2f7d[_0x15ae27++],_0x191b54=((_0xec694d&0x7)<<0x12|(_0x10da27&0x3f)<<0xc|(_0x1ad16d&0x3f)<<0x6|_0x2b2610&0x3f)-0x10000;_0x4d71f0[_0x561c6a++]=String['fromCharCode'](0xd800+(_0x191b54>>0xa)),_0x4d71f0[_0x561c6a++]=String['fromCharCode'](0xdc00+(_0x191b54&0x3ff));}else{const _0x19c059=_0x3a2f7d[_0x15ae27++],_0xa8c951=_0x3a2f7d[_0x15ae27++];_0x4d71f0[_0x561c6a++]=String['fromCharCode']((_0xec694d&0xf)<<0xc|(_0x19c059&0x3f)<<0x6|_0xa8c951&0x3f);}}}}return _0x4d71f0['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3369f8,_0x3d0d46){if(!Array['isArray'](_0x3369f8))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x68c841=_0x3d0d46?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x142ded=[];for(let _0x270932=0x0;_0x270932<_0x3369f8['length'];_0x270932+=0x3){const _0x15d67d=_0x3369f8[_0x270932],_0x2dd2fe=_0x270932+0x1<_0x3369f8['length'],_0x5e23e6=_0x2dd2fe?_0x3369f8[_0x270932+0x1]:0x0,_0x25b533=_0x270932+0x2<_0x3369f8['length'],_0x13895d=_0x25b533?_0x3369f8[_0x270932+0x2]:0x0,_0x2eef6f=_0x15d67d>>0x2,_0x5f0e5e=(_0x15d67d&0x3)<<0x4|_0x5e23e6>>0x4;let _0x7ec2b6=(_0x5e23e6&0xf)<<0x2|_0x13895d>>0x6,_0x51015e=_0x13895d&0x3f;_0x25b533||(_0x51015e=0x40,_0x2dd2fe||(_0x7ec2b6=0x40)),_0x142ded['push'](_0x68c841[_0x2eef6f],_0x68c841[_0x5f0e5e],_0x68c841[_0x7ec2b6],_0x68c841[_0x51015e]);}return _0x142ded['join']('');},'encodeString'(_0x5439f3,_0x123f04){return this['HAS_NATIVE_SUPPORT']&&!_0x123f04?btoa(_0x5439f3):this['encodeByteArray'](Hr(_0x5439f3),_0x123f04);},'decodeString'(_0x3121a4,_0x3050ed){return this['HAS_NATIVE_SUPPORT']&&!_0x3050ed?atob(_0x3121a4):nc(this['decodeStringToByteArray'](_0x3121a4,_0x3050ed));},'decodeStringToByteArray'(_0x4befa3,_0xbf482c){this['init_']();const _0x3897a3=_0xbf482c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xaee640=[];for(let _0x51b139=0x0;_0x51b139<_0x4befa3['length'];){const _0x3426ed=_0x3897a3[_0x4befa3['charAt'](_0x51b139++)],_0x5e8fb3=_0x51b139<_0x4befa3['length']?_0x3897a3[_0x4befa3['charAt'](_0x51b139)]:0x0;++_0x51b139;const _0x36e270=_0x51b139<_0x4befa3['length']?_0x3897a3[_0x4befa3['charAt'](_0x51b139)]:0x40;++_0x51b139;const _0x4def1a=_0x51b139<_0x4befa3['length']?_0x3897a3[_0x4befa3['charAt'](_0x51b139)]:0x40;if(++_0x51b139,_0x3426ed==null||_0x5e8fb3==null||_0x36e270==null||_0x4def1a==null)throw new ic();const _0x329325=_0x3426ed<<0x2|_0x5e8fb3>>0x4;if(_0xaee640['push'](_0x329325),_0x36e270!==0x40){const _0x2679f5=_0x5e8fb3<<0x4&0xf0|_0x36e270>>0x2;if(_0xaee640['push'](_0x2679f5),_0x4def1a!==0x40){const _0x4585f4=_0x36e270<<0x6&0xc0|_0x4def1a;_0xaee640['push'](_0x4585f4);}}}return _0xaee640;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x763be4=0x0;_0x763be4<this['ENCODED_VALS']['length'];_0x763be4++)this['byteToCharMap_'][_0x763be4]=this['ENCODED_VALS']['charAt'](_0x763be4),this['charToByteMap_'][this['byteToCharMap_'][_0x763be4]]=_0x763be4,this['byteToCharMapWebSafe_'][_0x763be4]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x763be4),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x763be4]]=_0x763be4,_0x763be4>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x763be4)]=_0x763be4,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x763be4)]=_0x763be4);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x1f1ebc){const _0x3a91c8=Hr(_0x1f1ebc);return Fi['encodeByteArray'](_0x3a91c8,!0x0);},dn=function(_0x365d07){return $r(_0x365d07)['replace'](/\./g,'');},fn=function(_0x5ca8d4){try{return Fi['decodeString'](_0x5ca8d4,!0x0);}catch(_0x33110e){console['error']('base64Decode\x20failed:\x20',_0x33110e);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x37e960){return Gr(void 0x0,_0x37e960);}function Gr(_0x185db6,_0x48c78c){if(!(_0x48c78c instanceof Object))return _0x48c78c;switch(_0x48c78c['constructor']){case Date:const _0xdd98a=_0x48c78c;return new Date(_0xdd98a['getTime']());case Object:_0x185db6===void 0x0&&(_0x185db6={});break;case Array:_0x185db6=[];break;default:return _0x48c78c;}for(const _0x301eb8 in _0x48c78c)!_0x48c78c['hasOwnProperty'](_0x301eb8)||!rc(_0x301eb8)||(_0x185db6[_0x301eb8]=Gr(_0x185db6[_0x301eb8],_0x48c78c[_0x301eb8]));return _0x185db6;}function rc(_0x857a76){return _0x857a76!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x354cc4=Ns['__FIREBASE_DEFAULTS__'];if(_0x354cc4)return JSON['parse'](_0x354cc4);},lc=()=>{if(typeof document>'u')return;let _0x14af9f;try{_0x14af9f=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x206167=_0x14af9f&&fn(_0x14af9f[0x1]);return _0x206167&&JSON['parse'](_0x206167);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x4069b4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4069b4);return;}},qr=_0x4454c8=>{var _0x258d89,_0x5420f1;return(_0x5420f1=(_0x258d89=Ui())==null?void 0x0:_0x258d89['emulatorHosts'])==null?void 0x0:_0x5420f1[_0x4454c8];},hc=_0x6f5a8c=>{const _0x5a7cd3=qr(_0x6f5a8c);if(!_0x5a7cd3)return;const _0x4ec626=_0x5a7cd3['lastIndexOf'](':');if(_0x4ec626<=0x0||_0x4ec626+0x1===_0x5a7cd3['length'])throw new Error('Invalid\x20host\x20'+_0x5a7cd3+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4d981f=parseInt(_0x5a7cd3['substring'](_0x4ec626+0x1),0xa);return _0x5a7cd3[0x0]==='['?[_0x5a7cd3['substring'](0x1,_0x4ec626-0x1),_0x4d981f]:[_0x5a7cd3['substring'](0x0,_0x4ec626),_0x4d981f];},zr=()=>{var _0x2c9873;return(_0x2c9873=Ui())==null?void 0x0:_0x2c9873['config'];},jr=_0x1069c1=>{var _0x3f7e2c;return(_0x3f7e2c=Ui())==null?void 0x0:_0x3f7e2c['_'+_0x1069c1];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3ca48b,_0x321e24)=>{this['resolve']=_0x3ca48b,this['reject']=_0x321e24;});}['wrapCallback'](_0x568890){return(_0x52c512,_0xfec49f)=>{_0x52c512?this['reject'](_0x52c512):this['resolve'](_0xfec49f),typeof _0x568890=='function'&&(this['promise']['catch'](()=>{}),_0x568890['length']===0x1?_0x568890(_0x52c512):_0x568890(_0x52c512,_0xfec49f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x33fed0,_0x460106){if(_0x33fed0['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x2ba631={'alg':'none','type':'JWT'},_0x4c930b=_0x460106||'demo-project',_0x518983=_0x33fed0['iat']||0x0,_0x3547c2=_0x33fed0['sub']||_0x33fed0['user_id'];if(!_0x3547c2)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x29a043={'iss':'https://securetoken.google.com/'+_0x4c930b,'aud':_0x4c930b,'iat':_0x518983,'exp':_0x518983+0xe10,'auth_time':_0x518983,'sub':_0x3547c2,'user_id':_0x3547c2,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x33fed0};return[dn(JSON['stringify'](_0x2ba631)),dn(JSON['stringify'](_0x29a043)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x1c02ee=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1c02ee=='object'&&_0x1c02ee['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x34e263=W();return _0x34e263['indexOf']('MSIE\x20')>=0x0||_0x34e263['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x6f0dfa,_0x183fab)=>{try{let _0x80626c=!0x0;const _0x8174f6='validate-browser-context-for-indexeddb-analytics-module',_0x2c0711=self['indexedDB']['open'](_0x8174f6);_0x2c0711['onsuccess']=()=>{_0x2c0711['result']['close'](),_0x80626c||self['indexedDB']['deleteDatabase'](_0x8174f6),_0x6f0dfa(!0x0);},_0x2c0711['onupgradeneeded']=()=>{_0x80626c=!0x1;},_0x2c0711['onerror']=()=>{var _0x39a8d7;_0x183fab(((_0x39a8d7=_0x2c0711['error'])==null?void 0x0:_0x39a8d7['message'])||'');};}catch(_0x2d82c6){_0x183fab(_0x2d82c6);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x3859e9,_0x366a05,_0x45d93a){super(_0x366a05),this['code']=_0x3859e9,this['customData']=_0x45d93a,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x3649d7,_0x3c5eb9,_0x150ad4){this['service']=_0x3649d7,this['serviceName']=_0x3c5eb9,this['errors']=_0x150ad4;}['create'](_0x4306f4,..._0x1a4f3f){const _0x5253d2=_0x1a4f3f[0x0]||{},_0x4af31d=this['service']+'/'+_0x4306f4,_0x343b6e=this['errors'][_0x4306f4],_0xbce31=_0x343b6e?vc(_0x343b6e,_0x5253d2):'Error',_0x36979e=this['serviceName']+':\x20'+_0xbce31+'\x20('+_0x4af31d+').';return new Re(_0x4af31d,_0x36979e,_0x5253d2);}}function vc(_0x553051,_0x5f58ad){return _0x553051['replace'](Ec,(_0x46aa82,_0x3cc84c)=>{const _0x572973=_0x5f58ad[_0x3cc84c];return _0x572973!=null?String(_0x572973):'<'+_0x3cc84c+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2a43b6){return JSON['parse'](_0x2a43b6);}function O(_0x288d4b){return JSON['stringify'](_0x288d4b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0xb03494){let _0x5ce9f3={},_0x3cd017={},_0x44fbbf={},_0x10429d='';try{const _0x27c8ca=_0xb03494['split']('.');_0x5ce9f3=Nt(fn(_0x27c8ca[0x0])||''),_0x3cd017=Nt(fn(_0x27c8ca[0x1])||''),_0x10429d=_0x27c8ca[0x2],_0x44fbbf=_0x3cd017['d']||{},delete _0x3cd017['d'];}catch{}return{'header':_0x5ce9f3,'claims':_0x3cd017,'data':_0x44fbbf,'signature':_0x10429d};},Ic=function(_0x4665c8){const _0x50005c=Yr(_0x4665c8),_0x121439=_0x50005c['claims'];return!!_0x121439&&typeof _0x121439=='object'&&_0x121439['hasOwnProperty']('iat');},wc=function(_0x397638){const _0x5e587d=Yr(_0x397638)['claims'];return typeof _0x5e587d=='object'&&_0x5e587d['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x472d47,_0x4e3774){return Object['prototype']['hasOwnProperty']['call'](_0x472d47,_0x4e3774);}function Me(_0x7c969b,_0x1049d8){if(Object['prototype']['hasOwnProperty']['call'](_0x7c969b,_0x1049d8))return _0x7c969b[_0x1049d8];}function pn(_0x44cc65){for(const _0x414a56 in _0x44cc65)if(Object['prototype']['hasOwnProperty']['call'](_0x44cc65,_0x414a56))return!0x1;return!0x0;}function _n(_0x219fcb,_0x40c891,_0x439c30){const _0x23272f={};for(const _0x5c75c5 in _0x219fcb)Object['prototype']['hasOwnProperty']['call'](_0x219fcb,_0x5c75c5)&&(_0x23272f[_0x5c75c5]=_0x40c891['call'](_0x439c30,_0x219fcb[_0x5c75c5],_0x5c75c5,_0x219fcb));return _0x23272f;}function Le(_0x561de3,_0x33bca6){if(_0x561de3===_0x33bca6)return!0x0;const _0x5351b1=Object['keys'](_0x561de3),_0x18783e=Object['keys'](_0x33bca6);for(const _0x5a81d2 of _0x5351b1){if(!_0x18783e['includes'](_0x5a81d2))return!0x1;const _0x2cb18e=_0x561de3[_0x5a81d2],_0x2df276=_0x33bca6[_0x5a81d2];if(Ps(_0x2cb18e)&&Ps(_0x2df276)){if(!Le(_0x2cb18e,_0x2df276))return!0x1;}else{if(_0x2cb18e!==_0x2df276)return!0x1;}}for(const _0x5f1f5b of _0x18783e)if(!_0x5351b1['includes'](_0x5f1f5b))return!0x1;return!0x0;}function Ps(_0x52fa2d){return _0x52fa2d!==null&&typeof _0x52fa2d=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x46baf7){const _0x5e5f7f=[];for(const [_0x42befe,_0x1001ee]of Object['entries'](_0x46baf7))Array['isArray'](_0x1001ee)?_0x1001ee['forEach'](_0x363edc=>{_0x5e5f7f['push'](encodeURIComponent(_0x42befe)+'='+encodeURIComponent(_0x363edc));}):_0x5e5f7f['push'](encodeURIComponent(_0x42befe)+'='+encodeURIComponent(_0x1001ee));return _0x5e5f7f['length']?'&'+_0x5e5f7f['join']('&'):'';}function wt(_0x2aeaaf){const _0x471ff9={};return _0x2aeaaf['replace'](/^\?/,'')['split']('&')['forEach'](_0x3c66f9=>{if(_0x3c66f9){const [_0xf29bb4,_0x4a80dd]=_0x3c66f9['split']('=');_0x471ff9[decodeURIComponent(_0xf29bb4)]=decodeURIComponent(_0x4a80dd);}}),_0x471ff9;}function Ct(_0x24ed97){const _0xbe167=_0x24ed97['indexOf']('?');if(!_0xbe167)return'';const _0x1fb1f9=_0x24ed97['indexOf']('#',_0xbe167);return _0x24ed97['substring'](_0xbe167,_0x1fb1f9>0x0?_0x1fb1f9:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4ba1bf=0x1;_0x4ba1bf<this['blockSize'];++_0x4ba1bf)this['pad_'][_0x4ba1bf]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x775f53,_0x3f032a){_0x3f032a||(_0x3f032a=0x0);const _0x4e7fa9=this['W_'];if(typeof _0x775f53=='string'){for(let _0xd68fc3=0x0;_0xd68fc3<0x10;_0xd68fc3++)_0x4e7fa9[_0xd68fc3]=_0x775f53['charCodeAt'](_0x3f032a)<<0x18|_0x775f53['charCodeAt'](_0x3f032a+0x1)<<0x10|_0x775f53['charCodeAt'](_0x3f032a+0x2)<<0x8|_0x775f53['charCodeAt'](_0x3f032a+0x3),_0x3f032a+=0x4;}else{for(let _0x23ae9a=0x0;_0x23ae9a<0x10;_0x23ae9a++)_0x4e7fa9[_0x23ae9a]=_0x775f53[_0x3f032a]<<0x18|_0x775f53[_0x3f032a+0x1]<<0x10|_0x775f53[_0x3f032a+0x2]<<0x8|_0x775f53[_0x3f032a+0x3],_0x3f032a+=0x4;}for(let _0x128a5c=0x10;_0x128a5c<0x50;_0x128a5c++){const _0xb22aaa=_0x4e7fa9[_0x128a5c-0x3]^_0x4e7fa9[_0x128a5c-0x8]^_0x4e7fa9[_0x128a5c-0xe]^_0x4e7fa9[_0x128a5c-0x10];_0x4e7fa9[_0x128a5c]=(_0xb22aaa<<0x1|_0xb22aaa>>>0x1f)&0xffffffff;}let _0x22a6d1=this['chain_'][0x0],_0x5c7c31=this['chain_'][0x1],_0x2631c5=this['chain_'][0x2],_0x1577de=this['chain_'][0x3],_0x4f9fe4=this['chain_'][0x4],_0x5c13fc,_0x5d8155;for(let _0x255f9=0x0;_0x255f9<0x50;_0x255f9++){_0x255f9<0x28?_0x255f9<0x14?(_0x5c13fc=_0x1577de^_0x5c7c31&(_0x2631c5^_0x1577de),_0x5d8155=0x5a827999):(_0x5c13fc=_0x5c7c31^_0x2631c5^_0x1577de,_0x5d8155=0x6ed9eba1):_0x255f9<0x3c?(_0x5c13fc=_0x5c7c31&_0x2631c5|_0x1577de&(_0x5c7c31|_0x2631c5),_0x5d8155=0x8f1bbcdc):(_0x5c13fc=_0x5c7c31^_0x2631c5^_0x1577de,_0x5d8155=0xca62c1d6);const _0x4e6ff2=(_0x22a6d1<<0x5|_0x22a6d1>>>0x1b)+_0x5c13fc+_0x4f9fe4+_0x5d8155+_0x4e7fa9[_0x255f9]&0xffffffff;_0x4f9fe4=_0x1577de,_0x1577de=_0x2631c5,_0x2631c5=(_0x5c7c31<<0x1e|_0x5c7c31>>>0x2)&0xffffffff,_0x5c7c31=_0x22a6d1,_0x22a6d1=_0x4e6ff2;}this['chain_'][0x0]=this['chain_'][0x0]+_0x22a6d1&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5c7c31&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2631c5&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1577de&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4f9fe4&0xffffffff;}['update'](_0x250862,_0x996d3c){if(_0x250862==null)return;_0x996d3c===void 0x0&&(_0x996d3c=_0x250862['length']);const _0x2afaf1=_0x996d3c-this['blockSize'];let _0x2ed809=0x0;const _0x1f1268=this['buf_'];let _0x1478c0=this['inbuf_'];for(;_0x2ed809<_0x996d3c;){if(_0x1478c0===0x0){for(;_0x2ed809<=_0x2afaf1;)this['compress_'](_0x250862,_0x2ed809),_0x2ed809+=this['blockSize'];}if(typeof _0x250862=='string'){for(;_0x2ed809<_0x996d3c;)if(_0x1f1268[_0x1478c0]=_0x250862['charCodeAt'](_0x2ed809),++_0x1478c0,++_0x2ed809,_0x1478c0===this['blockSize']){this['compress_'](_0x1f1268),_0x1478c0=0x0;break;}}else{for(;_0x2ed809<_0x996d3c;)if(_0x1f1268[_0x1478c0]=_0x250862[_0x2ed809],++_0x1478c0,++_0x2ed809,_0x1478c0===this['blockSize']){this['compress_'](_0x1f1268),_0x1478c0=0x0;break;}}}this['inbuf_']=_0x1478c0,this['total_']+=_0x996d3c;}['digest'](){const _0x793a91=[];let _0x19ba20=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x119984=this['blockSize']-0x1;_0x119984>=0x38;_0x119984--)this['buf_'][_0x119984]=_0x19ba20&0xff,_0x19ba20/=0x100;this['compress_'](this['buf_']);let _0x2acca7=0x0;for(let _0x1b703b=0x0;_0x1b703b<0x5;_0x1b703b++)for(let _0x4e6727=0x18;_0x4e6727>=0x0;_0x4e6727-=0x8)_0x793a91[_0x2acca7]=this['chain_'][_0x1b703b]>>_0x4e6727&0xff,++_0x2acca7;return _0x793a91;}}function Tc(_0x1b6d18,_0x3649e5){const _0x14c481=new Sc(_0x1b6d18,_0x3649e5);return _0x14c481['subscribe']['bind'](_0x14c481);}class Sc{constructor(_0x3a30b9,_0x518577){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x518577,this['task']['then'](()=>{_0x3a30b9(this);})['catch'](_0x3e21c1=>{this['error'](_0x3e21c1);});}['next'](_0x473158){this['forEachObserver'](_0x16d3ce=>{_0x16d3ce['next'](_0x473158);});}['error'](_0x18f54c){this['forEachObserver'](_0x34681f=>{_0x34681f['error'](_0x18f54c);}),this['close'](_0x18f54c);}['complete'](){this['forEachObserver'](_0x5453a6=>{_0x5453a6['complete']();}),this['close']();}['subscribe'](_0x2cc090,_0x3bb7ea,_0x3fc53c){let _0x2f9bc2;if(_0x2cc090===void 0x0&&_0x3bb7ea===void 0x0&&_0x3fc53c===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2cc090,['next','error','complete'])?_0x2f9bc2=_0x2cc090:_0x2f9bc2={'next':_0x2cc090,'error':_0x3bb7ea,'complete':_0x3fc53c},_0x2f9bc2['next']===void 0x0&&(_0x2f9bc2['next']=ti),_0x2f9bc2['error']===void 0x0&&(_0x2f9bc2['error']=ti),_0x2f9bc2['complete']===void 0x0&&(_0x2f9bc2['complete']=ti);const _0x413f61=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2f9bc2['error'](this['finalError']):_0x2f9bc2['complete']();}catch{}}),this['observers']['push'](_0x2f9bc2),_0x413f61;}['unsubscribeOne'](_0xe39246){this['observers']===void 0x0||this['observers'][_0xe39246]===void 0x0||(delete this['observers'][_0xe39246],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1b4e44){if(!this['finalized']){for(let _0x18389d=0x0;_0x18389d<this['observers']['length'];_0x18389d++)this['sendOne'](_0x18389d,_0x1b4e44);}}['sendOne'](_0x4d3edf,_0x297da6){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4d3edf]!==void 0x0)try{_0x297da6(this['observers'][_0x4d3edf]);}catch(_0x2a7947){typeof console<'u'&&console['error']&&console['error'](_0x2a7947);}});}['close'](_0x2fd078){this['finalized']||(this['finalized']=!0x0,_0x2fd078!==void 0x0&&(this['finalError']=_0x2fd078),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5b014e,_0x420aa7){if(typeof _0x5b014e!='object'||_0x5b014e===null)return!0x1;for(const _0x2aa67f of _0x420aa7)if(_0x2aa67f in _0x5b014e&&typeof _0x5b014e[_0x2aa67f]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1be9ef,_0x1db6ad){return _0x1be9ef+'\x20failed:\x20'+_0x1db6ad+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x40588c){const _0x3fb20f=[];let _0x57dc8e=0x0;for(let _0x22b44b=0x0;_0x22b44b<_0x40588c['length'];_0x22b44b++){let _0x5de4ac=_0x40588c['charCodeAt'](_0x22b44b);if(_0x5de4ac>=0xd800&&_0x5de4ac<=0xdbff){const _0x2f40eb=_0x5de4ac-0xd800;_0x22b44b++,f(_0x22b44b<_0x40588c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x246241=_0x40588c['charCodeAt'](_0x22b44b)-0xdc00;_0x5de4ac=0x10000+(_0x2f40eb<<0xa)+_0x246241;}_0x5de4ac<0x80?_0x3fb20f[_0x57dc8e++]=_0x5de4ac:_0x5de4ac<0x800?(_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0x6|0xc0,_0x3fb20f[_0x57dc8e++]=_0x5de4ac&0x3f|0x80):_0x5de4ac<0x10000?(_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0xc|0xe0,_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0x6&0x3f|0x80,_0x3fb20f[_0x57dc8e++]=_0x5de4ac&0x3f|0x80):(_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0x12|0xf0,_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0xc&0x3f|0x80,_0x3fb20f[_0x57dc8e++]=_0x5de4ac>>0x6&0x3f|0x80,_0x3fb20f[_0x57dc8e++]=_0x5de4ac&0x3f|0x80);}return _0x3fb20f;},Ln=function(_0x14a670){let _0x1fc9d2=0x0;for(let _0x1666a7=0x0;_0x1666a7<_0x14a670['length'];_0x1666a7++){const _0x193f34=_0x14a670['charCodeAt'](_0x1666a7);_0x193f34<0x80?_0x1fc9d2++:_0x193f34<0x800?_0x1fc9d2+=0x2:_0x193f34>=0xd800&&_0x193f34<=0xdbff?(_0x1fc9d2+=0x4,_0x1666a7++):_0x1fc9d2+=0x3;}return _0x1fc9d2;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x1b4af1){return _0x1b4af1&&_0x1b4af1['_delegate']?_0x1b4af1['_delegate']:_0x1b4af1;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x4cd1d2){try{return(_0x4cd1d2['startsWith']('http://')||_0x4cd1d2['startsWith']('https://')?new URL(_0x4cd1d2)['hostname']:_0x4cd1d2)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x4ea561){return(await fetch(_0x4ea561,{'credentials':'include'}))['ok'];}class xe{constructor(_0x2b5c26,_0x548ffe,_0x11944a){this['name']=_0x2b5c26,this['instanceFactory']=_0x548ffe,this['type']=_0x11944a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x55e471){return this['instantiationMode']=_0x55e471,this;}['setMultipleInstances'](_0x567ad9){return this['multipleInstances']=_0x567ad9,this;}['setServiceProps'](_0x3208bd){return this['serviceProps']=_0x3208bd,this;}['setInstanceCreatedCallback'](_0x46bd08){return this['onInstanceCreated']=_0x46bd08,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x27f73b,_0x9e83aa){this['name']=_0x27f73b,this['container']=_0x9e83aa,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x68eef3){const _0x3d71e9=this['normalizeInstanceIdentifier'](_0x68eef3);if(!this['instancesDeferred']['has'](_0x3d71e9)){const _0x349643=new H();if(this['instancesDeferred']['set'](_0x3d71e9,_0x349643),this['isInitialized'](_0x3d71e9)||this['shouldAutoInitialize']())try{const _0x411681=this['getOrInitializeService']({'instanceIdentifier':_0x3d71e9});_0x411681&&_0x349643['resolve'](_0x411681);}catch{}}return this['instancesDeferred']['get'](_0x3d71e9)['promise'];}['getImmediate'](_0x5ab93f){const _0x34ab05=this['normalizeInstanceIdentifier'](_0x5ab93f==null?void 0x0:_0x5ab93f['identifier']),_0x5e2186=(_0x5ab93f==null?void 0x0:_0x5ab93f['optional'])??!0x1;if(this['isInitialized'](_0x34ab05)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x34ab05});}catch(_0x585b78){if(_0x5e2186)return null;throw _0x585b78;}else{if(_0x5e2186)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x525ea4){if(_0x525ea4['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x525ea4['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x525ea4,!!this['shouldAutoInitialize']()){if(Nc(_0x525ea4))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x5a1fb7,_0x54dd53]of this['instancesDeferred']['entries']()){const _0xa58aed=this['normalizeInstanceIdentifier'](_0x5a1fb7);try{const _0x1e599c=this['getOrInitializeService']({'instanceIdentifier':_0xa58aed});_0x54dd53['resolve'](_0x1e599c);}catch{}}}}['clearInstance'](_0x1a23c6=Ne){this['instancesDeferred']['delete'](_0x1a23c6),this['instancesOptions']['delete'](_0x1a23c6),this['instances']['delete'](_0x1a23c6);}async['delete'](){const _0x5885ac=Array['from'](this['instances']['values']());await Promise['all']([..._0x5885ac['filter'](_0x4c4a77=>'INTERNAL'in _0x4c4a77)['map'](_0x1d91f6=>_0x1d91f6['INTERNAL']['delete']()),..._0x5885ac['filter'](_0x24bd40=>'_delete'in _0x24bd40)['map'](_0x18b650=>_0x18b650['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x17c8d2=Ne){return this['instances']['has'](_0x17c8d2);}['getOptions'](_0xa84707=Ne){return this['instancesOptions']['get'](_0xa84707)||{};}['initialize'](_0x3eea2d={}){const {options:_0x5dcc2d={}}=_0x3eea2d,_0x1594ce=this['normalizeInstanceIdentifier'](_0x3eea2d['instanceIdentifier']);if(this['isInitialized'](_0x1594ce))throw Error(this['name']+'('+_0x1594ce+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4c5ad7=this['getOrInitializeService']({'instanceIdentifier':_0x1594ce,'options':_0x5dcc2d});for(const [_0x223ab0,_0x1d076d]of this['instancesDeferred']['entries']()){const _0x19ffbb=this['normalizeInstanceIdentifier'](_0x223ab0);_0x1594ce===_0x19ffbb&&_0x1d076d['resolve'](_0x4c5ad7);}return _0x4c5ad7;}['onInit'](_0x3934de,_0x2413dd){const _0x49c924=this['normalizeInstanceIdentifier'](_0x2413dd),_0x3273b6=this['onInitCallbacks']['get'](_0x49c924)??new Set();_0x3273b6['add'](_0x3934de),this['onInitCallbacks']['set'](_0x49c924,_0x3273b6);const _0x255fc5=this['instances']['get'](_0x49c924);return _0x255fc5&&_0x3934de(_0x255fc5,_0x49c924),()=>{_0x3273b6['delete'](_0x3934de);};}['invokeOnInitCallbacks'](_0x1d63a4,_0x5ec90b){const _0x1c8edf=this['onInitCallbacks']['get'](_0x5ec90b);if(_0x1c8edf){for(const _0x3ce183 of _0x1c8edf)try{_0x3ce183(_0x1d63a4,_0x5ec90b);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x9f539d,options:_0x3ce28f={}}){let _0x13753a=this['instances']['get'](_0x9f539d);if(!_0x13753a&&this['component']&&(_0x13753a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x9f539d),'options':_0x3ce28f}),this['instances']['set'](_0x9f539d,_0x13753a),this['instancesOptions']['set'](_0x9f539d,_0x3ce28f),this['invokeOnInitCallbacks'](_0x13753a,_0x9f539d),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x9f539d,_0x13753a);}catch{}return _0x13753a||null;}['normalizeInstanceIdentifier'](_0x4b0719=Ne){return this['component']?this['component']['multipleInstances']?_0x4b0719:Ne:_0x4b0719;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2a4b0f){return _0x2a4b0f===Ne?void 0x0:_0x2a4b0f;}function Nc(_0x309c2a){return _0x309c2a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x10422f){this['name']=_0x10422f,this['providers']=new Map();}['addComponent'](_0x98c616){const _0xab65e1=this['getProvider'](_0x98c616['name']);if(_0xab65e1['isComponentSet']())throw new Error('Component\x20'+_0x98c616['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xab65e1['setComponent'](_0x98c616);}['addOrOverwriteComponent'](_0xbf96da){this['getProvider'](_0xbf96da['name'])['isComponentSet']()&&this['providers']['delete'](_0xbf96da['name']),this['addComponent'](_0xbf96da);}['getProvider'](_0x1c5e2d){if(this['providers']['has'](_0x1c5e2d))return this['providers']['get'](_0x1c5e2d);const _0x3586ac=new Ac(_0x1c5e2d,this);return this['providers']['set'](_0x1c5e2d,_0x3586ac),_0x3586ac;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x34e4bb){_0x34e4bb[_0x34e4bb['DEBUG']=0x0]='DEBUG',_0x34e4bb[_0x34e4bb['VERBOSE']=0x1]='VERBOSE',_0x34e4bb[_0x34e4bb['INFO']=0x2]='INFO',_0x34e4bb[_0x34e4bb['WARN']=0x3]='WARN',_0x34e4bb[_0x34e4bb['ERROR']=0x4]='ERROR',_0x34e4bb[_0x34e4bb['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4383dd,_0x91b679,..._0x547978)=>{if(_0x91b679<_0x4383dd['logLevel'])return;const _0x4702b4=new Date()['toISOString'](),_0x4beb8e=Mc[_0x91b679];if(_0x4beb8e)console[_0x4beb8e]('['+_0x4702b4+']\x20\x20'+_0x4383dd['name']+':',..._0x547978);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x91b679+')');};class Bi{constructor(_0x9f9eff){this['name']=_0x9f9eff,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3d5744){if(!(_0x3d5744 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3d5744+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3d5744;}['setLogLevel'](_0x2cb22e){this['_logLevel']=typeof _0x2cb22e=='string'?Oc[_0x2cb22e]:_0x2cb22e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4a29b3){if(typeof _0x4a29b3!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4a29b3;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4a0a45){this['_userLogHandler']=_0x4a0a45;}['debug'](..._0x275408){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x275408),this['_logHandler'](this,T['DEBUG'],..._0x275408);}['log'](..._0x25dd0e){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x25dd0e),this['_logHandler'](this,T['VERBOSE'],..._0x25dd0e);}['info'](..._0x320747){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x320747),this['_logHandler'](this,T['INFO'],..._0x320747);}['warn'](..._0x24e37d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x24e37d),this['_logHandler'](this,T['WARN'],..._0x24e37d);}['error'](..._0x248f1e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x248f1e),this['_logHandler'](this,T['ERROR'],..._0x248f1e);}}const xc=(_0x164dcb,_0x506a85)=>_0x506a85['some'](_0x40d127=>_0x164dcb instanceof _0x40d127);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x5a3966){const _0x15dee5=new Promise((_0x39398f,_0x59108e)=>{const _0x57adf3=()=>{_0x5a3966['removeEventListener']('success',_0x4ee461),_0x5a3966['removeEventListener']('error',_0x7cebb);},_0x4ee461=()=>{_0x39398f(ge(_0x5a3966['result'])),_0x57adf3();},_0x7cebb=()=>{_0x59108e(_0x5a3966['error']),_0x57adf3();};_0x5a3966['addEventListener']('success',_0x4ee461),_0x5a3966['addEventListener']('error',_0x7cebb);});return _0x15dee5['then'](_0x821055=>{_0x821055 instanceof IDBCursor&&Jr['set'](_0x821055,_0x5a3966);})['catch'](()=>{}),Vi['set'](_0x15dee5,_0x5a3966),_0x15dee5;}function Bc(_0x610c77){if(_i['has'](_0x610c77))return;const _0x10cbb7=new Promise((_0xbc52b4,_0x397c5b)=>{const _0x68f139=()=>{_0x610c77['removeEventListener']('complete',_0x2a43c4),_0x610c77['removeEventListener']('error',_0x3c6e5),_0x610c77['removeEventListener']('abort',_0x3c6e5);},_0x2a43c4=()=>{_0xbc52b4(),_0x68f139();},_0x3c6e5=()=>{_0x397c5b(_0x610c77['error']||new DOMException('AbortError','AbortError')),_0x68f139();};_0x610c77['addEventListener']('complete',_0x2a43c4),_0x610c77['addEventListener']('error',_0x3c6e5),_0x610c77['addEventListener']('abort',_0x3c6e5);});_i['set'](_0x610c77,_0x10cbb7);}let gi={'get'(_0x46a149,_0x28d2fb,_0x52a46f){if(_0x46a149 instanceof IDBTransaction){if(_0x28d2fb==='done')return _i['get'](_0x46a149);if(_0x28d2fb==='objectStoreNames')return _0x46a149['objectStoreNames']||Xr['get'](_0x46a149);if(_0x28d2fb==='store')return _0x52a46f['objectStoreNames'][0x1]?void 0x0:_0x52a46f['objectStore'](_0x52a46f['objectStoreNames'][0x0]);}return ge(_0x46a149[_0x28d2fb]);},'set'(_0x2330f2,_0x703798,_0x46dadb){return _0x2330f2[_0x703798]=_0x46dadb,!0x0;},'has'(_0x48151a,_0x27539f){return _0x48151a instanceof IDBTransaction&&(_0x27539f==='done'||_0x27539f==='store')?!0x0:_0x27539f in _0x48151a;}};function Vc(_0x518281){gi=_0x518281(gi);}function Hc(_0x328c39){return _0x328c39===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x6b810a,..._0xb8fd4e){const _0x1d2d75=_0x328c39['call'](ii(this),_0x6b810a,..._0xb8fd4e);return Xr['set'](_0x1d2d75,_0x6b810a['sort']?_0x6b810a['sort']():[_0x6b810a]),ge(_0x1d2d75);}:Uc()['includes'](_0x328c39)?function(..._0x45858c){return _0x328c39['apply'](ii(this),_0x45858c),ge(Jr['get'](this));}:function(..._0xd1581b){return ge(_0x328c39['apply'](ii(this),_0xd1581b));};}function $c(_0x2156e1){return typeof _0x2156e1=='function'?Hc(_0x2156e1):(_0x2156e1 instanceof IDBTransaction&&Bc(_0x2156e1),xc(_0x2156e1,Fc())?new Proxy(_0x2156e1,gi):_0x2156e1);}function ge(_0x42b480){if(_0x42b480 instanceof IDBRequest)return Wc(_0x42b480);if(ni['has'](_0x42b480))return ni['get'](_0x42b480);const _0xfad6f4=$c(_0x42b480);return _0xfad6f4!==_0x42b480&&(ni['set'](_0x42b480,_0xfad6f4),Vi['set'](_0xfad6f4,_0x42b480)),_0xfad6f4;}const ii=_0x54b5cb=>Vi['get'](_0x54b5cb);function Gc(_0x14a335,_0x5d99a8,{blocked:_0x38c034,upgrade:_0x545e20,blocking:_0x2049b5,terminated:_0xef6d7}={}){const _0x31ff87=indexedDB['open'](_0x14a335,_0x5d99a8),_0x1e2823=ge(_0x31ff87);return _0x545e20&&_0x31ff87['addEventListener']('upgradeneeded',_0x3c0103=>{_0x545e20(ge(_0x31ff87['result']),_0x3c0103['oldVersion'],_0x3c0103['newVersion'],ge(_0x31ff87['transaction']),_0x3c0103);}),_0x38c034&&_0x31ff87['addEventListener']('blocked',_0x3ab934=>_0x38c034(_0x3ab934['oldVersion'],_0x3ab934['newVersion'],_0x3ab934)),_0x1e2823['then'](_0x1963e0=>{_0xef6d7&&_0x1963e0['addEventListener']('close',()=>_0xef6d7()),_0x2049b5&&_0x1963e0['addEventListener']('versionchange',_0x391705=>_0x2049b5(_0x391705['oldVersion'],_0x391705['newVersion'],_0x391705));})['catch'](()=>{}),_0x1e2823;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x436094,_0x4c877e){if(!(_0x436094 instanceof IDBDatabase&&!(_0x4c877e in _0x436094)&&typeof _0x4c877e=='string'))return;if(si['get'](_0x4c877e))return si['get'](_0x4c877e);const _0x5f5bc2=_0x4c877e['replace'](/FromIndex$/,''),_0x3a0160=_0x4c877e!==_0x5f5bc2,_0x412a27=zc['includes'](_0x5f5bc2);if(!(_0x5f5bc2 in(_0x3a0160?IDBIndex:IDBObjectStore)['prototype'])||!(_0x412a27||qc['includes'](_0x5f5bc2)))return;const _0x128453=async function(_0x311a0c,..._0x5f3df3){const _0xd677a=this['transaction'](_0x311a0c,_0x412a27?'readwrite':'readonly');let _0x4c3280=_0xd677a['store'];return _0x3a0160&&(_0x4c3280=_0x4c3280['index'](_0x5f3df3['shift']())),(await Promise['all']([_0x4c3280[_0x5f5bc2](..._0x5f3df3),_0x412a27&&_0xd677a['done']]))[0x0];};return si['set'](_0x4c877e,_0x128453),_0x128453;}Vc(_0x437eeb=>({..._0x437eeb,'get':(_0x22dbfc,_0x50b6de,_0x25a657)=>Ms(_0x22dbfc,_0x50b6de)||_0x437eeb['get'](_0x22dbfc,_0x50b6de,_0x25a657),'has':(_0x39f5f0,_0x1c30b3)=>!!Ms(_0x39f5f0,_0x1c30b3)||_0x437eeb['has'](_0x39f5f0,_0x1c30b3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1bfc1b){this['container']=_0x1bfc1b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1571ff=>{if(Kc(_0x1571ff)){const _0x414f1e=_0x1571ff['getImmediate']();return _0x414f1e['library']+'/'+_0x414f1e['version'];}else return null;})['filter'](_0x2cb1cd=>_0x2cb1cd)['join']('\x20');}}function Kc(_0x1b8c17){const _0x596f3b=_0x1b8c17['getComponent']();return(_0x596f3b==null?void 0x0:_0x596f3b['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x51d563,_0x4c903a){try{_0x51d563['container']['addComponent'](_0x4c903a);}catch(_0x3c2fe5){oe['debug']('Component\x20'+_0x4c903a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x51d563['name'],_0x3c2fe5);}}function st(_0x46d0af){const _0x4697e8=_0x46d0af['name'];if(Ei['has'](_0x4697e8))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4697e8+'.'),!0x1;Ei['set'](_0x4697e8,_0x46d0af);for(const _0x50a98c of Fe['values']())xs(_0x50a98c,_0x46d0af);for(const _0x22ea71 of vi['values']())xs(_0x22ea71,_0x46d0af);return!0x0;}function Hi(_0x1f3c58,_0x23a907){const _0x63a963=_0x1f3c58['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x63a963&&_0x63a963['triggerHeartbeat'](),_0x1f3c58['container']['getProvider'](_0x23a907);}function $(_0x310400){return _0x310400==null?!0x1:_0x310400['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5e2d3d,_0x457d77,_0x27a012){this['_isDeleted']=!0x1,this['_options']={..._0x5e2d3d},this['_config']={..._0x457d77},this['_name']=_0x457d77['name'],this['_automaticDataCollectionEnabled']=_0x457d77['automaticDataCollectionEnabled'],this['_container']=_0x27a012,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1d981b){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1d981b;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x59ee8c){this['_isDeleted']=_0x59ee8c;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1b2762,_0x2576da={}){let _0x1d721b=_0x1b2762;typeof _0x2576da!='object'&&(_0x2576da={'name':_0x2576da});const _0x30543a={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x2576da},_0x137609=_0x30543a['name'];if(typeof _0x137609!='string'||!_0x137609)throw me['create']('bad-app-name',{'appName':String(_0x137609)});if(_0x1d721b||(_0x1d721b=zr()),!_0x1d721b)throw me['create']('no-options');const _0x312222=Fe['get'](_0x137609);if(_0x312222){if(Le(_0x1d721b,_0x312222['options'])&&Le(_0x30543a,_0x312222['config']))return _0x312222;throw me['create']('duplicate-app',{'appName':_0x137609});}const _0x5aa37b=new Pc(_0x137609);for(const _0x5f1de9 of Ei['values']())_0x5aa37b['addComponent'](_0x5f1de9);const _0x3a25a4=new Tl(_0x1d721b,_0x30543a,_0x5aa37b);return Fe['set'](_0x137609,_0x3a25a4),_0x3a25a4;}function Zr(_0x59ec31=yi){const _0x1d4773=Fe['get'](_0x59ec31);if(!_0x1d4773&&_0x59ec31===yi&&zr())return Sl();if(!_0x1d4773)throw me['create']('no-app',{'appName':_0x59ec31});return _0x1d4773;}function p_(){return Array['from'](Fe['values']());}async function __(_0x63dfbc){let _0x2c35f4=!0x1;const _0x18cfe1=_0x63dfbc['name'];Fe['has'](_0x18cfe1)?(_0x2c35f4=!0x0,Fe['delete'](_0x18cfe1)):vi['has'](_0x18cfe1)&&_0x63dfbc['decRefCount']()<=0x0&&(vi['delete'](_0x18cfe1),_0x2c35f4=!0x0),_0x2c35f4&&(await Promise['all'](_0x63dfbc['container']['getProviders']()['map'](_0x45f3fc=>_0x45f3fc['delete']())),_0x63dfbc['isDeleted']=!0x0);}function ye(_0x847c62,_0x5d08bb,_0x5818de){let _0xc96cec=wl[_0x847c62]??_0x847c62;_0x5818de&&(_0xc96cec+='-'+_0x5818de);const _0x10c3c5=_0xc96cec['match'](/\s|\//),_0x4a3330=_0x5d08bb['match'](/\s|\//);if(_0x10c3c5||_0x4a3330){const _0x1b9389=['Unable\x20to\x20register\x20library\x20\x22'+_0xc96cec+'\x22\x20with\x20version\x20\x22'+_0x5d08bb+'\x22:'];_0x10c3c5&&_0x1b9389['push']('library\x20name\x20\x22'+_0xc96cec+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x10c3c5&&_0x4a3330&&_0x1b9389['push']('and'),_0x4a3330&&_0x1b9389['push']('version\x20name\x20\x22'+_0x5d08bb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1b9389['join']('\x20'));return;}st(new xe(_0xc96cec+'-version',()=>({'library':_0xc96cec,'version':_0x5d08bb}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x27dd7e,_0x5c4d16)=>{switch(_0x5c4d16){case 0x0:try{_0x27dd7e['createObjectStore'](Pt);}catch(_0x42c553){console['warn'](_0x42c553);}}}})['catch'](_0xc044f3=>{throw me['create']('idb-open',{'originalErrorMessage':_0xc044f3['message']});})),ri;}async function Al(_0xdf7886){try{const _0x4bbb43=(await eo())['transaction'](Pt),_0x51b9fd=await _0x4bbb43['objectStore'](Pt)['get'](to(_0xdf7886));return await _0x4bbb43['done'],_0x51b9fd;}catch(_0x9104ee){if(_0x9104ee instanceof Re)oe['warn'](_0x9104ee['message']);else{const _0x3e02ff=me['create']('idb-get',{'originalErrorMessage':_0x9104ee==null?void 0x0:_0x9104ee['message']});oe['warn'](_0x3e02ff['message']);}}}async function Fs(_0x4916e2,_0x83f5d){try{const _0x2c8616=(await eo())['transaction'](Pt,'readwrite');await _0x2c8616['objectStore'](Pt)['put'](_0x83f5d,to(_0x4916e2)),await _0x2c8616['done'];}catch(_0x257a46){if(_0x257a46 instanceof Re)oe['warn'](_0x257a46['message']);else{const _0x52ee1e=me['create']('idb-set',{'originalErrorMessage':_0x257a46==null?void 0x0:_0x257a46['message']});oe['warn'](_0x52ee1e['message']);}}}function to(_0x4dafda){return _0x4dafda['name']+'!'+_0x4dafda['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x3670a9){this['container']=_0x3670a9,this['_heartbeatsCache']=null;const _0x4aff49=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4aff49),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1ea212=>(this['_heartbeatsCache']=_0x1ea212,_0x1ea212));}async['triggerHeartbeat'](){var _0x35e832,_0x490f54;try{const _0x389bd3=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3b2dc1=Us();if(((_0x35e832=this['_heartbeatsCache'])==null?void 0x0:_0x35e832['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x490f54=this['_heartbeatsCache'])==null?void 0x0:_0x490f54['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3b2dc1||this['_heartbeatsCache']['heartbeats']['some'](_0xf6eebe=>_0xf6eebe['date']===_0x3b2dc1))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3b2dc1,'agent':_0x389bd3}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x1847bc=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1847bc,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x58af5c){oe['warn'](_0x58af5c);}}async['getHeartbeatsHeader'](){var _0x2b5d51;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x2b5d51=this['_heartbeatsCache'])==null?void 0x0:_0x2b5d51['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x51eab1=Us(),{heartbeatsToSend:_0x101932,unsentEntries:_0x28f815}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3e65aa=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x101932}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x51eab1,_0x28f815['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x28f815,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3e65aa;}catch(_0x385c89){return oe['warn'](_0x385c89),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x96dfe0,_0x104fbb=kl){const _0x32ee64=[];let _0x1f3da8=_0x96dfe0['slice']();for(const _0xa8d01e of _0x96dfe0){const _0x5b05dc=_0x32ee64['find'](_0x128758=>_0x128758['agent']===_0xa8d01e['agent']);if(_0x5b05dc){if(_0x5b05dc['dates']['push'](_0xa8d01e['date']),Ws(_0x32ee64)>_0x104fbb){_0x5b05dc['dates']['pop']();break;}}else{if(_0x32ee64['push']({'agent':_0xa8d01e['agent'],'dates':[_0xa8d01e['date']]}),Ws(_0x32ee64)>_0x104fbb){_0x32ee64['pop']();break;}}_0x1f3da8=_0x1f3da8['slice'](0x1);}return{'heartbeatsToSend':_0x32ee64,'unsentEntries':_0x1f3da8};}class Dl{constructor(_0x1cad16){this['app']=_0x1cad16,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3f70e1=await Al(this['app']);return _0x3f70e1!=null&&_0x3f70e1['heartbeats']?_0x3f70e1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3652ee){if(await this['_canUseIndexedDBPromise']){const _0xb8ecb=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3652ee['lastSentHeartbeatDate']??_0xb8ecb['lastSentHeartbeatDate'],'heartbeats':_0x3652ee['heartbeats']});}else return;}async['add'](_0x2beb91){if(await this['_canUseIndexedDBPromise']){const _0x1c697b=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2beb91['lastSentHeartbeatDate']??_0x1c697b['lastSentHeartbeatDate'],'heartbeats':[..._0x1c697b['heartbeats'],..._0x2beb91['heartbeats']]});}else return;}}function Ws(_0x36e080){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x36e080}))['length'];}function Ml(_0x57fea7){if(_0x57fea7['length']===0x0)return-0x1;let _0x22ad86=0x0,_0x55cd4a=_0x57fea7[0x0]['date'];for(let _0x4e3bea=0x1;_0x4e3bea<_0x57fea7['length'];_0x4e3bea++)_0x57fea7[_0x4e3bea]['date']<_0x55cd4a&&(_0x55cd4a=_0x57fea7[_0x4e3bea]['date'],_0x22ad86=_0x4e3bea);return _0x22ad86;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x24a231){st(new xe('platform-logger',_0x4fa4b9=>new jc(_0x4fa4b9),'PRIVATE')),st(new xe('heartbeat',_0x1bda9a=>new Pl(_0x1bda9a),'PRIVATE')),ye(mi,Ls,_0x24a231),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2db062){no=_0x2db062;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1514f5){this['domStorage_']=_0x1514f5,this['prefix_']='firebase:';}['set'](_0x2419a5,_0x125abd){_0x125abd==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2419a5)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2419a5),O(_0x125abd));}['get'](_0x8bd569){const _0xc1e72f=this['domStorage_']['getItem'](this['prefixedName_'](_0x8bd569));return _0xc1e72f==null?null:Nt(_0xc1e72f);}['remove'](_0x499e96){this['domStorage_']['removeItem'](this['prefixedName_'](_0x499e96));}['prefixedName_'](_0x36c4c1){return this['prefix_']+_0x36c4c1;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0xa29d6f,_0x30e191){_0x30e191==null?delete this['cache_'][_0xa29d6f]:this['cache_'][_0xa29d6f]=_0x30e191;}['get'](_0x5cc583){return Q(this['cache_'],_0x5cc583)?this['cache_'][_0x5cc583]:null;}['remove'](_0x3a396f){delete this['cache_'][_0x3a396f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x27a9d5){try{if(typeof window<'u'&&typeof window[_0x27a9d5]<'u'){const _0x21b9b1=window[_0x27a9d5];return _0x21b9b1['setItem']('firebase:sentinel','cache'),_0x21b9b1['removeItem']('firebase:sentinel'),new Wl(_0x21b9b1);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x582413=0x1;return function(){return _0x582413++;};}()),ro=function(_0x3167ac){const _0x2a023a=Rc(_0x3167ac),_0xa40e08=new Cc();_0xa40e08['update'](_0x2a023a);const _0xa525e1=_0xa40e08['digest']();return Fi['encodeByteArray'](_0xa525e1);},qt=function(..._0x1504d7){let _0xbe12a0='';for(let _0x2ab63e=0x0;_0x2ab63e<_0x1504d7['length'];_0x2ab63e++){const _0x2297ba=_0x1504d7[_0x2ab63e];Array['isArray'](_0x2297ba)||_0x2297ba&&typeof _0x2297ba=='object'&&typeof _0x2297ba['length']=='number'?_0xbe12a0+=qt['apply'](null,_0x2297ba):typeof _0x2297ba=='object'?_0xbe12a0+=O(_0x2297ba):_0xbe12a0+=_0x2297ba,_0xbe12a0+='\x20';}return _0xbe12a0;};let Tt=null,$s=!0x0;const Hl=function(_0x1a61af,_0x3bb978){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0x2c8534){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0x4a3ed6=qt['apply'](null,_0x2c8534);Tt(_0x4a3ed6);}},zt=function(_0x2e7cf2){return function(..._0x188a6d){L(_0x2e7cf2,..._0x188a6d);};},Ii=function(..._0x399b9e){const _0x25993f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x399b9e);Ze['error'](_0x25993f);},ae=function(..._0x5e2591){const _0x5f18ed='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x5e2591);throw Ze['error'](_0x5f18ed),new Error(_0x5f18ed);},U=function(..._0x292aff){const _0x97716e='FIREBASE\x20WARNING:\x20'+qt(..._0x292aff);Ze['warn'](_0x97716e);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3e32c3){return typeof _0x3e32c3=='number'&&(_0x3e32c3!==_0x3e32c3||_0x3e32c3===Number['POSITIVE_INFINITY']||_0x3e32c3===Number['NEGATIVE_INFINITY']);},Gl=function(_0x37798e){if(document['readyState']==='complete')_0x37798e();else{let _0x101953=!0x1;const _0x2c3a8e=function(){if(!document['body']){setTimeout(_0x2c3a8e,Math['floor'](0xa));return;}_0x101953||(_0x101953=!0x0,_0x37798e());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2c3a8e,!0x1),window['addEventListener']('load',_0x2c3a8e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2c3a8e();}),window['attachEvent']('onload',_0x2c3a8e));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x737f73,_0x1b3785){if(_0x737f73===_0x1b3785)return 0x0;if(_0x737f73===Ue||_0x1b3785===we)return-0x1;if(_0x1b3785===Ue||_0x737f73===we)return 0x1;{const _0x39fb46=Gs(_0x737f73),_0x10d2d5=Gs(_0x1b3785);return _0x39fb46!==null?_0x10d2d5!==null?_0x39fb46-_0x10d2d5===0x0?_0x737f73['length']-_0x1b3785['length']:_0x39fb46-_0x10d2d5:-0x1:_0x10d2d5!==null?0x1:_0x737f73<_0x1b3785?-0x1:0x1;}},ql=function(_0x47e57a,_0x1f895b){return _0x47e57a===_0x1f895b?0x0:_0x47e57a<_0x1f895b?-0x1:0x1;},yt=function(_0xd93602,_0x35f2a0){if(_0x35f2a0&&_0xd93602 in _0x35f2a0)return _0x35f2a0[_0xd93602];throw new Error('Missing\x20required\x20key\x20('+_0xd93602+')\x20in\x20object:\x20'+O(_0x35f2a0));},$i=function(_0xe8d1e6){if(typeof _0xe8d1e6!='object'||_0xe8d1e6===null)return O(_0xe8d1e6);const _0x17108c=[];for(const _0x474d38 in _0xe8d1e6)_0x17108c['push'](_0x474d38);_0x17108c['sort']();let _0x21422a='{';for(let _0x1e8bf7=0x0;_0x1e8bf7<_0x17108c['length'];_0x1e8bf7++)_0x1e8bf7!==0x0&&(_0x21422a+=','),_0x21422a+=O(_0x17108c[_0x1e8bf7]),_0x21422a+=':',_0x21422a+=$i(_0xe8d1e6[_0x17108c[_0x1e8bf7]]);return _0x21422a+='}',_0x21422a;},oo=function(_0x55291d,_0x46d442){const _0x46ca6e=_0x55291d['length'];if(_0x46ca6e<=_0x46d442)return[_0x55291d];const _0x5ae3d8=[];for(let _0x2b7191=0x0;_0x2b7191<_0x46ca6e;_0x2b7191+=_0x46d442)_0x2b7191+_0x46d442>_0x46ca6e?_0x5ae3d8['push'](_0x55291d['substring'](_0x2b7191,_0x46ca6e)):_0x5ae3d8['push'](_0x55291d['substring'](_0x2b7191,_0x2b7191+_0x46d442));return _0x5ae3d8;};function x(_0x14d461,_0x108cac){for(const _0x408aec in _0x14d461)_0x14d461['hasOwnProperty'](_0x408aec)&&_0x108cac(_0x408aec,_0x14d461[_0x408aec]);}const ao=function(_0x69a6ac){f(!xn(_0x69a6ac),'Invalid\x20JSON\x20number');const _0x257c0d=0xb,_0x2b2b36=0x34,_0x245134=(0x1<<_0x257c0d-0x1)-0x1;let _0x417853,_0x350141,_0x450ce0,_0x548f9d,_0x49857c;_0x69a6ac===0x0?(_0x350141=0x0,_0x450ce0=0x0,_0x417853=0x1/_0x69a6ac===-0x1/0x0?0x1:0x0):(_0x417853=_0x69a6ac<0x0,_0x69a6ac=Math['abs'](_0x69a6ac),_0x69a6ac>=Math['pow'](0x2,0x1-_0x245134)?(_0x548f9d=Math['min'](Math['floor'](Math['log'](_0x69a6ac)/Math['LN2']),_0x245134),_0x350141=_0x548f9d+_0x245134,_0x450ce0=Math['round'](_0x69a6ac*Math['pow'](0x2,_0x2b2b36-_0x548f9d)-Math['pow'](0x2,_0x2b2b36))):(_0x350141=0x0,_0x450ce0=Math['round'](_0x69a6ac/Math['pow'](0x2,0x1-_0x245134-_0x2b2b36))));const _0x5ee19f=[];for(_0x49857c=_0x2b2b36;_0x49857c;_0x49857c-=0x1)_0x5ee19f['push'](_0x450ce0%0x2?0x1:0x0),_0x450ce0=Math['floor'](_0x450ce0/0x2);for(_0x49857c=_0x257c0d;_0x49857c;_0x49857c-=0x1)_0x5ee19f['push'](_0x350141%0x2?0x1:0x0),_0x350141=Math['floor'](_0x350141/0x2);_0x5ee19f['push'](_0x417853?0x1:0x0),_0x5ee19f['reverse']();const _0x3432cb=_0x5ee19f['join']('');let _0x2a5303='';for(_0x49857c=0x0;_0x49857c<0x40;_0x49857c+=0x8){let _0x333098=parseInt(_0x3432cb['substr'](_0x49857c,0x8),0x2)['toString'](0x10);_0x333098['length']===0x1&&(_0x333098='0'+_0x333098),_0x2a5303=_0x2a5303+_0x333098;}return _0x2a5303['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x5ce685,_0x193601){let _0x1a6c0d='Unknown\x20Error';_0x5ce685==='too_big'?_0x1a6c0d='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5ce685==='permission_denied'?_0x1a6c0d='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5ce685==='unavailable'&&(_0x1a6c0d='The\x20service\x20is\x20unavailable');const _0x1fcb99=new Error(_0x5ce685+'\x20at\x20'+_0x193601['_path']['toString']()+':\x20'+_0x1a6c0d);return _0x1fcb99['code']=_0x5ce685['toUpperCase'](),_0x1fcb99;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x4f3440){if(Yl['test'](_0x4f3440)){const _0x7eca21=Number(_0x4f3440);if(_0x7eca21>=Ql&&_0x7eca21<=Jl)return _0x7eca21;}return null;},ft=function(_0x5b9d98){try{_0x5b9d98();}catch(_0x4bdd24){setTimeout(()=>{const _0x4f0d6a=_0x4bdd24['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4f0d6a),_0x4bdd24;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x3dfbc6,_0x5a2d72){const _0x523488=setTimeout(_0x3dfbc6,_0x5a2d72);return typeof _0x523488=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x523488):typeof _0x523488=='object'&&_0x523488['unref']&&_0x523488['unref'](),_0x523488;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1cc88b,_0x263414){this['appCheckProvider']=_0x263414,this['appName']=_0x1cc88b['name'],$(_0x1cc88b)&&_0x1cc88b['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1cc88b['settings']['appCheckToken']),this['appCheck']=_0x263414==null?void 0x0:_0x263414['getImmediate']({'optional':!0x0}),this['appCheck']||_0x263414==null||_0x263414['get']()['then'](_0x2b9caf=>this['appCheck']=_0x2b9caf);}['getToken'](_0x12b336){if(this['serverAppAppCheckToken']){if(_0x12b336)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x12b336):new Promise((_0x2954d4,_0x56ecd3)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x12b336)['then'](_0x2954d4,_0x56ecd3):_0x2954d4(null);},0x0);});}['addTokenChangeListener'](_0x196fde){var _0x5a4a01;(_0x5a4a01=this['appCheckProvider'])==null||_0x5a4a01['get']()['then'](_0x1a1512=>_0x1a1512['addTokenListener'](_0x196fde));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3d4357,_0x2e823d,_0x16f06a){this['appName_']=_0x3d4357,this['firebaseOptions_']=_0x2e823d,this['authProvider_']=_0x16f06a,this['auth_']=null,this['auth_']=_0x16f06a['getImmediate']({'optional':!0x0}),this['auth_']||_0x16f06a['onInit'](_0x4eed5a=>this['auth_']=_0x4eed5a);}['getToken'](_0x1116ef){return this['auth_']?this['auth_']['getToken'](_0x1116ef)['catch'](_0x8c6a82=>_0x8c6a82&&_0x8c6a82['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x8c6a82)):new Promise((_0x3f8239,_0xfafe9f)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1116ef)['then'](_0x3f8239,_0xfafe9f):_0x3f8239(null);},0x0);});}['addTokenChangeListener'](_0x4ddb3e){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4ddb3e):this['authProvider_']['get']()['then'](_0x147f25=>_0x147f25['addAuthTokenListener'](_0x4ddb3e));}['removeTokenChangeListener'](_0x46f521){this['authProvider_']['get']()['then'](_0x1bbaf5=>_0x1bbaf5['removeAuthTokenListener'](_0x46f521));}['notifyForInvalidToken'](){let _0x1cc67d='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1cc67d+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1cc67d+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1cc67d+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1cc67d);}}class an{constructor(_0x4dc48e){this['accessToken']=_0x4dc48e;}['getToken'](_0x38a8fb){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x371188){_0x371188(this['accessToken']);}['removeTokenChangeListener'](_0x47bbb6){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x231dde,_0x12a028,_0x4bd666,_0x3bb188,_0xf2607d=!0x1,_0x5ae744='',_0x51b429=!0x1,_0xd05bb3=!0x1,_0x55e6ba=null){this['secure']=_0x12a028,this['namespace']=_0x4bd666,this['webSocketOnly']=_0x3bb188,this['nodeAdmin']=_0xf2607d,this['persistenceKey']=_0x5ae744,this['includeNamespaceInQueryParams']=_0x51b429,this['isUsingEmulator']=_0xd05bb3,this['emulatorOptions']=_0x55e6ba,this['_host']=_0x231dde['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x231dde)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x17de3e){_0x17de3e!==this['internalHost']&&(this['internalHost']=_0x17de3e,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3480be=this['toURLString']();return this['persistenceKey']&&(_0x3480be+='<'+this['persistenceKey']+'>'),_0x3480be;}['toURLString'](){const _0x12700d=this['secure']?'https://':'http://',_0x184c8c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x12700d+this['host']+'/'+_0x184c8c;}}function th(_0x43fed6){return _0x43fed6['host']!==_0x43fed6['internalHost']||_0x43fed6['isCustomHost']()||_0x43fed6['includeNamespaceInQueryParams'];}function vo(_0xebd19,_0xe445d3,_0x21c9b8){f(typeof _0xe445d3=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x21c9b8=='object','typeof\x20params\x20must\x20==\x20object');let _0x4cad4b;if(_0xe445d3===go)_0x4cad4b=(_0xebd19['secure']?'wss://':'ws://')+_0xebd19['internalHost']+'/.ws?';else{if(_0xe445d3===mo)_0x4cad4b=(_0xebd19['secure']?'https://':'http://')+_0xebd19['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0xe445d3);}th(_0xebd19)&&(_0x21c9b8['ns']=_0xebd19['namespace']);const _0x2f6512=[];return x(_0x21c9b8,(_0x338d61,_0x557f79)=>{_0x2f6512['push'](_0x338d61+'='+_0x557f79);}),_0x4cad4b+_0x2f6512['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xce38cc,_0x2cab04=0x1){Q(this['counters_'],_0xce38cc)||(this['counters_'][_0xce38cc]=0x0),this['counters_'][_0xce38cc]+=_0x2cab04;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x40ac89){const _0x176a88=_0x40ac89['toString']();return oi[_0x176a88]||(oi[_0x176a88]=new nh()),oi[_0x176a88];}function ih(_0x1d2049,_0x5bd344){const _0x173855=_0x1d2049['toString']();return ai[_0x173855]||(ai[_0x173855]=_0x5bd344()),ai[_0x173855];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x2c4f8a){this['onMessage_']=_0x2c4f8a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x7164ab,_0x14822f){this['closeAfterResponse']=_0x7164ab,this['onClose']=_0x14822f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x311ff1,_0x5462e4){for(this['pendingResponses'][_0x311ff1]=_0x5462e4;this['pendingResponses'][this['currentResponseNum']];){const _0x38b89d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xeec29e=0x0;_0xeec29e<_0x38b89d['length'];++_0xeec29e)_0x38b89d[_0xeec29e]&&ft(()=>{this['onMessage_'](_0x38b89d[_0xeec29e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x1197ca,_0x5c9b15,_0x4fa15c,_0x61ff66,_0x27be7b,_0x1fb21f,_0x33e774){this['connId']=_0x1197ca,this['repoInfo']=_0x5c9b15,this['applicationId']=_0x4fa15c,this['appCheckToken']=_0x61ff66,this['authToken']=_0x27be7b,this['transportSessionId']=_0x1fb21f,this['lastSessionId']=_0x33e774,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x1197ca),this['stats_']=qi(_0x5c9b15),this['urlFn']=_0x5ad7b3=>(this['appCheckToken']&&(_0x5ad7b3[wi]=this['appCheckToken']),vo(_0x5c9b15,mo,_0x5ad7b3));}['open'](_0x374d93,_0x1cb2ef){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1cb2ef,this['myPacketOrderer']=new sh(_0x374d93),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5d87fa)=>{const [_0x433356,_0x196376,_0x97e0b,_0x306a51,_0x27b205]=_0x5d87fa;if(this['incrementIncomingBytes_'](_0x5d87fa),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x433356===qs)this['id']=_0x196376,this['password']=_0x97e0b;else{if(_0x433356===rh)_0x196376?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x196376,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x433356);}}},(..._0x4903c2)=>{const [_0x3fd70d,_0x59c52f]=_0x4903c2;this['incrementIncomingBytes_'](_0x4903c2),this['myPacketOrderer']['handleResponse'](_0x3fd70d,_0x59c52f);},()=>{this['onClosed_']();},this['urlFn']);const _0x184760={};_0x184760[qs]='t',_0x184760[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x184760[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x184760[co]=Gi,this['transportSessionId']&&(_0x184760[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x184760[po]=this['lastSessionId']),this['applicationId']&&(_0x184760[_o]=this['applicationId']),this['appCheckToken']&&(_0x184760[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x184760[ho]=uo);const _0x20027e=this['urlFn'](_0x184760);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x20027e),this['scriptTagHolder']['addTag'](_0x20027e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x41c7cf){const _0x10f73c=O(_0x41c7cf);this['bytesSent']+=_0x10f73c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x10f73c['length']);const _0x59b10a=$r(_0x10f73c),_0x54a10c=oo(_0x59b10a,fh);for(let _0x3257c3=0x0;_0x3257c3<_0x54a10c['length'];_0x3257c3++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x54a10c['length'],_0x54a10c[_0x3257c3]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xca9d0c,_0x265370){this['myDisconnFrame']=document['createElement']('iframe');const _0x1ea6ec={};_0x1ea6ec[dh]='t',_0x1ea6ec[Eo]=_0xca9d0c,_0x1ea6ec[Io]=_0x265370,this['myDisconnFrame']['src']=this['urlFn'](_0x1ea6ec),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3467f6){const _0x308221=O(_0x3467f6)['length'];this['bytesReceived']+=_0x308221,this['stats_']['incrementCounter']('bytes_received',_0x308221);}}class zi{constructor(_0xed067c,_0x17870a,_0x4a5a37,_0xa99daa){this['onDisconnect']=_0x4a5a37,this['urlFn']=_0xa99daa,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xed067c,window[ah+this['uniqueCallbackIdentifier']]=_0x17870a,this['myIFrame']=zi['createIFrame_']();let _0x4cc799='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4cc799='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3d3360='<html><body>'+_0x4cc799+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3d3360),this['myIFrame']['doc']['close']();}catch(_0x2004eb){L('frame\x20writing\x20exception'),_0x2004eb['stack']&&L(_0x2004eb['stack']),L(_0x2004eb);}}}static['createIFrame_'](){const _0x1c64b4=document['createElement']('iframe');if(_0x1c64b4['style']['display']='none',document['body']){document['body']['appendChild'](_0x1c64b4);try{_0x1c64b4['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x315981=document['domain'];_0x1c64b4['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x315981+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1c64b4['contentDocument']?_0x1c64b4['doc']=_0x1c64b4['contentDocument']:_0x1c64b4['contentWindow']?_0x1c64b4['doc']=_0x1c64b4['contentWindow']['document']:_0x1c64b4['document']&&(_0x1c64b4['doc']=_0x1c64b4['document']),_0x1c64b4;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x42660a=this['onDisconnect'];_0x42660a&&(this['onDisconnect']=null,_0x42660a());}['startLongPoll'](_0x2ceabf,_0x4c4e36){for(this['myID']=_0x2ceabf,this['myPW']=_0x4c4e36,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1b7af1={};_0x1b7af1[Eo]=this['myID'],_0x1b7af1[Io]=this['myPW'],_0x1b7af1[wo]=this['currentSerial'];let _0x23957e=this['urlFn'](_0x1b7af1),_0x29f6a5='',_0x46074a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x29f6a5['length']<=Co;){const _0x58c5cb=this['pendingSegs']['shift']();_0x29f6a5=_0x29f6a5+'&'+lh+_0x46074a+'='+_0x58c5cb['seg']+'&'+hh+_0x46074a+'='+_0x58c5cb['ts']+'&'+uh+_0x46074a+'='+_0x58c5cb['d'],_0x46074a++;}return _0x23957e=_0x23957e+_0x29f6a5,this['addLongPollTag_'](_0x23957e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x301b7c,_0x51643c,_0x31c753){this['pendingSegs']['push']({'seg':_0x301b7c,'ts':_0x51643c,'d':_0x31c753}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5312ce,_0x136949){this['outstandingRequests']['add'](_0x136949);const _0x3b9352=()=>{this['outstandingRequests']['delete'](_0x136949),this['newRequest_']();},_0x3cfb4d=setTimeout(_0x3b9352,Math['floor'](ph)),_0x360c17=()=>{clearTimeout(_0x3cfb4d),_0x3b9352();};this['addTag'](_0x5312ce,_0x360c17);}['addTag'](_0x4c55af,_0x173e98){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x11bcb2=this['myIFrame']['doc']['createElement']('script');_0x11bcb2['type']='text/javascript',_0x11bcb2['async']=!0x0,_0x11bcb2['src']=_0x4c55af,_0x11bcb2['onload']=_0x11bcb2['onreadystatechange']=function(){const _0x48d93d=_0x11bcb2['readyState'];(!_0x48d93d||_0x48d93d==='loaded'||_0x48d93d==='complete')&&(_0x11bcb2['onload']=_0x11bcb2['onreadystatechange']=null,_0x11bcb2['parentNode']&&_0x11bcb2['parentNode']['removeChild'](_0x11bcb2),_0x173e98());},_0x11bcb2['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4c55af),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x11bcb2);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x709ab1,_0x1ed99b,_0x1c24f6,_0xc248f3,_0x1b7b4a,_0x1bdc33,_0x4c1300){this['connId']=_0x709ab1,this['applicationId']=_0x1c24f6,this['appCheckToken']=_0xc248f3,this['authToken']=_0x1b7b4a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0x1ed99b),this['connURL']=q['connectionURL_'](_0x1ed99b,_0x1bdc33,_0x4c1300,_0xc248f3,_0x1c24f6),this['nodeAdmin']=_0x1ed99b['nodeAdmin'];}static['connectionURL_'](_0x1666dd,_0x7594ab,_0x509100,_0x1b1b5f,_0x1e7f7e){const _0x54f238={};return _0x54f238[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x54f238[ho]=uo),_0x7594ab&&(_0x54f238[lo]=_0x7594ab),_0x509100&&(_0x54f238[po]=_0x509100),_0x1b1b5f&&(_0x54f238[wi]=_0x1b1b5f),_0x1e7f7e&&(_0x54f238[_o]=_0x1e7f7e),vo(_0x1666dd,go,_0x54f238);}['open'](_0x1f3b5d,_0x339fb5){this['onDisconnect']=_0x339fb5,this['onMessage']=_0x1f3b5d,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x5d05ae;_c(),this['mySock']=new gn(this['connURL'],[],_0x5d05ae);}catch(_0x2fc9ad){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x44d2af=_0x2fc9ad['message']||_0x2fc9ad['data'];_0x44d2af&&this['log_'](_0x44d2af),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xbdd415=>{this['handleIncomingFrame'](_0xbdd415);},this['mySock']['onerror']=_0x23861d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x127424=_0x23861d['message']||_0x23861d['data'];_0x127424&&this['log_'](_0x127424),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x43ee47=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4fa9fa=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x22d77a=navigator['userAgent']['match'](_0x4fa9fa);_0x22d77a&&_0x22d77a['length']>0x1&&parseFloat(_0x22d77a[0x1])<4.4&&(_0x43ee47=!0x0);}return!_0x43ee47&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x18d695){if(this['frames']['push'](_0x18d695),this['frames']['length']===this['totalFrames']){const _0x20cb25=this['frames']['join']('');this['frames']=null;const _0x3459ba=Nt(_0x20cb25);this['onMessage'](_0x3459ba);}}['handleNewFrameCount_'](_0x259660){this['totalFrames']=_0x259660,this['frames']=[];}['extractFrameCount_'](_0x5c69b8){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5c69b8['length']<=0x6){const _0x4073ad=Number(_0x5c69b8);if(!isNaN(_0x4073ad))return this['handleNewFrameCount_'](_0x4073ad),null;}return this['handleNewFrameCount_'](0x1),_0x5c69b8;}['handleIncomingFrame'](_0x9cf1c9){if(this['mySock']===null)return;const _0x570241=_0x9cf1c9['data'];if(this['bytesReceived']+=_0x570241['length'],this['stats_']['incrementCounter']('bytes_received',_0x570241['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x570241);else{const _0x2daf9d=this['extractFrameCount_'](_0x570241);_0x2daf9d!==null&&this['appendFrame_'](_0x2daf9d);}}['send'](_0x5e6547){this['resetKeepAlive']();const _0x3974e9=O(_0x5e6547);this['bytesSent']+=_0x3974e9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3974e9['length']);const _0x37b042=oo(_0x3974e9,gh);_0x37b042['length']>0x1&&this['sendString_'](String(_0x37b042['length']));for(let _0x373e1a=0x0;_0x373e1a<_0x37b042['length'];_0x373e1a++)this['sendString_'](_0x37b042[_0x373e1a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x137a96){try{this['mySock']['send'](_0x137a96);}catch(_0x1360cf){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1360cf['message']||_0x1360cf['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1756a4){this['initTransports_'](_0x1756a4);}['initTransports_'](_0x326f18){const _0x4f1bf1=q&&q['isAvailable']();let _0x47c860=_0x4f1bf1&&!q['previouslyFailed']();if(_0x326f18['webSocketOnly']&&(_0x4f1bf1||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x47c860=!0x0),_0x47c860)this['transports_']=[q];else{const _0x1387e4=this['transports_']=[];for(const _0x134e25 of Ot['ALL_TRANSPORTS'])_0x134e25&&_0x134e25['isAvailable']()&&_0x1387e4['push'](_0x134e25);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0xc5a7fe,_0x5be451,_0x1519ca,_0x4ecdaf,_0x36a5ee,_0x1bbdf2,_0x4dd5c3,_0x5d4290,_0x2397ad,_0x17075d){this['id']=_0xc5a7fe,this['repoInfo_']=_0x5be451,this['applicationId_']=_0x1519ca,this['appCheckToken_']=_0x4ecdaf,this['authToken_']=_0x36a5ee,this['onMessage_']=_0x1bbdf2,this['onReady_']=_0x4dd5c3,this['onDisconnect_']=_0x5d4290,this['onKill_']=_0x2397ad,this['lastSessionId']=_0x17075d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x5be451),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x219a85=this['transportManager_']['initialTransport']();this['conn_']=new _0x219a85(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x219a85['responsesRequiredToBeHealthy']||0x0;const _0x2613a3=this['connReceiver_'](this['conn_']),_0x5e86b9=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2613a3,_0x5e86b9);},Math['floor'](0x0));const _0x38f8f3=_0x219a85['healthyTimeout']||0x0;_0x38f8f3>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x38f8f3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x39d580){return _0x4ccd4d=>{_0x39d580===this['conn_']?this['onConnectionLost_'](_0x4ccd4d):_0x39d580===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x28659b){return _0x2e7436=>{this['state_']!==0x2&&(_0x28659b===this['rx_']?this['onPrimaryMessageReceived_'](_0x2e7436):_0x28659b===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2e7436):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x48bf2c){const _0x34f57c={'t':'d','d':_0x48bf2c};this['sendData_'](_0x34f57c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4b9db3){if(ci in _0x4b9db3){const _0x19cefc=_0x4b9db3[ci];_0x19cefc===Ys?this['upgradeIfSecondaryHealthy_']():_0x19cefc===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x19cefc===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x369007){const _0x4a263b=yt('t',_0x369007),_0x401d8d=yt('d',_0x369007);if(_0x4a263b==='c')this['onSecondaryControl_'](_0x401d8d);else{if(_0x4a263b==='d')this['pendingDataMessages']['push'](_0x401d8d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4a263b);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1bce05){const _0x4a56da=yt('t',_0x1bce05),_0x3a3c1a=yt('d',_0x1bce05);_0x4a56da==='c'?this['onControl_'](_0x3a3c1a):_0x4a56da==='d'&&this['onDataMessage_'](_0x3a3c1a);}['onDataMessage_'](_0x3439a3){this['onPrimaryResponse_'](),this['onMessage_'](_0x3439a3);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4eb2fd){const _0x20a392=yt(ci,_0x4eb2fd);if(zs in _0x4eb2fd){const _0x370231=_0x4eb2fd[zs];if(_0x20a392===Th){const _0x59b42b={..._0x370231};this['repoInfo_']['isUsingEmulator']&&(_0x59b42b['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x59b42b);}else{if(_0x20a392===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x47d973=0x0;_0x47d973<this['pendingDataMessages']['length'];++_0x47d973)this['onDataMessage_'](this['pendingDataMessages'][_0x47d973]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x20a392===wh?this['onConnectionShutdown_'](_0x370231):_0x20a392===js?this['onReset_'](_0x370231):_0x20a392===Ch?Ii('Server\x20Error:\x20'+_0x370231):_0x20a392===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x20a392);}}}['onHandshake_'](_0x54ad57){const _0x28d718=_0x54ad57['ts'],_0x22ba69=_0x54ad57['v'],_0x43a926=_0x54ad57['h'];this['sessionId']=_0x54ad57['s'],this['repoInfo_']['host']=_0x43a926,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x28d718),Gi!==_0x22ba69&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x473c6f=this['transportManager_']['upgradeTransport']();_0x473c6f&&this['startUpgrade_'](_0x473c6f);}['startUpgrade_'](_0x504127){this['secondaryConn_']=new _0x504127(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x504127['responsesRequiredToBeHealthy']||0x0;const _0x3a6f85=this['connReceiver_'](this['secondaryConn_']),_0x4fdbc0=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3a6f85,_0x4fdbc0),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x44a95a){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x44a95a),this['repoInfo_']['host']=_0x44a95a,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4e3a6b,_0x211461){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4e3a6b,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x211461,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2b1a56=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2b1a56||this['rx_']===_0x2b1a56)&&this['close']();}['onConnectionLost_'](_0x229d3c){this['conn_']=null,!_0x229d3c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x50cd1d){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x50cd1d),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x33cea8){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x33cea8);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x568adb,_0x3597c2,_0x4a2920,_0xd02398){}['merge'](_0x4d66ac,_0x585f3d,_0x3b9e16,_0x5bcdb9){}['refreshAuthToken'](_0x43d863){}['refreshAppCheckToken'](_0x325603){}['onDisconnectPut'](_0x57987d,_0x2e8b51,_0x2aee8a){}['onDisconnectMerge'](_0x1107cd,_0x21f70e,_0x13ac08){}['onDisconnectCancel'](_0x2ee42f,_0x399348){}['reportStats'](_0x30b0cc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x11558f){this['allowedEvents_']=_0x11558f,this['listeners_']={},f(Array['isArray'](_0x11558f)&&_0x11558f['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x183457,..._0x29188a){if(Array['isArray'](this['listeners_'][_0x183457])){const _0xcafe17=[...this['listeners_'][_0x183457]];for(let _0x12358e=0x0;_0x12358e<_0xcafe17['length'];_0x12358e++)_0xcafe17[_0x12358e]['callback']['apply'](_0xcafe17[_0x12358e]['context'],_0x29188a);}}['on'](_0x29660a,_0x56b911,_0x4e89e6){this['validateEventType_'](_0x29660a),this['listeners_'][_0x29660a]=this['listeners_'][_0x29660a]||[],this['listeners_'][_0x29660a]['push']({'callback':_0x56b911,'context':_0x4e89e6});const _0xa54bde=this['getInitialEvent'](_0x29660a);_0xa54bde&&_0x56b911['apply'](_0x4e89e6,_0xa54bde);}['off'](_0x33fdb7,_0x25b09a,_0x319c50){this['validateEventType_'](_0x33fdb7);const _0x5a3fef=this['listeners_'][_0x33fdb7]||[];for(let _0xb6fffd=0x0;_0xb6fffd<_0x5a3fef['length'];_0xb6fffd++)if(_0x5a3fef[_0xb6fffd]['callback']===_0x25b09a&&(!_0x319c50||_0x319c50===_0x5a3fef[_0xb6fffd]['context'])){_0x5a3fef['splice'](_0xb6fffd,0x1);return;}}['validateEventType_'](_0x43c0af){f(this['allowedEvents_']['find'](_0x5c481c=>_0x5c481c===_0x43c0af),'Unknown\x20event:\x20'+_0x43c0af);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x107156){return f(_0x107156==='online','Unknown\x20event\x20type:\x20'+_0x107156),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1b5364,_0x1ed291){if(_0x1ed291===void 0x0){this['pieces_']=_0x1b5364['split']('/');let _0x373cc0=0x0;for(let _0x245036=0x0;_0x245036<this['pieces_']['length'];_0x245036++)this['pieces_'][_0x245036]['length']>0x0&&(this['pieces_'][_0x373cc0]=this['pieces_'][_0x245036],_0x373cc0++);this['pieces_']['length']=_0x373cc0,this['pieceNum_']=0x0;}else this['pieces_']=_0x1b5364,this['pieceNum_']=_0x1ed291;}['toString'](){let _0x5da762='';for(let _0xb77f5f=this['pieceNum_'];_0xb77f5f<this['pieces_']['length'];_0xb77f5f++)this['pieces_'][_0xb77f5f]!==''&&(_0x5da762+='/'+this['pieces_'][_0xb77f5f]);return _0x5da762||'/';}}function w(){return new C('');}function y(_0xe8ae24){return _0xe8ae24['pieceNum_']>=_0xe8ae24['pieces_']['length']?null:_0xe8ae24['pieces_'][_0xe8ae24['pieceNum_']];}function Ce(_0x1a08ca){return _0x1a08ca['pieces_']['length']-_0x1a08ca['pieceNum_'];}function S(_0x23f638){let _0x259b0b=_0x23f638['pieceNum_'];return _0x259b0b<_0x23f638['pieces_']['length']&&_0x259b0b++,new C(_0x23f638['pieces_'],_0x259b0b);}function ji(_0x541566){return _0x541566['pieceNum_']<_0x541566['pieces_']['length']?_0x541566['pieces_'][_0x541566['pieces_']['length']-0x1]:null;}function bh(_0x4612a8){let _0x542f50='';for(let _0x4e5f2d=_0x4612a8['pieceNum_'];_0x4e5f2d<_0x4612a8['pieces_']['length'];_0x4e5f2d++)_0x4612a8['pieces_'][_0x4e5f2d]!==''&&(_0x542f50+='/'+encodeURIComponent(String(_0x4612a8['pieces_'][_0x4e5f2d])));return _0x542f50||'/';}function Dt(_0x50f96d,_0x1a873f=0x0){return _0x50f96d['pieces_']['slice'](_0x50f96d['pieceNum_']+_0x1a873f);}function Ro(_0x3e1854){if(_0x3e1854['pieceNum_']>=_0x3e1854['pieces_']['length'])return null;const _0xfe5726=[];for(let _0x3fdd7f=_0x3e1854['pieceNum_'];_0x3fdd7f<_0x3e1854['pieces_']['length']-0x1;_0x3fdd7f++)_0xfe5726['push'](_0x3e1854['pieces_'][_0x3fdd7f]);return new C(_0xfe5726,0x0);}function k(_0x2794fc,_0x28ebb4){const _0x273905=[];for(let _0xcb4b71=_0x2794fc['pieceNum_'];_0xcb4b71<_0x2794fc['pieces_']['length'];_0xcb4b71++)_0x273905['push'](_0x2794fc['pieces_'][_0xcb4b71]);if(_0x28ebb4 instanceof C){for(let _0x37683f=_0x28ebb4['pieceNum_'];_0x37683f<_0x28ebb4['pieces_']['length'];_0x37683f++)_0x273905['push'](_0x28ebb4['pieces_'][_0x37683f]);}else{const _0x3784bb=_0x28ebb4['split']('/');for(let _0xdd9851=0x0;_0xdd9851<_0x3784bb['length'];_0xdd9851++)_0x3784bb[_0xdd9851]['length']>0x0&&_0x273905['push'](_0x3784bb[_0xdd9851]);}return new C(_0x273905,0x0);}function v(_0x1f38f6){return _0x1f38f6['pieceNum_']>=_0x1f38f6['pieces_']['length'];}function F(_0x5288f8,_0x3bc18f){const _0x42f1df=y(_0x5288f8),_0x484b70=y(_0x3bc18f);if(_0x42f1df===null)return _0x3bc18f;if(_0x42f1df===_0x484b70)return F(S(_0x5288f8),S(_0x3bc18f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3bc18f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x5288f8+')');}function Rh(_0x1853ae,_0x23255d){const _0x31f5c2=Dt(_0x1853ae,0x0),_0x233d03=Dt(_0x23255d,0x0);for(let _0x3eed52=0x0;_0x3eed52<_0x31f5c2['length']&&_0x3eed52<_0x233d03['length'];_0x3eed52++){const _0x3f85b8=Ge(_0x31f5c2[_0x3eed52],_0x233d03[_0x3eed52]);if(_0x3f85b8!==0x0)return _0x3f85b8;}return _0x31f5c2['length']===_0x233d03['length']?0x0:_0x31f5c2['length']<_0x233d03['length']?-0x1:0x1;}function Ki(_0x4e023f,_0x1e6e4b){if(Ce(_0x4e023f)!==Ce(_0x1e6e4b))return!0x1;for(let _0x54df89=_0x4e023f['pieceNum_'],_0x2d157b=_0x1e6e4b['pieceNum_'];_0x54df89<=_0x4e023f['pieces_']['length'];_0x54df89++,_0x2d157b++)if(_0x4e023f['pieces_'][_0x54df89]!==_0x1e6e4b['pieces_'][_0x2d157b])return!0x1;return!0x0;}function G(_0x15c70d,_0x1de9a7){let _0xf7b523=_0x15c70d['pieceNum_'],_0x4e161c=_0x1de9a7['pieceNum_'];if(Ce(_0x15c70d)>Ce(_0x1de9a7))return!0x1;for(;_0xf7b523<_0x15c70d['pieces_']['length'];){if(_0x15c70d['pieces_'][_0xf7b523]!==_0x1de9a7['pieces_'][_0x4e161c])return!0x1;++_0xf7b523,++_0x4e161c;}return!0x0;}class Ah{constructor(_0xcfd503,_0x181c24){this['errorPrefix_']=_0x181c24,this['parts_']=Dt(_0xcfd503,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3a7e13=0x0;_0x3a7e13<this['parts_']['length'];_0x3a7e13++)this['byteLength_']+=Ln(this['parts_'][_0x3a7e13]);Ao(this);}}function kh(_0x3d65e2,_0x55de57){_0x3d65e2['parts_']['length']>0x0&&(_0x3d65e2['byteLength_']+=0x1),_0x3d65e2['parts_']['push'](_0x55de57),_0x3d65e2['byteLength_']+=Ln(_0x55de57),Ao(_0x3d65e2);}function Nh(_0x35b2d8){const _0x16d6c5=_0x35b2d8['parts_']['pop']();_0x35b2d8['byteLength_']-=Ln(_0x16d6c5),_0x35b2d8['parts_']['length']>0x0&&(_0x35b2d8['byteLength_']-=0x1);}function Ao(_0x542ef8){if(_0x542ef8['byteLength_']>Zs)throw new Error(_0x542ef8['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x542ef8['byteLength_']+').');if(_0x542ef8['parts_']['length']>Xs)throw new Error(_0x542ef8['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x542ef8));}function Pe(_0x3aeece){return _0x3aeece['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3aeece['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x461329,_0x1b690b;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1b690b='visibilitychange',_0x461329='hidden'):typeof document['mozHidden']<'u'?(_0x1b690b='mozvisibilitychange',_0x461329='mozHidden'):typeof document['msHidden']<'u'?(_0x1b690b='msvisibilitychange',_0x461329='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1b690b='webkitvisibilitychange',_0x461329='webkitHidden')),this['visible_']=!0x0,_0x1b690b&&document['addEventListener'](_0x1b690b,()=>{const _0x597b1a=!document[_0x461329];_0x597b1a!==this['visible_']&&(this['visible_']=_0x597b1a,this['trigger']('visible',_0x597b1a));},!0x1);}['getInitialEvent'](_0x3ea622){return f(_0x3ea622==='visible','Unknown\x20event\x20type:\x20'+_0x3ea622),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x35acb3,_0x10059f,_0x5f4fc7,_0x490cf1,_0x160b5d,_0x365fe2,_0xa3fd5a,_0xa5bf3c){if(super(),this['repoInfo_']=_0x35acb3,this['applicationId_']=_0x10059f,this['onDataUpdate_']=_0x5f4fc7,this['onConnectStatus_']=_0x490cf1,this['onServerInfoUpdate_']=_0x160b5d,this['authTokenProvider_']=_0x365fe2,this['appCheckTokenProvider_']=_0xa3fd5a,this['authOverride_']=_0xa5bf3c,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xa5bf3c)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x35acb3['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x7f242c,_0x3273c0,_0x210c83){const _0x515c46=++this['requestNumber_'],_0x4eccce={'r':_0x515c46,'a':_0x7f242c,'b':_0x3273c0};this['log_'](O(_0x4eccce)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4eccce),_0x210c83&&(this['requestCBHash_'][_0x515c46]=_0x210c83);}['get'](_0x2aaff9){this['initConnection_']();const _0x216356=new H(),_0x18ac92={'action':'g','request':{'p':_0x2aaff9['_path']['toString'](),'q':_0x2aaff9['_queryObject']},'onComplete':_0x3fbb31=>{const _0x164c8b=_0x3fbb31['d'];_0x3fbb31['s']==='ok'?_0x216356['resolve'](_0x164c8b):_0x216356['reject'](_0x164c8b);}};this['outstandingGets_']['push'](_0x18ac92),this['outstandingGetCount_']++;const _0x31d5a3=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x31d5a3),_0x216356['promise'];}['listen'](_0x399a4c,_0x5b93d1,_0x555d54,_0x35f39c){this['initConnection_']();const _0x2c1346=_0x399a4c['_queryIdentifier'],_0x350448=_0x399a4c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x350448+'\x20'+_0x2c1346),this['listens']['has'](_0x350448)||this['listens']['set'](_0x350448,new Map()),f(_0x399a4c['_queryParams']['isDefault']()||!_0x399a4c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x350448)['has'](_0x2c1346),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5ff8e4={'onComplete':_0x35f39c,'hashFn':_0x5b93d1,'query':_0x399a4c,'tag':_0x555d54};this['listens']['get'](_0x350448)['set'](_0x2c1346,_0x5ff8e4),this['connected_']&&this['sendListen_'](_0x5ff8e4);}['sendGet_'](_0x2bf354){const _0x2691c7=this['outstandingGets_'][_0x2bf354];this['sendRequest']('g',_0x2691c7['request'],_0x2a3d25=>{delete this['outstandingGets_'][_0x2bf354],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2691c7['onComplete']&&_0x2691c7['onComplete'](_0x2a3d25);});}['sendListen_'](_0x187e30){const _0x366538=_0x187e30['query'],_0x2fe214=_0x366538['_path']['toString'](),_0x4089b4=_0x366538['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2fe214+'\x20for\x20'+_0x4089b4);const _0x139a53={'p':_0x2fe214},_0x5d9020='q';_0x187e30['tag']&&(_0x139a53['q']=_0x366538['_queryObject'],_0x139a53['t']=_0x187e30['tag']),_0x139a53['h']=_0x187e30['hashFn'](),this['sendRequest'](_0x5d9020,_0x139a53,_0x1698dd=>{const _0x48aee3=_0x1698dd['d'],_0x3f21e8=_0x1698dd['s'];se['warnOnListenWarnings_'](_0x48aee3,_0x366538),(this['listens']['get'](_0x2fe214)&&this['listens']['get'](_0x2fe214)['get'](_0x4089b4))===_0x187e30&&(this['log_']('listen\x20response',_0x1698dd),_0x3f21e8!=='ok'&&this['removeListen_'](_0x2fe214,_0x4089b4),_0x187e30['onComplete']&&_0x187e30['onComplete'](_0x3f21e8,_0x48aee3));});}static['warnOnListenWarnings_'](_0x55b16e,_0x1c4c8c){if(_0x55b16e&&typeof _0x55b16e=='object'&&Q(_0x55b16e,'w')){const _0x102657=Me(_0x55b16e,'w');if(Array['isArray'](_0x102657)&&~_0x102657['indexOf']('no_index')){const _0x4e1025='\x22.indexOn\x22:\x20\x22'+_0x1c4c8c['_queryParams']['getIndex']()['toString']()+'\x22',_0x10b5cd=_0x1c4c8c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4e1025+'\x20at\x20'+_0x10b5cd+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x18af4a){this['authToken_']=_0x18af4a,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x18af4a);}['reduceReconnectDelayIfAdminCredential_'](_0x2d140f){(_0x2d140f&&_0x2d140f['length']===0x28||wc(_0x2d140f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x246b4d){this['appCheckToken_']=_0x246b4d,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x28aaeb=this['authToken_'],_0x58e987=Ic(_0x28aaeb)?'auth':'gauth',_0x5010fc={'cred':_0x28aaeb};this['authOverride_']===null?_0x5010fc['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5010fc['authvar']=this['authOverride_']),this['sendRequest'](_0x58e987,_0x5010fc,_0x23ce85=>{const _0x3adc4b=_0x23ce85['s'],_0x289c77=_0x23ce85['d']||'error';this['authToken_']===_0x28aaeb&&(_0x3adc4b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3adc4b,_0x289c77));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4c11dc=>{const _0x145316=_0x4c11dc['s'],_0x3b2773=_0x4c11dc['d']||'error';_0x145316==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x145316,_0x3b2773);});}['unlisten'](_0xaabdbc,_0x4f4eaf){const _0x3a7dfe=_0xaabdbc['_path']['toString'](),_0x47d318=_0xaabdbc['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3a7dfe+'\x20'+_0x47d318),f(_0xaabdbc['_queryParams']['isDefault']()||!_0xaabdbc['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3a7dfe,_0x47d318)&&this['connected_']&&this['sendUnlisten_'](_0x3a7dfe,_0x47d318,_0xaabdbc['_queryObject'],_0x4f4eaf);}['sendUnlisten_'](_0x590e15,_0x3da368,_0x370d63,_0x490b3c){this['log_']('Unlisten\x20on\x20'+_0x590e15+'\x20for\x20'+_0x3da368);const _0x25b53b={'p':_0x590e15},_0x135b43='n';_0x490b3c&&(_0x25b53b['q']=_0x370d63,_0x25b53b['t']=_0x490b3c),this['sendRequest'](_0x135b43,_0x25b53b);}['onDisconnectPut'](_0x2e9cbb,_0x573efe,_0xbec1c8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2e9cbb,_0x573efe,_0xbec1c8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2e9cbb,'action':'o','data':_0x573efe,'onComplete':_0xbec1c8});}['onDisconnectMerge'](_0x395d52,_0x2f360f,_0x5e6881){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x395d52,_0x2f360f,_0x5e6881):this['onDisconnectRequestQueue_']['push']({'pathString':_0x395d52,'action':'om','data':_0x2f360f,'onComplete':_0x5e6881});}['onDisconnectCancel'](_0x291686,_0x8b9075){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x291686,null,_0x8b9075):this['onDisconnectRequestQueue_']['push']({'pathString':_0x291686,'action':'oc','data':null,'onComplete':_0x8b9075});}['sendOnDisconnect_'](_0x29d0d4,_0x55f6b0,_0x2ae851,_0x398f4a){const _0x2aacd7={'p':_0x55f6b0,'d':_0x2ae851};this['log_']('onDisconnect\x20'+_0x29d0d4,_0x2aacd7),this['sendRequest'](_0x29d0d4,_0x2aacd7,_0x45197b=>{_0x398f4a&&setTimeout(()=>{_0x398f4a(_0x45197b['s'],_0x45197b['d']);},Math['floor'](0x0));});}['put'](_0x284c0b,_0x330a21,_0x23f27e,_0x8adf97){this['putInternal']('p',_0x284c0b,_0x330a21,_0x23f27e,_0x8adf97);}['merge'](_0x4686bb,_0x40791f,_0x449404,_0x351196){this['putInternal']('m',_0x4686bb,_0x40791f,_0x449404,_0x351196);}['putInternal'](_0x1c54f3,_0x299d8e,_0x2a6d46,_0x408d4c,_0x1a05c5){this['initConnection_']();const _0x3e0d79={'p':_0x299d8e,'d':_0x2a6d46};_0x1a05c5!==void 0x0&&(_0x3e0d79['h']=_0x1a05c5),this['outstandingPuts_']['push']({'action':_0x1c54f3,'request':_0x3e0d79,'onComplete':_0x408d4c}),this['outstandingPutCount_']++;const _0x41ddd0=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x41ddd0):this['log_']('Buffering\x20put:\x20'+_0x299d8e);}['sendPut_'](_0xdd5685){const _0x1dc55f=this['outstandingPuts_'][_0xdd5685]['action'],_0x79d29e=this['outstandingPuts_'][_0xdd5685]['request'],_0x48a57f=this['outstandingPuts_'][_0xdd5685]['onComplete'];this['outstandingPuts_'][_0xdd5685]['queued']=this['connected_'],this['sendRequest'](_0x1dc55f,_0x79d29e,_0x5a94ee=>{this['log_'](_0x1dc55f+'\x20response',_0x5a94ee),delete this['outstandingPuts_'][_0xdd5685],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x48a57f&&_0x48a57f(_0x5a94ee['s'],_0x5a94ee['d']);});}['reportStats'](_0x373a28){if(this['connected_']){const _0x2114e9={'c':_0x373a28};this['log_']('reportStats',_0x2114e9),this['sendRequest']('s',_0x2114e9,_0x4f492a=>{if(_0x4f492a['s']!=='ok'){const _0x54e8a7=_0x4f492a['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x54e8a7);}});}}['onDataMessage_'](_0x1e21fd){if('r'in _0x1e21fd){this['log_']('from\x20server:\x20'+O(_0x1e21fd));const _0x526235=_0x1e21fd['r'],_0x1c5b16=this['requestCBHash_'][_0x526235];_0x1c5b16&&(delete this['requestCBHash_'][_0x526235],_0x1c5b16(_0x1e21fd['b']));}else{if('error'in _0x1e21fd)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1e21fd['error'];'a'in _0x1e21fd&&this['onDataPush_'](_0x1e21fd['a'],_0x1e21fd['b']);}}['onDataPush_'](_0x438986,_0x5363bc){this['log_']('handleServerMessage',_0x438986,_0x5363bc),_0x438986==='d'?this['onDataUpdate_'](_0x5363bc['p'],_0x5363bc['d'],!0x1,_0x5363bc['t']):_0x438986==='m'?this['onDataUpdate_'](_0x5363bc['p'],_0x5363bc['d'],!0x0,_0x5363bc['t']):_0x438986==='c'?this['onListenRevoked_'](_0x5363bc['p'],_0x5363bc['q']):_0x438986==='ac'?this['onAuthRevoked_'](_0x5363bc['s'],_0x5363bc['d']):_0x438986==='apc'?this['onAppCheckRevoked_'](_0x5363bc['s'],_0x5363bc['d']):_0x438986==='sd'?this['onSecurityDebugPacket_'](_0x5363bc):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x438986)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0xb0d3fb,_0x16959c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0xb0d3fb),this['lastSessionId']=_0x16959c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2a9b15){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2a9b15));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1cc04b){_0x1cc04b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1cc04b;}['onOnline_'](_0x37b0c8){_0x37b0c8?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3cc38d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x221fcc=Math['max'](0x0,this['reconnectDelay_']-_0x3cc38d);_0x221fcc=Math['random']()*_0x221fcc,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x221fcc+'ms'),this['scheduleConnect_'](_0x221fcc),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4bdfa2=this['onDataMessage_']['bind'](this),_0x54f1f6=this['onReady_']['bind'](this),_0x425ead=this['onRealtimeDisconnect_']['bind'](this),_0x4c8b18=this['id']+':'+se['nextConnectionId_']++,_0x305d1d=this['lastSessionId'];let _0x549f1b=!0x1,_0x25cf8d=null;const _0x2fa236=function(){_0x25cf8d?_0x25cf8d['close']():(_0x549f1b=!0x0,_0x425ead());},_0x52187d=function(_0x4e6ffd){f(_0x25cf8d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x25cf8d['sendRequest'](_0x4e6ffd);};this['realtime_']={'close':_0x2fa236,'sendRequest':_0x52187d};const _0xa041f0=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5aae28,_0x2fd735]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xa041f0),this['appCheckTokenProvider_']['getToken'](_0xa041f0)]);_0x549f1b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5aae28&&_0x5aae28['accessToken'],this['appCheckToken_']=_0x2fd735&&_0x2fd735['token'],_0x25cf8d=new Sh(_0x4c8b18,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4bdfa2,_0x54f1f6,_0x425ead,_0x4a5f5b=>{U(_0x4a5f5b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x305d1d));}catch(_0x3eb877){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3eb877),_0x549f1b||(this['repoInfo_']['nodeAdmin']&&U(_0x3eb877),_0x2fa236());}}}['interrupt'](_0x2f0a67){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2f0a67),this['interruptReasons_'][_0x2f0a67]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x10c210){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x10c210),delete this['interruptReasons_'][_0x10c210],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4d9d38){const _0x42a866=_0x4d9d38-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x42a866});}['cancelSentTransactions_'](){for(let _0x26346b=0x0;_0x26346b<this['outstandingPuts_']['length'];_0x26346b++){const _0x5eb161=this['outstandingPuts_'][_0x26346b];_0x5eb161&&'h'in _0x5eb161['request']&&_0x5eb161['queued']&&(_0x5eb161['onComplete']&&_0x5eb161['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x26346b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5f1274,_0x2803fc){let _0x154a1d;_0x2803fc?_0x154a1d=_0x2803fc['map'](_0x44c4c1=>$i(_0x44c4c1))['join']('$'):_0x154a1d='default';const _0x14bc27=this['removeListen_'](_0x5f1274,_0x154a1d);_0x14bc27&&_0x14bc27['onComplete']&&_0x14bc27['onComplete']('permission_denied');}['removeListen_'](_0x35c611,_0x28fd76){const _0x12336a=new C(_0x35c611)['toString']();let _0x256849;if(this['listens']['has'](_0x12336a)){const _0x7214e=this['listens']['get'](_0x12336a);_0x256849=_0x7214e['get'](_0x28fd76),_0x7214e['delete'](_0x28fd76),_0x7214e['size']===0x0&&this['listens']['delete'](_0x12336a);}else _0x256849=void 0x0;return _0x256849;}['onAuthRevoked_'](_0x1af6b6,_0x50c51f){L('Auth\x20token\x20revoked:\x20'+_0x1af6b6+'/'+_0x50c51f),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1af6b6==='invalid_token'||_0x1af6b6==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5b7b24,_0x38982f){L('App\x20check\x20token\x20revoked:\x20'+_0x5b7b24+'/'+_0x38982f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5b7b24==='invalid_token'||_0x5b7b24==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x223a18){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x223a18):'msg'in _0x223a18&&console['log']('FIREBASE:\x20'+_0x223a18['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x406463 of this['listens']['values']())for(const _0x522ef9 of _0x406463['values']())this['sendListen_'](_0x522ef9);for(let _0x257e87=0x0;_0x257e87<this['outstandingPuts_']['length'];_0x257e87++)this['outstandingPuts_'][_0x257e87]&&this['sendPut_'](_0x257e87);for(;this['onDisconnectRequestQueue_']['length'];){const _0x10914e=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x10914e['action'],_0x10914e['pathString'],_0x10914e['data'],_0x10914e['onComplete']);}for(let _0x541c89=0x0;_0x541c89<this['outstandingGets_']['length'];_0x541c89++)this['outstandingGets_'][_0x541c89]&&this['sendGet_'](_0x541c89);}['sendConnectStats_'](){const _0x50c7f5={};let _0x491f03='js';_0x50c7f5['sdk.'+_0x491f03+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x50c7f5['framework.cordova']=0x1:Kr()&&(_0x50c7f5['framework.reactnative']=0x1),this['reportStats'](_0x50c7f5);}['shouldReconnect_'](){const _0x5c3080=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5c3080;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x43930c,_0x39aeb1){this['name']=_0x43930c,this['node']=_0x39aeb1;}static['Wrap'](_0x29594f,_0x11e263){return new E(_0x29594f,_0x11e263);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4ec3c3,_0x196bdc){const _0x5c50ac=new E(Ue,_0x4ec3c3),_0x546ee4=new E(Ue,_0x196bdc);return this['compare'](_0x5c50ac,_0x546ee4)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x18b3f1){sn=_0x18b3f1;}['compare'](_0x44bb30,_0x402729){return Ge(_0x44bb30['name'],_0x402729['name']);}['isDefinedOn'](_0x5a91b8){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x42c3e2,_0x22d4ad){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x3fff6e,_0x46cad1){return f(typeof _0x3fff6e=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3fff6e,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x6f0fc5,_0x4fcd7b,_0x2c2cfa,_0x2a0e48,_0x3751cb=null){this['isReverse_']=_0x2a0e48,this['resultGenerator_']=_0x3751cb,this['nodeStack_']=[];let _0x1bf5d3=0x1;for(;!_0x6f0fc5['isEmpty']();)if(_0x6f0fc5=_0x6f0fc5,_0x1bf5d3=_0x4fcd7b?_0x2c2cfa(_0x6f0fc5['key'],_0x4fcd7b):0x1,_0x2a0e48&&(_0x1bf5d3*=-0x1),_0x1bf5d3<0x0)this['isReverse_']?_0x6f0fc5=_0x6f0fc5['left']:_0x6f0fc5=_0x6f0fc5['right'];else{if(_0x1bf5d3===0x0){this['nodeStack_']['push'](_0x6f0fc5);break;}else this['nodeStack_']['push'](_0x6f0fc5),this['isReverse_']?_0x6f0fc5=_0x6f0fc5['right']:_0x6f0fc5=_0x6f0fc5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2c0150=this['nodeStack_']['pop'](),_0x194b0e;if(this['resultGenerator_']?_0x194b0e=this['resultGenerator_'](_0x2c0150['key'],_0x2c0150['value']):_0x194b0e={'key':_0x2c0150['key'],'value':_0x2c0150['value']},this['isReverse_']){for(_0x2c0150=_0x2c0150['left'];!_0x2c0150['isEmpty']();)this['nodeStack_']['push'](_0x2c0150),_0x2c0150=_0x2c0150['right'];}else{for(_0x2c0150=_0x2c0150['right'];!_0x2c0150['isEmpty']();)this['nodeStack_']['push'](_0x2c0150),_0x2c0150=_0x2c0150['left'];}return _0x194b0e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x275bf3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x275bf3['key'],_0x275bf3['value']):{'key':_0x275bf3['key'],'value':_0x275bf3['value']};}}class M{constructor(_0x4b704c,_0x3813b5,_0x3c9647,_0x34f1bc,_0x4a0a2d){this['key']=_0x4b704c,this['value']=_0x3813b5,this['color']=_0x3c9647??M['RED'],this['left']=_0x34f1bc??B['EMPTY_NODE'],this['right']=_0x4a0a2d??B['EMPTY_NODE'];}['copy'](_0x3dd59f,_0x246df7,_0x59ed3d,_0xae6b4b,_0xb38618){return new M(_0x3dd59f??this['key'],_0x246df7??this['value'],_0x59ed3d??this['color'],_0xae6b4b??this['left'],_0xb38618??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3c8bcc){return this['left']['inorderTraversal'](_0x3c8bcc)||!!_0x3c8bcc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3c8bcc);}['reverseTraversal'](_0x4069b2){return this['right']['reverseTraversal'](_0x4069b2)||_0x4069b2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4069b2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1472a8,_0x5f05b6,_0x1ef7d1){let _0x2bbe19=this;const _0x5b3475=_0x1ef7d1(_0x1472a8,_0x2bbe19['key']);return _0x5b3475<0x0?_0x2bbe19=_0x2bbe19['copy'](null,null,null,_0x2bbe19['left']['insert'](_0x1472a8,_0x5f05b6,_0x1ef7d1),null):_0x5b3475===0x0?_0x2bbe19=_0x2bbe19['copy'](null,_0x5f05b6,null,null,null):_0x2bbe19=_0x2bbe19['copy'](null,null,null,null,_0x2bbe19['right']['insert'](_0x1472a8,_0x5f05b6,_0x1ef7d1)),_0x2bbe19['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x49409e=this;return!_0x49409e['left']['isRed_']()&&!_0x49409e['left']['left']['isRed_']()&&(_0x49409e=_0x49409e['moveRedLeft_']()),_0x49409e=_0x49409e['copy'](null,null,null,_0x49409e['left']['removeMin_'](),null),_0x49409e['fixUp_']();}['remove'](_0x189d60,_0x421cc3){let _0x2085d1,_0x13cb19;if(_0x2085d1=this,_0x421cc3(_0x189d60,_0x2085d1['key'])<0x0)!_0x2085d1['left']['isEmpty']()&&!_0x2085d1['left']['isRed_']()&&!_0x2085d1['left']['left']['isRed_']()&&(_0x2085d1=_0x2085d1['moveRedLeft_']()),_0x2085d1=_0x2085d1['copy'](null,null,null,_0x2085d1['left']['remove'](_0x189d60,_0x421cc3),null);else{if(_0x2085d1['left']['isRed_']()&&(_0x2085d1=_0x2085d1['rotateRight_']()),!_0x2085d1['right']['isEmpty']()&&!_0x2085d1['right']['isRed_']()&&!_0x2085d1['right']['left']['isRed_']()&&(_0x2085d1=_0x2085d1['moveRedRight_']()),_0x421cc3(_0x189d60,_0x2085d1['key'])===0x0){if(_0x2085d1['right']['isEmpty']())return B['EMPTY_NODE'];_0x13cb19=_0x2085d1['right']['min_'](),_0x2085d1=_0x2085d1['copy'](_0x13cb19['key'],_0x13cb19['value'],null,null,_0x2085d1['right']['removeMin_']());}_0x2085d1=_0x2085d1['copy'](null,null,null,null,_0x2085d1['right']['remove'](_0x189d60,_0x421cc3));}return _0x2085d1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x331ac5=this;return _0x331ac5['right']['isRed_']()&&!_0x331ac5['left']['isRed_']()&&(_0x331ac5=_0x331ac5['rotateLeft_']()),_0x331ac5['left']['isRed_']()&&_0x331ac5['left']['left']['isRed_']()&&(_0x331ac5=_0x331ac5['rotateRight_']()),_0x331ac5['left']['isRed_']()&&_0x331ac5['right']['isRed_']()&&(_0x331ac5=_0x331ac5['colorFlip_']()),_0x331ac5;}['moveRedLeft_'](){let _0x3c33fc=this['colorFlip_']();return _0x3c33fc['right']['left']['isRed_']()&&(_0x3c33fc=_0x3c33fc['copy'](null,null,null,null,_0x3c33fc['right']['rotateRight_']()),_0x3c33fc=_0x3c33fc['rotateLeft_'](),_0x3c33fc=_0x3c33fc['colorFlip_']()),_0x3c33fc;}['moveRedRight_'](){let _0x58e106=this['colorFlip_']();return _0x58e106['left']['left']['isRed_']()&&(_0x58e106=_0x58e106['rotateRight_'](),_0x58e106=_0x58e106['colorFlip_']()),_0x58e106;}['rotateLeft_'](){const _0x2f4590=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2f4590,null);}['rotateRight_'](){const _0x118ea3=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x118ea3);}['colorFlip_'](){const _0xe70ff7=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3e36e8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xe70ff7,_0x3e36e8);}['checkMaxDepth_'](){const _0x281f49=this['check_']();return Math['pow'](0x2,_0x281f49)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x7f0615=this['left']['check_']();if(_0x7f0615!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x7f0615+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xc7891b,_0x30356f,_0x589bad,_0x232a86,_0x48e71a){return this;}['insert'](_0x3c35f6,_0x594560,_0x5e3757){return new M(_0x3c35f6,_0x594560,null);}['remove'](_0x4ac105,_0xc2ed41){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5e321f){return!0x1;}['reverseTraversal'](_0x1ca6ef){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x3da8d1,_0x15572f=B['EMPTY_NODE']){this['comparator_']=_0x3da8d1,this['root_']=_0x15572f;}['insert'](_0x4b8c2a,_0x5e0a8e){return new B(this['comparator_'],this['root_']['insert'](_0x4b8c2a,_0x5e0a8e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x478887){return new B(this['comparator_'],this['root_']['remove'](_0x478887,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1af346){let _0x2aa3a2,_0xce4889=this['root_'];for(;!_0xce4889['isEmpty']();){if(_0x2aa3a2=this['comparator_'](_0x1af346,_0xce4889['key']),_0x2aa3a2===0x0)return _0xce4889['value'];_0x2aa3a2<0x0?_0xce4889=_0xce4889['left']:_0x2aa3a2>0x0&&(_0xce4889=_0xce4889['right']);}return null;}['getPredecessorKey'](_0x37fd47){let _0x2b4533,_0x1af55f=this['root_'],_0x465cf6=null;for(;!_0x1af55f['isEmpty']();)if(_0x2b4533=this['comparator_'](_0x37fd47,_0x1af55f['key']),_0x2b4533===0x0){if(_0x1af55f['left']['isEmpty']())return _0x465cf6?_0x465cf6['key']:null;for(_0x1af55f=_0x1af55f['left'];!_0x1af55f['right']['isEmpty']();)_0x1af55f=_0x1af55f['right'];return _0x1af55f['key'];}else _0x2b4533<0x0?_0x1af55f=_0x1af55f['left']:_0x2b4533>0x0&&(_0x465cf6=_0x1af55f,_0x1af55f=_0x1af55f['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x22522b){return this['root_']['inorderTraversal'](_0x22522b);}['reverseTraversal'](_0x33bd99){return this['root_']['reverseTraversal'](_0x33bd99);}['getIterator'](_0x3a590d){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x3a590d);}['getIteratorFrom'](_0x33d76e,_0x54ee57){return new rn(this['root_'],_0x33d76e,this['comparator_'],!0x1,_0x54ee57);}['getReverseIteratorFrom'](_0xdcaa35,_0x34a91c){return new rn(this['root_'],_0xdcaa35,this['comparator_'],!0x0,_0x34a91c);}['getReverseIterator'](_0x4f7f7e){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x4f7f7e);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x140a21,_0x2a992c){return Ge(_0x140a21['name'],_0x2a992c['name']);}function Qi(_0x42a9aa,_0x198d90){return Ge(_0x42a9aa,_0x198d90);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x8a408b){Ci=_0x8a408b;}const No=function(_0x36040e){return typeof _0x36040e=='number'?'number:'+ao(_0x36040e):'string:'+_0x36040e;},Po=function(_0x173916){if(_0x173916['isLeafNode']()){const _0x4e8ad7=_0x173916['val']();f(typeof _0x4e8ad7=='string'||typeof _0x4e8ad7=='number'||typeof _0x4e8ad7=='object'&&Q(_0x4e8ad7,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x173916===Ci||_0x173916['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x173916===Ci||_0x173916['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x3d7cae){nr=_0x3d7cae;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x248b4a,_0x2f1a6d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x248b4a,this['priorityNode_']=_0x2f1a6d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3eca07){return new D(this['value_'],_0x3eca07);}['getImmediateChild'](_0x5af113){return _0x5af113==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x525151){return v(_0x525151)?this:y(_0x525151)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x19b226,_0xabf990){return null;}['updateImmediateChild'](_0x4d0cd5,_0x548862){return _0x4d0cd5==='.priority'?this['updatePriority'](_0x548862):_0x548862['isEmpty']()&&_0x4d0cd5!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4d0cd5,_0x548862)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5db78a,_0x3c121a){const _0x3b766b=y(_0x5db78a);return _0x3b766b===null?_0x3c121a:_0x3c121a['isEmpty']()&&_0x3b766b!=='.priority'?this:(f(_0x3b766b!=='.priority'||Ce(_0x5db78a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3b766b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x5db78a),_0x3c121a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x9f4362,_0x279ec8){return!0x1;}['val'](_0x404c7f){return _0x404c7f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3e0be9='';this['priorityNode_']['isEmpty']()||(_0x3e0be9+='priority:'+No(this['priorityNode_']['val']())+':');const _0xcaea5c=typeof this['value_'];_0x3e0be9+=_0xcaea5c+':',_0xcaea5c==='number'?_0x3e0be9+=ao(this['value_']):_0x3e0be9+=this['value_'],this['lazyHash_']=ro(_0x3e0be9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x20c713){return _0x20c713===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x20c713 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x20c713['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x20c713));}['compareToLeafNode_'](_0x37ec98){const _0x2ded3b=typeof _0x37ec98['value_'],_0x56ced8=typeof this['value_'],_0x571846=D['VALUE_TYPE_ORDER']['indexOf'](_0x2ded3b),_0x4d5f05=D['VALUE_TYPE_ORDER']['indexOf'](_0x56ced8);return f(_0x571846>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2ded3b),f(_0x4d5f05>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x56ced8),_0x571846===_0x4d5f05?_0x56ced8==='object'?0x0:this['value_']<_0x37ec98['value_']?-0x1:this['value_']===_0x37ec98['value_']?0x0:0x1:_0x4d5f05-_0x571846;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x445929){if(_0x445929===this)return!0x0;if(_0x445929['isLeafNode']()){const _0x560d6f=_0x445929;return this['value_']===_0x560d6f['value_']&&this['priorityNode_']['equals'](_0x560d6f['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x4f140b){Oo=_0x4f140b;}function Wh(_0x4f1cc8){Do=_0x4f1cc8;}class Bh extends Fn{['compare'](_0x32701f,_0x2ffde7){const _0x517ab5=_0x32701f['node']['getPriority'](),_0x53d63f=_0x2ffde7['node']['getPriority'](),_0x29a238=_0x517ab5['compareTo'](_0x53d63f);return _0x29a238===0x0?Ge(_0x32701f['name'],_0x2ffde7['name']):_0x29a238;}['isDefinedOn'](_0x1adcbd){return!_0x1adcbd['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x151b1d,_0x18f0b5){return!_0x151b1d['getPriority']()['equals'](_0x18f0b5['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x37df90,_0x29a32d){const _0x592522=Oo(_0x37df90);return new E(_0x29a32d,new D('[PRIORITY-POST]',_0x592522));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1da610){const _0x31647e=_0x5b5e2c=>parseInt(Math['log'](_0x5b5e2c)/Vh,0xa),_0x4f21c4=_0x302f9d=>parseInt(Array(_0x302f9d+0x1)['join']('1'),0x2);this['count']=_0x31647e(_0x1da610+0x1),this['current_']=this['count']-0x1;const _0x515b40=_0x4f21c4(this['count']);this['bits_']=_0x1da610+0x1&_0x515b40;}['nextBitIsOne'](){const _0x426831=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x426831;}}const yn=function(_0x5bb1bf,_0x3a991a,_0x33a4fa,_0x56a5b5){_0x5bb1bf['sort'](_0x3a991a);const _0x31b191=function(_0x402123,_0x1808d9){const _0x4ebec2=_0x1808d9-_0x402123;let _0x4fcc76,_0x5c35a9;if(_0x4ebec2===0x0)return null;if(_0x4ebec2===0x1)return _0x4fcc76=_0x5bb1bf[_0x402123],_0x5c35a9=_0x33a4fa?_0x33a4fa(_0x4fcc76):_0x4fcc76,new M(_0x5c35a9,_0x4fcc76['node'],M['BLACK'],null,null);{const _0x534c1b=parseInt(_0x4ebec2/0x2,0xa)+_0x402123,_0x5b7494=_0x31b191(_0x402123,_0x534c1b),_0x1a37ef=_0x31b191(_0x534c1b+0x1,_0x1808d9);return _0x4fcc76=_0x5bb1bf[_0x534c1b],_0x5c35a9=_0x33a4fa?_0x33a4fa(_0x4fcc76):_0x4fcc76,new M(_0x5c35a9,_0x4fcc76['node'],M['BLACK'],_0x5b7494,_0x1a37ef);}},_0x5d7dd1=function(_0x46dd15){let _0x9cf785=null,_0x6024f4=null,_0xa02419=_0x5bb1bf['length'];const _0x292198=function(_0x127d96,_0xe4fb59){const _0x56fccd=_0xa02419-_0x127d96,_0x52a563=_0xa02419;_0xa02419-=_0x127d96;const _0x273ad3=_0x31b191(_0x56fccd+0x1,_0x52a563),_0x3b5bfc=_0x5bb1bf[_0x56fccd],_0x331a1c=_0x33a4fa?_0x33a4fa(_0x3b5bfc):_0x3b5bfc;_0x207763(new M(_0x331a1c,_0x3b5bfc['node'],_0xe4fb59,null,_0x273ad3));},_0x207763=function(_0x5dfeae){_0x9cf785?(_0x9cf785['left']=_0x5dfeae,_0x9cf785=_0x5dfeae):(_0x6024f4=_0x5dfeae,_0x9cf785=_0x5dfeae);};for(let _0x479a54=0x0;_0x479a54<_0x46dd15['count'];++_0x479a54){const _0x372b50=_0x46dd15['nextBitIsOne'](),_0xefd9ea=Math['pow'](0x2,_0x46dd15['count']-(_0x479a54+0x1));_0x372b50?_0x292198(_0xefd9ea,M['BLACK']):(_0x292198(_0xefd9ea,M['BLACK']),_0x292198(_0xefd9ea,M['RED']));}return _0x6024f4;},_0x3e037a=new Hh(_0x5bb1bf['length']),_0x300900=_0x5d7dd1(_0x3e037a);return new B(_0x56a5b5||_0x3a991a,_0x300900);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3a55e0,_0x18e693){this['indexes_']=_0x3a55e0,this['indexSet_']=_0x18e693;}['get'](_0x34f887){const _0x267768=Me(this['indexes_'],_0x34f887);if(!_0x267768)throw new Error('No\x20index\x20defined\x20for\x20'+_0x34f887);return _0x267768 instanceof B?_0x267768:null;}['hasIndex'](_0x51a8b3){return Q(this['indexSet_'],_0x51a8b3['toString']());}['addIndex'](_0x2347c9,_0x2e8793){f(_0x2347c9!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x5ca446=[];let _0x636370=!0x1;const _0xc78112=_0x2e8793['getIterator'](E['Wrap']);let _0x3cb9d6=_0xc78112['getNext']();for(;_0x3cb9d6;)_0x636370=_0x636370||_0x2347c9['isDefinedOn'](_0x3cb9d6['node']),_0x5ca446['push'](_0x3cb9d6),_0x3cb9d6=_0xc78112['getNext']();let _0x26b8c3;_0x636370?_0x26b8c3=yn(_0x5ca446,_0x2347c9['getCompare']()):_0x26b8c3=Qe;const _0x5dc3a1=_0x2347c9['toString'](),_0x39a9cf={...this['indexSet_']};_0x39a9cf[_0x5dc3a1]=_0x2347c9;const _0x240729={...this['indexes_']};return _0x240729[_0x5dc3a1]=_0x26b8c3,new te(_0x240729,_0x39a9cf);}['addToIndexes'](_0x25e836,_0x15f182){const _0x6fe6a2=_n(this['indexes_'],(_0x1385a3,_0x344a56)=>{const _0x3439c9=Me(this['indexSet_'],_0x344a56);if(f(_0x3439c9,'Missing\x20index\x20implementation\x20for\x20'+_0x344a56),_0x1385a3===Qe){if(_0x3439c9['isDefinedOn'](_0x25e836['node'])){const _0x58006e=[],_0x51bfd3=_0x15f182['getIterator'](E['Wrap']);let _0x4a2b15=_0x51bfd3['getNext']();for(;_0x4a2b15;)_0x4a2b15['name']!==_0x25e836['name']&&_0x58006e['push'](_0x4a2b15),_0x4a2b15=_0x51bfd3['getNext']();return _0x58006e['push'](_0x25e836),yn(_0x58006e,_0x3439c9['getCompare']());}else return Qe;}else{const _0x5a1e6c=_0x15f182['get'](_0x25e836['name']);let _0xf1b0c9=_0x1385a3;return _0x5a1e6c&&(_0xf1b0c9=_0xf1b0c9['remove'](new E(_0x25e836['name'],_0x5a1e6c))),_0xf1b0c9['insert'](_0x25e836,_0x25e836['node']);}});return new te(_0x6fe6a2,this['indexSet_']);}['removeFromIndexes'](_0x9f5a74,_0x5eceeb){const _0x1b3eb0=_n(this['indexes_'],_0x4b2bc0=>{if(_0x4b2bc0===Qe)return _0x4b2bc0;{const _0x2329dd=_0x5eceeb['get'](_0x9f5a74['name']);return _0x2329dd?_0x4b2bc0['remove'](new E(_0x9f5a74['name'],_0x2329dd)):_0x4b2bc0;}});return new te(_0x1b3eb0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x36ffe6,_0x1f2930,_0x1e92a6){this['children_']=_0x36ffe6,this['priorityNode_']=_0x1f2930,this['indexMap_']=_0x1e92a6,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x248853){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x248853,this['indexMap_']);}['getImmediateChild'](_0x50d9f4){if(_0x50d9f4==='.priority')return this['getPriority']();{const _0x7241e3=this['children_']['get'](_0x50d9f4);return _0x7241e3===null?Et:_0x7241e3;}}['getChild'](_0x151f51){const _0x92bfb7=y(_0x151f51);return _0x92bfb7===null?this:this['getImmediateChild'](_0x92bfb7)['getChild'](S(_0x151f51));}['hasChild'](_0x4dd72f){return this['children_']['get'](_0x4dd72f)!==null;}['updateImmediateChild'](_0x3e894b,_0x30fdcc){if(f(_0x30fdcc,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3e894b==='.priority')return this['updatePriority'](_0x30fdcc);{const _0x1b03ef=new E(_0x3e894b,_0x30fdcc);let _0x118a59,_0x6082c3;_0x30fdcc['isEmpty']()?(_0x118a59=this['children_']['remove'](_0x3e894b),_0x6082c3=this['indexMap_']['removeFromIndexes'](_0x1b03ef,this['children_'])):(_0x118a59=this['children_']['insert'](_0x3e894b,_0x30fdcc),_0x6082c3=this['indexMap_']['addToIndexes'](_0x1b03ef,this['children_']));const _0x230788=_0x118a59['isEmpty']()?Et:this['priorityNode_'];return new g(_0x118a59,_0x230788,_0x6082c3);}}['updateChild'](_0x141453,_0x146235){const _0x945091=y(_0x141453);if(_0x945091===null)return _0x146235;{f(y(_0x141453)!=='.priority'||Ce(_0x141453)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xb203b5=this['getImmediateChild'](_0x945091)['updateChild'](S(_0x141453),_0x146235);return this['updateImmediateChild'](_0x945091,_0xb203b5);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x6115c0){if(this['isEmpty']())return null;const _0x394172={};let _0x5ad0e4=0x0,_0x5b1b14=0x0,_0x413f95=!0x0;if(this['forEachChild'](R,(_0x27582a,_0x573fdd)=>{_0x394172[_0x27582a]=_0x573fdd['val'](_0x6115c0),_0x5ad0e4++,_0x413f95&&g['INTEGER_REGEXP_']['test'](_0x27582a)?_0x5b1b14=Math['max'](_0x5b1b14,Number(_0x27582a)):_0x413f95=!0x1;}),!_0x6115c0&&_0x413f95&&_0x5b1b14<0x2*_0x5ad0e4){const _0x2377d7=[];for(const _0x56827f in _0x394172)_0x2377d7[_0x56827f]=_0x394172[_0x56827f];return _0x2377d7;}else return _0x6115c0&&!this['getPriority']()['isEmpty']()&&(_0x394172['.priority']=this['getPriority']()['val']()),_0x394172;}['hash'](){if(this['lazyHash_']===null){let _0x3ca9f2='';this['getPriority']()['isEmpty']()||(_0x3ca9f2+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3ad995,_0x56b3bc)=>{const _0xb9e837=_0x56b3bc['hash']();_0xb9e837!==''&&(_0x3ca9f2+=':'+_0x3ad995+':'+_0xb9e837);}),this['lazyHash_']=_0x3ca9f2===''?'':ro(_0x3ca9f2);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4ca32b,_0x567248,_0x142473){const _0x3eb452=this['resolveIndex_'](_0x142473);if(_0x3eb452){const _0x9a09ff=_0x3eb452['getPredecessorKey'](new E(_0x4ca32b,_0x567248));return _0x9a09ff?_0x9a09ff['name']:null;}else return this['children_']['getPredecessorKey'](_0x4ca32b);}['getFirstChildName'](_0x31903f){const _0x469bdb=this['resolveIndex_'](_0x31903f);if(_0x469bdb){const _0x22c587=_0x469bdb['minKey']();return _0x22c587&&_0x22c587['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x436fd0){const _0x18b2de=this['getFirstChildName'](_0x436fd0);return _0x18b2de?new E(_0x18b2de,this['children_']['get'](_0x18b2de)):null;}['getLastChildName'](_0x4a93f8){const _0x1bf9f9=this['resolveIndex_'](_0x4a93f8);if(_0x1bf9f9){const _0x51dd2a=_0x1bf9f9['maxKey']();return _0x51dd2a&&_0x51dd2a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4595b3){const _0x3070e0=this['getLastChildName'](_0x4595b3);return _0x3070e0?new E(_0x3070e0,this['children_']['get'](_0x3070e0)):null;}['forEachChild'](_0xaa42b5,_0x3205b6){const _0xfd3a82=this['resolveIndex_'](_0xaa42b5);return _0xfd3a82?_0xfd3a82['inorderTraversal'](_0x40e0e2=>_0x3205b6(_0x40e0e2['name'],_0x40e0e2['node'])):this['children_']['inorderTraversal'](_0x3205b6);}['getIterator'](_0x1951f2){return this['getIteratorFrom'](_0x1951f2['minPost'](),_0x1951f2);}['getIteratorFrom'](_0x411dbd,_0x5316ae){const _0x50e00b=this['resolveIndex_'](_0x5316ae);if(_0x50e00b)return _0x50e00b['getIteratorFrom'](_0x411dbd,_0x282b18=>_0x282b18);{const _0x422112=this['children_']['getIteratorFrom'](_0x411dbd['name'],E['Wrap']);let _0x4f3a30=_0x422112['peek']();for(;_0x4f3a30!=null&&_0x5316ae['compare'](_0x4f3a30,_0x411dbd)<0x0;)_0x422112['getNext'](),_0x4f3a30=_0x422112['peek']();return _0x422112;}}['getReverseIterator'](_0x160b09){return this['getReverseIteratorFrom'](_0x160b09['maxPost'](),_0x160b09);}['getReverseIteratorFrom'](_0x265224,_0x268c5a){const _0x55d7f9=this['resolveIndex_'](_0x268c5a);if(_0x55d7f9)return _0x55d7f9['getReverseIteratorFrom'](_0x265224,_0x276318=>_0x276318);{const _0x257e55=this['children_']['getReverseIteratorFrom'](_0x265224['name'],E['Wrap']);let _0x325960=_0x257e55['peek']();for(;_0x325960!=null&&_0x268c5a['compare'](_0x325960,_0x265224)>0x0;)_0x257e55['getNext'](),_0x325960=_0x257e55['peek']();return _0x257e55;}}['compareTo'](_0x4bc988){return this['isEmpty']()?_0x4bc988['isEmpty']()?0x0:-0x1:_0x4bc988['isLeafNode']()||_0x4bc988['isEmpty']()?0x1:_0x4bc988===jt?-0x1:0x0;}['withIndex'](_0x1b3ff0){if(_0x1b3ff0===ve||this['indexMap_']['hasIndex'](_0x1b3ff0))return this;{const _0x327738=this['indexMap_']['addIndex'](_0x1b3ff0,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x327738);}}['isIndexed'](_0x4271d9){return _0x4271d9===ve||this['indexMap_']['hasIndex'](_0x4271d9);}['equals'](_0x4e8c6e){if(_0x4e8c6e===this)return!0x0;if(_0x4e8c6e['isLeafNode']())return!0x1;{const _0x5af9c5=_0x4e8c6e;if(this['getPriority']()['equals'](_0x5af9c5['getPriority']())){if(this['children_']['count']()===_0x5af9c5['children_']['count']()){const _0x4b292e=this['getIterator'](R),_0x47abd7=_0x5af9c5['getIterator'](R);let _0x3ffa8a=_0x4b292e['getNext'](),_0x407adf=_0x47abd7['getNext']();for(;_0x3ffa8a&&_0x407adf;){if(_0x3ffa8a['name']!==_0x407adf['name']||!_0x3ffa8a['node']['equals'](_0x407adf['node']))return!0x1;_0x3ffa8a=_0x4b292e['getNext'](),_0x407adf=_0x47abd7['getNext']();}return _0x3ffa8a===null&&_0x407adf===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5cdf68){return _0x5cdf68===ve?null:this['indexMap_']['get'](_0x5cdf68['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4f9322){return _0x4f9322===this?0x0:0x1;}['equals'](_0x38038c){return _0x38038c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x48c7eb){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x2bcb59,_0x34f906=null){if(_0x2bcb59===null)return g['EMPTY_NODE'];if(typeof _0x2bcb59=='object'&&'.priority'in _0x2bcb59&&(_0x34f906=_0x2bcb59['.priority']),f(_0x34f906===null||typeof _0x34f906=='string'||typeof _0x34f906=='number'||typeof _0x34f906=='object'&&'.sv'in _0x34f906,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x34f906),typeof _0x2bcb59=='object'&&'.value'in _0x2bcb59&&_0x2bcb59['.value']!==null&&(_0x2bcb59=_0x2bcb59['.value']),typeof _0x2bcb59!='object'||'.sv'in _0x2bcb59){const _0x3ca679=_0x2bcb59;return new D(_0x3ca679,A(_0x34f906));}if(!(_0x2bcb59 instanceof Array)&&Gh){const _0x978e21=[];let _0x5898f2=!0x1;if(x(_0x2bcb59,(_0x3a89a4,_0xfb7738)=>{if(_0x3a89a4['substring'](0x0,0x1)!=='.'){const _0x59423e=A(_0xfb7738);_0x59423e['isEmpty']()||(_0x5898f2=_0x5898f2||!_0x59423e['getPriority']()['isEmpty'](),_0x978e21['push'](new E(_0x3a89a4,_0x59423e)));}}),_0x978e21['length']===0x0)return g['EMPTY_NODE'];const _0x1b2cd2=yn(_0x978e21,xh,_0x55e2f0=>_0x55e2f0['name'],Qi);if(_0x5898f2){const _0x10a64c=yn(_0x978e21,R['getCompare']());return new g(_0x1b2cd2,A(_0x34f906),new te({'.priority':_0x10a64c},{'.priority':R}));}else return new g(_0x1b2cd2,A(_0x34f906),te['Default']);}else{let _0x381d6a=g['EMPTY_NODE'];return x(_0x2bcb59,(_0x48794f,_0x559f03)=>{if(Q(_0x2bcb59,_0x48794f)&&_0x48794f['substring'](0x0,0x1)!=='.'){const _0x2281dd=A(_0x559f03);(_0x2281dd['isLeafNode']()||!_0x2281dd['isEmpty']())&&(_0x381d6a=_0x381d6a['updateImmediateChild'](_0x48794f,_0x2281dd));}}),_0x381d6a['updatePriority'](A(_0x34f906));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x52afc4){super(),this['indexPath_']=_0x52afc4,f(!v(_0x52afc4)&&y(_0x52afc4)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3b5906){return _0x3b5906['getChild'](this['indexPath_']);}['isDefinedOn'](_0xe52865){return!_0xe52865['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x25f542,_0x1fd5bf){const _0x1c0799=this['extractChild'](_0x25f542['node']),_0xde4524=this['extractChild'](_0x1fd5bf['node']),_0x1ab283=_0x1c0799['compareTo'](_0xde4524);return _0x1ab283===0x0?Ge(_0x25f542['name'],_0x1fd5bf['name']):_0x1ab283;}['makePost'](_0x537310,_0x883b90){const _0x24509e=A(_0x537310),_0x4b57ab=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x24509e);return new E(_0x883b90,_0x4b57ab);}['maxPost'](){const _0x4867dd=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x4867dd);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x1668a6,_0x4d3c76){const _0x42b9eb=_0x1668a6['node']['compareTo'](_0x4d3c76['node']);return _0x42b9eb===0x0?Ge(_0x1668a6['name'],_0x4d3c76['name']):_0x42b9eb;}['isDefinedOn'](_0x55e0cb){return!0x0;}['indexedValueChanged'](_0x10a517,_0x3dd876){return!_0x10a517['equals'](_0x3dd876);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1d2d5d,_0x11fc4c){const _0x1441bd=A(_0x1d2d5d);return new E(_0x11fc4c,_0x1441bd);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x42c049){return{'type':'value','snapshotNode':_0x42c049};}function rt(_0x3e4093,_0x482155){return{'type':'child_added','snapshotNode':_0x482155,'childName':_0x3e4093};}function Mt(_0xc19d3d,_0xdb414b){return{'type':'child_removed','snapshotNode':_0xdb414b,'childName':_0xc19d3d};}function Lt(_0x3ad3ad,_0x3ff940,_0x5d5168){return{'type':'child_changed','snapshotNode':_0x3ff940,'childName':_0x3ad3ad,'oldSnap':_0x5d5168};}function zh(_0xa738b9,_0x463e59){return{'type':'child_moved','snapshotNode':_0x463e59,'childName':_0xa738b9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0xae3696){this['index_']=_0xae3696;}['updateChild'](_0x19f450,_0x2b5dda,_0x59d752,_0x45dc4a,_0x5af1a7,_0x4e11d3){f(_0x19f450['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4de2a6=_0x19f450['getImmediateChild'](_0x2b5dda);return _0x4de2a6['getChild'](_0x45dc4a)['equals'](_0x59d752['getChild'](_0x45dc4a))&&_0x4de2a6['isEmpty']()===_0x59d752['isEmpty']()||(_0x4e11d3!=null&&(_0x59d752['isEmpty']()?_0x19f450['hasChild'](_0x2b5dda)?_0x4e11d3['trackChildChange'](Mt(_0x2b5dda,_0x4de2a6)):f(_0x19f450['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4de2a6['isEmpty']()?_0x4e11d3['trackChildChange'](rt(_0x2b5dda,_0x59d752)):_0x4e11d3['trackChildChange'](Lt(_0x2b5dda,_0x59d752,_0x4de2a6))),_0x19f450['isLeafNode']()&&_0x59d752['isEmpty']())?_0x19f450:_0x19f450['updateImmediateChild'](_0x2b5dda,_0x59d752)['withIndex'](this['index_']);}['updateFullNode'](_0x2349f7,_0x409676,_0xe1f3a5){return _0xe1f3a5!=null&&(_0x2349f7['isLeafNode']()||_0x2349f7['forEachChild'](R,(_0x50c5f3,_0x386ad4)=>{_0x409676['hasChild'](_0x50c5f3)||_0xe1f3a5['trackChildChange'](Mt(_0x50c5f3,_0x386ad4));}),_0x409676['isLeafNode']()||_0x409676['forEachChild'](R,(_0x42d32c,_0x527bf4)=>{if(_0x2349f7['hasChild'](_0x42d32c)){const _0x27a53f=_0x2349f7['getImmediateChild'](_0x42d32c);_0x27a53f['equals'](_0x527bf4)||_0xe1f3a5['trackChildChange'](Lt(_0x42d32c,_0x527bf4,_0x27a53f));}else _0xe1f3a5['trackChildChange'](rt(_0x42d32c,_0x527bf4));})),_0x409676['withIndex'](this['index_']);}['updatePriority'](_0x362971,_0x4eb742){return _0x362971['isEmpty']()?g['EMPTY_NODE']:_0x362971['updatePriority'](_0x4eb742);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x4388c3){this['indexedFilter_']=new Xi(_0x4388c3['getIndex']()),this['index_']=_0x4388c3['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x4388c3),this['endPost_']=xt['getEndPost_'](_0x4388c3),this['startIsInclusive_']=!_0x4388c3['startAfterSet_'],this['endIsInclusive_']=!_0x4388c3['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x451531){const _0x281d37=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x451531)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x451531)<0x0,_0x22c472=this['endIsInclusive_']?this['index_']['compare'](_0x451531,this['getEndPost']())<=0x0:this['index_']['compare'](_0x451531,this['getEndPost']())<0x0;return _0x281d37&&_0x22c472;}['updateChild'](_0x51c04c,_0x5045c1,_0x3d6248,_0x3fbbb3,_0x55c4bd,_0x5f95f7){return this['matches'](new E(_0x5045c1,_0x3d6248))||(_0x3d6248=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x51c04c,_0x5045c1,_0x3d6248,_0x3fbbb3,_0x55c4bd,_0x5f95f7);}['updateFullNode'](_0x3a9c8a,_0x5ef35b,_0x348f41){_0x5ef35b['isLeafNode']()&&(_0x5ef35b=g['EMPTY_NODE']);let _0x52bc8a=_0x5ef35b['withIndex'](this['index_']);_0x52bc8a=_0x52bc8a['updatePriority'](g['EMPTY_NODE']);const _0x53c5f4=this;return _0x5ef35b['forEachChild'](R,(_0x2f1115,_0x299aa8)=>{_0x53c5f4['matches'](new E(_0x2f1115,_0x299aa8))||(_0x52bc8a=_0x52bc8a['updateImmediateChild'](_0x2f1115,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3a9c8a,_0x52bc8a,_0x348f41);}['updatePriority'](_0x31a754,_0x317f2a){return _0x31a754;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3b93c4){if(_0x3b93c4['hasStart']()){const _0x359bcb=_0x3b93c4['getIndexStartName']();return _0x3b93c4['getIndex']()['makePost'](_0x3b93c4['getIndexStartValue'](),_0x359bcb);}else return _0x3b93c4['getIndex']()['minPost']();}static['getEndPost_'](_0xb6860e){if(_0xb6860e['hasEnd']()){const _0x245dc5=_0xb6860e['getIndexEndName']();return _0xb6860e['getIndex']()['makePost'](_0xb6860e['getIndexEndValue'](),_0x245dc5);}else return _0xb6860e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2d65f3){this['withinDirectionalStart']=_0x56e0f0=>this['reverse_']?this['withinEndPost'](_0x56e0f0):this['withinStartPost'](_0x56e0f0),this['withinDirectionalEnd']=_0x20f260=>this['reverse_']?this['withinStartPost'](_0x20f260):this['withinEndPost'](_0x20f260),this['withinStartPost']=_0x311b07=>{const _0x391551=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x311b07);return this['startIsInclusive_']?_0x391551<=0x0:_0x391551<0x0;},this['withinEndPost']=_0xf4a84e=>{const _0x40a964=this['index_']['compare'](_0xf4a84e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x40a964<=0x0:_0x40a964<0x0;},this['rangedFilter_']=new xt(_0x2d65f3),this['index_']=_0x2d65f3['getIndex'](),this['limit_']=_0x2d65f3['getLimit'](),this['reverse_']=!_0x2d65f3['isViewFromLeft'](),this['startIsInclusive_']=!_0x2d65f3['startAfterSet_'],this['endIsInclusive_']=!_0x2d65f3['endBeforeSet_'];}['updateChild'](_0x229b12,_0x4f6e73,_0x583a31,_0x1aca14,_0x172df4,_0xad21f3){return this['rangedFilter_']['matches'](new E(_0x4f6e73,_0x583a31))||(_0x583a31=g['EMPTY_NODE']),_0x229b12['getImmediateChild'](_0x4f6e73)['equals'](_0x583a31)?_0x229b12:_0x229b12['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x229b12,_0x4f6e73,_0x583a31,_0x1aca14,_0x172df4,_0xad21f3):this['fullLimitUpdateChild_'](_0x229b12,_0x4f6e73,_0x583a31,_0x172df4,_0xad21f3);}['updateFullNode'](_0x16927,_0x29638c,_0x11bf7f){let _0x27f316;if(_0x29638c['isLeafNode']()||_0x29638c['isEmpty']())_0x27f316=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x29638c['numChildren']()&&_0x29638c['isIndexed'](this['index_'])){_0x27f316=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x57b214;this['reverse_']?_0x57b214=_0x29638c['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x57b214=_0x29638c['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x17bbbe=0x0;for(;_0x57b214['hasNext']()&&_0x17bbbe<this['limit_'];){const _0x4c1c99=_0x57b214['getNext']();if(this['withinDirectionalStart'](_0x4c1c99)){if(this['withinDirectionalEnd'](_0x4c1c99))_0x27f316=_0x27f316['updateImmediateChild'](_0x4c1c99['name'],_0x4c1c99['node']),_0x17bbbe++;else break;}else continue;}}else{_0x27f316=_0x29638c['withIndex'](this['index_']),_0x27f316=_0x27f316['updatePriority'](g['EMPTY_NODE']);let _0x565b77;this['reverse_']?_0x565b77=_0x27f316['getReverseIterator'](this['index_']):_0x565b77=_0x27f316['getIterator'](this['index_']);let _0x1d011d=0x0;for(;_0x565b77['hasNext']();){const _0x484d13=_0x565b77['getNext']();_0x1d011d<this['limit_']&&this['withinDirectionalStart'](_0x484d13)&&this['withinDirectionalEnd'](_0x484d13)?_0x1d011d++:_0x27f316=_0x27f316['updateImmediateChild'](_0x484d13['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x16927,_0x27f316,_0x11bf7f);}['updatePriority'](_0x1a17bd,_0x5a0dde){return _0x1a17bd;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5cecd9,_0x242c48,_0x4d3801,_0x286b26,_0x140109){let _0x215dbd;if(this['reverse_']){const _0x74ef8=this['index_']['getCompare']();_0x215dbd=(_0x17574f,_0x391d0d)=>_0x74ef8(_0x391d0d,_0x17574f);}else _0x215dbd=this['index_']['getCompare']();const _0x22297a=_0x5cecd9;f(_0x22297a['numChildren']()===this['limit_'],'');const _0x192dab=new E(_0x242c48,_0x4d3801),_0xb076bd=this['reverse_']?_0x22297a['getFirstChild'](this['index_']):_0x22297a['getLastChild'](this['index_']),_0x2cd456=this['rangedFilter_']['matches'](_0x192dab);if(_0x22297a['hasChild'](_0x242c48)){const _0x3f7535=_0x22297a['getImmediateChild'](_0x242c48);let _0x548434=_0x286b26['getChildAfterChild'](this['index_'],_0xb076bd,this['reverse_']);for(;_0x548434!=null&&(_0x548434['name']===_0x242c48||_0x22297a['hasChild'](_0x548434['name']));)_0x548434=_0x286b26['getChildAfterChild'](this['index_'],_0x548434,this['reverse_']);const _0x4080da=_0x548434==null?0x1:_0x215dbd(_0x548434,_0x192dab);if(_0x2cd456&&!_0x4d3801['isEmpty']()&&_0x4080da>=0x0)return _0x140109!=null&&_0x140109['trackChildChange'](Lt(_0x242c48,_0x4d3801,_0x3f7535)),_0x22297a['updateImmediateChild'](_0x242c48,_0x4d3801);{_0x140109!=null&&_0x140109['trackChildChange'](Mt(_0x242c48,_0x3f7535));const _0x436d27=_0x22297a['updateImmediateChild'](_0x242c48,g['EMPTY_NODE']);return _0x548434!=null&&this['rangedFilter_']['matches'](_0x548434)?(_0x140109!=null&&_0x140109['trackChildChange'](rt(_0x548434['name'],_0x548434['node'])),_0x436d27['updateImmediateChild'](_0x548434['name'],_0x548434['node'])):_0x436d27;}}else return _0x4d3801['isEmpty']()?_0x5cecd9:_0x2cd456&&_0x215dbd(_0xb076bd,_0x192dab)>=0x0?(_0x140109!=null&&(_0x140109['trackChildChange'](Mt(_0xb076bd['name'],_0xb076bd['node'])),_0x140109['trackChildChange'](rt(_0x242c48,_0x4d3801))),_0x22297a['updateImmediateChild'](_0x242c48,_0x4d3801)['updateImmediateChild'](_0xb076bd['name'],g['EMPTY_NODE'])):_0x5cecd9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2d348f=new Zi();return _0x2d348f['limitSet_']=this['limitSet_'],_0x2d348f['limit_']=this['limit_'],_0x2d348f['startSet_']=this['startSet_'],_0x2d348f['startAfterSet_']=this['startAfterSet_'],_0x2d348f['indexStartValue_']=this['indexStartValue_'],_0x2d348f['startNameSet_']=this['startNameSet_'],_0x2d348f['indexStartName_']=this['indexStartName_'],_0x2d348f['endSet_']=this['endSet_'],_0x2d348f['endBeforeSet_']=this['endBeforeSet_'],_0x2d348f['indexEndValue_']=this['indexEndValue_'],_0x2d348f['endNameSet_']=this['endNameSet_'],_0x2d348f['indexEndName_']=this['indexEndName_'],_0x2d348f['index_']=this['index_'],_0x2d348f['viewFrom_']=this['viewFrom_'],_0x2d348f;}}function Kh(_0x150591){return _0x150591['loadsAllData']()?new Xi(_0x150591['getIndex']()):_0x150591['hasLimit']()?new jh(_0x150591):new xt(_0x150591);}function Yh(_0x4281af,_0x4b152b,_0x15eac6){const _0x33babf=_0x4281af['copy']();return _0x33babf['startSet_']=!0x0,_0x4b152b===void 0x0&&(_0x4b152b=null),_0x33babf['indexStartValue_']=_0x4b152b,_0x15eac6!=null?(_0x33babf['startNameSet_']=!0x0,_0x33babf['indexStartName_']=_0x15eac6):(_0x33babf['startNameSet_']=!0x1,_0x33babf['indexStartName_']=''),_0x33babf;}function Qh(_0x421c9f,_0x49c314,_0x5cab03){const _0x8109fa=_0x421c9f['copy']();return _0x8109fa['endSet_']=!0x0,_0x49c314===void 0x0&&(_0x49c314=null),_0x8109fa['indexEndValue_']=_0x49c314,_0x5cab03!==void 0x0?(_0x8109fa['endNameSet_']=!0x0,_0x8109fa['indexEndName_']=_0x5cab03):(_0x8109fa['endNameSet_']=!0x1,_0x8109fa['indexEndName_']=''),_0x8109fa;}function xo(_0x1353cb,_0x188761){const _0x4a6fdd=_0x1353cb['copy']();return _0x4a6fdd['index_']=_0x188761,_0x4a6fdd;}function ir(_0x239de8){const _0x47e0b7={};if(_0x239de8['isDefault']())return _0x47e0b7;let _0x51687e;if(_0x239de8['index_']===R?_0x51687e='$priority':_0x239de8['index_']===Mo?_0x51687e='$value':_0x239de8['index_']===ve?_0x51687e='$key':(f(_0x239de8['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x51687e=_0x239de8['index_']['toString']()),_0x47e0b7['orderBy']=O(_0x51687e),_0x239de8['startSet_']){const _0x2bea6b=_0x239de8['startAfterSet_']?'startAfter':'startAt';_0x47e0b7[_0x2bea6b]=O(_0x239de8['indexStartValue_']),_0x239de8['startNameSet_']&&(_0x47e0b7[_0x2bea6b]+=','+O(_0x239de8['indexStartName_']));}if(_0x239de8['endSet_']){const _0x419462=_0x239de8['endBeforeSet_']?'endBefore':'endAt';_0x47e0b7[_0x419462]=O(_0x239de8['indexEndValue_']),_0x239de8['endNameSet_']&&(_0x47e0b7[_0x419462]+=','+O(_0x239de8['indexEndName_']));}return _0x239de8['limitSet_']&&(_0x239de8['isViewFromLeft']()?_0x47e0b7['limitToFirst']=_0x239de8['limit_']:_0x47e0b7['limitToLast']=_0x239de8['limit_']),_0x47e0b7;}function sr(_0x241eab){const _0x4ab970={};if(_0x241eab['startSet_']&&(_0x4ab970['sp']=_0x241eab['indexStartValue_'],_0x241eab['startNameSet_']&&(_0x4ab970['sn']=_0x241eab['indexStartName_']),_0x4ab970['sin']=!_0x241eab['startAfterSet_']),_0x241eab['endSet_']&&(_0x4ab970['ep']=_0x241eab['indexEndValue_'],_0x241eab['endNameSet_']&&(_0x4ab970['en']=_0x241eab['indexEndName_']),_0x4ab970['ein']=!_0x241eab['endBeforeSet_']),_0x241eab['limitSet_']){_0x4ab970['l']=_0x241eab['limit_'];let _0x331559=_0x241eab['viewFrom_'];_0x331559===''&&(_0x241eab['isViewFromLeft']()?_0x331559='l':_0x331559='r'),_0x4ab970['vf']=_0x331559;}return _0x241eab['index_']!==R&&(_0x4ab970['i']=_0x241eab['index_']['toString']()),_0x4ab970;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x8f96aa){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x464b7e,_0x5a6b0a){return _0x5a6b0a!==void 0x0?'tag$'+_0x5a6b0a:(f(_0x464b7e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x464b7e['_path']['toString']());}constructor(_0x2dcbdc,_0x4ad667,_0x1a5a15,_0x5624f3){super(),this['repoInfo_']=_0x2dcbdc,this['onDataUpdate_']=_0x4ad667,this['authTokenProvider_']=_0x1a5a15,this['appCheckTokenProvider_']=_0x5624f3,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x5c5eb5,_0x404fce,_0x14348c,_0x140828){const _0x45a7d3=_0x5c5eb5['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x45a7d3+'\x20'+_0x5c5eb5['_queryIdentifier']);const _0x2ecac1=vn['getListenId_'](_0x5c5eb5,_0x14348c),_0x471cde={};this['listens_'][_0x2ecac1]=_0x471cde;const _0x4e3b2a=ir(_0x5c5eb5['_queryParams']);this['restRequest_'](_0x45a7d3+'.json',_0x4e3b2a,(_0x574908,_0x35e3f8)=>{let _0x3c979c=_0x35e3f8;if(_0x574908===0x194&&(_0x3c979c=null,_0x574908=null),_0x574908===null&&this['onDataUpdate_'](_0x45a7d3,_0x3c979c,!0x1,_0x14348c),Me(this['listens_'],_0x2ecac1)===_0x471cde){let _0x1d0fa2;_0x574908?_0x574908===0x191?_0x1d0fa2='permission_denied':_0x1d0fa2='rest_error:'+_0x574908:_0x1d0fa2='ok',_0x140828(_0x1d0fa2,null);}});}['unlisten'](_0x5af719,_0x30da88){const _0x43eb44=vn['getListenId_'](_0x5af719,_0x30da88);delete this['listens_'][_0x43eb44];}['get'](_0x4864fa){const _0x23489c=ir(_0x4864fa['_queryParams']),_0xde8d71=_0x4864fa['_path']['toString'](),_0x2a2bea=new H();return this['restRequest_'](_0xde8d71+'.json',_0x23489c,(_0x27373a,_0x26ec46)=>{let _0xec116c=_0x26ec46;_0x27373a===0x194&&(_0xec116c=null,_0x27373a=null),_0x27373a===null?(this['onDataUpdate_'](_0xde8d71,_0xec116c,!0x1,null),_0x2a2bea['resolve'](_0xec116c)):_0x2a2bea['reject'](new Error(_0xec116c));}),_0x2a2bea['promise'];}['refreshAuthToken'](_0x53fd38){}['restRequest_'](_0x10f90f,_0x2fd4c9={},_0x2875f6){return _0x2fd4c9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5630ec,_0x39d10e])=>{_0x5630ec&&_0x5630ec['accessToken']&&(_0x2fd4c9['auth']=_0x5630ec['accessToken']),_0x39d10e&&_0x39d10e['token']&&(_0x2fd4c9['ac']=_0x39d10e['token']);const _0x393ce4=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x10f90f+'?ns='+this['repoInfo_']['namespace']+ut(_0x2fd4c9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x393ce4);const _0x5a19bb=new XMLHttpRequest();_0x5a19bb['onreadystatechange']=()=>{if(_0x2875f6&&_0x5a19bb['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x393ce4+'\x20received.\x20status:',_0x5a19bb['status'],'response:',_0x5a19bb['responseText']);let _0x2d8065=null;if(_0x5a19bb['status']>=0xc8&&_0x5a19bb['status']<0x12c){try{_0x2d8065=Nt(_0x5a19bb['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x393ce4+':\x20'+_0x5a19bb['responseText']);}_0x2875f6(null,_0x2d8065);}else _0x5a19bb['status']!==0x191&&_0x5a19bb['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x393ce4+'\x20Status:\x20'+_0x5a19bb['status']),_0x2875f6(_0x5a19bb['status']);_0x2875f6=null;}},_0x5a19bb['open']('GET',_0x393ce4,!0x0),_0x5a19bb['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x437de7){return this['rootNode_']['getChild'](_0x437de7);}['updateSnapshot'](_0x3586c1,_0x559c47){this['rootNode_']=this['rootNode_']['updateChild'](_0x3586c1,_0x559c47);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0xdf93d2,_0x37d243,_0x19dac2){if(v(_0x37d243))_0xdf93d2['value']=_0x19dac2,_0xdf93d2['children']['clear']();else{if(_0xdf93d2['value']!==null)_0xdf93d2['value']=_0xdf93d2['value']['updateChild'](_0x37d243,_0x19dac2);else{const _0x5b0b27=y(_0x37d243);_0xdf93d2['children']['has'](_0x5b0b27)||_0xdf93d2['children']['set'](_0x5b0b27,En());const _0x177e8f=_0xdf93d2['children']['get'](_0x5b0b27);_0x37d243=S(_0x37d243),pt(_0x177e8f,_0x37d243,_0x19dac2);}}}function Ti(_0x5b00e3,_0xb1cf70){if(v(_0xb1cf70))return _0x5b00e3['value']=null,_0x5b00e3['children']['clear'](),!0x0;if(_0x5b00e3['value']!==null){if(_0x5b00e3['value']['isLeafNode']())return!0x1;{const _0x14082e=_0x5b00e3['value'];return _0x5b00e3['value']=null,_0x14082e['forEachChild'](R,(_0x100506,_0xd6a7da)=>{pt(_0x5b00e3,new C(_0x100506),_0xd6a7da);}),Ti(_0x5b00e3,_0xb1cf70);}}else{if(_0x5b00e3['children']['size']>0x0){const _0x28f809=y(_0xb1cf70);return _0xb1cf70=S(_0xb1cf70),_0x5b00e3['children']['has'](_0x28f809)&&Ti(_0x5b00e3['children']['get'](_0x28f809),_0xb1cf70)&&_0x5b00e3['children']['delete'](_0x28f809),_0x5b00e3['children']['size']===0x0;}else return!0x0;}}function Si(_0x47fd74,_0xc9d4d3,_0x3af3b6){_0x47fd74['value']!==null?_0x3af3b6(_0xc9d4d3,_0x47fd74['value']):Xh(_0x47fd74,(_0x376538,_0x119352)=>{const _0x18ba64=new C(_0xc9d4d3['toString']()+'/'+_0x376538);Si(_0x119352,_0x18ba64,_0x3af3b6);});}function Xh(_0x5a11ad,_0x4cb3d8){_0x5a11ad['children']['forEach']((_0x2ef24b,_0x324e79)=>{_0x4cb3d8(_0x324e79,_0x2ef24b);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x3ebba7){this['collection_']=_0x3ebba7,this['last_']=null;}['get'](){const _0x5f8a0=this['collection_']['get'](),_0x6a79c9={..._0x5f8a0};return this['last_']&&x(this['last_'],(_0x36eb9d,_0x149202)=>{_0x6a79c9[_0x36eb9d]=_0x6a79c9[_0x36eb9d]-_0x149202;}),this['last_']=_0x5f8a0,_0x6a79c9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x1c9a52,_0x566c41){this['server_']=_0x566c41,this['statsToReport_']={},this['statsListener_']=new Zh(_0x1c9a52);const _0x2cda60=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x2cda60));}['reportStats_'](){const _0x12bbc2=this['statsListener_']['get'](),_0x28dca7={};let _0xaf0fc=!0x1;x(_0x12bbc2,(_0x570809,_0x433774)=>{_0x433774>0x0&&Q(this['statsToReport_'],_0x570809)&&(_0x28dca7[_0x570809]=_0x433774,_0xaf0fc=!0x0);}),_0xaf0fc&&this['server_']['reportStats'](_0x28dca7),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x5ce208){_0x5ce208[_0x5ce208['OVERWRITE']=0x0]='OVERWRITE',_0x5ce208[_0x5ce208['MERGE']=0x1]='MERGE',_0x5ce208[_0x5ce208['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5ce208[_0x5ce208['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1ebf85){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1ebf85,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x4191d4,_0x3156a3,_0x4b40f2){this['path']=_0x4191d4,this['affectedTree']=_0x3156a3,this['revert']=_0x4b40f2,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3f4cac){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xe73fad=this['affectedTree']['subtree'](new C(_0x3f4cac));return new In(w(),_0xe73fad,this['revert']);}}else return f(y(this['path'])===_0x3f4cac,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2dd3dd,_0x29dde7){this['source']=_0x2dd3dd,this['path']=_0x29dde7,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x7f4f6c){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x589fea,_0x52bf5d,_0x3270d4){this['source']=_0x589fea,this['path']=_0x52bf5d,this['snap']=_0x3270d4,this['type']=z['OVERWRITE'];}['operationForChild'](_0x20dc91){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x20dc91)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4b0090,_0x1bb125,_0x57bd78){this['source']=_0x4b0090,this['path']=_0x1bb125,this['children']=_0x57bd78,this['type']=z['MERGE'];}['operationForChild'](_0x2961b1){if(v(this['path'])){const _0xf87056=this['children']['subtree'](new C(_0x2961b1));return _0xf87056['isEmpty']()?null:_0xf87056['value']?new We(this['source'],w(),_0xf87056['value']):new ot(this['source'],w(),_0xf87056);}else return f(y(this['path'])===_0x2961b1,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x462658,_0x24eae3,_0x5287bb){this['node_']=_0x462658,this['fullyInitialized_']=_0x24eae3,this['filtered_']=_0x5287bb;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x306d86){if(v(_0x306d86))return this['isFullyInitialized']()&&!this['filtered_'];const _0x11d8f1=y(_0x306d86);return this['isCompleteForChild'](_0x11d8f1);}['isCompleteForChild'](_0x1fa040){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1fa040);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0x5b20e6){this['query_']=_0x5b20e6,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x474257,_0x5d921d,_0x4727bb,_0x8662ea){const _0x141459=[],_0x179021=[];return _0x5d921d['forEach'](_0x238aaa=>{_0x238aaa['type']==='child_changed'&&_0x474257['index_']['indexedValueChanged'](_0x238aaa['oldSnap'],_0x238aaa['snapshotNode'])&&_0x179021['push'](zh(_0x238aaa['childName'],_0x238aaa['snapshotNode']));}),It(_0x474257,_0x141459,'child_removed',_0x5d921d,_0x8662ea,_0x4727bb),It(_0x474257,_0x141459,'child_added',_0x5d921d,_0x8662ea,_0x4727bb),It(_0x474257,_0x141459,'child_moved',_0x179021,_0x8662ea,_0x4727bb),It(_0x474257,_0x141459,'child_changed',_0x5d921d,_0x8662ea,_0x4727bb),It(_0x474257,_0x141459,'value',_0x5d921d,_0x8662ea,_0x4727bb),_0x141459;}function It(_0x2671e8,_0x4ab25a,_0x8d18fc,_0x5235c1,_0x40827d,_0x5efce2){const _0x2c7907=_0x5235c1['filter'](_0x4f773d=>_0x4f773d['type']===_0x8d18fc);_0x2c7907['sort']((_0x52fc52,_0x27bc1e)=>ou(_0x2671e8,_0x52fc52,_0x27bc1e)),_0x2c7907['forEach'](_0x595f79=>{const _0x28021e=ru(_0x2671e8,_0x595f79,_0x5efce2);_0x40827d['forEach'](_0x562ca3=>{_0x562ca3['respondsTo'](_0x595f79['type'])&&_0x4ab25a['push'](_0x562ca3['createEvent'](_0x28021e,_0x2671e8['query_']));});});}function ru(_0x27769d,_0xa284de,_0x3295f2){return _0xa284de['type']==='value'||_0xa284de['type']==='child_removed'||(_0xa284de['prevName']=_0x3295f2['getPredecessorChildName'](_0xa284de['childName'],_0xa284de['snapshotNode'],_0x27769d['index_'])),_0xa284de;}function ou(_0x1f6567,_0x45f516,_0x1cf31f){if(_0x45f516['childName']==null||_0x1cf31f['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x30cc03=new E(_0x45f516['childName'],_0x45f516['snapshotNode']),_0x3bbc2b=new E(_0x1cf31f['childName'],_0x1cf31f['snapshotNode']);return _0x1f6567['index_']['compare'](_0x30cc03,_0x3bbc2b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x376f64,_0x1ea390){return{'eventCache':_0x376f64,'serverCache':_0x1ea390};}function bt(_0x2c0264,_0x1eb5fd,_0x898152,_0x212768){return Un(new Te(_0x1eb5fd,_0x898152,_0x212768),_0x2c0264['serverCache']);}function Fo(_0x329f00,_0x4520bd,_0x213835,_0x462ee3){return Un(_0x329f00['eventCache'],new Te(_0x4520bd,_0x213835,_0x462ee3));}function wn(_0x525821){return _0x525821['eventCache']['isFullyInitialized']()?_0x525821['eventCache']['getNode']():null;}function Be(_0x4b9c98){return _0x4b9c98['serverCache']['isFullyInitialized']()?_0x4b9c98['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x688e6c){let _0xfbc3ab=new b(null);return x(_0x688e6c,(_0x18d17f,_0x2738d6)=>{_0xfbc3ab=_0xfbc3ab['set'](new C(_0x18d17f),_0x2738d6);}),_0xfbc3ab;}constructor(_0xee8b48,_0x24b371=au()){this['value']=_0xee8b48,this['children']=_0x24b371;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x20a605,_0x5c8927){if(this['value']!=null&&_0x5c8927(this['value']))return{'path':w(),'value':this['value']};if(v(_0x20a605))return null;{const _0x2c5e24=y(_0x20a605),_0x1fff9a=this['children']['get'](_0x2c5e24);if(_0x1fff9a!==null){const _0x318397=_0x1fff9a['findRootMostMatchingPathAndValue'](S(_0x20a605),_0x5c8927);return _0x318397!=null?{'path':k(new C(_0x2c5e24),_0x318397['path']),'value':_0x318397['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xacb180){return this['findRootMostMatchingPathAndValue'](_0xacb180,()=>!0x0);}['subtree'](_0x524f5c){if(v(_0x524f5c))return this;{const _0x299015=y(_0x524f5c),_0x559382=this['children']['get'](_0x299015);return _0x559382!==null?_0x559382['subtree'](S(_0x524f5c)):new b(null);}}['set'](_0x4a4cb9,_0x19979d){if(v(_0x4a4cb9))return new b(_0x19979d,this['children']);{const _0x3a0cab=y(_0x4a4cb9),_0x61cfb3=(this['children']['get'](_0x3a0cab)||new b(null))['set'](S(_0x4a4cb9),_0x19979d),_0x45fc75=this['children']['insert'](_0x3a0cab,_0x61cfb3);return new b(this['value'],_0x45fc75);}}['remove'](_0xb7b472){if(v(_0xb7b472))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x4228b5=y(_0xb7b472),_0x5baf67=this['children']['get'](_0x4228b5);if(_0x5baf67){const _0x35b8d2=_0x5baf67['remove'](S(_0xb7b472));let _0xf5b11a;return _0x35b8d2['isEmpty']()?_0xf5b11a=this['children']['remove'](_0x4228b5):_0xf5b11a=this['children']['insert'](_0x4228b5,_0x35b8d2),this['value']===null&&_0xf5b11a['isEmpty']()?new b(null):new b(this['value'],_0xf5b11a);}else return this;}}['get'](_0x2dc2e7){if(v(_0x2dc2e7))return this['value'];{const _0x4c5e26=y(_0x2dc2e7),_0x33d98c=this['children']['get'](_0x4c5e26);return _0x33d98c?_0x33d98c['get'](S(_0x2dc2e7)):null;}}['setTree'](_0x5da4f9,_0x3db13a){if(v(_0x5da4f9))return _0x3db13a;{const _0x11d3c4=y(_0x5da4f9),_0x4d01d8=(this['children']['get'](_0x11d3c4)||new b(null))['setTree'](S(_0x5da4f9),_0x3db13a);let _0x6c3da4;return _0x4d01d8['isEmpty']()?_0x6c3da4=this['children']['remove'](_0x11d3c4):_0x6c3da4=this['children']['insert'](_0x11d3c4,_0x4d01d8),new b(this['value'],_0x6c3da4);}}['fold'](_0x4a13ae){return this['fold_'](w(),_0x4a13ae);}['fold_'](_0x47e332,_0x2d7330){const _0x2e0862={};return this['children']['inorderTraversal']((_0x5a93f8,_0x4c702b)=>{_0x2e0862[_0x5a93f8]=_0x4c702b['fold_'](k(_0x47e332,_0x5a93f8),_0x2d7330);}),_0x2d7330(_0x47e332,this['value'],_0x2e0862);}['findOnPath'](_0x997023,_0x3f9990){return this['findOnPath_'](_0x997023,w(),_0x3f9990);}['findOnPath_'](_0x3a1be6,_0x13e88a,_0x180a09){const _0x22e0b9=this['value']?_0x180a09(_0x13e88a,this['value']):!0x1;if(_0x22e0b9)return _0x22e0b9;if(v(_0x3a1be6))return null;{const _0x2cb2d6=y(_0x3a1be6),_0x4a5227=this['children']['get'](_0x2cb2d6);return _0x4a5227?_0x4a5227['findOnPath_'](S(_0x3a1be6),k(_0x13e88a,_0x2cb2d6),_0x180a09):null;}}['foreachOnPath'](_0x547847,_0x3e99e7){return this['foreachOnPath_'](_0x547847,w(),_0x3e99e7);}['foreachOnPath_'](_0x507a74,_0x518544,_0x7c4573){if(v(_0x507a74))return this;{this['value']&&_0x7c4573(_0x518544,this['value']);const _0x5e4b57=y(_0x507a74),_0x34a002=this['children']['get'](_0x5e4b57);return _0x34a002?_0x34a002['foreachOnPath_'](S(_0x507a74),k(_0x518544,_0x5e4b57),_0x7c4573):new b(null);}}['foreach'](_0x5e91a1){this['foreach_'](w(),_0x5e91a1);}['foreach_'](_0x12b891,_0x58f424){this['children']['inorderTraversal']((_0x13d9e5,_0x34be2f)=>{_0x34be2f['foreach_'](k(_0x12b891,_0x13d9e5),_0x58f424);}),this['value']&&_0x58f424(_0x12b891,this['value']);}['foreachChild'](_0x5b9191){this['children']['inorderTraversal']((_0xbe6db4,_0x8c9e5e)=>{_0x8c9e5e['value']&&_0x5b9191(_0xbe6db4,_0x8c9e5e['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4fa0ef){this['writeTree_']=_0x4fa0ef;}static['empty'](){return new K(new b(null));}}function Rt(_0x532a0d,_0x332511,_0x7a93b8){if(v(_0x332511))return new K(new b(_0x7a93b8));{const _0x5c053a=_0x532a0d['writeTree_']['findRootMostValueAndPath'](_0x332511);if(_0x5c053a!=null){const _0x53d6f5=_0x5c053a['path'];let _0x3ac4d6=_0x5c053a['value'];const _0x53c7d2=F(_0x53d6f5,_0x332511);return _0x3ac4d6=_0x3ac4d6['updateChild'](_0x53c7d2,_0x7a93b8),new K(_0x532a0d['writeTree_']['set'](_0x53d6f5,_0x3ac4d6));}else{const _0x595ad7=new b(_0x7a93b8),_0xde8db=_0x532a0d['writeTree_']['setTree'](_0x332511,_0x595ad7);return new K(_0xde8db);}}}function bi(_0x2c64f4,_0x29cafc,_0x3a799e){let _0x25728d=_0x2c64f4;return x(_0x3a799e,(_0x4cb244,_0x497a04)=>{_0x25728d=Rt(_0x25728d,k(_0x29cafc,_0x4cb244),_0x497a04);}),_0x25728d;}function or(_0x247cfe,_0x3483fd){if(v(_0x3483fd))return K['empty']();{const _0x18a729=_0x247cfe['writeTree_']['setTree'](_0x3483fd,new b(null));return new K(_0x18a729);}}function Ri(_0x26a25d,_0x2ae1b5){return qe(_0x26a25d,_0x2ae1b5)!=null;}function qe(_0x48b382,_0x51339f){const _0x56d319=_0x48b382['writeTree_']['findRootMostValueAndPath'](_0x51339f);return _0x56d319!=null?_0x48b382['writeTree_']['get'](_0x56d319['path'])['getChild'](F(_0x56d319['path'],_0x51339f)):null;}function ar(_0x3bcad7){const _0x1c5269=[],_0x3646f9=_0x3bcad7['writeTree_']['value'];return _0x3646f9!=null?_0x3646f9['isLeafNode']()||_0x3646f9['forEachChild'](R,(_0x40c1b6,_0x3daa08)=>{_0x1c5269['push'](new E(_0x40c1b6,_0x3daa08));}):_0x3bcad7['writeTree_']['children']['inorderTraversal']((_0x197c57,_0xd496fc)=>{_0xd496fc['value']!=null&&_0x1c5269['push'](new E(_0x197c57,_0xd496fc['value']));}),_0x1c5269;}function Ee(_0x1774da,_0x508911){if(v(_0x508911))return _0x1774da;{const _0x10cf29=qe(_0x1774da,_0x508911);return _0x10cf29!=null?new K(new b(_0x10cf29)):new K(_0x1774da['writeTree_']['subtree'](_0x508911));}}function Ai(_0x4129c2){return _0x4129c2['writeTree_']['isEmpty']();}function at(_0x15e865,_0x5eef53){return Uo(w(),_0x15e865['writeTree_'],_0x5eef53);}function Uo(_0x2237b6,_0x17fb3c,_0x474bf3){if(_0x17fb3c['value']!=null)return _0x474bf3['updateChild'](_0x2237b6,_0x17fb3c['value']);{let _0x5ed76d=null;return _0x17fb3c['children']['inorderTraversal']((_0x2821e7,_0x1bd8f9)=>{_0x2821e7==='.priority'?(f(_0x1bd8f9['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5ed76d=_0x1bd8f9['value']):_0x474bf3=Uo(k(_0x2237b6,_0x2821e7),_0x1bd8f9,_0x474bf3);}),!_0x474bf3['getChild'](_0x2237b6)['isEmpty']()&&_0x5ed76d!==null&&(_0x474bf3=_0x474bf3['updateChild'](k(_0x2237b6,'.priority'),_0x5ed76d)),_0x474bf3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0xa9f938,_0x10f000){return Ho(_0x10f000,_0xa9f938);}function cu(_0x162bb9,_0x2f9640,_0x2ca3df,_0x2fca13,_0x8d0d7c){f(_0x2fca13>_0x162bb9['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x8d0d7c===void 0x0&&(_0x8d0d7c=!0x0),_0x162bb9['allWrites']['push']({'path':_0x2f9640,'snap':_0x2ca3df,'writeId':_0x2fca13,'visible':_0x8d0d7c}),_0x8d0d7c&&(_0x162bb9['visibleWrites']=Rt(_0x162bb9['visibleWrites'],_0x2f9640,_0x2ca3df)),_0x162bb9['lastWriteId']=_0x2fca13;}function lu(_0x1709cc,_0x5073bd,_0xe10508,_0x1903aa){f(_0x1903aa>_0x1709cc['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1709cc['allWrites']['push']({'path':_0x5073bd,'children':_0xe10508,'writeId':_0x1903aa,'visible':!0x0}),_0x1709cc['visibleWrites']=bi(_0x1709cc['visibleWrites'],_0x5073bd,_0xe10508),_0x1709cc['lastWriteId']=_0x1903aa;}function hu(_0x2d9677,_0x5cc66c){for(let _0x1a015d=0x0;_0x1a015d<_0x2d9677['allWrites']['length'];_0x1a015d++){const _0x5a39b6=_0x2d9677['allWrites'][_0x1a015d];if(_0x5a39b6['writeId']===_0x5cc66c)return _0x5a39b6;}return null;}function uu(_0x368176,_0x5140d3){const _0x15b323=_0x368176['allWrites']['findIndex'](_0x1aa6df=>_0x1aa6df['writeId']===_0x5140d3);f(_0x15b323>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x40adb6=_0x368176['allWrites'][_0x15b323];_0x368176['allWrites']['splice'](_0x15b323,0x1);let _0x3c770c=_0x40adb6['visible'],_0xc4ed59=!0x1,_0x34b869=_0x368176['allWrites']['length']-0x1;for(;_0x3c770c&&_0x34b869>=0x0;){const _0x11ddf4=_0x368176['allWrites'][_0x34b869];_0x11ddf4['visible']&&(_0x34b869>=_0x15b323&&du(_0x11ddf4,_0x40adb6['path'])?_0x3c770c=!0x1:G(_0x40adb6['path'],_0x11ddf4['path'])&&(_0xc4ed59=!0x0)),_0x34b869--;}if(_0x3c770c){if(_0xc4ed59)return fu(_0x368176),!0x0;if(_0x40adb6['snap'])_0x368176['visibleWrites']=or(_0x368176['visibleWrites'],_0x40adb6['path']);else{const _0xe5078a=_0x40adb6['children'];x(_0xe5078a,_0x153a24=>{_0x368176['visibleWrites']=or(_0x368176['visibleWrites'],k(_0x40adb6['path'],_0x153a24));});}return!0x0;}else return!0x1;}function du(_0x5057a1,_0x44661a){if(_0x5057a1['snap'])return G(_0x5057a1['path'],_0x44661a);for(const _0x2b8a10 in _0x5057a1['children'])if(_0x5057a1['children']['hasOwnProperty'](_0x2b8a10)&&G(k(_0x5057a1['path'],_0x2b8a10),_0x44661a))return!0x0;return!0x1;}function fu(_0x5d9747){_0x5d9747['visibleWrites']=Wo(_0x5d9747['allWrites'],pu,w()),_0x5d9747['allWrites']['length']>0x0?_0x5d9747['lastWriteId']=_0x5d9747['allWrites'][_0x5d9747['allWrites']['length']-0x1]['writeId']:_0x5d9747['lastWriteId']=-0x1;}function pu(_0xd8459e){return _0xd8459e['visible'];}function Wo(_0x247ea1,_0x144213,_0x224098){let _0x5f4c71=K['empty']();for(let _0x4c3238=0x0;_0x4c3238<_0x247ea1['length'];++_0x4c3238){const _0x37e5af=_0x247ea1[_0x4c3238];if(_0x144213(_0x37e5af)){const _0x3b8920=_0x37e5af['path'];let _0xd53db2;if(_0x37e5af['snap'])G(_0x224098,_0x3b8920)?(_0xd53db2=F(_0x224098,_0x3b8920),_0x5f4c71=Rt(_0x5f4c71,_0xd53db2,_0x37e5af['snap'])):G(_0x3b8920,_0x224098)&&(_0xd53db2=F(_0x3b8920,_0x224098),_0x5f4c71=Rt(_0x5f4c71,w(),_0x37e5af['snap']['getChild'](_0xd53db2)));else{if(_0x37e5af['children']){if(G(_0x224098,_0x3b8920))_0xd53db2=F(_0x224098,_0x3b8920),_0x5f4c71=bi(_0x5f4c71,_0xd53db2,_0x37e5af['children']);else{if(G(_0x3b8920,_0x224098)){if(_0xd53db2=F(_0x3b8920,_0x224098),v(_0xd53db2))_0x5f4c71=bi(_0x5f4c71,w(),_0x37e5af['children']);else{const _0x4a97f9=Me(_0x37e5af['children'],y(_0xd53db2));if(_0x4a97f9){const _0x40f4b1=_0x4a97f9['getChild'](S(_0xd53db2));_0x5f4c71=Rt(_0x5f4c71,w(),_0x40f4b1);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5f4c71;}function Bo(_0x1f3f84,_0x5c7414,_0x22cb3b,_0x564c1d,_0x75a8ef){if(!_0x564c1d&&!_0x75a8ef){const _0x1a5415=qe(_0x1f3f84['visibleWrites'],_0x5c7414);if(_0x1a5415!=null)return _0x1a5415;{const _0x3e2910=Ee(_0x1f3f84['visibleWrites'],_0x5c7414);if(Ai(_0x3e2910))return _0x22cb3b;if(_0x22cb3b==null&&!Ri(_0x3e2910,w()))return null;{const _0x423021=_0x22cb3b||g['EMPTY_NODE'];return at(_0x3e2910,_0x423021);}}}else{const _0x821052=Ee(_0x1f3f84['visibleWrites'],_0x5c7414);if(!_0x75a8ef&&Ai(_0x821052))return _0x22cb3b;if(!_0x75a8ef&&_0x22cb3b==null&&!Ri(_0x821052,w()))return null;{const _0x22bc96=function(_0x48cc90){return(_0x48cc90['visible']||_0x75a8ef)&&(!_0x564c1d||!~_0x564c1d['indexOf'](_0x48cc90['writeId']))&&(G(_0x48cc90['path'],_0x5c7414)||G(_0x5c7414,_0x48cc90['path']));},_0x139d7a=Wo(_0x1f3f84['allWrites'],_0x22bc96,_0x5c7414),_0x36c6a2=_0x22cb3b||g['EMPTY_NODE'];return at(_0x139d7a,_0x36c6a2);}}}function _u(_0x2f2d4c,_0x205c5f,_0x4efa57){let _0x27daf1=g['EMPTY_NODE'];const _0x118bda=qe(_0x2f2d4c['visibleWrites'],_0x205c5f);if(_0x118bda)return _0x118bda['isLeafNode']()||_0x118bda['forEachChild'](R,(_0x6c02ee,_0x3fad80)=>{_0x27daf1=_0x27daf1['updateImmediateChild'](_0x6c02ee,_0x3fad80);}),_0x27daf1;if(_0x4efa57){const _0x978263=Ee(_0x2f2d4c['visibleWrites'],_0x205c5f);return _0x4efa57['forEachChild'](R,(_0x4c7cd1,_0x2385b9)=>{const _0x9ff9e5=at(Ee(_0x978263,new C(_0x4c7cd1)),_0x2385b9);_0x27daf1=_0x27daf1['updateImmediateChild'](_0x4c7cd1,_0x9ff9e5);}),ar(_0x978263)['forEach'](_0x13bf08=>{_0x27daf1=_0x27daf1['updateImmediateChild'](_0x13bf08['name'],_0x13bf08['node']);}),_0x27daf1;}else{const _0x5305f=Ee(_0x2f2d4c['visibleWrites'],_0x205c5f);return ar(_0x5305f)['forEach'](_0x14c002=>{_0x27daf1=_0x27daf1['updateImmediateChild'](_0x14c002['name'],_0x14c002['node']);}),_0x27daf1;}}function gu(_0x4667cf,_0x1caa87,_0x3e4708,_0x43cb4,_0x11cfba){f(_0x43cb4||_0x11cfba,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x28b468=k(_0x1caa87,_0x3e4708);if(Ri(_0x4667cf['visibleWrites'],_0x28b468))return null;{const _0x4331f5=Ee(_0x4667cf['visibleWrites'],_0x28b468);return Ai(_0x4331f5)?_0x11cfba['getChild'](_0x3e4708):at(_0x4331f5,_0x11cfba['getChild'](_0x3e4708));}}function mu(_0x96fe55,_0x3e2980,_0x41657e,_0x3d96d9){const _0x27add0=k(_0x3e2980,_0x41657e),_0x55350b=qe(_0x96fe55['visibleWrites'],_0x27add0);if(_0x55350b!=null)return _0x55350b;if(_0x3d96d9['isCompleteForChild'](_0x41657e)){const _0x3436c5=Ee(_0x96fe55['visibleWrites'],_0x27add0);return at(_0x3436c5,_0x3d96d9['getNode']()['getImmediateChild'](_0x41657e));}else return null;}function yu(_0x167dd7,_0x292b2d){return qe(_0x167dd7['visibleWrites'],_0x292b2d);}function vu(_0x5e315b,_0x2d0b3e,_0x3afd08,_0x3528ba,_0x2c96ac,_0x4c53b6,_0x1f0de7){let _0x48c4c0;const _0x19dfc8=Ee(_0x5e315b['visibleWrites'],_0x2d0b3e),_0x520a6c=qe(_0x19dfc8,w());if(_0x520a6c!=null)_0x48c4c0=_0x520a6c;else{if(_0x3afd08!=null)_0x48c4c0=at(_0x19dfc8,_0x3afd08);else return[];}if(_0x48c4c0=_0x48c4c0['withIndex'](_0x1f0de7),!_0x48c4c0['isEmpty']()&&!_0x48c4c0['isLeafNode']()){const _0x221b60=[],_0x5a3b23=_0x1f0de7['getCompare'](),_0x104f1f=_0x4c53b6?_0x48c4c0['getReverseIteratorFrom'](_0x3528ba,_0x1f0de7):_0x48c4c0['getIteratorFrom'](_0x3528ba,_0x1f0de7);let _0x5abba1=_0x104f1f['getNext']();for(;_0x5abba1&&_0x221b60['length']<_0x2c96ac;)_0x5a3b23(_0x5abba1,_0x3528ba)!==0x0&&_0x221b60['push'](_0x5abba1),_0x5abba1=_0x104f1f['getNext']();return _0x221b60;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x1a3e44,_0x5eddfd,_0x149576,_0x21eb97){return Bo(_0x1a3e44['writeTree'],_0x1a3e44['treePath'],_0x5eddfd,_0x149576,_0x21eb97);}function is(_0x30cc45,_0x52a215){return _u(_0x30cc45['writeTree'],_0x30cc45['treePath'],_0x52a215);}function cr(_0x264232,_0x566903,_0x549189,_0x5d48ef){return gu(_0x264232['writeTree'],_0x264232['treePath'],_0x566903,_0x549189,_0x5d48ef);}function Tn(_0x21ddb1,_0x2844ed){return yu(_0x21ddb1['writeTree'],k(_0x21ddb1['treePath'],_0x2844ed));}function Iu(_0x24ab5f,_0x50e146,_0xb94213,_0x2378a9,_0x1ef0a3,_0x2a2c95){return vu(_0x24ab5f['writeTree'],_0x24ab5f['treePath'],_0x50e146,_0xb94213,_0x2378a9,_0x1ef0a3,_0x2a2c95);}function ss(_0xe09848,_0x404832,_0x3d3973){return mu(_0xe09848['writeTree'],_0xe09848['treePath'],_0x404832,_0x3d3973);}function Vo(_0x3b845e,_0x34a7d1){return Ho(k(_0x3b845e['treePath'],_0x34a7d1),_0x3b845e['writeTree']);}function Ho(_0x5ac2cd,_0x210416){return{'treePath':_0x5ac2cd,'writeTree':_0x210416};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5161cb){const _0x3ee38d=_0x5161cb['type'],_0x207058=_0x5161cb['childName'];f(_0x3ee38d==='child_added'||_0x3ee38d==='child_changed'||_0x3ee38d==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x207058!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x86b842=this['changeMap']['get'](_0x207058);if(_0x86b842){const _0x980409=_0x86b842['type'];if(_0x3ee38d==='child_added'&&_0x980409==='child_removed')this['changeMap']['set'](_0x207058,Lt(_0x207058,_0x5161cb['snapshotNode'],_0x86b842['snapshotNode']));else{if(_0x3ee38d==='child_removed'&&_0x980409==='child_added')this['changeMap']['delete'](_0x207058);else{if(_0x3ee38d==='child_removed'&&_0x980409==='child_changed')this['changeMap']['set'](_0x207058,Mt(_0x207058,_0x86b842['oldSnap']));else{if(_0x3ee38d==='child_changed'&&_0x980409==='child_added')this['changeMap']['set'](_0x207058,rt(_0x207058,_0x5161cb['snapshotNode']));else{if(_0x3ee38d==='child_changed'&&_0x980409==='child_changed')this['changeMap']['set'](_0x207058,Lt(_0x207058,_0x5161cb['snapshotNode'],_0x86b842['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x5161cb+'\x20occurred\x20after\x20'+_0x86b842);}}}}}else this['changeMap']['set'](_0x207058,_0x5161cb);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x310072){return null;}['getChildAfterChild'](_0x353b82,_0x56359f,_0x5e302c){return null;}}const $o=new Cu();class rs{constructor(_0x456d1e,_0x15bdde,_0x4a6b9a=null){this['writes_']=_0x456d1e,this['viewCache_']=_0x15bdde,this['optCompleteServerCache_']=_0x4a6b9a;}['getCompleteChild'](_0x43b025){const _0x27f707=this['viewCache_']['eventCache'];if(_0x27f707['isCompleteForChild'](_0x43b025))return _0x27f707['getNode']()['getImmediateChild'](_0x43b025);{const _0xc949f8=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x43b025,_0xc949f8);}}['getChildAfterChild'](_0x5a45c5,_0xe99284,_0x4e4a4a){const _0x293ba4=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x5851c6=Iu(this['writes_'],_0x293ba4,_0xe99284,0x1,_0x4e4a4a,_0x5a45c5);return _0x5851c6['length']===0x0?null:_0x5851c6[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x276989){return{'filter':_0x276989};}function Su(_0x299d11,_0x3c0dd3){f(_0x3c0dd3['eventCache']['getNode']()['isIndexed'](_0x299d11['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3c0dd3['serverCache']['getNode']()['isIndexed'](_0x299d11['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x370618,_0x43faf8,_0x23bae3,_0x497b15,_0x1efe1a){const _0x3f3cfa=new wu();let _0x4ad3fe,_0x10b9cd;if(_0x23bae3['type']===z['OVERWRITE']){const _0x4caee7=_0x23bae3;_0x4caee7['source']['fromUser']?_0x4ad3fe=ki(_0x370618,_0x43faf8,_0x4caee7['path'],_0x4caee7['snap'],_0x497b15,_0x1efe1a,_0x3f3cfa):(f(_0x4caee7['source']['fromServer'],'Unknown\x20source.'),_0x10b9cd=_0x4caee7['source']['tagged']||_0x43faf8['serverCache']['isFiltered']()&&!v(_0x4caee7['path']),_0x4ad3fe=Sn(_0x370618,_0x43faf8,_0x4caee7['path'],_0x4caee7['snap'],_0x497b15,_0x1efe1a,_0x10b9cd,_0x3f3cfa));}else{if(_0x23bae3['type']===z['MERGE']){const _0x1863fe=_0x23bae3;_0x1863fe['source']['fromUser']?_0x4ad3fe=Au(_0x370618,_0x43faf8,_0x1863fe['path'],_0x1863fe['children'],_0x497b15,_0x1efe1a,_0x3f3cfa):(f(_0x1863fe['source']['fromServer'],'Unknown\x20source.'),_0x10b9cd=_0x1863fe['source']['tagged']||_0x43faf8['serverCache']['isFiltered'](),_0x4ad3fe=Ni(_0x370618,_0x43faf8,_0x1863fe['path'],_0x1863fe['children'],_0x497b15,_0x1efe1a,_0x10b9cd,_0x3f3cfa));}else{if(_0x23bae3['type']===z['ACK_USER_WRITE']){const _0x2c7d0a=_0x23bae3;_0x2c7d0a['revert']?_0x4ad3fe=Pu(_0x370618,_0x43faf8,_0x2c7d0a['path'],_0x497b15,_0x1efe1a,_0x3f3cfa):_0x4ad3fe=ku(_0x370618,_0x43faf8,_0x2c7d0a['path'],_0x2c7d0a['affectedTree'],_0x497b15,_0x1efe1a,_0x3f3cfa);}else{if(_0x23bae3['type']===z['LISTEN_COMPLETE'])_0x4ad3fe=Nu(_0x370618,_0x43faf8,_0x23bae3['path'],_0x497b15,_0x3f3cfa);else throw ht('Unknown\x20operation\x20type:\x20'+_0x23bae3['type']);}}}const _0x6ccba4=_0x3f3cfa['getChanges']();return Ru(_0x43faf8,_0x4ad3fe,_0x6ccba4),{'viewCache':_0x4ad3fe,'changes':_0x6ccba4};}function Ru(_0x231acc,_0x2a7300,_0x37a81f){const _0x1103e4=_0x2a7300['eventCache'];if(_0x1103e4['isFullyInitialized']()){const _0x52b7d0=_0x1103e4['getNode']()['isLeafNode']()||_0x1103e4['getNode']()['isEmpty'](),_0x17b55a=wn(_0x231acc);(_0x37a81f['length']>0x0||!_0x231acc['eventCache']['isFullyInitialized']()||_0x52b7d0&&!_0x1103e4['getNode']()['equals'](_0x17b55a)||!_0x1103e4['getNode']()['getPriority']()['equals'](_0x17b55a['getPriority']()))&&_0x37a81f['push'](Lo(wn(_0x2a7300)));}}function Go(_0x1672db,_0x3b37a7,_0x556870,_0xe3fb19,_0x560f11,_0xdd02b4){const _0x3281a3=_0x3b37a7['eventCache'];if(Tn(_0xe3fb19,_0x556870)!=null)return _0x3b37a7;{let _0x3d14a1,_0x22fe7f;if(v(_0x556870)){if(f(_0x3b37a7['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3b37a7['serverCache']['isFiltered']()){const _0x38d062=Be(_0x3b37a7),_0x163c81=_0x38d062 instanceof g?_0x38d062:g['EMPTY_NODE'],_0x4d11d0=is(_0xe3fb19,_0x163c81);_0x3d14a1=_0x1672db['filter']['updateFullNode'](_0x3b37a7['eventCache']['getNode'](),_0x4d11d0,_0xdd02b4);}else{const _0xbb8d15=Cn(_0xe3fb19,Be(_0x3b37a7));_0x3d14a1=_0x1672db['filter']['updateFullNode'](_0x3b37a7['eventCache']['getNode'](),_0xbb8d15,_0xdd02b4);}}else{const _0x3ef47a=y(_0x556870);if(_0x3ef47a==='.priority'){f(Ce(_0x556870)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x11ac1d=_0x3281a3['getNode']();_0x22fe7f=_0x3b37a7['serverCache']['getNode']();const _0x542b8c=cr(_0xe3fb19,_0x556870,_0x11ac1d,_0x22fe7f);_0x542b8c!=null?_0x3d14a1=_0x1672db['filter']['updatePriority'](_0x11ac1d,_0x542b8c):_0x3d14a1=_0x3281a3['getNode']();}else{const _0x3d7a83=S(_0x556870);let _0x57f3d4;if(_0x3281a3['isCompleteForChild'](_0x3ef47a)){_0x22fe7f=_0x3b37a7['serverCache']['getNode']();const _0x3e857d=cr(_0xe3fb19,_0x556870,_0x3281a3['getNode'](),_0x22fe7f);_0x3e857d!=null?_0x57f3d4=_0x3281a3['getNode']()['getImmediateChild'](_0x3ef47a)['updateChild'](_0x3d7a83,_0x3e857d):_0x57f3d4=_0x3281a3['getNode']()['getImmediateChild'](_0x3ef47a);}else _0x57f3d4=ss(_0xe3fb19,_0x3ef47a,_0x3b37a7['serverCache']);_0x57f3d4!=null?_0x3d14a1=_0x1672db['filter']['updateChild'](_0x3281a3['getNode'](),_0x3ef47a,_0x57f3d4,_0x3d7a83,_0x560f11,_0xdd02b4):_0x3d14a1=_0x3281a3['getNode']();}}return bt(_0x3b37a7,_0x3d14a1,_0x3281a3['isFullyInitialized']()||v(_0x556870),_0x1672db['filter']['filtersNodes']());}}function Sn(_0xd89442,_0x1e9cb2,_0x5c5e29,_0x5be64f,_0x4e93e8,_0x5a6f07,_0x1fc0d3,_0x3d6b07){const _0x50558d=_0x1e9cb2['serverCache'];let _0x2e3b0b;const _0x495c1f=_0x1fc0d3?_0xd89442['filter']:_0xd89442['filter']['getIndexedFilter']();if(v(_0x5c5e29))_0x2e3b0b=_0x495c1f['updateFullNode'](_0x50558d['getNode'](),_0x5be64f,null);else{if(_0x495c1f['filtersNodes']()&&!_0x50558d['isFiltered']()){const _0x346c56=_0x50558d['getNode']()['updateChild'](_0x5c5e29,_0x5be64f);_0x2e3b0b=_0x495c1f['updateFullNode'](_0x50558d['getNode'](),_0x346c56,null);}else{const _0x3b2096=y(_0x5c5e29);if(!_0x50558d['isCompleteForPath'](_0x5c5e29)&&Ce(_0x5c5e29)>0x1)return _0x1e9cb2;const _0x82bc=S(_0x5c5e29),_0x48e3a2=_0x50558d['getNode']()['getImmediateChild'](_0x3b2096)['updateChild'](_0x82bc,_0x5be64f);_0x3b2096==='.priority'?_0x2e3b0b=_0x495c1f['updatePriority'](_0x50558d['getNode'](),_0x48e3a2):_0x2e3b0b=_0x495c1f['updateChild'](_0x50558d['getNode'](),_0x3b2096,_0x48e3a2,_0x82bc,$o,null);}}const _0x2b5ba4=Fo(_0x1e9cb2,_0x2e3b0b,_0x50558d['isFullyInitialized']()||v(_0x5c5e29),_0x495c1f['filtersNodes']()),_0x5e1f7f=new rs(_0x4e93e8,_0x2b5ba4,_0x5a6f07);return Go(_0xd89442,_0x2b5ba4,_0x5c5e29,_0x4e93e8,_0x5e1f7f,_0x3d6b07);}function ki(_0x4370ab,_0x147d9d,_0x546aa7,_0x5275af,_0x5d19f0,_0x2d4884,_0x4521ec){const _0x3f15d3=_0x147d9d['eventCache'];let _0x49641e,_0x4dd9d2;const _0x3beae7=new rs(_0x5d19f0,_0x147d9d,_0x2d4884);if(v(_0x546aa7))_0x4dd9d2=_0x4370ab['filter']['updateFullNode'](_0x147d9d['eventCache']['getNode'](),_0x5275af,_0x4521ec),_0x49641e=bt(_0x147d9d,_0x4dd9d2,!0x0,_0x4370ab['filter']['filtersNodes']());else{const _0x446e57=y(_0x546aa7);if(_0x446e57==='.priority')_0x4dd9d2=_0x4370ab['filter']['updatePriority'](_0x147d9d['eventCache']['getNode'](),_0x5275af),_0x49641e=bt(_0x147d9d,_0x4dd9d2,_0x3f15d3['isFullyInitialized'](),_0x3f15d3['isFiltered']());else{const _0x41f728=S(_0x546aa7),_0x80df3d=_0x3f15d3['getNode']()['getImmediateChild'](_0x446e57);let _0x34318f;if(v(_0x41f728))_0x34318f=_0x5275af;else{const _0x35064a=_0x3beae7['getCompleteChild'](_0x446e57);_0x35064a!=null?ji(_0x41f728)==='.priority'&&_0x35064a['getChild'](Ro(_0x41f728))['isEmpty']()?_0x34318f=_0x35064a:_0x34318f=_0x35064a['updateChild'](_0x41f728,_0x5275af):_0x34318f=g['EMPTY_NODE'];}if(_0x80df3d['equals'](_0x34318f))_0x49641e=_0x147d9d;else{const _0x4f6c72=_0x4370ab['filter']['updateChild'](_0x3f15d3['getNode'](),_0x446e57,_0x34318f,_0x41f728,_0x3beae7,_0x4521ec);_0x49641e=bt(_0x147d9d,_0x4f6c72,_0x3f15d3['isFullyInitialized'](),_0x4370ab['filter']['filtersNodes']());}}}return _0x49641e;}function lr(_0x42fe73,_0x38a18e){return _0x42fe73['eventCache']['isCompleteForChild'](_0x38a18e);}function Au(_0x3d92d5,_0x58ee4b,_0x2b0278,_0x9ab6b2,_0x7889b,_0xdfa4f5,_0x5a4291){let _0x251feb=_0x58ee4b;return _0x9ab6b2['foreach']((_0x290662,_0x4f2390)=>{const _0x1c02d5=k(_0x2b0278,_0x290662);lr(_0x58ee4b,y(_0x1c02d5))&&(_0x251feb=ki(_0x3d92d5,_0x251feb,_0x1c02d5,_0x4f2390,_0x7889b,_0xdfa4f5,_0x5a4291));}),_0x9ab6b2['foreach']((_0x413617,_0x195089)=>{const _0x32679d=k(_0x2b0278,_0x413617);lr(_0x58ee4b,y(_0x32679d))||(_0x251feb=ki(_0x3d92d5,_0x251feb,_0x32679d,_0x195089,_0x7889b,_0xdfa4f5,_0x5a4291));}),_0x251feb;}function hr(_0x55030e,_0x5680a0,_0x25a409){return _0x25a409['foreach']((_0x3f276b,_0x5362bb)=>{_0x5680a0=_0x5680a0['updateChild'](_0x3f276b,_0x5362bb);}),_0x5680a0;}function Ni(_0x27c19b,_0x16ae38,_0x4c4e7d,_0x18ada2,_0x55a2b8,_0x5a30b3,_0x44aeab,_0x3be76f){if(_0x16ae38['serverCache']['getNode']()['isEmpty']()&&!_0x16ae38['serverCache']['isFullyInitialized']())return _0x16ae38;let _0x5ba2f2=_0x16ae38,_0x23e883;v(_0x4c4e7d)?_0x23e883=_0x18ada2:_0x23e883=new b(null)['setTree'](_0x4c4e7d,_0x18ada2);const _0x191419=_0x16ae38['serverCache']['getNode']();return _0x23e883['children']['inorderTraversal']((_0x2cccfc,_0x352be3)=>{if(_0x191419['hasChild'](_0x2cccfc)){const _0x40ebd9=_0x16ae38['serverCache']['getNode']()['getImmediateChild'](_0x2cccfc),_0x443b1b=hr(_0x27c19b,_0x40ebd9,_0x352be3);_0x5ba2f2=Sn(_0x27c19b,_0x5ba2f2,new C(_0x2cccfc),_0x443b1b,_0x55a2b8,_0x5a30b3,_0x44aeab,_0x3be76f);}}),_0x23e883['children']['inorderTraversal']((_0x45ad73,_0x565483)=>{const _0x100ccb=!_0x16ae38['serverCache']['isCompleteForChild'](_0x45ad73)&&_0x565483['value']===null;if(!_0x191419['hasChild'](_0x45ad73)&&!_0x100ccb){const _0xa2dc6d=_0x16ae38['serverCache']['getNode']()['getImmediateChild'](_0x45ad73),_0x26c5e=hr(_0x27c19b,_0xa2dc6d,_0x565483);_0x5ba2f2=Sn(_0x27c19b,_0x5ba2f2,new C(_0x45ad73),_0x26c5e,_0x55a2b8,_0x5a30b3,_0x44aeab,_0x3be76f);}}),_0x5ba2f2;}function ku(_0x16bf04,_0x4425a8,_0x15df32,_0x301cee,_0x116e4d,_0x343f24,_0x461d64){if(Tn(_0x116e4d,_0x15df32)!=null)return _0x4425a8;const _0x3aa1c6=_0x4425a8['serverCache']['isFiltered'](),_0xfc9849=_0x4425a8['serverCache'];if(_0x301cee['value']!=null){if(v(_0x15df32)&&_0xfc9849['isFullyInitialized']()||_0xfc9849['isCompleteForPath'](_0x15df32))return Sn(_0x16bf04,_0x4425a8,_0x15df32,_0xfc9849['getNode']()['getChild'](_0x15df32),_0x116e4d,_0x343f24,_0x3aa1c6,_0x461d64);if(v(_0x15df32)){let _0x22e2ab=new b(null);return _0xfc9849['getNode']()['forEachChild'](ve,(_0x7febe7,_0x10bada)=>{_0x22e2ab=_0x22e2ab['set'](new C(_0x7febe7),_0x10bada);}),Ni(_0x16bf04,_0x4425a8,_0x15df32,_0x22e2ab,_0x116e4d,_0x343f24,_0x3aa1c6,_0x461d64);}else return _0x4425a8;}else{let _0x48e0b1=new b(null);return _0x301cee['foreach']((_0xdcabb3,_0x4fb893)=>{const _0x334ba8=k(_0x15df32,_0xdcabb3);_0xfc9849['isCompleteForPath'](_0x334ba8)&&(_0x48e0b1=_0x48e0b1['set'](_0xdcabb3,_0xfc9849['getNode']()['getChild'](_0x334ba8)));}),Ni(_0x16bf04,_0x4425a8,_0x15df32,_0x48e0b1,_0x116e4d,_0x343f24,_0x3aa1c6,_0x461d64);}}function Nu(_0xd7bebe,_0x22fada,_0x189f65,_0x224056,_0x479ddd){const _0x812c1f=_0x22fada['serverCache'],_0x724b84=Fo(_0x22fada,_0x812c1f['getNode'](),_0x812c1f['isFullyInitialized']()||v(_0x189f65),_0x812c1f['isFiltered']());return Go(_0xd7bebe,_0x724b84,_0x189f65,_0x224056,$o,_0x479ddd);}function Pu(_0x12c7f6,_0x64e2ac,_0x3f0064,_0x1c35d4,_0xb5cd9c,_0x5f3146){let _0x3c9602;if(Tn(_0x1c35d4,_0x3f0064)!=null)return _0x64e2ac;{const _0x1ea2b1=new rs(_0x1c35d4,_0x64e2ac,_0xb5cd9c),_0x24dada=_0x64e2ac['eventCache']['getNode']();let _0x5174e4;if(v(_0x3f0064)||y(_0x3f0064)==='.priority'){let _0x3eb42c;if(_0x64e2ac['serverCache']['isFullyInitialized']())_0x3eb42c=Cn(_0x1c35d4,Be(_0x64e2ac));else{const _0x8f8654=_0x64e2ac['serverCache']['getNode']();f(_0x8f8654 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3eb42c=is(_0x1c35d4,_0x8f8654);}_0x3eb42c=_0x3eb42c,_0x5174e4=_0x12c7f6['filter']['updateFullNode'](_0x24dada,_0x3eb42c,_0x5f3146);}else{const _0x5be684=y(_0x3f0064);let _0x3706b5=ss(_0x1c35d4,_0x5be684,_0x64e2ac['serverCache']);_0x3706b5==null&&_0x64e2ac['serverCache']['isCompleteForChild'](_0x5be684)&&(_0x3706b5=_0x24dada['getImmediateChild'](_0x5be684)),_0x3706b5!=null?_0x5174e4=_0x12c7f6['filter']['updateChild'](_0x24dada,_0x5be684,_0x3706b5,S(_0x3f0064),_0x1ea2b1,_0x5f3146):_0x64e2ac['eventCache']['getNode']()['hasChild'](_0x5be684)?_0x5174e4=_0x12c7f6['filter']['updateChild'](_0x24dada,_0x5be684,g['EMPTY_NODE'],S(_0x3f0064),_0x1ea2b1,_0x5f3146):_0x5174e4=_0x24dada,_0x5174e4['isEmpty']()&&_0x64e2ac['serverCache']['isFullyInitialized']()&&(_0x3c9602=Cn(_0x1c35d4,Be(_0x64e2ac)),_0x3c9602['isLeafNode']()&&(_0x5174e4=_0x12c7f6['filter']['updateFullNode'](_0x5174e4,_0x3c9602,_0x5f3146)));}return _0x3c9602=_0x64e2ac['serverCache']['isFullyInitialized']()||Tn(_0x1c35d4,w())!=null,bt(_0x64e2ac,_0x5174e4,_0x3c9602,_0x12c7f6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x2b39ea,_0x38ddbf){this['query_']=_0x2b39ea,this['eventRegistrations_']=[];const _0x25d7e5=this['query_']['_queryParams'],_0xc5f147=new Xi(_0x25d7e5['getIndex']()),_0x5afe1d=Kh(_0x25d7e5);this['processor_']=Tu(_0x5afe1d);const _0x2c8f43=_0x38ddbf['serverCache'],_0x44ef21=_0x38ddbf['eventCache'],_0x5d79f5=_0xc5f147['updateFullNode'](g['EMPTY_NODE'],_0x2c8f43['getNode'](),null),_0x29b074=_0x5afe1d['updateFullNode'](g['EMPTY_NODE'],_0x44ef21['getNode'](),null),_0x42e072=new Te(_0x5d79f5,_0x2c8f43['isFullyInitialized'](),_0xc5f147['filtersNodes']()),_0x28cf18=new Te(_0x29b074,_0x44ef21['isFullyInitialized'](),_0x5afe1d['filtersNodes']());this['viewCache_']=Un(_0x28cf18,_0x42e072),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0x2c50cf){return _0x2c50cf['viewCache_']['serverCache']['getNode']();}function Mu(_0x462f36){return wn(_0x462f36['viewCache_']);}function Lu(_0x1ffc3a,_0x36e4a5){const _0x554cb4=Be(_0x1ffc3a['viewCache_']);return _0x554cb4&&(_0x1ffc3a['query']['_queryParams']['loadsAllData']()||!v(_0x36e4a5)&&!_0x554cb4['getImmediateChild'](y(_0x36e4a5))['isEmpty']())?_0x554cb4['getChild'](_0x36e4a5):null;}function ur(_0x41fd70){return _0x41fd70['eventRegistrations_']['length']===0x0;}function xu(_0x1bf984,_0x15830d){_0x1bf984['eventRegistrations_']['push'](_0x15830d);}function dr(_0x40a7c1,_0x4aab81,_0x42844d){const _0x55c9e1=[];if(_0x42844d){f(_0x4aab81==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x214dee=_0x40a7c1['query']['_path'];_0x40a7c1['eventRegistrations_']['forEach'](_0x13b492=>{const _0x21f6f9=_0x13b492['createCancelEvent'](_0x42844d,_0x214dee);_0x21f6f9&&_0x55c9e1['push'](_0x21f6f9);});}if(_0x4aab81){let _0x4c3afe=[];for(let _0x170d8b=0x0;_0x170d8b<_0x40a7c1['eventRegistrations_']['length'];++_0x170d8b){const _0x4c62d5=_0x40a7c1['eventRegistrations_'][_0x170d8b];if(!_0x4c62d5['matches'](_0x4aab81))_0x4c3afe['push'](_0x4c62d5);else{if(_0x4aab81['hasAnyCallback']()){_0x4c3afe=_0x4c3afe['concat'](_0x40a7c1['eventRegistrations_']['slice'](_0x170d8b+0x1));break;}}}_0x40a7c1['eventRegistrations_']=_0x4c3afe;}else _0x40a7c1['eventRegistrations_']=[];return _0x55c9e1;}function fr(_0x2bee46,_0x17b7e,_0x5038c0,_0x3fde77){_0x17b7e['type']===z['MERGE']&&_0x17b7e['source']['queryId']!==null&&(f(Be(_0x2bee46['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2bee46['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x384c84=_0x2bee46['viewCache_'],_0x32bba5=bu(_0x2bee46['processor_'],_0x384c84,_0x17b7e,_0x5038c0,_0x3fde77);return Su(_0x2bee46['processor_'],_0x32bba5['viewCache']),f(_0x32bba5['viewCache']['serverCache']['isFullyInitialized']()||!_0x384c84['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2bee46['viewCache_']=_0x32bba5['viewCache'],qo(_0x2bee46,_0x32bba5['changes'],_0x32bba5['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x2c3dc6,_0x55318d){const _0x36ccad=_0x2c3dc6['viewCache_']['eventCache'],_0x4e4bb1=[];return _0x36ccad['getNode']()['isLeafNode']()||_0x36ccad['getNode']()['forEachChild'](R,(_0x542d8d,_0x2db71c)=>{_0x4e4bb1['push'](rt(_0x542d8d,_0x2db71c));}),_0x36ccad['isFullyInitialized']()&&_0x4e4bb1['push'](Lo(_0x36ccad['getNode']())),qo(_0x2c3dc6,_0x4e4bb1,_0x36ccad['getNode'](),_0x55318d);}function qo(_0x2dea29,_0x2c3f2a,_0x285837,_0x22d8e4){const _0x149635=_0x22d8e4?[_0x22d8e4]:_0x2dea29['eventRegistrations_'];return su(_0x2dea29['eventGenerator_'],_0x2c3f2a,_0x285837,_0x149635);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x395e24){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x395e24;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x2e350f){return _0x2e350f['views']['size']===0x0;}function os(_0x5270ed,_0x5a7109,_0xcb60b3,_0x22b7d4){const _0x1d1507=_0x5a7109['source']['queryId'];if(_0x1d1507!==null){const _0x5ba7d1=_0x5270ed['views']['get'](_0x1d1507);return f(_0x5ba7d1!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x5ba7d1,_0x5a7109,_0xcb60b3,_0x22b7d4);}else{let _0x3f9bd5=[];for(const _0xa59721 of _0x5270ed['views']['values']())_0x3f9bd5=_0x3f9bd5['concat'](fr(_0xa59721,_0x5a7109,_0xcb60b3,_0x22b7d4));return _0x3f9bd5;}}function jo(_0x122214,_0x44fb5f,_0x525eb5,_0x17556a,_0x50022c){const _0x2b52ff=_0x44fb5f['_queryIdentifier'],_0x1b9200=_0x122214['views']['get'](_0x2b52ff);if(!_0x1b9200){let _0x38a0dc=Cn(_0x525eb5,_0x50022c?_0x17556a:null),_0x371bc9=!0x1;_0x38a0dc?_0x371bc9=!0x0:_0x17556a instanceof g?(_0x38a0dc=is(_0x525eb5,_0x17556a),_0x371bc9=!0x1):(_0x38a0dc=g['EMPTY_NODE'],_0x371bc9=!0x1);const _0x329605=Un(new Te(_0x38a0dc,_0x371bc9,!0x1),new Te(_0x17556a,_0x50022c,!0x1));return new Ou(_0x44fb5f,_0x329605);}return _0x1b9200;}function Vu(_0x165a37,_0xc90de0,_0x5875dc,_0x452137,_0x20b9fc,_0x1e20b5){const _0x48c6fb=jo(_0x165a37,_0xc90de0,_0x452137,_0x20b9fc,_0x1e20b5);return _0x165a37['views']['has'](_0xc90de0['_queryIdentifier'])||_0x165a37['views']['set'](_0xc90de0['_queryIdentifier'],_0x48c6fb),xu(_0x48c6fb,_0x5875dc),Fu(_0x48c6fb,_0x5875dc);}function Hu(_0x28a933,_0x3ba953,_0x1510ef,_0x444204){const _0x126b68=_0x3ba953['_queryIdentifier'],_0x12d676=[];let _0x59033f=[];const _0x59d2b6=Se(_0x28a933);if(_0x126b68==='default'){for(const [_0x57aa3d,_0x123e3b]of _0x28a933['views']['entries']())_0x59033f=_0x59033f['concat'](dr(_0x123e3b,_0x1510ef,_0x444204)),ur(_0x123e3b)&&(_0x28a933['views']['delete'](_0x57aa3d),_0x123e3b['query']['_queryParams']['loadsAllData']()||_0x12d676['push'](_0x123e3b['query']));}else{const _0x18ffcc=_0x28a933['views']['get'](_0x126b68);_0x18ffcc&&(_0x59033f=_0x59033f['concat'](dr(_0x18ffcc,_0x1510ef,_0x444204)),ur(_0x18ffcc)&&(_0x28a933['views']['delete'](_0x126b68),_0x18ffcc['query']['_queryParams']['loadsAllData']()||_0x12d676['push'](_0x18ffcc['query'])));}return _0x59d2b6&&!Se(_0x28a933)&&_0x12d676['push'](new(Wu())(_0x3ba953['_repo'],_0x3ba953['_path'])),{'removed':_0x12d676,'events':_0x59033f};}function Ko(_0x14f1fb){const _0x34d56e=[];for(const _0x55522e of _0x14f1fb['views']['values']())_0x55522e['query']['_queryParams']['loadsAllData']()||_0x34d56e['push'](_0x55522e);return _0x34d56e;}function Ie(_0x87b66,_0x4a8874){let _0x3de678=null;for(const _0x3834fc of _0x87b66['views']['values']())_0x3de678=_0x3de678||Lu(_0x3834fc,_0x4a8874);return _0x3de678;}function Yo(_0x448c82,_0x3de6e5){if(_0x3de6e5['_queryParams']['loadsAllData']())return Bn(_0x448c82);{const _0x212c54=_0x3de6e5['_queryIdentifier'];return _0x448c82['views']['get'](_0x212c54);}}function Qo(_0x464543,_0x23fb21){return Yo(_0x464543,_0x23fb21)!=null;}function Se(_0x1392a9){return Bn(_0x1392a9)!=null;}function Bn(_0x564479){for(const _0x1688dd of _0x564479['views']['values']())if(_0x1688dd['query']['_queryParams']['loadsAllData']())return _0x1688dd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x2924d8){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2924d8;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x3f397d){this['listenProvider_']=_0x3f397d,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2d13dc,_0x66b9be,_0x1035c8,_0x12053f,_0x1f60aa){return cu(_0x2d13dc['pendingWriteTree_'],_0x66b9be,_0x1035c8,_0x12053f,_0x1f60aa),_0x1f60aa?_t(_0x2d13dc,new We(es(),_0x66b9be,_0x1035c8)):[];}function zu(_0x46e6f1,_0x23b9cd,_0x2a0cc6,_0x3fd317){lu(_0x46e6f1['pendingWriteTree_'],_0x23b9cd,_0x2a0cc6,_0x3fd317);const _0x4dee6e=b['fromObject'](_0x2a0cc6);return _t(_0x46e6f1,new ot(es(),_0x23b9cd,_0x4dee6e));}function _e(_0x1f86ef,_0x369169,_0x5f1fa8=!0x1){const _0xa91f80=hu(_0x1f86ef['pendingWriteTree_'],_0x369169);if(uu(_0x1f86ef['pendingWriteTree_'],_0x369169)){let _0x2f2f33=new b(null);return _0xa91f80['snap']!=null?_0x2f2f33=_0x2f2f33['set'](w(),!0x0):x(_0xa91f80['children'],_0x4115d7=>{_0x2f2f33=_0x2f2f33['set'](new C(_0x4115d7),!0x0);}),_t(_0x1f86ef,new In(_0xa91f80['path'],_0x2f2f33,_0x5f1fa8));}else return[];}function Kt(_0x49e816,_0xfb9520,_0x3c17c7){return _t(_0x49e816,new We(ts(),_0xfb9520,_0x3c17c7));}function ju(_0x4aafc5,_0x5879d8,_0x31b564){const _0x6be100=b['fromObject'](_0x31b564);return _t(_0x4aafc5,new ot(ts(),_0x5879d8,_0x6be100));}function Ku(_0x42cbdd,_0x212fac){return _t(_0x42cbdd,new Ft(ts(),_0x212fac));}function Yu(_0x1357cd,_0xdc41a3,_0x2a2520){const _0x2faae1=cs(_0x1357cd,_0x2a2520);if(_0x2faae1){const _0x575ab2=ls(_0x2faae1),_0xb07e31=_0x575ab2['path'],_0x197c46=_0x575ab2['queryId'],_0x1c0143=F(_0xb07e31,_0xdc41a3),_0x434ac8=new Ft(ns(_0x197c46),_0x1c0143);return hs(_0x1357cd,_0xb07e31,_0x434ac8);}else return[];}function An(_0x285845,_0x9af4ed,_0x1243c6,_0x6d97cb,_0x174501=!0x1){const _0x486782=_0x9af4ed['_path'],_0x7bb107=_0x285845['syncPointTree_']['get'](_0x486782);let _0x213458=[];if(_0x7bb107&&(_0x9af4ed['_queryIdentifier']==='default'||Qo(_0x7bb107,_0x9af4ed))){const _0x52e8e7=Hu(_0x7bb107,_0x9af4ed,_0x1243c6,_0x6d97cb);Bu(_0x7bb107)&&(_0x285845['syncPointTree_']=_0x285845['syncPointTree_']['remove'](_0x486782));const _0x40b4d5=_0x52e8e7['removed'];if(_0x213458=_0x52e8e7['events'],!_0x174501){const _0x32a692=_0x40b4d5['findIndex'](_0x5b1e9e=>_0x5b1e9e['_queryParams']['loadsAllData']())!==-0x1,_0x1ddd7a=_0x285845['syncPointTree_']['findOnPath'](_0x486782,(_0x3f16d5,_0x377911)=>Se(_0x377911));if(_0x32a692&&!_0x1ddd7a){const _0x3eb173=_0x285845['syncPointTree_']['subtree'](_0x486782);if(!_0x3eb173['isEmpty']()){const _0x8ee358=Xu(_0x3eb173);for(let _0x150f1f=0x0;_0x150f1f<_0x8ee358['length'];++_0x150f1f){const _0x1dda37=_0x8ee358[_0x150f1f],_0x5728ca=_0x1dda37['query'],_0x57d29c=ea(_0x285845,_0x1dda37);_0x285845['listenProvider_']['startListening'](At(_0x5728ca),Ut(_0x285845,_0x5728ca),_0x57d29c['hashFn'],_0x57d29c['onComplete']);}}}!_0x1ddd7a&&_0x40b4d5['length']>0x0&&!_0x6d97cb&&(_0x32a692?_0x285845['listenProvider_']['stopListening'](At(_0x9af4ed),null):_0x40b4d5['forEach'](_0x4b45e9=>{const _0x40cb14=_0x285845['queryToTagMap']['get'](Hn(_0x4b45e9));_0x285845['listenProvider_']['stopListening'](At(_0x4b45e9),_0x40cb14);}));}Zu(_0x285845,_0x40b4d5);}return _0x213458;}function Jo(_0x2b9d35,_0x177194,_0x1c4ea2,_0x5ad47b){const _0x4e6420=cs(_0x2b9d35,_0x5ad47b);if(_0x4e6420!=null){const _0x5b81d6=ls(_0x4e6420),_0x4b6455=_0x5b81d6['path'],_0x175e22=_0x5b81d6['queryId'],_0x247a13=F(_0x4b6455,_0x177194),_0x1d64ae=new We(ns(_0x175e22),_0x247a13,_0x1c4ea2);return hs(_0x2b9d35,_0x4b6455,_0x1d64ae);}else return[];}function Qu(_0xfe4488,_0x5cb937,_0x4aef45,_0x3bebe4){const _0x438bbc=cs(_0xfe4488,_0x3bebe4);if(_0x438bbc){const _0x3fbc82=ls(_0x438bbc),_0x23a1f8=_0x3fbc82['path'],_0x3f1d0c=_0x3fbc82['queryId'],_0x45db02=F(_0x23a1f8,_0x5cb937),_0x9c4995=b['fromObject'](_0x4aef45),_0x54fe3a=new ot(ns(_0x3f1d0c),_0x45db02,_0x9c4995);return hs(_0xfe4488,_0x23a1f8,_0x54fe3a);}else return[];}function Pi(_0x49fc2b,_0x1824db,_0x1ca8aa,_0x27a0c4=!0x1){const _0x1b58d8=_0x1824db['_path'];let _0x359fe2=null,_0x332f1b=!0x1;_0x49fc2b['syncPointTree_']['foreachOnPath'](_0x1b58d8,(_0x59570c,_0x1771df)=>{const _0x47a912=F(_0x59570c,_0x1b58d8);_0x359fe2=_0x359fe2||Ie(_0x1771df,_0x47a912),_0x332f1b=_0x332f1b||Se(_0x1771df);});let _0x2ac838=_0x49fc2b['syncPointTree_']['get'](_0x1b58d8);_0x2ac838?(_0x332f1b=_0x332f1b||Se(_0x2ac838),_0x359fe2=_0x359fe2||Ie(_0x2ac838,w())):(_0x2ac838=new zo(),_0x49fc2b['syncPointTree_']=_0x49fc2b['syncPointTree_']['set'](_0x1b58d8,_0x2ac838));let _0x5ada20;_0x359fe2!=null?_0x5ada20=!0x0:(_0x5ada20=!0x1,_0x359fe2=g['EMPTY_NODE'],_0x49fc2b['syncPointTree_']['subtree'](_0x1b58d8)['foreachChild']((_0x37301c,_0x2ed369)=>{const _0x16e320=Ie(_0x2ed369,w());_0x16e320&&(_0x359fe2=_0x359fe2['updateImmediateChild'](_0x37301c,_0x16e320));}));const _0x41224f=Qo(_0x2ac838,_0x1824db);if(!_0x41224f&&!_0x1824db['_queryParams']['loadsAllData']()){const _0x5adb6b=Hn(_0x1824db);f(!_0x49fc2b['queryToTagMap']['has'](_0x5adb6b),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xe338ee=ed();_0x49fc2b['queryToTagMap']['set'](_0x5adb6b,_0xe338ee),_0x49fc2b['tagToQueryMap']['set'](_0xe338ee,_0x5adb6b);}const _0x16bf27=Wn(_0x49fc2b['pendingWriteTree_'],_0x1b58d8);let _0x2a5d75=Vu(_0x2ac838,_0x1824db,_0x1ca8aa,_0x16bf27,_0x359fe2,_0x5ada20);if(!_0x41224f&&!_0x332f1b&&!_0x27a0c4){const _0x1998e3=Yo(_0x2ac838,_0x1824db);_0x2a5d75=_0x2a5d75['concat'](td(_0x49fc2b,_0x1824db,_0x1998e3));}return _0x2a5d75;}function Vn(_0xc69c11,_0x3f273e,_0x256680){const _0xa144ca=_0xc69c11['pendingWriteTree_'],_0x24e644=_0xc69c11['syncPointTree_']['findOnPath'](_0x3f273e,(_0x62850,_0x4e2abf)=>{const _0x175481=F(_0x62850,_0x3f273e),_0x3289f9=Ie(_0x4e2abf,_0x175481);if(_0x3289f9)return _0x3289f9;});return Bo(_0xa144ca,_0x3f273e,_0x24e644,_0x256680,!0x0);}function Ju(_0x3210a3,_0x30fed8){const _0x40b533=_0x30fed8['_path'];let _0x2079e2=null;_0x3210a3['syncPointTree_']['foreachOnPath'](_0x40b533,(_0x3e7ba3,_0x21c27e)=>{const _0x5a7df7=F(_0x3e7ba3,_0x40b533);_0x2079e2=_0x2079e2||Ie(_0x21c27e,_0x5a7df7);});let _0x3a5e00=_0x3210a3['syncPointTree_']['get'](_0x40b533);_0x3a5e00?_0x2079e2=_0x2079e2||Ie(_0x3a5e00,w()):(_0x3a5e00=new zo(),_0x3210a3['syncPointTree_']=_0x3210a3['syncPointTree_']['set'](_0x40b533,_0x3a5e00));const _0x5ee7d7=_0x2079e2!=null,_0xe815f0=_0x5ee7d7?new Te(_0x2079e2,!0x0,!0x1):null,_0x2fff90=Wn(_0x3210a3['pendingWriteTree_'],_0x30fed8['_path']),_0x2af4b8=jo(_0x3a5e00,_0x30fed8,_0x2fff90,_0x5ee7d7?_0xe815f0['getNode']():g['EMPTY_NODE'],_0x5ee7d7);return Mu(_0x2af4b8);}function _t(_0xf03299,_0x50d13a){return Xo(_0x50d13a,_0xf03299['syncPointTree_'],null,Wn(_0xf03299['pendingWriteTree_'],w()));}function Xo(_0x37b1ae,_0x428795,_0x4eafed,_0x4db84e){if(v(_0x37b1ae['path']))return Zo(_0x37b1ae,_0x428795,_0x4eafed,_0x4db84e);{const _0x25e512=_0x428795['get'](w());_0x4eafed==null&&_0x25e512!=null&&(_0x4eafed=Ie(_0x25e512,w()));let _0x2811df=[];const _0x57ce60=y(_0x37b1ae['path']),_0x16f01e=_0x37b1ae['operationForChild'](_0x57ce60),_0x5ba6de=_0x428795['children']['get'](_0x57ce60);if(_0x5ba6de&&_0x16f01e){const _0x3a39c9=_0x4eafed?_0x4eafed['getImmediateChild'](_0x57ce60):null,_0x509b84=Vo(_0x4db84e,_0x57ce60);_0x2811df=_0x2811df['concat'](Xo(_0x16f01e,_0x5ba6de,_0x3a39c9,_0x509b84));}return _0x25e512&&(_0x2811df=_0x2811df['concat'](os(_0x25e512,_0x37b1ae,_0x4db84e,_0x4eafed))),_0x2811df;}}function Zo(_0x5248a2,_0x4ea671,_0x308429,_0x112aa4){const _0x516df8=_0x4ea671['get'](w());_0x308429==null&&_0x516df8!=null&&(_0x308429=Ie(_0x516df8,w()));let _0x874a7f=[];return _0x4ea671['children']['inorderTraversal']((_0x5edaac,_0x1dc5bf)=>{const _0x147d02=_0x308429?_0x308429['getImmediateChild'](_0x5edaac):null,_0xb99988=Vo(_0x112aa4,_0x5edaac),_0x47323f=_0x5248a2['operationForChild'](_0x5edaac);_0x47323f&&(_0x874a7f=_0x874a7f['concat'](Zo(_0x47323f,_0x1dc5bf,_0x147d02,_0xb99988)));}),_0x516df8&&(_0x874a7f=_0x874a7f['concat'](os(_0x516df8,_0x5248a2,_0x112aa4,_0x308429))),_0x874a7f;}function ea(_0x2536c9,_0x2df4e9){const _0x9f9b=_0x2df4e9['query'],_0x512a34=Ut(_0x2536c9,_0x9f9b);return{'hashFn':()=>(Du(_0x2df4e9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0xb51329=>{if(_0xb51329==='ok')return _0x512a34?Yu(_0x2536c9,_0x9f9b['_path'],_0x512a34):Ku(_0x2536c9,_0x9f9b['_path']);{const _0x585095=Kl(_0xb51329,_0x9f9b);return An(_0x2536c9,_0x9f9b,null,_0x585095);}}};}function Ut(_0x20781b,_0x503725){const _0x5003d1=Hn(_0x503725);return _0x20781b['queryToTagMap']['get'](_0x5003d1);}function Hn(_0x19e875){return _0x19e875['_path']['toString']()+'$'+_0x19e875['_queryIdentifier'];}function cs(_0xb93719,_0xa9be76){return _0xb93719['tagToQueryMap']['get'](_0xa9be76);}function ls(_0x3e2e8a){const _0xae73cc=_0x3e2e8a['indexOf']('$');return f(_0xae73cc!==-0x1&&_0xae73cc<_0x3e2e8a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3e2e8a['substr'](_0xae73cc+0x1),'path':new C(_0x3e2e8a['substr'](0x0,_0xae73cc))};}function hs(_0x50fb05,_0x3eb3b5,_0x25a207){const _0x449e88=_0x50fb05['syncPointTree_']['get'](_0x3eb3b5);f(_0x449e88,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2752bf=Wn(_0x50fb05['pendingWriteTree_'],_0x3eb3b5);return os(_0x449e88,_0x25a207,_0x2752bf,null);}function Xu(_0x107815){return _0x107815['fold']((_0x254339,_0x12558f,_0x147186)=>{if(_0x12558f&&Se(_0x12558f))return[Bn(_0x12558f)];{let _0x8be504=[];return _0x12558f&&(_0x8be504=Ko(_0x12558f)),x(_0x147186,(_0x45e8b4,_0x42f089)=>{_0x8be504=_0x8be504['concat'](_0x42f089);}),_0x8be504;}});}function At(_0x88468){return _0x88468['_queryParams']['loadsAllData']()&&!_0x88468['_queryParams']['isDefault']()?new(Gu())(_0x88468['_repo'],_0x88468['_path']):_0x88468;}function Zu(_0x474bc7,_0x418304){for(let _0xb10eb0=0x0;_0xb10eb0<_0x418304['length'];++_0xb10eb0){const _0xc5ff05=_0x418304[_0xb10eb0];if(!_0xc5ff05['_queryParams']['loadsAllData']()){const _0x45c232=Hn(_0xc5ff05),_0x11708f=_0x474bc7['queryToTagMap']['get'](_0x45c232);_0x474bc7['queryToTagMap']['delete'](_0x45c232),_0x474bc7['tagToQueryMap']['delete'](_0x11708f);}}}function ed(){return qu++;}function td(_0x911c4c,_0x5f012f,_0x5289b0){const _0x33e6e5=_0x5f012f['_path'],_0x40cd85=Ut(_0x911c4c,_0x5f012f),_0x5cd9af=ea(_0x911c4c,_0x5289b0),_0x56cff1=_0x911c4c['listenProvider_']['startListening'](At(_0x5f012f),_0x40cd85,_0x5cd9af['hashFn'],_0x5cd9af['onComplete']),_0x3361e2=_0x911c4c['syncPointTree_']['subtree'](_0x33e6e5);if(_0x40cd85)f(!Se(_0x3361e2['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5fa7f0=_0x3361e2['fold']((_0x2d5155,_0x11bafe,_0x358b38)=>{if(!v(_0x2d5155)&&_0x11bafe&&Se(_0x11bafe))return[Bn(_0x11bafe)['query']];{let _0x3e5040=[];return _0x11bafe&&(_0x3e5040=_0x3e5040['concat'](Ko(_0x11bafe)['map'](_0x2e2c9c=>_0x2e2c9c['query']))),x(_0x358b38,(_0x2bcc3a,_0x21973f)=>{_0x3e5040=_0x3e5040['concat'](_0x21973f);}),_0x3e5040;}});for(let _0x9ccd7d=0x0;_0x9ccd7d<_0x5fa7f0['length'];++_0x9ccd7d){const _0x786c3=_0x5fa7f0[_0x9ccd7d];_0x911c4c['listenProvider_']['stopListening'](At(_0x786c3),Ut(_0x911c4c,_0x786c3));}}return _0x56cff1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x2e6ce8){this['node_']=_0x2e6ce8;}['getImmediateChild'](_0x4077a2){const _0x2d6530=this['node_']['getImmediateChild'](_0x4077a2);return new us(_0x2d6530);}['node'](){return this['node_'];}}class ds{constructor(_0x218dfb,_0x18eedb){this['syncTree_']=_0x218dfb,this['path_']=_0x18eedb;}['getImmediateChild'](_0x59cf12){const _0x524e71=k(this['path_'],_0x59cf12);return new ds(this['syncTree_'],_0x524e71);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0x3d1ea3){return _0x3d1ea3=_0x3d1ea3||{},_0x3d1ea3['timestamp']=_0x3d1ea3['timestamp']||new Date()['getTime'](),_0x3d1ea3;},_r=function(_0x43d1a2,_0x3cd558,_0x51d862){if(!_0x43d1a2||typeof _0x43d1a2!='object')return _0x43d1a2;if(f('.sv'in _0x43d1a2,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x43d1a2['.sv']=='string')return id(_0x43d1a2['.sv'],_0x3cd558,_0x51d862);if(typeof _0x43d1a2['.sv']=='object')return sd(_0x43d1a2['.sv'],_0x3cd558);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x43d1a2,null,0x2));},id=function(_0x399fd0,_0x246aae,_0x10772a){switch(_0x399fd0){case'timestamp':return _0x10772a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x399fd0);}},sd=function(_0x35e8a9,_0x84d2a2,_0x515b91){_0x35e8a9['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x35e8a9,null,0x2));const _0x3a0f80=_0x35e8a9['increment'];typeof _0x3a0f80!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3a0f80);const _0x6b915a=_0x84d2a2['node']();if(f(_0x6b915a!==null&&typeof _0x6b915a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x6b915a['isLeafNode']())return _0x3a0f80;const _0x40b70a=_0x6b915a['getValue']();return typeof _0x40b70a!='number'?_0x3a0f80:_0x40b70a+_0x3a0f80;},ta=function(_0xf36a3b,_0x56c23c,_0x218260,_0x165422){return ps(_0x56c23c,new ds(_0x218260,_0xf36a3b),_0x165422);},fs=function(_0x415434,_0x533203,_0x1205cd){return ps(_0x415434,new us(_0x533203),_0x1205cd);};function ps(_0x4a140e,_0x236ecf,_0x3ccd32){const _0x34eb42=_0x4a140e['getPriority']()['val'](),_0x326e06=_r(_0x34eb42,_0x236ecf['getImmediateChild']('.priority'),_0x3ccd32);let _0x3f67c9;if(_0x4a140e['isLeafNode']()){const _0x4b9728=_0x4a140e,_0x29d33e=_r(_0x4b9728['getValue'](),_0x236ecf,_0x3ccd32);return _0x29d33e!==_0x4b9728['getValue']()||_0x326e06!==_0x4b9728['getPriority']()['val']()?new D(_0x29d33e,A(_0x326e06)):_0x4a140e;}else{const _0x558e48=_0x4a140e;return _0x3f67c9=_0x558e48,_0x326e06!==_0x558e48['getPriority']()['val']()&&(_0x3f67c9=_0x3f67c9['updatePriority'](new D(_0x326e06))),_0x558e48['forEachChild'](R,(_0x1a3802,_0xee5062)=>{const _0x92046f=ps(_0xee5062,_0x236ecf['getImmediateChild'](_0x1a3802),_0x3ccd32);_0x92046f!==_0xee5062&&(_0x3f67c9=_0x3f67c9['updateImmediateChild'](_0x1a3802,_0x92046f));}),_0x3f67c9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0xbe376c='',_0x3294d7=null,_0x28c676={'children':{},'childCount':0x0}){this['name']=_0xbe376c,this['parent']=_0x3294d7,this['node']=_0x28c676;}}function $n(_0x3f5e55,_0x5a8c0f){let _0x25da7a=_0x5a8c0f instanceof C?_0x5a8c0f:new C(_0x5a8c0f),_0x3051a6=_0x3f5e55,_0x193138=y(_0x25da7a);for(;_0x193138!==null;){const _0x14ad08=Me(_0x3051a6['node']['children'],_0x193138)||{'children':{},'childCount':0x0};_0x3051a6=new _s(_0x193138,_0x3051a6,_0x14ad08),_0x25da7a=S(_0x25da7a),_0x193138=y(_0x25da7a);}return _0x3051a6;}function ze(_0x239dcc){return _0x239dcc['node']['value'];}function gs(_0x4edeb0,_0x1ba20a){_0x4edeb0['node']['value']=_0x1ba20a,Oi(_0x4edeb0);}function na(_0x21d866){return _0x21d866['node']['childCount']>0x0;}function rd(_0x5c26db){return ze(_0x5c26db)===void 0x0&&!na(_0x5c26db);}function Gn(_0x444b8d,_0x3ff9dd){x(_0x444b8d['node']['children'],(_0x1b613f,_0x4b3039)=>{_0x3ff9dd(new _s(_0x1b613f,_0x444b8d,_0x4b3039));});}function ia(_0xcd7268,_0x450ea7,_0x3695d6,_0x39092d){_0x3695d6&&_0x450ea7(_0xcd7268),Gn(_0xcd7268,_0x1ecfd1=>{ia(_0x1ecfd1,_0x450ea7,!0x0);});}function od(_0x110645,_0x3faab3,_0x42e8c9){let _0x433aeb=_0x110645['parent'];for(;_0x433aeb!==null;){if(_0x3faab3(_0x433aeb))return!0x0;_0x433aeb=_0x433aeb['parent'];}return!0x1;}function Yt(_0x135aaf){return new C(_0x135aaf['parent']===null?_0x135aaf['name']:Yt(_0x135aaf['parent'])+'/'+_0x135aaf['name']);}function Oi(_0x579534){_0x579534['parent']!==null&&ad(_0x579534['parent'],_0x579534['name'],_0x579534);}function ad(_0x24cad1,_0x2264b9,_0x24829){const _0x479ad3=rd(_0x24829),_0x32bda6=Q(_0x24cad1['node']['children'],_0x2264b9);_0x479ad3&&_0x32bda6?(delete _0x24cad1['node']['children'][_0x2264b9],_0x24cad1['node']['childCount']--,Oi(_0x24cad1)):!_0x479ad3&&!_0x32bda6&&(_0x24cad1['node']['children'][_0x2264b9]=_0x24829['node'],_0x24cad1['node']['childCount']++,Oi(_0x24cad1));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3d7a32){return typeof _0x3d7a32=='string'&&_0x3d7a32['length']!==0x0&&!cd['test'](_0x3d7a32);},sa=function(_0x352a29){return typeof _0x352a29=='string'&&_0x352a29['length']!==0x0&&!ld['test'](_0x352a29);},hd=function(_0x26d96d){return _0x26d96d&&(_0x26d96d=_0x26d96d['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x26d96d);},Wt=function(_0x4435c5){return _0x4435c5===null||typeof _0x4435c5=='string'||typeof _0x4435c5=='number'&&!xn(_0x4435c5)||_0x4435c5&&typeof _0x4435c5=='object'&&Q(_0x4435c5,'.sv');},Ve=function(_0x53df8a,_0x5da5ef,_0x3acee0,_0x1c73b1){_0x1c73b1&&_0x5da5ef===void 0x0||Qt(it(_0x53df8a,'value'),_0x5da5ef,_0x3acee0);},Qt=function(_0x442c92,_0x5b790a,_0x89aca5){const _0x78ebff=_0x89aca5 instanceof C?new Ah(_0x89aca5,_0x442c92):_0x89aca5;if(_0x5b790a===void 0x0)throw new Error(_0x442c92+'contains\x20undefined\x20'+Pe(_0x78ebff));if(typeof _0x5b790a=='function')throw new Error(_0x442c92+'contains\x20a\x20function\x20'+Pe(_0x78ebff)+'\x20with\x20contents\x20=\x20'+_0x5b790a['toString']());if(xn(_0x5b790a))throw new Error(_0x442c92+'contains\x20'+_0x5b790a['toString']()+'\x20'+Pe(_0x78ebff));if(typeof _0x5b790a=='string'&&_0x5b790a['length']>ui/0x3&&Ln(_0x5b790a)>ui)throw new Error(_0x442c92+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x78ebff)+'\x20(\x27'+_0x5b790a['substring'](0x0,0x32)+'...\x27)');if(_0x5b790a&&typeof _0x5b790a=='object'){let _0x1bf16f=!0x1,_0x18595d=!0x1;if(x(_0x5b790a,(_0x37731a,_0x189201)=>{if(_0x37731a==='.value')_0x1bf16f=!0x0;else{if(_0x37731a!=='.priority'&&_0x37731a!=='.sv'&&(_0x18595d=!0x0,!ms(_0x37731a)))throw new Error(_0x442c92+'\x20contains\x20an\x20invalid\x20key\x20('+_0x37731a+')\x20'+Pe(_0x78ebff)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x78ebff,_0x37731a),Qt(_0x442c92,_0x189201,_0x78ebff),Nh(_0x78ebff);}),_0x1bf16f&&_0x18595d)throw new Error(_0x442c92+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x78ebff)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0x2fe884,_0x35487e){let _0x2329e9,_0x36c035;for(_0x2329e9=0x0;_0x2329e9<_0x35487e['length'];_0x2329e9++){_0x36c035=_0x35487e[_0x2329e9];const _0xb1d193=Dt(_0x36c035);for(let _0x585f0d=0x0;_0x585f0d<_0xb1d193['length'];_0x585f0d++)if(!(_0xb1d193[_0x585f0d]==='.priority'&&_0x585f0d===_0xb1d193['length']-0x1)){if(!ms(_0xb1d193[_0x585f0d]))throw new Error(_0x2fe884+'contains\x20an\x20invalid\x20key\x20('+_0xb1d193[_0x585f0d]+')\x20in\x20path\x20'+_0x36c035['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x35487e['sort'](Rh);let _0x1a334a=null;for(_0x2329e9=0x0;_0x2329e9<_0x35487e['length'];_0x2329e9++){if(_0x36c035=_0x35487e[_0x2329e9],_0x1a334a!==null&&G(_0x1a334a,_0x36c035))throw new Error(_0x2fe884+'contains\x20a\x20path\x20'+_0x1a334a['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x36c035['toString']());_0x1a334a=_0x36c035;}},ra=function(_0x4810c1,_0x4ca105,_0x36ba7a,_0x49ee5c){const _0x8ee81c=it(_0x4810c1,'values');if(!(_0x4ca105&&typeof _0x4ca105=='object')||Array['isArray'](_0x4ca105))throw new Error(_0x8ee81c+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xa65681=[];x(_0x4ca105,(_0x109d11,_0x5d1814)=>{const _0x41c9c3=new C(_0x109d11);if(Qt(_0x8ee81c,_0x5d1814,k(_0x36ba7a,_0x41c9c3)),ji(_0x41c9c3)==='.priority'&&!Wt(_0x5d1814))throw new Error(_0x8ee81c+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x41c9c3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xa65681['push'](_0x41c9c3);}),ud(_0x8ee81c,_0xa65681);},dd=function(_0x541e09,_0x3152e6,_0x60d0b){if(xn(_0x3152e6))throw new Error(it(_0x541e09,'priority')+'is\x20'+_0x3152e6['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x3152e6))throw new Error(it(_0x541e09,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x405913,_0x2cea1e,_0x2a3057,_0x51cf83){if(!sa(_0x2a3057))throw new Error(it(_0x405913,_0x2cea1e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2a3057+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0xdd5b15,_0x1d8766,_0x16178b,_0x56ae90){_0x16178b&&(_0x16178b=_0x16178b['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xdd5b15,_0x1d8766,_0x16178b);},De=function(_0x249625,_0x38f65b){if(y(_0x38f65b)==='.info')throw new Error(_0x249625+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x381044,_0x53e451){const _0x1e7c2f=_0x53e451['path']['toString']();if(typeof _0x53e451['repoInfo']['host']!='string'||_0x53e451['repoInfo']['host']['length']===0x0||!ms(_0x53e451['repoInfo']['namespace'])&&_0x53e451['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1e7c2f['length']!==0x0&&!hd(_0x1e7c2f))throw new Error(it(_0x381044,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x4f7fd9,_0x14ff7c){let _0x3a835a=null;for(let _0x3976e3=0x0;_0x3976e3<_0x14ff7c['length'];_0x3976e3++){const _0x1d2cf2=_0x14ff7c[_0x3976e3],_0x15767e=_0x1d2cf2['getPath']();_0x3a835a!==null&&!Ki(_0x15767e,_0x3a835a['path'])&&(_0x4f7fd9['eventLists_']['push'](_0x3a835a),_0x3a835a=null),_0x3a835a===null&&(_0x3a835a={'events':[],'path':_0x15767e}),_0x3a835a['events']['push'](_0x1d2cf2);}_0x3a835a&&_0x4f7fd9['eventLists_']['push'](_0x3a835a);}function oa(_0x5f16b7,_0x2dbfb8,_0x579a4b){qn(_0x5f16b7,_0x579a4b),aa(_0x5f16b7,_0x5dbde7=>Ki(_0x5dbde7,_0x2dbfb8));}function V(_0x583b1e,_0x394b03,_0x1b7f07){qn(_0x583b1e,_0x1b7f07),aa(_0x583b1e,_0xc3af81=>G(_0xc3af81,_0x394b03)||G(_0x394b03,_0xc3af81));}function aa(_0x46c2f5,_0x4f2746){_0x46c2f5['recursionDepth_']++;let _0x52413d=!0x0;for(let _0x24c430=0x0;_0x24c430<_0x46c2f5['eventLists_']['length'];_0x24c430++){const _0x1e0f27=_0x46c2f5['eventLists_'][_0x24c430];if(_0x1e0f27){const _0x11dc21=_0x1e0f27['path'];_0x4f2746(_0x11dc21)?(gd(_0x46c2f5['eventLists_'][_0x24c430]),_0x46c2f5['eventLists_'][_0x24c430]=null):_0x52413d=!0x1;}}_0x52413d&&(_0x46c2f5['eventLists_']=[]),_0x46c2f5['recursionDepth_']--;}function gd(_0x5c4ea6){for(let _0x470b5a=0x0;_0x470b5a<_0x5c4ea6['events']['length'];_0x470b5a++){const _0x367da3=_0x5c4ea6['events'][_0x470b5a];if(_0x367da3!==null){_0x5c4ea6['events'][_0x470b5a]=null;const _0x1b57f3=_0x367da3['getEventRunner']();Tt&&L('event:\x20'+_0x367da3['toString']()),ft(_0x1b57f3);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x3096c0,_0x7823a3,_0x18a164,_0x4c061f){this['repoInfo_']=_0x3096c0,this['forceRestClient_']=_0x7823a3,this['authTokenProvider_']=_0x18a164,this['appCheckProvider_']=_0x4c061f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0x39c0eb,_0x570d3e,_0x5deb0a){if(_0x39c0eb['stats_']=qi(_0x39c0eb['repoInfo_']),_0x39c0eb['forceRestClient_']||Xl())_0x39c0eb['server_']=new vn(_0x39c0eb['repoInfo_'],(_0x3bfcd4,_0x203a18,_0x2553e1,_0x25c85b)=>{gr(_0x39c0eb,_0x3bfcd4,_0x203a18,_0x2553e1,_0x25c85b);},_0x39c0eb['authTokenProvider_'],_0x39c0eb['appCheckProvider_']),setTimeout(()=>mr(_0x39c0eb,!0x0),0x0);else{if(typeof _0x5deb0a<'u'&&_0x5deb0a!==null){if(typeof _0x5deb0a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5deb0a);}catch(_0xbcc5f8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0xbcc5f8);}}_0x39c0eb['persistentConnection_']=new se(_0x39c0eb['repoInfo_'],_0x570d3e,(_0x5e7965,_0x37359d,_0x1a21af,_0x5eda28)=>{gr(_0x39c0eb,_0x5e7965,_0x37359d,_0x1a21af,_0x5eda28);},_0x2cd613=>{mr(_0x39c0eb,_0x2cd613);},_0x1cb543=>{Ed(_0x39c0eb,_0x1cb543);},_0x39c0eb['authTokenProvider_'],_0x39c0eb['appCheckProvider_'],_0x5deb0a),_0x39c0eb['server_']=_0x39c0eb['persistentConnection_'];}_0x39c0eb['authTokenProvider_']['addTokenChangeListener'](_0x2cbf7d=>{_0x39c0eb['server_']['refreshAuthToken'](_0x2cbf7d);}),_0x39c0eb['appCheckProvider_']['addTokenChangeListener'](_0x16c7ca=>{_0x39c0eb['server_']['refreshAppCheckToken'](_0x16c7ca['token']);}),_0x39c0eb['statsReporter_']=ih(_0x39c0eb['repoInfo_'],()=>new nu(_0x39c0eb['stats_'],_0x39c0eb['server_'])),_0x39c0eb['infoData_']=new Jh(),_0x39c0eb['infoSyncTree_']=new pr({'startListening':(_0x5278fc,_0x3d0e29,_0x1c87ea,_0x1a6425)=>{let _0xd10753=[];const _0x3e78ca=_0x39c0eb['infoData_']['getNode'](_0x5278fc['_path']);return _0x3e78ca['isEmpty']()||(_0xd10753=Kt(_0x39c0eb['infoSyncTree_'],_0x5278fc['_path'],_0x3e78ca),setTimeout(()=>{_0x1a6425('ok');},0x0)),_0xd10753;},'stopListening':()=>{}}),vs(_0x39c0eb,'connected',!0x1),_0x39c0eb['serverSyncTree_']=new pr({'startListening':(_0x484de9,_0xea2d7a,_0x48e270,_0x1197aa)=>(_0x39c0eb['server_']['listen'](_0x484de9,_0x48e270,_0xea2d7a,(_0x4cf2c4,_0x4ec22f)=>{const _0x3862d4=_0x1197aa(_0x4cf2c4,_0x4ec22f);V(_0x39c0eb['eventQueue_'],_0x484de9['_path'],_0x3862d4);}),[]),'stopListening':(_0x5d7483,_0x282818)=>{_0x39c0eb['server_']['unlisten'](_0x5d7483,_0x282818);}});}function la(_0x321150){const _0xeceb73=_0x321150['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xeceb73;}function Jt(_0x566880){return nd({'timestamp':la(_0x566880)});}function gr(_0x584161,_0x32b291,_0x2d92f9,_0xc02377,_0x1f1230){_0x584161['dataUpdateCount']++;const _0x257382=new C(_0x32b291);_0x2d92f9=_0x584161['interceptServerDataCallback_']?_0x584161['interceptServerDataCallback_'](_0x32b291,_0x2d92f9):_0x2d92f9;let _0x20c0f6=[];if(_0x1f1230){if(_0xc02377){const _0x4905e8=_n(_0x2d92f9,_0x237271=>A(_0x237271));_0x20c0f6=Qu(_0x584161['serverSyncTree_'],_0x257382,_0x4905e8,_0x1f1230);}else{const _0x4a9b69=A(_0x2d92f9);_0x20c0f6=Jo(_0x584161['serverSyncTree_'],_0x257382,_0x4a9b69,_0x1f1230);}}else{if(_0xc02377){const _0x39650a=_n(_0x2d92f9,_0x2125fe=>A(_0x2125fe));_0x20c0f6=ju(_0x584161['serverSyncTree_'],_0x257382,_0x39650a);}else{const _0x240d84=A(_0x2d92f9);_0x20c0f6=Kt(_0x584161['serverSyncTree_'],_0x257382,_0x240d84);}}let _0x80979d=_0x257382;_0x20c0f6['length']>0x0&&(_0x80979d=ct(_0x584161,_0x257382)),V(_0x584161['eventQueue_'],_0x80979d,_0x20c0f6);}function mr(_0x2d9a6a,_0x1ecc46){vs(_0x2d9a6a,'connected',_0x1ecc46),_0x1ecc46===!0x1&&Td(_0x2d9a6a);}function Ed(_0x3aefe5,_0x5954b3){x(_0x5954b3,(_0x3213f8,_0x466818)=>{vs(_0x3aefe5,_0x3213f8,_0x466818);});}function vs(_0x5878ed,_0x31ad18,_0x33b556){const _0x5ac226=new C('/.info/'+_0x31ad18),_0x1bde3a=A(_0x33b556);_0x5878ed['infoData_']['updateSnapshot'](_0x5ac226,_0x1bde3a);const _0x970124=Kt(_0x5878ed['infoSyncTree_'],_0x5ac226,_0x1bde3a);V(_0x5878ed['eventQueue_'],_0x5ac226,_0x970124);}function zn(_0x4b3e95){return _0x4b3e95['nextWriteId_']++;}function Id(_0x500b05,_0x2d11d8,_0x3c6da6){const _0x5dd3a9=Ju(_0x500b05['serverSyncTree_'],_0x2d11d8);return _0x5dd3a9!=null?Promise['resolve'](_0x5dd3a9):_0x500b05['server_']['get'](_0x2d11d8)['then'](_0x56288e=>{const _0x2c6922=A(_0x56288e)['withIndex'](_0x2d11d8['_queryParams']['getIndex']());Pi(_0x500b05['serverSyncTree_'],_0x2d11d8,_0x3c6da6,!0x0);let _0x522dc2;if(_0x2d11d8['_queryParams']['loadsAllData']())_0x522dc2=Kt(_0x500b05['serverSyncTree_'],_0x2d11d8['_path'],_0x2c6922);else{const _0x41f985=Ut(_0x500b05['serverSyncTree_'],_0x2d11d8);_0x522dc2=Jo(_0x500b05['serverSyncTree_'],_0x2d11d8['_path'],_0x2c6922,_0x41f985);}return V(_0x500b05['eventQueue_'],_0x2d11d8['_path'],_0x522dc2),An(_0x500b05['serverSyncTree_'],_0x2d11d8,_0x3c6da6,null,!0x0),_0x2c6922;},_0x323449=>(gt(_0x500b05,'get\x20for\x20query\x20'+O(_0x2d11d8)+'\x20failed:\x20'+_0x323449),Promise['reject'](new Error(_0x323449))));}function wd(_0x1828cf,_0x6ad2b2,_0x477388,_0x3de7c1,_0x2d7c09){gt(_0x1828cf,'set',{'path':_0x6ad2b2['toString'](),'value':_0x477388,'priority':_0x3de7c1});const _0x14b8e4=Jt(_0x1828cf),_0x227cd2=A(_0x477388,_0x3de7c1),_0x231117=Vn(_0x1828cf['serverSyncTree_'],_0x6ad2b2),_0x20ab49=fs(_0x227cd2,_0x231117,_0x14b8e4),_0x3f1935=zn(_0x1828cf),_0x12fb81=as(_0x1828cf['serverSyncTree_'],_0x6ad2b2,_0x20ab49,_0x3f1935,!0x0);qn(_0x1828cf['eventQueue_'],_0x12fb81),_0x1828cf['server_']['put'](_0x6ad2b2['toString'](),_0x227cd2['val'](!0x0),(_0x1feaaf,_0x13b785)=>{const _0x90c85a=_0x1feaaf==='ok';_0x90c85a||U('set\x20at\x20'+_0x6ad2b2+'\x20failed:\x20'+_0x1feaaf);const _0xa83eee=_e(_0x1828cf['serverSyncTree_'],_0x3f1935,!_0x90c85a);V(_0x1828cf['eventQueue_'],_0x6ad2b2,_0xa83eee),be(_0x1828cf,_0x2d7c09,_0x1feaaf,_0x13b785);});const _0x12fef7=Is(_0x1828cf,_0x6ad2b2);ct(_0x1828cf,_0x12fef7),V(_0x1828cf['eventQueue_'],_0x12fef7,[]);}function Cd(_0x1f3cbb,_0x3b760e,_0x11893b,_0x4bc045){gt(_0x1f3cbb,'update',{'path':_0x3b760e['toString'](),'value':_0x11893b});let _0x90a75=!0x0;const _0x493c4e=Jt(_0x1f3cbb),_0x239de7={};if(x(_0x11893b,(_0x308132,_0x55ed8f)=>{_0x90a75=!0x1,_0x239de7[_0x308132]=ta(k(_0x3b760e,_0x308132),A(_0x55ed8f),_0x1f3cbb['serverSyncTree_'],_0x493c4e);}),_0x90a75)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1f3cbb,_0x4bc045,'ok',void 0x0);else{const _0x2154e0=zn(_0x1f3cbb),_0x4f1f85=zu(_0x1f3cbb['serverSyncTree_'],_0x3b760e,_0x239de7,_0x2154e0);qn(_0x1f3cbb['eventQueue_'],_0x4f1f85),_0x1f3cbb['server_']['merge'](_0x3b760e['toString'](),_0x11893b,(_0x4013ec,_0x11cdb0)=>{const _0x315b36=_0x4013ec==='ok';_0x315b36||U('update\x20at\x20'+_0x3b760e+'\x20failed:\x20'+_0x4013ec);const _0xbc94e6=_e(_0x1f3cbb['serverSyncTree_'],_0x2154e0,!_0x315b36),_0x2b5230=_0xbc94e6['length']>0x0?ct(_0x1f3cbb,_0x3b760e):_0x3b760e;V(_0x1f3cbb['eventQueue_'],_0x2b5230,_0xbc94e6),be(_0x1f3cbb,_0x4bc045,_0x4013ec,_0x11cdb0);}),x(_0x11893b,_0x4a1cb6=>{const _0x3743cf=Is(_0x1f3cbb,k(_0x3b760e,_0x4a1cb6));ct(_0x1f3cbb,_0x3743cf);}),V(_0x1f3cbb['eventQueue_'],_0x3b760e,[]);}}function Td(_0x55eb5a){gt(_0x55eb5a,'onDisconnectEvents');const _0x2a7f76=Jt(_0x55eb5a),_0x259dcc=En();Si(_0x55eb5a['onDisconnect_'],w(),(_0x52f192,_0x5c9fc5)=>{const _0x575823=ta(_0x52f192,_0x5c9fc5,_0x55eb5a['serverSyncTree_'],_0x2a7f76);pt(_0x259dcc,_0x52f192,_0x575823);});let _0x3d1eae=[];Si(_0x259dcc,w(),(_0xafe715,_0x16fd9e)=>{_0x3d1eae=_0x3d1eae['concat'](Kt(_0x55eb5a['serverSyncTree_'],_0xafe715,_0x16fd9e));const _0x452649=Is(_0x55eb5a,_0xafe715);ct(_0x55eb5a,_0x452649);}),_0x55eb5a['onDisconnect_']=En(),V(_0x55eb5a['eventQueue_'],w(),_0x3d1eae);}function Sd(_0x5e0946,_0x703f0d,_0x3cbc8a){_0x5e0946['server_']['onDisconnectCancel'](_0x703f0d['toString'](),(_0x265998,_0x3023fb)=>{_0x265998==='ok'&&Ti(_0x5e0946['onDisconnect_'],_0x703f0d),be(_0x5e0946,_0x3cbc8a,_0x265998,_0x3023fb);});}function yr(_0x3e087b,_0x4f7ab3,_0x356f38,_0x526498){const _0x443dfe=A(_0x356f38);_0x3e087b['server_']['onDisconnectPut'](_0x4f7ab3['toString'](),_0x443dfe['val'](!0x0),(_0x4c938e,_0x15fbc7)=>{_0x4c938e==='ok'&&pt(_0x3e087b['onDisconnect_'],_0x4f7ab3,_0x443dfe),be(_0x3e087b,_0x526498,_0x4c938e,_0x15fbc7);});}function bd(_0x3e2774,_0x2868b5,_0x8bd49a,_0xbd3b40,_0x26e3dd){const _0x178399=A(_0x8bd49a,_0xbd3b40);_0x3e2774['server_']['onDisconnectPut'](_0x2868b5['toString'](),_0x178399['val'](!0x0),(_0x404001,_0x3f7fbc)=>{_0x404001==='ok'&&pt(_0x3e2774['onDisconnect_'],_0x2868b5,_0x178399),be(_0x3e2774,_0x26e3dd,_0x404001,_0x3f7fbc);});}function Rd(_0x39cf86,_0xdc1924,_0x17b10a,_0x3cd232){if(pn(_0x17b10a)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x39cf86,_0x3cd232,'ok',void 0x0);return;}_0x39cf86['server_']['onDisconnectMerge'](_0xdc1924['toString'](),_0x17b10a,(_0x4e1c07,_0xbd8e4b)=>{_0x4e1c07==='ok'&&x(_0x17b10a,(_0x6fe259,_0x3af7b6)=>{const _0x21002c=A(_0x3af7b6);pt(_0x39cf86['onDisconnect_'],k(_0xdc1924,_0x6fe259),_0x21002c);}),be(_0x39cf86,_0x3cd232,_0x4e1c07,_0xbd8e4b);});}function Ad(_0x3dabb5,_0x55be3d,_0x4023c7){let _0x319f3e;y(_0x55be3d['_path'])==='.info'?_0x319f3e=Pi(_0x3dabb5['infoSyncTree_'],_0x55be3d,_0x4023c7):_0x319f3e=Pi(_0x3dabb5['serverSyncTree_'],_0x55be3d,_0x4023c7),oa(_0x3dabb5['eventQueue_'],_0x55be3d['_path'],_0x319f3e);}function kd(_0x4904cc,_0x1356da,_0x2aab8b){let _0x4fa59b;y(_0x1356da['_path'])==='.info'?_0x4fa59b=An(_0x4904cc['infoSyncTree_'],_0x1356da,_0x2aab8b):_0x4fa59b=An(_0x4904cc['serverSyncTree_'],_0x1356da,_0x2aab8b),oa(_0x4904cc['eventQueue_'],_0x1356da['_path'],_0x4fa59b);}function ha(_0x1ce818){_0x1ce818['persistentConnection_']&&_0x1ce818['persistentConnection_']['interrupt'](ca);}function Nd(_0x3096d3){_0x3096d3['persistentConnection_']&&_0x3096d3['persistentConnection_']['resume'](ca);}function gt(_0x2000ea,..._0x264ede){let _0x1fa7ff='';_0x2000ea['persistentConnection_']&&(_0x1fa7ff=_0x2000ea['persistentConnection_']['id']+':'),L(_0x1fa7ff,..._0x264ede);}function be(_0x320cf6,_0xe8ed0c,_0x360e0a,_0x22681b){_0xe8ed0c&&ft(()=>{if(_0x360e0a==='ok')_0xe8ed0c(null);else{const _0xcf65fd=(_0x360e0a||'error')['toUpperCase']();let _0x17ee40=_0xcf65fd;_0x22681b&&(_0x17ee40+=':\x20'+_0x22681b);const _0xa738a=new Error(_0x17ee40);_0xa738a['code']=_0xcf65fd,_0xe8ed0c(_0xa738a);}});}function Pd(_0x1d6a21,_0x23c3d6,_0x4f5f25,_0x1ab315,_0x3502de,_0x2e245a){gt(_0x1d6a21,'transaction\x20on\x20'+_0x23c3d6);const _0x9a819b={'path':_0x23c3d6,'update':_0x4f5f25,'onComplete':_0x1ab315,'status':null,'order':so(),'applyLocally':_0x2e245a,'retryCount':0x0,'unwatcher':_0x3502de,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x104ef1=Es(_0x1d6a21,_0x23c3d6,void 0x0);_0x9a819b['currentInputSnapshot']=_0x104ef1;const _0x2e6665=_0x9a819b['update'](_0x104ef1['val']());if(_0x2e6665===void 0x0)_0x9a819b['unwatcher'](),_0x9a819b['currentOutputSnapshotRaw']=null,_0x9a819b['currentOutputSnapshotResolved']=null,_0x9a819b['onComplete']&&_0x9a819b['onComplete'](null,!0x1,_0x9a819b['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x2e6665,_0x9a819b['path']),_0x9a819b['status']=0x0;const _0xb52473=$n(_0x1d6a21['transactionQueueTree_'],_0x23c3d6),_0x282d91=ze(_0xb52473)||[];_0x282d91['push'](_0x9a819b),gs(_0xb52473,_0x282d91);let _0x1ebc1e;typeof _0x2e6665=='object'&&_0x2e6665!==null&&Q(_0x2e6665,'.priority')?(_0x1ebc1e=Me(_0x2e6665,'.priority'),f(Wt(_0x1ebc1e),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1ebc1e=(Vn(_0x1d6a21['serverSyncTree_'],_0x23c3d6)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x46d739=Jt(_0x1d6a21),_0x4cae61=A(_0x2e6665,_0x1ebc1e),_0x31db06=fs(_0x4cae61,_0x104ef1,_0x46d739);_0x9a819b['currentOutputSnapshotRaw']=_0x4cae61,_0x9a819b['currentOutputSnapshotResolved']=_0x31db06,_0x9a819b['currentWriteId']=zn(_0x1d6a21);const _0xc40b2c=as(_0x1d6a21['serverSyncTree_'],_0x23c3d6,_0x31db06,_0x9a819b['currentWriteId'],_0x9a819b['applyLocally']);V(_0x1d6a21['eventQueue_'],_0x23c3d6,_0xc40b2c),jn(_0x1d6a21,_0x1d6a21['transactionQueueTree_']);}}function Es(_0x2615b6,_0xddaac4,_0xb9c930){return Vn(_0x2615b6['serverSyncTree_'],_0xddaac4,_0xb9c930)||g['EMPTY_NODE'];}function jn(_0x233452,_0x3bdf37=_0x233452['transactionQueueTree_']){if(_0x3bdf37||Kn(_0x233452,_0x3bdf37),ze(_0x3bdf37)){const _0x4d7180=da(_0x233452,_0x3bdf37);f(_0x4d7180['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4d7180['every'](_0x59b59b=>_0x59b59b['status']===0x0)&&Od(_0x233452,Yt(_0x3bdf37),_0x4d7180);}else na(_0x3bdf37)&&Gn(_0x3bdf37,_0x40dc26=>{jn(_0x233452,_0x40dc26);});}function Od(_0x421643,_0x2348d8,_0x3b34ae){const _0x4a7bb0=_0x3b34ae['map'](_0x3e5a25=>_0x3e5a25['currentWriteId']),_0x282dc8=Es(_0x421643,_0x2348d8,_0x4a7bb0);let _0x29b245=_0x282dc8;const _0x4b8b8d=_0x282dc8['hash']();for(let _0x2a4727=0x0;_0x2a4727<_0x3b34ae['length'];_0x2a4727++){const _0xafb85c=_0x3b34ae[_0x2a4727];f(_0xafb85c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xafb85c['status']=0x1,_0xafb85c['retryCount']++;const _0x2feaa1=F(_0x2348d8,_0xafb85c['path']);_0x29b245=_0x29b245['updateChild'](_0x2feaa1,_0xafb85c['currentOutputSnapshotRaw']);}const _0x116cba=_0x29b245['val'](!0x0),_0x275cec=_0x2348d8;_0x421643['server_']['put'](_0x275cec['toString'](),_0x116cba,_0x48fbd2=>{gt(_0x421643,'transaction\x20put\x20response',{'path':_0x275cec['toString'](),'status':_0x48fbd2});let _0x2316df=[];if(_0x48fbd2==='ok'){const _0x4bcca0=[];for(let _0x3abea6=0x0;_0x3abea6<_0x3b34ae['length'];_0x3abea6++)_0x3b34ae[_0x3abea6]['status']=0x2,_0x2316df=_0x2316df['concat'](_e(_0x421643['serverSyncTree_'],_0x3b34ae[_0x3abea6]['currentWriteId'])),_0x3b34ae[_0x3abea6]['onComplete']&&_0x4bcca0['push'](()=>_0x3b34ae[_0x3abea6]['onComplete'](null,!0x0,_0x3b34ae[_0x3abea6]['currentOutputSnapshotResolved'])),_0x3b34ae[_0x3abea6]['unwatcher']();Kn(_0x421643,$n(_0x421643['transactionQueueTree_'],_0x2348d8)),jn(_0x421643,_0x421643['transactionQueueTree_']),V(_0x421643['eventQueue_'],_0x2348d8,_0x2316df);for(let _0x75baf4=0x0;_0x75baf4<_0x4bcca0['length'];_0x75baf4++)ft(_0x4bcca0[_0x75baf4]);}else{if(_0x48fbd2==='datastale'){for(let _0x5ef397=0x0;_0x5ef397<_0x3b34ae['length'];_0x5ef397++)_0x3b34ae[_0x5ef397]['status']===0x3?_0x3b34ae[_0x5ef397]['status']=0x4:_0x3b34ae[_0x5ef397]['status']=0x0;}else{U('transaction\x20at\x20'+_0x275cec['toString']()+'\x20failed:\x20'+_0x48fbd2);for(let _0x1c6f06=0x0;_0x1c6f06<_0x3b34ae['length'];_0x1c6f06++)_0x3b34ae[_0x1c6f06]['status']=0x4,_0x3b34ae[_0x1c6f06]['abortReason']=_0x48fbd2;}ct(_0x421643,_0x2348d8);}},_0x4b8b8d);}function ct(_0x2842a5,_0x3bcd64){const _0x296e14=ua(_0x2842a5,_0x3bcd64),_0x2473e8=Yt(_0x296e14),_0x292f0d=da(_0x2842a5,_0x296e14);return Dd(_0x2842a5,_0x292f0d,_0x2473e8),_0x2473e8;}function Dd(_0x12ee9b,_0x1f8c0d,_0x3fd202){if(_0x1f8c0d['length']===0x0)return;const _0x2ac4ce=[];let _0x402a7e=[];const _0x366ea7=_0x1f8c0d['filter'](_0x522362=>_0x522362['status']===0x0)['map'](_0x48e3c2=>_0x48e3c2['currentWriteId']);for(let _0x782f96=0x0;_0x782f96<_0x1f8c0d['length'];_0x782f96++){const _0x4fef93=_0x1f8c0d[_0x782f96],_0x46b76b=F(_0x3fd202,_0x4fef93['path']);let _0x42ecc1=!0x1,_0x486a1e;if(f(_0x46b76b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4fef93['status']===0x4)_0x42ecc1=!0x0,_0x486a1e=_0x4fef93['abortReason'],_0x402a7e=_0x402a7e['concat'](_e(_0x12ee9b['serverSyncTree_'],_0x4fef93['currentWriteId'],!0x0));else{if(_0x4fef93['status']===0x0){if(_0x4fef93['retryCount']>=md)_0x42ecc1=!0x0,_0x486a1e='maxretry',_0x402a7e=_0x402a7e['concat'](_e(_0x12ee9b['serverSyncTree_'],_0x4fef93['currentWriteId'],!0x0));else{const _0x388af9=Es(_0x12ee9b,_0x4fef93['path'],_0x366ea7);_0x4fef93['currentInputSnapshot']=_0x388af9;const _0x337927=_0x1f8c0d[_0x782f96]['update'](_0x388af9['val']());if(_0x337927!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x337927,_0x4fef93['path']);let _0x1a71ab=A(_0x337927);typeof _0x337927=='object'&&_0x337927!=null&&Q(_0x337927,'.priority')||(_0x1a71ab=_0x1a71ab['updatePriority'](_0x388af9['getPriority']()));const _0x29c9c8=_0x4fef93['currentWriteId'],_0x2bcad8=Jt(_0x12ee9b),_0x13219f=fs(_0x1a71ab,_0x388af9,_0x2bcad8);_0x4fef93['currentOutputSnapshotRaw']=_0x1a71ab,_0x4fef93['currentOutputSnapshotResolved']=_0x13219f,_0x4fef93['currentWriteId']=zn(_0x12ee9b),_0x366ea7['splice'](_0x366ea7['indexOf'](_0x29c9c8),0x1),_0x402a7e=_0x402a7e['concat'](as(_0x12ee9b['serverSyncTree_'],_0x4fef93['path'],_0x13219f,_0x4fef93['currentWriteId'],_0x4fef93['applyLocally'])),_0x402a7e=_0x402a7e['concat'](_e(_0x12ee9b['serverSyncTree_'],_0x29c9c8,!0x0));}else _0x42ecc1=!0x0,_0x486a1e='nodata',_0x402a7e=_0x402a7e['concat'](_e(_0x12ee9b['serverSyncTree_'],_0x4fef93['currentWriteId'],!0x0));}}}V(_0x12ee9b['eventQueue_'],_0x3fd202,_0x402a7e),_0x402a7e=[],_0x42ecc1&&(_0x1f8c0d[_0x782f96]['status']=0x2,function(_0x1a433b){setTimeout(_0x1a433b,Math['floor'](0x0));}(_0x1f8c0d[_0x782f96]['unwatcher']),_0x1f8c0d[_0x782f96]['onComplete']&&(_0x486a1e==='nodata'?_0x2ac4ce['push'](()=>_0x1f8c0d[_0x782f96]['onComplete'](null,!0x1,_0x1f8c0d[_0x782f96]['currentInputSnapshot'])):_0x2ac4ce['push'](()=>_0x1f8c0d[_0x782f96]['onComplete'](new Error(_0x486a1e),!0x1,null))));}Kn(_0x12ee9b,_0x12ee9b['transactionQueueTree_']);for(let _0x29fc90=0x0;_0x29fc90<_0x2ac4ce['length'];_0x29fc90++)ft(_0x2ac4ce[_0x29fc90]);jn(_0x12ee9b,_0x12ee9b['transactionQueueTree_']);}function ua(_0x44d352,_0x1ec8ce){let _0x380e64,_0x2078a5=_0x44d352['transactionQueueTree_'];for(_0x380e64=y(_0x1ec8ce);_0x380e64!==null&&ze(_0x2078a5)===void 0x0;)_0x2078a5=$n(_0x2078a5,_0x380e64),_0x1ec8ce=S(_0x1ec8ce),_0x380e64=y(_0x1ec8ce);return _0x2078a5;}function da(_0x5a0203,_0xef6e9f){const _0x8e8a50=[];return fa(_0x5a0203,_0xef6e9f,_0x8e8a50),_0x8e8a50['sort']((_0x2d9ba8,_0x48d77f)=>_0x2d9ba8['order']-_0x48d77f['order']),_0x8e8a50;}function fa(_0x31145e,_0x21e79e,_0x392500){const _0x239f2d=ze(_0x21e79e);if(_0x239f2d){for(let _0x5a26af=0x0;_0x5a26af<_0x239f2d['length'];_0x5a26af++)_0x392500['push'](_0x239f2d[_0x5a26af]);}Gn(_0x21e79e,_0x3c5767=>{fa(_0x31145e,_0x3c5767,_0x392500);});}function Kn(_0xefaf9e,_0x54cb8e){const _0x4d05e2=ze(_0x54cb8e);if(_0x4d05e2){let _0x975fdd=0x0;for(let _0x5efa34=0x0;_0x5efa34<_0x4d05e2['length'];_0x5efa34++)_0x4d05e2[_0x5efa34]['status']!==0x2&&(_0x4d05e2[_0x975fdd]=_0x4d05e2[_0x5efa34],_0x975fdd++);_0x4d05e2['length']=_0x975fdd,gs(_0x54cb8e,_0x4d05e2['length']>0x0?_0x4d05e2:void 0x0);}Gn(_0x54cb8e,_0x429a03=>{Kn(_0xefaf9e,_0x429a03);});}function Is(_0x57684c,_0x258994){const _0x1fa1c1=Yt(ua(_0x57684c,_0x258994)),_0x28a8d0=$n(_0x57684c['transactionQueueTree_'],_0x258994);return od(_0x28a8d0,_0x233157=>{di(_0x57684c,_0x233157);}),di(_0x57684c,_0x28a8d0),ia(_0x28a8d0,_0x3c175c=>{di(_0x57684c,_0x3c175c);}),_0x1fa1c1;}function di(_0x2577ae,_0x3be7da){const _0x203a32=ze(_0x3be7da);if(_0x203a32){const _0x573183=[];let _0x3a7791=[],_0x500ef9=-0x1;for(let _0x13efc1=0x0;_0x13efc1<_0x203a32['length'];_0x13efc1++)_0x203a32[_0x13efc1]['status']===0x3||(_0x203a32[_0x13efc1]['status']===0x1?(f(_0x500ef9===_0x13efc1-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x500ef9=_0x13efc1,_0x203a32[_0x13efc1]['status']=0x3,_0x203a32[_0x13efc1]['abortReason']='set'):(f(_0x203a32[_0x13efc1]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x203a32[_0x13efc1]['unwatcher'](),_0x3a7791=_0x3a7791['concat'](_e(_0x2577ae['serverSyncTree_'],_0x203a32[_0x13efc1]['currentWriteId'],!0x0)),_0x203a32[_0x13efc1]['onComplete']&&_0x573183['push'](_0x203a32[_0x13efc1]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x500ef9===-0x1?gs(_0x3be7da,void 0x0):_0x203a32['length']=_0x500ef9+0x1,V(_0x2577ae['eventQueue_'],Yt(_0x3be7da),_0x3a7791);for(let _0x177d05=0x0;_0x177d05<_0x573183['length'];_0x177d05++)ft(_0x573183[_0x177d05]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x3ddda2){let _0x583210='';const _0x5d71b0=_0x3ddda2['split']('/');for(let _0x32f2c7=0x0;_0x32f2c7<_0x5d71b0['length'];_0x32f2c7++)if(_0x5d71b0[_0x32f2c7]['length']>0x0){let _0x534fc6=_0x5d71b0[_0x32f2c7];try{_0x534fc6=decodeURIComponent(_0x534fc6['replace'](/\+/g,'\x20'));}catch{}_0x583210+='/'+_0x534fc6;}return _0x583210;}function Ld(_0x279eca){const _0x4cac5e={};_0x279eca['charAt'](0x0)==='?'&&(_0x279eca=_0x279eca['substring'](0x1));for(const _0x1517fe of _0x279eca['split']('&')){if(_0x1517fe['length']===0x0)continue;const _0x5174df=_0x1517fe['split']('=');_0x5174df['length']===0x2?_0x4cac5e[decodeURIComponent(_0x5174df[0x0])]=decodeURIComponent(_0x5174df[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1517fe+'\x27\x20in\x20query\x20\x27'+_0x279eca+'\x27');}return _0x4cac5e;}const vr=function(_0x4cde9b,_0x1ea528){const _0x2a3bba=xd(_0x4cde9b),_0x5b0e33=_0x2a3bba['namespace'];_0x2a3bba['domain']==='firebase.com'&&ae(_0x2a3bba['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5b0e33||_0x5b0e33==='undefined')&&_0x2a3bba['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2a3bba['secure']||$l();const _0x4b47e1=_0x2a3bba['scheme']==='ws'||_0x2a3bba['scheme']==='wss';return{'repoInfo':new yo(_0x2a3bba['host'],_0x2a3bba['secure'],_0x5b0e33,_0x4b47e1,_0x1ea528,'',_0x5b0e33!==_0x2a3bba['subdomain']),'path':new C(_0x2a3bba['pathString'])};},xd=function(_0x56e3e8){let _0xb54665='',_0x2da2ab='',_0x2f99ef='',_0x31a693='',_0x3b41d9='',_0x524f8b=!0x0,_0x173dde='https',_0x1ea65a=0x1bb;if(typeof _0x56e3e8=='string'){let _0x250274=_0x56e3e8['indexOf']('//');_0x250274>=0x0&&(_0x173dde=_0x56e3e8['substring'](0x0,_0x250274-0x1),_0x56e3e8=_0x56e3e8['substring'](_0x250274+0x2));let _0x50f16c=_0x56e3e8['indexOf']('/');_0x50f16c===-0x1&&(_0x50f16c=_0x56e3e8['length']);let _0x41c1f6=_0x56e3e8['indexOf']('?');_0x41c1f6===-0x1&&(_0x41c1f6=_0x56e3e8['length']),_0xb54665=_0x56e3e8['substring'](0x0,Math['min'](_0x50f16c,_0x41c1f6)),_0x50f16c<_0x41c1f6&&(_0x31a693=Md(_0x56e3e8['substring'](_0x50f16c,_0x41c1f6)));const _0x31663a=Ld(_0x56e3e8['substring'](Math['min'](_0x56e3e8['length'],_0x41c1f6)));_0x250274=_0xb54665['indexOf'](':'),_0x250274>=0x0?(_0x524f8b=_0x173dde==='https'||_0x173dde==='wss',_0x1ea65a=parseInt(_0xb54665['substring'](_0x250274+0x1),0xa)):_0x250274=_0xb54665['length'];const _0x17f4c9=_0xb54665['slice'](0x0,_0x250274);if(_0x17f4c9['toLowerCase']()==='localhost')_0x2da2ab='localhost';else{if(_0x17f4c9['split']('.')['length']<=0x2)_0x2da2ab=_0x17f4c9;else{const _0x24f2a8=_0xb54665['indexOf']('.');_0x2f99ef=_0xb54665['substring'](0x0,_0x24f2a8)['toLowerCase'](),_0x2da2ab=_0xb54665['substring'](_0x24f2a8+0x1),_0x3b41d9=_0x2f99ef;}}'ns'in _0x31663a&&(_0x3b41d9=_0x31663a['ns']);}return{'host':_0xb54665,'port':_0x1ea65a,'domain':_0x2da2ab,'subdomain':_0x2f99ef,'secure':_0x524f8b,'scheme':_0x173dde,'pathString':_0x31a693,'namespace':_0x3b41d9};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x20b187=0x0;const _0x4f94b6=[];return function(_0x122bcb){const _0x4d0c60=_0x122bcb===_0x20b187;_0x20b187=_0x122bcb;let _0x4cf16d;const _0x3d14df=new Array(0x8);for(_0x4cf16d=0x7;_0x4cf16d>=0x0;_0x4cf16d--)_0x3d14df[_0x4cf16d]=Er['charAt'](_0x122bcb%0x40),_0x122bcb=Math['floor'](_0x122bcb/0x40);f(_0x122bcb===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x512fb1=_0x3d14df['join']('');if(_0x4d0c60){for(_0x4cf16d=0xb;_0x4cf16d>=0x0&&_0x4f94b6[_0x4cf16d]===0x3f;_0x4cf16d--)_0x4f94b6[_0x4cf16d]=0x0;_0x4f94b6[_0x4cf16d]++;}else{for(_0x4cf16d=0x0;_0x4cf16d<0xc;_0x4cf16d++)_0x4f94b6[_0x4cf16d]=Math['floor'](Math['random']()*0x40);}for(_0x4cf16d=0x0;_0x4cf16d<0xc;_0x4cf16d++)_0x512fb1+=Er['charAt'](_0x4f94b6[_0x4cf16d]);return f(_0x512fb1['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x512fb1;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0x3c7a16,_0x2d5ea9,_0x595754,_0x15b262){this['eventType']=_0x3c7a16,this['eventRegistration']=_0x2d5ea9,this['snapshot']=_0x595754,this['prevName']=_0x15b262;}['getPath'](){const _0x74bd9f=this['snapshot']['ref'];return this['eventType']==='value'?_0x74bd9f['_path']:_0x74bd9f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0xaded72,_0x17454f,_0x1b9004){this['eventRegistration']=_0xaded72,this['error']=_0x17454f,this['path']=_0x1b9004;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x585ca0,_0x9cb1fc){this['snapshotCallback']=_0x585ca0,this['cancelCallback']=_0x9cb1fc;}['onValue'](_0x4ecccf,_0x9bcfc7){this['snapshotCallback']['call'](null,_0x4ecccf,_0x9bcfc7);}['onCancel'](_0x534d37){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x534d37);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x363fb4){return this['snapshotCallback']===_0x363fb4['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x363fb4['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x363fb4['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x5a7de2,_0x39deb3){this['_repo']=_0x5a7de2,this['_path']=_0x39deb3;}['cancel'](){const _0x50e69e=new H();return Sd(this['_repo'],this['_path'],_0x50e69e['wrapCallback'](()=>{})),_0x50e69e['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x2f9475=new H();return yr(this['_repo'],this['_path'],null,_0x2f9475['wrapCallback'](()=>{})),_0x2f9475['promise'];}['set'](_0x2dc8fa){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x2dc8fa,this['_path'],!0x1);const _0x43a3d9=new H();return yr(this['_repo'],this['_path'],_0x2dc8fa,_0x43a3d9['wrapCallback'](()=>{})),_0x43a3d9['promise'];}['setWithPriority'](_0x4c59c6,_0x371aa2){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x4c59c6,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x371aa2);const _0x2d4b9e=new H();return bd(this['_repo'],this['_path'],_0x4c59c6,_0x371aa2,_0x2d4b9e['wrapCallback'](()=>{})),_0x2d4b9e['promise'];}['update'](_0x4512b2){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x4512b2,this['_path']);const _0x46ba31=new H();return Rd(this['_repo'],this['_path'],_0x4512b2,_0x46ba31['wrapCallback'](()=>{})),_0x46ba31['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x3a2f1d,_0x129e51,_0x54e554,_0x1562fd){this['_repo']=_0x3a2f1d,this['_path']=_0x129e51,this['_queryParams']=_0x54e554,this['_orderByCalled']=_0x1562fd;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x538805=sr(this['_queryParams']),_0x1bf8ae=$i(_0x538805);return _0x1bf8ae==='{}'?'default':_0x1bf8ae;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x3f8414){if(_0x3f8414=N(_0x3f8414),!(_0x3f8414 instanceof je))return!0x1;const _0x1caa71=this['_repo']===_0x3f8414['_repo'],_0x1794f0=Ki(this['_path'],_0x3f8414['_path']),_0x49cc7e=this['_queryIdentifier']===_0x3f8414['_queryIdentifier'];return _0x1caa71&&_0x1794f0&&_0x49cc7e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x18fcf7,_0x143489){if(_0x18fcf7['_orderByCalled']===!0x0)throw new Error(_0x143489+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x493a2c){let _0x3a4b15=null,_0x617ad7=null;if(_0x493a2c['hasStart']()&&(_0x3a4b15=_0x493a2c['getIndexStartValue']()),_0x493a2c['hasEnd']()&&(_0x617ad7=_0x493a2c['getIndexEndValue']()),_0x493a2c['getIndex']()===ve){const _0xa5b719='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3a8114='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x493a2c['hasStart']()){if(_0x493a2c['getIndexStartName']()!==Ue)throw new Error(_0xa5b719);if(typeof _0x3a4b15!='string')throw new Error(_0x3a8114);}if(_0x493a2c['hasEnd']()){if(_0x493a2c['getIndexEndName']()!==we)throw new Error(_0xa5b719);if(typeof _0x617ad7!='string')throw new Error(_0x3a8114);}}else{if(_0x493a2c['getIndex']()===R){if(_0x3a4b15!=null&&!Wt(_0x3a4b15)||_0x617ad7!=null&&!Wt(_0x617ad7))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x493a2c['getIndex']()instanceof Ji||_0x493a2c['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3a4b15!=null&&typeof _0x3a4b15=='object'||_0x617ad7!=null&&typeof _0x617ad7=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x401a5b){if(_0x401a5b['hasStart']()&&_0x401a5b['hasEnd']()&&_0x401a5b['hasLimit']()&&!_0x401a5b['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0x5b49bb,_0x214856){super(_0x5b49bb,_0x214856,new Zi(),!0x1);}get['parent'](){const _0x251ce8=Ro(this['_path']);return _0x251ce8===null?null:new ee(this['_repo'],_0x251ce8);}get['root'](){let _0x25ef66=this;for(;_0x25ef66['parent']!==null;)_0x25ef66=_0x25ef66['parent'];return _0x25ef66;}}class lt{constructor(_0x2c9de2,_0x4a85cf,_0x47b456){this['_node']=_0x2c9de2,this['ref']=_0x4a85cf,this['_index']=_0x47b456;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x434e26){const _0x54f2af=new C(_0x434e26),_0x409db8=Bt(this['ref'],_0x434e26);return new lt(this['_node']['getChild'](_0x54f2af),_0x409db8,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x8244ab){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1c2c3d,_0xb0a66c)=>_0x8244ab(new lt(_0xb0a66c,Bt(this['ref'],_0x1c2c3d),R)));}['hasChild'](_0x27084c){const _0x2db221=new C(_0x27084c);return!this['_node']['getChild'](_0x2db221)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x26a7fd,_0x6b30db){return _0x26a7fd=N(_0x26a7fd),_0x26a7fd['_checkNotDeleted']('ref'),_0x6b30db!==void 0x0?Bt(_0x26a7fd['_root'],_0x6b30db):_0x26a7fd['_root'];}function Bt(_0x2addc5,_0x402cad){return _0x2addc5=N(_0x2addc5),y(_0x2addc5['_path'])===null?fd('child','path',_0x402cad):ys('child','path',_0x402cad),new ee(_0x2addc5['_repo'],k(_0x2addc5['_path'],_0x402cad));}function m_(_0x456261){return _0x456261=N(_0x456261),new Bd(_0x456261['_repo'],_0x456261['_path']);}function y_(_0x3f891a,_0x3dcef1){_0x3f891a=N(_0x3f891a),De('push',_0x3f891a['_path']),Ve('push',_0x3dcef1,_0x3f891a['_path'],!0x0);const _0x420f82=la(_0x3f891a['_repo']),_0x25f446=Fd(_0x420f82),_0x2c9e77=Bt(_0x3f891a,_0x25f446),_0x231303=Bt(_0x3f891a,_0x25f446);let _0x9234c9;return _0x3dcef1!=null?_0x9234c9=Vd(_0x231303,_0x3dcef1)['then'](()=>_0x231303):_0x9234c9=Promise['resolve'](_0x231303),_0x2c9e77['then']=_0x9234c9['then']['bind'](_0x9234c9),_0x2c9e77['catch']=_0x9234c9['then']['bind'](_0x9234c9,void 0x0),_0x2c9e77;}function Vd(_0x236f1b,_0x536896){_0x236f1b=N(_0x236f1b),De('set',_0x236f1b['_path']),Ve('set',_0x536896,_0x236f1b['_path'],!0x1);const _0x2ea320=new H();return wd(_0x236f1b['_repo'],_0x236f1b['_path'],_0x536896,null,_0x2ea320['wrapCallback'](()=>{})),_0x2ea320['promise'];}function v_(_0x59873f,_0x861ffb){ra('update',_0x861ffb,_0x59873f['_path']);const _0x2de188=new H();return Cd(_0x59873f['_repo'],_0x59873f['_path'],_0x861ffb,_0x2de188['wrapCallback'](()=>{})),_0x2de188['promise'];}function E_(_0x3de8c6){_0x3de8c6=N(_0x3de8c6);const _0x5d6491=new pa(()=>{}),_0x34c316=new Qn(_0x5d6491);return Id(_0x3de8c6['_repo'],_0x3de8c6,_0x34c316)['then'](_0x5c620f=>new lt(_0x5c620f,new ee(_0x3de8c6['_repo'],_0x3de8c6['_path']),_0x3de8c6['_queryParams']['getIndex']()));}class Qn{constructor(_0x3cd2a0){this['callbackContext']=_0x3cd2a0;}['respondsTo'](_0x1571d6){return _0x1571d6==='value';}['createEvent'](_0x4b0529,_0x806d86){const _0x4d8d55=_0x806d86['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x4b0529['snapshotNode'],new ee(_0x806d86['_repo'],_0x806d86['_path']),_0x4d8d55));}['getEventRunner'](_0x3e743b){return _0x3e743b['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3e743b['error']):()=>this['callbackContext']['onValue'](_0x3e743b['snapshot'],null);}['createCancelEvent'](_0x225242,_0x42ac7a){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x225242,_0x42ac7a):null;}['matches'](_0x318b63){return _0x318b63 instanceof Qn?!_0x318b63['callbackContext']||!this['callbackContext']?!0x0:_0x318b63['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x348b1,_0x4be86c,_0x3056f7,_0x1fabfe,_0x1ba2f8){const _0x538b38=new pa(_0x3056f7,void 0x0),_0x3f8927=new Qn(_0x538b38);return Ad(_0x348b1['_repo'],_0x348b1,_0x3f8927),()=>kd(_0x348b1['_repo'],_0x348b1,_0x3f8927);}function $d(_0x123bea,_0x535445,_0x349656,_0x1facf7){return Hd(_0x123bea,'value',_0x535445);}class Xt{}class ma extends Xt{constructor(_0x2809ee,_0x387fc8){super(),this['_value']=_0x2809ee,this['_key']=_0x387fc8,this['type']='endAt';}['_apply'](_0x170d2d){Ve('endAt',this['_value'],_0x170d2d['_path'],!0x0);const _0x2b8d85=Qh(_0x170d2d['_queryParams'],this['_value'],this['_key']);if(ga(_0x2b8d85),Yn(_0x2b8d85),_0x170d2d['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x170d2d['_repo'],_0x170d2d['_path'],_0x2b8d85,_0x170d2d['_orderByCalled']);}}function I_(_0xfa7224,_0x4c3834){return new ma(_0xfa7224,_0x4c3834);}class ya extends Xt{constructor(_0x26409f,_0x5f36ba){super(),this['_value']=_0x26409f,this['_key']=_0x5f36ba,this['type']='startAt';}['_apply'](_0x13b010){Ve('startAt',this['_value'],_0x13b010['_path'],!0x0);const _0x183cce=Yh(_0x13b010['_queryParams'],this['_value'],this['_key']);if(ga(_0x183cce),Yn(_0x183cce),_0x13b010['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x13b010['_repo'],_0x13b010['_path'],_0x183cce,_0x13b010['_orderByCalled']);}}function w_(_0x2b4782=null,_0x2276ef){return new ya(_0x2b4782,_0x2276ef);}class Gd extends Xt{constructor(_0x1f092a){super(),this['_path']=_0x1f092a,this['type']='orderByChild';}['_apply'](_0xbcdfa0){_a(_0xbcdfa0,'orderByChild');const _0x16eaa1=new C(this['_path']);if(v(_0x16eaa1))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x420254=new Ji(_0x16eaa1),_0x1ee290=xo(_0xbcdfa0['_queryParams'],_0x420254);return Yn(_0x1ee290),new je(_0xbcdfa0['_repo'],_0xbcdfa0['_path'],_0x1ee290,!0x0);}}function C_(_0x4c6c07){if(_0x4c6c07==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4c6c07==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4c6c07==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x4c6c07),new Gd(_0x4c6c07);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1f116e){_a(_0x1f116e,'orderByKey');const _0x54dd12=xo(_0x1f116e['_queryParams'],ve);return Yn(_0x54dd12),new je(_0x1f116e['_repo'],_0x1f116e['_path'],_0x54dd12,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0x5beee,_0x1f3910){super(),this['_value']=_0x5beee,this['_key']=_0x1f3910,this['type']='equalTo';}['_apply'](_0x5385d6){if(Ve('equalTo',this['_value'],_0x5385d6['_path'],!0x1),_0x5385d6['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5385d6['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x5385d6));}}function S_(_0x142be7,_0x2dc0f6){return new zd(_0x142be7,_0x2dc0f6);}function b_(_0x1f6e2c,..._0x10aaac){let _0x360ba8=N(_0x1f6e2c);for(const _0x18cf16 of _0x10aaac)_0x360ba8=_0x18cf16['_apply'](_0x360ba8);return _0x360ba8;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x89bda2,_0x4e3aa1,_0x46c109,_0x4143d1){const _0x107835=_0x4e3aa1['lastIndexOf'](':'),_0x4abcad=_0x4e3aa1['substring'](0x0,_0x107835),_0x13bd03=Gt(_0x4abcad);_0x89bda2['repoInfo_']=new yo(_0x4e3aa1,_0x13bd03,_0x89bda2['repoInfo_']['namespace'],_0x89bda2['repoInfo_']['webSocketOnly'],_0x89bda2['repoInfo_']['nodeAdmin'],_0x89bda2['repoInfo_']['persistenceKey'],_0x89bda2['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x46c109),_0x4143d1&&(_0x89bda2['authTokenProvider_']=_0x4143d1);}function Qd(_0x407d6b,_0x296e17,_0xedea4,_0x35bbcd,_0xd1db96){let _0x2a252b=_0x35bbcd||_0x407d6b['options']['databaseURL'];_0x2a252b===void 0x0&&(_0x407d6b['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x407d6b['options']['projectId']),_0x2a252b=_0x407d6b['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4038e5=vr(_0x2a252b,_0xd1db96),_0x2ba697=_0x4038e5['repoInfo'],_0xc0ef80;typeof process<'u'&&Bs&&(_0xc0ef80=Bs[jd]),_0xc0ef80?(_0x2a252b='http://'+_0xc0ef80+'?ns='+_0x2ba697['namespace'],_0x4038e5=vr(_0x2a252b,_0xd1db96),_0x2ba697=_0x4038e5['repoInfo']):_0x4038e5['repoInfo']['secure'];const _0x228a41=new eh(_0x407d6b['name'],_0x407d6b['options'],_0x296e17);pd('Invalid\x20Firebase\x20Database\x20URL',_0x4038e5),v(_0x4038e5['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x281f89=Xd(_0x2ba697,_0x407d6b,_0x228a41,new Zl(_0x407d6b,_0xedea4));return new Zd(_0x281f89,_0x407d6b);}function Jd(_0x362ed9,_0x34c44e){const _0x2bbc52=Di[_0x34c44e];(!_0x2bbc52||_0x2bbc52[_0x362ed9['key']]!==_0x362ed9)&&ae('Database\x20'+_0x34c44e+'('+_0x362ed9['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x362ed9),delete _0x2bbc52[_0x362ed9['key']];}function Xd(_0x26f073,_0xa619a3,_0x2aa6bb,_0x140555){let _0x4cc770=Di[_0xa619a3['name']];_0x4cc770||(_0x4cc770={},Di[_0xa619a3['name']]=_0x4cc770);let _0x400673=_0x4cc770[_0x26f073['toURLString']()];return _0x400673&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x400673=new yd(_0x26f073,Kd,_0x2aa6bb,_0x140555),_0x4cc770[_0x26f073['toURLString']()]=_0x400673,_0x400673;}class Zd{constructor(_0x59dcfc,_0x5acaba){this['_repoInternal']=_0x59dcfc,this['app']=_0x5acaba,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x55e105){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x55e105+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0x6d25c=Zr(),_0x369953){const _0x1a0332=Hi(_0x6d25c,'database')['getImmediate']({'identifier':_0x369953});if(!_0x1a0332['_instanceStarted']){const _0x33c3b6=hc('database');_0x33c3b6&&ef(_0x1a0332,..._0x33c3b6);}return _0x1a0332;}function ef(_0x1aa7fc,_0x420640,_0x167313,_0x3f01a6={}){_0x1aa7fc=N(_0x1aa7fc),_0x1aa7fc['_checkNotDeleted']('useEmulator');const _0x2107c7=_0x420640+':'+_0x167313,_0x286c80=_0x1aa7fc['_repoInternal'];if(_0x1aa7fc['_instanceStarted']){if(_0x2107c7===_0x1aa7fc['_repoInternal']['repoInfo_']['host']&&Le(_0x3f01a6,_0x286c80['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x40d1a0;if(_0x286c80['repoInfo_']['nodeAdmin'])_0x3f01a6['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x40d1a0=new an(an['OWNER']);else{if(_0x3f01a6['mockUserToken']){const _0x47a7fe=typeof _0x3f01a6['mockUserToken']=='string'?_0x3f01a6['mockUserToken']:uc(_0x3f01a6['mockUserToken'],_0x1aa7fc['app']['options']['projectId']);_0x40d1a0=new an(_0x47a7fe);}}Gt(_0x420640)&&Qr(_0x420640),Yd(_0x286c80,_0x2107c7,_0x3f01a6,_0x40d1a0);}function A_(_0x28d036){_0x28d036=N(_0x28d036),_0x28d036['_checkNotDeleted']('goOffline'),ha(_0x28d036['_repo']);}function k_(_0x36986f){_0x36986f=N(_0x36986f),_0x36986f['_checkNotDeleted']('goOnline'),Nd(_0x36986f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0x9552e){Ul(dt),st(new xe('database',(_0x2eeebf,{instanceIdentifier:_0x3b48e0})=>{const _0x390dd8=_0x2eeebf['getProvider']('app')['getImmediate'](),_0x19063c=_0x2eeebf['getProvider']('auth-internal'),_0x57ce52=_0x2eeebf['getProvider']('app-check-internal');return Qd(_0x390dd8,_0x19063c,_0x57ce52,_0x3b48e0);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x9552e),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0x43f5d3,_0x496a02){this['committed']=_0x43f5d3,this['snapshot']=_0x496a02;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x37a054,_0x514132,_0x3298e7){if(_0x37a054=N(_0x37a054),De('Reference.transaction',_0x37a054['_path']),_0x37a054['key']==='.length'||_0x37a054['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x37a054['key']+'\x20is\x20a\x20read-only\x20object.';const _0x18a017=!0x0,_0x14cacf=new H(),_0x25c1b9=(_0x489143,_0x19e2d7,_0x140856)=>{let _0x1abf1d=null;_0x489143?_0x14cacf['reject'](_0x489143):(_0x1abf1d=new lt(_0x140856,new ee(_0x37a054['_repo'],_0x37a054['_path']),R),_0x14cacf['resolve'](new sf(_0x19e2d7,_0x1abf1d)));},_0x40e6c2=$d(_0x37a054,()=>{});return Pd(_0x37a054['_repo'],_0x37a054['_path'],_0x514132,_0x25c1b9,_0x40e6c2,_0x18a017),_0x14cacf['promise'];}se['prototype']['simpleListen']=function(_0x56cffa,_0x10f41c){this['sendRequest']('q',{'p':_0x56cffa},_0x10f41c);},se['prototype']['echo']=function(_0x7243d,_0x1d6f20){this['sendRequest']('echo',{'d':_0x7243d},_0x1d6f20);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0xcc6ce0,..._0x24d064){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0xcc6ce0,..._0x24d064);}function cn(_0x3d8684,..._0xaadfe7){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3d8684,..._0xaadfe7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x2df89d,..._0x3b2b27){throw ws(_0x2df89d,..._0x3b2b27);}function X(_0x48ce5f,..._0x26d7ce){return ws(_0x48ce5f,..._0x26d7ce);}function Ia(_0x4f9c7e,_0x4e4ab1,_0x65d186){const _0x4f2fd9={...rf(),[_0x4e4ab1]:_0x65d186};return new $t('auth','Firebase',_0x4f2fd9)['create'](_0x4e4ab1,{'appName':_0x4f9c7e['name']});}function re(_0x5f5611){return Ia(_0x5f5611,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x19d1d0,..._0x11de3d){if(typeof _0x19d1d0!='string'){const _0x46d09a=_0x11de3d[0x0],_0x4bee19=[..._0x11de3d['slice'](0x1)];return _0x4bee19[0x0]&&(_0x4bee19[0x0]['appName']=_0x19d1d0['name']),_0x19d1d0['_errorFactory']['create'](_0x46d09a,..._0x4bee19);}return Ea['create'](_0x19d1d0,..._0x11de3d);}function m(_0x43f70b,_0x15acc9,..._0x35acdf){if(!_0x43f70b)throw ws(_0x15acc9,..._0x35acdf);}function ne(_0x3f9bf4){const _0x4c5cc1='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3f9bf4;throw cn(_0x4c5cc1),new Error(_0x4c5cc1);}function ce(_0x220476,_0x2d3cc3){_0x220476||ne(_0x2d3cc3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x20b483;return typeof self<'u'&&((_0x20b483=self['location'])==null?void 0x0:_0x20b483['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5d1bf0;return typeof self<'u'&&((_0x5d1bf0=self['location'])==null?void 0x0:_0x5d1bf0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0x1e4908=navigator;return _0x1e4908['languages']&&_0x1e4908['languages'][0x0]||_0x1e4908['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x271b7d,_0x46c495){this['shortDelay']=_0x271b7d,this['longDelay']=_0x46c495,ce(_0x46c495>_0x271b7d,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2df6ea,_0x379208){ce(_0x2df6ea['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2eb75d}=_0x2df6ea['emulator'];return _0x379208?''+_0x2eb75d+(_0x379208['startsWith']('/')?_0x379208['slice'](0x1):_0x379208):_0x2eb75d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x14b170,_0x265e1d,_0x171e26){this['fetchImpl']=_0x14b170,_0x265e1d&&(this['headersImpl']=_0x265e1d),_0x171e26&&(this['responseImpl']=_0x171e26);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x1112c2,_0x41bf57){return _0x1112c2['tenantId']&&!_0x41bf57['tenantId']?{..._0x41bf57,'tenantId':_0x1112c2['tenantId']}:_0x41bf57;}async function ke(_0x1af0a2,_0x456253,_0x31d93e,_0x5f34f4,_0x2f65c2={}){return Ca(_0x1af0a2,_0x2f65c2,async()=>{let _0x2b62d9={},_0x158520={};_0x5f34f4&&(_0x456253==='GET'?_0x158520=_0x5f34f4:_0x2b62d9={'body':JSON['stringify'](_0x5f34f4)});const _0x40b94d=ut({..._0x158520,'key':_0x1af0a2['config']['apiKey']})['slice'](0x1),_0x2fc338=await _0x1af0a2['_getAdditionalHeaders']();_0x2fc338['Content-Type']='application/json',_0x1af0a2['languageCode']&&(_0x2fc338['X-Firebase-Locale']=_0x1af0a2['languageCode']);const _0x111ecb={'method':_0x456253,'headers':_0x2fc338,..._0x2b62d9};return dc()||(_0x111ecb['referrerPolicy']='strict-origin-when-cross-origin'),_0x1af0a2['emulatorConfig']&&Gt(_0x1af0a2['emulatorConfig']['host'])&&(_0x111ecb['credentials']='include'),wa['fetch']()(await Ta(_0x1af0a2,_0x1af0a2['config']['apiHost'],_0x31d93e,_0x40b94d),_0x111ecb);});}async function Ca(_0x1e4056,_0x1835e0,_0x38db6c){_0x1e4056['_canInitEmulator']=!0x1;const _0x2faca6={...hf,..._0x1835e0};try{const _0x426d5f=new pf(_0x1e4056),_0x329dc4=await Promise['race']([_0x38db6c(),_0x426d5f['promise']]);_0x426d5f['clearNetworkTimeout']();const _0x1d6b9e=await _0x329dc4['json']();if('needConfirmation'in _0x1d6b9e)throw on(_0x1e4056,'account-exists-with-different-credential',_0x1d6b9e);if(_0x329dc4['ok']&&!('errorMessage'in _0x1d6b9e))return _0x1d6b9e;{const _0x189358=_0x329dc4['ok']?_0x1d6b9e['errorMessage']:_0x1d6b9e['error']['message'],[_0x8bad8c,_0x903592]=_0x189358['split']('\x20:\x20');if(_0x8bad8c==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1e4056,'credential-already-in-use',_0x1d6b9e);if(_0x8bad8c==='EMAIL_EXISTS')throw on(_0x1e4056,'email-already-in-use',_0x1d6b9e);if(_0x8bad8c==='USER_DISABLED')throw on(_0x1e4056,'user-disabled',_0x1d6b9e);const _0x134198=_0x2faca6[_0x8bad8c]||_0x8bad8c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x903592)throw Ia(_0x1e4056,_0x134198,_0x903592);Y(_0x1e4056,_0x134198);}}catch(_0x5dadec){if(_0x5dadec instanceof Re)throw _0x5dadec;Y(_0x1e4056,'network-request-failed',{'message':String(_0x5dadec)});}}async function en(_0x1e74c8,_0x4e9c88,_0x2f046f,_0x3fd8c7,_0x2d1efe={}){const _0x457f22=await ke(_0x1e74c8,_0x4e9c88,_0x2f046f,_0x3fd8c7,_0x2d1efe);return'mfaPendingCredential'in _0x457f22&&Y(_0x1e74c8,'multi-factor-auth-required',{'_serverResponse':_0x457f22}),_0x457f22;}async function Ta(_0xf8dcd6,_0x5620dc,_0x4a2eda,_0x23726a){const _0x334094=''+_0x5620dc+_0x4a2eda+'?'+_0x23726a,_0x381f65=_0xf8dcd6,_0x1cc290=_0x381f65['config']['emulator']?Cs(_0xf8dcd6['config'],_0x334094):_0xf8dcd6['config']['apiScheme']+'://'+_0x334094;return uf['includes'](_0x4a2eda)&&(await _0x381f65['_persistenceManagerAvailable'],_0x381f65['_getPersistenceType']()==='COOKIE')?_0x381f65['_getPersistence']()['_getFinalTarget'](_0x1cc290)['toString']():_0x1cc290;}function ff(_0x1ce125){switch(_0x1ce125){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x53948b){this['auth']=_0x53948b,this['timer']=null,this['promise']=new Promise((_0x23f7e3,_0x46d52e)=>{this['timer']=setTimeout(()=>_0x46d52e(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x33c48b,_0x3ffb6b,_0x5bef57){const _0x4e280a={'appName':_0x33c48b['name']};_0x5bef57['email']&&(_0x4e280a['email']=_0x5bef57['email']),_0x5bef57['phoneNumber']&&(_0x4e280a['phoneNumber']=_0x5bef57['phoneNumber']);const _0x3ef16d=X(_0x33c48b,_0x3ffb6b,_0x4e280a);return _0x3ef16d['customData']['_tokenResponse']=_0x5bef57,_0x3ef16d;}function wr(_0x2aa289){return _0x2aa289!==void 0x0&&_0x2aa289['enterprise']!==void 0x0;}class _f{constructor(_0x3cc348){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3cc348['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3cc348['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3cc348['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2d8681){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3b2190 of this['recaptchaEnforcementState'])if(_0x3b2190['provider']&&_0x3b2190['provider']===_0x2d8681)return ff(_0x3b2190['enforcementState']);return null;}['isProviderEnabled'](_0x20ca53){return this['getProviderEnforcementState'](_0x20ca53)==='ENFORCE'||this['getProviderEnforcementState'](_0x20ca53)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0x3c27be,_0x51cbcd){return ke(_0x3c27be,'GET','/v2/recaptchaConfig',Ae(_0x3c27be,_0x51cbcd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x2d86a2,_0x2ab111){return ke(_0x2d86a2,'POST','/v1/accounts:delete',_0x2ab111);}async function Nn(_0x69e16e,_0x5d81cd){return ke(_0x69e16e,'POST','/v1/accounts:lookup',_0x5d81cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x553834){if(_0x553834)try{const _0xa8e28a=new Date(Number(_0x553834));if(!isNaN(_0xa8e28a['getTime']()))return _0xa8e28a['toUTCString']();}catch{}}async function yf(_0x262838,_0x3f94d8=!0x1){const _0x12a323=N(_0x262838),_0x50aeea=await _0x12a323['getIdToken'](_0x3f94d8),_0x1b77ad=Ts(_0x50aeea);m(_0x1b77ad&&_0x1b77ad['exp']&&_0x1b77ad['auth_time']&&_0x1b77ad['iat'],_0x12a323['auth'],'internal-error');const _0x21f492=typeof _0x1b77ad['firebase']=='object'?_0x1b77ad['firebase']:void 0x0,_0x504e18=_0x21f492==null?void 0x0:_0x21f492['sign_in_provider'];return{'claims':_0x1b77ad,'token':_0x50aeea,'authTime':kt(fi(_0x1b77ad['auth_time'])),'issuedAtTime':kt(fi(_0x1b77ad['iat'])),'expirationTime':kt(fi(_0x1b77ad['exp'])),'signInProvider':_0x504e18||null,'signInSecondFactor':(_0x21f492==null?void 0x0:_0x21f492['sign_in_second_factor'])||null};}function fi(_0x46fb17){return Number(_0x46fb17)*0x3e8;}function Ts(_0x46e319){const [_0x21d2dc,_0x3c37ea,_0x1729c7]=_0x46e319['split']('.');if(_0x21d2dc===void 0x0||_0x3c37ea===void 0x0||_0x1729c7===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x25b674=fn(_0x3c37ea);return _0x25b674?JSON['parse'](_0x25b674):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x131a28){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x131a28==null?void 0x0:_0x131a28['toString']()),null;}}function Cr(_0x19aa01){const _0x4b1da3=Ts(_0x19aa01);return m(_0x4b1da3,'internal-error'),m(typeof _0x4b1da3['exp']<'u','internal-error'),m(typeof _0x4b1da3['iat']<'u','internal-error'),Number(_0x4b1da3['exp'])-Number(_0x4b1da3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0xa87f3c,_0x135303,_0x5472f9=!0x1){if(_0x5472f9)return _0x135303;try{return await _0x135303;}catch(_0x41417e){throw _0x41417e instanceof Re&&vf(_0x41417e)&&_0xa87f3c['auth']['currentUser']===_0xa87f3c&&await _0xa87f3c['auth']['signOut'](),_0x41417e;}}function vf({code:_0x7cea18}){return _0x7cea18==='auth/user-disabled'||_0x7cea18==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0xb07c46){this['user']=_0xb07c46,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x211e76){if(_0x211e76){const _0x4cbba9=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4cbba9;}else{this['errorBackoff']=0x7530;const _0x4fc91=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4fc91);}}['schedule'](_0x5d7f71=!0x1){if(!this['isRunning'])return;const _0x200ffa=this['getInterval'](_0x5d7f71);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x200ffa);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2b32a1){(_0x2b32a1==null?void 0x0:_0x2b32a1['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x26b4f6,_0x593624){this['createdAt']=_0x26b4f6,this['lastLoginAt']=_0x593624,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x42315e){this['createdAt']=_0x42315e['createdAt'],this['lastLoginAt']=_0x42315e['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0x2ed9f9){var _0x443bfd;const _0xa8984d=_0x2ed9f9['auth'],_0x59fd9a=await _0x2ed9f9['getIdToken'](),_0xec2383=await Vt(_0x2ed9f9,Nn(_0xa8984d,{'idToken':_0x59fd9a}));m(_0xec2383==null?void 0x0:_0xec2383['users']['length'],_0xa8984d,'internal-error');const _0x200918=_0xec2383['users'][0x0];_0x2ed9f9['_notifyReloadListener'](_0x200918);const _0x2da645=(_0x443bfd=_0x200918['providerUserInfo'])!=null&&_0x443bfd['length']?Sa(_0x200918['providerUserInfo']):[],_0x345d7e=wf(_0x2ed9f9['providerData'],_0x2da645),_0x1403c4=_0x2ed9f9['isAnonymous'],_0xe6a8e6=!(_0x2ed9f9['email']&&_0x200918['passwordHash'])&&!(_0x345d7e!=null&&_0x345d7e['length']),_0x56704a=_0x1403c4?_0xe6a8e6:!0x1,_0x22cd2c={'uid':_0x200918['localId'],'displayName':_0x200918['displayName']||null,'photoURL':_0x200918['photoUrl']||null,'email':_0x200918['email']||null,'emailVerified':_0x200918['emailVerified']||!0x1,'phoneNumber':_0x200918['phoneNumber']||null,'tenantId':_0x200918['tenantId']||null,'providerData':_0x345d7e,'metadata':new Li(_0x200918['createdAt'],_0x200918['lastLoginAt']),'isAnonymous':_0x56704a};Object['assign'](_0x2ed9f9,_0x22cd2c);}async function If(_0x361400){const _0x4a8815=N(_0x361400);await Pn(_0x4a8815),await _0x4a8815['auth']['_persistUserIfCurrent'](_0x4a8815),_0x4a8815['auth']['_notifyListenersIfCurrent'](_0x4a8815);}function wf(_0x18bed,_0x37ef4d){return[..._0x18bed['filter'](_0x2f0dfb=>!_0x37ef4d['some'](_0x1b7dd3=>_0x1b7dd3['providerId']===_0x2f0dfb['providerId'])),..._0x37ef4d];}function Sa(_0x565a3e){return _0x565a3e['map'](({providerId:_0x5a8108,..._0x325f70})=>({'providerId':_0x5a8108,'uid':_0x325f70['rawId']||'','displayName':_0x325f70['displayName']||null,'email':_0x325f70['email']||null,'phoneNumber':_0x325f70['phoneNumber']||null,'photoURL':_0x325f70['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x52cf39,_0x695ea1){const _0x66faca=await Ca(_0x52cf39,{},async()=>{const _0x1a19d3=ut({'grant_type':'refresh_token','refresh_token':_0x695ea1})['slice'](0x1),{tokenApiHost:_0x1f0697,apiKey:_0x5b78ab}=_0x52cf39['config'],_0x4549b0=await Ta(_0x52cf39,_0x1f0697,'/v1/token','key='+_0x5b78ab),_0x5de75b=await _0x52cf39['_getAdditionalHeaders']();_0x5de75b['Content-Type']='application/x-www-form-urlencoded';const _0x56a56e={'method':'POST','headers':_0x5de75b,'body':_0x1a19d3};return _0x52cf39['emulatorConfig']&&Gt(_0x52cf39['emulatorConfig']['host'])&&(_0x56a56e['credentials']='include'),wa['fetch']()(_0x4549b0,_0x56a56e);});return{'accessToken':_0x66faca['access_token'],'expiresIn':_0x66faca['expires_in'],'refreshToken':_0x66faca['refresh_token']};}async function Tf(_0x5d3fb6,_0xd3e189){return ke(_0x5d3fb6,'POST','/v2/accounts:revokeToken',Ae(_0x5d3fb6,_0xd3e189));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x64d65a){m(_0x64d65a['idToken'],'internal-error'),m(typeof _0x64d65a['idToken']<'u','internal-error'),m(typeof _0x64d65a['refreshToken']<'u','internal-error');const _0x1f30b9='expiresIn'in _0x64d65a&&typeof _0x64d65a['expiresIn']<'u'?Number(_0x64d65a['expiresIn']):Cr(_0x64d65a['idToken']);this['updateTokensAndExpiration'](_0x64d65a['idToken'],_0x64d65a['refreshToken'],_0x1f30b9);}['updateFromIdToken'](_0xe130af){m(_0xe130af['length']!==0x0,'internal-error');const _0x3b4a2f=Cr(_0xe130af);this['updateTokensAndExpiration'](_0xe130af,null,_0x3b4a2f);}async['getToken'](_0x5203b6,_0x17d73a=!0x1){return!_0x17d73a&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5203b6,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5203b6,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xfef3c4,_0x36534a){const {accessToken:_0x30a0b1,refreshToken:_0xe1f139,expiresIn:_0x14708a}=await Cf(_0xfef3c4,_0x36534a);this['updateTokensAndExpiration'](_0x30a0b1,_0xe1f139,Number(_0x14708a));}['updateTokensAndExpiration'](_0x5eba9f,_0xe58b49,_0x4c6f3e){this['refreshToken']=_0xe58b49||null,this['accessToken']=_0x5eba9f||null,this['expirationTime']=Date['now']()+_0x4c6f3e*0x3e8;}static['fromJSON'](_0x2c1719,_0x5bdc4c){const {refreshToken:_0x2ea167,accessToken:_0x28583a,expirationTime:_0x54b60f}=_0x5bdc4c,_0x24b64d=new et();return _0x2ea167&&(m(typeof _0x2ea167=='string','internal-error',{'appName':_0x2c1719}),_0x24b64d['refreshToken']=_0x2ea167),_0x28583a&&(m(typeof _0x28583a=='string','internal-error',{'appName':_0x2c1719}),_0x24b64d['accessToken']=_0x28583a),_0x54b60f&&(m(typeof _0x54b60f=='number','internal-error',{'appName':_0x2c1719}),_0x24b64d['expirationTime']=_0x54b60f),_0x24b64d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1e1500){this['accessToken']=_0x1e1500['accessToken'],this['refreshToken']=_0x1e1500['refreshToken'],this['expirationTime']=_0x1e1500['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2c7de3,_0x336432){m(typeof _0x2c7de3=='string'||typeof _0x2c7de3>'u','internal-error',{'appName':_0x336432});}class j{constructor({uid:_0x14796e,auth:_0x15cf80,stsTokenManager:_0x153c8c,..._0x597b1f}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x14796e,this['auth']=_0x15cf80,this['stsTokenManager']=_0x153c8c,this['accessToken']=_0x153c8c['accessToken'],this['displayName']=_0x597b1f['displayName']||null,this['email']=_0x597b1f['email']||null,this['emailVerified']=_0x597b1f['emailVerified']||!0x1,this['phoneNumber']=_0x597b1f['phoneNumber']||null,this['photoURL']=_0x597b1f['photoURL']||null,this['isAnonymous']=_0x597b1f['isAnonymous']||!0x1,this['tenantId']=_0x597b1f['tenantId']||null,this['providerData']=_0x597b1f['providerData']?[..._0x597b1f['providerData']]:[],this['metadata']=new Li(_0x597b1f['createdAt']||void 0x0,_0x597b1f['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3b7fd1){const _0x41f65f=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x3b7fd1));return m(_0x41f65f,this['auth'],'internal-error'),this['accessToken']!==_0x41f65f&&(this['accessToken']=_0x41f65f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x41f65f;}['getIdTokenResult'](_0x374cd7){return yf(this,_0x374cd7);}['reload'](){return If(this);}['_assign'](_0x433b49){this!==_0x433b49&&(m(this['uid']===_0x433b49['uid'],this['auth'],'internal-error'),this['displayName']=_0x433b49['displayName'],this['photoURL']=_0x433b49['photoURL'],this['email']=_0x433b49['email'],this['emailVerified']=_0x433b49['emailVerified'],this['phoneNumber']=_0x433b49['phoneNumber'],this['isAnonymous']=_0x433b49['isAnonymous'],this['tenantId']=_0x433b49['tenantId'],this['providerData']=_0x433b49['providerData']['map'](_0x3a9dab=>({..._0x3a9dab})),this['metadata']['_copy'](_0x433b49['metadata']),this['stsTokenManager']['_assign'](_0x433b49['stsTokenManager']));}['_clone'](_0x5a0411){const _0x38442f=new j({...this,'auth':_0x5a0411,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x38442f['metadata']['_copy'](this['metadata']),_0x38442f;}['_onReload'](_0x181725){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x181725,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4b1a94){this['reloadListener']?this['reloadListener'](_0x4b1a94):this['reloadUserInfo']=_0x4b1a94;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xf5d75f,_0x3e3c56=!0x1){let _0x25f836=!0x1;_0xf5d75f['idToken']&&_0xf5d75f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xf5d75f),_0x25f836=!0x0),_0x3e3c56&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x25f836&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x45a909=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x45a909})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1e5463=>({..._0x1e5463})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x112123,_0x56bbae){const _0x1878cc=_0x56bbae['displayName']??void 0x0,_0x2fc878=_0x56bbae['email']??void 0x0,_0x3b3a12=_0x56bbae['phoneNumber']??void 0x0,_0x52b640=_0x56bbae['photoURL']??void 0x0,_0x10af01=_0x56bbae['tenantId']??void 0x0,_0x3fdf4b=_0x56bbae['_redirectEventId']??void 0x0,_0x8eefd5=_0x56bbae['createdAt']??void 0x0,_0x487dd5=_0x56bbae['lastLoginAt']??void 0x0,{uid:_0x43ff5e,emailVerified:_0x50300a,isAnonymous:_0xf4bfd6,providerData:_0xadb788,stsTokenManager:_0x56ad2a}=_0x56bbae;m(_0x43ff5e&&_0x56ad2a,_0x112123,'internal-error');const _0x6c1e4=et['fromJSON'](this['name'],_0x56ad2a);m(typeof _0x43ff5e=='string',_0x112123,'internal-error'),le(_0x1878cc,_0x112123['name']),le(_0x2fc878,_0x112123['name']),m(typeof _0x50300a=='boolean',_0x112123,'internal-error'),m(typeof _0xf4bfd6=='boolean',_0x112123,'internal-error'),le(_0x3b3a12,_0x112123['name']),le(_0x52b640,_0x112123['name']),le(_0x10af01,_0x112123['name']),le(_0x3fdf4b,_0x112123['name']),le(_0x8eefd5,_0x112123['name']),le(_0x487dd5,_0x112123['name']);const _0x3cd583=new j({'uid':_0x43ff5e,'auth':_0x112123,'email':_0x2fc878,'emailVerified':_0x50300a,'displayName':_0x1878cc,'isAnonymous':_0xf4bfd6,'photoURL':_0x52b640,'phoneNumber':_0x3b3a12,'tenantId':_0x10af01,'stsTokenManager':_0x6c1e4,'createdAt':_0x8eefd5,'lastLoginAt':_0x487dd5});return _0xadb788&&Array['isArray'](_0xadb788)&&(_0x3cd583['providerData']=_0xadb788['map'](_0x2e8e09=>({..._0x2e8e09}))),_0x3fdf4b&&(_0x3cd583['_redirectEventId']=_0x3fdf4b),_0x3cd583;}static async['_fromIdTokenResponse'](_0x32094a,_0x2b4698,_0x5db91f=!0x1){const _0x50ea6d=new et();_0x50ea6d['updateFromServerResponse'](_0x2b4698);const _0x1827aa=new j({'uid':_0x2b4698['localId'],'auth':_0x32094a,'stsTokenManager':_0x50ea6d,'isAnonymous':_0x5db91f});return await Pn(_0x1827aa),_0x1827aa;}static async['_fromGetAccountInfoResponse'](_0x4f6f92,_0x2e0eef,_0xe5545c){const _0x16cd81=_0x2e0eef['users'][0x0];m(_0x16cd81['localId']!==void 0x0,'internal-error');const _0x82df96=_0x16cd81['providerUserInfo']!==void 0x0?Sa(_0x16cd81['providerUserInfo']):[],_0xe38542=!(_0x16cd81['email']&&_0x16cd81['passwordHash'])&&!(_0x82df96!=null&&_0x82df96['length']),_0x501812=new et();_0x501812['updateFromIdToken'](_0xe5545c);const _0x5d6875=new j({'uid':_0x16cd81['localId'],'auth':_0x4f6f92,'stsTokenManager':_0x501812,'isAnonymous':_0xe38542}),_0x49e01d={'uid':_0x16cd81['localId'],'displayName':_0x16cd81['displayName']||null,'photoURL':_0x16cd81['photoUrl']||null,'email':_0x16cd81['email']||null,'emailVerified':_0x16cd81['emailVerified']||!0x1,'phoneNumber':_0x16cd81['phoneNumber']||null,'tenantId':_0x16cd81['tenantId']||null,'providerData':_0x82df96,'metadata':new Li(_0x16cd81['createdAt'],_0x16cd81['lastLoginAt']),'isAnonymous':!(_0x16cd81['email']&&_0x16cd81['passwordHash'])&&!(_0x82df96!=null&&_0x82df96['length'])};return Object['assign'](_0x5d6875,_0x49e01d),_0x5d6875;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x182666){ce(_0x182666 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3e1059=Tr['get'](_0x182666);return _0x3e1059?(ce(_0x3e1059 instanceof _0x182666,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3e1059):(_0x3e1059=new _0x182666(),Tr['set'](_0x182666,_0x3e1059),_0x3e1059);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x517b8c,_0x150a46){this['storage'][_0x517b8c]=_0x150a46;}async['_get'](_0xf7e416){const _0x49bd23=this['storage'][_0xf7e416];return _0x49bd23===void 0x0?null:_0x49bd23;}async['_remove'](_0x1c7b9c){delete this['storage'][_0x1c7b9c];}['_addListener'](_0x34dfa7,_0xb52e57){}['_removeListener'](_0x2185c7,_0x44299f){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1ee40a,_0x4406d8,_0x4bcdb3){return'firebase:'+_0x1ee40a+':'+_0x4406d8+':'+_0x4bcdb3;}class tt{constructor(_0xf123f0,_0x4d166d,_0x4ef77b){this['persistence']=_0xf123f0,this['auth']=_0x4d166d,this['userKey']=_0x4ef77b;const {config:_0x37542b,name:_0xaacaa2}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x37542b['apiKey'],_0xaacaa2),this['fullPersistenceKey']=ln('persistence',_0x37542b['apiKey'],_0xaacaa2),this['boundEventHandler']=_0x4d166d['_onStorageEvent']['bind'](_0x4d166d),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4542fc){return this['persistence']['_set'](this['fullUserKey'],_0x4542fc['toJSON']());}async['getCurrentUser'](){const _0x43191c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x43191c)return null;if(typeof _0x43191c=='string'){const _0x2fab63=await Nn(this['auth'],{'idToken':_0x43191c})['catch'](()=>{});return _0x2fab63?j['_fromGetAccountInfoResponse'](this['auth'],_0x2fab63,_0x43191c):null;}return j['_fromJSON'](this['auth'],_0x43191c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5ee5f0){if(this['persistence']===_0x5ee5f0)return;const _0x2fb7ed=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5ee5f0,_0x2fb7ed)return this['setCurrentUser'](_0x2fb7ed);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2601d9,_0x55fb80,_0x46796a='authUser'){if(!_0x55fb80['length'])return new tt(ie(Sr),_0x2601d9,_0x46796a);const _0x2398b5=(await Promise['all'](_0x55fb80['map'](async _0x6a48e3=>{if(await _0x6a48e3['_isAvailable']())return _0x6a48e3;})))['filter'](_0x4df3b6=>_0x4df3b6);let _0x40452d=_0x2398b5[0x0]||ie(Sr);const _0x1b6eac=ln(_0x46796a,_0x2601d9['config']['apiKey'],_0x2601d9['name']);let _0x22e6cd=null;for(const _0x151053 of _0x55fb80)try{const _0x2faa32=await _0x151053['_get'](_0x1b6eac);if(_0x2faa32){let _0x344f7b;if(typeof _0x2faa32=='string'){const _0x36ee19=await Nn(_0x2601d9,{'idToken':_0x2faa32})['catch'](()=>{});if(!_0x36ee19)break;_0x344f7b=await j['_fromGetAccountInfoResponse'](_0x2601d9,_0x36ee19,_0x2faa32);}else _0x344f7b=j['_fromJSON'](_0x2601d9,_0x2faa32);_0x151053!==_0x40452d&&(_0x22e6cd=_0x344f7b),_0x40452d=_0x151053;break;}}catch{}const _0x2db321=_0x2398b5['filter'](_0x19a943=>_0x19a943['_shouldAllowMigration']);return!_0x40452d['_shouldAllowMigration']||!_0x2db321['length']?new tt(_0x40452d,_0x2601d9,_0x46796a):(_0x40452d=_0x2db321[0x0],_0x22e6cd&&await _0x40452d['_set'](_0x1b6eac,_0x22e6cd['toJSON']()),await Promise['all'](_0x55fb80['map'](async _0x250928=>{if(_0x250928!==_0x40452d)try{await _0x250928['_remove'](_0x1b6eac);}catch{}})),new tt(_0x40452d,_0x2601d9,_0x46796a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5b7eaa){const _0x4bd1cb=_0x5b7eaa['toLowerCase']();if(_0x4bd1cb['includes']('opera/')||_0x4bd1cb['includes']('opr/')||_0x4bd1cb['includes']('opios/'))return'Opera';if(Na(_0x4bd1cb))return'IEMobile';if(_0x4bd1cb['includes']('msie')||_0x4bd1cb['includes']('trident/'))return'IE';if(_0x4bd1cb['includes']('edge/'))return'Edge';if(Ra(_0x4bd1cb))return'Firefox';if(_0x4bd1cb['includes']('silk/'))return'Silk';if(Oa(_0x4bd1cb))return'Blackberry';if(Da(_0x4bd1cb))return'Webos';if(Aa(_0x4bd1cb))return'Safari';if((_0x4bd1cb['includes']('chrome/')||ka(_0x4bd1cb))&&!_0x4bd1cb['includes']('edge/'))return'Chrome';if(Pa(_0x4bd1cb))return'Android';{const _0x326313=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4f26fc=_0x5b7eaa['match'](_0x326313);if((_0x4f26fc==null?void 0x0:_0x4f26fc['length'])===0x2)return _0x4f26fc[0x1];}return'Other';}function Ra(_0x30518e=W()){return/firefox\//i['test'](_0x30518e);}function Aa(_0xacf992=W()){const _0x156402=_0xacf992['toLowerCase']();return _0x156402['includes']('safari/')&&!_0x156402['includes']('chrome/')&&!_0x156402['includes']('crios/')&&!_0x156402['includes']('android');}function ka(_0x495fd3=W()){return/crios\//i['test'](_0x495fd3);}function Na(_0xe45321=W()){return/iemobile/i['test'](_0xe45321);}function Pa(_0x3d9fe6=W()){return/android/i['test'](_0x3d9fe6);}function Oa(_0x37f7a5=W()){return/blackberry/i['test'](_0x37f7a5);}function Da(_0x54cbca=W()){return/webos/i['test'](_0x54cbca);}function Ss(_0x8772e=W()){return/iphone|ipad|ipod/i['test'](_0x8772e)||/macintosh/i['test'](_0x8772e)&&/mobile/i['test'](_0x8772e);}function Sf(_0x5ed186=W()){var _0x322485;return Ss(_0x5ed186)&&!!((_0x322485=window['navigator'])!=null&&_0x322485['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3095ef=W()){return Ss(_0x3095ef)||Pa(_0x3095ef)||Da(_0x3095ef)||Oa(_0x3095ef)||/windows phone/i['test'](_0x3095ef)||Na(_0x3095ef);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x25708c,_0x2b3a32=[]){let _0x9ad06c;switch(_0x25708c){case'Browser':_0x9ad06c=br(W());break;case'Worker':_0x9ad06c=br(W())+'-'+_0x25708c;break;default:_0x9ad06c=_0x25708c;}const _0x8a97ff=_0x2b3a32['length']?_0x2b3a32['join'](','):'FirebaseCore-web';return _0x9ad06c+'/JsCore/'+dt+'/'+_0x8a97ff;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x270b26){this['auth']=_0x270b26,this['queue']=[];}['pushCallback'](_0x67a072,_0x4f21b9){const _0x40b1d2=_0x526fd4=>new Promise((_0x2fe002,_0x577021)=>{try{const _0x42dd66=_0x67a072(_0x526fd4);_0x2fe002(_0x42dd66);}catch(_0x64c818){_0x577021(_0x64c818);}});_0x40b1d2['onAbort']=_0x4f21b9,this['queue']['push'](_0x40b1d2);const _0x5780a4=this['queue']['length']-0x1;return()=>{this['queue'][_0x5780a4]=()=>Promise['resolve']();};}async['runMiddleware'](_0x19af5d){if(this['auth']['currentUser']===_0x19af5d)return;const _0x16229d=[];try{for(const _0x520a84 of this['queue'])await _0x520a84(_0x19af5d),_0x520a84['onAbort']&&_0x16229d['push'](_0x520a84['onAbort']);}catch(_0x32c18f){_0x16229d['reverse']();for(const _0x3c68d6 of _0x16229d)try{_0x3c68d6();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x32c18f==null?void 0x0:_0x32c18f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x405384,_0x3ea938={}){return ke(_0x405384,'GET','/v2/passwordPolicy',Ae(_0x405384,_0x3ea938));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x1e604e){var _0x443327;const _0x37d3f0=_0x1e604e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x37d3f0['minPasswordLength']??kf,_0x37d3f0['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x37d3f0['maxPasswordLength']),_0x37d3f0['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x37d3f0['containsLowercaseCharacter']),_0x37d3f0['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x37d3f0['containsUppercaseCharacter']),_0x37d3f0['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x37d3f0['containsNumericCharacter']),_0x37d3f0['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x37d3f0['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1e604e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x443327=_0x1e604e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x443327['join'](''))??'',this['forceUpgradeOnSignin']=_0x1e604e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1e604e['schemaVersion'];}['validatePassword'](_0x8beb67){const _0x274120={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x8beb67,_0x274120),this['validatePasswordCharacterOptions'](_0x8beb67,_0x274120),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['meetsMinPasswordLength']??!0x0),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['meetsMaxPasswordLength']??!0x0),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['containsLowercaseLetter']??!0x0),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['containsUppercaseLetter']??!0x0),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['containsNumericCharacter']??!0x0),_0x274120['isValid']&&(_0x274120['isValid']=_0x274120['containsNonAlphanumericCharacter']??!0x0),_0x274120;}['validatePasswordLengthOptions'](_0x45a276,_0x3c6dd0){const _0x57d7bd=this['customStrengthOptions']['minPasswordLength'],_0x2ad5ab=this['customStrengthOptions']['maxPasswordLength'];_0x57d7bd&&(_0x3c6dd0['meetsMinPasswordLength']=_0x45a276['length']>=_0x57d7bd),_0x2ad5ab&&(_0x3c6dd0['meetsMaxPasswordLength']=_0x45a276['length']<=_0x2ad5ab);}['validatePasswordCharacterOptions'](_0xa943f0,_0x2b0d9b){this['updatePasswordCharacterOptionsStatuses'](_0x2b0d9b,!0x1,!0x1,!0x1,!0x1);let _0x21704d;for(let _0x3bacfe=0x0;_0x3bacfe<_0xa943f0['length'];_0x3bacfe++)_0x21704d=_0xa943f0['charAt'](_0x3bacfe),this['updatePasswordCharacterOptionsStatuses'](_0x2b0d9b,_0x21704d>='a'&&_0x21704d<='z',_0x21704d>='A'&&_0x21704d<='Z',_0x21704d>='0'&&_0x21704d<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x21704d));}['updatePasswordCharacterOptionsStatuses'](_0x4c1961,_0x55da0,_0x54d325,_0x571e85,_0x41719f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4c1961['containsLowercaseLetter']||(_0x4c1961['containsLowercaseLetter']=_0x55da0)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4c1961['containsUppercaseLetter']||(_0x4c1961['containsUppercaseLetter']=_0x54d325)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4c1961['containsNumericCharacter']||(_0x4c1961['containsNumericCharacter']=_0x571e85)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4c1961['containsNonAlphanumericCharacter']||(_0x4c1961['containsNonAlphanumericCharacter']=_0x41719f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0x40e3af,_0x105402,_0xa70b97,_0x572238){this['app']=_0x40e3af,this['heartbeatServiceProvider']=_0x105402,this['appCheckServiceProvider']=_0xa70b97,this['config']=_0x572238,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x40e3af['name'],this['clientVersion']=_0x572238['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5ec446=>this['_resolvePersistenceManagerAvailable']=_0x5ec446);}['_initializeWithPersistence'](_0xe8ecbc,_0x2313e3){return _0x2313e3&&(this['_popupRedirectResolver']=ie(_0x2313e3)),this['_initializationPromise']=this['queue'](async()=>{var _0x11416c,_0x36ae59,_0x394271;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0xe8ecbc),(_0x11416c=this['_resolvePersistenceManagerAvailable'])==null||_0x11416c['call'](this),!this['_deleted'])){if((_0x36ae59=this['_popupRedirectResolver'])!=null&&_0x36ae59['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2313e3),this['lastNotifiedUid']=((_0x394271=this['currentUser'])==null?void 0x0:_0x394271['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x251fb5=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x251fb5)){if(this['currentUser']&&_0x251fb5&&this['currentUser']['uid']===_0x251fb5['uid']){this['_currentUser']['_assign'](_0x251fb5),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x251fb5,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1dc3b1){try{const _0x197ec8=await Nn(this,{'idToken':_0x1dc3b1}),_0x34f27f=await j['_fromGetAccountInfoResponse'](this,_0x197ec8,_0x1dc3b1);await this['directlySetCurrentUser'](_0x34f27f);}catch(_0x5e29b1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5e29b1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5e9a24){var _0x5541af;if($(this['app'])){const _0x2829b5=this['app']['settings']['authIdToken'];return _0x2829b5?new Promise(_0x48e48d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2829b5)['then'](_0x48e48d,_0x48e48d));}):this['directlySetCurrentUser'](null);}const _0x13f129=await this['assertedPersistence']['getCurrentUser']();let _0x4ff2a5=_0x13f129,_0xc349e3=!0x1;if(_0x5e9a24&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3dd122=(_0x5541af=this['redirectUser'])==null?void 0x0:_0x5541af['_redirectEventId'],_0x890a1=_0x4ff2a5==null?void 0x0:_0x4ff2a5['_redirectEventId'],_0x48092d=await this['tryRedirectSignIn'](_0x5e9a24);(!_0x3dd122||_0x3dd122===_0x890a1)&&(_0x48092d!=null&&_0x48092d['user'])&&(_0x4ff2a5=_0x48092d['user'],_0xc349e3=!0x0);}if(!_0x4ff2a5)return this['directlySetCurrentUser'](null);if(!_0x4ff2a5['_redirectEventId']){if(_0xc349e3)try{await this['beforeStateQueue']['runMiddleware'](_0x4ff2a5);}catch(_0x1540f9){_0x4ff2a5=_0x13f129,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1540f9));}return _0x4ff2a5?this['reloadAndSetCurrentUserOrClear'](_0x4ff2a5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4ff2a5['_redirectEventId']?this['directlySetCurrentUser'](_0x4ff2a5):this['reloadAndSetCurrentUserOrClear'](_0x4ff2a5);}async['tryRedirectSignIn'](_0x34f255){let _0x2f3fae=null;try{_0x2f3fae=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x34f255,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2f3fae;}async['reloadAndSetCurrentUserOrClear'](_0x59c727){try{await Pn(_0x59c727);}catch(_0x45dd6a){if((_0x45dd6a==null?void 0x0:_0x45dd6a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x59c727);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x334c68){if($(this['app']))return Promise['reject'](re(this));const _0x5749f7=_0x334c68?N(_0x334c68):null;return _0x5749f7&&m(_0x5749f7['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5749f7&&_0x5749f7['_clone'](this));}async['_updateCurrentUser'](_0xf7a583,_0xeb3dc6=!0x1){if(!this['_deleted'])return _0xf7a583&&m(this['tenantId']===_0xf7a583['tenantId'],this,'tenant-id-mismatch'),_0xeb3dc6||await this['beforeStateQueue']['runMiddleware'](_0xf7a583),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xf7a583),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1eb496){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1eb496));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x12115c){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3e783e=this['_getPasswordPolicyInternal']();return _0x3e783e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3e783e['validatePassword'](_0x12115c);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x128764=await Af(this),_0x4aeb64=new Nf(_0x128764);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4aeb64:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4aeb64;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x17c8d1){this['_errorFactory']=new $t('auth','Firebase',_0x17c8d1());}['onAuthStateChanged'](_0x5d888d,_0x40ecd9,_0x3a4574){return this['registerStateListener'](this['authStateSubscription'],_0x5d888d,_0x40ecd9,_0x3a4574);}['beforeAuthStateChanged'](_0x464a1d,_0x485054){return this['beforeStateQueue']['pushCallback'](_0x464a1d,_0x485054);}['onIdTokenChanged'](_0x4a7850,_0x383039,_0x5eb6c3){return this['registerStateListener'](this['idTokenSubscription'],_0x4a7850,_0x383039,_0x5eb6c3);}['authStateReady'](){return new Promise((_0x4bbd47,_0x86efbd)=>{if(this['currentUser'])_0x4bbd47();else{const _0x4c2a94=this['onAuthStateChanged'](()=>{_0x4c2a94(),_0x4bbd47();},_0x86efbd);}});}async['revokeAccessToken'](_0x28cf70){if(this['currentUser']){const _0xa69c80=await this['currentUser']['getIdToken'](),_0x10a014={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x28cf70,'idToken':_0xa69c80};this['tenantId']!=null&&(_0x10a014['tenantId']=this['tenantId']),await Tf(this,_0x10a014);}}['toJSON'](){var _0x469474;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x469474=this['_currentUser'])==null?void 0x0:_0x469474['toJSON']()};}async['_setRedirectUser'](_0xcbb9d5,_0x122a2b){const _0x35cb06=await this['getOrInitRedirectPersistenceManager'](_0x122a2b);return _0xcbb9d5===null?_0x35cb06['removeCurrentUser']():_0x35cb06['setCurrentUser'](_0xcbb9d5);}async['getOrInitRedirectPersistenceManager'](_0x144a4e){if(!this['redirectPersistenceManager']){const _0x56599d=_0x144a4e&&ie(_0x144a4e)||this['_popupRedirectResolver'];m(_0x56599d,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x56599d['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x80a0e7){var _0x3cc13a,_0x52c81f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3cc13a=this['_currentUser'])==null?void 0x0:_0x3cc13a['_redirectEventId'])===_0x80a0e7?this['_currentUser']:((_0x52c81f=this['redirectUser'])==null?void 0x0:_0x52c81f['_redirectEventId'])===_0x80a0e7?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x36b7c9){if(_0x36b7c9===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x36b7c9));}['_notifyListenersIfCurrent'](_0x54184b){_0x54184b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x279490;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x59bfff=((_0x279490=this['currentUser'])==null?void 0x0:_0x279490['uid'])??null;this['lastNotifiedUid']!==_0x59bfff&&(this['lastNotifiedUid']=_0x59bfff,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2b1d48,_0x265e33,_0x57b685,_0x1a57b1){if(this['_deleted'])return()=>{};const _0x5f5bb3=typeof _0x265e33=='function'?_0x265e33:_0x265e33['next']['bind'](_0x265e33);let _0x2e45b6=!0x1;const _0x765aea=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x765aea,this,'internal-error'),_0x765aea['then'](()=>{_0x2e45b6||_0x5f5bb3(this['currentUser']);}),typeof _0x265e33=='function'){const _0xbc7073=_0x2b1d48['addObserver'](_0x265e33,_0x57b685,_0x1a57b1);return()=>{_0x2e45b6=!0x0,_0xbc7073();};}else{const _0x5d8c48=_0x2b1d48['addObserver'](_0x265e33);return()=>{_0x2e45b6=!0x0,_0x5d8c48();};}}async['directlySetCurrentUser'](_0x11291e){this['currentUser']&&this['currentUser']!==_0x11291e&&this['_currentUser']['_stopProactiveRefresh'](),_0x11291e&&this['isProactiveRefreshEnabled']&&_0x11291e['_startProactiveRefresh'](),this['currentUser']=_0x11291e,_0x11291e?await this['assertedPersistence']['setCurrentUser'](_0x11291e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4a3c02){return this['operations']=this['operations']['then'](_0x4a3c02,_0x4a3c02),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3e0bc0){!_0x3e0bc0||this['frameworks']['includes'](_0x3e0bc0)||(this['frameworks']['push'](_0x3e0bc0),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5dce32;const _0x5bde14={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5bde14['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xe77d21=await((_0x5dce32=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5dce32['getHeartbeatsHeader']());_0xe77d21&&(_0x5bde14['X-Firebase-Client']=_0xe77d21);const _0xae1c38=await this['_getAppCheckToken']();return _0xae1c38&&(_0x5bde14['X-Firebase-AppCheck']=_0xae1c38),_0x5bde14;}async['_getAppCheckToken'](){var _0x117a2f;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xce802a=await((_0x117a2f=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x117a2f['getToken']());return _0xce802a!=null&&_0xce802a['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xce802a['error']),_0xce802a==null?void 0x0:_0xce802a['token'];}}function Ke(_0x13f401){return N(_0x13f401);}class Rr{constructor(_0x2707e3){this['auth']=_0x2707e3,this['observer']=null,this['addObserver']=Tc(_0x16f308=>this['observer']=_0x16f308);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x1f7435){Jn=_0x1f7435;}function xa(_0x498d5f){return Jn['loadJS'](_0x498d5f);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x18ffb3){return'__'+_0x18ffb3+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x1ad311){_0x1ad311();}['execute'](_0x3c9a0a,_0x29bb18){return Promise['resolve']('token');}['render'](_0x411e30,_0x23afe9){return'';}}class Ff{['ready'](_0x26296d){_0x26296d();}['execute'](_0x4607fc,_0xb37d04){return Promise['resolve']('token');}['render'](_0x3ae84f,_0x402858){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x605398){this['type']=Uf,this['auth']=Ke(_0x605398);}async['verify'](_0x5badbd='verify',_0x35d661=!0x1){async function _0x587657(_0x28e676){if(!_0x35d661){if(_0x28e676['tenantId']==null&&_0x28e676['_agentRecaptchaConfig']!=null)return _0x28e676['_agentRecaptchaConfig']['siteKey'];if(_0x28e676['tenantId']!=null&&_0x28e676['_tenantRecaptchaConfigs'][_0x28e676['tenantId']]!==void 0x0)return _0x28e676['_tenantRecaptchaConfigs'][_0x28e676['tenantId']]['siteKey'];}return new Promise(async(_0x1723a7,_0x3e9931)=>{gf(_0x28e676,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x5ad5a3=>{if(_0x5ad5a3['recaptchaKey']===void 0x0)_0x3e9931(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3f7aa8=new _f(_0x5ad5a3);return _0x28e676['tenantId']==null?_0x28e676['_agentRecaptchaConfig']=_0x3f7aa8:_0x28e676['_tenantRecaptchaConfigs'][_0x28e676['tenantId']]=_0x3f7aa8,_0x1723a7(_0x3f7aa8['siteKey']);}})['catch'](_0x34a1e1=>{_0x3e9931(_0x34a1e1);});});}function _0x6cc2d3(_0x4c2e63,_0x2dee9c,_0x5f0a96){const _0x2b0611=window['grecaptcha'];wr(_0x2b0611)?_0x2b0611['enterprise']['ready'](()=>{_0x2b0611['enterprise']['execute'](_0x4c2e63,{'action':_0x5badbd})['then'](_0x72f2b7=>{_0x2dee9c(_0x72f2b7);})['catch'](()=>{_0x2dee9c(Fa);});}):_0x5f0a96(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4885e6,_0xb08414)=>{_0x587657(this['auth'])['then'](async _0x1ae267=>{if(!_0x35d661&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x6cc2d3(_0x1ae267,_0x4885e6,_0xb08414);else{if(typeof window>'u'){_0xb08414(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4073e3=Df();_0x4073e3['length']!==0x0&&(_0x4073e3+=_0x1ae267+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x1347e;(_0x1347e=he['scriptInjectionDeferred'])==null||_0x1347e['resolve']();},xa(_0x4073e3)['then'](()=>{var _0x89caf8;return(_0x89caf8=he['scriptInjectionDeferred'])==null?void 0x0:_0x89caf8['promise'];})['then'](()=>{_0x6cc2d3(_0x1ae267,_0x4885e6,_0xb08414);})['catch'](_0xfe8ec8=>{_0xb08414(_0xfe8ec8);});}})['catch'](_0x12ce9c=>{_0xb08414(_0x12ce9c);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5ae225,_0x4c9b53,_0x30df03,_0x109015=!0x1,_0x46a305=!0x1){const _0x59886e=new he(_0x5ae225);let _0x1dc86f;if(_0x46a305)_0x1dc86f=Fa;else try{_0x1dc86f=await _0x59886e['verify'](_0x30df03);}catch{_0x1dc86f=await _0x59886e['verify'](_0x30df03,!0x0);}const _0x36b801={..._0x4c9b53};if(_0x30df03==='mfaSmsEnrollment'||_0x30df03==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x36b801){const _0xd41587=_0x36b801['phoneEnrollmentInfo']['phoneNumber'],_0x839f05=_0x36b801['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x36b801,{'phoneEnrollmentInfo':{'phoneNumber':_0xd41587,'recaptchaToken':_0x839f05,'captchaResponse':_0x1dc86f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x36b801){const _0x35e7e6=_0x36b801['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x36b801,{'phoneSignInInfo':{'recaptchaToken':_0x35e7e6,'captchaResponse':_0x1dc86f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x36b801;}return _0x109015?Object['assign'](_0x36b801,{'captchaResp':_0x1dc86f}):Object['assign'](_0x36b801,{'captchaResponse':_0x1dc86f}),Object['assign'](_0x36b801,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x36b801,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x36b801;}async function xi(_0x40cc25,_0x2956c1,_0x5a8943,_0x5cba51,_0x2daaed){var _0x1451da;if((_0x1451da=_0x40cc25['_getRecaptchaConfig']())!=null&&_0x1451da['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x50e426=await kr(_0x40cc25,_0x2956c1,_0x5a8943,_0x5a8943==='getOobCode');return _0x5cba51(_0x40cc25,_0x50e426);}else return _0x5cba51(_0x40cc25,_0x2956c1)['catch'](async _0x17c055=>{if(_0x17c055['code']==='auth/missing-recaptcha-token'){console['log'](_0x5a8943+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5eb953=await kr(_0x40cc25,_0x2956c1,_0x5a8943,_0x5a8943==='getOobCode');return _0x5cba51(_0x40cc25,_0x5eb953);}else return Promise['reject'](_0x17c055);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0x4c55e0,_0x72699b){const _0x2cbe2b=Hi(_0x4c55e0,'auth');if(_0x2cbe2b['isInitialized']()){const _0x497295=_0x2cbe2b['getImmediate'](),_0x38f290=_0x2cbe2b['getOptions']();if(Le(_0x38f290,_0x72699b??{}))return _0x497295;Y(_0x497295,'already-initialized');}return _0x2cbe2b['initialize']({'options':_0x72699b});}function Bf(_0x4cdff9,_0x2c8acf){const _0x1b9e81=(_0x2c8acf==null?void 0x0:_0x2c8acf['persistence'])||[],_0x21853c=(Array['isArray'](_0x1b9e81)?_0x1b9e81:[_0x1b9e81])['map'](ie);_0x2c8acf!=null&&_0x2c8acf['errorMap']&&_0x4cdff9['_updateErrorMap'](_0x2c8acf['errorMap']),_0x4cdff9['_initializeWithPersistence'](_0x21853c,_0x2c8acf==null?void 0x0:_0x2c8acf['popupRedirectResolver']);}function Vf(_0x233446,_0x6f2c50,_0x126065){const _0x2e192a=Ke(_0x233446);m(/^https?:\/\//['test'](_0x6f2c50),_0x2e192a,'invalid-emulator-scheme');const _0x353b33=!0x1,_0x19203a=Ua(_0x6f2c50),{host:_0x242183,port:_0x3ec3b3}=Hf(_0x6f2c50),_0x2c4e80=_0x3ec3b3===null?'':':'+_0x3ec3b3,_0x461c67={'url':_0x19203a+'//'+_0x242183+_0x2c4e80+'/'},_0x15e2fe=Object['freeze']({'host':_0x242183,'port':_0x3ec3b3,'protocol':_0x19203a['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x353b33})});if(!_0x2e192a['_canInitEmulator']){m(_0x2e192a['config']['emulator']&&_0x2e192a['emulatorConfig'],_0x2e192a,'emulator-config-failed'),m(Le(_0x461c67,_0x2e192a['config']['emulator'])&&Le(_0x15e2fe,_0x2e192a['emulatorConfig']),_0x2e192a,'emulator-config-failed');return;}_0x2e192a['config']['emulator']=_0x461c67,_0x2e192a['emulatorConfig']=_0x15e2fe,_0x2e192a['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x242183)?Qr(_0x19203a+'//'+_0x242183+_0x2c4e80):$f();}function Ua(_0x15760f){const _0x33e9d4=_0x15760f['indexOf'](':');return _0x33e9d4<0x0?'':_0x15760f['substr'](0x0,_0x33e9d4+0x1);}function Hf(_0x296a14){const _0x2eeb61=Ua(_0x296a14),_0x1f9702=/(\/\/)?([^?#/]+)/['exec'](_0x296a14['substr'](_0x2eeb61['length']));if(!_0x1f9702)return{'host':'','port':null};const _0x34abb=_0x1f9702[0x2]['split']('@')['pop']()||'',_0x5bee17=/^(\[[^\]]+\])(:|$)/['exec'](_0x34abb);if(_0x5bee17){const _0x41437e=_0x5bee17[0x1];return{'host':_0x41437e,'port':Nr(_0x34abb['substr'](_0x41437e['length']+0x1))};}else{const [_0x59fe8e,_0x1d1c3d]=_0x34abb['split'](':');return{'host':_0x59fe8e,'port':Nr(_0x1d1c3d)};}}function Nr(_0x240a4f){if(!_0x240a4f)return null;const _0x1c97a7=Number(_0x240a4f);return isNaN(_0x1c97a7)?null:_0x1c97a7;}function $f(){function _0x319ed5(){const _0x29b27b=document['createElement']('p'),_0xd04f34=_0x29b27b['style'];_0x29b27b['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xd04f34['position']='fixed',_0xd04f34['width']='100%',_0xd04f34['backgroundColor']='#ffffff',_0xd04f34['border']='.1em\x20solid\x20#000000',_0xd04f34['color']='#b50000',_0xd04f34['bottom']='0px',_0xd04f34['left']='0px',_0xd04f34['margin']='0px',_0xd04f34['zIndex']='10000',_0xd04f34['textAlign']='center',_0x29b27b['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x29b27b);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x319ed5):_0x319ed5());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3e5660,_0x214371){this['providerId']=_0x3e5660,this['signInMethod']=_0x214371;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x161108){return ne('not\x20implemented');}['_linkToIdToken'](_0x6d184e,_0x12af72){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x3848b8){return ne('not\x20implemented');}}async function Gf(_0x509913,_0x53d11a){return ke(_0x509913,'POST','/v1/accounts:signUp',_0x53d11a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5ca477,_0x3e81a2){return en(_0x5ca477,'POST','/v1/accounts:signInWithPassword',Ae(_0x5ca477,_0x3e81a2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4dd958,_0x1d2f16){return en(_0x4dd958,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x4dd958,_0x1d2f16));}async function jf(_0x871a6d,_0x134c64){return en(_0x871a6d,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x871a6d,_0x134c64));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x4cb32f,_0x2a0146,_0x58ae70,_0x3ca57c=null){super('password',_0x58ae70),this['_email']=_0x4cb32f,this['_password']=_0x2a0146,this['_tenantId']=_0x3ca57c;}static['_fromEmailAndPassword'](_0x2be2ed,_0x3ee9bb){return new Ht(_0x2be2ed,_0x3ee9bb,'password');}static['_fromEmailAndCode'](_0x17d884,_0x5a0ee5,_0x12dd01=null){return new Ht(_0x17d884,_0x5a0ee5,'emailLink',_0x12dd01);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1b65a0){const _0x258ebb=typeof _0x1b65a0=='string'?JSON['parse'](_0x1b65a0):_0x1b65a0;if(_0x258ebb!=null&&_0x258ebb['email']&&(_0x258ebb!=null&&_0x258ebb['password'])){if(_0x258ebb['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x258ebb['email'],_0x258ebb['password']);if(_0x258ebb['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x258ebb['email'],_0x258ebb['password'],_0x258ebb['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2141d7){switch(this['signInMethod']){case'password':const _0x20e6ee={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2141d7,_0x20e6ee,'signInWithPassword',qf);case'emailLink':return zf(_0x2141d7,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2141d7,'internal-error');}}async['_linkToIdToken'](_0x4a3b96,_0x1f8b40){switch(this['signInMethod']){case'password':const _0x5a9699={'idToken':_0x1f8b40,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4a3b96,_0x5a9699,'signUpPassword',Gf);case'emailLink':return jf(_0x4a3b96,{'idToken':_0x1f8b40,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4a3b96,'internal-error');}}['_getReauthenticationResolver'](_0x304b5e){return this['_getIdTokenResponse'](_0x304b5e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2c4744,_0x2eaba5){return en(_0x2c4744,'POST','/v1/accounts:signInWithIdp',Ae(_0x2c4744,_0x2eaba5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x127c08){const _0x546ce1=new He(_0x127c08['providerId'],_0x127c08['signInMethod']);return _0x127c08['idToken']||_0x127c08['accessToken']?(_0x127c08['idToken']&&(_0x546ce1['idToken']=_0x127c08['idToken']),_0x127c08['accessToken']&&(_0x546ce1['accessToken']=_0x127c08['accessToken']),_0x127c08['nonce']&&!_0x127c08['pendingToken']&&(_0x546ce1['nonce']=_0x127c08['nonce']),_0x127c08['pendingToken']&&(_0x546ce1['pendingToken']=_0x127c08['pendingToken'])):_0x127c08['oauthToken']&&_0x127c08['oauthTokenSecret']?(_0x546ce1['accessToken']=_0x127c08['oauthToken'],_0x546ce1['secret']=_0x127c08['oauthTokenSecret']):Y('argument-error'),_0x546ce1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2ab1c2){const _0x1fd818=typeof _0x2ab1c2=='string'?JSON['parse'](_0x2ab1c2):_0x2ab1c2,{providerId:_0x1caef9,signInMethod:_0x2c904b,..._0x2a5efd}=_0x1fd818;if(!_0x1caef9||!_0x2c904b)return null;const _0x3ed07f=new He(_0x1caef9,_0x2c904b);return _0x3ed07f['idToken']=_0x2a5efd['idToken']||void 0x0,_0x3ed07f['accessToken']=_0x2a5efd['accessToken']||void 0x0,_0x3ed07f['secret']=_0x2a5efd['secret'],_0x3ed07f['nonce']=_0x2a5efd['nonce'],_0x3ed07f['pendingToken']=_0x2a5efd['pendingToken']||null,_0x3ed07f;}['_getIdTokenResponse'](_0xdf1d97){const _0x5d21b7=this['buildRequest']();return nt(_0xdf1d97,_0x5d21b7);}['_linkToIdToken'](_0x15986a,_0x1b1186){const _0x166637=this['buildRequest']();return _0x166637['idToken']=_0x1b1186,nt(_0x15986a,_0x166637);}['_getReauthenticationResolver'](_0x1249fe){const _0x378868=this['buildRequest']();return _0x378868['autoCreate']=!0x1,nt(_0x1249fe,_0x378868);}['buildRequest'](){const _0x3f6609={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3f6609['pendingToken']=this['pendingToken'];else{const _0x985058={};this['idToken']&&(_0x985058['id_token']=this['idToken']),this['accessToken']&&(_0x985058['access_token']=this['accessToken']),this['secret']&&(_0x985058['oauth_token_secret']=this['secret']),_0x985058['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x985058['nonce']=this['nonce']),_0x3f6609['postBody']=ut(_0x985058);}return _0x3f6609;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0x133ab9){switch(_0x133ab9){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x12fdf3){const _0x7e7acd=wt(Ct(_0x12fdf3))['link'],_0x10df90=_0x7e7acd?wt(Ct(_0x7e7acd))['deep_link_id']:null,_0x52fde2=wt(Ct(_0x12fdf3))['deep_link_id'];return(_0x52fde2?wt(Ct(_0x52fde2))['link']:null)||_0x52fde2||_0x10df90||_0x7e7acd||_0x12fdf3;}class Rs{constructor(_0x7c5890){const _0x4a7c77=wt(Ct(_0x7c5890)),_0x227154=_0x4a7c77['apiKey']??null,_0x57dd03=_0x4a7c77['oobCode']??null,_0x347c49=Yf(_0x4a7c77['mode']??null);m(_0x227154&&_0x57dd03&&_0x347c49,'argument-error'),this['apiKey']=_0x227154,this['operation']=_0x347c49,this['code']=_0x57dd03,this['continueUrl']=_0x4a7c77['continueUrl']??null,this['languageCode']=_0x4a7c77['lang']??null,this['tenantId']=_0x4a7c77['tenantId']??null;}static['parseLink'](_0x368a68){const _0x4261c9=Qf(_0x368a68);try{return new Rs(_0x4261c9);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x35e69e,_0x3a377e){return Ht['_fromEmailAndPassword'](_0x35e69e,_0x3a377e);}static['credentialWithLink'](_0x3dcc3b,_0x4a89f2){const _0x36a69a=Rs['parseLink'](_0x4a89f2);return m(_0x36a69a,'argument-error'),Ht['_fromEmailAndCode'](_0x3dcc3b,_0x36a69a['code'],_0x36a69a['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0xa938e9){this['providerId']=_0xa938e9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x50b55c){this['defaultLanguageCode']=_0x50b55c;}['setCustomParameters'](_0x4834d0){return this['customParameters']=_0x4834d0,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x59880c){return this['scopes']['includes'](_0x59880c)||this['scopes']['push'](_0x59880c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2fa7d1){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2fa7d1});}static['credentialFromResult'](_0xd38498){return ue['credentialFromTaggedObject'](_0xd38498);}static['credentialFromError'](_0x36cd63){return ue['credentialFromTaggedObject'](_0x36cd63['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2739b1}){if(!_0x2739b1||!('oauthAccessToken'in _0x2739b1)||!_0x2739b1['oauthAccessToken'])return null;try{return ue['credential'](_0x2739b1['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1ac6cb,_0xc7b5){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1ac6cb,'accessToken':_0xc7b5});}static['credentialFromResult'](_0x4a1dbf){return de['credentialFromTaggedObject'](_0x4a1dbf);}static['credentialFromError'](_0x4be28a){return de['credentialFromTaggedObject'](_0x4be28a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47b0d4}){if(!_0x47b0d4)return null;const {oauthIdToken:_0x131a12,oauthAccessToken:_0x1e8872}=_0x47b0d4;if(!_0x131a12&&!_0x1e8872)return null;try{return de['credential'](_0x131a12,_0x1e8872);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4dfad6){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4dfad6});}static['credentialFromResult'](_0x885d71){return fe['credentialFromTaggedObject'](_0x885d71);}static['credentialFromError'](_0x270614){return fe['credentialFromTaggedObject'](_0x270614['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4bf8c2}){if(!_0x4bf8c2||!('oauthAccessToken'in _0x4bf8c2)||!_0x4bf8c2['oauthAccessToken'])return null;try{return fe['credential'](_0x4bf8c2['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4e1f21,_0x28e43e){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4e1f21,'oauthTokenSecret':_0x28e43e});}static['credentialFromResult'](_0x58afca){return pe['credentialFromTaggedObject'](_0x58afca);}static['credentialFromError'](_0x1197e0){return pe['credentialFromTaggedObject'](_0x1197e0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x34688e}){if(!_0x34688e)return null;const {oauthAccessToken:_0x497861,oauthTokenSecret:_0x5d530a}=_0x34688e;if(!_0x497861||!_0x5d530a)return null;try{return pe['credential'](_0x497861,_0x5d530a);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x3ae2f9,_0x404301){return en(_0x3ae2f9,'POST','/v1/accounts:signUp',Ae(_0x3ae2f9,_0x404301));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x14dc26){this['user']=_0x14dc26['user'],this['providerId']=_0x14dc26['providerId'],this['_tokenResponse']=_0x14dc26['_tokenResponse'],this['operationType']=_0x14dc26['operationType'];}static async['_fromIdTokenResponse'](_0x5ad9f5,_0x393fe7,_0x27b768,_0x49a40a=!0x1){const _0x410710=await j['_fromIdTokenResponse'](_0x5ad9f5,_0x27b768,_0x49a40a),_0x1e06fd=Pr(_0x27b768);return new $e({'user':_0x410710,'providerId':_0x1e06fd,'_tokenResponse':_0x27b768,'operationType':_0x393fe7});}static async['_forOperation'](_0x28504a,_0x2bbf50,_0x235499){await _0x28504a['_updateTokensIfNecessary'](_0x235499,!0x0);const _0x25a8e8=Pr(_0x235499);return new $e({'user':_0x28504a,'providerId':_0x25a8e8,'_tokenResponse':_0x235499,'operationType':_0x2bbf50});}}function Pr(_0x4845bc){return _0x4845bc['providerId']?_0x4845bc['providerId']:'phoneNumber'in _0x4845bc?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x28e596,_0x1e7b6f,_0x1aea35,_0x42e5c6){super(_0x1e7b6f['code'],_0x1e7b6f['message']),this['operationType']=_0x1aea35,this['user']=_0x42e5c6,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x28e596['name'],'tenantId':_0x28e596['tenantId']??void 0x0,'_serverResponse':_0x1e7b6f['customData']['_serverResponse'],'operationType':_0x1aea35};}static['_fromErrorAndOperation'](_0xc9b90c,_0x3e0d28,_0x46b96e,_0x270646){return new On(_0xc9b90c,_0x3e0d28,_0x46b96e,_0x270646);}}function Ba(_0x2cda31,_0x3db436,_0xcf0d55,_0x53d6ab){return(_0x3db436==='reauthenticate'?_0xcf0d55['_getReauthenticationResolver'](_0x2cda31):_0xcf0d55['_getIdTokenResponse'](_0x2cda31))['catch'](_0x26f245=>{throw _0x26f245['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x2cda31,_0x26f245,_0x3db436,_0x53d6ab):_0x26f245;});}async function Xf(_0x1886f7,_0x12ee7a,_0x4f006a=!0x1){const _0x5deecb=await Vt(_0x1886f7,_0x12ee7a['_linkToIdToken'](_0x1886f7['auth'],await _0x1886f7['getIdToken']()),_0x4f006a);return $e['_forOperation'](_0x1886f7,'link',_0x5deecb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4dd6a0,_0x522cc3,_0x2b3cc1=!0x1){const {auth:_0x3cef4c}=_0x4dd6a0;if($(_0x3cef4c['app']))return Promise['reject'](re(_0x3cef4c));const _0x33995='reauthenticate';try{const _0x168dc4=await Vt(_0x4dd6a0,Ba(_0x3cef4c,_0x33995,_0x522cc3,_0x4dd6a0),_0x2b3cc1);m(_0x168dc4['idToken'],_0x3cef4c,'internal-error');const _0x287d79=Ts(_0x168dc4['idToken']);m(_0x287d79,_0x3cef4c,'internal-error');const {sub:_0x425ee5}=_0x287d79;return m(_0x4dd6a0['uid']===_0x425ee5,_0x3cef4c,'user-mismatch'),$e['_forOperation'](_0x4dd6a0,_0x33995,_0x168dc4);}catch(_0x38dd12){throw(_0x38dd12==null?void 0x0:_0x38dd12['code'])==='auth/user-not-found'&&Y(_0x3cef4c,'user-mismatch'),_0x38dd12;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2081a3,_0x1e55f0,_0x5ea48a=!0x1){if($(_0x2081a3['app']))return Promise['reject'](re(_0x2081a3));const _0x7478bb='signIn',_0x52ea65=await Ba(_0x2081a3,_0x7478bb,_0x1e55f0),_0x43a340=await $e['_fromIdTokenResponse'](_0x2081a3,_0x7478bb,_0x52ea65);return _0x5ea48a||await _0x2081a3['_updateCurrentUser'](_0x43a340['user']),_0x43a340;}async function ep(_0x33a9a9,_0x4310d6){return Va(Ke(_0x33a9a9),_0x4310d6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x585c7f){const _0x231095=Ke(_0x585c7f);_0x231095['_getPasswordPolicyInternal']()&&await _0x231095['_updatePasswordPolicy']();}async function O_(_0x236b85,_0x3fa826,_0x3eb09d){if($(_0x236b85['app']))return Promise['reject'](re(_0x236b85));const _0x5e7538=Ke(_0x236b85),_0x5a700c=await xi(_0x5e7538,{'returnSecureToken':!0x0,'email':_0x3fa826,'password':_0x3eb09d,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0xccbce=>{throw _0xccbce['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x236b85),_0xccbce;}),_0x33f8c7=await $e['_fromIdTokenResponse'](_0x5e7538,'signIn',_0x5a700c);return await _0x5e7538['_updateCurrentUser'](_0x33f8c7['user']),_0x33f8c7;}function D_(_0xc7ae2c,_0x58d50b,_0x1901b8){return $(_0xc7ae2c['app'])?Promise['reject'](re(_0xc7ae2c)):ep(N(_0xc7ae2c),mt['credential'](_0x58d50b,_0x1901b8))['catch'](async _0x1d5809=>{throw _0x1d5809['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xc7ae2c),_0x1d5809;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x14d0ec,_0x40b9df){return N(_0x14d0ec)['setPersistence'](_0x40b9df);}function tp(_0x4dd1d1,_0x5b44d6,_0x349edd,_0x2229b3){return N(_0x4dd1d1)['onIdTokenChanged'](_0x5b44d6,_0x349edd,_0x2229b3);}function np(_0x140ec4,_0x25b39b,_0x3ffd09){return N(_0x140ec4)['beforeAuthStateChanged'](_0x25b39b,_0x3ffd09);}function L_(_0x1578ad,_0x7cacff,_0x396582,_0x5bcd1a){return N(_0x1578ad)['onAuthStateChanged'](_0x7cacff,_0x396582,_0x5bcd1a);}function x_(_0x204fcd){return N(_0x204fcd)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x12a6d2,_0x59fc06){this['storageRetriever']=_0x12a6d2,this['type']=_0x59fc06;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5a4039,_0x108765){return this['storage']['setItem'](_0x5a4039,JSON['stringify'](_0x108765)),Promise['resolve']();}['_get'](_0x342a91){const _0x48217c=this['storage']['getItem'](_0x342a91);return Promise['resolve'](_0x48217c?JSON['parse'](_0x48217c):null);}['_remove'](_0x204681){return this['storage']['removeItem'](_0x204681),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xc36934,_0x27cacc)=>this['onStorageEvent'](_0xc36934,_0x27cacc),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x85a46d){for(const _0x1c28a7 of Object['keys'](this['listeners'])){const _0x4ed86f=this['storage']['getItem'](_0x1c28a7),_0x5b95ff=this['localCache'][_0x1c28a7];_0x4ed86f!==_0x5b95ff&&_0x85a46d(_0x1c28a7,_0x5b95ff,_0x4ed86f);}}['onStorageEvent'](_0x4180d8,_0x23845c=!0x1){if(!_0x4180d8['key']){this['forAllChangedKeys']((_0x5e3462,_0x56ea23,_0x1b4a7e)=>{this['notifyListeners'](_0x5e3462,_0x1b4a7e);});return;}const _0x18e2c6=_0x4180d8['key'];_0x23845c?this['detachListener']():this['stopPolling']();const _0x146ca9=()=>{const _0x751955=this['storage']['getItem'](_0x18e2c6);!_0x23845c&&this['localCache'][_0x18e2c6]===_0x751955||this['notifyListeners'](_0x18e2c6,_0x751955);},_0x658c59=this['storage']['getItem'](_0x18e2c6);bf()&&_0x658c59!==_0x4180d8['newValue']&&_0x4180d8['newValue']!==_0x4180d8['oldValue']?setTimeout(_0x146ca9,sp):_0x146ca9();}['notifyListeners'](_0x18e39c,_0x269797){this['localCache'][_0x18e39c]=_0x269797;const _0x2a726c=this['listeners'][_0x18e39c];if(_0x2a726c){for(const _0x226f08 of Array['from'](_0x2a726c))_0x226f08(_0x269797&&JSON['parse'](_0x269797));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x305c0d,_0x11984c,_0x52b7f4)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x305c0d,'oldValue':_0x11984c,'newValue':_0x52b7f4}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x301e97,_0x621f3a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x301e97]||(this['listeners'][_0x301e97]=new Set(),this['localCache'][_0x301e97]=this['storage']['getItem'](_0x301e97)),this['listeners'][_0x301e97]['add'](_0x621f3a);}['_removeListener'](_0x3eafd9,_0x2e56bf){this['listeners'][_0x3eafd9]&&(this['listeners'][_0x3eafd9]['delete'](_0x2e56bf),this['listeners'][_0x3eafd9]['size']===0x0&&delete this['listeners'][_0x3eafd9]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x292321,_0x2acf29){await super['_set'](_0x292321,_0x2acf29),this['localCache'][_0x292321]=JSON['stringify'](_0x2acf29);}async['_get'](_0x3b5f2b){const _0x5bdb98=await super['_get'](_0x3b5f2b);return this['localCache'][_0x3b5f2b]=JSON['stringify'](_0x5bdb98),_0x5bdb98;}async['_remove'](_0x103833){await super['_remove'](_0x103833),delete this['localCache'][_0x103833];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x57c70f,_0x4f8d1){}['_removeListener'](_0x4473ea,_0x9e668b){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x9fe348){return Promise['all'](_0x9fe348['map'](async _0x5073d4=>{try{return{'fulfilled':!0x0,'value':await _0x5073d4};}catch(_0x44ed4a){return{'fulfilled':!0x1,'reason':_0x44ed4a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x20893a){this['eventTarget']=_0x20893a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3512ce){const _0x2fdd40=this['receivers']['find'](_0x5174fe=>_0x5174fe['isListeningto'](_0x3512ce));if(_0x2fdd40)return _0x2fdd40;const _0xeab47d=new Xn(_0x3512ce);return this['receivers']['push'](_0xeab47d),_0xeab47d;}['isListeningto'](_0x1dee31){return this['eventTarget']===_0x1dee31;}async['handleEvent'](_0x3595c3){const _0x5820f6=_0x3595c3,{eventId:_0x155dca,eventType:_0x4b9afd,data:_0x118f51}=_0x5820f6['data'],_0x4a0f8f=this['handlersMap'][_0x4b9afd];if(!(_0x4a0f8f!=null&&_0x4a0f8f['size']))return;_0x5820f6['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x155dca,'eventType':_0x4b9afd});const _0x126696=Array['from'](_0x4a0f8f)['map'](async _0x114615=>_0x114615(_0x5820f6['origin'],_0x118f51)),_0x5830a9=await op(_0x126696);_0x5820f6['ports'][0x0]['postMessage']({'status':'done','eventId':_0x155dca,'eventType':_0x4b9afd,'response':_0x5830a9});}['_subscribe'](_0x1879bf,_0x4f0d24){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1879bf]||(this['handlersMap'][_0x1879bf]=new Set()),this['handlersMap'][_0x1879bf]['add'](_0x4f0d24);}['_unsubscribe'](_0x4d1c22,_0xaf1d35){this['handlersMap'][_0x4d1c22]&&_0xaf1d35&&this['handlersMap'][_0x4d1c22]['delete'](_0xaf1d35),(!_0xaf1d35||this['handlersMap'][_0x4d1c22]['size']===0x0)&&delete this['handlersMap'][_0x4d1c22],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x435831='',_0x353689=0xa){let _0x26965c='';for(let _0x43c93d=0x0;_0x43c93d<_0x353689;_0x43c93d++)_0x26965c+=Math['floor'](Math['random']()*0xa);return _0x435831+_0x26965c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0x16baca){this['target']=_0x16baca,this['handlers']=new Set();}['removeMessageHandler'](_0x53bc01){_0x53bc01['messageChannel']&&(_0x53bc01['messageChannel']['port1']['removeEventListener']('message',_0x53bc01['onMessage']),_0x53bc01['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x53bc01);}async['_send'](_0x21be42,_0x502ce4,_0x1564e7=0x32){const _0x495cce=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x495cce)throw new Error('connection_unavailable');let _0x5dcf0e,_0x236195;return new Promise((_0x1fbd9b,_0x8a4e46)=>{const _0x5b7c9a=As('',0x14);_0x495cce['port1']['start']();const _0x909abf=setTimeout(()=>{_0x8a4e46(new Error('unsupported_event'));},_0x1564e7);_0x236195={'messageChannel':_0x495cce,'onMessage'(_0x17b2c8){const _0x4ee7f7=_0x17b2c8;if(_0x4ee7f7['data']['eventId']===_0x5b7c9a)switch(_0x4ee7f7['data']['status']){case'ack':clearTimeout(_0x909abf),_0x5dcf0e=setTimeout(()=>{_0x8a4e46(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5dcf0e),_0x1fbd9b(_0x4ee7f7['data']['response']);break;default:clearTimeout(_0x909abf),clearTimeout(_0x5dcf0e),_0x8a4e46(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x236195),_0x495cce['port1']['addEventListener']('message',_0x236195['onMessage']),this['target']['postMessage']({'eventType':_0x21be42,'eventId':_0x5b7c9a,'data':_0x502ce4},[_0x495cce['port2']]);})['finally'](()=>{_0x236195&&this['removeMessageHandler'](_0x236195);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0x33a52e){Z()['location']['href']=_0x33a52e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x34d540;return((_0x34d540=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x34d540['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4018ee){this['request']=_0x4018ee;}['toPromise'](){return new Promise((_0x145a57,_0x5acc76)=>{this['request']['addEventListener']('success',()=>{_0x145a57(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x5acc76(this['request']['error']);});});}}function Zn(_0x35f89e,_0x30f417){return _0x35f89e['transaction']([Mn],_0x30f417?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x1d7c3d=indexedDB['deleteDatabase'](Ka);return new nn(_0x1d7c3d)['toPromise']();}function Qa(){const _0x4a5fc1=indexedDB['open'](Ka,dp);return new Promise((_0x40a343,_0x2c4f45)=>{_0x4a5fc1['addEventListener']('error',()=>{_0x2c4f45(_0x4a5fc1['error']);}),_0x4a5fc1['addEventListener']('upgradeneeded',()=>{const _0x18b592=_0x4a5fc1['result'];try{_0x18b592['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3cf863){_0x2c4f45(_0x3cf863);}}),_0x4a5fc1['addEventListener']('success',async()=>{const _0x53e69b=_0x4a5fc1['result'];_0x53e69b['objectStoreNames']['contains'](Mn)?_0x40a343(_0x53e69b):(_0x53e69b['close'](),await fp(),_0x40a343(await Qa()));});});}async function Or(_0x5b3db7,_0x52e1ca,_0x3c6234){const _0x2d1be9=Zn(_0x5b3db7,!0x0)['put']({[Ya]:_0x52e1ca,'value':_0x3c6234});return new nn(_0x2d1be9)['toPromise']();}async function pp(_0x5b4574,_0x3891a){const _0x427f26=Zn(_0x5b4574,!0x1)['get'](_0x3891a),_0x3b0f6a=await new nn(_0x427f26)['toPromise']();return _0x3b0f6a===void 0x0?null:_0x3b0f6a['value'];}function Dr(_0x165826,_0x16057c){const _0x4ad2d1=Zn(_0x165826,!0x0)['delete'](_0x16057c);return new nn(_0x4ad2d1)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1f05c7){let _0x53f103=0x0;for(;;)try{const _0x1d8cb5=await this['_openDb']();return await _0x1f05c7(_0x1d8cb5);}catch(_0x2b5f9e){if(_0x53f103++>gp)throw _0x2b5f9e;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0x5aa273,_0x1019f8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1019f8['key'])})),this['receiver']['_subscribe']('ping',async(_0x45f227,_0x4657e6)=>['keyChanged']);}async['initializeSender'](){var _0x5740d3,_0x5af304;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0x325634=await this['sender']['_send']('ping',{},0x320);_0x325634&&(_0x5740d3=_0x325634[0x0])!=null&&_0x5740d3['fulfilled']&&(_0x5af304=_0x325634[0x0])!=null&&_0x5af304['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x995d8b){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x995d8b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x19f27c=>{await Or(_0x19f27c,Dn,'1'),await Dr(_0x19f27c,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x34a817){this['pendingWrites']++;try{await _0x34a817();}finally{this['pendingWrites']--;}}async['_set'](_0x149f8f,_0x287de5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x524617=>Or(_0x524617,_0x149f8f,_0x287de5)),this['localCache'][_0x149f8f]=_0x287de5,this['notifyServiceWorker'](_0x149f8f)));}async['_get'](_0x458f73){const _0x26a492=await this['_withRetries'](_0x3645af=>pp(_0x3645af,_0x458f73));return this['localCache'][_0x458f73]=_0x26a492,_0x26a492;}async['_remove'](_0x11b451){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x209aea=>Dr(_0x209aea,_0x11b451)),delete this['localCache'][_0x11b451],this['notifyServiceWorker'](_0x11b451)));}async['_poll'](){const _0x255e22=await this['_withRetries'](_0x37fa6e=>{const _0x41f56a=Zn(_0x37fa6e,!0x1)['getAll']();return new nn(_0x41f56a)['toPromise']();});if(!_0x255e22)return[];if(this['pendingWrites']!==0x0)return[];const _0x534cec=[],_0x49b1d3=new Set();if(_0x255e22['length']!==0x0){for(const {fbase_key:_0x34a2d5,value:_0x133e2f}of _0x255e22)_0x49b1d3['add'](_0x34a2d5),JSON['stringify'](this['localCache'][_0x34a2d5])!==JSON['stringify'](_0x133e2f)&&(this['notifyListeners'](_0x34a2d5,_0x133e2f),_0x534cec['push'](_0x34a2d5));}for(const _0x2cf428 of Object['keys'](this['localCache']))this['localCache'][_0x2cf428]&&!_0x49b1d3['has'](_0x2cf428)&&(this['notifyListeners'](_0x2cf428,null),_0x534cec['push'](_0x2cf428));return _0x534cec;}['notifyListeners'](_0x9380a5,_0x8efc7d){this['localCache'][_0x9380a5]=_0x8efc7d;const _0xa113b=this['listeners'][_0x9380a5];if(_0xa113b){for(const _0x59fcc3 of Array['from'](_0xa113b))_0x59fcc3(_0x8efc7d);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x404aea,_0x423dc8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x404aea]||(this['listeners'][_0x404aea]=new Set(),this['_get'](_0x404aea)),this['listeners'][_0x404aea]['add'](_0x423dc8);}['_removeListener'](_0x3ccdb7,_0x374cae){this['listeners'][_0x3ccdb7]&&(this['listeners'][_0x3ccdb7]['delete'](_0x374cae),this['listeners'][_0x3ccdb7]['size']===0x0&&delete this['listeners'][_0x3ccdb7]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0x2be556,_0x1e34e3){return _0x1e34e3?ie(_0x1e34e3):(m(_0x2be556['_popupRedirectResolver'],_0x2be556,'argument-error'),_0x2be556['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4928b3){super('custom','custom'),this['params']=_0x4928b3;}['_getIdTokenResponse'](_0x4ccb0c){return nt(_0x4ccb0c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x19ef3f,_0x1b4f81){return nt(_0x19ef3f,this['_buildIdpRequest'](_0x1b4f81));}['_getReauthenticationResolver'](_0x17cd3c){return nt(_0x17cd3c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x557832){const _0x151a39={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x557832&&(_0x151a39['idToken']=_0x557832),_0x151a39;}}function vp(_0x151512){return Va(_0x151512['auth'],new ks(_0x151512),_0x151512['bypassAuthState']);}function Ep(_0x1827ba){const {auth:_0xa5e4c1,user:_0x584ac3}=_0x1827ba;return m(_0x584ac3,_0xa5e4c1,'internal-error'),Zf(_0x584ac3,new ks(_0x1827ba),_0x1827ba['bypassAuthState']);}async function Ip(_0x57ef72){const {auth:_0x4f895b,user:_0x57ce69}=_0x57ef72;return m(_0x57ce69,_0x4f895b,'internal-error'),Xf(_0x57ce69,new ks(_0x57ef72),_0x57ef72['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x5cf637,_0x16c905,_0x3afb63,_0xa80080,_0x44ac28=!0x1){this['auth']=_0x5cf637,this['resolver']=_0x3afb63,this['user']=_0xa80080,this['bypassAuthState']=_0x44ac28,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x16c905)?_0x16c905:[_0x16c905];}['execute'](){return new Promise(async(_0x1bda6d,_0x4f7385)=>{this['pendingPromise']={'resolve':_0x1bda6d,'reject':_0x4f7385};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x613339){this['reject'](_0x613339);}});}async['onAuthEvent'](_0x561694){const {urlResponse:_0x59ac17,sessionId:_0x71d999,postBody:_0x3447bf,tenantId:_0xeb601,error:_0x21bef8,type:_0x2c1cef}=_0x561694;if(_0x21bef8){this['reject'](_0x21bef8);return;}const _0x2ae192={'auth':this['auth'],'requestUri':_0x59ac17,'sessionId':_0x71d999,'tenantId':_0xeb601||void 0x0,'postBody':_0x3447bf||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2c1cef)(_0x2ae192));}catch(_0x5c63e3){this['reject'](_0x5c63e3);}}['onError'](_0xe78a71){this['reject'](_0xe78a71);}['getIdpTask'](_0x2c440d){switch(_0x2c440d){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0x5c234f){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5c234f),this['unregisterAndCleanUp']();}['reject'](_0x40ba78){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x40ba78),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x1560d1,_0x3ab9af,_0x1a2324,_0x39134d,_0x2e247e){super(_0x1560d1,_0x3ab9af,_0x39134d,_0x2e247e),this['provider']=_0x1a2324,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4221c3=await this['execute']();return m(_0x4221c3,this['auth'],'internal-error'),_0x4221c3;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2b3c0f=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2b3c0f),this['authWindow']['associatedEvent']=_0x2b3c0f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x841b27=>{this['reject'](_0x841b27);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x364d63=>{_0x364d63||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2dd1f5;return((_0x2dd1f5=this['authWindow'])==null?void 0x0:_0x2dd1f5['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x289906=()=>{var _0x27f0bc,_0x24848d;if((_0x24848d=(_0x27f0bc=this['authWindow'])==null?void 0x0:_0x27f0bc['window'])!=null&&_0x24848d['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x289906,wp['get']());};_0x289906();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x16ad83,_0x5427a2,_0x2f48e4=!0x1){super(_0x16ad83,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5427a2,void 0x0,_0x2f48e4),this['eventId']=null;}async['execute'](){let _0x2d6b79=hn['get'](this['auth']['_key']());if(!_0x2d6b79){try{const _0x5d5e33=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0x2d6b79=()=>Promise['resolve'](_0x5d5e33);}catch(_0x140bb8){_0x2d6b79=()=>Promise['reject'](_0x140bb8);}hn['set'](this['auth']['_key'](),_0x2d6b79);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2d6b79();}async['onAuthEvent'](_0x2fbbd9){if(_0x2fbbd9['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2fbbd9);if(_0x2fbbd9['type']==='unknown'){this['resolve'](null);return;}if(_0x2fbbd9['eventId']){const _0xc2bc5d=await this['auth']['_redirectUserForId'](_0x2fbbd9['eventId']);if(_0xc2bc5d)return this['user']=_0xc2bc5d,super['onAuthEvent'](_0x2fbbd9);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0x364ad6,_0x14b1c2){const _0x4d3673=Ap(_0x14b1c2),_0x3578a4=Rp(_0x364ad6);if(!await _0x3578a4['_isAvailable']())return!0x1;const _0x3ac4e7=await _0x3578a4['_get'](_0x4d3673)==='true';return await _0x3578a4['_remove'](_0x4d3673),_0x3ac4e7;}function bp(_0x240e19,_0x1609df){hn['set'](_0x240e19['_key'](),_0x1609df);}function Rp(_0x20d7bc){return ie(_0x20d7bc['_redirectPersistence']);}function Ap(_0x2329f7){return ln(Cp,_0x2329f7['config']['apiKey'],_0x2329f7['name']);}async function kp(_0x2c5508,_0x2019a5,_0x2edf4c=!0x1){if($(_0x2c5508['app']))return Promise['reject'](re(_0x2c5508));const _0x5a64cc=Ke(_0x2c5508),_0x1db6e9=yp(_0x5a64cc,_0x2019a5),_0x378fea=await new Tp(_0x5a64cc,_0x1db6e9,_0x2edf4c)['execute']();return _0x378fea&&!_0x2edf4c&&(delete _0x378fea['user']['_redirectEventId'],await _0x5a64cc['_persistUserIfCurrent'](_0x378fea['user']),await _0x5a64cc['_setRedirectUser'](null,_0x2019a5)),_0x378fea;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x6ad2b){this['auth']=_0x6ad2b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x14bb38){this['consumers']['add'](_0x14bb38),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x14bb38)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x14bb38),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3659cd){this['consumers']['delete'](_0x3659cd);}['onEvent'](_0xd7898f){if(this['hasEventBeenHandled'](_0xd7898f))return!0x1;let _0xd9a525=!0x1;return this['consumers']['forEach'](_0x3b0435=>{this['isEventForConsumer'](_0xd7898f,_0x3b0435)&&(_0xd9a525=!0x0,this['sendToConsumer'](_0xd7898f,_0x3b0435),this['saveEventToCache'](_0xd7898f));}),this['hasHandledPotentialRedirect']||!Op(_0xd7898f)||(this['hasHandledPotentialRedirect']=!0x0,_0xd9a525||(this['queuedRedirectEvent']=_0xd7898f,_0xd9a525=!0x0)),_0xd9a525;}['sendToConsumer'](_0x1c0150,_0x320c38){var _0xd7e46a;if(_0x1c0150['error']&&!Za(_0x1c0150)){const _0x5a9c14=((_0xd7e46a=_0x1c0150['error']['code'])==null?void 0x0:_0xd7e46a['split']('auth/')[0x1])||'internal-error';_0x320c38['onError'](X(this['auth'],_0x5a9c14));}else _0x320c38['onAuthEvent'](_0x1c0150);}['isEventForConsumer'](_0x24f557,_0x1e2c47){const _0x588e87=_0x1e2c47['eventId']===null||!!_0x24f557['eventId']&&_0x24f557['eventId']===_0x1e2c47['eventId'];return _0x1e2c47['filter']['includes'](_0x24f557['type'])&&_0x588e87;}['hasEventBeenHandled'](_0x289543){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x289543));}['saveEventToCache'](_0x19fa77){this['cachedEventUids']['add'](Mr(_0x19fa77)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2d0aa7){return[_0x2d0aa7['type'],_0x2d0aa7['eventId'],_0x2d0aa7['sessionId'],_0x2d0aa7['tenantId']]['filter'](_0x107bef=>_0x107bef)['join']('-');}function Za({type:_0x5f36b1,error:_0xcd055e}){return _0x5f36b1==='unknown'&&(_0xcd055e==null?void 0x0:_0xcd055e['code'])==='auth/no-auth-event';}function Op(_0x163c6c){switch(_0x163c6c['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x163c6c);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x1f9a40,_0x511cd9={}){return ke(_0x1f9a40,'GET','/v1/projects',_0x511cd9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x2154e1){if(_0x2154e1['config']['emulator'])return;const {authorizedDomains:_0x14e267}=await Dp(_0x2154e1);for(const _0x2f9063 of _0x14e267)try{if(Fp(_0x2f9063))return;}catch{}Y(_0x2154e1,'unauthorized-domain');}function Fp(_0x4b3940){const _0x2d20e1=Mi(),{protocol:_0x52f50c,hostname:_0x1512b6}=new URL(_0x2d20e1);if(_0x4b3940['startsWith']('chrome-extension://')){const _0x1281c5=new URL(_0x4b3940);return _0x1281c5['hostname']===''&&_0x1512b6===''?_0x52f50c==='chrome-extension:'&&_0x4b3940['replace']('chrome-extension://','')===_0x2d20e1['replace']('chrome-extension://',''):_0x52f50c==='chrome-extension:'&&_0x1281c5['hostname']===_0x1512b6;}if(!Lp['test'](_0x52f50c))return!0x1;if(Mp['test'](_0x4b3940))return _0x1512b6===_0x4b3940;const _0xdced8b=_0x4b3940['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xdced8b+'|'+_0xdced8b+')$','i')['test'](_0x1512b6);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0x1dd144=Z()['___jsl'];if(_0x1dd144!=null&&_0x1dd144['H']){for(const _0x1ba35a of Object['keys'](_0x1dd144['H']))if(_0x1dd144['H'][_0x1ba35a]['r']=_0x1dd144['H'][_0x1ba35a]['r']||[],_0x1dd144['H'][_0x1ba35a]['L']=_0x1dd144['H'][_0x1ba35a]['L']||[],_0x1dd144['H'][_0x1ba35a]['r']=[..._0x1dd144['H'][_0x1ba35a]['L']],_0x1dd144['CP']){for(let _0x17dc78=0x0;_0x17dc78<_0x1dd144['CP']['length'];_0x17dc78++)_0x1dd144['CP'][_0x17dc78]=null;}}}function Wp(_0x241386){return new Promise((_0x2d46d4,_0x4b1808)=>{var _0x61e2db,_0x46462a,_0x503396;function _0x1f8e5c(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2d46d4(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4b1808(X(_0x241386,'network-request-failed'));},'timeout':Up['get']()});}if((_0x46462a=(_0x61e2db=Z()['gapi'])==null?void 0x0:_0x61e2db['iframes'])!=null&&_0x46462a['Iframe'])_0x2d46d4(gapi['iframes']['getContext']());else{if((_0x503396=Z()['gapi'])!=null&&_0x503396['load'])_0x1f8e5c();else{const _0x424e29=Lf('iframefcb');return Z()[_0x424e29]=()=>{gapi['load']?_0x1f8e5c():_0x4b1808(X(_0x241386,'network-request-failed'));},xa(Mf()+'?onload='+_0x424e29)['catch'](_0x4901cf=>_0x4b1808(_0x4901cf));}}})['catch'](_0x31b6c2=>{throw un=null,_0x31b6c2;});}let un=null;function Bp(_0x23a830){return un=un||Wp(_0x23a830),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0x11bcdf){const _0x1633b3=_0x11bcdf['config'];m(_0x1633b3['authDomain'],_0x11bcdf,'auth-domain-config-required');const _0xdcbd45=_0x1633b3['emulator']?Cs(_0x1633b3,$p):'https://'+_0x11bcdf['config']['authDomain']+'/'+Hp,_0x3a2063={'apiKey':_0x1633b3['apiKey'],'appName':_0x11bcdf['name'],'v':dt},_0x4aee71=qp['get'](_0x11bcdf['config']['apiHost']);_0x4aee71&&(_0x3a2063['eid']=_0x4aee71);const _0x3216d5=_0x11bcdf['_getFrameworks']();return _0x3216d5['length']&&(_0x3a2063['fw']=_0x3216d5['join'](',')),_0xdcbd45+'?'+ut(_0x3a2063)['slice'](0x1);}async function jp(_0x4669d8){const _0x54ec37=await Bp(_0x4669d8),_0x594c9e=Z()['gapi'];return m(_0x594c9e,_0x4669d8,'internal-error'),_0x54ec37['open']({'where':document['body'],'url':zp(_0x4669d8),'messageHandlersFilter':_0x594c9e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0x540266=>new Promise(async(_0x3d3006,_0x167420)=>{await _0x540266['restyle']({'setHideOnLeave':!0x1});const _0x2c1a80=X(_0x4669d8,'network-request-failed'),_0x2678c7=Z()['setTimeout'](()=>{_0x167420(_0x2c1a80);},Vp['get']());function _0x1db349(){Z()['clearTimeout'](_0x2678c7),_0x3d3006(_0x540266);}_0x540266['ping'](_0x1db349)['then'](_0x1db349,()=>{_0x167420(_0x2c1a80);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x58012c){this['window']=_0x58012c,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x4c0fbc,_0x583296,_0xe8f1af,_0x4a81b6=Yp,_0x283f96=Qp){const _0x239139=Math['max']((window['screen']['availHeight']-_0x283f96)/0x2,0x0)['toString'](),_0x21ada0=Math['max']((window['screen']['availWidth']-_0x4a81b6)/0x2,0x0)['toString']();let _0x39dab4='';const _0x4270dc={...Kp,'width':_0x4a81b6['toString'](),'height':_0x283f96['toString'](),'top':_0x239139,'left':_0x21ada0},_0x5c96f5=W()['toLowerCase']();_0xe8f1af&&(_0x39dab4=ka(_0x5c96f5)?Jp:_0xe8f1af),Ra(_0x5c96f5)&&(_0x583296=_0x583296||Xp,_0x4270dc['scrollbars']='yes');const _0x7385a6=Object['entries'](_0x4270dc)['reduce']((_0x41bd15,[_0x45e16b,_0x474244])=>''+_0x41bd15+_0x45e16b+'='+_0x474244+',','');if(Sf(_0x5c96f5)&&_0x39dab4!=='_self')return e_(_0x583296||'',_0x39dab4),new xr(null);const _0x28f79f=window['open'](_0x583296||'',_0x39dab4,_0x7385a6);m(_0x28f79f,_0x4c0fbc,'popup-blocked');try{_0x28f79f['focus']();}catch{}return new xr(_0x28f79f);}function e_(_0x5b1e44,_0x1bf65b){const _0x4c430a=document['createElement']('a');_0x4c430a['href']=_0x5b1e44,_0x4c430a['target']=_0x1bf65b;const _0x49ff80=document['createEvent']('MouseEvent');_0x49ff80['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4c430a['dispatchEvent'](_0x49ff80);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0x10e8b7,_0x1abcdf,_0x263765,_0x2b18ad,_0x32b212,_0x296a16){m(_0x10e8b7['config']['authDomain'],_0x10e8b7,'auth-domain-config-required'),m(_0x10e8b7['config']['apiKey'],_0x10e8b7,'invalid-api-key');const _0xc67105={'apiKey':_0x10e8b7['config']['apiKey'],'appName':_0x10e8b7['name'],'authType':_0x263765,'redirectUrl':_0x2b18ad,'v':dt,'eventId':_0x32b212};if(_0x1abcdf instanceof Wa){_0x1abcdf['setDefaultLanguage'](_0x10e8b7['languageCode']),_0xc67105['providerId']=_0x1abcdf['providerId']||'',pn(_0x1abcdf['getCustomParameters']())||(_0xc67105['customParameters']=JSON['stringify'](_0x1abcdf['getCustomParameters']()));for(const [_0x21a537,_0x49279f]of Object['entries']({}))_0xc67105[_0x21a537]=_0x49279f;}if(_0x1abcdf instanceof tn){const _0x14e45e=_0x1abcdf['getScopes']()['filter'](_0x3cbd3a=>_0x3cbd3a!=='');_0x14e45e['length']>0x0&&(_0xc67105['scopes']=_0x14e45e['join'](','));}_0x10e8b7['tenantId']&&(_0xc67105['tid']=_0x10e8b7['tenantId']);const _0x4cef2a=_0xc67105;for(const _0x23745b of Object['keys'](_0x4cef2a))_0x4cef2a[_0x23745b]===void 0x0&&delete _0x4cef2a[_0x23745b];const _0x51c5a2=await _0x10e8b7['_getAppCheckToken'](),_0x57c0dc=_0x51c5a2?'#'+i_+'='+encodeURIComponent(_0x51c5a2):'';return s_(_0x10e8b7)+'?'+ut(_0x4cef2a)['slice'](0x1)+_0x57c0dc;}function s_({config:_0x329aa}){return _0x329aa['emulator']?Cs(_0x329aa,n_):'https://'+_0x329aa['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x4d3d70,_0x53833c,_0x5d9f8b,_0x3011d3){var _0x584be2;ce((_0x584be2=this['eventManagers'][_0x4d3d70['_key']()])==null?void 0x0:_0x584be2['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x17e86b=await Fr(_0x4d3d70,_0x53833c,_0x5d9f8b,Mi(),_0x3011d3);return Zp(_0x4d3d70,_0x17e86b,As());}async['_openRedirect'](_0x1d4640,_0x2fbf36,_0x513ee8,_0x5df6e4){await this['_originValidation'](_0x1d4640);const _0x286de7=await Fr(_0x1d4640,_0x2fbf36,_0x513ee8,Mi(),_0x5df6e4);return cp(_0x286de7),new Promise(()=>{});}['_initialize'](_0x3476cc){const _0x1cf633=_0x3476cc['_key']();if(this['eventManagers'][_0x1cf633]){const {manager:_0x296043,promise:_0x2c5791}=this['eventManagers'][_0x1cf633];return _0x296043?Promise['resolve'](_0x296043):(ce(_0x2c5791,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2c5791);}const _0x5e58dc=this['initAndGetManager'](_0x3476cc);return this['eventManagers'][_0x1cf633]={'promise':_0x5e58dc},_0x5e58dc['catch'](()=>{delete this['eventManagers'][_0x1cf633];}),_0x5e58dc;}async['initAndGetManager'](_0x3066ec){const _0x365d3e=await jp(_0x3066ec),_0x1abf09=new Pp(_0x3066ec);return _0x365d3e['register']('authEvent',_0x464851=>(m(_0x464851==null?void 0x0:_0x464851['authEvent'],_0x3066ec,'invalid-auth-event'),{'status':_0x1abf09['onEvent'](_0x464851['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3066ec['_key']()]={'manager':_0x1abf09},this['iframes'][_0x3066ec['_key']()]=_0x365d3e,_0x1abf09;}['_isIframeWebStorageSupported'](_0x1f8cab,_0x9aaa06){this['iframes'][_0x1f8cab['_key']()]['send'](pi,{'type':pi},_0x213d8b=>{var _0x3679e9;const _0x5afa62=(_0x3679e9=_0x213d8b==null?void 0x0:_0x213d8b[0x0])==null?void 0x0:_0x3679e9[pi];_0x5afa62!==void 0x0&&_0x9aaa06(!!_0x5afa62),Y(_0x1f8cab,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x30afad){const _0x167b9b=_0x30afad['_key']();return this['originValidationPromises'][_0x167b9b]||(this['originValidationPromises'][_0x167b9b]=xp(_0x30afad)),this['originValidationPromises'][_0x167b9b];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0x32fac2){this['auth']=_0x32fac2,this['internalListeners']=new Map();}['getUid'](){var _0x5bb1b5;return this['assertAuthConfigured'](),((_0x5bb1b5=this['auth']['currentUser'])==null?void 0x0:_0x5bb1b5['uid'])||null;}async['getToken'](_0x7d4d4d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x7d4d4d)}:null;}['addAuthTokenListener'](_0x558d53){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x558d53))return;const _0x20a139=this['auth']['onIdTokenChanged'](_0x536b97=>{_0x558d53((_0x536b97==null?void 0x0:_0x536b97['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x558d53,_0x20a139),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xcc7da2){this['assertAuthConfigured']();const _0x30e16b=this['internalListeners']['get'](_0xcc7da2);_0x30e16b&&(this['internalListeners']['delete'](_0xcc7da2),_0x30e16b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x43f0ca){switch(_0x43f0ca){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x46af3d){st(new xe('auth',(_0x392b95,{options:_0x2d7165})=>{const _0x4c3ce2=_0x392b95['getProvider']('app')['getImmediate'](),_0x1db932=_0x392b95['getProvider']('heartbeat'),_0x2e51fc=_0x392b95['getProvider']('app-check-internal'),{apiKey:_0x3a99de,authDomain:_0x4aaf6b}=_0x4c3ce2['options'];m(_0x3a99de&&!_0x3a99de['includes'](':'),'invalid-api-key',{'appName':_0x4c3ce2['name']});const _0x15c9c9={'apiKey':_0x3a99de,'authDomain':_0x4aaf6b,'clientPlatform':_0x46af3d,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x46af3d)},_0x4c0233=new Pf(_0x4c3ce2,_0x1db932,_0x2e51fc,_0x15c9c9);return Bf(_0x4c0233,_0x2d7165),_0x4c0233;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x59d1c4,_0x30fdff,_0x4cdd11)=>{_0x59d1c4['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x476611=>{const _0x591e62=Ke(_0x476611['getProvider']('auth')['getImmediate']());return(_0x198746=>new a_(_0x198746))(_0x591e62);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x46af3d)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x3f9f11=>async _0xb032af=>{const _0xa664b4=_0xb032af&&await _0xb032af['getIdTokenResult'](),_0x4182b1=_0xa664b4&&(new Date()['getTime']()-Date['parse'](_0xa664b4['issuedAtTime']))/0x3e8;if(_0x4182b1&&_0x4182b1>u_)return;const _0x1f06f3=_0xa664b4==null?void 0x0:_0xa664b4['token'];Br!==_0x1f06f3&&(Br=_0x1f06f3,await fetch(_0x3f9f11,{'method':_0x1f06f3?'POST':'DELETE','headers':_0x1f06f3?{'Authorization':'Bearer\x20'+_0x1f06f3}:{}}));};function F_(_0x4187c6=Zr()){const _0x283832=Hi(_0x4187c6,'auth');if(_0x283832['isInitialized']())return _0x283832['getImmediate']();const _0x47b97b=Wf(_0x4187c6,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0x1c7ff2=jr('authTokenSyncURL');if(_0x1c7ff2&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x48418e=new URL(_0x1c7ff2,location['origin']);if(location['origin']===_0x48418e['origin']){const _0x2b1051=d_(_0x48418e['toString']());np(_0x47b97b,_0x2b1051,()=>_0x2b1051(_0x47b97b['currentUser'])),tp(_0x47b97b,_0x1e191f=>_0x2b1051(_0x1e191f));}}const _0x387b96=qr('auth');return _0x387b96&&Vf(_0x47b97b,'http://'+_0x387b96),_0x47b97b;}function f_(){var _0x5ca426;return((_0x5ca426=document['getElementsByTagName']('head'))==null?void 0x0:_0x5ca426[0x0])??document;}Of({'loadJS'(_0x290adf){return new Promise((_0xcaa97f,_0x28e347)=>{const _0x4db239=document['createElement']('script');_0x4db239['setAttribute']('src',_0x290adf),_0x4db239['onload']=_0xcaa97f,_0x4db239['onerror']=_0xc738bb=>{const _0x15ac87=X('internal-error');_0x15ac87['customData']=_0xc738bb,_0x28e347(_0x15ac87);},_0x4db239['type']='text/javascript',_0x4db239['charset']='UTF-8',f_()['appendChild'](_0x4db239);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{x_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,__ as h,Sl as i,Vd as j,N_ as k,$d as l,A_ as m,L_ as n,m_ as o,k_ as p,b_ as q,g_ as r,M_ as s,C_ as t,v_ as u,S_ as v,Bt as w,y_ as x,P_ as y,O_ as z};