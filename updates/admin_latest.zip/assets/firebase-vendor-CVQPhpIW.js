const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3c92cb,_0x560543){if(!_0x3c92cb)throw ht(_0x560543);},ht=function(_0x1e38ce){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1e38ce);},Hr=function(_0x5bdfdf){const _0x734bac=[];let _0x4438f2=0x0;for(let _0x5224fb=0x0;_0x5224fb<_0x5bdfdf['length'];_0x5224fb++){let _0x3fb0de=_0x5bdfdf['charCodeAt'](_0x5224fb);_0x3fb0de<0x80?_0x734bac[_0x4438f2++]=_0x3fb0de:_0x3fb0de<0x800?(_0x734bac[_0x4438f2++]=_0x3fb0de>>0x6|0xc0,_0x734bac[_0x4438f2++]=_0x3fb0de&0x3f|0x80):(_0x3fb0de&0xfc00)===0xd800&&_0x5224fb+0x1<_0x5bdfdf['length']&&(_0x5bdfdf['charCodeAt'](_0x5224fb+0x1)&0xfc00)===0xdc00?(_0x3fb0de=0x10000+((_0x3fb0de&0x3ff)<<0xa)+(_0x5bdfdf['charCodeAt'](++_0x5224fb)&0x3ff),_0x734bac[_0x4438f2++]=_0x3fb0de>>0x12|0xf0,_0x734bac[_0x4438f2++]=_0x3fb0de>>0xc&0x3f|0x80,_0x734bac[_0x4438f2++]=_0x3fb0de>>0x6&0x3f|0x80,_0x734bac[_0x4438f2++]=_0x3fb0de&0x3f|0x80):(_0x734bac[_0x4438f2++]=_0x3fb0de>>0xc|0xe0,_0x734bac[_0x4438f2++]=_0x3fb0de>>0x6&0x3f|0x80,_0x734bac[_0x4438f2++]=_0x3fb0de&0x3f|0x80);}return _0x734bac;},nc=function(_0x24ce7a){const _0x16cb92=[];let _0x1f997f=0x0,_0x1ccb2e=0x0;for(;_0x1f997f<_0x24ce7a['length'];){const _0x4e7ae0=_0x24ce7a[_0x1f997f++];if(_0x4e7ae0<0x80)_0x16cb92[_0x1ccb2e++]=String['fromCharCode'](_0x4e7ae0);else{if(_0x4e7ae0>0xbf&&_0x4e7ae0<0xe0){const _0x58c31d=_0x24ce7a[_0x1f997f++];_0x16cb92[_0x1ccb2e++]=String['fromCharCode']((_0x4e7ae0&0x1f)<<0x6|_0x58c31d&0x3f);}else{if(_0x4e7ae0>0xef&&_0x4e7ae0<0x16d){const _0x26c4a1=_0x24ce7a[_0x1f997f++],_0x7991c9=_0x24ce7a[_0x1f997f++],_0xc63bb4=_0x24ce7a[_0x1f997f++],_0x2d0d19=((_0x4e7ae0&0x7)<<0x12|(_0x26c4a1&0x3f)<<0xc|(_0x7991c9&0x3f)<<0x6|_0xc63bb4&0x3f)-0x10000;_0x16cb92[_0x1ccb2e++]=String['fromCharCode'](0xd800+(_0x2d0d19>>0xa)),_0x16cb92[_0x1ccb2e++]=String['fromCharCode'](0xdc00+(_0x2d0d19&0x3ff));}else{const _0xd19db0=_0x24ce7a[_0x1f997f++],_0x294f10=_0x24ce7a[_0x1f997f++];_0x16cb92[_0x1ccb2e++]=String['fromCharCode']((_0x4e7ae0&0xf)<<0xc|(_0xd19db0&0x3f)<<0x6|_0x294f10&0x3f);}}}}return _0x16cb92['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4f5bc8,_0x44b1ef){if(!Array['isArray'](_0x4f5bc8))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x489365=_0x44b1ef?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3f6713=[];for(let _0x51503c=0x0;_0x51503c<_0x4f5bc8['length'];_0x51503c+=0x3){const _0x56c2a9=_0x4f5bc8[_0x51503c],_0x5b9143=_0x51503c+0x1<_0x4f5bc8['length'],_0x573460=_0x5b9143?_0x4f5bc8[_0x51503c+0x1]:0x0,_0x32820f=_0x51503c+0x2<_0x4f5bc8['length'],_0x13dbfe=_0x32820f?_0x4f5bc8[_0x51503c+0x2]:0x0,_0x2f022e=_0x56c2a9>>0x2,_0x25c19a=(_0x56c2a9&0x3)<<0x4|_0x573460>>0x4;let _0xa13708=(_0x573460&0xf)<<0x2|_0x13dbfe>>0x6,_0x3d5c35=_0x13dbfe&0x3f;_0x32820f||(_0x3d5c35=0x40,_0x5b9143||(_0xa13708=0x40)),_0x3f6713['push'](_0x489365[_0x2f022e],_0x489365[_0x25c19a],_0x489365[_0xa13708],_0x489365[_0x3d5c35]);}return _0x3f6713['join']('');},'encodeString'(_0x3be56d,_0x5b8d99){return this['HAS_NATIVE_SUPPORT']&&!_0x5b8d99?btoa(_0x3be56d):this['encodeByteArray'](Hr(_0x3be56d),_0x5b8d99);},'decodeString'(_0x38d19b,_0x2c6f8c){return this['HAS_NATIVE_SUPPORT']&&!_0x2c6f8c?atob(_0x38d19b):nc(this['decodeStringToByteArray'](_0x38d19b,_0x2c6f8c));},'decodeStringToByteArray'(_0x6fc6cd,_0x2743fc){this['init_']();const _0x428116=_0x2743fc?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x23248b=[];for(let _0x33dad5=0x0;_0x33dad5<_0x6fc6cd['length'];){const _0x124625=_0x428116[_0x6fc6cd['charAt'](_0x33dad5++)],_0xa2c780=_0x33dad5<_0x6fc6cd['length']?_0x428116[_0x6fc6cd['charAt'](_0x33dad5)]:0x0;++_0x33dad5;const _0x1583f4=_0x33dad5<_0x6fc6cd['length']?_0x428116[_0x6fc6cd['charAt'](_0x33dad5)]:0x40;++_0x33dad5;const _0x500ba5=_0x33dad5<_0x6fc6cd['length']?_0x428116[_0x6fc6cd['charAt'](_0x33dad5)]:0x40;if(++_0x33dad5,_0x124625==null||_0xa2c780==null||_0x1583f4==null||_0x500ba5==null)throw new ic();const _0x3cb702=_0x124625<<0x2|_0xa2c780>>0x4;if(_0x23248b['push'](_0x3cb702),_0x1583f4!==0x40){const _0x4f010c=_0xa2c780<<0x4&0xf0|_0x1583f4>>0x2;if(_0x23248b['push'](_0x4f010c),_0x500ba5!==0x40){const _0x3e870c=_0x1583f4<<0x6&0xc0|_0x500ba5;_0x23248b['push'](_0x3e870c);}}}return _0x23248b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3db23f=0x0;_0x3db23f<this['ENCODED_VALS']['length'];_0x3db23f++)this['byteToCharMap_'][_0x3db23f]=this['ENCODED_VALS']['charAt'](_0x3db23f),this['charToByteMap_'][this['byteToCharMap_'][_0x3db23f]]=_0x3db23f,this['byteToCharMapWebSafe_'][_0x3db23f]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3db23f),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3db23f]]=_0x3db23f,_0x3db23f>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3db23f)]=_0x3db23f,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3db23f)]=_0x3db23f);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x52e173){const _0x8af099=Hr(_0x52e173);return Fi['encodeByteArray'](_0x8af099,!0x0);},dn=function(_0x33a6f2){return $r(_0x33a6f2)['replace'](/\./g,'');},fn=function(_0x5a2a8c){try{return Fi['decodeString'](_0x5a2a8c,!0x0);}catch(_0x18de63){console['error']('base64Decode\x20failed:\x20',_0x18de63);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x13affe){return Gr(void 0x0,_0x13affe);}function Gr(_0x552e17,_0x58b091){if(!(_0x58b091 instanceof Object))return _0x58b091;switch(_0x58b091['constructor']){case Date:const _0x4703a0=_0x58b091;return new Date(_0x4703a0['getTime']());case Object:_0x552e17===void 0x0&&(_0x552e17={});break;case Array:_0x552e17=[];break;default:return _0x58b091;}for(const _0x36c979 in _0x58b091)!_0x58b091['hasOwnProperty'](_0x36c979)||!rc(_0x36c979)||(_0x552e17[_0x36c979]=Gr(_0x552e17[_0x36c979],_0x58b091[_0x36c979]));return _0x552e17;}function rc(_0x111f51){return _0x111f51!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3ec3c2=Ns['__FIREBASE_DEFAULTS__'];if(_0x3ec3c2)return JSON['parse'](_0x3ec3c2);},lc=()=>{if(typeof document>'u')return;let _0x52f2e1;try{_0x52f2e1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x26f6a4=_0x52f2e1&&fn(_0x52f2e1[0x1]);return _0x26f6a4&&JSON['parse'](_0x26f6a4);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x439ff7){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x439ff7);return;}},qr=_0x4b8e1d=>{var _0x10e49e,_0x41fcb8;return(_0x41fcb8=(_0x10e49e=Ui())==null?void 0x0:_0x10e49e['emulatorHosts'])==null?void 0x0:_0x41fcb8[_0x4b8e1d];},hc=_0x239101=>{const _0x50a35b=qr(_0x239101);if(!_0x50a35b)return;const _0x27c440=_0x50a35b['lastIndexOf'](':');if(_0x27c440<=0x0||_0x27c440+0x1===_0x50a35b['length'])throw new Error('Invalid\x20host\x20'+_0x50a35b+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x129457=parseInt(_0x50a35b['substring'](_0x27c440+0x1),0xa);return _0x50a35b[0x0]==='['?[_0x50a35b['substring'](0x1,_0x27c440-0x1),_0x129457]:[_0x50a35b['substring'](0x0,_0x27c440),_0x129457];},zr=()=>{var _0x3059ec;return(_0x3059ec=Ui())==null?void 0x0:_0x3059ec['config'];},jr=_0x1b50f3=>{var _0x5d4ccb;return(_0x5d4ccb=Ui())==null?void 0x0:_0x5d4ccb['_'+_0x1b50f3];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x8964f,_0x4db17b)=>{this['resolve']=_0x8964f,this['reject']=_0x4db17b;});}['wrapCallback'](_0x1ea33a){return(_0x80d8d3,_0x5cbc4f)=>{_0x80d8d3?this['reject'](_0x80d8d3):this['resolve'](_0x5cbc4f),typeof _0x1ea33a=='function'&&(this['promise']['catch'](()=>{}),_0x1ea33a['length']===0x1?_0x1ea33a(_0x80d8d3):_0x1ea33a(_0x80d8d3,_0x5cbc4f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x19cba4,_0x5aebfb){if(_0x19cba4['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x53e5db={'alg':'none','type':'JWT'},_0x132875=_0x5aebfb||'demo-project',_0x26cb2b=_0x19cba4['iat']||0x0,_0x3c9a84=_0x19cba4['sub']||_0x19cba4['user_id'];if(!_0x3c9a84)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x20602f={'iss':'https://securetoken.google.com/'+_0x132875,'aud':_0x132875,'iat':_0x26cb2b,'exp':_0x26cb2b+0xe10,'auth_time':_0x26cb2b,'sub':_0x3c9a84,'user_id':_0x3c9a84,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x19cba4};return[dn(JSON['stringify'](_0x53e5db)),dn(JSON['stringify'](_0x20602f)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x48f325=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x48f325=='object'&&_0x48f325['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2219d5=W();return _0x2219d5['indexOf']('MSIE\x20')>=0x0||_0x2219d5['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x4baeea,_0xb477dd)=>{try{let _0x238c05=!0x0;const _0x57dc22='validate-browser-context-for-indexeddb-analytics-module',_0x38558e=self['indexedDB']['open'](_0x57dc22);_0x38558e['onsuccess']=()=>{_0x38558e['result']['close'](),_0x238c05||self['indexedDB']['deleteDatabase'](_0x57dc22),_0x4baeea(!0x0);},_0x38558e['onupgradeneeded']=()=>{_0x238c05=!0x1;},_0x38558e['onerror']=()=>{var _0x3aa080;_0xb477dd(((_0x3aa080=_0x38558e['error'])==null?void 0x0:_0x3aa080['message'])||'');};}catch(_0x334ce0){_0xb477dd(_0x334ce0);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x179d64,_0x2cb38c,_0x5c63ee){super(_0x2cb38c),this['code']=_0x179d64,this['customData']=_0x5c63ee,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0xe36dbf,_0x44f9b7,_0x401675){this['service']=_0xe36dbf,this['serviceName']=_0x44f9b7,this['errors']=_0x401675;}['create'](_0x29ba36,..._0x54e508){const _0x5abb75=_0x54e508[0x0]||{},_0x4e33ee=this['service']+'/'+_0x29ba36,_0x40aaa6=this['errors'][_0x29ba36],_0x3a4e8b=_0x40aaa6?vc(_0x40aaa6,_0x5abb75):'Error',_0x3b8566=this['serviceName']+':\x20'+_0x3a4e8b+'\x20('+_0x4e33ee+').';return new Re(_0x4e33ee,_0x3b8566,_0x5abb75);}}function vc(_0x223acc,_0x6feac3){return _0x223acc['replace'](Ec,(_0x48aabf,_0x4946cb)=>{const _0x2aca11=_0x6feac3[_0x4946cb];return _0x2aca11!=null?String(_0x2aca11):'<'+_0x4946cb+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x1e0b92){return JSON['parse'](_0x1e0b92);}function O(_0x3691d1){return JSON['stringify'](_0x3691d1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x512710){let _0x37a34c={},_0x34cc06={},_0x1d9b6d={},_0x15792d='';try{const _0x228e51=_0x512710['split']('.');_0x37a34c=Nt(fn(_0x228e51[0x0])||''),_0x34cc06=Nt(fn(_0x228e51[0x1])||''),_0x15792d=_0x228e51[0x2],_0x1d9b6d=_0x34cc06['d']||{},delete _0x34cc06['d'];}catch{}return{'header':_0x37a34c,'claims':_0x34cc06,'data':_0x1d9b6d,'signature':_0x15792d};},Ic=function(_0x2ae75b){const _0x46bd24=Yr(_0x2ae75b),_0xd96e40=_0x46bd24['claims'];return!!_0xd96e40&&typeof _0xd96e40=='object'&&_0xd96e40['hasOwnProperty']('iat');},wc=function(_0x51f447){const _0x4dde3f=Yr(_0x51f447)['claims'];return typeof _0x4dde3f=='object'&&_0x4dde3f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x13db1c,_0x459ef5){return Object['prototype']['hasOwnProperty']['call'](_0x13db1c,_0x459ef5);}function Me(_0x4e684d,_0x2cbb91){if(Object['prototype']['hasOwnProperty']['call'](_0x4e684d,_0x2cbb91))return _0x4e684d[_0x2cbb91];}function pn(_0xb50f38){for(const _0x1af320 in _0xb50f38)if(Object['prototype']['hasOwnProperty']['call'](_0xb50f38,_0x1af320))return!0x1;return!0x0;}function _n(_0x5ab410,_0x574a47,_0x3a1d89){const _0x2880ee={};for(const _0x49a747 in _0x5ab410)Object['prototype']['hasOwnProperty']['call'](_0x5ab410,_0x49a747)&&(_0x2880ee[_0x49a747]=_0x574a47['call'](_0x3a1d89,_0x5ab410[_0x49a747],_0x49a747,_0x5ab410));return _0x2880ee;}function Le(_0xf98e94,_0x12026c){if(_0xf98e94===_0x12026c)return!0x0;const _0x386393=Object['keys'](_0xf98e94),_0x428ba4=Object['keys'](_0x12026c);for(const _0xa31a11 of _0x386393){if(!_0x428ba4['includes'](_0xa31a11))return!0x1;const _0x12d831=_0xf98e94[_0xa31a11],_0x2d77f9=_0x12026c[_0xa31a11];if(Ps(_0x12d831)&&Ps(_0x2d77f9)){if(!Le(_0x12d831,_0x2d77f9))return!0x1;}else{if(_0x12d831!==_0x2d77f9)return!0x1;}}for(const _0x169633 of _0x428ba4)if(!_0x386393['includes'](_0x169633))return!0x1;return!0x0;}function Ps(_0xc20bd8){return _0xc20bd8!==null&&typeof _0xc20bd8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x2c1e4e){const _0x25b11d=[];for(const [_0x55a603,_0x126691]of Object['entries'](_0x2c1e4e))Array['isArray'](_0x126691)?_0x126691['forEach'](_0x30e097=>{_0x25b11d['push'](encodeURIComponent(_0x55a603)+'='+encodeURIComponent(_0x30e097));}):_0x25b11d['push'](encodeURIComponent(_0x55a603)+'='+encodeURIComponent(_0x126691));return _0x25b11d['length']?'&'+_0x25b11d['join']('&'):'';}function wt(_0x28f9b8){const _0x3a90dd={};return _0x28f9b8['replace'](/^\?/,'')['split']('&')['forEach'](_0x4771d0=>{if(_0x4771d0){const [_0x329780,_0x45c0ef]=_0x4771d0['split']('=');_0x3a90dd[decodeURIComponent(_0x329780)]=decodeURIComponent(_0x45c0ef);}}),_0x3a90dd;}function Ct(_0xee0370){const _0xb53a30=_0xee0370['indexOf']('?');if(!_0xb53a30)return'';const _0x223a47=_0xee0370['indexOf']('#',_0xb53a30);return _0xee0370['substring'](_0xb53a30,_0x223a47>0x0?_0x223a47:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x27bd26=0x1;_0x27bd26<this['blockSize'];++_0x27bd26)this['pad_'][_0x27bd26]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x24a798,_0x5888db){_0x5888db||(_0x5888db=0x0);const _0x3c5af6=this['W_'];if(typeof _0x24a798=='string'){for(let _0x4fe59f=0x0;_0x4fe59f<0x10;_0x4fe59f++)_0x3c5af6[_0x4fe59f]=_0x24a798['charCodeAt'](_0x5888db)<<0x18|_0x24a798['charCodeAt'](_0x5888db+0x1)<<0x10|_0x24a798['charCodeAt'](_0x5888db+0x2)<<0x8|_0x24a798['charCodeAt'](_0x5888db+0x3),_0x5888db+=0x4;}else{for(let _0x3c7001=0x0;_0x3c7001<0x10;_0x3c7001++)_0x3c5af6[_0x3c7001]=_0x24a798[_0x5888db]<<0x18|_0x24a798[_0x5888db+0x1]<<0x10|_0x24a798[_0x5888db+0x2]<<0x8|_0x24a798[_0x5888db+0x3],_0x5888db+=0x4;}for(let _0x1b80d5=0x10;_0x1b80d5<0x50;_0x1b80d5++){const _0x96d379=_0x3c5af6[_0x1b80d5-0x3]^_0x3c5af6[_0x1b80d5-0x8]^_0x3c5af6[_0x1b80d5-0xe]^_0x3c5af6[_0x1b80d5-0x10];_0x3c5af6[_0x1b80d5]=(_0x96d379<<0x1|_0x96d379>>>0x1f)&0xffffffff;}let _0x95c9b7=this['chain_'][0x0],_0x3a878a=this['chain_'][0x1],_0x32e4d8=this['chain_'][0x2],_0x38fca0=this['chain_'][0x3],_0x44a8a5=this['chain_'][0x4],_0x2b5a02,_0x509f95;for(let _0x2d3157=0x0;_0x2d3157<0x50;_0x2d3157++){_0x2d3157<0x28?_0x2d3157<0x14?(_0x2b5a02=_0x38fca0^_0x3a878a&(_0x32e4d8^_0x38fca0),_0x509f95=0x5a827999):(_0x2b5a02=_0x3a878a^_0x32e4d8^_0x38fca0,_0x509f95=0x6ed9eba1):_0x2d3157<0x3c?(_0x2b5a02=_0x3a878a&_0x32e4d8|_0x38fca0&(_0x3a878a|_0x32e4d8),_0x509f95=0x8f1bbcdc):(_0x2b5a02=_0x3a878a^_0x32e4d8^_0x38fca0,_0x509f95=0xca62c1d6);const _0x1bd9f0=(_0x95c9b7<<0x5|_0x95c9b7>>>0x1b)+_0x2b5a02+_0x44a8a5+_0x509f95+_0x3c5af6[_0x2d3157]&0xffffffff;_0x44a8a5=_0x38fca0,_0x38fca0=_0x32e4d8,_0x32e4d8=(_0x3a878a<<0x1e|_0x3a878a>>>0x2)&0xffffffff,_0x3a878a=_0x95c9b7,_0x95c9b7=_0x1bd9f0;}this['chain_'][0x0]=this['chain_'][0x0]+_0x95c9b7&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3a878a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x32e4d8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x38fca0&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x44a8a5&0xffffffff;}['update'](_0x383c73,_0x1fe4fa){if(_0x383c73==null)return;_0x1fe4fa===void 0x0&&(_0x1fe4fa=_0x383c73['length']);const _0x3f4bd8=_0x1fe4fa-this['blockSize'];let _0x758ab=0x0;const _0x176e1c=this['buf_'];let _0x2cc604=this['inbuf_'];for(;_0x758ab<_0x1fe4fa;){if(_0x2cc604===0x0){for(;_0x758ab<=_0x3f4bd8;)this['compress_'](_0x383c73,_0x758ab),_0x758ab+=this['blockSize'];}if(typeof _0x383c73=='string'){for(;_0x758ab<_0x1fe4fa;)if(_0x176e1c[_0x2cc604]=_0x383c73['charCodeAt'](_0x758ab),++_0x2cc604,++_0x758ab,_0x2cc604===this['blockSize']){this['compress_'](_0x176e1c),_0x2cc604=0x0;break;}}else{for(;_0x758ab<_0x1fe4fa;)if(_0x176e1c[_0x2cc604]=_0x383c73[_0x758ab],++_0x2cc604,++_0x758ab,_0x2cc604===this['blockSize']){this['compress_'](_0x176e1c),_0x2cc604=0x0;break;}}}this['inbuf_']=_0x2cc604,this['total_']+=_0x1fe4fa;}['digest'](){const _0x469599=[];let _0x1e92c3=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xe15eda=this['blockSize']-0x1;_0xe15eda>=0x38;_0xe15eda--)this['buf_'][_0xe15eda]=_0x1e92c3&0xff,_0x1e92c3/=0x100;this['compress_'](this['buf_']);let _0x5ccc44=0x0;for(let _0x170780=0x0;_0x170780<0x5;_0x170780++)for(let _0x734a5e=0x18;_0x734a5e>=0x0;_0x734a5e-=0x8)_0x469599[_0x5ccc44]=this['chain_'][_0x170780]>>_0x734a5e&0xff,++_0x5ccc44;return _0x469599;}}function Tc(_0xef79d4,_0x392519){const _0x5e36ab=new Sc(_0xef79d4,_0x392519);return _0x5e36ab['subscribe']['bind'](_0x5e36ab);}class Sc{constructor(_0x393c1e,_0x2709f8){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2709f8,this['task']['then'](()=>{_0x393c1e(this);})['catch'](_0x174a8f=>{this['error'](_0x174a8f);});}['next'](_0x354c17){this['forEachObserver'](_0x4ee35e=>{_0x4ee35e['next'](_0x354c17);});}['error'](_0x1aa092){this['forEachObserver'](_0x9c87ef=>{_0x9c87ef['error'](_0x1aa092);}),this['close'](_0x1aa092);}['complete'](){this['forEachObserver'](_0x37c857=>{_0x37c857['complete']();}),this['close']();}['subscribe'](_0x27c055,_0x35978e,_0x3c237b){let _0x19f2a4;if(_0x27c055===void 0x0&&_0x35978e===void 0x0&&_0x3c237b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x27c055,['next','error','complete'])?_0x19f2a4=_0x27c055:_0x19f2a4={'next':_0x27c055,'error':_0x35978e,'complete':_0x3c237b},_0x19f2a4['next']===void 0x0&&(_0x19f2a4['next']=ti),_0x19f2a4['error']===void 0x0&&(_0x19f2a4['error']=ti),_0x19f2a4['complete']===void 0x0&&(_0x19f2a4['complete']=ti);const _0x1f2c2e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x19f2a4['error'](this['finalError']):_0x19f2a4['complete']();}catch{}}),this['observers']['push'](_0x19f2a4),_0x1f2c2e;}['unsubscribeOne'](_0x285f53){this['observers']===void 0x0||this['observers'][_0x285f53]===void 0x0||(delete this['observers'][_0x285f53],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xf6cbe3){if(!this['finalized']){for(let _0x519e8b=0x0;_0x519e8b<this['observers']['length'];_0x519e8b++)this['sendOne'](_0x519e8b,_0xf6cbe3);}}['sendOne'](_0x52040e,_0x148b1b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x52040e]!==void 0x0)try{_0x148b1b(this['observers'][_0x52040e]);}catch(_0x35ae4d){typeof console<'u'&&console['error']&&console['error'](_0x35ae4d);}});}['close'](_0x1aa3fc){this['finalized']||(this['finalized']=!0x0,_0x1aa3fc!==void 0x0&&(this['finalError']=_0x1aa3fc),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1257b8,_0x31698b){if(typeof _0x1257b8!='object'||_0x1257b8===null)return!0x1;for(const _0x3b7493 of _0x31698b)if(_0x3b7493 in _0x1257b8&&typeof _0x1257b8[_0x3b7493]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x14391d,_0x2a8cfe){return _0x14391d+'\x20failed:\x20'+_0x2a8cfe+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x1cebff){const _0x6cf963=[];let _0x2f2716=0x0;for(let _0x404f4f=0x0;_0x404f4f<_0x1cebff['length'];_0x404f4f++){let _0x38008b=_0x1cebff['charCodeAt'](_0x404f4f);if(_0x38008b>=0xd800&&_0x38008b<=0xdbff){const _0x203f32=_0x38008b-0xd800;_0x404f4f++,f(_0x404f4f<_0x1cebff['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1a90d2=_0x1cebff['charCodeAt'](_0x404f4f)-0xdc00;_0x38008b=0x10000+(_0x203f32<<0xa)+_0x1a90d2;}_0x38008b<0x80?_0x6cf963[_0x2f2716++]=_0x38008b:_0x38008b<0x800?(_0x6cf963[_0x2f2716++]=_0x38008b>>0x6|0xc0,_0x6cf963[_0x2f2716++]=_0x38008b&0x3f|0x80):_0x38008b<0x10000?(_0x6cf963[_0x2f2716++]=_0x38008b>>0xc|0xe0,_0x6cf963[_0x2f2716++]=_0x38008b>>0x6&0x3f|0x80,_0x6cf963[_0x2f2716++]=_0x38008b&0x3f|0x80):(_0x6cf963[_0x2f2716++]=_0x38008b>>0x12|0xf0,_0x6cf963[_0x2f2716++]=_0x38008b>>0xc&0x3f|0x80,_0x6cf963[_0x2f2716++]=_0x38008b>>0x6&0x3f|0x80,_0x6cf963[_0x2f2716++]=_0x38008b&0x3f|0x80);}return _0x6cf963;},Ln=function(_0x487831){let _0x3a8438=0x0;for(let _0x500b1d=0x0;_0x500b1d<_0x487831['length'];_0x500b1d++){const _0x5d704b=_0x487831['charCodeAt'](_0x500b1d);_0x5d704b<0x80?_0x3a8438++:_0x5d704b<0x800?_0x3a8438+=0x2:_0x5d704b>=0xd800&&_0x5d704b<=0xdbff?(_0x3a8438+=0x4,_0x500b1d++):_0x3a8438+=0x3;}return _0x3a8438;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0xa17f3f){return _0xa17f3f&&_0xa17f3f['_delegate']?_0xa17f3f['_delegate']:_0xa17f3f;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x59c3a1){try{return(_0x59c3a1['startsWith']('http://')||_0x59c3a1['startsWith']('https://')?new URL(_0x59c3a1)['hostname']:_0x59c3a1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x1616a8){return(await fetch(_0x1616a8,{'credentials':'include'}))['ok'];}class xe{constructor(_0x508bc2,_0x337109,_0x239375){this['name']=_0x508bc2,this['instanceFactory']=_0x337109,this['type']=_0x239375,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x45a1e5){return this['instantiationMode']=_0x45a1e5,this;}['setMultipleInstances'](_0x473cdd){return this['multipleInstances']=_0x473cdd,this;}['setServiceProps'](_0x51ace5){return this['serviceProps']=_0x51ace5,this;}['setInstanceCreatedCallback'](_0x48347e){return this['onInstanceCreated']=_0x48347e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xe4d13,_0x163035){this['name']=_0xe4d13,this['container']=_0x163035,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4ff8d3){const _0x1c21dc=this['normalizeInstanceIdentifier'](_0x4ff8d3);if(!this['instancesDeferred']['has'](_0x1c21dc)){const _0x1ed8c7=new H();if(this['instancesDeferred']['set'](_0x1c21dc,_0x1ed8c7),this['isInitialized'](_0x1c21dc)||this['shouldAutoInitialize']())try{const _0x44b0aa=this['getOrInitializeService']({'instanceIdentifier':_0x1c21dc});_0x44b0aa&&_0x1ed8c7['resolve'](_0x44b0aa);}catch{}}return this['instancesDeferred']['get'](_0x1c21dc)['promise'];}['getImmediate'](_0x5a6465){const _0x15a416=this['normalizeInstanceIdentifier'](_0x5a6465==null?void 0x0:_0x5a6465['identifier']),_0x18bb3e=(_0x5a6465==null?void 0x0:_0x5a6465['optional'])??!0x1;if(this['isInitialized'](_0x15a416)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x15a416});}catch(_0x460dd6){if(_0x18bb3e)return null;throw _0x460dd6;}else{if(_0x18bb3e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x53f1d5){if(_0x53f1d5['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x53f1d5['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x53f1d5,!!this['shouldAutoInitialize']()){if(Nc(_0x53f1d5))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x55bb4f,_0x1b8f0a]of this['instancesDeferred']['entries']()){const _0x438899=this['normalizeInstanceIdentifier'](_0x55bb4f);try{const _0x146731=this['getOrInitializeService']({'instanceIdentifier':_0x438899});_0x1b8f0a['resolve'](_0x146731);}catch{}}}}['clearInstance'](_0x3cd9b9=Ne){this['instancesDeferred']['delete'](_0x3cd9b9),this['instancesOptions']['delete'](_0x3cd9b9),this['instances']['delete'](_0x3cd9b9);}async['delete'](){const _0x37f329=Array['from'](this['instances']['values']());await Promise['all']([..._0x37f329['filter'](_0xcb31c=>'INTERNAL'in _0xcb31c)['map'](_0x13090e=>_0x13090e['INTERNAL']['delete']()),..._0x37f329['filter'](_0xdc70f5=>'_delete'in _0xdc70f5)['map'](_0x5166db=>_0x5166db['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1e19b3=Ne){return this['instances']['has'](_0x1e19b3);}['getOptions'](_0x2abbdc=Ne){return this['instancesOptions']['get'](_0x2abbdc)||{};}['initialize'](_0x243487={}){const {options:_0x3df934={}}=_0x243487,_0x4b9460=this['normalizeInstanceIdentifier'](_0x243487['instanceIdentifier']);if(this['isInitialized'](_0x4b9460))throw Error(this['name']+'('+_0x4b9460+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x102b67=this['getOrInitializeService']({'instanceIdentifier':_0x4b9460,'options':_0x3df934});for(const [_0x33ad6f,_0x3cf435]of this['instancesDeferred']['entries']()){const _0x178431=this['normalizeInstanceIdentifier'](_0x33ad6f);_0x4b9460===_0x178431&&_0x3cf435['resolve'](_0x102b67);}return _0x102b67;}['onInit'](_0x3e9766,_0x227cba){const _0x1358a5=this['normalizeInstanceIdentifier'](_0x227cba),_0x71eb94=this['onInitCallbacks']['get'](_0x1358a5)??new Set();_0x71eb94['add'](_0x3e9766),this['onInitCallbacks']['set'](_0x1358a5,_0x71eb94);const _0x32ee60=this['instances']['get'](_0x1358a5);return _0x32ee60&&_0x3e9766(_0x32ee60,_0x1358a5),()=>{_0x71eb94['delete'](_0x3e9766);};}['invokeOnInitCallbacks'](_0x43288c,_0x1de83c){const _0x28a09f=this['onInitCallbacks']['get'](_0x1de83c);if(_0x28a09f){for(const _0x7b63d5 of _0x28a09f)try{_0x7b63d5(_0x43288c,_0x1de83c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xb9eb00,options:_0x597f0f={}}){let _0xd90351=this['instances']['get'](_0xb9eb00);if(!_0xd90351&&this['component']&&(_0xd90351=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0xb9eb00),'options':_0x597f0f}),this['instances']['set'](_0xb9eb00,_0xd90351),this['instancesOptions']['set'](_0xb9eb00,_0x597f0f),this['invokeOnInitCallbacks'](_0xd90351,_0xb9eb00),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xb9eb00,_0xd90351);}catch{}return _0xd90351||null;}['normalizeInstanceIdentifier'](_0x3b58ca=Ne){return this['component']?this['component']['multipleInstances']?_0x3b58ca:Ne:_0x3b58ca;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x460568){return _0x460568===Ne?void 0x0:_0x460568;}function Nc(_0x1d1959){return _0x1d1959['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x252faf){this['name']=_0x252faf,this['providers']=new Map();}['addComponent'](_0x543a1b){const _0x245e78=this['getProvider'](_0x543a1b['name']);if(_0x245e78['isComponentSet']())throw new Error('Component\x20'+_0x543a1b['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x245e78['setComponent'](_0x543a1b);}['addOrOverwriteComponent'](_0x3c10bc){this['getProvider'](_0x3c10bc['name'])['isComponentSet']()&&this['providers']['delete'](_0x3c10bc['name']),this['addComponent'](_0x3c10bc);}['getProvider'](_0x17782b){if(this['providers']['has'](_0x17782b))return this['providers']['get'](_0x17782b);const _0x5b0e31=new Ac(_0x17782b,this);return this['providers']['set'](_0x17782b,_0x5b0e31),_0x5b0e31;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x13d011){_0x13d011[_0x13d011['DEBUG']=0x0]='DEBUG',_0x13d011[_0x13d011['VERBOSE']=0x1]='VERBOSE',_0x13d011[_0x13d011['INFO']=0x2]='INFO',_0x13d011[_0x13d011['WARN']=0x3]='WARN',_0x13d011[_0x13d011['ERROR']=0x4]='ERROR',_0x13d011[_0x13d011['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x13d6e5,_0x105281,..._0x53060c)=>{if(_0x105281<_0x13d6e5['logLevel'])return;const _0x4cc1c0=new Date()['toISOString'](),_0x12fe0f=Mc[_0x105281];if(_0x12fe0f)console[_0x12fe0f]('['+_0x4cc1c0+']\x20\x20'+_0x13d6e5['name']+':',..._0x53060c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x105281+')');};class Bi{constructor(_0x1e1bcd){this['name']=_0x1e1bcd,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4c7ad2){if(!(_0x4c7ad2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4c7ad2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4c7ad2;}['setLogLevel'](_0x5c19ca){this['_logLevel']=typeof _0x5c19ca=='string'?Oc[_0x5c19ca]:_0x5c19ca;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x33e1ae){if(typeof _0x33e1ae!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x33e1ae;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5832ec){this['_userLogHandler']=_0x5832ec;}['debug'](..._0x316682){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x316682),this['_logHandler'](this,T['DEBUG'],..._0x316682);}['log'](..._0xadef38){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xadef38),this['_logHandler'](this,T['VERBOSE'],..._0xadef38);}['info'](..._0x187d15){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x187d15),this['_logHandler'](this,T['INFO'],..._0x187d15);}['warn'](..._0x3a5799){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3a5799),this['_logHandler'](this,T['WARN'],..._0x3a5799);}['error'](..._0x58ebbe){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x58ebbe),this['_logHandler'](this,T['ERROR'],..._0x58ebbe);}}const xc=(_0x543519,_0xaee041)=>_0xaee041['some'](_0x11a025=>_0x543519 instanceof _0x11a025);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x47aba9){const _0x54f1e3=new Promise((_0x451dd8,_0x54cd5a)=>{const _0xc7698d=()=>{_0x47aba9['removeEventListener']('success',_0x16be06),_0x47aba9['removeEventListener']('error',_0x533e22);},_0x16be06=()=>{_0x451dd8(ge(_0x47aba9['result'])),_0xc7698d();},_0x533e22=()=>{_0x54cd5a(_0x47aba9['error']),_0xc7698d();};_0x47aba9['addEventListener']('success',_0x16be06),_0x47aba9['addEventListener']('error',_0x533e22);});return _0x54f1e3['then'](_0x1df76b=>{_0x1df76b instanceof IDBCursor&&Jr['set'](_0x1df76b,_0x47aba9);})['catch'](()=>{}),Vi['set'](_0x54f1e3,_0x47aba9),_0x54f1e3;}function Bc(_0x4c54a9){if(_i['has'](_0x4c54a9))return;const _0xcf7148=new Promise((_0x475d85,_0x11fdf9)=>{const _0x1d938e=()=>{_0x4c54a9['removeEventListener']('complete',_0x3c850e),_0x4c54a9['removeEventListener']('error',_0x173cfc),_0x4c54a9['removeEventListener']('abort',_0x173cfc);},_0x3c850e=()=>{_0x475d85(),_0x1d938e();},_0x173cfc=()=>{_0x11fdf9(_0x4c54a9['error']||new DOMException('AbortError','AbortError')),_0x1d938e();};_0x4c54a9['addEventListener']('complete',_0x3c850e),_0x4c54a9['addEventListener']('error',_0x173cfc),_0x4c54a9['addEventListener']('abort',_0x173cfc);});_i['set'](_0x4c54a9,_0xcf7148);}let gi={'get'(_0x16644c,_0x2e40f7,_0x24e50f){if(_0x16644c instanceof IDBTransaction){if(_0x2e40f7==='done')return _i['get'](_0x16644c);if(_0x2e40f7==='objectStoreNames')return _0x16644c['objectStoreNames']||Xr['get'](_0x16644c);if(_0x2e40f7==='store')return _0x24e50f['objectStoreNames'][0x1]?void 0x0:_0x24e50f['objectStore'](_0x24e50f['objectStoreNames'][0x0]);}return ge(_0x16644c[_0x2e40f7]);},'set'(_0x519e54,_0x331025,_0x583fc2){return _0x519e54[_0x331025]=_0x583fc2,!0x0;},'has'(_0x40bfaf,_0x239a0d){return _0x40bfaf instanceof IDBTransaction&&(_0x239a0d==='done'||_0x239a0d==='store')?!0x0:_0x239a0d in _0x40bfaf;}};function Vc(_0xbe33f3){gi=_0xbe33f3(gi);}function Hc(_0x4a9595){return _0x4a9595===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x46c22f,..._0x4f81a0){const _0x593015=_0x4a9595['call'](ii(this),_0x46c22f,..._0x4f81a0);return Xr['set'](_0x593015,_0x46c22f['sort']?_0x46c22f['sort']():[_0x46c22f]),ge(_0x593015);}:Uc()['includes'](_0x4a9595)?function(..._0x686eef){return _0x4a9595['apply'](ii(this),_0x686eef),ge(Jr['get'](this));}:function(..._0x4ce55d){return ge(_0x4a9595['apply'](ii(this),_0x4ce55d));};}function $c(_0x8e7e46){return typeof _0x8e7e46=='function'?Hc(_0x8e7e46):(_0x8e7e46 instanceof IDBTransaction&&Bc(_0x8e7e46),xc(_0x8e7e46,Fc())?new Proxy(_0x8e7e46,gi):_0x8e7e46);}function ge(_0x5ce0f9){if(_0x5ce0f9 instanceof IDBRequest)return Wc(_0x5ce0f9);if(ni['has'](_0x5ce0f9))return ni['get'](_0x5ce0f9);const _0x50bd0c=$c(_0x5ce0f9);return _0x50bd0c!==_0x5ce0f9&&(ni['set'](_0x5ce0f9,_0x50bd0c),Vi['set'](_0x50bd0c,_0x5ce0f9)),_0x50bd0c;}const ii=_0x3ae283=>Vi['get'](_0x3ae283);function Gc(_0x78006a,_0x4330eb,{blocked:_0x1dd4ce,upgrade:_0x198bf5,blocking:_0x31e415,terminated:_0x572d1d}={}){const _0x55c353=indexedDB['open'](_0x78006a,_0x4330eb),_0x6f989d=ge(_0x55c353);return _0x198bf5&&_0x55c353['addEventListener']('upgradeneeded',_0x24f14f=>{_0x198bf5(ge(_0x55c353['result']),_0x24f14f['oldVersion'],_0x24f14f['newVersion'],ge(_0x55c353['transaction']),_0x24f14f);}),_0x1dd4ce&&_0x55c353['addEventListener']('blocked',_0x2deef5=>_0x1dd4ce(_0x2deef5['oldVersion'],_0x2deef5['newVersion'],_0x2deef5)),_0x6f989d['then'](_0x5d076f=>{_0x572d1d&&_0x5d076f['addEventListener']('close',()=>_0x572d1d()),_0x31e415&&_0x5d076f['addEventListener']('versionchange',_0x39a4b6=>_0x31e415(_0x39a4b6['oldVersion'],_0x39a4b6['newVersion'],_0x39a4b6));})['catch'](()=>{}),_0x6f989d;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x3bf2c3,_0x1a19f6){if(!(_0x3bf2c3 instanceof IDBDatabase&&!(_0x1a19f6 in _0x3bf2c3)&&typeof _0x1a19f6=='string'))return;if(si['get'](_0x1a19f6))return si['get'](_0x1a19f6);const _0x461597=_0x1a19f6['replace'](/FromIndex$/,''),_0x2f3da2=_0x1a19f6!==_0x461597,_0xce19c1=zc['includes'](_0x461597);if(!(_0x461597 in(_0x2f3da2?IDBIndex:IDBObjectStore)['prototype'])||!(_0xce19c1||qc['includes'](_0x461597)))return;const _0x45faeb=async function(_0x3d829f,..._0x1e6d58){const _0x313fa0=this['transaction'](_0x3d829f,_0xce19c1?'readwrite':'readonly');let _0x52a163=_0x313fa0['store'];return _0x2f3da2&&(_0x52a163=_0x52a163['index'](_0x1e6d58['shift']())),(await Promise['all']([_0x52a163[_0x461597](..._0x1e6d58),_0xce19c1&&_0x313fa0['done']]))[0x0];};return si['set'](_0x1a19f6,_0x45faeb),_0x45faeb;}Vc(_0x360213=>({..._0x360213,'get':(_0x542995,_0x48767f,_0x46bdb1)=>Ms(_0x542995,_0x48767f)||_0x360213['get'](_0x542995,_0x48767f,_0x46bdb1),'has':(_0x26e0f3,_0x2bd593)=>!!Ms(_0x26e0f3,_0x2bd593)||_0x360213['has'](_0x26e0f3,_0x2bd593)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x36f1ee){this['container']=_0x36f1ee;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3f1ffb=>{if(Kc(_0x3f1ffb)){const _0x548b67=_0x3f1ffb['getImmediate']();return _0x548b67['library']+'/'+_0x548b67['version'];}else return null;})['filter'](_0xdd2a7c=>_0xdd2a7c)['join']('\x20');}}function Kc(_0x82096d){const _0x274e85=_0x82096d['getComponent']();return(_0x274e85==null?void 0x0:_0x274e85['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x3470ce,_0x51d1a4){try{_0x3470ce['container']['addComponent'](_0x51d1a4);}catch(_0x30c336){oe['debug']('Component\x20'+_0x51d1a4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3470ce['name'],_0x30c336);}}function st(_0x39c85d){const _0x5727ee=_0x39c85d['name'];if(Ei['has'](_0x5727ee))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5727ee+'.'),!0x1;Ei['set'](_0x5727ee,_0x39c85d);for(const _0x401012 of Fe['values']())xs(_0x401012,_0x39c85d);for(const _0x231749 of vi['values']())xs(_0x231749,_0x39c85d);return!0x0;}function Hi(_0x291765,_0x10b953){const _0x3a383b=_0x291765['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3a383b&&_0x3a383b['triggerHeartbeat'](),_0x291765['container']['getProvider'](_0x10b953);}function $(_0x1b6f06){return _0x1b6f06==null?!0x1:_0x1b6f06['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x6498d0,_0x476d0f,_0x29df58){this['_isDeleted']=!0x1,this['_options']={..._0x6498d0},this['_config']={..._0x476d0f},this['_name']=_0x476d0f['name'],this['_automaticDataCollectionEnabled']=_0x476d0f['automaticDataCollectionEnabled'],this['_container']=_0x29df58,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x274da4){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x274da4;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0xb0c039){this['_isDeleted']=_0xb0c039;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3fd0e5,_0x189c20={}){let _0x4371c8=_0x3fd0e5;typeof _0x189c20!='object'&&(_0x189c20={'name':_0x189c20});const _0xf5aacd={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x189c20},_0x3d6c4e=_0xf5aacd['name'];if(typeof _0x3d6c4e!='string'||!_0x3d6c4e)throw me['create']('bad-app-name',{'appName':String(_0x3d6c4e)});if(_0x4371c8||(_0x4371c8=zr()),!_0x4371c8)throw me['create']('no-options');const _0x3f42fd=Fe['get'](_0x3d6c4e);if(_0x3f42fd){if(Le(_0x4371c8,_0x3f42fd['options'])&&Le(_0xf5aacd,_0x3f42fd['config']))return _0x3f42fd;throw me['create']('duplicate-app',{'appName':_0x3d6c4e});}const _0x33a1f3=new Pc(_0x3d6c4e);for(const _0x5ac2b0 of Ei['values']())_0x33a1f3['addComponent'](_0x5ac2b0);const _0x4af2d8=new Tl(_0x4371c8,_0xf5aacd,_0x33a1f3);return Fe['set'](_0x3d6c4e,_0x4af2d8),_0x4af2d8;}function Zr(_0x378889=yi){const _0x3fc2d4=Fe['get'](_0x378889);if(!_0x3fc2d4&&_0x378889===yi&&zr())return Sl();if(!_0x3fc2d4)throw me['create']('no-app',{'appName':_0x378889});return _0x3fc2d4;}function p_(){return Array['from'](Fe['values']());}async function __(_0x8b5a1c){let _0x44b324=!0x1;const _0x4e9994=_0x8b5a1c['name'];Fe['has'](_0x4e9994)?(_0x44b324=!0x0,Fe['delete'](_0x4e9994)):vi['has'](_0x4e9994)&&_0x8b5a1c['decRefCount']()<=0x0&&(vi['delete'](_0x4e9994),_0x44b324=!0x0),_0x44b324&&(await Promise['all'](_0x8b5a1c['container']['getProviders']()['map'](_0x4d7360=>_0x4d7360['delete']())),_0x8b5a1c['isDeleted']=!0x0);}function ye(_0x5290b7,_0x16a573,_0x156cee){let _0x49d0f5=wl[_0x5290b7]??_0x5290b7;_0x156cee&&(_0x49d0f5+='-'+_0x156cee);const _0x17219=_0x49d0f5['match'](/\s|\//),_0x588777=_0x16a573['match'](/\s|\//);if(_0x17219||_0x588777){const _0x5f51e9=['Unable\x20to\x20register\x20library\x20\x22'+_0x49d0f5+'\x22\x20with\x20version\x20\x22'+_0x16a573+'\x22:'];_0x17219&&_0x5f51e9['push']('library\x20name\x20\x22'+_0x49d0f5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x17219&&_0x588777&&_0x5f51e9['push']('and'),_0x588777&&_0x5f51e9['push']('version\x20name\x20\x22'+_0x16a573+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5f51e9['join']('\x20'));return;}st(new xe(_0x49d0f5+'-version',()=>({'library':_0x49d0f5,'version':_0x16a573}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3b9da8,_0x4ebed2)=>{switch(_0x4ebed2){case 0x0:try{_0x3b9da8['createObjectStore'](Pt);}catch(_0x2ea4e2){console['warn'](_0x2ea4e2);}}}})['catch'](_0x289605=>{throw me['create']('idb-open',{'originalErrorMessage':_0x289605['message']});})),ri;}async function Al(_0x5bd1a9){try{const _0x16abc6=(await eo())['transaction'](Pt),_0x113e89=await _0x16abc6['objectStore'](Pt)['get'](to(_0x5bd1a9));return await _0x16abc6['done'],_0x113e89;}catch(_0x167e25){if(_0x167e25 instanceof Re)oe['warn'](_0x167e25['message']);else{const _0x5793d8=me['create']('idb-get',{'originalErrorMessage':_0x167e25==null?void 0x0:_0x167e25['message']});oe['warn'](_0x5793d8['message']);}}}async function Fs(_0x4d15cd,_0x15e622){try{const _0x169036=(await eo())['transaction'](Pt,'readwrite');await _0x169036['objectStore'](Pt)['put'](_0x15e622,to(_0x4d15cd)),await _0x169036['done'];}catch(_0x26f65e){if(_0x26f65e instanceof Re)oe['warn'](_0x26f65e['message']);else{const _0x30b24d=me['create']('idb-set',{'originalErrorMessage':_0x26f65e==null?void 0x0:_0x26f65e['message']});oe['warn'](_0x30b24d['message']);}}}function to(_0x1aef62){return _0x1aef62['name']+'!'+_0x1aef62['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x4be703){this['container']=_0x4be703,this['_heartbeatsCache']=null;const _0x25e059=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x25e059),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x185b6d=>(this['_heartbeatsCache']=_0x185b6d,_0x185b6d));}async['triggerHeartbeat'](){var _0x3e674f,_0x2cf769;try{const _0x43b14f=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1ab53f=Us();if(((_0x3e674f=this['_heartbeatsCache'])==null?void 0x0:_0x3e674f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2cf769=this['_heartbeatsCache'])==null?void 0x0:_0x2cf769['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1ab53f||this['_heartbeatsCache']['heartbeats']['some'](_0x321e0d=>_0x321e0d['date']===_0x1ab53f))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1ab53f,'agent':_0x43b14f}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x108a12=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x108a12,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x436467){oe['warn'](_0x436467);}}async['getHeartbeatsHeader'](){var _0xd1a1bd;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xd1a1bd=this['_heartbeatsCache'])==null?void 0x0:_0xd1a1bd['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x785dc9=Us(),{heartbeatsToSend:_0x389320,unsentEntries:_0x23f751}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4b935f=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x389320}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x785dc9,_0x23f751['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x23f751,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4b935f;}catch(_0x3f865b){return oe['warn'](_0x3f865b),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x30abec,_0x30e886=kl){const _0x276065=[];let _0x1cdd41=_0x30abec['slice']();for(const _0x147d3e of _0x30abec){const _0xbc87b9=_0x276065['find'](_0x124f79=>_0x124f79['agent']===_0x147d3e['agent']);if(_0xbc87b9){if(_0xbc87b9['dates']['push'](_0x147d3e['date']),Ws(_0x276065)>_0x30e886){_0xbc87b9['dates']['pop']();break;}}else{if(_0x276065['push']({'agent':_0x147d3e['agent'],'dates':[_0x147d3e['date']]}),Ws(_0x276065)>_0x30e886){_0x276065['pop']();break;}}_0x1cdd41=_0x1cdd41['slice'](0x1);}return{'heartbeatsToSend':_0x276065,'unsentEntries':_0x1cdd41};}class Dl{constructor(_0x4f5054){this['app']=_0x4f5054,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4fbea8=await Al(this['app']);return _0x4fbea8!=null&&_0x4fbea8['heartbeats']?_0x4fbea8:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2708ad){if(await this['_canUseIndexedDBPromise']){const _0x164bad=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2708ad['lastSentHeartbeatDate']??_0x164bad['lastSentHeartbeatDate'],'heartbeats':_0x2708ad['heartbeats']});}else return;}async['add'](_0x4d1f66){if(await this['_canUseIndexedDBPromise']){const _0xd8dda9=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4d1f66['lastSentHeartbeatDate']??_0xd8dda9['lastSentHeartbeatDate'],'heartbeats':[..._0xd8dda9['heartbeats'],..._0x4d1f66['heartbeats']]});}else return;}}function Ws(_0x459121){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x459121}))['length'];}function Ml(_0x2347cc){if(_0x2347cc['length']===0x0)return-0x1;let _0x34c7d6=0x0,_0x3982b3=_0x2347cc[0x0]['date'];for(let _0x312c6a=0x1;_0x312c6a<_0x2347cc['length'];_0x312c6a++)_0x2347cc[_0x312c6a]['date']<_0x3982b3&&(_0x3982b3=_0x2347cc[_0x312c6a]['date'],_0x34c7d6=_0x312c6a);return _0x34c7d6;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x323985){st(new xe('platform-logger',_0x5e4752=>new jc(_0x5e4752),'PRIVATE')),st(new xe('heartbeat',_0x387103=>new Pl(_0x387103),'PRIVATE')),ye(mi,Ls,_0x323985),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x26bfb6){no=_0x26bfb6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x308e73){this['domStorage_']=_0x308e73,this['prefix_']='firebase:';}['set'](_0x3f6003,_0x31843a){_0x31843a==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3f6003)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3f6003),O(_0x31843a));}['get'](_0xe0508b){const _0xd71e8b=this['domStorage_']['getItem'](this['prefixedName_'](_0xe0508b));return _0xd71e8b==null?null:Nt(_0xd71e8b);}['remove'](_0x246f00){this['domStorage_']['removeItem'](this['prefixedName_'](_0x246f00));}['prefixedName_'](_0x2616c2){return this['prefix_']+_0x2616c2;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x54aea6,_0x92d0a0){_0x92d0a0==null?delete this['cache_'][_0x54aea6]:this['cache_'][_0x54aea6]=_0x92d0a0;}['get'](_0x179bb9){return Q(this['cache_'],_0x179bb9)?this['cache_'][_0x179bb9]:null;}['remove'](_0x72f58e){delete this['cache_'][_0x72f58e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1d5522){try{if(typeof window<'u'&&typeof window[_0x1d5522]<'u'){const _0x2b7b70=window[_0x1d5522];return _0x2b7b70['setItem']('firebase:sentinel','cache'),_0x2b7b70['removeItem']('firebase:sentinel'),new Wl(_0x2b7b70);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x49e9e0=0x1;return function(){return _0x49e9e0++;};}()),ro=function(_0x21229e){const _0x2c0185=Rc(_0x21229e),_0x10241e=new Cc();_0x10241e['update'](_0x2c0185);const _0x174005=_0x10241e['digest']();return Fi['encodeByteArray'](_0x174005);},qt=function(..._0x22d2af){let _0xe7cfb1='';for(let _0x2e47df=0x0;_0x2e47df<_0x22d2af['length'];_0x2e47df++){const _0x248b29=_0x22d2af[_0x2e47df];Array['isArray'](_0x248b29)||_0x248b29&&typeof _0x248b29=='object'&&typeof _0x248b29['length']=='number'?_0xe7cfb1+=qt['apply'](null,_0x248b29):typeof _0x248b29=='object'?_0xe7cfb1+=O(_0x248b29):_0xe7cfb1+=_0x248b29,_0xe7cfb1+='\x20';}return _0xe7cfb1;};let Tt=null,$s=!0x0;const Hl=function(_0x4bc327,_0x43b67f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0x383365){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0x567750=qt['apply'](null,_0x383365);Tt(_0x567750);}},zt=function(_0x390862){return function(..._0x384ef9){L(_0x390862,..._0x384ef9);};},Ii=function(..._0x56c599){const _0x5d9f44='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x56c599);Ze['error'](_0x5d9f44);},ae=function(..._0x462eac){const _0x1fc26a='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x462eac);throw Ze['error'](_0x1fc26a),new Error(_0x1fc26a);},U=function(..._0x256890){const _0x63b95c='FIREBASE\x20WARNING:\x20'+qt(..._0x256890);Ze['warn'](_0x63b95c);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x335ea8){return typeof _0x335ea8=='number'&&(_0x335ea8!==_0x335ea8||_0x335ea8===Number['POSITIVE_INFINITY']||_0x335ea8===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4cc571){if(document['readyState']==='complete')_0x4cc571();else{let _0x1b9460=!0x1;const _0x20b556=function(){if(!document['body']){setTimeout(_0x20b556,Math['floor'](0xa));return;}_0x1b9460||(_0x1b9460=!0x0,_0x4cc571());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x20b556,!0x1),window['addEventListener']('load',_0x20b556,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x20b556();}),window['attachEvent']('onload',_0x20b556));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x12a998,_0x130312){if(_0x12a998===_0x130312)return 0x0;if(_0x12a998===Ue||_0x130312===we)return-0x1;if(_0x130312===Ue||_0x12a998===we)return 0x1;{const _0x31b1c8=Gs(_0x12a998),_0x31de68=Gs(_0x130312);return _0x31b1c8!==null?_0x31de68!==null?_0x31b1c8-_0x31de68===0x0?_0x12a998['length']-_0x130312['length']:_0x31b1c8-_0x31de68:-0x1:_0x31de68!==null?0x1:_0x12a998<_0x130312?-0x1:0x1;}},ql=function(_0x2c1944,_0x1e7a01){return _0x2c1944===_0x1e7a01?0x0:_0x2c1944<_0x1e7a01?-0x1:0x1;},yt=function(_0x32c573,_0x20a8bc){if(_0x20a8bc&&_0x32c573 in _0x20a8bc)return _0x20a8bc[_0x32c573];throw new Error('Missing\x20required\x20key\x20('+_0x32c573+')\x20in\x20object:\x20'+O(_0x20a8bc));},$i=function(_0x120fac){if(typeof _0x120fac!='object'||_0x120fac===null)return O(_0x120fac);const _0x4d40c4=[];for(const _0x5d5c25 in _0x120fac)_0x4d40c4['push'](_0x5d5c25);_0x4d40c4['sort']();let _0x46ec0c='{';for(let _0x19e355=0x0;_0x19e355<_0x4d40c4['length'];_0x19e355++)_0x19e355!==0x0&&(_0x46ec0c+=','),_0x46ec0c+=O(_0x4d40c4[_0x19e355]),_0x46ec0c+=':',_0x46ec0c+=$i(_0x120fac[_0x4d40c4[_0x19e355]]);return _0x46ec0c+='}',_0x46ec0c;},oo=function(_0x2d63ae,_0x1df252){const _0x5d39ad=_0x2d63ae['length'];if(_0x5d39ad<=_0x1df252)return[_0x2d63ae];const _0x34f62d=[];for(let _0x34c85c=0x0;_0x34c85c<_0x5d39ad;_0x34c85c+=_0x1df252)_0x34c85c+_0x1df252>_0x5d39ad?_0x34f62d['push'](_0x2d63ae['substring'](_0x34c85c,_0x5d39ad)):_0x34f62d['push'](_0x2d63ae['substring'](_0x34c85c,_0x34c85c+_0x1df252));return _0x34f62d;};function x(_0x2d3001,_0x1c2aa8){for(const _0x86e6e1 in _0x2d3001)_0x2d3001['hasOwnProperty'](_0x86e6e1)&&_0x1c2aa8(_0x86e6e1,_0x2d3001[_0x86e6e1]);}const ao=function(_0x566eee){f(!xn(_0x566eee),'Invalid\x20JSON\x20number');const _0x3031fa=0xb,_0x14f479=0x34,_0x1bc3ee=(0x1<<_0x3031fa-0x1)-0x1;let _0x2768c9,_0x2cf10a,_0x23260d,_0x8a17b6,_0x14a54d;_0x566eee===0x0?(_0x2cf10a=0x0,_0x23260d=0x0,_0x2768c9=0x1/_0x566eee===-0x1/0x0?0x1:0x0):(_0x2768c9=_0x566eee<0x0,_0x566eee=Math['abs'](_0x566eee),_0x566eee>=Math['pow'](0x2,0x1-_0x1bc3ee)?(_0x8a17b6=Math['min'](Math['floor'](Math['log'](_0x566eee)/Math['LN2']),_0x1bc3ee),_0x2cf10a=_0x8a17b6+_0x1bc3ee,_0x23260d=Math['round'](_0x566eee*Math['pow'](0x2,_0x14f479-_0x8a17b6)-Math['pow'](0x2,_0x14f479))):(_0x2cf10a=0x0,_0x23260d=Math['round'](_0x566eee/Math['pow'](0x2,0x1-_0x1bc3ee-_0x14f479))));const _0x1d7f7d=[];for(_0x14a54d=_0x14f479;_0x14a54d;_0x14a54d-=0x1)_0x1d7f7d['push'](_0x23260d%0x2?0x1:0x0),_0x23260d=Math['floor'](_0x23260d/0x2);for(_0x14a54d=_0x3031fa;_0x14a54d;_0x14a54d-=0x1)_0x1d7f7d['push'](_0x2cf10a%0x2?0x1:0x0),_0x2cf10a=Math['floor'](_0x2cf10a/0x2);_0x1d7f7d['push'](_0x2768c9?0x1:0x0),_0x1d7f7d['reverse']();const _0xdc0c92=_0x1d7f7d['join']('');let _0x5daf14='';for(_0x14a54d=0x0;_0x14a54d<0x40;_0x14a54d+=0x8){let _0xca3741=parseInt(_0xdc0c92['substr'](_0x14a54d,0x8),0x2)['toString'](0x10);_0xca3741['length']===0x1&&(_0xca3741='0'+_0xca3741),_0x5daf14=_0x5daf14+_0xca3741;}return _0x5daf14['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x109fe2,_0x4f26bc){let _0x514da5='Unknown\x20Error';_0x109fe2==='too_big'?_0x514da5='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x109fe2==='permission_denied'?_0x514da5='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x109fe2==='unavailable'&&(_0x514da5='The\x20service\x20is\x20unavailable');const _0xb109b4=new Error(_0x109fe2+'\x20at\x20'+_0x4f26bc['_path']['toString']()+':\x20'+_0x514da5);return _0xb109b4['code']=_0x109fe2['toUpperCase'](),_0xb109b4;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x39033f){if(Yl['test'](_0x39033f)){const _0x31f3da=Number(_0x39033f);if(_0x31f3da>=Ql&&_0x31f3da<=Jl)return _0x31f3da;}return null;},ft=function(_0x535951){try{_0x535951();}catch(_0x28cf12){setTimeout(()=>{const _0x4dd35e=_0x28cf12['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4dd35e),_0x28cf12;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x251c88,_0x15fa44){const _0x2486e0=setTimeout(_0x251c88,_0x15fa44);return typeof _0x2486e0=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2486e0):typeof _0x2486e0=='object'&&_0x2486e0['unref']&&_0x2486e0['unref'](),_0x2486e0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x5a77ee,_0x53b5e2){this['appCheckProvider']=_0x53b5e2,this['appName']=_0x5a77ee['name'],$(_0x5a77ee)&&_0x5a77ee['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5a77ee['settings']['appCheckToken']),this['appCheck']=_0x53b5e2==null?void 0x0:_0x53b5e2['getImmediate']({'optional':!0x0}),this['appCheck']||_0x53b5e2==null||_0x53b5e2['get']()['then'](_0x3d7b30=>this['appCheck']=_0x3d7b30);}['getToken'](_0x3ca710){if(this['serverAppAppCheckToken']){if(_0x3ca710)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3ca710):new Promise((_0x5cf5f7,_0x1d0684)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3ca710)['then'](_0x5cf5f7,_0x1d0684):_0x5cf5f7(null);},0x0);});}['addTokenChangeListener'](_0x3a9c87){var _0xe8a27d;(_0xe8a27d=this['appCheckProvider'])==null||_0xe8a27d['get']()['then'](_0x3e6ca4=>_0x3e6ca4['addTokenListener'](_0x3a9c87));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x571636,_0x5b334f,_0x193894){this['appName_']=_0x571636,this['firebaseOptions_']=_0x5b334f,this['authProvider_']=_0x193894,this['auth_']=null,this['auth_']=_0x193894['getImmediate']({'optional':!0x0}),this['auth_']||_0x193894['onInit'](_0x2d26d5=>this['auth_']=_0x2d26d5);}['getToken'](_0xdf3dd2){return this['auth_']?this['auth_']['getToken'](_0xdf3dd2)['catch'](_0x29de7c=>_0x29de7c&&_0x29de7c['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x29de7c)):new Promise((_0x44327e,_0x37755e)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xdf3dd2)['then'](_0x44327e,_0x37755e):_0x44327e(null);},0x0);});}['addTokenChangeListener'](_0x3cd7f8){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3cd7f8):this['authProvider_']['get']()['then'](_0x48b31d=>_0x48b31d['addAuthTokenListener'](_0x3cd7f8));}['removeTokenChangeListener'](_0x3f807b){this['authProvider_']['get']()['then'](_0x2e6037=>_0x2e6037['removeAuthTokenListener'](_0x3f807b));}['notifyForInvalidToken'](){let _0x468c3a='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x468c3a+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x468c3a+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x468c3a+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x468c3a);}}class an{constructor(_0x54a401){this['accessToken']=_0x54a401;}['getToken'](_0x5d6c1d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x27051d){_0x27051d(this['accessToken']);}['removeTokenChangeListener'](_0x55bbd5){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4389ad,_0x5eea58,_0x5bda9b,_0x10010b,_0x5e4c14=!0x1,_0x2b2e29='',_0x54a71d=!0x1,_0x3e6c79=!0x1,_0x265fba=null){this['secure']=_0x5eea58,this['namespace']=_0x5bda9b,this['webSocketOnly']=_0x10010b,this['nodeAdmin']=_0x5e4c14,this['persistenceKey']=_0x2b2e29,this['includeNamespaceInQueryParams']=_0x54a71d,this['isUsingEmulator']=_0x3e6c79,this['emulatorOptions']=_0x265fba,this['_host']=_0x4389ad['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x4389ad)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x558ef4){_0x558ef4!==this['internalHost']&&(this['internalHost']=_0x558ef4,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x61ecbd=this['toURLString']();return this['persistenceKey']&&(_0x61ecbd+='<'+this['persistenceKey']+'>'),_0x61ecbd;}['toURLString'](){const _0x5b8962=this['secure']?'https://':'http://',_0x56aee3=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5b8962+this['host']+'/'+_0x56aee3;}}function th(_0x491ff4){return _0x491ff4['host']!==_0x491ff4['internalHost']||_0x491ff4['isCustomHost']()||_0x491ff4['includeNamespaceInQueryParams'];}function vo(_0x37c875,_0x2ab90c,_0x2af629){f(typeof _0x2ab90c=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2af629=='object','typeof\x20params\x20must\x20==\x20object');let _0x3daffa;if(_0x2ab90c===go)_0x3daffa=(_0x37c875['secure']?'wss://':'ws://')+_0x37c875['internalHost']+'/.ws?';else{if(_0x2ab90c===mo)_0x3daffa=(_0x37c875['secure']?'https://':'http://')+_0x37c875['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2ab90c);}th(_0x37c875)&&(_0x2af629['ns']=_0x37c875['namespace']);const _0x4e645d=[];return x(_0x2af629,(_0x31d97e,_0x536f64)=>{_0x4e645d['push'](_0x31d97e+'='+_0x536f64);}),_0x3daffa+_0x4e645d['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x34ced1,_0x219a57=0x1){Q(this['counters_'],_0x34ced1)||(this['counters_'][_0x34ced1]=0x0),this['counters_'][_0x34ced1]+=_0x219a57;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x16501d){const _0x1d151c=_0x16501d['toString']();return oi[_0x1d151c]||(oi[_0x1d151c]=new nh()),oi[_0x1d151c];}function ih(_0x1b1ad7,_0x548ab5){const _0x422862=_0x1b1ad7['toString']();return ai[_0x422862]||(ai[_0x422862]=_0x548ab5()),ai[_0x422862];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x6216f8){this['onMessage_']=_0x6216f8,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x196a9c,_0x541c65){this['closeAfterResponse']=_0x196a9c,this['onClose']=_0x541c65,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x375307,_0x1b09dd){for(this['pendingResponses'][_0x375307]=_0x1b09dd;this['pendingResponses'][this['currentResponseNum']];){const _0x2606fa=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xe3b302=0x0;_0xe3b302<_0x2606fa['length'];++_0xe3b302)_0x2606fa[_0xe3b302]&&ft(()=>{this['onMessage_'](_0x2606fa[_0xe3b302]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3d5a6d,_0x482cec,_0x55d57c,_0x1ca666,_0x2bb3f5,_0xd41f8e,_0x8aead1){this['connId']=_0x3d5a6d,this['repoInfo']=_0x482cec,this['applicationId']=_0x55d57c,this['appCheckToken']=_0x1ca666,this['authToken']=_0x2bb3f5,this['transportSessionId']=_0xd41f8e,this['lastSessionId']=_0x8aead1,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x3d5a6d),this['stats_']=qi(_0x482cec),this['urlFn']=_0x2ed663=>(this['appCheckToken']&&(_0x2ed663[wi]=this['appCheckToken']),vo(_0x482cec,mo,_0x2ed663));}['open'](_0xf0bf21,_0x3a30e8){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3a30e8,this['myPacketOrderer']=new sh(_0xf0bf21),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x34509e)=>{const [_0x166c61,_0x2b6f9d,_0x472f89,_0x254c17,_0x387ae7]=_0x34509e;if(this['incrementIncomingBytes_'](_0x34509e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x166c61===qs)this['id']=_0x2b6f9d,this['password']=_0x472f89;else{if(_0x166c61===rh)_0x2b6f9d?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2b6f9d,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x166c61);}}},(..._0x548946)=>{const [_0x4605b4,_0x19e925]=_0x548946;this['incrementIncomingBytes_'](_0x548946),this['myPacketOrderer']['handleResponse'](_0x4605b4,_0x19e925);},()=>{this['onClosed_']();},this['urlFn']);const _0x458065={};_0x458065[qs]='t',_0x458065[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x458065[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x458065[co]=Gi,this['transportSessionId']&&(_0x458065[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x458065[po]=this['lastSessionId']),this['applicationId']&&(_0x458065[_o]=this['applicationId']),this['appCheckToken']&&(_0x458065[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x458065[ho]=uo);const _0x4df1c9=this['urlFn'](_0x458065);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4df1c9),this['scriptTagHolder']['addTag'](_0x4df1c9,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4d10e4){const _0x5b3cb3=O(_0x4d10e4);this['bytesSent']+=_0x5b3cb3['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5b3cb3['length']);const _0x55b901=$r(_0x5b3cb3),_0x4e8ab8=oo(_0x55b901,fh);for(let _0x6843a5=0x0;_0x6843a5<_0x4e8ab8['length'];_0x6843a5++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4e8ab8['length'],_0x4e8ab8[_0x6843a5]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x391760,_0x393d6c){this['myDisconnFrame']=document['createElement']('iframe');const _0x42cf14={};_0x42cf14[dh]='t',_0x42cf14[Eo]=_0x391760,_0x42cf14[Io]=_0x393d6c,this['myDisconnFrame']['src']=this['urlFn'](_0x42cf14),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x513a53){const _0x249e74=O(_0x513a53)['length'];this['bytesReceived']+=_0x249e74,this['stats_']['incrementCounter']('bytes_received',_0x249e74);}}class zi{constructor(_0x3f67ce,_0x34e060,_0x194faa,_0x28eaab){this['onDisconnect']=_0x194faa,this['urlFn']=_0x28eaab,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3f67ce,window[ah+this['uniqueCallbackIdentifier']]=_0x34e060,this['myIFrame']=zi['createIFrame_']();let _0x150cfd='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x150cfd='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xbb4537='<html><body>'+_0x150cfd+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xbb4537),this['myIFrame']['doc']['close']();}catch(_0x3094d6){L('frame\x20writing\x20exception'),_0x3094d6['stack']&&L(_0x3094d6['stack']),L(_0x3094d6);}}}static['createIFrame_'](){const _0x458c02=document['createElement']('iframe');if(_0x458c02['style']['display']='none',document['body']){document['body']['appendChild'](_0x458c02);try{_0x458c02['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x44348c=document['domain'];_0x458c02['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x44348c+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x458c02['contentDocument']?_0x458c02['doc']=_0x458c02['contentDocument']:_0x458c02['contentWindow']?_0x458c02['doc']=_0x458c02['contentWindow']['document']:_0x458c02['document']&&(_0x458c02['doc']=_0x458c02['document']),_0x458c02;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2428e7=this['onDisconnect'];_0x2428e7&&(this['onDisconnect']=null,_0x2428e7());}['startLongPoll'](_0x24f63d,_0x53f61c){for(this['myID']=_0x24f63d,this['myPW']=_0x53f61c,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x30408a={};_0x30408a[Eo]=this['myID'],_0x30408a[Io]=this['myPW'],_0x30408a[wo]=this['currentSerial'];let _0x56a670=this['urlFn'](_0x30408a),_0x45dde2='',_0x33f699=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x45dde2['length']<=Co;){const _0x100852=this['pendingSegs']['shift']();_0x45dde2=_0x45dde2+'&'+lh+_0x33f699+'='+_0x100852['seg']+'&'+hh+_0x33f699+'='+_0x100852['ts']+'&'+uh+_0x33f699+'='+_0x100852['d'],_0x33f699++;}return _0x56a670=_0x56a670+_0x45dde2,this['addLongPollTag_'](_0x56a670,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x165465,_0x1c7046,_0x5d7296){this['pendingSegs']['push']({'seg':_0x165465,'ts':_0x1c7046,'d':_0x5d7296}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x12be4d,_0x40d279){this['outstandingRequests']['add'](_0x40d279);const _0x4093ab=()=>{this['outstandingRequests']['delete'](_0x40d279),this['newRequest_']();},_0x2bd314=setTimeout(_0x4093ab,Math['floor'](ph)),_0x25e675=()=>{clearTimeout(_0x2bd314),_0x4093ab();};this['addTag'](_0x12be4d,_0x25e675);}['addTag'](_0x1a19fb,_0x19e526){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x221554=this['myIFrame']['doc']['createElement']('script');_0x221554['type']='text/javascript',_0x221554['async']=!0x0,_0x221554['src']=_0x1a19fb,_0x221554['onload']=_0x221554['onreadystatechange']=function(){const _0xf99961=_0x221554['readyState'];(!_0xf99961||_0xf99961==='loaded'||_0xf99961==='complete')&&(_0x221554['onload']=_0x221554['onreadystatechange']=null,_0x221554['parentNode']&&_0x221554['parentNode']['removeChild'](_0x221554),_0x19e526());},_0x221554['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x1a19fb),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x221554);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x5cc4b3,_0x46ce06,_0x16ecaf,_0x10d681,_0x296f7b,_0x44c00d,_0x27d908){this['connId']=_0x5cc4b3,this['applicationId']=_0x16ecaf,this['appCheckToken']=_0x10d681,this['authToken']=_0x296f7b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0x46ce06),this['connURL']=q['connectionURL_'](_0x46ce06,_0x44c00d,_0x27d908,_0x10d681,_0x16ecaf),this['nodeAdmin']=_0x46ce06['nodeAdmin'];}static['connectionURL_'](_0x2cda27,_0x30b26f,_0x3ebad7,_0x3dc895,_0x548f20){const _0x5eed68={};return _0x5eed68[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5eed68[ho]=uo),_0x30b26f&&(_0x5eed68[lo]=_0x30b26f),_0x3ebad7&&(_0x5eed68[po]=_0x3ebad7),_0x3dc895&&(_0x5eed68[wi]=_0x3dc895),_0x548f20&&(_0x5eed68[_o]=_0x548f20),vo(_0x2cda27,go,_0x5eed68);}['open'](_0x218413,_0x150879){this['onDisconnect']=_0x150879,this['onMessage']=_0x218413,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x5d0212;_c(),this['mySock']=new gn(this['connURL'],[],_0x5d0212);}catch(_0x320166){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4e4190=_0x320166['message']||_0x320166['data'];_0x4e4190&&this['log_'](_0x4e4190),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x49173a=>{this['handleIncomingFrame'](_0x49173a);},this['mySock']['onerror']=_0x87f1ac=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xb080c4=_0x87f1ac['message']||_0x87f1ac['data'];_0xb080c4&&this['log_'](_0xb080c4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x265788=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x57d9ef=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x131da9=navigator['userAgent']['match'](_0x57d9ef);_0x131da9&&_0x131da9['length']>0x1&&parseFloat(_0x131da9[0x1])<4.4&&(_0x265788=!0x0);}return!_0x265788&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2d2144){if(this['frames']['push'](_0x2d2144),this['frames']['length']===this['totalFrames']){const _0x58bba9=this['frames']['join']('');this['frames']=null;const _0x3a634d=Nt(_0x58bba9);this['onMessage'](_0x3a634d);}}['handleNewFrameCount_'](_0x333ce5){this['totalFrames']=_0x333ce5,this['frames']=[];}['extractFrameCount_'](_0x37d2d8){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x37d2d8['length']<=0x6){const _0x5b1139=Number(_0x37d2d8);if(!isNaN(_0x5b1139))return this['handleNewFrameCount_'](_0x5b1139),null;}return this['handleNewFrameCount_'](0x1),_0x37d2d8;}['handleIncomingFrame'](_0x132ecf){if(this['mySock']===null)return;const _0x4d4b4e=_0x132ecf['data'];if(this['bytesReceived']+=_0x4d4b4e['length'],this['stats_']['incrementCounter']('bytes_received',_0x4d4b4e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4d4b4e);else{const _0x218b6c=this['extractFrameCount_'](_0x4d4b4e);_0x218b6c!==null&&this['appendFrame_'](_0x218b6c);}}['send'](_0x41ef11){this['resetKeepAlive']();const _0x485724=O(_0x41ef11);this['bytesSent']+=_0x485724['length'],this['stats_']['incrementCounter']('bytes_sent',_0x485724['length']);const _0x464ad4=oo(_0x485724,gh);_0x464ad4['length']>0x1&&this['sendString_'](String(_0x464ad4['length']));for(let _0x4cb481=0x0;_0x4cb481<_0x464ad4['length'];_0x4cb481++)this['sendString_'](_0x464ad4[_0x4cb481]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x27420f){try{this['mySock']['send'](_0x27420f);}catch(_0x2b788d){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2b788d['message']||_0x2b788d['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x141ad6){this['initTransports_'](_0x141ad6);}['initTransports_'](_0x4cc220){const _0x4fe60e=q&&q['isAvailable']();let _0x13006d=_0x4fe60e&&!q['previouslyFailed']();if(_0x4cc220['webSocketOnly']&&(_0x4fe60e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x13006d=!0x0),_0x13006d)this['transports_']=[q];else{const _0x22af5e=this['transports_']=[];for(const _0x2fabfb of Ot['ALL_TRANSPORTS'])_0x2fabfb&&_0x2fabfb['isAvailable']()&&_0x22af5e['push'](_0x2fabfb);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x217434,_0x12e648,_0x22c052,_0x57cad0,_0x1380af,_0x4cac0a,_0x39b7d8,_0x37f0d5,_0xcff259,_0x119538){this['id']=_0x217434,this['repoInfo_']=_0x12e648,this['applicationId_']=_0x22c052,this['appCheckToken_']=_0x57cad0,this['authToken_']=_0x1380af,this['onMessage_']=_0x4cac0a,this['onReady_']=_0x39b7d8,this['onDisconnect_']=_0x37f0d5,this['onKill_']=_0xcff259,this['lastSessionId']=_0x119538,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x12e648),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2d3094=this['transportManager_']['initialTransport']();this['conn_']=new _0x2d3094(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2d3094['responsesRequiredToBeHealthy']||0x0;const _0x410488=this['connReceiver_'](this['conn_']),_0x1b486e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x410488,_0x1b486e);},Math['floor'](0x0));const _0x2b6f85=_0x2d3094['healthyTimeout']||0x0;_0x2b6f85>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2b6f85)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5ca42f){return _0xae53ac=>{_0x5ca42f===this['conn_']?this['onConnectionLost_'](_0xae53ac):_0x5ca42f===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1b2d41){return _0x415c78=>{this['state_']!==0x2&&(_0x1b2d41===this['rx_']?this['onPrimaryMessageReceived_'](_0x415c78):_0x1b2d41===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x415c78):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x340e62){const _0x312885={'t':'d','d':_0x340e62};this['sendData_'](_0x312885);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x35d165){if(ci in _0x35d165){const _0x44b562=_0x35d165[ci];_0x44b562===Ys?this['upgradeIfSecondaryHealthy_']():_0x44b562===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x44b562===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3125d6){const _0x39c57c=yt('t',_0x3125d6),_0x967e88=yt('d',_0x3125d6);if(_0x39c57c==='c')this['onSecondaryControl_'](_0x967e88);else{if(_0x39c57c==='d')this['pendingDataMessages']['push'](_0x967e88);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x39c57c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5f4423){const _0x57c89a=yt('t',_0x5f4423),_0x308fc2=yt('d',_0x5f4423);_0x57c89a==='c'?this['onControl_'](_0x308fc2):_0x57c89a==='d'&&this['onDataMessage_'](_0x308fc2);}['onDataMessage_'](_0x379010){this['onPrimaryResponse_'](),this['onMessage_'](_0x379010);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3d7ea8){const _0x1f585d=yt(ci,_0x3d7ea8);if(zs in _0x3d7ea8){const _0x180e76=_0x3d7ea8[zs];if(_0x1f585d===Th){const _0x4792b3={..._0x180e76};this['repoInfo_']['isUsingEmulator']&&(_0x4792b3['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4792b3);}else{if(_0x1f585d===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x530df1=0x0;_0x530df1<this['pendingDataMessages']['length'];++_0x530df1)this['onDataMessage_'](this['pendingDataMessages'][_0x530df1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1f585d===wh?this['onConnectionShutdown_'](_0x180e76):_0x1f585d===js?this['onReset_'](_0x180e76):_0x1f585d===Ch?Ii('Server\x20Error:\x20'+_0x180e76):_0x1f585d===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1f585d);}}}['onHandshake_'](_0x4a8e6c){const _0x314e75=_0x4a8e6c['ts'],_0x273d2f=_0x4a8e6c['v'],_0x3197bf=_0x4a8e6c['h'];this['sessionId']=_0x4a8e6c['s'],this['repoInfo_']['host']=_0x3197bf,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x314e75),Gi!==_0x273d2f&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x540208=this['transportManager_']['upgradeTransport']();_0x540208&&this['startUpgrade_'](_0x540208);}['startUpgrade_'](_0x1d5fe7){this['secondaryConn_']=new _0x1d5fe7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1d5fe7['responsesRequiredToBeHealthy']||0x0;const _0xba1796=this['connReceiver_'](this['secondaryConn_']),_0x541bc8=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xba1796,_0x541bc8),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x456355){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x456355),this['repoInfo_']['host']=_0x456355,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4d096f,_0x52d9dd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4d096f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x52d9dd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x408c43=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x408c43||this['rx_']===_0x408c43)&&this['close']();}['onConnectionLost_'](_0x5e4897){this['conn_']=null,!_0x5e4897&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2f1a1){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2f1a1),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1e8ee8){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1e8ee8);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x151f25,_0x5023d5,_0x21733f,_0x59374b){}['merge'](_0x10a41a,_0x58f1ce,_0x136de5,_0x2146bd){}['refreshAuthToken'](_0xe09632){}['refreshAppCheckToken'](_0x3b382a){}['onDisconnectPut'](_0x22ee5c,_0x532118,_0x8b6de0){}['onDisconnectMerge'](_0xcfc7d5,_0x2f871f,_0x473217){}['onDisconnectCancel'](_0x5c45fa,_0x55b0c5){}['reportStats'](_0x191053){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x22f670){this['allowedEvents_']=_0x22f670,this['listeners_']={},f(Array['isArray'](_0x22f670)&&_0x22f670['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4cab6f,..._0x3ed37d){if(Array['isArray'](this['listeners_'][_0x4cab6f])){const _0x28e65c=[...this['listeners_'][_0x4cab6f]];for(let _0x2a7cf1=0x0;_0x2a7cf1<_0x28e65c['length'];_0x2a7cf1++)_0x28e65c[_0x2a7cf1]['callback']['apply'](_0x28e65c[_0x2a7cf1]['context'],_0x3ed37d);}}['on'](_0xd099f7,_0x92c80c,_0x4363f1){this['validateEventType_'](_0xd099f7),this['listeners_'][_0xd099f7]=this['listeners_'][_0xd099f7]||[],this['listeners_'][_0xd099f7]['push']({'callback':_0x92c80c,'context':_0x4363f1});const _0xacd937=this['getInitialEvent'](_0xd099f7);_0xacd937&&_0x92c80c['apply'](_0x4363f1,_0xacd937);}['off'](_0x881e0e,_0x3a5b70,_0x47a6b3){this['validateEventType_'](_0x881e0e);const _0x15866e=this['listeners_'][_0x881e0e]||[];for(let _0x57c95c=0x0;_0x57c95c<_0x15866e['length'];_0x57c95c++)if(_0x15866e[_0x57c95c]['callback']===_0x3a5b70&&(!_0x47a6b3||_0x47a6b3===_0x15866e[_0x57c95c]['context'])){_0x15866e['splice'](_0x57c95c,0x1);return;}}['validateEventType_'](_0x1b074e){f(this['allowedEvents_']['find'](_0x47fc1f=>_0x47fc1f===_0x1b074e),'Unknown\x20event:\x20'+_0x1b074e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x237cc4){return f(_0x237cc4==='online','Unknown\x20event\x20type:\x20'+_0x237cc4),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x42feed,_0x1b1e2e){if(_0x1b1e2e===void 0x0){this['pieces_']=_0x42feed['split']('/');let _0x2b97b5=0x0;for(let _0x4c9dd0=0x0;_0x4c9dd0<this['pieces_']['length'];_0x4c9dd0++)this['pieces_'][_0x4c9dd0]['length']>0x0&&(this['pieces_'][_0x2b97b5]=this['pieces_'][_0x4c9dd0],_0x2b97b5++);this['pieces_']['length']=_0x2b97b5,this['pieceNum_']=0x0;}else this['pieces_']=_0x42feed,this['pieceNum_']=_0x1b1e2e;}['toString'](){let _0x437af1='';for(let _0x18ac4a=this['pieceNum_'];_0x18ac4a<this['pieces_']['length'];_0x18ac4a++)this['pieces_'][_0x18ac4a]!==''&&(_0x437af1+='/'+this['pieces_'][_0x18ac4a]);return _0x437af1||'/';}}function w(){return new C('');}function y(_0x19af7){return _0x19af7['pieceNum_']>=_0x19af7['pieces_']['length']?null:_0x19af7['pieces_'][_0x19af7['pieceNum_']];}function Ce(_0x2ce96a){return _0x2ce96a['pieces_']['length']-_0x2ce96a['pieceNum_'];}function S(_0x2ac46b){let _0x30fa60=_0x2ac46b['pieceNum_'];return _0x30fa60<_0x2ac46b['pieces_']['length']&&_0x30fa60++,new C(_0x2ac46b['pieces_'],_0x30fa60);}function ji(_0x4b992c){return _0x4b992c['pieceNum_']<_0x4b992c['pieces_']['length']?_0x4b992c['pieces_'][_0x4b992c['pieces_']['length']-0x1]:null;}function bh(_0x19fb31){let _0x242fd4='';for(let _0x29a7fe=_0x19fb31['pieceNum_'];_0x29a7fe<_0x19fb31['pieces_']['length'];_0x29a7fe++)_0x19fb31['pieces_'][_0x29a7fe]!==''&&(_0x242fd4+='/'+encodeURIComponent(String(_0x19fb31['pieces_'][_0x29a7fe])));return _0x242fd4||'/';}function Dt(_0x141547,_0x49b9cf=0x0){return _0x141547['pieces_']['slice'](_0x141547['pieceNum_']+_0x49b9cf);}function Ro(_0xea3003){if(_0xea3003['pieceNum_']>=_0xea3003['pieces_']['length'])return null;const _0x119c60=[];for(let _0x59bfb8=_0xea3003['pieceNum_'];_0x59bfb8<_0xea3003['pieces_']['length']-0x1;_0x59bfb8++)_0x119c60['push'](_0xea3003['pieces_'][_0x59bfb8]);return new C(_0x119c60,0x0);}function k(_0x36df12,_0x27ffc3){const _0xfaad53=[];for(let _0x14bbe9=_0x36df12['pieceNum_'];_0x14bbe9<_0x36df12['pieces_']['length'];_0x14bbe9++)_0xfaad53['push'](_0x36df12['pieces_'][_0x14bbe9]);if(_0x27ffc3 instanceof C){for(let _0x3e8208=_0x27ffc3['pieceNum_'];_0x3e8208<_0x27ffc3['pieces_']['length'];_0x3e8208++)_0xfaad53['push'](_0x27ffc3['pieces_'][_0x3e8208]);}else{const _0x1b5b75=_0x27ffc3['split']('/');for(let _0x27726f=0x0;_0x27726f<_0x1b5b75['length'];_0x27726f++)_0x1b5b75[_0x27726f]['length']>0x0&&_0xfaad53['push'](_0x1b5b75[_0x27726f]);}return new C(_0xfaad53,0x0);}function v(_0x590543){return _0x590543['pieceNum_']>=_0x590543['pieces_']['length'];}function F(_0x31e179,_0x38fa04){const _0x4e9680=y(_0x31e179),_0x3f159b=y(_0x38fa04);if(_0x4e9680===null)return _0x38fa04;if(_0x4e9680===_0x3f159b)return F(S(_0x31e179),S(_0x38fa04));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x38fa04+')\x20is\x20not\x20within\x20outerPath\x20('+_0x31e179+')');}function Rh(_0xfb91c7,_0x4119cb){const _0x2e7e5d=Dt(_0xfb91c7,0x0),_0x6a3fe8=Dt(_0x4119cb,0x0);for(let _0x2a895e=0x0;_0x2a895e<_0x2e7e5d['length']&&_0x2a895e<_0x6a3fe8['length'];_0x2a895e++){const _0x13d25d=Ge(_0x2e7e5d[_0x2a895e],_0x6a3fe8[_0x2a895e]);if(_0x13d25d!==0x0)return _0x13d25d;}return _0x2e7e5d['length']===_0x6a3fe8['length']?0x0:_0x2e7e5d['length']<_0x6a3fe8['length']?-0x1:0x1;}function Ki(_0x3777f6,_0x32f6e1){if(Ce(_0x3777f6)!==Ce(_0x32f6e1))return!0x1;for(let _0x32debf=_0x3777f6['pieceNum_'],_0x3f4b83=_0x32f6e1['pieceNum_'];_0x32debf<=_0x3777f6['pieces_']['length'];_0x32debf++,_0x3f4b83++)if(_0x3777f6['pieces_'][_0x32debf]!==_0x32f6e1['pieces_'][_0x3f4b83])return!0x1;return!0x0;}function G(_0x35101e,_0x204343){let _0x410b3a=_0x35101e['pieceNum_'],_0x426d5c=_0x204343['pieceNum_'];if(Ce(_0x35101e)>Ce(_0x204343))return!0x1;for(;_0x410b3a<_0x35101e['pieces_']['length'];){if(_0x35101e['pieces_'][_0x410b3a]!==_0x204343['pieces_'][_0x426d5c])return!0x1;++_0x410b3a,++_0x426d5c;}return!0x0;}class Ah{constructor(_0x33a49e,_0x2032b5){this['errorPrefix_']=_0x2032b5,this['parts_']=Dt(_0x33a49e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x31445a=0x0;_0x31445a<this['parts_']['length'];_0x31445a++)this['byteLength_']+=Ln(this['parts_'][_0x31445a]);Ao(this);}}function kh(_0x22ad77,_0x4f29df){_0x22ad77['parts_']['length']>0x0&&(_0x22ad77['byteLength_']+=0x1),_0x22ad77['parts_']['push'](_0x4f29df),_0x22ad77['byteLength_']+=Ln(_0x4f29df),Ao(_0x22ad77);}function Nh(_0x379b9e){const _0x444ece=_0x379b9e['parts_']['pop']();_0x379b9e['byteLength_']-=Ln(_0x444ece),_0x379b9e['parts_']['length']>0x0&&(_0x379b9e['byteLength_']-=0x1);}function Ao(_0x54b39f){if(_0x54b39f['byteLength_']>Zs)throw new Error(_0x54b39f['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x54b39f['byteLength_']+').');if(_0x54b39f['parts_']['length']>Xs)throw new Error(_0x54b39f['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x54b39f));}function Pe(_0x502e12){return _0x502e12['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x502e12['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x48d527,_0x3994c7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3994c7='visibilitychange',_0x48d527='hidden'):typeof document['mozHidden']<'u'?(_0x3994c7='mozvisibilitychange',_0x48d527='mozHidden'):typeof document['msHidden']<'u'?(_0x3994c7='msvisibilitychange',_0x48d527='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3994c7='webkitvisibilitychange',_0x48d527='webkitHidden')),this['visible_']=!0x0,_0x3994c7&&document['addEventListener'](_0x3994c7,()=>{const _0x415497=!document[_0x48d527];_0x415497!==this['visible_']&&(this['visible_']=_0x415497,this['trigger']('visible',_0x415497));},!0x1);}['getInitialEvent'](_0x318fd3){return f(_0x318fd3==='visible','Unknown\x20event\x20type:\x20'+_0x318fd3),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3e4365,_0x17ff40,_0xa619b2,_0x502dd8,_0x472826,_0x40617f,_0x5aa8d5,_0x49958b){if(super(),this['repoInfo_']=_0x3e4365,this['applicationId_']=_0x17ff40,this['onDataUpdate_']=_0xa619b2,this['onConnectStatus_']=_0x502dd8,this['onServerInfoUpdate_']=_0x472826,this['authTokenProvider_']=_0x40617f,this['appCheckTokenProvider_']=_0x5aa8d5,this['authOverride_']=_0x49958b,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x49958b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3e4365['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x23a064,_0x57aee8,_0x2faab0){const _0x56be9e=++this['requestNumber_'],_0x4452c8={'r':_0x56be9e,'a':_0x23a064,'b':_0x57aee8};this['log_'](O(_0x4452c8)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4452c8),_0x2faab0&&(this['requestCBHash_'][_0x56be9e]=_0x2faab0);}['get'](_0x54df0c){this['initConnection_']();const _0x260ef9=new H(),_0x133c87={'action':'g','request':{'p':_0x54df0c['_path']['toString'](),'q':_0x54df0c['_queryObject']},'onComplete':_0x37117a=>{const _0x324eb3=_0x37117a['d'];_0x37117a['s']==='ok'?_0x260ef9['resolve'](_0x324eb3):_0x260ef9['reject'](_0x324eb3);}};this['outstandingGets_']['push'](_0x133c87),this['outstandingGetCount_']++;const _0x36a83a=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x36a83a),_0x260ef9['promise'];}['listen'](_0x33f005,_0x542fd3,_0x462463,_0x4a2b16){this['initConnection_']();const _0x16f27c=_0x33f005['_queryIdentifier'],_0x44f281=_0x33f005['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x44f281+'\x20'+_0x16f27c),this['listens']['has'](_0x44f281)||this['listens']['set'](_0x44f281,new Map()),f(_0x33f005['_queryParams']['isDefault']()||!_0x33f005['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x44f281)['has'](_0x16f27c),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x25ae08={'onComplete':_0x4a2b16,'hashFn':_0x542fd3,'query':_0x33f005,'tag':_0x462463};this['listens']['get'](_0x44f281)['set'](_0x16f27c,_0x25ae08),this['connected_']&&this['sendListen_'](_0x25ae08);}['sendGet_'](_0x27a940){const _0x1f788b=this['outstandingGets_'][_0x27a940];this['sendRequest']('g',_0x1f788b['request'],_0x119144=>{delete this['outstandingGets_'][_0x27a940],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1f788b['onComplete']&&_0x1f788b['onComplete'](_0x119144);});}['sendListen_'](_0x4e283e){const _0x569fc8=_0x4e283e['query'],_0x44a08b=_0x569fc8['_path']['toString'](),_0x5e5033=_0x569fc8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x44a08b+'\x20for\x20'+_0x5e5033);const _0x4399bf={'p':_0x44a08b},_0x27804b='q';_0x4e283e['tag']&&(_0x4399bf['q']=_0x569fc8['_queryObject'],_0x4399bf['t']=_0x4e283e['tag']),_0x4399bf['h']=_0x4e283e['hashFn'](),this['sendRequest'](_0x27804b,_0x4399bf,_0x1b95c3=>{const _0x489b75=_0x1b95c3['d'],_0x496ba5=_0x1b95c3['s'];se['warnOnListenWarnings_'](_0x489b75,_0x569fc8),(this['listens']['get'](_0x44a08b)&&this['listens']['get'](_0x44a08b)['get'](_0x5e5033))===_0x4e283e&&(this['log_']('listen\x20response',_0x1b95c3),_0x496ba5!=='ok'&&this['removeListen_'](_0x44a08b,_0x5e5033),_0x4e283e['onComplete']&&_0x4e283e['onComplete'](_0x496ba5,_0x489b75));});}static['warnOnListenWarnings_'](_0x2de078,_0x5a3604){if(_0x2de078&&typeof _0x2de078=='object'&&Q(_0x2de078,'w')){const _0x1183d8=Me(_0x2de078,'w');if(Array['isArray'](_0x1183d8)&&~_0x1183d8['indexOf']('no_index')){const _0x9cc76e='\x22.indexOn\x22:\x20\x22'+_0x5a3604['_queryParams']['getIndex']()['toString']()+'\x22',_0x913086=_0x5a3604['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x9cc76e+'\x20at\x20'+_0x913086+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3f29e4){this['authToken_']=_0x3f29e4,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3f29e4);}['reduceReconnectDelayIfAdminCredential_'](_0x334554){(_0x334554&&_0x334554['length']===0x28||wc(_0x334554))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2f19a6){this['appCheckToken_']=_0x2f19a6,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x55d6ea=this['authToken_'],_0x5eff5c=Ic(_0x55d6ea)?'auth':'gauth',_0x2488af={'cred':_0x55d6ea};this['authOverride_']===null?_0x2488af['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x2488af['authvar']=this['authOverride_']),this['sendRequest'](_0x5eff5c,_0x2488af,_0x422437=>{const _0x2837e0=_0x422437['s'],_0x2fa12b=_0x422437['d']||'error';this['authToken_']===_0x55d6ea&&(_0x2837e0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2837e0,_0x2fa12b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x32e98d=>{const _0x4efa48=_0x32e98d['s'],_0x5849f3=_0x32e98d['d']||'error';_0x4efa48==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4efa48,_0x5849f3);});}['unlisten'](_0x3c63cd,_0x34edcb){const _0x167ad1=_0x3c63cd['_path']['toString'](),_0x295549=_0x3c63cd['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x167ad1+'\x20'+_0x295549),f(_0x3c63cd['_queryParams']['isDefault']()||!_0x3c63cd['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x167ad1,_0x295549)&&this['connected_']&&this['sendUnlisten_'](_0x167ad1,_0x295549,_0x3c63cd['_queryObject'],_0x34edcb);}['sendUnlisten_'](_0x31a9ec,_0x5eafd3,_0x3ca9cc,_0x3e5f0e){this['log_']('Unlisten\x20on\x20'+_0x31a9ec+'\x20for\x20'+_0x5eafd3);const _0x587567={'p':_0x31a9ec},_0x4e21a9='n';_0x3e5f0e&&(_0x587567['q']=_0x3ca9cc,_0x587567['t']=_0x3e5f0e),this['sendRequest'](_0x4e21a9,_0x587567);}['onDisconnectPut'](_0x28fbd0,_0x5a2d7d,_0x4e414b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x28fbd0,_0x5a2d7d,_0x4e414b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x28fbd0,'action':'o','data':_0x5a2d7d,'onComplete':_0x4e414b});}['onDisconnectMerge'](_0x55c71f,_0x2b981a,_0x490321){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x55c71f,_0x2b981a,_0x490321):this['onDisconnectRequestQueue_']['push']({'pathString':_0x55c71f,'action':'om','data':_0x2b981a,'onComplete':_0x490321});}['onDisconnectCancel'](_0x2c6427,_0x37bc2f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2c6427,null,_0x37bc2f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2c6427,'action':'oc','data':null,'onComplete':_0x37bc2f});}['sendOnDisconnect_'](_0x3c53b5,_0x314a05,_0x18d0d2,_0x1a552f){const _0x20882b={'p':_0x314a05,'d':_0x18d0d2};this['log_']('onDisconnect\x20'+_0x3c53b5,_0x20882b),this['sendRequest'](_0x3c53b5,_0x20882b,_0x554832=>{_0x1a552f&&setTimeout(()=>{_0x1a552f(_0x554832['s'],_0x554832['d']);},Math['floor'](0x0));});}['put'](_0x5c1793,_0x32929d,_0x51419a,_0x844a9c){this['putInternal']('p',_0x5c1793,_0x32929d,_0x51419a,_0x844a9c);}['merge'](_0x36ac36,_0x16797e,_0x310eda,_0x2f63f2){this['putInternal']('m',_0x36ac36,_0x16797e,_0x310eda,_0x2f63f2);}['putInternal'](_0x1d34bc,_0x4a74a6,_0x505539,_0x2b59a3,_0xbdee8b){this['initConnection_']();const _0x216fc9={'p':_0x4a74a6,'d':_0x505539};_0xbdee8b!==void 0x0&&(_0x216fc9['h']=_0xbdee8b),this['outstandingPuts_']['push']({'action':_0x1d34bc,'request':_0x216fc9,'onComplete':_0x2b59a3}),this['outstandingPutCount_']++;const _0x265c04=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x265c04):this['log_']('Buffering\x20put:\x20'+_0x4a74a6);}['sendPut_'](_0x37918e){const _0x586b0e=this['outstandingPuts_'][_0x37918e]['action'],_0x15d29b=this['outstandingPuts_'][_0x37918e]['request'],_0x3ca344=this['outstandingPuts_'][_0x37918e]['onComplete'];this['outstandingPuts_'][_0x37918e]['queued']=this['connected_'],this['sendRequest'](_0x586b0e,_0x15d29b,_0x1d9eb1=>{this['log_'](_0x586b0e+'\x20response',_0x1d9eb1),delete this['outstandingPuts_'][_0x37918e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3ca344&&_0x3ca344(_0x1d9eb1['s'],_0x1d9eb1['d']);});}['reportStats'](_0x2802e1){if(this['connected_']){const _0x176857={'c':_0x2802e1};this['log_']('reportStats',_0x176857),this['sendRequest']('s',_0x176857,_0x202887=>{if(_0x202887['s']!=='ok'){const _0x93493e=_0x202887['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x93493e);}});}}['onDataMessage_'](_0x18646d){if('r'in _0x18646d){this['log_']('from\x20server:\x20'+O(_0x18646d));const _0x1cf9f4=_0x18646d['r'],_0x29fb3a=this['requestCBHash_'][_0x1cf9f4];_0x29fb3a&&(delete this['requestCBHash_'][_0x1cf9f4],_0x29fb3a(_0x18646d['b']));}else{if('error'in _0x18646d)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x18646d['error'];'a'in _0x18646d&&this['onDataPush_'](_0x18646d['a'],_0x18646d['b']);}}['onDataPush_'](_0x3ad160,_0x1ce60b){this['log_']('handleServerMessage',_0x3ad160,_0x1ce60b),_0x3ad160==='d'?this['onDataUpdate_'](_0x1ce60b['p'],_0x1ce60b['d'],!0x1,_0x1ce60b['t']):_0x3ad160==='m'?this['onDataUpdate_'](_0x1ce60b['p'],_0x1ce60b['d'],!0x0,_0x1ce60b['t']):_0x3ad160==='c'?this['onListenRevoked_'](_0x1ce60b['p'],_0x1ce60b['q']):_0x3ad160==='ac'?this['onAuthRevoked_'](_0x1ce60b['s'],_0x1ce60b['d']):_0x3ad160==='apc'?this['onAppCheckRevoked_'](_0x1ce60b['s'],_0x1ce60b['d']):_0x3ad160==='sd'?this['onSecurityDebugPacket_'](_0x1ce60b):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3ad160)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5c6822,_0x147f55){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5c6822),this['lastSessionId']=_0x147f55,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x57d974){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x57d974));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x35eee6){_0x35eee6&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x35eee6;}['onOnline_'](_0x56439a){_0x56439a?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4449d3=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3f7e7e=Math['max'](0x0,this['reconnectDelay_']-_0x4449d3);_0x3f7e7e=Math['random']()*_0x3f7e7e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3f7e7e+'ms'),this['scheduleConnect_'](_0x3f7e7e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x48d674=this['onDataMessage_']['bind'](this),_0x45a9f6=this['onReady_']['bind'](this),_0x4a524b=this['onRealtimeDisconnect_']['bind'](this),_0x37fabb=this['id']+':'+se['nextConnectionId_']++,_0xd6404e=this['lastSessionId'];let _0x3a5590=!0x1,_0x2bb0bf=null;const _0x331339=function(){_0x2bb0bf?_0x2bb0bf['close']():(_0x3a5590=!0x0,_0x4a524b());},_0x34a001=function(_0x2df1a0){f(_0x2bb0bf,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2bb0bf['sendRequest'](_0x2df1a0);};this['realtime_']={'close':_0x331339,'sendRequest':_0x34a001};const _0x2d1c3e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x46d521,_0x42f3d0]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2d1c3e),this['appCheckTokenProvider_']['getToken'](_0x2d1c3e)]);_0x3a5590?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x46d521&&_0x46d521['accessToken'],this['appCheckToken_']=_0x42f3d0&&_0x42f3d0['token'],_0x2bb0bf=new Sh(_0x37fabb,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x48d674,_0x45a9f6,_0x4a524b,_0x1b8086=>{U(_0x1b8086+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xd6404e));}catch(_0x2409a8){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2409a8),_0x3a5590||(this['repoInfo_']['nodeAdmin']&&U(_0x2409a8),_0x331339());}}}['interrupt'](_0x3a6718){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3a6718),this['interruptReasons_'][_0x3a6718]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x326042){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x326042),delete this['interruptReasons_'][_0x326042],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x257e3d){const _0x54256=_0x257e3d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x54256});}['cancelSentTransactions_'](){for(let _0x229db2=0x0;_0x229db2<this['outstandingPuts_']['length'];_0x229db2++){const _0x454292=this['outstandingPuts_'][_0x229db2];_0x454292&&'h'in _0x454292['request']&&_0x454292['queued']&&(_0x454292['onComplete']&&_0x454292['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x229db2],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x112bb8,_0x6783b){let _0x513380;_0x6783b?_0x513380=_0x6783b['map'](_0xc3a6d1=>$i(_0xc3a6d1))['join']('$'):_0x513380='default';const _0x2161b6=this['removeListen_'](_0x112bb8,_0x513380);_0x2161b6&&_0x2161b6['onComplete']&&_0x2161b6['onComplete']('permission_denied');}['removeListen_'](_0x11ead2,_0x79449c){const _0x5357b9=new C(_0x11ead2)['toString']();let _0x36091f;if(this['listens']['has'](_0x5357b9)){const _0x25272d=this['listens']['get'](_0x5357b9);_0x36091f=_0x25272d['get'](_0x79449c),_0x25272d['delete'](_0x79449c),_0x25272d['size']===0x0&&this['listens']['delete'](_0x5357b9);}else _0x36091f=void 0x0;return _0x36091f;}['onAuthRevoked_'](_0x8cfa38,_0x37d44b){L('Auth\x20token\x20revoked:\x20'+_0x8cfa38+'/'+_0x37d44b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x8cfa38==='invalid_token'||_0x8cfa38==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x29e69b,_0x1ca711){L('App\x20check\x20token\x20revoked:\x20'+_0x29e69b+'/'+_0x1ca711),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x29e69b==='invalid_token'||_0x29e69b==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4f3236){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4f3236):'msg'in _0x4f3236&&console['log']('FIREBASE:\x20'+_0x4f3236['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x12938e of this['listens']['values']())for(const _0x428499 of _0x12938e['values']())this['sendListen_'](_0x428499);for(let _0x5a8c02=0x0;_0x5a8c02<this['outstandingPuts_']['length'];_0x5a8c02++)this['outstandingPuts_'][_0x5a8c02]&&this['sendPut_'](_0x5a8c02);for(;this['onDisconnectRequestQueue_']['length'];){const _0x27be6a=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x27be6a['action'],_0x27be6a['pathString'],_0x27be6a['data'],_0x27be6a['onComplete']);}for(let _0x58c185=0x0;_0x58c185<this['outstandingGets_']['length'];_0x58c185++)this['outstandingGets_'][_0x58c185]&&this['sendGet_'](_0x58c185);}['sendConnectStats_'](){const _0xff452={};let _0x20c6ce='js';_0xff452['sdk.'+_0x20c6ce+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xff452['framework.cordova']=0x1:Kr()&&(_0xff452['framework.reactnative']=0x1),this['reportStats'](_0xff452);}['shouldReconnect_'](){const _0x3c5ca3=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x3c5ca3;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3de172,_0x3bf0f9){this['name']=_0x3de172,this['node']=_0x3bf0f9;}static['Wrap'](_0x17d9d1,_0xe5f159){return new E(_0x17d9d1,_0xe5f159);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4e856e,_0x4386c6){const _0xd3395c=new E(Ue,_0x4e856e),_0x19c6ea=new E(Ue,_0x4386c6);return this['compare'](_0xd3395c,_0x19c6ea)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x290b9a){sn=_0x290b9a;}['compare'](_0x315cfc,_0x15a90a){return Ge(_0x315cfc['name'],_0x15a90a['name']);}['isDefinedOn'](_0x593a1b){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x33cbe9,_0x3a54b4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x19b2b9,_0x4f1b86){return f(typeof _0x19b2b9=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x19b2b9,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x45c437,_0x1cb0a9,_0x365ceb,_0x38d237,_0x3eca74=null){this['isReverse_']=_0x38d237,this['resultGenerator_']=_0x3eca74,this['nodeStack_']=[];let _0x47c1eb=0x1;for(;!_0x45c437['isEmpty']();)if(_0x45c437=_0x45c437,_0x47c1eb=_0x1cb0a9?_0x365ceb(_0x45c437['key'],_0x1cb0a9):0x1,_0x38d237&&(_0x47c1eb*=-0x1),_0x47c1eb<0x0)this['isReverse_']?_0x45c437=_0x45c437['left']:_0x45c437=_0x45c437['right'];else{if(_0x47c1eb===0x0){this['nodeStack_']['push'](_0x45c437);break;}else this['nodeStack_']['push'](_0x45c437),this['isReverse_']?_0x45c437=_0x45c437['right']:_0x45c437=_0x45c437['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3df529=this['nodeStack_']['pop'](),_0x39349c;if(this['resultGenerator_']?_0x39349c=this['resultGenerator_'](_0x3df529['key'],_0x3df529['value']):_0x39349c={'key':_0x3df529['key'],'value':_0x3df529['value']},this['isReverse_']){for(_0x3df529=_0x3df529['left'];!_0x3df529['isEmpty']();)this['nodeStack_']['push'](_0x3df529),_0x3df529=_0x3df529['right'];}else{for(_0x3df529=_0x3df529['right'];!_0x3df529['isEmpty']();)this['nodeStack_']['push'](_0x3df529),_0x3df529=_0x3df529['left'];}return _0x39349c;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x28bebf=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x28bebf['key'],_0x28bebf['value']):{'key':_0x28bebf['key'],'value':_0x28bebf['value']};}}class M{constructor(_0x2e4811,_0x4dc592,_0x13314b,_0x5be3c8,_0x30da76){this['key']=_0x2e4811,this['value']=_0x4dc592,this['color']=_0x13314b??M['RED'],this['left']=_0x5be3c8??B['EMPTY_NODE'],this['right']=_0x30da76??B['EMPTY_NODE'];}['copy'](_0x22b7d6,_0x368c36,_0x381efa,_0x3b4bb7,_0xc05f2a){return new M(_0x22b7d6??this['key'],_0x368c36??this['value'],_0x381efa??this['color'],_0x3b4bb7??this['left'],_0xc05f2a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5a0090){return this['left']['inorderTraversal'](_0x5a0090)||!!_0x5a0090(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5a0090);}['reverseTraversal'](_0x1bcf6e){return this['right']['reverseTraversal'](_0x1bcf6e)||_0x1bcf6e(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1bcf6e);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1a98ef,_0x493058,_0x23e4ee){let _0x2e8e7c=this;const _0x5a6897=_0x23e4ee(_0x1a98ef,_0x2e8e7c['key']);return _0x5a6897<0x0?_0x2e8e7c=_0x2e8e7c['copy'](null,null,null,_0x2e8e7c['left']['insert'](_0x1a98ef,_0x493058,_0x23e4ee),null):_0x5a6897===0x0?_0x2e8e7c=_0x2e8e7c['copy'](null,_0x493058,null,null,null):_0x2e8e7c=_0x2e8e7c['copy'](null,null,null,null,_0x2e8e7c['right']['insert'](_0x1a98ef,_0x493058,_0x23e4ee)),_0x2e8e7c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2879e5=this;return!_0x2879e5['left']['isRed_']()&&!_0x2879e5['left']['left']['isRed_']()&&(_0x2879e5=_0x2879e5['moveRedLeft_']()),_0x2879e5=_0x2879e5['copy'](null,null,null,_0x2879e5['left']['removeMin_'](),null),_0x2879e5['fixUp_']();}['remove'](_0x17eb6d,_0x3b85ca){let _0x590140,_0x3c34a4;if(_0x590140=this,_0x3b85ca(_0x17eb6d,_0x590140['key'])<0x0)!_0x590140['left']['isEmpty']()&&!_0x590140['left']['isRed_']()&&!_0x590140['left']['left']['isRed_']()&&(_0x590140=_0x590140['moveRedLeft_']()),_0x590140=_0x590140['copy'](null,null,null,_0x590140['left']['remove'](_0x17eb6d,_0x3b85ca),null);else{if(_0x590140['left']['isRed_']()&&(_0x590140=_0x590140['rotateRight_']()),!_0x590140['right']['isEmpty']()&&!_0x590140['right']['isRed_']()&&!_0x590140['right']['left']['isRed_']()&&(_0x590140=_0x590140['moveRedRight_']()),_0x3b85ca(_0x17eb6d,_0x590140['key'])===0x0){if(_0x590140['right']['isEmpty']())return B['EMPTY_NODE'];_0x3c34a4=_0x590140['right']['min_'](),_0x590140=_0x590140['copy'](_0x3c34a4['key'],_0x3c34a4['value'],null,null,_0x590140['right']['removeMin_']());}_0x590140=_0x590140['copy'](null,null,null,null,_0x590140['right']['remove'](_0x17eb6d,_0x3b85ca));}return _0x590140['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2a60b7=this;return _0x2a60b7['right']['isRed_']()&&!_0x2a60b7['left']['isRed_']()&&(_0x2a60b7=_0x2a60b7['rotateLeft_']()),_0x2a60b7['left']['isRed_']()&&_0x2a60b7['left']['left']['isRed_']()&&(_0x2a60b7=_0x2a60b7['rotateRight_']()),_0x2a60b7['left']['isRed_']()&&_0x2a60b7['right']['isRed_']()&&(_0x2a60b7=_0x2a60b7['colorFlip_']()),_0x2a60b7;}['moveRedLeft_'](){let _0x588959=this['colorFlip_']();return _0x588959['right']['left']['isRed_']()&&(_0x588959=_0x588959['copy'](null,null,null,null,_0x588959['right']['rotateRight_']()),_0x588959=_0x588959['rotateLeft_'](),_0x588959=_0x588959['colorFlip_']()),_0x588959;}['moveRedRight_'](){let _0x3b5fe1=this['colorFlip_']();return _0x3b5fe1['left']['left']['isRed_']()&&(_0x3b5fe1=_0x3b5fe1['rotateRight_'](),_0x3b5fe1=_0x3b5fe1['colorFlip_']()),_0x3b5fe1;}['rotateLeft_'](){const _0x1beae8=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1beae8,null);}['rotateRight_'](){const _0x246fae=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x246fae);}['colorFlip_'](){const _0x575396=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x11389e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x575396,_0x11389e);}['checkMaxDepth_'](){const _0x1fd109=this['check_']();return Math['pow'](0x2,_0x1fd109)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4c63b1=this['left']['check_']();if(_0x4c63b1!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4c63b1+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4dd413,_0xcb10c4,_0x415229,_0x63e67d,_0x6ed6f8){return this;}['insert'](_0x269663,_0x153f53,_0x44a432){return new M(_0x269663,_0x153f53,null);}['remove'](_0x59da81,_0xba3602){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x34c042){return!0x1;}['reverseTraversal'](_0x5ca4a9){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5038ec,_0x477654=B['EMPTY_NODE']){this['comparator_']=_0x5038ec,this['root_']=_0x477654;}['insert'](_0x4bd100,_0x212201){return new B(this['comparator_'],this['root_']['insert'](_0x4bd100,_0x212201,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1219a6){return new B(this['comparator_'],this['root_']['remove'](_0x1219a6,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x535fbd){let _0x2f1940,_0x589684=this['root_'];for(;!_0x589684['isEmpty']();){if(_0x2f1940=this['comparator_'](_0x535fbd,_0x589684['key']),_0x2f1940===0x0)return _0x589684['value'];_0x2f1940<0x0?_0x589684=_0x589684['left']:_0x2f1940>0x0&&(_0x589684=_0x589684['right']);}return null;}['getPredecessorKey'](_0x3bf6c8){let _0x38bfd9,_0x53216f=this['root_'],_0x1bbc60=null;for(;!_0x53216f['isEmpty']();)if(_0x38bfd9=this['comparator_'](_0x3bf6c8,_0x53216f['key']),_0x38bfd9===0x0){if(_0x53216f['left']['isEmpty']())return _0x1bbc60?_0x1bbc60['key']:null;for(_0x53216f=_0x53216f['left'];!_0x53216f['right']['isEmpty']();)_0x53216f=_0x53216f['right'];return _0x53216f['key'];}else _0x38bfd9<0x0?_0x53216f=_0x53216f['left']:_0x38bfd9>0x0&&(_0x1bbc60=_0x53216f,_0x53216f=_0x53216f['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2d98c4){return this['root_']['inorderTraversal'](_0x2d98c4);}['reverseTraversal'](_0xe8515b){return this['root_']['reverseTraversal'](_0xe8515b);}['getIterator'](_0x399767){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x399767);}['getIteratorFrom'](_0x4c9431,_0x5813b3){return new rn(this['root_'],_0x4c9431,this['comparator_'],!0x1,_0x5813b3);}['getReverseIteratorFrom'](_0x21c50d,_0x114a9e){return new rn(this['root_'],_0x21c50d,this['comparator_'],!0x0,_0x114a9e);}['getReverseIterator'](_0x13d9eb){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x13d9eb);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0xb440ae,_0x1c0166){return Ge(_0xb440ae['name'],_0x1c0166['name']);}function Qi(_0x23d306,_0x28eeec){return Ge(_0x23d306,_0x28eeec);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x17d112){Ci=_0x17d112;}const No=function(_0x23449d){return typeof _0x23449d=='number'?'number:'+ao(_0x23449d):'string:'+_0x23449d;},Po=function(_0x570d84){if(_0x570d84['isLeafNode']()){const _0x8da292=_0x570d84['val']();f(typeof _0x8da292=='string'||typeof _0x8da292=='number'||typeof _0x8da292=='object'&&Q(_0x8da292,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x570d84===Ci||_0x570d84['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x570d84===Ci||_0x570d84['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0xea749d){nr=_0xea749d;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x3d41ec,_0x3192ce=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3d41ec,this['priorityNode_']=_0x3192ce,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x154c2e){return new D(this['value_'],_0x154c2e);}['getImmediateChild'](_0x3dab5e){return _0x3dab5e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x326230){return v(_0x326230)?this:y(_0x326230)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x30e8b6,_0x562cc1){return null;}['updateImmediateChild'](_0x25d265,_0x21fd85){return _0x25d265==='.priority'?this['updatePriority'](_0x21fd85):_0x21fd85['isEmpty']()&&_0x25d265!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x25d265,_0x21fd85)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3a5215,_0x17be37){const _0x2e5af9=y(_0x3a5215);return _0x2e5af9===null?_0x17be37:_0x17be37['isEmpty']()&&_0x2e5af9!=='.priority'?this:(f(_0x2e5af9!=='.priority'||Ce(_0x3a5215)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2e5af9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3a5215),_0x17be37)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4facc9,_0x5b24a9){return!0x1;}['val'](_0x2291b9){return _0x2291b9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2cdfcd='';this['priorityNode_']['isEmpty']()||(_0x2cdfcd+='priority:'+No(this['priorityNode_']['val']())+':');const _0x5d40b5=typeof this['value_'];_0x2cdfcd+=_0x5d40b5+':',_0x5d40b5==='number'?_0x2cdfcd+=ao(this['value_']):_0x2cdfcd+=this['value_'],this['lazyHash_']=ro(_0x2cdfcd);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x956635){return _0x956635===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x956635 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x956635['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x956635));}['compareToLeafNode_'](_0x79864b){const _0x5b8085=typeof _0x79864b['value_'],_0x157d0a=typeof this['value_'],_0x1da8fb=D['VALUE_TYPE_ORDER']['indexOf'](_0x5b8085),_0x5d2c25=D['VALUE_TYPE_ORDER']['indexOf'](_0x157d0a);return f(_0x1da8fb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5b8085),f(_0x5d2c25>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x157d0a),_0x1da8fb===_0x5d2c25?_0x157d0a==='object'?0x0:this['value_']<_0x79864b['value_']?-0x1:this['value_']===_0x79864b['value_']?0x0:0x1:_0x5d2c25-_0x1da8fb;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1b97e4){if(_0x1b97e4===this)return!0x0;if(_0x1b97e4['isLeafNode']()){const _0x4102ae=_0x1b97e4;return this['value_']===_0x4102ae['value_']&&this['priorityNode_']['equals'](_0x4102ae['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0xb95031){Oo=_0xb95031;}function Wh(_0xb97bc){Do=_0xb97bc;}class Bh extends Fn{['compare'](_0x52eab6,_0x5d80a2){const _0x355bcf=_0x52eab6['node']['getPriority'](),_0x547b9e=_0x5d80a2['node']['getPriority'](),_0x1d5a30=_0x355bcf['compareTo'](_0x547b9e);return _0x1d5a30===0x0?Ge(_0x52eab6['name'],_0x5d80a2['name']):_0x1d5a30;}['isDefinedOn'](_0x893745){return!_0x893745['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x34fddd,_0x47bffb){return!_0x34fddd['getPriority']()['equals'](_0x47bffb['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x24f43d,_0x45c1f9){const _0x7bfd9=Oo(_0x24f43d);return new E(_0x45c1f9,new D('[PRIORITY-POST]',_0x7bfd9));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x81a423){const _0x13dc44=_0x1607f7=>parseInt(Math['log'](_0x1607f7)/Vh,0xa),_0x5a9c68=_0xd24b58=>parseInt(Array(_0xd24b58+0x1)['join']('1'),0x2);this['count']=_0x13dc44(_0x81a423+0x1),this['current_']=this['count']-0x1;const _0x2018d5=_0x5a9c68(this['count']);this['bits_']=_0x81a423+0x1&_0x2018d5;}['nextBitIsOne'](){const _0x3b8304=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3b8304;}}const yn=function(_0x131809,_0x3adbbe,_0x50d211,_0x43f4ff){_0x131809['sort'](_0x3adbbe);const _0x34c2fb=function(_0x33ad9c,_0x1915e0){const _0x968616=_0x1915e0-_0x33ad9c;let _0x5c851b,_0x258e05;if(_0x968616===0x0)return null;if(_0x968616===0x1)return _0x5c851b=_0x131809[_0x33ad9c],_0x258e05=_0x50d211?_0x50d211(_0x5c851b):_0x5c851b,new M(_0x258e05,_0x5c851b['node'],M['BLACK'],null,null);{const _0xc44e80=parseInt(_0x968616/0x2,0xa)+_0x33ad9c,_0x5aea9b=_0x34c2fb(_0x33ad9c,_0xc44e80),_0x55ef0c=_0x34c2fb(_0xc44e80+0x1,_0x1915e0);return _0x5c851b=_0x131809[_0xc44e80],_0x258e05=_0x50d211?_0x50d211(_0x5c851b):_0x5c851b,new M(_0x258e05,_0x5c851b['node'],M['BLACK'],_0x5aea9b,_0x55ef0c);}},_0x3ce230=function(_0x12c76c){let _0x1eab3f=null,_0x40882f=null,_0x516443=_0x131809['length'];const _0x4813c7=function(_0x91cb62,_0x4db2dd){const _0x494cae=_0x516443-_0x91cb62,_0x13998c=_0x516443;_0x516443-=_0x91cb62;const _0x4eae68=_0x34c2fb(_0x494cae+0x1,_0x13998c),_0x4d7f61=_0x131809[_0x494cae],_0x2e0e42=_0x50d211?_0x50d211(_0x4d7f61):_0x4d7f61;_0x4e7287(new M(_0x2e0e42,_0x4d7f61['node'],_0x4db2dd,null,_0x4eae68));},_0x4e7287=function(_0x188274){_0x1eab3f?(_0x1eab3f['left']=_0x188274,_0x1eab3f=_0x188274):(_0x40882f=_0x188274,_0x1eab3f=_0x188274);};for(let _0x2ffe18=0x0;_0x2ffe18<_0x12c76c['count'];++_0x2ffe18){const _0x30b6b1=_0x12c76c['nextBitIsOne'](),_0x34b386=Math['pow'](0x2,_0x12c76c['count']-(_0x2ffe18+0x1));_0x30b6b1?_0x4813c7(_0x34b386,M['BLACK']):(_0x4813c7(_0x34b386,M['BLACK']),_0x4813c7(_0x34b386,M['RED']));}return _0x40882f;},_0x548fb8=new Hh(_0x131809['length']),_0x16a9bd=_0x3ce230(_0x548fb8);return new B(_0x43f4ff||_0x3adbbe,_0x16a9bd);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3a09c2,_0x8143e8){this['indexes_']=_0x3a09c2,this['indexSet_']=_0x8143e8;}['get'](_0x5aad90){const _0x3e27af=Me(this['indexes_'],_0x5aad90);if(!_0x3e27af)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5aad90);return _0x3e27af instanceof B?_0x3e27af:null;}['hasIndex'](_0x54bf30){return Q(this['indexSet_'],_0x54bf30['toString']());}['addIndex'](_0x1fe891,_0x55476b){f(_0x1fe891!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2ae03b=[];let _0x2554e1=!0x1;const _0x1096e8=_0x55476b['getIterator'](E['Wrap']);let _0xb1a8cd=_0x1096e8['getNext']();for(;_0xb1a8cd;)_0x2554e1=_0x2554e1||_0x1fe891['isDefinedOn'](_0xb1a8cd['node']),_0x2ae03b['push'](_0xb1a8cd),_0xb1a8cd=_0x1096e8['getNext']();let _0x34875c;_0x2554e1?_0x34875c=yn(_0x2ae03b,_0x1fe891['getCompare']()):_0x34875c=Qe;const _0x1753d9=_0x1fe891['toString'](),_0x44dbcd={...this['indexSet_']};_0x44dbcd[_0x1753d9]=_0x1fe891;const _0x52a0a5={...this['indexes_']};return _0x52a0a5[_0x1753d9]=_0x34875c,new te(_0x52a0a5,_0x44dbcd);}['addToIndexes'](_0xb198f6,_0x241c06){const _0x513c36=_n(this['indexes_'],(_0x25bd10,_0x18011a)=>{const _0x4b6b48=Me(this['indexSet_'],_0x18011a);if(f(_0x4b6b48,'Missing\x20index\x20implementation\x20for\x20'+_0x18011a),_0x25bd10===Qe){if(_0x4b6b48['isDefinedOn'](_0xb198f6['node'])){const _0x1d2a94=[],_0x764f86=_0x241c06['getIterator'](E['Wrap']);let _0xd053b6=_0x764f86['getNext']();for(;_0xd053b6;)_0xd053b6['name']!==_0xb198f6['name']&&_0x1d2a94['push'](_0xd053b6),_0xd053b6=_0x764f86['getNext']();return _0x1d2a94['push'](_0xb198f6),yn(_0x1d2a94,_0x4b6b48['getCompare']());}else return Qe;}else{const _0x5227a1=_0x241c06['get'](_0xb198f6['name']);let _0x16be6b=_0x25bd10;return _0x5227a1&&(_0x16be6b=_0x16be6b['remove'](new E(_0xb198f6['name'],_0x5227a1))),_0x16be6b['insert'](_0xb198f6,_0xb198f6['node']);}});return new te(_0x513c36,this['indexSet_']);}['removeFromIndexes'](_0x512766,_0x5747cf){const _0x26fae9=_n(this['indexes_'],_0x2846aa=>{if(_0x2846aa===Qe)return _0x2846aa;{const _0x1167c7=_0x5747cf['get'](_0x512766['name']);return _0x1167c7?_0x2846aa['remove'](new E(_0x512766['name'],_0x1167c7)):_0x2846aa;}});return new te(_0x26fae9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x22bae4,_0x1cad11,_0xf9de7e){this['children_']=_0x22bae4,this['priorityNode_']=_0x1cad11,this['indexMap_']=_0xf9de7e,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x17a6eb){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x17a6eb,this['indexMap_']);}['getImmediateChild'](_0x5bb002){if(_0x5bb002==='.priority')return this['getPriority']();{const _0x3548c3=this['children_']['get'](_0x5bb002);return _0x3548c3===null?Et:_0x3548c3;}}['getChild'](_0x2c89ab){const _0x374b39=y(_0x2c89ab);return _0x374b39===null?this:this['getImmediateChild'](_0x374b39)['getChild'](S(_0x2c89ab));}['hasChild'](_0x4116d6){return this['children_']['get'](_0x4116d6)!==null;}['updateImmediateChild'](_0x449a45,_0x5d1f9a){if(f(_0x5d1f9a,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x449a45==='.priority')return this['updatePriority'](_0x5d1f9a);{const _0x19268e=new E(_0x449a45,_0x5d1f9a);let _0x1bd243,_0x3612a3;_0x5d1f9a['isEmpty']()?(_0x1bd243=this['children_']['remove'](_0x449a45),_0x3612a3=this['indexMap_']['removeFromIndexes'](_0x19268e,this['children_'])):(_0x1bd243=this['children_']['insert'](_0x449a45,_0x5d1f9a),_0x3612a3=this['indexMap_']['addToIndexes'](_0x19268e,this['children_']));const _0x1508e6=_0x1bd243['isEmpty']()?Et:this['priorityNode_'];return new g(_0x1bd243,_0x1508e6,_0x3612a3);}}['updateChild'](_0x42d216,_0xecbde4){const _0x5b1051=y(_0x42d216);if(_0x5b1051===null)return _0xecbde4;{f(y(_0x42d216)!=='.priority'||Ce(_0x42d216)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x256eda=this['getImmediateChild'](_0x5b1051)['updateChild'](S(_0x42d216),_0xecbde4);return this['updateImmediateChild'](_0x5b1051,_0x256eda);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x102003){if(this['isEmpty']())return null;const _0x11b70c={};let _0x5d9c73=0x0,_0x1e17a5=0x0,_0x4f15a4=!0x0;if(this['forEachChild'](R,(_0x3140cd,_0x3149cb)=>{_0x11b70c[_0x3140cd]=_0x3149cb['val'](_0x102003),_0x5d9c73++,_0x4f15a4&&g['INTEGER_REGEXP_']['test'](_0x3140cd)?_0x1e17a5=Math['max'](_0x1e17a5,Number(_0x3140cd)):_0x4f15a4=!0x1;}),!_0x102003&&_0x4f15a4&&_0x1e17a5<0x2*_0x5d9c73){const _0x2ddfd1=[];for(const _0x263456 in _0x11b70c)_0x2ddfd1[_0x263456]=_0x11b70c[_0x263456];return _0x2ddfd1;}else return _0x102003&&!this['getPriority']()['isEmpty']()&&(_0x11b70c['.priority']=this['getPriority']()['val']()),_0x11b70c;}['hash'](){if(this['lazyHash_']===null){let _0x257b91='';this['getPriority']()['isEmpty']()||(_0x257b91+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xa7b47c,_0x2b45c2)=>{const _0x520500=_0x2b45c2['hash']();_0x520500!==''&&(_0x257b91+=':'+_0xa7b47c+':'+_0x520500);}),this['lazyHash_']=_0x257b91===''?'':ro(_0x257b91);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1051c5,_0x2511e0,_0x4efc2a){const _0x58e3cd=this['resolveIndex_'](_0x4efc2a);if(_0x58e3cd){const _0x5e8420=_0x58e3cd['getPredecessorKey'](new E(_0x1051c5,_0x2511e0));return _0x5e8420?_0x5e8420['name']:null;}else return this['children_']['getPredecessorKey'](_0x1051c5);}['getFirstChildName'](_0x532abe){const _0x5af6f2=this['resolveIndex_'](_0x532abe);if(_0x5af6f2){const _0x587de6=_0x5af6f2['minKey']();return _0x587de6&&_0x587de6['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x54a72c){const _0x15a805=this['getFirstChildName'](_0x54a72c);return _0x15a805?new E(_0x15a805,this['children_']['get'](_0x15a805)):null;}['getLastChildName'](_0x3d0ae9){const _0x3294b4=this['resolveIndex_'](_0x3d0ae9);if(_0x3294b4){const _0x50a06a=_0x3294b4['maxKey']();return _0x50a06a&&_0x50a06a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x17d123){const _0x53b786=this['getLastChildName'](_0x17d123);return _0x53b786?new E(_0x53b786,this['children_']['get'](_0x53b786)):null;}['forEachChild'](_0x4f9fa9,_0x244ebc){const _0x8c03ce=this['resolveIndex_'](_0x4f9fa9);return _0x8c03ce?_0x8c03ce['inorderTraversal'](_0x9cdcc9=>_0x244ebc(_0x9cdcc9['name'],_0x9cdcc9['node'])):this['children_']['inorderTraversal'](_0x244ebc);}['getIterator'](_0x5eacb0){return this['getIteratorFrom'](_0x5eacb0['minPost'](),_0x5eacb0);}['getIteratorFrom'](_0x5889dd,_0x46534c){const _0x3d446d=this['resolveIndex_'](_0x46534c);if(_0x3d446d)return _0x3d446d['getIteratorFrom'](_0x5889dd,_0x46df02=>_0x46df02);{const _0x2f4fb9=this['children_']['getIteratorFrom'](_0x5889dd['name'],E['Wrap']);let _0x3bbec5=_0x2f4fb9['peek']();for(;_0x3bbec5!=null&&_0x46534c['compare'](_0x3bbec5,_0x5889dd)<0x0;)_0x2f4fb9['getNext'](),_0x3bbec5=_0x2f4fb9['peek']();return _0x2f4fb9;}}['getReverseIterator'](_0x36ea72){return this['getReverseIteratorFrom'](_0x36ea72['maxPost'](),_0x36ea72);}['getReverseIteratorFrom'](_0x2e0d4f,_0x5abd78){const _0x4bca29=this['resolveIndex_'](_0x5abd78);if(_0x4bca29)return _0x4bca29['getReverseIteratorFrom'](_0x2e0d4f,_0x55e96b=>_0x55e96b);{const _0x8d7e1b=this['children_']['getReverseIteratorFrom'](_0x2e0d4f['name'],E['Wrap']);let _0x177302=_0x8d7e1b['peek']();for(;_0x177302!=null&&_0x5abd78['compare'](_0x177302,_0x2e0d4f)>0x0;)_0x8d7e1b['getNext'](),_0x177302=_0x8d7e1b['peek']();return _0x8d7e1b;}}['compareTo'](_0x320ce2){return this['isEmpty']()?_0x320ce2['isEmpty']()?0x0:-0x1:_0x320ce2['isLeafNode']()||_0x320ce2['isEmpty']()?0x1:_0x320ce2===jt?-0x1:0x0;}['withIndex'](_0x37f49a){if(_0x37f49a===ve||this['indexMap_']['hasIndex'](_0x37f49a))return this;{const _0x47228b=this['indexMap_']['addIndex'](_0x37f49a,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x47228b);}}['isIndexed'](_0xdb8146){return _0xdb8146===ve||this['indexMap_']['hasIndex'](_0xdb8146);}['equals'](_0xfa5fd6){if(_0xfa5fd6===this)return!0x0;if(_0xfa5fd6['isLeafNode']())return!0x1;{const _0x4783b3=_0xfa5fd6;if(this['getPriority']()['equals'](_0x4783b3['getPriority']())){if(this['children_']['count']()===_0x4783b3['children_']['count']()){const _0x25fb9e=this['getIterator'](R),_0x4c1920=_0x4783b3['getIterator'](R);let _0x5b067a=_0x25fb9e['getNext'](),_0x1c8336=_0x4c1920['getNext']();for(;_0x5b067a&&_0x1c8336;){if(_0x5b067a['name']!==_0x1c8336['name']||!_0x5b067a['node']['equals'](_0x1c8336['node']))return!0x1;_0x5b067a=_0x25fb9e['getNext'](),_0x1c8336=_0x4c1920['getNext']();}return _0x5b067a===null&&_0x1c8336===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5a9690){return _0x5a9690===ve?null:this['indexMap_']['get'](_0x5a9690['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x26a78c){return _0x26a78c===this?0x0:0x1;}['equals'](_0x24a174){return _0x24a174===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3ab7a4){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x120df7,_0x5ab48d=null){if(_0x120df7===null)return g['EMPTY_NODE'];if(typeof _0x120df7=='object'&&'.priority'in _0x120df7&&(_0x5ab48d=_0x120df7['.priority']),f(_0x5ab48d===null||typeof _0x5ab48d=='string'||typeof _0x5ab48d=='number'||typeof _0x5ab48d=='object'&&'.sv'in _0x5ab48d,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5ab48d),typeof _0x120df7=='object'&&'.value'in _0x120df7&&_0x120df7['.value']!==null&&(_0x120df7=_0x120df7['.value']),typeof _0x120df7!='object'||'.sv'in _0x120df7){const _0x13d75d=_0x120df7;return new D(_0x13d75d,A(_0x5ab48d));}if(!(_0x120df7 instanceof Array)&&Gh){const _0x27f008=[];let _0x490f69=!0x1;if(x(_0x120df7,(_0xcf0d2e,_0x429393)=>{if(_0xcf0d2e['substring'](0x0,0x1)!=='.'){const _0x40035c=A(_0x429393);_0x40035c['isEmpty']()||(_0x490f69=_0x490f69||!_0x40035c['getPriority']()['isEmpty'](),_0x27f008['push'](new E(_0xcf0d2e,_0x40035c)));}}),_0x27f008['length']===0x0)return g['EMPTY_NODE'];const _0x1a8550=yn(_0x27f008,xh,_0x15d233=>_0x15d233['name'],Qi);if(_0x490f69){const _0x35e5e4=yn(_0x27f008,R['getCompare']());return new g(_0x1a8550,A(_0x5ab48d),new te({'.priority':_0x35e5e4},{'.priority':R}));}else return new g(_0x1a8550,A(_0x5ab48d),te['Default']);}else{let _0x55edf6=g['EMPTY_NODE'];return x(_0x120df7,(_0x5bf5bb,_0x112dbb)=>{if(Q(_0x120df7,_0x5bf5bb)&&_0x5bf5bb['substring'](0x0,0x1)!=='.'){const _0x43d86a=A(_0x112dbb);(_0x43d86a['isLeafNode']()||!_0x43d86a['isEmpty']())&&(_0x55edf6=_0x55edf6['updateImmediateChild'](_0x5bf5bb,_0x43d86a));}}),_0x55edf6['updatePriority'](A(_0x5ab48d));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x34d829){super(),this['indexPath_']=_0x34d829,f(!v(_0x34d829)&&y(_0x34d829)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x26e29c){return _0x26e29c['getChild'](this['indexPath_']);}['isDefinedOn'](_0x368e63){return!_0x368e63['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2385c2,_0x30f2f7){const _0x4a6292=this['extractChild'](_0x2385c2['node']),_0x29a52f=this['extractChild'](_0x30f2f7['node']),_0x5f3958=_0x4a6292['compareTo'](_0x29a52f);return _0x5f3958===0x0?Ge(_0x2385c2['name'],_0x30f2f7['name']):_0x5f3958;}['makePost'](_0x227a31,_0x739c97){const _0xfbd3dd=A(_0x227a31),_0x20bf52=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xfbd3dd);return new E(_0x739c97,_0x20bf52);}['maxPost'](){const _0x40f950=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x40f950);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x580212,_0x1c3bce){const _0x11ed5f=_0x580212['node']['compareTo'](_0x1c3bce['node']);return _0x11ed5f===0x0?Ge(_0x580212['name'],_0x1c3bce['name']):_0x11ed5f;}['isDefinedOn'](_0x450179){return!0x0;}['indexedValueChanged'](_0x44340f,_0x44331f){return!_0x44340f['equals'](_0x44331f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x52f35e,_0x3e2c17){const _0x36b9d5=A(_0x52f35e);return new E(_0x3e2c17,_0x36b9d5);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x25252a){return{'type':'value','snapshotNode':_0x25252a};}function rt(_0x12c7d6,_0x14dfe0){return{'type':'child_added','snapshotNode':_0x14dfe0,'childName':_0x12c7d6};}function Mt(_0x307dec,_0x2ead9e){return{'type':'child_removed','snapshotNode':_0x2ead9e,'childName':_0x307dec};}function Lt(_0x2ab89b,_0x13fdc7,_0x17df00){return{'type':'child_changed','snapshotNode':_0x13fdc7,'childName':_0x2ab89b,'oldSnap':_0x17df00};}function zh(_0x3ecd30,_0x505b5e){return{'type':'child_moved','snapshotNode':_0x505b5e,'childName':_0x3ecd30};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x5052d7){this['index_']=_0x5052d7;}['updateChild'](_0x15a3fa,_0x510ecb,_0x40e498,_0x40b44b,_0x9a26cc,_0x52e50c){f(_0x15a3fa['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4b6d0b=_0x15a3fa['getImmediateChild'](_0x510ecb);return _0x4b6d0b['getChild'](_0x40b44b)['equals'](_0x40e498['getChild'](_0x40b44b))&&_0x4b6d0b['isEmpty']()===_0x40e498['isEmpty']()||(_0x52e50c!=null&&(_0x40e498['isEmpty']()?_0x15a3fa['hasChild'](_0x510ecb)?_0x52e50c['trackChildChange'](Mt(_0x510ecb,_0x4b6d0b)):f(_0x15a3fa['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4b6d0b['isEmpty']()?_0x52e50c['trackChildChange'](rt(_0x510ecb,_0x40e498)):_0x52e50c['trackChildChange'](Lt(_0x510ecb,_0x40e498,_0x4b6d0b))),_0x15a3fa['isLeafNode']()&&_0x40e498['isEmpty']())?_0x15a3fa:_0x15a3fa['updateImmediateChild'](_0x510ecb,_0x40e498)['withIndex'](this['index_']);}['updateFullNode'](_0xff9d16,_0xa40625,_0x174e75){return _0x174e75!=null&&(_0xff9d16['isLeafNode']()||_0xff9d16['forEachChild'](R,(_0x423d94,_0x4372ca)=>{_0xa40625['hasChild'](_0x423d94)||_0x174e75['trackChildChange'](Mt(_0x423d94,_0x4372ca));}),_0xa40625['isLeafNode']()||_0xa40625['forEachChild'](R,(_0x102984,_0x149bcf)=>{if(_0xff9d16['hasChild'](_0x102984)){const _0x3c66ec=_0xff9d16['getImmediateChild'](_0x102984);_0x3c66ec['equals'](_0x149bcf)||_0x174e75['trackChildChange'](Lt(_0x102984,_0x149bcf,_0x3c66ec));}else _0x174e75['trackChildChange'](rt(_0x102984,_0x149bcf));})),_0xa40625['withIndex'](this['index_']);}['updatePriority'](_0xcdc197,_0x1b9628){return _0xcdc197['isEmpty']()?g['EMPTY_NODE']:_0xcdc197['updatePriority'](_0x1b9628);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x1802c4){this['indexedFilter_']=new Xi(_0x1802c4['getIndex']()),this['index_']=_0x1802c4['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x1802c4),this['endPost_']=xt['getEndPost_'](_0x1802c4),this['startIsInclusive_']=!_0x1802c4['startAfterSet_'],this['endIsInclusive_']=!_0x1802c4['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x163903){const _0x485716=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x163903)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x163903)<0x0,_0x227202=this['endIsInclusive_']?this['index_']['compare'](_0x163903,this['getEndPost']())<=0x0:this['index_']['compare'](_0x163903,this['getEndPost']())<0x0;return _0x485716&&_0x227202;}['updateChild'](_0xd6a889,_0x2ea537,_0x1c2f6b,_0x384897,_0x4989e8,_0x2f5136){return this['matches'](new E(_0x2ea537,_0x1c2f6b))||(_0x1c2f6b=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xd6a889,_0x2ea537,_0x1c2f6b,_0x384897,_0x4989e8,_0x2f5136);}['updateFullNode'](_0x3c821a,_0x4220ce,_0x2a4314){_0x4220ce['isLeafNode']()&&(_0x4220ce=g['EMPTY_NODE']);let _0x5ec700=_0x4220ce['withIndex'](this['index_']);_0x5ec700=_0x5ec700['updatePriority'](g['EMPTY_NODE']);const _0x206b32=this;return _0x4220ce['forEachChild'](R,(_0x50a59e,_0x20a50f)=>{_0x206b32['matches'](new E(_0x50a59e,_0x20a50f))||(_0x5ec700=_0x5ec700['updateImmediateChild'](_0x50a59e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3c821a,_0x5ec700,_0x2a4314);}['updatePriority'](_0x5ae1b1,_0x22d71f){return _0x5ae1b1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x28d341){if(_0x28d341['hasStart']()){const _0x8e9729=_0x28d341['getIndexStartName']();return _0x28d341['getIndex']()['makePost'](_0x28d341['getIndexStartValue'](),_0x8e9729);}else return _0x28d341['getIndex']()['minPost']();}static['getEndPost_'](_0x330c53){if(_0x330c53['hasEnd']()){const _0x4c82c3=_0x330c53['getIndexEndName']();return _0x330c53['getIndex']()['makePost'](_0x330c53['getIndexEndValue'](),_0x4c82c3);}else return _0x330c53['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0xb9c4e8){this['withinDirectionalStart']=_0xcf890=>this['reverse_']?this['withinEndPost'](_0xcf890):this['withinStartPost'](_0xcf890),this['withinDirectionalEnd']=_0x1664a4=>this['reverse_']?this['withinStartPost'](_0x1664a4):this['withinEndPost'](_0x1664a4),this['withinStartPost']=_0x424ce6=>{const _0x4db76d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x424ce6);return this['startIsInclusive_']?_0x4db76d<=0x0:_0x4db76d<0x0;},this['withinEndPost']=_0x4d7d5a=>{const _0x3cf9ab=this['index_']['compare'](_0x4d7d5a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3cf9ab<=0x0:_0x3cf9ab<0x0;},this['rangedFilter_']=new xt(_0xb9c4e8),this['index_']=_0xb9c4e8['getIndex'](),this['limit_']=_0xb9c4e8['getLimit'](),this['reverse_']=!_0xb9c4e8['isViewFromLeft'](),this['startIsInclusive_']=!_0xb9c4e8['startAfterSet_'],this['endIsInclusive_']=!_0xb9c4e8['endBeforeSet_'];}['updateChild'](_0x937418,_0x3b62af,_0x25efb3,_0x3c73ce,_0x4f55db,_0x3bf7ac){return this['rangedFilter_']['matches'](new E(_0x3b62af,_0x25efb3))||(_0x25efb3=g['EMPTY_NODE']),_0x937418['getImmediateChild'](_0x3b62af)['equals'](_0x25efb3)?_0x937418:_0x937418['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x937418,_0x3b62af,_0x25efb3,_0x3c73ce,_0x4f55db,_0x3bf7ac):this['fullLimitUpdateChild_'](_0x937418,_0x3b62af,_0x25efb3,_0x4f55db,_0x3bf7ac);}['updateFullNode'](_0x40f573,_0x83f9bc,_0x12eb02){let _0x15bad7;if(_0x83f9bc['isLeafNode']()||_0x83f9bc['isEmpty']())_0x15bad7=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x83f9bc['numChildren']()&&_0x83f9bc['isIndexed'](this['index_'])){_0x15bad7=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3fd12c;this['reverse_']?_0x3fd12c=_0x83f9bc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3fd12c=_0x83f9bc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x12ffa2=0x0;for(;_0x3fd12c['hasNext']()&&_0x12ffa2<this['limit_'];){const _0x132bf3=_0x3fd12c['getNext']();if(this['withinDirectionalStart'](_0x132bf3)){if(this['withinDirectionalEnd'](_0x132bf3))_0x15bad7=_0x15bad7['updateImmediateChild'](_0x132bf3['name'],_0x132bf3['node']),_0x12ffa2++;else break;}else continue;}}else{_0x15bad7=_0x83f9bc['withIndex'](this['index_']),_0x15bad7=_0x15bad7['updatePriority'](g['EMPTY_NODE']);let _0x1791cf;this['reverse_']?_0x1791cf=_0x15bad7['getReverseIterator'](this['index_']):_0x1791cf=_0x15bad7['getIterator'](this['index_']);let _0x475a98=0x0;for(;_0x1791cf['hasNext']();){const _0x48a1ed=_0x1791cf['getNext']();_0x475a98<this['limit_']&&this['withinDirectionalStart'](_0x48a1ed)&&this['withinDirectionalEnd'](_0x48a1ed)?_0x475a98++:_0x15bad7=_0x15bad7['updateImmediateChild'](_0x48a1ed['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x40f573,_0x15bad7,_0x12eb02);}['updatePriority'](_0x4a72c0,_0x373a75){return _0x4a72c0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1d9872,_0x4e9c91,_0x439e92,_0x347c44,_0x51c48d){let _0x315978;if(this['reverse_']){const _0x1a65b8=this['index_']['getCompare']();_0x315978=(_0x306532,_0x3f958f)=>_0x1a65b8(_0x3f958f,_0x306532);}else _0x315978=this['index_']['getCompare']();const _0x3b3055=_0x1d9872;f(_0x3b3055['numChildren']()===this['limit_'],'');const _0x480256=new E(_0x4e9c91,_0x439e92),_0x3da6ac=this['reverse_']?_0x3b3055['getFirstChild'](this['index_']):_0x3b3055['getLastChild'](this['index_']),_0x46048c=this['rangedFilter_']['matches'](_0x480256);if(_0x3b3055['hasChild'](_0x4e9c91)){const _0x2d92dc=_0x3b3055['getImmediateChild'](_0x4e9c91);let _0x25ddaf=_0x347c44['getChildAfterChild'](this['index_'],_0x3da6ac,this['reverse_']);for(;_0x25ddaf!=null&&(_0x25ddaf['name']===_0x4e9c91||_0x3b3055['hasChild'](_0x25ddaf['name']));)_0x25ddaf=_0x347c44['getChildAfterChild'](this['index_'],_0x25ddaf,this['reverse_']);const _0xe9c89b=_0x25ddaf==null?0x1:_0x315978(_0x25ddaf,_0x480256);if(_0x46048c&&!_0x439e92['isEmpty']()&&_0xe9c89b>=0x0)return _0x51c48d!=null&&_0x51c48d['trackChildChange'](Lt(_0x4e9c91,_0x439e92,_0x2d92dc)),_0x3b3055['updateImmediateChild'](_0x4e9c91,_0x439e92);{_0x51c48d!=null&&_0x51c48d['trackChildChange'](Mt(_0x4e9c91,_0x2d92dc));const _0x2b5357=_0x3b3055['updateImmediateChild'](_0x4e9c91,g['EMPTY_NODE']);return _0x25ddaf!=null&&this['rangedFilter_']['matches'](_0x25ddaf)?(_0x51c48d!=null&&_0x51c48d['trackChildChange'](rt(_0x25ddaf['name'],_0x25ddaf['node'])),_0x2b5357['updateImmediateChild'](_0x25ddaf['name'],_0x25ddaf['node'])):_0x2b5357;}}else return _0x439e92['isEmpty']()?_0x1d9872:_0x46048c&&_0x315978(_0x3da6ac,_0x480256)>=0x0?(_0x51c48d!=null&&(_0x51c48d['trackChildChange'](Mt(_0x3da6ac['name'],_0x3da6ac['node'])),_0x51c48d['trackChildChange'](rt(_0x4e9c91,_0x439e92))),_0x3b3055['updateImmediateChild'](_0x4e9c91,_0x439e92)['updateImmediateChild'](_0x3da6ac['name'],g['EMPTY_NODE'])):_0x1d9872;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x21d98b=new Zi();return _0x21d98b['limitSet_']=this['limitSet_'],_0x21d98b['limit_']=this['limit_'],_0x21d98b['startSet_']=this['startSet_'],_0x21d98b['startAfterSet_']=this['startAfterSet_'],_0x21d98b['indexStartValue_']=this['indexStartValue_'],_0x21d98b['startNameSet_']=this['startNameSet_'],_0x21d98b['indexStartName_']=this['indexStartName_'],_0x21d98b['endSet_']=this['endSet_'],_0x21d98b['endBeforeSet_']=this['endBeforeSet_'],_0x21d98b['indexEndValue_']=this['indexEndValue_'],_0x21d98b['endNameSet_']=this['endNameSet_'],_0x21d98b['indexEndName_']=this['indexEndName_'],_0x21d98b['index_']=this['index_'],_0x21d98b['viewFrom_']=this['viewFrom_'],_0x21d98b;}}function Kh(_0x52584d){return _0x52584d['loadsAllData']()?new Xi(_0x52584d['getIndex']()):_0x52584d['hasLimit']()?new jh(_0x52584d):new xt(_0x52584d);}function Yh(_0x53d225,_0x3cb1e2,_0x959881){const _0xfcdec1=_0x53d225['copy']();return _0xfcdec1['startSet_']=!0x0,_0x3cb1e2===void 0x0&&(_0x3cb1e2=null),_0xfcdec1['indexStartValue_']=_0x3cb1e2,_0x959881!=null?(_0xfcdec1['startNameSet_']=!0x0,_0xfcdec1['indexStartName_']=_0x959881):(_0xfcdec1['startNameSet_']=!0x1,_0xfcdec1['indexStartName_']=''),_0xfcdec1;}function Qh(_0x3bb8b9,_0x21bb7a,_0x4836ae){const _0x58ba12=_0x3bb8b9['copy']();return _0x58ba12['endSet_']=!0x0,_0x21bb7a===void 0x0&&(_0x21bb7a=null),_0x58ba12['indexEndValue_']=_0x21bb7a,_0x4836ae!==void 0x0?(_0x58ba12['endNameSet_']=!0x0,_0x58ba12['indexEndName_']=_0x4836ae):(_0x58ba12['endNameSet_']=!0x1,_0x58ba12['indexEndName_']=''),_0x58ba12;}function xo(_0x93dffe,_0x58e345){const _0x3d006b=_0x93dffe['copy']();return _0x3d006b['index_']=_0x58e345,_0x3d006b;}function ir(_0x4e1e3d){const _0x3d1aed={};if(_0x4e1e3d['isDefault']())return _0x3d1aed;let _0x4472e6;if(_0x4e1e3d['index_']===R?_0x4472e6='$priority':_0x4e1e3d['index_']===Mo?_0x4472e6='$value':_0x4e1e3d['index_']===ve?_0x4472e6='$key':(f(_0x4e1e3d['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4472e6=_0x4e1e3d['index_']['toString']()),_0x3d1aed['orderBy']=O(_0x4472e6),_0x4e1e3d['startSet_']){const _0x385c78=_0x4e1e3d['startAfterSet_']?'startAfter':'startAt';_0x3d1aed[_0x385c78]=O(_0x4e1e3d['indexStartValue_']),_0x4e1e3d['startNameSet_']&&(_0x3d1aed[_0x385c78]+=','+O(_0x4e1e3d['indexStartName_']));}if(_0x4e1e3d['endSet_']){const _0x1b6f9f=_0x4e1e3d['endBeforeSet_']?'endBefore':'endAt';_0x3d1aed[_0x1b6f9f]=O(_0x4e1e3d['indexEndValue_']),_0x4e1e3d['endNameSet_']&&(_0x3d1aed[_0x1b6f9f]+=','+O(_0x4e1e3d['indexEndName_']));}return _0x4e1e3d['limitSet_']&&(_0x4e1e3d['isViewFromLeft']()?_0x3d1aed['limitToFirst']=_0x4e1e3d['limit_']:_0x3d1aed['limitToLast']=_0x4e1e3d['limit_']),_0x3d1aed;}function sr(_0x41017e){const _0x2c7e29={};if(_0x41017e['startSet_']&&(_0x2c7e29['sp']=_0x41017e['indexStartValue_'],_0x41017e['startNameSet_']&&(_0x2c7e29['sn']=_0x41017e['indexStartName_']),_0x2c7e29['sin']=!_0x41017e['startAfterSet_']),_0x41017e['endSet_']&&(_0x2c7e29['ep']=_0x41017e['indexEndValue_'],_0x41017e['endNameSet_']&&(_0x2c7e29['en']=_0x41017e['indexEndName_']),_0x2c7e29['ein']=!_0x41017e['endBeforeSet_']),_0x41017e['limitSet_']){_0x2c7e29['l']=_0x41017e['limit_'];let _0x39f108=_0x41017e['viewFrom_'];_0x39f108===''&&(_0x41017e['isViewFromLeft']()?_0x39f108='l':_0x39f108='r'),_0x2c7e29['vf']=_0x39f108;}return _0x41017e['index_']!==R&&(_0x2c7e29['i']=_0x41017e['index_']['toString']()),_0x2c7e29;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x378f08){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x542bdc,_0x1b3c28){return _0x1b3c28!==void 0x0?'tag$'+_0x1b3c28:(f(_0x542bdc['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x542bdc['_path']['toString']());}constructor(_0x4b43a4,_0x36540d,_0x4b0b1b,_0x1a91b7){super(),this['repoInfo_']=_0x4b43a4,this['onDataUpdate_']=_0x36540d,this['authTokenProvider_']=_0x4b0b1b,this['appCheckTokenProvider_']=_0x1a91b7,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x413c60,_0x4e1e9c,_0xf9c324,_0x881978){const _0x2d0bae=_0x413c60['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2d0bae+'\x20'+_0x413c60['_queryIdentifier']);const _0x1aa59a=vn['getListenId_'](_0x413c60,_0xf9c324),_0x1b5cd8={};this['listens_'][_0x1aa59a]=_0x1b5cd8;const _0x2a156b=ir(_0x413c60['_queryParams']);this['restRequest_'](_0x2d0bae+'.json',_0x2a156b,(_0xcd3cfe,_0x280e85)=>{let _0x21254d=_0x280e85;if(_0xcd3cfe===0x194&&(_0x21254d=null,_0xcd3cfe=null),_0xcd3cfe===null&&this['onDataUpdate_'](_0x2d0bae,_0x21254d,!0x1,_0xf9c324),Me(this['listens_'],_0x1aa59a)===_0x1b5cd8){let _0x20ea4d;_0xcd3cfe?_0xcd3cfe===0x191?_0x20ea4d='permission_denied':_0x20ea4d='rest_error:'+_0xcd3cfe:_0x20ea4d='ok',_0x881978(_0x20ea4d,null);}});}['unlisten'](_0xa284ee,_0x19005f){const _0x3e4102=vn['getListenId_'](_0xa284ee,_0x19005f);delete this['listens_'][_0x3e4102];}['get'](_0x489a05){const _0x2ee3b4=ir(_0x489a05['_queryParams']),_0x5dc7c7=_0x489a05['_path']['toString'](),_0x49fa81=new H();return this['restRequest_'](_0x5dc7c7+'.json',_0x2ee3b4,(_0x232462,_0xac9a41)=>{let _0x37a018=_0xac9a41;_0x232462===0x194&&(_0x37a018=null,_0x232462=null),_0x232462===null?(this['onDataUpdate_'](_0x5dc7c7,_0x37a018,!0x1,null),_0x49fa81['resolve'](_0x37a018)):_0x49fa81['reject'](new Error(_0x37a018));}),_0x49fa81['promise'];}['refreshAuthToken'](_0x540a0a){}['restRequest_'](_0x5675e8,_0x3033bb={},_0x245eff){return _0x3033bb['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x26da98,_0x119a15])=>{_0x26da98&&_0x26da98['accessToken']&&(_0x3033bb['auth']=_0x26da98['accessToken']),_0x119a15&&_0x119a15['token']&&(_0x3033bb['ac']=_0x119a15['token']);const _0x581fb6=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5675e8+'?ns='+this['repoInfo_']['namespace']+ut(_0x3033bb);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x581fb6);const _0x30ca1c=new XMLHttpRequest();_0x30ca1c['onreadystatechange']=()=>{if(_0x245eff&&_0x30ca1c['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x581fb6+'\x20received.\x20status:',_0x30ca1c['status'],'response:',_0x30ca1c['responseText']);let _0x4db434=null;if(_0x30ca1c['status']>=0xc8&&_0x30ca1c['status']<0x12c){try{_0x4db434=Nt(_0x30ca1c['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x581fb6+':\x20'+_0x30ca1c['responseText']);}_0x245eff(null,_0x4db434);}else _0x30ca1c['status']!==0x191&&_0x30ca1c['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x581fb6+'\x20Status:\x20'+_0x30ca1c['status']),_0x245eff(_0x30ca1c['status']);_0x245eff=null;}},_0x30ca1c['open']('GET',_0x581fb6,!0x0),_0x30ca1c['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x49d0c1){return this['rootNode_']['getChild'](_0x49d0c1);}['updateSnapshot'](_0x3c5267,_0x4c9eb3){this['rootNode_']=this['rootNode_']['updateChild'](_0x3c5267,_0x4c9eb3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x427108,_0x548307,_0x168dd3){if(v(_0x548307))_0x427108['value']=_0x168dd3,_0x427108['children']['clear']();else{if(_0x427108['value']!==null)_0x427108['value']=_0x427108['value']['updateChild'](_0x548307,_0x168dd3);else{const _0x14ec86=y(_0x548307);_0x427108['children']['has'](_0x14ec86)||_0x427108['children']['set'](_0x14ec86,En());const _0x3f02d1=_0x427108['children']['get'](_0x14ec86);_0x548307=S(_0x548307),pt(_0x3f02d1,_0x548307,_0x168dd3);}}}function Ti(_0x5c4f50,_0x329efc){if(v(_0x329efc))return _0x5c4f50['value']=null,_0x5c4f50['children']['clear'](),!0x0;if(_0x5c4f50['value']!==null){if(_0x5c4f50['value']['isLeafNode']())return!0x1;{const _0x47b380=_0x5c4f50['value'];return _0x5c4f50['value']=null,_0x47b380['forEachChild'](R,(_0x4389ee,_0x404059)=>{pt(_0x5c4f50,new C(_0x4389ee),_0x404059);}),Ti(_0x5c4f50,_0x329efc);}}else{if(_0x5c4f50['children']['size']>0x0){const _0x468ad9=y(_0x329efc);return _0x329efc=S(_0x329efc),_0x5c4f50['children']['has'](_0x468ad9)&&Ti(_0x5c4f50['children']['get'](_0x468ad9),_0x329efc)&&_0x5c4f50['children']['delete'](_0x468ad9),_0x5c4f50['children']['size']===0x0;}else return!0x0;}}function Si(_0x242b78,_0x13337e,_0x5ab525){_0x242b78['value']!==null?_0x5ab525(_0x13337e,_0x242b78['value']):Xh(_0x242b78,(_0x5bc703,_0x2c14b0)=>{const _0x38a955=new C(_0x13337e['toString']()+'/'+_0x5bc703);Si(_0x2c14b0,_0x38a955,_0x5ab525);});}function Xh(_0x9cab9,_0x3cb48c){_0x9cab9['children']['forEach']((_0x3d078a,_0x535876)=>{_0x3cb48c(_0x535876,_0x3d078a);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x20e2de){this['collection_']=_0x20e2de,this['last_']=null;}['get'](){const _0x5def5d=this['collection_']['get'](),_0x553b70={..._0x5def5d};return this['last_']&&x(this['last_'],(_0x2a1600,_0x4782b9)=>{_0x553b70[_0x2a1600]=_0x553b70[_0x2a1600]-_0x4782b9;}),this['last_']=_0x5def5d,_0x553b70;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x478a84,_0x1f8476){this['server_']=_0x1f8476,this['statsToReport_']={},this['statsListener_']=new Zh(_0x478a84);const _0x4cfcd6=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x4cfcd6));}['reportStats_'](){const _0x13fe22=this['statsListener_']['get'](),_0x23ac94={};let _0x2700c4=!0x1;x(_0x13fe22,(_0x50c779,_0x4b356b)=>{_0x4b356b>0x0&&Q(this['statsToReport_'],_0x50c779)&&(_0x23ac94[_0x50c779]=_0x4b356b,_0x2700c4=!0x0);}),_0x2700c4&&this['server_']['reportStats'](_0x23ac94),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4eafe0){_0x4eafe0[_0x4eafe0['OVERWRITE']=0x0]='OVERWRITE',_0x4eafe0[_0x4eafe0['MERGE']=0x1]='MERGE',_0x4eafe0[_0x4eafe0['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4eafe0[_0x4eafe0['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x378ab6){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x378ab6,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1760c2,_0x478b2e,_0x1c642c){this['path']=_0x1760c2,this['affectedTree']=_0x478b2e,this['revert']=_0x1c642c,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1bb67a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4a4b7f=this['affectedTree']['subtree'](new C(_0x1bb67a));return new In(w(),_0x4a4b7f,this['revert']);}}else return f(y(this['path'])===_0x1bb67a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x358a72,_0x6a0748){this['source']=_0x358a72,this['path']=_0x6a0748,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5c4d1c){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x4b83bf,_0x309108,_0x760428){this['source']=_0x4b83bf,this['path']=_0x309108,this['snap']=_0x760428,this['type']=z['OVERWRITE'];}['operationForChild'](_0x5bbdc5){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x5bbdc5)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x290c34,_0xd654bd,_0x59f598){this['source']=_0x290c34,this['path']=_0xd654bd,this['children']=_0x59f598,this['type']=z['MERGE'];}['operationForChild'](_0x35188d){if(v(this['path'])){const _0x1e4c7e=this['children']['subtree'](new C(_0x35188d));return _0x1e4c7e['isEmpty']()?null:_0x1e4c7e['value']?new We(this['source'],w(),_0x1e4c7e['value']):new ot(this['source'],w(),_0x1e4c7e);}else return f(y(this['path'])===_0x35188d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2769d5,_0x4aa632,_0x140d90){this['node_']=_0x2769d5,this['fullyInitialized_']=_0x4aa632,this['filtered_']=_0x140d90;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x34a030){if(v(_0x34a030))return this['isFullyInitialized']()&&!this['filtered_'];const _0x180876=y(_0x34a030);return this['isCompleteForChild'](_0x180876);}['isCompleteForChild'](_0x1d63f1){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1d63f1);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0x444e7d){this['query_']=_0x444e7d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x2a1f21,_0x219261,_0x5e0ceb,_0x13b016){const _0x30ad08=[],_0x5ea8b8=[];return _0x219261['forEach'](_0x2e93a1=>{_0x2e93a1['type']==='child_changed'&&_0x2a1f21['index_']['indexedValueChanged'](_0x2e93a1['oldSnap'],_0x2e93a1['snapshotNode'])&&_0x5ea8b8['push'](zh(_0x2e93a1['childName'],_0x2e93a1['snapshotNode']));}),It(_0x2a1f21,_0x30ad08,'child_removed',_0x219261,_0x13b016,_0x5e0ceb),It(_0x2a1f21,_0x30ad08,'child_added',_0x219261,_0x13b016,_0x5e0ceb),It(_0x2a1f21,_0x30ad08,'child_moved',_0x5ea8b8,_0x13b016,_0x5e0ceb),It(_0x2a1f21,_0x30ad08,'child_changed',_0x219261,_0x13b016,_0x5e0ceb),It(_0x2a1f21,_0x30ad08,'value',_0x219261,_0x13b016,_0x5e0ceb),_0x30ad08;}function It(_0x556215,_0x2c17ea,_0x85c6fa,_0x374efc,_0x3816e6,_0x595ad9){const _0x3199ca=_0x374efc['filter'](_0x5ad9bd=>_0x5ad9bd['type']===_0x85c6fa);_0x3199ca['sort']((_0xa37753,_0xf01111)=>ou(_0x556215,_0xa37753,_0xf01111)),_0x3199ca['forEach'](_0x4223c3=>{const _0x3667fc=ru(_0x556215,_0x4223c3,_0x595ad9);_0x3816e6['forEach'](_0x333cc1=>{_0x333cc1['respondsTo'](_0x4223c3['type'])&&_0x2c17ea['push'](_0x333cc1['createEvent'](_0x3667fc,_0x556215['query_']));});});}function ru(_0x11adc4,_0x1cce47,_0x1ed96b){return _0x1cce47['type']==='value'||_0x1cce47['type']==='child_removed'||(_0x1cce47['prevName']=_0x1ed96b['getPredecessorChildName'](_0x1cce47['childName'],_0x1cce47['snapshotNode'],_0x11adc4['index_'])),_0x1cce47;}function ou(_0x4177eb,_0x42b08c,_0x4914fc){if(_0x42b08c['childName']==null||_0x4914fc['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x168ca8=new E(_0x42b08c['childName'],_0x42b08c['snapshotNode']),_0x4e2631=new E(_0x4914fc['childName'],_0x4914fc['snapshotNode']);return _0x4177eb['index_']['compare'](_0x168ca8,_0x4e2631);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x4cda13,_0x3cfb6e){return{'eventCache':_0x4cda13,'serverCache':_0x3cfb6e};}function bt(_0x5f97ca,_0x279aba,_0x293d32,_0x27f37a){return Un(new Te(_0x279aba,_0x293d32,_0x27f37a),_0x5f97ca['serverCache']);}function Fo(_0x253e07,_0x291398,_0x23e22f,_0x211060){return Un(_0x253e07['eventCache'],new Te(_0x291398,_0x23e22f,_0x211060));}function wn(_0x23b402){return _0x23b402['eventCache']['isFullyInitialized']()?_0x23b402['eventCache']['getNode']():null;}function Be(_0x2aae11){return _0x2aae11['serverCache']['isFullyInitialized']()?_0x2aae11['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2a0836){let _0xc90f27=new b(null);return x(_0x2a0836,(_0x3ff34a,_0x41c491)=>{_0xc90f27=_0xc90f27['set'](new C(_0x3ff34a),_0x41c491);}),_0xc90f27;}constructor(_0x1aedcc,_0x485c27=au()){this['value']=_0x1aedcc,this['children']=_0x485c27;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x11b99,_0x590d9b){if(this['value']!=null&&_0x590d9b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x11b99))return null;{const _0xb0735b=y(_0x11b99),_0x11d928=this['children']['get'](_0xb0735b);if(_0x11d928!==null){const _0x410c6e=_0x11d928['findRootMostMatchingPathAndValue'](S(_0x11b99),_0x590d9b);return _0x410c6e!=null?{'path':k(new C(_0xb0735b),_0x410c6e['path']),'value':_0x410c6e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x19f241){return this['findRootMostMatchingPathAndValue'](_0x19f241,()=>!0x0);}['subtree'](_0x5cd35a){if(v(_0x5cd35a))return this;{const _0x24fd9f=y(_0x5cd35a),_0x5bc3e7=this['children']['get'](_0x24fd9f);return _0x5bc3e7!==null?_0x5bc3e7['subtree'](S(_0x5cd35a)):new b(null);}}['set'](_0x1ef55d,_0x5d89d6){if(v(_0x1ef55d))return new b(_0x5d89d6,this['children']);{const _0xb0e946=y(_0x1ef55d),_0x34662f=(this['children']['get'](_0xb0e946)||new b(null))['set'](S(_0x1ef55d),_0x5d89d6),_0x30c4d6=this['children']['insert'](_0xb0e946,_0x34662f);return new b(this['value'],_0x30c4d6);}}['remove'](_0x1584a6){if(v(_0x1584a6))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2fdda5=y(_0x1584a6),_0x38563a=this['children']['get'](_0x2fdda5);if(_0x38563a){const _0x25d0f9=_0x38563a['remove'](S(_0x1584a6));let _0x3a0edf;return _0x25d0f9['isEmpty']()?_0x3a0edf=this['children']['remove'](_0x2fdda5):_0x3a0edf=this['children']['insert'](_0x2fdda5,_0x25d0f9),this['value']===null&&_0x3a0edf['isEmpty']()?new b(null):new b(this['value'],_0x3a0edf);}else return this;}}['get'](_0x6a4098){if(v(_0x6a4098))return this['value'];{const _0x3bd7ef=y(_0x6a4098),_0x2b81aa=this['children']['get'](_0x3bd7ef);return _0x2b81aa?_0x2b81aa['get'](S(_0x6a4098)):null;}}['setTree'](_0x45bb36,_0x36517f){if(v(_0x45bb36))return _0x36517f;{const _0x3dc64c=y(_0x45bb36),_0x53f355=(this['children']['get'](_0x3dc64c)||new b(null))['setTree'](S(_0x45bb36),_0x36517f);let _0x3b23d9;return _0x53f355['isEmpty']()?_0x3b23d9=this['children']['remove'](_0x3dc64c):_0x3b23d9=this['children']['insert'](_0x3dc64c,_0x53f355),new b(this['value'],_0x3b23d9);}}['fold'](_0x3f2a1f){return this['fold_'](w(),_0x3f2a1f);}['fold_'](_0x5eb928,_0xc21611){const _0x77a0bc={};return this['children']['inorderTraversal']((_0x1d6ba3,_0x11eb23)=>{_0x77a0bc[_0x1d6ba3]=_0x11eb23['fold_'](k(_0x5eb928,_0x1d6ba3),_0xc21611);}),_0xc21611(_0x5eb928,this['value'],_0x77a0bc);}['findOnPath'](_0x1fd0f2,_0x3fdee2){return this['findOnPath_'](_0x1fd0f2,w(),_0x3fdee2);}['findOnPath_'](_0x326025,_0x36be0a,_0x9ebcbf){const _0x51b5ee=this['value']?_0x9ebcbf(_0x36be0a,this['value']):!0x1;if(_0x51b5ee)return _0x51b5ee;if(v(_0x326025))return null;{const _0x32bd76=y(_0x326025),_0x3e5751=this['children']['get'](_0x32bd76);return _0x3e5751?_0x3e5751['findOnPath_'](S(_0x326025),k(_0x36be0a,_0x32bd76),_0x9ebcbf):null;}}['foreachOnPath'](_0x3f2a95,_0x3f3860){return this['foreachOnPath_'](_0x3f2a95,w(),_0x3f3860);}['foreachOnPath_'](_0x2ec544,_0xcc44e4,_0x3263f8){if(v(_0x2ec544))return this;{this['value']&&_0x3263f8(_0xcc44e4,this['value']);const _0x3bb818=y(_0x2ec544),_0x1bb1cc=this['children']['get'](_0x3bb818);return _0x1bb1cc?_0x1bb1cc['foreachOnPath_'](S(_0x2ec544),k(_0xcc44e4,_0x3bb818),_0x3263f8):new b(null);}}['foreach'](_0x10b2fe){this['foreach_'](w(),_0x10b2fe);}['foreach_'](_0x57d75c,_0xb6af3d){this['children']['inorderTraversal']((_0x5d93f3,_0x114314)=>{_0x114314['foreach_'](k(_0x57d75c,_0x5d93f3),_0xb6af3d);}),this['value']&&_0xb6af3d(_0x57d75c,this['value']);}['foreachChild'](_0x6ba9b0){this['children']['inorderTraversal']((_0x2459cc,_0x5b9f93)=>{_0x5b9f93['value']&&_0x6ba9b0(_0x2459cc,_0x5b9f93['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x92de8c){this['writeTree_']=_0x92de8c;}static['empty'](){return new K(new b(null));}}function Rt(_0x2c6d34,_0x56d2ac,_0x3cb6e7){if(v(_0x56d2ac))return new K(new b(_0x3cb6e7));{const _0x1cb70b=_0x2c6d34['writeTree_']['findRootMostValueAndPath'](_0x56d2ac);if(_0x1cb70b!=null){const _0x5e313e=_0x1cb70b['path'];let _0x1d21dc=_0x1cb70b['value'];const _0xd9ad56=F(_0x5e313e,_0x56d2ac);return _0x1d21dc=_0x1d21dc['updateChild'](_0xd9ad56,_0x3cb6e7),new K(_0x2c6d34['writeTree_']['set'](_0x5e313e,_0x1d21dc));}else{const _0x5cca98=new b(_0x3cb6e7),_0x19c9f9=_0x2c6d34['writeTree_']['setTree'](_0x56d2ac,_0x5cca98);return new K(_0x19c9f9);}}}function bi(_0x3e6320,_0x45b76b,_0x3c0022){let _0x2b8861=_0x3e6320;return x(_0x3c0022,(_0x462e7a,_0x5b467c)=>{_0x2b8861=Rt(_0x2b8861,k(_0x45b76b,_0x462e7a),_0x5b467c);}),_0x2b8861;}function or(_0x5bbeed,_0x4cb2b2){if(v(_0x4cb2b2))return K['empty']();{const _0xe3fad0=_0x5bbeed['writeTree_']['setTree'](_0x4cb2b2,new b(null));return new K(_0xe3fad0);}}function Ri(_0x3b9d04,_0x2aca45){return qe(_0x3b9d04,_0x2aca45)!=null;}function qe(_0xf79d4a,_0x333ed8){const _0x466d4a=_0xf79d4a['writeTree_']['findRootMostValueAndPath'](_0x333ed8);return _0x466d4a!=null?_0xf79d4a['writeTree_']['get'](_0x466d4a['path'])['getChild'](F(_0x466d4a['path'],_0x333ed8)):null;}function ar(_0x346d53){const _0x209dfc=[],_0x5a1034=_0x346d53['writeTree_']['value'];return _0x5a1034!=null?_0x5a1034['isLeafNode']()||_0x5a1034['forEachChild'](R,(_0x374203,_0x5c86c9)=>{_0x209dfc['push'](new E(_0x374203,_0x5c86c9));}):_0x346d53['writeTree_']['children']['inorderTraversal']((_0x58479f,_0x3c73da)=>{_0x3c73da['value']!=null&&_0x209dfc['push'](new E(_0x58479f,_0x3c73da['value']));}),_0x209dfc;}function Ee(_0x25c903,_0x4b0395){if(v(_0x4b0395))return _0x25c903;{const _0x3957d6=qe(_0x25c903,_0x4b0395);return _0x3957d6!=null?new K(new b(_0x3957d6)):new K(_0x25c903['writeTree_']['subtree'](_0x4b0395));}}function Ai(_0x4e8688){return _0x4e8688['writeTree_']['isEmpty']();}function at(_0x144c25,_0x44faff){return Uo(w(),_0x144c25['writeTree_'],_0x44faff);}function Uo(_0x134e8f,_0xc9d368,_0x40de5e){if(_0xc9d368['value']!=null)return _0x40de5e['updateChild'](_0x134e8f,_0xc9d368['value']);{let _0x50c258=null;return _0xc9d368['children']['inorderTraversal']((_0x44e401,_0x4b9aa9)=>{_0x44e401==='.priority'?(f(_0x4b9aa9['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x50c258=_0x4b9aa9['value']):_0x40de5e=Uo(k(_0x134e8f,_0x44e401),_0x4b9aa9,_0x40de5e);}),!_0x40de5e['getChild'](_0x134e8f)['isEmpty']()&&_0x50c258!==null&&(_0x40de5e=_0x40de5e['updateChild'](k(_0x134e8f,'.priority'),_0x50c258)),_0x40de5e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x206654,_0x5abb10){return Ho(_0x5abb10,_0x206654);}function cu(_0x24d8ac,_0xf0a9a,_0x404933,_0x15f952,_0x1040d2){f(_0x15f952>_0x24d8ac['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1040d2===void 0x0&&(_0x1040d2=!0x0),_0x24d8ac['allWrites']['push']({'path':_0xf0a9a,'snap':_0x404933,'writeId':_0x15f952,'visible':_0x1040d2}),_0x1040d2&&(_0x24d8ac['visibleWrites']=Rt(_0x24d8ac['visibleWrites'],_0xf0a9a,_0x404933)),_0x24d8ac['lastWriteId']=_0x15f952;}function lu(_0x3f39bd,_0x2ceda4,_0x290768,_0x50bf81){f(_0x50bf81>_0x3f39bd['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3f39bd['allWrites']['push']({'path':_0x2ceda4,'children':_0x290768,'writeId':_0x50bf81,'visible':!0x0}),_0x3f39bd['visibleWrites']=bi(_0x3f39bd['visibleWrites'],_0x2ceda4,_0x290768),_0x3f39bd['lastWriteId']=_0x50bf81;}function hu(_0x5704fd,_0x497c03){for(let _0x423fe0=0x0;_0x423fe0<_0x5704fd['allWrites']['length'];_0x423fe0++){const _0x522030=_0x5704fd['allWrites'][_0x423fe0];if(_0x522030['writeId']===_0x497c03)return _0x522030;}return null;}function uu(_0x23e775,_0xf9ccb2){const _0x47df6a=_0x23e775['allWrites']['findIndex'](_0x5e3644=>_0x5e3644['writeId']===_0xf9ccb2);f(_0x47df6a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3f82dc=_0x23e775['allWrites'][_0x47df6a];_0x23e775['allWrites']['splice'](_0x47df6a,0x1);let _0x31c308=_0x3f82dc['visible'],_0x28f2e8=!0x1,_0x2ad4a0=_0x23e775['allWrites']['length']-0x1;for(;_0x31c308&&_0x2ad4a0>=0x0;){const _0x4a164a=_0x23e775['allWrites'][_0x2ad4a0];_0x4a164a['visible']&&(_0x2ad4a0>=_0x47df6a&&du(_0x4a164a,_0x3f82dc['path'])?_0x31c308=!0x1:G(_0x3f82dc['path'],_0x4a164a['path'])&&(_0x28f2e8=!0x0)),_0x2ad4a0--;}if(_0x31c308){if(_0x28f2e8)return fu(_0x23e775),!0x0;if(_0x3f82dc['snap'])_0x23e775['visibleWrites']=or(_0x23e775['visibleWrites'],_0x3f82dc['path']);else{const _0x4816b0=_0x3f82dc['children'];x(_0x4816b0,_0x3ddfae=>{_0x23e775['visibleWrites']=or(_0x23e775['visibleWrites'],k(_0x3f82dc['path'],_0x3ddfae));});}return!0x0;}else return!0x1;}function du(_0x4df308,_0x556ad1){if(_0x4df308['snap'])return G(_0x4df308['path'],_0x556ad1);for(const _0x27c449 in _0x4df308['children'])if(_0x4df308['children']['hasOwnProperty'](_0x27c449)&&G(k(_0x4df308['path'],_0x27c449),_0x556ad1))return!0x0;return!0x1;}function fu(_0x7f095a){_0x7f095a['visibleWrites']=Wo(_0x7f095a['allWrites'],pu,w()),_0x7f095a['allWrites']['length']>0x0?_0x7f095a['lastWriteId']=_0x7f095a['allWrites'][_0x7f095a['allWrites']['length']-0x1]['writeId']:_0x7f095a['lastWriteId']=-0x1;}function pu(_0x2bde99){return _0x2bde99['visible'];}function Wo(_0x5839ac,_0xa3dabb,_0x3d8eae){let _0x3b2183=K['empty']();for(let _0x4c13a1=0x0;_0x4c13a1<_0x5839ac['length'];++_0x4c13a1){const _0x5f38da=_0x5839ac[_0x4c13a1];if(_0xa3dabb(_0x5f38da)){const _0x1ba42d=_0x5f38da['path'];let _0x10f8dd;if(_0x5f38da['snap'])G(_0x3d8eae,_0x1ba42d)?(_0x10f8dd=F(_0x3d8eae,_0x1ba42d),_0x3b2183=Rt(_0x3b2183,_0x10f8dd,_0x5f38da['snap'])):G(_0x1ba42d,_0x3d8eae)&&(_0x10f8dd=F(_0x1ba42d,_0x3d8eae),_0x3b2183=Rt(_0x3b2183,w(),_0x5f38da['snap']['getChild'](_0x10f8dd)));else{if(_0x5f38da['children']){if(G(_0x3d8eae,_0x1ba42d))_0x10f8dd=F(_0x3d8eae,_0x1ba42d),_0x3b2183=bi(_0x3b2183,_0x10f8dd,_0x5f38da['children']);else{if(G(_0x1ba42d,_0x3d8eae)){if(_0x10f8dd=F(_0x1ba42d,_0x3d8eae),v(_0x10f8dd))_0x3b2183=bi(_0x3b2183,w(),_0x5f38da['children']);else{const _0x2f2cad=Me(_0x5f38da['children'],y(_0x10f8dd));if(_0x2f2cad){const _0x3b7353=_0x2f2cad['getChild'](S(_0x10f8dd));_0x3b2183=Rt(_0x3b2183,w(),_0x3b7353);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3b2183;}function Bo(_0x42225a,_0x4e50d1,_0x3a382e,_0x266b6d,_0x504ae2){if(!_0x266b6d&&!_0x504ae2){const _0xbeb355=qe(_0x42225a['visibleWrites'],_0x4e50d1);if(_0xbeb355!=null)return _0xbeb355;{const _0x4c0a2f=Ee(_0x42225a['visibleWrites'],_0x4e50d1);if(Ai(_0x4c0a2f))return _0x3a382e;if(_0x3a382e==null&&!Ri(_0x4c0a2f,w()))return null;{const _0x4c3700=_0x3a382e||g['EMPTY_NODE'];return at(_0x4c0a2f,_0x4c3700);}}}else{const _0x10bb39=Ee(_0x42225a['visibleWrites'],_0x4e50d1);if(!_0x504ae2&&Ai(_0x10bb39))return _0x3a382e;if(!_0x504ae2&&_0x3a382e==null&&!Ri(_0x10bb39,w()))return null;{const _0x44b7f5=function(_0x32c08d){return(_0x32c08d['visible']||_0x504ae2)&&(!_0x266b6d||!~_0x266b6d['indexOf'](_0x32c08d['writeId']))&&(G(_0x32c08d['path'],_0x4e50d1)||G(_0x4e50d1,_0x32c08d['path']));},_0x1f3678=Wo(_0x42225a['allWrites'],_0x44b7f5,_0x4e50d1),_0x2d0d4=_0x3a382e||g['EMPTY_NODE'];return at(_0x1f3678,_0x2d0d4);}}}function _u(_0x5124cb,_0x371ee5,_0x3de76c){let _0x8d7d93=g['EMPTY_NODE'];const _0x541150=qe(_0x5124cb['visibleWrites'],_0x371ee5);if(_0x541150)return _0x541150['isLeafNode']()||_0x541150['forEachChild'](R,(_0x5b7146,_0xd73222)=>{_0x8d7d93=_0x8d7d93['updateImmediateChild'](_0x5b7146,_0xd73222);}),_0x8d7d93;if(_0x3de76c){const _0x19eb78=Ee(_0x5124cb['visibleWrites'],_0x371ee5);return _0x3de76c['forEachChild'](R,(_0x3816c7,_0x4218a2)=>{const _0x1ff2c1=at(Ee(_0x19eb78,new C(_0x3816c7)),_0x4218a2);_0x8d7d93=_0x8d7d93['updateImmediateChild'](_0x3816c7,_0x1ff2c1);}),ar(_0x19eb78)['forEach'](_0x19a7cd=>{_0x8d7d93=_0x8d7d93['updateImmediateChild'](_0x19a7cd['name'],_0x19a7cd['node']);}),_0x8d7d93;}else{const _0x5d8204=Ee(_0x5124cb['visibleWrites'],_0x371ee5);return ar(_0x5d8204)['forEach'](_0x40672a=>{_0x8d7d93=_0x8d7d93['updateImmediateChild'](_0x40672a['name'],_0x40672a['node']);}),_0x8d7d93;}}function gu(_0x4a8a5a,_0x4f309e,_0x25769d,_0xddb796,_0x4424f9){f(_0xddb796||_0x4424f9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x403acf=k(_0x4f309e,_0x25769d);if(Ri(_0x4a8a5a['visibleWrites'],_0x403acf))return null;{const _0x473cdf=Ee(_0x4a8a5a['visibleWrites'],_0x403acf);return Ai(_0x473cdf)?_0x4424f9['getChild'](_0x25769d):at(_0x473cdf,_0x4424f9['getChild'](_0x25769d));}}function mu(_0x27d45f,_0x23bc1b,_0x1dbf0f,_0x42aecd){const _0xcce2e3=k(_0x23bc1b,_0x1dbf0f),_0x5a3d52=qe(_0x27d45f['visibleWrites'],_0xcce2e3);if(_0x5a3d52!=null)return _0x5a3d52;if(_0x42aecd['isCompleteForChild'](_0x1dbf0f)){const _0x564122=Ee(_0x27d45f['visibleWrites'],_0xcce2e3);return at(_0x564122,_0x42aecd['getNode']()['getImmediateChild'](_0x1dbf0f));}else return null;}function yu(_0x57b450,_0x42a0a7){return qe(_0x57b450['visibleWrites'],_0x42a0a7);}function vu(_0x370d0a,_0x4f0c2e,_0x391df1,_0x3302eb,_0x25f033,_0x2dcb6e,_0x202085){let _0x284078;const _0x170032=Ee(_0x370d0a['visibleWrites'],_0x4f0c2e),_0x57efbc=qe(_0x170032,w());if(_0x57efbc!=null)_0x284078=_0x57efbc;else{if(_0x391df1!=null)_0x284078=at(_0x170032,_0x391df1);else return[];}if(_0x284078=_0x284078['withIndex'](_0x202085),!_0x284078['isEmpty']()&&!_0x284078['isLeafNode']()){const _0x1daae5=[],_0x4513e4=_0x202085['getCompare'](),_0x16f4cf=_0x2dcb6e?_0x284078['getReverseIteratorFrom'](_0x3302eb,_0x202085):_0x284078['getIteratorFrom'](_0x3302eb,_0x202085);let _0x23ffb7=_0x16f4cf['getNext']();for(;_0x23ffb7&&_0x1daae5['length']<_0x25f033;)_0x4513e4(_0x23ffb7,_0x3302eb)!==0x0&&_0x1daae5['push'](_0x23ffb7),_0x23ffb7=_0x16f4cf['getNext']();return _0x1daae5;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x3b8be2,_0x5400ee,_0x53cd4b,_0x53ede1){return Bo(_0x3b8be2['writeTree'],_0x3b8be2['treePath'],_0x5400ee,_0x53cd4b,_0x53ede1);}function is(_0x27da2a,_0x49bb7b){return _u(_0x27da2a['writeTree'],_0x27da2a['treePath'],_0x49bb7b);}function cr(_0x358d2f,_0x20e4ce,_0x236735,_0x47c44e){return gu(_0x358d2f['writeTree'],_0x358d2f['treePath'],_0x20e4ce,_0x236735,_0x47c44e);}function Tn(_0x2b5328,_0x191ed){return yu(_0x2b5328['writeTree'],k(_0x2b5328['treePath'],_0x191ed));}function Iu(_0x4d89a6,_0x923210,_0x5ece3d,_0x30300e,_0x4af287,_0x2d832d){return vu(_0x4d89a6['writeTree'],_0x4d89a6['treePath'],_0x923210,_0x5ece3d,_0x30300e,_0x4af287,_0x2d832d);}function ss(_0x2189fc,_0x5afc62,_0x408e68){return mu(_0x2189fc['writeTree'],_0x2189fc['treePath'],_0x5afc62,_0x408e68);}function Vo(_0x28b5f5,_0x3c5d98){return Ho(k(_0x28b5f5['treePath'],_0x3c5d98),_0x28b5f5['writeTree']);}function Ho(_0x36f128,_0x2806d4){return{'treePath':_0x36f128,'writeTree':_0x2806d4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x42b56b){const _0x35261b=_0x42b56b['type'],_0x1f3d36=_0x42b56b['childName'];f(_0x35261b==='child_added'||_0x35261b==='child_changed'||_0x35261b==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1f3d36!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5567b4=this['changeMap']['get'](_0x1f3d36);if(_0x5567b4){const _0x3fa135=_0x5567b4['type'];if(_0x35261b==='child_added'&&_0x3fa135==='child_removed')this['changeMap']['set'](_0x1f3d36,Lt(_0x1f3d36,_0x42b56b['snapshotNode'],_0x5567b4['snapshotNode']));else{if(_0x35261b==='child_removed'&&_0x3fa135==='child_added')this['changeMap']['delete'](_0x1f3d36);else{if(_0x35261b==='child_removed'&&_0x3fa135==='child_changed')this['changeMap']['set'](_0x1f3d36,Mt(_0x1f3d36,_0x5567b4['oldSnap']));else{if(_0x35261b==='child_changed'&&_0x3fa135==='child_added')this['changeMap']['set'](_0x1f3d36,rt(_0x1f3d36,_0x42b56b['snapshotNode']));else{if(_0x35261b==='child_changed'&&_0x3fa135==='child_changed')this['changeMap']['set'](_0x1f3d36,Lt(_0x1f3d36,_0x42b56b['snapshotNode'],_0x5567b4['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x42b56b+'\x20occurred\x20after\x20'+_0x5567b4);}}}}}else this['changeMap']['set'](_0x1f3d36,_0x42b56b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x1aa9e7){return null;}['getChildAfterChild'](_0x42c15a,_0x43bf22,_0x379db0){return null;}}const $o=new Cu();class rs{constructor(_0x44ea3d,_0x40d9c5,_0x543c26=null){this['writes_']=_0x44ea3d,this['viewCache_']=_0x40d9c5,this['optCompleteServerCache_']=_0x543c26;}['getCompleteChild'](_0x1f9a94){const _0x3d5a53=this['viewCache_']['eventCache'];if(_0x3d5a53['isCompleteForChild'](_0x1f9a94))return _0x3d5a53['getNode']()['getImmediateChild'](_0x1f9a94);{const _0x306214=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x1f9a94,_0x306214);}}['getChildAfterChild'](_0xcee18a,_0x5cd493,_0x3d21a5){const _0x4e1c26=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x46a190=Iu(this['writes_'],_0x4e1c26,_0x5cd493,0x1,_0x3d21a5,_0xcee18a);return _0x46a190['length']===0x0?null:_0x46a190[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x59734c){return{'filter':_0x59734c};}function Su(_0x28f0b8,_0x4bac57){f(_0x4bac57['eventCache']['getNode']()['isIndexed'](_0x28f0b8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4bac57['serverCache']['getNode']()['isIndexed'](_0x28f0b8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x4d3104,_0x3aef7d,_0x288cef,_0x2c2701,_0x1e4797){const _0x1e628e=new wu();let _0x5d6a0c,_0x418762;if(_0x288cef['type']===z['OVERWRITE']){const _0x1dd686=_0x288cef;_0x1dd686['source']['fromUser']?_0x5d6a0c=ki(_0x4d3104,_0x3aef7d,_0x1dd686['path'],_0x1dd686['snap'],_0x2c2701,_0x1e4797,_0x1e628e):(f(_0x1dd686['source']['fromServer'],'Unknown\x20source.'),_0x418762=_0x1dd686['source']['tagged']||_0x3aef7d['serverCache']['isFiltered']()&&!v(_0x1dd686['path']),_0x5d6a0c=Sn(_0x4d3104,_0x3aef7d,_0x1dd686['path'],_0x1dd686['snap'],_0x2c2701,_0x1e4797,_0x418762,_0x1e628e));}else{if(_0x288cef['type']===z['MERGE']){const _0x31c0f0=_0x288cef;_0x31c0f0['source']['fromUser']?_0x5d6a0c=Au(_0x4d3104,_0x3aef7d,_0x31c0f0['path'],_0x31c0f0['children'],_0x2c2701,_0x1e4797,_0x1e628e):(f(_0x31c0f0['source']['fromServer'],'Unknown\x20source.'),_0x418762=_0x31c0f0['source']['tagged']||_0x3aef7d['serverCache']['isFiltered'](),_0x5d6a0c=Ni(_0x4d3104,_0x3aef7d,_0x31c0f0['path'],_0x31c0f0['children'],_0x2c2701,_0x1e4797,_0x418762,_0x1e628e));}else{if(_0x288cef['type']===z['ACK_USER_WRITE']){const _0x2ed719=_0x288cef;_0x2ed719['revert']?_0x5d6a0c=Pu(_0x4d3104,_0x3aef7d,_0x2ed719['path'],_0x2c2701,_0x1e4797,_0x1e628e):_0x5d6a0c=ku(_0x4d3104,_0x3aef7d,_0x2ed719['path'],_0x2ed719['affectedTree'],_0x2c2701,_0x1e4797,_0x1e628e);}else{if(_0x288cef['type']===z['LISTEN_COMPLETE'])_0x5d6a0c=Nu(_0x4d3104,_0x3aef7d,_0x288cef['path'],_0x2c2701,_0x1e628e);else throw ht('Unknown\x20operation\x20type:\x20'+_0x288cef['type']);}}}const _0x1bd05d=_0x1e628e['getChanges']();return Ru(_0x3aef7d,_0x5d6a0c,_0x1bd05d),{'viewCache':_0x5d6a0c,'changes':_0x1bd05d};}function Ru(_0x21541c,_0x1722e5,_0x3d7aad){const _0x46c72c=_0x1722e5['eventCache'];if(_0x46c72c['isFullyInitialized']()){const _0xd35832=_0x46c72c['getNode']()['isLeafNode']()||_0x46c72c['getNode']()['isEmpty'](),_0x2d09c0=wn(_0x21541c);(_0x3d7aad['length']>0x0||!_0x21541c['eventCache']['isFullyInitialized']()||_0xd35832&&!_0x46c72c['getNode']()['equals'](_0x2d09c0)||!_0x46c72c['getNode']()['getPriority']()['equals'](_0x2d09c0['getPriority']()))&&_0x3d7aad['push'](Lo(wn(_0x1722e5)));}}function Go(_0x2e71ed,_0x2cfde7,_0x463029,_0x55ebe5,_0x344653,_0x3910f7){const _0x89c29=_0x2cfde7['eventCache'];if(Tn(_0x55ebe5,_0x463029)!=null)return _0x2cfde7;{let _0x535d1a,_0x2f56b2;if(v(_0x463029)){if(f(_0x2cfde7['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2cfde7['serverCache']['isFiltered']()){const _0x459910=Be(_0x2cfde7),_0x4df52b=_0x459910 instanceof g?_0x459910:g['EMPTY_NODE'],_0x2b5d1a=is(_0x55ebe5,_0x4df52b);_0x535d1a=_0x2e71ed['filter']['updateFullNode'](_0x2cfde7['eventCache']['getNode'](),_0x2b5d1a,_0x3910f7);}else{const _0x37dec1=Cn(_0x55ebe5,Be(_0x2cfde7));_0x535d1a=_0x2e71ed['filter']['updateFullNode'](_0x2cfde7['eventCache']['getNode'](),_0x37dec1,_0x3910f7);}}else{const _0x5726bb=y(_0x463029);if(_0x5726bb==='.priority'){f(Ce(_0x463029)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x487bc0=_0x89c29['getNode']();_0x2f56b2=_0x2cfde7['serverCache']['getNode']();const _0xb18cf7=cr(_0x55ebe5,_0x463029,_0x487bc0,_0x2f56b2);_0xb18cf7!=null?_0x535d1a=_0x2e71ed['filter']['updatePriority'](_0x487bc0,_0xb18cf7):_0x535d1a=_0x89c29['getNode']();}else{const _0x1520b4=S(_0x463029);let _0x486eca;if(_0x89c29['isCompleteForChild'](_0x5726bb)){_0x2f56b2=_0x2cfde7['serverCache']['getNode']();const _0x477265=cr(_0x55ebe5,_0x463029,_0x89c29['getNode'](),_0x2f56b2);_0x477265!=null?_0x486eca=_0x89c29['getNode']()['getImmediateChild'](_0x5726bb)['updateChild'](_0x1520b4,_0x477265):_0x486eca=_0x89c29['getNode']()['getImmediateChild'](_0x5726bb);}else _0x486eca=ss(_0x55ebe5,_0x5726bb,_0x2cfde7['serverCache']);_0x486eca!=null?_0x535d1a=_0x2e71ed['filter']['updateChild'](_0x89c29['getNode'](),_0x5726bb,_0x486eca,_0x1520b4,_0x344653,_0x3910f7):_0x535d1a=_0x89c29['getNode']();}}return bt(_0x2cfde7,_0x535d1a,_0x89c29['isFullyInitialized']()||v(_0x463029),_0x2e71ed['filter']['filtersNodes']());}}function Sn(_0x10c042,_0x4eccd5,_0x25a2a1,_0x540720,_0x85b57,_0x523847,_0x5b0ade,_0x553b40){const _0x3c910c=_0x4eccd5['serverCache'];let _0x1a24b2;const _0x4cc7d8=_0x5b0ade?_0x10c042['filter']:_0x10c042['filter']['getIndexedFilter']();if(v(_0x25a2a1))_0x1a24b2=_0x4cc7d8['updateFullNode'](_0x3c910c['getNode'](),_0x540720,null);else{if(_0x4cc7d8['filtersNodes']()&&!_0x3c910c['isFiltered']()){const _0x1379bf=_0x3c910c['getNode']()['updateChild'](_0x25a2a1,_0x540720);_0x1a24b2=_0x4cc7d8['updateFullNode'](_0x3c910c['getNode'](),_0x1379bf,null);}else{const _0x2e6690=y(_0x25a2a1);if(!_0x3c910c['isCompleteForPath'](_0x25a2a1)&&Ce(_0x25a2a1)>0x1)return _0x4eccd5;const _0x1c1187=S(_0x25a2a1),_0x51b931=_0x3c910c['getNode']()['getImmediateChild'](_0x2e6690)['updateChild'](_0x1c1187,_0x540720);_0x2e6690==='.priority'?_0x1a24b2=_0x4cc7d8['updatePriority'](_0x3c910c['getNode'](),_0x51b931):_0x1a24b2=_0x4cc7d8['updateChild'](_0x3c910c['getNode'](),_0x2e6690,_0x51b931,_0x1c1187,$o,null);}}const _0x2a0079=Fo(_0x4eccd5,_0x1a24b2,_0x3c910c['isFullyInitialized']()||v(_0x25a2a1),_0x4cc7d8['filtersNodes']()),_0x11caf1=new rs(_0x85b57,_0x2a0079,_0x523847);return Go(_0x10c042,_0x2a0079,_0x25a2a1,_0x85b57,_0x11caf1,_0x553b40);}function ki(_0x2261ee,_0xfcb87f,_0x2df583,_0x4af512,_0xb8207d,_0x42a988,_0x280b70){const _0x5ce6fc=_0xfcb87f['eventCache'];let _0x75b321,_0x3ffadf;const _0x28f0ae=new rs(_0xb8207d,_0xfcb87f,_0x42a988);if(v(_0x2df583))_0x3ffadf=_0x2261ee['filter']['updateFullNode'](_0xfcb87f['eventCache']['getNode'](),_0x4af512,_0x280b70),_0x75b321=bt(_0xfcb87f,_0x3ffadf,!0x0,_0x2261ee['filter']['filtersNodes']());else{const _0x5861a9=y(_0x2df583);if(_0x5861a9==='.priority')_0x3ffadf=_0x2261ee['filter']['updatePriority'](_0xfcb87f['eventCache']['getNode'](),_0x4af512),_0x75b321=bt(_0xfcb87f,_0x3ffadf,_0x5ce6fc['isFullyInitialized'](),_0x5ce6fc['isFiltered']());else{const _0x2b084f=S(_0x2df583),_0x161cd1=_0x5ce6fc['getNode']()['getImmediateChild'](_0x5861a9);let _0x587731;if(v(_0x2b084f))_0x587731=_0x4af512;else{const _0x5896e7=_0x28f0ae['getCompleteChild'](_0x5861a9);_0x5896e7!=null?ji(_0x2b084f)==='.priority'&&_0x5896e7['getChild'](Ro(_0x2b084f))['isEmpty']()?_0x587731=_0x5896e7:_0x587731=_0x5896e7['updateChild'](_0x2b084f,_0x4af512):_0x587731=g['EMPTY_NODE'];}if(_0x161cd1['equals'](_0x587731))_0x75b321=_0xfcb87f;else{const _0x4e0fec=_0x2261ee['filter']['updateChild'](_0x5ce6fc['getNode'](),_0x5861a9,_0x587731,_0x2b084f,_0x28f0ae,_0x280b70);_0x75b321=bt(_0xfcb87f,_0x4e0fec,_0x5ce6fc['isFullyInitialized'](),_0x2261ee['filter']['filtersNodes']());}}}return _0x75b321;}function lr(_0x54d8be,_0x243a0c){return _0x54d8be['eventCache']['isCompleteForChild'](_0x243a0c);}function Au(_0x5979eb,_0x1ec720,_0x41b5f6,_0x5878c6,_0x2fcc23,_0x5db9ad,_0x1bb493){let _0x2f5edb=_0x1ec720;return _0x5878c6['foreach']((_0xa45a60,_0x2d3809)=>{const _0xb458e3=k(_0x41b5f6,_0xa45a60);lr(_0x1ec720,y(_0xb458e3))&&(_0x2f5edb=ki(_0x5979eb,_0x2f5edb,_0xb458e3,_0x2d3809,_0x2fcc23,_0x5db9ad,_0x1bb493));}),_0x5878c6['foreach']((_0x47f52c,_0x4f24b9)=>{const _0x20ada0=k(_0x41b5f6,_0x47f52c);lr(_0x1ec720,y(_0x20ada0))||(_0x2f5edb=ki(_0x5979eb,_0x2f5edb,_0x20ada0,_0x4f24b9,_0x2fcc23,_0x5db9ad,_0x1bb493));}),_0x2f5edb;}function hr(_0x2ff314,_0x20b5ba,_0x16bd2f){return _0x16bd2f['foreach']((_0x25989e,_0x199bbb)=>{_0x20b5ba=_0x20b5ba['updateChild'](_0x25989e,_0x199bbb);}),_0x20b5ba;}function Ni(_0x486e0e,_0x56a800,_0x2305f3,_0xfe1445,_0x1053f2,_0x27a4a1,_0x50ad03,_0x1f0268){if(_0x56a800['serverCache']['getNode']()['isEmpty']()&&!_0x56a800['serverCache']['isFullyInitialized']())return _0x56a800;let _0x2350b3=_0x56a800,_0x584345;v(_0x2305f3)?_0x584345=_0xfe1445:_0x584345=new b(null)['setTree'](_0x2305f3,_0xfe1445);const _0x10a1cc=_0x56a800['serverCache']['getNode']();return _0x584345['children']['inorderTraversal']((_0x26bd4d,_0x4a3e2a)=>{if(_0x10a1cc['hasChild'](_0x26bd4d)){const _0x17fce8=_0x56a800['serverCache']['getNode']()['getImmediateChild'](_0x26bd4d),_0x101d62=hr(_0x486e0e,_0x17fce8,_0x4a3e2a);_0x2350b3=Sn(_0x486e0e,_0x2350b3,new C(_0x26bd4d),_0x101d62,_0x1053f2,_0x27a4a1,_0x50ad03,_0x1f0268);}}),_0x584345['children']['inorderTraversal']((_0x9d014,_0x4222ac)=>{const _0x16363c=!_0x56a800['serverCache']['isCompleteForChild'](_0x9d014)&&_0x4222ac['value']===null;if(!_0x10a1cc['hasChild'](_0x9d014)&&!_0x16363c){const _0x19c241=_0x56a800['serverCache']['getNode']()['getImmediateChild'](_0x9d014),_0x38e643=hr(_0x486e0e,_0x19c241,_0x4222ac);_0x2350b3=Sn(_0x486e0e,_0x2350b3,new C(_0x9d014),_0x38e643,_0x1053f2,_0x27a4a1,_0x50ad03,_0x1f0268);}}),_0x2350b3;}function ku(_0x2e0efd,_0x37c739,_0x5afc23,_0x36d5c9,_0x2420ff,_0xf6a947,_0x1d2136){if(Tn(_0x2420ff,_0x5afc23)!=null)return _0x37c739;const _0x168012=_0x37c739['serverCache']['isFiltered'](),_0x243dab=_0x37c739['serverCache'];if(_0x36d5c9['value']!=null){if(v(_0x5afc23)&&_0x243dab['isFullyInitialized']()||_0x243dab['isCompleteForPath'](_0x5afc23))return Sn(_0x2e0efd,_0x37c739,_0x5afc23,_0x243dab['getNode']()['getChild'](_0x5afc23),_0x2420ff,_0xf6a947,_0x168012,_0x1d2136);if(v(_0x5afc23)){let _0x526f0e=new b(null);return _0x243dab['getNode']()['forEachChild'](ve,(_0x1a36b2,_0x3731fa)=>{_0x526f0e=_0x526f0e['set'](new C(_0x1a36b2),_0x3731fa);}),Ni(_0x2e0efd,_0x37c739,_0x5afc23,_0x526f0e,_0x2420ff,_0xf6a947,_0x168012,_0x1d2136);}else return _0x37c739;}else{let _0x39f631=new b(null);return _0x36d5c9['foreach']((_0x41ac4f,_0x4337c0)=>{const _0x4d03ec=k(_0x5afc23,_0x41ac4f);_0x243dab['isCompleteForPath'](_0x4d03ec)&&(_0x39f631=_0x39f631['set'](_0x41ac4f,_0x243dab['getNode']()['getChild'](_0x4d03ec)));}),Ni(_0x2e0efd,_0x37c739,_0x5afc23,_0x39f631,_0x2420ff,_0xf6a947,_0x168012,_0x1d2136);}}function Nu(_0x2b5da9,_0x1931f6,_0x49af31,_0x3a2ed7,_0x57cdcd){const _0x3b896d=_0x1931f6['serverCache'],_0xb63305=Fo(_0x1931f6,_0x3b896d['getNode'](),_0x3b896d['isFullyInitialized']()||v(_0x49af31),_0x3b896d['isFiltered']());return Go(_0x2b5da9,_0xb63305,_0x49af31,_0x3a2ed7,$o,_0x57cdcd);}function Pu(_0x1f8e1c,_0x47b26a,_0x27558a,_0x10854d,_0x437375,_0x12ea42){let _0x4e0bce;if(Tn(_0x10854d,_0x27558a)!=null)return _0x47b26a;{const _0x4163dc=new rs(_0x10854d,_0x47b26a,_0x437375),_0x3946bf=_0x47b26a['eventCache']['getNode']();let _0x56a588;if(v(_0x27558a)||y(_0x27558a)==='.priority'){let _0x2a4269;if(_0x47b26a['serverCache']['isFullyInitialized']())_0x2a4269=Cn(_0x10854d,Be(_0x47b26a));else{const _0x5356de=_0x47b26a['serverCache']['getNode']();f(_0x5356de instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2a4269=is(_0x10854d,_0x5356de);}_0x2a4269=_0x2a4269,_0x56a588=_0x1f8e1c['filter']['updateFullNode'](_0x3946bf,_0x2a4269,_0x12ea42);}else{const _0x1b3e29=y(_0x27558a);let _0x5c62ab=ss(_0x10854d,_0x1b3e29,_0x47b26a['serverCache']);_0x5c62ab==null&&_0x47b26a['serverCache']['isCompleteForChild'](_0x1b3e29)&&(_0x5c62ab=_0x3946bf['getImmediateChild'](_0x1b3e29)),_0x5c62ab!=null?_0x56a588=_0x1f8e1c['filter']['updateChild'](_0x3946bf,_0x1b3e29,_0x5c62ab,S(_0x27558a),_0x4163dc,_0x12ea42):_0x47b26a['eventCache']['getNode']()['hasChild'](_0x1b3e29)?_0x56a588=_0x1f8e1c['filter']['updateChild'](_0x3946bf,_0x1b3e29,g['EMPTY_NODE'],S(_0x27558a),_0x4163dc,_0x12ea42):_0x56a588=_0x3946bf,_0x56a588['isEmpty']()&&_0x47b26a['serverCache']['isFullyInitialized']()&&(_0x4e0bce=Cn(_0x10854d,Be(_0x47b26a)),_0x4e0bce['isLeafNode']()&&(_0x56a588=_0x1f8e1c['filter']['updateFullNode'](_0x56a588,_0x4e0bce,_0x12ea42)));}return _0x4e0bce=_0x47b26a['serverCache']['isFullyInitialized']()||Tn(_0x10854d,w())!=null,bt(_0x47b26a,_0x56a588,_0x4e0bce,_0x1f8e1c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x5a7c53,_0x4a3296){this['query_']=_0x5a7c53,this['eventRegistrations_']=[];const _0x53f0cf=this['query_']['_queryParams'],_0x3f9f6e=new Xi(_0x53f0cf['getIndex']()),_0x919904=Kh(_0x53f0cf);this['processor_']=Tu(_0x919904);const _0x33f361=_0x4a3296['serverCache'],_0x159552=_0x4a3296['eventCache'],_0x361cb9=_0x3f9f6e['updateFullNode'](g['EMPTY_NODE'],_0x33f361['getNode'](),null),_0x437156=_0x919904['updateFullNode'](g['EMPTY_NODE'],_0x159552['getNode'](),null),_0x545042=new Te(_0x361cb9,_0x33f361['isFullyInitialized'](),_0x3f9f6e['filtersNodes']()),_0x586fc4=new Te(_0x437156,_0x159552['isFullyInitialized'](),_0x919904['filtersNodes']());this['viewCache_']=Un(_0x586fc4,_0x545042),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0xd80489){return _0xd80489['viewCache_']['serverCache']['getNode']();}function Mu(_0x391f79){return wn(_0x391f79['viewCache_']);}function Lu(_0x5e601e,_0x425f85){const _0x6b8c20=Be(_0x5e601e['viewCache_']);return _0x6b8c20&&(_0x5e601e['query']['_queryParams']['loadsAllData']()||!v(_0x425f85)&&!_0x6b8c20['getImmediateChild'](y(_0x425f85))['isEmpty']())?_0x6b8c20['getChild'](_0x425f85):null;}function ur(_0xdfa0aa){return _0xdfa0aa['eventRegistrations_']['length']===0x0;}function xu(_0x18d573,_0x49f890){_0x18d573['eventRegistrations_']['push'](_0x49f890);}function dr(_0x3d443b,_0x16955b,_0xb689d3){const _0x54373c=[];if(_0xb689d3){f(_0x16955b==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5e5407=_0x3d443b['query']['_path'];_0x3d443b['eventRegistrations_']['forEach'](_0x484b87=>{const _0x3190e6=_0x484b87['createCancelEvent'](_0xb689d3,_0x5e5407);_0x3190e6&&_0x54373c['push'](_0x3190e6);});}if(_0x16955b){let _0x51a889=[];for(let _0x319074=0x0;_0x319074<_0x3d443b['eventRegistrations_']['length'];++_0x319074){const _0xec45bd=_0x3d443b['eventRegistrations_'][_0x319074];if(!_0xec45bd['matches'](_0x16955b))_0x51a889['push'](_0xec45bd);else{if(_0x16955b['hasAnyCallback']()){_0x51a889=_0x51a889['concat'](_0x3d443b['eventRegistrations_']['slice'](_0x319074+0x1));break;}}}_0x3d443b['eventRegistrations_']=_0x51a889;}else _0x3d443b['eventRegistrations_']=[];return _0x54373c;}function fr(_0xe1fe36,_0x5c4f37,_0x1d1d98,_0x1023a5){_0x5c4f37['type']===z['MERGE']&&_0x5c4f37['source']['queryId']!==null&&(f(Be(_0xe1fe36['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0xe1fe36['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3a4d45=_0xe1fe36['viewCache_'],_0x533b61=bu(_0xe1fe36['processor_'],_0x3a4d45,_0x5c4f37,_0x1d1d98,_0x1023a5);return Su(_0xe1fe36['processor_'],_0x533b61['viewCache']),f(_0x533b61['viewCache']['serverCache']['isFullyInitialized']()||!_0x3a4d45['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xe1fe36['viewCache_']=_0x533b61['viewCache'],qo(_0xe1fe36,_0x533b61['changes'],_0x533b61['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x2223b8,_0x20869b){const _0xe4a63f=_0x2223b8['viewCache_']['eventCache'],_0x45579f=[];return _0xe4a63f['getNode']()['isLeafNode']()||_0xe4a63f['getNode']()['forEachChild'](R,(_0x2636d0,_0xb7cd58)=>{_0x45579f['push'](rt(_0x2636d0,_0xb7cd58));}),_0xe4a63f['isFullyInitialized']()&&_0x45579f['push'](Lo(_0xe4a63f['getNode']())),qo(_0x2223b8,_0x45579f,_0xe4a63f['getNode'](),_0x20869b);}function qo(_0x5d3416,_0x52688a,_0x39315d,_0x2f6711){const _0x355582=_0x2f6711?[_0x2f6711]:_0x5d3416['eventRegistrations_'];return su(_0x5d3416['eventGenerator_'],_0x52688a,_0x39315d,_0x355582);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x539dd6){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x539dd6;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x55b815){return _0x55b815['views']['size']===0x0;}function os(_0x5838cf,_0x838cba,_0x5b18e5,_0x51f508){const _0x5b082b=_0x838cba['source']['queryId'];if(_0x5b082b!==null){const _0xab3063=_0x5838cf['views']['get'](_0x5b082b);return f(_0xab3063!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xab3063,_0x838cba,_0x5b18e5,_0x51f508);}else{let _0x1b5d18=[];for(const _0x379a25 of _0x5838cf['views']['values']())_0x1b5d18=_0x1b5d18['concat'](fr(_0x379a25,_0x838cba,_0x5b18e5,_0x51f508));return _0x1b5d18;}}function jo(_0x4b3d57,_0x32c221,_0x2b339b,_0x3e8927,_0x2810a1){const _0x108281=_0x32c221['_queryIdentifier'],_0x18787e=_0x4b3d57['views']['get'](_0x108281);if(!_0x18787e){let _0x5a51d4=Cn(_0x2b339b,_0x2810a1?_0x3e8927:null),_0x231613=!0x1;_0x5a51d4?_0x231613=!0x0:_0x3e8927 instanceof g?(_0x5a51d4=is(_0x2b339b,_0x3e8927),_0x231613=!0x1):(_0x5a51d4=g['EMPTY_NODE'],_0x231613=!0x1);const _0x2f1757=Un(new Te(_0x5a51d4,_0x231613,!0x1),new Te(_0x3e8927,_0x2810a1,!0x1));return new Ou(_0x32c221,_0x2f1757);}return _0x18787e;}function Vu(_0x10630a,_0x4483bd,_0x1c2913,_0x315e4e,_0x3ce917,_0x4ebdd8){const _0x56cc28=jo(_0x10630a,_0x4483bd,_0x315e4e,_0x3ce917,_0x4ebdd8);return _0x10630a['views']['has'](_0x4483bd['_queryIdentifier'])||_0x10630a['views']['set'](_0x4483bd['_queryIdentifier'],_0x56cc28),xu(_0x56cc28,_0x1c2913),Fu(_0x56cc28,_0x1c2913);}function Hu(_0x116243,_0x2cb1fc,_0x809ccc,_0xeb4579){const _0x123a43=_0x2cb1fc['_queryIdentifier'],_0x29c4ed=[];let _0x21ee25=[];const _0x16625e=Se(_0x116243);if(_0x123a43==='default'){for(const [_0x50707d,_0x277bf8]of _0x116243['views']['entries']())_0x21ee25=_0x21ee25['concat'](dr(_0x277bf8,_0x809ccc,_0xeb4579)),ur(_0x277bf8)&&(_0x116243['views']['delete'](_0x50707d),_0x277bf8['query']['_queryParams']['loadsAllData']()||_0x29c4ed['push'](_0x277bf8['query']));}else{const _0x56dc41=_0x116243['views']['get'](_0x123a43);_0x56dc41&&(_0x21ee25=_0x21ee25['concat'](dr(_0x56dc41,_0x809ccc,_0xeb4579)),ur(_0x56dc41)&&(_0x116243['views']['delete'](_0x123a43),_0x56dc41['query']['_queryParams']['loadsAllData']()||_0x29c4ed['push'](_0x56dc41['query'])));}return _0x16625e&&!Se(_0x116243)&&_0x29c4ed['push'](new(Wu())(_0x2cb1fc['_repo'],_0x2cb1fc['_path'])),{'removed':_0x29c4ed,'events':_0x21ee25};}function Ko(_0x126b88){const _0x2ab597=[];for(const _0x1907c2 of _0x126b88['views']['values']())_0x1907c2['query']['_queryParams']['loadsAllData']()||_0x2ab597['push'](_0x1907c2);return _0x2ab597;}function Ie(_0x4ecd1d,_0x452f2f){let _0x3b8187=null;for(const _0x21035b of _0x4ecd1d['views']['values']())_0x3b8187=_0x3b8187||Lu(_0x21035b,_0x452f2f);return _0x3b8187;}function Yo(_0x2d8624,_0x31a6a0){if(_0x31a6a0['_queryParams']['loadsAllData']())return Bn(_0x2d8624);{const _0x5ef068=_0x31a6a0['_queryIdentifier'];return _0x2d8624['views']['get'](_0x5ef068);}}function Qo(_0x731b8f,_0x275652){return Yo(_0x731b8f,_0x275652)!=null;}function Se(_0x53d0dc){return Bn(_0x53d0dc)!=null;}function Bn(_0x837a27){for(const _0x18781f of _0x837a27['views']['values']())if(_0x18781f['query']['_queryParams']['loadsAllData']())return _0x18781f;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x420cdf){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x420cdf;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x1ce0ff){this['listenProvider_']=_0x1ce0ff,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x47bfab,_0xfe9338,_0x588f99,_0x3ada4e,_0x5d20fe){return cu(_0x47bfab['pendingWriteTree_'],_0xfe9338,_0x588f99,_0x3ada4e,_0x5d20fe),_0x5d20fe?_t(_0x47bfab,new We(es(),_0xfe9338,_0x588f99)):[];}function zu(_0x2bc90a,_0x47c869,_0x2857d4,_0x1e05eb){lu(_0x2bc90a['pendingWriteTree_'],_0x47c869,_0x2857d4,_0x1e05eb);const _0x10bfd0=b['fromObject'](_0x2857d4);return _t(_0x2bc90a,new ot(es(),_0x47c869,_0x10bfd0));}function _e(_0x4a1710,_0x15e612,_0x1ff755=!0x1){const _0x543677=hu(_0x4a1710['pendingWriteTree_'],_0x15e612);if(uu(_0x4a1710['pendingWriteTree_'],_0x15e612)){let _0x4bc21f=new b(null);return _0x543677['snap']!=null?_0x4bc21f=_0x4bc21f['set'](w(),!0x0):x(_0x543677['children'],_0x4bffea=>{_0x4bc21f=_0x4bc21f['set'](new C(_0x4bffea),!0x0);}),_t(_0x4a1710,new In(_0x543677['path'],_0x4bc21f,_0x1ff755));}else return[];}function Kt(_0x27afe6,_0x312d2c,_0x558e3b){return _t(_0x27afe6,new We(ts(),_0x312d2c,_0x558e3b));}function ju(_0xf8cde,_0x1fc056,_0x158bca){const _0xef8e57=b['fromObject'](_0x158bca);return _t(_0xf8cde,new ot(ts(),_0x1fc056,_0xef8e57));}function Ku(_0x2c29ce,_0x2c10e9){return _t(_0x2c29ce,new Ft(ts(),_0x2c10e9));}function Yu(_0x138383,_0x330240,_0x3580fa){const _0x569ec1=cs(_0x138383,_0x3580fa);if(_0x569ec1){const _0x4dbe19=ls(_0x569ec1),_0x1d1cfc=_0x4dbe19['path'],_0x1e6a5d=_0x4dbe19['queryId'],_0x284cf1=F(_0x1d1cfc,_0x330240),_0x190869=new Ft(ns(_0x1e6a5d),_0x284cf1);return hs(_0x138383,_0x1d1cfc,_0x190869);}else return[];}function An(_0x3fb8ae,_0x2635f6,_0x20e1d7,_0x3f7613,_0x98fd24=!0x1){const _0x39c2e4=_0x2635f6['_path'],_0x26394c=_0x3fb8ae['syncPointTree_']['get'](_0x39c2e4);let _0x300af8=[];if(_0x26394c&&(_0x2635f6['_queryIdentifier']==='default'||Qo(_0x26394c,_0x2635f6))){const _0x27eb84=Hu(_0x26394c,_0x2635f6,_0x20e1d7,_0x3f7613);Bu(_0x26394c)&&(_0x3fb8ae['syncPointTree_']=_0x3fb8ae['syncPointTree_']['remove'](_0x39c2e4));const _0x10f812=_0x27eb84['removed'];if(_0x300af8=_0x27eb84['events'],!_0x98fd24){const _0x17dd6b=_0x10f812['findIndex'](_0xe76f33=>_0xe76f33['_queryParams']['loadsAllData']())!==-0x1,_0x100490=_0x3fb8ae['syncPointTree_']['findOnPath'](_0x39c2e4,(_0x3b4d1a,_0xd1a905)=>Se(_0xd1a905));if(_0x17dd6b&&!_0x100490){const _0x5db4de=_0x3fb8ae['syncPointTree_']['subtree'](_0x39c2e4);if(!_0x5db4de['isEmpty']()){const _0x4773c7=Xu(_0x5db4de);for(let _0x4a5dbd=0x0;_0x4a5dbd<_0x4773c7['length'];++_0x4a5dbd){const _0x55cd55=_0x4773c7[_0x4a5dbd],_0x498f29=_0x55cd55['query'],_0x1de526=ea(_0x3fb8ae,_0x55cd55);_0x3fb8ae['listenProvider_']['startListening'](At(_0x498f29),Ut(_0x3fb8ae,_0x498f29),_0x1de526['hashFn'],_0x1de526['onComplete']);}}}!_0x100490&&_0x10f812['length']>0x0&&!_0x3f7613&&(_0x17dd6b?_0x3fb8ae['listenProvider_']['stopListening'](At(_0x2635f6),null):_0x10f812['forEach'](_0x597913=>{const _0x46c5f3=_0x3fb8ae['queryToTagMap']['get'](Hn(_0x597913));_0x3fb8ae['listenProvider_']['stopListening'](At(_0x597913),_0x46c5f3);}));}Zu(_0x3fb8ae,_0x10f812);}return _0x300af8;}function Jo(_0x261f4d,_0xb7cb1f,_0xd76e87,_0x72b579){const _0x465ef5=cs(_0x261f4d,_0x72b579);if(_0x465ef5!=null){const _0xecf0f2=ls(_0x465ef5),_0x169b56=_0xecf0f2['path'],_0x2ec416=_0xecf0f2['queryId'],_0x1fc5e1=F(_0x169b56,_0xb7cb1f),_0x232b24=new We(ns(_0x2ec416),_0x1fc5e1,_0xd76e87);return hs(_0x261f4d,_0x169b56,_0x232b24);}else return[];}function Qu(_0x1189fd,_0x1b8077,_0x2b3394,_0x20a3a4){const _0x393b99=cs(_0x1189fd,_0x20a3a4);if(_0x393b99){const _0x187647=ls(_0x393b99),_0x2c852a=_0x187647['path'],_0x358235=_0x187647['queryId'],_0x4bbd81=F(_0x2c852a,_0x1b8077),_0x380754=b['fromObject'](_0x2b3394),_0x13fc94=new ot(ns(_0x358235),_0x4bbd81,_0x380754);return hs(_0x1189fd,_0x2c852a,_0x13fc94);}else return[];}function Pi(_0x23c2b2,_0x2d5db5,_0x1fec8d,_0x1615c0=!0x1){const _0x2146c3=_0x2d5db5['_path'];let _0xb7b120=null,_0x18c453=!0x1;_0x23c2b2['syncPointTree_']['foreachOnPath'](_0x2146c3,(_0x263f44,_0x1ea081)=>{const _0x2a5656=F(_0x263f44,_0x2146c3);_0xb7b120=_0xb7b120||Ie(_0x1ea081,_0x2a5656),_0x18c453=_0x18c453||Se(_0x1ea081);});let _0x1bcf8f=_0x23c2b2['syncPointTree_']['get'](_0x2146c3);_0x1bcf8f?(_0x18c453=_0x18c453||Se(_0x1bcf8f),_0xb7b120=_0xb7b120||Ie(_0x1bcf8f,w())):(_0x1bcf8f=new zo(),_0x23c2b2['syncPointTree_']=_0x23c2b2['syncPointTree_']['set'](_0x2146c3,_0x1bcf8f));let _0x2e48ab;_0xb7b120!=null?_0x2e48ab=!0x0:(_0x2e48ab=!0x1,_0xb7b120=g['EMPTY_NODE'],_0x23c2b2['syncPointTree_']['subtree'](_0x2146c3)['foreachChild']((_0x5d3eed,_0x288eef)=>{const _0x37ff41=Ie(_0x288eef,w());_0x37ff41&&(_0xb7b120=_0xb7b120['updateImmediateChild'](_0x5d3eed,_0x37ff41));}));const _0x33c9be=Qo(_0x1bcf8f,_0x2d5db5);if(!_0x33c9be&&!_0x2d5db5['_queryParams']['loadsAllData']()){const _0x528576=Hn(_0x2d5db5);f(!_0x23c2b2['queryToTagMap']['has'](_0x528576),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xb1df8a=ed();_0x23c2b2['queryToTagMap']['set'](_0x528576,_0xb1df8a),_0x23c2b2['tagToQueryMap']['set'](_0xb1df8a,_0x528576);}const _0x53433b=Wn(_0x23c2b2['pendingWriteTree_'],_0x2146c3);let _0x442679=Vu(_0x1bcf8f,_0x2d5db5,_0x1fec8d,_0x53433b,_0xb7b120,_0x2e48ab);if(!_0x33c9be&&!_0x18c453&&!_0x1615c0){const _0x575699=Yo(_0x1bcf8f,_0x2d5db5);_0x442679=_0x442679['concat'](td(_0x23c2b2,_0x2d5db5,_0x575699));}return _0x442679;}function Vn(_0x2ea096,_0x70513f,_0x5c3075){const _0x2f7004=_0x2ea096['pendingWriteTree_'],_0x20a6f2=_0x2ea096['syncPointTree_']['findOnPath'](_0x70513f,(_0x28e56a,_0x5dc8e4)=>{const _0x483ef6=F(_0x28e56a,_0x70513f),_0x190d50=Ie(_0x5dc8e4,_0x483ef6);if(_0x190d50)return _0x190d50;});return Bo(_0x2f7004,_0x70513f,_0x20a6f2,_0x5c3075,!0x0);}function Ju(_0xecff89,_0x32127a){const _0x2751bd=_0x32127a['_path'];let _0x582355=null;_0xecff89['syncPointTree_']['foreachOnPath'](_0x2751bd,(_0x380bcb,_0x183a99)=>{const _0x32f429=F(_0x380bcb,_0x2751bd);_0x582355=_0x582355||Ie(_0x183a99,_0x32f429);});let _0x12241b=_0xecff89['syncPointTree_']['get'](_0x2751bd);_0x12241b?_0x582355=_0x582355||Ie(_0x12241b,w()):(_0x12241b=new zo(),_0xecff89['syncPointTree_']=_0xecff89['syncPointTree_']['set'](_0x2751bd,_0x12241b));const _0x2efeaa=_0x582355!=null,_0x53b84e=_0x2efeaa?new Te(_0x582355,!0x0,!0x1):null,_0x14138c=Wn(_0xecff89['pendingWriteTree_'],_0x32127a['_path']),_0x29b8bd=jo(_0x12241b,_0x32127a,_0x14138c,_0x2efeaa?_0x53b84e['getNode']():g['EMPTY_NODE'],_0x2efeaa);return Mu(_0x29b8bd);}function _t(_0x4a4b3f,_0x5b1297){return Xo(_0x5b1297,_0x4a4b3f['syncPointTree_'],null,Wn(_0x4a4b3f['pendingWriteTree_'],w()));}function Xo(_0xe680ac,_0x23fde3,_0x47e5e9,_0x59cea1){if(v(_0xe680ac['path']))return Zo(_0xe680ac,_0x23fde3,_0x47e5e9,_0x59cea1);{const _0x5eede0=_0x23fde3['get'](w());_0x47e5e9==null&&_0x5eede0!=null&&(_0x47e5e9=Ie(_0x5eede0,w()));let _0x5948c5=[];const _0x225717=y(_0xe680ac['path']),_0x17a6d0=_0xe680ac['operationForChild'](_0x225717),_0x40911e=_0x23fde3['children']['get'](_0x225717);if(_0x40911e&&_0x17a6d0){const _0x406857=_0x47e5e9?_0x47e5e9['getImmediateChild'](_0x225717):null,_0x56982c=Vo(_0x59cea1,_0x225717);_0x5948c5=_0x5948c5['concat'](Xo(_0x17a6d0,_0x40911e,_0x406857,_0x56982c));}return _0x5eede0&&(_0x5948c5=_0x5948c5['concat'](os(_0x5eede0,_0xe680ac,_0x59cea1,_0x47e5e9))),_0x5948c5;}}function Zo(_0x412ee3,_0x2df144,_0x50d9b1,_0x1ac145){const _0x47d9c3=_0x2df144['get'](w());_0x50d9b1==null&&_0x47d9c3!=null&&(_0x50d9b1=Ie(_0x47d9c3,w()));let _0x423a9d=[];return _0x2df144['children']['inorderTraversal']((_0x487888,_0x304ae2)=>{const _0x2a7b51=_0x50d9b1?_0x50d9b1['getImmediateChild'](_0x487888):null,_0x23310c=Vo(_0x1ac145,_0x487888),_0x1a6209=_0x412ee3['operationForChild'](_0x487888);_0x1a6209&&(_0x423a9d=_0x423a9d['concat'](Zo(_0x1a6209,_0x304ae2,_0x2a7b51,_0x23310c)));}),_0x47d9c3&&(_0x423a9d=_0x423a9d['concat'](os(_0x47d9c3,_0x412ee3,_0x1ac145,_0x50d9b1))),_0x423a9d;}function ea(_0x1b573a,_0xdcd6a4){const _0xde1596=_0xdcd6a4['query'],_0x242eef=Ut(_0x1b573a,_0xde1596);return{'hashFn':()=>(Du(_0xdcd6a4)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x45377e=>{if(_0x45377e==='ok')return _0x242eef?Yu(_0x1b573a,_0xde1596['_path'],_0x242eef):Ku(_0x1b573a,_0xde1596['_path']);{const _0x24338b=Kl(_0x45377e,_0xde1596);return An(_0x1b573a,_0xde1596,null,_0x24338b);}}};}function Ut(_0x25888c,_0x462ffd){const _0x1e3909=Hn(_0x462ffd);return _0x25888c['queryToTagMap']['get'](_0x1e3909);}function Hn(_0xa2dde4){return _0xa2dde4['_path']['toString']()+'$'+_0xa2dde4['_queryIdentifier'];}function cs(_0x2fb75f,_0x326bca){return _0x2fb75f['tagToQueryMap']['get'](_0x326bca);}function ls(_0x18fa1f){const _0x288de3=_0x18fa1f['indexOf']('$');return f(_0x288de3!==-0x1&&_0x288de3<_0x18fa1f['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x18fa1f['substr'](_0x288de3+0x1),'path':new C(_0x18fa1f['substr'](0x0,_0x288de3))};}function hs(_0x3e0442,_0x254805,_0x4b8add){const _0x17f728=_0x3e0442['syncPointTree_']['get'](_0x254805);f(_0x17f728,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5947e4=Wn(_0x3e0442['pendingWriteTree_'],_0x254805);return os(_0x17f728,_0x4b8add,_0x5947e4,null);}function Xu(_0x294acf){return _0x294acf['fold']((_0x1faecc,_0x3612c5,_0x312de6)=>{if(_0x3612c5&&Se(_0x3612c5))return[Bn(_0x3612c5)];{let _0xa18f83=[];return _0x3612c5&&(_0xa18f83=Ko(_0x3612c5)),x(_0x312de6,(_0x545fda,_0x33a211)=>{_0xa18f83=_0xa18f83['concat'](_0x33a211);}),_0xa18f83;}});}function At(_0x3d791e){return _0x3d791e['_queryParams']['loadsAllData']()&&!_0x3d791e['_queryParams']['isDefault']()?new(Gu())(_0x3d791e['_repo'],_0x3d791e['_path']):_0x3d791e;}function Zu(_0xef445c,_0x3fd745){for(let _0xebca46=0x0;_0xebca46<_0x3fd745['length'];++_0xebca46){const _0x4606a7=_0x3fd745[_0xebca46];if(!_0x4606a7['_queryParams']['loadsAllData']()){const _0x517977=Hn(_0x4606a7),_0xe8e0b7=_0xef445c['queryToTagMap']['get'](_0x517977);_0xef445c['queryToTagMap']['delete'](_0x517977),_0xef445c['tagToQueryMap']['delete'](_0xe8e0b7);}}}function ed(){return qu++;}function td(_0x16f997,_0x158a7d,_0x52ee5a){const _0xf251ac=_0x158a7d['_path'],_0x2821d6=Ut(_0x16f997,_0x158a7d),_0x4615f2=ea(_0x16f997,_0x52ee5a),_0x2ca86d=_0x16f997['listenProvider_']['startListening'](At(_0x158a7d),_0x2821d6,_0x4615f2['hashFn'],_0x4615f2['onComplete']),_0x5928fd=_0x16f997['syncPointTree_']['subtree'](_0xf251ac);if(_0x2821d6)f(!Se(_0x5928fd['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x438171=_0x5928fd['fold']((_0x344270,_0x269c17,_0x456d5c)=>{if(!v(_0x344270)&&_0x269c17&&Se(_0x269c17))return[Bn(_0x269c17)['query']];{let _0x1d69e1=[];return _0x269c17&&(_0x1d69e1=_0x1d69e1['concat'](Ko(_0x269c17)['map'](_0x5e88b8=>_0x5e88b8['query']))),x(_0x456d5c,(_0x2c0ef4,_0x273ef4)=>{_0x1d69e1=_0x1d69e1['concat'](_0x273ef4);}),_0x1d69e1;}});for(let _0x18028b=0x0;_0x18028b<_0x438171['length'];++_0x18028b){const _0x4b0f25=_0x438171[_0x18028b];_0x16f997['listenProvider_']['stopListening'](At(_0x4b0f25),Ut(_0x16f997,_0x4b0f25));}}return _0x2ca86d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x17b260){this['node_']=_0x17b260;}['getImmediateChild'](_0x5b3807){const _0x258e62=this['node_']['getImmediateChild'](_0x5b3807);return new us(_0x258e62);}['node'](){return this['node_'];}}class ds{constructor(_0x48809f,_0x213b8b){this['syncTree_']=_0x48809f,this['path_']=_0x213b8b;}['getImmediateChild'](_0x3fe1b0){const _0x33fbb8=k(this['path_'],_0x3fe1b0);return new ds(this['syncTree_'],_0x33fbb8);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0x4087d4){return _0x4087d4=_0x4087d4||{},_0x4087d4['timestamp']=_0x4087d4['timestamp']||new Date()['getTime'](),_0x4087d4;},_r=function(_0x4a8d3d,_0x13f15c,_0x57874e){if(!_0x4a8d3d||typeof _0x4a8d3d!='object')return _0x4a8d3d;if(f('.sv'in _0x4a8d3d,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4a8d3d['.sv']=='string')return id(_0x4a8d3d['.sv'],_0x13f15c,_0x57874e);if(typeof _0x4a8d3d['.sv']=='object')return sd(_0x4a8d3d['.sv'],_0x13f15c);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4a8d3d,null,0x2));},id=function(_0x2490c7,_0x47d813,_0x2887e1){switch(_0x2490c7){case'timestamp':return _0x2887e1['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2490c7);}},sd=function(_0x4621fd,_0x34eef4,_0x414cfb){_0x4621fd['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4621fd,null,0x2));const _0x500b72=_0x4621fd['increment'];typeof _0x500b72!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x500b72);const _0x1a1951=_0x34eef4['node']();if(f(_0x1a1951!==null&&typeof _0x1a1951<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1a1951['isLeafNode']())return _0x500b72;const _0x508420=_0x1a1951['getValue']();return typeof _0x508420!='number'?_0x500b72:_0x508420+_0x500b72;},ta=function(_0x36011c,_0x2a6d4e,_0x40b6de,_0x749453){return ps(_0x2a6d4e,new ds(_0x40b6de,_0x36011c),_0x749453);},fs=function(_0x405571,_0x1a24ac,_0x23854c){return ps(_0x405571,new us(_0x1a24ac),_0x23854c);};function ps(_0x111cd1,_0x1a7b89,_0x235a48){const _0x37f885=_0x111cd1['getPriority']()['val'](),_0x55c86b=_r(_0x37f885,_0x1a7b89['getImmediateChild']('.priority'),_0x235a48);let _0x169119;if(_0x111cd1['isLeafNode']()){const _0xe36eaa=_0x111cd1,_0x4b230d=_r(_0xe36eaa['getValue'](),_0x1a7b89,_0x235a48);return _0x4b230d!==_0xe36eaa['getValue']()||_0x55c86b!==_0xe36eaa['getPriority']()['val']()?new D(_0x4b230d,A(_0x55c86b)):_0x111cd1;}else{const _0x30979c=_0x111cd1;return _0x169119=_0x30979c,_0x55c86b!==_0x30979c['getPriority']()['val']()&&(_0x169119=_0x169119['updatePriority'](new D(_0x55c86b))),_0x30979c['forEachChild'](R,(_0x4dfeba,_0x48bb67)=>{const _0x24dc62=ps(_0x48bb67,_0x1a7b89['getImmediateChild'](_0x4dfeba),_0x235a48);_0x24dc62!==_0x48bb67&&(_0x169119=_0x169119['updateImmediateChild'](_0x4dfeba,_0x24dc62));}),_0x169119;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x386161='',_0x2e57e9=null,_0x45cc96={'children':{},'childCount':0x0}){this['name']=_0x386161,this['parent']=_0x2e57e9,this['node']=_0x45cc96;}}function $n(_0x10fd3d,_0x47cfd8){let _0x195025=_0x47cfd8 instanceof C?_0x47cfd8:new C(_0x47cfd8),_0xb98ace=_0x10fd3d,_0x330643=y(_0x195025);for(;_0x330643!==null;){const _0x26b48a=Me(_0xb98ace['node']['children'],_0x330643)||{'children':{},'childCount':0x0};_0xb98ace=new _s(_0x330643,_0xb98ace,_0x26b48a),_0x195025=S(_0x195025),_0x330643=y(_0x195025);}return _0xb98ace;}function ze(_0x397c12){return _0x397c12['node']['value'];}function gs(_0x22b6cc,_0x3a7884){_0x22b6cc['node']['value']=_0x3a7884,Oi(_0x22b6cc);}function na(_0x1a30b5){return _0x1a30b5['node']['childCount']>0x0;}function rd(_0x2ebc0a){return ze(_0x2ebc0a)===void 0x0&&!na(_0x2ebc0a);}function Gn(_0x4cc9e0,_0x500218){x(_0x4cc9e0['node']['children'],(_0x5332f2,_0x4b3467)=>{_0x500218(new _s(_0x5332f2,_0x4cc9e0,_0x4b3467));});}function ia(_0x6043d5,_0xcf6a4f,_0x104374,_0x44b7d4){_0x104374&&_0xcf6a4f(_0x6043d5),Gn(_0x6043d5,_0x18c9a7=>{ia(_0x18c9a7,_0xcf6a4f,!0x0);});}function od(_0x506d81,_0x215725,_0x30640f){let _0x4a0a11=_0x506d81['parent'];for(;_0x4a0a11!==null;){if(_0x215725(_0x4a0a11))return!0x0;_0x4a0a11=_0x4a0a11['parent'];}return!0x1;}function Yt(_0x1f89b1){return new C(_0x1f89b1['parent']===null?_0x1f89b1['name']:Yt(_0x1f89b1['parent'])+'/'+_0x1f89b1['name']);}function Oi(_0x45366b){_0x45366b['parent']!==null&&ad(_0x45366b['parent'],_0x45366b['name'],_0x45366b);}function ad(_0x4915b0,_0x587d34,_0x440989){const _0x395508=rd(_0x440989),_0x99aa59=Q(_0x4915b0['node']['children'],_0x587d34);_0x395508&&_0x99aa59?(delete _0x4915b0['node']['children'][_0x587d34],_0x4915b0['node']['childCount']--,Oi(_0x4915b0)):!_0x395508&&!_0x99aa59&&(_0x4915b0['node']['children'][_0x587d34]=_0x440989['node'],_0x4915b0['node']['childCount']++,Oi(_0x4915b0));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x38efaf){return typeof _0x38efaf=='string'&&_0x38efaf['length']!==0x0&&!cd['test'](_0x38efaf);},sa=function(_0x13d0c9){return typeof _0x13d0c9=='string'&&_0x13d0c9['length']!==0x0&&!ld['test'](_0x13d0c9);},hd=function(_0x4daed4){return _0x4daed4&&(_0x4daed4=_0x4daed4['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x4daed4);},Wt=function(_0x4887f4){return _0x4887f4===null||typeof _0x4887f4=='string'||typeof _0x4887f4=='number'&&!xn(_0x4887f4)||_0x4887f4&&typeof _0x4887f4=='object'&&Q(_0x4887f4,'.sv');},Ve=function(_0x2a1f74,_0x3688f8,_0xba1e69,_0x1c2791){_0x1c2791&&_0x3688f8===void 0x0||Qt(it(_0x2a1f74,'value'),_0x3688f8,_0xba1e69);},Qt=function(_0xa4a73e,_0x48b222,_0x41bac4){const _0x17f2fe=_0x41bac4 instanceof C?new Ah(_0x41bac4,_0xa4a73e):_0x41bac4;if(_0x48b222===void 0x0)throw new Error(_0xa4a73e+'contains\x20undefined\x20'+Pe(_0x17f2fe));if(typeof _0x48b222=='function')throw new Error(_0xa4a73e+'contains\x20a\x20function\x20'+Pe(_0x17f2fe)+'\x20with\x20contents\x20=\x20'+_0x48b222['toString']());if(xn(_0x48b222))throw new Error(_0xa4a73e+'contains\x20'+_0x48b222['toString']()+'\x20'+Pe(_0x17f2fe));if(typeof _0x48b222=='string'&&_0x48b222['length']>ui/0x3&&Ln(_0x48b222)>ui)throw new Error(_0xa4a73e+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x17f2fe)+'\x20(\x27'+_0x48b222['substring'](0x0,0x32)+'...\x27)');if(_0x48b222&&typeof _0x48b222=='object'){let _0x260954=!0x1,_0x53215c=!0x1;if(x(_0x48b222,(_0x5d7355,_0x38dbb0)=>{if(_0x5d7355==='.value')_0x260954=!0x0;else{if(_0x5d7355!=='.priority'&&_0x5d7355!=='.sv'&&(_0x53215c=!0x0,!ms(_0x5d7355)))throw new Error(_0xa4a73e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5d7355+')\x20'+Pe(_0x17f2fe)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x17f2fe,_0x5d7355),Qt(_0xa4a73e,_0x38dbb0,_0x17f2fe),Nh(_0x17f2fe);}),_0x260954&&_0x53215c)throw new Error(_0xa4a73e+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x17f2fe)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0x3264f2,_0x4cb1fb){let _0x49c5b5,_0x182990;for(_0x49c5b5=0x0;_0x49c5b5<_0x4cb1fb['length'];_0x49c5b5++){_0x182990=_0x4cb1fb[_0x49c5b5];const _0x3599a9=Dt(_0x182990);for(let _0x2eb9db=0x0;_0x2eb9db<_0x3599a9['length'];_0x2eb9db++)if(!(_0x3599a9[_0x2eb9db]==='.priority'&&_0x2eb9db===_0x3599a9['length']-0x1)){if(!ms(_0x3599a9[_0x2eb9db]))throw new Error(_0x3264f2+'contains\x20an\x20invalid\x20key\x20('+_0x3599a9[_0x2eb9db]+')\x20in\x20path\x20'+_0x182990['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4cb1fb['sort'](Rh);let _0x568525=null;for(_0x49c5b5=0x0;_0x49c5b5<_0x4cb1fb['length'];_0x49c5b5++){if(_0x182990=_0x4cb1fb[_0x49c5b5],_0x568525!==null&&G(_0x568525,_0x182990))throw new Error(_0x3264f2+'contains\x20a\x20path\x20'+_0x568525['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x182990['toString']());_0x568525=_0x182990;}},ra=function(_0x523535,_0x5e79f6,_0x5c7578,_0x1cea95){const _0x1c42df=it(_0x523535,'values');if(!(_0x5e79f6&&typeof _0x5e79f6=='object')||Array['isArray'](_0x5e79f6))throw new Error(_0x1c42df+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x161f33=[];x(_0x5e79f6,(_0x4e6cd8,_0x106042)=>{const _0x361dea=new C(_0x4e6cd8);if(Qt(_0x1c42df,_0x106042,k(_0x5c7578,_0x361dea)),ji(_0x361dea)==='.priority'&&!Wt(_0x106042))throw new Error(_0x1c42df+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x361dea['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x161f33['push'](_0x361dea);}),ud(_0x1c42df,_0x161f33);},dd=function(_0x3d87ff,_0x387cc9,_0x140ff6){if(xn(_0x387cc9))throw new Error(it(_0x3d87ff,'priority')+'is\x20'+_0x387cc9['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x387cc9))throw new Error(it(_0x3d87ff,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x37baa2,_0x42c29b,_0x4122b4,_0x367907){if(!sa(_0x4122b4))throw new Error(it(_0x37baa2,_0x42c29b)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4122b4+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0x851017,_0x272bc2,_0x1bac60,_0x5e375f){_0x1bac60&&(_0x1bac60=_0x1bac60['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x851017,_0x272bc2,_0x1bac60);},De=function(_0x419bac,_0x192a19){if(y(_0x192a19)==='.info')throw new Error(_0x419bac+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x57250f,_0xe234c8){const _0x4f1d0d=_0xe234c8['path']['toString']();if(typeof _0xe234c8['repoInfo']['host']!='string'||_0xe234c8['repoInfo']['host']['length']===0x0||!ms(_0xe234c8['repoInfo']['namespace'])&&_0xe234c8['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4f1d0d['length']!==0x0&&!hd(_0x4f1d0d))throw new Error(it(_0x57250f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x27bfae,_0x1430e7){let _0x9b20e5=null;for(let _0x546a12=0x0;_0x546a12<_0x1430e7['length'];_0x546a12++){const _0x23b9e0=_0x1430e7[_0x546a12],_0xdde740=_0x23b9e0['getPath']();_0x9b20e5!==null&&!Ki(_0xdde740,_0x9b20e5['path'])&&(_0x27bfae['eventLists_']['push'](_0x9b20e5),_0x9b20e5=null),_0x9b20e5===null&&(_0x9b20e5={'events':[],'path':_0xdde740}),_0x9b20e5['events']['push'](_0x23b9e0);}_0x9b20e5&&_0x27bfae['eventLists_']['push'](_0x9b20e5);}function oa(_0x1b478f,_0x1a5147,_0x30ef01){qn(_0x1b478f,_0x30ef01),aa(_0x1b478f,_0x24a968=>Ki(_0x24a968,_0x1a5147));}function V(_0x47845a,_0x1b82c7,_0x40005a){qn(_0x47845a,_0x40005a),aa(_0x47845a,_0x502870=>G(_0x502870,_0x1b82c7)||G(_0x1b82c7,_0x502870));}function aa(_0x545709,_0xb981a8){_0x545709['recursionDepth_']++;let _0x51d9f5=!0x0;for(let _0x3c9ff6=0x0;_0x3c9ff6<_0x545709['eventLists_']['length'];_0x3c9ff6++){const _0x5cc19d=_0x545709['eventLists_'][_0x3c9ff6];if(_0x5cc19d){const _0x3a1adb=_0x5cc19d['path'];_0xb981a8(_0x3a1adb)?(gd(_0x545709['eventLists_'][_0x3c9ff6]),_0x545709['eventLists_'][_0x3c9ff6]=null):_0x51d9f5=!0x1;}}_0x51d9f5&&(_0x545709['eventLists_']=[]),_0x545709['recursionDepth_']--;}function gd(_0x559bfd){for(let _0x19e3a8=0x0;_0x19e3a8<_0x559bfd['events']['length'];_0x19e3a8++){const _0x27560f=_0x559bfd['events'][_0x19e3a8];if(_0x27560f!==null){_0x559bfd['events'][_0x19e3a8]=null;const _0x4bf6dc=_0x27560f['getEventRunner']();Tt&&L('event:\x20'+_0x27560f['toString']()),ft(_0x4bf6dc);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x2f01d3,_0x3d926c,_0x10e16d,_0x510ec4){this['repoInfo_']=_0x2f01d3,this['forceRestClient_']=_0x3d926c,this['authTokenProvider_']=_0x10e16d,this['appCheckProvider_']=_0x510ec4,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0x574d28,_0x10db62,_0x5a734e){if(_0x574d28['stats_']=qi(_0x574d28['repoInfo_']),_0x574d28['forceRestClient_']||Xl())_0x574d28['server_']=new vn(_0x574d28['repoInfo_'],(_0x47b357,_0x1477ab,_0x3b120a,_0x391d75)=>{gr(_0x574d28,_0x47b357,_0x1477ab,_0x3b120a,_0x391d75);},_0x574d28['authTokenProvider_'],_0x574d28['appCheckProvider_']),setTimeout(()=>mr(_0x574d28,!0x0),0x0);else{if(typeof _0x5a734e<'u'&&_0x5a734e!==null){if(typeof _0x5a734e!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5a734e);}catch(_0x165e1b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x165e1b);}}_0x574d28['persistentConnection_']=new se(_0x574d28['repoInfo_'],_0x10db62,(_0x5ab5ee,_0x3e8fb4,_0x2764bc,_0x24b4e1)=>{gr(_0x574d28,_0x5ab5ee,_0x3e8fb4,_0x2764bc,_0x24b4e1);},_0x61a0b9=>{mr(_0x574d28,_0x61a0b9);},_0x1410a7=>{Ed(_0x574d28,_0x1410a7);},_0x574d28['authTokenProvider_'],_0x574d28['appCheckProvider_'],_0x5a734e),_0x574d28['server_']=_0x574d28['persistentConnection_'];}_0x574d28['authTokenProvider_']['addTokenChangeListener'](_0x486305=>{_0x574d28['server_']['refreshAuthToken'](_0x486305);}),_0x574d28['appCheckProvider_']['addTokenChangeListener'](_0x2a0e08=>{_0x574d28['server_']['refreshAppCheckToken'](_0x2a0e08['token']);}),_0x574d28['statsReporter_']=ih(_0x574d28['repoInfo_'],()=>new nu(_0x574d28['stats_'],_0x574d28['server_'])),_0x574d28['infoData_']=new Jh(),_0x574d28['infoSyncTree_']=new pr({'startListening':(_0x2b884e,_0x54b2ef,_0xfbf580,_0x519910)=>{let _0x19488a=[];const _0x5060b5=_0x574d28['infoData_']['getNode'](_0x2b884e['_path']);return _0x5060b5['isEmpty']()||(_0x19488a=Kt(_0x574d28['infoSyncTree_'],_0x2b884e['_path'],_0x5060b5),setTimeout(()=>{_0x519910('ok');},0x0)),_0x19488a;},'stopListening':()=>{}}),vs(_0x574d28,'connected',!0x1),_0x574d28['serverSyncTree_']=new pr({'startListening':(_0x48a180,_0x1a98cb,_0x14f1e0,_0xa5ba33)=>(_0x574d28['server_']['listen'](_0x48a180,_0x14f1e0,_0x1a98cb,(_0x31ffce,_0x138030)=>{const _0x481750=_0xa5ba33(_0x31ffce,_0x138030);V(_0x574d28['eventQueue_'],_0x48a180['_path'],_0x481750);}),[]),'stopListening':(_0x13c842,_0x50d1cc)=>{_0x574d28['server_']['unlisten'](_0x13c842,_0x50d1cc);}});}function la(_0x2dd27c){const _0x38ecdb=_0x2dd27c['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x38ecdb;}function Jt(_0x303b04){return nd({'timestamp':la(_0x303b04)});}function gr(_0xe83abc,_0x599c74,_0x509176,_0x422a75,_0x5994a7){_0xe83abc['dataUpdateCount']++;const _0x19a5d9=new C(_0x599c74);_0x509176=_0xe83abc['interceptServerDataCallback_']?_0xe83abc['interceptServerDataCallback_'](_0x599c74,_0x509176):_0x509176;let _0x10fb6b=[];if(_0x5994a7){if(_0x422a75){const _0x331219=_n(_0x509176,_0xd5bba6=>A(_0xd5bba6));_0x10fb6b=Qu(_0xe83abc['serverSyncTree_'],_0x19a5d9,_0x331219,_0x5994a7);}else{const _0x568479=A(_0x509176);_0x10fb6b=Jo(_0xe83abc['serverSyncTree_'],_0x19a5d9,_0x568479,_0x5994a7);}}else{if(_0x422a75){const _0x1d7002=_n(_0x509176,_0x306f04=>A(_0x306f04));_0x10fb6b=ju(_0xe83abc['serverSyncTree_'],_0x19a5d9,_0x1d7002);}else{const _0x1e0c6f=A(_0x509176);_0x10fb6b=Kt(_0xe83abc['serverSyncTree_'],_0x19a5d9,_0x1e0c6f);}}let _0x16b477=_0x19a5d9;_0x10fb6b['length']>0x0&&(_0x16b477=ct(_0xe83abc,_0x19a5d9)),V(_0xe83abc['eventQueue_'],_0x16b477,_0x10fb6b);}function mr(_0x415e57,_0xed0de8){vs(_0x415e57,'connected',_0xed0de8),_0xed0de8===!0x1&&Td(_0x415e57);}function Ed(_0x4f6f08,_0x1f5f1a){x(_0x1f5f1a,(_0x570cbd,_0x3b5d4f)=>{vs(_0x4f6f08,_0x570cbd,_0x3b5d4f);});}function vs(_0x1f936a,_0x18b97e,_0x44eaa8){const _0x2d5ef5=new C('/.info/'+_0x18b97e),_0x3dc5c6=A(_0x44eaa8);_0x1f936a['infoData_']['updateSnapshot'](_0x2d5ef5,_0x3dc5c6);const _0x106cf9=Kt(_0x1f936a['infoSyncTree_'],_0x2d5ef5,_0x3dc5c6);V(_0x1f936a['eventQueue_'],_0x2d5ef5,_0x106cf9);}function zn(_0x3009c9){return _0x3009c9['nextWriteId_']++;}function Id(_0x27a36c,_0x242e31,_0x3bcc69){const _0x555732=Ju(_0x27a36c['serverSyncTree_'],_0x242e31);return _0x555732!=null?Promise['resolve'](_0x555732):_0x27a36c['server_']['get'](_0x242e31)['then'](_0x5a228d=>{const _0x1cbf2d=A(_0x5a228d)['withIndex'](_0x242e31['_queryParams']['getIndex']());Pi(_0x27a36c['serverSyncTree_'],_0x242e31,_0x3bcc69,!0x0);let _0x45281c;if(_0x242e31['_queryParams']['loadsAllData']())_0x45281c=Kt(_0x27a36c['serverSyncTree_'],_0x242e31['_path'],_0x1cbf2d);else{const _0xa2e761=Ut(_0x27a36c['serverSyncTree_'],_0x242e31);_0x45281c=Jo(_0x27a36c['serverSyncTree_'],_0x242e31['_path'],_0x1cbf2d,_0xa2e761);}return V(_0x27a36c['eventQueue_'],_0x242e31['_path'],_0x45281c),An(_0x27a36c['serverSyncTree_'],_0x242e31,_0x3bcc69,null,!0x0),_0x1cbf2d;},_0x4a1791=>(gt(_0x27a36c,'get\x20for\x20query\x20'+O(_0x242e31)+'\x20failed:\x20'+_0x4a1791),Promise['reject'](new Error(_0x4a1791))));}function wd(_0x1b3bb6,_0x44ea52,_0x2186e2,_0x477fa5,_0x4e895d){gt(_0x1b3bb6,'set',{'path':_0x44ea52['toString'](),'value':_0x2186e2,'priority':_0x477fa5});const _0x3b641f=Jt(_0x1b3bb6),_0x4a6f9f=A(_0x2186e2,_0x477fa5),_0x3e911a=Vn(_0x1b3bb6['serverSyncTree_'],_0x44ea52),_0x51bc7d=fs(_0x4a6f9f,_0x3e911a,_0x3b641f),_0x54e388=zn(_0x1b3bb6),_0x1f5fc5=as(_0x1b3bb6['serverSyncTree_'],_0x44ea52,_0x51bc7d,_0x54e388,!0x0);qn(_0x1b3bb6['eventQueue_'],_0x1f5fc5),_0x1b3bb6['server_']['put'](_0x44ea52['toString'](),_0x4a6f9f['val'](!0x0),(_0x4522df,_0x513d16)=>{const _0xc49bf9=_0x4522df==='ok';_0xc49bf9||U('set\x20at\x20'+_0x44ea52+'\x20failed:\x20'+_0x4522df);const _0xa53608=_e(_0x1b3bb6['serverSyncTree_'],_0x54e388,!_0xc49bf9);V(_0x1b3bb6['eventQueue_'],_0x44ea52,_0xa53608),be(_0x1b3bb6,_0x4e895d,_0x4522df,_0x513d16);});const _0x207666=Is(_0x1b3bb6,_0x44ea52);ct(_0x1b3bb6,_0x207666),V(_0x1b3bb6['eventQueue_'],_0x207666,[]);}function Cd(_0x1ce17f,_0x284865,_0x44530b,_0x2c14b2){gt(_0x1ce17f,'update',{'path':_0x284865['toString'](),'value':_0x44530b});let _0x3900d2=!0x0;const _0x30283c=Jt(_0x1ce17f),_0x116750={};if(x(_0x44530b,(_0x59a3f0,_0x4f6449)=>{_0x3900d2=!0x1,_0x116750[_0x59a3f0]=ta(k(_0x284865,_0x59a3f0),A(_0x4f6449),_0x1ce17f['serverSyncTree_'],_0x30283c);}),_0x3900d2)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1ce17f,_0x2c14b2,'ok',void 0x0);else{const _0x7f3e3=zn(_0x1ce17f),_0x97c920=zu(_0x1ce17f['serverSyncTree_'],_0x284865,_0x116750,_0x7f3e3);qn(_0x1ce17f['eventQueue_'],_0x97c920),_0x1ce17f['server_']['merge'](_0x284865['toString'](),_0x44530b,(_0x519b4a,_0x530a78)=>{const _0x5f0c9e=_0x519b4a==='ok';_0x5f0c9e||U('update\x20at\x20'+_0x284865+'\x20failed:\x20'+_0x519b4a);const _0x4514e0=_e(_0x1ce17f['serverSyncTree_'],_0x7f3e3,!_0x5f0c9e),_0x317f30=_0x4514e0['length']>0x0?ct(_0x1ce17f,_0x284865):_0x284865;V(_0x1ce17f['eventQueue_'],_0x317f30,_0x4514e0),be(_0x1ce17f,_0x2c14b2,_0x519b4a,_0x530a78);}),x(_0x44530b,_0x55a689=>{const _0x38f795=Is(_0x1ce17f,k(_0x284865,_0x55a689));ct(_0x1ce17f,_0x38f795);}),V(_0x1ce17f['eventQueue_'],_0x284865,[]);}}function Td(_0x1904e3){gt(_0x1904e3,'onDisconnectEvents');const _0x57d2a0=Jt(_0x1904e3),_0x44ef20=En();Si(_0x1904e3['onDisconnect_'],w(),(_0x478457,_0x55225c)=>{const _0x236c94=ta(_0x478457,_0x55225c,_0x1904e3['serverSyncTree_'],_0x57d2a0);pt(_0x44ef20,_0x478457,_0x236c94);});let _0x1808c2=[];Si(_0x44ef20,w(),(_0x30a8dc,_0x3fccb6)=>{_0x1808c2=_0x1808c2['concat'](Kt(_0x1904e3['serverSyncTree_'],_0x30a8dc,_0x3fccb6));const _0x39ec44=Is(_0x1904e3,_0x30a8dc);ct(_0x1904e3,_0x39ec44);}),_0x1904e3['onDisconnect_']=En(),V(_0x1904e3['eventQueue_'],w(),_0x1808c2);}function Sd(_0x5d7d7d,_0x473a3c,_0x31f75b){_0x5d7d7d['server_']['onDisconnectCancel'](_0x473a3c['toString'](),(_0xfa31c0,_0x594ba7)=>{_0xfa31c0==='ok'&&Ti(_0x5d7d7d['onDisconnect_'],_0x473a3c),be(_0x5d7d7d,_0x31f75b,_0xfa31c0,_0x594ba7);});}function yr(_0x112483,_0x29c3c0,_0x5392fa,_0x6609b3){const _0x41e2c2=A(_0x5392fa);_0x112483['server_']['onDisconnectPut'](_0x29c3c0['toString'](),_0x41e2c2['val'](!0x0),(_0x5a36d3,_0xf53ba6)=>{_0x5a36d3==='ok'&&pt(_0x112483['onDisconnect_'],_0x29c3c0,_0x41e2c2),be(_0x112483,_0x6609b3,_0x5a36d3,_0xf53ba6);});}function bd(_0x2aa54a,_0x4ab572,_0x12743f,_0x114c06,_0x4c7222){const _0xfcd82d=A(_0x12743f,_0x114c06);_0x2aa54a['server_']['onDisconnectPut'](_0x4ab572['toString'](),_0xfcd82d['val'](!0x0),(_0x2f8d60,_0x514c86)=>{_0x2f8d60==='ok'&&pt(_0x2aa54a['onDisconnect_'],_0x4ab572,_0xfcd82d),be(_0x2aa54a,_0x4c7222,_0x2f8d60,_0x514c86);});}function Rd(_0x46e129,_0x1e88aa,_0x334249,_0x281303){if(pn(_0x334249)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x46e129,_0x281303,'ok',void 0x0);return;}_0x46e129['server_']['onDisconnectMerge'](_0x1e88aa['toString'](),_0x334249,(_0x50b5b2,_0x2d5291)=>{_0x50b5b2==='ok'&&x(_0x334249,(_0x53ace3,_0xbab1d3)=>{const _0x306624=A(_0xbab1d3);pt(_0x46e129['onDisconnect_'],k(_0x1e88aa,_0x53ace3),_0x306624);}),be(_0x46e129,_0x281303,_0x50b5b2,_0x2d5291);});}function Ad(_0x252cec,_0x380b23,_0x117363){let _0x49406e;y(_0x380b23['_path'])==='.info'?_0x49406e=Pi(_0x252cec['infoSyncTree_'],_0x380b23,_0x117363):_0x49406e=Pi(_0x252cec['serverSyncTree_'],_0x380b23,_0x117363),oa(_0x252cec['eventQueue_'],_0x380b23['_path'],_0x49406e);}function kd(_0x5d3c32,_0x22dd1d,_0x3bcb29){let _0x1d90c4;y(_0x22dd1d['_path'])==='.info'?_0x1d90c4=An(_0x5d3c32['infoSyncTree_'],_0x22dd1d,_0x3bcb29):_0x1d90c4=An(_0x5d3c32['serverSyncTree_'],_0x22dd1d,_0x3bcb29),oa(_0x5d3c32['eventQueue_'],_0x22dd1d['_path'],_0x1d90c4);}function ha(_0x5a724d){_0x5a724d['persistentConnection_']&&_0x5a724d['persistentConnection_']['interrupt'](ca);}function Nd(_0x40449a){_0x40449a['persistentConnection_']&&_0x40449a['persistentConnection_']['resume'](ca);}function gt(_0x4e8d5d,..._0x1d9957){let _0x36d43c='';_0x4e8d5d['persistentConnection_']&&(_0x36d43c=_0x4e8d5d['persistentConnection_']['id']+':'),L(_0x36d43c,..._0x1d9957);}function be(_0x249c37,_0xa3068d,_0x53643a,_0x1fbbf4){_0xa3068d&&ft(()=>{if(_0x53643a==='ok')_0xa3068d(null);else{const _0x11a31d=(_0x53643a||'error')['toUpperCase']();let _0x1c5537=_0x11a31d;_0x1fbbf4&&(_0x1c5537+=':\x20'+_0x1fbbf4);const _0x47e15d=new Error(_0x1c5537);_0x47e15d['code']=_0x11a31d,_0xa3068d(_0x47e15d);}});}function Pd(_0x5b96e2,_0x3b5172,_0x14f31c,_0x4591a6,_0x5dc473,_0x475848){gt(_0x5b96e2,'transaction\x20on\x20'+_0x3b5172);const _0x54ff90={'path':_0x3b5172,'update':_0x14f31c,'onComplete':_0x4591a6,'status':null,'order':so(),'applyLocally':_0x475848,'retryCount':0x0,'unwatcher':_0x5dc473,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0xf8e634=Es(_0x5b96e2,_0x3b5172,void 0x0);_0x54ff90['currentInputSnapshot']=_0xf8e634;const _0x227266=_0x54ff90['update'](_0xf8e634['val']());if(_0x227266===void 0x0)_0x54ff90['unwatcher'](),_0x54ff90['currentOutputSnapshotRaw']=null,_0x54ff90['currentOutputSnapshotResolved']=null,_0x54ff90['onComplete']&&_0x54ff90['onComplete'](null,!0x1,_0x54ff90['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x227266,_0x54ff90['path']),_0x54ff90['status']=0x0;const _0x29343f=$n(_0x5b96e2['transactionQueueTree_'],_0x3b5172),_0x2fe617=ze(_0x29343f)||[];_0x2fe617['push'](_0x54ff90),gs(_0x29343f,_0x2fe617);let _0x280f0d;typeof _0x227266=='object'&&_0x227266!==null&&Q(_0x227266,'.priority')?(_0x280f0d=Me(_0x227266,'.priority'),f(Wt(_0x280f0d),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x280f0d=(Vn(_0x5b96e2['serverSyncTree_'],_0x3b5172)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3a2ed3=Jt(_0x5b96e2),_0x46d986=A(_0x227266,_0x280f0d),_0x5811bf=fs(_0x46d986,_0xf8e634,_0x3a2ed3);_0x54ff90['currentOutputSnapshotRaw']=_0x46d986,_0x54ff90['currentOutputSnapshotResolved']=_0x5811bf,_0x54ff90['currentWriteId']=zn(_0x5b96e2);const _0x3066ea=as(_0x5b96e2['serverSyncTree_'],_0x3b5172,_0x5811bf,_0x54ff90['currentWriteId'],_0x54ff90['applyLocally']);V(_0x5b96e2['eventQueue_'],_0x3b5172,_0x3066ea),jn(_0x5b96e2,_0x5b96e2['transactionQueueTree_']);}}function Es(_0x20f96b,_0x21a476,_0x2e6019){return Vn(_0x20f96b['serverSyncTree_'],_0x21a476,_0x2e6019)||g['EMPTY_NODE'];}function jn(_0x204f84,_0x34de9b=_0x204f84['transactionQueueTree_']){if(_0x34de9b||Kn(_0x204f84,_0x34de9b),ze(_0x34de9b)){const _0x2253d3=da(_0x204f84,_0x34de9b);f(_0x2253d3['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2253d3['every'](_0x6592c=>_0x6592c['status']===0x0)&&Od(_0x204f84,Yt(_0x34de9b),_0x2253d3);}else na(_0x34de9b)&&Gn(_0x34de9b,_0x42c23c=>{jn(_0x204f84,_0x42c23c);});}function Od(_0x58e696,_0x38b7de,_0x15ea67){const _0x1e8321=_0x15ea67['map'](_0x1aaa20=>_0x1aaa20['currentWriteId']),_0x582250=Es(_0x58e696,_0x38b7de,_0x1e8321);let _0x2e0097=_0x582250;const _0x20ea97=_0x582250['hash']();for(let _0x3bcaa7=0x0;_0x3bcaa7<_0x15ea67['length'];_0x3bcaa7++){const _0x198a4c=_0x15ea67[_0x3bcaa7];f(_0x198a4c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x198a4c['status']=0x1,_0x198a4c['retryCount']++;const _0x56f5f4=F(_0x38b7de,_0x198a4c['path']);_0x2e0097=_0x2e0097['updateChild'](_0x56f5f4,_0x198a4c['currentOutputSnapshotRaw']);}const _0x15aba2=_0x2e0097['val'](!0x0),_0xfbe867=_0x38b7de;_0x58e696['server_']['put'](_0xfbe867['toString'](),_0x15aba2,_0x302eaf=>{gt(_0x58e696,'transaction\x20put\x20response',{'path':_0xfbe867['toString'](),'status':_0x302eaf});let _0x286f75=[];if(_0x302eaf==='ok'){const _0x2cec89=[];for(let _0xfbd12a=0x0;_0xfbd12a<_0x15ea67['length'];_0xfbd12a++)_0x15ea67[_0xfbd12a]['status']=0x2,_0x286f75=_0x286f75['concat'](_e(_0x58e696['serverSyncTree_'],_0x15ea67[_0xfbd12a]['currentWriteId'])),_0x15ea67[_0xfbd12a]['onComplete']&&_0x2cec89['push'](()=>_0x15ea67[_0xfbd12a]['onComplete'](null,!0x0,_0x15ea67[_0xfbd12a]['currentOutputSnapshotResolved'])),_0x15ea67[_0xfbd12a]['unwatcher']();Kn(_0x58e696,$n(_0x58e696['transactionQueueTree_'],_0x38b7de)),jn(_0x58e696,_0x58e696['transactionQueueTree_']),V(_0x58e696['eventQueue_'],_0x38b7de,_0x286f75);for(let _0x33e881=0x0;_0x33e881<_0x2cec89['length'];_0x33e881++)ft(_0x2cec89[_0x33e881]);}else{if(_0x302eaf==='datastale'){for(let _0x29e083=0x0;_0x29e083<_0x15ea67['length'];_0x29e083++)_0x15ea67[_0x29e083]['status']===0x3?_0x15ea67[_0x29e083]['status']=0x4:_0x15ea67[_0x29e083]['status']=0x0;}else{U('transaction\x20at\x20'+_0xfbe867['toString']()+'\x20failed:\x20'+_0x302eaf);for(let _0x57e73b=0x0;_0x57e73b<_0x15ea67['length'];_0x57e73b++)_0x15ea67[_0x57e73b]['status']=0x4,_0x15ea67[_0x57e73b]['abortReason']=_0x302eaf;}ct(_0x58e696,_0x38b7de);}},_0x20ea97);}function ct(_0xb52ab0,_0x2b74c6){const _0x177722=ua(_0xb52ab0,_0x2b74c6),_0x16eabe=Yt(_0x177722),_0x48694d=da(_0xb52ab0,_0x177722);return Dd(_0xb52ab0,_0x48694d,_0x16eabe),_0x16eabe;}function Dd(_0x5bebc8,_0x35c57f,_0x5dec31){if(_0x35c57f['length']===0x0)return;const _0x3b8edf=[];let _0x262f75=[];const _0x351547=_0x35c57f['filter'](_0x7266cc=>_0x7266cc['status']===0x0)['map'](_0xa38bc5=>_0xa38bc5['currentWriteId']);for(let _0x1ba2f8=0x0;_0x1ba2f8<_0x35c57f['length'];_0x1ba2f8++){const _0x49288a=_0x35c57f[_0x1ba2f8],_0x176567=F(_0x5dec31,_0x49288a['path']);let _0x345b51=!0x1,_0x5a1b3c;if(f(_0x176567!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x49288a['status']===0x4)_0x345b51=!0x0,_0x5a1b3c=_0x49288a['abortReason'],_0x262f75=_0x262f75['concat'](_e(_0x5bebc8['serverSyncTree_'],_0x49288a['currentWriteId'],!0x0));else{if(_0x49288a['status']===0x0){if(_0x49288a['retryCount']>=md)_0x345b51=!0x0,_0x5a1b3c='maxretry',_0x262f75=_0x262f75['concat'](_e(_0x5bebc8['serverSyncTree_'],_0x49288a['currentWriteId'],!0x0));else{const _0x4a934c=Es(_0x5bebc8,_0x49288a['path'],_0x351547);_0x49288a['currentInputSnapshot']=_0x4a934c;const _0x513ded=_0x35c57f[_0x1ba2f8]['update'](_0x4a934c['val']());if(_0x513ded!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x513ded,_0x49288a['path']);let _0x1dc93c=A(_0x513ded);typeof _0x513ded=='object'&&_0x513ded!=null&&Q(_0x513ded,'.priority')||(_0x1dc93c=_0x1dc93c['updatePriority'](_0x4a934c['getPriority']()));const _0x1115f8=_0x49288a['currentWriteId'],_0x3e84c7=Jt(_0x5bebc8),_0x602f44=fs(_0x1dc93c,_0x4a934c,_0x3e84c7);_0x49288a['currentOutputSnapshotRaw']=_0x1dc93c,_0x49288a['currentOutputSnapshotResolved']=_0x602f44,_0x49288a['currentWriteId']=zn(_0x5bebc8),_0x351547['splice'](_0x351547['indexOf'](_0x1115f8),0x1),_0x262f75=_0x262f75['concat'](as(_0x5bebc8['serverSyncTree_'],_0x49288a['path'],_0x602f44,_0x49288a['currentWriteId'],_0x49288a['applyLocally'])),_0x262f75=_0x262f75['concat'](_e(_0x5bebc8['serverSyncTree_'],_0x1115f8,!0x0));}else _0x345b51=!0x0,_0x5a1b3c='nodata',_0x262f75=_0x262f75['concat'](_e(_0x5bebc8['serverSyncTree_'],_0x49288a['currentWriteId'],!0x0));}}}V(_0x5bebc8['eventQueue_'],_0x5dec31,_0x262f75),_0x262f75=[],_0x345b51&&(_0x35c57f[_0x1ba2f8]['status']=0x2,function(_0x462a57){setTimeout(_0x462a57,Math['floor'](0x0));}(_0x35c57f[_0x1ba2f8]['unwatcher']),_0x35c57f[_0x1ba2f8]['onComplete']&&(_0x5a1b3c==='nodata'?_0x3b8edf['push'](()=>_0x35c57f[_0x1ba2f8]['onComplete'](null,!0x1,_0x35c57f[_0x1ba2f8]['currentInputSnapshot'])):_0x3b8edf['push'](()=>_0x35c57f[_0x1ba2f8]['onComplete'](new Error(_0x5a1b3c),!0x1,null))));}Kn(_0x5bebc8,_0x5bebc8['transactionQueueTree_']);for(let _0x37da27=0x0;_0x37da27<_0x3b8edf['length'];_0x37da27++)ft(_0x3b8edf[_0x37da27]);jn(_0x5bebc8,_0x5bebc8['transactionQueueTree_']);}function ua(_0xe37a61,_0x5218c9){let _0x2b2f01,_0x360e67=_0xe37a61['transactionQueueTree_'];for(_0x2b2f01=y(_0x5218c9);_0x2b2f01!==null&&ze(_0x360e67)===void 0x0;)_0x360e67=$n(_0x360e67,_0x2b2f01),_0x5218c9=S(_0x5218c9),_0x2b2f01=y(_0x5218c9);return _0x360e67;}function da(_0x2b0070,_0x3ab4e6){const _0x92d9d8=[];return fa(_0x2b0070,_0x3ab4e6,_0x92d9d8),_0x92d9d8['sort']((_0x44662d,_0x5a35ea)=>_0x44662d['order']-_0x5a35ea['order']),_0x92d9d8;}function fa(_0x5f2297,_0x3cd615,_0x3d1904){const _0x4daeb5=ze(_0x3cd615);if(_0x4daeb5){for(let _0x4c8cc3=0x0;_0x4c8cc3<_0x4daeb5['length'];_0x4c8cc3++)_0x3d1904['push'](_0x4daeb5[_0x4c8cc3]);}Gn(_0x3cd615,_0x1cd91d=>{fa(_0x5f2297,_0x1cd91d,_0x3d1904);});}function Kn(_0x2bf4ba,_0x271b91){const _0xf8556=ze(_0x271b91);if(_0xf8556){let _0x1d510f=0x0;for(let _0x40c1e2=0x0;_0x40c1e2<_0xf8556['length'];_0x40c1e2++)_0xf8556[_0x40c1e2]['status']!==0x2&&(_0xf8556[_0x1d510f]=_0xf8556[_0x40c1e2],_0x1d510f++);_0xf8556['length']=_0x1d510f,gs(_0x271b91,_0xf8556['length']>0x0?_0xf8556:void 0x0);}Gn(_0x271b91,_0x8be9dc=>{Kn(_0x2bf4ba,_0x8be9dc);});}function Is(_0x5f1ab7,_0x200506){const _0x1096e6=Yt(ua(_0x5f1ab7,_0x200506)),_0x2eb76e=$n(_0x5f1ab7['transactionQueueTree_'],_0x200506);return od(_0x2eb76e,_0x5095fd=>{di(_0x5f1ab7,_0x5095fd);}),di(_0x5f1ab7,_0x2eb76e),ia(_0x2eb76e,_0x367646=>{di(_0x5f1ab7,_0x367646);}),_0x1096e6;}function di(_0x4806c7,_0x15e441){const _0x3c5e56=ze(_0x15e441);if(_0x3c5e56){const _0x1d414a=[];let _0x5cf556=[],_0x2510ac=-0x1;for(let _0x590373=0x0;_0x590373<_0x3c5e56['length'];_0x590373++)_0x3c5e56[_0x590373]['status']===0x3||(_0x3c5e56[_0x590373]['status']===0x1?(f(_0x2510ac===_0x590373-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2510ac=_0x590373,_0x3c5e56[_0x590373]['status']=0x3,_0x3c5e56[_0x590373]['abortReason']='set'):(f(_0x3c5e56[_0x590373]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3c5e56[_0x590373]['unwatcher'](),_0x5cf556=_0x5cf556['concat'](_e(_0x4806c7['serverSyncTree_'],_0x3c5e56[_0x590373]['currentWriteId'],!0x0)),_0x3c5e56[_0x590373]['onComplete']&&_0x1d414a['push'](_0x3c5e56[_0x590373]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2510ac===-0x1?gs(_0x15e441,void 0x0):_0x3c5e56['length']=_0x2510ac+0x1,V(_0x4806c7['eventQueue_'],Yt(_0x15e441),_0x5cf556);for(let _0x201370=0x0;_0x201370<_0x1d414a['length'];_0x201370++)ft(_0x1d414a[_0x201370]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x33e7e8){let _0x4807ad='';const _0x3bb16b=_0x33e7e8['split']('/');for(let _0x5466df=0x0;_0x5466df<_0x3bb16b['length'];_0x5466df++)if(_0x3bb16b[_0x5466df]['length']>0x0){let _0x1615d8=_0x3bb16b[_0x5466df];try{_0x1615d8=decodeURIComponent(_0x1615d8['replace'](/\+/g,'\x20'));}catch{}_0x4807ad+='/'+_0x1615d8;}return _0x4807ad;}function Ld(_0xd2a24){const _0x375c20={};_0xd2a24['charAt'](0x0)==='?'&&(_0xd2a24=_0xd2a24['substring'](0x1));for(const _0x249a7e of _0xd2a24['split']('&')){if(_0x249a7e['length']===0x0)continue;const _0x41b3c7=_0x249a7e['split']('=');_0x41b3c7['length']===0x2?_0x375c20[decodeURIComponent(_0x41b3c7[0x0])]=decodeURIComponent(_0x41b3c7[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x249a7e+'\x27\x20in\x20query\x20\x27'+_0xd2a24+'\x27');}return _0x375c20;}const vr=function(_0x4fe2b5,_0x9a097){const _0x8df9a2=xd(_0x4fe2b5),_0x6bc92f=_0x8df9a2['namespace'];_0x8df9a2['domain']==='firebase.com'&&ae(_0x8df9a2['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x6bc92f||_0x6bc92f==='undefined')&&_0x8df9a2['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x8df9a2['secure']||$l();const _0x4842ef=_0x8df9a2['scheme']==='ws'||_0x8df9a2['scheme']==='wss';return{'repoInfo':new yo(_0x8df9a2['host'],_0x8df9a2['secure'],_0x6bc92f,_0x4842ef,_0x9a097,'',_0x6bc92f!==_0x8df9a2['subdomain']),'path':new C(_0x8df9a2['pathString'])};},xd=function(_0x37dec2){let _0x291400='',_0x48b761='',_0x184071='',_0x598d9c='',_0x3a8020='',_0x511364=!0x0,_0x41ccc2='https',_0x51322e=0x1bb;if(typeof _0x37dec2=='string'){let _0x2f339d=_0x37dec2['indexOf']('//');_0x2f339d>=0x0&&(_0x41ccc2=_0x37dec2['substring'](0x0,_0x2f339d-0x1),_0x37dec2=_0x37dec2['substring'](_0x2f339d+0x2));let _0xd6c633=_0x37dec2['indexOf']('/');_0xd6c633===-0x1&&(_0xd6c633=_0x37dec2['length']);let _0x3f77c8=_0x37dec2['indexOf']('?');_0x3f77c8===-0x1&&(_0x3f77c8=_0x37dec2['length']),_0x291400=_0x37dec2['substring'](0x0,Math['min'](_0xd6c633,_0x3f77c8)),_0xd6c633<_0x3f77c8&&(_0x598d9c=Md(_0x37dec2['substring'](_0xd6c633,_0x3f77c8)));const _0x5aece3=Ld(_0x37dec2['substring'](Math['min'](_0x37dec2['length'],_0x3f77c8)));_0x2f339d=_0x291400['indexOf'](':'),_0x2f339d>=0x0?(_0x511364=_0x41ccc2==='https'||_0x41ccc2==='wss',_0x51322e=parseInt(_0x291400['substring'](_0x2f339d+0x1),0xa)):_0x2f339d=_0x291400['length'];const _0x55b31a=_0x291400['slice'](0x0,_0x2f339d);if(_0x55b31a['toLowerCase']()==='localhost')_0x48b761='localhost';else{if(_0x55b31a['split']('.')['length']<=0x2)_0x48b761=_0x55b31a;else{const _0xbff3c9=_0x291400['indexOf']('.');_0x184071=_0x291400['substring'](0x0,_0xbff3c9)['toLowerCase'](),_0x48b761=_0x291400['substring'](_0xbff3c9+0x1),_0x3a8020=_0x184071;}}'ns'in _0x5aece3&&(_0x3a8020=_0x5aece3['ns']);}return{'host':_0x291400,'port':_0x51322e,'domain':_0x48b761,'subdomain':_0x184071,'secure':_0x511364,'scheme':_0x41ccc2,'pathString':_0x598d9c,'namespace':_0x3a8020};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x718a8c=0x0;const _0x4ca42e=[];return function(_0x2122b5){const _0x4eb15c=_0x2122b5===_0x718a8c;_0x718a8c=_0x2122b5;let _0x586ecb;const _0x11268f=new Array(0x8);for(_0x586ecb=0x7;_0x586ecb>=0x0;_0x586ecb--)_0x11268f[_0x586ecb]=Er['charAt'](_0x2122b5%0x40),_0x2122b5=Math['floor'](_0x2122b5/0x40);f(_0x2122b5===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x369eeb=_0x11268f['join']('');if(_0x4eb15c){for(_0x586ecb=0xb;_0x586ecb>=0x0&&_0x4ca42e[_0x586ecb]===0x3f;_0x586ecb--)_0x4ca42e[_0x586ecb]=0x0;_0x4ca42e[_0x586ecb]++;}else{for(_0x586ecb=0x0;_0x586ecb<0xc;_0x586ecb++)_0x4ca42e[_0x586ecb]=Math['floor'](Math['random']()*0x40);}for(_0x586ecb=0x0;_0x586ecb<0xc;_0x586ecb++)_0x369eeb+=Er['charAt'](_0x4ca42e[_0x586ecb]);return f(_0x369eeb['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x369eeb;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0xce37bc,_0x5e0493,_0x4f9a70,_0x36c6c9){this['eventType']=_0xce37bc,this['eventRegistration']=_0x5e0493,this['snapshot']=_0x4f9a70,this['prevName']=_0x36c6c9;}['getPath'](){const _0x584cc6=this['snapshot']['ref'];return this['eventType']==='value'?_0x584cc6['_path']:_0x584cc6['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0x54731a,_0x68efad,_0x482fa3){this['eventRegistration']=_0x54731a,this['error']=_0x68efad,this['path']=_0x482fa3;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3caa5c,_0x3b648b){this['snapshotCallback']=_0x3caa5c,this['cancelCallback']=_0x3b648b;}['onValue'](_0xc195c4,_0x11c425){this['snapshotCallback']['call'](null,_0xc195c4,_0x11c425);}['onCancel'](_0xe59951){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xe59951);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x131461){return this['snapshotCallback']===_0x131461['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x131461['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x131461['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x3278f9,_0x6b7a06){this['_repo']=_0x3278f9,this['_path']=_0x6b7a06;}['cancel'](){const _0x1426d7=new H();return Sd(this['_repo'],this['_path'],_0x1426d7['wrapCallback'](()=>{})),_0x1426d7['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x2ae31c=new H();return yr(this['_repo'],this['_path'],null,_0x2ae31c['wrapCallback'](()=>{})),_0x2ae31c['promise'];}['set'](_0x54d5ad){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x54d5ad,this['_path'],!0x1);const _0x63efd3=new H();return yr(this['_repo'],this['_path'],_0x54d5ad,_0x63efd3['wrapCallback'](()=>{})),_0x63efd3['promise'];}['setWithPriority'](_0x4578e0,_0x295556){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x4578e0,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x295556);const _0xbd0a42=new H();return bd(this['_repo'],this['_path'],_0x4578e0,_0x295556,_0xbd0a42['wrapCallback'](()=>{})),_0xbd0a42['promise'];}['update'](_0x270e86){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x270e86,this['_path']);const _0x366765=new H();return Rd(this['_repo'],this['_path'],_0x270e86,_0x366765['wrapCallback'](()=>{})),_0x366765['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x5d0014,_0x1ea50c,_0x558033,_0x11738e){this['_repo']=_0x5d0014,this['_path']=_0x1ea50c,this['_queryParams']=_0x558033,this['_orderByCalled']=_0x11738e;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5de4c0=sr(this['_queryParams']),_0x38ec04=$i(_0x5de4c0);return _0x38ec04==='{}'?'default':_0x38ec04;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x388387){if(_0x388387=N(_0x388387),!(_0x388387 instanceof je))return!0x1;const _0x307cd0=this['_repo']===_0x388387['_repo'],_0x224738=Ki(this['_path'],_0x388387['_path']),_0x1c4228=this['_queryIdentifier']===_0x388387['_queryIdentifier'];return _0x307cd0&&_0x224738&&_0x1c4228;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1c340b,_0x3343dd){if(_0x1c340b['_orderByCalled']===!0x0)throw new Error(_0x3343dd+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2e0a6a){let _0x4a4f47=null,_0x5c37ce=null;if(_0x2e0a6a['hasStart']()&&(_0x4a4f47=_0x2e0a6a['getIndexStartValue']()),_0x2e0a6a['hasEnd']()&&(_0x5c37ce=_0x2e0a6a['getIndexEndValue']()),_0x2e0a6a['getIndex']()===ve){const _0x42b149='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xd69a5e='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2e0a6a['hasStart']()){if(_0x2e0a6a['getIndexStartName']()!==Ue)throw new Error(_0x42b149);if(typeof _0x4a4f47!='string')throw new Error(_0xd69a5e);}if(_0x2e0a6a['hasEnd']()){if(_0x2e0a6a['getIndexEndName']()!==we)throw new Error(_0x42b149);if(typeof _0x5c37ce!='string')throw new Error(_0xd69a5e);}}else{if(_0x2e0a6a['getIndex']()===R){if(_0x4a4f47!=null&&!Wt(_0x4a4f47)||_0x5c37ce!=null&&!Wt(_0x5c37ce))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2e0a6a['getIndex']()instanceof Ji||_0x2e0a6a['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4a4f47!=null&&typeof _0x4a4f47=='object'||_0x5c37ce!=null&&typeof _0x5c37ce=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x195d56){if(_0x195d56['hasStart']()&&_0x195d56['hasEnd']()&&_0x195d56['hasLimit']()&&!_0x195d56['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0x4c42ff,_0x3d5b44){super(_0x4c42ff,_0x3d5b44,new Zi(),!0x1);}get['parent'](){const _0x3e31f0=Ro(this['_path']);return _0x3e31f0===null?null:new ee(this['_repo'],_0x3e31f0);}get['root'](){let _0x2707d7=this;for(;_0x2707d7['parent']!==null;)_0x2707d7=_0x2707d7['parent'];return _0x2707d7;}}class lt{constructor(_0x55d0d2,_0x5abffc,_0x54519c){this['_node']=_0x55d0d2,this['ref']=_0x5abffc,this['_index']=_0x54519c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2a83a){const _0x45aa01=new C(_0x2a83a),_0x29ca7c=Bt(this['ref'],_0x2a83a);return new lt(this['_node']['getChild'](_0x45aa01),_0x29ca7c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x17a40d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5b6eb5,_0x13b673)=>_0x17a40d(new lt(_0x13b673,Bt(this['ref'],_0x5b6eb5),R)));}['hasChild'](_0x19f89b){const _0x4589a7=new C(_0x19f89b);return!this['_node']['getChild'](_0x4589a7)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x4c2afb,_0x47515b){return _0x4c2afb=N(_0x4c2afb),_0x4c2afb['_checkNotDeleted']('ref'),_0x47515b!==void 0x0?Bt(_0x4c2afb['_root'],_0x47515b):_0x4c2afb['_root'];}function Bt(_0x516629,_0x249ebc){return _0x516629=N(_0x516629),y(_0x516629['_path'])===null?fd('child','path',_0x249ebc):ys('child','path',_0x249ebc),new ee(_0x516629['_repo'],k(_0x516629['_path'],_0x249ebc));}function m_(_0x2cd004){return _0x2cd004=N(_0x2cd004),new Bd(_0x2cd004['_repo'],_0x2cd004['_path']);}function y_(_0x2d998a,_0x2562a5){_0x2d998a=N(_0x2d998a),De('push',_0x2d998a['_path']),Ve('push',_0x2562a5,_0x2d998a['_path'],!0x0);const _0x39d7c5=la(_0x2d998a['_repo']),_0x2f5d6c=Fd(_0x39d7c5),_0x1dff1f=Bt(_0x2d998a,_0x2f5d6c),_0x27389d=Bt(_0x2d998a,_0x2f5d6c);let _0x33faee;return _0x2562a5!=null?_0x33faee=Vd(_0x27389d,_0x2562a5)['then'](()=>_0x27389d):_0x33faee=Promise['resolve'](_0x27389d),_0x1dff1f['then']=_0x33faee['then']['bind'](_0x33faee),_0x1dff1f['catch']=_0x33faee['then']['bind'](_0x33faee,void 0x0),_0x1dff1f;}function Vd(_0x17e32e,_0x4a4eb9){_0x17e32e=N(_0x17e32e),De('set',_0x17e32e['_path']),Ve('set',_0x4a4eb9,_0x17e32e['_path'],!0x1);const _0xe78cf6=new H();return wd(_0x17e32e['_repo'],_0x17e32e['_path'],_0x4a4eb9,null,_0xe78cf6['wrapCallback'](()=>{})),_0xe78cf6['promise'];}function v_(_0x41ae3b,_0x1e1d1b){ra('update',_0x1e1d1b,_0x41ae3b['_path']);const _0x5ab8a5=new H();return Cd(_0x41ae3b['_repo'],_0x41ae3b['_path'],_0x1e1d1b,_0x5ab8a5['wrapCallback'](()=>{})),_0x5ab8a5['promise'];}function E_(_0x5ba8ee){_0x5ba8ee=N(_0x5ba8ee);const _0x4ab9df=new pa(()=>{}),_0x3c7388=new Qn(_0x4ab9df);return Id(_0x5ba8ee['_repo'],_0x5ba8ee,_0x3c7388)['then'](_0x55239d=>new lt(_0x55239d,new ee(_0x5ba8ee['_repo'],_0x5ba8ee['_path']),_0x5ba8ee['_queryParams']['getIndex']()));}class Qn{constructor(_0x20d685){this['callbackContext']=_0x20d685;}['respondsTo'](_0x8db3e5){return _0x8db3e5==='value';}['createEvent'](_0x328909,_0x560755){const _0x2d0785=_0x560755['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x328909['snapshotNode'],new ee(_0x560755['_repo'],_0x560755['_path']),_0x2d0785));}['getEventRunner'](_0x11e398){return _0x11e398['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x11e398['error']):()=>this['callbackContext']['onValue'](_0x11e398['snapshot'],null);}['createCancelEvent'](_0x252d07,_0x1a43c5){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x252d07,_0x1a43c5):null;}['matches'](_0x9e405c){return _0x9e405c instanceof Qn?!_0x9e405c['callbackContext']||!this['callbackContext']?!0x0:_0x9e405c['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x37a19a,_0x440857,_0x3ca9c0,_0x299a48,_0x587657){const _0x4b3dc4=new pa(_0x3ca9c0,void 0x0),_0x500469=new Qn(_0x4b3dc4);return Ad(_0x37a19a['_repo'],_0x37a19a,_0x500469),()=>kd(_0x37a19a['_repo'],_0x37a19a,_0x500469);}function $d(_0x2df336,_0x4ae8d7,_0x26dc6e,_0x8267f5){return Hd(_0x2df336,'value',_0x4ae8d7);}class Xt{}class ma extends Xt{constructor(_0x71ff5c,_0x44b785){super(),this['_value']=_0x71ff5c,this['_key']=_0x44b785,this['type']='endAt';}['_apply'](_0x2b45b5){Ve('endAt',this['_value'],_0x2b45b5['_path'],!0x0);const _0x5794f1=Qh(_0x2b45b5['_queryParams'],this['_value'],this['_key']);if(ga(_0x5794f1),Yn(_0x5794f1),_0x2b45b5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x2b45b5['_repo'],_0x2b45b5['_path'],_0x5794f1,_0x2b45b5['_orderByCalled']);}}function I_(_0x43ed4f,_0x35d876){return new ma(_0x43ed4f,_0x35d876);}class ya extends Xt{constructor(_0x2ceae1,_0x1c2ab4){super(),this['_value']=_0x2ceae1,this['_key']=_0x1c2ab4,this['type']='startAt';}['_apply'](_0x411eb3){Ve('startAt',this['_value'],_0x411eb3['_path'],!0x0);const _0x5983ab=Yh(_0x411eb3['_queryParams'],this['_value'],this['_key']);if(ga(_0x5983ab),Yn(_0x5983ab),_0x411eb3['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x411eb3['_repo'],_0x411eb3['_path'],_0x5983ab,_0x411eb3['_orderByCalled']);}}function w_(_0x4a8d5c=null,_0x28ccfd){return new ya(_0x4a8d5c,_0x28ccfd);}class Gd extends Xt{constructor(_0x154da3){super(),this['_path']=_0x154da3,this['type']='orderByChild';}['_apply'](_0x2d5e8c){_a(_0x2d5e8c,'orderByChild');const _0x2a1433=new C(this['_path']);if(v(_0x2a1433))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x599698=new Ji(_0x2a1433),_0x27a7dd=xo(_0x2d5e8c['_queryParams'],_0x599698);return Yn(_0x27a7dd),new je(_0x2d5e8c['_repo'],_0x2d5e8c['_path'],_0x27a7dd,!0x0);}}function C_(_0x320a27){if(_0x320a27==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x320a27==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x320a27==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x320a27),new Gd(_0x320a27);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1d648f){_a(_0x1d648f,'orderByKey');const _0xabd64f=xo(_0x1d648f['_queryParams'],ve);return Yn(_0xabd64f),new je(_0x1d648f['_repo'],_0x1d648f['_path'],_0xabd64f,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0x261850,_0x476958){super(),this['_value']=_0x261850,this['_key']=_0x476958,this['type']='equalTo';}['_apply'](_0x4d9c0f){if(Ve('equalTo',this['_value'],_0x4d9c0f['_path'],!0x1),_0x4d9c0f['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4d9c0f['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4d9c0f));}}function S_(_0x2d23a2,_0x3bdc43){return new zd(_0x2d23a2,_0x3bdc43);}function b_(_0x13c1c6,..._0x4a68a9){let _0x45542e=N(_0x13c1c6);for(const _0x33f268 of _0x4a68a9)_0x45542e=_0x33f268['_apply'](_0x45542e);return _0x45542e;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x1a9a76,_0x17f193,_0x2c2c90,_0x53b4b6){const _0x8b9500=_0x17f193['lastIndexOf'](':'),_0x32253a=_0x17f193['substring'](0x0,_0x8b9500),_0x39703b=Gt(_0x32253a);_0x1a9a76['repoInfo_']=new yo(_0x17f193,_0x39703b,_0x1a9a76['repoInfo_']['namespace'],_0x1a9a76['repoInfo_']['webSocketOnly'],_0x1a9a76['repoInfo_']['nodeAdmin'],_0x1a9a76['repoInfo_']['persistenceKey'],_0x1a9a76['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2c2c90),_0x53b4b6&&(_0x1a9a76['authTokenProvider_']=_0x53b4b6);}function Qd(_0x39a3d3,_0x298ae4,_0x2d120b,_0x44901f,_0x500241){let _0x59ca66=_0x44901f||_0x39a3d3['options']['databaseURL'];_0x59ca66===void 0x0&&(_0x39a3d3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x39a3d3['options']['projectId']),_0x59ca66=_0x39a3d3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x51fe39=vr(_0x59ca66,_0x500241),_0x176c2d=_0x51fe39['repoInfo'],_0x3253ab;typeof process<'u'&&Bs&&(_0x3253ab=Bs[jd]),_0x3253ab?(_0x59ca66='http://'+_0x3253ab+'?ns='+_0x176c2d['namespace'],_0x51fe39=vr(_0x59ca66,_0x500241),_0x176c2d=_0x51fe39['repoInfo']):_0x51fe39['repoInfo']['secure'];const _0x186d41=new eh(_0x39a3d3['name'],_0x39a3d3['options'],_0x298ae4);pd('Invalid\x20Firebase\x20Database\x20URL',_0x51fe39),v(_0x51fe39['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2e8fee=Xd(_0x176c2d,_0x39a3d3,_0x186d41,new Zl(_0x39a3d3,_0x2d120b));return new Zd(_0x2e8fee,_0x39a3d3);}function Jd(_0x449162,_0x5bbaa0){const _0x14637a=Di[_0x5bbaa0];(!_0x14637a||_0x14637a[_0x449162['key']]!==_0x449162)&&ae('Database\x20'+_0x5bbaa0+'('+_0x449162['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x449162),delete _0x14637a[_0x449162['key']];}function Xd(_0x17616a,_0x497406,_0x19f03b,_0x22aab2){let _0x3f2b35=Di[_0x497406['name']];_0x3f2b35||(_0x3f2b35={},Di[_0x497406['name']]=_0x3f2b35);let _0x20269b=_0x3f2b35[_0x17616a['toURLString']()];return _0x20269b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x20269b=new yd(_0x17616a,Kd,_0x19f03b,_0x22aab2),_0x3f2b35[_0x17616a['toURLString']()]=_0x20269b,_0x20269b;}class Zd{constructor(_0x1974e6,_0x5aaedb){this['_repoInternal']=_0x1974e6,this['app']=_0x5aaedb,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5153a4){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5153a4+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0x3c2178=Zr(),_0x144f26){const _0x186a93=Hi(_0x3c2178,'database')['getImmediate']({'identifier':_0x144f26});if(!_0x186a93['_instanceStarted']){const _0x1093b1=hc('database');_0x1093b1&&ef(_0x186a93,..._0x1093b1);}return _0x186a93;}function ef(_0x525ae1,_0xc1b915,_0x46579a,_0x460587={}){_0x525ae1=N(_0x525ae1),_0x525ae1['_checkNotDeleted']('useEmulator');const _0x333d21=_0xc1b915+':'+_0x46579a,_0x18f3ce=_0x525ae1['_repoInternal'];if(_0x525ae1['_instanceStarted']){if(_0x333d21===_0x525ae1['_repoInternal']['repoInfo_']['host']&&Le(_0x460587,_0x18f3ce['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5ee1e0;if(_0x18f3ce['repoInfo_']['nodeAdmin'])_0x460587['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5ee1e0=new an(an['OWNER']);else{if(_0x460587['mockUserToken']){const _0x55f81d=typeof _0x460587['mockUserToken']=='string'?_0x460587['mockUserToken']:uc(_0x460587['mockUserToken'],_0x525ae1['app']['options']['projectId']);_0x5ee1e0=new an(_0x55f81d);}}Gt(_0xc1b915)&&Qr(_0xc1b915),Yd(_0x18f3ce,_0x333d21,_0x460587,_0x5ee1e0);}function A_(_0x4f264b){_0x4f264b=N(_0x4f264b),_0x4f264b['_checkNotDeleted']('goOffline'),ha(_0x4f264b['_repo']);}function k_(_0x124f12){_0x124f12=N(_0x124f12),_0x124f12['_checkNotDeleted']('goOnline'),Nd(_0x124f12['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0x92646c){Ul(dt),st(new xe('database',(_0x1441ff,{instanceIdentifier:_0x37d683})=>{const _0x22054d=_0x1441ff['getProvider']('app')['getImmediate'](),_0x100e06=_0x1441ff['getProvider']('auth-internal'),_0x20440f=_0x1441ff['getProvider']('app-check-internal');return Qd(_0x22054d,_0x100e06,_0x20440f,_0x37d683);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x92646c),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0xfde661,_0x3c336f){this['committed']=_0xfde661,this['snapshot']=_0x3c336f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x42e2e3,_0x2479e0,_0x177ec3){if(_0x42e2e3=N(_0x42e2e3),De('Reference.transaction',_0x42e2e3['_path']),_0x42e2e3['key']==='.length'||_0x42e2e3['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x42e2e3['key']+'\x20is\x20a\x20read-only\x20object.';const _0x25844c=!0x0,_0x58136c=new H(),_0x503887=(_0x3dfe9c,_0x4f2594,_0x36a045)=>{let _0x374144=null;_0x3dfe9c?_0x58136c['reject'](_0x3dfe9c):(_0x374144=new lt(_0x36a045,new ee(_0x42e2e3['_repo'],_0x42e2e3['_path']),R),_0x58136c['resolve'](new sf(_0x4f2594,_0x374144)));},_0x501d06=$d(_0x42e2e3,()=>{});return Pd(_0x42e2e3['_repo'],_0x42e2e3['_path'],_0x2479e0,_0x503887,_0x501d06,_0x25844c),_0x58136c['promise'];}se['prototype']['simpleListen']=function(_0x110c6c,_0x2540cf){this['sendRequest']('q',{'p':_0x110c6c},_0x2540cf);},se['prototype']['echo']=function(_0x5cae4b,_0x3c67d1){this['sendRequest']('echo',{'d':_0x5cae4b},_0x3c67d1);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0x25dc13,..._0x4078d8){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x25dc13,..._0x4078d8);}function cn(_0x10c686,..._0x11633c){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x10c686,..._0x11633c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x13b4f3,..._0x5f0b0a){throw ws(_0x13b4f3,..._0x5f0b0a);}function X(_0x49863f,..._0x20db42){return ws(_0x49863f,..._0x20db42);}function Ia(_0x54f130,_0x92fdb8,_0x4a0ab5){const _0xd05fa7={...rf(),[_0x92fdb8]:_0x4a0ab5};return new $t('auth','Firebase',_0xd05fa7)['create'](_0x92fdb8,{'appName':_0x54f130['name']});}function re(_0x3510b8){return Ia(_0x3510b8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x25292,..._0x5d4d0e){if(typeof _0x25292!='string'){const _0x3e39bf=_0x5d4d0e[0x0],_0x108ae7=[..._0x5d4d0e['slice'](0x1)];return _0x108ae7[0x0]&&(_0x108ae7[0x0]['appName']=_0x25292['name']),_0x25292['_errorFactory']['create'](_0x3e39bf,..._0x108ae7);}return Ea['create'](_0x25292,..._0x5d4d0e);}function m(_0x4c60d1,_0x4810eb,..._0x4118bb){if(!_0x4c60d1)throw ws(_0x4810eb,..._0x4118bb);}function ne(_0x19e2b0){const _0xa24900='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x19e2b0;throw cn(_0xa24900),new Error(_0xa24900);}function ce(_0xc5c149,_0x5d6426){_0xc5c149||ne(_0x5d6426);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0xc0173b;return typeof self<'u'&&((_0xc0173b=self['location'])==null?void 0x0:_0xc0173b['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1621d3;return typeof self<'u'&&((_0x1621d3=self['location'])==null?void 0x0:_0x1621d3['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0xaa2fa6=navigator;return _0xaa2fa6['languages']&&_0xaa2fa6['languages'][0x0]||_0xaa2fa6['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x9dfb44,_0x507fa1){this['shortDelay']=_0x9dfb44,this['longDelay']=_0x507fa1,ce(_0x507fa1>_0x9dfb44,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x397a25,_0x16f4b2){ce(_0x397a25['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3a47d9}=_0x397a25['emulator'];return _0x16f4b2?''+_0x3a47d9+(_0x16f4b2['startsWith']('/')?_0x16f4b2['slice'](0x1):_0x16f4b2):_0x3a47d9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x827160,_0x15af9b,_0x28462d){this['fetchImpl']=_0x827160,_0x15af9b&&(this['headersImpl']=_0x15af9b),_0x28462d&&(this['responseImpl']=_0x28462d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x535f16,_0x4fd078){return _0x535f16['tenantId']&&!_0x4fd078['tenantId']?{..._0x4fd078,'tenantId':_0x535f16['tenantId']}:_0x4fd078;}async function ke(_0x451431,_0x38b10e,_0x1f5143,_0xb0db01,_0xce8dd0={}){return Ca(_0x451431,_0xce8dd0,async()=>{let _0x3691b4={},_0x4d85a2={};_0xb0db01&&(_0x38b10e==='GET'?_0x4d85a2=_0xb0db01:_0x3691b4={'body':JSON['stringify'](_0xb0db01)});const _0x5efde9=ut({..._0x4d85a2,'key':_0x451431['config']['apiKey']})['slice'](0x1),_0x3efa5a=await _0x451431['_getAdditionalHeaders']();_0x3efa5a['Content-Type']='application/json',_0x451431['languageCode']&&(_0x3efa5a['X-Firebase-Locale']=_0x451431['languageCode']);const _0x26dfa6={'method':_0x38b10e,'headers':_0x3efa5a,..._0x3691b4};return dc()||(_0x26dfa6['referrerPolicy']='strict-origin-when-cross-origin'),_0x451431['emulatorConfig']&&Gt(_0x451431['emulatorConfig']['host'])&&(_0x26dfa6['credentials']='include'),wa['fetch']()(await Ta(_0x451431,_0x451431['config']['apiHost'],_0x1f5143,_0x5efde9),_0x26dfa6);});}async function Ca(_0x1e2905,_0x4d3b2a,_0x56f53f){_0x1e2905['_canInitEmulator']=!0x1;const _0xaf4d44={...hf,..._0x4d3b2a};try{const _0x2bdc1f=new pf(_0x1e2905),_0x6b4164=await Promise['race']([_0x56f53f(),_0x2bdc1f['promise']]);_0x2bdc1f['clearNetworkTimeout']();const _0x2260bd=await _0x6b4164['json']();if('needConfirmation'in _0x2260bd)throw on(_0x1e2905,'account-exists-with-different-credential',_0x2260bd);if(_0x6b4164['ok']&&!('errorMessage'in _0x2260bd))return _0x2260bd;{const _0x5ef82b=_0x6b4164['ok']?_0x2260bd['errorMessage']:_0x2260bd['error']['message'],[_0x33d39f,_0xa3775]=_0x5ef82b['split']('\x20:\x20');if(_0x33d39f==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1e2905,'credential-already-in-use',_0x2260bd);if(_0x33d39f==='EMAIL_EXISTS')throw on(_0x1e2905,'email-already-in-use',_0x2260bd);if(_0x33d39f==='USER_DISABLED')throw on(_0x1e2905,'user-disabled',_0x2260bd);const _0x56700f=_0xaf4d44[_0x33d39f]||_0x33d39f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xa3775)throw Ia(_0x1e2905,_0x56700f,_0xa3775);Y(_0x1e2905,_0x56700f);}}catch(_0x9bb061){if(_0x9bb061 instanceof Re)throw _0x9bb061;Y(_0x1e2905,'network-request-failed',{'message':String(_0x9bb061)});}}async function en(_0x2b491a,_0x2f3c39,_0x585a22,_0x18c5e4,_0x48fc28={}){const _0x22daac=await ke(_0x2b491a,_0x2f3c39,_0x585a22,_0x18c5e4,_0x48fc28);return'mfaPendingCredential'in _0x22daac&&Y(_0x2b491a,'multi-factor-auth-required',{'_serverResponse':_0x22daac}),_0x22daac;}async function Ta(_0x481786,_0x19b7cf,_0x5567ef,_0x5c3740){const _0x4dbb45=''+_0x19b7cf+_0x5567ef+'?'+_0x5c3740,_0x1cd896=_0x481786,_0x22a10a=_0x1cd896['config']['emulator']?Cs(_0x481786['config'],_0x4dbb45):_0x481786['config']['apiScheme']+'://'+_0x4dbb45;return uf['includes'](_0x5567ef)&&(await _0x1cd896['_persistenceManagerAvailable'],_0x1cd896['_getPersistenceType']()==='COOKIE')?_0x1cd896['_getPersistence']()['_getFinalTarget'](_0x22a10a)['toString']():_0x22a10a;}function ff(_0x16d7ff){switch(_0x16d7ff){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0xda1dd2){this['auth']=_0xda1dd2,this['timer']=null,this['promise']=new Promise((_0x3b4910,_0x5c1915)=>{this['timer']=setTimeout(()=>_0x5c1915(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x58c8f6,_0x359420,_0xaecfc7){const _0x47ad8e={'appName':_0x58c8f6['name']};_0xaecfc7['email']&&(_0x47ad8e['email']=_0xaecfc7['email']),_0xaecfc7['phoneNumber']&&(_0x47ad8e['phoneNumber']=_0xaecfc7['phoneNumber']);const _0x346e87=X(_0x58c8f6,_0x359420,_0x47ad8e);return _0x346e87['customData']['_tokenResponse']=_0xaecfc7,_0x346e87;}function wr(_0xc46918){return _0xc46918!==void 0x0&&_0xc46918['enterprise']!==void 0x0;}class _f{constructor(_0x4c2189){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4c2189['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4c2189['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4c2189['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x47f0d3){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2f91ef of this['recaptchaEnforcementState'])if(_0x2f91ef['provider']&&_0x2f91ef['provider']===_0x47f0d3)return ff(_0x2f91ef['enforcementState']);return null;}['isProviderEnabled'](_0x4642b6){return this['getProviderEnforcementState'](_0x4642b6)==='ENFORCE'||this['getProviderEnforcementState'](_0x4642b6)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0x39a6e8,_0x218433){return ke(_0x39a6e8,'GET','/v2/recaptchaConfig',Ae(_0x39a6e8,_0x218433));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x30280c,_0x1e9eeb){return ke(_0x30280c,'POST','/v1/accounts:delete',_0x1e9eeb);}async function Nn(_0x228b48,_0x3ccfad){return ke(_0x228b48,'POST','/v1/accounts:lookup',_0x3ccfad);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x8871bb){if(_0x8871bb)try{const _0x35793b=new Date(Number(_0x8871bb));if(!isNaN(_0x35793b['getTime']()))return _0x35793b['toUTCString']();}catch{}}async function yf(_0x4b5079,_0x1f4e0e=!0x1){const _0x446e0f=N(_0x4b5079),_0xdebc92=await _0x446e0f['getIdToken'](_0x1f4e0e),_0x4262e0=Ts(_0xdebc92);m(_0x4262e0&&_0x4262e0['exp']&&_0x4262e0['auth_time']&&_0x4262e0['iat'],_0x446e0f['auth'],'internal-error');const _0x298e6e=typeof _0x4262e0['firebase']=='object'?_0x4262e0['firebase']:void 0x0,_0x365e95=_0x298e6e==null?void 0x0:_0x298e6e['sign_in_provider'];return{'claims':_0x4262e0,'token':_0xdebc92,'authTime':kt(fi(_0x4262e0['auth_time'])),'issuedAtTime':kt(fi(_0x4262e0['iat'])),'expirationTime':kt(fi(_0x4262e0['exp'])),'signInProvider':_0x365e95||null,'signInSecondFactor':(_0x298e6e==null?void 0x0:_0x298e6e['sign_in_second_factor'])||null};}function fi(_0x28bbd3){return Number(_0x28bbd3)*0x3e8;}function Ts(_0x1b74fb){const [_0x1b9903,_0x501c5d,_0xef9910]=_0x1b74fb['split']('.');if(_0x1b9903===void 0x0||_0x501c5d===void 0x0||_0xef9910===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5e9c12=fn(_0x501c5d);return _0x5e9c12?JSON['parse'](_0x5e9c12):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3b1f90){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3b1f90==null?void 0x0:_0x3b1f90['toString']()),null;}}function Cr(_0x541ca5){const _0x2e781e=Ts(_0x541ca5);return m(_0x2e781e,'internal-error'),m(typeof _0x2e781e['exp']<'u','internal-error'),m(typeof _0x2e781e['iat']<'u','internal-error'),Number(_0x2e781e['exp'])-Number(_0x2e781e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x335ab7,_0xbc6282,_0x31d950=!0x1){if(_0x31d950)return _0xbc6282;try{return await _0xbc6282;}catch(_0xb8088c){throw _0xb8088c instanceof Re&&vf(_0xb8088c)&&_0x335ab7['auth']['currentUser']===_0x335ab7&&await _0x335ab7['auth']['signOut'](),_0xb8088c;}}function vf({code:_0x8d9d6c}){return _0x8d9d6c==='auth/user-disabled'||_0x8d9d6c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0x15f128){this['user']=_0x15f128,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2ac7aa){if(_0x2ac7aa){const _0x152991=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x152991;}else{this['errorBackoff']=0x7530;const _0x517dfb=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x517dfb);}}['schedule'](_0x46e8de=!0x1){if(!this['isRunning'])return;const _0xa99b5c=this['getInterval'](_0x46e8de);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xa99b5c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xb296e){(_0xb296e==null?void 0x0:_0xb296e['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x6fce2b,_0x5960a0){this['createdAt']=_0x6fce2b,this['lastLoginAt']=_0x5960a0,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x33043c){this['createdAt']=_0x33043c['createdAt'],this['lastLoginAt']=_0x33043c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0x14968b){var _0x242dee;const _0x16fbb6=_0x14968b['auth'],_0x50c89d=await _0x14968b['getIdToken'](),_0x1424c1=await Vt(_0x14968b,Nn(_0x16fbb6,{'idToken':_0x50c89d}));m(_0x1424c1==null?void 0x0:_0x1424c1['users']['length'],_0x16fbb6,'internal-error');const _0x309a72=_0x1424c1['users'][0x0];_0x14968b['_notifyReloadListener'](_0x309a72);const _0x19dca8=(_0x242dee=_0x309a72['providerUserInfo'])!=null&&_0x242dee['length']?Sa(_0x309a72['providerUserInfo']):[],_0x356e8a=wf(_0x14968b['providerData'],_0x19dca8),_0x20064c=_0x14968b['isAnonymous'],_0x5e4c4d=!(_0x14968b['email']&&_0x309a72['passwordHash'])&&!(_0x356e8a!=null&&_0x356e8a['length']),_0x7ecaa9=_0x20064c?_0x5e4c4d:!0x1,_0x144610={'uid':_0x309a72['localId'],'displayName':_0x309a72['displayName']||null,'photoURL':_0x309a72['photoUrl']||null,'email':_0x309a72['email']||null,'emailVerified':_0x309a72['emailVerified']||!0x1,'phoneNumber':_0x309a72['phoneNumber']||null,'tenantId':_0x309a72['tenantId']||null,'providerData':_0x356e8a,'metadata':new Li(_0x309a72['createdAt'],_0x309a72['lastLoginAt']),'isAnonymous':_0x7ecaa9};Object['assign'](_0x14968b,_0x144610);}async function If(_0x3643f3){const _0x38ffa5=N(_0x3643f3);await Pn(_0x38ffa5),await _0x38ffa5['auth']['_persistUserIfCurrent'](_0x38ffa5),_0x38ffa5['auth']['_notifyListenersIfCurrent'](_0x38ffa5);}function wf(_0xeee12c,_0x5eca20){return[..._0xeee12c['filter'](_0x4dc0f6=>!_0x5eca20['some'](_0x3a128f=>_0x3a128f['providerId']===_0x4dc0f6['providerId'])),..._0x5eca20];}function Sa(_0x38a5bd){return _0x38a5bd['map'](({providerId:_0x1c0c94,..._0x30e2b9})=>({'providerId':_0x1c0c94,'uid':_0x30e2b9['rawId']||'','displayName':_0x30e2b9['displayName']||null,'email':_0x30e2b9['email']||null,'phoneNumber':_0x30e2b9['phoneNumber']||null,'photoURL':_0x30e2b9['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x16ea27,_0x97f7e9){const _0x1580c5=await Ca(_0x16ea27,{},async()=>{const _0x977c79=ut({'grant_type':'refresh_token','refresh_token':_0x97f7e9})['slice'](0x1),{tokenApiHost:_0x500f7e,apiKey:_0x1feda3}=_0x16ea27['config'],_0x157fb3=await Ta(_0x16ea27,_0x500f7e,'/v1/token','key='+_0x1feda3),_0x216881=await _0x16ea27['_getAdditionalHeaders']();_0x216881['Content-Type']='application/x-www-form-urlencoded';const _0x19d3af={'method':'POST','headers':_0x216881,'body':_0x977c79};return _0x16ea27['emulatorConfig']&&Gt(_0x16ea27['emulatorConfig']['host'])&&(_0x19d3af['credentials']='include'),wa['fetch']()(_0x157fb3,_0x19d3af);});return{'accessToken':_0x1580c5['access_token'],'expiresIn':_0x1580c5['expires_in'],'refreshToken':_0x1580c5['refresh_token']};}async function Tf(_0xa04d6c,_0x2f4f5d){return ke(_0xa04d6c,'POST','/v2/accounts:revokeToken',Ae(_0xa04d6c,_0x2f4f5d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3eb661){m(_0x3eb661['idToken'],'internal-error'),m(typeof _0x3eb661['idToken']<'u','internal-error'),m(typeof _0x3eb661['refreshToken']<'u','internal-error');const _0x5717c7='expiresIn'in _0x3eb661&&typeof _0x3eb661['expiresIn']<'u'?Number(_0x3eb661['expiresIn']):Cr(_0x3eb661['idToken']);this['updateTokensAndExpiration'](_0x3eb661['idToken'],_0x3eb661['refreshToken'],_0x5717c7);}['updateFromIdToken'](_0x16386f){m(_0x16386f['length']!==0x0,'internal-error');const _0x24259c=Cr(_0x16386f);this['updateTokensAndExpiration'](_0x16386f,null,_0x24259c);}async['getToken'](_0x516d46,_0x4cd021=!0x1){return!_0x4cd021&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x516d46,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x516d46,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3ec9de,_0x1e62b0){const {accessToken:_0x4d2f9a,refreshToken:_0x4a30b9,expiresIn:_0x27d817}=await Cf(_0x3ec9de,_0x1e62b0);this['updateTokensAndExpiration'](_0x4d2f9a,_0x4a30b9,Number(_0x27d817));}['updateTokensAndExpiration'](_0x45f3a3,_0x1e2c28,_0x312ff7){this['refreshToken']=_0x1e2c28||null,this['accessToken']=_0x45f3a3||null,this['expirationTime']=Date['now']()+_0x312ff7*0x3e8;}static['fromJSON'](_0x4ac9e2,_0x24bfec){const {refreshToken:_0x447c23,accessToken:_0x4d7455,expirationTime:_0x2e4a47}=_0x24bfec,_0x4aace2=new et();return _0x447c23&&(m(typeof _0x447c23=='string','internal-error',{'appName':_0x4ac9e2}),_0x4aace2['refreshToken']=_0x447c23),_0x4d7455&&(m(typeof _0x4d7455=='string','internal-error',{'appName':_0x4ac9e2}),_0x4aace2['accessToken']=_0x4d7455),_0x2e4a47&&(m(typeof _0x2e4a47=='number','internal-error',{'appName':_0x4ac9e2}),_0x4aace2['expirationTime']=_0x2e4a47),_0x4aace2;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2747dd){this['accessToken']=_0x2747dd['accessToken'],this['refreshToken']=_0x2747dd['refreshToken'],this['expirationTime']=_0x2747dd['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x15acdd,_0x21fb46){m(typeof _0x15acdd=='string'||typeof _0x15acdd>'u','internal-error',{'appName':_0x21fb46});}class j{constructor({uid:_0x3c1389,auth:_0x5bc665,stsTokenManager:_0x1551b2,..._0x2dc641}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3c1389,this['auth']=_0x5bc665,this['stsTokenManager']=_0x1551b2,this['accessToken']=_0x1551b2['accessToken'],this['displayName']=_0x2dc641['displayName']||null,this['email']=_0x2dc641['email']||null,this['emailVerified']=_0x2dc641['emailVerified']||!0x1,this['phoneNumber']=_0x2dc641['phoneNumber']||null,this['photoURL']=_0x2dc641['photoURL']||null,this['isAnonymous']=_0x2dc641['isAnonymous']||!0x1,this['tenantId']=_0x2dc641['tenantId']||null,this['providerData']=_0x2dc641['providerData']?[..._0x2dc641['providerData']]:[],this['metadata']=new Li(_0x2dc641['createdAt']||void 0x0,_0x2dc641['lastLoginAt']||void 0x0);}async['getIdToken'](_0x982344){const _0x4e4d73=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x982344));return m(_0x4e4d73,this['auth'],'internal-error'),this['accessToken']!==_0x4e4d73&&(this['accessToken']=_0x4e4d73,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4e4d73;}['getIdTokenResult'](_0x5e9769){return yf(this,_0x5e9769);}['reload'](){return If(this);}['_assign'](_0x3cf94c){this!==_0x3cf94c&&(m(this['uid']===_0x3cf94c['uid'],this['auth'],'internal-error'),this['displayName']=_0x3cf94c['displayName'],this['photoURL']=_0x3cf94c['photoURL'],this['email']=_0x3cf94c['email'],this['emailVerified']=_0x3cf94c['emailVerified'],this['phoneNumber']=_0x3cf94c['phoneNumber'],this['isAnonymous']=_0x3cf94c['isAnonymous'],this['tenantId']=_0x3cf94c['tenantId'],this['providerData']=_0x3cf94c['providerData']['map'](_0x545b70=>({..._0x545b70})),this['metadata']['_copy'](_0x3cf94c['metadata']),this['stsTokenManager']['_assign'](_0x3cf94c['stsTokenManager']));}['_clone'](_0x15a109){const _0x63c9d7=new j({...this,'auth':_0x15a109,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x63c9d7['metadata']['_copy'](this['metadata']),_0x63c9d7;}['_onReload'](_0xa3a200){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xa3a200,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3ac5e5){this['reloadListener']?this['reloadListener'](_0x3ac5e5):this['reloadUserInfo']=_0x3ac5e5;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x45bc4b,_0x3ad151=!0x1){let _0x335fa1=!0x1;_0x45bc4b['idToken']&&_0x45bc4b['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x45bc4b),_0x335fa1=!0x0),_0x3ad151&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x335fa1&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1d0449=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x1d0449})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4169d1=>({..._0x4169d1})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x46477a,_0x115baa){const _0x3af83d=_0x115baa['displayName']??void 0x0,_0x29950a=_0x115baa['email']??void 0x0,_0x4adf7d=_0x115baa['phoneNumber']??void 0x0,_0x2c0192=_0x115baa['photoURL']??void 0x0,_0x29dadb=_0x115baa['tenantId']??void 0x0,_0x539eb6=_0x115baa['_redirectEventId']??void 0x0,_0x72dbc=_0x115baa['createdAt']??void 0x0,_0x26611f=_0x115baa['lastLoginAt']??void 0x0,{uid:_0x14d798,emailVerified:_0x401f36,isAnonymous:_0x5e654c,providerData:_0x30baf9,stsTokenManager:_0x23bdc5}=_0x115baa;m(_0x14d798&&_0x23bdc5,_0x46477a,'internal-error');const _0x5e23f=et['fromJSON'](this['name'],_0x23bdc5);m(typeof _0x14d798=='string',_0x46477a,'internal-error'),le(_0x3af83d,_0x46477a['name']),le(_0x29950a,_0x46477a['name']),m(typeof _0x401f36=='boolean',_0x46477a,'internal-error'),m(typeof _0x5e654c=='boolean',_0x46477a,'internal-error'),le(_0x4adf7d,_0x46477a['name']),le(_0x2c0192,_0x46477a['name']),le(_0x29dadb,_0x46477a['name']),le(_0x539eb6,_0x46477a['name']),le(_0x72dbc,_0x46477a['name']),le(_0x26611f,_0x46477a['name']);const _0x932118=new j({'uid':_0x14d798,'auth':_0x46477a,'email':_0x29950a,'emailVerified':_0x401f36,'displayName':_0x3af83d,'isAnonymous':_0x5e654c,'photoURL':_0x2c0192,'phoneNumber':_0x4adf7d,'tenantId':_0x29dadb,'stsTokenManager':_0x5e23f,'createdAt':_0x72dbc,'lastLoginAt':_0x26611f});return _0x30baf9&&Array['isArray'](_0x30baf9)&&(_0x932118['providerData']=_0x30baf9['map'](_0x5c0a4d=>({..._0x5c0a4d}))),_0x539eb6&&(_0x932118['_redirectEventId']=_0x539eb6),_0x932118;}static async['_fromIdTokenResponse'](_0x27d362,_0x11d488,_0x49b0d1=!0x1){const _0x475609=new et();_0x475609['updateFromServerResponse'](_0x11d488);const _0x171957=new j({'uid':_0x11d488['localId'],'auth':_0x27d362,'stsTokenManager':_0x475609,'isAnonymous':_0x49b0d1});return await Pn(_0x171957),_0x171957;}static async['_fromGetAccountInfoResponse'](_0x59af0e,_0x17cdf7,_0xa603f2){const _0x28ec7a=_0x17cdf7['users'][0x0];m(_0x28ec7a['localId']!==void 0x0,'internal-error');const _0x2fb7d4=_0x28ec7a['providerUserInfo']!==void 0x0?Sa(_0x28ec7a['providerUserInfo']):[],_0xa0a887=!(_0x28ec7a['email']&&_0x28ec7a['passwordHash'])&&!(_0x2fb7d4!=null&&_0x2fb7d4['length']),_0x4ada27=new et();_0x4ada27['updateFromIdToken'](_0xa603f2);const _0x10347f=new j({'uid':_0x28ec7a['localId'],'auth':_0x59af0e,'stsTokenManager':_0x4ada27,'isAnonymous':_0xa0a887}),_0x15fd88={'uid':_0x28ec7a['localId'],'displayName':_0x28ec7a['displayName']||null,'photoURL':_0x28ec7a['photoUrl']||null,'email':_0x28ec7a['email']||null,'emailVerified':_0x28ec7a['emailVerified']||!0x1,'phoneNumber':_0x28ec7a['phoneNumber']||null,'tenantId':_0x28ec7a['tenantId']||null,'providerData':_0x2fb7d4,'metadata':new Li(_0x28ec7a['createdAt'],_0x28ec7a['lastLoginAt']),'isAnonymous':!(_0x28ec7a['email']&&_0x28ec7a['passwordHash'])&&!(_0x2fb7d4!=null&&_0x2fb7d4['length'])};return Object['assign'](_0x10347f,_0x15fd88),_0x10347f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x26b427){ce(_0x26b427 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x106ddc=Tr['get'](_0x26b427);return _0x106ddc?(ce(_0x106ddc instanceof _0x26b427,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x106ddc):(_0x106ddc=new _0x26b427(),Tr['set'](_0x26b427,_0x106ddc),_0x106ddc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1b9e8a,_0x418f73){this['storage'][_0x1b9e8a]=_0x418f73;}async['_get'](_0x27e1cd){const _0x3f420a=this['storage'][_0x27e1cd];return _0x3f420a===void 0x0?null:_0x3f420a;}async['_remove'](_0x1f5fbb){delete this['storage'][_0x1f5fbb];}['_addListener'](_0x16fb71,_0x4e2096){}['_removeListener'](_0x400c9d,_0x1a43a4){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x569743,_0x24ab90,_0x4b3a28){return'firebase:'+_0x569743+':'+_0x24ab90+':'+_0x4b3a28;}class tt{constructor(_0x3fbb9f,_0x5ea19f,_0x4fb999){this['persistence']=_0x3fbb9f,this['auth']=_0x5ea19f,this['userKey']=_0x4fb999;const {config:_0x24de45,name:_0x3f2234}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x24de45['apiKey'],_0x3f2234),this['fullPersistenceKey']=ln('persistence',_0x24de45['apiKey'],_0x3f2234),this['boundEventHandler']=_0x5ea19f['_onStorageEvent']['bind'](_0x5ea19f),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x20fc94){return this['persistence']['_set'](this['fullUserKey'],_0x20fc94['toJSON']());}async['getCurrentUser'](){const _0x22d0cd=await this['persistence']['_get'](this['fullUserKey']);if(!_0x22d0cd)return null;if(typeof _0x22d0cd=='string'){const _0x3aab8c=await Nn(this['auth'],{'idToken':_0x22d0cd})['catch'](()=>{});return _0x3aab8c?j['_fromGetAccountInfoResponse'](this['auth'],_0x3aab8c,_0x22d0cd):null;}return j['_fromJSON'](this['auth'],_0x22d0cd);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2d1ba9){if(this['persistence']===_0x2d1ba9)return;const _0x425c68=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2d1ba9,_0x425c68)return this['setCurrentUser'](_0x425c68);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1d6a40,_0x464f40,_0x59250e='authUser'){if(!_0x464f40['length'])return new tt(ie(Sr),_0x1d6a40,_0x59250e);const _0x17ec86=(await Promise['all'](_0x464f40['map'](async _0x38e955=>{if(await _0x38e955['_isAvailable']())return _0x38e955;})))['filter'](_0x541400=>_0x541400);let _0x1cd3a2=_0x17ec86[0x0]||ie(Sr);const _0x52a981=ln(_0x59250e,_0x1d6a40['config']['apiKey'],_0x1d6a40['name']);let _0x11cf8e=null;for(const _0x4a6306 of _0x464f40)try{const _0x139468=await _0x4a6306['_get'](_0x52a981);if(_0x139468){let _0x599b5e;if(typeof _0x139468=='string'){const _0x317154=await Nn(_0x1d6a40,{'idToken':_0x139468})['catch'](()=>{});if(!_0x317154)break;_0x599b5e=await j['_fromGetAccountInfoResponse'](_0x1d6a40,_0x317154,_0x139468);}else _0x599b5e=j['_fromJSON'](_0x1d6a40,_0x139468);_0x4a6306!==_0x1cd3a2&&(_0x11cf8e=_0x599b5e),_0x1cd3a2=_0x4a6306;break;}}catch{}const _0x2acad6=_0x17ec86['filter'](_0x6d2bb3=>_0x6d2bb3['_shouldAllowMigration']);return!_0x1cd3a2['_shouldAllowMigration']||!_0x2acad6['length']?new tt(_0x1cd3a2,_0x1d6a40,_0x59250e):(_0x1cd3a2=_0x2acad6[0x0],_0x11cf8e&&await _0x1cd3a2['_set'](_0x52a981,_0x11cf8e['toJSON']()),await Promise['all'](_0x464f40['map'](async _0x25af3c=>{if(_0x25af3c!==_0x1cd3a2)try{await _0x25af3c['_remove'](_0x52a981);}catch{}})),new tt(_0x1cd3a2,_0x1d6a40,_0x59250e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1dc3b5){const _0xb71174=_0x1dc3b5['toLowerCase']();if(_0xb71174['includes']('opera/')||_0xb71174['includes']('opr/')||_0xb71174['includes']('opios/'))return'Opera';if(Na(_0xb71174))return'IEMobile';if(_0xb71174['includes']('msie')||_0xb71174['includes']('trident/'))return'IE';if(_0xb71174['includes']('edge/'))return'Edge';if(Ra(_0xb71174))return'Firefox';if(_0xb71174['includes']('silk/'))return'Silk';if(Oa(_0xb71174))return'Blackberry';if(Da(_0xb71174))return'Webos';if(Aa(_0xb71174))return'Safari';if((_0xb71174['includes']('chrome/')||ka(_0xb71174))&&!_0xb71174['includes']('edge/'))return'Chrome';if(Pa(_0xb71174))return'Android';{const _0x2ecb63=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x45e170=_0x1dc3b5['match'](_0x2ecb63);if((_0x45e170==null?void 0x0:_0x45e170['length'])===0x2)return _0x45e170[0x1];}return'Other';}function Ra(_0x315b8b=W()){return/firefox\//i['test'](_0x315b8b);}function Aa(_0x492fcc=W()){const _0x20cced=_0x492fcc['toLowerCase']();return _0x20cced['includes']('safari/')&&!_0x20cced['includes']('chrome/')&&!_0x20cced['includes']('crios/')&&!_0x20cced['includes']('android');}function ka(_0x1b1829=W()){return/crios\//i['test'](_0x1b1829);}function Na(_0x44449f=W()){return/iemobile/i['test'](_0x44449f);}function Pa(_0xda9271=W()){return/android/i['test'](_0xda9271);}function Oa(_0x45cf8d=W()){return/blackberry/i['test'](_0x45cf8d);}function Da(_0x1220c2=W()){return/webos/i['test'](_0x1220c2);}function Ss(_0x3d3606=W()){return/iphone|ipad|ipod/i['test'](_0x3d3606)||/macintosh/i['test'](_0x3d3606)&&/mobile/i['test'](_0x3d3606);}function Sf(_0x2e9279=W()){var _0x3b7ee2;return Ss(_0x2e9279)&&!!((_0x3b7ee2=window['navigator'])!=null&&_0x3b7ee2['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x85b74a=W()){return Ss(_0x85b74a)||Pa(_0x85b74a)||Da(_0x85b74a)||Oa(_0x85b74a)||/windows phone/i['test'](_0x85b74a)||Na(_0x85b74a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x3013f2,_0x59b827=[]){let _0x25253f;switch(_0x3013f2){case'Browser':_0x25253f=br(W());break;case'Worker':_0x25253f=br(W())+'-'+_0x3013f2;break;default:_0x25253f=_0x3013f2;}const _0x48ccd3=_0x59b827['length']?_0x59b827['join'](','):'FirebaseCore-web';return _0x25253f+'/JsCore/'+dt+'/'+_0x48ccd3;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x43e9ad){this['auth']=_0x43e9ad,this['queue']=[];}['pushCallback'](_0x5211d1,_0x4dbf39){const _0x4e3f8d=_0x37eb0f=>new Promise((_0x5e9268,_0xc8cacf)=>{try{const _0xe8a3dc=_0x5211d1(_0x37eb0f);_0x5e9268(_0xe8a3dc);}catch(_0x4ae5b0){_0xc8cacf(_0x4ae5b0);}});_0x4e3f8d['onAbort']=_0x4dbf39,this['queue']['push'](_0x4e3f8d);const _0x105ed5=this['queue']['length']-0x1;return()=>{this['queue'][_0x105ed5]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3f8175){if(this['auth']['currentUser']===_0x3f8175)return;const _0x3d2d6d=[];try{for(const _0x1dccf5 of this['queue'])await _0x1dccf5(_0x3f8175),_0x1dccf5['onAbort']&&_0x3d2d6d['push'](_0x1dccf5['onAbort']);}catch(_0x239c53){_0x3d2d6d['reverse']();for(const _0x346168 of _0x3d2d6d)try{_0x346168();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x239c53==null?void 0x0:_0x239c53['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x371ece,_0x4132f4={}){return ke(_0x371ece,'GET','/v2/passwordPolicy',Ae(_0x371ece,_0x4132f4));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x47993c){var _0x3d330a;const _0x471eb5=_0x47993c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x471eb5['minPasswordLength']??kf,_0x471eb5['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x471eb5['maxPasswordLength']),_0x471eb5['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x471eb5['containsLowercaseCharacter']),_0x471eb5['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x471eb5['containsUppercaseCharacter']),_0x471eb5['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x471eb5['containsNumericCharacter']),_0x471eb5['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x471eb5['containsNonAlphanumericCharacter']),this['enforcementState']=_0x47993c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3d330a=_0x47993c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3d330a['join'](''))??'',this['forceUpgradeOnSignin']=_0x47993c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x47993c['schemaVersion'];}['validatePassword'](_0x5bfdaa){const _0xfd1229={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5bfdaa,_0xfd1229),this['validatePasswordCharacterOptions'](_0x5bfdaa,_0xfd1229),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['meetsMinPasswordLength']??!0x0),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['meetsMaxPasswordLength']??!0x0),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['containsLowercaseLetter']??!0x0),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['containsUppercaseLetter']??!0x0),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['containsNumericCharacter']??!0x0),_0xfd1229['isValid']&&(_0xfd1229['isValid']=_0xfd1229['containsNonAlphanumericCharacter']??!0x0),_0xfd1229;}['validatePasswordLengthOptions'](_0x4b126f,_0x1fe14c){const _0x4d3f9c=this['customStrengthOptions']['minPasswordLength'],_0x40f5b2=this['customStrengthOptions']['maxPasswordLength'];_0x4d3f9c&&(_0x1fe14c['meetsMinPasswordLength']=_0x4b126f['length']>=_0x4d3f9c),_0x40f5b2&&(_0x1fe14c['meetsMaxPasswordLength']=_0x4b126f['length']<=_0x40f5b2);}['validatePasswordCharacterOptions'](_0x558f7d,_0x24ce60){this['updatePasswordCharacterOptionsStatuses'](_0x24ce60,!0x1,!0x1,!0x1,!0x1);let _0xbdad73;for(let _0x907374=0x0;_0x907374<_0x558f7d['length'];_0x907374++)_0xbdad73=_0x558f7d['charAt'](_0x907374),this['updatePasswordCharacterOptionsStatuses'](_0x24ce60,_0xbdad73>='a'&&_0xbdad73<='z',_0xbdad73>='A'&&_0xbdad73<='Z',_0xbdad73>='0'&&_0xbdad73<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xbdad73));}['updatePasswordCharacterOptionsStatuses'](_0x422d98,_0x2e9a39,_0x5739b0,_0x1550cd,_0x318fa2){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x422d98['containsLowercaseLetter']||(_0x422d98['containsLowercaseLetter']=_0x2e9a39)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x422d98['containsUppercaseLetter']||(_0x422d98['containsUppercaseLetter']=_0x5739b0)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x422d98['containsNumericCharacter']||(_0x422d98['containsNumericCharacter']=_0x1550cd)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x422d98['containsNonAlphanumericCharacter']||(_0x422d98['containsNonAlphanumericCharacter']=_0x318fa2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0xb35a7c,_0x57235d,_0x4464f0,_0x46e49a){this['app']=_0xb35a7c,this['heartbeatServiceProvider']=_0x57235d,this['appCheckServiceProvider']=_0x4464f0,this['config']=_0x46e49a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xb35a7c['name'],this['clientVersion']=_0x46e49a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3eacec=>this['_resolvePersistenceManagerAvailable']=_0x3eacec);}['_initializeWithPersistence'](_0x588fc9,_0x30d6d0){return _0x30d6d0&&(this['_popupRedirectResolver']=ie(_0x30d6d0)),this['_initializationPromise']=this['queue'](async()=>{var _0x17929c,_0x55c52d,_0x16cfca;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x588fc9),(_0x17929c=this['_resolvePersistenceManagerAvailable'])==null||_0x17929c['call'](this),!this['_deleted'])){if((_0x55c52d=this['_popupRedirectResolver'])!=null&&_0x55c52d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x30d6d0),this['lastNotifiedUid']=((_0x16cfca=this['currentUser'])==null?void 0x0:_0x16cfca['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5c2d02=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5c2d02)){if(this['currentUser']&&_0x5c2d02&&this['currentUser']['uid']===_0x5c2d02['uid']){this['_currentUser']['_assign'](_0x5c2d02),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5c2d02,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4d03e9){try{const _0x29858d=await Nn(this,{'idToken':_0x4d03e9}),_0x51df19=await j['_fromGetAccountInfoResponse'](this,_0x29858d,_0x4d03e9);await this['directlySetCurrentUser'](_0x51df19);}catch(_0x4da6c5){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4da6c5),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xbc3d26){var _0x4f321f;if($(this['app'])){const _0x56e206=this['app']['settings']['authIdToken'];return _0x56e206?new Promise(_0x185b7d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x56e206)['then'](_0x185b7d,_0x185b7d));}):this['directlySetCurrentUser'](null);}const _0x19c00a=await this['assertedPersistence']['getCurrentUser']();let _0x3215d5=_0x19c00a,_0xbfe100=!0x1;if(_0xbc3d26&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3de4ea=(_0x4f321f=this['redirectUser'])==null?void 0x0:_0x4f321f['_redirectEventId'],_0x163fc9=_0x3215d5==null?void 0x0:_0x3215d5['_redirectEventId'],_0x813650=await this['tryRedirectSignIn'](_0xbc3d26);(!_0x3de4ea||_0x3de4ea===_0x163fc9)&&(_0x813650!=null&&_0x813650['user'])&&(_0x3215d5=_0x813650['user'],_0xbfe100=!0x0);}if(!_0x3215d5)return this['directlySetCurrentUser'](null);if(!_0x3215d5['_redirectEventId']){if(_0xbfe100)try{await this['beforeStateQueue']['runMiddleware'](_0x3215d5);}catch(_0x2a4d00){_0x3215d5=_0x19c00a,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2a4d00));}return _0x3215d5?this['reloadAndSetCurrentUserOrClear'](_0x3215d5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3215d5['_redirectEventId']?this['directlySetCurrentUser'](_0x3215d5):this['reloadAndSetCurrentUserOrClear'](_0x3215d5);}async['tryRedirectSignIn'](_0x4a8716){let _0x1e2415=null;try{_0x1e2415=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4a8716,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1e2415;}async['reloadAndSetCurrentUserOrClear'](_0x3fae9c){try{await Pn(_0x3fae9c);}catch(_0x31e610){if((_0x31e610==null?void 0x0:_0x31e610['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3fae9c);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x26ad7e){if($(this['app']))return Promise['reject'](re(this));const _0x57382a=_0x26ad7e?N(_0x26ad7e):null;return _0x57382a&&m(_0x57382a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x57382a&&_0x57382a['_clone'](this));}async['_updateCurrentUser'](_0x4ede75,_0x4de281=!0x1){if(!this['_deleted'])return _0x4ede75&&m(this['tenantId']===_0x4ede75['tenantId'],this,'tenant-id-mismatch'),_0x4de281||await this['beforeStateQueue']['runMiddleware'](_0x4ede75),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x4ede75),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2eedf3){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2eedf3));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x403779){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x6e5c72=this['_getPasswordPolicyInternal']();return _0x6e5c72['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x6e5c72['validatePassword'](_0x403779);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x206df0=await Af(this),_0x47ab9a=new Nf(_0x206df0);this['tenantId']===null?this['_projectPasswordPolicy']=_0x47ab9a:this['_tenantPasswordPolicies'][this['tenantId']]=_0x47ab9a;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2e5273){this['_errorFactory']=new $t('auth','Firebase',_0x2e5273());}['onAuthStateChanged'](_0x1c5c5e,_0x29d64a,_0x5abffa){return this['registerStateListener'](this['authStateSubscription'],_0x1c5c5e,_0x29d64a,_0x5abffa);}['beforeAuthStateChanged'](_0xa514e8,_0x281a1d){return this['beforeStateQueue']['pushCallback'](_0xa514e8,_0x281a1d);}['onIdTokenChanged'](_0xaa3dff,_0x293673,_0x2a6971){return this['registerStateListener'](this['idTokenSubscription'],_0xaa3dff,_0x293673,_0x2a6971);}['authStateReady'](){return new Promise((_0x2da352,_0x1f28d0)=>{if(this['currentUser'])_0x2da352();else{const _0x5d6edf=this['onAuthStateChanged'](()=>{_0x5d6edf(),_0x2da352();},_0x1f28d0);}});}async['revokeAccessToken'](_0x2c4391){if(this['currentUser']){const _0x4eaad9=await this['currentUser']['getIdToken'](),_0x1b99ef={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2c4391,'idToken':_0x4eaad9};this['tenantId']!=null&&(_0x1b99ef['tenantId']=this['tenantId']),await Tf(this,_0x1b99ef);}}['toJSON'](){var _0x2b91c7;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2b91c7=this['_currentUser'])==null?void 0x0:_0x2b91c7['toJSON']()};}async['_setRedirectUser'](_0xf3dccb,_0x1553c7){const _0x18efd7=await this['getOrInitRedirectPersistenceManager'](_0x1553c7);return _0xf3dccb===null?_0x18efd7['removeCurrentUser']():_0x18efd7['setCurrentUser'](_0xf3dccb);}async['getOrInitRedirectPersistenceManager'](_0x4e68c1){if(!this['redirectPersistenceManager']){const _0x4a799f=_0x4e68c1&&ie(_0x4e68c1)||this['_popupRedirectResolver'];m(_0x4a799f,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x4a799f['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4e157a){var _0x4421b8,_0xbfd8bc;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4421b8=this['_currentUser'])==null?void 0x0:_0x4421b8['_redirectEventId'])===_0x4e157a?this['_currentUser']:((_0xbfd8bc=this['redirectUser'])==null?void 0x0:_0xbfd8bc['_redirectEventId'])===_0x4e157a?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x17267c){if(_0x17267c===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x17267c));}['_notifyListenersIfCurrent'](_0x213ffe){_0x213ffe===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x39481c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x509885=((_0x39481c=this['currentUser'])==null?void 0x0:_0x39481c['uid'])??null;this['lastNotifiedUid']!==_0x509885&&(this['lastNotifiedUid']=_0x509885,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1fd3b2,_0x3fadd1,_0x12b4ba,_0x4fc236){if(this['_deleted'])return()=>{};const _0x44f83e=typeof _0x3fadd1=='function'?_0x3fadd1:_0x3fadd1['next']['bind'](_0x3fadd1);let _0x2795a7=!0x1;const _0x351f51=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x351f51,this,'internal-error'),_0x351f51['then'](()=>{_0x2795a7||_0x44f83e(this['currentUser']);}),typeof _0x3fadd1=='function'){const _0x1a4910=_0x1fd3b2['addObserver'](_0x3fadd1,_0x12b4ba,_0x4fc236);return()=>{_0x2795a7=!0x0,_0x1a4910();};}else{const _0x4b95dd=_0x1fd3b2['addObserver'](_0x3fadd1);return()=>{_0x2795a7=!0x0,_0x4b95dd();};}}async['directlySetCurrentUser'](_0xcc9dfa){this['currentUser']&&this['currentUser']!==_0xcc9dfa&&this['_currentUser']['_stopProactiveRefresh'](),_0xcc9dfa&&this['isProactiveRefreshEnabled']&&_0xcc9dfa['_startProactiveRefresh'](),this['currentUser']=_0xcc9dfa,_0xcc9dfa?await this['assertedPersistence']['setCurrentUser'](_0xcc9dfa):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3d7f37){return this['operations']=this['operations']['then'](_0x3d7f37,_0x3d7f37),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x21226c){!_0x21226c||this['frameworks']['includes'](_0x21226c)||(this['frameworks']['push'](_0x21226c),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x25e5bd;const _0x3e7a2a={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3e7a2a['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x23f6e0=await((_0x25e5bd=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x25e5bd['getHeartbeatsHeader']());_0x23f6e0&&(_0x3e7a2a['X-Firebase-Client']=_0x23f6e0);const _0x2c02fb=await this['_getAppCheckToken']();return _0x2c02fb&&(_0x3e7a2a['X-Firebase-AppCheck']=_0x2c02fb),_0x3e7a2a;}async['_getAppCheckToken'](){var _0xca296d;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3e23ab=await((_0xca296d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xca296d['getToken']());return _0x3e23ab!=null&&_0x3e23ab['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3e23ab['error']),_0x3e23ab==null?void 0x0:_0x3e23ab['token'];}}function Ke(_0x196917){return N(_0x196917);}class Rr{constructor(_0x5de91a){this['auth']=_0x5de91a,this['observer']=null,this['addObserver']=Tc(_0x4d694a=>this['observer']=_0x4d694a);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x25d685){Jn=_0x25d685;}function xa(_0x6a6915){return Jn['loadJS'](_0x6a6915);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x5d5e0d){return'__'+_0x5d5e0d+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x1340f5){_0x1340f5();}['execute'](_0x21cadc,_0x210373){return Promise['resolve']('token');}['render'](_0x57dd61,_0x1a4253){return'';}}class Ff{['ready'](_0x56fd7c){_0x56fd7c();}['execute'](_0x1a0455,_0x5ed2b0){return Promise['resolve']('token');}['render'](_0x330461,_0x4e3c68){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3d92ce){this['type']=Uf,this['auth']=Ke(_0x3d92ce);}async['verify'](_0x39ac8b='verify',_0x3de3f7=!0x1){async function _0x13bce6(_0x149f1c){if(!_0x3de3f7){if(_0x149f1c['tenantId']==null&&_0x149f1c['_agentRecaptchaConfig']!=null)return _0x149f1c['_agentRecaptchaConfig']['siteKey'];if(_0x149f1c['tenantId']!=null&&_0x149f1c['_tenantRecaptchaConfigs'][_0x149f1c['tenantId']]!==void 0x0)return _0x149f1c['_tenantRecaptchaConfigs'][_0x149f1c['tenantId']]['siteKey'];}return new Promise(async(_0x19a88c,_0x3cb131)=>{gf(_0x149f1c,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xbdd2b6=>{if(_0xbdd2b6['recaptchaKey']===void 0x0)_0x3cb131(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xba2eb9=new _f(_0xbdd2b6);return _0x149f1c['tenantId']==null?_0x149f1c['_agentRecaptchaConfig']=_0xba2eb9:_0x149f1c['_tenantRecaptchaConfigs'][_0x149f1c['tenantId']]=_0xba2eb9,_0x19a88c(_0xba2eb9['siteKey']);}})['catch'](_0x5e77fc=>{_0x3cb131(_0x5e77fc);});});}function _0x48ec0a(_0x35e107,_0x4aaabc,_0x541a81){const _0x563293=window['grecaptcha'];wr(_0x563293)?_0x563293['enterprise']['ready'](()=>{_0x563293['enterprise']['execute'](_0x35e107,{'action':_0x39ac8b})['then'](_0x4e41ca=>{_0x4aaabc(_0x4e41ca);})['catch'](()=>{_0x4aaabc(Fa);});}):_0x541a81(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x2184ac,_0x7a131b)=>{_0x13bce6(this['auth'])['then'](async _0x524ec3=>{if(!_0x3de3f7&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x48ec0a(_0x524ec3,_0x2184ac,_0x7a131b);else{if(typeof window>'u'){_0x7a131b(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2cd1df=Df();_0x2cd1df['length']!==0x0&&(_0x2cd1df+=_0x524ec3+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x23f541;(_0x23f541=he['scriptInjectionDeferred'])==null||_0x23f541['resolve']();},xa(_0x2cd1df)['then'](()=>{var _0x2bfc66;return(_0x2bfc66=he['scriptInjectionDeferred'])==null?void 0x0:_0x2bfc66['promise'];})['then'](()=>{_0x48ec0a(_0x524ec3,_0x2184ac,_0x7a131b);})['catch'](_0x538258=>{_0x7a131b(_0x538258);});}})['catch'](_0xc8f0de=>{_0x7a131b(_0xc8f0de);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x322231,_0x2001c0,_0x4965e3,_0x2506cb=!0x1,_0x335ab4=!0x1){const _0x1f3051=new he(_0x322231);let _0x3885f;if(_0x335ab4)_0x3885f=Fa;else try{_0x3885f=await _0x1f3051['verify'](_0x4965e3);}catch{_0x3885f=await _0x1f3051['verify'](_0x4965e3,!0x0);}const _0x1a164b={..._0x2001c0};if(_0x4965e3==='mfaSmsEnrollment'||_0x4965e3==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1a164b){const _0x590930=_0x1a164b['phoneEnrollmentInfo']['phoneNumber'],_0x169511=_0x1a164b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1a164b,{'phoneEnrollmentInfo':{'phoneNumber':_0x590930,'recaptchaToken':_0x169511,'captchaResponse':_0x3885f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1a164b){const _0x459f46=_0x1a164b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1a164b,{'phoneSignInInfo':{'recaptchaToken':_0x459f46,'captchaResponse':_0x3885f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1a164b;}return _0x2506cb?Object['assign'](_0x1a164b,{'captchaResp':_0x3885f}):Object['assign'](_0x1a164b,{'captchaResponse':_0x3885f}),Object['assign'](_0x1a164b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1a164b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1a164b;}async function xi(_0x391f7a,_0x30f2e0,_0x170c44,_0xf9abaa,_0x30a5a4){var _0x3a34ca;if((_0x3a34ca=_0x391f7a['_getRecaptchaConfig']())!=null&&_0x3a34ca['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x13cb3a=await kr(_0x391f7a,_0x30f2e0,_0x170c44,_0x170c44==='getOobCode');return _0xf9abaa(_0x391f7a,_0x13cb3a);}else return _0xf9abaa(_0x391f7a,_0x30f2e0)['catch'](async _0x44859e=>{if(_0x44859e['code']==='auth/missing-recaptcha-token'){console['log'](_0x170c44+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3d2279=await kr(_0x391f7a,_0x30f2e0,_0x170c44,_0x170c44==='getOobCode');return _0xf9abaa(_0x391f7a,_0x3d2279);}else return Promise['reject'](_0x44859e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0x1b206d,_0x1827e5){const _0x2bc21c=Hi(_0x1b206d,'auth');if(_0x2bc21c['isInitialized']()){const _0x21fe03=_0x2bc21c['getImmediate'](),_0x33762d=_0x2bc21c['getOptions']();if(Le(_0x33762d,_0x1827e5??{}))return _0x21fe03;Y(_0x21fe03,'already-initialized');}return _0x2bc21c['initialize']({'options':_0x1827e5});}function Bf(_0x5de576,_0xa6ebdd){const _0x988675=(_0xa6ebdd==null?void 0x0:_0xa6ebdd['persistence'])||[],_0x5f48a8=(Array['isArray'](_0x988675)?_0x988675:[_0x988675])['map'](ie);_0xa6ebdd!=null&&_0xa6ebdd['errorMap']&&_0x5de576['_updateErrorMap'](_0xa6ebdd['errorMap']),_0x5de576['_initializeWithPersistence'](_0x5f48a8,_0xa6ebdd==null?void 0x0:_0xa6ebdd['popupRedirectResolver']);}function Vf(_0x2bdf5c,_0x3231ae,_0x2e7d84){const _0x2f9639=Ke(_0x2bdf5c);m(/^https?:\/\//['test'](_0x3231ae),_0x2f9639,'invalid-emulator-scheme');const _0x545938=!0x1,_0x49dddd=Ua(_0x3231ae),{host:_0x1f1785,port:_0x149f8a}=Hf(_0x3231ae),_0x27fee2=_0x149f8a===null?'':':'+_0x149f8a,_0xe19fa0={'url':_0x49dddd+'//'+_0x1f1785+_0x27fee2+'/'},_0x3fc38d=Object['freeze']({'host':_0x1f1785,'port':_0x149f8a,'protocol':_0x49dddd['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x545938})});if(!_0x2f9639['_canInitEmulator']){m(_0x2f9639['config']['emulator']&&_0x2f9639['emulatorConfig'],_0x2f9639,'emulator-config-failed'),m(Le(_0xe19fa0,_0x2f9639['config']['emulator'])&&Le(_0x3fc38d,_0x2f9639['emulatorConfig']),_0x2f9639,'emulator-config-failed');return;}_0x2f9639['config']['emulator']=_0xe19fa0,_0x2f9639['emulatorConfig']=_0x3fc38d,_0x2f9639['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x1f1785)?Qr(_0x49dddd+'//'+_0x1f1785+_0x27fee2):$f();}function Ua(_0x40c8cb){const _0xd4a1f5=_0x40c8cb['indexOf'](':');return _0xd4a1f5<0x0?'':_0x40c8cb['substr'](0x0,_0xd4a1f5+0x1);}function Hf(_0x13069a){const _0x185f05=Ua(_0x13069a),_0x44bb05=/(\/\/)?([^?#/]+)/['exec'](_0x13069a['substr'](_0x185f05['length']));if(!_0x44bb05)return{'host':'','port':null};const _0x1729fe=_0x44bb05[0x2]['split']('@')['pop']()||'',_0x3febed=/^(\[[^\]]+\])(:|$)/['exec'](_0x1729fe);if(_0x3febed){const _0x4d5dda=_0x3febed[0x1];return{'host':_0x4d5dda,'port':Nr(_0x1729fe['substr'](_0x4d5dda['length']+0x1))};}else{const [_0x1d18fb,_0x350be0]=_0x1729fe['split'](':');return{'host':_0x1d18fb,'port':Nr(_0x350be0)};}}function Nr(_0x51b492){if(!_0x51b492)return null;const _0x36eb7f=Number(_0x51b492);return isNaN(_0x36eb7f)?null:_0x36eb7f;}function $f(){function _0x1d07a1(){const _0x2d693f=document['createElement']('p'),_0x1f5c51=_0x2d693f['style'];_0x2d693f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1f5c51['position']='fixed',_0x1f5c51['width']='100%',_0x1f5c51['backgroundColor']='#ffffff',_0x1f5c51['border']='.1em\x20solid\x20#000000',_0x1f5c51['color']='#b50000',_0x1f5c51['bottom']='0px',_0x1f5c51['left']='0px',_0x1f5c51['margin']='0px',_0x1f5c51['zIndex']='10000',_0x1f5c51['textAlign']='center',_0x2d693f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2d693f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1d07a1):_0x1d07a1());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x75d000,_0x2264cb){this['providerId']=_0x75d000,this['signInMethod']=_0x2264cb;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x17c8de){return ne('not\x20implemented');}['_linkToIdToken'](_0xdecfe7,_0x5d96a7){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x4ee543){return ne('not\x20implemented');}}async function Gf(_0x43c7dc,_0x10b595){return ke(_0x43c7dc,'POST','/v1/accounts:signUp',_0x10b595);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x448ef9,_0xde26c){return en(_0x448ef9,'POST','/v1/accounts:signInWithPassword',Ae(_0x448ef9,_0xde26c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x46e774,_0x2febaa){return en(_0x46e774,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x46e774,_0x2febaa));}async function jf(_0x341d1f,_0x47db00){return en(_0x341d1f,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x341d1f,_0x47db00));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x2d2c66,_0x19fdd7,_0x12cf8d,_0x136541=null){super('password',_0x12cf8d),this['_email']=_0x2d2c66,this['_password']=_0x19fdd7,this['_tenantId']=_0x136541;}static['_fromEmailAndPassword'](_0x5f23d8,_0x2dd0b1){return new Ht(_0x5f23d8,_0x2dd0b1,'password');}static['_fromEmailAndCode'](_0x296da9,_0x588ac3,_0x3fa333=null){return new Ht(_0x296da9,_0x588ac3,'emailLink',_0x3fa333);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4139a4){const _0x9966ab=typeof _0x4139a4=='string'?JSON['parse'](_0x4139a4):_0x4139a4;if(_0x9966ab!=null&&_0x9966ab['email']&&(_0x9966ab!=null&&_0x9966ab['password'])){if(_0x9966ab['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x9966ab['email'],_0x9966ab['password']);if(_0x9966ab['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x9966ab['email'],_0x9966ab['password'],_0x9966ab['tenantId']);}return null;}async['_getIdTokenResponse'](_0x107029){switch(this['signInMethod']){case'password':const _0x9c4b={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x107029,_0x9c4b,'signInWithPassword',qf);case'emailLink':return zf(_0x107029,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x107029,'internal-error');}}async['_linkToIdToken'](_0x549ed7,_0x399fd3){switch(this['signInMethod']){case'password':const _0x59d055={'idToken':_0x399fd3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x549ed7,_0x59d055,'signUpPassword',Gf);case'emailLink':return jf(_0x549ed7,{'idToken':_0x399fd3,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x549ed7,'internal-error');}}['_getReauthenticationResolver'](_0x1b3480){return this['_getIdTokenResponse'](_0x1b3480);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2c7842,_0x1e9561){return en(_0x2c7842,'POST','/v1/accounts:signInWithIdp',Ae(_0x2c7842,_0x1e9561));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x204e67){const _0x1bc1ea=new He(_0x204e67['providerId'],_0x204e67['signInMethod']);return _0x204e67['idToken']||_0x204e67['accessToken']?(_0x204e67['idToken']&&(_0x1bc1ea['idToken']=_0x204e67['idToken']),_0x204e67['accessToken']&&(_0x1bc1ea['accessToken']=_0x204e67['accessToken']),_0x204e67['nonce']&&!_0x204e67['pendingToken']&&(_0x1bc1ea['nonce']=_0x204e67['nonce']),_0x204e67['pendingToken']&&(_0x1bc1ea['pendingToken']=_0x204e67['pendingToken'])):_0x204e67['oauthToken']&&_0x204e67['oauthTokenSecret']?(_0x1bc1ea['accessToken']=_0x204e67['oauthToken'],_0x1bc1ea['secret']=_0x204e67['oauthTokenSecret']):Y('argument-error'),_0x1bc1ea;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x45e8ab){const _0x162751=typeof _0x45e8ab=='string'?JSON['parse'](_0x45e8ab):_0x45e8ab,{providerId:_0x2b2ebc,signInMethod:_0x198cce,..._0x423d04}=_0x162751;if(!_0x2b2ebc||!_0x198cce)return null;const _0x34943a=new He(_0x2b2ebc,_0x198cce);return _0x34943a['idToken']=_0x423d04['idToken']||void 0x0,_0x34943a['accessToken']=_0x423d04['accessToken']||void 0x0,_0x34943a['secret']=_0x423d04['secret'],_0x34943a['nonce']=_0x423d04['nonce'],_0x34943a['pendingToken']=_0x423d04['pendingToken']||null,_0x34943a;}['_getIdTokenResponse'](_0x5a1768){const _0x2ce0a4=this['buildRequest']();return nt(_0x5a1768,_0x2ce0a4);}['_linkToIdToken'](_0x68830b,_0x419d07){const _0x8b1dab=this['buildRequest']();return _0x8b1dab['idToken']=_0x419d07,nt(_0x68830b,_0x8b1dab);}['_getReauthenticationResolver'](_0x4b491c){const _0x5ddbed=this['buildRequest']();return _0x5ddbed['autoCreate']=!0x1,nt(_0x4b491c,_0x5ddbed);}['buildRequest'](){const _0x405993={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x405993['pendingToken']=this['pendingToken'];else{const _0xa85a14={};this['idToken']&&(_0xa85a14['id_token']=this['idToken']),this['accessToken']&&(_0xa85a14['access_token']=this['accessToken']),this['secret']&&(_0xa85a14['oauth_token_secret']=this['secret']),_0xa85a14['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xa85a14['nonce']=this['nonce']),_0x405993['postBody']=ut(_0xa85a14);}return _0x405993;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0x558a26){switch(_0x558a26){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x25e4a7){const _0x1745d5=wt(Ct(_0x25e4a7))['link'],_0x51cc02=_0x1745d5?wt(Ct(_0x1745d5))['deep_link_id']:null,_0x1c8066=wt(Ct(_0x25e4a7))['deep_link_id'];return(_0x1c8066?wt(Ct(_0x1c8066))['link']:null)||_0x1c8066||_0x51cc02||_0x1745d5||_0x25e4a7;}class Rs{constructor(_0x354014){const _0x3fdcfd=wt(Ct(_0x354014)),_0x2a2ff3=_0x3fdcfd['apiKey']??null,_0x354cce=_0x3fdcfd['oobCode']??null,_0x411b91=Yf(_0x3fdcfd['mode']??null);m(_0x2a2ff3&&_0x354cce&&_0x411b91,'argument-error'),this['apiKey']=_0x2a2ff3,this['operation']=_0x411b91,this['code']=_0x354cce,this['continueUrl']=_0x3fdcfd['continueUrl']??null,this['languageCode']=_0x3fdcfd['lang']??null,this['tenantId']=_0x3fdcfd['tenantId']??null;}static['parseLink'](_0xbd6f2){const _0x1c2c27=Qf(_0xbd6f2);try{return new Rs(_0x1c2c27);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0xf9626c,_0x133a7c){return Ht['_fromEmailAndPassword'](_0xf9626c,_0x133a7c);}static['credentialWithLink'](_0x3e0e47,_0x716f3f){const _0x6e1067=Rs['parseLink'](_0x716f3f);return m(_0x6e1067,'argument-error'),Ht['_fromEmailAndCode'](_0x3e0e47,_0x6e1067['code'],_0x6e1067['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3b9ea2){this['providerId']=_0x3b9ea2,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x32632e){this['defaultLanguageCode']=_0x32632e;}['setCustomParameters'](_0x470970){return this['customParameters']=_0x470970,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x241b38){return this['scopes']['includes'](_0x241b38)||this['scopes']['push'](_0x241b38),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x53db7e){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x53db7e});}static['credentialFromResult'](_0x5e7012){return ue['credentialFromTaggedObject'](_0x5e7012);}static['credentialFromError'](_0x41cf5a){return ue['credentialFromTaggedObject'](_0x41cf5a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x50ae36}){if(!_0x50ae36||!('oauthAccessToken'in _0x50ae36)||!_0x50ae36['oauthAccessToken'])return null;try{return ue['credential'](_0x50ae36['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xf99404,_0x45e603){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xf99404,'accessToken':_0x45e603});}static['credentialFromResult'](_0x35bb58){return de['credentialFromTaggedObject'](_0x35bb58);}static['credentialFromError'](_0x5a21bb){return de['credentialFromTaggedObject'](_0x5a21bb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x446227}){if(!_0x446227)return null;const {oauthIdToken:_0x44ac19,oauthAccessToken:_0xf69d0b}=_0x446227;if(!_0x44ac19&&!_0xf69d0b)return null;try{return de['credential'](_0x44ac19,_0xf69d0b);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x24fca2){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x24fca2});}static['credentialFromResult'](_0x38bd79){return fe['credentialFromTaggedObject'](_0x38bd79);}static['credentialFromError'](_0x20705c){return fe['credentialFromTaggedObject'](_0x20705c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x7dbdcf}){if(!_0x7dbdcf||!('oauthAccessToken'in _0x7dbdcf)||!_0x7dbdcf['oauthAccessToken'])return null;try{return fe['credential'](_0x7dbdcf['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4753c8,_0xe1d45a){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4753c8,'oauthTokenSecret':_0xe1d45a});}static['credentialFromResult'](_0x18b10f){return pe['credentialFromTaggedObject'](_0x18b10f);}static['credentialFromError'](_0x3de189){return pe['credentialFromTaggedObject'](_0x3de189['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4655aa}){if(!_0x4655aa)return null;const {oauthAccessToken:_0xebba4,oauthTokenSecret:_0x4027b5}=_0x4655aa;if(!_0xebba4||!_0x4027b5)return null;try{return pe['credential'](_0xebba4,_0x4027b5);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x4d7745,_0x2794ff){return en(_0x4d7745,'POST','/v1/accounts:signUp',Ae(_0x4d7745,_0x2794ff));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x28d43a){this['user']=_0x28d43a['user'],this['providerId']=_0x28d43a['providerId'],this['_tokenResponse']=_0x28d43a['_tokenResponse'],this['operationType']=_0x28d43a['operationType'];}static async['_fromIdTokenResponse'](_0x1521f6,_0x1e7302,_0x2421f0,_0x461df1=!0x1){const _0x3a50ad=await j['_fromIdTokenResponse'](_0x1521f6,_0x2421f0,_0x461df1),_0x317266=Pr(_0x2421f0);return new $e({'user':_0x3a50ad,'providerId':_0x317266,'_tokenResponse':_0x2421f0,'operationType':_0x1e7302});}static async['_forOperation'](_0x1ed760,_0x49bf54,_0x56d7e6){await _0x1ed760['_updateTokensIfNecessary'](_0x56d7e6,!0x0);const _0x2c45a6=Pr(_0x56d7e6);return new $e({'user':_0x1ed760,'providerId':_0x2c45a6,'_tokenResponse':_0x56d7e6,'operationType':_0x49bf54});}}function Pr(_0x38ad94){return _0x38ad94['providerId']?_0x38ad94['providerId']:'phoneNumber'in _0x38ad94?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x2d3138,_0x35297a,_0x109d77,_0x41176c){super(_0x35297a['code'],_0x35297a['message']),this['operationType']=_0x109d77,this['user']=_0x41176c,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x2d3138['name'],'tenantId':_0x2d3138['tenantId']??void 0x0,'_serverResponse':_0x35297a['customData']['_serverResponse'],'operationType':_0x109d77};}static['_fromErrorAndOperation'](_0x586984,_0x714e98,_0x3647c0,_0xf0aea8){return new On(_0x586984,_0x714e98,_0x3647c0,_0xf0aea8);}}function Ba(_0x2be367,_0x5ce9f4,_0x365f3d,_0x37d540){return(_0x5ce9f4==='reauthenticate'?_0x365f3d['_getReauthenticationResolver'](_0x2be367):_0x365f3d['_getIdTokenResponse'](_0x2be367))['catch'](_0x2475ec=>{throw _0x2475ec['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x2be367,_0x2475ec,_0x5ce9f4,_0x37d540):_0x2475ec;});}async function Xf(_0x1bdddc,_0x5ced98,_0x5f2dd3=!0x1){const _0x4b283a=await Vt(_0x1bdddc,_0x5ced98['_linkToIdToken'](_0x1bdddc['auth'],await _0x1bdddc['getIdToken']()),_0x5f2dd3);return $e['_forOperation'](_0x1bdddc,'link',_0x4b283a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x242bbd,_0x3c12e3,_0x4773a3=!0x1){const {auth:_0x5ee7f6}=_0x242bbd;if($(_0x5ee7f6['app']))return Promise['reject'](re(_0x5ee7f6));const _0x15809f='reauthenticate';try{const _0x2f7f41=await Vt(_0x242bbd,Ba(_0x5ee7f6,_0x15809f,_0x3c12e3,_0x242bbd),_0x4773a3);m(_0x2f7f41['idToken'],_0x5ee7f6,'internal-error');const _0x80a5c7=Ts(_0x2f7f41['idToken']);m(_0x80a5c7,_0x5ee7f6,'internal-error');const {sub:_0xfbf335}=_0x80a5c7;return m(_0x242bbd['uid']===_0xfbf335,_0x5ee7f6,'user-mismatch'),$e['_forOperation'](_0x242bbd,_0x15809f,_0x2f7f41);}catch(_0x479c0f){throw(_0x479c0f==null?void 0x0:_0x479c0f['code'])==='auth/user-not-found'&&Y(_0x5ee7f6,'user-mismatch'),_0x479c0f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x541401,_0x467cd,_0x3db37d=!0x1){if($(_0x541401['app']))return Promise['reject'](re(_0x541401));const _0x84e498='signIn',_0x2321a1=await Ba(_0x541401,_0x84e498,_0x467cd),_0x556779=await $e['_fromIdTokenResponse'](_0x541401,_0x84e498,_0x2321a1);return _0x3db37d||await _0x541401['_updateCurrentUser'](_0x556779['user']),_0x556779;}async function ep(_0x265fbc,_0x28eff2){return Va(Ke(_0x265fbc),_0x28eff2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4cdbe0){const _0x38e548=Ke(_0x4cdbe0);_0x38e548['_getPasswordPolicyInternal']()&&await _0x38e548['_updatePasswordPolicy']();}async function O_(_0x2cd068,_0x249d33,_0x2ceb11){if($(_0x2cd068['app']))return Promise['reject'](re(_0x2cd068));const _0x5cf100=Ke(_0x2cd068),_0x2e9373=await xi(_0x5cf100,{'returnSecureToken':!0x0,'email':_0x249d33,'password':_0x2ceb11,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0x386d95=>{throw _0x386d95['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2cd068),_0x386d95;}),_0x2ad132=await $e['_fromIdTokenResponse'](_0x5cf100,'signIn',_0x2e9373);return await _0x5cf100['_updateCurrentUser'](_0x2ad132['user']),_0x2ad132;}function D_(_0x12a97f,_0x81768b,_0x537043){return $(_0x12a97f['app'])?Promise['reject'](re(_0x12a97f)):ep(N(_0x12a97f),mt['credential'](_0x81768b,_0x537043))['catch'](async _0x51c6db=>{throw _0x51c6db['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x12a97f),_0x51c6db;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x463b67,_0x2ac369){return N(_0x463b67)['setPersistence'](_0x2ac369);}function tp(_0x5a3574,_0xee23ae,_0x5a7329,_0x305c13){return N(_0x5a3574)['onIdTokenChanged'](_0xee23ae,_0x5a7329,_0x305c13);}function np(_0x5d6614,_0x41f330,_0x58b07b){return N(_0x5d6614)['beforeAuthStateChanged'](_0x41f330,_0x58b07b);}function L_(_0x3775b2,_0x5e06b7,_0x3d53b0,_0x42420f){return N(_0x3775b2)['onAuthStateChanged'](_0x5e06b7,_0x3d53b0,_0x42420f);}function x_(_0x3a938d){return N(_0x3a938d)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x55b40a,_0x20f3d8){this['storageRetriever']=_0x55b40a,this['type']=_0x20f3d8;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x58ddce,_0x191a71){return this['storage']['setItem'](_0x58ddce,JSON['stringify'](_0x191a71)),Promise['resolve']();}['_get'](_0x2214c9){const _0x13ab54=this['storage']['getItem'](_0x2214c9);return Promise['resolve'](_0x13ab54?JSON['parse'](_0x13ab54):null);}['_remove'](_0x1f238e){return this['storage']['removeItem'](_0x1f238e),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3e7f3b,_0x3c8873)=>this['onStorageEvent'](_0x3e7f3b,_0x3c8873),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x57bb8a){for(const _0x257da4 of Object['keys'](this['listeners'])){const _0x478f5e=this['storage']['getItem'](_0x257da4),_0x593fda=this['localCache'][_0x257da4];_0x478f5e!==_0x593fda&&_0x57bb8a(_0x257da4,_0x593fda,_0x478f5e);}}['onStorageEvent'](_0x227283,_0xef0ade=!0x1){if(!_0x227283['key']){this['forAllChangedKeys']((_0x4ca04a,_0x208692,_0x1a8c65)=>{this['notifyListeners'](_0x4ca04a,_0x1a8c65);});return;}const _0x49c105=_0x227283['key'];_0xef0ade?this['detachListener']():this['stopPolling']();const _0x32cf8e=()=>{const _0x398f7d=this['storage']['getItem'](_0x49c105);!_0xef0ade&&this['localCache'][_0x49c105]===_0x398f7d||this['notifyListeners'](_0x49c105,_0x398f7d);},_0x1d9238=this['storage']['getItem'](_0x49c105);bf()&&_0x1d9238!==_0x227283['newValue']&&_0x227283['newValue']!==_0x227283['oldValue']?setTimeout(_0x32cf8e,sp):_0x32cf8e();}['notifyListeners'](_0x54baa8,_0x41aa9e){this['localCache'][_0x54baa8]=_0x41aa9e;const _0xd36f59=this['listeners'][_0x54baa8];if(_0xd36f59){for(const _0x5c89a8 of Array['from'](_0xd36f59))_0x5c89a8(_0x41aa9e&&JSON['parse'](_0x41aa9e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x735266,_0x1bc371,_0x23c8c7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x735266,'oldValue':_0x1bc371,'newValue':_0x23c8c7}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x232ba6,_0x2136fb){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x232ba6]||(this['listeners'][_0x232ba6]=new Set(),this['localCache'][_0x232ba6]=this['storage']['getItem'](_0x232ba6)),this['listeners'][_0x232ba6]['add'](_0x2136fb);}['_removeListener'](_0x4241fd,_0x1010ef){this['listeners'][_0x4241fd]&&(this['listeners'][_0x4241fd]['delete'](_0x1010ef),this['listeners'][_0x4241fd]['size']===0x0&&delete this['listeners'][_0x4241fd]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2b7f04,_0x301f25){await super['_set'](_0x2b7f04,_0x301f25),this['localCache'][_0x2b7f04]=JSON['stringify'](_0x301f25);}async['_get'](_0x3ac2bf){const _0x314f8d=await super['_get'](_0x3ac2bf);return this['localCache'][_0x3ac2bf]=JSON['stringify'](_0x314f8d),_0x314f8d;}async['_remove'](_0x172ccd){await super['_remove'](_0x172ccd),delete this['localCache'][_0x172ccd];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xffb419,_0x27e0bd){}['_removeListener'](_0x5e23ce,_0x36033c){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x5d7b68){return Promise['all'](_0x5d7b68['map'](async _0x343ec1=>{try{return{'fulfilled':!0x0,'value':await _0x343ec1};}catch(_0x4ac42e){return{'fulfilled':!0x1,'reason':_0x4ac42e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x18f2ef){this['eventTarget']=_0x18f2ef,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x25e8a7){const _0x323961=this['receivers']['find'](_0x3da00b=>_0x3da00b['isListeningto'](_0x25e8a7));if(_0x323961)return _0x323961;const _0x1ce837=new Xn(_0x25e8a7);return this['receivers']['push'](_0x1ce837),_0x1ce837;}['isListeningto'](_0xf0468c){return this['eventTarget']===_0xf0468c;}async['handleEvent'](_0x86bf40){const _0xbe97e9=_0x86bf40,{eventId:_0x5492a9,eventType:_0x256e7d,data:_0x6ddfe}=_0xbe97e9['data'],_0x4a722d=this['handlersMap'][_0x256e7d];if(!(_0x4a722d!=null&&_0x4a722d['size']))return;_0xbe97e9['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5492a9,'eventType':_0x256e7d});const _0x4e1c1f=Array['from'](_0x4a722d)['map'](async _0x37e430=>_0x37e430(_0xbe97e9['origin'],_0x6ddfe)),_0x31009d=await op(_0x4e1c1f);_0xbe97e9['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5492a9,'eventType':_0x256e7d,'response':_0x31009d});}['_subscribe'](_0x155378,_0x95ec36){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x155378]||(this['handlersMap'][_0x155378]=new Set()),this['handlersMap'][_0x155378]['add'](_0x95ec36);}['_unsubscribe'](_0xce797c,_0x3facec){this['handlersMap'][_0xce797c]&&_0x3facec&&this['handlersMap'][_0xce797c]['delete'](_0x3facec),(!_0x3facec||this['handlersMap'][_0xce797c]['size']===0x0)&&delete this['handlersMap'][_0xce797c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x19b3dc='',_0x322643=0xa){let _0x1912be='';for(let _0x2f4abd=0x0;_0x2f4abd<_0x322643;_0x2f4abd++)_0x1912be+=Math['floor'](Math['random']()*0xa);return _0x19b3dc+_0x1912be;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0x1ec90a){this['target']=_0x1ec90a,this['handlers']=new Set();}['removeMessageHandler'](_0xc99e8d){_0xc99e8d['messageChannel']&&(_0xc99e8d['messageChannel']['port1']['removeEventListener']('message',_0xc99e8d['onMessage']),_0xc99e8d['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xc99e8d);}async['_send'](_0x1da283,_0x1d9567,_0xb2c28=0x32){const _0xc52f22=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xc52f22)throw new Error('connection_unavailable');let _0x4bc418,_0x43b667;return new Promise((_0x227761,_0x578cd2)=>{const _0xf3a6d9=As('',0x14);_0xc52f22['port1']['start']();const _0x462908=setTimeout(()=>{_0x578cd2(new Error('unsupported_event'));},_0xb2c28);_0x43b667={'messageChannel':_0xc52f22,'onMessage'(_0x46af49){const _0x15737f=_0x46af49;if(_0x15737f['data']['eventId']===_0xf3a6d9)switch(_0x15737f['data']['status']){case'ack':clearTimeout(_0x462908),_0x4bc418=setTimeout(()=>{_0x578cd2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4bc418),_0x227761(_0x15737f['data']['response']);break;default:clearTimeout(_0x462908),clearTimeout(_0x4bc418),_0x578cd2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x43b667),_0xc52f22['port1']['addEventListener']('message',_0x43b667['onMessage']),this['target']['postMessage']({'eventType':_0x1da283,'eventId':_0xf3a6d9,'data':_0x1d9567},[_0xc52f22['port2']]);})['finally'](()=>{_0x43b667&&this['removeMessageHandler'](_0x43b667);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0xdcc252){Z()['location']['href']=_0xdcc252;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x228c78;return((_0x228c78=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x228c78['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x42e9a0){this['request']=_0x42e9a0;}['toPromise'](){return new Promise((_0x24337f,_0x3178f9)=>{this['request']['addEventListener']('success',()=>{_0x24337f(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3178f9(this['request']['error']);});});}}function Zn(_0x22f14a,_0x4212fa){return _0x22f14a['transaction']([Mn],_0x4212fa?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x44ca7a=indexedDB['deleteDatabase'](Ka);return new nn(_0x44ca7a)['toPromise']();}function Qa(){const _0x498946=indexedDB['open'](Ka,dp);return new Promise((_0x19b5e6,_0x2d5113)=>{_0x498946['addEventListener']('error',()=>{_0x2d5113(_0x498946['error']);}),_0x498946['addEventListener']('upgradeneeded',()=>{const _0x41fbe6=_0x498946['result'];try{_0x41fbe6['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0xdc00e0){_0x2d5113(_0xdc00e0);}}),_0x498946['addEventListener']('success',async()=>{const _0x2f44a0=_0x498946['result'];_0x2f44a0['objectStoreNames']['contains'](Mn)?_0x19b5e6(_0x2f44a0):(_0x2f44a0['close'](),await fp(),_0x19b5e6(await Qa()));});});}async function Or(_0x478514,_0x543a94,_0x57f4e9){const _0x37e85a=Zn(_0x478514,!0x0)['put']({[Ya]:_0x543a94,'value':_0x57f4e9});return new nn(_0x37e85a)['toPromise']();}async function pp(_0x484f54,_0x3181a4){const _0x44fd65=Zn(_0x484f54,!0x1)['get'](_0x3181a4),_0x46c9f3=await new nn(_0x44fd65)['toPromise']();return _0x46c9f3===void 0x0?null:_0x46c9f3['value'];}function Dr(_0xcefb80,_0x29bbaa){const _0x3ee7eb=Zn(_0xcefb80,!0x0)['delete'](_0x29bbaa);return new nn(_0x3ee7eb)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3aa856){let _0x4adf32=0x0;for(;;)try{const _0xb28cf8=await this['_openDb']();return await _0x3aa856(_0xb28cf8);}catch(_0x3824c8){if(_0x4adf32++>gp)throw _0x3824c8;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0x3daf47,_0x4a059c)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4a059c['key'])})),this['receiver']['_subscribe']('ping',async(_0x38e7ed,_0x324393)=>['keyChanged']);}async['initializeSender'](){var _0x2a72a7,_0x3a7f9e;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0x146017=await this['sender']['_send']('ping',{},0x320);_0x146017&&(_0x2a72a7=_0x146017[0x0])!=null&&_0x2a72a7['fulfilled']&&(_0x3a7f9e=_0x146017[0x0])!=null&&_0x3a7f9e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x19b8ff){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x19b8ff},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1a8fb7=>{await Or(_0x1a8fb7,Dn,'1'),await Dr(_0x1a8fb7,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x14d273){this['pendingWrites']++;try{await _0x14d273();}finally{this['pendingWrites']--;}}async['_set'](_0x4f721a,_0x1e6280){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1baa98=>Or(_0x1baa98,_0x4f721a,_0x1e6280)),this['localCache'][_0x4f721a]=_0x1e6280,this['notifyServiceWorker'](_0x4f721a)));}async['_get'](_0x2f8ac8){const _0x3c3f66=await this['_withRetries'](_0x39bde1=>pp(_0x39bde1,_0x2f8ac8));return this['localCache'][_0x2f8ac8]=_0x3c3f66,_0x3c3f66;}async['_remove'](_0x3eaf02){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3513a5=>Dr(_0x3513a5,_0x3eaf02)),delete this['localCache'][_0x3eaf02],this['notifyServiceWorker'](_0x3eaf02)));}async['_poll'](){const _0x1c8564=await this['_withRetries'](_0x445261=>{const _0xe47c38=Zn(_0x445261,!0x1)['getAll']();return new nn(_0xe47c38)['toPromise']();});if(!_0x1c8564)return[];if(this['pendingWrites']!==0x0)return[];const _0x143fb7=[],_0x2280c7=new Set();if(_0x1c8564['length']!==0x0){for(const {fbase_key:_0x2dcf88,value:_0x553737}of _0x1c8564)_0x2280c7['add'](_0x2dcf88),JSON['stringify'](this['localCache'][_0x2dcf88])!==JSON['stringify'](_0x553737)&&(this['notifyListeners'](_0x2dcf88,_0x553737),_0x143fb7['push'](_0x2dcf88));}for(const _0x534346 of Object['keys'](this['localCache']))this['localCache'][_0x534346]&&!_0x2280c7['has'](_0x534346)&&(this['notifyListeners'](_0x534346,null),_0x143fb7['push'](_0x534346));return _0x143fb7;}['notifyListeners'](_0xbea714,_0x431210){this['localCache'][_0xbea714]=_0x431210;const _0x170652=this['listeners'][_0xbea714];if(_0x170652){for(const _0x5623b8 of Array['from'](_0x170652))_0x5623b8(_0x431210);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x215328,_0x4e7fe1){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x215328]||(this['listeners'][_0x215328]=new Set(),this['_get'](_0x215328)),this['listeners'][_0x215328]['add'](_0x4e7fe1);}['_removeListener'](_0x49ad2f,_0x13425b){this['listeners'][_0x49ad2f]&&(this['listeners'][_0x49ad2f]['delete'](_0x13425b),this['listeners'][_0x49ad2f]['size']===0x0&&delete this['listeners'][_0x49ad2f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0x4e6dec,_0x1a1308){return _0x1a1308?ie(_0x1a1308):(m(_0x4e6dec['_popupRedirectResolver'],_0x4e6dec,'argument-error'),_0x4e6dec['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x366a64){super('custom','custom'),this['params']=_0x366a64;}['_getIdTokenResponse'](_0x5a22d8){return nt(_0x5a22d8,this['_buildIdpRequest']());}['_linkToIdToken'](_0x419a7c,_0x3af8d5){return nt(_0x419a7c,this['_buildIdpRequest'](_0x3af8d5));}['_getReauthenticationResolver'](_0x22abbe){return nt(_0x22abbe,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x19a7c3){const _0x123f8e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x19a7c3&&(_0x123f8e['idToken']=_0x19a7c3),_0x123f8e;}}function vp(_0x161d39){return Va(_0x161d39['auth'],new ks(_0x161d39),_0x161d39['bypassAuthState']);}function Ep(_0x4e758b){const {auth:_0x35ed5c,user:_0x3b31ef}=_0x4e758b;return m(_0x3b31ef,_0x35ed5c,'internal-error'),Zf(_0x3b31ef,new ks(_0x4e758b),_0x4e758b['bypassAuthState']);}async function Ip(_0x88c2e5){const {auth:_0xe5050,user:_0x3550b7}=_0x88c2e5;return m(_0x3550b7,_0xe5050,'internal-error'),Xf(_0x3550b7,new ks(_0x88c2e5),_0x88c2e5['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x4e26fc,_0x3eeed5,_0x256ba0,_0x3d9658,_0x6d8270=!0x1){this['auth']=_0x4e26fc,this['resolver']=_0x256ba0,this['user']=_0x3d9658,this['bypassAuthState']=_0x6d8270,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3eeed5)?_0x3eeed5:[_0x3eeed5];}['execute'](){return new Promise(async(_0x2d4cd6,_0x2da104)=>{this['pendingPromise']={'resolve':_0x2d4cd6,'reject':_0x2da104};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x128f60){this['reject'](_0x128f60);}});}async['onAuthEvent'](_0x43951f){const {urlResponse:_0x3d7a38,sessionId:_0x5ab19e,postBody:_0x456721,tenantId:_0x3d21ca,error:_0xa8d02c,type:_0x5d05b8}=_0x43951f;if(_0xa8d02c){this['reject'](_0xa8d02c);return;}const _0x18e6a3={'auth':this['auth'],'requestUri':_0x3d7a38,'sessionId':_0x5ab19e,'tenantId':_0x3d21ca||void 0x0,'postBody':_0x456721||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5d05b8)(_0x18e6a3));}catch(_0x4d2ade){this['reject'](_0x4d2ade);}}['onError'](_0x309d9e){this['reject'](_0x309d9e);}['getIdpTask'](_0x1c171b){switch(_0x1c171b){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0x2906f1){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2906f1),this['unregisterAndCleanUp']();}['reject'](_0x31ac89){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x31ac89),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x2a973e,_0x208117,_0x2111da,_0x1ecebc,_0x47140d){super(_0x2a973e,_0x208117,_0x1ecebc,_0x47140d),this['provider']=_0x2111da,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x291955=await this['execute']();return m(_0x291955,this['auth'],'internal-error'),_0x291955;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xeb0c27=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xeb0c27),this['authWindow']['associatedEvent']=_0xeb0c27,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3e76ca=>{this['reject'](_0x3e76ca);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x16cc33=>{_0x16cc33||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x121c5f;return((_0x121c5f=this['authWindow'])==null?void 0x0:_0x121c5f['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x296b29=()=>{var _0x3e81e7,_0x1eac52;if((_0x1eac52=(_0x3e81e7=this['authWindow'])==null?void 0x0:_0x3e81e7['window'])!=null&&_0x1eac52['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x296b29,wp['get']());};_0x296b29();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x4780ad,_0x2523eb,_0x45f129=!0x1){super(_0x4780ad,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2523eb,void 0x0,_0x45f129),this['eventId']=null;}async['execute'](){let _0x453f20=hn['get'](this['auth']['_key']());if(!_0x453f20){try{const _0x36cff4=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0x453f20=()=>Promise['resolve'](_0x36cff4);}catch(_0x4912ec){_0x453f20=()=>Promise['reject'](_0x4912ec);}hn['set'](this['auth']['_key'](),_0x453f20);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x453f20();}async['onAuthEvent'](_0x55a895){if(_0x55a895['type']==='signInViaRedirect')return super['onAuthEvent'](_0x55a895);if(_0x55a895['type']==='unknown'){this['resolve'](null);return;}if(_0x55a895['eventId']){const _0x1139a4=await this['auth']['_redirectUserForId'](_0x55a895['eventId']);if(_0x1139a4)return this['user']=_0x1139a4,super['onAuthEvent'](_0x55a895);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0xfce699,_0x480b69){const _0x2f0fd3=Ap(_0x480b69),_0x2850aa=Rp(_0xfce699);if(!await _0x2850aa['_isAvailable']())return!0x1;const _0x4294dd=await _0x2850aa['_get'](_0x2f0fd3)==='true';return await _0x2850aa['_remove'](_0x2f0fd3),_0x4294dd;}function bp(_0x1732b1,_0x6db397){hn['set'](_0x1732b1['_key'](),_0x6db397);}function Rp(_0x36fb49){return ie(_0x36fb49['_redirectPersistence']);}function Ap(_0x4d739a){return ln(Cp,_0x4d739a['config']['apiKey'],_0x4d739a['name']);}async function kp(_0x49bd12,_0x2db787,_0x58229b=!0x1){if($(_0x49bd12['app']))return Promise['reject'](re(_0x49bd12));const _0x4c39cb=Ke(_0x49bd12),_0xc241bf=yp(_0x4c39cb,_0x2db787),_0x444587=await new Tp(_0x4c39cb,_0xc241bf,_0x58229b)['execute']();return _0x444587&&!_0x58229b&&(delete _0x444587['user']['_redirectEventId'],await _0x4c39cb['_persistUserIfCurrent'](_0x444587['user']),await _0x4c39cb['_setRedirectUser'](null,_0x2db787)),_0x444587;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x2ca012){this['auth']=_0x2ca012,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1e1c92){this['consumers']['add'](_0x1e1c92),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1e1c92)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1e1c92),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x518bb6){this['consumers']['delete'](_0x518bb6);}['onEvent'](_0x52a3e0){if(this['hasEventBeenHandled'](_0x52a3e0))return!0x1;let _0x50b52f=!0x1;return this['consumers']['forEach'](_0x52bf46=>{this['isEventForConsumer'](_0x52a3e0,_0x52bf46)&&(_0x50b52f=!0x0,this['sendToConsumer'](_0x52a3e0,_0x52bf46),this['saveEventToCache'](_0x52a3e0));}),this['hasHandledPotentialRedirect']||!Op(_0x52a3e0)||(this['hasHandledPotentialRedirect']=!0x0,_0x50b52f||(this['queuedRedirectEvent']=_0x52a3e0,_0x50b52f=!0x0)),_0x50b52f;}['sendToConsumer'](_0x2afdad,_0x58ee49){var _0x56860b;if(_0x2afdad['error']&&!Za(_0x2afdad)){const _0x3fbfbc=((_0x56860b=_0x2afdad['error']['code'])==null?void 0x0:_0x56860b['split']('auth/')[0x1])||'internal-error';_0x58ee49['onError'](X(this['auth'],_0x3fbfbc));}else _0x58ee49['onAuthEvent'](_0x2afdad);}['isEventForConsumer'](_0x4a0289,_0x28f151){const _0x4fc3c6=_0x28f151['eventId']===null||!!_0x4a0289['eventId']&&_0x4a0289['eventId']===_0x28f151['eventId'];return _0x28f151['filter']['includes'](_0x4a0289['type'])&&_0x4fc3c6;}['hasEventBeenHandled'](_0x49f014){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x49f014));}['saveEventToCache'](_0xbdc543){this['cachedEventUids']['add'](Mr(_0xbdc543)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2e595b){return[_0x2e595b['type'],_0x2e595b['eventId'],_0x2e595b['sessionId'],_0x2e595b['tenantId']]['filter'](_0x4b62f9=>_0x4b62f9)['join']('-');}function Za({type:_0x3e67fc,error:_0x4d8eb9}){return _0x3e67fc==='unknown'&&(_0x4d8eb9==null?void 0x0:_0x4d8eb9['code'])==='auth/no-auth-event';}function Op(_0x2b2b7a){switch(_0x2b2b7a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x2b2b7a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x5b2a20,_0x127d7c={}){return ke(_0x5b2a20,'GET','/v1/projects',_0x127d7c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x2d0c3c){if(_0x2d0c3c['config']['emulator'])return;const {authorizedDomains:_0xfc7a0f}=await Dp(_0x2d0c3c);for(const _0x3dae3f of _0xfc7a0f)try{if(Fp(_0x3dae3f))return;}catch{}Y(_0x2d0c3c,'unauthorized-domain');}function Fp(_0x384c0a){const _0x514ccd=Mi(),{protocol:_0x212ef4,hostname:_0x375bfe}=new URL(_0x514ccd);if(_0x384c0a['startsWith']('chrome-extension://')){const _0x39ccd9=new URL(_0x384c0a);return _0x39ccd9['hostname']===''&&_0x375bfe===''?_0x212ef4==='chrome-extension:'&&_0x384c0a['replace']('chrome-extension://','')===_0x514ccd['replace']('chrome-extension://',''):_0x212ef4==='chrome-extension:'&&_0x39ccd9['hostname']===_0x375bfe;}if(!Lp['test'](_0x212ef4))return!0x1;if(Mp['test'](_0x384c0a))return _0x375bfe===_0x384c0a;const _0x288a1c=_0x384c0a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x288a1c+'|'+_0x288a1c+')$','i')['test'](_0x375bfe);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0x29e7a2=Z()['___jsl'];if(_0x29e7a2!=null&&_0x29e7a2['H']){for(const _0x4ca333 of Object['keys'](_0x29e7a2['H']))if(_0x29e7a2['H'][_0x4ca333]['r']=_0x29e7a2['H'][_0x4ca333]['r']||[],_0x29e7a2['H'][_0x4ca333]['L']=_0x29e7a2['H'][_0x4ca333]['L']||[],_0x29e7a2['H'][_0x4ca333]['r']=[..._0x29e7a2['H'][_0x4ca333]['L']],_0x29e7a2['CP']){for(let _0x4e744f=0x0;_0x4e744f<_0x29e7a2['CP']['length'];_0x4e744f++)_0x29e7a2['CP'][_0x4e744f]=null;}}}function Wp(_0x13ff1f){return new Promise((_0x4734a3,_0x4d59fc)=>{var _0x5b06cb,_0x41e492,_0x4a941d;function _0x7393(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4734a3(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4d59fc(X(_0x13ff1f,'network-request-failed'));},'timeout':Up['get']()});}if((_0x41e492=(_0x5b06cb=Z()['gapi'])==null?void 0x0:_0x5b06cb['iframes'])!=null&&_0x41e492['Iframe'])_0x4734a3(gapi['iframes']['getContext']());else{if((_0x4a941d=Z()['gapi'])!=null&&_0x4a941d['load'])_0x7393();else{const _0x54a374=Lf('iframefcb');return Z()[_0x54a374]=()=>{gapi['load']?_0x7393():_0x4d59fc(X(_0x13ff1f,'network-request-failed'));},xa(Mf()+'?onload='+_0x54a374)['catch'](_0x297660=>_0x4d59fc(_0x297660));}}})['catch'](_0x3653c2=>{throw un=null,_0x3653c2;});}let un=null;function Bp(_0x96537a){return un=un||Wp(_0x96537a),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0x13bd9c){const _0x470998=_0x13bd9c['config'];m(_0x470998['authDomain'],_0x13bd9c,'auth-domain-config-required');const _0x376160=_0x470998['emulator']?Cs(_0x470998,$p):'https://'+_0x13bd9c['config']['authDomain']+'/'+Hp,_0x6cdb7={'apiKey':_0x470998['apiKey'],'appName':_0x13bd9c['name'],'v':dt},_0x3ef36d=qp['get'](_0x13bd9c['config']['apiHost']);_0x3ef36d&&(_0x6cdb7['eid']=_0x3ef36d);const _0x1cccf0=_0x13bd9c['_getFrameworks']();return _0x1cccf0['length']&&(_0x6cdb7['fw']=_0x1cccf0['join'](',')),_0x376160+'?'+ut(_0x6cdb7)['slice'](0x1);}async function jp(_0x1b73dc){const _0x8c80f5=await Bp(_0x1b73dc),_0x4cc206=Z()['gapi'];return m(_0x4cc206,_0x1b73dc,'internal-error'),_0x8c80f5['open']({'where':document['body'],'url':zp(_0x1b73dc),'messageHandlersFilter':_0x4cc206['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0xfcc7cb=>new Promise(async(_0x2a143,_0x19e534)=>{await _0xfcc7cb['restyle']({'setHideOnLeave':!0x1});const _0x38d12a=X(_0x1b73dc,'network-request-failed'),_0x54a9a0=Z()['setTimeout'](()=>{_0x19e534(_0x38d12a);},Vp['get']());function _0x44ff76(){Z()['clearTimeout'](_0x54a9a0),_0x2a143(_0xfcc7cb);}_0xfcc7cb['ping'](_0x44ff76)['then'](_0x44ff76,()=>{_0x19e534(_0x38d12a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x3d41a6){this['window']=_0x3d41a6,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x84a2c5,_0x354585,_0x2f582b,_0x3079f0=Yp,_0x1c12e1=Qp){const _0x27e0bf=Math['max']((window['screen']['availHeight']-_0x1c12e1)/0x2,0x0)['toString'](),_0x2519c9=Math['max']((window['screen']['availWidth']-_0x3079f0)/0x2,0x0)['toString']();let _0x2d61da='';const _0x1328e5={...Kp,'width':_0x3079f0['toString'](),'height':_0x1c12e1['toString'](),'top':_0x27e0bf,'left':_0x2519c9},_0x5927ff=W()['toLowerCase']();_0x2f582b&&(_0x2d61da=ka(_0x5927ff)?Jp:_0x2f582b),Ra(_0x5927ff)&&(_0x354585=_0x354585||Xp,_0x1328e5['scrollbars']='yes');const _0x79e2c7=Object['entries'](_0x1328e5)['reduce']((_0xc43960,[_0x2fd2e3,_0x1c64cb])=>''+_0xc43960+_0x2fd2e3+'='+_0x1c64cb+',','');if(Sf(_0x5927ff)&&_0x2d61da!=='_self')return e_(_0x354585||'',_0x2d61da),new xr(null);const _0x49d773=window['open'](_0x354585||'',_0x2d61da,_0x79e2c7);m(_0x49d773,_0x84a2c5,'popup-blocked');try{_0x49d773['focus']();}catch{}return new xr(_0x49d773);}function e_(_0x4b9bea,_0x537329){const _0xcf7ba8=document['createElement']('a');_0xcf7ba8['href']=_0x4b9bea,_0xcf7ba8['target']=_0x537329;const _0xe96b44=document['createEvent']('MouseEvent');_0xe96b44['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xcf7ba8['dispatchEvent'](_0xe96b44);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0xa36f8e,_0x5dd385,_0x35a787,_0x6a6526,_0x2bf43b,_0x1c703d){m(_0xa36f8e['config']['authDomain'],_0xa36f8e,'auth-domain-config-required'),m(_0xa36f8e['config']['apiKey'],_0xa36f8e,'invalid-api-key');const _0x1f7608={'apiKey':_0xa36f8e['config']['apiKey'],'appName':_0xa36f8e['name'],'authType':_0x35a787,'redirectUrl':_0x6a6526,'v':dt,'eventId':_0x2bf43b};if(_0x5dd385 instanceof Wa){_0x5dd385['setDefaultLanguage'](_0xa36f8e['languageCode']),_0x1f7608['providerId']=_0x5dd385['providerId']||'',pn(_0x5dd385['getCustomParameters']())||(_0x1f7608['customParameters']=JSON['stringify'](_0x5dd385['getCustomParameters']()));for(const [_0x3cb793,_0x3cf5ca]of Object['entries']({}))_0x1f7608[_0x3cb793]=_0x3cf5ca;}if(_0x5dd385 instanceof tn){const _0x4766bf=_0x5dd385['getScopes']()['filter'](_0x3088be=>_0x3088be!=='');_0x4766bf['length']>0x0&&(_0x1f7608['scopes']=_0x4766bf['join'](','));}_0xa36f8e['tenantId']&&(_0x1f7608['tid']=_0xa36f8e['tenantId']);const _0x3e7661=_0x1f7608;for(const _0x5c9684 of Object['keys'](_0x3e7661))_0x3e7661[_0x5c9684]===void 0x0&&delete _0x3e7661[_0x5c9684];const _0x387080=await _0xa36f8e['_getAppCheckToken'](),_0x4bf882=_0x387080?'#'+i_+'='+encodeURIComponent(_0x387080):'';return s_(_0xa36f8e)+'?'+ut(_0x3e7661)['slice'](0x1)+_0x4bf882;}function s_({config:_0x1b6729}){return _0x1b6729['emulator']?Cs(_0x1b6729,n_):'https://'+_0x1b6729['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x5a89b8,_0x4e60bd,_0x5cedb6,_0x4250b3){var _0x172aa8;ce((_0x172aa8=this['eventManagers'][_0x5a89b8['_key']()])==null?void 0x0:_0x172aa8['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x24a50d=await Fr(_0x5a89b8,_0x4e60bd,_0x5cedb6,Mi(),_0x4250b3);return Zp(_0x5a89b8,_0x24a50d,As());}async['_openRedirect'](_0x22127c,_0x15740f,_0x310590,_0x21f043){await this['_originValidation'](_0x22127c);const _0xa0a5e0=await Fr(_0x22127c,_0x15740f,_0x310590,Mi(),_0x21f043);return cp(_0xa0a5e0),new Promise(()=>{});}['_initialize'](_0x5462dd){const _0x29436b=_0x5462dd['_key']();if(this['eventManagers'][_0x29436b]){const {manager:_0x3f614d,promise:_0x3e062f}=this['eventManagers'][_0x29436b];return _0x3f614d?Promise['resolve'](_0x3f614d):(ce(_0x3e062f,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3e062f);}const _0x531bee=this['initAndGetManager'](_0x5462dd);return this['eventManagers'][_0x29436b]={'promise':_0x531bee},_0x531bee['catch'](()=>{delete this['eventManagers'][_0x29436b];}),_0x531bee;}async['initAndGetManager'](_0x276062){const _0x34f843=await jp(_0x276062),_0x2ce46b=new Pp(_0x276062);return _0x34f843['register']('authEvent',_0x4970be=>(m(_0x4970be==null?void 0x0:_0x4970be['authEvent'],_0x276062,'invalid-auth-event'),{'status':_0x2ce46b['onEvent'](_0x4970be['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x276062['_key']()]={'manager':_0x2ce46b},this['iframes'][_0x276062['_key']()]=_0x34f843,_0x2ce46b;}['_isIframeWebStorageSupported'](_0xfe7307,_0xf4b716){this['iframes'][_0xfe7307['_key']()]['send'](pi,{'type':pi},_0x5028a3=>{var _0x3a6591;const _0x12e57d=(_0x3a6591=_0x5028a3==null?void 0x0:_0x5028a3[0x0])==null?void 0x0:_0x3a6591[pi];_0x12e57d!==void 0x0&&_0xf4b716(!!_0x12e57d),Y(_0xfe7307,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3e4b17){const _0x57ea6d=_0x3e4b17['_key']();return this['originValidationPromises'][_0x57ea6d]||(this['originValidationPromises'][_0x57ea6d]=xp(_0x3e4b17)),this['originValidationPromises'][_0x57ea6d];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0x53e7eb){this['auth']=_0x53e7eb,this['internalListeners']=new Map();}['getUid'](){var _0x5447f5;return this['assertAuthConfigured'](),((_0x5447f5=this['auth']['currentUser'])==null?void 0x0:_0x5447f5['uid'])||null;}async['getToken'](_0x2e719a){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2e719a)}:null;}['addAuthTokenListener'](_0x27a423){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x27a423))return;const _0x48d6db=this['auth']['onIdTokenChanged'](_0x26d84c=>{_0x27a423((_0x26d84c==null?void 0x0:_0x26d84c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x27a423,_0x48d6db),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x473113){this['assertAuthConfigured']();const _0x17972b=this['internalListeners']['get'](_0x473113);_0x17972b&&(this['internalListeners']['delete'](_0x473113),_0x17972b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x5d39b3){switch(_0x5d39b3){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x2dbed4){st(new xe('auth',(_0x1f4d03,{options:_0x2b1e5e})=>{const _0x2b24df=_0x1f4d03['getProvider']('app')['getImmediate'](),_0x59aab8=_0x1f4d03['getProvider']('heartbeat'),_0x17ac55=_0x1f4d03['getProvider']('app-check-internal'),{apiKey:_0x3d5b8b,authDomain:_0x5ce9c1}=_0x2b24df['options'];m(_0x3d5b8b&&!_0x3d5b8b['includes'](':'),'invalid-api-key',{'appName':_0x2b24df['name']});const _0x5b14b0={'apiKey':_0x3d5b8b,'authDomain':_0x5ce9c1,'clientPlatform':_0x2dbed4,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2dbed4)},_0x9a6be=new Pf(_0x2b24df,_0x59aab8,_0x17ac55,_0x5b14b0);return Bf(_0x9a6be,_0x2b1e5e),_0x9a6be;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x431dc6,_0xef2ff6,_0x3f09da)=>{_0x431dc6['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x2fa739=>{const _0x37a846=Ke(_0x2fa739['getProvider']('auth')['getImmediate']());return(_0x3226c0=>new a_(_0x3226c0))(_0x37a846);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x2dbed4)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x433910=>async _0x430296=>{const _0x3bd715=_0x430296&&await _0x430296['getIdTokenResult'](),_0x1b482c=_0x3bd715&&(new Date()['getTime']()-Date['parse'](_0x3bd715['issuedAtTime']))/0x3e8;if(_0x1b482c&&_0x1b482c>u_)return;const _0x3124b7=_0x3bd715==null?void 0x0:_0x3bd715['token'];Br!==_0x3124b7&&(Br=_0x3124b7,await fetch(_0x433910,{'method':_0x3124b7?'POST':'DELETE','headers':_0x3124b7?{'Authorization':'Bearer\x20'+_0x3124b7}:{}}));};function F_(_0xb28056=Zr()){const _0x2f4e26=Hi(_0xb28056,'auth');if(_0x2f4e26['isInitialized']())return _0x2f4e26['getImmediate']();const _0x209503=Wf(_0xb28056,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0x1d9ff4=jr('authTokenSyncURL');if(_0x1d9ff4&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4ee21a=new URL(_0x1d9ff4,location['origin']);if(location['origin']===_0x4ee21a['origin']){const _0x24f361=d_(_0x4ee21a['toString']());np(_0x209503,_0x24f361,()=>_0x24f361(_0x209503['currentUser'])),tp(_0x209503,_0x5d9e7f=>_0x24f361(_0x5d9e7f));}}const _0x183024=qr('auth');return _0x183024&&Vf(_0x209503,'http://'+_0x183024),_0x209503;}function f_(){var _0x558f77;return((_0x558f77=document['getElementsByTagName']('head'))==null?void 0x0:_0x558f77[0x0])??document;}Of({'loadJS'(_0x38e4f1){return new Promise((_0x3d2f79,_0x33261b)=>{const _0x1ba1b5=document['createElement']('script');_0x1ba1b5['setAttribute']('src',_0x38e4f1),_0x1ba1b5['onload']=_0x3d2f79,_0x1ba1b5['onerror']=_0x2d8f66=>{const _0x1be930=X('internal-error');_0x1be930['customData']=_0x2d8f66,_0x33261b(_0x1be930);},_0x1ba1b5['type']='text/javascript',_0x1ba1b5['charset']='UTF-8',f_()['appendChild'](_0x1ba1b5);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{x_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,__ as h,Sl as i,Vd as j,N_ as k,$d as l,A_ as m,L_ as n,m_ as o,k_ as p,b_ as q,g_ as r,M_ as s,C_ as t,v_ as u,S_ as v,Bt as w,y_ as x,P_ as y,O_ as z};