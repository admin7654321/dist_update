const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3f3bce,_0x4468e9){if(!_0x3f3bce)throw ht(_0x4468e9);},ht=function(_0x569839){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x569839);},Hr=function(_0x104cf7){const _0x22e8d8=[];let _0x53d5a5=0x0;for(let _0x47fb6b=0x0;_0x47fb6b<_0x104cf7['length'];_0x47fb6b++){let _0x1e7a73=_0x104cf7['charCodeAt'](_0x47fb6b);_0x1e7a73<0x80?_0x22e8d8[_0x53d5a5++]=_0x1e7a73:_0x1e7a73<0x800?(_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0x6|0xc0,_0x22e8d8[_0x53d5a5++]=_0x1e7a73&0x3f|0x80):(_0x1e7a73&0xfc00)===0xd800&&_0x47fb6b+0x1<_0x104cf7['length']&&(_0x104cf7['charCodeAt'](_0x47fb6b+0x1)&0xfc00)===0xdc00?(_0x1e7a73=0x10000+((_0x1e7a73&0x3ff)<<0xa)+(_0x104cf7['charCodeAt'](++_0x47fb6b)&0x3ff),_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0x12|0xf0,_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0xc&0x3f|0x80,_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0x6&0x3f|0x80,_0x22e8d8[_0x53d5a5++]=_0x1e7a73&0x3f|0x80):(_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0xc|0xe0,_0x22e8d8[_0x53d5a5++]=_0x1e7a73>>0x6&0x3f|0x80,_0x22e8d8[_0x53d5a5++]=_0x1e7a73&0x3f|0x80);}return _0x22e8d8;},nc=function(_0x178cc8){const _0x286807=[];let _0x4687e2=0x0,_0x15503c=0x0;for(;_0x4687e2<_0x178cc8['length'];){const _0x14105b=_0x178cc8[_0x4687e2++];if(_0x14105b<0x80)_0x286807[_0x15503c++]=String['fromCharCode'](_0x14105b);else{if(_0x14105b>0xbf&&_0x14105b<0xe0){const _0x13f86b=_0x178cc8[_0x4687e2++];_0x286807[_0x15503c++]=String['fromCharCode']((_0x14105b&0x1f)<<0x6|_0x13f86b&0x3f);}else{if(_0x14105b>0xef&&_0x14105b<0x16d){const _0x51f761=_0x178cc8[_0x4687e2++],_0x100a89=_0x178cc8[_0x4687e2++],_0x194c5d=_0x178cc8[_0x4687e2++],_0x1d742e=((_0x14105b&0x7)<<0x12|(_0x51f761&0x3f)<<0xc|(_0x100a89&0x3f)<<0x6|_0x194c5d&0x3f)-0x10000;_0x286807[_0x15503c++]=String['fromCharCode'](0xd800+(_0x1d742e>>0xa)),_0x286807[_0x15503c++]=String['fromCharCode'](0xdc00+(_0x1d742e&0x3ff));}else{const _0x261252=_0x178cc8[_0x4687e2++],_0x1ad229=_0x178cc8[_0x4687e2++];_0x286807[_0x15503c++]=String['fromCharCode']((_0x14105b&0xf)<<0xc|(_0x261252&0x3f)<<0x6|_0x1ad229&0x3f);}}}}return _0x286807['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x431147,_0x2935be){if(!Array['isArray'](_0x431147))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xf4962c=_0x2935be?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x550360=[];for(let _0x1e807d=0x0;_0x1e807d<_0x431147['length'];_0x1e807d+=0x3){const _0x375b96=_0x431147[_0x1e807d],_0x56c9f5=_0x1e807d+0x1<_0x431147['length'],_0xdf8e32=_0x56c9f5?_0x431147[_0x1e807d+0x1]:0x0,_0x5251b8=_0x1e807d+0x2<_0x431147['length'],_0x100751=_0x5251b8?_0x431147[_0x1e807d+0x2]:0x0,_0x132140=_0x375b96>>0x2,_0x351f7b=(_0x375b96&0x3)<<0x4|_0xdf8e32>>0x4;let _0x4aaaaa=(_0xdf8e32&0xf)<<0x2|_0x100751>>0x6,_0x117614=_0x100751&0x3f;_0x5251b8||(_0x117614=0x40,_0x56c9f5||(_0x4aaaaa=0x40)),_0x550360['push'](_0xf4962c[_0x132140],_0xf4962c[_0x351f7b],_0xf4962c[_0x4aaaaa],_0xf4962c[_0x117614]);}return _0x550360['join']('');},'encodeString'(_0x29d340,_0x175e56){return this['HAS_NATIVE_SUPPORT']&&!_0x175e56?btoa(_0x29d340):this['encodeByteArray'](Hr(_0x29d340),_0x175e56);},'decodeString'(_0x1c79e0,_0x44da2d){return this['HAS_NATIVE_SUPPORT']&&!_0x44da2d?atob(_0x1c79e0):nc(this['decodeStringToByteArray'](_0x1c79e0,_0x44da2d));},'decodeStringToByteArray'(_0x161658,_0x4c19d7){this['init_']();const _0x34d84b=_0x4c19d7?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x381f38=[];for(let _0x68b04a=0x0;_0x68b04a<_0x161658['length'];){const _0x19e642=_0x34d84b[_0x161658['charAt'](_0x68b04a++)],_0x48cb58=_0x68b04a<_0x161658['length']?_0x34d84b[_0x161658['charAt'](_0x68b04a)]:0x0;++_0x68b04a;const _0x4433fa=_0x68b04a<_0x161658['length']?_0x34d84b[_0x161658['charAt'](_0x68b04a)]:0x40;++_0x68b04a;const _0x5f50a3=_0x68b04a<_0x161658['length']?_0x34d84b[_0x161658['charAt'](_0x68b04a)]:0x40;if(++_0x68b04a,_0x19e642==null||_0x48cb58==null||_0x4433fa==null||_0x5f50a3==null)throw new ic();const _0x1c8308=_0x19e642<<0x2|_0x48cb58>>0x4;if(_0x381f38['push'](_0x1c8308),_0x4433fa!==0x40){const _0x2e806a=_0x48cb58<<0x4&0xf0|_0x4433fa>>0x2;if(_0x381f38['push'](_0x2e806a),_0x5f50a3!==0x40){const _0x20cb5d=_0x4433fa<<0x6&0xc0|_0x5f50a3;_0x381f38['push'](_0x20cb5d);}}}return _0x381f38;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x33e5c8=0x0;_0x33e5c8<this['ENCODED_VALS']['length'];_0x33e5c8++)this['byteToCharMap_'][_0x33e5c8]=this['ENCODED_VALS']['charAt'](_0x33e5c8),this['charToByteMap_'][this['byteToCharMap_'][_0x33e5c8]]=_0x33e5c8,this['byteToCharMapWebSafe_'][_0x33e5c8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x33e5c8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x33e5c8]]=_0x33e5c8,_0x33e5c8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x33e5c8)]=_0x33e5c8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x33e5c8)]=_0x33e5c8);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x598c70){const _0x1d8cac=Hr(_0x598c70);return Fi['encodeByteArray'](_0x1d8cac,!0x0);},dn=function(_0x10189f){return $r(_0x10189f)['replace'](/\./g,'');},fn=function(_0xec8f2){try{return Fi['decodeString'](_0xec8f2,!0x0);}catch(_0x3542ff){console['error']('base64Decode\x20failed:\x20',_0x3542ff);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x1ce6f5){return Gr(void 0x0,_0x1ce6f5);}function Gr(_0x559cb0,_0x55cbd4){if(!(_0x55cbd4 instanceof Object))return _0x55cbd4;switch(_0x55cbd4['constructor']){case Date:const _0x4d1dda=_0x55cbd4;return new Date(_0x4d1dda['getTime']());case Object:_0x559cb0===void 0x0&&(_0x559cb0={});break;case Array:_0x559cb0=[];break;default:return _0x55cbd4;}for(const _0x2adfff in _0x55cbd4)!_0x55cbd4['hasOwnProperty'](_0x2adfff)||!rc(_0x2adfff)||(_0x559cb0[_0x2adfff]=Gr(_0x559cb0[_0x2adfff],_0x55cbd4[_0x2adfff]));return _0x559cb0;}function rc(_0x5a1eec){return _0x5a1eec!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0xc663f9=Ns['__FIREBASE_DEFAULTS__'];if(_0xc663f9)return JSON['parse'](_0xc663f9);},lc=()=>{if(typeof document>'u')return;let _0x3fa933;try{_0x3fa933=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xc9c5b5=_0x3fa933&&fn(_0x3fa933[0x1]);return _0xc9c5b5&&JSON['parse'](_0xc9c5b5);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3af40a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3af40a);return;}},qr=_0x5a8efd=>{var _0x43246,_0x14b6bb;return(_0x14b6bb=(_0x43246=Ui())==null?void 0x0:_0x43246['emulatorHosts'])==null?void 0x0:_0x14b6bb[_0x5a8efd];},hc=_0x54b609=>{const _0x36ea44=qr(_0x54b609);if(!_0x36ea44)return;const _0x660c06=_0x36ea44['lastIndexOf'](':');if(_0x660c06<=0x0||_0x660c06+0x1===_0x36ea44['length'])throw new Error('Invalid\x20host\x20'+_0x36ea44+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1fa353=parseInt(_0x36ea44['substring'](_0x660c06+0x1),0xa);return _0x36ea44[0x0]==='['?[_0x36ea44['substring'](0x1,_0x660c06-0x1),_0x1fa353]:[_0x36ea44['substring'](0x0,_0x660c06),_0x1fa353];},zr=()=>{var _0x3f79f2;return(_0x3f79f2=Ui())==null?void 0x0:_0x3f79f2['config'];},jr=_0x23d206=>{var _0x3d0fb2;return(_0x3d0fb2=Ui())==null?void 0x0:_0x3d0fb2['_'+_0x23d206];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3a00a2,_0x4cad40)=>{this['resolve']=_0x3a00a2,this['reject']=_0x4cad40;});}['wrapCallback'](_0xbaa800){return(_0x2b3965,_0x534a6c)=>{_0x2b3965?this['reject'](_0x2b3965):this['resolve'](_0x534a6c),typeof _0xbaa800=='function'&&(this['promise']['catch'](()=>{}),_0xbaa800['length']===0x1?_0xbaa800(_0x2b3965):_0xbaa800(_0x2b3965,_0x534a6c));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x526c34,_0x33394c){if(_0x526c34['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3e45e5={'alg':'none','type':'JWT'},_0x32b894=_0x33394c||'demo-project',_0x1a12a9=_0x526c34['iat']||0x0,_0x1124eb=_0x526c34['sub']||_0x526c34['user_id'];if(!_0x1124eb)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3835e1={'iss':'https://securetoken.google.com/'+_0x32b894,'aud':_0x32b894,'iat':_0x1a12a9,'exp':_0x1a12a9+0xe10,'auth_time':_0x1a12a9,'sub':_0x1124eb,'user_id':_0x1124eb,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x526c34};return[dn(JSON['stringify'](_0x3e45e5)),dn(JSON['stringify'](_0x3835e1)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x37e47b=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x37e47b=='object'&&_0x37e47b['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2bd1b1=W();return _0x2bd1b1['indexOf']('MSIE\x20')>=0x0||_0x2bd1b1['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x232ba6,_0x4cf3b7)=>{try{let _0x188282=!0x0;const _0x3288cf='validate-browser-context-for-indexeddb-analytics-module',_0x45ad4b=self['indexedDB']['open'](_0x3288cf);_0x45ad4b['onsuccess']=()=>{_0x45ad4b['result']['close'](),_0x188282||self['indexedDB']['deleteDatabase'](_0x3288cf),_0x232ba6(!0x0);},_0x45ad4b['onupgradeneeded']=()=>{_0x188282=!0x1;},_0x45ad4b['onerror']=()=>{var _0x57cdfa;_0x4cf3b7(((_0x57cdfa=_0x45ad4b['error'])==null?void 0x0:_0x57cdfa['message'])||'');};}catch(_0xc93cd1){_0x4cf3b7(_0xc93cd1);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2ac300,_0x5c377e,_0x2e6b62){super(_0x5c377e),this['code']=_0x2ac300,this['customData']=_0x2e6b62,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x4538ae,_0x1a08d6,_0x157e01){this['service']=_0x4538ae,this['serviceName']=_0x1a08d6,this['errors']=_0x157e01;}['create'](_0x28862c,..._0x50d133){const _0x48d92e=_0x50d133[0x0]||{},_0x1b4bff=this['service']+'/'+_0x28862c,_0x5da841=this['errors'][_0x28862c],_0x4059e5=_0x5da841?vc(_0x5da841,_0x48d92e):'Error',_0x473e07=this['serviceName']+':\x20'+_0x4059e5+'\x20('+_0x1b4bff+').';return new Re(_0x1b4bff,_0x473e07,_0x48d92e);}}function vc(_0x3c2f7c,_0x28cf4f){return _0x3c2f7c['replace'](Ec,(_0x4ac575,_0x2fe447)=>{const _0x39f684=_0x28cf4f[_0x2fe447];return _0x39f684!=null?String(_0x39f684):'<'+_0x2fe447+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x21be72){return JSON['parse'](_0x21be72);}function O(_0x564846){return JSON['stringify'](_0x564846);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x55aab1){let _0xbcf241={},_0x31da4d={},_0x5bac0a={},_0x3e76cd='';try{const _0x5142c7=_0x55aab1['split']('.');_0xbcf241=Nt(fn(_0x5142c7[0x0])||''),_0x31da4d=Nt(fn(_0x5142c7[0x1])||''),_0x3e76cd=_0x5142c7[0x2],_0x5bac0a=_0x31da4d['d']||{},delete _0x31da4d['d'];}catch{}return{'header':_0xbcf241,'claims':_0x31da4d,'data':_0x5bac0a,'signature':_0x3e76cd};},Ic=function(_0x1b7c64){const _0x6c0a8d=Yr(_0x1b7c64),_0x3823a8=_0x6c0a8d['claims'];return!!_0x3823a8&&typeof _0x3823a8=='object'&&_0x3823a8['hasOwnProperty']('iat');},wc=function(_0x59681f){const _0x59254f=Yr(_0x59681f)['claims'];return typeof _0x59254f=='object'&&_0x59254f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4deedd,_0x4b6854){return Object['prototype']['hasOwnProperty']['call'](_0x4deedd,_0x4b6854);}function Me(_0x1ec865,_0x168867){if(Object['prototype']['hasOwnProperty']['call'](_0x1ec865,_0x168867))return _0x1ec865[_0x168867];}function pn(_0x27dffe){for(const _0x335000 in _0x27dffe)if(Object['prototype']['hasOwnProperty']['call'](_0x27dffe,_0x335000))return!0x1;return!0x0;}function _n(_0x535cf8,_0x34dbad,_0x570a0c){const _0x1667bd={};for(const _0x188771 in _0x535cf8)Object['prototype']['hasOwnProperty']['call'](_0x535cf8,_0x188771)&&(_0x1667bd[_0x188771]=_0x34dbad['call'](_0x570a0c,_0x535cf8[_0x188771],_0x188771,_0x535cf8));return _0x1667bd;}function Le(_0x5ce672,_0x1695e8){if(_0x5ce672===_0x1695e8)return!0x0;const _0x2fd443=Object['keys'](_0x5ce672),_0x4dbcd2=Object['keys'](_0x1695e8);for(const _0x31f0f8 of _0x2fd443){if(!_0x4dbcd2['includes'](_0x31f0f8))return!0x1;const _0x11130a=_0x5ce672[_0x31f0f8],_0x3bca66=_0x1695e8[_0x31f0f8];if(Ps(_0x11130a)&&Ps(_0x3bca66)){if(!Le(_0x11130a,_0x3bca66))return!0x1;}else{if(_0x11130a!==_0x3bca66)return!0x1;}}for(const _0x14b26e of _0x4dbcd2)if(!_0x2fd443['includes'](_0x14b26e))return!0x1;return!0x0;}function Ps(_0x298831){return _0x298831!==null&&typeof _0x298831=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x15aeb6){const _0x4d45e4=[];for(const [_0x3f5dcf,_0x3ffc4]of Object['entries'](_0x15aeb6))Array['isArray'](_0x3ffc4)?_0x3ffc4['forEach'](_0x1c078e=>{_0x4d45e4['push'](encodeURIComponent(_0x3f5dcf)+'='+encodeURIComponent(_0x1c078e));}):_0x4d45e4['push'](encodeURIComponent(_0x3f5dcf)+'='+encodeURIComponent(_0x3ffc4));return _0x4d45e4['length']?'&'+_0x4d45e4['join']('&'):'';}function wt(_0x210a73){const _0x5a3f55={};return _0x210a73['replace'](/^\?/,'')['split']('&')['forEach'](_0x16f7a8=>{if(_0x16f7a8){const [_0x16aa9b,_0x5b6a32]=_0x16f7a8['split']('=');_0x5a3f55[decodeURIComponent(_0x16aa9b)]=decodeURIComponent(_0x5b6a32);}}),_0x5a3f55;}function Ct(_0x57a3dd){const _0x5f4d20=_0x57a3dd['indexOf']('?');if(!_0x5f4d20)return'';const _0x4c0f1d=_0x57a3dd['indexOf']('#',_0x5f4d20);return _0x57a3dd['substring'](_0x5f4d20,_0x4c0f1d>0x0?_0x4c0f1d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x32bea=0x1;_0x32bea<this['blockSize'];++_0x32bea)this['pad_'][_0x32bea]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x451346,_0xbe548b){_0xbe548b||(_0xbe548b=0x0);const _0x2cc6da=this['W_'];if(typeof _0x451346=='string'){for(let _0x17ee49=0x0;_0x17ee49<0x10;_0x17ee49++)_0x2cc6da[_0x17ee49]=_0x451346['charCodeAt'](_0xbe548b)<<0x18|_0x451346['charCodeAt'](_0xbe548b+0x1)<<0x10|_0x451346['charCodeAt'](_0xbe548b+0x2)<<0x8|_0x451346['charCodeAt'](_0xbe548b+0x3),_0xbe548b+=0x4;}else{for(let _0xbed472=0x0;_0xbed472<0x10;_0xbed472++)_0x2cc6da[_0xbed472]=_0x451346[_0xbe548b]<<0x18|_0x451346[_0xbe548b+0x1]<<0x10|_0x451346[_0xbe548b+0x2]<<0x8|_0x451346[_0xbe548b+0x3],_0xbe548b+=0x4;}for(let _0x3c25aa=0x10;_0x3c25aa<0x50;_0x3c25aa++){const _0x25b8e1=_0x2cc6da[_0x3c25aa-0x3]^_0x2cc6da[_0x3c25aa-0x8]^_0x2cc6da[_0x3c25aa-0xe]^_0x2cc6da[_0x3c25aa-0x10];_0x2cc6da[_0x3c25aa]=(_0x25b8e1<<0x1|_0x25b8e1>>>0x1f)&0xffffffff;}let _0x5d0647=this['chain_'][0x0],_0x5ca9c6=this['chain_'][0x1],_0x309ac9=this['chain_'][0x2],_0x479c29=this['chain_'][0x3],_0x45a6ec=this['chain_'][0x4],_0x49d629,_0x4e4ce4;for(let _0xc847d5=0x0;_0xc847d5<0x50;_0xc847d5++){_0xc847d5<0x28?_0xc847d5<0x14?(_0x49d629=_0x479c29^_0x5ca9c6&(_0x309ac9^_0x479c29),_0x4e4ce4=0x5a827999):(_0x49d629=_0x5ca9c6^_0x309ac9^_0x479c29,_0x4e4ce4=0x6ed9eba1):_0xc847d5<0x3c?(_0x49d629=_0x5ca9c6&_0x309ac9|_0x479c29&(_0x5ca9c6|_0x309ac9),_0x4e4ce4=0x8f1bbcdc):(_0x49d629=_0x5ca9c6^_0x309ac9^_0x479c29,_0x4e4ce4=0xca62c1d6);const _0x396546=(_0x5d0647<<0x5|_0x5d0647>>>0x1b)+_0x49d629+_0x45a6ec+_0x4e4ce4+_0x2cc6da[_0xc847d5]&0xffffffff;_0x45a6ec=_0x479c29,_0x479c29=_0x309ac9,_0x309ac9=(_0x5ca9c6<<0x1e|_0x5ca9c6>>>0x2)&0xffffffff,_0x5ca9c6=_0x5d0647,_0x5d0647=_0x396546;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5d0647&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5ca9c6&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x309ac9&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x479c29&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x45a6ec&0xffffffff;}['update'](_0x22665d,_0x4c2b04){if(_0x22665d==null)return;_0x4c2b04===void 0x0&&(_0x4c2b04=_0x22665d['length']);const _0x1b0d36=_0x4c2b04-this['blockSize'];let _0x42c5bd=0x0;const _0x56d488=this['buf_'];let _0x18da61=this['inbuf_'];for(;_0x42c5bd<_0x4c2b04;){if(_0x18da61===0x0){for(;_0x42c5bd<=_0x1b0d36;)this['compress_'](_0x22665d,_0x42c5bd),_0x42c5bd+=this['blockSize'];}if(typeof _0x22665d=='string'){for(;_0x42c5bd<_0x4c2b04;)if(_0x56d488[_0x18da61]=_0x22665d['charCodeAt'](_0x42c5bd),++_0x18da61,++_0x42c5bd,_0x18da61===this['blockSize']){this['compress_'](_0x56d488),_0x18da61=0x0;break;}}else{for(;_0x42c5bd<_0x4c2b04;)if(_0x56d488[_0x18da61]=_0x22665d[_0x42c5bd],++_0x18da61,++_0x42c5bd,_0x18da61===this['blockSize']){this['compress_'](_0x56d488),_0x18da61=0x0;break;}}}this['inbuf_']=_0x18da61,this['total_']+=_0x4c2b04;}['digest'](){const _0x25647b=[];let _0x222a6e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x739102=this['blockSize']-0x1;_0x739102>=0x38;_0x739102--)this['buf_'][_0x739102]=_0x222a6e&0xff,_0x222a6e/=0x100;this['compress_'](this['buf_']);let _0x1b3742=0x0;for(let _0x29af1e=0x0;_0x29af1e<0x5;_0x29af1e++)for(let _0xf4bbc1=0x18;_0xf4bbc1>=0x0;_0xf4bbc1-=0x8)_0x25647b[_0x1b3742]=this['chain_'][_0x29af1e]>>_0xf4bbc1&0xff,++_0x1b3742;return _0x25647b;}}function Tc(_0x498409,_0x358239){const _0x4301cc=new Sc(_0x498409,_0x358239);return _0x4301cc['subscribe']['bind'](_0x4301cc);}class Sc{constructor(_0x54403a,_0x45f963){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x45f963,this['task']['then'](()=>{_0x54403a(this);})['catch'](_0x3d0ce3=>{this['error'](_0x3d0ce3);});}['next'](_0x10ce5d){this['forEachObserver'](_0x51f6bd=>{_0x51f6bd['next'](_0x10ce5d);});}['error'](_0xe7dc9d){this['forEachObserver'](_0x225836=>{_0x225836['error'](_0xe7dc9d);}),this['close'](_0xe7dc9d);}['complete'](){this['forEachObserver'](_0x5ee41b=>{_0x5ee41b['complete']();}),this['close']();}['subscribe'](_0x55ed1c,_0x26da6b,_0x3d340a){let _0x2562a2;if(_0x55ed1c===void 0x0&&_0x26da6b===void 0x0&&_0x3d340a===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x55ed1c,['next','error','complete'])?_0x2562a2=_0x55ed1c:_0x2562a2={'next':_0x55ed1c,'error':_0x26da6b,'complete':_0x3d340a},_0x2562a2['next']===void 0x0&&(_0x2562a2['next']=ti),_0x2562a2['error']===void 0x0&&(_0x2562a2['error']=ti),_0x2562a2['complete']===void 0x0&&(_0x2562a2['complete']=ti);const _0x3aa6e7=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2562a2['error'](this['finalError']):_0x2562a2['complete']();}catch{}}),this['observers']['push'](_0x2562a2),_0x3aa6e7;}['unsubscribeOne'](_0x1cff3a){this['observers']===void 0x0||this['observers'][_0x1cff3a]===void 0x0||(delete this['observers'][_0x1cff3a],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x13c2bf){if(!this['finalized']){for(let _0x4566fd=0x0;_0x4566fd<this['observers']['length'];_0x4566fd++)this['sendOne'](_0x4566fd,_0x13c2bf);}}['sendOne'](_0xaaf6e4,_0x52f6b4){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xaaf6e4]!==void 0x0)try{_0x52f6b4(this['observers'][_0xaaf6e4]);}catch(_0x24025f){typeof console<'u'&&console['error']&&console['error'](_0x24025f);}});}['close'](_0x4741e3){this['finalized']||(this['finalized']=!0x0,_0x4741e3!==void 0x0&&(this['finalError']=_0x4741e3),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x427ea8,_0x240dd7){if(typeof _0x427ea8!='object'||_0x427ea8===null)return!0x1;for(const _0xc5bda7 of _0x240dd7)if(_0xc5bda7 in _0x427ea8&&typeof _0x427ea8[_0xc5bda7]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x24163a,_0x565c39){return _0x24163a+'\x20failed:\x20'+_0x565c39+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x30d6a6){const _0x2161e4=[];let _0x5bf37e=0x0;for(let _0x150d2d=0x0;_0x150d2d<_0x30d6a6['length'];_0x150d2d++){let _0x110eea=_0x30d6a6['charCodeAt'](_0x150d2d);if(_0x110eea>=0xd800&&_0x110eea<=0xdbff){const _0x354cc6=_0x110eea-0xd800;_0x150d2d++,f(_0x150d2d<_0x30d6a6['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2c567d=_0x30d6a6['charCodeAt'](_0x150d2d)-0xdc00;_0x110eea=0x10000+(_0x354cc6<<0xa)+_0x2c567d;}_0x110eea<0x80?_0x2161e4[_0x5bf37e++]=_0x110eea:_0x110eea<0x800?(_0x2161e4[_0x5bf37e++]=_0x110eea>>0x6|0xc0,_0x2161e4[_0x5bf37e++]=_0x110eea&0x3f|0x80):_0x110eea<0x10000?(_0x2161e4[_0x5bf37e++]=_0x110eea>>0xc|0xe0,_0x2161e4[_0x5bf37e++]=_0x110eea>>0x6&0x3f|0x80,_0x2161e4[_0x5bf37e++]=_0x110eea&0x3f|0x80):(_0x2161e4[_0x5bf37e++]=_0x110eea>>0x12|0xf0,_0x2161e4[_0x5bf37e++]=_0x110eea>>0xc&0x3f|0x80,_0x2161e4[_0x5bf37e++]=_0x110eea>>0x6&0x3f|0x80,_0x2161e4[_0x5bf37e++]=_0x110eea&0x3f|0x80);}return _0x2161e4;},Ln=function(_0x57cc24){let _0x2545ba=0x0;for(let _0x3b1f8c=0x0;_0x3b1f8c<_0x57cc24['length'];_0x3b1f8c++){const _0x6a5230=_0x57cc24['charCodeAt'](_0x3b1f8c);_0x6a5230<0x80?_0x2545ba++:_0x6a5230<0x800?_0x2545ba+=0x2:_0x6a5230>=0xd800&&_0x6a5230<=0xdbff?(_0x2545ba+=0x4,_0x3b1f8c++):_0x2545ba+=0x3;}return _0x2545ba;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x1fcf92){return _0x1fcf92&&_0x1fcf92['_delegate']?_0x1fcf92['_delegate']:_0x1fcf92;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0xd925b0){try{return(_0xd925b0['startsWith']('http://')||_0xd925b0['startsWith']('https://')?new URL(_0xd925b0)['hostname']:_0xd925b0)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3664d6){return(await fetch(_0x3664d6,{'credentials':'include'}))['ok'];}class xe{constructor(_0x53eb74,_0x1a55e1,_0x2f3e93){this['name']=_0x53eb74,this['instanceFactory']=_0x1a55e1,this['type']=_0x2f3e93,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x684a13){return this['instantiationMode']=_0x684a13,this;}['setMultipleInstances'](_0x3cef17){return this['multipleInstances']=_0x3cef17,this;}['setServiceProps'](_0x2f71dc){return this['serviceProps']=_0x2f71dc,this;}['setInstanceCreatedCallback'](_0x35d90b){return this['onInstanceCreated']=_0x35d90b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x6f827d,_0x2d5cdc){this['name']=_0x6f827d,this['container']=_0x2d5cdc,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4a5757){const _0x25e546=this['normalizeInstanceIdentifier'](_0x4a5757);if(!this['instancesDeferred']['has'](_0x25e546)){const _0x489f1c=new H();if(this['instancesDeferred']['set'](_0x25e546,_0x489f1c),this['isInitialized'](_0x25e546)||this['shouldAutoInitialize']())try{const _0x2e9ee4=this['getOrInitializeService']({'instanceIdentifier':_0x25e546});_0x2e9ee4&&_0x489f1c['resolve'](_0x2e9ee4);}catch{}}return this['instancesDeferred']['get'](_0x25e546)['promise'];}['getImmediate'](_0xd04722){const _0x33f4f9=this['normalizeInstanceIdentifier'](_0xd04722==null?void 0x0:_0xd04722['identifier']),_0x3f9b1c=(_0xd04722==null?void 0x0:_0xd04722['optional'])??!0x1;if(this['isInitialized'](_0x33f4f9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x33f4f9});}catch(_0x549062){if(_0x3f9b1c)return null;throw _0x549062;}else{if(_0x3f9b1c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x131c07){if(_0x131c07['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x131c07['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x131c07,!!this['shouldAutoInitialize']()){if(Nc(_0x131c07))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x55f172,_0x2918dd]of this['instancesDeferred']['entries']()){const _0x216005=this['normalizeInstanceIdentifier'](_0x55f172);try{const _0x1da394=this['getOrInitializeService']({'instanceIdentifier':_0x216005});_0x2918dd['resolve'](_0x1da394);}catch{}}}}['clearInstance'](_0x25366a=Ne){this['instancesDeferred']['delete'](_0x25366a),this['instancesOptions']['delete'](_0x25366a),this['instances']['delete'](_0x25366a);}async['delete'](){const _0x1031fc=Array['from'](this['instances']['values']());await Promise['all']([..._0x1031fc['filter'](_0x337a21=>'INTERNAL'in _0x337a21)['map'](_0x24a3b5=>_0x24a3b5['INTERNAL']['delete']()),..._0x1031fc['filter'](_0x233813=>'_delete'in _0x233813)['map'](_0x4c4f69=>_0x4c4f69['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2031a4=Ne){return this['instances']['has'](_0x2031a4);}['getOptions'](_0x14eac3=Ne){return this['instancesOptions']['get'](_0x14eac3)||{};}['initialize'](_0x76d7c8={}){const {options:_0x5eacc1={}}=_0x76d7c8,_0x31296a=this['normalizeInstanceIdentifier'](_0x76d7c8['instanceIdentifier']);if(this['isInitialized'](_0x31296a))throw Error(this['name']+'('+_0x31296a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x86024a=this['getOrInitializeService']({'instanceIdentifier':_0x31296a,'options':_0x5eacc1});for(const [_0x27a338,_0x4ebcf0]of this['instancesDeferred']['entries']()){const _0x366318=this['normalizeInstanceIdentifier'](_0x27a338);_0x31296a===_0x366318&&_0x4ebcf0['resolve'](_0x86024a);}return _0x86024a;}['onInit'](_0x294fa5,_0x36507f){const _0x5255d9=this['normalizeInstanceIdentifier'](_0x36507f),_0x1e795e=this['onInitCallbacks']['get'](_0x5255d9)??new Set();_0x1e795e['add'](_0x294fa5),this['onInitCallbacks']['set'](_0x5255d9,_0x1e795e);const _0x471618=this['instances']['get'](_0x5255d9);return _0x471618&&_0x294fa5(_0x471618,_0x5255d9),()=>{_0x1e795e['delete'](_0x294fa5);};}['invokeOnInitCallbacks'](_0x3368b8,_0x185530){const _0xadb7b9=this['onInitCallbacks']['get'](_0x185530);if(_0xadb7b9){for(const _0x36eaa0 of _0xadb7b9)try{_0x36eaa0(_0x3368b8,_0x185530);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2ab3de,options:_0x18d9f2={}}){let _0x505587=this['instances']['get'](_0x2ab3de);if(!_0x505587&&this['component']&&(_0x505587=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2ab3de),'options':_0x18d9f2}),this['instances']['set'](_0x2ab3de,_0x505587),this['instancesOptions']['set'](_0x2ab3de,_0x18d9f2),this['invokeOnInitCallbacks'](_0x505587,_0x2ab3de),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2ab3de,_0x505587);}catch{}return _0x505587||null;}['normalizeInstanceIdentifier'](_0xbf6aec=Ne){return this['component']?this['component']['multipleInstances']?_0xbf6aec:Ne:_0xbf6aec;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5944d4){return _0x5944d4===Ne?void 0x0:_0x5944d4;}function Nc(_0xdec9d9){return _0xdec9d9['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x10e0d9){this['name']=_0x10e0d9,this['providers']=new Map();}['addComponent'](_0x31b1f8){const _0x501a53=this['getProvider'](_0x31b1f8['name']);if(_0x501a53['isComponentSet']())throw new Error('Component\x20'+_0x31b1f8['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x501a53['setComponent'](_0x31b1f8);}['addOrOverwriteComponent'](_0x446f2b){this['getProvider'](_0x446f2b['name'])['isComponentSet']()&&this['providers']['delete'](_0x446f2b['name']),this['addComponent'](_0x446f2b);}['getProvider'](_0x27bb2a){if(this['providers']['has'](_0x27bb2a))return this['providers']['get'](_0x27bb2a);const _0x3faa69=new Ac(_0x27bb2a,this);return this['providers']['set'](_0x27bb2a,_0x3faa69),_0x3faa69;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x17a697){_0x17a697[_0x17a697['DEBUG']=0x0]='DEBUG',_0x17a697[_0x17a697['VERBOSE']=0x1]='VERBOSE',_0x17a697[_0x17a697['INFO']=0x2]='INFO',_0x17a697[_0x17a697['WARN']=0x3]='WARN',_0x17a697[_0x17a697['ERROR']=0x4]='ERROR',_0x17a697[_0x17a697['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x3fde24,_0x4bf08e,..._0x15d7e9)=>{if(_0x4bf08e<_0x3fde24['logLevel'])return;const _0x36db61=new Date()['toISOString'](),_0x198790=Mc[_0x4bf08e];if(_0x198790)console[_0x198790]('['+_0x36db61+']\x20\x20'+_0x3fde24['name']+':',..._0x15d7e9);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4bf08e+')');};class Bi{constructor(_0x597cd9){this['name']=_0x597cd9,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x48dbbd){if(!(_0x48dbbd in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x48dbbd+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x48dbbd;}['setLogLevel'](_0x4c9627){this['_logLevel']=typeof _0x4c9627=='string'?Oc[_0x4c9627]:_0x4c9627;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x180f12){if(typeof _0x180f12!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x180f12;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x25b918){this['_userLogHandler']=_0x25b918;}['debug'](..._0x35c500){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x35c500),this['_logHandler'](this,T['DEBUG'],..._0x35c500);}['log'](..._0x537f4d){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x537f4d),this['_logHandler'](this,T['VERBOSE'],..._0x537f4d);}['info'](..._0x45f665){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x45f665),this['_logHandler'](this,T['INFO'],..._0x45f665);}['warn'](..._0x109cfb){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x109cfb),this['_logHandler'](this,T['WARN'],..._0x109cfb);}['error'](..._0x491300){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x491300),this['_logHandler'](this,T['ERROR'],..._0x491300);}}const xc=(_0x1f7acb,_0x3b496e)=>_0x3b496e['some'](_0x166da6=>_0x1f7acb instanceof _0x166da6);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x915f53){const _0x4334f5=new Promise((_0x174d07,_0x211c76)=>{const _0x1092a0=()=>{_0x915f53['removeEventListener']('success',_0x20db26),_0x915f53['removeEventListener']('error',_0x3b6385);},_0x20db26=()=>{_0x174d07(ge(_0x915f53['result'])),_0x1092a0();},_0x3b6385=()=>{_0x211c76(_0x915f53['error']),_0x1092a0();};_0x915f53['addEventListener']('success',_0x20db26),_0x915f53['addEventListener']('error',_0x3b6385);});return _0x4334f5['then'](_0x146c9b=>{_0x146c9b instanceof IDBCursor&&Jr['set'](_0x146c9b,_0x915f53);})['catch'](()=>{}),Vi['set'](_0x4334f5,_0x915f53),_0x4334f5;}function Bc(_0x43e6da){if(_i['has'](_0x43e6da))return;const _0x351930=new Promise((_0x1311dc,_0x53887e)=>{const _0x1875fd=()=>{_0x43e6da['removeEventListener']('complete',_0x492f3d),_0x43e6da['removeEventListener']('error',_0x2193cf),_0x43e6da['removeEventListener']('abort',_0x2193cf);},_0x492f3d=()=>{_0x1311dc(),_0x1875fd();},_0x2193cf=()=>{_0x53887e(_0x43e6da['error']||new DOMException('AbortError','AbortError')),_0x1875fd();};_0x43e6da['addEventListener']('complete',_0x492f3d),_0x43e6da['addEventListener']('error',_0x2193cf),_0x43e6da['addEventListener']('abort',_0x2193cf);});_i['set'](_0x43e6da,_0x351930);}let gi={'get'(_0x20256f,_0x17a6f9,_0x755c31){if(_0x20256f instanceof IDBTransaction){if(_0x17a6f9==='done')return _i['get'](_0x20256f);if(_0x17a6f9==='objectStoreNames')return _0x20256f['objectStoreNames']||Xr['get'](_0x20256f);if(_0x17a6f9==='store')return _0x755c31['objectStoreNames'][0x1]?void 0x0:_0x755c31['objectStore'](_0x755c31['objectStoreNames'][0x0]);}return ge(_0x20256f[_0x17a6f9]);},'set'(_0x5358ec,_0x50d5c0,_0x1fb283){return _0x5358ec[_0x50d5c0]=_0x1fb283,!0x0;},'has'(_0x217e76,_0x21469f){return _0x217e76 instanceof IDBTransaction&&(_0x21469f==='done'||_0x21469f==='store')?!0x0:_0x21469f in _0x217e76;}};function Vc(_0x499ddd){gi=_0x499ddd(gi);}function Hc(_0x448923){return _0x448923===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x407b2a,..._0x301bd2){const _0x5692ea=_0x448923['call'](ii(this),_0x407b2a,..._0x301bd2);return Xr['set'](_0x5692ea,_0x407b2a['sort']?_0x407b2a['sort']():[_0x407b2a]),ge(_0x5692ea);}:Uc()['includes'](_0x448923)?function(..._0xce95fb){return _0x448923['apply'](ii(this),_0xce95fb),ge(Jr['get'](this));}:function(..._0x563770){return ge(_0x448923['apply'](ii(this),_0x563770));};}function $c(_0x490087){return typeof _0x490087=='function'?Hc(_0x490087):(_0x490087 instanceof IDBTransaction&&Bc(_0x490087),xc(_0x490087,Fc())?new Proxy(_0x490087,gi):_0x490087);}function ge(_0x1c2f4a){if(_0x1c2f4a instanceof IDBRequest)return Wc(_0x1c2f4a);if(ni['has'](_0x1c2f4a))return ni['get'](_0x1c2f4a);const _0x50a058=$c(_0x1c2f4a);return _0x50a058!==_0x1c2f4a&&(ni['set'](_0x1c2f4a,_0x50a058),Vi['set'](_0x50a058,_0x1c2f4a)),_0x50a058;}const ii=_0x1a489f=>Vi['get'](_0x1a489f);function Gc(_0x2e301a,_0x50387a,{blocked:_0x3af004,upgrade:_0x4ec40a,blocking:_0x348269,terminated:_0x203e78}={}){const _0x2bcd82=indexedDB['open'](_0x2e301a,_0x50387a),_0x3a79c8=ge(_0x2bcd82);return _0x4ec40a&&_0x2bcd82['addEventListener']('upgradeneeded',_0x5a42a7=>{_0x4ec40a(ge(_0x2bcd82['result']),_0x5a42a7['oldVersion'],_0x5a42a7['newVersion'],ge(_0x2bcd82['transaction']),_0x5a42a7);}),_0x3af004&&_0x2bcd82['addEventListener']('blocked',_0x308ba1=>_0x3af004(_0x308ba1['oldVersion'],_0x308ba1['newVersion'],_0x308ba1)),_0x3a79c8['then'](_0xf4b5fb=>{_0x203e78&&_0xf4b5fb['addEventListener']('close',()=>_0x203e78()),_0x348269&&_0xf4b5fb['addEventListener']('versionchange',_0x38d792=>_0x348269(_0x38d792['oldVersion'],_0x38d792['newVersion'],_0x38d792));})['catch'](()=>{}),_0x3a79c8;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x498e56,_0x32cfc2){if(!(_0x498e56 instanceof IDBDatabase&&!(_0x32cfc2 in _0x498e56)&&typeof _0x32cfc2=='string'))return;if(si['get'](_0x32cfc2))return si['get'](_0x32cfc2);const _0x554806=_0x32cfc2['replace'](/FromIndex$/,''),_0x1964c0=_0x32cfc2!==_0x554806,_0x2deff5=zc['includes'](_0x554806);if(!(_0x554806 in(_0x1964c0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2deff5||qc['includes'](_0x554806)))return;const _0x4eaee9=async function(_0x2e9811,..._0x48beed){const _0x727eba=this['transaction'](_0x2e9811,_0x2deff5?'readwrite':'readonly');let _0x3c8be9=_0x727eba['store'];return _0x1964c0&&(_0x3c8be9=_0x3c8be9['index'](_0x48beed['shift']())),(await Promise['all']([_0x3c8be9[_0x554806](..._0x48beed),_0x2deff5&&_0x727eba['done']]))[0x0];};return si['set'](_0x32cfc2,_0x4eaee9),_0x4eaee9;}Vc(_0x35354f=>({..._0x35354f,'get':(_0x3be7a0,_0xb0b631,_0x165493)=>Ms(_0x3be7a0,_0xb0b631)||_0x35354f['get'](_0x3be7a0,_0xb0b631,_0x165493),'has':(_0x130df2,_0x38f268)=>!!Ms(_0x130df2,_0x38f268)||_0x35354f['has'](_0x130df2,_0x38f268)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x46f30c){this['container']=_0x46f30c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5b7178=>{if(Kc(_0x5b7178)){const _0x3f82af=_0x5b7178['getImmediate']();return _0x3f82af['library']+'/'+_0x3f82af['version'];}else return null;})['filter'](_0x2be19d=>_0x2be19d)['join']('\x20');}}function Kc(_0x2fcc32){const _0xc2c81=_0x2fcc32['getComponent']();return(_0xc2c81==null?void 0x0:_0xc2c81['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x5931a8,_0x57bde4){try{_0x5931a8['container']['addComponent'](_0x57bde4);}catch(_0x1d225a){oe['debug']('Component\x20'+_0x57bde4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5931a8['name'],_0x1d225a);}}function st(_0x112f42){const _0x18683c=_0x112f42['name'];if(Ei['has'](_0x18683c))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x18683c+'.'),!0x1;Ei['set'](_0x18683c,_0x112f42);for(const _0x48b258 of Fe['values']())xs(_0x48b258,_0x112f42);for(const _0x8a8519 of vi['values']())xs(_0x8a8519,_0x112f42);return!0x0;}function Hi(_0x4c133d,_0x45bee9){const _0x33a8ac=_0x4c133d['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x33a8ac&&_0x33a8ac['triggerHeartbeat'](),_0x4c133d['container']['getProvider'](_0x45bee9);}function $(_0x43be40){return _0x43be40==null?!0x1:_0x43be40['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0xc5b4ac,_0x4c88e8,_0x2e3081){this['_isDeleted']=!0x1,this['_options']={..._0xc5b4ac},this['_config']={..._0x4c88e8},this['_name']=_0x4c88e8['name'],this['_automaticDataCollectionEnabled']=_0x4c88e8['automaticDataCollectionEnabled'],this['_container']=_0x2e3081,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x351744){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x351744;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4c2f71){this['_isDeleted']=_0x4c2f71;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x29ae40,_0x2ecc92={}){let _0x125663=_0x29ae40;typeof _0x2ecc92!='object'&&(_0x2ecc92={'name':_0x2ecc92});const _0xf1e3f4={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x2ecc92},_0x179761=_0xf1e3f4['name'];if(typeof _0x179761!='string'||!_0x179761)throw me['create']('bad-app-name',{'appName':String(_0x179761)});if(_0x125663||(_0x125663=zr()),!_0x125663)throw me['create']('no-options');const _0x548bb6=Fe['get'](_0x179761);if(_0x548bb6){if(Le(_0x125663,_0x548bb6['options'])&&Le(_0xf1e3f4,_0x548bb6['config']))return _0x548bb6;throw me['create']('duplicate-app',{'appName':_0x179761});}const _0x256ead=new Pc(_0x179761);for(const _0x7a46ca of Ei['values']())_0x256ead['addComponent'](_0x7a46ca);const _0x4dd26d=new Tl(_0x125663,_0xf1e3f4,_0x256ead);return Fe['set'](_0x179761,_0x4dd26d),_0x4dd26d;}function Zr(_0x48b810=yi){const _0x42af5d=Fe['get'](_0x48b810);if(!_0x42af5d&&_0x48b810===yi&&zr())return Sl();if(!_0x42af5d)throw me['create']('no-app',{'appName':_0x48b810});return _0x42af5d;}function p_(){return Array['from'](Fe['values']());}async function __(_0x5bc58d){let _0x1cbb37=!0x1;const _0x5624f8=_0x5bc58d['name'];Fe['has'](_0x5624f8)?(_0x1cbb37=!0x0,Fe['delete'](_0x5624f8)):vi['has'](_0x5624f8)&&_0x5bc58d['decRefCount']()<=0x0&&(vi['delete'](_0x5624f8),_0x1cbb37=!0x0),_0x1cbb37&&(await Promise['all'](_0x5bc58d['container']['getProviders']()['map'](_0x1773fe=>_0x1773fe['delete']())),_0x5bc58d['isDeleted']=!0x0);}function ye(_0x43578e,_0xc5787f,_0x172329){let _0x5bdbec=wl[_0x43578e]??_0x43578e;_0x172329&&(_0x5bdbec+='-'+_0x172329);const _0x52a463=_0x5bdbec['match'](/\s|\//),_0xe6471d=_0xc5787f['match'](/\s|\//);if(_0x52a463||_0xe6471d){const _0xb8592f=['Unable\x20to\x20register\x20library\x20\x22'+_0x5bdbec+'\x22\x20with\x20version\x20\x22'+_0xc5787f+'\x22:'];_0x52a463&&_0xb8592f['push']('library\x20name\x20\x22'+_0x5bdbec+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x52a463&&_0xe6471d&&_0xb8592f['push']('and'),_0xe6471d&&_0xb8592f['push']('version\x20name\x20\x22'+_0xc5787f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0xb8592f['join']('\x20'));return;}st(new xe(_0x5bdbec+'-version',()=>({'library':_0x5bdbec,'version':_0xc5787f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x39a3e0,_0x21f602)=>{switch(_0x21f602){case 0x0:try{_0x39a3e0['createObjectStore'](Pt);}catch(_0x3e8939){console['warn'](_0x3e8939);}}}})['catch'](_0x7c5f5e=>{throw me['create']('idb-open',{'originalErrorMessage':_0x7c5f5e['message']});})),ri;}async function Al(_0x17245a){try{const _0xa1a79d=(await eo())['transaction'](Pt),_0x570ff6=await _0xa1a79d['objectStore'](Pt)['get'](to(_0x17245a));return await _0xa1a79d['done'],_0x570ff6;}catch(_0x2b29e0){if(_0x2b29e0 instanceof Re)oe['warn'](_0x2b29e0['message']);else{const _0x3be2e1=me['create']('idb-get',{'originalErrorMessage':_0x2b29e0==null?void 0x0:_0x2b29e0['message']});oe['warn'](_0x3be2e1['message']);}}}async function Fs(_0x5a2faf,_0x3c157e){try{const _0x19973d=(await eo())['transaction'](Pt,'readwrite');await _0x19973d['objectStore'](Pt)['put'](_0x3c157e,to(_0x5a2faf)),await _0x19973d['done'];}catch(_0x10bb71){if(_0x10bb71 instanceof Re)oe['warn'](_0x10bb71['message']);else{const _0x5821cd=me['create']('idb-set',{'originalErrorMessage':_0x10bb71==null?void 0x0:_0x10bb71['message']});oe['warn'](_0x5821cd['message']);}}}function to(_0x1a2043){return _0x1a2043['name']+'!'+_0x1a2043['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x142897){this['container']=_0x142897,this['_heartbeatsCache']=null;const _0x20970f=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x20970f),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5544c1=>(this['_heartbeatsCache']=_0x5544c1,_0x5544c1));}async['triggerHeartbeat'](){var _0x46fb6a,_0x30921a;try{const _0x4bbbe9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3f1232=Us();if(((_0x46fb6a=this['_heartbeatsCache'])==null?void 0x0:_0x46fb6a['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x30921a=this['_heartbeatsCache'])==null?void 0x0:_0x30921a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3f1232||this['_heartbeatsCache']['heartbeats']['some'](_0xbe43e9=>_0xbe43e9['date']===_0x3f1232))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3f1232,'agent':_0x4bbbe9}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x251fe0=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x251fe0,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4185cc){oe['warn'](_0x4185cc);}}async['getHeartbeatsHeader'](){var _0xb5b109;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xb5b109=this['_heartbeatsCache'])==null?void 0x0:_0xb5b109['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x365b21=Us(),{heartbeatsToSend:_0x23a069,unsentEntries:_0x201866}=Ol(this['_heartbeatsCache']['heartbeats']),_0x44b716=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x23a069}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x365b21,_0x201866['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x201866,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x44b716;}catch(_0x51663e){return oe['warn'](_0x51663e),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2e36ab,_0x2c5ab7=kl){const _0x4a84af=[];let _0x779f13=_0x2e36ab['slice']();for(const _0x401972 of _0x2e36ab){const _0x14f14c=_0x4a84af['find'](_0x57c133=>_0x57c133['agent']===_0x401972['agent']);if(_0x14f14c){if(_0x14f14c['dates']['push'](_0x401972['date']),Ws(_0x4a84af)>_0x2c5ab7){_0x14f14c['dates']['pop']();break;}}else{if(_0x4a84af['push']({'agent':_0x401972['agent'],'dates':[_0x401972['date']]}),Ws(_0x4a84af)>_0x2c5ab7){_0x4a84af['pop']();break;}}_0x779f13=_0x779f13['slice'](0x1);}return{'heartbeatsToSend':_0x4a84af,'unsentEntries':_0x779f13};}class Dl{constructor(_0x1b4b83){this['app']=_0x1b4b83,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x384f4a=await Al(this['app']);return _0x384f4a!=null&&_0x384f4a['heartbeats']?_0x384f4a:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x38b370){if(await this['_canUseIndexedDBPromise']){const _0x209e6f=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x38b370['lastSentHeartbeatDate']??_0x209e6f['lastSentHeartbeatDate'],'heartbeats':_0x38b370['heartbeats']});}else return;}async['add'](_0x3d64ed){if(await this['_canUseIndexedDBPromise']){const _0x5c8ea4=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3d64ed['lastSentHeartbeatDate']??_0x5c8ea4['lastSentHeartbeatDate'],'heartbeats':[..._0x5c8ea4['heartbeats'],..._0x3d64ed['heartbeats']]});}else return;}}function Ws(_0x4eb487){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4eb487}))['length'];}function Ml(_0x259de8){if(_0x259de8['length']===0x0)return-0x1;let _0x3d0cc3=0x0,_0x2d7a32=_0x259de8[0x0]['date'];for(let _0x1edbed=0x1;_0x1edbed<_0x259de8['length'];_0x1edbed++)_0x259de8[_0x1edbed]['date']<_0x2d7a32&&(_0x2d7a32=_0x259de8[_0x1edbed]['date'],_0x3d0cc3=_0x1edbed);return _0x3d0cc3;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x446fcc){st(new xe('platform-logger',_0xaf9500=>new jc(_0xaf9500),'PRIVATE')),st(new xe('heartbeat',_0x590fac=>new Pl(_0x590fac),'PRIVATE')),ye(mi,Ls,_0x446fcc),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x381cc0){no=_0x381cc0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x44666a){this['domStorage_']=_0x44666a,this['prefix_']='firebase:';}['set'](_0x399153,_0x273f79){_0x273f79==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x399153)):this['domStorage_']['setItem'](this['prefixedName_'](_0x399153),O(_0x273f79));}['get'](_0x34fe78){const _0x48a3e7=this['domStorage_']['getItem'](this['prefixedName_'](_0x34fe78));return _0x48a3e7==null?null:Nt(_0x48a3e7);}['remove'](_0x5b299f){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5b299f));}['prefixedName_'](_0x31a73d){return this['prefix_']+_0x31a73d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x24de3c,_0x2ba2ab){_0x2ba2ab==null?delete this['cache_'][_0x24de3c]:this['cache_'][_0x24de3c]=_0x2ba2ab;}['get'](_0x188c17){return Q(this['cache_'],_0x188c17)?this['cache_'][_0x188c17]:null;}['remove'](_0x922547){delete this['cache_'][_0x922547];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4e48f0){try{if(typeof window<'u'&&typeof window[_0x4e48f0]<'u'){const _0x51b703=window[_0x4e48f0];return _0x51b703['setItem']('firebase:sentinel','cache'),_0x51b703['removeItem']('firebase:sentinel'),new Wl(_0x51b703);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x499298=0x1;return function(){return _0x499298++;};}()),ro=function(_0x4f7191){const _0x27f855=Rc(_0x4f7191),_0x1c44df=new Cc();_0x1c44df['update'](_0x27f855);const _0x4df230=_0x1c44df['digest']();return Fi['encodeByteArray'](_0x4df230);},qt=function(..._0x194810){let _0x2a9bc8='';for(let _0xbd6073=0x0;_0xbd6073<_0x194810['length'];_0xbd6073++){const _0x319424=_0x194810[_0xbd6073];Array['isArray'](_0x319424)||_0x319424&&typeof _0x319424=='object'&&typeof _0x319424['length']=='number'?_0x2a9bc8+=qt['apply'](null,_0x319424):typeof _0x319424=='object'?_0x2a9bc8+=O(_0x319424):_0x2a9bc8+=_0x319424,_0x2a9bc8+='\x20';}return _0x2a9bc8;};let Tt=null,$s=!0x0;const Hl=function(_0x57f1fc,_0x515806){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0x297253){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0x2c5775=qt['apply'](null,_0x297253);Tt(_0x2c5775);}},zt=function(_0x2bd3bb){return function(..._0x37a41f){L(_0x2bd3bb,..._0x37a41f);};},Ii=function(..._0x446e7d){const _0x5e2a8c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x446e7d);Ze['error'](_0x5e2a8c);},ae=function(..._0x154703){const _0x29f367='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x154703);throw Ze['error'](_0x29f367),new Error(_0x29f367);},U=function(..._0x2b46bb){const _0xf4e39a='FIREBASE\x20WARNING:\x20'+qt(..._0x2b46bb);Ze['warn'](_0xf4e39a);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5ada75){return typeof _0x5ada75=='number'&&(_0x5ada75!==_0x5ada75||_0x5ada75===Number['POSITIVE_INFINITY']||_0x5ada75===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2217c2){if(document['readyState']==='complete')_0x2217c2();else{let _0x3c0284=!0x1;const _0x375b5c=function(){if(!document['body']){setTimeout(_0x375b5c,Math['floor'](0xa));return;}_0x3c0284||(_0x3c0284=!0x0,_0x2217c2());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x375b5c,!0x1),window['addEventListener']('load',_0x375b5c,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x375b5c();}),window['attachEvent']('onload',_0x375b5c));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x1e4586,_0x3ec89c){if(_0x1e4586===_0x3ec89c)return 0x0;if(_0x1e4586===Ue||_0x3ec89c===we)return-0x1;if(_0x3ec89c===Ue||_0x1e4586===we)return 0x1;{const _0x47f077=Gs(_0x1e4586),_0x16b040=Gs(_0x3ec89c);return _0x47f077!==null?_0x16b040!==null?_0x47f077-_0x16b040===0x0?_0x1e4586['length']-_0x3ec89c['length']:_0x47f077-_0x16b040:-0x1:_0x16b040!==null?0x1:_0x1e4586<_0x3ec89c?-0x1:0x1;}},ql=function(_0x5e19aa,_0x4b3cf2){return _0x5e19aa===_0x4b3cf2?0x0:_0x5e19aa<_0x4b3cf2?-0x1:0x1;},yt=function(_0x121554,_0x39de19){if(_0x39de19&&_0x121554 in _0x39de19)return _0x39de19[_0x121554];throw new Error('Missing\x20required\x20key\x20('+_0x121554+')\x20in\x20object:\x20'+O(_0x39de19));},$i=function(_0x1d1604){if(typeof _0x1d1604!='object'||_0x1d1604===null)return O(_0x1d1604);const _0x3b9449=[];for(const _0x122f50 in _0x1d1604)_0x3b9449['push'](_0x122f50);_0x3b9449['sort']();let _0x3d6d95='{';for(let _0x2d84ef=0x0;_0x2d84ef<_0x3b9449['length'];_0x2d84ef++)_0x2d84ef!==0x0&&(_0x3d6d95+=','),_0x3d6d95+=O(_0x3b9449[_0x2d84ef]),_0x3d6d95+=':',_0x3d6d95+=$i(_0x1d1604[_0x3b9449[_0x2d84ef]]);return _0x3d6d95+='}',_0x3d6d95;},oo=function(_0x1eae4e,_0x26db5b){const _0x5ecb43=_0x1eae4e['length'];if(_0x5ecb43<=_0x26db5b)return[_0x1eae4e];const _0x572b16=[];for(let _0x12f863=0x0;_0x12f863<_0x5ecb43;_0x12f863+=_0x26db5b)_0x12f863+_0x26db5b>_0x5ecb43?_0x572b16['push'](_0x1eae4e['substring'](_0x12f863,_0x5ecb43)):_0x572b16['push'](_0x1eae4e['substring'](_0x12f863,_0x12f863+_0x26db5b));return _0x572b16;};function x(_0x4aeb98,_0x3ce023){for(const _0x53d4b3 in _0x4aeb98)_0x4aeb98['hasOwnProperty'](_0x53d4b3)&&_0x3ce023(_0x53d4b3,_0x4aeb98[_0x53d4b3]);}const ao=function(_0x220247){f(!xn(_0x220247),'Invalid\x20JSON\x20number');const _0x250430=0xb,_0x3b7c85=0x34,_0x47905d=(0x1<<_0x250430-0x1)-0x1;let _0x343cee,_0x3aefa5,_0x428e27,_0xd76cf0,_0x38bf5e;_0x220247===0x0?(_0x3aefa5=0x0,_0x428e27=0x0,_0x343cee=0x1/_0x220247===-0x1/0x0?0x1:0x0):(_0x343cee=_0x220247<0x0,_0x220247=Math['abs'](_0x220247),_0x220247>=Math['pow'](0x2,0x1-_0x47905d)?(_0xd76cf0=Math['min'](Math['floor'](Math['log'](_0x220247)/Math['LN2']),_0x47905d),_0x3aefa5=_0xd76cf0+_0x47905d,_0x428e27=Math['round'](_0x220247*Math['pow'](0x2,_0x3b7c85-_0xd76cf0)-Math['pow'](0x2,_0x3b7c85))):(_0x3aefa5=0x0,_0x428e27=Math['round'](_0x220247/Math['pow'](0x2,0x1-_0x47905d-_0x3b7c85))));const _0x48b52c=[];for(_0x38bf5e=_0x3b7c85;_0x38bf5e;_0x38bf5e-=0x1)_0x48b52c['push'](_0x428e27%0x2?0x1:0x0),_0x428e27=Math['floor'](_0x428e27/0x2);for(_0x38bf5e=_0x250430;_0x38bf5e;_0x38bf5e-=0x1)_0x48b52c['push'](_0x3aefa5%0x2?0x1:0x0),_0x3aefa5=Math['floor'](_0x3aefa5/0x2);_0x48b52c['push'](_0x343cee?0x1:0x0),_0x48b52c['reverse']();const _0x56d393=_0x48b52c['join']('');let _0x52e955='';for(_0x38bf5e=0x0;_0x38bf5e<0x40;_0x38bf5e+=0x8){let _0x18f0be=parseInt(_0x56d393['substr'](_0x38bf5e,0x8),0x2)['toString'](0x10);_0x18f0be['length']===0x1&&(_0x18f0be='0'+_0x18f0be),_0x52e955=_0x52e955+_0x18f0be;}return _0x52e955['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x57cc74,_0x2f93ce){let _0x59ec4e='Unknown\x20Error';_0x57cc74==='too_big'?_0x59ec4e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x57cc74==='permission_denied'?_0x59ec4e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x57cc74==='unavailable'&&(_0x59ec4e='The\x20service\x20is\x20unavailable');const _0x1e2631=new Error(_0x57cc74+'\x20at\x20'+_0x2f93ce['_path']['toString']()+':\x20'+_0x59ec4e);return _0x1e2631['code']=_0x57cc74['toUpperCase'](),_0x1e2631;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x35c6a8){if(Yl['test'](_0x35c6a8)){const _0x52d9eb=Number(_0x35c6a8);if(_0x52d9eb>=Ql&&_0x52d9eb<=Jl)return _0x52d9eb;}return null;},ft=function(_0x5be284){try{_0x5be284();}catch(_0x584a99){setTimeout(()=>{const _0x5b439d=_0x584a99['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5b439d),_0x584a99;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x3f9aa8,_0x10eff6){const _0x3539a1=setTimeout(_0x3f9aa8,_0x10eff6);return typeof _0x3539a1=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3539a1):typeof _0x3539a1=='object'&&_0x3539a1['unref']&&_0x3539a1['unref'](),_0x3539a1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x386511,_0x50bd89){this['appCheckProvider']=_0x50bd89,this['appName']=_0x386511['name'],$(_0x386511)&&_0x386511['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x386511['settings']['appCheckToken']),this['appCheck']=_0x50bd89==null?void 0x0:_0x50bd89['getImmediate']({'optional':!0x0}),this['appCheck']||_0x50bd89==null||_0x50bd89['get']()['then'](_0x133586=>this['appCheck']=_0x133586);}['getToken'](_0x3770f3){if(this['serverAppAppCheckToken']){if(_0x3770f3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3770f3):new Promise((_0x295028,_0x309a81)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3770f3)['then'](_0x295028,_0x309a81):_0x295028(null);},0x0);});}['addTokenChangeListener'](_0x1bbe5a){var _0x27807a;(_0x27807a=this['appCheckProvider'])==null||_0x27807a['get']()['then'](_0x58f387=>_0x58f387['addTokenListener'](_0x1bbe5a));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5d237b,_0x27e06c,_0x51a159){this['appName_']=_0x5d237b,this['firebaseOptions_']=_0x27e06c,this['authProvider_']=_0x51a159,this['auth_']=null,this['auth_']=_0x51a159['getImmediate']({'optional':!0x0}),this['auth_']||_0x51a159['onInit'](_0x36471f=>this['auth_']=_0x36471f);}['getToken'](_0xc782e4){return this['auth_']?this['auth_']['getToken'](_0xc782e4)['catch'](_0x149563=>_0x149563&&_0x149563['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x149563)):new Promise((_0x440722,_0x391135)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xc782e4)['then'](_0x440722,_0x391135):_0x440722(null);},0x0);});}['addTokenChangeListener'](_0x4ee1a4){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4ee1a4):this['authProvider_']['get']()['then'](_0x61750b=>_0x61750b['addAuthTokenListener'](_0x4ee1a4));}['removeTokenChangeListener'](_0x1e52bb){this['authProvider_']['get']()['then'](_0x482430=>_0x482430['removeAuthTokenListener'](_0x1e52bb));}['notifyForInvalidToken'](){let _0x847f1a='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x847f1a+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x847f1a+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x847f1a+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x847f1a);}}class an{constructor(_0x50d0e5){this['accessToken']=_0x50d0e5;}['getToken'](_0x2f7fd9){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5d34b9){_0x5d34b9(this['accessToken']);}['removeTokenChangeListener'](_0x2ea3ef){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4649cf,_0x22fc43,_0x3c741c,_0x1a3c7c,_0x4b3e5c=!0x1,_0x5dab3b='',_0x96fe6=!0x1,_0x3b7cab=!0x1,_0x166a6e=null){this['secure']=_0x22fc43,this['namespace']=_0x3c741c,this['webSocketOnly']=_0x1a3c7c,this['nodeAdmin']=_0x4b3e5c,this['persistenceKey']=_0x5dab3b,this['includeNamespaceInQueryParams']=_0x96fe6,this['isUsingEmulator']=_0x3b7cab,this['emulatorOptions']=_0x166a6e,this['_host']=_0x4649cf['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x4649cf)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1a93b6){_0x1a93b6!==this['internalHost']&&(this['internalHost']=_0x1a93b6,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3ea01e=this['toURLString']();return this['persistenceKey']&&(_0x3ea01e+='<'+this['persistenceKey']+'>'),_0x3ea01e;}['toURLString'](){const _0x38ada9=this['secure']?'https://':'http://',_0x5c31d2=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x38ada9+this['host']+'/'+_0x5c31d2;}}function th(_0x155cbd){return _0x155cbd['host']!==_0x155cbd['internalHost']||_0x155cbd['isCustomHost']()||_0x155cbd['includeNamespaceInQueryParams'];}function vo(_0x256c80,_0x2fd8b1,_0x335ef4){f(typeof _0x2fd8b1=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x335ef4=='object','typeof\x20params\x20must\x20==\x20object');let _0x36f801;if(_0x2fd8b1===go)_0x36f801=(_0x256c80['secure']?'wss://':'ws://')+_0x256c80['internalHost']+'/.ws?';else{if(_0x2fd8b1===mo)_0x36f801=(_0x256c80['secure']?'https://':'http://')+_0x256c80['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2fd8b1);}th(_0x256c80)&&(_0x335ef4['ns']=_0x256c80['namespace']);const _0x17a72a=[];return x(_0x335ef4,(_0x5ca02e,_0x5ca071)=>{_0x17a72a['push'](_0x5ca02e+'='+_0x5ca071);}),_0x36f801+_0x17a72a['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x326e2b,_0xe1af5e=0x1){Q(this['counters_'],_0x326e2b)||(this['counters_'][_0x326e2b]=0x0),this['counters_'][_0x326e2b]+=_0xe1af5e;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x179a1a){const _0x1e9345=_0x179a1a['toString']();return oi[_0x1e9345]||(oi[_0x1e9345]=new nh()),oi[_0x1e9345];}function ih(_0x4043c6,_0x2272c4){const _0x58a8f5=_0x4043c6['toString']();return ai[_0x58a8f5]||(ai[_0x58a8f5]=_0x2272c4()),ai[_0x58a8f5];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x47dcd0){this['onMessage_']=_0x47dcd0,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x41bf77,_0x4005a0){this['closeAfterResponse']=_0x41bf77,this['onClose']=_0x4005a0,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x37ae8c,_0x459db1){for(this['pendingResponses'][_0x37ae8c]=_0x459db1;this['pendingResponses'][this['currentResponseNum']];){const _0x5a31bc=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x44756e=0x0;_0x44756e<_0x5a31bc['length'];++_0x44756e)_0x5a31bc[_0x44756e]&&ft(()=>{this['onMessage_'](_0x5a31bc[_0x44756e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2767a3,_0x28c8b4,_0x31d5ec,_0xd1c6ca,_0x311f7a,_0xc38bd7,_0x2ef453){this['connId']=_0x2767a3,this['repoInfo']=_0x28c8b4,this['applicationId']=_0x31d5ec,this['appCheckToken']=_0xd1c6ca,this['authToken']=_0x311f7a,this['transportSessionId']=_0xc38bd7,this['lastSessionId']=_0x2ef453,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x2767a3),this['stats_']=qi(_0x28c8b4),this['urlFn']=_0xb47b4=>(this['appCheckToken']&&(_0xb47b4[wi]=this['appCheckToken']),vo(_0x28c8b4,mo,_0xb47b4));}['open'](_0x37af1d,_0x5883c4){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5883c4,this['myPacketOrderer']=new sh(_0x37af1d),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x2058ca)=>{const [_0x22f8f3,_0x556f33,_0x1a00e8,_0x552e60,_0x23bbdc]=_0x2058ca;if(this['incrementIncomingBytes_'](_0x2058ca),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x22f8f3===qs)this['id']=_0x556f33,this['password']=_0x1a00e8;else{if(_0x22f8f3===rh)_0x556f33?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x556f33,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x22f8f3);}}},(..._0x1f6c48)=>{const [_0x5d9991,_0x4f6bf3]=_0x1f6c48;this['incrementIncomingBytes_'](_0x1f6c48),this['myPacketOrderer']['handleResponse'](_0x5d9991,_0x4f6bf3);},()=>{this['onClosed_']();},this['urlFn']);const _0x2000d2={};_0x2000d2[qs]='t',_0x2000d2[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2000d2[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2000d2[co]=Gi,this['transportSessionId']&&(_0x2000d2[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x2000d2[po]=this['lastSessionId']),this['applicationId']&&(_0x2000d2[_o]=this['applicationId']),this['appCheckToken']&&(_0x2000d2[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2000d2[ho]=uo);const _0x14cd63=this['urlFn'](_0x2000d2);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x14cd63),this['scriptTagHolder']['addTag'](_0x14cd63,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1392d5){const _0x33487a=O(_0x1392d5);this['bytesSent']+=_0x33487a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x33487a['length']);const _0x161e9f=$r(_0x33487a),_0x60f694=oo(_0x161e9f,fh);for(let _0x1c16cb=0x0;_0x1c16cb<_0x60f694['length'];_0x1c16cb++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x60f694['length'],_0x60f694[_0x1c16cb]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5a69e7,_0x7fb9a9){this['myDisconnFrame']=document['createElement']('iframe');const _0x3329a0={};_0x3329a0[dh]='t',_0x3329a0[Eo]=_0x5a69e7,_0x3329a0[Io]=_0x7fb9a9,this['myDisconnFrame']['src']=this['urlFn'](_0x3329a0),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x333f6c){const _0x4fb447=O(_0x333f6c)['length'];this['bytesReceived']+=_0x4fb447,this['stats_']['incrementCounter']('bytes_received',_0x4fb447);}}class zi{constructor(_0x30e664,_0x4b474c,_0x2490d1,_0x2addff){this['onDisconnect']=_0x2490d1,this['urlFn']=_0x2addff,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x30e664,window[ah+this['uniqueCallbackIdentifier']]=_0x4b474c,this['myIFrame']=zi['createIFrame_']();let _0xa3146a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0xa3146a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x307d4b='<html><body>'+_0xa3146a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x307d4b),this['myIFrame']['doc']['close']();}catch(_0x5661de){L('frame\x20writing\x20exception'),_0x5661de['stack']&&L(_0x5661de['stack']),L(_0x5661de);}}}static['createIFrame_'](){const _0x30392d=document['createElement']('iframe');if(_0x30392d['style']['display']='none',document['body']){document['body']['appendChild'](_0x30392d);try{_0x30392d['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x61bb53=document['domain'];_0x30392d['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x61bb53+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x30392d['contentDocument']?_0x30392d['doc']=_0x30392d['contentDocument']:_0x30392d['contentWindow']?_0x30392d['doc']=_0x30392d['contentWindow']['document']:_0x30392d['document']&&(_0x30392d['doc']=_0x30392d['document']),_0x30392d;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x110f52=this['onDisconnect'];_0x110f52&&(this['onDisconnect']=null,_0x110f52());}['startLongPoll'](_0x464acf,_0x3e068d){for(this['myID']=_0x464acf,this['myPW']=_0x3e068d,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3c9b3a={};_0x3c9b3a[Eo]=this['myID'],_0x3c9b3a[Io]=this['myPW'],_0x3c9b3a[wo]=this['currentSerial'];let _0x2fa7c8=this['urlFn'](_0x3c9b3a),_0x554335='',_0x3e437e=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x554335['length']<=Co;){const _0x3eeebc=this['pendingSegs']['shift']();_0x554335=_0x554335+'&'+lh+_0x3e437e+'='+_0x3eeebc['seg']+'&'+hh+_0x3e437e+'='+_0x3eeebc['ts']+'&'+uh+_0x3e437e+'='+_0x3eeebc['d'],_0x3e437e++;}return _0x2fa7c8=_0x2fa7c8+_0x554335,this['addLongPollTag_'](_0x2fa7c8,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x570500,_0x13a995,_0x35ace7){this['pendingSegs']['push']({'seg':_0x570500,'ts':_0x13a995,'d':_0x35ace7}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x43f830,_0x108109){this['outstandingRequests']['add'](_0x108109);const _0x84d1ba=()=>{this['outstandingRequests']['delete'](_0x108109),this['newRequest_']();},_0x27c5a1=setTimeout(_0x84d1ba,Math['floor'](ph)),_0x258a61=()=>{clearTimeout(_0x27c5a1),_0x84d1ba();};this['addTag'](_0x43f830,_0x258a61);}['addTag'](_0x2756c9,_0x44c1a1){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5043f3=this['myIFrame']['doc']['createElement']('script');_0x5043f3['type']='text/javascript',_0x5043f3['async']=!0x0,_0x5043f3['src']=_0x2756c9,_0x5043f3['onload']=_0x5043f3['onreadystatechange']=function(){const _0x2bca5a=_0x5043f3['readyState'];(!_0x2bca5a||_0x2bca5a==='loaded'||_0x2bca5a==='complete')&&(_0x5043f3['onload']=_0x5043f3['onreadystatechange']=null,_0x5043f3['parentNode']&&_0x5043f3['parentNode']['removeChild'](_0x5043f3),_0x44c1a1());},_0x5043f3['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2756c9),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5043f3);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x215fdb,_0x15730a,_0xe27a11,_0x1a47de,_0x152633,_0xc907de,_0x45a6c0){this['connId']=_0x215fdb,this['applicationId']=_0xe27a11,this['appCheckToken']=_0x1a47de,this['authToken']=_0x152633,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0x15730a),this['connURL']=q['connectionURL_'](_0x15730a,_0xc907de,_0x45a6c0,_0x1a47de,_0xe27a11),this['nodeAdmin']=_0x15730a['nodeAdmin'];}static['connectionURL_'](_0x3d74da,_0x1c99e2,_0x2ed649,_0x3f12e2,_0x3f4170){const _0x1368a0={};return _0x1368a0[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1368a0[ho]=uo),_0x1c99e2&&(_0x1368a0[lo]=_0x1c99e2),_0x2ed649&&(_0x1368a0[po]=_0x2ed649),_0x3f12e2&&(_0x1368a0[wi]=_0x3f12e2),_0x3f4170&&(_0x1368a0[_o]=_0x3f4170),vo(_0x3d74da,go,_0x1368a0);}['open'](_0x14c351,_0x4ad00b){this['onDisconnect']=_0x4ad00b,this['onMessage']=_0x14c351,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x4e8881;_c(),this['mySock']=new gn(this['connURL'],[],_0x4e8881);}catch(_0x314ee1){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x53f9ec=_0x314ee1['message']||_0x314ee1['data'];_0x53f9ec&&this['log_'](_0x53f9ec),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x40029b=>{this['handleIncomingFrame'](_0x40029b);},this['mySock']['onerror']=_0x365b7b=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x11559c=_0x365b7b['message']||_0x365b7b['data'];_0x11559c&&this['log_'](_0x11559c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x278943=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x35006c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x22adf3=navigator['userAgent']['match'](_0x35006c);_0x22adf3&&_0x22adf3['length']>0x1&&parseFloat(_0x22adf3[0x1])<4.4&&(_0x278943=!0x0);}return!_0x278943&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4abbfb){if(this['frames']['push'](_0x4abbfb),this['frames']['length']===this['totalFrames']){const _0x3123ef=this['frames']['join']('');this['frames']=null;const _0x338261=Nt(_0x3123ef);this['onMessage'](_0x338261);}}['handleNewFrameCount_'](_0x4be559){this['totalFrames']=_0x4be559,this['frames']=[];}['extractFrameCount_'](_0xea2690){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xea2690['length']<=0x6){const _0x56047e=Number(_0xea2690);if(!isNaN(_0x56047e))return this['handleNewFrameCount_'](_0x56047e),null;}return this['handleNewFrameCount_'](0x1),_0xea2690;}['handleIncomingFrame'](_0x308eff){if(this['mySock']===null)return;const _0x204440=_0x308eff['data'];if(this['bytesReceived']+=_0x204440['length'],this['stats_']['incrementCounter']('bytes_received',_0x204440['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x204440);else{const _0x4de8b3=this['extractFrameCount_'](_0x204440);_0x4de8b3!==null&&this['appendFrame_'](_0x4de8b3);}}['send'](_0x1559ee){this['resetKeepAlive']();const _0x2fe312=O(_0x1559ee);this['bytesSent']+=_0x2fe312['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2fe312['length']);const _0x3a89fd=oo(_0x2fe312,gh);_0x3a89fd['length']>0x1&&this['sendString_'](String(_0x3a89fd['length']));for(let _0x49bb66=0x0;_0x49bb66<_0x3a89fd['length'];_0x49bb66++)this['sendString_'](_0x3a89fd[_0x49bb66]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2a0ffe){try{this['mySock']['send'](_0x2a0ffe);}catch(_0x1bbd8c){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1bbd8c['message']||_0x1bbd8c['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x511938){this['initTransports_'](_0x511938);}['initTransports_'](_0x2a640d){const _0x3ebe27=q&&q['isAvailable']();let _0x5c6f54=_0x3ebe27&&!q['previouslyFailed']();if(_0x2a640d['webSocketOnly']&&(_0x3ebe27||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5c6f54=!0x0),_0x5c6f54)this['transports_']=[q];else{const _0x524ddb=this['transports_']=[];for(const _0x5ba778 of Ot['ALL_TRANSPORTS'])_0x5ba778&&_0x5ba778['isAvailable']()&&_0x524ddb['push'](_0x5ba778);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x57a370,_0x1d20e9,_0x2aba1d,_0xed3a77,_0x18d754,_0x12d001,_0xca1496,_0x107856,_0x10a54e,_0x436855){this['id']=_0x57a370,this['repoInfo_']=_0x1d20e9,this['applicationId_']=_0x2aba1d,this['appCheckToken_']=_0xed3a77,this['authToken_']=_0x18d754,this['onMessage_']=_0x12d001,this['onReady_']=_0xca1496,this['onDisconnect_']=_0x107856,this['onKill_']=_0x10a54e,this['lastSessionId']=_0x436855,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x1d20e9),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4fb8a1=this['transportManager_']['initialTransport']();this['conn_']=new _0x4fb8a1(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4fb8a1['responsesRequiredToBeHealthy']||0x0;const _0x5c537c=this['connReceiver_'](this['conn_']),_0x311ea8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5c537c,_0x311ea8);},Math['floor'](0x0));const _0xb6903a=_0x4fb8a1['healthyTimeout']||0x0;_0xb6903a>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xb6903a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x448fb7){return _0x592624=>{_0x448fb7===this['conn_']?this['onConnectionLost_'](_0x592624):_0x448fb7===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x439d87){return _0x6fb385=>{this['state_']!==0x2&&(_0x439d87===this['rx_']?this['onPrimaryMessageReceived_'](_0x6fb385):_0x439d87===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x6fb385):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3c16df){const _0x558677={'t':'d','d':_0x3c16df};this['sendData_'](_0x558677);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4ff30c){if(ci in _0x4ff30c){const _0x2deac3=_0x4ff30c[ci];_0x2deac3===Ys?this['upgradeIfSecondaryHealthy_']():_0x2deac3===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2deac3===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4c04ad){const _0x35426c=yt('t',_0x4c04ad),_0x1168b1=yt('d',_0x4c04ad);if(_0x35426c==='c')this['onSecondaryControl_'](_0x1168b1);else{if(_0x35426c==='d')this['pendingDataMessages']['push'](_0x1168b1);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x35426c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x484def){const _0x2f7cce=yt('t',_0x484def),_0x29cc47=yt('d',_0x484def);_0x2f7cce==='c'?this['onControl_'](_0x29cc47):_0x2f7cce==='d'&&this['onDataMessage_'](_0x29cc47);}['onDataMessage_'](_0x101dae){this['onPrimaryResponse_'](),this['onMessage_'](_0x101dae);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1a3db2){const _0x100b6f=yt(ci,_0x1a3db2);if(zs in _0x1a3db2){const _0x35ae3d=_0x1a3db2[zs];if(_0x100b6f===Th){const _0x9f09cb={..._0x35ae3d};this['repoInfo_']['isUsingEmulator']&&(_0x9f09cb['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x9f09cb);}else{if(_0x100b6f===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xc722b3=0x0;_0xc722b3<this['pendingDataMessages']['length'];++_0xc722b3)this['onDataMessage_'](this['pendingDataMessages'][_0xc722b3]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x100b6f===wh?this['onConnectionShutdown_'](_0x35ae3d):_0x100b6f===js?this['onReset_'](_0x35ae3d):_0x100b6f===Ch?Ii('Server\x20Error:\x20'+_0x35ae3d):_0x100b6f===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x100b6f);}}}['onHandshake_'](_0x245c74){const _0x27bb45=_0x245c74['ts'],_0xd815da=_0x245c74['v'],_0x1879e5=_0x245c74['h'];this['sessionId']=_0x245c74['s'],this['repoInfo_']['host']=_0x1879e5,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x27bb45),Gi!==_0xd815da&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1ba98a=this['transportManager_']['upgradeTransport']();_0x1ba98a&&this['startUpgrade_'](_0x1ba98a);}['startUpgrade_'](_0x5278c6){this['secondaryConn_']=new _0x5278c6(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5278c6['responsesRequiredToBeHealthy']||0x0;const _0x5aeae2=this['connReceiver_'](this['secondaryConn_']),_0x37556c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5aeae2,_0x37556c),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x937e57){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x937e57),this['repoInfo_']['host']=_0x937e57,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x806bb3,_0x3d21ff){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x806bb3,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3d21ff,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x296741=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x296741||this['rx_']===_0x296741)&&this['close']();}['onConnectionLost_'](_0x2318d7){this['conn_']=null,!_0x2318d7&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5b8baa){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5b8baa),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x179197){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x179197);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x136d26,_0x3354e9,_0x23435b,_0x37a0cf){}['merge'](_0x524098,_0x2d17b6,_0xa32e1,_0x381c30){}['refreshAuthToken'](_0x39103c){}['refreshAppCheckToken'](_0x3d32dc){}['onDisconnectPut'](_0x162337,_0x264000,_0x52ab9b){}['onDisconnectMerge'](_0x4f137c,_0x3a68c6,_0xad3491){}['onDisconnectCancel'](_0x1f1e86,_0x1c0ed9){}['reportStats'](_0x5ce5bc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1321dd){this['allowedEvents_']=_0x1321dd,this['listeners_']={},f(Array['isArray'](_0x1321dd)&&_0x1321dd['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5a3efa,..._0x7e505){if(Array['isArray'](this['listeners_'][_0x5a3efa])){const _0x553785=[...this['listeners_'][_0x5a3efa]];for(let _0x3550c7=0x0;_0x3550c7<_0x553785['length'];_0x3550c7++)_0x553785[_0x3550c7]['callback']['apply'](_0x553785[_0x3550c7]['context'],_0x7e505);}}['on'](_0x5febd8,_0x332a96,_0x5428eb){this['validateEventType_'](_0x5febd8),this['listeners_'][_0x5febd8]=this['listeners_'][_0x5febd8]||[],this['listeners_'][_0x5febd8]['push']({'callback':_0x332a96,'context':_0x5428eb});const _0x166a4e=this['getInitialEvent'](_0x5febd8);_0x166a4e&&_0x332a96['apply'](_0x5428eb,_0x166a4e);}['off'](_0x4c677b,_0x21079f,_0x2ac8cc){this['validateEventType_'](_0x4c677b);const _0x1f6cc1=this['listeners_'][_0x4c677b]||[];for(let _0x34247b=0x0;_0x34247b<_0x1f6cc1['length'];_0x34247b++)if(_0x1f6cc1[_0x34247b]['callback']===_0x21079f&&(!_0x2ac8cc||_0x2ac8cc===_0x1f6cc1[_0x34247b]['context'])){_0x1f6cc1['splice'](_0x34247b,0x1);return;}}['validateEventType_'](_0x5729b2){f(this['allowedEvents_']['find'](_0x5c12d3=>_0x5c12d3===_0x5729b2),'Unknown\x20event:\x20'+_0x5729b2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x6ecb9f){return f(_0x6ecb9f==='online','Unknown\x20event\x20type:\x20'+_0x6ecb9f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x403077,_0x26c290){if(_0x26c290===void 0x0){this['pieces_']=_0x403077['split']('/');let _0xfce6e=0x0;for(let _0x38da36=0x0;_0x38da36<this['pieces_']['length'];_0x38da36++)this['pieces_'][_0x38da36]['length']>0x0&&(this['pieces_'][_0xfce6e]=this['pieces_'][_0x38da36],_0xfce6e++);this['pieces_']['length']=_0xfce6e,this['pieceNum_']=0x0;}else this['pieces_']=_0x403077,this['pieceNum_']=_0x26c290;}['toString'](){let _0x335f27='';for(let _0x1d610f=this['pieceNum_'];_0x1d610f<this['pieces_']['length'];_0x1d610f++)this['pieces_'][_0x1d610f]!==''&&(_0x335f27+='/'+this['pieces_'][_0x1d610f]);return _0x335f27||'/';}}function w(){return new C('');}function y(_0x4ecc39){return _0x4ecc39['pieceNum_']>=_0x4ecc39['pieces_']['length']?null:_0x4ecc39['pieces_'][_0x4ecc39['pieceNum_']];}function Ce(_0x1f7d86){return _0x1f7d86['pieces_']['length']-_0x1f7d86['pieceNum_'];}function S(_0x1ab6b2){let _0x106466=_0x1ab6b2['pieceNum_'];return _0x106466<_0x1ab6b2['pieces_']['length']&&_0x106466++,new C(_0x1ab6b2['pieces_'],_0x106466);}function ji(_0x3fe556){return _0x3fe556['pieceNum_']<_0x3fe556['pieces_']['length']?_0x3fe556['pieces_'][_0x3fe556['pieces_']['length']-0x1]:null;}function bh(_0x4ae8d5){let _0x56423b='';for(let _0x12b670=_0x4ae8d5['pieceNum_'];_0x12b670<_0x4ae8d5['pieces_']['length'];_0x12b670++)_0x4ae8d5['pieces_'][_0x12b670]!==''&&(_0x56423b+='/'+encodeURIComponent(String(_0x4ae8d5['pieces_'][_0x12b670])));return _0x56423b||'/';}function Dt(_0x1efd93,_0x5874eb=0x0){return _0x1efd93['pieces_']['slice'](_0x1efd93['pieceNum_']+_0x5874eb);}function Ro(_0x20e755){if(_0x20e755['pieceNum_']>=_0x20e755['pieces_']['length'])return null;const _0x396052=[];for(let _0x3f91f3=_0x20e755['pieceNum_'];_0x3f91f3<_0x20e755['pieces_']['length']-0x1;_0x3f91f3++)_0x396052['push'](_0x20e755['pieces_'][_0x3f91f3]);return new C(_0x396052,0x0);}function k(_0x5b0e29,_0x763fdd){const _0x447140=[];for(let _0x1cc06c=_0x5b0e29['pieceNum_'];_0x1cc06c<_0x5b0e29['pieces_']['length'];_0x1cc06c++)_0x447140['push'](_0x5b0e29['pieces_'][_0x1cc06c]);if(_0x763fdd instanceof C){for(let _0x3e2677=_0x763fdd['pieceNum_'];_0x3e2677<_0x763fdd['pieces_']['length'];_0x3e2677++)_0x447140['push'](_0x763fdd['pieces_'][_0x3e2677]);}else{const _0x28b22c=_0x763fdd['split']('/');for(let _0x205b6b=0x0;_0x205b6b<_0x28b22c['length'];_0x205b6b++)_0x28b22c[_0x205b6b]['length']>0x0&&_0x447140['push'](_0x28b22c[_0x205b6b]);}return new C(_0x447140,0x0);}function v(_0x221f50){return _0x221f50['pieceNum_']>=_0x221f50['pieces_']['length'];}function F(_0x29fe7f,_0x2c8f4d){const _0x4f7db2=y(_0x29fe7f),_0x5320e8=y(_0x2c8f4d);if(_0x4f7db2===null)return _0x2c8f4d;if(_0x4f7db2===_0x5320e8)return F(S(_0x29fe7f),S(_0x2c8f4d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2c8f4d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x29fe7f+')');}function Rh(_0x1d5bc1,_0x2fccd7){const _0x2d7cc0=Dt(_0x1d5bc1,0x0),_0x4d6e61=Dt(_0x2fccd7,0x0);for(let _0x1cb23c=0x0;_0x1cb23c<_0x2d7cc0['length']&&_0x1cb23c<_0x4d6e61['length'];_0x1cb23c++){const _0x559cbd=Ge(_0x2d7cc0[_0x1cb23c],_0x4d6e61[_0x1cb23c]);if(_0x559cbd!==0x0)return _0x559cbd;}return _0x2d7cc0['length']===_0x4d6e61['length']?0x0:_0x2d7cc0['length']<_0x4d6e61['length']?-0x1:0x1;}function Ki(_0x3f91ed,_0x41915f){if(Ce(_0x3f91ed)!==Ce(_0x41915f))return!0x1;for(let _0x511188=_0x3f91ed['pieceNum_'],_0x476aea=_0x41915f['pieceNum_'];_0x511188<=_0x3f91ed['pieces_']['length'];_0x511188++,_0x476aea++)if(_0x3f91ed['pieces_'][_0x511188]!==_0x41915f['pieces_'][_0x476aea])return!0x1;return!0x0;}function G(_0x55250c,_0x31d74e){let _0x3a724a=_0x55250c['pieceNum_'],_0xa25395=_0x31d74e['pieceNum_'];if(Ce(_0x55250c)>Ce(_0x31d74e))return!0x1;for(;_0x3a724a<_0x55250c['pieces_']['length'];){if(_0x55250c['pieces_'][_0x3a724a]!==_0x31d74e['pieces_'][_0xa25395])return!0x1;++_0x3a724a,++_0xa25395;}return!0x0;}class Ah{constructor(_0x5cefd0,_0x5aa496){this['errorPrefix_']=_0x5aa496,this['parts_']=Dt(_0x5cefd0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5d8b17=0x0;_0x5d8b17<this['parts_']['length'];_0x5d8b17++)this['byteLength_']+=Ln(this['parts_'][_0x5d8b17]);Ao(this);}}function kh(_0x42c055,_0x5358af){_0x42c055['parts_']['length']>0x0&&(_0x42c055['byteLength_']+=0x1),_0x42c055['parts_']['push'](_0x5358af),_0x42c055['byteLength_']+=Ln(_0x5358af),Ao(_0x42c055);}function Nh(_0x5c50e7){const _0x3e6125=_0x5c50e7['parts_']['pop']();_0x5c50e7['byteLength_']-=Ln(_0x3e6125),_0x5c50e7['parts_']['length']>0x0&&(_0x5c50e7['byteLength_']-=0x1);}function Ao(_0x27bd84){if(_0x27bd84['byteLength_']>Zs)throw new Error(_0x27bd84['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x27bd84['byteLength_']+').');if(_0x27bd84['parts_']['length']>Xs)throw new Error(_0x27bd84['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x27bd84));}function Pe(_0x3f1919){return _0x3f1919['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3f1919['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x2f994a,_0x459601;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x459601='visibilitychange',_0x2f994a='hidden'):typeof document['mozHidden']<'u'?(_0x459601='mozvisibilitychange',_0x2f994a='mozHidden'):typeof document['msHidden']<'u'?(_0x459601='msvisibilitychange',_0x2f994a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x459601='webkitvisibilitychange',_0x2f994a='webkitHidden')),this['visible_']=!0x0,_0x459601&&document['addEventListener'](_0x459601,()=>{const _0x2a63ab=!document[_0x2f994a];_0x2a63ab!==this['visible_']&&(this['visible_']=_0x2a63ab,this['trigger']('visible',_0x2a63ab));},!0x1);}['getInitialEvent'](_0x56ee4d){return f(_0x56ee4d==='visible','Unknown\x20event\x20type:\x20'+_0x56ee4d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2f4953,_0x1e2a0e,_0x4ccacf,_0x207117,_0x8885eb,_0x40b4ed,_0x162b79,_0x4c1919){if(super(),this['repoInfo_']=_0x2f4953,this['applicationId_']=_0x1e2a0e,this['onDataUpdate_']=_0x4ccacf,this['onConnectStatus_']=_0x207117,this['onServerInfoUpdate_']=_0x8885eb,this['authTokenProvider_']=_0x40b4ed,this['appCheckTokenProvider_']=_0x162b79,this['authOverride_']=_0x4c1919,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4c1919)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2f4953['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x40d4b2,_0x47451c,_0x3a8eb5){const _0x486be8=++this['requestNumber_'],_0x5083c8={'r':_0x486be8,'a':_0x40d4b2,'b':_0x47451c};this['log_'](O(_0x5083c8)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5083c8),_0x3a8eb5&&(this['requestCBHash_'][_0x486be8]=_0x3a8eb5);}['get'](_0x5b5d14){this['initConnection_']();const _0x35a80c=new H(),_0x2ef7d1={'action':'g','request':{'p':_0x5b5d14['_path']['toString'](),'q':_0x5b5d14['_queryObject']},'onComplete':_0x475cc1=>{const _0x4115e5=_0x475cc1['d'];_0x475cc1['s']==='ok'?_0x35a80c['resolve'](_0x4115e5):_0x35a80c['reject'](_0x4115e5);}};this['outstandingGets_']['push'](_0x2ef7d1),this['outstandingGetCount_']++;const _0x525384=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x525384),_0x35a80c['promise'];}['listen'](_0x537445,_0x3bc371,_0x242f0d,_0x2a971c){this['initConnection_']();const _0x2f96ab=_0x537445['_queryIdentifier'],_0x17c3d4=_0x537445['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x17c3d4+'\x20'+_0x2f96ab),this['listens']['has'](_0x17c3d4)||this['listens']['set'](_0x17c3d4,new Map()),f(_0x537445['_queryParams']['isDefault']()||!_0x537445['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x17c3d4)['has'](_0x2f96ab),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x29fc46={'onComplete':_0x2a971c,'hashFn':_0x3bc371,'query':_0x537445,'tag':_0x242f0d};this['listens']['get'](_0x17c3d4)['set'](_0x2f96ab,_0x29fc46),this['connected_']&&this['sendListen_'](_0x29fc46);}['sendGet_'](_0x1a2d34){const _0x51d651=this['outstandingGets_'][_0x1a2d34];this['sendRequest']('g',_0x51d651['request'],_0x376de9=>{delete this['outstandingGets_'][_0x1a2d34],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x51d651['onComplete']&&_0x51d651['onComplete'](_0x376de9);});}['sendListen_'](_0x57e523){const _0x5c20c8=_0x57e523['query'],_0x7f0674=_0x5c20c8['_path']['toString'](),_0x1b3459=_0x5c20c8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x7f0674+'\x20for\x20'+_0x1b3459);const _0x201354={'p':_0x7f0674},_0x3f0e10='q';_0x57e523['tag']&&(_0x201354['q']=_0x5c20c8['_queryObject'],_0x201354['t']=_0x57e523['tag']),_0x201354['h']=_0x57e523['hashFn'](),this['sendRequest'](_0x3f0e10,_0x201354,_0x5bbc04=>{const _0x4e6dba=_0x5bbc04['d'],_0xece07=_0x5bbc04['s'];se['warnOnListenWarnings_'](_0x4e6dba,_0x5c20c8),(this['listens']['get'](_0x7f0674)&&this['listens']['get'](_0x7f0674)['get'](_0x1b3459))===_0x57e523&&(this['log_']('listen\x20response',_0x5bbc04),_0xece07!=='ok'&&this['removeListen_'](_0x7f0674,_0x1b3459),_0x57e523['onComplete']&&_0x57e523['onComplete'](_0xece07,_0x4e6dba));});}static['warnOnListenWarnings_'](_0x192d46,_0x41bfc7){if(_0x192d46&&typeof _0x192d46=='object'&&Q(_0x192d46,'w')){const _0x266549=Me(_0x192d46,'w');if(Array['isArray'](_0x266549)&&~_0x266549['indexOf']('no_index')){const _0x30de3f='\x22.indexOn\x22:\x20\x22'+_0x41bfc7['_queryParams']['getIndex']()['toString']()+'\x22',_0x386883=_0x41bfc7['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x30de3f+'\x20at\x20'+_0x386883+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3eaa8e){this['authToken_']=_0x3eaa8e,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3eaa8e);}['reduceReconnectDelayIfAdminCredential_'](_0x4a52d5){(_0x4a52d5&&_0x4a52d5['length']===0x28||wc(_0x4a52d5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x1f45d7){this['appCheckToken_']=_0x1f45d7,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x29d0e2=this['authToken_'],_0x2fc5a9=Ic(_0x29d0e2)?'auth':'gauth',_0x8f7a3d={'cred':_0x29d0e2};this['authOverride_']===null?_0x8f7a3d['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x8f7a3d['authvar']=this['authOverride_']),this['sendRequest'](_0x2fc5a9,_0x8f7a3d,_0x4f6a54=>{const _0x14d5e1=_0x4f6a54['s'],_0xa18889=_0x4f6a54['d']||'error';this['authToken_']===_0x29d0e2&&(_0x14d5e1==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x14d5e1,_0xa18889));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x385c46=>{const _0x5411a1=_0x385c46['s'],_0x2e9f02=_0x385c46['d']||'error';_0x5411a1==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5411a1,_0x2e9f02);});}['unlisten'](_0x792cb8,_0x30b5d1){const _0x476a25=_0x792cb8['_path']['toString'](),_0x2c20c1=_0x792cb8['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x476a25+'\x20'+_0x2c20c1),f(_0x792cb8['_queryParams']['isDefault']()||!_0x792cb8['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x476a25,_0x2c20c1)&&this['connected_']&&this['sendUnlisten_'](_0x476a25,_0x2c20c1,_0x792cb8['_queryObject'],_0x30b5d1);}['sendUnlisten_'](_0x102cbd,_0x2df876,_0x48471e,_0x59a788){this['log_']('Unlisten\x20on\x20'+_0x102cbd+'\x20for\x20'+_0x2df876);const _0x389f18={'p':_0x102cbd},_0x2f7e86='n';_0x59a788&&(_0x389f18['q']=_0x48471e,_0x389f18['t']=_0x59a788),this['sendRequest'](_0x2f7e86,_0x389f18);}['onDisconnectPut'](_0x2bbd8e,_0x6202e6,_0x1c1c72){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2bbd8e,_0x6202e6,_0x1c1c72):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2bbd8e,'action':'o','data':_0x6202e6,'onComplete':_0x1c1c72});}['onDisconnectMerge'](_0x2a8d0e,_0x4ca780,_0x9e8cd7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2a8d0e,_0x4ca780,_0x9e8cd7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2a8d0e,'action':'om','data':_0x4ca780,'onComplete':_0x9e8cd7});}['onDisconnectCancel'](_0x54c3ba,_0xfc92d8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x54c3ba,null,_0xfc92d8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x54c3ba,'action':'oc','data':null,'onComplete':_0xfc92d8});}['sendOnDisconnect_'](_0x3ddb9f,_0x13a585,_0x3cf04e,_0x547606){const _0x592b25={'p':_0x13a585,'d':_0x3cf04e};this['log_']('onDisconnect\x20'+_0x3ddb9f,_0x592b25),this['sendRequest'](_0x3ddb9f,_0x592b25,_0xeb6617=>{_0x547606&&setTimeout(()=>{_0x547606(_0xeb6617['s'],_0xeb6617['d']);},Math['floor'](0x0));});}['put'](_0x17f0a0,_0x5a29a3,_0x5b3fbb,_0x3de926){this['putInternal']('p',_0x17f0a0,_0x5a29a3,_0x5b3fbb,_0x3de926);}['merge'](_0x5f03dc,_0x12cef0,_0x1855e7,_0x34f7be){this['putInternal']('m',_0x5f03dc,_0x12cef0,_0x1855e7,_0x34f7be);}['putInternal'](_0x25026f,_0x21c079,_0x255536,_0x28bdb8,_0x298678){this['initConnection_']();const _0x5e7d35={'p':_0x21c079,'d':_0x255536};_0x298678!==void 0x0&&(_0x5e7d35['h']=_0x298678),this['outstandingPuts_']['push']({'action':_0x25026f,'request':_0x5e7d35,'onComplete':_0x28bdb8}),this['outstandingPutCount_']++;const _0x587c57=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x587c57):this['log_']('Buffering\x20put:\x20'+_0x21c079);}['sendPut_'](_0x5694de){const _0x280a9f=this['outstandingPuts_'][_0x5694de]['action'],_0x584271=this['outstandingPuts_'][_0x5694de]['request'],_0x243dbb=this['outstandingPuts_'][_0x5694de]['onComplete'];this['outstandingPuts_'][_0x5694de]['queued']=this['connected_'],this['sendRequest'](_0x280a9f,_0x584271,_0x36c8b1=>{this['log_'](_0x280a9f+'\x20response',_0x36c8b1),delete this['outstandingPuts_'][_0x5694de],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x243dbb&&_0x243dbb(_0x36c8b1['s'],_0x36c8b1['d']);});}['reportStats'](_0x24d6e2){if(this['connected_']){const _0x20ca4f={'c':_0x24d6e2};this['log_']('reportStats',_0x20ca4f),this['sendRequest']('s',_0x20ca4f,_0xa8da08=>{if(_0xa8da08['s']!=='ok'){const _0x4cea53=_0xa8da08['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x4cea53);}});}}['onDataMessage_'](_0x38d46b){if('r'in _0x38d46b){this['log_']('from\x20server:\x20'+O(_0x38d46b));const _0x1944a7=_0x38d46b['r'],_0x4d5cec=this['requestCBHash_'][_0x1944a7];_0x4d5cec&&(delete this['requestCBHash_'][_0x1944a7],_0x4d5cec(_0x38d46b['b']));}else{if('error'in _0x38d46b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x38d46b['error'];'a'in _0x38d46b&&this['onDataPush_'](_0x38d46b['a'],_0x38d46b['b']);}}['onDataPush_'](_0x4f7c5f,_0x214857){this['log_']('handleServerMessage',_0x4f7c5f,_0x214857),_0x4f7c5f==='d'?this['onDataUpdate_'](_0x214857['p'],_0x214857['d'],!0x1,_0x214857['t']):_0x4f7c5f==='m'?this['onDataUpdate_'](_0x214857['p'],_0x214857['d'],!0x0,_0x214857['t']):_0x4f7c5f==='c'?this['onListenRevoked_'](_0x214857['p'],_0x214857['q']):_0x4f7c5f==='ac'?this['onAuthRevoked_'](_0x214857['s'],_0x214857['d']):_0x4f7c5f==='apc'?this['onAppCheckRevoked_'](_0x214857['s'],_0x214857['d']):_0x4f7c5f==='sd'?this['onSecurityDebugPacket_'](_0x214857):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4f7c5f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2c5777,_0x238699){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2c5777),this['lastSessionId']=_0x238699,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3592c2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3592c2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x284fe0){_0x284fe0&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x284fe0;}['onOnline_'](_0x2153ac){_0x2153ac?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x43ce43=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x345b60=Math['max'](0x0,this['reconnectDelay_']-_0x43ce43);_0x345b60=Math['random']()*_0x345b60,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x345b60+'ms'),this['scheduleConnect_'](_0x345b60),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x320fba=this['onDataMessage_']['bind'](this),_0x5cf57c=this['onReady_']['bind'](this),_0x1485b9=this['onRealtimeDisconnect_']['bind'](this),_0x496906=this['id']+':'+se['nextConnectionId_']++,_0x47257b=this['lastSessionId'];let _0x5b7e82=!0x1,_0x4349d3=null;const _0x54accd=function(){_0x4349d3?_0x4349d3['close']():(_0x5b7e82=!0x0,_0x1485b9());},_0x5b4deb=function(_0x546a21){f(_0x4349d3,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4349d3['sendRequest'](_0x546a21);};this['realtime_']={'close':_0x54accd,'sendRequest':_0x5b4deb};const _0x31ca7c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x504259,_0x44c3a9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x31ca7c),this['appCheckTokenProvider_']['getToken'](_0x31ca7c)]);_0x5b7e82?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x504259&&_0x504259['accessToken'],this['appCheckToken_']=_0x44c3a9&&_0x44c3a9['token'],_0x4349d3=new Sh(_0x496906,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x320fba,_0x5cf57c,_0x1485b9,_0x55ad80=>{U(_0x55ad80+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x47257b));}catch(_0x439ba3){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x439ba3),_0x5b7e82||(this['repoInfo_']['nodeAdmin']&&U(_0x439ba3),_0x54accd());}}}['interrupt'](_0x463e69){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x463e69),this['interruptReasons_'][_0x463e69]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x217308){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x217308),delete this['interruptReasons_'][_0x217308],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5e8626){const _0x4a312d=_0x5e8626-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4a312d});}['cancelSentTransactions_'](){for(let _0x2edea6=0x0;_0x2edea6<this['outstandingPuts_']['length'];_0x2edea6++){const _0xdb9185=this['outstandingPuts_'][_0x2edea6];_0xdb9185&&'h'in _0xdb9185['request']&&_0xdb9185['queued']&&(_0xdb9185['onComplete']&&_0xdb9185['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2edea6],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4e045b,_0x7578e8){let _0x5e2771;_0x7578e8?_0x5e2771=_0x7578e8['map'](_0x36a8ae=>$i(_0x36a8ae))['join']('$'):_0x5e2771='default';const _0x4a0fd8=this['removeListen_'](_0x4e045b,_0x5e2771);_0x4a0fd8&&_0x4a0fd8['onComplete']&&_0x4a0fd8['onComplete']('permission_denied');}['removeListen_'](_0x217cae,_0x34fccb){const _0xc0cd89=new C(_0x217cae)['toString']();let _0x576406;if(this['listens']['has'](_0xc0cd89)){const _0x545bc9=this['listens']['get'](_0xc0cd89);_0x576406=_0x545bc9['get'](_0x34fccb),_0x545bc9['delete'](_0x34fccb),_0x545bc9['size']===0x0&&this['listens']['delete'](_0xc0cd89);}else _0x576406=void 0x0;return _0x576406;}['onAuthRevoked_'](_0x6c8dab,_0x1ee931){L('Auth\x20token\x20revoked:\x20'+_0x6c8dab+'/'+_0x1ee931),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x6c8dab==='invalid_token'||_0x6c8dab==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3e4ff0,_0x555eb6){L('App\x20check\x20token\x20revoked:\x20'+_0x3e4ff0+'/'+_0x555eb6),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3e4ff0==='invalid_token'||_0x3e4ff0==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x269475){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x269475):'msg'in _0x269475&&console['log']('FIREBASE:\x20'+_0x269475['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5c420b of this['listens']['values']())for(const _0x12e2ff of _0x5c420b['values']())this['sendListen_'](_0x12e2ff);for(let _0x7b661b=0x0;_0x7b661b<this['outstandingPuts_']['length'];_0x7b661b++)this['outstandingPuts_'][_0x7b661b]&&this['sendPut_'](_0x7b661b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x285321=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x285321['action'],_0x285321['pathString'],_0x285321['data'],_0x285321['onComplete']);}for(let _0x2ecb50=0x0;_0x2ecb50<this['outstandingGets_']['length'];_0x2ecb50++)this['outstandingGets_'][_0x2ecb50]&&this['sendGet_'](_0x2ecb50);}['sendConnectStats_'](){const _0x7a56eb={};let _0x23e17='js';_0x7a56eb['sdk.'+_0x23e17+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x7a56eb['framework.cordova']=0x1:Kr()&&(_0x7a56eb['framework.reactnative']=0x1),this['reportStats'](_0x7a56eb);}['shouldReconnect_'](){const _0x15823f=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x15823f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4780cc,_0x27a6f5){this['name']=_0x4780cc,this['node']=_0x27a6f5;}static['Wrap'](_0x29d6b2,_0x1f980d){return new E(_0x29d6b2,_0x1f980d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x812553,_0x6e3865){const _0x373fee=new E(Ue,_0x812553),_0x2386af=new E(Ue,_0x6e3865);return this['compare'](_0x373fee,_0x2386af)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5d3ebf){sn=_0x5d3ebf;}['compare'](_0x27f957,_0x368b83){return Ge(_0x27f957['name'],_0x368b83['name']);}['isDefinedOn'](_0xcb234e){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x43921d,_0x1dd6bd){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x1615ce,_0x26fe11){return f(typeof _0x1615ce=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1615ce,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x443864,_0x3150c5,_0x3d31c6,_0x330aa7,_0x59e369=null){this['isReverse_']=_0x330aa7,this['resultGenerator_']=_0x59e369,this['nodeStack_']=[];let _0x29ea1d=0x1;for(;!_0x443864['isEmpty']();)if(_0x443864=_0x443864,_0x29ea1d=_0x3150c5?_0x3d31c6(_0x443864['key'],_0x3150c5):0x1,_0x330aa7&&(_0x29ea1d*=-0x1),_0x29ea1d<0x0)this['isReverse_']?_0x443864=_0x443864['left']:_0x443864=_0x443864['right'];else{if(_0x29ea1d===0x0){this['nodeStack_']['push'](_0x443864);break;}else this['nodeStack_']['push'](_0x443864),this['isReverse_']?_0x443864=_0x443864['right']:_0x443864=_0x443864['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x57359c=this['nodeStack_']['pop'](),_0x47db9e;if(this['resultGenerator_']?_0x47db9e=this['resultGenerator_'](_0x57359c['key'],_0x57359c['value']):_0x47db9e={'key':_0x57359c['key'],'value':_0x57359c['value']},this['isReverse_']){for(_0x57359c=_0x57359c['left'];!_0x57359c['isEmpty']();)this['nodeStack_']['push'](_0x57359c),_0x57359c=_0x57359c['right'];}else{for(_0x57359c=_0x57359c['right'];!_0x57359c['isEmpty']();)this['nodeStack_']['push'](_0x57359c),_0x57359c=_0x57359c['left'];}return _0x47db9e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4ac3e1=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4ac3e1['key'],_0x4ac3e1['value']):{'key':_0x4ac3e1['key'],'value':_0x4ac3e1['value']};}}class M{constructor(_0x95a31b,_0x5ac39d,_0x42ea36,_0x301045,_0x411cba){this['key']=_0x95a31b,this['value']=_0x5ac39d,this['color']=_0x42ea36??M['RED'],this['left']=_0x301045??B['EMPTY_NODE'],this['right']=_0x411cba??B['EMPTY_NODE'];}['copy'](_0x569b50,_0x24991a,_0x52858c,_0xe3816,_0x2421e0){return new M(_0x569b50??this['key'],_0x24991a??this['value'],_0x52858c??this['color'],_0xe3816??this['left'],_0x2421e0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3d069f){return this['left']['inorderTraversal'](_0x3d069f)||!!_0x3d069f(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3d069f);}['reverseTraversal'](_0x29f4d6){return this['right']['reverseTraversal'](_0x29f4d6)||_0x29f4d6(this['key'],this['value'])||this['left']['reverseTraversal'](_0x29f4d6);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5b1be7,_0x4f5a3,_0x3427d1){let _0x6b306d=this;const _0x3e5ff4=_0x3427d1(_0x5b1be7,_0x6b306d['key']);return _0x3e5ff4<0x0?_0x6b306d=_0x6b306d['copy'](null,null,null,_0x6b306d['left']['insert'](_0x5b1be7,_0x4f5a3,_0x3427d1),null):_0x3e5ff4===0x0?_0x6b306d=_0x6b306d['copy'](null,_0x4f5a3,null,null,null):_0x6b306d=_0x6b306d['copy'](null,null,null,null,_0x6b306d['right']['insert'](_0x5b1be7,_0x4f5a3,_0x3427d1)),_0x6b306d['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x12f07d=this;return!_0x12f07d['left']['isRed_']()&&!_0x12f07d['left']['left']['isRed_']()&&(_0x12f07d=_0x12f07d['moveRedLeft_']()),_0x12f07d=_0x12f07d['copy'](null,null,null,_0x12f07d['left']['removeMin_'](),null),_0x12f07d['fixUp_']();}['remove'](_0x39a3a7,_0xb54c3e){let _0x5eae68,_0x4eb306;if(_0x5eae68=this,_0xb54c3e(_0x39a3a7,_0x5eae68['key'])<0x0)!_0x5eae68['left']['isEmpty']()&&!_0x5eae68['left']['isRed_']()&&!_0x5eae68['left']['left']['isRed_']()&&(_0x5eae68=_0x5eae68['moveRedLeft_']()),_0x5eae68=_0x5eae68['copy'](null,null,null,_0x5eae68['left']['remove'](_0x39a3a7,_0xb54c3e),null);else{if(_0x5eae68['left']['isRed_']()&&(_0x5eae68=_0x5eae68['rotateRight_']()),!_0x5eae68['right']['isEmpty']()&&!_0x5eae68['right']['isRed_']()&&!_0x5eae68['right']['left']['isRed_']()&&(_0x5eae68=_0x5eae68['moveRedRight_']()),_0xb54c3e(_0x39a3a7,_0x5eae68['key'])===0x0){if(_0x5eae68['right']['isEmpty']())return B['EMPTY_NODE'];_0x4eb306=_0x5eae68['right']['min_'](),_0x5eae68=_0x5eae68['copy'](_0x4eb306['key'],_0x4eb306['value'],null,null,_0x5eae68['right']['removeMin_']());}_0x5eae68=_0x5eae68['copy'](null,null,null,null,_0x5eae68['right']['remove'](_0x39a3a7,_0xb54c3e));}return _0x5eae68['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x458f71=this;return _0x458f71['right']['isRed_']()&&!_0x458f71['left']['isRed_']()&&(_0x458f71=_0x458f71['rotateLeft_']()),_0x458f71['left']['isRed_']()&&_0x458f71['left']['left']['isRed_']()&&(_0x458f71=_0x458f71['rotateRight_']()),_0x458f71['left']['isRed_']()&&_0x458f71['right']['isRed_']()&&(_0x458f71=_0x458f71['colorFlip_']()),_0x458f71;}['moveRedLeft_'](){let _0x32e380=this['colorFlip_']();return _0x32e380['right']['left']['isRed_']()&&(_0x32e380=_0x32e380['copy'](null,null,null,null,_0x32e380['right']['rotateRight_']()),_0x32e380=_0x32e380['rotateLeft_'](),_0x32e380=_0x32e380['colorFlip_']()),_0x32e380;}['moveRedRight_'](){let _0x5c66cb=this['colorFlip_']();return _0x5c66cb['left']['left']['isRed_']()&&(_0x5c66cb=_0x5c66cb['rotateRight_'](),_0x5c66cb=_0x5c66cb['colorFlip_']()),_0x5c66cb;}['rotateLeft_'](){const _0x346bfb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x346bfb,null);}['rotateRight_'](){const _0x56c08c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x56c08c);}['colorFlip_'](){const _0x1971ff=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x49dd42=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1971ff,_0x49dd42);}['checkMaxDepth_'](){const _0x15318d=this['check_']();return Math['pow'](0x2,_0x15318d)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xb1cc40=this['left']['check_']();if(_0xb1cc40!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xb1cc40+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5887,_0x5984e0,_0x2663f3,_0x3d115d,_0x1065bf){return this;}['insert'](_0x7ce8dd,_0x488667,_0x1e14b2){return new M(_0x7ce8dd,_0x488667,null);}['remove'](_0x1b9254,_0xda80ac){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1d8b08){return!0x1;}['reverseTraversal'](_0x2e8b07){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x364a91,_0x49db54=B['EMPTY_NODE']){this['comparator_']=_0x364a91,this['root_']=_0x49db54;}['insert'](_0xb33cc5,_0x1a172b){return new B(this['comparator_'],this['root_']['insert'](_0xb33cc5,_0x1a172b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x113f90){return new B(this['comparator_'],this['root_']['remove'](_0x113f90,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x6db2f7){let _0x5cb88f,_0x276327=this['root_'];for(;!_0x276327['isEmpty']();){if(_0x5cb88f=this['comparator_'](_0x6db2f7,_0x276327['key']),_0x5cb88f===0x0)return _0x276327['value'];_0x5cb88f<0x0?_0x276327=_0x276327['left']:_0x5cb88f>0x0&&(_0x276327=_0x276327['right']);}return null;}['getPredecessorKey'](_0x2adb64){let _0xfc45ff,_0x110bba=this['root_'],_0x585d98=null;for(;!_0x110bba['isEmpty']();)if(_0xfc45ff=this['comparator_'](_0x2adb64,_0x110bba['key']),_0xfc45ff===0x0){if(_0x110bba['left']['isEmpty']())return _0x585d98?_0x585d98['key']:null;for(_0x110bba=_0x110bba['left'];!_0x110bba['right']['isEmpty']();)_0x110bba=_0x110bba['right'];return _0x110bba['key'];}else _0xfc45ff<0x0?_0x110bba=_0x110bba['left']:_0xfc45ff>0x0&&(_0x585d98=_0x110bba,_0x110bba=_0x110bba['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x46e32a){return this['root_']['inorderTraversal'](_0x46e32a);}['reverseTraversal'](_0x465498){return this['root_']['reverseTraversal'](_0x465498);}['getIterator'](_0x1ac931){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x1ac931);}['getIteratorFrom'](_0x4fe0d0,_0x1d1360){return new rn(this['root_'],_0x4fe0d0,this['comparator_'],!0x1,_0x1d1360);}['getReverseIteratorFrom'](_0x42333c,_0x21fd1e){return new rn(this['root_'],_0x42333c,this['comparator_'],!0x0,_0x21fd1e);}['getReverseIterator'](_0x33cff4){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x33cff4);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x497825,_0x124bc8){return Ge(_0x497825['name'],_0x124bc8['name']);}function Qi(_0xac6845,_0x321aa0){return Ge(_0xac6845,_0x321aa0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x5d143a){Ci=_0x5d143a;}const No=function(_0x22767f){return typeof _0x22767f=='number'?'number:'+ao(_0x22767f):'string:'+_0x22767f;},Po=function(_0x2dbfc0){if(_0x2dbfc0['isLeafNode']()){const _0x4ee672=_0x2dbfc0['val']();f(typeof _0x4ee672=='string'||typeof _0x4ee672=='number'||typeof _0x4ee672=='object'&&Q(_0x4ee672,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2dbfc0===Ci||_0x2dbfc0['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2dbfc0===Ci||_0x2dbfc0['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1aa9dc){nr=_0x1aa9dc;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x52ebac,_0x336d92=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x52ebac,this['priorityNode_']=_0x336d92,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x2dfe00){return new D(this['value_'],_0x2dfe00);}['getImmediateChild'](_0x278c05){return _0x278c05==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x317737){return v(_0x317737)?this:y(_0x317737)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5a3d12,_0x24f79d){return null;}['updateImmediateChild'](_0x2db896,_0x151919){return _0x2db896==='.priority'?this['updatePriority'](_0x151919):_0x151919['isEmpty']()&&_0x2db896!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2db896,_0x151919)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x57affa,_0x817a87){const _0x5395b7=y(_0x57affa);return _0x5395b7===null?_0x817a87:_0x817a87['isEmpty']()&&_0x5395b7!=='.priority'?this:(f(_0x5395b7!=='.priority'||Ce(_0x57affa)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x5395b7,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x57affa),_0x817a87)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x482b3f,_0xe9a05b){return!0x1;}['val'](_0x1a0d3d){return _0x1a0d3d&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x408c78='';this['priorityNode_']['isEmpty']()||(_0x408c78+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1633d6=typeof this['value_'];_0x408c78+=_0x1633d6+':',_0x1633d6==='number'?_0x408c78+=ao(this['value_']):_0x408c78+=this['value_'],this['lazyHash_']=ro(_0x408c78);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xdebaa9){return _0xdebaa9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xdebaa9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xdebaa9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xdebaa9));}['compareToLeafNode_'](_0x31b65e){const _0x3aca9f=typeof _0x31b65e['value_'],_0x3f6339=typeof this['value_'],_0x277d46=D['VALUE_TYPE_ORDER']['indexOf'](_0x3aca9f),_0xfd3fd0=D['VALUE_TYPE_ORDER']['indexOf'](_0x3f6339);return f(_0x277d46>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3aca9f),f(_0xfd3fd0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3f6339),_0x277d46===_0xfd3fd0?_0x3f6339==='object'?0x0:this['value_']<_0x31b65e['value_']?-0x1:this['value_']===_0x31b65e['value_']?0x0:0x1:_0xfd3fd0-_0x277d46;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4cb5e0){if(_0x4cb5e0===this)return!0x0;if(_0x4cb5e0['isLeafNode']()){const _0x3483cb=_0x4cb5e0;return this['value_']===_0x3483cb['value_']&&this['priorityNode_']['equals'](_0x3483cb['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2c634f){Oo=_0x2c634f;}function Wh(_0x37cbe9){Do=_0x37cbe9;}class Bh extends Fn{['compare'](_0x23b600,_0xad2646){const _0x28cbd1=_0x23b600['node']['getPriority'](),_0x55b731=_0xad2646['node']['getPriority'](),_0x99b8ef=_0x28cbd1['compareTo'](_0x55b731);return _0x99b8ef===0x0?Ge(_0x23b600['name'],_0xad2646['name']):_0x99b8ef;}['isDefinedOn'](_0x3ac334){return!_0x3ac334['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x248abd,_0x442e0e){return!_0x248abd['getPriority']()['equals'](_0x442e0e['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x46c22f,_0x15cf69){const _0x39bd28=Oo(_0x46c22f);return new E(_0x15cf69,new D('[PRIORITY-POST]',_0x39bd28));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3e9fcf){const _0x3ff651=_0x3169b1=>parseInt(Math['log'](_0x3169b1)/Vh,0xa),_0x44c8e1=_0x3178e6=>parseInt(Array(_0x3178e6+0x1)['join']('1'),0x2);this['count']=_0x3ff651(_0x3e9fcf+0x1),this['current_']=this['count']-0x1;const _0x5f4977=_0x44c8e1(this['count']);this['bits_']=_0x3e9fcf+0x1&_0x5f4977;}['nextBitIsOne'](){const _0x4c2f37=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4c2f37;}}const yn=function(_0x3718f9,_0x401bc6,_0x962660,_0x5d4af1){_0x3718f9['sort'](_0x401bc6);const _0x20ae19=function(_0xdd7763,_0x195845){const _0x133546=_0x195845-_0xdd7763;let _0x21ad86,_0x2bc01b;if(_0x133546===0x0)return null;if(_0x133546===0x1)return _0x21ad86=_0x3718f9[_0xdd7763],_0x2bc01b=_0x962660?_0x962660(_0x21ad86):_0x21ad86,new M(_0x2bc01b,_0x21ad86['node'],M['BLACK'],null,null);{const _0x1336c3=parseInt(_0x133546/0x2,0xa)+_0xdd7763,_0x3b7e8b=_0x20ae19(_0xdd7763,_0x1336c3),_0x18052e=_0x20ae19(_0x1336c3+0x1,_0x195845);return _0x21ad86=_0x3718f9[_0x1336c3],_0x2bc01b=_0x962660?_0x962660(_0x21ad86):_0x21ad86,new M(_0x2bc01b,_0x21ad86['node'],M['BLACK'],_0x3b7e8b,_0x18052e);}},_0x528eb7=function(_0x42f6b1){let _0xb284db=null,_0x53e69a=null,_0x4beee9=_0x3718f9['length'];const _0x1e1810=function(_0x489094,_0xb7cd3a){const _0x5a1c03=_0x4beee9-_0x489094,_0x5f7815=_0x4beee9;_0x4beee9-=_0x489094;const _0x542cdf=_0x20ae19(_0x5a1c03+0x1,_0x5f7815),_0x1b15d3=_0x3718f9[_0x5a1c03],_0x561348=_0x962660?_0x962660(_0x1b15d3):_0x1b15d3;_0x49bb29(new M(_0x561348,_0x1b15d3['node'],_0xb7cd3a,null,_0x542cdf));},_0x49bb29=function(_0x4e1bb5){_0xb284db?(_0xb284db['left']=_0x4e1bb5,_0xb284db=_0x4e1bb5):(_0x53e69a=_0x4e1bb5,_0xb284db=_0x4e1bb5);};for(let _0x1416a1=0x0;_0x1416a1<_0x42f6b1['count'];++_0x1416a1){const _0x4522d3=_0x42f6b1['nextBitIsOne'](),_0x1d4578=Math['pow'](0x2,_0x42f6b1['count']-(_0x1416a1+0x1));_0x4522d3?_0x1e1810(_0x1d4578,M['BLACK']):(_0x1e1810(_0x1d4578,M['BLACK']),_0x1e1810(_0x1d4578,M['RED']));}return _0x53e69a;},_0x18a0b0=new Hh(_0x3718f9['length']),_0x3c3243=_0x528eb7(_0x18a0b0);return new B(_0x5d4af1||_0x401bc6,_0x3c3243);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x6ffc39,_0x279344){this['indexes_']=_0x6ffc39,this['indexSet_']=_0x279344;}['get'](_0x5737c5){const _0x381520=Me(this['indexes_'],_0x5737c5);if(!_0x381520)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5737c5);return _0x381520 instanceof B?_0x381520:null;}['hasIndex'](_0x70c981){return Q(this['indexSet_'],_0x70c981['toString']());}['addIndex'](_0xb44ddd,_0x1297a2){f(_0xb44ddd!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1c1461=[];let _0x5be0e4=!0x1;const _0x2d473f=_0x1297a2['getIterator'](E['Wrap']);let _0x32a397=_0x2d473f['getNext']();for(;_0x32a397;)_0x5be0e4=_0x5be0e4||_0xb44ddd['isDefinedOn'](_0x32a397['node']),_0x1c1461['push'](_0x32a397),_0x32a397=_0x2d473f['getNext']();let _0x1bf770;_0x5be0e4?_0x1bf770=yn(_0x1c1461,_0xb44ddd['getCompare']()):_0x1bf770=Qe;const _0x4272a6=_0xb44ddd['toString'](),_0x197799={...this['indexSet_']};_0x197799[_0x4272a6]=_0xb44ddd;const _0x31aa0c={...this['indexes_']};return _0x31aa0c[_0x4272a6]=_0x1bf770,new te(_0x31aa0c,_0x197799);}['addToIndexes'](_0x265c9a,_0x575c78){const _0x12aeea=_n(this['indexes_'],(_0x312481,_0x64e5a)=>{const _0x10dae2=Me(this['indexSet_'],_0x64e5a);if(f(_0x10dae2,'Missing\x20index\x20implementation\x20for\x20'+_0x64e5a),_0x312481===Qe){if(_0x10dae2['isDefinedOn'](_0x265c9a['node'])){const _0x4aa4c0=[],_0x4dfe31=_0x575c78['getIterator'](E['Wrap']);let _0x21a82c=_0x4dfe31['getNext']();for(;_0x21a82c;)_0x21a82c['name']!==_0x265c9a['name']&&_0x4aa4c0['push'](_0x21a82c),_0x21a82c=_0x4dfe31['getNext']();return _0x4aa4c0['push'](_0x265c9a),yn(_0x4aa4c0,_0x10dae2['getCompare']());}else return Qe;}else{const _0x96b7c3=_0x575c78['get'](_0x265c9a['name']);let _0x13c997=_0x312481;return _0x96b7c3&&(_0x13c997=_0x13c997['remove'](new E(_0x265c9a['name'],_0x96b7c3))),_0x13c997['insert'](_0x265c9a,_0x265c9a['node']);}});return new te(_0x12aeea,this['indexSet_']);}['removeFromIndexes'](_0x419291,_0x25c283){const _0x346871=_n(this['indexes_'],_0x456268=>{if(_0x456268===Qe)return _0x456268;{const _0x39679e=_0x25c283['get'](_0x419291['name']);return _0x39679e?_0x456268['remove'](new E(_0x419291['name'],_0x39679e)):_0x456268;}});return new te(_0x346871,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x280869,_0x6a46f8,_0x2a316f){this['children_']=_0x280869,this['priorityNode_']=_0x6a46f8,this['indexMap_']=_0x2a316f,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x12d38c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x12d38c,this['indexMap_']);}['getImmediateChild'](_0x406bac){if(_0x406bac==='.priority')return this['getPriority']();{const _0x25542d=this['children_']['get'](_0x406bac);return _0x25542d===null?Et:_0x25542d;}}['getChild'](_0x413f8b){const _0xd14318=y(_0x413f8b);return _0xd14318===null?this:this['getImmediateChild'](_0xd14318)['getChild'](S(_0x413f8b));}['hasChild'](_0x5b6fb8){return this['children_']['get'](_0x5b6fb8)!==null;}['updateImmediateChild'](_0x529092,_0x4292c8){if(f(_0x4292c8,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x529092==='.priority')return this['updatePriority'](_0x4292c8);{const _0x43bbef=new E(_0x529092,_0x4292c8);let _0x4d35c6,_0x132322;_0x4292c8['isEmpty']()?(_0x4d35c6=this['children_']['remove'](_0x529092),_0x132322=this['indexMap_']['removeFromIndexes'](_0x43bbef,this['children_'])):(_0x4d35c6=this['children_']['insert'](_0x529092,_0x4292c8),_0x132322=this['indexMap_']['addToIndexes'](_0x43bbef,this['children_']));const _0x258472=_0x4d35c6['isEmpty']()?Et:this['priorityNode_'];return new g(_0x4d35c6,_0x258472,_0x132322);}}['updateChild'](_0x2976d5,_0x1b70e2){const _0x29d474=y(_0x2976d5);if(_0x29d474===null)return _0x1b70e2;{f(y(_0x2976d5)!=='.priority'||Ce(_0x2976d5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x55b14f=this['getImmediateChild'](_0x29d474)['updateChild'](S(_0x2976d5),_0x1b70e2);return this['updateImmediateChild'](_0x29d474,_0x55b14f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1d1920){if(this['isEmpty']())return null;const _0x5bbb30={};let _0x371276=0x0,_0x49d048=0x0,_0x50a666=!0x0;if(this['forEachChild'](R,(_0x591f10,_0xef77f0)=>{_0x5bbb30[_0x591f10]=_0xef77f0['val'](_0x1d1920),_0x371276++,_0x50a666&&g['INTEGER_REGEXP_']['test'](_0x591f10)?_0x49d048=Math['max'](_0x49d048,Number(_0x591f10)):_0x50a666=!0x1;}),!_0x1d1920&&_0x50a666&&_0x49d048<0x2*_0x371276){const _0x281143=[];for(const _0x4cc07f in _0x5bbb30)_0x281143[_0x4cc07f]=_0x5bbb30[_0x4cc07f];return _0x281143;}else return _0x1d1920&&!this['getPriority']()['isEmpty']()&&(_0x5bbb30['.priority']=this['getPriority']()['val']()),_0x5bbb30;}['hash'](){if(this['lazyHash_']===null){let _0x48d29f='';this['getPriority']()['isEmpty']()||(_0x48d29f+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5a21ab,_0x46ea89)=>{const _0x592b72=_0x46ea89['hash']();_0x592b72!==''&&(_0x48d29f+=':'+_0x5a21ab+':'+_0x592b72);}),this['lazyHash_']=_0x48d29f===''?'':ro(_0x48d29f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3161cc,_0x38ceec,_0x444fbe){const _0x1d20bb=this['resolveIndex_'](_0x444fbe);if(_0x1d20bb){const _0x5658f5=_0x1d20bb['getPredecessorKey'](new E(_0x3161cc,_0x38ceec));return _0x5658f5?_0x5658f5['name']:null;}else return this['children_']['getPredecessorKey'](_0x3161cc);}['getFirstChildName'](_0x452d12){const _0xe1593e=this['resolveIndex_'](_0x452d12);if(_0xe1593e){const _0x156d17=_0xe1593e['minKey']();return _0x156d17&&_0x156d17['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x27e6a0){const _0x35e4ba=this['getFirstChildName'](_0x27e6a0);return _0x35e4ba?new E(_0x35e4ba,this['children_']['get'](_0x35e4ba)):null;}['getLastChildName'](_0x1130d8){const _0x50d57d=this['resolveIndex_'](_0x1130d8);if(_0x50d57d){const _0x4f946e=_0x50d57d['maxKey']();return _0x4f946e&&_0x4f946e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xb687a1){const _0x2e1c84=this['getLastChildName'](_0xb687a1);return _0x2e1c84?new E(_0x2e1c84,this['children_']['get'](_0x2e1c84)):null;}['forEachChild'](_0x7dc7c5,_0x5465f4){const _0x3fb1b7=this['resolveIndex_'](_0x7dc7c5);return _0x3fb1b7?_0x3fb1b7['inorderTraversal'](_0x164ec8=>_0x5465f4(_0x164ec8['name'],_0x164ec8['node'])):this['children_']['inorderTraversal'](_0x5465f4);}['getIterator'](_0x451b76){return this['getIteratorFrom'](_0x451b76['minPost'](),_0x451b76);}['getIteratorFrom'](_0x7ef73a,_0x71bd03){const _0x22a4cb=this['resolveIndex_'](_0x71bd03);if(_0x22a4cb)return _0x22a4cb['getIteratorFrom'](_0x7ef73a,_0x523b78=>_0x523b78);{const _0x368245=this['children_']['getIteratorFrom'](_0x7ef73a['name'],E['Wrap']);let _0x4f791f=_0x368245['peek']();for(;_0x4f791f!=null&&_0x71bd03['compare'](_0x4f791f,_0x7ef73a)<0x0;)_0x368245['getNext'](),_0x4f791f=_0x368245['peek']();return _0x368245;}}['getReverseIterator'](_0x5edd52){return this['getReverseIteratorFrom'](_0x5edd52['maxPost'](),_0x5edd52);}['getReverseIteratorFrom'](_0x4f3327,_0x9a20b2){const _0x18ba6a=this['resolveIndex_'](_0x9a20b2);if(_0x18ba6a)return _0x18ba6a['getReverseIteratorFrom'](_0x4f3327,_0x3d68a1=>_0x3d68a1);{const _0x4cb8b0=this['children_']['getReverseIteratorFrom'](_0x4f3327['name'],E['Wrap']);let _0x538467=_0x4cb8b0['peek']();for(;_0x538467!=null&&_0x9a20b2['compare'](_0x538467,_0x4f3327)>0x0;)_0x4cb8b0['getNext'](),_0x538467=_0x4cb8b0['peek']();return _0x4cb8b0;}}['compareTo'](_0x45961d){return this['isEmpty']()?_0x45961d['isEmpty']()?0x0:-0x1:_0x45961d['isLeafNode']()||_0x45961d['isEmpty']()?0x1:_0x45961d===jt?-0x1:0x0;}['withIndex'](_0x1284de){if(_0x1284de===ve||this['indexMap_']['hasIndex'](_0x1284de))return this;{const _0x25d756=this['indexMap_']['addIndex'](_0x1284de,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x25d756);}}['isIndexed'](_0x400934){return _0x400934===ve||this['indexMap_']['hasIndex'](_0x400934);}['equals'](_0x7cbaa3){if(_0x7cbaa3===this)return!0x0;if(_0x7cbaa3['isLeafNode']())return!0x1;{const _0x1c5475=_0x7cbaa3;if(this['getPriority']()['equals'](_0x1c5475['getPriority']())){if(this['children_']['count']()===_0x1c5475['children_']['count']()){const _0x2816c8=this['getIterator'](R),_0x2f9b1d=_0x1c5475['getIterator'](R);let _0xa54e57=_0x2816c8['getNext'](),_0x4da6ec=_0x2f9b1d['getNext']();for(;_0xa54e57&&_0x4da6ec;){if(_0xa54e57['name']!==_0x4da6ec['name']||!_0xa54e57['node']['equals'](_0x4da6ec['node']))return!0x1;_0xa54e57=_0x2816c8['getNext'](),_0x4da6ec=_0x2f9b1d['getNext']();}return _0xa54e57===null&&_0x4da6ec===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x446488){return _0x446488===ve?null:this['indexMap_']['get'](_0x446488['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x2eabaa){return _0x2eabaa===this?0x0:0x1;}['equals'](_0x13f3df){return _0x13f3df===this;}['getPriority'](){return this;}['getImmediateChild'](_0x383b1d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x2e36e4,_0x5ae0b7=null){if(_0x2e36e4===null)return g['EMPTY_NODE'];if(typeof _0x2e36e4=='object'&&'.priority'in _0x2e36e4&&(_0x5ae0b7=_0x2e36e4['.priority']),f(_0x5ae0b7===null||typeof _0x5ae0b7=='string'||typeof _0x5ae0b7=='number'||typeof _0x5ae0b7=='object'&&'.sv'in _0x5ae0b7,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5ae0b7),typeof _0x2e36e4=='object'&&'.value'in _0x2e36e4&&_0x2e36e4['.value']!==null&&(_0x2e36e4=_0x2e36e4['.value']),typeof _0x2e36e4!='object'||'.sv'in _0x2e36e4){const _0x5dee79=_0x2e36e4;return new D(_0x5dee79,A(_0x5ae0b7));}if(!(_0x2e36e4 instanceof Array)&&Gh){const _0x36dc63=[];let _0xc2d51e=!0x1;if(x(_0x2e36e4,(_0x2b4638,_0x15d192)=>{if(_0x2b4638['substring'](0x0,0x1)!=='.'){const _0x1ab4ef=A(_0x15d192);_0x1ab4ef['isEmpty']()||(_0xc2d51e=_0xc2d51e||!_0x1ab4ef['getPriority']()['isEmpty'](),_0x36dc63['push'](new E(_0x2b4638,_0x1ab4ef)));}}),_0x36dc63['length']===0x0)return g['EMPTY_NODE'];const _0x195941=yn(_0x36dc63,xh,_0x15123d=>_0x15123d['name'],Qi);if(_0xc2d51e){const _0x590b13=yn(_0x36dc63,R['getCompare']());return new g(_0x195941,A(_0x5ae0b7),new te({'.priority':_0x590b13},{'.priority':R}));}else return new g(_0x195941,A(_0x5ae0b7),te['Default']);}else{let _0x574928=g['EMPTY_NODE'];return x(_0x2e36e4,(_0x5a97d6,_0x571bbf)=>{if(Q(_0x2e36e4,_0x5a97d6)&&_0x5a97d6['substring'](0x0,0x1)!=='.'){const _0x54de7f=A(_0x571bbf);(_0x54de7f['isLeafNode']()||!_0x54de7f['isEmpty']())&&(_0x574928=_0x574928['updateImmediateChild'](_0x5a97d6,_0x54de7f));}}),_0x574928['updatePriority'](A(_0x5ae0b7));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x35dcba){super(),this['indexPath_']=_0x35dcba,f(!v(_0x35dcba)&&y(_0x35dcba)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x164d33){return _0x164d33['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2893e3){return!_0x2893e3['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x432640,_0x1a5dc1){const _0x3d761e=this['extractChild'](_0x432640['node']),_0x434e0e=this['extractChild'](_0x1a5dc1['node']),_0x366b2f=_0x3d761e['compareTo'](_0x434e0e);return _0x366b2f===0x0?Ge(_0x432640['name'],_0x1a5dc1['name']):_0x366b2f;}['makePost'](_0x225670,_0xcec8b5){const _0x30450f=A(_0x225670),_0xbce1ea=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x30450f);return new E(_0xcec8b5,_0xbce1ea);}['maxPost'](){const _0x23adf8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x23adf8);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0xb09834,_0x441e10){const _0x71bff2=_0xb09834['node']['compareTo'](_0x441e10['node']);return _0x71bff2===0x0?Ge(_0xb09834['name'],_0x441e10['name']):_0x71bff2;}['isDefinedOn'](_0x4e3972){return!0x0;}['indexedValueChanged'](_0x5ce6ce,_0x4b7b6d){return!_0x5ce6ce['equals'](_0x4b7b6d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x15bcdf,_0x55f892){const _0x182f44=A(_0x15bcdf);return new E(_0x55f892,_0x182f44);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x432964){return{'type':'value','snapshotNode':_0x432964};}function rt(_0x1fb357,_0xca9601){return{'type':'child_added','snapshotNode':_0xca9601,'childName':_0x1fb357};}function Mt(_0x25aae0,_0xb39dd9){return{'type':'child_removed','snapshotNode':_0xb39dd9,'childName':_0x25aae0};}function Lt(_0x3d5541,_0x42345e,_0x118484){return{'type':'child_changed','snapshotNode':_0x42345e,'childName':_0x3d5541,'oldSnap':_0x118484};}function zh(_0xa5aff2,_0x1cc63e){return{'type':'child_moved','snapshotNode':_0x1cc63e,'childName':_0xa5aff2};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x55c7d6){this['index_']=_0x55c7d6;}['updateChild'](_0x42d644,_0x27a4b5,_0xd5b625,_0x1a10fe,_0x5d33d1,_0x23deec){f(_0x42d644['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x10d0c6=_0x42d644['getImmediateChild'](_0x27a4b5);return _0x10d0c6['getChild'](_0x1a10fe)['equals'](_0xd5b625['getChild'](_0x1a10fe))&&_0x10d0c6['isEmpty']()===_0xd5b625['isEmpty']()||(_0x23deec!=null&&(_0xd5b625['isEmpty']()?_0x42d644['hasChild'](_0x27a4b5)?_0x23deec['trackChildChange'](Mt(_0x27a4b5,_0x10d0c6)):f(_0x42d644['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x10d0c6['isEmpty']()?_0x23deec['trackChildChange'](rt(_0x27a4b5,_0xd5b625)):_0x23deec['trackChildChange'](Lt(_0x27a4b5,_0xd5b625,_0x10d0c6))),_0x42d644['isLeafNode']()&&_0xd5b625['isEmpty']())?_0x42d644:_0x42d644['updateImmediateChild'](_0x27a4b5,_0xd5b625)['withIndex'](this['index_']);}['updateFullNode'](_0x5159e7,_0x37a08d,_0x33dec6){return _0x33dec6!=null&&(_0x5159e7['isLeafNode']()||_0x5159e7['forEachChild'](R,(_0x2188f1,_0x5f2881)=>{_0x37a08d['hasChild'](_0x2188f1)||_0x33dec6['trackChildChange'](Mt(_0x2188f1,_0x5f2881));}),_0x37a08d['isLeafNode']()||_0x37a08d['forEachChild'](R,(_0xd47293,_0x256305)=>{if(_0x5159e7['hasChild'](_0xd47293)){const _0x5a10b2=_0x5159e7['getImmediateChild'](_0xd47293);_0x5a10b2['equals'](_0x256305)||_0x33dec6['trackChildChange'](Lt(_0xd47293,_0x256305,_0x5a10b2));}else _0x33dec6['trackChildChange'](rt(_0xd47293,_0x256305));})),_0x37a08d['withIndex'](this['index_']);}['updatePriority'](_0x1f4567,_0x23eead){return _0x1f4567['isEmpty']()?g['EMPTY_NODE']:_0x1f4567['updatePriority'](_0x23eead);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x1a9b83){this['indexedFilter_']=new Xi(_0x1a9b83['getIndex']()),this['index_']=_0x1a9b83['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x1a9b83),this['endPost_']=xt['getEndPost_'](_0x1a9b83),this['startIsInclusive_']=!_0x1a9b83['startAfterSet_'],this['endIsInclusive_']=!_0x1a9b83['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x32202c){const _0x3366d6=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x32202c)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x32202c)<0x0,_0x2fdfa3=this['endIsInclusive_']?this['index_']['compare'](_0x32202c,this['getEndPost']())<=0x0:this['index_']['compare'](_0x32202c,this['getEndPost']())<0x0;return _0x3366d6&&_0x2fdfa3;}['updateChild'](_0x3cf426,_0x265331,_0x2c45fa,_0x3444e9,_0x3bea14,_0x2728f4){return this['matches'](new E(_0x265331,_0x2c45fa))||(_0x2c45fa=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3cf426,_0x265331,_0x2c45fa,_0x3444e9,_0x3bea14,_0x2728f4);}['updateFullNode'](_0x81de44,_0x172cf7,_0x1b8b50){_0x172cf7['isLeafNode']()&&(_0x172cf7=g['EMPTY_NODE']);let _0x50467f=_0x172cf7['withIndex'](this['index_']);_0x50467f=_0x50467f['updatePriority'](g['EMPTY_NODE']);const _0x228981=this;return _0x172cf7['forEachChild'](R,(_0x1f1988,_0x2757df)=>{_0x228981['matches'](new E(_0x1f1988,_0x2757df))||(_0x50467f=_0x50467f['updateImmediateChild'](_0x1f1988,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x81de44,_0x50467f,_0x1b8b50);}['updatePriority'](_0x215576,_0x5a4ebf){return _0x215576;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x36c6a1){if(_0x36c6a1['hasStart']()){const _0x1cd37f=_0x36c6a1['getIndexStartName']();return _0x36c6a1['getIndex']()['makePost'](_0x36c6a1['getIndexStartValue'](),_0x1cd37f);}else return _0x36c6a1['getIndex']()['minPost']();}static['getEndPost_'](_0x300fa1){if(_0x300fa1['hasEnd']()){const _0x1fa625=_0x300fa1['getIndexEndName']();return _0x300fa1['getIndex']()['makePost'](_0x300fa1['getIndexEndValue'](),_0x1fa625);}else return _0x300fa1['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x54c474){this['withinDirectionalStart']=_0x33e6bd=>this['reverse_']?this['withinEndPost'](_0x33e6bd):this['withinStartPost'](_0x33e6bd),this['withinDirectionalEnd']=_0x2b58b9=>this['reverse_']?this['withinStartPost'](_0x2b58b9):this['withinEndPost'](_0x2b58b9),this['withinStartPost']=_0xf4cbb9=>{const _0x27fe8d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xf4cbb9);return this['startIsInclusive_']?_0x27fe8d<=0x0:_0x27fe8d<0x0;},this['withinEndPost']=_0x14425e=>{const _0x4ef42b=this['index_']['compare'](_0x14425e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4ef42b<=0x0:_0x4ef42b<0x0;},this['rangedFilter_']=new xt(_0x54c474),this['index_']=_0x54c474['getIndex'](),this['limit_']=_0x54c474['getLimit'](),this['reverse_']=!_0x54c474['isViewFromLeft'](),this['startIsInclusive_']=!_0x54c474['startAfterSet_'],this['endIsInclusive_']=!_0x54c474['endBeforeSet_'];}['updateChild'](_0x2bfccd,_0x1d18f7,_0x346141,_0x39d89f,_0x557562,_0x4c9732){return this['rangedFilter_']['matches'](new E(_0x1d18f7,_0x346141))||(_0x346141=g['EMPTY_NODE']),_0x2bfccd['getImmediateChild'](_0x1d18f7)['equals'](_0x346141)?_0x2bfccd:_0x2bfccd['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2bfccd,_0x1d18f7,_0x346141,_0x39d89f,_0x557562,_0x4c9732):this['fullLimitUpdateChild_'](_0x2bfccd,_0x1d18f7,_0x346141,_0x557562,_0x4c9732);}['updateFullNode'](_0xdefdb3,_0x695142,_0x4080cc){let _0x480298;if(_0x695142['isLeafNode']()||_0x695142['isEmpty']())_0x480298=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x695142['numChildren']()&&_0x695142['isIndexed'](this['index_'])){_0x480298=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3165aa;this['reverse_']?_0x3165aa=_0x695142['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3165aa=_0x695142['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x497389=0x0;for(;_0x3165aa['hasNext']()&&_0x497389<this['limit_'];){const _0x13357a=_0x3165aa['getNext']();if(this['withinDirectionalStart'](_0x13357a)){if(this['withinDirectionalEnd'](_0x13357a))_0x480298=_0x480298['updateImmediateChild'](_0x13357a['name'],_0x13357a['node']),_0x497389++;else break;}else continue;}}else{_0x480298=_0x695142['withIndex'](this['index_']),_0x480298=_0x480298['updatePriority'](g['EMPTY_NODE']);let _0x10c3fe;this['reverse_']?_0x10c3fe=_0x480298['getReverseIterator'](this['index_']):_0x10c3fe=_0x480298['getIterator'](this['index_']);let _0x1177d4=0x0;for(;_0x10c3fe['hasNext']();){const _0x5744a2=_0x10c3fe['getNext']();_0x1177d4<this['limit_']&&this['withinDirectionalStart'](_0x5744a2)&&this['withinDirectionalEnd'](_0x5744a2)?_0x1177d4++:_0x480298=_0x480298['updateImmediateChild'](_0x5744a2['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xdefdb3,_0x480298,_0x4080cc);}['updatePriority'](_0x5dc0a8,_0x476521){return _0x5dc0a8;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x7a019d,_0x5cb0a7,_0x4d1cba,_0x46c3c6,_0x491096){let _0x5024ea;if(this['reverse_']){const _0x5b91fd=this['index_']['getCompare']();_0x5024ea=(_0x4d2f72,_0x4865a6)=>_0x5b91fd(_0x4865a6,_0x4d2f72);}else _0x5024ea=this['index_']['getCompare']();const _0x3125dc=_0x7a019d;f(_0x3125dc['numChildren']()===this['limit_'],'');const _0x43eee6=new E(_0x5cb0a7,_0x4d1cba),_0x333a94=this['reverse_']?_0x3125dc['getFirstChild'](this['index_']):_0x3125dc['getLastChild'](this['index_']),_0x156285=this['rangedFilter_']['matches'](_0x43eee6);if(_0x3125dc['hasChild'](_0x5cb0a7)){const _0x2d74f0=_0x3125dc['getImmediateChild'](_0x5cb0a7);let _0x448023=_0x46c3c6['getChildAfterChild'](this['index_'],_0x333a94,this['reverse_']);for(;_0x448023!=null&&(_0x448023['name']===_0x5cb0a7||_0x3125dc['hasChild'](_0x448023['name']));)_0x448023=_0x46c3c6['getChildAfterChild'](this['index_'],_0x448023,this['reverse_']);const _0x4f6c48=_0x448023==null?0x1:_0x5024ea(_0x448023,_0x43eee6);if(_0x156285&&!_0x4d1cba['isEmpty']()&&_0x4f6c48>=0x0)return _0x491096!=null&&_0x491096['trackChildChange'](Lt(_0x5cb0a7,_0x4d1cba,_0x2d74f0)),_0x3125dc['updateImmediateChild'](_0x5cb0a7,_0x4d1cba);{_0x491096!=null&&_0x491096['trackChildChange'](Mt(_0x5cb0a7,_0x2d74f0));const _0xcb3b0e=_0x3125dc['updateImmediateChild'](_0x5cb0a7,g['EMPTY_NODE']);return _0x448023!=null&&this['rangedFilter_']['matches'](_0x448023)?(_0x491096!=null&&_0x491096['trackChildChange'](rt(_0x448023['name'],_0x448023['node'])),_0xcb3b0e['updateImmediateChild'](_0x448023['name'],_0x448023['node'])):_0xcb3b0e;}}else return _0x4d1cba['isEmpty']()?_0x7a019d:_0x156285&&_0x5024ea(_0x333a94,_0x43eee6)>=0x0?(_0x491096!=null&&(_0x491096['trackChildChange'](Mt(_0x333a94['name'],_0x333a94['node'])),_0x491096['trackChildChange'](rt(_0x5cb0a7,_0x4d1cba))),_0x3125dc['updateImmediateChild'](_0x5cb0a7,_0x4d1cba)['updateImmediateChild'](_0x333a94['name'],g['EMPTY_NODE'])):_0x7a019d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x16f76a=new Zi();return _0x16f76a['limitSet_']=this['limitSet_'],_0x16f76a['limit_']=this['limit_'],_0x16f76a['startSet_']=this['startSet_'],_0x16f76a['startAfterSet_']=this['startAfterSet_'],_0x16f76a['indexStartValue_']=this['indexStartValue_'],_0x16f76a['startNameSet_']=this['startNameSet_'],_0x16f76a['indexStartName_']=this['indexStartName_'],_0x16f76a['endSet_']=this['endSet_'],_0x16f76a['endBeforeSet_']=this['endBeforeSet_'],_0x16f76a['indexEndValue_']=this['indexEndValue_'],_0x16f76a['endNameSet_']=this['endNameSet_'],_0x16f76a['indexEndName_']=this['indexEndName_'],_0x16f76a['index_']=this['index_'],_0x16f76a['viewFrom_']=this['viewFrom_'],_0x16f76a;}}function Kh(_0x3f1331){return _0x3f1331['loadsAllData']()?new Xi(_0x3f1331['getIndex']()):_0x3f1331['hasLimit']()?new jh(_0x3f1331):new xt(_0x3f1331);}function Yh(_0xe1c380,_0xfc821d,_0x1c9e53){const _0x3bc0b9=_0xe1c380['copy']();return _0x3bc0b9['startSet_']=!0x0,_0xfc821d===void 0x0&&(_0xfc821d=null),_0x3bc0b9['indexStartValue_']=_0xfc821d,_0x1c9e53!=null?(_0x3bc0b9['startNameSet_']=!0x0,_0x3bc0b9['indexStartName_']=_0x1c9e53):(_0x3bc0b9['startNameSet_']=!0x1,_0x3bc0b9['indexStartName_']=''),_0x3bc0b9;}function Qh(_0x5e2e52,_0x384e67,_0x30b8b9){const _0x4f64d0=_0x5e2e52['copy']();return _0x4f64d0['endSet_']=!0x0,_0x384e67===void 0x0&&(_0x384e67=null),_0x4f64d0['indexEndValue_']=_0x384e67,_0x30b8b9!==void 0x0?(_0x4f64d0['endNameSet_']=!0x0,_0x4f64d0['indexEndName_']=_0x30b8b9):(_0x4f64d0['endNameSet_']=!0x1,_0x4f64d0['indexEndName_']=''),_0x4f64d0;}function xo(_0x22c539,_0x2bfc98){const _0x51ea5d=_0x22c539['copy']();return _0x51ea5d['index_']=_0x2bfc98,_0x51ea5d;}function ir(_0x24b292){const _0x221538={};if(_0x24b292['isDefault']())return _0x221538;let _0x1f2322;if(_0x24b292['index_']===R?_0x1f2322='$priority':_0x24b292['index_']===Mo?_0x1f2322='$value':_0x24b292['index_']===ve?_0x1f2322='$key':(f(_0x24b292['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1f2322=_0x24b292['index_']['toString']()),_0x221538['orderBy']=O(_0x1f2322),_0x24b292['startSet_']){const _0x27f836=_0x24b292['startAfterSet_']?'startAfter':'startAt';_0x221538[_0x27f836]=O(_0x24b292['indexStartValue_']),_0x24b292['startNameSet_']&&(_0x221538[_0x27f836]+=','+O(_0x24b292['indexStartName_']));}if(_0x24b292['endSet_']){const _0x37dcde=_0x24b292['endBeforeSet_']?'endBefore':'endAt';_0x221538[_0x37dcde]=O(_0x24b292['indexEndValue_']),_0x24b292['endNameSet_']&&(_0x221538[_0x37dcde]+=','+O(_0x24b292['indexEndName_']));}return _0x24b292['limitSet_']&&(_0x24b292['isViewFromLeft']()?_0x221538['limitToFirst']=_0x24b292['limit_']:_0x221538['limitToLast']=_0x24b292['limit_']),_0x221538;}function sr(_0x2b6e56){const _0x15fefc={};if(_0x2b6e56['startSet_']&&(_0x15fefc['sp']=_0x2b6e56['indexStartValue_'],_0x2b6e56['startNameSet_']&&(_0x15fefc['sn']=_0x2b6e56['indexStartName_']),_0x15fefc['sin']=!_0x2b6e56['startAfterSet_']),_0x2b6e56['endSet_']&&(_0x15fefc['ep']=_0x2b6e56['indexEndValue_'],_0x2b6e56['endNameSet_']&&(_0x15fefc['en']=_0x2b6e56['indexEndName_']),_0x15fefc['ein']=!_0x2b6e56['endBeforeSet_']),_0x2b6e56['limitSet_']){_0x15fefc['l']=_0x2b6e56['limit_'];let _0x2c092a=_0x2b6e56['viewFrom_'];_0x2c092a===''&&(_0x2b6e56['isViewFromLeft']()?_0x2c092a='l':_0x2c092a='r'),_0x15fefc['vf']=_0x2c092a;}return _0x2b6e56['index_']!==R&&(_0x15fefc['i']=_0x2b6e56['index_']['toString']()),_0x15fefc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2997b6){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5c3bee,_0x56809a){return _0x56809a!==void 0x0?'tag$'+_0x56809a:(f(_0x5c3bee['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5c3bee['_path']['toString']());}constructor(_0x354aad,_0xa52de7,_0x5982b0,_0x49513a){super(),this['repoInfo_']=_0x354aad,this['onDataUpdate_']=_0xa52de7,this['authTokenProvider_']=_0x5982b0,this['appCheckTokenProvider_']=_0x49513a,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x4c9794,_0xe3945d,_0x2d2e01,_0x5761cf){const _0x1d1d62=_0x4c9794['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1d1d62+'\x20'+_0x4c9794['_queryIdentifier']);const _0x4e3dbc=vn['getListenId_'](_0x4c9794,_0x2d2e01),_0x1d8966={};this['listens_'][_0x4e3dbc]=_0x1d8966;const _0x29fc82=ir(_0x4c9794['_queryParams']);this['restRequest_'](_0x1d1d62+'.json',_0x29fc82,(_0x331742,_0x1314f7)=>{let _0x380811=_0x1314f7;if(_0x331742===0x194&&(_0x380811=null,_0x331742=null),_0x331742===null&&this['onDataUpdate_'](_0x1d1d62,_0x380811,!0x1,_0x2d2e01),Me(this['listens_'],_0x4e3dbc)===_0x1d8966){let _0x5c8a70;_0x331742?_0x331742===0x191?_0x5c8a70='permission_denied':_0x5c8a70='rest_error:'+_0x331742:_0x5c8a70='ok',_0x5761cf(_0x5c8a70,null);}});}['unlisten'](_0x380bbf,_0xd7a602){const _0x2dfb22=vn['getListenId_'](_0x380bbf,_0xd7a602);delete this['listens_'][_0x2dfb22];}['get'](_0x11fd01){const _0x55beae=ir(_0x11fd01['_queryParams']),_0x19b6f2=_0x11fd01['_path']['toString'](),_0x3fc15d=new H();return this['restRequest_'](_0x19b6f2+'.json',_0x55beae,(_0x2838f7,_0x487366)=>{let _0x197cae=_0x487366;_0x2838f7===0x194&&(_0x197cae=null,_0x2838f7=null),_0x2838f7===null?(this['onDataUpdate_'](_0x19b6f2,_0x197cae,!0x1,null),_0x3fc15d['resolve'](_0x197cae)):_0x3fc15d['reject'](new Error(_0x197cae));}),_0x3fc15d['promise'];}['refreshAuthToken'](_0x1dfb72){}['restRequest_'](_0x2a5a08,_0x34fdba={},_0x287a83){return _0x34fdba['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2e9d4b,_0x440b01])=>{_0x2e9d4b&&_0x2e9d4b['accessToken']&&(_0x34fdba['auth']=_0x2e9d4b['accessToken']),_0x440b01&&_0x440b01['token']&&(_0x34fdba['ac']=_0x440b01['token']);const _0x5ae44b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2a5a08+'?ns='+this['repoInfo_']['namespace']+ut(_0x34fdba);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5ae44b);const _0x5bb746=new XMLHttpRequest();_0x5bb746['onreadystatechange']=()=>{if(_0x287a83&&_0x5bb746['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5ae44b+'\x20received.\x20status:',_0x5bb746['status'],'response:',_0x5bb746['responseText']);let _0x1c15f9=null;if(_0x5bb746['status']>=0xc8&&_0x5bb746['status']<0x12c){try{_0x1c15f9=Nt(_0x5bb746['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5ae44b+':\x20'+_0x5bb746['responseText']);}_0x287a83(null,_0x1c15f9);}else _0x5bb746['status']!==0x191&&_0x5bb746['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5ae44b+'\x20Status:\x20'+_0x5bb746['status']),_0x287a83(_0x5bb746['status']);_0x287a83=null;}},_0x5bb746['open']('GET',_0x5ae44b,!0x0),_0x5bb746['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x205dff){return this['rootNode_']['getChild'](_0x205dff);}['updateSnapshot'](_0x152def,_0x4d1728){this['rootNode_']=this['rootNode_']['updateChild'](_0x152def,_0x4d1728);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x27311e,_0x5d5f1f,_0x2fdf82){if(v(_0x5d5f1f))_0x27311e['value']=_0x2fdf82,_0x27311e['children']['clear']();else{if(_0x27311e['value']!==null)_0x27311e['value']=_0x27311e['value']['updateChild'](_0x5d5f1f,_0x2fdf82);else{const _0x339655=y(_0x5d5f1f);_0x27311e['children']['has'](_0x339655)||_0x27311e['children']['set'](_0x339655,En());const _0x3f6f57=_0x27311e['children']['get'](_0x339655);_0x5d5f1f=S(_0x5d5f1f),pt(_0x3f6f57,_0x5d5f1f,_0x2fdf82);}}}function Ti(_0x506837,_0x1917db){if(v(_0x1917db))return _0x506837['value']=null,_0x506837['children']['clear'](),!0x0;if(_0x506837['value']!==null){if(_0x506837['value']['isLeafNode']())return!0x1;{const _0x47aff1=_0x506837['value'];return _0x506837['value']=null,_0x47aff1['forEachChild'](R,(_0x2e10ca,_0x1ed792)=>{pt(_0x506837,new C(_0x2e10ca),_0x1ed792);}),Ti(_0x506837,_0x1917db);}}else{if(_0x506837['children']['size']>0x0){const _0x36e0c7=y(_0x1917db);return _0x1917db=S(_0x1917db),_0x506837['children']['has'](_0x36e0c7)&&Ti(_0x506837['children']['get'](_0x36e0c7),_0x1917db)&&_0x506837['children']['delete'](_0x36e0c7),_0x506837['children']['size']===0x0;}else return!0x0;}}function Si(_0x474bb9,_0x1f2ba7,_0x102050){_0x474bb9['value']!==null?_0x102050(_0x1f2ba7,_0x474bb9['value']):Xh(_0x474bb9,(_0x41d906,_0x5a938c)=>{const _0x2a7a96=new C(_0x1f2ba7['toString']()+'/'+_0x41d906);Si(_0x5a938c,_0x2a7a96,_0x102050);});}function Xh(_0x50debf,_0x45486a){_0x50debf['children']['forEach']((_0xf49f88,_0xc19978)=>{_0x45486a(_0xc19978,_0xf49f88);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x1cad5d){this['collection_']=_0x1cad5d,this['last_']=null;}['get'](){const _0x46be3f=this['collection_']['get'](),_0x4ad131={..._0x46be3f};return this['last_']&&x(this['last_'],(_0x55258c,_0x23f94c)=>{_0x4ad131[_0x55258c]=_0x4ad131[_0x55258c]-_0x23f94c;}),this['last_']=_0x46be3f,_0x4ad131;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x4b4b6a,_0x85ae24){this['server_']=_0x85ae24,this['statsToReport_']={},this['statsListener_']=new Zh(_0x4b4b6a);const _0x8ec1b5=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x8ec1b5));}['reportStats_'](){const _0x178ab8=this['statsListener_']['get'](),_0x344426={};let _0x4bed90=!0x1;x(_0x178ab8,(_0x950739,_0x4fb141)=>{_0x4fb141>0x0&&Q(this['statsToReport_'],_0x950739)&&(_0x344426[_0x950739]=_0x4fb141,_0x4bed90=!0x0);}),_0x4bed90&&this['server_']['reportStats'](_0x344426),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xfb34a0){_0xfb34a0[_0xfb34a0['OVERWRITE']=0x0]='OVERWRITE',_0xfb34a0[_0xfb34a0['MERGE']=0x1]='MERGE',_0xfb34a0[_0xfb34a0['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xfb34a0[_0xfb34a0['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x38ca64){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x38ca64,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x33d6ab,_0x3b8914,_0x1fa835){this['path']=_0x33d6ab,this['affectedTree']=_0x3b8914,this['revert']=_0x1fa835,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x53f150){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4ea595=this['affectedTree']['subtree'](new C(_0x53f150));return new In(w(),_0x4ea595,this['revert']);}}else return f(y(this['path'])===_0x53f150,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x8190e,_0x18157a){this['source']=_0x8190e,this['path']=_0x18157a,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x370a4e){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x1138c0,_0xce311f,_0x49df8c){this['source']=_0x1138c0,this['path']=_0xce311f,this['snap']=_0x49df8c,this['type']=z['OVERWRITE'];}['operationForChild'](_0x23992f){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x23992f)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x54ca49,_0x411f42,_0x5092d8){this['source']=_0x54ca49,this['path']=_0x411f42,this['children']=_0x5092d8,this['type']=z['MERGE'];}['operationForChild'](_0x2c1db3){if(v(this['path'])){const _0x1587a5=this['children']['subtree'](new C(_0x2c1db3));return _0x1587a5['isEmpty']()?null:_0x1587a5['value']?new We(this['source'],w(),_0x1587a5['value']):new ot(this['source'],w(),_0x1587a5);}else return f(y(this['path'])===_0x2c1db3,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x35889a,_0x279651,_0x218f9c){this['node_']=_0x35889a,this['fullyInitialized_']=_0x279651,this['filtered_']=_0x218f9c;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x23fc78){if(v(_0x23fc78))return this['isFullyInitialized']()&&!this['filtered_'];const _0xd66caf=y(_0x23fc78);return this['isCompleteForChild'](_0xd66caf);}['isCompleteForChild'](_0x1f1209){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1f1209);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0xef6129){this['query_']=_0xef6129,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x185eca,_0x582547,_0x3ba118,_0x26c8c8){const _0x3a0a1e=[],_0x47b0b3=[];return _0x582547['forEach'](_0x12bf66=>{_0x12bf66['type']==='child_changed'&&_0x185eca['index_']['indexedValueChanged'](_0x12bf66['oldSnap'],_0x12bf66['snapshotNode'])&&_0x47b0b3['push'](zh(_0x12bf66['childName'],_0x12bf66['snapshotNode']));}),It(_0x185eca,_0x3a0a1e,'child_removed',_0x582547,_0x26c8c8,_0x3ba118),It(_0x185eca,_0x3a0a1e,'child_added',_0x582547,_0x26c8c8,_0x3ba118),It(_0x185eca,_0x3a0a1e,'child_moved',_0x47b0b3,_0x26c8c8,_0x3ba118),It(_0x185eca,_0x3a0a1e,'child_changed',_0x582547,_0x26c8c8,_0x3ba118),It(_0x185eca,_0x3a0a1e,'value',_0x582547,_0x26c8c8,_0x3ba118),_0x3a0a1e;}function It(_0x543744,_0x2b9917,_0x4822a4,_0x4d7e5d,_0x292e57,_0x32504f){const _0x48cf5d=_0x4d7e5d['filter'](_0x1315a1=>_0x1315a1['type']===_0x4822a4);_0x48cf5d['sort']((_0x3bfa45,_0x7cedd6)=>ou(_0x543744,_0x3bfa45,_0x7cedd6)),_0x48cf5d['forEach'](_0x6532bb=>{const _0x519d00=ru(_0x543744,_0x6532bb,_0x32504f);_0x292e57['forEach'](_0x581bae=>{_0x581bae['respondsTo'](_0x6532bb['type'])&&_0x2b9917['push'](_0x581bae['createEvent'](_0x519d00,_0x543744['query_']));});});}function ru(_0xb01c61,_0xcb4071,_0x1ecfcd){return _0xcb4071['type']==='value'||_0xcb4071['type']==='child_removed'||(_0xcb4071['prevName']=_0x1ecfcd['getPredecessorChildName'](_0xcb4071['childName'],_0xcb4071['snapshotNode'],_0xb01c61['index_'])),_0xcb4071;}function ou(_0x490a9f,_0x20f5f0,_0x2adb0a){if(_0x20f5f0['childName']==null||_0x2adb0a['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x55538c=new E(_0x20f5f0['childName'],_0x20f5f0['snapshotNode']),_0x5223f2=new E(_0x2adb0a['childName'],_0x2adb0a['snapshotNode']);return _0x490a9f['index_']['compare'](_0x55538c,_0x5223f2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x34a902,_0x46cb3c){return{'eventCache':_0x34a902,'serverCache':_0x46cb3c};}function bt(_0x218088,_0x579263,_0x1a8100,_0x33dc01){return Un(new Te(_0x579263,_0x1a8100,_0x33dc01),_0x218088['serverCache']);}function Fo(_0x4ab39e,_0x3068b5,_0x194290,_0x29e314){return Un(_0x4ab39e['eventCache'],new Te(_0x3068b5,_0x194290,_0x29e314));}function wn(_0x53b20b){return _0x53b20b['eventCache']['isFullyInitialized']()?_0x53b20b['eventCache']['getNode']():null;}function Be(_0x5f308c){return _0x5f308c['serverCache']['isFullyInitialized']()?_0x5f308c['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x374918){let _0x5e7874=new b(null);return x(_0x374918,(_0x302399,_0x175480)=>{_0x5e7874=_0x5e7874['set'](new C(_0x302399),_0x175480);}),_0x5e7874;}constructor(_0x44bcb5,_0x16564b=au()){this['value']=_0x44bcb5,this['children']=_0x16564b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xb74f5d,_0x549cae){if(this['value']!=null&&_0x549cae(this['value']))return{'path':w(),'value':this['value']};if(v(_0xb74f5d))return null;{const _0x25e133=y(_0xb74f5d),_0x4aa270=this['children']['get'](_0x25e133);if(_0x4aa270!==null){const _0x101fa6=_0x4aa270['findRootMostMatchingPathAndValue'](S(_0xb74f5d),_0x549cae);return _0x101fa6!=null?{'path':k(new C(_0x25e133),_0x101fa6['path']),'value':_0x101fa6['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x277d69){return this['findRootMostMatchingPathAndValue'](_0x277d69,()=>!0x0);}['subtree'](_0x3e3ebe){if(v(_0x3e3ebe))return this;{const _0x4ac4ab=y(_0x3e3ebe),_0x26ab6d=this['children']['get'](_0x4ac4ab);return _0x26ab6d!==null?_0x26ab6d['subtree'](S(_0x3e3ebe)):new b(null);}}['set'](_0x4be865,_0x3577a1){if(v(_0x4be865))return new b(_0x3577a1,this['children']);{const _0x51c1d2=y(_0x4be865),_0x1b63ca=(this['children']['get'](_0x51c1d2)||new b(null))['set'](S(_0x4be865),_0x3577a1),_0x15a9f7=this['children']['insert'](_0x51c1d2,_0x1b63ca);return new b(this['value'],_0x15a9f7);}}['remove'](_0x56c4c2){if(v(_0x56c4c2))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x1a2184=y(_0x56c4c2),_0x219e61=this['children']['get'](_0x1a2184);if(_0x219e61){const _0x3d40c4=_0x219e61['remove'](S(_0x56c4c2));let _0x41221f;return _0x3d40c4['isEmpty']()?_0x41221f=this['children']['remove'](_0x1a2184):_0x41221f=this['children']['insert'](_0x1a2184,_0x3d40c4),this['value']===null&&_0x41221f['isEmpty']()?new b(null):new b(this['value'],_0x41221f);}else return this;}}['get'](_0xc22b12){if(v(_0xc22b12))return this['value'];{const _0x58749d=y(_0xc22b12),_0x370f59=this['children']['get'](_0x58749d);return _0x370f59?_0x370f59['get'](S(_0xc22b12)):null;}}['setTree'](_0x25181a,_0x4d48b6){if(v(_0x25181a))return _0x4d48b6;{const _0x349974=y(_0x25181a),_0x531a36=(this['children']['get'](_0x349974)||new b(null))['setTree'](S(_0x25181a),_0x4d48b6);let _0x3672dd;return _0x531a36['isEmpty']()?_0x3672dd=this['children']['remove'](_0x349974):_0x3672dd=this['children']['insert'](_0x349974,_0x531a36),new b(this['value'],_0x3672dd);}}['fold'](_0x3b3ea9){return this['fold_'](w(),_0x3b3ea9);}['fold_'](_0xcc763,_0x23d686){const _0x56387c={};return this['children']['inorderTraversal']((_0x5b087a,_0x38b104)=>{_0x56387c[_0x5b087a]=_0x38b104['fold_'](k(_0xcc763,_0x5b087a),_0x23d686);}),_0x23d686(_0xcc763,this['value'],_0x56387c);}['findOnPath'](_0x3109fc,_0x563f35){return this['findOnPath_'](_0x3109fc,w(),_0x563f35);}['findOnPath_'](_0x96add9,_0x2e92dc,_0xdf552d){const _0x545e5d=this['value']?_0xdf552d(_0x2e92dc,this['value']):!0x1;if(_0x545e5d)return _0x545e5d;if(v(_0x96add9))return null;{const _0x3c17e7=y(_0x96add9),_0x306973=this['children']['get'](_0x3c17e7);return _0x306973?_0x306973['findOnPath_'](S(_0x96add9),k(_0x2e92dc,_0x3c17e7),_0xdf552d):null;}}['foreachOnPath'](_0x926080,_0x314d7f){return this['foreachOnPath_'](_0x926080,w(),_0x314d7f);}['foreachOnPath_'](_0x29d6c4,_0x236f54,_0x57aab1){if(v(_0x29d6c4))return this;{this['value']&&_0x57aab1(_0x236f54,this['value']);const _0x5477f7=y(_0x29d6c4),_0x1d63e7=this['children']['get'](_0x5477f7);return _0x1d63e7?_0x1d63e7['foreachOnPath_'](S(_0x29d6c4),k(_0x236f54,_0x5477f7),_0x57aab1):new b(null);}}['foreach'](_0x2d492b){this['foreach_'](w(),_0x2d492b);}['foreach_'](_0x3aedda,_0x5c04f1){this['children']['inorderTraversal']((_0x5ad856,_0x61729c)=>{_0x61729c['foreach_'](k(_0x3aedda,_0x5ad856),_0x5c04f1);}),this['value']&&_0x5c04f1(_0x3aedda,this['value']);}['foreachChild'](_0x3e58d6){this['children']['inorderTraversal']((_0x41854f,_0x38f1f9)=>{_0x38f1f9['value']&&_0x3e58d6(_0x41854f,_0x38f1f9['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x167b6f){this['writeTree_']=_0x167b6f;}static['empty'](){return new K(new b(null));}}function Rt(_0x3af680,_0x788902,_0x323901){if(v(_0x788902))return new K(new b(_0x323901));{const _0x5e8b0b=_0x3af680['writeTree_']['findRootMostValueAndPath'](_0x788902);if(_0x5e8b0b!=null){const _0x5de901=_0x5e8b0b['path'];let _0x359d9d=_0x5e8b0b['value'];const _0x3d832f=F(_0x5de901,_0x788902);return _0x359d9d=_0x359d9d['updateChild'](_0x3d832f,_0x323901),new K(_0x3af680['writeTree_']['set'](_0x5de901,_0x359d9d));}else{const _0x3baf15=new b(_0x323901),_0x4084da=_0x3af680['writeTree_']['setTree'](_0x788902,_0x3baf15);return new K(_0x4084da);}}}function bi(_0x5f0164,_0x392799,_0x1cb6d0){let _0x306994=_0x5f0164;return x(_0x1cb6d0,(_0x3a284b,_0x55361e)=>{_0x306994=Rt(_0x306994,k(_0x392799,_0x3a284b),_0x55361e);}),_0x306994;}function or(_0x361d12,_0x2597ce){if(v(_0x2597ce))return K['empty']();{const _0x9b1839=_0x361d12['writeTree_']['setTree'](_0x2597ce,new b(null));return new K(_0x9b1839);}}function Ri(_0x4ce4f7,_0x16fdc7){return qe(_0x4ce4f7,_0x16fdc7)!=null;}function qe(_0x22f879,_0x5ad8fd){const _0xf61afd=_0x22f879['writeTree_']['findRootMostValueAndPath'](_0x5ad8fd);return _0xf61afd!=null?_0x22f879['writeTree_']['get'](_0xf61afd['path'])['getChild'](F(_0xf61afd['path'],_0x5ad8fd)):null;}function ar(_0x508414){const _0x26ee99=[],_0x1506ee=_0x508414['writeTree_']['value'];return _0x1506ee!=null?_0x1506ee['isLeafNode']()||_0x1506ee['forEachChild'](R,(_0x4e8b77,_0x600767)=>{_0x26ee99['push'](new E(_0x4e8b77,_0x600767));}):_0x508414['writeTree_']['children']['inorderTraversal']((_0x507914,_0x3ca211)=>{_0x3ca211['value']!=null&&_0x26ee99['push'](new E(_0x507914,_0x3ca211['value']));}),_0x26ee99;}function Ee(_0x542ca2,_0x4cad74){if(v(_0x4cad74))return _0x542ca2;{const _0x294db1=qe(_0x542ca2,_0x4cad74);return _0x294db1!=null?new K(new b(_0x294db1)):new K(_0x542ca2['writeTree_']['subtree'](_0x4cad74));}}function Ai(_0x5a9634){return _0x5a9634['writeTree_']['isEmpty']();}function at(_0x56ba55,_0x4627f1){return Uo(w(),_0x56ba55['writeTree_'],_0x4627f1);}function Uo(_0xd1c702,_0x377e15,_0x33ebe3){if(_0x377e15['value']!=null)return _0x33ebe3['updateChild'](_0xd1c702,_0x377e15['value']);{let _0x5d3c71=null;return _0x377e15['children']['inorderTraversal']((_0x1e673a,_0x4f0e72)=>{_0x1e673a==='.priority'?(f(_0x4f0e72['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5d3c71=_0x4f0e72['value']):_0x33ebe3=Uo(k(_0xd1c702,_0x1e673a),_0x4f0e72,_0x33ebe3);}),!_0x33ebe3['getChild'](_0xd1c702)['isEmpty']()&&_0x5d3c71!==null&&(_0x33ebe3=_0x33ebe3['updateChild'](k(_0xd1c702,'.priority'),_0x5d3c71)),_0x33ebe3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x53c29d,_0x5eec46){return Ho(_0x5eec46,_0x53c29d);}function cu(_0x486d0a,_0x12a71a,_0x2f9eb4,_0xb97ff8,_0x3ea4ca){f(_0xb97ff8>_0x486d0a['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3ea4ca===void 0x0&&(_0x3ea4ca=!0x0),_0x486d0a['allWrites']['push']({'path':_0x12a71a,'snap':_0x2f9eb4,'writeId':_0xb97ff8,'visible':_0x3ea4ca}),_0x3ea4ca&&(_0x486d0a['visibleWrites']=Rt(_0x486d0a['visibleWrites'],_0x12a71a,_0x2f9eb4)),_0x486d0a['lastWriteId']=_0xb97ff8;}function lu(_0x356965,_0x1389c9,_0x2584a8,_0x41f0df){f(_0x41f0df>_0x356965['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x356965['allWrites']['push']({'path':_0x1389c9,'children':_0x2584a8,'writeId':_0x41f0df,'visible':!0x0}),_0x356965['visibleWrites']=bi(_0x356965['visibleWrites'],_0x1389c9,_0x2584a8),_0x356965['lastWriteId']=_0x41f0df;}function hu(_0x14cf40,_0x1a1c5f){for(let _0x13dd26=0x0;_0x13dd26<_0x14cf40['allWrites']['length'];_0x13dd26++){const _0x2c650c=_0x14cf40['allWrites'][_0x13dd26];if(_0x2c650c['writeId']===_0x1a1c5f)return _0x2c650c;}return null;}function uu(_0x9bf705,_0x4a2096){const _0x18d780=_0x9bf705['allWrites']['findIndex'](_0x2c910f=>_0x2c910f['writeId']===_0x4a2096);f(_0x18d780>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1ad35e=_0x9bf705['allWrites'][_0x18d780];_0x9bf705['allWrites']['splice'](_0x18d780,0x1);let _0x23d6d0=_0x1ad35e['visible'],_0x290c60=!0x1,_0xef05fb=_0x9bf705['allWrites']['length']-0x1;for(;_0x23d6d0&&_0xef05fb>=0x0;){const _0x203f1b=_0x9bf705['allWrites'][_0xef05fb];_0x203f1b['visible']&&(_0xef05fb>=_0x18d780&&du(_0x203f1b,_0x1ad35e['path'])?_0x23d6d0=!0x1:G(_0x1ad35e['path'],_0x203f1b['path'])&&(_0x290c60=!0x0)),_0xef05fb--;}if(_0x23d6d0){if(_0x290c60)return fu(_0x9bf705),!0x0;if(_0x1ad35e['snap'])_0x9bf705['visibleWrites']=or(_0x9bf705['visibleWrites'],_0x1ad35e['path']);else{const _0x59df33=_0x1ad35e['children'];x(_0x59df33,_0x54d677=>{_0x9bf705['visibleWrites']=or(_0x9bf705['visibleWrites'],k(_0x1ad35e['path'],_0x54d677));});}return!0x0;}else return!0x1;}function du(_0x107751,_0x346d04){if(_0x107751['snap'])return G(_0x107751['path'],_0x346d04);for(const _0x439f5a in _0x107751['children'])if(_0x107751['children']['hasOwnProperty'](_0x439f5a)&&G(k(_0x107751['path'],_0x439f5a),_0x346d04))return!0x0;return!0x1;}function fu(_0x415656){_0x415656['visibleWrites']=Wo(_0x415656['allWrites'],pu,w()),_0x415656['allWrites']['length']>0x0?_0x415656['lastWriteId']=_0x415656['allWrites'][_0x415656['allWrites']['length']-0x1]['writeId']:_0x415656['lastWriteId']=-0x1;}function pu(_0x1f3f39){return _0x1f3f39['visible'];}function Wo(_0x1eca24,_0x5efa66,_0x5549e1){let _0x55f89a=K['empty']();for(let _0x5bd6a1=0x0;_0x5bd6a1<_0x1eca24['length'];++_0x5bd6a1){const _0x2611f9=_0x1eca24[_0x5bd6a1];if(_0x5efa66(_0x2611f9)){const _0x6cfa3b=_0x2611f9['path'];let _0x4b6142;if(_0x2611f9['snap'])G(_0x5549e1,_0x6cfa3b)?(_0x4b6142=F(_0x5549e1,_0x6cfa3b),_0x55f89a=Rt(_0x55f89a,_0x4b6142,_0x2611f9['snap'])):G(_0x6cfa3b,_0x5549e1)&&(_0x4b6142=F(_0x6cfa3b,_0x5549e1),_0x55f89a=Rt(_0x55f89a,w(),_0x2611f9['snap']['getChild'](_0x4b6142)));else{if(_0x2611f9['children']){if(G(_0x5549e1,_0x6cfa3b))_0x4b6142=F(_0x5549e1,_0x6cfa3b),_0x55f89a=bi(_0x55f89a,_0x4b6142,_0x2611f9['children']);else{if(G(_0x6cfa3b,_0x5549e1)){if(_0x4b6142=F(_0x6cfa3b,_0x5549e1),v(_0x4b6142))_0x55f89a=bi(_0x55f89a,w(),_0x2611f9['children']);else{const _0x13cfd5=Me(_0x2611f9['children'],y(_0x4b6142));if(_0x13cfd5){const _0x1ef94c=_0x13cfd5['getChild'](S(_0x4b6142));_0x55f89a=Rt(_0x55f89a,w(),_0x1ef94c);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x55f89a;}function Bo(_0x578ede,_0x1b71c9,_0x2c204b,_0x409ec3,_0x5881b4){if(!_0x409ec3&&!_0x5881b4){const _0x499cb0=qe(_0x578ede['visibleWrites'],_0x1b71c9);if(_0x499cb0!=null)return _0x499cb0;{const _0x489638=Ee(_0x578ede['visibleWrites'],_0x1b71c9);if(Ai(_0x489638))return _0x2c204b;if(_0x2c204b==null&&!Ri(_0x489638,w()))return null;{const _0x3d55c5=_0x2c204b||g['EMPTY_NODE'];return at(_0x489638,_0x3d55c5);}}}else{const _0x213f01=Ee(_0x578ede['visibleWrites'],_0x1b71c9);if(!_0x5881b4&&Ai(_0x213f01))return _0x2c204b;if(!_0x5881b4&&_0x2c204b==null&&!Ri(_0x213f01,w()))return null;{const _0x2e30c9=function(_0x1cd6fb){return(_0x1cd6fb['visible']||_0x5881b4)&&(!_0x409ec3||!~_0x409ec3['indexOf'](_0x1cd6fb['writeId']))&&(G(_0x1cd6fb['path'],_0x1b71c9)||G(_0x1b71c9,_0x1cd6fb['path']));},_0x6aba8b=Wo(_0x578ede['allWrites'],_0x2e30c9,_0x1b71c9),_0x5d8132=_0x2c204b||g['EMPTY_NODE'];return at(_0x6aba8b,_0x5d8132);}}}function _u(_0x459f42,_0x478e57,_0x19acdb){let _0x1b9c55=g['EMPTY_NODE'];const _0x536b3e=qe(_0x459f42['visibleWrites'],_0x478e57);if(_0x536b3e)return _0x536b3e['isLeafNode']()||_0x536b3e['forEachChild'](R,(_0x87d212,_0x4514db)=>{_0x1b9c55=_0x1b9c55['updateImmediateChild'](_0x87d212,_0x4514db);}),_0x1b9c55;if(_0x19acdb){const _0x32eb27=Ee(_0x459f42['visibleWrites'],_0x478e57);return _0x19acdb['forEachChild'](R,(_0x3e4770,_0x2da051)=>{const _0x222218=at(Ee(_0x32eb27,new C(_0x3e4770)),_0x2da051);_0x1b9c55=_0x1b9c55['updateImmediateChild'](_0x3e4770,_0x222218);}),ar(_0x32eb27)['forEach'](_0x35e08c=>{_0x1b9c55=_0x1b9c55['updateImmediateChild'](_0x35e08c['name'],_0x35e08c['node']);}),_0x1b9c55;}else{const _0x3e4859=Ee(_0x459f42['visibleWrites'],_0x478e57);return ar(_0x3e4859)['forEach'](_0x59fe0a=>{_0x1b9c55=_0x1b9c55['updateImmediateChild'](_0x59fe0a['name'],_0x59fe0a['node']);}),_0x1b9c55;}}function gu(_0x288d00,_0x440818,_0x4bce59,_0x3ba00e,_0x55131e){f(_0x3ba00e||_0x55131e,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5af33e=k(_0x440818,_0x4bce59);if(Ri(_0x288d00['visibleWrites'],_0x5af33e))return null;{const _0x26be26=Ee(_0x288d00['visibleWrites'],_0x5af33e);return Ai(_0x26be26)?_0x55131e['getChild'](_0x4bce59):at(_0x26be26,_0x55131e['getChild'](_0x4bce59));}}function mu(_0x438181,_0x4c32c4,_0x42bdd1,_0x29e2ce){const _0x9cb3c=k(_0x4c32c4,_0x42bdd1),_0x43f61d=qe(_0x438181['visibleWrites'],_0x9cb3c);if(_0x43f61d!=null)return _0x43f61d;if(_0x29e2ce['isCompleteForChild'](_0x42bdd1)){const _0x94f5af=Ee(_0x438181['visibleWrites'],_0x9cb3c);return at(_0x94f5af,_0x29e2ce['getNode']()['getImmediateChild'](_0x42bdd1));}else return null;}function yu(_0x5ee261,_0x5957ac){return qe(_0x5ee261['visibleWrites'],_0x5957ac);}function vu(_0x42ba5a,_0x27f83f,_0x6cc4f9,_0x3ca67a,_0x5d6b1a,_0x263520,_0x4917a2){let _0x277466;const _0x106873=Ee(_0x42ba5a['visibleWrites'],_0x27f83f),_0x30bd8d=qe(_0x106873,w());if(_0x30bd8d!=null)_0x277466=_0x30bd8d;else{if(_0x6cc4f9!=null)_0x277466=at(_0x106873,_0x6cc4f9);else return[];}if(_0x277466=_0x277466['withIndex'](_0x4917a2),!_0x277466['isEmpty']()&&!_0x277466['isLeafNode']()){const _0x208421=[],_0x475942=_0x4917a2['getCompare'](),_0x61a123=_0x263520?_0x277466['getReverseIteratorFrom'](_0x3ca67a,_0x4917a2):_0x277466['getIteratorFrom'](_0x3ca67a,_0x4917a2);let _0x3c753e=_0x61a123['getNext']();for(;_0x3c753e&&_0x208421['length']<_0x5d6b1a;)_0x475942(_0x3c753e,_0x3ca67a)!==0x0&&_0x208421['push'](_0x3c753e),_0x3c753e=_0x61a123['getNext']();return _0x208421;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x211cad,_0x1c91a4,_0x1c3fa8,_0x29d890){return Bo(_0x211cad['writeTree'],_0x211cad['treePath'],_0x1c91a4,_0x1c3fa8,_0x29d890);}function is(_0x49d476,_0x601b67){return _u(_0x49d476['writeTree'],_0x49d476['treePath'],_0x601b67);}function cr(_0x143e90,_0x2f68e0,_0x2c3a62,_0x4f02ef){return gu(_0x143e90['writeTree'],_0x143e90['treePath'],_0x2f68e0,_0x2c3a62,_0x4f02ef);}function Tn(_0x28f978,_0x31d308){return yu(_0x28f978['writeTree'],k(_0x28f978['treePath'],_0x31d308));}function Iu(_0x59f6fd,_0x341733,_0x148d28,_0x267880,_0x264df9,_0x346455){return vu(_0x59f6fd['writeTree'],_0x59f6fd['treePath'],_0x341733,_0x148d28,_0x267880,_0x264df9,_0x346455);}function ss(_0x5b3e12,_0xa14255,_0x3e6780){return mu(_0x5b3e12['writeTree'],_0x5b3e12['treePath'],_0xa14255,_0x3e6780);}function Vo(_0x353fa3,_0xda618e){return Ho(k(_0x353fa3['treePath'],_0xda618e),_0x353fa3['writeTree']);}function Ho(_0x5ebd21,_0x3743){return{'treePath':_0x5ebd21,'writeTree':_0x3743};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2651d6){const _0x3dfc66=_0x2651d6['type'],_0xabbf56=_0x2651d6['childName'];f(_0x3dfc66==='child_added'||_0x3dfc66==='child_changed'||_0x3dfc66==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xabbf56!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x8205ad=this['changeMap']['get'](_0xabbf56);if(_0x8205ad){const _0x66e531=_0x8205ad['type'];if(_0x3dfc66==='child_added'&&_0x66e531==='child_removed')this['changeMap']['set'](_0xabbf56,Lt(_0xabbf56,_0x2651d6['snapshotNode'],_0x8205ad['snapshotNode']));else{if(_0x3dfc66==='child_removed'&&_0x66e531==='child_added')this['changeMap']['delete'](_0xabbf56);else{if(_0x3dfc66==='child_removed'&&_0x66e531==='child_changed')this['changeMap']['set'](_0xabbf56,Mt(_0xabbf56,_0x8205ad['oldSnap']));else{if(_0x3dfc66==='child_changed'&&_0x66e531==='child_added')this['changeMap']['set'](_0xabbf56,rt(_0xabbf56,_0x2651d6['snapshotNode']));else{if(_0x3dfc66==='child_changed'&&_0x66e531==='child_changed')this['changeMap']['set'](_0xabbf56,Lt(_0xabbf56,_0x2651d6['snapshotNode'],_0x8205ad['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x2651d6+'\x20occurred\x20after\x20'+_0x8205ad);}}}}}else this['changeMap']['set'](_0xabbf56,_0x2651d6);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x12a218){return null;}['getChildAfterChild'](_0x5a1b6f,_0xa426ea,_0x162263){return null;}}const $o=new Cu();class rs{constructor(_0x205309,_0x12f848,_0x9d0433=null){this['writes_']=_0x205309,this['viewCache_']=_0x12f848,this['optCompleteServerCache_']=_0x9d0433;}['getCompleteChild'](_0x29e129){const _0x4a1ac3=this['viewCache_']['eventCache'];if(_0x4a1ac3['isCompleteForChild'](_0x29e129))return _0x4a1ac3['getNode']()['getImmediateChild'](_0x29e129);{const _0x11a806=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x29e129,_0x11a806);}}['getChildAfterChild'](_0x2f4bb7,_0x3da67e,_0x5b9518){const _0x431aa8=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x24d776=Iu(this['writes_'],_0x431aa8,_0x3da67e,0x1,_0x5b9518,_0x2f4bb7);return _0x24d776['length']===0x0?null:_0x24d776[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x94c58a){return{'filter':_0x94c58a};}function Su(_0xbdf3ea,_0x546f5f){f(_0x546f5f['eventCache']['getNode']()['isIndexed'](_0xbdf3ea['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x546f5f['serverCache']['getNode']()['isIndexed'](_0xbdf3ea['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x42e639,_0x3b3c45,_0x590254,_0x771741,_0xfad2f6){const _0x4126f4=new wu();let _0x2727a6,_0x3e45de;if(_0x590254['type']===z['OVERWRITE']){const _0x3a3ed3=_0x590254;_0x3a3ed3['source']['fromUser']?_0x2727a6=ki(_0x42e639,_0x3b3c45,_0x3a3ed3['path'],_0x3a3ed3['snap'],_0x771741,_0xfad2f6,_0x4126f4):(f(_0x3a3ed3['source']['fromServer'],'Unknown\x20source.'),_0x3e45de=_0x3a3ed3['source']['tagged']||_0x3b3c45['serverCache']['isFiltered']()&&!v(_0x3a3ed3['path']),_0x2727a6=Sn(_0x42e639,_0x3b3c45,_0x3a3ed3['path'],_0x3a3ed3['snap'],_0x771741,_0xfad2f6,_0x3e45de,_0x4126f4));}else{if(_0x590254['type']===z['MERGE']){const _0x558735=_0x590254;_0x558735['source']['fromUser']?_0x2727a6=Au(_0x42e639,_0x3b3c45,_0x558735['path'],_0x558735['children'],_0x771741,_0xfad2f6,_0x4126f4):(f(_0x558735['source']['fromServer'],'Unknown\x20source.'),_0x3e45de=_0x558735['source']['tagged']||_0x3b3c45['serverCache']['isFiltered'](),_0x2727a6=Ni(_0x42e639,_0x3b3c45,_0x558735['path'],_0x558735['children'],_0x771741,_0xfad2f6,_0x3e45de,_0x4126f4));}else{if(_0x590254['type']===z['ACK_USER_WRITE']){const _0x2af92a=_0x590254;_0x2af92a['revert']?_0x2727a6=Pu(_0x42e639,_0x3b3c45,_0x2af92a['path'],_0x771741,_0xfad2f6,_0x4126f4):_0x2727a6=ku(_0x42e639,_0x3b3c45,_0x2af92a['path'],_0x2af92a['affectedTree'],_0x771741,_0xfad2f6,_0x4126f4);}else{if(_0x590254['type']===z['LISTEN_COMPLETE'])_0x2727a6=Nu(_0x42e639,_0x3b3c45,_0x590254['path'],_0x771741,_0x4126f4);else throw ht('Unknown\x20operation\x20type:\x20'+_0x590254['type']);}}}const _0x47d7d7=_0x4126f4['getChanges']();return Ru(_0x3b3c45,_0x2727a6,_0x47d7d7),{'viewCache':_0x2727a6,'changes':_0x47d7d7};}function Ru(_0x205a11,_0x3ab73c,_0x51dc74){const _0x5f081f=_0x3ab73c['eventCache'];if(_0x5f081f['isFullyInitialized']()){const _0x10b853=_0x5f081f['getNode']()['isLeafNode']()||_0x5f081f['getNode']()['isEmpty'](),_0x2dee12=wn(_0x205a11);(_0x51dc74['length']>0x0||!_0x205a11['eventCache']['isFullyInitialized']()||_0x10b853&&!_0x5f081f['getNode']()['equals'](_0x2dee12)||!_0x5f081f['getNode']()['getPriority']()['equals'](_0x2dee12['getPriority']()))&&_0x51dc74['push'](Lo(wn(_0x3ab73c)));}}function Go(_0x16de76,_0x1868c4,_0x40a4fe,_0x188a83,_0x149c72,_0x54c7e0){const _0x2e35b3=_0x1868c4['eventCache'];if(Tn(_0x188a83,_0x40a4fe)!=null)return _0x1868c4;{let _0x5b9daa,_0x157749;if(v(_0x40a4fe)){if(f(_0x1868c4['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1868c4['serverCache']['isFiltered']()){const _0x32917d=Be(_0x1868c4),_0x489c59=_0x32917d instanceof g?_0x32917d:g['EMPTY_NODE'],_0x252a6b=is(_0x188a83,_0x489c59);_0x5b9daa=_0x16de76['filter']['updateFullNode'](_0x1868c4['eventCache']['getNode'](),_0x252a6b,_0x54c7e0);}else{const _0x21c84d=Cn(_0x188a83,Be(_0x1868c4));_0x5b9daa=_0x16de76['filter']['updateFullNode'](_0x1868c4['eventCache']['getNode'](),_0x21c84d,_0x54c7e0);}}else{const _0x256d5c=y(_0x40a4fe);if(_0x256d5c==='.priority'){f(Ce(_0x40a4fe)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4d6126=_0x2e35b3['getNode']();_0x157749=_0x1868c4['serverCache']['getNode']();const _0x2b7d7f=cr(_0x188a83,_0x40a4fe,_0x4d6126,_0x157749);_0x2b7d7f!=null?_0x5b9daa=_0x16de76['filter']['updatePriority'](_0x4d6126,_0x2b7d7f):_0x5b9daa=_0x2e35b3['getNode']();}else{const _0x143dfd=S(_0x40a4fe);let _0x2a9612;if(_0x2e35b3['isCompleteForChild'](_0x256d5c)){_0x157749=_0x1868c4['serverCache']['getNode']();const _0x189f0b=cr(_0x188a83,_0x40a4fe,_0x2e35b3['getNode'](),_0x157749);_0x189f0b!=null?_0x2a9612=_0x2e35b3['getNode']()['getImmediateChild'](_0x256d5c)['updateChild'](_0x143dfd,_0x189f0b):_0x2a9612=_0x2e35b3['getNode']()['getImmediateChild'](_0x256d5c);}else _0x2a9612=ss(_0x188a83,_0x256d5c,_0x1868c4['serverCache']);_0x2a9612!=null?_0x5b9daa=_0x16de76['filter']['updateChild'](_0x2e35b3['getNode'](),_0x256d5c,_0x2a9612,_0x143dfd,_0x149c72,_0x54c7e0):_0x5b9daa=_0x2e35b3['getNode']();}}return bt(_0x1868c4,_0x5b9daa,_0x2e35b3['isFullyInitialized']()||v(_0x40a4fe),_0x16de76['filter']['filtersNodes']());}}function Sn(_0x4697d6,_0x442c8c,_0x1ae520,_0x349700,_0x187b19,_0x4e9f55,_0x2cc705,_0x548b14){const _0x5a4ecf=_0x442c8c['serverCache'];let _0x55737e;const _0x3cdd92=_0x2cc705?_0x4697d6['filter']:_0x4697d6['filter']['getIndexedFilter']();if(v(_0x1ae520))_0x55737e=_0x3cdd92['updateFullNode'](_0x5a4ecf['getNode'](),_0x349700,null);else{if(_0x3cdd92['filtersNodes']()&&!_0x5a4ecf['isFiltered']()){const _0x29dbf9=_0x5a4ecf['getNode']()['updateChild'](_0x1ae520,_0x349700);_0x55737e=_0x3cdd92['updateFullNode'](_0x5a4ecf['getNode'](),_0x29dbf9,null);}else{const _0x930a3e=y(_0x1ae520);if(!_0x5a4ecf['isCompleteForPath'](_0x1ae520)&&Ce(_0x1ae520)>0x1)return _0x442c8c;const _0x916ec5=S(_0x1ae520),_0x427751=_0x5a4ecf['getNode']()['getImmediateChild'](_0x930a3e)['updateChild'](_0x916ec5,_0x349700);_0x930a3e==='.priority'?_0x55737e=_0x3cdd92['updatePriority'](_0x5a4ecf['getNode'](),_0x427751):_0x55737e=_0x3cdd92['updateChild'](_0x5a4ecf['getNode'](),_0x930a3e,_0x427751,_0x916ec5,$o,null);}}const _0x58c2c7=Fo(_0x442c8c,_0x55737e,_0x5a4ecf['isFullyInitialized']()||v(_0x1ae520),_0x3cdd92['filtersNodes']()),_0xba486a=new rs(_0x187b19,_0x58c2c7,_0x4e9f55);return Go(_0x4697d6,_0x58c2c7,_0x1ae520,_0x187b19,_0xba486a,_0x548b14);}function ki(_0x425dc2,_0x3ec93d,_0x533818,_0x1a7ca4,_0x5be4ec,_0x3cecc3,_0x587de4){const _0x40fa2d=_0x3ec93d['eventCache'];let _0x4055ce,_0x42974c;const _0x3cbbf9=new rs(_0x5be4ec,_0x3ec93d,_0x3cecc3);if(v(_0x533818))_0x42974c=_0x425dc2['filter']['updateFullNode'](_0x3ec93d['eventCache']['getNode'](),_0x1a7ca4,_0x587de4),_0x4055ce=bt(_0x3ec93d,_0x42974c,!0x0,_0x425dc2['filter']['filtersNodes']());else{const _0x248770=y(_0x533818);if(_0x248770==='.priority')_0x42974c=_0x425dc2['filter']['updatePriority'](_0x3ec93d['eventCache']['getNode'](),_0x1a7ca4),_0x4055ce=bt(_0x3ec93d,_0x42974c,_0x40fa2d['isFullyInitialized'](),_0x40fa2d['isFiltered']());else{const _0x50746a=S(_0x533818),_0x122a43=_0x40fa2d['getNode']()['getImmediateChild'](_0x248770);let _0x439afe;if(v(_0x50746a))_0x439afe=_0x1a7ca4;else{const _0x54b5a9=_0x3cbbf9['getCompleteChild'](_0x248770);_0x54b5a9!=null?ji(_0x50746a)==='.priority'&&_0x54b5a9['getChild'](Ro(_0x50746a))['isEmpty']()?_0x439afe=_0x54b5a9:_0x439afe=_0x54b5a9['updateChild'](_0x50746a,_0x1a7ca4):_0x439afe=g['EMPTY_NODE'];}if(_0x122a43['equals'](_0x439afe))_0x4055ce=_0x3ec93d;else{const _0x1527a6=_0x425dc2['filter']['updateChild'](_0x40fa2d['getNode'](),_0x248770,_0x439afe,_0x50746a,_0x3cbbf9,_0x587de4);_0x4055ce=bt(_0x3ec93d,_0x1527a6,_0x40fa2d['isFullyInitialized'](),_0x425dc2['filter']['filtersNodes']());}}}return _0x4055ce;}function lr(_0x5447d2,_0x3fa6de){return _0x5447d2['eventCache']['isCompleteForChild'](_0x3fa6de);}function Au(_0x5e3f7e,_0x4f0a01,_0x10b1d,_0x43c53f,_0x4d9f79,_0x38b601,_0x424611){let _0xee2865=_0x4f0a01;return _0x43c53f['foreach']((_0x5b682d,_0x130a36)=>{const _0x8cfd5c=k(_0x10b1d,_0x5b682d);lr(_0x4f0a01,y(_0x8cfd5c))&&(_0xee2865=ki(_0x5e3f7e,_0xee2865,_0x8cfd5c,_0x130a36,_0x4d9f79,_0x38b601,_0x424611));}),_0x43c53f['foreach']((_0x1b51cb,_0x422b73)=>{const _0x514be6=k(_0x10b1d,_0x1b51cb);lr(_0x4f0a01,y(_0x514be6))||(_0xee2865=ki(_0x5e3f7e,_0xee2865,_0x514be6,_0x422b73,_0x4d9f79,_0x38b601,_0x424611));}),_0xee2865;}function hr(_0x9c9fb6,_0x48142b,_0x15e750){return _0x15e750['foreach']((_0x1aa66d,_0x3edd63)=>{_0x48142b=_0x48142b['updateChild'](_0x1aa66d,_0x3edd63);}),_0x48142b;}function Ni(_0x3bd2d8,_0x4cec45,_0x18ac2b,_0xe6c2f,_0x24f476,_0x581c70,_0x47320f,_0x4520b8){if(_0x4cec45['serverCache']['getNode']()['isEmpty']()&&!_0x4cec45['serverCache']['isFullyInitialized']())return _0x4cec45;let _0x21924c=_0x4cec45,_0x206350;v(_0x18ac2b)?_0x206350=_0xe6c2f:_0x206350=new b(null)['setTree'](_0x18ac2b,_0xe6c2f);const _0x36604e=_0x4cec45['serverCache']['getNode']();return _0x206350['children']['inorderTraversal']((_0x341c68,_0x3c07ad)=>{if(_0x36604e['hasChild'](_0x341c68)){const _0x83eb49=_0x4cec45['serverCache']['getNode']()['getImmediateChild'](_0x341c68),_0x46818a=hr(_0x3bd2d8,_0x83eb49,_0x3c07ad);_0x21924c=Sn(_0x3bd2d8,_0x21924c,new C(_0x341c68),_0x46818a,_0x24f476,_0x581c70,_0x47320f,_0x4520b8);}}),_0x206350['children']['inorderTraversal']((_0x2ca762,_0x1325fe)=>{const _0x28e447=!_0x4cec45['serverCache']['isCompleteForChild'](_0x2ca762)&&_0x1325fe['value']===null;if(!_0x36604e['hasChild'](_0x2ca762)&&!_0x28e447){const _0x49af7b=_0x4cec45['serverCache']['getNode']()['getImmediateChild'](_0x2ca762),_0x3191ba=hr(_0x3bd2d8,_0x49af7b,_0x1325fe);_0x21924c=Sn(_0x3bd2d8,_0x21924c,new C(_0x2ca762),_0x3191ba,_0x24f476,_0x581c70,_0x47320f,_0x4520b8);}}),_0x21924c;}function ku(_0xf3d589,_0x1911e2,_0x5691ac,_0x5acaee,_0x344be2,_0x1ce903,_0x5769ed){if(Tn(_0x344be2,_0x5691ac)!=null)return _0x1911e2;const _0x5ab2fc=_0x1911e2['serverCache']['isFiltered'](),_0x47031b=_0x1911e2['serverCache'];if(_0x5acaee['value']!=null){if(v(_0x5691ac)&&_0x47031b['isFullyInitialized']()||_0x47031b['isCompleteForPath'](_0x5691ac))return Sn(_0xf3d589,_0x1911e2,_0x5691ac,_0x47031b['getNode']()['getChild'](_0x5691ac),_0x344be2,_0x1ce903,_0x5ab2fc,_0x5769ed);if(v(_0x5691ac)){let _0x5cdbc6=new b(null);return _0x47031b['getNode']()['forEachChild'](ve,(_0x481789,_0x1f0896)=>{_0x5cdbc6=_0x5cdbc6['set'](new C(_0x481789),_0x1f0896);}),Ni(_0xf3d589,_0x1911e2,_0x5691ac,_0x5cdbc6,_0x344be2,_0x1ce903,_0x5ab2fc,_0x5769ed);}else return _0x1911e2;}else{let _0x255981=new b(null);return _0x5acaee['foreach']((_0x784c76,_0x22bb55)=>{const _0x79da8e=k(_0x5691ac,_0x784c76);_0x47031b['isCompleteForPath'](_0x79da8e)&&(_0x255981=_0x255981['set'](_0x784c76,_0x47031b['getNode']()['getChild'](_0x79da8e)));}),Ni(_0xf3d589,_0x1911e2,_0x5691ac,_0x255981,_0x344be2,_0x1ce903,_0x5ab2fc,_0x5769ed);}}function Nu(_0x1d4667,_0x59f160,_0x446392,_0x48f4b2,_0x13aa04){const _0x1a8953=_0x59f160['serverCache'],_0x3a1218=Fo(_0x59f160,_0x1a8953['getNode'](),_0x1a8953['isFullyInitialized']()||v(_0x446392),_0x1a8953['isFiltered']());return Go(_0x1d4667,_0x3a1218,_0x446392,_0x48f4b2,$o,_0x13aa04);}function Pu(_0x249446,_0x514a66,_0x9f0712,_0x24768b,_0x16d807,_0x109d6a){let _0x2165a3;if(Tn(_0x24768b,_0x9f0712)!=null)return _0x514a66;{const _0x31fd75=new rs(_0x24768b,_0x514a66,_0x16d807),_0x440139=_0x514a66['eventCache']['getNode']();let _0xeebb5c;if(v(_0x9f0712)||y(_0x9f0712)==='.priority'){let _0x5789c0;if(_0x514a66['serverCache']['isFullyInitialized']())_0x5789c0=Cn(_0x24768b,Be(_0x514a66));else{const _0x17bec5=_0x514a66['serverCache']['getNode']();f(_0x17bec5 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5789c0=is(_0x24768b,_0x17bec5);}_0x5789c0=_0x5789c0,_0xeebb5c=_0x249446['filter']['updateFullNode'](_0x440139,_0x5789c0,_0x109d6a);}else{const _0x2dd156=y(_0x9f0712);let _0x19321a=ss(_0x24768b,_0x2dd156,_0x514a66['serverCache']);_0x19321a==null&&_0x514a66['serverCache']['isCompleteForChild'](_0x2dd156)&&(_0x19321a=_0x440139['getImmediateChild'](_0x2dd156)),_0x19321a!=null?_0xeebb5c=_0x249446['filter']['updateChild'](_0x440139,_0x2dd156,_0x19321a,S(_0x9f0712),_0x31fd75,_0x109d6a):_0x514a66['eventCache']['getNode']()['hasChild'](_0x2dd156)?_0xeebb5c=_0x249446['filter']['updateChild'](_0x440139,_0x2dd156,g['EMPTY_NODE'],S(_0x9f0712),_0x31fd75,_0x109d6a):_0xeebb5c=_0x440139,_0xeebb5c['isEmpty']()&&_0x514a66['serverCache']['isFullyInitialized']()&&(_0x2165a3=Cn(_0x24768b,Be(_0x514a66)),_0x2165a3['isLeafNode']()&&(_0xeebb5c=_0x249446['filter']['updateFullNode'](_0xeebb5c,_0x2165a3,_0x109d6a)));}return _0x2165a3=_0x514a66['serverCache']['isFullyInitialized']()||Tn(_0x24768b,w())!=null,bt(_0x514a66,_0xeebb5c,_0x2165a3,_0x249446['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x5eacac,_0x1c40ad){this['query_']=_0x5eacac,this['eventRegistrations_']=[];const _0x3f5c21=this['query_']['_queryParams'],_0x2221d9=new Xi(_0x3f5c21['getIndex']()),_0xd3acae=Kh(_0x3f5c21);this['processor_']=Tu(_0xd3acae);const _0x32e514=_0x1c40ad['serverCache'],_0x3b62a4=_0x1c40ad['eventCache'],_0x4aaab9=_0x2221d9['updateFullNode'](g['EMPTY_NODE'],_0x32e514['getNode'](),null),_0x2ec1e0=_0xd3acae['updateFullNode'](g['EMPTY_NODE'],_0x3b62a4['getNode'](),null),_0x134eec=new Te(_0x4aaab9,_0x32e514['isFullyInitialized'](),_0x2221d9['filtersNodes']()),_0x1b44fb=new Te(_0x2ec1e0,_0x3b62a4['isFullyInitialized'](),_0xd3acae['filtersNodes']());this['viewCache_']=Un(_0x1b44fb,_0x134eec),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0x2c959c){return _0x2c959c['viewCache_']['serverCache']['getNode']();}function Mu(_0x4b6a2b){return wn(_0x4b6a2b['viewCache_']);}function Lu(_0x2a5140,_0x50e521){const _0x267440=Be(_0x2a5140['viewCache_']);return _0x267440&&(_0x2a5140['query']['_queryParams']['loadsAllData']()||!v(_0x50e521)&&!_0x267440['getImmediateChild'](y(_0x50e521))['isEmpty']())?_0x267440['getChild'](_0x50e521):null;}function ur(_0x30e5c8){return _0x30e5c8['eventRegistrations_']['length']===0x0;}function xu(_0x1d60ed,_0x5c5fa1){_0x1d60ed['eventRegistrations_']['push'](_0x5c5fa1);}function dr(_0x1086cf,_0x3bcdf8,_0x47b484){const _0x1c730c=[];if(_0x47b484){f(_0x3bcdf8==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x28e21a=_0x1086cf['query']['_path'];_0x1086cf['eventRegistrations_']['forEach'](_0x35355a=>{const _0x15eb1f=_0x35355a['createCancelEvent'](_0x47b484,_0x28e21a);_0x15eb1f&&_0x1c730c['push'](_0x15eb1f);});}if(_0x3bcdf8){let _0x3a632b=[];for(let _0x3adc89=0x0;_0x3adc89<_0x1086cf['eventRegistrations_']['length'];++_0x3adc89){const _0x205f9f=_0x1086cf['eventRegistrations_'][_0x3adc89];if(!_0x205f9f['matches'](_0x3bcdf8))_0x3a632b['push'](_0x205f9f);else{if(_0x3bcdf8['hasAnyCallback']()){_0x3a632b=_0x3a632b['concat'](_0x1086cf['eventRegistrations_']['slice'](_0x3adc89+0x1));break;}}}_0x1086cf['eventRegistrations_']=_0x3a632b;}else _0x1086cf['eventRegistrations_']=[];return _0x1c730c;}function fr(_0x1fa8cd,_0x85b4f5,_0x538712,_0x2e619a){_0x85b4f5['type']===z['MERGE']&&_0x85b4f5['source']['queryId']!==null&&(f(Be(_0x1fa8cd['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x1fa8cd['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x54afd3=_0x1fa8cd['viewCache_'],_0xeb9ef0=bu(_0x1fa8cd['processor_'],_0x54afd3,_0x85b4f5,_0x538712,_0x2e619a);return Su(_0x1fa8cd['processor_'],_0xeb9ef0['viewCache']),f(_0xeb9ef0['viewCache']['serverCache']['isFullyInitialized']()||!_0x54afd3['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1fa8cd['viewCache_']=_0xeb9ef0['viewCache'],qo(_0x1fa8cd,_0xeb9ef0['changes'],_0xeb9ef0['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x5cb49d,_0x28d789){const _0x43a6c4=_0x5cb49d['viewCache_']['eventCache'],_0x9c0e0c=[];return _0x43a6c4['getNode']()['isLeafNode']()||_0x43a6c4['getNode']()['forEachChild'](R,(_0x2d1d57,_0x390b30)=>{_0x9c0e0c['push'](rt(_0x2d1d57,_0x390b30));}),_0x43a6c4['isFullyInitialized']()&&_0x9c0e0c['push'](Lo(_0x43a6c4['getNode']())),qo(_0x5cb49d,_0x9c0e0c,_0x43a6c4['getNode'](),_0x28d789);}function qo(_0x31e4ae,_0x56ca17,_0x5f4d46,_0x429608){const _0x2e6100=_0x429608?[_0x429608]:_0x31e4ae['eventRegistrations_'];return su(_0x31e4ae['eventGenerator_'],_0x56ca17,_0x5f4d46,_0x2e6100);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x22fdf9){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x22fdf9;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x2f1a78){return _0x2f1a78['views']['size']===0x0;}function os(_0x4d8554,_0x13c735,_0x3ec7c4,_0x3af379){const _0x4a7ee2=_0x13c735['source']['queryId'];if(_0x4a7ee2!==null){const _0x28afbc=_0x4d8554['views']['get'](_0x4a7ee2);return f(_0x28afbc!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x28afbc,_0x13c735,_0x3ec7c4,_0x3af379);}else{let _0x2b096f=[];for(const _0x27da00 of _0x4d8554['views']['values']())_0x2b096f=_0x2b096f['concat'](fr(_0x27da00,_0x13c735,_0x3ec7c4,_0x3af379));return _0x2b096f;}}function jo(_0x254996,_0x3e4ffe,_0x45d366,_0x282edb,_0x3bab4a){const _0x1ec401=_0x3e4ffe['_queryIdentifier'],_0x589e32=_0x254996['views']['get'](_0x1ec401);if(!_0x589e32){let _0x42e469=Cn(_0x45d366,_0x3bab4a?_0x282edb:null),_0x234c52=!0x1;_0x42e469?_0x234c52=!0x0:_0x282edb instanceof g?(_0x42e469=is(_0x45d366,_0x282edb),_0x234c52=!0x1):(_0x42e469=g['EMPTY_NODE'],_0x234c52=!0x1);const _0x893708=Un(new Te(_0x42e469,_0x234c52,!0x1),new Te(_0x282edb,_0x3bab4a,!0x1));return new Ou(_0x3e4ffe,_0x893708);}return _0x589e32;}function Vu(_0x506840,_0x22cf52,_0x3e0840,_0x42ea65,_0x14f4ae,_0x2ab050){const _0x18b6b3=jo(_0x506840,_0x22cf52,_0x42ea65,_0x14f4ae,_0x2ab050);return _0x506840['views']['has'](_0x22cf52['_queryIdentifier'])||_0x506840['views']['set'](_0x22cf52['_queryIdentifier'],_0x18b6b3),xu(_0x18b6b3,_0x3e0840),Fu(_0x18b6b3,_0x3e0840);}function Hu(_0x1b8366,_0x409a21,_0x195ddb,_0x3bd47b){const _0x5ad577=_0x409a21['_queryIdentifier'],_0x89669d=[];let _0x402de9=[];const _0x4acd0c=Se(_0x1b8366);if(_0x5ad577==='default'){for(const [_0x5dc690,_0x239460]of _0x1b8366['views']['entries']())_0x402de9=_0x402de9['concat'](dr(_0x239460,_0x195ddb,_0x3bd47b)),ur(_0x239460)&&(_0x1b8366['views']['delete'](_0x5dc690),_0x239460['query']['_queryParams']['loadsAllData']()||_0x89669d['push'](_0x239460['query']));}else{const _0x397525=_0x1b8366['views']['get'](_0x5ad577);_0x397525&&(_0x402de9=_0x402de9['concat'](dr(_0x397525,_0x195ddb,_0x3bd47b)),ur(_0x397525)&&(_0x1b8366['views']['delete'](_0x5ad577),_0x397525['query']['_queryParams']['loadsAllData']()||_0x89669d['push'](_0x397525['query'])));}return _0x4acd0c&&!Se(_0x1b8366)&&_0x89669d['push'](new(Wu())(_0x409a21['_repo'],_0x409a21['_path'])),{'removed':_0x89669d,'events':_0x402de9};}function Ko(_0x7d1cb8){const _0xfd1f43=[];for(const _0x3b9635 of _0x7d1cb8['views']['values']())_0x3b9635['query']['_queryParams']['loadsAllData']()||_0xfd1f43['push'](_0x3b9635);return _0xfd1f43;}function Ie(_0x27f686,_0x479b4f){let _0x29097b=null;for(const _0xef6ee5 of _0x27f686['views']['values']())_0x29097b=_0x29097b||Lu(_0xef6ee5,_0x479b4f);return _0x29097b;}function Yo(_0x1a88dc,_0x3b2ff4){if(_0x3b2ff4['_queryParams']['loadsAllData']())return Bn(_0x1a88dc);{const _0x5922a6=_0x3b2ff4['_queryIdentifier'];return _0x1a88dc['views']['get'](_0x5922a6);}}function Qo(_0x3e7452,_0x118554){return Yo(_0x3e7452,_0x118554)!=null;}function Se(_0x314db3){return Bn(_0x314db3)!=null;}function Bn(_0x142d20){for(const _0x519e2a of _0x142d20['views']['values']())if(_0x519e2a['query']['_queryParams']['loadsAllData']())return _0x519e2a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x18e848){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x18e848;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x5b3da6){this['listenProvider_']=_0x5b3da6,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x587b27,_0x3109b7,_0x444b24,_0x4ddbfa,_0x2da540){return cu(_0x587b27['pendingWriteTree_'],_0x3109b7,_0x444b24,_0x4ddbfa,_0x2da540),_0x2da540?_t(_0x587b27,new We(es(),_0x3109b7,_0x444b24)):[];}function zu(_0x44b69e,_0x3d791d,_0x21924a,_0x18d6ee){lu(_0x44b69e['pendingWriteTree_'],_0x3d791d,_0x21924a,_0x18d6ee);const _0x3acac8=b['fromObject'](_0x21924a);return _t(_0x44b69e,new ot(es(),_0x3d791d,_0x3acac8));}function _e(_0x1a36a8,_0xf58cb0,_0x4c57f7=!0x1){const _0x3ccb93=hu(_0x1a36a8['pendingWriteTree_'],_0xf58cb0);if(uu(_0x1a36a8['pendingWriteTree_'],_0xf58cb0)){let _0x300e97=new b(null);return _0x3ccb93['snap']!=null?_0x300e97=_0x300e97['set'](w(),!0x0):x(_0x3ccb93['children'],_0x312c7a=>{_0x300e97=_0x300e97['set'](new C(_0x312c7a),!0x0);}),_t(_0x1a36a8,new In(_0x3ccb93['path'],_0x300e97,_0x4c57f7));}else return[];}function Kt(_0x489dec,_0x45831d,_0x5eb036){return _t(_0x489dec,new We(ts(),_0x45831d,_0x5eb036));}function ju(_0x23122b,_0x4f7f92,_0x42e616){const _0x2b9c93=b['fromObject'](_0x42e616);return _t(_0x23122b,new ot(ts(),_0x4f7f92,_0x2b9c93));}function Ku(_0x481214,_0x41a1c3){return _t(_0x481214,new Ft(ts(),_0x41a1c3));}function Yu(_0x108c39,_0x1eee9b,_0x2b0c0a){const _0x4af4c6=cs(_0x108c39,_0x2b0c0a);if(_0x4af4c6){const _0x4ce698=ls(_0x4af4c6),_0x36c822=_0x4ce698['path'],_0x3fee56=_0x4ce698['queryId'],_0x4dc94e=F(_0x36c822,_0x1eee9b),_0x157b8d=new Ft(ns(_0x3fee56),_0x4dc94e);return hs(_0x108c39,_0x36c822,_0x157b8d);}else return[];}function An(_0x4fdce9,_0x3e4fd4,_0x8a482f,_0x124b75,_0x27c147=!0x1){const _0x166ec4=_0x3e4fd4['_path'],_0x34bda6=_0x4fdce9['syncPointTree_']['get'](_0x166ec4);let _0x445718=[];if(_0x34bda6&&(_0x3e4fd4['_queryIdentifier']==='default'||Qo(_0x34bda6,_0x3e4fd4))){const _0x5c56b9=Hu(_0x34bda6,_0x3e4fd4,_0x8a482f,_0x124b75);Bu(_0x34bda6)&&(_0x4fdce9['syncPointTree_']=_0x4fdce9['syncPointTree_']['remove'](_0x166ec4));const _0x44b24a=_0x5c56b9['removed'];if(_0x445718=_0x5c56b9['events'],!_0x27c147){const _0x56133f=_0x44b24a['findIndex'](_0x4dccd5=>_0x4dccd5['_queryParams']['loadsAllData']())!==-0x1,_0x4d4c45=_0x4fdce9['syncPointTree_']['findOnPath'](_0x166ec4,(_0x1e81ee,_0x45df96)=>Se(_0x45df96));if(_0x56133f&&!_0x4d4c45){const _0x53bf27=_0x4fdce9['syncPointTree_']['subtree'](_0x166ec4);if(!_0x53bf27['isEmpty']()){const _0x388367=Xu(_0x53bf27);for(let _0x5b0d84=0x0;_0x5b0d84<_0x388367['length'];++_0x5b0d84){const _0xa40e97=_0x388367[_0x5b0d84],_0x2bfdf8=_0xa40e97['query'],_0x1b7676=ea(_0x4fdce9,_0xa40e97);_0x4fdce9['listenProvider_']['startListening'](At(_0x2bfdf8),Ut(_0x4fdce9,_0x2bfdf8),_0x1b7676['hashFn'],_0x1b7676['onComplete']);}}}!_0x4d4c45&&_0x44b24a['length']>0x0&&!_0x124b75&&(_0x56133f?_0x4fdce9['listenProvider_']['stopListening'](At(_0x3e4fd4),null):_0x44b24a['forEach'](_0x486894=>{const _0x39a939=_0x4fdce9['queryToTagMap']['get'](Hn(_0x486894));_0x4fdce9['listenProvider_']['stopListening'](At(_0x486894),_0x39a939);}));}Zu(_0x4fdce9,_0x44b24a);}return _0x445718;}function Jo(_0x41e24b,_0x750126,_0x286db2,_0x13deb7){const _0x4d5cf3=cs(_0x41e24b,_0x13deb7);if(_0x4d5cf3!=null){const _0x15cfc4=ls(_0x4d5cf3),_0x283fa8=_0x15cfc4['path'],_0x480747=_0x15cfc4['queryId'],_0x26ecd1=F(_0x283fa8,_0x750126),_0x4cdb5c=new We(ns(_0x480747),_0x26ecd1,_0x286db2);return hs(_0x41e24b,_0x283fa8,_0x4cdb5c);}else return[];}function Qu(_0x3a3e5a,_0x4a1262,_0x337d8c,_0x3ee3b6){const _0x43b302=cs(_0x3a3e5a,_0x3ee3b6);if(_0x43b302){const _0x5b9ae0=ls(_0x43b302),_0x5a715e=_0x5b9ae0['path'],_0xd888ae=_0x5b9ae0['queryId'],_0x1c7c1c=F(_0x5a715e,_0x4a1262),_0x42fe7c=b['fromObject'](_0x337d8c),_0x10cb69=new ot(ns(_0xd888ae),_0x1c7c1c,_0x42fe7c);return hs(_0x3a3e5a,_0x5a715e,_0x10cb69);}else return[];}function Pi(_0x1d587c,_0x461d25,_0x1967fd,_0x242b70=!0x1){const _0x43953e=_0x461d25['_path'];let _0x28d33e=null,_0x1f4193=!0x1;_0x1d587c['syncPointTree_']['foreachOnPath'](_0x43953e,(_0x5cd041,_0x1dbfa0)=>{const _0x23a059=F(_0x5cd041,_0x43953e);_0x28d33e=_0x28d33e||Ie(_0x1dbfa0,_0x23a059),_0x1f4193=_0x1f4193||Se(_0x1dbfa0);});let _0x4ed1a2=_0x1d587c['syncPointTree_']['get'](_0x43953e);_0x4ed1a2?(_0x1f4193=_0x1f4193||Se(_0x4ed1a2),_0x28d33e=_0x28d33e||Ie(_0x4ed1a2,w())):(_0x4ed1a2=new zo(),_0x1d587c['syncPointTree_']=_0x1d587c['syncPointTree_']['set'](_0x43953e,_0x4ed1a2));let _0x4d5d21;_0x28d33e!=null?_0x4d5d21=!0x0:(_0x4d5d21=!0x1,_0x28d33e=g['EMPTY_NODE'],_0x1d587c['syncPointTree_']['subtree'](_0x43953e)['foreachChild']((_0x5a493a,_0x5c1086)=>{const _0x5cccd0=Ie(_0x5c1086,w());_0x5cccd0&&(_0x28d33e=_0x28d33e['updateImmediateChild'](_0x5a493a,_0x5cccd0));}));const _0x21ffb4=Qo(_0x4ed1a2,_0x461d25);if(!_0x21ffb4&&!_0x461d25['_queryParams']['loadsAllData']()){const _0x4c30cb=Hn(_0x461d25);f(!_0x1d587c['queryToTagMap']['has'](_0x4c30cb),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3e4322=ed();_0x1d587c['queryToTagMap']['set'](_0x4c30cb,_0x3e4322),_0x1d587c['tagToQueryMap']['set'](_0x3e4322,_0x4c30cb);}const _0x3f1388=Wn(_0x1d587c['pendingWriteTree_'],_0x43953e);let _0x2f827d=Vu(_0x4ed1a2,_0x461d25,_0x1967fd,_0x3f1388,_0x28d33e,_0x4d5d21);if(!_0x21ffb4&&!_0x1f4193&&!_0x242b70){const _0x270756=Yo(_0x4ed1a2,_0x461d25);_0x2f827d=_0x2f827d['concat'](td(_0x1d587c,_0x461d25,_0x270756));}return _0x2f827d;}function Vn(_0x228d9e,_0x1aca76,_0x42f187){const _0x37f5d0=_0x228d9e['pendingWriteTree_'],_0x166c69=_0x228d9e['syncPointTree_']['findOnPath'](_0x1aca76,(_0x4298ae,_0x3fa5cd)=>{const _0x3d4bff=F(_0x4298ae,_0x1aca76),_0xb94a0a=Ie(_0x3fa5cd,_0x3d4bff);if(_0xb94a0a)return _0xb94a0a;});return Bo(_0x37f5d0,_0x1aca76,_0x166c69,_0x42f187,!0x0);}function Ju(_0x17418d,_0x38a88b){const _0x30eb66=_0x38a88b['_path'];let _0x2dafd9=null;_0x17418d['syncPointTree_']['foreachOnPath'](_0x30eb66,(_0x5400ac,_0x58959d)=>{const _0x5ac0f2=F(_0x5400ac,_0x30eb66);_0x2dafd9=_0x2dafd9||Ie(_0x58959d,_0x5ac0f2);});let _0x54f81e=_0x17418d['syncPointTree_']['get'](_0x30eb66);_0x54f81e?_0x2dafd9=_0x2dafd9||Ie(_0x54f81e,w()):(_0x54f81e=new zo(),_0x17418d['syncPointTree_']=_0x17418d['syncPointTree_']['set'](_0x30eb66,_0x54f81e));const _0x52e4cc=_0x2dafd9!=null,_0x88c810=_0x52e4cc?new Te(_0x2dafd9,!0x0,!0x1):null,_0x1c27ea=Wn(_0x17418d['pendingWriteTree_'],_0x38a88b['_path']),_0x4c4a5f=jo(_0x54f81e,_0x38a88b,_0x1c27ea,_0x52e4cc?_0x88c810['getNode']():g['EMPTY_NODE'],_0x52e4cc);return Mu(_0x4c4a5f);}function _t(_0x33d675,_0x57e575){return Xo(_0x57e575,_0x33d675['syncPointTree_'],null,Wn(_0x33d675['pendingWriteTree_'],w()));}function Xo(_0x1bd46b,_0x4ebc19,_0x453223,_0x362a99){if(v(_0x1bd46b['path']))return Zo(_0x1bd46b,_0x4ebc19,_0x453223,_0x362a99);{const _0x4dd811=_0x4ebc19['get'](w());_0x453223==null&&_0x4dd811!=null&&(_0x453223=Ie(_0x4dd811,w()));let _0x110d60=[];const _0x4ff2fb=y(_0x1bd46b['path']),_0x3d18b8=_0x1bd46b['operationForChild'](_0x4ff2fb),_0x1a6d81=_0x4ebc19['children']['get'](_0x4ff2fb);if(_0x1a6d81&&_0x3d18b8){const _0x74daab=_0x453223?_0x453223['getImmediateChild'](_0x4ff2fb):null,_0x7c0e2b=Vo(_0x362a99,_0x4ff2fb);_0x110d60=_0x110d60['concat'](Xo(_0x3d18b8,_0x1a6d81,_0x74daab,_0x7c0e2b));}return _0x4dd811&&(_0x110d60=_0x110d60['concat'](os(_0x4dd811,_0x1bd46b,_0x362a99,_0x453223))),_0x110d60;}}function Zo(_0x1d4c83,_0x31816a,_0xf20fa7,_0x12cf3a){const _0x7783dc=_0x31816a['get'](w());_0xf20fa7==null&&_0x7783dc!=null&&(_0xf20fa7=Ie(_0x7783dc,w()));let _0x3b0351=[];return _0x31816a['children']['inorderTraversal']((_0x548f2b,_0x346a39)=>{const _0x5eae9e=_0xf20fa7?_0xf20fa7['getImmediateChild'](_0x548f2b):null,_0x1a97e1=Vo(_0x12cf3a,_0x548f2b),_0x5c1488=_0x1d4c83['operationForChild'](_0x548f2b);_0x5c1488&&(_0x3b0351=_0x3b0351['concat'](Zo(_0x5c1488,_0x346a39,_0x5eae9e,_0x1a97e1)));}),_0x7783dc&&(_0x3b0351=_0x3b0351['concat'](os(_0x7783dc,_0x1d4c83,_0x12cf3a,_0xf20fa7))),_0x3b0351;}function ea(_0x45b178,_0x319ebf){const _0x5b5813=_0x319ebf['query'],_0x257b83=Ut(_0x45b178,_0x5b5813);return{'hashFn':()=>(Du(_0x319ebf)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3a9733=>{if(_0x3a9733==='ok')return _0x257b83?Yu(_0x45b178,_0x5b5813['_path'],_0x257b83):Ku(_0x45b178,_0x5b5813['_path']);{const _0x531d7e=Kl(_0x3a9733,_0x5b5813);return An(_0x45b178,_0x5b5813,null,_0x531d7e);}}};}function Ut(_0x6838ed,_0x1c478c){const _0x351aa0=Hn(_0x1c478c);return _0x6838ed['queryToTagMap']['get'](_0x351aa0);}function Hn(_0x457946){return _0x457946['_path']['toString']()+'$'+_0x457946['_queryIdentifier'];}function cs(_0x497cbd,_0x21927c){return _0x497cbd['tagToQueryMap']['get'](_0x21927c);}function ls(_0x42801d){const _0x1cd200=_0x42801d['indexOf']('$');return f(_0x1cd200!==-0x1&&_0x1cd200<_0x42801d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x42801d['substr'](_0x1cd200+0x1),'path':new C(_0x42801d['substr'](0x0,_0x1cd200))};}function hs(_0x253c0a,_0x13a239,_0x6bd0ff){const _0x589a64=_0x253c0a['syncPointTree_']['get'](_0x13a239);f(_0x589a64,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x340792=Wn(_0x253c0a['pendingWriteTree_'],_0x13a239);return os(_0x589a64,_0x6bd0ff,_0x340792,null);}function Xu(_0x81fd20){return _0x81fd20['fold']((_0x1f97c2,_0x57b022,_0x2be00c)=>{if(_0x57b022&&Se(_0x57b022))return[Bn(_0x57b022)];{let _0x539b0e=[];return _0x57b022&&(_0x539b0e=Ko(_0x57b022)),x(_0x2be00c,(_0xede0c1,_0x31b08d)=>{_0x539b0e=_0x539b0e['concat'](_0x31b08d);}),_0x539b0e;}});}function At(_0x3f4c37){return _0x3f4c37['_queryParams']['loadsAllData']()&&!_0x3f4c37['_queryParams']['isDefault']()?new(Gu())(_0x3f4c37['_repo'],_0x3f4c37['_path']):_0x3f4c37;}function Zu(_0x59b4df,_0x5e0b64){for(let _0x54faa5=0x0;_0x54faa5<_0x5e0b64['length'];++_0x54faa5){const _0x34c0c3=_0x5e0b64[_0x54faa5];if(!_0x34c0c3['_queryParams']['loadsAllData']()){const _0x25a97d=Hn(_0x34c0c3),_0x11d844=_0x59b4df['queryToTagMap']['get'](_0x25a97d);_0x59b4df['queryToTagMap']['delete'](_0x25a97d),_0x59b4df['tagToQueryMap']['delete'](_0x11d844);}}}function ed(){return qu++;}function td(_0xab5269,_0x186508,_0x21c2dc){const _0x3def29=_0x186508['_path'],_0x3b2877=Ut(_0xab5269,_0x186508),_0x58e591=ea(_0xab5269,_0x21c2dc),_0x337453=_0xab5269['listenProvider_']['startListening'](At(_0x186508),_0x3b2877,_0x58e591['hashFn'],_0x58e591['onComplete']),_0x20bdde=_0xab5269['syncPointTree_']['subtree'](_0x3def29);if(_0x3b2877)f(!Se(_0x20bdde['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x41284d=_0x20bdde['fold']((_0x1b995d,_0xb3932f,_0x3ccabf)=>{if(!v(_0x1b995d)&&_0xb3932f&&Se(_0xb3932f))return[Bn(_0xb3932f)['query']];{let _0x445354=[];return _0xb3932f&&(_0x445354=_0x445354['concat'](Ko(_0xb3932f)['map'](_0x108ab2=>_0x108ab2['query']))),x(_0x3ccabf,(_0x2b6969,_0x3cfae3)=>{_0x445354=_0x445354['concat'](_0x3cfae3);}),_0x445354;}});for(let _0x24311b=0x0;_0x24311b<_0x41284d['length'];++_0x24311b){const _0x4afb65=_0x41284d[_0x24311b];_0xab5269['listenProvider_']['stopListening'](At(_0x4afb65),Ut(_0xab5269,_0x4afb65));}}return _0x337453;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x30374a){this['node_']=_0x30374a;}['getImmediateChild'](_0x4e3cd5){const _0x7c00d7=this['node_']['getImmediateChild'](_0x4e3cd5);return new us(_0x7c00d7);}['node'](){return this['node_'];}}class ds{constructor(_0x15845b,_0xf2fac8){this['syncTree_']=_0x15845b,this['path_']=_0xf2fac8;}['getImmediateChild'](_0x4a78b9){const _0x47d8cd=k(this['path_'],_0x4a78b9);return new ds(this['syncTree_'],_0x47d8cd);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0x37efee){return _0x37efee=_0x37efee||{},_0x37efee['timestamp']=_0x37efee['timestamp']||new Date()['getTime'](),_0x37efee;},_r=function(_0xc3dacd,_0x45a517,_0x37e0da){if(!_0xc3dacd||typeof _0xc3dacd!='object')return _0xc3dacd;if(f('.sv'in _0xc3dacd,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xc3dacd['.sv']=='string')return id(_0xc3dacd['.sv'],_0x45a517,_0x37e0da);if(typeof _0xc3dacd['.sv']=='object')return sd(_0xc3dacd['.sv'],_0x45a517);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xc3dacd,null,0x2));},id=function(_0x1c905b,_0x4fa7c7,_0x1de148){switch(_0x1c905b){case'timestamp':return _0x1de148['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1c905b);}},sd=function(_0x599bb9,_0x411b39,_0x13b9dd){_0x599bb9['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x599bb9,null,0x2));const _0xa892cf=_0x599bb9['increment'];typeof _0xa892cf!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xa892cf);const _0x51098f=_0x411b39['node']();if(f(_0x51098f!==null&&typeof _0x51098f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x51098f['isLeafNode']())return _0xa892cf;const _0x168cd5=_0x51098f['getValue']();return typeof _0x168cd5!='number'?_0xa892cf:_0x168cd5+_0xa892cf;},ta=function(_0x5dc5ca,_0x3d30ea,_0x9b67c5,_0x435782){return ps(_0x3d30ea,new ds(_0x9b67c5,_0x5dc5ca),_0x435782);},fs=function(_0x245b8c,_0x46c5b3,_0x2d97f8){return ps(_0x245b8c,new us(_0x46c5b3),_0x2d97f8);};function ps(_0x3bfab3,_0x544260,_0x49bf24){const _0x585e2f=_0x3bfab3['getPriority']()['val'](),_0x56869f=_r(_0x585e2f,_0x544260['getImmediateChild']('.priority'),_0x49bf24);let _0x2c34cf;if(_0x3bfab3['isLeafNode']()){const _0x5ecb5b=_0x3bfab3,_0x529a38=_r(_0x5ecb5b['getValue'](),_0x544260,_0x49bf24);return _0x529a38!==_0x5ecb5b['getValue']()||_0x56869f!==_0x5ecb5b['getPriority']()['val']()?new D(_0x529a38,A(_0x56869f)):_0x3bfab3;}else{const _0x367606=_0x3bfab3;return _0x2c34cf=_0x367606,_0x56869f!==_0x367606['getPriority']()['val']()&&(_0x2c34cf=_0x2c34cf['updatePriority'](new D(_0x56869f))),_0x367606['forEachChild'](R,(_0x1c23cb,_0x44532d)=>{const _0x141230=ps(_0x44532d,_0x544260['getImmediateChild'](_0x1c23cb),_0x49bf24);_0x141230!==_0x44532d&&(_0x2c34cf=_0x2c34cf['updateImmediateChild'](_0x1c23cb,_0x141230));}),_0x2c34cf;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x454d7a='',_0x1cbbc2=null,_0x57c528={'children':{},'childCount':0x0}){this['name']=_0x454d7a,this['parent']=_0x1cbbc2,this['node']=_0x57c528;}}function $n(_0x5a56ab,_0xc8482){let _0x463709=_0xc8482 instanceof C?_0xc8482:new C(_0xc8482),_0x395b27=_0x5a56ab,_0x1f4d4c=y(_0x463709);for(;_0x1f4d4c!==null;){const _0x358041=Me(_0x395b27['node']['children'],_0x1f4d4c)||{'children':{},'childCount':0x0};_0x395b27=new _s(_0x1f4d4c,_0x395b27,_0x358041),_0x463709=S(_0x463709),_0x1f4d4c=y(_0x463709);}return _0x395b27;}function ze(_0x5659fa){return _0x5659fa['node']['value'];}function gs(_0x31a98d,_0x544a6d){_0x31a98d['node']['value']=_0x544a6d,Oi(_0x31a98d);}function na(_0x12cb0f){return _0x12cb0f['node']['childCount']>0x0;}function rd(_0x3613c6){return ze(_0x3613c6)===void 0x0&&!na(_0x3613c6);}function Gn(_0x10c573,_0x7371c0){x(_0x10c573['node']['children'],(_0x28eb2d,_0x222df3)=>{_0x7371c0(new _s(_0x28eb2d,_0x10c573,_0x222df3));});}function ia(_0x910b8c,_0x3e5296,_0x3fdd8f,_0x52a1c0){_0x3fdd8f&&_0x3e5296(_0x910b8c),Gn(_0x910b8c,_0x35ba58=>{ia(_0x35ba58,_0x3e5296,!0x0);});}function od(_0x33de1f,_0x24c22c,_0x576b29){let _0x2ac3d8=_0x33de1f['parent'];for(;_0x2ac3d8!==null;){if(_0x24c22c(_0x2ac3d8))return!0x0;_0x2ac3d8=_0x2ac3d8['parent'];}return!0x1;}function Yt(_0x50682c){return new C(_0x50682c['parent']===null?_0x50682c['name']:Yt(_0x50682c['parent'])+'/'+_0x50682c['name']);}function Oi(_0x34b995){_0x34b995['parent']!==null&&ad(_0x34b995['parent'],_0x34b995['name'],_0x34b995);}function ad(_0x5c375a,_0x53e3f5,_0x4c57de){const _0x24cb0c=rd(_0x4c57de),_0x3b23b6=Q(_0x5c375a['node']['children'],_0x53e3f5);_0x24cb0c&&_0x3b23b6?(delete _0x5c375a['node']['children'][_0x53e3f5],_0x5c375a['node']['childCount']--,Oi(_0x5c375a)):!_0x24cb0c&&!_0x3b23b6&&(_0x5c375a['node']['children'][_0x53e3f5]=_0x4c57de['node'],_0x5c375a['node']['childCount']++,Oi(_0x5c375a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x575981){return typeof _0x575981=='string'&&_0x575981['length']!==0x0&&!cd['test'](_0x575981);},sa=function(_0x110b4d){return typeof _0x110b4d=='string'&&_0x110b4d['length']!==0x0&&!ld['test'](_0x110b4d);},hd=function(_0x37e356){return _0x37e356&&(_0x37e356=_0x37e356['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x37e356);},Wt=function(_0x4aae27){return _0x4aae27===null||typeof _0x4aae27=='string'||typeof _0x4aae27=='number'&&!xn(_0x4aae27)||_0x4aae27&&typeof _0x4aae27=='object'&&Q(_0x4aae27,'.sv');},Ve=function(_0x33f867,_0x1bf65f,_0x58d76e,_0x421e67){_0x421e67&&_0x1bf65f===void 0x0||Qt(it(_0x33f867,'value'),_0x1bf65f,_0x58d76e);},Qt=function(_0x29d17e,_0x32fbe0,_0x33fd59){const _0x5df5b7=_0x33fd59 instanceof C?new Ah(_0x33fd59,_0x29d17e):_0x33fd59;if(_0x32fbe0===void 0x0)throw new Error(_0x29d17e+'contains\x20undefined\x20'+Pe(_0x5df5b7));if(typeof _0x32fbe0=='function')throw new Error(_0x29d17e+'contains\x20a\x20function\x20'+Pe(_0x5df5b7)+'\x20with\x20contents\x20=\x20'+_0x32fbe0['toString']());if(xn(_0x32fbe0))throw new Error(_0x29d17e+'contains\x20'+_0x32fbe0['toString']()+'\x20'+Pe(_0x5df5b7));if(typeof _0x32fbe0=='string'&&_0x32fbe0['length']>ui/0x3&&Ln(_0x32fbe0)>ui)throw new Error(_0x29d17e+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x5df5b7)+'\x20(\x27'+_0x32fbe0['substring'](0x0,0x32)+'...\x27)');if(_0x32fbe0&&typeof _0x32fbe0=='object'){let _0x3de288=!0x1,_0x4267e9=!0x1;if(x(_0x32fbe0,(_0x3cb831,_0xc8222c)=>{if(_0x3cb831==='.value')_0x3de288=!0x0;else{if(_0x3cb831!=='.priority'&&_0x3cb831!=='.sv'&&(_0x4267e9=!0x0,!ms(_0x3cb831)))throw new Error(_0x29d17e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3cb831+')\x20'+Pe(_0x5df5b7)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5df5b7,_0x3cb831),Qt(_0x29d17e,_0xc8222c,_0x5df5b7),Nh(_0x5df5b7);}),_0x3de288&&_0x4267e9)throw new Error(_0x29d17e+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x5df5b7)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0xfb04b3,_0x200465){let _0xbd0dad,_0x51682b;for(_0xbd0dad=0x0;_0xbd0dad<_0x200465['length'];_0xbd0dad++){_0x51682b=_0x200465[_0xbd0dad];const _0xde678f=Dt(_0x51682b);for(let _0x42b780=0x0;_0x42b780<_0xde678f['length'];_0x42b780++)if(!(_0xde678f[_0x42b780]==='.priority'&&_0x42b780===_0xde678f['length']-0x1)){if(!ms(_0xde678f[_0x42b780]))throw new Error(_0xfb04b3+'contains\x20an\x20invalid\x20key\x20('+_0xde678f[_0x42b780]+')\x20in\x20path\x20'+_0x51682b['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x200465['sort'](Rh);let _0x494f87=null;for(_0xbd0dad=0x0;_0xbd0dad<_0x200465['length'];_0xbd0dad++){if(_0x51682b=_0x200465[_0xbd0dad],_0x494f87!==null&&G(_0x494f87,_0x51682b))throw new Error(_0xfb04b3+'contains\x20a\x20path\x20'+_0x494f87['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x51682b['toString']());_0x494f87=_0x51682b;}},ra=function(_0x7289e5,_0x2f4a9f,_0xe36c60,_0x2ba2f5){const _0x7a3f96=it(_0x7289e5,'values');if(!(_0x2f4a9f&&typeof _0x2f4a9f=='object')||Array['isArray'](_0x2f4a9f))throw new Error(_0x7a3f96+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5abc42=[];x(_0x2f4a9f,(_0x104bb0,_0xf8dc47)=>{const _0x255446=new C(_0x104bb0);if(Qt(_0x7a3f96,_0xf8dc47,k(_0xe36c60,_0x255446)),ji(_0x255446)==='.priority'&&!Wt(_0xf8dc47))throw new Error(_0x7a3f96+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x255446['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5abc42['push'](_0x255446);}),ud(_0x7a3f96,_0x5abc42);},dd=function(_0x1c9954,_0x4303ca,_0x1d2cfc){if(xn(_0x4303ca))throw new Error(it(_0x1c9954,'priority')+'is\x20'+_0x4303ca['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x4303ca))throw new Error(it(_0x1c9954,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x6e0043,_0x3413ff,_0x307ab2,_0x5eee89){if(!sa(_0x307ab2))throw new Error(it(_0x6e0043,_0x3413ff)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x307ab2+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0x4f69d6,_0x1b0c26,_0x554f1f,_0x4b89f6){_0x554f1f&&(_0x554f1f=_0x554f1f['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4f69d6,_0x1b0c26,_0x554f1f);},De=function(_0xf69e6,_0x8ebfcf){if(y(_0x8ebfcf)==='.info')throw new Error(_0xf69e6+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x27acdf,_0x194309){const _0x6a49c6=_0x194309['path']['toString']();if(typeof _0x194309['repoInfo']['host']!='string'||_0x194309['repoInfo']['host']['length']===0x0||!ms(_0x194309['repoInfo']['namespace'])&&_0x194309['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x6a49c6['length']!==0x0&&!hd(_0x6a49c6))throw new Error(it(_0x27acdf,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x1225a8,_0x12043b){let _0x13622f=null;for(let _0x1d2e00=0x0;_0x1d2e00<_0x12043b['length'];_0x1d2e00++){const _0x52fb99=_0x12043b[_0x1d2e00],_0x564d79=_0x52fb99['getPath']();_0x13622f!==null&&!Ki(_0x564d79,_0x13622f['path'])&&(_0x1225a8['eventLists_']['push'](_0x13622f),_0x13622f=null),_0x13622f===null&&(_0x13622f={'events':[],'path':_0x564d79}),_0x13622f['events']['push'](_0x52fb99);}_0x13622f&&_0x1225a8['eventLists_']['push'](_0x13622f);}function oa(_0x213124,_0x46a107,_0x3d1a44){qn(_0x213124,_0x3d1a44),aa(_0x213124,_0x4e1524=>Ki(_0x4e1524,_0x46a107));}function V(_0x4ff482,_0xcdc4a4,_0x2f4c38){qn(_0x4ff482,_0x2f4c38),aa(_0x4ff482,_0x494d6c=>G(_0x494d6c,_0xcdc4a4)||G(_0xcdc4a4,_0x494d6c));}function aa(_0x4d33c9,_0xf3959a){_0x4d33c9['recursionDepth_']++;let _0x8a53bd=!0x0;for(let _0xc2d9f9=0x0;_0xc2d9f9<_0x4d33c9['eventLists_']['length'];_0xc2d9f9++){const _0x5e175d=_0x4d33c9['eventLists_'][_0xc2d9f9];if(_0x5e175d){const _0x4d2f08=_0x5e175d['path'];_0xf3959a(_0x4d2f08)?(gd(_0x4d33c9['eventLists_'][_0xc2d9f9]),_0x4d33c9['eventLists_'][_0xc2d9f9]=null):_0x8a53bd=!0x1;}}_0x8a53bd&&(_0x4d33c9['eventLists_']=[]),_0x4d33c9['recursionDepth_']--;}function gd(_0x360d46){for(let _0x43184b=0x0;_0x43184b<_0x360d46['events']['length'];_0x43184b++){const _0x17ef2b=_0x360d46['events'][_0x43184b];if(_0x17ef2b!==null){_0x360d46['events'][_0x43184b]=null;const _0x40203b=_0x17ef2b['getEventRunner']();Tt&&L('event:\x20'+_0x17ef2b['toString']()),ft(_0x40203b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x3e9368,_0x498bcc,_0x490f13,_0x50fb69){this['repoInfo_']=_0x3e9368,this['forceRestClient_']=_0x498bcc,this['authTokenProvider_']=_0x490f13,this['appCheckProvider_']=_0x50fb69,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0x13d037,_0x1d19f3,_0x4dd166){if(_0x13d037['stats_']=qi(_0x13d037['repoInfo_']),_0x13d037['forceRestClient_']||Xl())_0x13d037['server_']=new vn(_0x13d037['repoInfo_'],(_0x247ca9,_0x283dd1,_0x474e82,_0xee0db2)=>{gr(_0x13d037,_0x247ca9,_0x283dd1,_0x474e82,_0xee0db2);},_0x13d037['authTokenProvider_'],_0x13d037['appCheckProvider_']),setTimeout(()=>mr(_0x13d037,!0x0),0x0);else{if(typeof _0x4dd166<'u'&&_0x4dd166!==null){if(typeof _0x4dd166!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4dd166);}catch(_0x3e0ed8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3e0ed8);}}_0x13d037['persistentConnection_']=new se(_0x13d037['repoInfo_'],_0x1d19f3,(_0x1e5f62,_0x2e67ea,_0x2f7b7f,_0x404fb1)=>{gr(_0x13d037,_0x1e5f62,_0x2e67ea,_0x2f7b7f,_0x404fb1);},_0x27646c=>{mr(_0x13d037,_0x27646c);},_0x119c81=>{Ed(_0x13d037,_0x119c81);},_0x13d037['authTokenProvider_'],_0x13d037['appCheckProvider_'],_0x4dd166),_0x13d037['server_']=_0x13d037['persistentConnection_'];}_0x13d037['authTokenProvider_']['addTokenChangeListener'](_0x23a506=>{_0x13d037['server_']['refreshAuthToken'](_0x23a506);}),_0x13d037['appCheckProvider_']['addTokenChangeListener'](_0x22d63d=>{_0x13d037['server_']['refreshAppCheckToken'](_0x22d63d['token']);}),_0x13d037['statsReporter_']=ih(_0x13d037['repoInfo_'],()=>new nu(_0x13d037['stats_'],_0x13d037['server_'])),_0x13d037['infoData_']=new Jh(),_0x13d037['infoSyncTree_']=new pr({'startListening':(_0x2715e0,_0x4a0a83,_0x4695f3,_0x331c87)=>{let _0x45525f=[];const _0x119e14=_0x13d037['infoData_']['getNode'](_0x2715e0['_path']);return _0x119e14['isEmpty']()||(_0x45525f=Kt(_0x13d037['infoSyncTree_'],_0x2715e0['_path'],_0x119e14),setTimeout(()=>{_0x331c87('ok');},0x0)),_0x45525f;},'stopListening':()=>{}}),vs(_0x13d037,'connected',!0x1),_0x13d037['serverSyncTree_']=new pr({'startListening':(_0x16a4ab,_0x29cd57,_0x1ecabe,_0x243cef)=>(_0x13d037['server_']['listen'](_0x16a4ab,_0x1ecabe,_0x29cd57,(_0x296da6,_0x1e8b3e)=>{const _0x21b14d=_0x243cef(_0x296da6,_0x1e8b3e);V(_0x13d037['eventQueue_'],_0x16a4ab['_path'],_0x21b14d);}),[]),'stopListening':(_0x2eec60,_0x2703a9)=>{_0x13d037['server_']['unlisten'](_0x2eec60,_0x2703a9);}});}function la(_0x4a8b3a){const _0x443362=_0x4a8b3a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x443362;}function Jt(_0x18ab72){return nd({'timestamp':la(_0x18ab72)});}function gr(_0x60b207,_0x47a3a7,_0x3c1a2d,_0x2f9234,_0x2df389){_0x60b207['dataUpdateCount']++;const _0x59ebf1=new C(_0x47a3a7);_0x3c1a2d=_0x60b207['interceptServerDataCallback_']?_0x60b207['interceptServerDataCallback_'](_0x47a3a7,_0x3c1a2d):_0x3c1a2d;let _0x2f2c41=[];if(_0x2df389){if(_0x2f9234){const _0x2833a6=_n(_0x3c1a2d,_0x298111=>A(_0x298111));_0x2f2c41=Qu(_0x60b207['serverSyncTree_'],_0x59ebf1,_0x2833a6,_0x2df389);}else{const _0x1cb1f0=A(_0x3c1a2d);_0x2f2c41=Jo(_0x60b207['serverSyncTree_'],_0x59ebf1,_0x1cb1f0,_0x2df389);}}else{if(_0x2f9234){const _0x4617d2=_n(_0x3c1a2d,_0x3b057e=>A(_0x3b057e));_0x2f2c41=ju(_0x60b207['serverSyncTree_'],_0x59ebf1,_0x4617d2);}else{const _0x1fd280=A(_0x3c1a2d);_0x2f2c41=Kt(_0x60b207['serverSyncTree_'],_0x59ebf1,_0x1fd280);}}let _0xf61cd1=_0x59ebf1;_0x2f2c41['length']>0x0&&(_0xf61cd1=ct(_0x60b207,_0x59ebf1)),V(_0x60b207['eventQueue_'],_0xf61cd1,_0x2f2c41);}function mr(_0x2391d0,_0x385ecc){vs(_0x2391d0,'connected',_0x385ecc),_0x385ecc===!0x1&&Td(_0x2391d0);}function Ed(_0x6e114d,_0x66c38e){x(_0x66c38e,(_0x217856,_0x4bd5a4)=>{vs(_0x6e114d,_0x217856,_0x4bd5a4);});}function vs(_0x14c1f9,_0x165908,_0x42e482){const _0x3475fd=new C('/.info/'+_0x165908),_0x560966=A(_0x42e482);_0x14c1f9['infoData_']['updateSnapshot'](_0x3475fd,_0x560966);const _0x565673=Kt(_0x14c1f9['infoSyncTree_'],_0x3475fd,_0x560966);V(_0x14c1f9['eventQueue_'],_0x3475fd,_0x565673);}function zn(_0x489028){return _0x489028['nextWriteId_']++;}function Id(_0x3e5c14,_0x191ced,_0x336fed){const _0x1e7fd0=Ju(_0x3e5c14['serverSyncTree_'],_0x191ced);return _0x1e7fd0!=null?Promise['resolve'](_0x1e7fd0):_0x3e5c14['server_']['get'](_0x191ced)['then'](_0x421b91=>{const _0x4705cc=A(_0x421b91)['withIndex'](_0x191ced['_queryParams']['getIndex']());Pi(_0x3e5c14['serverSyncTree_'],_0x191ced,_0x336fed,!0x0);let _0x219ba4;if(_0x191ced['_queryParams']['loadsAllData']())_0x219ba4=Kt(_0x3e5c14['serverSyncTree_'],_0x191ced['_path'],_0x4705cc);else{const _0x362617=Ut(_0x3e5c14['serverSyncTree_'],_0x191ced);_0x219ba4=Jo(_0x3e5c14['serverSyncTree_'],_0x191ced['_path'],_0x4705cc,_0x362617);}return V(_0x3e5c14['eventQueue_'],_0x191ced['_path'],_0x219ba4),An(_0x3e5c14['serverSyncTree_'],_0x191ced,_0x336fed,null,!0x0),_0x4705cc;},_0x59f4bf=>(gt(_0x3e5c14,'get\x20for\x20query\x20'+O(_0x191ced)+'\x20failed:\x20'+_0x59f4bf),Promise['reject'](new Error(_0x59f4bf))));}function wd(_0x453aee,_0x35bc85,_0x1ee9b0,_0x73bad0,_0x39c09e){gt(_0x453aee,'set',{'path':_0x35bc85['toString'](),'value':_0x1ee9b0,'priority':_0x73bad0});const _0x182cbe=Jt(_0x453aee),_0x5be594=A(_0x1ee9b0,_0x73bad0),_0x41233d=Vn(_0x453aee['serverSyncTree_'],_0x35bc85),_0x375ff9=fs(_0x5be594,_0x41233d,_0x182cbe),_0x1d4c13=zn(_0x453aee),_0x486aa8=as(_0x453aee['serverSyncTree_'],_0x35bc85,_0x375ff9,_0x1d4c13,!0x0);qn(_0x453aee['eventQueue_'],_0x486aa8),_0x453aee['server_']['put'](_0x35bc85['toString'](),_0x5be594['val'](!0x0),(_0x5e9dd4,_0x3bbbfd)=>{const _0x2a43f7=_0x5e9dd4==='ok';_0x2a43f7||U('set\x20at\x20'+_0x35bc85+'\x20failed:\x20'+_0x5e9dd4);const _0x394b4b=_e(_0x453aee['serverSyncTree_'],_0x1d4c13,!_0x2a43f7);V(_0x453aee['eventQueue_'],_0x35bc85,_0x394b4b),be(_0x453aee,_0x39c09e,_0x5e9dd4,_0x3bbbfd);});const _0x2d8ac7=Is(_0x453aee,_0x35bc85);ct(_0x453aee,_0x2d8ac7),V(_0x453aee['eventQueue_'],_0x2d8ac7,[]);}function Cd(_0x1a1332,_0x4114b4,_0x4f184a,_0x52a113){gt(_0x1a1332,'update',{'path':_0x4114b4['toString'](),'value':_0x4f184a});let _0x34fc7b=!0x0;const _0x1e3c15=Jt(_0x1a1332),_0x11dd93={};if(x(_0x4f184a,(_0x16d5d5,_0x57465c)=>{_0x34fc7b=!0x1,_0x11dd93[_0x16d5d5]=ta(k(_0x4114b4,_0x16d5d5),A(_0x57465c),_0x1a1332['serverSyncTree_'],_0x1e3c15);}),_0x34fc7b)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1a1332,_0x52a113,'ok',void 0x0);else{const _0x53870f=zn(_0x1a1332),_0x1391ce=zu(_0x1a1332['serverSyncTree_'],_0x4114b4,_0x11dd93,_0x53870f);qn(_0x1a1332['eventQueue_'],_0x1391ce),_0x1a1332['server_']['merge'](_0x4114b4['toString'](),_0x4f184a,(_0x4a092b,_0x3b3b58)=>{const _0x55fd84=_0x4a092b==='ok';_0x55fd84||U('update\x20at\x20'+_0x4114b4+'\x20failed:\x20'+_0x4a092b);const _0x5a26c3=_e(_0x1a1332['serverSyncTree_'],_0x53870f,!_0x55fd84),_0x2dc0db=_0x5a26c3['length']>0x0?ct(_0x1a1332,_0x4114b4):_0x4114b4;V(_0x1a1332['eventQueue_'],_0x2dc0db,_0x5a26c3),be(_0x1a1332,_0x52a113,_0x4a092b,_0x3b3b58);}),x(_0x4f184a,_0x5c77f6=>{const _0x266516=Is(_0x1a1332,k(_0x4114b4,_0x5c77f6));ct(_0x1a1332,_0x266516);}),V(_0x1a1332['eventQueue_'],_0x4114b4,[]);}}function Td(_0xbc08a0){gt(_0xbc08a0,'onDisconnectEvents');const _0x4cf326=Jt(_0xbc08a0),_0x71c64c=En();Si(_0xbc08a0['onDisconnect_'],w(),(_0xd59e1e,_0x4051ac)=>{const _0x170c59=ta(_0xd59e1e,_0x4051ac,_0xbc08a0['serverSyncTree_'],_0x4cf326);pt(_0x71c64c,_0xd59e1e,_0x170c59);});let _0x47e5a3=[];Si(_0x71c64c,w(),(_0xe5f3d7,_0x4eb93f)=>{_0x47e5a3=_0x47e5a3['concat'](Kt(_0xbc08a0['serverSyncTree_'],_0xe5f3d7,_0x4eb93f));const _0x32bdad=Is(_0xbc08a0,_0xe5f3d7);ct(_0xbc08a0,_0x32bdad);}),_0xbc08a0['onDisconnect_']=En(),V(_0xbc08a0['eventQueue_'],w(),_0x47e5a3);}function Sd(_0x2af9cb,_0x34d3d8,_0x47748e){_0x2af9cb['server_']['onDisconnectCancel'](_0x34d3d8['toString'](),(_0x1331cc,_0x33ed41)=>{_0x1331cc==='ok'&&Ti(_0x2af9cb['onDisconnect_'],_0x34d3d8),be(_0x2af9cb,_0x47748e,_0x1331cc,_0x33ed41);});}function yr(_0x156b0d,_0x1085a7,_0x487920,_0x2ffb4a){const _0xf92e85=A(_0x487920);_0x156b0d['server_']['onDisconnectPut'](_0x1085a7['toString'](),_0xf92e85['val'](!0x0),(_0x141c43,_0x23e98c)=>{_0x141c43==='ok'&&pt(_0x156b0d['onDisconnect_'],_0x1085a7,_0xf92e85),be(_0x156b0d,_0x2ffb4a,_0x141c43,_0x23e98c);});}function bd(_0x28240b,_0x2cd03a,_0x421bcd,_0x5ef28e,_0x3592fd){const _0x5cc6dd=A(_0x421bcd,_0x5ef28e);_0x28240b['server_']['onDisconnectPut'](_0x2cd03a['toString'](),_0x5cc6dd['val'](!0x0),(_0x48c04b,_0x2e5618)=>{_0x48c04b==='ok'&&pt(_0x28240b['onDisconnect_'],_0x2cd03a,_0x5cc6dd),be(_0x28240b,_0x3592fd,_0x48c04b,_0x2e5618);});}function Rd(_0x55caca,_0x4790c1,_0xa4a697,_0x17f1ca){if(pn(_0xa4a697)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x55caca,_0x17f1ca,'ok',void 0x0);return;}_0x55caca['server_']['onDisconnectMerge'](_0x4790c1['toString'](),_0xa4a697,(_0x2ca95a,_0x4ada95)=>{_0x2ca95a==='ok'&&x(_0xa4a697,(_0x27cc9b,_0x225be8)=>{const _0x403019=A(_0x225be8);pt(_0x55caca['onDisconnect_'],k(_0x4790c1,_0x27cc9b),_0x403019);}),be(_0x55caca,_0x17f1ca,_0x2ca95a,_0x4ada95);});}function Ad(_0x186d92,_0x4083d7,_0x533e85){let _0x3a75e9;y(_0x4083d7['_path'])==='.info'?_0x3a75e9=Pi(_0x186d92['infoSyncTree_'],_0x4083d7,_0x533e85):_0x3a75e9=Pi(_0x186d92['serverSyncTree_'],_0x4083d7,_0x533e85),oa(_0x186d92['eventQueue_'],_0x4083d7['_path'],_0x3a75e9);}function kd(_0x477d0f,_0x5183e5,_0x16f751){let _0x1cdce4;y(_0x5183e5['_path'])==='.info'?_0x1cdce4=An(_0x477d0f['infoSyncTree_'],_0x5183e5,_0x16f751):_0x1cdce4=An(_0x477d0f['serverSyncTree_'],_0x5183e5,_0x16f751),oa(_0x477d0f['eventQueue_'],_0x5183e5['_path'],_0x1cdce4);}function ha(_0x47d320){_0x47d320['persistentConnection_']&&_0x47d320['persistentConnection_']['interrupt'](ca);}function Nd(_0xb67847){_0xb67847['persistentConnection_']&&_0xb67847['persistentConnection_']['resume'](ca);}function gt(_0xb71f7,..._0x2d9447){let _0x273cec='';_0xb71f7['persistentConnection_']&&(_0x273cec=_0xb71f7['persistentConnection_']['id']+':'),L(_0x273cec,..._0x2d9447);}function be(_0x4ba8ea,_0x272f7c,_0x5f2200,_0xcef01a){_0x272f7c&&ft(()=>{if(_0x5f2200==='ok')_0x272f7c(null);else{const _0x53e7b3=(_0x5f2200||'error')['toUpperCase']();let _0x19818b=_0x53e7b3;_0xcef01a&&(_0x19818b+=':\x20'+_0xcef01a);const _0x39500e=new Error(_0x19818b);_0x39500e['code']=_0x53e7b3,_0x272f7c(_0x39500e);}});}function Pd(_0x18e21a,_0x360ae2,_0x331a70,_0x406ac4,_0x5dc953,_0x2631b1){gt(_0x18e21a,'transaction\x20on\x20'+_0x360ae2);const _0x1ded7f={'path':_0x360ae2,'update':_0x331a70,'onComplete':_0x406ac4,'status':null,'order':so(),'applyLocally':_0x2631b1,'retryCount':0x0,'unwatcher':_0x5dc953,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5bf5b2=Es(_0x18e21a,_0x360ae2,void 0x0);_0x1ded7f['currentInputSnapshot']=_0x5bf5b2;const _0x1596af=_0x1ded7f['update'](_0x5bf5b2['val']());if(_0x1596af===void 0x0)_0x1ded7f['unwatcher'](),_0x1ded7f['currentOutputSnapshotRaw']=null,_0x1ded7f['currentOutputSnapshotResolved']=null,_0x1ded7f['onComplete']&&_0x1ded7f['onComplete'](null,!0x1,_0x1ded7f['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x1596af,_0x1ded7f['path']),_0x1ded7f['status']=0x0;const _0x481ddd=$n(_0x18e21a['transactionQueueTree_'],_0x360ae2),_0x1fa460=ze(_0x481ddd)||[];_0x1fa460['push'](_0x1ded7f),gs(_0x481ddd,_0x1fa460);let _0x181ffb;typeof _0x1596af=='object'&&_0x1596af!==null&&Q(_0x1596af,'.priority')?(_0x181ffb=Me(_0x1596af,'.priority'),f(Wt(_0x181ffb),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x181ffb=(Vn(_0x18e21a['serverSyncTree_'],_0x360ae2)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3f3acb=Jt(_0x18e21a),_0x7512d8=A(_0x1596af,_0x181ffb),_0xdb3f3d=fs(_0x7512d8,_0x5bf5b2,_0x3f3acb);_0x1ded7f['currentOutputSnapshotRaw']=_0x7512d8,_0x1ded7f['currentOutputSnapshotResolved']=_0xdb3f3d,_0x1ded7f['currentWriteId']=zn(_0x18e21a);const _0x380a82=as(_0x18e21a['serverSyncTree_'],_0x360ae2,_0xdb3f3d,_0x1ded7f['currentWriteId'],_0x1ded7f['applyLocally']);V(_0x18e21a['eventQueue_'],_0x360ae2,_0x380a82),jn(_0x18e21a,_0x18e21a['transactionQueueTree_']);}}function Es(_0xed7953,_0x5818ad,_0x275451){return Vn(_0xed7953['serverSyncTree_'],_0x5818ad,_0x275451)||g['EMPTY_NODE'];}function jn(_0x407908,_0x315ce3=_0x407908['transactionQueueTree_']){if(_0x315ce3||Kn(_0x407908,_0x315ce3),ze(_0x315ce3)){const _0x2aceec=da(_0x407908,_0x315ce3);f(_0x2aceec['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2aceec['every'](_0x5ca98b=>_0x5ca98b['status']===0x0)&&Od(_0x407908,Yt(_0x315ce3),_0x2aceec);}else na(_0x315ce3)&&Gn(_0x315ce3,_0x344100=>{jn(_0x407908,_0x344100);});}function Od(_0x46e78e,_0x14cd92,_0x3e5336){const _0x21aafc=_0x3e5336['map'](_0x51b09a=>_0x51b09a['currentWriteId']),_0x17abe0=Es(_0x46e78e,_0x14cd92,_0x21aafc);let _0x37ad79=_0x17abe0;const _0x1af4b2=_0x17abe0['hash']();for(let _0x1d4dfc=0x0;_0x1d4dfc<_0x3e5336['length'];_0x1d4dfc++){const _0x27bb96=_0x3e5336[_0x1d4dfc];f(_0x27bb96['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x27bb96['status']=0x1,_0x27bb96['retryCount']++;const _0x37d6d2=F(_0x14cd92,_0x27bb96['path']);_0x37ad79=_0x37ad79['updateChild'](_0x37d6d2,_0x27bb96['currentOutputSnapshotRaw']);}const _0x159b31=_0x37ad79['val'](!0x0),_0x18dddd=_0x14cd92;_0x46e78e['server_']['put'](_0x18dddd['toString'](),_0x159b31,_0x41b76d=>{gt(_0x46e78e,'transaction\x20put\x20response',{'path':_0x18dddd['toString'](),'status':_0x41b76d});let _0x34df0f=[];if(_0x41b76d==='ok'){const _0x5823c7=[];for(let _0x5955d6=0x0;_0x5955d6<_0x3e5336['length'];_0x5955d6++)_0x3e5336[_0x5955d6]['status']=0x2,_0x34df0f=_0x34df0f['concat'](_e(_0x46e78e['serverSyncTree_'],_0x3e5336[_0x5955d6]['currentWriteId'])),_0x3e5336[_0x5955d6]['onComplete']&&_0x5823c7['push'](()=>_0x3e5336[_0x5955d6]['onComplete'](null,!0x0,_0x3e5336[_0x5955d6]['currentOutputSnapshotResolved'])),_0x3e5336[_0x5955d6]['unwatcher']();Kn(_0x46e78e,$n(_0x46e78e['transactionQueueTree_'],_0x14cd92)),jn(_0x46e78e,_0x46e78e['transactionQueueTree_']),V(_0x46e78e['eventQueue_'],_0x14cd92,_0x34df0f);for(let _0x1edd4c=0x0;_0x1edd4c<_0x5823c7['length'];_0x1edd4c++)ft(_0x5823c7[_0x1edd4c]);}else{if(_0x41b76d==='datastale'){for(let _0x27904e=0x0;_0x27904e<_0x3e5336['length'];_0x27904e++)_0x3e5336[_0x27904e]['status']===0x3?_0x3e5336[_0x27904e]['status']=0x4:_0x3e5336[_0x27904e]['status']=0x0;}else{U('transaction\x20at\x20'+_0x18dddd['toString']()+'\x20failed:\x20'+_0x41b76d);for(let _0x53d11b=0x0;_0x53d11b<_0x3e5336['length'];_0x53d11b++)_0x3e5336[_0x53d11b]['status']=0x4,_0x3e5336[_0x53d11b]['abortReason']=_0x41b76d;}ct(_0x46e78e,_0x14cd92);}},_0x1af4b2);}function ct(_0x49d24d,_0x29bf22){const _0x10ad71=ua(_0x49d24d,_0x29bf22),_0x2554e7=Yt(_0x10ad71),_0x1b4111=da(_0x49d24d,_0x10ad71);return Dd(_0x49d24d,_0x1b4111,_0x2554e7),_0x2554e7;}function Dd(_0x4568ea,_0x3cc508,_0x47af4b){if(_0x3cc508['length']===0x0)return;const _0xf96c4b=[];let _0x210893=[];const _0x222480=_0x3cc508['filter'](_0x1a99d6=>_0x1a99d6['status']===0x0)['map'](_0x53ba3f=>_0x53ba3f['currentWriteId']);for(let _0x4711bd=0x0;_0x4711bd<_0x3cc508['length'];_0x4711bd++){const _0x5cd70a=_0x3cc508[_0x4711bd],_0x24716d=F(_0x47af4b,_0x5cd70a['path']);let _0xca14b1=!0x1,_0x395f34;if(f(_0x24716d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5cd70a['status']===0x4)_0xca14b1=!0x0,_0x395f34=_0x5cd70a['abortReason'],_0x210893=_0x210893['concat'](_e(_0x4568ea['serverSyncTree_'],_0x5cd70a['currentWriteId'],!0x0));else{if(_0x5cd70a['status']===0x0){if(_0x5cd70a['retryCount']>=md)_0xca14b1=!0x0,_0x395f34='maxretry',_0x210893=_0x210893['concat'](_e(_0x4568ea['serverSyncTree_'],_0x5cd70a['currentWriteId'],!0x0));else{const _0x4af54f=Es(_0x4568ea,_0x5cd70a['path'],_0x222480);_0x5cd70a['currentInputSnapshot']=_0x4af54f;const _0x1842b5=_0x3cc508[_0x4711bd]['update'](_0x4af54f['val']());if(_0x1842b5!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x1842b5,_0x5cd70a['path']);let _0x927997=A(_0x1842b5);typeof _0x1842b5=='object'&&_0x1842b5!=null&&Q(_0x1842b5,'.priority')||(_0x927997=_0x927997['updatePriority'](_0x4af54f['getPriority']()));const _0x2ead3b=_0x5cd70a['currentWriteId'],_0x40d29e=Jt(_0x4568ea),_0x34160a=fs(_0x927997,_0x4af54f,_0x40d29e);_0x5cd70a['currentOutputSnapshotRaw']=_0x927997,_0x5cd70a['currentOutputSnapshotResolved']=_0x34160a,_0x5cd70a['currentWriteId']=zn(_0x4568ea),_0x222480['splice'](_0x222480['indexOf'](_0x2ead3b),0x1),_0x210893=_0x210893['concat'](as(_0x4568ea['serverSyncTree_'],_0x5cd70a['path'],_0x34160a,_0x5cd70a['currentWriteId'],_0x5cd70a['applyLocally'])),_0x210893=_0x210893['concat'](_e(_0x4568ea['serverSyncTree_'],_0x2ead3b,!0x0));}else _0xca14b1=!0x0,_0x395f34='nodata',_0x210893=_0x210893['concat'](_e(_0x4568ea['serverSyncTree_'],_0x5cd70a['currentWriteId'],!0x0));}}}V(_0x4568ea['eventQueue_'],_0x47af4b,_0x210893),_0x210893=[],_0xca14b1&&(_0x3cc508[_0x4711bd]['status']=0x2,function(_0x4e7f42){setTimeout(_0x4e7f42,Math['floor'](0x0));}(_0x3cc508[_0x4711bd]['unwatcher']),_0x3cc508[_0x4711bd]['onComplete']&&(_0x395f34==='nodata'?_0xf96c4b['push'](()=>_0x3cc508[_0x4711bd]['onComplete'](null,!0x1,_0x3cc508[_0x4711bd]['currentInputSnapshot'])):_0xf96c4b['push'](()=>_0x3cc508[_0x4711bd]['onComplete'](new Error(_0x395f34),!0x1,null))));}Kn(_0x4568ea,_0x4568ea['transactionQueueTree_']);for(let _0x6bc90d=0x0;_0x6bc90d<_0xf96c4b['length'];_0x6bc90d++)ft(_0xf96c4b[_0x6bc90d]);jn(_0x4568ea,_0x4568ea['transactionQueueTree_']);}function ua(_0x1ff0d0,_0x587468){let _0x4f83f5,_0x251447=_0x1ff0d0['transactionQueueTree_'];for(_0x4f83f5=y(_0x587468);_0x4f83f5!==null&&ze(_0x251447)===void 0x0;)_0x251447=$n(_0x251447,_0x4f83f5),_0x587468=S(_0x587468),_0x4f83f5=y(_0x587468);return _0x251447;}function da(_0x1dad14,_0x529bfc){const _0x598115=[];return fa(_0x1dad14,_0x529bfc,_0x598115),_0x598115['sort']((_0x1c9a27,_0x4906ec)=>_0x1c9a27['order']-_0x4906ec['order']),_0x598115;}function fa(_0x395761,_0x350fcc,_0x42b961){const _0x32767e=ze(_0x350fcc);if(_0x32767e){for(let _0x332408=0x0;_0x332408<_0x32767e['length'];_0x332408++)_0x42b961['push'](_0x32767e[_0x332408]);}Gn(_0x350fcc,_0x3a07e9=>{fa(_0x395761,_0x3a07e9,_0x42b961);});}function Kn(_0x180572,_0x5a9c4e){const _0x2b1122=ze(_0x5a9c4e);if(_0x2b1122){let _0x1d1198=0x0;for(let _0x56b3c1=0x0;_0x56b3c1<_0x2b1122['length'];_0x56b3c1++)_0x2b1122[_0x56b3c1]['status']!==0x2&&(_0x2b1122[_0x1d1198]=_0x2b1122[_0x56b3c1],_0x1d1198++);_0x2b1122['length']=_0x1d1198,gs(_0x5a9c4e,_0x2b1122['length']>0x0?_0x2b1122:void 0x0);}Gn(_0x5a9c4e,_0x3f5016=>{Kn(_0x180572,_0x3f5016);});}function Is(_0x6ab012,_0x27283b){const _0x422940=Yt(ua(_0x6ab012,_0x27283b)),_0x1d7a61=$n(_0x6ab012['transactionQueueTree_'],_0x27283b);return od(_0x1d7a61,_0x351717=>{di(_0x6ab012,_0x351717);}),di(_0x6ab012,_0x1d7a61),ia(_0x1d7a61,_0x1e78a5=>{di(_0x6ab012,_0x1e78a5);}),_0x422940;}function di(_0x1be52a,_0x32cb36){const _0x3bdcf1=ze(_0x32cb36);if(_0x3bdcf1){const _0x17a723=[];let _0x4d4cb2=[],_0x1c3a1e=-0x1;for(let _0x38aafb=0x0;_0x38aafb<_0x3bdcf1['length'];_0x38aafb++)_0x3bdcf1[_0x38aafb]['status']===0x3||(_0x3bdcf1[_0x38aafb]['status']===0x1?(f(_0x1c3a1e===_0x38aafb-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1c3a1e=_0x38aafb,_0x3bdcf1[_0x38aafb]['status']=0x3,_0x3bdcf1[_0x38aafb]['abortReason']='set'):(f(_0x3bdcf1[_0x38aafb]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3bdcf1[_0x38aafb]['unwatcher'](),_0x4d4cb2=_0x4d4cb2['concat'](_e(_0x1be52a['serverSyncTree_'],_0x3bdcf1[_0x38aafb]['currentWriteId'],!0x0)),_0x3bdcf1[_0x38aafb]['onComplete']&&_0x17a723['push'](_0x3bdcf1[_0x38aafb]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1c3a1e===-0x1?gs(_0x32cb36,void 0x0):_0x3bdcf1['length']=_0x1c3a1e+0x1,V(_0x1be52a['eventQueue_'],Yt(_0x32cb36),_0x4d4cb2);for(let _0x223a9d=0x0;_0x223a9d<_0x17a723['length'];_0x223a9d++)ft(_0x17a723[_0x223a9d]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x3d23b6){let _0x2466ae='';const _0x4ef316=_0x3d23b6['split']('/');for(let _0x4a5ee6=0x0;_0x4a5ee6<_0x4ef316['length'];_0x4a5ee6++)if(_0x4ef316[_0x4a5ee6]['length']>0x0){let _0xe104dd=_0x4ef316[_0x4a5ee6];try{_0xe104dd=decodeURIComponent(_0xe104dd['replace'](/\+/g,'\x20'));}catch{}_0x2466ae+='/'+_0xe104dd;}return _0x2466ae;}function Ld(_0x51f319){const _0x2da816={};_0x51f319['charAt'](0x0)==='?'&&(_0x51f319=_0x51f319['substring'](0x1));for(const _0x25aa91 of _0x51f319['split']('&')){if(_0x25aa91['length']===0x0)continue;const _0x54af11=_0x25aa91['split']('=');_0x54af11['length']===0x2?_0x2da816[decodeURIComponent(_0x54af11[0x0])]=decodeURIComponent(_0x54af11[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x25aa91+'\x27\x20in\x20query\x20\x27'+_0x51f319+'\x27');}return _0x2da816;}const vr=function(_0x544eef,_0x28a027){const _0x2a8e1a=xd(_0x544eef),_0x3b8b7b=_0x2a8e1a['namespace'];_0x2a8e1a['domain']==='firebase.com'&&ae(_0x2a8e1a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3b8b7b||_0x3b8b7b==='undefined')&&_0x2a8e1a['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2a8e1a['secure']||$l();const _0x255773=_0x2a8e1a['scheme']==='ws'||_0x2a8e1a['scheme']==='wss';return{'repoInfo':new yo(_0x2a8e1a['host'],_0x2a8e1a['secure'],_0x3b8b7b,_0x255773,_0x28a027,'',_0x3b8b7b!==_0x2a8e1a['subdomain']),'path':new C(_0x2a8e1a['pathString'])};},xd=function(_0x443611){let _0x31ee1a='',_0x4b0c6a='',_0x21ef6a='',_0x2d6f87='',_0x1d9ae7='',_0x59c773=!0x0,_0x5f1fec='https',_0x1a512e=0x1bb;if(typeof _0x443611=='string'){let _0x3248ae=_0x443611['indexOf']('//');_0x3248ae>=0x0&&(_0x5f1fec=_0x443611['substring'](0x0,_0x3248ae-0x1),_0x443611=_0x443611['substring'](_0x3248ae+0x2));let _0x2b50fa=_0x443611['indexOf']('/');_0x2b50fa===-0x1&&(_0x2b50fa=_0x443611['length']);let _0x5996be=_0x443611['indexOf']('?');_0x5996be===-0x1&&(_0x5996be=_0x443611['length']),_0x31ee1a=_0x443611['substring'](0x0,Math['min'](_0x2b50fa,_0x5996be)),_0x2b50fa<_0x5996be&&(_0x2d6f87=Md(_0x443611['substring'](_0x2b50fa,_0x5996be)));const _0x24cbbd=Ld(_0x443611['substring'](Math['min'](_0x443611['length'],_0x5996be)));_0x3248ae=_0x31ee1a['indexOf'](':'),_0x3248ae>=0x0?(_0x59c773=_0x5f1fec==='https'||_0x5f1fec==='wss',_0x1a512e=parseInt(_0x31ee1a['substring'](_0x3248ae+0x1),0xa)):_0x3248ae=_0x31ee1a['length'];const _0x55486a=_0x31ee1a['slice'](0x0,_0x3248ae);if(_0x55486a['toLowerCase']()==='localhost')_0x4b0c6a='localhost';else{if(_0x55486a['split']('.')['length']<=0x2)_0x4b0c6a=_0x55486a;else{const _0x263903=_0x31ee1a['indexOf']('.');_0x21ef6a=_0x31ee1a['substring'](0x0,_0x263903)['toLowerCase'](),_0x4b0c6a=_0x31ee1a['substring'](_0x263903+0x1),_0x1d9ae7=_0x21ef6a;}}'ns'in _0x24cbbd&&(_0x1d9ae7=_0x24cbbd['ns']);}return{'host':_0x31ee1a,'port':_0x1a512e,'domain':_0x4b0c6a,'subdomain':_0x21ef6a,'secure':_0x59c773,'scheme':_0x5f1fec,'pathString':_0x2d6f87,'namespace':_0x1d9ae7};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x49d2c3=0x0;const _0xa556aa=[];return function(_0x2f6ca0){const _0x40ef84=_0x2f6ca0===_0x49d2c3;_0x49d2c3=_0x2f6ca0;let _0x5e6931;const _0x162e7b=new Array(0x8);for(_0x5e6931=0x7;_0x5e6931>=0x0;_0x5e6931--)_0x162e7b[_0x5e6931]=Er['charAt'](_0x2f6ca0%0x40),_0x2f6ca0=Math['floor'](_0x2f6ca0/0x40);f(_0x2f6ca0===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x351596=_0x162e7b['join']('');if(_0x40ef84){for(_0x5e6931=0xb;_0x5e6931>=0x0&&_0xa556aa[_0x5e6931]===0x3f;_0x5e6931--)_0xa556aa[_0x5e6931]=0x0;_0xa556aa[_0x5e6931]++;}else{for(_0x5e6931=0x0;_0x5e6931<0xc;_0x5e6931++)_0xa556aa[_0x5e6931]=Math['floor'](Math['random']()*0x40);}for(_0x5e6931=0x0;_0x5e6931<0xc;_0x5e6931++)_0x351596+=Er['charAt'](_0xa556aa[_0x5e6931]);return f(_0x351596['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x351596;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0x4fc037,_0x39db1e,_0x12458f,_0x229879){this['eventType']=_0x4fc037,this['eventRegistration']=_0x39db1e,this['snapshot']=_0x12458f,this['prevName']=_0x229879;}['getPath'](){const _0x30defb=this['snapshot']['ref'];return this['eventType']==='value'?_0x30defb['_path']:_0x30defb['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0x3a1feb,_0xb8e415,_0x2342f2){this['eventRegistration']=_0x3a1feb,this['error']=_0xb8e415,this['path']=_0x2342f2;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2a8061,_0x51d507){this['snapshotCallback']=_0x2a8061,this['cancelCallback']=_0x51d507;}['onValue'](_0x22fab4,_0x240551){this['snapshotCallback']['call'](null,_0x22fab4,_0x240551);}['onCancel'](_0x129afc){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x129afc);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x377a1c){return this['snapshotCallback']===_0x377a1c['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x377a1c['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x377a1c['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x43ec8c,_0x5eab9e){this['_repo']=_0x43ec8c,this['_path']=_0x5eab9e;}['cancel'](){const _0x55837f=new H();return Sd(this['_repo'],this['_path'],_0x55837f['wrapCallback'](()=>{})),_0x55837f['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x4bbbb2=new H();return yr(this['_repo'],this['_path'],null,_0x4bbbb2['wrapCallback'](()=>{})),_0x4bbbb2['promise'];}['set'](_0x46a62a){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x46a62a,this['_path'],!0x1);const _0x203445=new H();return yr(this['_repo'],this['_path'],_0x46a62a,_0x203445['wrapCallback'](()=>{})),_0x203445['promise'];}['setWithPriority'](_0x48420e,_0x524948){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x48420e,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x524948);const _0x2605cd=new H();return bd(this['_repo'],this['_path'],_0x48420e,_0x524948,_0x2605cd['wrapCallback'](()=>{})),_0x2605cd['promise'];}['update'](_0x25e87a){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x25e87a,this['_path']);const _0x3cae2f=new H();return Rd(this['_repo'],this['_path'],_0x25e87a,_0x3cae2f['wrapCallback'](()=>{})),_0x3cae2f['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x27a305,_0x378c1d,_0x29b421,_0x1cb548){this['_repo']=_0x27a305,this['_path']=_0x378c1d,this['_queryParams']=_0x29b421,this['_orderByCalled']=_0x1cb548;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x486246=sr(this['_queryParams']),_0x49e57b=$i(_0x486246);return _0x49e57b==='{}'?'default':_0x49e57b;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x6540fd){if(_0x6540fd=N(_0x6540fd),!(_0x6540fd instanceof je))return!0x1;const _0x350bbd=this['_repo']===_0x6540fd['_repo'],_0x2455ba=Ki(this['_path'],_0x6540fd['_path']),_0x28dffe=this['_queryIdentifier']===_0x6540fd['_queryIdentifier'];return _0x350bbd&&_0x2455ba&&_0x28dffe;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x19204c,_0x2a5531){if(_0x19204c['_orderByCalled']===!0x0)throw new Error(_0x2a5531+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2a1616){let _0xcd2d15=null,_0x4572e9=null;if(_0x2a1616['hasStart']()&&(_0xcd2d15=_0x2a1616['getIndexStartValue']()),_0x2a1616['hasEnd']()&&(_0x4572e9=_0x2a1616['getIndexEndValue']()),_0x2a1616['getIndex']()===ve){const _0x357b07='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x38e242='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2a1616['hasStart']()){if(_0x2a1616['getIndexStartName']()!==Ue)throw new Error(_0x357b07);if(typeof _0xcd2d15!='string')throw new Error(_0x38e242);}if(_0x2a1616['hasEnd']()){if(_0x2a1616['getIndexEndName']()!==we)throw new Error(_0x357b07);if(typeof _0x4572e9!='string')throw new Error(_0x38e242);}}else{if(_0x2a1616['getIndex']()===R){if(_0xcd2d15!=null&&!Wt(_0xcd2d15)||_0x4572e9!=null&&!Wt(_0x4572e9))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2a1616['getIndex']()instanceof Ji||_0x2a1616['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xcd2d15!=null&&typeof _0xcd2d15=='object'||_0x4572e9!=null&&typeof _0x4572e9=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4e35b3){if(_0x4e35b3['hasStart']()&&_0x4e35b3['hasEnd']()&&_0x4e35b3['hasLimit']()&&!_0x4e35b3['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0x90f787,_0x551f6f){super(_0x90f787,_0x551f6f,new Zi(),!0x1);}get['parent'](){const _0x5a2fd1=Ro(this['_path']);return _0x5a2fd1===null?null:new ee(this['_repo'],_0x5a2fd1);}get['root'](){let _0x31f60b=this;for(;_0x31f60b['parent']!==null;)_0x31f60b=_0x31f60b['parent'];return _0x31f60b;}}class lt{constructor(_0x5b7ac1,_0xb77fe4,_0x20ac9b){this['_node']=_0x5b7ac1,this['ref']=_0xb77fe4,this['_index']=_0x20ac9b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x642bbc){const _0x2199fb=new C(_0x642bbc),_0x1bcbe0=Bt(this['ref'],_0x642bbc);return new lt(this['_node']['getChild'](_0x2199fb),_0x1bcbe0,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x55cee4){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x53a838,_0x2bb9a7)=>_0x55cee4(new lt(_0x2bb9a7,Bt(this['ref'],_0x53a838),R)));}['hasChild'](_0x3e6335){const _0x1ab38c=new C(_0x3e6335);return!this['_node']['getChild'](_0x1ab38c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x2c1432,_0x16b226){return _0x2c1432=N(_0x2c1432),_0x2c1432['_checkNotDeleted']('ref'),_0x16b226!==void 0x0?Bt(_0x2c1432['_root'],_0x16b226):_0x2c1432['_root'];}function Bt(_0x1f59cd,_0x181bf5){return _0x1f59cd=N(_0x1f59cd),y(_0x1f59cd['_path'])===null?fd('child','path',_0x181bf5):ys('child','path',_0x181bf5),new ee(_0x1f59cd['_repo'],k(_0x1f59cd['_path'],_0x181bf5));}function m_(_0x2981ca){return _0x2981ca=N(_0x2981ca),new Bd(_0x2981ca['_repo'],_0x2981ca['_path']);}function y_(_0x3ca822,_0x410f97){_0x3ca822=N(_0x3ca822),De('push',_0x3ca822['_path']),Ve('push',_0x410f97,_0x3ca822['_path'],!0x0);const _0x40b62d=la(_0x3ca822['_repo']),_0x2fa42b=Fd(_0x40b62d),_0x138bc8=Bt(_0x3ca822,_0x2fa42b),_0x2a358b=Bt(_0x3ca822,_0x2fa42b);let _0x10022a;return _0x410f97!=null?_0x10022a=Vd(_0x2a358b,_0x410f97)['then'](()=>_0x2a358b):_0x10022a=Promise['resolve'](_0x2a358b),_0x138bc8['then']=_0x10022a['then']['bind'](_0x10022a),_0x138bc8['catch']=_0x10022a['then']['bind'](_0x10022a,void 0x0),_0x138bc8;}function Vd(_0xb34aaa,_0x297f15){_0xb34aaa=N(_0xb34aaa),De('set',_0xb34aaa['_path']),Ve('set',_0x297f15,_0xb34aaa['_path'],!0x1);const _0x487fba=new H();return wd(_0xb34aaa['_repo'],_0xb34aaa['_path'],_0x297f15,null,_0x487fba['wrapCallback'](()=>{})),_0x487fba['promise'];}function v_(_0x286bfa,_0x2f866c){ra('update',_0x2f866c,_0x286bfa['_path']);const _0x2a10b2=new H();return Cd(_0x286bfa['_repo'],_0x286bfa['_path'],_0x2f866c,_0x2a10b2['wrapCallback'](()=>{})),_0x2a10b2['promise'];}function E_(_0x41b351){_0x41b351=N(_0x41b351);const _0x2fe228=new pa(()=>{}),_0x3d002d=new Qn(_0x2fe228);return Id(_0x41b351['_repo'],_0x41b351,_0x3d002d)['then'](_0x341698=>new lt(_0x341698,new ee(_0x41b351['_repo'],_0x41b351['_path']),_0x41b351['_queryParams']['getIndex']()));}class Qn{constructor(_0x50e926){this['callbackContext']=_0x50e926;}['respondsTo'](_0xe612fb){return _0xe612fb==='value';}['createEvent'](_0x59b737,_0x4feaa5){const _0x1b2c28=_0x4feaa5['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x59b737['snapshotNode'],new ee(_0x4feaa5['_repo'],_0x4feaa5['_path']),_0x1b2c28));}['getEventRunner'](_0x596333){return _0x596333['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x596333['error']):()=>this['callbackContext']['onValue'](_0x596333['snapshot'],null);}['createCancelEvent'](_0x14fd94,_0x1c2608){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x14fd94,_0x1c2608):null;}['matches'](_0x899791){return _0x899791 instanceof Qn?!_0x899791['callbackContext']||!this['callbackContext']?!0x0:_0x899791['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x1d104d,_0x36d23d,_0x950540,_0x28808e,_0x369205){const _0xaeb140=new pa(_0x950540,void 0x0),_0xdb0fcc=new Qn(_0xaeb140);return Ad(_0x1d104d['_repo'],_0x1d104d,_0xdb0fcc),()=>kd(_0x1d104d['_repo'],_0x1d104d,_0xdb0fcc);}function $d(_0x26b4d3,_0xe9f818,_0x505709,_0x2c8871){return Hd(_0x26b4d3,'value',_0xe9f818);}class Xt{}class ma extends Xt{constructor(_0x164a86,_0x5aba6e){super(),this['_value']=_0x164a86,this['_key']=_0x5aba6e,this['type']='endAt';}['_apply'](_0x8ae0b4){Ve('endAt',this['_value'],_0x8ae0b4['_path'],!0x0);const _0x46e731=Qh(_0x8ae0b4['_queryParams'],this['_value'],this['_key']);if(ga(_0x46e731),Yn(_0x46e731),_0x8ae0b4['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x8ae0b4['_repo'],_0x8ae0b4['_path'],_0x46e731,_0x8ae0b4['_orderByCalled']);}}function I_(_0x26fdaa,_0x3ae4e4){return new ma(_0x26fdaa,_0x3ae4e4);}class ya extends Xt{constructor(_0x12b775,_0x5c7403){super(),this['_value']=_0x12b775,this['_key']=_0x5c7403,this['type']='startAt';}['_apply'](_0x845a99){Ve('startAt',this['_value'],_0x845a99['_path'],!0x0);const _0x1d73cb=Yh(_0x845a99['_queryParams'],this['_value'],this['_key']);if(ga(_0x1d73cb),Yn(_0x1d73cb),_0x845a99['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x845a99['_repo'],_0x845a99['_path'],_0x1d73cb,_0x845a99['_orderByCalled']);}}function w_(_0x27525d=null,_0x48bf58){return new ya(_0x27525d,_0x48bf58);}class Gd extends Xt{constructor(_0x498be7){super(),this['_path']=_0x498be7,this['type']='orderByChild';}['_apply'](_0x2fed13){_a(_0x2fed13,'orderByChild');const _0xe0b1a3=new C(this['_path']);if(v(_0xe0b1a3))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x42d154=new Ji(_0xe0b1a3),_0x4005de=xo(_0x2fed13['_queryParams'],_0x42d154);return Yn(_0x4005de),new je(_0x2fed13['_repo'],_0x2fed13['_path'],_0x4005de,!0x0);}}function C_(_0x540d31){if(_0x540d31==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x540d31==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x540d31==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x540d31),new Gd(_0x540d31);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xe2327e){_a(_0xe2327e,'orderByKey');const _0xaab9b9=xo(_0xe2327e['_queryParams'],ve);return Yn(_0xaab9b9),new je(_0xe2327e['_repo'],_0xe2327e['_path'],_0xaab9b9,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0x244da8,_0x67a6ae){super(),this['_value']=_0x244da8,this['_key']=_0x67a6ae,this['type']='equalTo';}['_apply'](_0x216374){if(Ve('equalTo',this['_value'],_0x216374['_path'],!0x1),_0x216374['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x216374['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x216374));}}function S_(_0x4b6100,_0x7d8dec){return new zd(_0x4b6100,_0x7d8dec);}function b_(_0x1ca50a,..._0x21ad2f){let _0x17f3dd=N(_0x1ca50a);for(const _0x197045 of _0x21ad2f)_0x17f3dd=_0x197045['_apply'](_0x17f3dd);return _0x17f3dd;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x11bcb5,_0x5d2ac4,_0x11611f,_0x1d54c8){const _0x281569=_0x5d2ac4['lastIndexOf'](':'),_0x13464d=_0x5d2ac4['substring'](0x0,_0x281569),_0x56ec81=Gt(_0x13464d);_0x11bcb5['repoInfo_']=new yo(_0x5d2ac4,_0x56ec81,_0x11bcb5['repoInfo_']['namespace'],_0x11bcb5['repoInfo_']['webSocketOnly'],_0x11bcb5['repoInfo_']['nodeAdmin'],_0x11bcb5['repoInfo_']['persistenceKey'],_0x11bcb5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x11611f),_0x1d54c8&&(_0x11bcb5['authTokenProvider_']=_0x1d54c8);}function Qd(_0x4d7ef2,_0x6a5a17,_0x367582,_0x220d10,_0x457e99){let _0x5e82ce=_0x220d10||_0x4d7ef2['options']['databaseURL'];_0x5e82ce===void 0x0&&(_0x4d7ef2['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4d7ef2['options']['projectId']),_0x5e82ce=_0x4d7ef2['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4e35ee=vr(_0x5e82ce,_0x457e99),_0x40f6f4=_0x4e35ee['repoInfo'],_0x123e22;typeof process<'u'&&Bs&&(_0x123e22=Bs[jd]),_0x123e22?(_0x5e82ce='http://'+_0x123e22+'?ns='+_0x40f6f4['namespace'],_0x4e35ee=vr(_0x5e82ce,_0x457e99),_0x40f6f4=_0x4e35ee['repoInfo']):_0x4e35ee['repoInfo']['secure'];const _0x3076d1=new eh(_0x4d7ef2['name'],_0x4d7ef2['options'],_0x6a5a17);pd('Invalid\x20Firebase\x20Database\x20URL',_0x4e35ee),v(_0x4e35ee['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x239374=Xd(_0x40f6f4,_0x4d7ef2,_0x3076d1,new Zl(_0x4d7ef2,_0x367582));return new Zd(_0x239374,_0x4d7ef2);}function Jd(_0x3e46f7,_0xf278d){const _0x57adec=Di[_0xf278d];(!_0x57adec||_0x57adec[_0x3e46f7['key']]!==_0x3e46f7)&&ae('Database\x20'+_0xf278d+'('+_0x3e46f7['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x3e46f7),delete _0x57adec[_0x3e46f7['key']];}function Xd(_0x27e864,_0x375d27,_0x5ce0d0,_0x5ea030){let _0x11a59d=Di[_0x375d27['name']];_0x11a59d||(_0x11a59d={},Di[_0x375d27['name']]=_0x11a59d);let _0x1d1567=_0x11a59d[_0x27e864['toURLString']()];return _0x1d1567&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1d1567=new yd(_0x27e864,Kd,_0x5ce0d0,_0x5ea030),_0x11a59d[_0x27e864['toURLString']()]=_0x1d1567,_0x1d1567;}class Zd{constructor(_0x3532d9,_0x260399){this['_repoInternal']=_0x3532d9,this['app']=_0x260399,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5a9783){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5a9783+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0x3067fe=Zr(),_0x1416dd){const _0x47f074=Hi(_0x3067fe,'database')['getImmediate']({'identifier':_0x1416dd});if(!_0x47f074['_instanceStarted']){const _0x34254c=hc('database');_0x34254c&&ef(_0x47f074,..._0x34254c);}return _0x47f074;}function ef(_0xfee753,_0x4c8e09,_0x2cbee0,_0x225700={}){_0xfee753=N(_0xfee753),_0xfee753['_checkNotDeleted']('useEmulator');const _0x4b55d9=_0x4c8e09+':'+_0x2cbee0,_0x5d556f=_0xfee753['_repoInternal'];if(_0xfee753['_instanceStarted']){if(_0x4b55d9===_0xfee753['_repoInternal']['repoInfo_']['host']&&Le(_0x225700,_0x5d556f['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xed8d98;if(_0x5d556f['repoInfo_']['nodeAdmin'])_0x225700['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xed8d98=new an(an['OWNER']);else{if(_0x225700['mockUserToken']){const _0x2265d3=typeof _0x225700['mockUserToken']=='string'?_0x225700['mockUserToken']:uc(_0x225700['mockUserToken'],_0xfee753['app']['options']['projectId']);_0xed8d98=new an(_0x2265d3);}}Gt(_0x4c8e09)&&Qr(_0x4c8e09),Yd(_0x5d556f,_0x4b55d9,_0x225700,_0xed8d98);}function A_(_0x34943b){_0x34943b=N(_0x34943b),_0x34943b['_checkNotDeleted']('goOffline'),ha(_0x34943b['_repo']);}function k_(_0x134648){_0x134648=N(_0x134648),_0x134648['_checkNotDeleted']('goOnline'),Nd(_0x134648['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0x5e5122){Ul(dt),st(new xe('database',(_0x5972f7,{instanceIdentifier:_0x24418e})=>{const _0x26efe4=_0x5972f7['getProvider']('app')['getImmediate'](),_0x36e539=_0x5972f7['getProvider']('auth-internal'),_0x34a2d1=_0x5972f7['getProvider']('app-check-internal');return Qd(_0x26efe4,_0x36e539,_0x34a2d1,_0x24418e);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x5e5122),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0x4e20dc,_0x3f9b30){this['committed']=_0x4e20dc,this['snapshot']=_0x3f9b30;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x4fefd9,_0x1d8ff8,_0xdddb80){if(_0x4fefd9=N(_0x4fefd9),De('Reference.transaction',_0x4fefd9['_path']),_0x4fefd9['key']==='.length'||_0x4fefd9['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4fefd9['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2f9833=!0x0,_0x29fe45=new H(),_0x1b1e80=(_0x58ec64,_0x1f7765,_0x4b4f34)=>{let _0xa9820c=null;_0x58ec64?_0x29fe45['reject'](_0x58ec64):(_0xa9820c=new lt(_0x4b4f34,new ee(_0x4fefd9['_repo'],_0x4fefd9['_path']),R),_0x29fe45['resolve'](new sf(_0x1f7765,_0xa9820c)));},_0x4d46f6=$d(_0x4fefd9,()=>{});return Pd(_0x4fefd9['_repo'],_0x4fefd9['_path'],_0x1d8ff8,_0x1b1e80,_0x4d46f6,_0x2f9833),_0x29fe45['promise'];}se['prototype']['simpleListen']=function(_0x36c5fd,_0x598823){this['sendRequest']('q',{'p':_0x36c5fd},_0x598823);},se['prototype']['echo']=function(_0x1b0df6,_0x430f76){this['sendRequest']('echo',{'d':_0x1b0df6},_0x430f76);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0x5b831c,..._0x3b2ca5){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5b831c,..._0x3b2ca5);}function cn(_0x12432e,..._0x31997c){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x12432e,..._0x31997c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x2e9768,..._0x454eb7){throw ws(_0x2e9768,..._0x454eb7);}function X(_0x5c94cd,..._0x4f7dde){return ws(_0x5c94cd,..._0x4f7dde);}function Ia(_0x171f86,_0x15db61,_0x3b1992){const _0x1aa0bc={...rf(),[_0x15db61]:_0x3b1992};return new $t('auth','Firebase',_0x1aa0bc)['create'](_0x15db61,{'appName':_0x171f86['name']});}function re(_0x2c4a72){return Ia(_0x2c4a72,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x5e30dc,..._0x589dfa){if(typeof _0x5e30dc!='string'){const _0x77d9d8=_0x589dfa[0x0],_0xfc02a=[..._0x589dfa['slice'](0x1)];return _0xfc02a[0x0]&&(_0xfc02a[0x0]['appName']=_0x5e30dc['name']),_0x5e30dc['_errorFactory']['create'](_0x77d9d8,..._0xfc02a);}return Ea['create'](_0x5e30dc,..._0x589dfa);}function m(_0x32bbba,_0x26b14a,..._0x4b3d1f){if(!_0x32bbba)throw ws(_0x26b14a,..._0x4b3d1f);}function ne(_0x5d8b82){const _0xdf2f02='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5d8b82;throw cn(_0xdf2f02),new Error(_0xdf2f02);}function ce(_0x31d355,_0x29dad7){_0x31d355||ne(_0x29dad7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x36f91a;return typeof self<'u'&&((_0x36f91a=self['location'])==null?void 0x0:_0x36f91a['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5c7298;return typeof self<'u'&&((_0x5c7298=self['location'])==null?void 0x0:_0x5c7298['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0x487b12=navigator;return _0x487b12['languages']&&_0x487b12['languages'][0x0]||_0x487b12['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x32b727,_0x35fa15){this['shortDelay']=_0x32b727,this['longDelay']=_0x35fa15,ce(_0x35fa15>_0x32b727,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x10c8b0,_0xd5c204){ce(_0x10c8b0['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x40c013}=_0x10c8b0['emulator'];return _0xd5c204?''+_0x40c013+(_0xd5c204['startsWith']('/')?_0xd5c204['slice'](0x1):_0xd5c204):_0x40c013;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x582ac2,_0x2b94c9,_0xbe27bf){this['fetchImpl']=_0x582ac2,_0x2b94c9&&(this['headersImpl']=_0x2b94c9),_0xbe27bf&&(this['responseImpl']=_0xbe27bf);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x23817b,_0x1b1764){return _0x23817b['tenantId']&&!_0x1b1764['tenantId']?{..._0x1b1764,'tenantId':_0x23817b['tenantId']}:_0x1b1764;}async function ke(_0x441c9a,_0x475ffc,_0x4e1c28,_0x10350e,_0x231fc8={}){return Ca(_0x441c9a,_0x231fc8,async()=>{let _0x59b777={},_0x5ee7d8={};_0x10350e&&(_0x475ffc==='GET'?_0x5ee7d8=_0x10350e:_0x59b777={'body':JSON['stringify'](_0x10350e)});const _0x2fedc2=ut({..._0x5ee7d8,'key':_0x441c9a['config']['apiKey']})['slice'](0x1),_0x27f6d7=await _0x441c9a['_getAdditionalHeaders']();_0x27f6d7['Content-Type']='application/json',_0x441c9a['languageCode']&&(_0x27f6d7['X-Firebase-Locale']=_0x441c9a['languageCode']);const _0x3773c8={'method':_0x475ffc,'headers':_0x27f6d7,..._0x59b777};return dc()||(_0x3773c8['referrerPolicy']='strict-origin-when-cross-origin'),_0x441c9a['emulatorConfig']&&Gt(_0x441c9a['emulatorConfig']['host'])&&(_0x3773c8['credentials']='include'),wa['fetch']()(await Ta(_0x441c9a,_0x441c9a['config']['apiHost'],_0x4e1c28,_0x2fedc2),_0x3773c8);});}async function Ca(_0x18494a,_0x127009,_0x155f81){_0x18494a['_canInitEmulator']=!0x1;const _0x518108={...hf,..._0x127009};try{const _0x5025db=new pf(_0x18494a),_0x753493=await Promise['race']([_0x155f81(),_0x5025db['promise']]);_0x5025db['clearNetworkTimeout']();const _0x308f53=await _0x753493['json']();if('needConfirmation'in _0x308f53)throw on(_0x18494a,'account-exists-with-different-credential',_0x308f53);if(_0x753493['ok']&&!('errorMessage'in _0x308f53))return _0x308f53;{const _0x7a3404=_0x753493['ok']?_0x308f53['errorMessage']:_0x308f53['error']['message'],[_0x311412,_0x1d95d9]=_0x7a3404['split']('\x20:\x20');if(_0x311412==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x18494a,'credential-already-in-use',_0x308f53);if(_0x311412==='EMAIL_EXISTS')throw on(_0x18494a,'email-already-in-use',_0x308f53);if(_0x311412==='USER_DISABLED')throw on(_0x18494a,'user-disabled',_0x308f53);const _0x1eb2e6=_0x518108[_0x311412]||_0x311412['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1d95d9)throw Ia(_0x18494a,_0x1eb2e6,_0x1d95d9);Y(_0x18494a,_0x1eb2e6);}}catch(_0x26b7c1){if(_0x26b7c1 instanceof Re)throw _0x26b7c1;Y(_0x18494a,'network-request-failed',{'message':String(_0x26b7c1)});}}async function en(_0x399496,_0x31ecf1,_0xc9e946,_0x1c9d40,_0x5f0fc9={}){const _0x4c35f7=await ke(_0x399496,_0x31ecf1,_0xc9e946,_0x1c9d40,_0x5f0fc9);return'mfaPendingCredential'in _0x4c35f7&&Y(_0x399496,'multi-factor-auth-required',{'_serverResponse':_0x4c35f7}),_0x4c35f7;}async function Ta(_0x27e5d8,_0x3adad4,_0x182f9e,_0x4e93ca){const _0xf8e3a9=''+_0x3adad4+_0x182f9e+'?'+_0x4e93ca,_0x2ddfc1=_0x27e5d8,_0x43707e=_0x2ddfc1['config']['emulator']?Cs(_0x27e5d8['config'],_0xf8e3a9):_0x27e5d8['config']['apiScheme']+'://'+_0xf8e3a9;return uf['includes'](_0x182f9e)&&(await _0x2ddfc1['_persistenceManagerAvailable'],_0x2ddfc1['_getPersistenceType']()==='COOKIE')?_0x2ddfc1['_getPersistence']()['_getFinalTarget'](_0x43707e)['toString']():_0x43707e;}function ff(_0x5d2ac5){switch(_0x5d2ac5){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x90e34){this['auth']=_0x90e34,this['timer']=null,this['promise']=new Promise((_0x4773aa,_0x3585ac)=>{this['timer']=setTimeout(()=>_0x3585ac(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x16bad0,_0x286783,_0x5187a2){const _0xc98a4d={'appName':_0x16bad0['name']};_0x5187a2['email']&&(_0xc98a4d['email']=_0x5187a2['email']),_0x5187a2['phoneNumber']&&(_0xc98a4d['phoneNumber']=_0x5187a2['phoneNumber']);const _0x35c8f3=X(_0x16bad0,_0x286783,_0xc98a4d);return _0x35c8f3['customData']['_tokenResponse']=_0x5187a2,_0x35c8f3;}function wr(_0x20e1a6){return _0x20e1a6!==void 0x0&&_0x20e1a6['enterprise']!==void 0x0;}class _f{constructor(_0x572156){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x572156['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x572156['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x572156['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x381d68){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x277b65 of this['recaptchaEnforcementState'])if(_0x277b65['provider']&&_0x277b65['provider']===_0x381d68)return ff(_0x277b65['enforcementState']);return null;}['isProviderEnabled'](_0x12cdcd){return this['getProviderEnforcementState'](_0x12cdcd)==='ENFORCE'||this['getProviderEnforcementState'](_0x12cdcd)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0x204625,_0x3c396e){return ke(_0x204625,'GET','/v2/recaptchaConfig',Ae(_0x204625,_0x3c396e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x2e70c0,_0x106fa5){return ke(_0x2e70c0,'POST','/v1/accounts:delete',_0x106fa5);}async function Nn(_0x56dd62,_0x46854e){return ke(_0x56dd62,'POST','/v1/accounts:lookup',_0x46854e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x149ece){if(_0x149ece)try{const _0x406221=new Date(Number(_0x149ece));if(!isNaN(_0x406221['getTime']()))return _0x406221['toUTCString']();}catch{}}async function yf(_0x1e148b,_0x1ddb67=!0x1){const _0xf7a10e=N(_0x1e148b),_0x43480e=await _0xf7a10e['getIdToken'](_0x1ddb67),_0x1e3fe9=Ts(_0x43480e);m(_0x1e3fe9&&_0x1e3fe9['exp']&&_0x1e3fe9['auth_time']&&_0x1e3fe9['iat'],_0xf7a10e['auth'],'internal-error');const _0x2de63b=typeof _0x1e3fe9['firebase']=='object'?_0x1e3fe9['firebase']:void 0x0,_0x30485f=_0x2de63b==null?void 0x0:_0x2de63b['sign_in_provider'];return{'claims':_0x1e3fe9,'token':_0x43480e,'authTime':kt(fi(_0x1e3fe9['auth_time'])),'issuedAtTime':kt(fi(_0x1e3fe9['iat'])),'expirationTime':kt(fi(_0x1e3fe9['exp'])),'signInProvider':_0x30485f||null,'signInSecondFactor':(_0x2de63b==null?void 0x0:_0x2de63b['sign_in_second_factor'])||null};}function fi(_0x19350a){return Number(_0x19350a)*0x3e8;}function Ts(_0x562c0d){const [_0x2e3cc1,_0xcc54f5,_0x32f1d4]=_0x562c0d['split']('.');if(_0x2e3cc1===void 0x0||_0xcc54f5===void 0x0||_0x32f1d4===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x401e6b=fn(_0xcc54f5);return _0x401e6b?JSON['parse'](_0x401e6b):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x763ddc){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x763ddc==null?void 0x0:_0x763ddc['toString']()),null;}}function Cr(_0x56e337){const _0x2d4a8d=Ts(_0x56e337);return m(_0x2d4a8d,'internal-error'),m(typeof _0x2d4a8d['exp']<'u','internal-error'),m(typeof _0x2d4a8d['iat']<'u','internal-error'),Number(_0x2d4a8d['exp'])-Number(_0x2d4a8d['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x1b055f,_0x304d2c,_0x63bb39=!0x1){if(_0x63bb39)return _0x304d2c;try{return await _0x304d2c;}catch(_0x80d373){throw _0x80d373 instanceof Re&&vf(_0x80d373)&&_0x1b055f['auth']['currentUser']===_0x1b055f&&await _0x1b055f['auth']['signOut'](),_0x80d373;}}function vf({code:_0x2db84f}){return _0x2db84f==='auth/user-disabled'||_0x2db84f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0x43399f){this['user']=_0x43399f,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xc6ed5b){if(_0xc6ed5b){const _0x4853eb=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4853eb;}else{this['errorBackoff']=0x7530;const _0x2136c2=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2136c2);}}['schedule'](_0x415e13=!0x1){if(!this['isRunning'])return;const _0x1b8d55=this['getInterval'](_0x415e13);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1b8d55);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xdb0808){(_0xdb0808==null?void 0x0:_0xdb0808['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x308298,_0x533ca4){this['createdAt']=_0x308298,this['lastLoginAt']=_0x533ca4,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x54e531){this['createdAt']=_0x54e531['createdAt'],this['lastLoginAt']=_0x54e531['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0x6e369b){var _0x464c1b;const _0x350c5f=_0x6e369b['auth'],_0x57ef9d=await _0x6e369b['getIdToken'](),_0x482d18=await Vt(_0x6e369b,Nn(_0x350c5f,{'idToken':_0x57ef9d}));m(_0x482d18==null?void 0x0:_0x482d18['users']['length'],_0x350c5f,'internal-error');const _0x16c5f5=_0x482d18['users'][0x0];_0x6e369b['_notifyReloadListener'](_0x16c5f5);const _0x22ee30=(_0x464c1b=_0x16c5f5['providerUserInfo'])!=null&&_0x464c1b['length']?Sa(_0x16c5f5['providerUserInfo']):[],_0x23d44b=wf(_0x6e369b['providerData'],_0x22ee30),_0x5a6d30=_0x6e369b['isAnonymous'],_0x3ffdcc=!(_0x6e369b['email']&&_0x16c5f5['passwordHash'])&&!(_0x23d44b!=null&&_0x23d44b['length']),_0x211914=_0x5a6d30?_0x3ffdcc:!0x1,_0x30a778={'uid':_0x16c5f5['localId'],'displayName':_0x16c5f5['displayName']||null,'photoURL':_0x16c5f5['photoUrl']||null,'email':_0x16c5f5['email']||null,'emailVerified':_0x16c5f5['emailVerified']||!0x1,'phoneNumber':_0x16c5f5['phoneNumber']||null,'tenantId':_0x16c5f5['tenantId']||null,'providerData':_0x23d44b,'metadata':new Li(_0x16c5f5['createdAt'],_0x16c5f5['lastLoginAt']),'isAnonymous':_0x211914};Object['assign'](_0x6e369b,_0x30a778);}async function If(_0x2b993d){const _0xab7626=N(_0x2b993d);await Pn(_0xab7626),await _0xab7626['auth']['_persistUserIfCurrent'](_0xab7626),_0xab7626['auth']['_notifyListenersIfCurrent'](_0xab7626);}function wf(_0x495696,_0x1d7f42){return[..._0x495696['filter'](_0x2d6135=>!_0x1d7f42['some'](_0x49c1d9=>_0x49c1d9['providerId']===_0x2d6135['providerId'])),..._0x1d7f42];}function Sa(_0x1b4518){return _0x1b4518['map'](({providerId:_0x27ade2,..._0x2184c9})=>({'providerId':_0x27ade2,'uid':_0x2184c9['rawId']||'','displayName':_0x2184c9['displayName']||null,'email':_0x2184c9['email']||null,'phoneNumber':_0x2184c9['phoneNumber']||null,'photoURL':_0x2184c9['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x2843f8,_0x33b657){const _0x36017a=await Ca(_0x2843f8,{},async()=>{const _0x24af1e=ut({'grant_type':'refresh_token','refresh_token':_0x33b657})['slice'](0x1),{tokenApiHost:_0x357a3f,apiKey:_0x190ecd}=_0x2843f8['config'],_0x1a31c4=await Ta(_0x2843f8,_0x357a3f,'/v1/token','key='+_0x190ecd),_0xbfc92c=await _0x2843f8['_getAdditionalHeaders']();_0xbfc92c['Content-Type']='application/x-www-form-urlencoded';const _0x275b8b={'method':'POST','headers':_0xbfc92c,'body':_0x24af1e};return _0x2843f8['emulatorConfig']&&Gt(_0x2843f8['emulatorConfig']['host'])&&(_0x275b8b['credentials']='include'),wa['fetch']()(_0x1a31c4,_0x275b8b);});return{'accessToken':_0x36017a['access_token'],'expiresIn':_0x36017a['expires_in'],'refreshToken':_0x36017a['refresh_token']};}async function Tf(_0x5cdf6e,_0x505e4e){return ke(_0x5cdf6e,'POST','/v2/accounts:revokeToken',Ae(_0x5cdf6e,_0x505e4e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x129a30){m(_0x129a30['idToken'],'internal-error'),m(typeof _0x129a30['idToken']<'u','internal-error'),m(typeof _0x129a30['refreshToken']<'u','internal-error');const _0x35950e='expiresIn'in _0x129a30&&typeof _0x129a30['expiresIn']<'u'?Number(_0x129a30['expiresIn']):Cr(_0x129a30['idToken']);this['updateTokensAndExpiration'](_0x129a30['idToken'],_0x129a30['refreshToken'],_0x35950e);}['updateFromIdToken'](_0x4345c1){m(_0x4345c1['length']!==0x0,'internal-error');const _0x507cc9=Cr(_0x4345c1);this['updateTokensAndExpiration'](_0x4345c1,null,_0x507cc9);}async['getToken'](_0x27c9b6,_0x5dbf06=!0x1){return!_0x5dbf06&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x27c9b6,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x27c9b6,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x987af9,_0xaec3b1){const {accessToken:_0xa2b813,refreshToken:_0x2364fc,expiresIn:_0x47c50c}=await Cf(_0x987af9,_0xaec3b1);this['updateTokensAndExpiration'](_0xa2b813,_0x2364fc,Number(_0x47c50c));}['updateTokensAndExpiration'](_0x3b34ff,_0xc27e5b,_0x28af4f){this['refreshToken']=_0xc27e5b||null,this['accessToken']=_0x3b34ff||null,this['expirationTime']=Date['now']()+_0x28af4f*0x3e8;}static['fromJSON'](_0x60eb29,_0x4c7b19){const {refreshToken:_0x5970fa,accessToken:_0x36fe4f,expirationTime:_0x390f75}=_0x4c7b19,_0x48e254=new et();return _0x5970fa&&(m(typeof _0x5970fa=='string','internal-error',{'appName':_0x60eb29}),_0x48e254['refreshToken']=_0x5970fa),_0x36fe4f&&(m(typeof _0x36fe4f=='string','internal-error',{'appName':_0x60eb29}),_0x48e254['accessToken']=_0x36fe4f),_0x390f75&&(m(typeof _0x390f75=='number','internal-error',{'appName':_0x60eb29}),_0x48e254['expirationTime']=_0x390f75),_0x48e254;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3de02a){this['accessToken']=_0x3de02a['accessToken'],this['refreshToken']=_0x3de02a['refreshToken'],this['expirationTime']=_0x3de02a['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3be80c,_0x5c2dff){m(typeof _0x3be80c=='string'||typeof _0x3be80c>'u','internal-error',{'appName':_0x5c2dff});}class j{constructor({uid:_0x4680ef,auth:_0x3f491a,stsTokenManager:_0x1dd676,..._0x5e80bc}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4680ef,this['auth']=_0x3f491a,this['stsTokenManager']=_0x1dd676,this['accessToken']=_0x1dd676['accessToken'],this['displayName']=_0x5e80bc['displayName']||null,this['email']=_0x5e80bc['email']||null,this['emailVerified']=_0x5e80bc['emailVerified']||!0x1,this['phoneNumber']=_0x5e80bc['phoneNumber']||null,this['photoURL']=_0x5e80bc['photoURL']||null,this['isAnonymous']=_0x5e80bc['isAnonymous']||!0x1,this['tenantId']=_0x5e80bc['tenantId']||null,this['providerData']=_0x5e80bc['providerData']?[..._0x5e80bc['providerData']]:[],this['metadata']=new Li(_0x5e80bc['createdAt']||void 0x0,_0x5e80bc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x372345){const _0x4775b7=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x372345));return m(_0x4775b7,this['auth'],'internal-error'),this['accessToken']!==_0x4775b7&&(this['accessToken']=_0x4775b7,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4775b7;}['getIdTokenResult'](_0x230be0){return yf(this,_0x230be0);}['reload'](){return If(this);}['_assign'](_0x5df6c3){this!==_0x5df6c3&&(m(this['uid']===_0x5df6c3['uid'],this['auth'],'internal-error'),this['displayName']=_0x5df6c3['displayName'],this['photoURL']=_0x5df6c3['photoURL'],this['email']=_0x5df6c3['email'],this['emailVerified']=_0x5df6c3['emailVerified'],this['phoneNumber']=_0x5df6c3['phoneNumber'],this['isAnonymous']=_0x5df6c3['isAnonymous'],this['tenantId']=_0x5df6c3['tenantId'],this['providerData']=_0x5df6c3['providerData']['map'](_0x11135e=>({..._0x11135e})),this['metadata']['_copy'](_0x5df6c3['metadata']),this['stsTokenManager']['_assign'](_0x5df6c3['stsTokenManager']));}['_clone'](_0x5e5635){const _0x1eead6=new j({...this,'auth':_0x5e5635,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1eead6['metadata']['_copy'](this['metadata']),_0x1eead6;}['_onReload'](_0xb329d0){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xb329d0,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1d79c7){this['reloadListener']?this['reloadListener'](_0x1d79c7):this['reloadUserInfo']=_0x1d79c7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4ee38f,_0x16afa3=!0x1){let _0x1655d4=!0x1;_0x4ee38f['idToken']&&_0x4ee38f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4ee38f),_0x1655d4=!0x0),_0x16afa3&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1655d4&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x409890=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x409890})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2bbd12=>({..._0x2bbd12})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4b831a,_0x33aea2){const _0x1251cb=_0x33aea2['displayName']??void 0x0,_0x3aa054=_0x33aea2['email']??void 0x0,_0x37934f=_0x33aea2['phoneNumber']??void 0x0,_0x226e9e=_0x33aea2['photoURL']??void 0x0,_0x3b84da=_0x33aea2['tenantId']??void 0x0,_0x265736=_0x33aea2['_redirectEventId']??void 0x0,_0x41b061=_0x33aea2['createdAt']??void 0x0,_0x550568=_0x33aea2['lastLoginAt']??void 0x0,{uid:_0x40a9f1,emailVerified:_0x5d886f,isAnonymous:_0x36d119,providerData:_0x121131,stsTokenManager:_0x183a30}=_0x33aea2;m(_0x40a9f1&&_0x183a30,_0x4b831a,'internal-error');const _0x55945e=et['fromJSON'](this['name'],_0x183a30);m(typeof _0x40a9f1=='string',_0x4b831a,'internal-error'),le(_0x1251cb,_0x4b831a['name']),le(_0x3aa054,_0x4b831a['name']),m(typeof _0x5d886f=='boolean',_0x4b831a,'internal-error'),m(typeof _0x36d119=='boolean',_0x4b831a,'internal-error'),le(_0x37934f,_0x4b831a['name']),le(_0x226e9e,_0x4b831a['name']),le(_0x3b84da,_0x4b831a['name']),le(_0x265736,_0x4b831a['name']),le(_0x41b061,_0x4b831a['name']),le(_0x550568,_0x4b831a['name']);const _0x56327e=new j({'uid':_0x40a9f1,'auth':_0x4b831a,'email':_0x3aa054,'emailVerified':_0x5d886f,'displayName':_0x1251cb,'isAnonymous':_0x36d119,'photoURL':_0x226e9e,'phoneNumber':_0x37934f,'tenantId':_0x3b84da,'stsTokenManager':_0x55945e,'createdAt':_0x41b061,'lastLoginAt':_0x550568});return _0x121131&&Array['isArray'](_0x121131)&&(_0x56327e['providerData']=_0x121131['map'](_0x5b373b=>({..._0x5b373b}))),_0x265736&&(_0x56327e['_redirectEventId']=_0x265736),_0x56327e;}static async['_fromIdTokenResponse'](_0x13c897,_0x3dfb0a,_0x3a02c7=!0x1){const _0x969428=new et();_0x969428['updateFromServerResponse'](_0x3dfb0a);const _0x24205c=new j({'uid':_0x3dfb0a['localId'],'auth':_0x13c897,'stsTokenManager':_0x969428,'isAnonymous':_0x3a02c7});return await Pn(_0x24205c),_0x24205c;}static async['_fromGetAccountInfoResponse'](_0x22b67b,_0x511d62,_0x2654c9){const _0x5dbd9f=_0x511d62['users'][0x0];m(_0x5dbd9f['localId']!==void 0x0,'internal-error');const _0x595d4b=_0x5dbd9f['providerUserInfo']!==void 0x0?Sa(_0x5dbd9f['providerUserInfo']):[],_0x201332=!(_0x5dbd9f['email']&&_0x5dbd9f['passwordHash'])&&!(_0x595d4b!=null&&_0x595d4b['length']),_0xa8e7dc=new et();_0xa8e7dc['updateFromIdToken'](_0x2654c9);const _0x145c42=new j({'uid':_0x5dbd9f['localId'],'auth':_0x22b67b,'stsTokenManager':_0xa8e7dc,'isAnonymous':_0x201332}),_0x3a97b9={'uid':_0x5dbd9f['localId'],'displayName':_0x5dbd9f['displayName']||null,'photoURL':_0x5dbd9f['photoUrl']||null,'email':_0x5dbd9f['email']||null,'emailVerified':_0x5dbd9f['emailVerified']||!0x1,'phoneNumber':_0x5dbd9f['phoneNumber']||null,'tenantId':_0x5dbd9f['tenantId']||null,'providerData':_0x595d4b,'metadata':new Li(_0x5dbd9f['createdAt'],_0x5dbd9f['lastLoginAt']),'isAnonymous':!(_0x5dbd9f['email']&&_0x5dbd9f['passwordHash'])&&!(_0x595d4b!=null&&_0x595d4b['length'])};return Object['assign'](_0x145c42,_0x3a97b9),_0x145c42;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x457dc0){ce(_0x457dc0 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x364969=Tr['get'](_0x457dc0);return _0x364969?(ce(_0x364969 instanceof _0x457dc0,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x364969):(_0x364969=new _0x457dc0(),Tr['set'](_0x457dc0,_0x364969),_0x364969);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x6d0600,_0x34011d){this['storage'][_0x6d0600]=_0x34011d;}async['_get'](_0x295c8c){const _0x1c61ae=this['storage'][_0x295c8c];return _0x1c61ae===void 0x0?null:_0x1c61ae;}async['_remove'](_0x3a230a){delete this['storage'][_0x3a230a];}['_addListener'](_0x1b0e9a,_0x94dc7b){}['_removeListener'](_0x50a5f1,_0x8e0ce6){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4c363d,_0x3327b9,_0x17ed34){return'firebase:'+_0x4c363d+':'+_0x3327b9+':'+_0x17ed34;}class tt{constructor(_0x47faa8,_0x442034,_0x112417){this['persistence']=_0x47faa8,this['auth']=_0x442034,this['userKey']=_0x112417;const {config:_0x16152c,name:_0x4bf40a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x16152c['apiKey'],_0x4bf40a),this['fullPersistenceKey']=ln('persistence',_0x16152c['apiKey'],_0x4bf40a),this['boundEventHandler']=_0x442034['_onStorageEvent']['bind'](_0x442034),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1ba1ac){return this['persistence']['_set'](this['fullUserKey'],_0x1ba1ac['toJSON']());}async['getCurrentUser'](){const _0x2e5c09=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2e5c09)return null;if(typeof _0x2e5c09=='string'){const _0x480aa=await Nn(this['auth'],{'idToken':_0x2e5c09})['catch'](()=>{});return _0x480aa?j['_fromGetAccountInfoResponse'](this['auth'],_0x480aa,_0x2e5c09):null;}return j['_fromJSON'](this['auth'],_0x2e5c09);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x257f9c){if(this['persistence']===_0x257f9c)return;const _0x5ac179=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x257f9c,_0x5ac179)return this['setCurrentUser'](_0x5ac179);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1ff20b,_0x284ed9,_0x35e60e='authUser'){if(!_0x284ed9['length'])return new tt(ie(Sr),_0x1ff20b,_0x35e60e);const _0x4e6470=(await Promise['all'](_0x284ed9['map'](async _0x47241b=>{if(await _0x47241b['_isAvailable']())return _0x47241b;})))['filter'](_0x265c2c=>_0x265c2c);let _0x11518d=_0x4e6470[0x0]||ie(Sr);const _0x497092=ln(_0x35e60e,_0x1ff20b['config']['apiKey'],_0x1ff20b['name']);let _0x3f6de7=null;for(const _0xa4330f of _0x284ed9)try{const _0x5e3992=await _0xa4330f['_get'](_0x497092);if(_0x5e3992){let _0x1326b9;if(typeof _0x5e3992=='string'){const _0x5b6a36=await Nn(_0x1ff20b,{'idToken':_0x5e3992})['catch'](()=>{});if(!_0x5b6a36)break;_0x1326b9=await j['_fromGetAccountInfoResponse'](_0x1ff20b,_0x5b6a36,_0x5e3992);}else _0x1326b9=j['_fromJSON'](_0x1ff20b,_0x5e3992);_0xa4330f!==_0x11518d&&(_0x3f6de7=_0x1326b9),_0x11518d=_0xa4330f;break;}}catch{}const _0x45e638=_0x4e6470['filter'](_0x131766=>_0x131766['_shouldAllowMigration']);return!_0x11518d['_shouldAllowMigration']||!_0x45e638['length']?new tt(_0x11518d,_0x1ff20b,_0x35e60e):(_0x11518d=_0x45e638[0x0],_0x3f6de7&&await _0x11518d['_set'](_0x497092,_0x3f6de7['toJSON']()),await Promise['all'](_0x284ed9['map'](async _0x2c89fa=>{if(_0x2c89fa!==_0x11518d)try{await _0x2c89fa['_remove'](_0x497092);}catch{}})),new tt(_0x11518d,_0x1ff20b,_0x35e60e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x8dcb8a){const _0x4cce71=_0x8dcb8a['toLowerCase']();if(_0x4cce71['includes']('opera/')||_0x4cce71['includes']('opr/')||_0x4cce71['includes']('opios/'))return'Opera';if(Na(_0x4cce71))return'IEMobile';if(_0x4cce71['includes']('msie')||_0x4cce71['includes']('trident/'))return'IE';if(_0x4cce71['includes']('edge/'))return'Edge';if(Ra(_0x4cce71))return'Firefox';if(_0x4cce71['includes']('silk/'))return'Silk';if(Oa(_0x4cce71))return'Blackberry';if(Da(_0x4cce71))return'Webos';if(Aa(_0x4cce71))return'Safari';if((_0x4cce71['includes']('chrome/')||ka(_0x4cce71))&&!_0x4cce71['includes']('edge/'))return'Chrome';if(Pa(_0x4cce71))return'Android';{const _0x2d868d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2645af=_0x8dcb8a['match'](_0x2d868d);if((_0x2645af==null?void 0x0:_0x2645af['length'])===0x2)return _0x2645af[0x1];}return'Other';}function Ra(_0x2632a8=W()){return/firefox\//i['test'](_0x2632a8);}function Aa(_0x17b614=W()){const _0xbee629=_0x17b614['toLowerCase']();return _0xbee629['includes']('safari/')&&!_0xbee629['includes']('chrome/')&&!_0xbee629['includes']('crios/')&&!_0xbee629['includes']('android');}function ka(_0x406232=W()){return/crios\//i['test'](_0x406232);}function Na(_0xd456ca=W()){return/iemobile/i['test'](_0xd456ca);}function Pa(_0x364055=W()){return/android/i['test'](_0x364055);}function Oa(_0x288136=W()){return/blackberry/i['test'](_0x288136);}function Da(_0x3e5de5=W()){return/webos/i['test'](_0x3e5de5);}function Ss(_0xff1f14=W()){return/iphone|ipad|ipod/i['test'](_0xff1f14)||/macintosh/i['test'](_0xff1f14)&&/mobile/i['test'](_0xff1f14);}function Sf(_0x52f485=W()){var _0x46722d;return Ss(_0x52f485)&&!!((_0x46722d=window['navigator'])!=null&&_0x46722d['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x90c0f9=W()){return Ss(_0x90c0f9)||Pa(_0x90c0f9)||Da(_0x90c0f9)||Oa(_0x90c0f9)||/windows phone/i['test'](_0x90c0f9)||Na(_0x90c0f9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x22a0ae,_0x46db92=[]){let _0x470419;switch(_0x22a0ae){case'Browser':_0x470419=br(W());break;case'Worker':_0x470419=br(W())+'-'+_0x22a0ae;break;default:_0x470419=_0x22a0ae;}const _0x3be4d6=_0x46db92['length']?_0x46db92['join'](','):'FirebaseCore-web';return _0x470419+'/JsCore/'+dt+'/'+_0x3be4d6;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x4cf690){this['auth']=_0x4cf690,this['queue']=[];}['pushCallback'](_0x5de2f0,_0x43ef48){const _0xf81b6b=_0x19daf7=>new Promise((_0x34ac51,_0x52158d)=>{try{const _0x5ee16a=_0x5de2f0(_0x19daf7);_0x34ac51(_0x5ee16a);}catch(_0x272d1c){_0x52158d(_0x272d1c);}});_0xf81b6b['onAbort']=_0x43ef48,this['queue']['push'](_0xf81b6b);const _0x1f46ae=this['queue']['length']-0x1;return()=>{this['queue'][_0x1f46ae]=()=>Promise['resolve']();};}async['runMiddleware'](_0x49b296){if(this['auth']['currentUser']===_0x49b296)return;const _0x49ae65=[];try{for(const _0x2b6430 of this['queue'])await _0x2b6430(_0x49b296),_0x2b6430['onAbort']&&_0x49ae65['push'](_0x2b6430['onAbort']);}catch(_0x513d01){_0x49ae65['reverse']();for(const _0x2d8306 of _0x49ae65)try{_0x2d8306();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x513d01==null?void 0x0:_0x513d01['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x19ca3b,_0x53308={}){return ke(_0x19ca3b,'GET','/v2/passwordPolicy',Ae(_0x19ca3b,_0x53308));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x1cd8f2){var _0x3b96e0;const _0x50ba99=_0x1cd8f2['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x50ba99['minPasswordLength']??kf,_0x50ba99['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x50ba99['maxPasswordLength']),_0x50ba99['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x50ba99['containsLowercaseCharacter']),_0x50ba99['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x50ba99['containsUppercaseCharacter']),_0x50ba99['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x50ba99['containsNumericCharacter']),_0x50ba99['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x50ba99['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1cd8f2['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3b96e0=_0x1cd8f2['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3b96e0['join'](''))??'',this['forceUpgradeOnSignin']=_0x1cd8f2['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1cd8f2['schemaVersion'];}['validatePassword'](_0x4e8982){const _0x50c058={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4e8982,_0x50c058),this['validatePasswordCharacterOptions'](_0x4e8982,_0x50c058),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['meetsMinPasswordLength']??!0x0),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['meetsMaxPasswordLength']??!0x0),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['containsLowercaseLetter']??!0x0),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['containsUppercaseLetter']??!0x0),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['containsNumericCharacter']??!0x0),_0x50c058['isValid']&&(_0x50c058['isValid']=_0x50c058['containsNonAlphanumericCharacter']??!0x0),_0x50c058;}['validatePasswordLengthOptions'](_0x25d3bd,_0x1617d7){const _0x164b31=this['customStrengthOptions']['minPasswordLength'],_0x6ea74d=this['customStrengthOptions']['maxPasswordLength'];_0x164b31&&(_0x1617d7['meetsMinPasswordLength']=_0x25d3bd['length']>=_0x164b31),_0x6ea74d&&(_0x1617d7['meetsMaxPasswordLength']=_0x25d3bd['length']<=_0x6ea74d);}['validatePasswordCharacterOptions'](_0x51afa6,_0x2f0cc7){this['updatePasswordCharacterOptionsStatuses'](_0x2f0cc7,!0x1,!0x1,!0x1,!0x1);let _0x555d61;for(let _0x50e183=0x0;_0x50e183<_0x51afa6['length'];_0x50e183++)_0x555d61=_0x51afa6['charAt'](_0x50e183),this['updatePasswordCharacterOptionsStatuses'](_0x2f0cc7,_0x555d61>='a'&&_0x555d61<='z',_0x555d61>='A'&&_0x555d61<='Z',_0x555d61>='0'&&_0x555d61<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x555d61));}['updatePasswordCharacterOptionsStatuses'](_0x4539f1,_0x11fee7,_0x162cd7,_0x2d7047,_0x4ede9a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4539f1['containsLowercaseLetter']||(_0x4539f1['containsLowercaseLetter']=_0x11fee7)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4539f1['containsUppercaseLetter']||(_0x4539f1['containsUppercaseLetter']=_0x162cd7)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4539f1['containsNumericCharacter']||(_0x4539f1['containsNumericCharacter']=_0x2d7047)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4539f1['containsNonAlphanumericCharacter']||(_0x4539f1['containsNonAlphanumericCharacter']=_0x4ede9a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0x49ccf3,_0xa96945,_0x3fd40b,_0x3fe893){this['app']=_0x49ccf3,this['heartbeatServiceProvider']=_0xa96945,this['appCheckServiceProvider']=_0x3fd40b,this['config']=_0x3fe893,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x49ccf3['name'],this['clientVersion']=_0x3fe893['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x199cd2=>this['_resolvePersistenceManagerAvailable']=_0x199cd2);}['_initializeWithPersistence'](_0x2445fd,_0x592a2a){return _0x592a2a&&(this['_popupRedirectResolver']=ie(_0x592a2a)),this['_initializationPromise']=this['queue'](async()=>{var _0x5f08d4,_0x5608c2,_0x5e9beb;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2445fd),(_0x5f08d4=this['_resolvePersistenceManagerAvailable'])==null||_0x5f08d4['call'](this),!this['_deleted'])){if((_0x5608c2=this['_popupRedirectResolver'])!=null&&_0x5608c2['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x592a2a),this['lastNotifiedUid']=((_0x5e9beb=this['currentUser'])==null?void 0x0:_0x5e9beb['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x54ca52=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x54ca52)){if(this['currentUser']&&_0x54ca52&&this['currentUser']['uid']===_0x54ca52['uid']){this['_currentUser']['_assign'](_0x54ca52),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x54ca52,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1e48be){try{const _0x5e9ac3=await Nn(this,{'idToken':_0x1e48be}),_0x5719c4=await j['_fromGetAccountInfoResponse'](this,_0x5e9ac3,_0x1e48be);await this['directlySetCurrentUser'](_0x5719c4);}catch(_0x1f48d6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1f48d6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x458db1){var _0x3d7fbd;if($(this['app'])){const _0x17bcb0=this['app']['settings']['authIdToken'];return _0x17bcb0?new Promise(_0x2ab2f2=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x17bcb0)['then'](_0x2ab2f2,_0x2ab2f2));}):this['directlySetCurrentUser'](null);}const _0x38b1c6=await this['assertedPersistence']['getCurrentUser']();let _0x1d17e8=_0x38b1c6,_0x4ac10a=!0x1;if(_0x458db1&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x374b9b=(_0x3d7fbd=this['redirectUser'])==null?void 0x0:_0x3d7fbd['_redirectEventId'],_0x34dbb0=_0x1d17e8==null?void 0x0:_0x1d17e8['_redirectEventId'],_0x23105c=await this['tryRedirectSignIn'](_0x458db1);(!_0x374b9b||_0x374b9b===_0x34dbb0)&&(_0x23105c!=null&&_0x23105c['user'])&&(_0x1d17e8=_0x23105c['user'],_0x4ac10a=!0x0);}if(!_0x1d17e8)return this['directlySetCurrentUser'](null);if(!_0x1d17e8['_redirectEventId']){if(_0x4ac10a)try{await this['beforeStateQueue']['runMiddleware'](_0x1d17e8);}catch(_0x3f356a){_0x1d17e8=_0x38b1c6,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3f356a));}return _0x1d17e8?this['reloadAndSetCurrentUserOrClear'](_0x1d17e8):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1d17e8['_redirectEventId']?this['directlySetCurrentUser'](_0x1d17e8):this['reloadAndSetCurrentUserOrClear'](_0x1d17e8);}async['tryRedirectSignIn'](_0x55bce5){let _0x12b5c5=null;try{_0x12b5c5=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x55bce5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x12b5c5;}async['reloadAndSetCurrentUserOrClear'](_0x1f001f){try{await Pn(_0x1f001f);}catch(_0x3c05a7){if((_0x3c05a7==null?void 0x0:_0x3c05a7['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1f001f);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x45159f){if($(this['app']))return Promise['reject'](re(this));const _0x30fae1=_0x45159f?N(_0x45159f):null;return _0x30fae1&&m(_0x30fae1['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x30fae1&&_0x30fae1['_clone'](this));}async['_updateCurrentUser'](_0x581b6e,_0x142863=!0x1){if(!this['_deleted'])return _0x581b6e&&m(this['tenantId']===_0x581b6e['tenantId'],this,'tenant-id-mismatch'),_0x142863||await this['beforeStateQueue']['runMiddleware'](_0x581b6e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x581b6e),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1a38a1){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1a38a1));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2d6763){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x298bec=this['_getPasswordPolicyInternal']();return _0x298bec['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x298bec['validatePassword'](_0x2d6763);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2ef442=await Af(this),_0x13c826=new Nf(_0x2ef442);this['tenantId']===null?this['_projectPasswordPolicy']=_0x13c826:this['_tenantPasswordPolicies'][this['tenantId']]=_0x13c826;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xe79e2e){this['_errorFactory']=new $t('auth','Firebase',_0xe79e2e());}['onAuthStateChanged'](_0x17d07d,_0x42f067,_0x69e14c){return this['registerStateListener'](this['authStateSubscription'],_0x17d07d,_0x42f067,_0x69e14c);}['beforeAuthStateChanged'](_0x8b647a,_0x1e7ff2){return this['beforeStateQueue']['pushCallback'](_0x8b647a,_0x1e7ff2);}['onIdTokenChanged'](_0x1b5b7a,_0x395444,_0x2a6804){return this['registerStateListener'](this['idTokenSubscription'],_0x1b5b7a,_0x395444,_0x2a6804);}['authStateReady'](){return new Promise((_0x254cce,_0x5e4abb)=>{if(this['currentUser'])_0x254cce();else{const _0x2268e8=this['onAuthStateChanged'](()=>{_0x2268e8(),_0x254cce();},_0x5e4abb);}});}async['revokeAccessToken'](_0x989164){if(this['currentUser']){const _0x566b62=await this['currentUser']['getIdToken'](),_0x26dba7={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x989164,'idToken':_0x566b62};this['tenantId']!=null&&(_0x26dba7['tenantId']=this['tenantId']),await Tf(this,_0x26dba7);}}['toJSON'](){var _0x26bbec;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x26bbec=this['_currentUser'])==null?void 0x0:_0x26bbec['toJSON']()};}async['_setRedirectUser'](_0x38a534,_0x355c0c){const _0x3fe746=await this['getOrInitRedirectPersistenceManager'](_0x355c0c);return _0x38a534===null?_0x3fe746['removeCurrentUser']():_0x3fe746['setCurrentUser'](_0x38a534);}async['getOrInitRedirectPersistenceManager'](_0x27959f){if(!this['redirectPersistenceManager']){const _0x3382e8=_0x27959f&&ie(_0x27959f)||this['_popupRedirectResolver'];m(_0x3382e8,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3382e8['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x56e416){var _0x3d7784,_0x1f5b41;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3d7784=this['_currentUser'])==null?void 0x0:_0x3d7784['_redirectEventId'])===_0x56e416?this['_currentUser']:((_0x1f5b41=this['redirectUser'])==null?void 0x0:_0x1f5b41['_redirectEventId'])===_0x56e416?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x385f73){if(_0x385f73===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x385f73));}['_notifyListenersIfCurrent'](_0x5c519d){_0x5c519d===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x407ffa;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x357bcc=((_0x407ffa=this['currentUser'])==null?void 0x0:_0x407ffa['uid'])??null;this['lastNotifiedUid']!==_0x357bcc&&(this['lastNotifiedUid']=_0x357bcc,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3e6546,_0x2a1dcf,_0x2bac14,_0x4cbdd2){if(this['_deleted'])return()=>{};const _0x35d36f=typeof _0x2a1dcf=='function'?_0x2a1dcf:_0x2a1dcf['next']['bind'](_0x2a1dcf);let _0x4ec7fc=!0x1;const _0x229849=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x229849,this,'internal-error'),_0x229849['then'](()=>{_0x4ec7fc||_0x35d36f(this['currentUser']);}),typeof _0x2a1dcf=='function'){const _0x12e14f=_0x3e6546['addObserver'](_0x2a1dcf,_0x2bac14,_0x4cbdd2);return()=>{_0x4ec7fc=!0x0,_0x12e14f();};}else{const _0x4a8d95=_0x3e6546['addObserver'](_0x2a1dcf);return()=>{_0x4ec7fc=!0x0,_0x4a8d95();};}}async['directlySetCurrentUser'](_0x1ac92c){this['currentUser']&&this['currentUser']!==_0x1ac92c&&this['_currentUser']['_stopProactiveRefresh'](),_0x1ac92c&&this['isProactiveRefreshEnabled']&&_0x1ac92c['_startProactiveRefresh'](),this['currentUser']=_0x1ac92c,_0x1ac92c?await this['assertedPersistence']['setCurrentUser'](_0x1ac92c):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x485734){return this['operations']=this['operations']['then'](_0x485734,_0x485734),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1bf66e){!_0x1bf66e||this['frameworks']['includes'](_0x1bf66e)||(this['frameworks']['push'](_0x1bf66e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x138315;const _0x4611f4={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4611f4['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x41c73c=await((_0x138315=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x138315['getHeartbeatsHeader']());_0x41c73c&&(_0x4611f4['X-Firebase-Client']=_0x41c73c);const _0x5308f8=await this['_getAppCheckToken']();return _0x5308f8&&(_0x4611f4['X-Firebase-AppCheck']=_0x5308f8),_0x4611f4;}async['_getAppCheckToken'](){var _0xa8cd84;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1a06e4=await((_0xa8cd84=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xa8cd84['getToken']());return _0x1a06e4!=null&&_0x1a06e4['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1a06e4['error']),_0x1a06e4==null?void 0x0:_0x1a06e4['token'];}}function Ke(_0x571d68){return N(_0x571d68);}class Rr{constructor(_0x1b751d){this['auth']=_0x1b751d,this['observer']=null,this['addObserver']=Tc(_0x419e40=>this['observer']=_0x419e40);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x2bb146){Jn=_0x2bb146;}function xa(_0x50b4d8){return Jn['loadJS'](_0x50b4d8);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x2f8f55){return'__'+_0x2f8f55+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x2b464f){_0x2b464f();}['execute'](_0x368d48,_0x3d020f){return Promise['resolve']('token');}['render'](_0x1ecc10,_0x1a438d){return'';}}class Ff{['ready'](_0x48c1d1){_0x48c1d1();}['execute'](_0x10fed7,_0x51f8f7){return Promise['resolve']('token');}['render'](_0x3809a7,_0x634950){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3b4798){this['type']=Uf,this['auth']=Ke(_0x3b4798);}async['verify'](_0x30af34='verify',_0x249bff=!0x1){async function _0x527617(_0x5f46af){if(!_0x249bff){if(_0x5f46af['tenantId']==null&&_0x5f46af['_agentRecaptchaConfig']!=null)return _0x5f46af['_agentRecaptchaConfig']['siteKey'];if(_0x5f46af['tenantId']!=null&&_0x5f46af['_tenantRecaptchaConfigs'][_0x5f46af['tenantId']]!==void 0x0)return _0x5f46af['_tenantRecaptchaConfigs'][_0x5f46af['tenantId']]['siteKey'];}return new Promise(async(_0x5177a4,_0x4c18f0)=>{gf(_0x5f46af,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1f3258=>{if(_0x1f3258['recaptchaKey']===void 0x0)_0x4c18f0(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xa57b77=new _f(_0x1f3258);return _0x5f46af['tenantId']==null?_0x5f46af['_agentRecaptchaConfig']=_0xa57b77:_0x5f46af['_tenantRecaptchaConfigs'][_0x5f46af['tenantId']]=_0xa57b77,_0x5177a4(_0xa57b77['siteKey']);}})['catch'](_0x344cce=>{_0x4c18f0(_0x344cce);});});}function _0x39c2eb(_0x1c740b,_0x2db60f,_0x49d0d2){const _0x123018=window['grecaptcha'];wr(_0x123018)?_0x123018['enterprise']['ready'](()=>{_0x123018['enterprise']['execute'](_0x1c740b,{'action':_0x30af34})['then'](_0x48ee58=>{_0x2db60f(_0x48ee58);})['catch'](()=>{_0x2db60f(Fa);});}):_0x49d0d2(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1245a8,_0x2fcd02)=>{_0x527617(this['auth'])['then'](async _0x51a9bd=>{if(!_0x249bff&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x39c2eb(_0x51a9bd,_0x1245a8,_0x2fcd02);else{if(typeof window>'u'){_0x2fcd02(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x514a5a=Df();_0x514a5a['length']!==0x0&&(_0x514a5a+=_0x51a9bd+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x2532b8;(_0x2532b8=he['scriptInjectionDeferred'])==null||_0x2532b8['resolve']();},xa(_0x514a5a)['then'](()=>{var _0x163d53;return(_0x163d53=he['scriptInjectionDeferred'])==null?void 0x0:_0x163d53['promise'];})['then'](()=>{_0x39c2eb(_0x51a9bd,_0x1245a8,_0x2fcd02);})['catch'](_0x594860=>{_0x2fcd02(_0x594860);});}})['catch'](_0x385701=>{_0x2fcd02(_0x385701);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x33a692,_0x53c814,_0x440a84,_0x51decd=!0x1,_0x11e303=!0x1){const _0x342bfd=new he(_0x33a692);let _0x49ec5f;if(_0x11e303)_0x49ec5f=Fa;else try{_0x49ec5f=await _0x342bfd['verify'](_0x440a84);}catch{_0x49ec5f=await _0x342bfd['verify'](_0x440a84,!0x0);}const _0x24304c={..._0x53c814};if(_0x440a84==='mfaSmsEnrollment'||_0x440a84==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x24304c){const _0x377df8=_0x24304c['phoneEnrollmentInfo']['phoneNumber'],_0x13c82=_0x24304c['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x24304c,{'phoneEnrollmentInfo':{'phoneNumber':_0x377df8,'recaptchaToken':_0x13c82,'captchaResponse':_0x49ec5f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x24304c){const _0xff37b3=_0x24304c['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x24304c,{'phoneSignInInfo':{'recaptchaToken':_0xff37b3,'captchaResponse':_0x49ec5f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x24304c;}return _0x51decd?Object['assign'](_0x24304c,{'captchaResp':_0x49ec5f}):Object['assign'](_0x24304c,{'captchaResponse':_0x49ec5f}),Object['assign'](_0x24304c,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x24304c,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x24304c;}async function xi(_0x3a25f5,_0x3283e4,_0x5c7355,_0x1fbc95,_0x502733){var _0x4393a6;if((_0x4393a6=_0x3a25f5['_getRecaptchaConfig']())!=null&&_0x4393a6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x15a921=await kr(_0x3a25f5,_0x3283e4,_0x5c7355,_0x5c7355==='getOobCode');return _0x1fbc95(_0x3a25f5,_0x15a921);}else return _0x1fbc95(_0x3a25f5,_0x3283e4)['catch'](async _0x596fae=>{if(_0x596fae['code']==='auth/missing-recaptcha-token'){console['log'](_0x5c7355+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x557a50=await kr(_0x3a25f5,_0x3283e4,_0x5c7355,_0x5c7355==='getOobCode');return _0x1fbc95(_0x3a25f5,_0x557a50);}else return Promise['reject'](_0x596fae);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0x5d920c,_0x9849dc){const _0x409e50=Hi(_0x5d920c,'auth');if(_0x409e50['isInitialized']()){const _0x17a38c=_0x409e50['getImmediate'](),_0x4db4e7=_0x409e50['getOptions']();if(Le(_0x4db4e7,_0x9849dc??{}))return _0x17a38c;Y(_0x17a38c,'already-initialized');}return _0x409e50['initialize']({'options':_0x9849dc});}function Bf(_0xd50916,_0x37fec4){const _0x51dea2=(_0x37fec4==null?void 0x0:_0x37fec4['persistence'])||[],_0x26c336=(Array['isArray'](_0x51dea2)?_0x51dea2:[_0x51dea2])['map'](ie);_0x37fec4!=null&&_0x37fec4['errorMap']&&_0xd50916['_updateErrorMap'](_0x37fec4['errorMap']),_0xd50916['_initializeWithPersistence'](_0x26c336,_0x37fec4==null?void 0x0:_0x37fec4['popupRedirectResolver']);}function Vf(_0x52679f,_0x44475b,_0x4d3c1a){const _0x280bb7=Ke(_0x52679f);m(/^https?:\/\//['test'](_0x44475b),_0x280bb7,'invalid-emulator-scheme');const _0x2b22dc=!0x1,_0x13e9cb=Ua(_0x44475b),{host:_0x1e2e87,port:_0x30ee91}=Hf(_0x44475b),_0x2021aa=_0x30ee91===null?'':':'+_0x30ee91,_0x568a62={'url':_0x13e9cb+'//'+_0x1e2e87+_0x2021aa+'/'},_0x464825=Object['freeze']({'host':_0x1e2e87,'port':_0x30ee91,'protocol':_0x13e9cb['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2b22dc})});if(!_0x280bb7['_canInitEmulator']){m(_0x280bb7['config']['emulator']&&_0x280bb7['emulatorConfig'],_0x280bb7,'emulator-config-failed'),m(Le(_0x568a62,_0x280bb7['config']['emulator'])&&Le(_0x464825,_0x280bb7['emulatorConfig']),_0x280bb7,'emulator-config-failed');return;}_0x280bb7['config']['emulator']=_0x568a62,_0x280bb7['emulatorConfig']=_0x464825,_0x280bb7['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x1e2e87)?Qr(_0x13e9cb+'//'+_0x1e2e87+_0x2021aa):$f();}function Ua(_0x3e580f){const _0x2a7bb2=_0x3e580f['indexOf'](':');return _0x2a7bb2<0x0?'':_0x3e580f['substr'](0x0,_0x2a7bb2+0x1);}function Hf(_0x53feaa){const _0x87f38f=Ua(_0x53feaa),_0x2e1561=/(\/\/)?([^?#/]+)/['exec'](_0x53feaa['substr'](_0x87f38f['length']));if(!_0x2e1561)return{'host':'','port':null};const _0x47dbaa=_0x2e1561[0x2]['split']('@')['pop']()||'',_0x34bf7e=/^(\[[^\]]+\])(:|$)/['exec'](_0x47dbaa);if(_0x34bf7e){const _0x391412=_0x34bf7e[0x1];return{'host':_0x391412,'port':Nr(_0x47dbaa['substr'](_0x391412['length']+0x1))};}else{const [_0x3b2ee9,_0x12d227]=_0x47dbaa['split'](':');return{'host':_0x3b2ee9,'port':Nr(_0x12d227)};}}function Nr(_0x23355b){if(!_0x23355b)return null;const _0x452dee=Number(_0x23355b);return isNaN(_0x452dee)?null:_0x452dee;}function $f(){function _0x293a0e(){const _0xb57035=document['createElement']('p'),_0x2c1870=_0xb57035['style'];_0xb57035['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2c1870['position']='fixed',_0x2c1870['width']='100%',_0x2c1870['backgroundColor']='#ffffff',_0x2c1870['border']='.1em\x20solid\x20#000000',_0x2c1870['color']='#b50000',_0x2c1870['bottom']='0px',_0x2c1870['left']='0px',_0x2c1870['margin']='0px',_0x2c1870['zIndex']='10000',_0x2c1870['textAlign']='center',_0xb57035['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xb57035);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x293a0e):_0x293a0e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3d2d0f,_0x4def88){this['providerId']=_0x3d2d0f,this['signInMethod']=_0x4def88;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0xfc8244){return ne('not\x20implemented');}['_linkToIdToken'](_0x3bb6d4,_0x25543e){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x5958f9){return ne('not\x20implemented');}}async function Gf(_0x878cc,_0x183b0e){return ke(_0x878cc,'POST','/v1/accounts:signUp',_0x183b0e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x2477d5,_0x17e25e){return en(_0x2477d5,'POST','/v1/accounts:signInWithPassword',Ae(_0x2477d5,_0x17e25e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x35833c,_0x3fba8e){return en(_0x35833c,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x35833c,_0x3fba8e));}async function jf(_0x991716,_0x2e3ddd){return en(_0x991716,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x991716,_0x2e3ddd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x510013,_0x141336,_0x31af4d,_0x43c1bc=null){super('password',_0x31af4d),this['_email']=_0x510013,this['_password']=_0x141336,this['_tenantId']=_0x43c1bc;}static['_fromEmailAndPassword'](_0x5d60d3,_0x31a027){return new Ht(_0x5d60d3,_0x31a027,'password');}static['_fromEmailAndCode'](_0x5b3029,_0xb0c26e,_0x4bf92a=null){return new Ht(_0x5b3029,_0xb0c26e,'emailLink',_0x4bf92a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x38e0a2){const _0x1ab093=typeof _0x38e0a2=='string'?JSON['parse'](_0x38e0a2):_0x38e0a2;if(_0x1ab093!=null&&_0x1ab093['email']&&(_0x1ab093!=null&&_0x1ab093['password'])){if(_0x1ab093['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1ab093['email'],_0x1ab093['password']);if(_0x1ab093['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1ab093['email'],_0x1ab093['password'],_0x1ab093['tenantId']);}return null;}async['_getIdTokenResponse'](_0x6983a8){switch(this['signInMethod']){case'password':const _0x2f0483={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x6983a8,_0x2f0483,'signInWithPassword',qf);case'emailLink':return zf(_0x6983a8,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x6983a8,'internal-error');}}async['_linkToIdToken'](_0x5d7bf3,_0x5c5c63){switch(this['signInMethod']){case'password':const _0x5eac42={'idToken':_0x5c5c63,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5d7bf3,_0x5eac42,'signUpPassword',Gf);case'emailLink':return jf(_0x5d7bf3,{'idToken':_0x5c5c63,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5d7bf3,'internal-error');}}['_getReauthenticationResolver'](_0x4ed808){return this['_getIdTokenResponse'](_0x4ed808);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x46c8ae,_0x36a4e1){return en(_0x46c8ae,'POST','/v1/accounts:signInWithIdp',Ae(_0x46c8ae,_0x36a4e1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x535f1d){const _0x3dd73d=new He(_0x535f1d['providerId'],_0x535f1d['signInMethod']);return _0x535f1d['idToken']||_0x535f1d['accessToken']?(_0x535f1d['idToken']&&(_0x3dd73d['idToken']=_0x535f1d['idToken']),_0x535f1d['accessToken']&&(_0x3dd73d['accessToken']=_0x535f1d['accessToken']),_0x535f1d['nonce']&&!_0x535f1d['pendingToken']&&(_0x3dd73d['nonce']=_0x535f1d['nonce']),_0x535f1d['pendingToken']&&(_0x3dd73d['pendingToken']=_0x535f1d['pendingToken'])):_0x535f1d['oauthToken']&&_0x535f1d['oauthTokenSecret']?(_0x3dd73d['accessToken']=_0x535f1d['oauthToken'],_0x3dd73d['secret']=_0x535f1d['oauthTokenSecret']):Y('argument-error'),_0x3dd73d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x136a5d){const _0x176462=typeof _0x136a5d=='string'?JSON['parse'](_0x136a5d):_0x136a5d,{providerId:_0x1bfec5,signInMethod:_0x1562c5,..._0x320b79}=_0x176462;if(!_0x1bfec5||!_0x1562c5)return null;const _0x483220=new He(_0x1bfec5,_0x1562c5);return _0x483220['idToken']=_0x320b79['idToken']||void 0x0,_0x483220['accessToken']=_0x320b79['accessToken']||void 0x0,_0x483220['secret']=_0x320b79['secret'],_0x483220['nonce']=_0x320b79['nonce'],_0x483220['pendingToken']=_0x320b79['pendingToken']||null,_0x483220;}['_getIdTokenResponse'](_0x401222){const _0x1f7e40=this['buildRequest']();return nt(_0x401222,_0x1f7e40);}['_linkToIdToken'](_0x37c368,_0x2381a1){const _0x47b12d=this['buildRequest']();return _0x47b12d['idToken']=_0x2381a1,nt(_0x37c368,_0x47b12d);}['_getReauthenticationResolver'](_0x3c642f){const _0x14e80c=this['buildRequest']();return _0x14e80c['autoCreate']=!0x1,nt(_0x3c642f,_0x14e80c);}['buildRequest'](){const _0x426bb3={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x426bb3['pendingToken']=this['pendingToken'];else{const _0x45ad5b={};this['idToken']&&(_0x45ad5b['id_token']=this['idToken']),this['accessToken']&&(_0x45ad5b['access_token']=this['accessToken']),this['secret']&&(_0x45ad5b['oauth_token_secret']=this['secret']),_0x45ad5b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x45ad5b['nonce']=this['nonce']),_0x426bb3['postBody']=ut(_0x45ad5b);}return _0x426bb3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0x36fa91){switch(_0x36fa91){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x1ea02f){const _0x4b6219=wt(Ct(_0x1ea02f))['link'],_0x3b4cec=_0x4b6219?wt(Ct(_0x4b6219))['deep_link_id']:null,_0x5b397c=wt(Ct(_0x1ea02f))['deep_link_id'];return(_0x5b397c?wt(Ct(_0x5b397c))['link']:null)||_0x5b397c||_0x3b4cec||_0x4b6219||_0x1ea02f;}class Rs{constructor(_0x5a6d13){const _0x264a0e=wt(Ct(_0x5a6d13)),_0x383986=_0x264a0e['apiKey']??null,_0x1398e5=_0x264a0e['oobCode']??null,_0x18e985=Yf(_0x264a0e['mode']??null);m(_0x383986&&_0x1398e5&&_0x18e985,'argument-error'),this['apiKey']=_0x383986,this['operation']=_0x18e985,this['code']=_0x1398e5,this['continueUrl']=_0x264a0e['continueUrl']??null,this['languageCode']=_0x264a0e['lang']??null,this['tenantId']=_0x264a0e['tenantId']??null;}static['parseLink'](_0x33997c){const _0x19b1fc=Qf(_0x33997c);try{return new Rs(_0x19b1fc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x2b9fec,_0x97853a){return Ht['_fromEmailAndPassword'](_0x2b9fec,_0x97853a);}static['credentialWithLink'](_0x5d28f4,_0x3d0dfa){const _0x1d9215=Rs['parseLink'](_0x3d0dfa);return m(_0x1d9215,'argument-error'),Ht['_fromEmailAndCode'](_0x5d28f4,_0x1d9215['code'],_0x1d9215['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2f9426){this['providerId']=_0x2f9426,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1c7657){this['defaultLanguageCode']=_0x1c7657;}['setCustomParameters'](_0x1cecb2){return this['customParameters']=_0x1cecb2,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x32fe17){return this['scopes']['includes'](_0x32fe17)||this['scopes']['push'](_0x32fe17),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x686a35){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x686a35});}static['credentialFromResult'](_0x258c58){return ue['credentialFromTaggedObject'](_0x258c58);}static['credentialFromError'](_0x58c5de){return ue['credentialFromTaggedObject'](_0x58c5de['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x45f531}){if(!_0x45f531||!('oauthAccessToken'in _0x45f531)||!_0x45f531['oauthAccessToken'])return null;try{return ue['credential'](_0x45f531['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2df3a0,_0x575c6f){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2df3a0,'accessToken':_0x575c6f});}static['credentialFromResult'](_0x1dd294){return de['credentialFromTaggedObject'](_0x1dd294);}static['credentialFromError'](_0x408c53){return de['credentialFromTaggedObject'](_0x408c53['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x10fad6}){if(!_0x10fad6)return null;const {oauthIdToken:_0x588326,oauthAccessToken:_0x4ac7f6}=_0x10fad6;if(!_0x588326&&!_0x4ac7f6)return null;try{return de['credential'](_0x588326,_0x4ac7f6);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x15a436){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x15a436});}static['credentialFromResult'](_0x4e72fd){return fe['credentialFromTaggedObject'](_0x4e72fd);}static['credentialFromError'](_0x5e552f){return fe['credentialFromTaggedObject'](_0x5e552f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb805f4}){if(!_0xb805f4||!('oauthAccessToken'in _0xb805f4)||!_0xb805f4['oauthAccessToken'])return null;try{return fe['credential'](_0xb805f4['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x360088,_0x362565){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x360088,'oauthTokenSecret':_0x362565});}static['credentialFromResult'](_0x5ea96c){return pe['credentialFromTaggedObject'](_0x5ea96c);}static['credentialFromError'](_0x363d5d){return pe['credentialFromTaggedObject'](_0x363d5d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x17b0b7}){if(!_0x17b0b7)return null;const {oauthAccessToken:_0x6774c8,oauthTokenSecret:_0x4e761d}=_0x17b0b7;if(!_0x6774c8||!_0x4e761d)return null;try{return pe['credential'](_0x6774c8,_0x4e761d);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x3c38de,_0x578a32){return en(_0x3c38de,'POST','/v1/accounts:signUp',Ae(_0x3c38de,_0x578a32));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x364b47){this['user']=_0x364b47['user'],this['providerId']=_0x364b47['providerId'],this['_tokenResponse']=_0x364b47['_tokenResponse'],this['operationType']=_0x364b47['operationType'];}static async['_fromIdTokenResponse'](_0x58258a,_0xe8fd71,_0x4c63e2,_0x12ff99=!0x1){const _0x5ead00=await j['_fromIdTokenResponse'](_0x58258a,_0x4c63e2,_0x12ff99),_0x51d6d0=Pr(_0x4c63e2);return new $e({'user':_0x5ead00,'providerId':_0x51d6d0,'_tokenResponse':_0x4c63e2,'operationType':_0xe8fd71});}static async['_forOperation'](_0x5215f3,_0x16250e,_0x56c4fd){await _0x5215f3['_updateTokensIfNecessary'](_0x56c4fd,!0x0);const _0x21aee2=Pr(_0x56c4fd);return new $e({'user':_0x5215f3,'providerId':_0x21aee2,'_tokenResponse':_0x56c4fd,'operationType':_0x16250e});}}function Pr(_0x44988e){return _0x44988e['providerId']?_0x44988e['providerId']:'phoneNumber'in _0x44988e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x29d9d7,_0x4e0ccd,_0x1e7fa1,_0x1e9cc1){super(_0x4e0ccd['code'],_0x4e0ccd['message']),this['operationType']=_0x1e7fa1,this['user']=_0x1e9cc1,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x29d9d7['name'],'tenantId':_0x29d9d7['tenantId']??void 0x0,'_serverResponse':_0x4e0ccd['customData']['_serverResponse'],'operationType':_0x1e7fa1};}static['_fromErrorAndOperation'](_0x5e2322,_0xc8cecd,_0x1a6147,_0x4eb2b9){return new On(_0x5e2322,_0xc8cecd,_0x1a6147,_0x4eb2b9);}}function Ba(_0x3daff4,_0x5308f1,_0x568e51,_0x2426d1){return(_0x5308f1==='reauthenticate'?_0x568e51['_getReauthenticationResolver'](_0x3daff4):_0x568e51['_getIdTokenResponse'](_0x3daff4))['catch'](_0x4077f4=>{throw _0x4077f4['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3daff4,_0x4077f4,_0x5308f1,_0x2426d1):_0x4077f4;});}async function Xf(_0xbd421d,_0x13a48e,_0x1ce98d=!0x1){const _0x59ca08=await Vt(_0xbd421d,_0x13a48e['_linkToIdToken'](_0xbd421d['auth'],await _0xbd421d['getIdToken']()),_0x1ce98d);return $e['_forOperation'](_0xbd421d,'link',_0x59ca08);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x362c8c,_0x3e89c1,_0x237554=!0x1){const {auth:_0x552931}=_0x362c8c;if($(_0x552931['app']))return Promise['reject'](re(_0x552931));const _0x128e78='reauthenticate';try{const _0x3e3769=await Vt(_0x362c8c,Ba(_0x552931,_0x128e78,_0x3e89c1,_0x362c8c),_0x237554);m(_0x3e3769['idToken'],_0x552931,'internal-error');const _0x5e6628=Ts(_0x3e3769['idToken']);m(_0x5e6628,_0x552931,'internal-error');const {sub:_0x47eb66}=_0x5e6628;return m(_0x362c8c['uid']===_0x47eb66,_0x552931,'user-mismatch'),$e['_forOperation'](_0x362c8c,_0x128e78,_0x3e3769);}catch(_0x4f6bfa){throw(_0x4f6bfa==null?void 0x0:_0x4f6bfa['code'])==='auth/user-not-found'&&Y(_0x552931,'user-mismatch'),_0x4f6bfa;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x49374b,_0x4c77ba,_0x50e63e=!0x1){if($(_0x49374b['app']))return Promise['reject'](re(_0x49374b));const _0x3aeab9='signIn',_0x314762=await Ba(_0x49374b,_0x3aeab9,_0x4c77ba),_0x223a29=await $e['_fromIdTokenResponse'](_0x49374b,_0x3aeab9,_0x314762);return _0x50e63e||await _0x49374b['_updateCurrentUser'](_0x223a29['user']),_0x223a29;}async function ep(_0x5c1af2,_0x58e3af){return Va(Ke(_0x5c1af2),_0x58e3af);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x52c49e){const _0x3996c6=Ke(_0x52c49e);_0x3996c6['_getPasswordPolicyInternal']()&&await _0x3996c6['_updatePasswordPolicy']();}async function O_(_0x476364,_0x92735a,_0x5e4cc1){if($(_0x476364['app']))return Promise['reject'](re(_0x476364));const _0x54ac24=Ke(_0x476364),_0x18b6fc=await xi(_0x54ac24,{'returnSecureToken':!0x0,'email':_0x92735a,'password':_0x5e4cc1,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0x237c11=>{throw _0x237c11['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x476364),_0x237c11;}),_0x340e23=await $e['_fromIdTokenResponse'](_0x54ac24,'signIn',_0x18b6fc);return await _0x54ac24['_updateCurrentUser'](_0x340e23['user']),_0x340e23;}function D_(_0x34bb03,_0x4ba05f,_0x38a6be){return $(_0x34bb03['app'])?Promise['reject'](re(_0x34bb03)):ep(N(_0x34bb03),mt['credential'](_0x4ba05f,_0x38a6be))['catch'](async _0x2cbb20=>{throw _0x2cbb20['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x34bb03),_0x2cbb20;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x45ddfd,_0x2bd862){return N(_0x45ddfd)['setPersistence'](_0x2bd862);}function tp(_0x227363,_0x264364,_0x388275,_0x207b86){return N(_0x227363)['onIdTokenChanged'](_0x264364,_0x388275,_0x207b86);}function np(_0x4725ba,_0x3303e7,_0x205e84){return N(_0x4725ba)['beforeAuthStateChanged'](_0x3303e7,_0x205e84);}function L_(_0x569bcc,_0x281b88,_0x5d1813,_0x461f50){return N(_0x569bcc)['onAuthStateChanged'](_0x281b88,_0x5d1813,_0x461f50);}function x_(_0x1ed775){return N(_0x1ed775)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x26610c,_0x531cdb){this['storageRetriever']=_0x26610c,this['type']=_0x531cdb;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2112cf,_0x382bb3){return this['storage']['setItem'](_0x2112cf,JSON['stringify'](_0x382bb3)),Promise['resolve']();}['_get'](_0x1ec5f2){const _0xcc60e1=this['storage']['getItem'](_0x1ec5f2);return Promise['resolve'](_0xcc60e1?JSON['parse'](_0xcc60e1):null);}['_remove'](_0x1f17ff){return this['storage']['removeItem'](_0x1f17ff),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x214f76,_0x2e992b)=>this['onStorageEvent'](_0x214f76,_0x2e992b),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4d7405){for(const _0x45beb9 of Object['keys'](this['listeners'])){const _0x34b5a6=this['storage']['getItem'](_0x45beb9),_0x4ec041=this['localCache'][_0x45beb9];_0x34b5a6!==_0x4ec041&&_0x4d7405(_0x45beb9,_0x4ec041,_0x34b5a6);}}['onStorageEvent'](_0x4684fa,_0x26e88c=!0x1){if(!_0x4684fa['key']){this['forAllChangedKeys']((_0x4fcf52,_0x3819f0,_0x35d6b3)=>{this['notifyListeners'](_0x4fcf52,_0x35d6b3);});return;}const _0x269b09=_0x4684fa['key'];_0x26e88c?this['detachListener']():this['stopPolling']();const _0x602fa0=()=>{const _0x5cdfaa=this['storage']['getItem'](_0x269b09);!_0x26e88c&&this['localCache'][_0x269b09]===_0x5cdfaa||this['notifyListeners'](_0x269b09,_0x5cdfaa);},_0x4db55c=this['storage']['getItem'](_0x269b09);bf()&&_0x4db55c!==_0x4684fa['newValue']&&_0x4684fa['newValue']!==_0x4684fa['oldValue']?setTimeout(_0x602fa0,sp):_0x602fa0();}['notifyListeners'](_0x2b38aa,_0x26c966){this['localCache'][_0x2b38aa]=_0x26c966;const _0x1a94b6=this['listeners'][_0x2b38aa];if(_0x1a94b6){for(const _0xe1e532 of Array['from'](_0x1a94b6))_0xe1e532(_0x26c966&&JSON['parse'](_0x26c966));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x23bfb8,_0x58b70c,_0xde81fe)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x23bfb8,'oldValue':_0x58b70c,'newValue':_0xde81fe}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x342a59,_0x37a048){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x342a59]||(this['listeners'][_0x342a59]=new Set(),this['localCache'][_0x342a59]=this['storage']['getItem'](_0x342a59)),this['listeners'][_0x342a59]['add'](_0x37a048);}['_removeListener'](_0x5db281,_0x2b429e){this['listeners'][_0x5db281]&&(this['listeners'][_0x5db281]['delete'](_0x2b429e),this['listeners'][_0x5db281]['size']===0x0&&delete this['listeners'][_0x5db281]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x552127,_0x3cb538){await super['_set'](_0x552127,_0x3cb538),this['localCache'][_0x552127]=JSON['stringify'](_0x3cb538);}async['_get'](_0x36f70c){const _0x441c8e=await super['_get'](_0x36f70c);return this['localCache'][_0x36f70c]=JSON['stringify'](_0x441c8e),_0x441c8e;}async['_remove'](_0x23303e){await super['_remove'](_0x23303e),delete this['localCache'][_0x23303e];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x771e21,_0x55a77f){}['_removeListener'](_0x5a7b77,_0x1ae41a){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x5cedf4){return Promise['all'](_0x5cedf4['map'](async _0x4862ba=>{try{return{'fulfilled':!0x0,'value':await _0x4862ba};}catch(_0x4c9f67){return{'fulfilled':!0x1,'reason':_0x4c9f67};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xdda1ea){this['eventTarget']=_0xdda1ea,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x364544){const _0x1c0fde=this['receivers']['find'](_0x1f5f93=>_0x1f5f93['isListeningto'](_0x364544));if(_0x1c0fde)return _0x1c0fde;const _0x4f1654=new Xn(_0x364544);return this['receivers']['push'](_0x4f1654),_0x4f1654;}['isListeningto'](_0x28a888){return this['eventTarget']===_0x28a888;}async['handleEvent'](_0x1f9526){const _0x3dc567=_0x1f9526,{eventId:_0x2d6abc,eventType:_0x339416,data:_0x1b2a69}=_0x3dc567['data'],_0x21c1aa=this['handlersMap'][_0x339416];if(!(_0x21c1aa!=null&&_0x21c1aa['size']))return;_0x3dc567['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2d6abc,'eventType':_0x339416});const _0x289e59=Array['from'](_0x21c1aa)['map'](async _0x146fdd=>_0x146fdd(_0x3dc567['origin'],_0x1b2a69)),_0x327c09=await op(_0x289e59);_0x3dc567['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2d6abc,'eventType':_0x339416,'response':_0x327c09});}['_subscribe'](_0x2c95ac,_0xb0a0ce){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2c95ac]||(this['handlersMap'][_0x2c95ac]=new Set()),this['handlersMap'][_0x2c95ac]['add'](_0xb0a0ce);}['_unsubscribe'](_0x366c29,_0x436633){this['handlersMap'][_0x366c29]&&_0x436633&&this['handlersMap'][_0x366c29]['delete'](_0x436633),(!_0x436633||this['handlersMap'][_0x366c29]['size']===0x0)&&delete this['handlersMap'][_0x366c29],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x525921='',_0x1be1e8=0xa){let _0x3e6a6a='';for(let _0x5b4344=0x0;_0x5b4344<_0x1be1e8;_0x5b4344++)_0x3e6a6a+=Math['floor'](Math['random']()*0xa);return _0x525921+_0x3e6a6a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0x3f61d3){this['target']=_0x3f61d3,this['handlers']=new Set();}['removeMessageHandler'](_0x21ef87){_0x21ef87['messageChannel']&&(_0x21ef87['messageChannel']['port1']['removeEventListener']('message',_0x21ef87['onMessage']),_0x21ef87['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x21ef87);}async['_send'](_0x10d72b,_0x1f067d,_0xbd617a=0x32){const _0x18801b=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x18801b)throw new Error('connection_unavailable');let _0x357453,_0x521aff;return new Promise((_0x411a7f,_0x478a61)=>{const _0x948b41=As('',0x14);_0x18801b['port1']['start']();const _0x1842ca=setTimeout(()=>{_0x478a61(new Error('unsupported_event'));},_0xbd617a);_0x521aff={'messageChannel':_0x18801b,'onMessage'(_0x498558){const _0x428850=_0x498558;if(_0x428850['data']['eventId']===_0x948b41)switch(_0x428850['data']['status']){case'ack':clearTimeout(_0x1842ca),_0x357453=setTimeout(()=>{_0x478a61(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x357453),_0x411a7f(_0x428850['data']['response']);break;default:clearTimeout(_0x1842ca),clearTimeout(_0x357453),_0x478a61(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x521aff),_0x18801b['port1']['addEventListener']('message',_0x521aff['onMessage']),this['target']['postMessage']({'eventType':_0x10d72b,'eventId':_0x948b41,'data':_0x1f067d},[_0x18801b['port2']]);})['finally'](()=>{_0x521aff&&this['removeMessageHandler'](_0x521aff);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0x37a29b){Z()['location']['href']=_0x37a29b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x59d8cb;return((_0x59d8cb=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x59d8cb['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x2a689f){this['request']=_0x2a689f;}['toPromise'](){return new Promise((_0x3d9337,_0x35be38)=>{this['request']['addEventListener']('success',()=>{_0x3d9337(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x35be38(this['request']['error']);});});}}function Zn(_0x399d38,_0x1d8a49){return _0x399d38['transaction']([Mn],_0x1d8a49?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x11165f=indexedDB['deleteDatabase'](Ka);return new nn(_0x11165f)['toPromise']();}function Qa(){const _0x5bbcf3=indexedDB['open'](Ka,dp);return new Promise((_0x33c57f,_0x27af30)=>{_0x5bbcf3['addEventListener']('error',()=>{_0x27af30(_0x5bbcf3['error']);}),_0x5bbcf3['addEventListener']('upgradeneeded',()=>{const _0x2584b9=_0x5bbcf3['result'];try{_0x2584b9['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x39f5fc){_0x27af30(_0x39f5fc);}}),_0x5bbcf3['addEventListener']('success',async()=>{const _0x396ca7=_0x5bbcf3['result'];_0x396ca7['objectStoreNames']['contains'](Mn)?_0x33c57f(_0x396ca7):(_0x396ca7['close'](),await fp(),_0x33c57f(await Qa()));});});}async function Or(_0x352752,_0xf19900,_0x40643a){const _0x3f7e53=Zn(_0x352752,!0x0)['put']({[Ya]:_0xf19900,'value':_0x40643a});return new nn(_0x3f7e53)['toPromise']();}async function pp(_0x203d6d,_0x41b5d3){const _0xee8ed9=Zn(_0x203d6d,!0x1)['get'](_0x41b5d3),_0x48fbbc=await new nn(_0xee8ed9)['toPromise']();return _0x48fbbc===void 0x0?null:_0x48fbbc['value'];}function Dr(_0x45aa18,_0x1932f4){const _0x28dadc=Zn(_0x45aa18,!0x0)['delete'](_0x1932f4);return new nn(_0x28dadc)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x886b48){let _0x3913fe=0x0;for(;;)try{const _0x263114=await this['_openDb']();return await _0x886b48(_0x263114);}catch(_0x17776c){if(_0x3913fe++>gp)throw _0x17776c;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0x18514c,_0x369f2f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x369f2f['key'])})),this['receiver']['_subscribe']('ping',async(_0x5857e2,_0x2f0fa4)=>['keyChanged']);}async['initializeSender'](){var _0x5a3102,_0x1b1b13;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0x36ba25=await this['sender']['_send']('ping',{},0x320);_0x36ba25&&(_0x5a3102=_0x36ba25[0x0])!=null&&_0x5a3102['fulfilled']&&(_0x1b1b13=_0x36ba25[0x0])!=null&&_0x1b1b13['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x16ebaa){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x16ebaa},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x52da28=>{await Or(_0x52da28,Dn,'1'),await Dr(_0x52da28,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2fce95){this['pendingWrites']++;try{await _0x2fce95();}finally{this['pendingWrites']--;}}async['_set'](_0x56be29,_0x3420a9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x33f21d=>Or(_0x33f21d,_0x56be29,_0x3420a9)),this['localCache'][_0x56be29]=_0x3420a9,this['notifyServiceWorker'](_0x56be29)));}async['_get'](_0x2665f1){const _0x5a464c=await this['_withRetries'](_0x381230=>pp(_0x381230,_0x2665f1));return this['localCache'][_0x2665f1]=_0x5a464c,_0x5a464c;}async['_remove'](_0x4f0941){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3bde5a=>Dr(_0x3bde5a,_0x4f0941)),delete this['localCache'][_0x4f0941],this['notifyServiceWorker'](_0x4f0941)));}async['_poll'](){const _0x1b3e98=await this['_withRetries'](_0x2981d5=>{const _0x127e2c=Zn(_0x2981d5,!0x1)['getAll']();return new nn(_0x127e2c)['toPromise']();});if(!_0x1b3e98)return[];if(this['pendingWrites']!==0x0)return[];const _0x17ff09=[],_0x2c0ff4=new Set();if(_0x1b3e98['length']!==0x0){for(const {fbase_key:_0x2564c2,value:_0x2ef569}of _0x1b3e98)_0x2c0ff4['add'](_0x2564c2),JSON['stringify'](this['localCache'][_0x2564c2])!==JSON['stringify'](_0x2ef569)&&(this['notifyListeners'](_0x2564c2,_0x2ef569),_0x17ff09['push'](_0x2564c2));}for(const _0x3ad942 of Object['keys'](this['localCache']))this['localCache'][_0x3ad942]&&!_0x2c0ff4['has'](_0x3ad942)&&(this['notifyListeners'](_0x3ad942,null),_0x17ff09['push'](_0x3ad942));return _0x17ff09;}['notifyListeners'](_0x508f9a,_0x13c1a0){this['localCache'][_0x508f9a]=_0x13c1a0;const _0xfb9f18=this['listeners'][_0x508f9a];if(_0xfb9f18){for(const _0x36301b of Array['from'](_0xfb9f18))_0x36301b(_0x13c1a0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x281175,_0x1c9529){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x281175]||(this['listeners'][_0x281175]=new Set(),this['_get'](_0x281175)),this['listeners'][_0x281175]['add'](_0x1c9529);}['_removeListener'](_0x986ed6,_0x1e3949){this['listeners'][_0x986ed6]&&(this['listeners'][_0x986ed6]['delete'](_0x1e3949),this['listeners'][_0x986ed6]['size']===0x0&&delete this['listeners'][_0x986ed6]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0xcc3c20,_0x1260f0){return _0x1260f0?ie(_0x1260f0):(m(_0xcc3c20['_popupRedirectResolver'],_0xcc3c20,'argument-error'),_0xcc3c20['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x205772){super('custom','custom'),this['params']=_0x205772;}['_getIdTokenResponse'](_0xda2023){return nt(_0xda2023,this['_buildIdpRequest']());}['_linkToIdToken'](_0x480ace,_0x57e6fb){return nt(_0x480ace,this['_buildIdpRequest'](_0x57e6fb));}['_getReauthenticationResolver'](_0x825cc2){return nt(_0x825cc2,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1e40e0){const _0x3a81d4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1e40e0&&(_0x3a81d4['idToken']=_0x1e40e0),_0x3a81d4;}}function vp(_0x369561){return Va(_0x369561['auth'],new ks(_0x369561),_0x369561['bypassAuthState']);}function Ep(_0xa53c0){const {auth:_0xdd2af3,user:_0x450fd3}=_0xa53c0;return m(_0x450fd3,_0xdd2af3,'internal-error'),Zf(_0x450fd3,new ks(_0xa53c0),_0xa53c0['bypassAuthState']);}async function Ip(_0x489792){const {auth:_0x2e4b2b,user:_0x4b5317}=_0x489792;return m(_0x4b5317,_0x2e4b2b,'internal-error'),Xf(_0x4b5317,new ks(_0x489792),_0x489792['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x58de5e,_0xd26797,_0x3d7739,_0x56fae2,_0x31d767=!0x1){this['auth']=_0x58de5e,this['resolver']=_0x3d7739,this['user']=_0x56fae2,this['bypassAuthState']=_0x31d767,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xd26797)?_0xd26797:[_0xd26797];}['execute'](){return new Promise(async(_0x261ed,_0x29320e)=>{this['pendingPromise']={'resolve':_0x261ed,'reject':_0x29320e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x320fea){this['reject'](_0x320fea);}});}async['onAuthEvent'](_0x3e4f86){const {urlResponse:_0x568b23,sessionId:_0x18af48,postBody:_0x43ae84,tenantId:_0x422f58,error:_0x48c4a9,type:_0x3f485c}=_0x3e4f86;if(_0x48c4a9){this['reject'](_0x48c4a9);return;}const _0x49d6ec={'auth':this['auth'],'requestUri':_0x568b23,'sessionId':_0x18af48,'tenantId':_0x422f58||void 0x0,'postBody':_0x43ae84||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3f485c)(_0x49d6ec));}catch(_0x2909bc){this['reject'](_0x2909bc);}}['onError'](_0x425853){this['reject'](_0x425853);}['getIdpTask'](_0x2d5746){switch(_0x2d5746){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0x57e7f1){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x57e7f1),this['unregisterAndCleanUp']();}['reject'](_0x5b4158){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5b4158),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x127bf1,_0x227aaf,_0x3e6992,_0x505e2c,_0x3ecfa3){super(_0x127bf1,_0x227aaf,_0x505e2c,_0x3ecfa3),this['provider']=_0x3e6992,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x465ad4=await this['execute']();return m(_0x465ad4,this['auth'],'internal-error'),_0x465ad4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5324fc=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5324fc),this['authWindow']['associatedEvent']=_0x5324fc,this['resolver']['_originValidation'](this['auth'])['catch'](_0x549237=>{this['reject'](_0x549237);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x44fefa=>{_0x44fefa||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x224690;return((_0x224690=this['authWindow'])==null?void 0x0:_0x224690['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x542be7=()=>{var _0x47fc91,_0x33afbf;if((_0x33afbf=(_0x47fc91=this['authWindow'])==null?void 0x0:_0x47fc91['window'])!=null&&_0x33afbf['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x542be7,wp['get']());};_0x542be7();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x3824a7,_0x4883af,_0x5c09ea=!0x1){super(_0x3824a7,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4883af,void 0x0,_0x5c09ea),this['eventId']=null;}async['execute'](){let _0x5c180c=hn['get'](this['auth']['_key']());if(!_0x5c180c){try{const _0x55ff92=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0x5c180c=()=>Promise['resolve'](_0x55ff92);}catch(_0x41ba49){_0x5c180c=()=>Promise['reject'](_0x41ba49);}hn['set'](this['auth']['_key'](),_0x5c180c);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5c180c();}async['onAuthEvent'](_0x4817fd){if(_0x4817fd['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4817fd);if(_0x4817fd['type']==='unknown'){this['resolve'](null);return;}if(_0x4817fd['eventId']){const _0x4212d4=await this['auth']['_redirectUserForId'](_0x4817fd['eventId']);if(_0x4212d4)return this['user']=_0x4212d4,super['onAuthEvent'](_0x4817fd);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0xa403f7,_0x15eb7a){const _0x5d6620=Ap(_0x15eb7a),_0x154a40=Rp(_0xa403f7);if(!await _0x154a40['_isAvailable']())return!0x1;const _0x2bdec0=await _0x154a40['_get'](_0x5d6620)==='true';return await _0x154a40['_remove'](_0x5d6620),_0x2bdec0;}function bp(_0x31cc7c,_0x559063){hn['set'](_0x31cc7c['_key'](),_0x559063);}function Rp(_0x393b08){return ie(_0x393b08['_redirectPersistence']);}function Ap(_0x4e1efa){return ln(Cp,_0x4e1efa['config']['apiKey'],_0x4e1efa['name']);}async function kp(_0x2699d2,_0x321dd4,_0x2585e0=!0x1){if($(_0x2699d2['app']))return Promise['reject'](re(_0x2699d2));const _0x221fed=Ke(_0x2699d2),_0x54862f=yp(_0x221fed,_0x321dd4),_0x40a2ac=await new Tp(_0x221fed,_0x54862f,_0x2585e0)['execute']();return _0x40a2ac&&!_0x2585e0&&(delete _0x40a2ac['user']['_redirectEventId'],await _0x221fed['_persistUserIfCurrent'](_0x40a2ac['user']),await _0x221fed['_setRedirectUser'](null,_0x321dd4)),_0x40a2ac;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x2dacf2){this['auth']=_0x2dacf2,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x5e9a04){this['consumers']['add'](_0x5e9a04),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x5e9a04)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x5e9a04),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5d75a0){this['consumers']['delete'](_0x5d75a0);}['onEvent'](_0x3d6d3d){if(this['hasEventBeenHandled'](_0x3d6d3d))return!0x1;let _0x45b1ce=!0x1;return this['consumers']['forEach'](_0x232712=>{this['isEventForConsumer'](_0x3d6d3d,_0x232712)&&(_0x45b1ce=!0x0,this['sendToConsumer'](_0x3d6d3d,_0x232712),this['saveEventToCache'](_0x3d6d3d));}),this['hasHandledPotentialRedirect']||!Op(_0x3d6d3d)||(this['hasHandledPotentialRedirect']=!0x0,_0x45b1ce||(this['queuedRedirectEvent']=_0x3d6d3d,_0x45b1ce=!0x0)),_0x45b1ce;}['sendToConsumer'](_0x2d0add,_0x5b3a7a){var _0x5530e8;if(_0x2d0add['error']&&!Za(_0x2d0add)){const _0x49f8eb=((_0x5530e8=_0x2d0add['error']['code'])==null?void 0x0:_0x5530e8['split']('auth/')[0x1])||'internal-error';_0x5b3a7a['onError'](X(this['auth'],_0x49f8eb));}else _0x5b3a7a['onAuthEvent'](_0x2d0add);}['isEventForConsumer'](_0x41e71c,_0x23dc0b){const _0x290ec=_0x23dc0b['eventId']===null||!!_0x41e71c['eventId']&&_0x41e71c['eventId']===_0x23dc0b['eventId'];return _0x23dc0b['filter']['includes'](_0x41e71c['type'])&&_0x290ec;}['hasEventBeenHandled'](_0x13fc21){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x13fc21));}['saveEventToCache'](_0x40cb2a){this['cachedEventUids']['add'](Mr(_0x40cb2a)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x10f803){return[_0x10f803['type'],_0x10f803['eventId'],_0x10f803['sessionId'],_0x10f803['tenantId']]['filter'](_0x366aef=>_0x366aef)['join']('-');}function Za({type:_0x386700,error:_0x4a124e}){return _0x386700==='unknown'&&(_0x4a124e==null?void 0x0:_0x4a124e['code'])==='auth/no-auth-event';}function Op(_0x50ddc3){switch(_0x50ddc3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x50ddc3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x2034e7,_0x2eab5a={}){return ke(_0x2034e7,'GET','/v1/projects',_0x2eab5a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x545c08){if(_0x545c08['config']['emulator'])return;const {authorizedDomains:_0xa10e68}=await Dp(_0x545c08);for(const _0x395022 of _0xa10e68)try{if(Fp(_0x395022))return;}catch{}Y(_0x545c08,'unauthorized-domain');}function Fp(_0x37c030){const _0x55b4f3=Mi(),{protocol:_0x182e69,hostname:_0x1e2670}=new URL(_0x55b4f3);if(_0x37c030['startsWith']('chrome-extension://')){const _0x4e3fe2=new URL(_0x37c030);return _0x4e3fe2['hostname']===''&&_0x1e2670===''?_0x182e69==='chrome-extension:'&&_0x37c030['replace']('chrome-extension://','')===_0x55b4f3['replace']('chrome-extension://',''):_0x182e69==='chrome-extension:'&&_0x4e3fe2['hostname']===_0x1e2670;}if(!Lp['test'](_0x182e69))return!0x1;if(Mp['test'](_0x37c030))return _0x1e2670===_0x37c030;const _0xb1602e=_0x37c030['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xb1602e+'|'+_0xb1602e+')$','i')['test'](_0x1e2670);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0x2e93e4=Z()['___jsl'];if(_0x2e93e4!=null&&_0x2e93e4['H']){for(const _0x1cba8c of Object['keys'](_0x2e93e4['H']))if(_0x2e93e4['H'][_0x1cba8c]['r']=_0x2e93e4['H'][_0x1cba8c]['r']||[],_0x2e93e4['H'][_0x1cba8c]['L']=_0x2e93e4['H'][_0x1cba8c]['L']||[],_0x2e93e4['H'][_0x1cba8c]['r']=[..._0x2e93e4['H'][_0x1cba8c]['L']],_0x2e93e4['CP']){for(let _0x28fd7b=0x0;_0x28fd7b<_0x2e93e4['CP']['length'];_0x28fd7b++)_0x2e93e4['CP'][_0x28fd7b]=null;}}}function Wp(_0x124f87){return new Promise((_0x553773,_0x15eeb0)=>{var _0x191c10,_0x22da24,_0x2c78dc;function _0x5b8a22(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x553773(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x15eeb0(X(_0x124f87,'network-request-failed'));},'timeout':Up['get']()});}if((_0x22da24=(_0x191c10=Z()['gapi'])==null?void 0x0:_0x191c10['iframes'])!=null&&_0x22da24['Iframe'])_0x553773(gapi['iframes']['getContext']());else{if((_0x2c78dc=Z()['gapi'])!=null&&_0x2c78dc['load'])_0x5b8a22();else{const _0x155663=Lf('iframefcb');return Z()[_0x155663]=()=>{gapi['load']?_0x5b8a22():_0x15eeb0(X(_0x124f87,'network-request-failed'));},xa(Mf()+'?onload='+_0x155663)['catch'](_0xdbba8b=>_0x15eeb0(_0xdbba8b));}}})['catch'](_0x444daa=>{throw un=null,_0x444daa;});}let un=null;function Bp(_0x3052f4){return un=un||Wp(_0x3052f4),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0x491ea0){const _0x10f979=_0x491ea0['config'];m(_0x10f979['authDomain'],_0x491ea0,'auth-domain-config-required');const _0x207037=_0x10f979['emulator']?Cs(_0x10f979,$p):'https://'+_0x491ea0['config']['authDomain']+'/'+Hp,_0x5eb45b={'apiKey':_0x10f979['apiKey'],'appName':_0x491ea0['name'],'v':dt},_0x1fd20e=qp['get'](_0x491ea0['config']['apiHost']);_0x1fd20e&&(_0x5eb45b['eid']=_0x1fd20e);const _0x3de0c3=_0x491ea0['_getFrameworks']();return _0x3de0c3['length']&&(_0x5eb45b['fw']=_0x3de0c3['join'](',')),_0x207037+'?'+ut(_0x5eb45b)['slice'](0x1);}async function jp(_0x5260fe){const _0x4beaff=await Bp(_0x5260fe),_0x33ddd2=Z()['gapi'];return m(_0x33ddd2,_0x5260fe,'internal-error'),_0x4beaff['open']({'where':document['body'],'url':zp(_0x5260fe),'messageHandlersFilter':_0x33ddd2['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0x527e5c=>new Promise(async(_0x2970b8,_0x2a2ab6)=>{await _0x527e5c['restyle']({'setHideOnLeave':!0x1});const _0x5c02e6=X(_0x5260fe,'network-request-failed'),_0x4d2007=Z()['setTimeout'](()=>{_0x2a2ab6(_0x5c02e6);},Vp['get']());function _0x17db0f(){Z()['clearTimeout'](_0x4d2007),_0x2970b8(_0x527e5c);}_0x527e5c['ping'](_0x17db0f)['then'](_0x17db0f,()=>{_0x2a2ab6(_0x5c02e6);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x37f6cc){this['window']=_0x37f6cc,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x4b8a9c,_0x4be65d,_0x4c9328,_0x44c0d0=Yp,_0x272ab0=Qp){const _0x699c92=Math['max']((window['screen']['availHeight']-_0x272ab0)/0x2,0x0)['toString'](),_0x1684dc=Math['max']((window['screen']['availWidth']-_0x44c0d0)/0x2,0x0)['toString']();let _0x373f57='';const _0x3dedc2={...Kp,'width':_0x44c0d0['toString'](),'height':_0x272ab0['toString'](),'top':_0x699c92,'left':_0x1684dc},_0x33c17e=W()['toLowerCase']();_0x4c9328&&(_0x373f57=ka(_0x33c17e)?Jp:_0x4c9328),Ra(_0x33c17e)&&(_0x4be65d=_0x4be65d||Xp,_0x3dedc2['scrollbars']='yes');const _0x10fcec=Object['entries'](_0x3dedc2)['reduce']((_0x5c09a0,[_0x460e55,_0x1a305a])=>''+_0x5c09a0+_0x460e55+'='+_0x1a305a+',','');if(Sf(_0x33c17e)&&_0x373f57!=='_self')return e_(_0x4be65d||'',_0x373f57),new xr(null);const _0x1dbc76=window['open'](_0x4be65d||'',_0x373f57,_0x10fcec);m(_0x1dbc76,_0x4b8a9c,'popup-blocked');try{_0x1dbc76['focus']();}catch{}return new xr(_0x1dbc76);}function e_(_0x15a04a,_0x4d1252){const _0x3215fa=document['createElement']('a');_0x3215fa['href']=_0x15a04a,_0x3215fa['target']=_0x4d1252;const _0x572d5b=document['createEvent']('MouseEvent');_0x572d5b['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3215fa['dispatchEvent'](_0x572d5b);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0x534845,_0x576fc7,_0x3fba05,_0xd00c19,_0x3fe0e1,_0xcb9ad2){m(_0x534845['config']['authDomain'],_0x534845,'auth-domain-config-required'),m(_0x534845['config']['apiKey'],_0x534845,'invalid-api-key');const _0x487005={'apiKey':_0x534845['config']['apiKey'],'appName':_0x534845['name'],'authType':_0x3fba05,'redirectUrl':_0xd00c19,'v':dt,'eventId':_0x3fe0e1};if(_0x576fc7 instanceof Wa){_0x576fc7['setDefaultLanguage'](_0x534845['languageCode']),_0x487005['providerId']=_0x576fc7['providerId']||'',pn(_0x576fc7['getCustomParameters']())||(_0x487005['customParameters']=JSON['stringify'](_0x576fc7['getCustomParameters']()));for(const [_0x566fe3,_0x3fee29]of Object['entries']({}))_0x487005[_0x566fe3]=_0x3fee29;}if(_0x576fc7 instanceof tn){const _0x39671c=_0x576fc7['getScopes']()['filter'](_0x2e5682=>_0x2e5682!=='');_0x39671c['length']>0x0&&(_0x487005['scopes']=_0x39671c['join'](','));}_0x534845['tenantId']&&(_0x487005['tid']=_0x534845['tenantId']);const _0x982dc3=_0x487005;for(const _0x21f246 of Object['keys'](_0x982dc3))_0x982dc3[_0x21f246]===void 0x0&&delete _0x982dc3[_0x21f246];const _0x24bebc=await _0x534845['_getAppCheckToken'](),_0x280c62=_0x24bebc?'#'+i_+'='+encodeURIComponent(_0x24bebc):'';return s_(_0x534845)+'?'+ut(_0x982dc3)['slice'](0x1)+_0x280c62;}function s_({config:_0xdfbebb}){return _0xdfbebb['emulator']?Cs(_0xdfbebb,n_):'https://'+_0xdfbebb['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x369770,_0x2e5a1f,_0x4f8f23,_0x3a3d24){var _0x2ade31;ce((_0x2ade31=this['eventManagers'][_0x369770['_key']()])==null?void 0x0:_0x2ade31['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x487d7d=await Fr(_0x369770,_0x2e5a1f,_0x4f8f23,Mi(),_0x3a3d24);return Zp(_0x369770,_0x487d7d,As());}async['_openRedirect'](_0x4db7be,_0x3cc0a9,_0x278888,_0x282003){await this['_originValidation'](_0x4db7be);const _0x13688d=await Fr(_0x4db7be,_0x3cc0a9,_0x278888,Mi(),_0x282003);return cp(_0x13688d),new Promise(()=>{});}['_initialize'](_0x5ed8e8){const _0x16bce2=_0x5ed8e8['_key']();if(this['eventManagers'][_0x16bce2]){const {manager:_0x402f19,promise:_0x517e9b}=this['eventManagers'][_0x16bce2];return _0x402f19?Promise['resolve'](_0x402f19):(ce(_0x517e9b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x517e9b);}const _0x4edc6a=this['initAndGetManager'](_0x5ed8e8);return this['eventManagers'][_0x16bce2]={'promise':_0x4edc6a},_0x4edc6a['catch'](()=>{delete this['eventManagers'][_0x16bce2];}),_0x4edc6a;}async['initAndGetManager'](_0x53a1f4){const _0x3f0624=await jp(_0x53a1f4),_0x38c71c=new Pp(_0x53a1f4);return _0x3f0624['register']('authEvent',_0x27aafc=>(m(_0x27aafc==null?void 0x0:_0x27aafc['authEvent'],_0x53a1f4,'invalid-auth-event'),{'status':_0x38c71c['onEvent'](_0x27aafc['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x53a1f4['_key']()]={'manager':_0x38c71c},this['iframes'][_0x53a1f4['_key']()]=_0x3f0624,_0x38c71c;}['_isIframeWebStorageSupported'](_0x116758,_0x39d324){this['iframes'][_0x116758['_key']()]['send'](pi,{'type':pi},_0x33eb1e=>{var _0x24d638;const _0x8c7150=(_0x24d638=_0x33eb1e==null?void 0x0:_0x33eb1e[0x0])==null?void 0x0:_0x24d638[pi];_0x8c7150!==void 0x0&&_0x39d324(!!_0x8c7150),Y(_0x116758,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x54b36b){const _0x5d6755=_0x54b36b['_key']();return this['originValidationPromises'][_0x5d6755]||(this['originValidationPromises'][_0x5d6755]=xp(_0x54b36b)),this['originValidationPromises'][_0x5d6755];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0x874e27){this['auth']=_0x874e27,this['internalListeners']=new Map();}['getUid'](){var _0x2c8d77;return this['assertAuthConfigured'](),((_0x2c8d77=this['auth']['currentUser'])==null?void 0x0:_0x2c8d77['uid'])||null;}async['getToken'](_0x21023f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x21023f)}:null;}['addAuthTokenListener'](_0x36fe84){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x36fe84))return;const _0x1d48e9=this['auth']['onIdTokenChanged'](_0xf97688=>{_0x36fe84((_0xf97688==null?void 0x0:_0xf97688['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x36fe84,_0x1d48e9),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2c5c8b){this['assertAuthConfigured']();const _0x2cbcb=this['internalListeners']['get'](_0x2c5c8b);_0x2cbcb&&(this['internalListeners']['delete'](_0x2c5c8b),_0x2cbcb(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x895244){switch(_0x895244){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x1f0175){st(new xe('auth',(_0x1ae383,{options:_0x51ee5c})=>{const _0xd0e983=_0x1ae383['getProvider']('app')['getImmediate'](),_0x19eae7=_0x1ae383['getProvider']('heartbeat'),_0xc6810e=_0x1ae383['getProvider']('app-check-internal'),{apiKey:_0x51022d,authDomain:_0x2a8d6d}=_0xd0e983['options'];m(_0x51022d&&!_0x51022d['includes'](':'),'invalid-api-key',{'appName':_0xd0e983['name']});const _0x466465={'apiKey':_0x51022d,'authDomain':_0x2a8d6d,'clientPlatform':_0x1f0175,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1f0175)},_0x5165d4=new Pf(_0xd0e983,_0x19eae7,_0xc6810e,_0x466465);return Bf(_0x5165d4,_0x51ee5c),_0x5165d4;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x40004d,_0x592699,_0x73da1d)=>{_0x40004d['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x3ff725=>{const _0x1da4f9=Ke(_0x3ff725['getProvider']('auth')['getImmediate']());return(_0x1abcc1=>new a_(_0x1abcc1))(_0x1da4f9);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x1f0175)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x5da86c=>async _0x46b4e1=>{const _0xe07e0=_0x46b4e1&&await _0x46b4e1['getIdTokenResult'](),_0x18cb23=_0xe07e0&&(new Date()['getTime']()-Date['parse'](_0xe07e0['issuedAtTime']))/0x3e8;if(_0x18cb23&&_0x18cb23>u_)return;const _0xe1f5d8=_0xe07e0==null?void 0x0:_0xe07e0['token'];Br!==_0xe1f5d8&&(Br=_0xe1f5d8,await fetch(_0x5da86c,{'method':_0xe1f5d8?'POST':'DELETE','headers':_0xe1f5d8?{'Authorization':'Bearer\x20'+_0xe1f5d8}:{}}));};function F_(_0xb14ccd=Zr()){const _0x3343ad=Hi(_0xb14ccd,'auth');if(_0x3343ad['isInitialized']())return _0x3343ad['getImmediate']();const _0x4e00ad=Wf(_0xb14ccd,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0xec3fc2=jr('authTokenSyncURL');if(_0xec3fc2&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xf602b=new URL(_0xec3fc2,location['origin']);if(location['origin']===_0xf602b['origin']){const _0xe4116c=d_(_0xf602b['toString']());np(_0x4e00ad,_0xe4116c,()=>_0xe4116c(_0x4e00ad['currentUser'])),tp(_0x4e00ad,_0x2eb844=>_0xe4116c(_0x2eb844));}}const _0x59ee06=qr('auth');return _0x59ee06&&Vf(_0x4e00ad,'http://'+_0x59ee06),_0x4e00ad;}function f_(){var _0x917874;return((_0x917874=document['getElementsByTagName']('head'))==null?void 0x0:_0x917874[0x0])??document;}Of({'loadJS'(_0x3f9014){return new Promise((_0x145599,_0x303372)=>{const _0xf0f837=document['createElement']('script');_0xf0f837['setAttribute']('src',_0x3f9014),_0xf0f837['onload']=_0x145599,_0xf0f837['onerror']=_0x3ef59f=>{const _0x2a1d33=X('internal-error');_0x2a1d33['customData']=_0x3ef59f,_0x303372(_0x2a1d33);},_0xf0f837['type']='text/javascript',_0xf0f837['charset']='UTF-8',f_()['appendChild'](_0xf0f837);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{x_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,__ as h,Sl as i,Vd as j,N_ as k,$d as l,A_ as m,L_ as n,m_ as o,k_ as p,b_ as q,g_ as r,M_ as s,C_ as t,v_ as u,S_ as v,Bt as w,y_ as x,P_ as y,O_ as z};