const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4443be,_0x2a0f3b){if(!_0x4443be)throw ht(_0x2a0f3b);},ht=function(_0xf8a4e2){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xf8a4e2);},Hr=function(_0x36d9db){const _0x2e68a3=[];let _0x1e3d65=0x0;for(let _0x3990c9=0x0;_0x3990c9<_0x36d9db['length'];_0x3990c9++){let _0x4d3224=_0x36d9db['charCodeAt'](_0x3990c9);_0x4d3224<0x80?_0x2e68a3[_0x1e3d65++]=_0x4d3224:_0x4d3224<0x800?(_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0x6|0xc0,_0x2e68a3[_0x1e3d65++]=_0x4d3224&0x3f|0x80):(_0x4d3224&0xfc00)===0xd800&&_0x3990c9+0x1<_0x36d9db['length']&&(_0x36d9db['charCodeAt'](_0x3990c9+0x1)&0xfc00)===0xdc00?(_0x4d3224=0x10000+((_0x4d3224&0x3ff)<<0xa)+(_0x36d9db['charCodeAt'](++_0x3990c9)&0x3ff),_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0x12|0xf0,_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0xc&0x3f|0x80,_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0x6&0x3f|0x80,_0x2e68a3[_0x1e3d65++]=_0x4d3224&0x3f|0x80):(_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0xc|0xe0,_0x2e68a3[_0x1e3d65++]=_0x4d3224>>0x6&0x3f|0x80,_0x2e68a3[_0x1e3d65++]=_0x4d3224&0x3f|0x80);}return _0x2e68a3;},nc=function(_0x245317){const _0x4eb7da=[];let _0x3664da=0x0,_0xbf927b=0x0;for(;_0x3664da<_0x245317['length'];){const _0xc18348=_0x245317[_0x3664da++];if(_0xc18348<0x80)_0x4eb7da[_0xbf927b++]=String['fromCharCode'](_0xc18348);else{if(_0xc18348>0xbf&&_0xc18348<0xe0){const _0x15b358=_0x245317[_0x3664da++];_0x4eb7da[_0xbf927b++]=String['fromCharCode']((_0xc18348&0x1f)<<0x6|_0x15b358&0x3f);}else{if(_0xc18348>0xef&&_0xc18348<0x16d){const _0x3c4b9c=_0x245317[_0x3664da++],_0x523c30=_0x245317[_0x3664da++],_0x460c63=_0x245317[_0x3664da++],_0x4ec6aa=((_0xc18348&0x7)<<0x12|(_0x3c4b9c&0x3f)<<0xc|(_0x523c30&0x3f)<<0x6|_0x460c63&0x3f)-0x10000;_0x4eb7da[_0xbf927b++]=String['fromCharCode'](0xd800+(_0x4ec6aa>>0xa)),_0x4eb7da[_0xbf927b++]=String['fromCharCode'](0xdc00+(_0x4ec6aa&0x3ff));}else{const _0x2762be=_0x245317[_0x3664da++],_0x479118=_0x245317[_0x3664da++];_0x4eb7da[_0xbf927b++]=String['fromCharCode']((_0xc18348&0xf)<<0xc|(_0x2762be&0x3f)<<0x6|_0x479118&0x3f);}}}}return _0x4eb7da['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4d5c0b,_0x368b6e){if(!Array['isArray'](_0x4d5c0b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5d90ee=_0x368b6e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3dcf1a=[];for(let _0x243bc3=0x0;_0x243bc3<_0x4d5c0b['length'];_0x243bc3+=0x3){const _0x96ba3e=_0x4d5c0b[_0x243bc3],_0x1f6e83=_0x243bc3+0x1<_0x4d5c0b['length'],_0x30461f=_0x1f6e83?_0x4d5c0b[_0x243bc3+0x1]:0x0,_0x3d9ddb=_0x243bc3+0x2<_0x4d5c0b['length'],_0x3e5b78=_0x3d9ddb?_0x4d5c0b[_0x243bc3+0x2]:0x0,_0x296b25=_0x96ba3e>>0x2,_0x17421f=(_0x96ba3e&0x3)<<0x4|_0x30461f>>0x4;let _0x1b7eed=(_0x30461f&0xf)<<0x2|_0x3e5b78>>0x6,_0x461807=_0x3e5b78&0x3f;_0x3d9ddb||(_0x461807=0x40,_0x1f6e83||(_0x1b7eed=0x40)),_0x3dcf1a['push'](_0x5d90ee[_0x296b25],_0x5d90ee[_0x17421f],_0x5d90ee[_0x1b7eed],_0x5d90ee[_0x461807]);}return _0x3dcf1a['join']('');},'encodeString'(_0x1c6604,_0x361069){return this['HAS_NATIVE_SUPPORT']&&!_0x361069?btoa(_0x1c6604):this['encodeByteArray'](Hr(_0x1c6604),_0x361069);},'decodeString'(_0x572fc8,_0x125e8c){return this['HAS_NATIVE_SUPPORT']&&!_0x125e8c?atob(_0x572fc8):nc(this['decodeStringToByteArray'](_0x572fc8,_0x125e8c));},'decodeStringToByteArray'(_0x3b19e3,_0x84fec1){this['init_']();const _0x34b1c6=_0x84fec1?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x49f0c1=[];for(let _0x3b3f59=0x0;_0x3b3f59<_0x3b19e3['length'];){const _0x30f0f2=_0x34b1c6[_0x3b19e3['charAt'](_0x3b3f59++)],_0x47baf3=_0x3b3f59<_0x3b19e3['length']?_0x34b1c6[_0x3b19e3['charAt'](_0x3b3f59)]:0x0;++_0x3b3f59;const _0x444045=_0x3b3f59<_0x3b19e3['length']?_0x34b1c6[_0x3b19e3['charAt'](_0x3b3f59)]:0x40;++_0x3b3f59;const _0x4ae43d=_0x3b3f59<_0x3b19e3['length']?_0x34b1c6[_0x3b19e3['charAt'](_0x3b3f59)]:0x40;if(++_0x3b3f59,_0x30f0f2==null||_0x47baf3==null||_0x444045==null||_0x4ae43d==null)throw new ic();const _0x2c6c6c=_0x30f0f2<<0x2|_0x47baf3>>0x4;if(_0x49f0c1['push'](_0x2c6c6c),_0x444045!==0x40){const _0xcdb35a=_0x47baf3<<0x4&0xf0|_0x444045>>0x2;if(_0x49f0c1['push'](_0xcdb35a),_0x4ae43d!==0x40){const _0xe76924=_0x444045<<0x6&0xc0|_0x4ae43d;_0x49f0c1['push'](_0xe76924);}}}return _0x49f0c1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4de1c1=0x0;_0x4de1c1<this['ENCODED_VALS']['length'];_0x4de1c1++)this['byteToCharMap_'][_0x4de1c1]=this['ENCODED_VALS']['charAt'](_0x4de1c1),this['charToByteMap_'][this['byteToCharMap_'][_0x4de1c1]]=_0x4de1c1,this['byteToCharMapWebSafe_'][_0x4de1c1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4de1c1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4de1c1]]=_0x4de1c1,_0x4de1c1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4de1c1)]=_0x4de1c1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4de1c1)]=_0x4de1c1);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3c32d6){const _0x3b19ea=Hr(_0x3c32d6);return Fi['encodeByteArray'](_0x3b19ea,!0x0);},dn=function(_0x191f8a){return $r(_0x191f8a)['replace'](/\./g,'');},fn=function(_0x2cfd31){try{return Fi['decodeString'](_0x2cfd31,!0x0);}catch(_0x399db0){console['error']('base64Decode\x20failed:\x20',_0x399db0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x16215d){return Gr(void 0x0,_0x16215d);}function Gr(_0x2ca4c0,_0x37ca8a){if(!(_0x37ca8a instanceof Object))return _0x37ca8a;switch(_0x37ca8a['constructor']){case Date:const _0x478bf5=_0x37ca8a;return new Date(_0x478bf5['getTime']());case Object:_0x2ca4c0===void 0x0&&(_0x2ca4c0={});break;case Array:_0x2ca4c0=[];break;default:return _0x37ca8a;}for(const _0x303f77 in _0x37ca8a)!_0x37ca8a['hasOwnProperty'](_0x303f77)||!rc(_0x303f77)||(_0x2ca4c0[_0x303f77]=Gr(_0x2ca4c0[_0x303f77],_0x37ca8a[_0x303f77]));return _0x2ca4c0;}function rc(_0x1a08f6){return _0x1a08f6!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x5137e9=Ns['__FIREBASE_DEFAULTS__'];if(_0x5137e9)return JSON['parse'](_0x5137e9);},lc=()=>{if(typeof document>'u')return;let _0xa6fe5d;try{_0xa6fe5d=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2cf918=_0xa6fe5d&&fn(_0xa6fe5d[0x1]);return _0x2cf918&&JSON['parse'](_0x2cf918);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3c37e1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3c37e1);return;}},qr=_0x3d79b0=>{var _0x5064e2,_0xa61a;return(_0xa61a=(_0x5064e2=Ui())==null?void 0x0:_0x5064e2['emulatorHosts'])==null?void 0x0:_0xa61a[_0x3d79b0];},hc=_0x571e74=>{const _0x2ac1da=qr(_0x571e74);if(!_0x2ac1da)return;const _0x283d6d=_0x2ac1da['lastIndexOf'](':');if(_0x283d6d<=0x0||_0x283d6d+0x1===_0x2ac1da['length'])throw new Error('Invalid\x20host\x20'+_0x2ac1da+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5476f1=parseInt(_0x2ac1da['substring'](_0x283d6d+0x1),0xa);return _0x2ac1da[0x0]==='['?[_0x2ac1da['substring'](0x1,_0x283d6d-0x1),_0x5476f1]:[_0x2ac1da['substring'](0x0,_0x283d6d),_0x5476f1];},zr=()=>{var _0x610184;return(_0x610184=Ui())==null?void 0x0:_0x610184['config'];},jr=_0x289ea2=>{var _0x12146f;return(_0x12146f=Ui())==null?void 0x0:_0x12146f['_'+_0x289ea2];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2f28fd,_0x48cba1)=>{this['resolve']=_0x2f28fd,this['reject']=_0x48cba1;});}['wrapCallback'](_0x117bdf){return(_0x55d912,_0x2bbb75)=>{_0x55d912?this['reject'](_0x55d912):this['resolve'](_0x2bbb75),typeof _0x117bdf=='function'&&(this['promise']['catch'](()=>{}),_0x117bdf['length']===0x1?_0x117bdf(_0x55d912):_0x117bdf(_0x55d912,_0x2bbb75));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4b5b89,_0x244339){if(_0x4b5b89['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3fbadc={'alg':'none','type':'JWT'},_0x11ac82=_0x244339||'demo-project',_0x596ef1=_0x4b5b89['iat']||0x0,_0x53d915=_0x4b5b89['sub']||_0x4b5b89['user_id'];if(!_0x53d915)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x434787={'iss':'https://securetoken.google.com/'+_0x11ac82,'aud':_0x11ac82,'iat':_0x596ef1,'exp':_0x596ef1+0xe10,'auth_time':_0x596ef1,'sub':_0x53d915,'user_id':_0x53d915,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4b5b89};return[dn(JSON['stringify'](_0x3fbadc)),dn(JSON['stringify'](_0x434787)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0xe555c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xe555c=='object'&&_0xe555c['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xb2f4ed=W();return _0xb2f4ed['indexOf']('MSIE\x20')>=0x0||_0xb2f4ed['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x17a28a,_0x1427a)=>{try{let _0x3b3f16=!0x0;const _0xfda072='validate-browser-context-for-indexeddb-analytics-module',_0x3246a8=self['indexedDB']['open'](_0xfda072);_0x3246a8['onsuccess']=()=>{_0x3246a8['result']['close'](),_0x3b3f16||self['indexedDB']['deleteDatabase'](_0xfda072),_0x17a28a(!0x0);},_0x3246a8['onupgradeneeded']=()=>{_0x3b3f16=!0x1;},_0x3246a8['onerror']=()=>{var _0x5632e2;_0x1427a(((_0x5632e2=_0x3246a8['error'])==null?void 0x0:_0x5632e2['message'])||'');};}catch(_0x5471f9){_0x1427a(_0x5471f9);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x395807,_0x4ce22c,_0x2f3bdf){super(_0x4ce22c),this['code']=_0x395807,this['customData']=_0x2f3bdf,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x369c5a,_0x1329c3,_0x424d1d){this['service']=_0x369c5a,this['serviceName']=_0x1329c3,this['errors']=_0x424d1d;}['create'](_0x4fae53,..._0xf0db86){const _0x26e3ff=_0xf0db86[0x0]||{},_0x5cf71a=this['service']+'/'+_0x4fae53,_0x322db0=this['errors'][_0x4fae53],_0x1ddd13=_0x322db0?vc(_0x322db0,_0x26e3ff):'Error',_0x281674=this['serviceName']+':\x20'+_0x1ddd13+'\x20('+_0x5cf71a+').';return new Re(_0x5cf71a,_0x281674,_0x26e3ff);}}function vc(_0x4cc561,_0x447d4b){return _0x4cc561['replace'](Ec,(_0x4f593d,_0x5d46ce)=>{const _0x224979=_0x447d4b[_0x5d46ce];return _0x224979!=null?String(_0x224979):'<'+_0x5d46ce+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x24441b){return JSON['parse'](_0x24441b);}function O(_0x213833){return JSON['stringify'](_0x213833);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x574c3e){let _0x87a0aa={},_0x2a2c53={},_0x371c83={},_0x3f9610='';try{const _0x3d5e49=_0x574c3e['split']('.');_0x87a0aa=Nt(fn(_0x3d5e49[0x0])||''),_0x2a2c53=Nt(fn(_0x3d5e49[0x1])||''),_0x3f9610=_0x3d5e49[0x2],_0x371c83=_0x2a2c53['d']||{},delete _0x2a2c53['d'];}catch{}return{'header':_0x87a0aa,'claims':_0x2a2c53,'data':_0x371c83,'signature':_0x3f9610};},Ic=function(_0x146dd1){const _0x58f3f7=Yr(_0x146dd1),_0x38bec5=_0x58f3f7['claims'];return!!_0x38bec5&&typeof _0x38bec5=='object'&&_0x38bec5['hasOwnProperty']('iat');},wc=function(_0x2a8726){const _0x3cecb0=Yr(_0x2a8726)['claims'];return typeof _0x3cecb0=='object'&&_0x3cecb0['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x53cc83,_0x3a300b){return Object['prototype']['hasOwnProperty']['call'](_0x53cc83,_0x3a300b);}function Me(_0x54d8b9,_0x2ea614){if(Object['prototype']['hasOwnProperty']['call'](_0x54d8b9,_0x2ea614))return _0x54d8b9[_0x2ea614];}function pn(_0x404847){for(const _0x39fdd3 in _0x404847)if(Object['prototype']['hasOwnProperty']['call'](_0x404847,_0x39fdd3))return!0x1;return!0x0;}function _n(_0xd35ce7,_0x3aa568,_0x5b239f){const _0x2641ee={};for(const _0x27d953 in _0xd35ce7)Object['prototype']['hasOwnProperty']['call'](_0xd35ce7,_0x27d953)&&(_0x2641ee[_0x27d953]=_0x3aa568['call'](_0x5b239f,_0xd35ce7[_0x27d953],_0x27d953,_0xd35ce7));return _0x2641ee;}function Le(_0x5b6178,_0x5294b5){if(_0x5b6178===_0x5294b5)return!0x0;const _0x1a19e3=Object['keys'](_0x5b6178),_0xc0cb96=Object['keys'](_0x5294b5);for(const _0x59688a of _0x1a19e3){if(!_0xc0cb96['includes'](_0x59688a))return!0x1;const _0x309eed=_0x5b6178[_0x59688a],_0x3948ec=_0x5294b5[_0x59688a];if(Ps(_0x309eed)&&Ps(_0x3948ec)){if(!Le(_0x309eed,_0x3948ec))return!0x1;}else{if(_0x309eed!==_0x3948ec)return!0x1;}}for(const _0x36dc2e of _0xc0cb96)if(!_0x1a19e3['includes'](_0x36dc2e))return!0x1;return!0x0;}function Ps(_0x5e9f85){return _0x5e9f85!==null&&typeof _0x5e9f85=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x3c14cd){const _0x5db144=[];for(const [_0x15358a,_0x3ea410]of Object['entries'](_0x3c14cd))Array['isArray'](_0x3ea410)?_0x3ea410['forEach'](_0x22ff26=>{_0x5db144['push'](encodeURIComponent(_0x15358a)+'='+encodeURIComponent(_0x22ff26));}):_0x5db144['push'](encodeURIComponent(_0x15358a)+'='+encodeURIComponent(_0x3ea410));return _0x5db144['length']?'&'+_0x5db144['join']('&'):'';}function wt(_0x1d6ae7){const _0x22fd37={};return _0x1d6ae7['replace'](/^\?/,'')['split']('&')['forEach'](_0x4ecb92=>{if(_0x4ecb92){const [_0x7372e7,_0x5a5fd0]=_0x4ecb92['split']('=');_0x22fd37[decodeURIComponent(_0x7372e7)]=decodeURIComponent(_0x5a5fd0);}}),_0x22fd37;}function Ct(_0x44f4e0){const _0x219976=_0x44f4e0['indexOf']('?');if(!_0x219976)return'';const _0x19754e=_0x44f4e0['indexOf']('#',_0x219976);return _0x44f4e0['substring'](_0x219976,_0x19754e>0x0?_0x19754e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x39e17c=0x1;_0x39e17c<this['blockSize'];++_0x39e17c)this['pad_'][_0x39e17c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5158fd,_0x4db783){_0x4db783||(_0x4db783=0x0);const _0x1e8e4a=this['W_'];if(typeof _0x5158fd=='string'){for(let _0x46bcae=0x0;_0x46bcae<0x10;_0x46bcae++)_0x1e8e4a[_0x46bcae]=_0x5158fd['charCodeAt'](_0x4db783)<<0x18|_0x5158fd['charCodeAt'](_0x4db783+0x1)<<0x10|_0x5158fd['charCodeAt'](_0x4db783+0x2)<<0x8|_0x5158fd['charCodeAt'](_0x4db783+0x3),_0x4db783+=0x4;}else{for(let _0x2ead8b=0x0;_0x2ead8b<0x10;_0x2ead8b++)_0x1e8e4a[_0x2ead8b]=_0x5158fd[_0x4db783]<<0x18|_0x5158fd[_0x4db783+0x1]<<0x10|_0x5158fd[_0x4db783+0x2]<<0x8|_0x5158fd[_0x4db783+0x3],_0x4db783+=0x4;}for(let _0x5aee25=0x10;_0x5aee25<0x50;_0x5aee25++){const _0xce7537=_0x1e8e4a[_0x5aee25-0x3]^_0x1e8e4a[_0x5aee25-0x8]^_0x1e8e4a[_0x5aee25-0xe]^_0x1e8e4a[_0x5aee25-0x10];_0x1e8e4a[_0x5aee25]=(_0xce7537<<0x1|_0xce7537>>>0x1f)&0xffffffff;}let _0x236e1=this['chain_'][0x0],_0x1aea99=this['chain_'][0x1],_0x2e566c=this['chain_'][0x2],_0x24ac8f=this['chain_'][0x3],_0x3ff3ed=this['chain_'][0x4],_0x292e6b,_0x387ab7;for(let _0x13f2b5=0x0;_0x13f2b5<0x50;_0x13f2b5++){_0x13f2b5<0x28?_0x13f2b5<0x14?(_0x292e6b=_0x24ac8f^_0x1aea99&(_0x2e566c^_0x24ac8f),_0x387ab7=0x5a827999):(_0x292e6b=_0x1aea99^_0x2e566c^_0x24ac8f,_0x387ab7=0x6ed9eba1):_0x13f2b5<0x3c?(_0x292e6b=_0x1aea99&_0x2e566c|_0x24ac8f&(_0x1aea99|_0x2e566c),_0x387ab7=0x8f1bbcdc):(_0x292e6b=_0x1aea99^_0x2e566c^_0x24ac8f,_0x387ab7=0xca62c1d6);const _0x26d0c2=(_0x236e1<<0x5|_0x236e1>>>0x1b)+_0x292e6b+_0x3ff3ed+_0x387ab7+_0x1e8e4a[_0x13f2b5]&0xffffffff;_0x3ff3ed=_0x24ac8f,_0x24ac8f=_0x2e566c,_0x2e566c=(_0x1aea99<<0x1e|_0x1aea99>>>0x2)&0xffffffff,_0x1aea99=_0x236e1,_0x236e1=_0x26d0c2;}this['chain_'][0x0]=this['chain_'][0x0]+_0x236e1&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1aea99&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2e566c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x24ac8f&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3ff3ed&0xffffffff;}['update'](_0x526c8a,_0x53d1d7){if(_0x526c8a==null)return;_0x53d1d7===void 0x0&&(_0x53d1d7=_0x526c8a['length']);const _0x22fec1=_0x53d1d7-this['blockSize'];let _0x3f09a1=0x0;const _0x4b2a9c=this['buf_'];let _0x4d6c8f=this['inbuf_'];for(;_0x3f09a1<_0x53d1d7;){if(_0x4d6c8f===0x0){for(;_0x3f09a1<=_0x22fec1;)this['compress_'](_0x526c8a,_0x3f09a1),_0x3f09a1+=this['blockSize'];}if(typeof _0x526c8a=='string'){for(;_0x3f09a1<_0x53d1d7;)if(_0x4b2a9c[_0x4d6c8f]=_0x526c8a['charCodeAt'](_0x3f09a1),++_0x4d6c8f,++_0x3f09a1,_0x4d6c8f===this['blockSize']){this['compress_'](_0x4b2a9c),_0x4d6c8f=0x0;break;}}else{for(;_0x3f09a1<_0x53d1d7;)if(_0x4b2a9c[_0x4d6c8f]=_0x526c8a[_0x3f09a1],++_0x4d6c8f,++_0x3f09a1,_0x4d6c8f===this['blockSize']){this['compress_'](_0x4b2a9c),_0x4d6c8f=0x0;break;}}}this['inbuf_']=_0x4d6c8f,this['total_']+=_0x53d1d7;}['digest'](){const _0x23bf55=[];let _0x1bd529=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x21d92d=this['blockSize']-0x1;_0x21d92d>=0x38;_0x21d92d--)this['buf_'][_0x21d92d]=_0x1bd529&0xff,_0x1bd529/=0x100;this['compress_'](this['buf_']);let _0x316e54=0x0;for(let _0x17e830=0x0;_0x17e830<0x5;_0x17e830++)for(let _0x4a3ace=0x18;_0x4a3ace>=0x0;_0x4a3ace-=0x8)_0x23bf55[_0x316e54]=this['chain_'][_0x17e830]>>_0x4a3ace&0xff,++_0x316e54;return _0x23bf55;}}function Tc(_0x5733a5,_0x1c982e){const _0x1d6686=new Sc(_0x5733a5,_0x1c982e);return _0x1d6686['subscribe']['bind'](_0x1d6686);}class Sc{constructor(_0x53f521,_0xcbca9e){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xcbca9e,this['task']['then'](()=>{_0x53f521(this);})['catch'](_0x53c239=>{this['error'](_0x53c239);});}['next'](_0x547ab1){this['forEachObserver'](_0x64b9b4=>{_0x64b9b4['next'](_0x547ab1);});}['error'](_0x55ec3){this['forEachObserver'](_0x541e7e=>{_0x541e7e['error'](_0x55ec3);}),this['close'](_0x55ec3);}['complete'](){this['forEachObserver'](_0x4c1ab0=>{_0x4c1ab0['complete']();}),this['close']();}['subscribe'](_0xc1a42e,_0x48c324,_0x2d3f07){let _0x4a2791;if(_0xc1a42e===void 0x0&&_0x48c324===void 0x0&&_0x2d3f07===void 0x0)throw new Error('Missing\x20Observer.');bc(_0xc1a42e,['next','error','complete'])?_0x4a2791=_0xc1a42e:_0x4a2791={'next':_0xc1a42e,'error':_0x48c324,'complete':_0x2d3f07},_0x4a2791['next']===void 0x0&&(_0x4a2791['next']=ti),_0x4a2791['error']===void 0x0&&(_0x4a2791['error']=ti),_0x4a2791['complete']===void 0x0&&(_0x4a2791['complete']=ti);const _0x3c385a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4a2791['error'](this['finalError']):_0x4a2791['complete']();}catch{}}),this['observers']['push'](_0x4a2791),_0x3c385a;}['unsubscribeOne'](_0x44de9d){this['observers']===void 0x0||this['observers'][_0x44de9d]===void 0x0||(delete this['observers'][_0x44de9d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x13b7c1){if(!this['finalized']){for(let _0x2b7760=0x0;_0x2b7760<this['observers']['length'];_0x2b7760++)this['sendOne'](_0x2b7760,_0x13b7c1);}}['sendOne'](_0x74b2e7,_0x4e61f5){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x74b2e7]!==void 0x0)try{_0x4e61f5(this['observers'][_0x74b2e7]);}catch(_0x59639d){typeof console<'u'&&console['error']&&console['error'](_0x59639d);}});}['close'](_0x4d0bcc){this['finalized']||(this['finalized']=!0x0,_0x4d0bcc!==void 0x0&&(this['finalError']=_0x4d0bcc),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x586fc3,_0x5815d3){if(typeof _0x586fc3!='object'||_0x586fc3===null)return!0x1;for(const _0x342e99 of _0x5815d3)if(_0x342e99 in _0x586fc3&&typeof _0x586fc3[_0x342e99]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x3418ba,_0x5de017){return _0x3418ba+'\x20failed:\x20'+_0x5de017+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x15c1a4){const _0x8b4ccc=[];let _0x30a78e=0x0;for(let _0x4dabad=0x0;_0x4dabad<_0x15c1a4['length'];_0x4dabad++){let _0x2435e3=_0x15c1a4['charCodeAt'](_0x4dabad);if(_0x2435e3>=0xd800&&_0x2435e3<=0xdbff){const _0xb90ec0=_0x2435e3-0xd800;_0x4dabad++,f(_0x4dabad<_0x15c1a4['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4d2c02=_0x15c1a4['charCodeAt'](_0x4dabad)-0xdc00;_0x2435e3=0x10000+(_0xb90ec0<<0xa)+_0x4d2c02;}_0x2435e3<0x80?_0x8b4ccc[_0x30a78e++]=_0x2435e3:_0x2435e3<0x800?(_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0x6|0xc0,_0x8b4ccc[_0x30a78e++]=_0x2435e3&0x3f|0x80):_0x2435e3<0x10000?(_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0xc|0xe0,_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0x6&0x3f|0x80,_0x8b4ccc[_0x30a78e++]=_0x2435e3&0x3f|0x80):(_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0x12|0xf0,_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0xc&0x3f|0x80,_0x8b4ccc[_0x30a78e++]=_0x2435e3>>0x6&0x3f|0x80,_0x8b4ccc[_0x30a78e++]=_0x2435e3&0x3f|0x80);}return _0x8b4ccc;},Ln=function(_0x174939){let _0x580adb=0x0;for(let _0x219ebb=0x0;_0x219ebb<_0x174939['length'];_0x219ebb++){const _0x135139=_0x174939['charCodeAt'](_0x219ebb);_0x135139<0x80?_0x580adb++:_0x135139<0x800?_0x580adb+=0x2:_0x135139>=0xd800&&_0x135139<=0xdbff?(_0x580adb+=0x4,_0x219ebb++):_0x580adb+=0x3;}return _0x580adb;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0xf0782e){return _0xf0782e&&_0xf0782e['_delegate']?_0xf0782e['_delegate']:_0xf0782e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x4128f5){try{return(_0x4128f5['startsWith']('http://')||_0x4128f5['startsWith']('https://')?new URL(_0x4128f5)['hostname']:_0x4128f5)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x79fa00){return(await fetch(_0x79fa00,{'credentials':'include'}))['ok'];}class xe{constructor(_0x2f58ed,_0x31ae85,_0x3bb840){this['name']=_0x2f58ed,this['instanceFactory']=_0x31ae85,this['type']=_0x3bb840,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1ac4e6){return this['instantiationMode']=_0x1ac4e6,this;}['setMultipleInstances'](_0x45f23b){return this['multipleInstances']=_0x45f23b,this;}['setServiceProps'](_0x282acd){return this['serviceProps']=_0x282acd,this;}['setInstanceCreatedCallback'](_0x3f556e){return this['onInstanceCreated']=_0x3f556e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1d2359,_0x11d45b){this['name']=_0x1d2359,this['container']=_0x11d45b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x50eabc){const _0x1e838c=this['normalizeInstanceIdentifier'](_0x50eabc);if(!this['instancesDeferred']['has'](_0x1e838c)){const _0x117f07=new H();if(this['instancesDeferred']['set'](_0x1e838c,_0x117f07),this['isInitialized'](_0x1e838c)||this['shouldAutoInitialize']())try{const _0x29095d=this['getOrInitializeService']({'instanceIdentifier':_0x1e838c});_0x29095d&&_0x117f07['resolve'](_0x29095d);}catch{}}return this['instancesDeferred']['get'](_0x1e838c)['promise'];}['getImmediate'](_0x1b20e9){const _0x1e77f6=this['normalizeInstanceIdentifier'](_0x1b20e9==null?void 0x0:_0x1b20e9['identifier']),_0x5d4cc8=(_0x1b20e9==null?void 0x0:_0x1b20e9['optional'])??!0x1;if(this['isInitialized'](_0x1e77f6)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1e77f6});}catch(_0xc8fea4){if(_0x5d4cc8)return null;throw _0xc8fea4;}else{if(_0x5d4cc8)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x169c46){if(_0x169c46['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x169c46['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x169c46,!!this['shouldAutoInitialize']()){if(Nc(_0x169c46))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4b0f65,_0x5bfd15]of this['instancesDeferred']['entries']()){const _0x192154=this['normalizeInstanceIdentifier'](_0x4b0f65);try{const _0x47fd7b=this['getOrInitializeService']({'instanceIdentifier':_0x192154});_0x5bfd15['resolve'](_0x47fd7b);}catch{}}}}['clearInstance'](_0x3f1c9a=Ne){this['instancesDeferred']['delete'](_0x3f1c9a),this['instancesOptions']['delete'](_0x3f1c9a),this['instances']['delete'](_0x3f1c9a);}async['delete'](){const _0x2d2c78=Array['from'](this['instances']['values']());await Promise['all']([..._0x2d2c78['filter'](_0x4cd728=>'INTERNAL'in _0x4cd728)['map'](_0x16850d=>_0x16850d['INTERNAL']['delete']()),..._0x2d2c78['filter'](_0x5bed1c=>'_delete'in _0x5bed1c)['map'](_0xcc4169=>_0xcc4169['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x59d009=Ne){return this['instances']['has'](_0x59d009);}['getOptions'](_0x467632=Ne){return this['instancesOptions']['get'](_0x467632)||{};}['initialize'](_0x1a660e={}){const {options:_0x371b1d={}}=_0x1a660e,_0x4aaf97=this['normalizeInstanceIdentifier'](_0x1a660e['instanceIdentifier']);if(this['isInitialized'](_0x4aaf97))throw Error(this['name']+'('+_0x4aaf97+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2d4577=this['getOrInitializeService']({'instanceIdentifier':_0x4aaf97,'options':_0x371b1d});for(const [_0x9e7bcf,_0x27fe14]of this['instancesDeferred']['entries']()){const _0x47b10f=this['normalizeInstanceIdentifier'](_0x9e7bcf);_0x4aaf97===_0x47b10f&&_0x27fe14['resolve'](_0x2d4577);}return _0x2d4577;}['onInit'](_0x5c8c40,_0x5ec745){const _0x296596=this['normalizeInstanceIdentifier'](_0x5ec745),_0x4553e0=this['onInitCallbacks']['get'](_0x296596)??new Set();_0x4553e0['add'](_0x5c8c40),this['onInitCallbacks']['set'](_0x296596,_0x4553e0);const _0x315084=this['instances']['get'](_0x296596);return _0x315084&&_0x5c8c40(_0x315084,_0x296596),()=>{_0x4553e0['delete'](_0x5c8c40);};}['invokeOnInitCallbacks'](_0x4a6bf5,_0x39345a){const _0x559720=this['onInitCallbacks']['get'](_0x39345a);if(_0x559720){for(const _0x327293 of _0x559720)try{_0x327293(_0x4a6bf5,_0x39345a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x15b2fb,options:_0x3a7cdb={}}){let _0x3c2826=this['instances']['get'](_0x15b2fb);if(!_0x3c2826&&this['component']&&(_0x3c2826=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x15b2fb),'options':_0x3a7cdb}),this['instances']['set'](_0x15b2fb,_0x3c2826),this['instancesOptions']['set'](_0x15b2fb,_0x3a7cdb),this['invokeOnInitCallbacks'](_0x3c2826,_0x15b2fb),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x15b2fb,_0x3c2826);}catch{}return _0x3c2826||null;}['normalizeInstanceIdentifier'](_0x8a032=Ne){return this['component']?this['component']['multipleInstances']?_0x8a032:Ne:_0x8a032;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2ec86e){return _0x2ec86e===Ne?void 0x0:_0x2ec86e;}function Nc(_0xcb3db7){return _0xcb3db7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x46cee6){this['name']=_0x46cee6,this['providers']=new Map();}['addComponent'](_0x2d3466){const _0x5ddc08=this['getProvider'](_0x2d3466['name']);if(_0x5ddc08['isComponentSet']())throw new Error('Component\x20'+_0x2d3466['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5ddc08['setComponent'](_0x2d3466);}['addOrOverwriteComponent'](_0x34fe6d){this['getProvider'](_0x34fe6d['name'])['isComponentSet']()&&this['providers']['delete'](_0x34fe6d['name']),this['addComponent'](_0x34fe6d);}['getProvider'](_0x506079){if(this['providers']['has'](_0x506079))return this['providers']['get'](_0x506079);const _0xc765fc=new Ac(_0x506079,this);return this['providers']['set'](_0x506079,_0xc765fc),_0xc765fc;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x31d17b){_0x31d17b[_0x31d17b['DEBUG']=0x0]='DEBUG',_0x31d17b[_0x31d17b['VERBOSE']=0x1]='VERBOSE',_0x31d17b[_0x31d17b['INFO']=0x2]='INFO',_0x31d17b[_0x31d17b['WARN']=0x3]='WARN',_0x31d17b[_0x31d17b['ERROR']=0x4]='ERROR',_0x31d17b[_0x31d17b['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x2f1719,_0x27769d,..._0x2af4c2)=>{if(_0x27769d<_0x2f1719['logLevel'])return;const _0x1888ba=new Date()['toISOString'](),_0x1c2de3=Mc[_0x27769d];if(_0x1c2de3)console[_0x1c2de3]('['+_0x1888ba+']\x20\x20'+_0x2f1719['name']+':',..._0x2af4c2);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x27769d+')');};class Bi{constructor(_0x69d506){this['name']=_0x69d506,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xd85719){if(!(_0xd85719 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xd85719+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xd85719;}['setLogLevel'](_0x3fea84){this['_logLevel']=typeof _0x3fea84=='string'?Oc[_0x3fea84]:_0x3fea84;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x197d58){if(typeof _0x197d58!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x197d58;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5320fa){this['_userLogHandler']=_0x5320fa;}['debug'](..._0x1550e2){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1550e2),this['_logHandler'](this,T['DEBUG'],..._0x1550e2);}['log'](..._0x4ccc47){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4ccc47),this['_logHandler'](this,T['VERBOSE'],..._0x4ccc47);}['info'](..._0x2a87a7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x2a87a7),this['_logHandler'](this,T['INFO'],..._0x2a87a7);}['warn'](..._0x409228){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x409228),this['_logHandler'](this,T['WARN'],..._0x409228);}['error'](..._0x16b220){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x16b220),this['_logHandler'](this,T['ERROR'],..._0x16b220);}}const xc=(_0x4a8ae9,_0x525b9b)=>_0x525b9b['some'](_0x208d84=>_0x4a8ae9 instanceof _0x208d84);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x2af448){const _0x2d988d=new Promise((_0x2ce321,_0x40bdab)=>{const _0xd44913=()=>{_0x2af448['removeEventListener']('success',_0x433ff2),_0x2af448['removeEventListener']('error',_0x526757);},_0x433ff2=()=>{_0x2ce321(ge(_0x2af448['result'])),_0xd44913();},_0x526757=()=>{_0x40bdab(_0x2af448['error']),_0xd44913();};_0x2af448['addEventListener']('success',_0x433ff2),_0x2af448['addEventListener']('error',_0x526757);});return _0x2d988d['then'](_0x2e0cba=>{_0x2e0cba instanceof IDBCursor&&Jr['set'](_0x2e0cba,_0x2af448);})['catch'](()=>{}),Vi['set'](_0x2d988d,_0x2af448),_0x2d988d;}function Bc(_0x538576){if(_i['has'](_0x538576))return;const _0x355a09=new Promise((_0x5bbb27,_0x6119d4)=>{const _0x729af5=()=>{_0x538576['removeEventListener']('complete',_0x3b0cd8),_0x538576['removeEventListener']('error',_0x41e2a9),_0x538576['removeEventListener']('abort',_0x41e2a9);},_0x3b0cd8=()=>{_0x5bbb27(),_0x729af5();},_0x41e2a9=()=>{_0x6119d4(_0x538576['error']||new DOMException('AbortError','AbortError')),_0x729af5();};_0x538576['addEventListener']('complete',_0x3b0cd8),_0x538576['addEventListener']('error',_0x41e2a9),_0x538576['addEventListener']('abort',_0x41e2a9);});_i['set'](_0x538576,_0x355a09);}let gi={'get'(_0x1547ad,_0x53dc4e,_0x20a8ab){if(_0x1547ad instanceof IDBTransaction){if(_0x53dc4e==='done')return _i['get'](_0x1547ad);if(_0x53dc4e==='objectStoreNames')return _0x1547ad['objectStoreNames']||Xr['get'](_0x1547ad);if(_0x53dc4e==='store')return _0x20a8ab['objectStoreNames'][0x1]?void 0x0:_0x20a8ab['objectStore'](_0x20a8ab['objectStoreNames'][0x0]);}return ge(_0x1547ad[_0x53dc4e]);},'set'(_0x1639a9,_0x5514b7,_0x431f95){return _0x1639a9[_0x5514b7]=_0x431f95,!0x0;},'has'(_0x1e4e5f,_0x5e03fe){return _0x1e4e5f instanceof IDBTransaction&&(_0x5e03fe==='done'||_0x5e03fe==='store')?!0x0:_0x5e03fe in _0x1e4e5f;}};function Vc(_0x2724cf){gi=_0x2724cf(gi);}function Hc(_0xfd68de){return _0xfd68de===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x33b512,..._0x2e7d53){const _0x37514e=_0xfd68de['call'](ii(this),_0x33b512,..._0x2e7d53);return Xr['set'](_0x37514e,_0x33b512['sort']?_0x33b512['sort']():[_0x33b512]),ge(_0x37514e);}:Uc()['includes'](_0xfd68de)?function(..._0x935c4){return _0xfd68de['apply'](ii(this),_0x935c4),ge(Jr['get'](this));}:function(..._0x16f2f5){return ge(_0xfd68de['apply'](ii(this),_0x16f2f5));};}function $c(_0x2ef9af){return typeof _0x2ef9af=='function'?Hc(_0x2ef9af):(_0x2ef9af instanceof IDBTransaction&&Bc(_0x2ef9af),xc(_0x2ef9af,Fc())?new Proxy(_0x2ef9af,gi):_0x2ef9af);}function ge(_0x360074){if(_0x360074 instanceof IDBRequest)return Wc(_0x360074);if(ni['has'](_0x360074))return ni['get'](_0x360074);const _0x5324cc=$c(_0x360074);return _0x5324cc!==_0x360074&&(ni['set'](_0x360074,_0x5324cc),Vi['set'](_0x5324cc,_0x360074)),_0x5324cc;}const ii=_0x3e17a0=>Vi['get'](_0x3e17a0);function Gc(_0x1e6199,_0x10e316,{blocked:_0x4c870f,upgrade:_0x4a68a3,blocking:_0x6828b3,terminated:_0x330418}={}){const _0x398469=indexedDB['open'](_0x1e6199,_0x10e316),_0x222206=ge(_0x398469);return _0x4a68a3&&_0x398469['addEventListener']('upgradeneeded',_0x5ea71e=>{_0x4a68a3(ge(_0x398469['result']),_0x5ea71e['oldVersion'],_0x5ea71e['newVersion'],ge(_0x398469['transaction']),_0x5ea71e);}),_0x4c870f&&_0x398469['addEventListener']('blocked',_0x42f49b=>_0x4c870f(_0x42f49b['oldVersion'],_0x42f49b['newVersion'],_0x42f49b)),_0x222206['then'](_0x334453=>{_0x330418&&_0x334453['addEventListener']('close',()=>_0x330418()),_0x6828b3&&_0x334453['addEventListener']('versionchange',_0xd4009f=>_0x6828b3(_0xd4009f['oldVersion'],_0xd4009f['newVersion'],_0xd4009f));})['catch'](()=>{}),_0x222206;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x3e349e,_0x2a7611){if(!(_0x3e349e instanceof IDBDatabase&&!(_0x2a7611 in _0x3e349e)&&typeof _0x2a7611=='string'))return;if(si['get'](_0x2a7611))return si['get'](_0x2a7611);const _0x5d0b62=_0x2a7611['replace'](/FromIndex$/,''),_0x51a3f0=_0x2a7611!==_0x5d0b62,_0x2322fe=zc['includes'](_0x5d0b62);if(!(_0x5d0b62 in(_0x51a3f0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2322fe||qc['includes'](_0x5d0b62)))return;const _0x3c5e86=async function(_0x42c2a4,..._0x46de2c){const _0x5f479c=this['transaction'](_0x42c2a4,_0x2322fe?'readwrite':'readonly');let _0x5b5a2d=_0x5f479c['store'];return _0x51a3f0&&(_0x5b5a2d=_0x5b5a2d['index'](_0x46de2c['shift']())),(await Promise['all']([_0x5b5a2d[_0x5d0b62](..._0x46de2c),_0x2322fe&&_0x5f479c['done']]))[0x0];};return si['set'](_0x2a7611,_0x3c5e86),_0x3c5e86;}Vc(_0x39474a=>({..._0x39474a,'get':(_0x13b5e7,_0x102b26,_0x87fd1c)=>Ms(_0x13b5e7,_0x102b26)||_0x39474a['get'](_0x13b5e7,_0x102b26,_0x87fd1c),'has':(_0x50b5f4,_0x6d32df)=>!!Ms(_0x50b5f4,_0x6d32df)||_0x39474a['has'](_0x50b5f4,_0x6d32df)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1d5d56){this['container']=_0x1d5d56;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x302ce7=>{if(Kc(_0x302ce7)){const _0x1b8251=_0x302ce7['getImmediate']();return _0x1b8251['library']+'/'+_0x1b8251['version'];}else return null;})['filter'](_0x2b6060=>_0x2b6060)['join']('\x20');}}function Kc(_0xa8be8d){const _0x2a6641=_0xa8be8d['getComponent']();return(_0x2a6641==null?void 0x0:_0x2a6641['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x28dce4,_0x50676a){try{_0x28dce4['container']['addComponent'](_0x50676a);}catch(_0x5a13d0){oe['debug']('Component\x20'+_0x50676a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x28dce4['name'],_0x5a13d0);}}function st(_0x536898){const _0x183460=_0x536898['name'];if(Ei['has'](_0x183460))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x183460+'.'),!0x1;Ei['set'](_0x183460,_0x536898);for(const _0x718da9 of Fe['values']())xs(_0x718da9,_0x536898);for(const _0x42ea9e of vi['values']())xs(_0x42ea9e,_0x536898);return!0x0;}function Hi(_0x470ca9,_0x579c2a){const _0x1ff34a=_0x470ca9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1ff34a&&_0x1ff34a['triggerHeartbeat'](),_0x470ca9['container']['getProvider'](_0x579c2a);}function $(_0x4bc283){return _0x4bc283==null?!0x1:_0x4bc283['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4ffa29,_0x39878a,_0x37db22){this['_isDeleted']=!0x1,this['_options']={..._0x4ffa29},this['_config']={..._0x39878a},this['_name']=_0x39878a['name'],this['_automaticDataCollectionEnabled']=_0x39878a['automaticDataCollectionEnabled'],this['_container']=_0x37db22,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2571fb){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2571fb;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3adf94){this['_isDeleted']=_0x3adf94;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x217469,_0x273911={}){let _0x569413=_0x217469;typeof _0x273911!='object'&&(_0x273911={'name':_0x273911});const _0x1f83ed={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x273911},_0x4a3ba9=_0x1f83ed['name'];if(typeof _0x4a3ba9!='string'||!_0x4a3ba9)throw me['create']('bad-app-name',{'appName':String(_0x4a3ba9)});if(_0x569413||(_0x569413=zr()),!_0x569413)throw me['create']('no-options');const _0x1df2f0=Fe['get'](_0x4a3ba9);if(_0x1df2f0){if(Le(_0x569413,_0x1df2f0['options'])&&Le(_0x1f83ed,_0x1df2f0['config']))return _0x1df2f0;throw me['create']('duplicate-app',{'appName':_0x4a3ba9});}const _0x40e6fd=new Pc(_0x4a3ba9);for(const _0x138612 of Ei['values']())_0x40e6fd['addComponent'](_0x138612);const _0x38b908=new Tl(_0x569413,_0x1f83ed,_0x40e6fd);return Fe['set'](_0x4a3ba9,_0x38b908),_0x38b908;}function Zr(_0x3903fe=yi){const _0x213a4d=Fe['get'](_0x3903fe);if(!_0x213a4d&&_0x3903fe===yi&&zr())return Sl();if(!_0x213a4d)throw me['create']('no-app',{'appName':_0x3903fe});return _0x213a4d;}function p_(){return Array['from'](Fe['values']());}async function __(_0x45e859){let _0x1d2452=!0x1;const _0x49f2fb=_0x45e859['name'];Fe['has'](_0x49f2fb)?(_0x1d2452=!0x0,Fe['delete'](_0x49f2fb)):vi['has'](_0x49f2fb)&&_0x45e859['decRefCount']()<=0x0&&(vi['delete'](_0x49f2fb),_0x1d2452=!0x0),_0x1d2452&&(await Promise['all'](_0x45e859['container']['getProviders']()['map'](_0x3a3f69=>_0x3a3f69['delete']())),_0x45e859['isDeleted']=!0x0);}function ye(_0x5ec8b7,_0x1adbc8,_0x361a9a){let _0x37d9f9=wl[_0x5ec8b7]??_0x5ec8b7;_0x361a9a&&(_0x37d9f9+='-'+_0x361a9a);const _0xac657c=_0x37d9f9['match'](/\s|\//),_0x2ca024=_0x1adbc8['match'](/\s|\//);if(_0xac657c||_0x2ca024){const _0x51fee4=['Unable\x20to\x20register\x20library\x20\x22'+_0x37d9f9+'\x22\x20with\x20version\x20\x22'+_0x1adbc8+'\x22:'];_0xac657c&&_0x51fee4['push']('library\x20name\x20\x22'+_0x37d9f9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xac657c&&_0x2ca024&&_0x51fee4['push']('and'),_0x2ca024&&_0x51fee4['push']('version\x20name\x20\x22'+_0x1adbc8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x51fee4['join']('\x20'));return;}st(new xe(_0x37d9f9+'-version',()=>({'library':_0x37d9f9,'version':_0x1adbc8}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x138362,_0x42bdc6)=>{switch(_0x42bdc6){case 0x0:try{_0x138362['createObjectStore'](Pt);}catch(_0x24d949){console['warn'](_0x24d949);}}}})['catch'](_0x1ea0ce=>{throw me['create']('idb-open',{'originalErrorMessage':_0x1ea0ce['message']});})),ri;}async function Al(_0x36fbb2){try{const _0x104265=(await eo())['transaction'](Pt),_0x12e449=await _0x104265['objectStore'](Pt)['get'](to(_0x36fbb2));return await _0x104265['done'],_0x12e449;}catch(_0x4a1105){if(_0x4a1105 instanceof Re)oe['warn'](_0x4a1105['message']);else{const _0x1f3aea=me['create']('idb-get',{'originalErrorMessage':_0x4a1105==null?void 0x0:_0x4a1105['message']});oe['warn'](_0x1f3aea['message']);}}}async function Fs(_0x5007f5,_0x43b340){try{const _0x1b4b4e=(await eo())['transaction'](Pt,'readwrite');await _0x1b4b4e['objectStore'](Pt)['put'](_0x43b340,to(_0x5007f5)),await _0x1b4b4e['done'];}catch(_0x273b72){if(_0x273b72 instanceof Re)oe['warn'](_0x273b72['message']);else{const _0x3e0fa5=me['create']('idb-set',{'originalErrorMessage':_0x273b72==null?void 0x0:_0x273b72['message']});oe['warn'](_0x3e0fa5['message']);}}}function to(_0x3af796){return _0x3af796['name']+'!'+_0x3af796['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x2019f3){this['container']=_0x2019f3,this['_heartbeatsCache']=null;const _0x44ee7f=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x44ee7f),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4bab48=>(this['_heartbeatsCache']=_0x4bab48,_0x4bab48));}async['triggerHeartbeat'](){var _0x2cb8ea,_0x5d70c2;try{const _0x1a9fcc=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x136516=Us();if(((_0x2cb8ea=this['_heartbeatsCache'])==null?void 0x0:_0x2cb8ea['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5d70c2=this['_heartbeatsCache'])==null?void 0x0:_0x5d70c2['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x136516||this['_heartbeatsCache']['heartbeats']['some'](_0x147757=>_0x147757['date']===_0x136516))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x136516,'agent':_0x1a9fcc}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x221603=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x221603,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x48b766){oe['warn'](_0x48b766);}}async['getHeartbeatsHeader'](){var _0x2a1f9c;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x2a1f9c=this['_heartbeatsCache'])==null?void 0x0:_0x2a1f9c['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2af360=Us(),{heartbeatsToSend:_0x3e17e5,unsentEntries:_0x21b73b}=Ol(this['_heartbeatsCache']['heartbeats']),_0xb355ef=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3e17e5}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2af360,_0x21b73b['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x21b73b,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xb355ef;}catch(_0x2c79a4){return oe['warn'](_0x2c79a4),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x23bff6,_0x576538=kl){const _0xa27a9=[];let _0x5b1fac=_0x23bff6['slice']();for(const _0xca8094 of _0x23bff6){const _0xba8c3c=_0xa27a9['find'](_0x293ffe=>_0x293ffe['agent']===_0xca8094['agent']);if(_0xba8c3c){if(_0xba8c3c['dates']['push'](_0xca8094['date']),Ws(_0xa27a9)>_0x576538){_0xba8c3c['dates']['pop']();break;}}else{if(_0xa27a9['push']({'agent':_0xca8094['agent'],'dates':[_0xca8094['date']]}),Ws(_0xa27a9)>_0x576538){_0xa27a9['pop']();break;}}_0x5b1fac=_0x5b1fac['slice'](0x1);}return{'heartbeatsToSend':_0xa27a9,'unsentEntries':_0x5b1fac};}class Dl{constructor(_0x256356){this['app']=_0x256356,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2e40aa=await Al(this['app']);return _0x2e40aa!=null&&_0x2e40aa['heartbeats']?_0x2e40aa:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x479ea8){if(await this['_canUseIndexedDBPromise']){const _0x24597f=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x479ea8['lastSentHeartbeatDate']??_0x24597f['lastSentHeartbeatDate'],'heartbeats':_0x479ea8['heartbeats']});}else return;}async['add'](_0x5cf0ae){if(await this['_canUseIndexedDBPromise']){const _0x44adae=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5cf0ae['lastSentHeartbeatDate']??_0x44adae['lastSentHeartbeatDate'],'heartbeats':[..._0x44adae['heartbeats'],..._0x5cf0ae['heartbeats']]});}else return;}}function Ws(_0x340fa7){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x340fa7}))['length'];}function Ml(_0x5e4665){if(_0x5e4665['length']===0x0)return-0x1;let _0x48e06b=0x0,_0x552a44=_0x5e4665[0x0]['date'];for(let _0x2182be=0x1;_0x2182be<_0x5e4665['length'];_0x2182be++)_0x5e4665[_0x2182be]['date']<_0x552a44&&(_0x552a44=_0x5e4665[_0x2182be]['date'],_0x48e06b=_0x2182be);return _0x48e06b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1c9d0d){st(new xe('platform-logger',_0xc19fed=>new jc(_0xc19fed),'PRIVATE')),st(new xe('heartbeat',_0x5a6620=>new Pl(_0x5a6620),'PRIVATE')),ye(mi,Ls,_0x1c9d0d),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x12f22e){no=_0x12f22e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x326aab){this['domStorage_']=_0x326aab,this['prefix_']='firebase:';}['set'](_0x5bc833,_0x29db88){_0x29db88==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5bc833)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5bc833),O(_0x29db88));}['get'](_0x9bd357){const _0x57951f=this['domStorage_']['getItem'](this['prefixedName_'](_0x9bd357));return _0x57951f==null?null:Nt(_0x57951f);}['remove'](_0x1511e4){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1511e4));}['prefixedName_'](_0x511015){return this['prefix_']+_0x511015;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2b4ffd,_0x4c0b18){_0x4c0b18==null?delete this['cache_'][_0x2b4ffd]:this['cache_'][_0x2b4ffd]=_0x4c0b18;}['get'](_0x141fa2){return Q(this['cache_'],_0x141fa2)?this['cache_'][_0x141fa2]:null;}['remove'](_0x28d1bc){delete this['cache_'][_0x28d1bc];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x33d974){try{if(typeof window<'u'&&typeof window[_0x33d974]<'u'){const _0x4eb70a=window[_0x33d974];return _0x4eb70a['setItem']('firebase:sentinel','cache'),_0x4eb70a['removeItem']('firebase:sentinel'),new Wl(_0x4eb70a);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x5d08a3=0x1;return function(){return _0x5d08a3++;};}()),ro=function(_0x482470){const _0x27e5f6=Rc(_0x482470),_0x246e32=new Cc();_0x246e32['update'](_0x27e5f6);const _0x11080e=_0x246e32['digest']();return Fi['encodeByteArray'](_0x11080e);},qt=function(..._0x4a72ba){let _0xd4dc78='';for(let _0x10fbba=0x0;_0x10fbba<_0x4a72ba['length'];_0x10fbba++){const _0x36aba7=_0x4a72ba[_0x10fbba];Array['isArray'](_0x36aba7)||_0x36aba7&&typeof _0x36aba7=='object'&&typeof _0x36aba7['length']=='number'?_0xd4dc78+=qt['apply'](null,_0x36aba7):typeof _0x36aba7=='object'?_0xd4dc78+=O(_0x36aba7):_0xd4dc78+=_0x36aba7,_0xd4dc78+='\x20';}return _0xd4dc78;};let Tt=null,$s=!0x0;const Hl=function(_0x254e7c,_0x38be0b){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0xfbd980){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0x461d79=qt['apply'](null,_0xfbd980);Tt(_0x461d79);}},zt=function(_0x45c611){return function(..._0x3d94be){L(_0x45c611,..._0x3d94be);};},Ii=function(..._0x783b95){const _0x5ed69c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x783b95);Ze['error'](_0x5ed69c);},ae=function(..._0x2df9e8){const _0x1c3b1d='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x2df9e8);throw Ze['error'](_0x1c3b1d),new Error(_0x1c3b1d);},U=function(..._0x205a2e){const _0x490959='FIREBASE\x20WARNING:\x20'+qt(..._0x205a2e);Ze['warn'](_0x490959);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x23622d){return typeof _0x23622d=='number'&&(_0x23622d!==_0x23622d||_0x23622d===Number['POSITIVE_INFINITY']||_0x23622d===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3e45eb){if(document['readyState']==='complete')_0x3e45eb();else{let _0x3d8173=!0x1;const _0x23f555=function(){if(!document['body']){setTimeout(_0x23f555,Math['floor'](0xa));return;}_0x3d8173||(_0x3d8173=!0x0,_0x3e45eb());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x23f555,!0x1),window['addEventListener']('load',_0x23f555,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x23f555();}),window['attachEvent']('onload',_0x23f555));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x5108d3,_0x24b701){if(_0x5108d3===_0x24b701)return 0x0;if(_0x5108d3===Ue||_0x24b701===we)return-0x1;if(_0x24b701===Ue||_0x5108d3===we)return 0x1;{const _0x5cd210=Gs(_0x5108d3),_0x58dfe9=Gs(_0x24b701);return _0x5cd210!==null?_0x58dfe9!==null?_0x5cd210-_0x58dfe9===0x0?_0x5108d3['length']-_0x24b701['length']:_0x5cd210-_0x58dfe9:-0x1:_0x58dfe9!==null?0x1:_0x5108d3<_0x24b701?-0x1:0x1;}},ql=function(_0x2f3307,_0x204b79){return _0x2f3307===_0x204b79?0x0:_0x2f3307<_0x204b79?-0x1:0x1;},yt=function(_0x137f58,_0x422e26){if(_0x422e26&&_0x137f58 in _0x422e26)return _0x422e26[_0x137f58];throw new Error('Missing\x20required\x20key\x20('+_0x137f58+')\x20in\x20object:\x20'+O(_0x422e26));},$i=function(_0xa3cd3c){if(typeof _0xa3cd3c!='object'||_0xa3cd3c===null)return O(_0xa3cd3c);const _0x20210b=[];for(const _0x428cf0 in _0xa3cd3c)_0x20210b['push'](_0x428cf0);_0x20210b['sort']();let _0x1b47bd='{';for(let _0x5b39be=0x0;_0x5b39be<_0x20210b['length'];_0x5b39be++)_0x5b39be!==0x0&&(_0x1b47bd+=','),_0x1b47bd+=O(_0x20210b[_0x5b39be]),_0x1b47bd+=':',_0x1b47bd+=$i(_0xa3cd3c[_0x20210b[_0x5b39be]]);return _0x1b47bd+='}',_0x1b47bd;},oo=function(_0x25b09a,_0x1387e9){const _0x10746d=_0x25b09a['length'];if(_0x10746d<=_0x1387e9)return[_0x25b09a];const _0x322149=[];for(let _0x19edb1=0x0;_0x19edb1<_0x10746d;_0x19edb1+=_0x1387e9)_0x19edb1+_0x1387e9>_0x10746d?_0x322149['push'](_0x25b09a['substring'](_0x19edb1,_0x10746d)):_0x322149['push'](_0x25b09a['substring'](_0x19edb1,_0x19edb1+_0x1387e9));return _0x322149;};function x(_0x55d455,_0x231e78){for(const _0xa98c30 in _0x55d455)_0x55d455['hasOwnProperty'](_0xa98c30)&&_0x231e78(_0xa98c30,_0x55d455[_0xa98c30]);}const ao=function(_0x31c88a){f(!xn(_0x31c88a),'Invalid\x20JSON\x20number');const _0x4092c5=0xb,_0xd52373=0x34,_0x144f78=(0x1<<_0x4092c5-0x1)-0x1;let _0x432ee6,_0x2fb13d,_0x42e9b6,_0x23f05b,_0x1d227b;_0x31c88a===0x0?(_0x2fb13d=0x0,_0x42e9b6=0x0,_0x432ee6=0x1/_0x31c88a===-0x1/0x0?0x1:0x0):(_0x432ee6=_0x31c88a<0x0,_0x31c88a=Math['abs'](_0x31c88a),_0x31c88a>=Math['pow'](0x2,0x1-_0x144f78)?(_0x23f05b=Math['min'](Math['floor'](Math['log'](_0x31c88a)/Math['LN2']),_0x144f78),_0x2fb13d=_0x23f05b+_0x144f78,_0x42e9b6=Math['round'](_0x31c88a*Math['pow'](0x2,_0xd52373-_0x23f05b)-Math['pow'](0x2,_0xd52373))):(_0x2fb13d=0x0,_0x42e9b6=Math['round'](_0x31c88a/Math['pow'](0x2,0x1-_0x144f78-_0xd52373))));const _0x16d61e=[];for(_0x1d227b=_0xd52373;_0x1d227b;_0x1d227b-=0x1)_0x16d61e['push'](_0x42e9b6%0x2?0x1:0x0),_0x42e9b6=Math['floor'](_0x42e9b6/0x2);for(_0x1d227b=_0x4092c5;_0x1d227b;_0x1d227b-=0x1)_0x16d61e['push'](_0x2fb13d%0x2?0x1:0x0),_0x2fb13d=Math['floor'](_0x2fb13d/0x2);_0x16d61e['push'](_0x432ee6?0x1:0x0),_0x16d61e['reverse']();const _0x39c6e2=_0x16d61e['join']('');let _0x335048='';for(_0x1d227b=0x0;_0x1d227b<0x40;_0x1d227b+=0x8){let _0x43b6f4=parseInt(_0x39c6e2['substr'](_0x1d227b,0x8),0x2)['toString'](0x10);_0x43b6f4['length']===0x1&&(_0x43b6f4='0'+_0x43b6f4),_0x335048=_0x335048+_0x43b6f4;}return _0x335048['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2920e9,_0x496508){let _0x39ece1='Unknown\x20Error';_0x2920e9==='too_big'?_0x39ece1='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2920e9==='permission_denied'?_0x39ece1='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2920e9==='unavailable'&&(_0x39ece1='The\x20service\x20is\x20unavailable');const _0x308684=new Error(_0x2920e9+'\x20at\x20'+_0x496508['_path']['toString']()+':\x20'+_0x39ece1);return _0x308684['code']=_0x2920e9['toUpperCase'](),_0x308684;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x1857bc){if(Yl['test'](_0x1857bc)){const _0x5705da=Number(_0x1857bc);if(_0x5705da>=Ql&&_0x5705da<=Jl)return _0x5705da;}return null;},ft=function(_0x73c473){try{_0x73c473();}catch(_0x8b6abb){setTimeout(()=>{const _0x229fd8=_0x8b6abb['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x229fd8),_0x8b6abb;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x50dd6e,_0x730215){const _0x30f0a9=setTimeout(_0x50dd6e,_0x730215);return typeof _0x30f0a9=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x30f0a9):typeof _0x30f0a9=='object'&&_0x30f0a9['unref']&&_0x30f0a9['unref'](),_0x30f0a9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x7d6673,_0x329f27){this['appCheckProvider']=_0x329f27,this['appName']=_0x7d6673['name'],$(_0x7d6673)&&_0x7d6673['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x7d6673['settings']['appCheckToken']),this['appCheck']=_0x329f27==null?void 0x0:_0x329f27['getImmediate']({'optional':!0x0}),this['appCheck']||_0x329f27==null||_0x329f27['get']()['then'](_0x405fa5=>this['appCheck']=_0x405fa5);}['getToken'](_0x442ef8){if(this['serverAppAppCheckToken']){if(_0x442ef8)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x442ef8):new Promise((_0x5382db,_0x21d071)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x442ef8)['then'](_0x5382db,_0x21d071):_0x5382db(null);},0x0);});}['addTokenChangeListener'](_0x45f451){var _0x2f2fa2;(_0x2f2fa2=this['appCheckProvider'])==null||_0x2f2fa2['get']()['then'](_0x451376=>_0x451376['addTokenListener'](_0x45f451));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x4ad721,_0x709c1b,_0x184707){this['appName_']=_0x4ad721,this['firebaseOptions_']=_0x709c1b,this['authProvider_']=_0x184707,this['auth_']=null,this['auth_']=_0x184707['getImmediate']({'optional':!0x0}),this['auth_']||_0x184707['onInit'](_0x2d0f60=>this['auth_']=_0x2d0f60);}['getToken'](_0x28208b){return this['auth_']?this['auth_']['getToken'](_0x28208b)['catch'](_0x12127a=>_0x12127a&&_0x12127a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x12127a)):new Promise((_0x1969d6,_0x4bca4a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x28208b)['then'](_0x1969d6,_0x4bca4a):_0x1969d6(null);},0x0);});}['addTokenChangeListener'](_0x5bfb72){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5bfb72):this['authProvider_']['get']()['then'](_0x38698f=>_0x38698f['addAuthTokenListener'](_0x5bfb72));}['removeTokenChangeListener'](_0x14b755){this['authProvider_']['get']()['then'](_0x15fc5a=>_0x15fc5a['removeAuthTokenListener'](_0x14b755));}['notifyForInvalidToken'](){let _0x4866ad='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4866ad+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4866ad+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4866ad+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4866ad);}}class an{constructor(_0x1812b2){this['accessToken']=_0x1812b2;}['getToken'](_0x48be4c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x20ec82){_0x20ec82(this['accessToken']);}['removeTokenChangeListener'](_0x3735c6){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x577eba,_0x510505,_0x7b960,_0x3d0644,_0x585f1e=!0x1,_0x36a9d7='',_0x527c06=!0x1,_0x10f353=!0x1,_0x169a75=null){this['secure']=_0x510505,this['namespace']=_0x7b960,this['webSocketOnly']=_0x3d0644,this['nodeAdmin']=_0x585f1e,this['persistenceKey']=_0x36a9d7,this['includeNamespaceInQueryParams']=_0x527c06,this['isUsingEmulator']=_0x10f353,this['emulatorOptions']=_0x169a75,this['_host']=_0x577eba['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x577eba)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x120797){_0x120797!==this['internalHost']&&(this['internalHost']=_0x120797,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4e712b=this['toURLString']();return this['persistenceKey']&&(_0x4e712b+='<'+this['persistenceKey']+'>'),_0x4e712b;}['toURLString'](){const _0x2cf19f=this['secure']?'https://':'http://',_0x174cc3=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2cf19f+this['host']+'/'+_0x174cc3;}}function th(_0x22f333){return _0x22f333['host']!==_0x22f333['internalHost']||_0x22f333['isCustomHost']()||_0x22f333['includeNamespaceInQueryParams'];}function vo(_0x47a556,_0x1fbf6,_0x1e7955){f(typeof _0x1fbf6=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1e7955=='object','typeof\x20params\x20must\x20==\x20object');let _0x4c3a56;if(_0x1fbf6===go)_0x4c3a56=(_0x47a556['secure']?'wss://':'ws://')+_0x47a556['internalHost']+'/.ws?';else{if(_0x1fbf6===mo)_0x4c3a56=(_0x47a556['secure']?'https://':'http://')+_0x47a556['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1fbf6);}th(_0x47a556)&&(_0x1e7955['ns']=_0x47a556['namespace']);const _0x1f50a7=[];return x(_0x1e7955,(_0x32e75a,_0x5b7e51)=>{_0x1f50a7['push'](_0x32e75a+'='+_0x5b7e51);}),_0x4c3a56+_0x1f50a7['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4a5a15,_0x3a5646=0x1){Q(this['counters_'],_0x4a5a15)||(this['counters_'][_0x4a5a15]=0x0),this['counters_'][_0x4a5a15]+=_0x3a5646;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x228399){const _0x12d5a9=_0x228399['toString']();return oi[_0x12d5a9]||(oi[_0x12d5a9]=new nh()),oi[_0x12d5a9];}function ih(_0x2ae5e5,_0x4b2b52){const _0x41e59d=_0x2ae5e5['toString']();return ai[_0x41e59d]||(ai[_0x41e59d]=_0x4b2b52()),ai[_0x41e59d];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x57c9f3){this['onMessage_']=_0x57c9f3,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x193ed2,_0x502edd){this['closeAfterResponse']=_0x193ed2,this['onClose']=_0x502edd,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2af240,_0x5068b3){for(this['pendingResponses'][_0x2af240]=_0x5068b3;this['pendingResponses'][this['currentResponseNum']];){const _0x5da734=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1194d5=0x0;_0x1194d5<_0x5da734['length'];++_0x1194d5)_0x5da734[_0x1194d5]&&ft(()=>{this['onMessage_'](_0x5da734[_0x1194d5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3cfb74,_0x3ad9c1,_0x130899,_0x5360e8,_0x4d801b,_0x386c18,_0x5157b8){this['connId']=_0x3cfb74,this['repoInfo']=_0x3ad9c1,this['applicationId']=_0x130899,this['appCheckToken']=_0x5360e8,this['authToken']=_0x4d801b,this['transportSessionId']=_0x386c18,this['lastSessionId']=_0x5157b8,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x3cfb74),this['stats_']=qi(_0x3ad9c1),this['urlFn']=_0x513669=>(this['appCheckToken']&&(_0x513669[wi]=this['appCheckToken']),vo(_0x3ad9c1,mo,_0x513669));}['open'](_0x207052,_0x6b7e4d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x6b7e4d,this['myPacketOrderer']=new sh(_0x207052),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x311a27)=>{const [_0x5c173f,_0xff5cf7,_0x2287ef,_0xaca745,_0x5074c3]=_0x311a27;if(this['incrementIncomingBytes_'](_0x311a27),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5c173f===qs)this['id']=_0xff5cf7,this['password']=_0x2287ef;else{if(_0x5c173f===rh)_0xff5cf7?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xff5cf7,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5c173f);}}},(..._0x5c5696)=>{const [_0x385b6f,_0x5bed3f]=_0x5c5696;this['incrementIncomingBytes_'](_0x5c5696),this['myPacketOrderer']['handleResponse'](_0x385b6f,_0x5bed3f);},()=>{this['onClosed_']();},this['urlFn']);const _0x5e5130={};_0x5e5130[qs]='t',_0x5e5130[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5e5130[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5e5130[co]=Gi,this['transportSessionId']&&(_0x5e5130[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5e5130[po]=this['lastSessionId']),this['applicationId']&&(_0x5e5130[_o]=this['applicationId']),this['appCheckToken']&&(_0x5e5130[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5e5130[ho]=uo);const _0x55f6e2=this['urlFn'](_0x5e5130);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x55f6e2),this['scriptTagHolder']['addTag'](_0x55f6e2,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1fcbb4){const _0x260c1e=O(_0x1fcbb4);this['bytesSent']+=_0x260c1e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x260c1e['length']);const _0x439347=$r(_0x260c1e),_0x5c36a9=oo(_0x439347,fh);for(let _0x83f2ca=0x0;_0x83f2ca<_0x5c36a9['length'];_0x83f2ca++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5c36a9['length'],_0x5c36a9[_0x83f2ca]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x456d0b,_0x566697){this['myDisconnFrame']=document['createElement']('iframe');const _0x42722a={};_0x42722a[dh]='t',_0x42722a[Eo]=_0x456d0b,_0x42722a[Io]=_0x566697,this['myDisconnFrame']['src']=this['urlFn'](_0x42722a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x24488b){const _0x1f15f9=O(_0x24488b)['length'];this['bytesReceived']+=_0x1f15f9,this['stats_']['incrementCounter']('bytes_received',_0x1f15f9);}}class zi{constructor(_0x4632b9,_0x14fb2b,_0x2b5229,_0x2b7b02){this['onDisconnect']=_0x2b5229,this['urlFn']=_0x2b7b02,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x4632b9,window[ah+this['uniqueCallbackIdentifier']]=_0x14fb2b,this['myIFrame']=zi['createIFrame_']();let _0x30f702='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x30f702='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x393c26='<html><body>'+_0x30f702+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x393c26),this['myIFrame']['doc']['close']();}catch(_0x67879a){L('frame\x20writing\x20exception'),_0x67879a['stack']&&L(_0x67879a['stack']),L(_0x67879a);}}}static['createIFrame_'](){const _0x57d3d5=document['createElement']('iframe');if(_0x57d3d5['style']['display']='none',document['body']){document['body']['appendChild'](_0x57d3d5);try{_0x57d3d5['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3fa3cd=document['domain'];_0x57d3d5['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3fa3cd+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x57d3d5['contentDocument']?_0x57d3d5['doc']=_0x57d3d5['contentDocument']:_0x57d3d5['contentWindow']?_0x57d3d5['doc']=_0x57d3d5['contentWindow']['document']:_0x57d3d5['document']&&(_0x57d3d5['doc']=_0x57d3d5['document']),_0x57d3d5;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4ae60f=this['onDisconnect'];_0x4ae60f&&(this['onDisconnect']=null,_0x4ae60f());}['startLongPoll'](_0xe26cc5,_0x5ab5cc){for(this['myID']=_0xe26cc5,this['myPW']=_0x5ab5cc,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4b3f07={};_0x4b3f07[Eo]=this['myID'],_0x4b3f07[Io]=this['myPW'],_0x4b3f07[wo]=this['currentSerial'];let _0x344899=this['urlFn'](_0x4b3f07),_0x23aac8='',_0x4bf5c8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x23aac8['length']<=Co;){const _0x47c77f=this['pendingSegs']['shift']();_0x23aac8=_0x23aac8+'&'+lh+_0x4bf5c8+'='+_0x47c77f['seg']+'&'+hh+_0x4bf5c8+'='+_0x47c77f['ts']+'&'+uh+_0x4bf5c8+'='+_0x47c77f['d'],_0x4bf5c8++;}return _0x344899=_0x344899+_0x23aac8,this['addLongPollTag_'](_0x344899,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x14c985,_0x155485,_0x1c77ac){this['pendingSegs']['push']({'seg':_0x14c985,'ts':_0x155485,'d':_0x1c77ac}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5e71e1,_0x11bb4d){this['outstandingRequests']['add'](_0x11bb4d);const _0x5b581e=()=>{this['outstandingRequests']['delete'](_0x11bb4d),this['newRequest_']();},_0x48c8b8=setTimeout(_0x5b581e,Math['floor'](ph)),_0x5af400=()=>{clearTimeout(_0x48c8b8),_0x5b581e();};this['addTag'](_0x5e71e1,_0x5af400);}['addTag'](_0x255844,_0x5e7555){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1a1cee=this['myIFrame']['doc']['createElement']('script');_0x1a1cee['type']='text/javascript',_0x1a1cee['async']=!0x0,_0x1a1cee['src']=_0x255844,_0x1a1cee['onload']=_0x1a1cee['onreadystatechange']=function(){const _0xebe1d0=_0x1a1cee['readyState'];(!_0xebe1d0||_0xebe1d0==='loaded'||_0xebe1d0==='complete')&&(_0x1a1cee['onload']=_0x1a1cee['onreadystatechange']=null,_0x1a1cee['parentNode']&&_0x1a1cee['parentNode']['removeChild'](_0x1a1cee),_0x5e7555());},_0x1a1cee['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x255844),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1a1cee);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x31fffd,_0x514c48,_0x4ba163,_0x28c940,_0x53bf3b,_0x176ae2,_0x5e61e0){this['connId']=_0x31fffd,this['applicationId']=_0x4ba163,this['appCheckToken']=_0x28c940,this['authToken']=_0x53bf3b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0x514c48),this['connURL']=q['connectionURL_'](_0x514c48,_0x176ae2,_0x5e61e0,_0x28c940,_0x4ba163),this['nodeAdmin']=_0x514c48['nodeAdmin'];}static['connectionURL_'](_0x18172b,_0x4ac405,_0x1cbbd9,_0x1a7bbc,_0xd550f1){const _0x2f827d={};return _0x2f827d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2f827d[ho]=uo),_0x4ac405&&(_0x2f827d[lo]=_0x4ac405),_0x1cbbd9&&(_0x2f827d[po]=_0x1cbbd9),_0x1a7bbc&&(_0x2f827d[wi]=_0x1a7bbc),_0xd550f1&&(_0x2f827d[_o]=_0xd550f1),vo(_0x18172b,go,_0x2f827d);}['open'](_0x20ae16,_0x2115b5){this['onDisconnect']=_0x2115b5,this['onMessage']=_0x20ae16,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x200b50;_c(),this['mySock']=new gn(this['connURL'],[],_0x200b50);}catch(_0x79ae69){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x25ea47=_0x79ae69['message']||_0x79ae69['data'];_0x25ea47&&this['log_'](_0x25ea47),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x15b45c=>{this['handleIncomingFrame'](_0x15b45c);},this['mySock']['onerror']=_0x19d5cb=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4d4fb4=_0x19d5cb['message']||_0x19d5cb['data'];_0x4d4fb4&&this['log_'](_0x4d4fb4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xaf3710=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x529f62=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xd1f9eb=navigator['userAgent']['match'](_0x529f62);_0xd1f9eb&&_0xd1f9eb['length']>0x1&&parseFloat(_0xd1f9eb[0x1])<4.4&&(_0xaf3710=!0x0);}return!_0xaf3710&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4a22ad){if(this['frames']['push'](_0x4a22ad),this['frames']['length']===this['totalFrames']){const _0x2ddca3=this['frames']['join']('');this['frames']=null;const _0x17997e=Nt(_0x2ddca3);this['onMessage'](_0x17997e);}}['handleNewFrameCount_'](_0x455832){this['totalFrames']=_0x455832,this['frames']=[];}['extractFrameCount_'](_0x46b106){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x46b106['length']<=0x6){const _0x16772d=Number(_0x46b106);if(!isNaN(_0x16772d))return this['handleNewFrameCount_'](_0x16772d),null;}return this['handleNewFrameCount_'](0x1),_0x46b106;}['handleIncomingFrame'](_0x27637d){if(this['mySock']===null)return;const _0x435d56=_0x27637d['data'];if(this['bytesReceived']+=_0x435d56['length'],this['stats_']['incrementCounter']('bytes_received',_0x435d56['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x435d56);else{const _0x40272b=this['extractFrameCount_'](_0x435d56);_0x40272b!==null&&this['appendFrame_'](_0x40272b);}}['send'](_0x5e0caa){this['resetKeepAlive']();const _0xd3589e=O(_0x5e0caa);this['bytesSent']+=_0xd3589e['length'],this['stats_']['incrementCounter']('bytes_sent',_0xd3589e['length']);const _0x2ddc1e=oo(_0xd3589e,gh);_0x2ddc1e['length']>0x1&&this['sendString_'](String(_0x2ddc1e['length']));for(let _0x3f3ff0=0x0;_0x3f3ff0<_0x2ddc1e['length'];_0x3f3ff0++)this['sendString_'](_0x2ddc1e[_0x3f3ff0]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x14152c){try{this['mySock']['send'](_0x14152c);}catch(_0x4100d1){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4100d1['message']||_0x4100d1['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x52d5e4){this['initTransports_'](_0x52d5e4);}['initTransports_'](_0x13037d){const _0x54d64a=q&&q['isAvailable']();let _0x19393a=_0x54d64a&&!q['previouslyFailed']();if(_0x13037d['webSocketOnly']&&(_0x54d64a||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x19393a=!0x0),_0x19393a)this['transports_']=[q];else{const _0x34a7b4=this['transports_']=[];for(const _0x2fe14e of Ot['ALL_TRANSPORTS'])_0x2fe14e&&_0x2fe14e['isAvailable']()&&_0x34a7b4['push'](_0x2fe14e);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x1d0549,_0x5cc2df,_0x16f176,_0x185814,_0x49b5fa,_0x358f99,_0x455b7d,_0x30810b,_0x352e8c,_0x5641ce){this['id']=_0x1d0549,this['repoInfo_']=_0x5cc2df,this['applicationId_']=_0x16f176,this['appCheckToken_']=_0x185814,this['authToken_']=_0x49b5fa,this['onMessage_']=_0x358f99,this['onReady_']=_0x455b7d,this['onDisconnect_']=_0x30810b,this['onKill_']=_0x352e8c,this['lastSessionId']=_0x5641ce,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x5cc2df),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2773da=this['transportManager_']['initialTransport']();this['conn_']=new _0x2773da(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2773da['responsesRequiredToBeHealthy']||0x0;const _0x2ef576=this['connReceiver_'](this['conn_']),_0x30493e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2ef576,_0x30493e);},Math['floor'](0x0));const _0x55e178=_0x2773da['healthyTimeout']||0x0;_0x55e178>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x55e178)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1db0e3){return _0x2efac0=>{_0x1db0e3===this['conn_']?this['onConnectionLost_'](_0x2efac0):_0x1db0e3===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4895fe){return _0x3a78cf=>{this['state_']!==0x2&&(_0x4895fe===this['rx_']?this['onPrimaryMessageReceived_'](_0x3a78cf):_0x4895fe===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3a78cf):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x498e2d){const _0x364ce8={'t':'d','d':_0x498e2d};this['sendData_'](_0x364ce8);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5dcaf6){if(ci in _0x5dcaf6){const _0x1e5821=_0x5dcaf6[ci];_0x1e5821===Ys?this['upgradeIfSecondaryHealthy_']():_0x1e5821===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1e5821===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x544440){const _0x48c9e7=yt('t',_0x544440),_0x1f339d=yt('d',_0x544440);if(_0x48c9e7==='c')this['onSecondaryControl_'](_0x1f339d);else{if(_0x48c9e7==='d')this['pendingDataMessages']['push'](_0x1f339d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x48c9e7);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4354e0){const _0x4800a6=yt('t',_0x4354e0),_0x35bdf5=yt('d',_0x4354e0);_0x4800a6==='c'?this['onControl_'](_0x35bdf5):_0x4800a6==='d'&&this['onDataMessage_'](_0x35bdf5);}['onDataMessage_'](_0x2fc2ce){this['onPrimaryResponse_'](),this['onMessage_'](_0x2fc2ce);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2b92d0){const _0x5bdc8c=yt(ci,_0x2b92d0);if(zs in _0x2b92d0){const _0x47d92f=_0x2b92d0[zs];if(_0x5bdc8c===Th){const _0x45e100={..._0x47d92f};this['repoInfo_']['isUsingEmulator']&&(_0x45e100['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x45e100);}else{if(_0x5bdc8c===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2148f2=0x0;_0x2148f2<this['pendingDataMessages']['length'];++_0x2148f2)this['onDataMessage_'](this['pendingDataMessages'][_0x2148f2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5bdc8c===wh?this['onConnectionShutdown_'](_0x47d92f):_0x5bdc8c===js?this['onReset_'](_0x47d92f):_0x5bdc8c===Ch?Ii('Server\x20Error:\x20'+_0x47d92f):_0x5bdc8c===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x5bdc8c);}}}['onHandshake_'](_0x8b652a){const _0x5d7708=_0x8b652a['ts'],_0x2aafd9=_0x8b652a['v'],_0x132829=_0x8b652a['h'];this['sessionId']=_0x8b652a['s'],this['repoInfo_']['host']=_0x132829,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5d7708),Gi!==_0x2aafd9&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1e3aa5=this['transportManager_']['upgradeTransport']();_0x1e3aa5&&this['startUpgrade_'](_0x1e3aa5);}['startUpgrade_'](_0x1733a5){this['secondaryConn_']=new _0x1733a5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1733a5['responsesRequiredToBeHealthy']||0x0;const _0x21dfd6=this['connReceiver_'](this['secondaryConn_']),_0x742c05=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x21dfd6,_0x742c05),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x43e6ed){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x43e6ed),this['repoInfo_']['host']=_0x43e6ed,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2d296e,_0x524cb4){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2d296e,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x524cb4,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x13fe69=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x13fe69||this['rx_']===_0x13fe69)&&this['close']();}['onConnectionLost_'](_0x1434b6){this['conn_']=null,!_0x1434b6&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x139227){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x139227),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3aa37d){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3aa37d);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x5038fe,_0x17af85,_0x2b9f80,_0x19fb3b){}['merge'](_0x3a9f2e,_0xc1bc30,_0xca58e1,_0x28f462){}['refreshAuthToken'](_0x58241e){}['refreshAppCheckToken'](_0x4b9ea0){}['onDisconnectPut'](_0x2d12d8,_0x123e7e,_0x22893c){}['onDisconnectMerge'](_0x395a58,_0x1365b4,_0x45a946){}['onDisconnectCancel'](_0x4ef33b,_0x3b81c3){}['reportStats'](_0x794adc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3775c8){this['allowedEvents_']=_0x3775c8,this['listeners_']={},f(Array['isArray'](_0x3775c8)&&_0x3775c8['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4f59da,..._0xed644f){if(Array['isArray'](this['listeners_'][_0x4f59da])){const _0x240a8c=[...this['listeners_'][_0x4f59da]];for(let _0x1df470=0x0;_0x1df470<_0x240a8c['length'];_0x1df470++)_0x240a8c[_0x1df470]['callback']['apply'](_0x240a8c[_0x1df470]['context'],_0xed644f);}}['on'](_0x2db21a,_0x30e97f,_0x216465){this['validateEventType_'](_0x2db21a),this['listeners_'][_0x2db21a]=this['listeners_'][_0x2db21a]||[],this['listeners_'][_0x2db21a]['push']({'callback':_0x30e97f,'context':_0x216465});const _0x2246f4=this['getInitialEvent'](_0x2db21a);_0x2246f4&&_0x30e97f['apply'](_0x216465,_0x2246f4);}['off'](_0x7a9ea6,_0x3c607f,_0x1e1270){this['validateEventType_'](_0x7a9ea6);const _0x4d3e1b=this['listeners_'][_0x7a9ea6]||[];for(let _0x31ac08=0x0;_0x31ac08<_0x4d3e1b['length'];_0x31ac08++)if(_0x4d3e1b[_0x31ac08]['callback']===_0x3c607f&&(!_0x1e1270||_0x1e1270===_0x4d3e1b[_0x31ac08]['context'])){_0x4d3e1b['splice'](_0x31ac08,0x1);return;}}['validateEventType_'](_0x545a3d){f(this['allowedEvents_']['find'](_0x3cf230=>_0x3cf230===_0x545a3d),'Unknown\x20event:\x20'+_0x545a3d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2cab28){return f(_0x2cab28==='online','Unknown\x20event\x20type:\x20'+_0x2cab28),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x42cbed,_0x2427b8){if(_0x2427b8===void 0x0){this['pieces_']=_0x42cbed['split']('/');let _0x1df031=0x0;for(let _0x1ef4d3=0x0;_0x1ef4d3<this['pieces_']['length'];_0x1ef4d3++)this['pieces_'][_0x1ef4d3]['length']>0x0&&(this['pieces_'][_0x1df031]=this['pieces_'][_0x1ef4d3],_0x1df031++);this['pieces_']['length']=_0x1df031,this['pieceNum_']=0x0;}else this['pieces_']=_0x42cbed,this['pieceNum_']=_0x2427b8;}['toString'](){let _0x33aeae='';for(let _0x52d0fb=this['pieceNum_'];_0x52d0fb<this['pieces_']['length'];_0x52d0fb++)this['pieces_'][_0x52d0fb]!==''&&(_0x33aeae+='/'+this['pieces_'][_0x52d0fb]);return _0x33aeae||'/';}}function w(){return new C('');}function y(_0x31f33b){return _0x31f33b['pieceNum_']>=_0x31f33b['pieces_']['length']?null:_0x31f33b['pieces_'][_0x31f33b['pieceNum_']];}function Ce(_0x5caa3f){return _0x5caa3f['pieces_']['length']-_0x5caa3f['pieceNum_'];}function S(_0x5a269c){let _0x59088c=_0x5a269c['pieceNum_'];return _0x59088c<_0x5a269c['pieces_']['length']&&_0x59088c++,new C(_0x5a269c['pieces_'],_0x59088c);}function ji(_0x2de5cd){return _0x2de5cd['pieceNum_']<_0x2de5cd['pieces_']['length']?_0x2de5cd['pieces_'][_0x2de5cd['pieces_']['length']-0x1]:null;}function bh(_0x1a4296){let _0x397650='';for(let _0x4273a9=_0x1a4296['pieceNum_'];_0x4273a9<_0x1a4296['pieces_']['length'];_0x4273a9++)_0x1a4296['pieces_'][_0x4273a9]!==''&&(_0x397650+='/'+encodeURIComponent(String(_0x1a4296['pieces_'][_0x4273a9])));return _0x397650||'/';}function Dt(_0x4eb0bc,_0x1bd70b=0x0){return _0x4eb0bc['pieces_']['slice'](_0x4eb0bc['pieceNum_']+_0x1bd70b);}function Ro(_0x333324){if(_0x333324['pieceNum_']>=_0x333324['pieces_']['length'])return null;const _0x293aed=[];for(let _0x350723=_0x333324['pieceNum_'];_0x350723<_0x333324['pieces_']['length']-0x1;_0x350723++)_0x293aed['push'](_0x333324['pieces_'][_0x350723]);return new C(_0x293aed,0x0);}function k(_0x23e0ec,_0x1c6834){const _0x2b20cb=[];for(let _0x27dec9=_0x23e0ec['pieceNum_'];_0x27dec9<_0x23e0ec['pieces_']['length'];_0x27dec9++)_0x2b20cb['push'](_0x23e0ec['pieces_'][_0x27dec9]);if(_0x1c6834 instanceof C){for(let _0x26d8ab=_0x1c6834['pieceNum_'];_0x26d8ab<_0x1c6834['pieces_']['length'];_0x26d8ab++)_0x2b20cb['push'](_0x1c6834['pieces_'][_0x26d8ab]);}else{const _0x218b15=_0x1c6834['split']('/');for(let _0x80f92e=0x0;_0x80f92e<_0x218b15['length'];_0x80f92e++)_0x218b15[_0x80f92e]['length']>0x0&&_0x2b20cb['push'](_0x218b15[_0x80f92e]);}return new C(_0x2b20cb,0x0);}function v(_0x4462b6){return _0x4462b6['pieceNum_']>=_0x4462b6['pieces_']['length'];}function F(_0x1fe844,_0x5a7734){const _0x216eb5=y(_0x1fe844),_0x16af6b=y(_0x5a7734);if(_0x216eb5===null)return _0x5a7734;if(_0x216eb5===_0x16af6b)return F(S(_0x1fe844),S(_0x5a7734));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5a7734+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1fe844+')');}function Rh(_0x5c7a83,_0x2deda1){const _0x59b3e2=Dt(_0x5c7a83,0x0),_0x1adf7f=Dt(_0x2deda1,0x0);for(let _0x49a9fe=0x0;_0x49a9fe<_0x59b3e2['length']&&_0x49a9fe<_0x1adf7f['length'];_0x49a9fe++){const _0x1e4782=Ge(_0x59b3e2[_0x49a9fe],_0x1adf7f[_0x49a9fe]);if(_0x1e4782!==0x0)return _0x1e4782;}return _0x59b3e2['length']===_0x1adf7f['length']?0x0:_0x59b3e2['length']<_0x1adf7f['length']?-0x1:0x1;}function Ki(_0xfee612,_0x3b175a){if(Ce(_0xfee612)!==Ce(_0x3b175a))return!0x1;for(let _0x6ea2ed=_0xfee612['pieceNum_'],_0x5ce292=_0x3b175a['pieceNum_'];_0x6ea2ed<=_0xfee612['pieces_']['length'];_0x6ea2ed++,_0x5ce292++)if(_0xfee612['pieces_'][_0x6ea2ed]!==_0x3b175a['pieces_'][_0x5ce292])return!0x1;return!0x0;}function G(_0x32ca7e,_0x1c8e85){let _0x2c2b6f=_0x32ca7e['pieceNum_'],_0x4732fc=_0x1c8e85['pieceNum_'];if(Ce(_0x32ca7e)>Ce(_0x1c8e85))return!0x1;for(;_0x2c2b6f<_0x32ca7e['pieces_']['length'];){if(_0x32ca7e['pieces_'][_0x2c2b6f]!==_0x1c8e85['pieces_'][_0x4732fc])return!0x1;++_0x2c2b6f,++_0x4732fc;}return!0x0;}class Ah{constructor(_0x50500f,_0x54f202){this['errorPrefix_']=_0x54f202,this['parts_']=Dt(_0x50500f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x568f1f=0x0;_0x568f1f<this['parts_']['length'];_0x568f1f++)this['byteLength_']+=Ln(this['parts_'][_0x568f1f]);Ao(this);}}function kh(_0x463dd1,_0x47e8a8){_0x463dd1['parts_']['length']>0x0&&(_0x463dd1['byteLength_']+=0x1),_0x463dd1['parts_']['push'](_0x47e8a8),_0x463dd1['byteLength_']+=Ln(_0x47e8a8),Ao(_0x463dd1);}function Nh(_0x72f33d){const _0x3abba5=_0x72f33d['parts_']['pop']();_0x72f33d['byteLength_']-=Ln(_0x3abba5),_0x72f33d['parts_']['length']>0x0&&(_0x72f33d['byteLength_']-=0x1);}function Ao(_0x27e5cf){if(_0x27e5cf['byteLength_']>Zs)throw new Error(_0x27e5cf['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x27e5cf['byteLength_']+').');if(_0x27e5cf['parts_']['length']>Xs)throw new Error(_0x27e5cf['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x27e5cf));}function Pe(_0x4902ab){return _0x4902ab['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4902ab['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x285279,_0x59a280;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x59a280='visibilitychange',_0x285279='hidden'):typeof document['mozHidden']<'u'?(_0x59a280='mozvisibilitychange',_0x285279='mozHidden'):typeof document['msHidden']<'u'?(_0x59a280='msvisibilitychange',_0x285279='msHidden'):typeof document['webkitHidden']<'u'&&(_0x59a280='webkitvisibilitychange',_0x285279='webkitHidden')),this['visible_']=!0x0,_0x59a280&&document['addEventListener'](_0x59a280,()=>{const _0x2ef436=!document[_0x285279];_0x2ef436!==this['visible_']&&(this['visible_']=_0x2ef436,this['trigger']('visible',_0x2ef436));},!0x1);}['getInitialEvent'](_0x5075f5){return f(_0x5075f5==='visible','Unknown\x20event\x20type:\x20'+_0x5075f5),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4e5ebc,_0xe5fa24,_0xaeb954,_0x4e9dce,_0x1b23f6,_0x21b2a9,_0xbc8e28,_0x33525e){if(super(),this['repoInfo_']=_0x4e5ebc,this['applicationId_']=_0xe5fa24,this['onDataUpdate_']=_0xaeb954,this['onConnectStatus_']=_0x4e9dce,this['onServerInfoUpdate_']=_0x1b23f6,this['authTokenProvider_']=_0x21b2a9,this['appCheckTokenProvider_']=_0xbc8e28,this['authOverride_']=_0x33525e,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x33525e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4e5ebc['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x212ce0,_0x47eea0,_0x3e87a2){const _0x510a61=++this['requestNumber_'],_0x6cbefa={'r':_0x510a61,'a':_0x212ce0,'b':_0x47eea0};this['log_'](O(_0x6cbefa)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x6cbefa),_0x3e87a2&&(this['requestCBHash_'][_0x510a61]=_0x3e87a2);}['get'](_0x9782f2){this['initConnection_']();const _0x4ddd9b=new H(),_0x327f81={'action':'g','request':{'p':_0x9782f2['_path']['toString'](),'q':_0x9782f2['_queryObject']},'onComplete':_0xfcfcb3=>{const _0x180781=_0xfcfcb3['d'];_0xfcfcb3['s']==='ok'?_0x4ddd9b['resolve'](_0x180781):_0x4ddd9b['reject'](_0x180781);}};this['outstandingGets_']['push'](_0x327f81),this['outstandingGetCount_']++;const _0x3b538b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3b538b),_0x4ddd9b['promise'];}['listen'](_0x34b14a,_0x545004,_0x1bd70d,_0x3dd32e){this['initConnection_']();const _0x4cf48e=_0x34b14a['_queryIdentifier'],_0x58d633=_0x34b14a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x58d633+'\x20'+_0x4cf48e),this['listens']['has'](_0x58d633)||this['listens']['set'](_0x58d633,new Map()),f(_0x34b14a['_queryParams']['isDefault']()||!_0x34b14a['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x58d633)['has'](_0x4cf48e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1d8f5e={'onComplete':_0x3dd32e,'hashFn':_0x545004,'query':_0x34b14a,'tag':_0x1bd70d};this['listens']['get'](_0x58d633)['set'](_0x4cf48e,_0x1d8f5e),this['connected_']&&this['sendListen_'](_0x1d8f5e);}['sendGet_'](_0x4e1093){const _0xbffd5e=this['outstandingGets_'][_0x4e1093];this['sendRequest']('g',_0xbffd5e['request'],_0x3348d0=>{delete this['outstandingGets_'][_0x4e1093],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xbffd5e['onComplete']&&_0xbffd5e['onComplete'](_0x3348d0);});}['sendListen_'](_0x299b23){const _0xd9c65d=_0x299b23['query'],_0x5f56a0=_0xd9c65d['_path']['toString'](),_0x2a9f45=_0xd9c65d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5f56a0+'\x20for\x20'+_0x2a9f45);const _0x5dbe64={'p':_0x5f56a0},_0x233d79='q';_0x299b23['tag']&&(_0x5dbe64['q']=_0xd9c65d['_queryObject'],_0x5dbe64['t']=_0x299b23['tag']),_0x5dbe64['h']=_0x299b23['hashFn'](),this['sendRequest'](_0x233d79,_0x5dbe64,_0x60853a=>{const _0x30955c=_0x60853a['d'],_0x41f948=_0x60853a['s'];se['warnOnListenWarnings_'](_0x30955c,_0xd9c65d),(this['listens']['get'](_0x5f56a0)&&this['listens']['get'](_0x5f56a0)['get'](_0x2a9f45))===_0x299b23&&(this['log_']('listen\x20response',_0x60853a),_0x41f948!=='ok'&&this['removeListen_'](_0x5f56a0,_0x2a9f45),_0x299b23['onComplete']&&_0x299b23['onComplete'](_0x41f948,_0x30955c));});}static['warnOnListenWarnings_'](_0x17fa7b,_0x47a5b4){if(_0x17fa7b&&typeof _0x17fa7b=='object'&&Q(_0x17fa7b,'w')){const _0x3fc6a6=Me(_0x17fa7b,'w');if(Array['isArray'](_0x3fc6a6)&&~_0x3fc6a6['indexOf']('no_index')){const _0x44be03='\x22.indexOn\x22:\x20\x22'+_0x47a5b4['_queryParams']['getIndex']()['toString']()+'\x22',_0x3d6867=_0x47a5b4['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x44be03+'\x20at\x20'+_0x3d6867+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x133c26){this['authToken_']=_0x133c26,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x133c26);}['reduceReconnectDelayIfAdminCredential_'](_0x65c981){(_0x65c981&&_0x65c981['length']===0x28||wc(_0x65c981))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x191812){this['appCheckToken_']=_0x191812,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x394b4a=this['authToken_'],_0x3f541b=Ic(_0x394b4a)?'auth':'gauth',_0xd59317={'cred':_0x394b4a};this['authOverride_']===null?_0xd59317['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xd59317['authvar']=this['authOverride_']),this['sendRequest'](_0x3f541b,_0xd59317,_0xdf43b2=>{const _0x5af078=_0xdf43b2['s'],_0x1ff67d=_0xdf43b2['d']||'error';this['authToken_']===_0x394b4a&&(_0x5af078==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5af078,_0x1ff67d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x213d8f=>{const _0x4233dc=_0x213d8f['s'],_0x337540=_0x213d8f['d']||'error';_0x4233dc==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4233dc,_0x337540);});}['unlisten'](_0x22ba50,_0x1c847b){const _0x42ebf8=_0x22ba50['_path']['toString'](),_0x32dca0=_0x22ba50['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x42ebf8+'\x20'+_0x32dca0),f(_0x22ba50['_queryParams']['isDefault']()||!_0x22ba50['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x42ebf8,_0x32dca0)&&this['connected_']&&this['sendUnlisten_'](_0x42ebf8,_0x32dca0,_0x22ba50['_queryObject'],_0x1c847b);}['sendUnlisten_'](_0x591d07,_0x272037,_0x4092b6,_0x47dcb5){this['log_']('Unlisten\x20on\x20'+_0x591d07+'\x20for\x20'+_0x272037);const _0x5b5b89={'p':_0x591d07},_0x3708e0='n';_0x47dcb5&&(_0x5b5b89['q']=_0x4092b6,_0x5b5b89['t']=_0x47dcb5),this['sendRequest'](_0x3708e0,_0x5b5b89);}['onDisconnectPut'](_0x3cd8c9,_0xc115a2,_0x2921ae){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3cd8c9,_0xc115a2,_0x2921ae):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3cd8c9,'action':'o','data':_0xc115a2,'onComplete':_0x2921ae});}['onDisconnectMerge'](_0x12d6c2,_0x3f3836,_0x3c45d2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x12d6c2,_0x3f3836,_0x3c45d2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x12d6c2,'action':'om','data':_0x3f3836,'onComplete':_0x3c45d2});}['onDisconnectCancel'](_0x55240f,_0x212dac){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x55240f,null,_0x212dac):this['onDisconnectRequestQueue_']['push']({'pathString':_0x55240f,'action':'oc','data':null,'onComplete':_0x212dac});}['sendOnDisconnect_'](_0x1761ff,_0x587c70,_0x237496,_0x5c64de){const _0x1703f0={'p':_0x587c70,'d':_0x237496};this['log_']('onDisconnect\x20'+_0x1761ff,_0x1703f0),this['sendRequest'](_0x1761ff,_0x1703f0,_0x5f4d26=>{_0x5c64de&&setTimeout(()=>{_0x5c64de(_0x5f4d26['s'],_0x5f4d26['d']);},Math['floor'](0x0));});}['put'](_0x86a8ab,_0x1dd24f,_0x32338a,_0x57dac9){this['putInternal']('p',_0x86a8ab,_0x1dd24f,_0x32338a,_0x57dac9);}['merge'](_0x2e6ad6,_0x1753e5,_0x2fe2bc,_0x3bfdfb){this['putInternal']('m',_0x2e6ad6,_0x1753e5,_0x2fe2bc,_0x3bfdfb);}['putInternal'](_0x339fed,_0x2545ea,_0x7f3095,_0x2cb8a7,_0x2b0de3){this['initConnection_']();const _0x90a73={'p':_0x2545ea,'d':_0x7f3095};_0x2b0de3!==void 0x0&&(_0x90a73['h']=_0x2b0de3),this['outstandingPuts_']['push']({'action':_0x339fed,'request':_0x90a73,'onComplete':_0x2cb8a7}),this['outstandingPutCount_']++;const _0x3d630d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3d630d):this['log_']('Buffering\x20put:\x20'+_0x2545ea);}['sendPut_'](_0x46fc9b){const _0x92847a=this['outstandingPuts_'][_0x46fc9b]['action'],_0x873708=this['outstandingPuts_'][_0x46fc9b]['request'],_0x1fd4ba=this['outstandingPuts_'][_0x46fc9b]['onComplete'];this['outstandingPuts_'][_0x46fc9b]['queued']=this['connected_'],this['sendRequest'](_0x92847a,_0x873708,_0x2f6afa=>{this['log_'](_0x92847a+'\x20response',_0x2f6afa),delete this['outstandingPuts_'][_0x46fc9b],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1fd4ba&&_0x1fd4ba(_0x2f6afa['s'],_0x2f6afa['d']);});}['reportStats'](_0x46f19c){if(this['connected_']){const _0x2a9d48={'c':_0x46f19c};this['log_']('reportStats',_0x2a9d48),this['sendRequest']('s',_0x2a9d48,_0x14cbcc=>{if(_0x14cbcc['s']!=='ok'){const _0x29209e=_0x14cbcc['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x29209e);}});}}['onDataMessage_'](_0x4dd348){if('r'in _0x4dd348){this['log_']('from\x20server:\x20'+O(_0x4dd348));const _0x20fb61=_0x4dd348['r'],_0x556ccc=this['requestCBHash_'][_0x20fb61];_0x556ccc&&(delete this['requestCBHash_'][_0x20fb61],_0x556ccc(_0x4dd348['b']));}else{if('error'in _0x4dd348)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4dd348['error'];'a'in _0x4dd348&&this['onDataPush_'](_0x4dd348['a'],_0x4dd348['b']);}}['onDataPush_'](_0x9b7c63,_0x7e8947){this['log_']('handleServerMessage',_0x9b7c63,_0x7e8947),_0x9b7c63==='d'?this['onDataUpdate_'](_0x7e8947['p'],_0x7e8947['d'],!0x1,_0x7e8947['t']):_0x9b7c63==='m'?this['onDataUpdate_'](_0x7e8947['p'],_0x7e8947['d'],!0x0,_0x7e8947['t']):_0x9b7c63==='c'?this['onListenRevoked_'](_0x7e8947['p'],_0x7e8947['q']):_0x9b7c63==='ac'?this['onAuthRevoked_'](_0x7e8947['s'],_0x7e8947['d']):_0x9b7c63==='apc'?this['onAppCheckRevoked_'](_0x7e8947['s'],_0x7e8947['d']):_0x9b7c63==='sd'?this['onSecurityDebugPacket_'](_0x7e8947):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x9b7c63)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x34b031,_0x3e9291){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x34b031),this['lastSessionId']=_0x3e9291,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2c926c){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2c926c));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x368f61){_0x368f61&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x368f61;}['onOnline_'](_0x4b8b2f){_0x4b8b2f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4b36e9=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3ce406=Math['max'](0x0,this['reconnectDelay_']-_0x4b36e9);_0x3ce406=Math['random']()*_0x3ce406,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3ce406+'ms'),this['scheduleConnect_'](_0x3ce406),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3d60a0=this['onDataMessage_']['bind'](this),_0x5adb14=this['onReady_']['bind'](this),_0xc91b9=this['onRealtimeDisconnect_']['bind'](this),_0x19075d=this['id']+':'+se['nextConnectionId_']++,_0x252ce7=this['lastSessionId'];let _0x171073=!0x1,_0x5a5ae4=null;const _0x5189aa=function(){_0x5a5ae4?_0x5a5ae4['close']():(_0x171073=!0x0,_0xc91b9());},_0x15d60d=function(_0x374b38){f(_0x5a5ae4,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x5a5ae4['sendRequest'](_0x374b38);};this['realtime_']={'close':_0x5189aa,'sendRequest':_0x15d60d};const _0x158cc5=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xb62ae1,_0x24645e]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x158cc5),this['appCheckTokenProvider_']['getToken'](_0x158cc5)]);_0x171073?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xb62ae1&&_0xb62ae1['accessToken'],this['appCheckToken_']=_0x24645e&&_0x24645e['token'],_0x5a5ae4=new Sh(_0x19075d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3d60a0,_0x5adb14,_0xc91b9,_0x42b659=>{U(_0x42b659+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x252ce7));}catch(_0xafeba1){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xafeba1),_0x171073||(this['repoInfo_']['nodeAdmin']&&U(_0xafeba1),_0x5189aa());}}}['interrupt'](_0x46f8aa){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x46f8aa),this['interruptReasons_'][_0x46f8aa]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x9968a6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x9968a6),delete this['interruptReasons_'][_0x9968a6],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x272f45){const _0x69bf5f=_0x272f45-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x69bf5f});}['cancelSentTransactions_'](){for(let _0x53fe0e=0x0;_0x53fe0e<this['outstandingPuts_']['length'];_0x53fe0e++){const _0x13f0b2=this['outstandingPuts_'][_0x53fe0e];_0x13f0b2&&'h'in _0x13f0b2['request']&&_0x13f0b2['queued']&&(_0x13f0b2['onComplete']&&_0x13f0b2['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x53fe0e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x57a543,_0x578df3){let _0x24875d;_0x578df3?_0x24875d=_0x578df3['map'](_0x222498=>$i(_0x222498))['join']('$'):_0x24875d='default';const _0x47e940=this['removeListen_'](_0x57a543,_0x24875d);_0x47e940&&_0x47e940['onComplete']&&_0x47e940['onComplete']('permission_denied');}['removeListen_'](_0x23b34e,_0x231e41){const _0x50866a=new C(_0x23b34e)['toString']();let _0x4379bc;if(this['listens']['has'](_0x50866a)){const _0x4ee15d=this['listens']['get'](_0x50866a);_0x4379bc=_0x4ee15d['get'](_0x231e41),_0x4ee15d['delete'](_0x231e41),_0x4ee15d['size']===0x0&&this['listens']['delete'](_0x50866a);}else _0x4379bc=void 0x0;return _0x4379bc;}['onAuthRevoked_'](_0x2b9305,_0x5df638){L('Auth\x20token\x20revoked:\x20'+_0x2b9305+'/'+_0x5df638),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2b9305==='invalid_token'||_0x2b9305==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x34d7f5,_0x3c6a67){L('App\x20check\x20token\x20revoked:\x20'+_0x34d7f5+'/'+_0x3c6a67),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x34d7f5==='invalid_token'||_0x34d7f5==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1680d6){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1680d6):'msg'in _0x1680d6&&console['log']('FIREBASE:\x20'+_0x1680d6['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2db233 of this['listens']['values']())for(const _0x4ed92a of _0x2db233['values']())this['sendListen_'](_0x4ed92a);for(let _0xc7b6ad=0x0;_0xc7b6ad<this['outstandingPuts_']['length'];_0xc7b6ad++)this['outstandingPuts_'][_0xc7b6ad]&&this['sendPut_'](_0xc7b6ad);for(;this['onDisconnectRequestQueue_']['length'];){const _0x591070=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x591070['action'],_0x591070['pathString'],_0x591070['data'],_0x591070['onComplete']);}for(let _0x1dcce2=0x0;_0x1dcce2<this['outstandingGets_']['length'];_0x1dcce2++)this['outstandingGets_'][_0x1dcce2]&&this['sendGet_'](_0x1dcce2);}['sendConnectStats_'](){const _0x483f81={};let _0x323164='js';_0x483f81['sdk.'+_0x323164+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x483f81['framework.cordova']=0x1:Kr()&&(_0x483f81['framework.reactnative']=0x1),this['reportStats'](_0x483f81);}['shouldReconnect_'](){const _0x392631=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x392631;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5911c9,_0x397233){this['name']=_0x5911c9,this['node']=_0x397233;}static['Wrap'](_0x22c26a,_0x53b5d7){return new E(_0x22c26a,_0x53b5d7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x516589,_0x31f807){const _0x2ebc62=new E(Ue,_0x516589),_0x347b49=new E(Ue,_0x31f807);return this['compare'](_0x2ebc62,_0x347b49)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x3f1858){sn=_0x3f1858;}['compare'](_0x575db7,_0xbcb8ad){return Ge(_0x575db7['name'],_0xbcb8ad['name']);}['isDefinedOn'](_0xdcdfc8){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x239341,_0x5ceca0){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x47733b,_0x4bb6ca){return f(typeof _0x47733b=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x47733b,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x1e4725,_0x7b024a,_0x3d9312,_0x3dd710,_0x28bce2=null){this['isReverse_']=_0x3dd710,this['resultGenerator_']=_0x28bce2,this['nodeStack_']=[];let _0x112a95=0x1;for(;!_0x1e4725['isEmpty']();)if(_0x1e4725=_0x1e4725,_0x112a95=_0x7b024a?_0x3d9312(_0x1e4725['key'],_0x7b024a):0x1,_0x3dd710&&(_0x112a95*=-0x1),_0x112a95<0x0)this['isReverse_']?_0x1e4725=_0x1e4725['left']:_0x1e4725=_0x1e4725['right'];else{if(_0x112a95===0x0){this['nodeStack_']['push'](_0x1e4725);break;}else this['nodeStack_']['push'](_0x1e4725),this['isReverse_']?_0x1e4725=_0x1e4725['right']:_0x1e4725=_0x1e4725['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x39cb37=this['nodeStack_']['pop'](),_0x40682f;if(this['resultGenerator_']?_0x40682f=this['resultGenerator_'](_0x39cb37['key'],_0x39cb37['value']):_0x40682f={'key':_0x39cb37['key'],'value':_0x39cb37['value']},this['isReverse_']){for(_0x39cb37=_0x39cb37['left'];!_0x39cb37['isEmpty']();)this['nodeStack_']['push'](_0x39cb37),_0x39cb37=_0x39cb37['right'];}else{for(_0x39cb37=_0x39cb37['right'];!_0x39cb37['isEmpty']();)this['nodeStack_']['push'](_0x39cb37),_0x39cb37=_0x39cb37['left'];}return _0x40682f;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4911f7=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4911f7['key'],_0x4911f7['value']):{'key':_0x4911f7['key'],'value':_0x4911f7['value']};}}class M{constructor(_0x39063f,_0xaf9c07,_0x3f8641,_0x3ca330,_0x3e0948){this['key']=_0x39063f,this['value']=_0xaf9c07,this['color']=_0x3f8641??M['RED'],this['left']=_0x3ca330??B['EMPTY_NODE'],this['right']=_0x3e0948??B['EMPTY_NODE'];}['copy'](_0x4dad3a,_0x601674,_0x3ff06a,_0x4de9c4,_0x5e83ab){return new M(_0x4dad3a??this['key'],_0x601674??this['value'],_0x3ff06a??this['color'],_0x4de9c4??this['left'],_0x5e83ab??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5b557b){return this['left']['inorderTraversal'](_0x5b557b)||!!_0x5b557b(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5b557b);}['reverseTraversal'](_0x3e9ab2){return this['right']['reverseTraversal'](_0x3e9ab2)||_0x3e9ab2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3e9ab2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5d5c7f,_0x49811a,_0x1d3d14){let _0x4ccdc6=this;const _0x759fdd=_0x1d3d14(_0x5d5c7f,_0x4ccdc6['key']);return _0x759fdd<0x0?_0x4ccdc6=_0x4ccdc6['copy'](null,null,null,_0x4ccdc6['left']['insert'](_0x5d5c7f,_0x49811a,_0x1d3d14),null):_0x759fdd===0x0?_0x4ccdc6=_0x4ccdc6['copy'](null,_0x49811a,null,null,null):_0x4ccdc6=_0x4ccdc6['copy'](null,null,null,null,_0x4ccdc6['right']['insert'](_0x5d5c7f,_0x49811a,_0x1d3d14)),_0x4ccdc6['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x401ff6=this;return!_0x401ff6['left']['isRed_']()&&!_0x401ff6['left']['left']['isRed_']()&&(_0x401ff6=_0x401ff6['moveRedLeft_']()),_0x401ff6=_0x401ff6['copy'](null,null,null,_0x401ff6['left']['removeMin_'](),null),_0x401ff6['fixUp_']();}['remove'](_0x5509fd,_0x1f8892){let _0x3cd954,_0x19e5a4;if(_0x3cd954=this,_0x1f8892(_0x5509fd,_0x3cd954['key'])<0x0)!_0x3cd954['left']['isEmpty']()&&!_0x3cd954['left']['isRed_']()&&!_0x3cd954['left']['left']['isRed_']()&&(_0x3cd954=_0x3cd954['moveRedLeft_']()),_0x3cd954=_0x3cd954['copy'](null,null,null,_0x3cd954['left']['remove'](_0x5509fd,_0x1f8892),null);else{if(_0x3cd954['left']['isRed_']()&&(_0x3cd954=_0x3cd954['rotateRight_']()),!_0x3cd954['right']['isEmpty']()&&!_0x3cd954['right']['isRed_']()&&!_0x3cd954['right']['left']['isRed_']()&&(_0x3cd954=_0x3cd954['moveRedRight_']()),_0x1f8892(_0x5509fd,_0x3cd954['key'])===0x0){if(_0x3cd954['right']['isEmpty']())return B['EMPTY_NODE'];_0x19e5a4=_0x3cd954['right']['min_'](),_0x3cd954=_0x3cd954['copy'](_0x19e5a4['key'],_0x19e5a4['value'],null,null,_0x3cd954['right']['removeMin_']());}_0x3cd954=_0x3cd954['copy'](null,null,null,null,_0x3cd954['right']['remove'](_0x5509fd,_0x1f8892));}return _0x3cd954['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3c6fe2=this;return _0x3c6fe2['right']['isRed_']()&&!_0x3c6fe2['left']['isRed_']()&&(_0x3c6fe2=_0x3c6fe2['rotateLeft_']()),_0x3c6fe2['left']['isRed_']()&&_0x3c6fe2['left']['left']['isRed_']()&&(_0x3c6fe2=_0x3c6fe2['rotateRight_']()),_0x3c6fe2['left']['isRed_']()&&_0x3c6fe2['right']['isRed_']()&&(_0x3c6fe2=_0x3c6fe2['colorFlip_']()),_0x3c6fe2;}['moveRedLeft_'](){let _0x584f11=this['colorFlip_']();return _0x584f11['right']['left']['isRed_']()&&(_0x584f11=_0x584f11['copy'](null,null,null,null,_0x584f11['right']['rotateRight_']()),_0x584f11=_0x584f11['rotateLeft_'](),_0x584f11=_0x584f11['colorFlip_']()),_0x584f11;}['moveRedRight_'](){let _0x5e2b2d=this['colorFlip_']();return _0x5e2b2d['left']['left']['isRed_']()&&(_0x5e2b2d=_0x5e2b2d['rotateRight_'](),_0x5e2b2d=_0x5e2b2d['colorFlip_']()),_0x5e2b2d;}['rotateLeft_'](){const _0x15d3d1=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x15d3d1,null);}['rotateRight_'](){const _0x4ae2f9=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4ae2f9);}['colorFlip_'](){const _0x3a95a9=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3ae9d7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3a95a9,_0x3ae9d7);}['checkMaxDepth_'](){const _0x187507=this['check_']();return Math['pow'](0x2,_0x187507)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x45d412=this['left']['check_']();if(_0x45d412!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x45d412+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x3f4709,_0x40465b,_0x2f4dbd,_0x3af9b7,_0x1fb983){return this;}['insert'](_0x36ae15,_0x43ee2f,_0x524104){return new M(_0x36ae15,_0x43ee2f,null);}['remove'](_0x5bee75,_0x478e12){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x36d208){return!0x1;}['reverseTraversal'](_0x46c72a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0xee50bc,_0x2534de=B['EMPTY_NODE']){this['comparator_']=_0xee50bc,this['root_']=_0x2534de;}['insert'](_0x4e6e84,_0x10580c){return new B(this['comparator_'],this['root_']['insert'](_0x4e6e84,_0x10580c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x252efb){return new B(this['comparator_'],this['root_']['remove'](_0x252efb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3548fe){let _0x3d8863,_0x13ee2d=this['root_'];for(;!_0x13ee2d['isEmpty']();){if(_0x3d8863=this['comparator_'](_0x3548fe,_0x13ee2d['key']),_0x3d8863===0x0)return _0x13ee2d['value'];_0x3d8863<0x0?_0x13ee2d=_0x13ee2d['left']:_0x3d8863>0x0&&(_0x13ee2d=_0x13ee2d['right']);}return null;}['getPredecessorKey'](_0x122abc){let _0x5bc1f0,_0x89eee9=this['root_'],_0xbf4a96=null;for(;!_0x89eee9['isEmpty']();)if(_0x5bc1f0=this['comparator_'](_0x122abc,_0x89eee9['key']),_0x5bc1f0===0x0){if(_0x89eee9['left']['isEmpty']())return _0xbf4a96?_0xbf4a96['key']:null;for(_0x89eee9=_0x89eee9['left'];!_0x89eee9['right']['isEmpty']();)_0x89eee9=_0x89eee9['right'];return _0x89eee9['key'];}else _0x5bc1f0<0x0?_0x89eee9=_0x89eee9['left']:_0x5bc1f0>0x0&&(_0xbf4a96=_0x89eee9,_0x89eee9=_0x89eee9['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x348c88){return this['root_']['inorderTraversal'](_0x348c88);}['reverseTraversal'](_0x40f7e5){return this['root_']['reverseTraversal'](_0x40f7e5);}['getIterator'](_0x289ce7){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x289ce7);}['getIteratorFrom'](_0x463da9,_0x331521){return new rn(this['root_'],_0x463da9,this['comparator_'],!0x1,_0x331521);}['getReverseIteratorFrom'](_0xb91ecc,_0x4c0079){return new rn(this['root_'],_0xb91ecc,this['comparator_'],!0x0,_0x4c0079);}['getReverseIterator'](_0x3c0662){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3c0662);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x49c492,_0x280121){return Ge(_0x49c492['name'],_0x280121['name']);}function Qi(_0x9336e8,_0x1d52ad){return Ge(_0x9336e8,_0x1d52ad);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x548f7a){Ci=_0x548f7a;}const No=function(_0x569eb7){return typeof _0x569eb7=='number'?'number:'+ao(_0x569eb7):'string:'+_0x569eb7;},Po=function(_0x201b5a){if(_0x201b5a['isLeafNode']()){const _0x96347a=_0x201b5a['val']();f(typeof _0x96347a=='string'||typeof _0x96347a=='number'||typeof _0x96347a=='object'&&Q(_0x96347a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x201b5a===Ci||_0x201b5a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x201b5a===Ci||_0x201b5a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x4a3389){nr=_0x4a3389;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x169538,_0x46dd37=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x169538,this['priorityNode_']=_0x46dd37,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x55e512){return new D(this['value_'],_0x55e512);}['getImmediateChild'](_0x3314e9){return _0x3314e9==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1ebcc2){return v(_0x1ebcc2)?this:y(_0x1ebcc2)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x58cecf,_0x32a54b){return null;}['updateImmediateChild'](_0x4df61a,_0xe4694f){return _0x4df61a==='.priority'?this['updatePriority'](_0xe4694f):_0xe4694f['isEmpty']()&&_0x4df61a!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4df61a,_0xe4694f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x56761c,_0x31fc39){const _0x362d1f=y(_0x56761c);return _0x362d1f===null?_0x31fc39:_0x31fc39['isEmpty']()&&_0x362d1f!=='.priority'?this:(f(_0x362d1f!=='.priority'||Ce(_0x56761c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x362d1f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x56761c),_0x31fc39)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x151076,_0xa2ecb9){return!0x1;}['val'](_0x332e10){return _0x332e10&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3f5b02='';this['priorityNode_']['isEmpty']()||(_0x3f5b02+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1cef43=typeof this['value_'];_0x3f5b02+=_0x1cef43+':',_0x1cef43==='number'?_0x3f5b02+=ao(this['value_']):_0x3f5b02+=this['value_'],this['lazyHash_']=ro(_0x3f5b02);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x11e9b3){return _0x11e9b3===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x11e9b3 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x11e9b3['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x11e9b3));}['compareToLeafNode_'](_0x19f280){const _0x4a8019=typeof _0x19f280['value_'],_0x517b2b=typeof this['value_'],_0x3814fc=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a8019),_0x125710=D['VALUE_TYPE_ORDER']['indexOf'](_0x517b2b);return f(_0x3814fc>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a8019),f(_0x125710>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x517b2b),_0x3814fc===_0x125710?_0x517b2b==='object'?0x0:this['value_']<_0x19f280['value_']?-0x1:this['value_']===_0x19f280['value_']?0x0:0x1:_0x125710-_0x3814fc;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x37f65d){if(_0x37f65d===this)return!0x0;if(_0x37f65d['isLeafNode']()){const _0x159cc6=_0x37f65d;return this['value_']===_0x159cc6['value_']&&this['priorityNode_']['equals'](_0x159cc6['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1a8b4d){Oo=_0x1a8b4d;}function Wh(_0x885291){Do=_0x885291;}class Bh extends Fn{['compare'](_0x113c0e,_0x29a6b0){const _0x5828b0=_0x113c0e['node']['getPriority'](),_0x1b1b70=_0x29a6b0['node']['getPriority'](),_0x27c77e=_0x5828b0['compareTo'](_0x1b1b70);return _0x27c77e===0x0?Ge(_0x113c0e['name'],_0x29a6b0['name']):_0x27c77e;}['isDefinedOn'](_0x225d1d){return!_0x225d1d['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5d7d34,_0x3a7f13){return!_0x5d7d34['getPriority']()['equals'](_0x3a7f13['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x45995d,_0x381f2f){const _0x2704fe=Oo(_0x45995d);return new E(_0x381f2f,new D('[PRIORITY-POST]',_0x2704fe));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x27a5f5){const _0xf6dfec=_0x420bda=>parseInt(Math['log'](_0x420bda)/Vh,0xa),_0x20c43c=_0xc1896a=>parseInt(Array(_0xc1896a+0x1)['join']('1'),0x2);this['count']=_0xf6dfec(_0x27a5f5+0x1),this['current_']=this['count']-0x1;const _0x47371e=_0x20c43c(this['count']);this['bits_']=_0x27a5f5+0x1&_0x47371e;}['nextBitIsOne'](){const _0x3fabc5=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3fabc5;}}const yn=function(_0x24b555,_0x39c161,_0x4efb1d,_0x1f4791){_0x24b555['sort'](_0x39c161);const _0xebd66b=function(_0x1ff452,_0x4dffa3){const _0x2dda71=_0x4dffa3-_0x1ff452;let _0x5a6b6d,_0x331852;if(_0x2dda71===0x0)return null;if(_0x2dda71===0x1)return _0x5a6b6d=_0x24b555[_0x1ff452],_0x331852=_0x4efb1d?_0x4efb1d(_0x5a6b6d):_0x5a6b6d,new M(_0x331852,_0x5a6b6d['node'],M['BLACK'],null,null);{const _0x454ecb=parseInt(_0x2dda71/0x2,0xa)+_0x1ff452,_0x5cdb5c=_0xebd66b(_0x1ff452,_0x454ecb),_0x33dcdf=_0xebd66b(_0x454ecb+0x1,_0x4dffa3);return _0x5a6b6d=_0x24b555[_0x454ecb],_0x331852=_0x4efb1d?_0x4efb1d(_0x5a6b6d):_0x5a6b6d,new M(_0x331852,_0x5a6b6d['node'],M['BLACK'],_0x5cdb5c,_0x33dcdf);}},_0x12e44e=function(_0x2ce70d){let _0x2a16f8=null,_0x23950d=null,_0xed628b=_0x24b555['length'];const _0x5e7fe0=function(_0x44fbf4,_0x159075){const _0x1726bb=_0xed628b-_0x44fbf4,_0x227499=_0xed628b;_0xed628b-=_0x44fbf4;const _0xffdb8d=_0xebd66b(_0x1726bb+0x1,_0x227499),_0x337f5e=_0x24b555[_0x1726bb],_0x3ebba9=_0x4efb1d?_0x4efb1d(_0x337f5e):_0x337f5e;_0x5fdd53(new M(_0x3ebba9,_0x337f5e['node'],_0x159075,null,_0xffdb8d));},_0x5fdd53=function(_0x33b556){_0x2a16f8?(_0x2a16f8['left']=_0x33b556,_0x2a16f8=_0x33b556):(_0x23950d=_0x33b556,_0x2a16f8=_0x33b556);};for(let _0x21d883=0x0;_0x21d883<_0x2ce70d['count'];++_0x21d883){const _0x2718b=_0x2ce70d['nextBitIsOne'](),_0x2a6bab=Math['pow'](0x2,_0x2ce70d['count']-(_0x21d883+0x1));_0x2718b?_0x5e7fe0(_0x2a6bab,M['BLACK']):(_0x5e7fe0(_0x2a6bab,M['BLACK']),_0x5e7fe0(_0x2a6bab,M['RED']));}return _0x23950d;},_0x539e08=new Hh(_0x24b555['length']),_0x97652c=_0x12e44e(_0x539e08);return new B(_0x1f4791||_0x39c161,_0x97652c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x1e9934,_0x3f83dc){this['indexes_']=_0x1e9934,this['indexSet_']=_0x3f83dc;}['get'](_0x31a71f){const _0xd672d6=Me(this['indexes_'],_0x31a71f);if(!_0xd672d6)throw new Error('No\x20index\x20defined\x20for\x20'+_0x31a71f);return _0xd672d6 instanceof B?_0xd672d6:null;}['hasIndex'](_0x5207a0){return Q(this['indexSet_'],_0x5207a0['toString']());}['addIndex'](_0x1ea236,_0x42f908){f(_0x1ea236!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x23dfd0=[];let _0x47308a=!0x1;const _0x4ebee7=_0x42f908['getIterator'](E['Wrap']);let _0x6b5884=_0x4ebee7['getNext']();for(;_0x6b5884;)_0x47308a=_0x47308a||_0x1ea236['isDefinedOn'](_0x6b5884['node']),_0x23dfd0['push'](_0x6b5884),_0x6b5884=_0x4ebee7['getNext']();let _0x5a288f;_0x47308a?_0x5a288f=yn(_0x23dfd0,_0x1ea236['getCompare']()):_0x5a288f=Qe;const _0x310082=_0x1ea236['toString'](),_0x43a07c={...this['indexSet_']};_0x43a07c[_0x310082]=_0x1ea236;const _0x791d41={...this['indexes_']};return _0x791d41[_0x310082]=_0x5a288f,new te(_0x791d41,_0x43a07c);}['addToIndexes'](_0x277775,_0x5b0344){const _0x484d2b=_n(this['indexes_'],(_0x36ac10,_0x4e074a)=>{const _0x227daf=Me(this['indexSet_'],_0x4e074a);if(f(_0x227daf,'Missing\x20index\x20implementation\x20for\x20'+_0x4e074a),_0x36ac10===Qe){if(_0x227daf['isDefinedOn'](_0x277775['node'])){const _0x5aa948=[],_0x276880=_0x5b0344['getIterator'](E['Wrap']);let _0x5cc32a=_0x276880['getNext']();for(;_0x5cc32a;)_0x5cc32a['name']!==_0x277775['name']&&_0x5aa948['push'](_0x5cc32a),_0x5cc32a=_0x276880['getNext']();return _0x5aa948['push'](_0x277775),yn(_0x5aa948,_0x227daf['getCompare']());}else return Qe;}else{const _0x28bd07=_0x5b0344['get'](_0x277775['name']);let _0x3e95c8=_0x36ac10;return _0x28bd07&&(_0x3e95c8=_0x3e95c8['remove'](new E(_0x277775['name'],_0x28bd07))),_0x3e95c8['insert'](_0x277775,_0x277775['node']);}});return new te(_0x484d2b,this['indexSet_']);}['removeFromIndexes'](_0x4d04d0,_0x1b2fe7){const _0x40939f=_n(this['indexes_'],_0x3c27fb=>{if(_0x3c27fb===Qe)return _0x3c27fb;{const _0x519994=_0x1b2fe7['get'](_0x4d04d0['name']);return _0x519994?_0x3c27fb['remove'](new E(_0x4d04d0['name'],_0x519994)):_0x3c27fb;}});return new te(_0x40939f,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x2edc0d,_0xcff8c9,_0x8efb91){this['children_']=_0x2edc0d,this['priorityNode_']=_0xcff8c9,this['indexMap_']=_0x8efb91,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x36d356){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x36d356,this['indexMap_']);}['getImmediateChild'](_0x59eee2){if(_0x59eee2==='.priority')return this['getPriority']();{const _0x314b02=this['children_']['get'](_0x59eee2);return _0x314b02===null?Et:_0x314b02;}}['getChild'](_0x1f36d2){const _0x4be0d0=y(_0x1f36d2);return _0x4be0d0===null?this:this['getImmediateChild'](_0x4be0d0)['getChild'](S(_0x1f36d2));}['hasChild'](_0x1cde4d){return this['children_']['get'](_0x1cde4d)!==null;}['updateImmediateChild'](_0x75a4cb,_0x5ed266){if(f(_0x5ed266,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x75a4cb==='.priority')return this['updatePriority'](_0x5ed266);{const _0x259e32=new E(_0x75a4cb,_0x5ed266);let _0x112635,_0x2f504e;_0x5ed266['isEmpty']()?(_0x112635=this['children_']['remove'](_0x75a4cb),_0x2f504e=this['indexMap_']['removeFromIndexes'](_0x259e32,this['children_'])):(_0x112635=this['children_']['insert'](_0x75a4cb,_0x5ed266),_0x2f504e=this['indexMap_']['addToIndexes'](_0x259e32,this['children_']));const _0x3f35c2=_0x112635['isEmpty']()?Et:this['priorityNode_'];return new g(_0x112635,_0x3f35c2,_0x2f504e);}}['updateChild'](_0x5b784d,_0x11108e){const _0x215614=y(_0x5b784d);if(_0x215614===null)return _0x11108e;{f(y(_0x5b784d)!=='.priority'||Ce(_0x5b784d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2c72b2=this['getImmediateChild'](_0x215614)['updateChild'](S(_0x5b784d),_0x11108e);return this['updateImmediateChild'](_0x215614,_0x2c72b2);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5282df){if(this['isEmpty']())return null;const _0x7dd5cd={};let _0x1e6589=0x0,_0x27453a=0x0,_0x11d35a=!0x0;if(this['forEachChild'](R,(_0x75c244,_0x3d4331)=>{_0x7dd5cd[_0x75c244]=_0x3d4331['val'](_0x5282df),_0x1e6589++,_0x11d35a&&g['INTEGER_REGEXP_']['test'](_0x75c244)?_0x27453a=Math['max'](_0x27453a,Number(_0x75c244)):_0x11d35a=!0x1;}),!_0x5282df&&_0x11d35a&&_0x27453a<0x2*_0x1e6589){const _0x460ebb=[];for(const _0x4f329d in _0x7dd5cd)_0x460ebb[_0x4f329d]=_0x7dd5cd[_0x4f329d];return _0x460ebb;}else return _0x5282df&&!this['getPriority']()['isEmpty']()&&(_0x7dd5cd['.priority']=this['getPriority']()['val']()),_0x7dd5cd;}['hash'](){if(this['lazyHash_']===null){let _0x3d837c='';this['getPriority']()['isEmpty']()||(_0x3d837c+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x308f1c,_0x1a79d2)=>{const _0x721d79=_0x1a79d2['hash']();_0x721d79!==''&&(_0x3d837c+=':'+_0x308f1c+':'+_0x721d79);}),this['lazyHash_']=_0x3d837c===''?'':ro(_0x3d837c);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2439e7,_0xea386f,_0x2b3d33){const _0x67dcc9=this['resolveIndex_'](_0x2b3d33);if(_0x67dcc9){const _0xef42e4=_0x67dcc9['getPredecessorKey'](new E(_0x2439e7,_0xea386f));return _0xef42e4?_0xef42e4['name']:null;}else return this['children_']['getPredecessorKey'](_0x2439e7);}['getFirstChildName'](_0x307864){const _0x5e2130=this['resolveIndex_'](_0x307864);if(_0x5e2130){const _0x2c5cd9=_0x5e2130['minKey']();return _0x2c5cd9&&_0x2c5cd9['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1fd47c){const _0x55f004=this['getFirstChildName'](_0x1fd47c);return _0x55f004?new E(_0x55f004,this['children_']['get'](_0x55f004)):null;}['getLastChildName'](_0x267045){const _0x58b748=this['resolveIndex_'](_0x267045);if(_0x58b748){const _0x2a3391=_0x58b748['maxKey']();return _0x2a3391&&_0x2a3391['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x6e5cf8){const _0x35b5d8=this['getLastChildName'](_0x6e5cf8);return _0x35b5d8?new E(_0x35b5d8,this['children_']['get'](_0x35b5d8)):null;}['forEachChild'](_0x43a613,_0x1a7acd){const _0x1a1bb2=this['resolveIndex_'](_0x43a613);return _0x1a1bb2?_0x1a1bb2['inorderTraversal'](_0x518d00=>_0x1a7acd(_0x518d00['name'],_0x518d00['node'])):this['children_']['inorderTraversal'](_0x1a7acd);}['getIterator'](_0x2b61e0){return this['getIteratorFrom'](_0x2b61e0['minPost'](),_0x2b61e0);}['getIteratorFrom'](_0x50af82,_0x5c0567){const _0x4ea088=this['resolveIndex_'](_0x5c0567);if(_0x4ea088)return _0x4ea088['getIteratorFrom'](_0x50af82,_0x3e11e2=>_0x3e11e2);{const _0xb69cd5=this['children_']['getIteratorFrom'](_0x50af82['name'],E['Wrap']);let _0x446d91=_0xb69cd5['peek']();for(;_0x446d91!=null&&_0x5c0567['compare'](_0x446d91,_0x50af82)<0x0;)_0xb69cd5['getNext'](),_0x446d91=_0xb69cd5['peek']();return _0xb69cd5;}}['getReverseIterator'](_0x384f63){return this['getReverseIteratorFrom'](_0x384f63['maxPost'](),_0x384f63);}['getReverseIteratorFrom'](_0x5a9d1c,_0x37cf45){const _0x450471=this['resolveIndex_'](_0x37cf45);if(_0x450471)return _0x450471['getReverseIteratorFrom'](_0x5a9d1c,_0x2119b3=>_0x2119b3);{const _0x38ea88=this['children_']['getReverseIteratorFrom'](_0x5a9d1c['name'],E['Wrap']);let _0x3057b9=_0x38ea88['peek']();for(;_0x3057b9!=null&&_0x37cf45['compare'](_0x3057b9,_0x5a9d1c)>0x0;)_0x38ea88['getNext'](),_0x3057b9=_0x38ea88['peek']();return _0x38ea88;}}['compareTo'](_0x10d4fb){return this['isEmpty']()?_0x10d4fb['isEmpty']()?0x0:-0x1:_0x10d4fb['isLeafNode']()||_0x10d4fb['isEmpty']()?0x1:_0x10d4fb===jt?-0x1:0x0;}['withIndex'](_0x3001b8){if(_0x3001b8===ve||this['indexMap_']['hasIndex'](_0x3001b8))return this;{const _0x5e7169=this['indexMap_']['addIndex'](_0x3001b8,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5e7169);}}['isIndexed'](_0x53f064){return _0x53f064===ve||this['indexMap_']['hasIndex'](_0x53f064);}['equals'](_0x425b8e){if(_0x425b8e===this)return!0x0;if(_0x425b8e['isLeafNode']())return!0x1;{const _0x23d344=_0x425b8e;if(this['getPriority']()['equals'](_0x23d344['getPriority']())){if(this['children_']['count']()===_0x23d344['children_']['count']()){const _0x156713=this['getIterator'](R),_0x2b53e4=_0x23d344['getIterator'](R);let _0xf87a22=_0x156713['getNext'](),_0x3aad8f=_0x2b53e4['getNext']();for(;_0xf87a22&&_0x3aad8f;){if(_0xf87a22['name']!==_0x3aad8f['name']||!_0xf87a22['node']['equals'](_0x3aad8f['node']))return!0x1;_0xf87a22=_0x156713['getNext'](),_0x3aad8f=_0x2b53e4['getNext']();}return _0xf87a22===null&&_0x3aad8f===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x45c899){return _0x45c899===ve?null:this['indexMap_']['get'](_0x45c899['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x1a4895){return _0x1a4895===this?0x0:0x1;}['equals'](_0x331808){return _0x331808===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4cf52c){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x544837,_0x236646=null){if(_0x544837===null)return g['EMPTY_NODE'];if(typeof _0x544837=='object'&&'.priority'in _0x544837&&(_0x236646=_0x544837['.priority']),f(_0x236646===null||typeof _0x236646=='string'||typeof _0x236646=='number'||typeof _0x236646=='object'&&'.sv'in _0x236646,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x236646),typeof _0x544837=='object'&&'.value'in _0x544837&&_0x544837['.value']!==null&&(_0x544837=_0x544837['.value']),typeof _0x544837!='object'||'.sv'in _0x544837){const _0x3a6fb9=_0x544837;return new D(_0x3a6fb9,A(_0x236646));}if(!(_0x544837 instanceof Array)&&Gh){const _0x55c523=[];let _0x5164e0=!0x1;if(x(_0x544837,(_0x3083da,_0x5bb4b2)=>{if(_0x3083da['substring'](0x0,0x1)!=='.'){const _0x460ef8=A(_0x5bb4b2);_0x460ef8['isEmpty']()||(_0x5164e0=_0x5164e0||!_0x460ef8['getPriority']()['isEmpty'](),_0x55c523['push'](new E(_0x3083da,_0x460ef8)));}}),_0x55c523['length']===0x0)return g['EMPTY_NODE'];const _0x451753=yn(_0x55c523,xh,_0x15336c=>_0x15336c['name'],Qi);if(_0x5164e0){const _0x894f0a=yn(_0x55c523,R['getCompare']());return new g(_0x451753,A(_0x236646),new te({'.priority':_0x894f0a},{'.priority':R}));}else return new g(_0x451753,A(_0x236646),te['Default']);}else{let _0x421f9d=g['EMPTY_NODE'];return x(_0x544837,(_0x56ffe0,_0x375954)=>{if(Q(_0x544837,_0x56ffe0)&&_0x56ffe0['substring'](0x0,0x1)!=='.'){const _0x5ea55f=A(_0x375954);(_0x5ea55f['isLeafNode']()||!_0x5ea55f['isEmpty']())&&(_0x421f9d=_0x421f9d['updateImmediateChild'](_0x56ffe0,_0x5ea55f));}}),_0x421f9d['updatePriority'](A(_0x236646));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x23ad39){super(),this['indexPath_']=_0x23ad39,f(!v(_0x23ad39)&&y(_0x23ad39)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x55f080){return _0x55f080['getChild'](this['indexPath_']);}['isDefinedOn'](_0x10ff21){return!_0x10ff21['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3d7fbc,_0x1415f8){const _0x29eed7=this['extractChild'](_0x3d7fbc['node']),_0x42a402=this['extractChild'](_0x1415f8['node']),_0x2a76ce=_0x29eed7['compareTo'](_0x42a402);return _0x2a76ce===0x0?Ge(_0x3d7fbc['name'],_0x1415f8['name']):_0x2a76ce;}['makePost'](_0x27c373,_0x494927){const _0xb58a08=A(_0x27c373),_0x43c9be=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xb58a08);return new E(_0x494927,_0x43c9be);}['maxPost'](){const _0x3e08d6=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x3e08d6);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x325111,_0x41cbbc){const _0x1b7373=_0x325111['node']['compareTo'](_0x41cbbc['node']);return _0x1b7373===0x0?Ge(_0x325111['name'],_0x41cbbc['name']):_0x1b7373;}['isDefinedOn'](_0x50074d){return!0x0;}['indexedValueChanged'](_0x10834f,_0x413b23){return!_0x10834f['equals'](_0x413b23);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x53b119,_0x364a6){const _0x63c39d=A(_0x53b119);return new E(_0x364a6,_0x63c39d);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x37cff1){return{'type':'value','snapshotNode':_0x37cff1};}function rt(_0x55ad88,_0x44293a){return{'type':'child_added','snapshotNode':_0x44293a,'childName':_0x55ad88};}function Mt(_0x1ead2e,_0x560885){return{'type':'child_removed','snapshotNode':_0x560885,'childName':_0x1ead2e};}function Lt(_0xa136e1,_0x12a319,_0x262aa0){return{'type':'child_changed','snapshotNode':_0x12a319,'childName':_0xa136e1,'oldSnap':_0x262aa0};}function zh(_0x268aa7,_0x5aa2ec){return{'type':'child_moved','snapshotNode':_0x5aa2ec,'childName':_0x268aa7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x148465){this['index_']=_0x148465;}['updateChild'](_0x34943c,_0x1c9dc2,_0x23b136,_0x3aa4ba,_0x3147bb,_0x1360c5){f(_0x34943c['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3cfe37=_0x34943c['getImmediateChild'](_0x1c9dc2);return _0x3cfe37['getChild'](_0x3aa4ba)['equals'](_0x23b136['getChild'](_0x3aa4ba))&&_0x3cfe37['isEmpty']()===_0x23b136['isEmpty']()||(_0x1360c5!=null&&(_0x23b136['isEmpty']()?_0x34943c['hasChild'](_0x1c9dc2)?_0x1360c5['trackChildChange'](Mt(_0x1c9dc2,_0x3cfe37)):f(_0x34943c['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3cfe37['isEmpty']()?_0x1360c5['trackChildChange'](rt(_0x1c9dc2,_0x23b136)):_0x1360c5['trackChildChange'](Lt(_0x1c9dc2,_0x23b136,_0x3cfe37))),_0x34943c['isLeafNode']()&&_0x23b136['isEmpty']())?_0x34943c:_0x34943c['updateImmediateChild'](_0x1c9dc2,_0x23b136)['withIndex'](this['index_']);}['updateFullNode'](_0x302251,_0x44eaae,_0xae75c5){return _0xae75c5!=null&&(_0x302251['isLeafNode']()||_0x302251['forEachChild'](R,(_0x374fb2,_0x1a5179)=>{_0x44eaae['hasChild'](_0x374fb2)||_0xae75c5['trackChildChange'](Mt(_0x374fb2,_0x1a5179));}),_0x44eaae['isLeafNode']()||_0x44eaae['forEachChild'](R,(_0x266554,_0x42164d)=>{if(_0x302251['hasChild'](_0x266554)){const _0x135455=_0x302251['getImmediateChild'](_0x266554);_0x135455['equals'](_0x42164d)||_0xae75c5['trackChildChange'](Lt(_0x266554,_0x42164d,_0x135455));}else _0xae75c5['trackChildChange'](rt(_0x266554,_0x42164d));})),_0x44eaae['withIndex'](this['index_']);}['updatePriority'](_0x17c8e1,_0x395525){return _0x17c8e1['isEmpty']()?g['EMPTY_NODE']:_0x17c8e1['updatePriority'](_0x395525);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x39a9b4){this['indexedFilter_']=new Xi(_0x39a9b4['getIndex']()),this['index_']=_0x39a9b4['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x39a9b4),this['endPost_']=xt['getEndPost_'](_0x39a9b4),this['startIsInclusive_']=!_0x39a9b4['startAfterSet_'],this['endIsInclusive_']=!_0x39a9b4['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3c0dc8){const _0x498e6c=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3c0dc8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3c0dc8)<0x0,_0x43fdd6=this['endIsInclusive_']?this['index_']['compare'](_0x3c0dc8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3c0dc8,this['getEndPost']())<0x0;return _0x498e6c&&_0x43fdd6;}['updateChild'](_0x2addf1,_0x1a5a67,_0x17ae56,_0x2c4994,_0x5655e4,_0x5691b8){return this['matches'](new E(_0x1a5a67,_0x17ae56))||(_0x17ae56=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2addf1,_0x1a5a67,_0x17ae56,_0x2c4994,_0x5655e4,_0x5691b8);}['updateFullNode'](_0x8aefb8,_0x593e3a,_0x597845){_0x593e3a['isLeafNode']()&&(_0x593e3a=g['EMPTY_NODE']);let _0x4347e1=_0x593e3a['withIndex'](this['index_']);_0x4347e1=_0x4347e1['updatePriority'](g['EMPTY_NODE']);const _0x5ba384=this;return _0x593e3a['forEachChild'](R,(_0x3f0696,_0x5f1d26)=>{_0x5ba384['matches'](new E(_0x3f0696,_0x5f1d26))||(_0x4347e1=_0x4347e1['updateImmediateChild'](_0x3f0696,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x8aefb8,_0x4347e1,_0x597845);}['updatePriority'](_0x353e6e,_0x174bf3){return _0x353e6e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x40bfa4){if(_0x40bfa4['hasStart']()){const _0x352498=_0x40bfa4['getIndexStartName']();return _0x40bfa4['getIndex']()['makePost'](_0x40bfa4['getIndexStartValue'](),_0x352498);}else return _0x40bfa4['getIndex']()['minPost']();}static['getEndPost_'](_0x1e7020){if(_0x1e7020['hasEnd']()){const _0x26d078=_0x1e7020['getIndexEndName']();return _0x1e7020['getIndex']()['makePost'](_0x1e7020['getIndexEndValue'](),_0x26d078);}else return _0x1e7020['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1e6190){this['withinDirectionalStart']=_0x336f93=>this['reverse_']?this['withinEndPost'](_0x336f93):this['withinStartPost'](_0x336f93),this['withinDirectionalEnd']=_0x5d3cf8=>this['reverse_']?this['withinStartPost'](_0x5d3cf8):this['withinEndPost'](_0x5d3cf8),this['withinStartPost']=_0x19ce86=>{const _0x4c9d2b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x19ce86);return this['startIsInclusive_']?_0x4c9d2b<=0x0:_0x4c9d2b<0x0;},this['withinEndPost']=_0x22c707=>{const _0x46509c=this['index_']['compare'](_0x22c707,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x46509c<=0x0:_0x46509c<0x0;},this['rangedFilter_']=new xt(_0x1e6190),this['index_']=_0x1e6190['getIndex'](),this['limit_']=_0x1e6190['getLimit'](),this['reverse_']=!_0x1e6190['isViewFromLeft'](),this['startIsInclusive_']=!_0x1e6190['startAfterSet_'],this['endIsInclusive_']=!_0x1e6190['endBeforeSet_'];}['updateChild'](_0x28142c,_0x17e6e2,_0x3dabc7,_0xff20da,_0x305bbc,_0x251931){return this['rangedFilter_']['matches'](new E(_0x17e6e2,_0x3dabc7))||(_0x3dabc7=g['EMPTY_NODE']),_0x28142c['getImmediateChild'](_0x17e6e2)['equals'](_0x3dabc7)?_0x28142c:_0x28142c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x28142c,_0x17e6e2,_0x3dabc7,_0xff20da,_0x305bbc,_0x251931):this['fullLimitUpdateChild_'](_0x28142c,_0x17e6e2,_0x3dabc7,_0x305bbc,_0x251931);}['updateFullNode'](_0x2779c8,_0x9f0216,_0x4614bd){let _0x37a19f;if(_0x9f0216['isLeafNode']()||_0x9f0216['isEmpty']())_0x37a19f=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x9f0216['numChildren']()&&_0x9f0216['isIndexed'](this['index_'])){_0x37a19f=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5176a0;this['reverse_']?_0x5176a0=_0x9f0216['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5176a0=_0x9f0216['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x80864b=0x0;for(;_0x5176a0['hasNext']()&&_0x80864b<this['limit_'];){const _0x4ed6d6=_0x5176a0['getNext']();if(this['withinDirectionalStart'](_0x4ed6d6)){if(this['withinDirectionalEnd'](_0x4ed6d6))_0x37a19f=_0x37a19f['updateImmediateChild'](_0x4ed6d6['name'],_0x4ed6d6['node']),_0x80864b++;else break;}else continue;}}else{_0x37a19f=_0x9f0216['withIndex'](this['index_']),_0x37a19f=_0x37a19f['updatePriority'](g['EMPTY_NODE']);let _0x31d77a;this['reverse_']?_0x31d77a=_0x37a19f['getReverseIterator'](this['index_']):_0x31d77a=_0x37a19f['getIterator'](this['index_']);let _0x3e0c1f=0x0;for(;_0x31d77a['hasNext']();){const _0x4ca83c=_0x31d77a['getNext']();_0x3e0c1f<this['limit_']&&this['withinDirectionalStart'](_0x4ca83c)&&this['withinDirectionalEnd'](_0x4ca83c)?_0x3e0c1f++:_0x37a19f=_0x37a19f['updateImmediateChild'](_0x4ca83c['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2779c8,_0x37a19f,_0x4614bd);}['updatePriority'](_0xbee1b0,_0x4b0b6a){return _0xbee1b0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xe4d30c,_0x3ceb84,_0x4f9e8b,_0xa36d93,_0xc969f5){let _0x5110f7;if(this['reverse_']){const _0x147006=this['index_']['getCompare']();_0x5110f7=(_0x37ad64,_0x24bc5c)=>_0x147006(_0x24bc5c,_0x37ad64);}else _0x5110f7=this['index_']['getCompare']();const _0x2f5de6=_0xe4d30c;f(_0x2f5de6['numChildren']()===this['limit_'],'');const _0x448857=new E(_0x3ceb84,_0x4f9e8b),_0x3d52d2=this['reverse_']?_0x2f5de6['getFirstChild'](this['index_']):_0x2f5de6['getLastChild'](this['index_']),_0x2fa8df=this['rangedFilter_']['matches'](_0x448857);if(_0x2f5de6['hasChild'](_0x3ceb84)){const _0xa56b6b=_0x2f5de6['getImmediateChild'](_0x3ceb84);let _0x371dc2=_0xa36d93['getChildAfterChild'](this['index_'],_0x3d52d2,this['reverse_']);for(;_0x371dc2!=null&&(_0x371dc2['name']===_0x3ceb84||_0x2f5de6['hasChild'](_0x371dc2['name']));)_0x371dc2=_0xa36d93['getChildAfterChild'](this['index_'],_0x371dc2,this['reverse_']);const _0x311ac2=_0x371dc2==null?0x1:_0x5110f7(_0x371dc2,_0x448857);if(_0x2fa8df&&!_0x4f9e8b['isEmpty']()&&_0x311ac2>=0x0)return _0xc969f5!=null&&_0xc969f5['trackChildChange'](Lt(_0x3ceb84,_0x4f9e8b,_0xa56b6b)),_0x2f5de6['updateImmediateChild'](_0x3ceb84,_0x4f9e8b);{_0xc969f5!=null&&_0xc969f5['trackChildChange'](Mt(_0x3ceb84,_0xa56b6b));const _0x43379f=_0x2f5de6['updateImmediateChild'](_0x3ceb84,g['EMPTY_NODE']);return _0x371dc2!=null&&this['rangedFilter_']['matches'](_0x371dc2)?(_0xc969f5!=null&&_0xc969f5['trackChildChange'](rt(_0x371dc2['name'],_0x371dc2['node'])),_0x43379f['updateImmediateChild'](_0x371dc2['name'],_0x371dc2['node'])):_0x43379f;}}else return _0x4f9e8b['isEmpty']()?_0xe4d30c:_0x2fa8df&&_0x5110f7(_0x3d52d2,_0x448857)>=0x0?(_0xc969f5!=null&&(_0xc969f5['trackChildChange'](Mt(_0x3d52d2['name'],_0x3d52d2['node'])),_0xc969f5['trackChildChange'](rt(_0x3ceb84,_0x4f9e8b))),_0x2f5de6['updateImmediateChild'](_0x3ceb84,_0x4f9e8b)['updateImmediateChild'](_0x3d52d2['name'],g['EMPTY_NODE'])):_0xe4d30c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x67fdc=new Zi();return _0x67fdc['limitSet_']=this['limitSet_'],_0x67fdc['limit_']=this['limit_'],_0x67fdc['startSet_']=this['startSet_'],_0x67fdc['startAfterSet_']=this['startAfterSet_'],_0x67fdc['indexStartValue_']=this['indexStartValue_'],_0x67fdc['startNameSet_']=this['startNameSet_'],_0x67fdc['indexStartName_']=this['indexStartName_'],_0x67fdc['endSet_']=this['endSet_'],_0x67fdc['endBeforeSet_']=this['endBeforeSet_'],_0x67fdc['indexEndValue_']=this['indexEndValue_'],_0x67fdc['endNameSet_']=this['endNameSet_'],_0x67fdc['indexEndName_']=this['indexEndName_'],_0x67fdc['index_']=this['index_'],_0x67fdc['viewFrom_']=this['viewFrom_'],_0x67fdc;}}function Kh(_0x4c35ed){return _0x4c35ed['loadsAllData']()?new Xi(_0x4c35ed['getIndex']()):_0x4c35ed['hasLimit']()?new jh(_0x4c35ed):new xt(_0x4c35ed);}function Yh(_0x23402a,_0x301e75,_0x33d54d){const _0x47e61e=_0x23402a['copy']();return _0x47e61e['startSet_']=!0x0,_0x301e75===void 0x0&&(_0x301e75=null),_0x47e61e['indexStartValue_']=_0x301e75,_0x33d54d!=null?(_0x47e61e['startNameSet_']=!0x0,_0x47e61e['indexStartName_']=_0x33d54d):(_0x47e61e['startNameSet_']=!0x1,_0x47e61e['indexStartName_']=''),_0x47e61e;}function Qh(_0x3398ca,_0x26d013,_0x2946fa){const _0x5cb677=_0x3398ca['copy']();return _0x5cb677['endSet_']=!0x0,_0x26d013===void 0x0&&(_0x26d013=null),_0x5cb677['indexEndValue_']=_0x26d013,_0x2946fa!==void 0x0?(_0x5cb677['endNameSet_']=!0x0,_0x5cb677['indexEndName_']=_0x2946fa):(_0x5cb677['endNameSet_']=!0x1,_0x5cb677['indexEndName_']=''),_0x5cb677;}function xo(_0x12d70e,_0x2b54cc){const _0x1e3f9f=_0x12d70e['copy']();return _0x1e3f9f['index_']=_0x2b54cc,_0x1e3f9f;}function ir(_0x42b88f){const _0x21db71={};if(_0x42b88f['isDefault']())return _0x21db71;let _0x4bbf1f;if(_0x42b88f['index_']===R?_0x4bbf1f='$priority':_0x42b88f['index_']===Mo?_0x4bbf1f='$value':_0x42b88f['index_']===ve?_0x4bbf1f='$key':(f(_0x42b88f['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4bbf1f=_0x42b88f['index_']['toString']()),_0x21db71['orderBy']=O(_0x4bbf1f),_0x42b88f['startSet_']){const _0x32c113=_0x42b88f['startAfterSet_']?'startAfter':'startAt';_0x21db71[_0x32c113]=O(_0x42b88f['indexStartValue_']),_0x42b88f['startNameSet_']&&(_0x21db71[_0x32c113]+=','+O(_0x42b88f['indexStartName_']));}if(_0x42b88f['endSet_']){const _0x5c3138=_0x42b88f['endBeforeSet_']?'endBefore':'endAt';_0x21db71[_0x5c3138]=O(_0x42b88f['indexEndValue_']),_0x42b88f['endNameSet_']&&(_0x21db71[_0x5c3138]+=','+O(_0x42b88f['indexEndName_']));}return _0x42b88f['limitSet_']&&(_0x42b88f['isViewFromLeft']()?_0x21db71['limitToFirst']=_0x42b88f['limit_']:_0x21db71['limitToLast']=_0x42b88f['limit_']),_0x21db71;}function sr(_0x3a6a62){const _0x2d69aa={};if(_0x3a6a62['startSet_']&&(_0x2d69aa['sp']=_0x3a6a62['indexStartValue_'],_0x3a6a62['startNameSet_']&&(_0x2d69aa['sn']=_0x3a6a62['indexStartName_']),_0x2d69aa['sin']=!_0x3a6a62['startAfterSet_']),_0x3a6a62['endSet_']&&(_0x2d69aa['ep']=_0x3a6a62['indexEndValue_'],_0x3a6a62['endNameSet_']&&(_0x2d69aa['en']=_0x3a6a62['indexEndName_']),_0x2d69aa['ein']=!_0x3a6a62['endBeforeSet_']),_0x3a6a62['limitSet_']){_0x2d69aa['l']=_0x3a6a62['limit_'];let _0x15c4f4=_0x3a6a62['viewFrom_'];_0x15c4f4===''&&(_0x3a6a62['isViewFromLeft']()?_0x15c4f4='l':_0x15c4f4='r'),_0x2d69aa['vf']=_0x15c4f4;}return _0x3a6a62['index_']!==R&&(_0x2d69aa['i']=_0x3a6a62['index_']['toString']()),_0x2d69aa;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x6f676d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x565605,_0x43a6e7){return _0x43a6e7!==void 0x0?'tag$'+_0x43a6e7:(f(_0x565605['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x565605['_path']['toString']());}constructor(_0x2c30e6,_0x398996,_0x37ba97,_0x22df21){super(),this['repoInfo_']=_0x2c30e6,this['onDataUpdate_']=_0x398996,this['authTokenProvider_']=_0x37ba97,this['appCheckTokenProvider_']=_0x22df21,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x4b121d,_0x520e9a,_0x2c150c,_0x5f17a4){const _0x443c2b=_0x4b121d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x443c2b+'\x20'+_0x4b121d['_queryIdentifier']);const _0x3b07cc=vn['getListenId_'](_0x4b121d,_0x2c150c),_0x38baf1={};this['listens_'][_0x3b07cc]=_0x38baf1;const _0x265b79=ir(_0x4b121d['_queryParams']);this['restRequest_'](_0x443c2b+'.json',_0x265b79,(_0x26b362,_0x2119b6)=>{let _0x2dfb5c=_0x2119b6;if(_0x26b362===0x194&&(_0x2dfb5c=null,_0x26b362=null),_0x26b362===null&&this['onDataUpdate_'](_0x443c2b,_0x2dfb5c,!0x1,_0x2c150c),Me(this['listens_'],_0x3b07cc)===_0x38baf1){let _0x3aca2d;_0x26b362?_0x26b362===0x191?_0x3aca2d='permission_denied':_0x3aca2d='rest_error:'+_0x26b362:_0x3aca2d='ok',_0x5f17a4(_0x3aca2d,null);}});}['unlisten'](_0x361d2b,_0x133da9){const _0x5e115f=vn['getListenId_'](_0x361d2b,_0x133da9);delete this['listens_'][_0x5e115f];}['get'](_0x5c3d61){const _0x18c17d=ir(_0x5c3d61['_queryParams']),_0xf65974=_0x5c3d61['_path']['toString'](),_0x1aa557=new H();return this['restRequest_'](_0xf65974+'.json',_0x18c17d,(_0x118944,_0x421957)=>{let _0x3fe0d9=_0x421957;_0x118944===0x194&&(_0x3fe0d9=null,_0x118944=null),_0x118944===null?(this['onDataUpdate_'](_0xf65974,_0x3fe0d9,!0x1,null),_0x1aa557['resolve'](_0x3fe0d9)):_0x1aa557['reject'](new Error(_0x3fe0d9));}),_0x1aa557['promise'];}['refreshAuthToken'](_0x937895){}['restRequest_'](_0xb4a6f8,_0x23dd36={},_0x34d0d1){return _0x23dd36['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x441c31,_0xe33abf])=>{_0x441c31&&_0x441c31['accessToken']&&(_0x23dd36['auth']=_0x441c31['accessToken']),_0xe33abf&&_0xe33abf['token']&&(_0x23dd36['ac']=_0xe33abf['token']);const _0x25ac4f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xb4a6f8+'?ns='+this['repoInfo_']['namespace']+ut(_0x23dd36);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x25ac4f);const _0x3e6a89=new XMLHttpRequest();_0x3e6a89['onreadystatechange']=()=>{if(_0x34d0d1&&_0x3e6a89['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x25ac4f+'\x20received.\x20status:',_0x3e6a89['status'],'response:',_0x3e6a89['responseText']);let _0x11b110=null;if(_0x3e6a89['status']>=0xc8&&_0x3e6a89['status']<0x12c){try{_0x11b110=Nt(_0x3e6a89['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x25ac4f+':\x20'+_0x3e6a89['responseText']);}_0x34d0d1(null,_0x11b110);}else _0x3e6a89['status']!==0x191&&_0x3e6a89['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x25ac4f+'\x20Status:\x20'+_0x3e6a89['status']),_0x34d0d1(_0x3e6a89['status']);_0x34d0d1=null;}},_0x3e6a89['open']('GET',_0x25ac4f,!0x0),_0x3e6a89['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3f1c0a){return this['rootNode_']['getChild'](_0x3f1c0a);}['updateSnapshot'](_0x28d71c,_0xdea478){this['rootNode_']=this['rootNode_']['updateChild'](_0x28d71c,_0xdea478);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x5801fa,_0x3d01e0,_0x1d2d64){if(v(_0x3d01e0))_0x5801fa['value']=_0x1d2d64,_0x5801fa['children']['clear']();else{if(_0x5801fa['value']!==null)_0x5801fa['value']=_0x5801fa['value']['updateChild'](_0x3d01e0,_0x1d2d64);else{const _0x3afdd6=y(_0x3d01e0);_0x5801fa['children']['has'](_0x3afdd6)||_0x5801fa['children']['set'](_0x3afdd6,En());const _0x10cea2=_0x5801fa['children']['get'](_0x3afdd6);_0x3d01e0=S(_0x3d01e0),pt(_0x10cea2,_0x3d01e0,_0x1d2d64);}}}function Ti(_0x3affd5,_0x2b5b5a){if(v(_0x2b5b5a))return _0x3affd5['value']=null,_0x3affd5['children']['clear'](),!0x0;if(_0x3affd5['value']!==null){if(_0x3affd5['value']['isLeafNode']())return!0x1;{const _0x509482=_0x3affd5['value'];return _0x3affd5['value']=null,_0x509482['forEachChild'](R,(_0x282cd3,_0x8287da)=>{pt(_0x3affd5,new C(_0x282cd3),_0x8287da);}),Ti(_0x3affd5,_0x2b5b5a);}}else{if(_0x3affd5['children']['size']>0x0){const _0x5925cb=y(_0x2b5b5a);return _0x2b5b5a=S(_0x2b5b5a),_0x3affd5['children']['has'](_0x5925cb)&&Ti(_0x3affd5['children']['get'](_0x5925cb),_0x2b5b5a)&&_0x3affd5['children']['delete'](_0x5925cb),_0x3affd5['children']['size']===0x0;}else return!0x0;}}function Si(_0x7fd62f,_0x2a1073,_0x1bfff7){_0x7fd62f['value']!==null?_0x1bfff7(_0x2a1073,_0x7fd62f['value']):Xh(_0x7fd62f,(_0x5408f9,_0x8940ba)=>{const _0xfd9916=new C(_0x2a1073['toString']()+'/'+_0x5408f9);Si(_0x8940ba,_0xfd9916,_0x1bfff7);});}function Xh(_0x36153a,_0x3a10ca){_0x36153a['children']['forEach']((_0x2a0230,_0x22a089)=>{_0x3a10ca(_0x22a089,_0x2a0230);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x9043a0){this['collection_']=_0x9043a0,this['last_']=null;}['get'](){const _0x545dca=this['collection_']['get'](),_0x362813={..._0x545dca};return this['last_']&&x(this['last_'],(_0x54ad86,_0x22ea4c)=>{_0x362813[_0x54ad86]=_0x362813[_0x54ad86]-_0x22ea4c;}),this['last_']=_0x545dca,_0x362813;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x25a796,_0x331805){this['server_']=_0x331805,this['statsToReport_']={},this['statsListener_']=new Zh(_0x25a796);const _0x2fc234=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x2fc234));}['reportStats_'](){const _0x301dcd=this['statsListener_']['get'](),_0x3e30b6={};let _0x27a7d2=!0x1;x(_0x301dcd,(_0x33af5c,_0x4af574)=>{_0x4af574>0x0&&Q(this['statsToReport_'],_0x33af5c)&&(_0x3e30b6[_0x33af5c]=_0x4af574,_0x27a7d2=!0x0);}),_0x27a7d2&&this['server_']['reportStats'](_0x3e30b6),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2e9afc){_0x2e9afc[_0x2e9afc['OVERWRITE']=0x0]='OVERWRITE',_0x2e9afc[_0x2e9afc['MERGE']=0x1]='MERGE',_0x2e9afc[_0x2e9afc['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2e9afc[_0x2e9afc['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1190eb){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1190eb,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x3f33e7,_0x38f30f,_0x1faf15){this['path']=_0x3f33e7,this['affectedTree']=_0x38f30f,this['revert']=_0x1faf15,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x28e7b3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x32b523=this['affectedTree']['subtree'](new C(_0x28e7b3));return new In(w(),_0x32b523,this['revert']);}}else return f(y(this['path'])===_0x28e7b3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x26cf90,_0x1ff453){this['source']=_0x26cf90,this['path']=_0x1ff453,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x445f8e){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x11370a,_0x5ee01f,_0x2019b6){this['source']=_0x11370a,this['path']=_0x5ee01f,this['snap']=_0x2019b6,this['type']=z['OVERWRITE'];}['operationForChild'](_0x10e31d){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x10e31d)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x26b6d0,_0x5bed27,_0x34243e){this['source']=_0x26b6d0,this['path']=_0x5bed27,this['children']=_0x34243e,this['type']=z['MERGE'];}['operationForChild'](_0x26f80c){if(v(this['path'])){const _0x121895=this['children']['subtree'](new C(_0x26f80c));return _0x121895['isEmpty']()?null:_0x121895['value']?new We(this['source'],w(),_0x121895['value']):new ot(this['source'],w(),_0x121895);}else return f(y(this['path'])===_0x26f80c,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x1cad7e,_0x9ca4b5,_0x4b5d68){this['node_']=_0x1cad7e,this['fullyInitialized_']=_0x9ca4b5,this['filtered_']=_0x4b5d68;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x487277){if(v(_0x487277))return this['isFullyInitialized']()&&!this['filtered_'];const _0xd2ded5=y(_0x487277);return this['isCompleteForChild'](_0xd2ded5);}['isCompleteForChild'](_0xc8012d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0xc8012d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0x4a175d){this['query_']=_0x4a175d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x3f0a2c,_0x2b1df1,_0x5b3a55,_0x3b2fe0){const _0x24af4b=[],_0x1f289e=[];return _0x2b1df1['forEach'](_0x4e438b=>{_0x4e438b['type']==='child_changed'&&_0x3f0a2c['index_']['indexedValueChanged'](_0x4e438b['oldSnap'],_0x4e438b['snapshotNode'])&&_0x1f289e['push'](zh(_0x4e438b['childName'],_0x4e438b['snapshotNode']));}),It(_0x3f0a2c,_0x24af4b,'child_removed',_0x2b1df1,_0x3b2fe0,_0x5b3a55),It(_0x3f0a2c,_0x24af4b,'child_added',_0x2b1df1,_0x3b2fe0,_0x5b3a55),It(_0x3f0a2c,_0x24af4b,'child_moved',_0x1f289e,_0x3b2fe0,_0x5b3a55),It(_0x3f0a2c,_0x24af4b,'child_changed',_0x2b1df1,_0x3b2fe0,_0x5b3a55),It(_0x3f0a2c,_0x24af4b,'value',_0x2b1df1,_0x3b2fe0,_0x5b3a55),_0x24af4b;}function It(_0x237e8a,_0x1940fa,_0x5469ad,_0x1dad19,_0x573eac,_0x1f1592){const _0x3c2aa5=_0x1dad19['filter'](_0xb31f59=>_0xb31f59['type']===_0x5469ad);_0x3c2aa5['sort']((_0x284463,_0xce8ec3)=>ou(_0x237e8a,_0x284463,_0xce8ec3)),_0x3c2aa5['forEach'](_0x390c81=>{const _0x13f5db=ru(_0x237e8a,_0x390c81,_0x1f1592);_0x573eac['forEach'](_0x1bd43f=>{_0x1bd43f['respondsTo'](_0x390c81['type'])&&_0x1940fa['push'](_0x1bd43f['createEvent'](_0x13f5db,_0x237e8a['query_']));});});}function ru(_0x5e2f6c,_0x592639,_0x259bb9){return _0x592639['type']==='value'||_0x592639['type']==='child_removed'||(_0x592639['prevName']=_0x259bb9['getPredecessorChildName'](_0x592639['childName'],_0x592639['snapshotNode'],_0x5e2f6c['index_'])),_0x592639;}function ou(_0x5b8d7f,_0x23a59d,_0x43c5e0){if(_0x23a59d['childName']==null||_0x43c5e0['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x36244c=new E(_0x23a59d['childName'],_0x23a59d['snapshotNode']),_0x185f09=new E(_0x43c5e0['childName'],_0x43c5e0['snapshotNode']);return _0x5b8d7f['index_']['compare'](_0x36244c,_0x185f09);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2e29e9,_0x15c39c){return{'eventCache':_0x2e29e9,'serverCache':_0x15c39c};}function bt(_0x46fd50,_0x10c1bd,_0x5e26a0,_0x665496){return Un(new Te(_0x10c1bd,_0x5e26a0,_0x665496),_0x46fd50['serverCache']);}function Fo(_0x370e22,_0x42ce64,_0x3ede76,_0x3bb09e){return Un(_0x370e22['eventCache'],new Te(_0x42ce64,_0x3ede76,_0x3bb09e));}function wn(_0x188d70){return _0x188d70['eventCache']['isFullyInitialized']()?_0x188d70['eventCache']['getNode']():null;}function Be(_0x447b48){return _0x447b48['serverCache']['isFullyInitialized']()?_0x447b48['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x5a6fcb){let _0x5502ec=new b(null);return x(_0x5a6fcb,(_0xeec92,_0x21fb38)=>{_0x5502ec=_0x5502ec['set'](new C(_0xeec92),_0x21fb38);}),_0x5502ec;}constructor(_0x4ad577,_0x1acde6=au()){this['value']=_0x4ad577,this['children']=_0x1acde6;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3a1243,_0x5e8574){if(this['value']!=null&&_0x5e8574(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3a1243))return null;{const _0x271907=y(_0x3a1243),_0x15982=this['children']['get'](_0x271907);if(_0x15982!==null){const _0x10419e=_0x15982['findRootMostMatchingPathAndValue'](S(_0x3a1243),_0x5e8574);return _0x10419e!=null?{'path':k(new C(_0x271907),_0x10419e['path']),'value':_0x10419e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5bf37c){return this['findRootMostMatchingPathAndValue'](_0x5bf37c,()=>!0x0);}['subtree'](_0x270e1e){if(v(_0x270e1e))return this;{const _0x2b46e6=y(_0x270e1e),_0x350298=this['children']['get'](_0x2b46e6);return _0x350298!==null?_0x350298['subtree'](S(_0x270e1e)):new b(null);}}['set'](_0x55e2ea,_0x5ad5e1){if(v(_0x55e2ea))return new b(_0x5ad5e1,this['children']);{const _0x46f90e=y(_0x55e2ea),_0x41705a=(this['children']['get'](_0x46f90e)||new b(null))['set'](S(_0x55e2ea),_0x5ad5e1),_0x53a7aa=this['children']['insert'](_0x46f90e,_0x41705a);return new b(this['value'],_0x53a7aa);}}['remove'](_0x50db87){if(v(_0x50db87))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x7d594f=y(_0x50db87),_0x369eb1=this['children']['get'](_0x7d594f);if(_0x369eb1){const _0x266bd3=_0x369eb1['remove'](S(_0x50db87));let _0x2714f4;return _0x266bd3['isEmpty']()?_0x2714f4=this['children']['remove'](_0x7d594f):_0x2714f4=this['children']['insert'](_0x7d594f,_0x266bd3),this['value']===null&&_0x2714f4['isEmpty']()?new b(null):new b(this['value'],_0x2714f4);}else return this;}}['get'](_0x34df55){if(v(_0x34df55))return this['value'];{const _0x3e6ac5=y(_0x34df55),_0x370688=this['children']['get'](_0x3e6ac5);return _0x370688?_0x370688['get'](S(_0x34df55)):null;}}['setTree'](_0x346c17,_0x224236){if(v(_0x346c17))return _0x224236;{const _0x31de46=y(_0x346c17),_0x41cbe7=(this['children']['get'](_0x31de46)||new b(null))['setTree'](S(_0x346c17),_0x224236);let _0x3e7d8f;return _0x41cbe7['isEmpty']()?_0x3e7d8f=this['children']['remove'](_0x31de46):_0x3e7d8f=this['children']['insert'](_0x31de46,_0x41cbe7),new b(this['value'],_0x3e7d8f);}}['fold'](_0x460916){return this['fold_'](w(),_0x460916);}['fold_'](_0x3c0112,_0x575d8e){const _0x181df6={};return this['children']['inorderTraversal']((_0x2d1c75,_0x22dd0a)=>{_0x181df6[_0x2d1c75]=_0x22dd0a['fold_'](k(_0x3c0112,_0x2d1c75),_0x575d8e);}),_0x575d8e(_0x3c0112,this['value'],_0x181df6);}['findOnPath'](_0x415775,_0x4bc08c){return this['findOnPath_'](_0x415775,w(),_0x4bc08c);}['findOnPath_'](_0x284eeb,_0x5a4496,_0x12fb32){const _0x1e3583=this['value']?_0x12fb32(_0x5a4496,this['value']):!0x1;if(_0x1e3583)return _0x1e3583;if(v(_0x284eeb))return null;{const _0x3ed64e=y(_0x284eeb),_0x5913d0=this['children']['get'](_0x3ed64e);return _0x5913d0?_0x5913d0['findOnPath_'](S(_0x284eeb),k(_0x5a4496,_0x3ed64e),_0x12fb32):null;}}['foreachOnPath'](_0xea743d,_0x38c466){return this['foreachOnPath_'](_0xea743d,w(),_0x38c466);}['foreachOnPath_'](_0x287415,_0x36e26d,_0x41fa43){if(v(_0x287415))return this;{this['value']&&_0x41fa43(_0x36e26d,this['value']);const _0x31eade=y(_0x287415),_0x38f8ac=this['children']['get'](_0x31eade);return _0x38f8ac?_0x38f8ac['foreachOnPath_'](S(_0x287415),k(_0x36e26d,_0x31eade),_0x41fa43):new b(null);}}['foreach'](_0x32e1c6){this['foreach_'](w(),_0x32e1c6);}['foreach_'](_0x318a80,_0xf965e2){this['children']['inorderTraversal']((_0x581645,_0x4b3cb2)=>{_0x4b3cb2['foreach_'](k(_0x318a80,_0x581645),_0xf965e2);}),this['value']&&_0xf965e2(_0x318a80,this['value']);}['foreachChild'](_0x40de7f){this['children']['inorderTraversal']((_0x34d6bc,_0x255f81)=>{_0x255f81['value']&&_0x40de7f(_0x34d6bc,_0x255f81['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x2b458c){this['writeTree_']=_0x2b458c;}static['empty'](){return new K(new b(null));}}function Rt(_0x450d57,_0x1c0e0d,_0x4a2b8f){if(v(_0x1c0e0d))return new K(new b(_0x4a2b8f));{const _0x453a20=_0x450d57['writeTree_']['findRootMostValueAndPath'](_0x1c0e0d);if(_0x453a20!=null){const _0x249ab0=_0x453a20['path'];let _0x1b3a2f=_0x453a20['value'];const _0x2d7f08=F(_0x249ab0,_0x1c0e0d);return _0x1b3a2f=_0x1b3a2f['updateChild'](_0x2d7f08,_0x4a2b8f),new K(_0x450d57['writeTree_']['set'](_0x249ab0,_0x1b3a2f));}else{const _0x5bfbdd=new b(_0x4a2b8f),_0x5ae2b1=_0x450d57['writeTree_']['setTree'](_0x1c0e0d,_0x5bfbdd);return new K(_0x5ae2b1);}}}function bi(_0xd3da6c,_0x3bf68e,_0x210d44){let _0x54990f=_0xd3da6c;return x(_0x210d44,(_0x57b52f,_0x53759e)=>{_0x54990f=Rt(_0x54990f,k(_0x3bf68e,_0x57b52f),_0x53759e);}),_0x54990f;}function or(_0x5db8ea,_0x189d47){if(v(_0x189d47))return K['empty']();{const _0x386263=_0x5db8ea['writeTree_']['setTree'](_0x189d47,new b(null));return new K(_0x386263);}}function Ri(_0x444172,_0x491ca4){return qe(_0x444172,_0x491ca4)!=null;}function qe(_0x5b1a97,_0x51caa8){const _0x392efc=_0x5b1a97['writeTree_']['findRootMostValueAndPath'](_0x51caa8);return _0x392efc!=null?_0x5b1a97['writeTree_']['get'](_0x392efc['path'])['getChild'](F(_0x392efc['path'],_0x51caa8)):null;}function ar(_0x237d8e){const _0x4e8386=[],_0x5c2002=_0x237d8e['writeTree_']['value'];return _0x5c2002!=null?_0x5c2002['isLeafNode']()||_0x5c2002['forEachChild'](R,(_0x22e9a4,_0x76aec)=>{_0x4e8386['push'](new E(_0x22e9a4,_0x76aec));}):_0x237d8e['writeTree_']['children']['inorderTraversal']((_0x42135d,_0xbce951)=>{_0xbce951['value']!=null&&_0x4e8386['push'](new E(_0x42135d,_0xbce951['value']));}),_0x4e8386;}function Ee(_0x4a34ca,_0x37e80b){if(v(_0x37e80b))return _0x4a34ca;{const _0x59fdd5=qe(_0x4a34ca,_0x37e80b);return _0x59fdd5!=null?new K(new b(_0x59fdd5)):new K(_0x4a34ca['writeTree_']['subtree'](_0x37e80b));}}function Ai(_0x6f1b14){return _0x6f1b14['writeTree_']['isEmpty']();}function at(_0x353f86,_0x450ff4){return Uo(w(),_0x353f86['writeTree_'],_0x450ff4);}function Uo(_0x18bd9c,_0x506023,_0x36b677){if(_0x506023['value']!=null)return _0x36b677['updateChild'](_0x18bd9c,_0x506023['value']);{let _0x2dc0e6=null;return _0x506023['children']['inorderTraversal']((_0x43b22a,_0x10385e)=>{_0x43b22a==='.priority'?(f(_0x10385e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2dc0e6=_0x10385e['value']):_0x36b677=Uo(k(_0x18bd9c,_0x43b22a),_0x10385e,_0x36b677);}),!_0x36b677['getChild'](_0x18bd9c)['isEmpty']()&&_0x2dc0e6!==null&&(_0x36b677=_0x36b677['updateChild'](k(_0x18bd9c,'.priority'),_0x2dc0e6)),_0x36b677;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x2cddad,_0x736823){return Ho(_0x736823,_0x2cddad);}function cu(_0x3815ce,_0x4765af,_0x2ad974,_0x23f164,_0x459095){f(_0x23f164>_0x3815ce['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x459095===void 0x0&&(_0x459095=!0x0),_0x3815ce['allWrites']['push']({'path':_0x4765af,'snap':_0x2ad974,'writeId':_0x23f164,'visible':_0x459095}),_0x459095&&(_0x3815ce['visibleWrites']=Rt(_0x3815ce['visibleWrites'],_0x4765af,_0x2ad974)),_0x3815ce['lastWriteId']=_0x23f164;}function lu(_0x5eac03,_0x3f81b1,_0x473eb5,_0x14fd5f){f(_0x14fd5f>_0x5eac03['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5eac03['allWrites']['push']({'path':_0x3f81b1,'children':_0x473eb5,'writeId':_0x14fd5f,'visible':!0x0}),_0x5eac03['visibleWrites']=bi(_0x5eac03['visibleWrites'],_0x3f81b1,_0x473eb5),_0x5eac03['lastWriteId']=_0x14fd5f;}function hu(_0x451106,_0x55020d){for(let _0x191b2b=0x0;_0x191b2b<_0x451106['allWrites']['length'];_0x191b2b++){const _0x57c93e=_0x451106['allWrites'][_0x191b2b];if(_0x57c93e['writeId']===_0x55020d)return _0x57c93e;}return null;}function uu(_0x1669e3,_0x13c394){const _0x672488=_0x1669e3['allWrites']['findIndex'](_0x316432=>_0x316432['writeId']===_0x13c394);f(_0x672488>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x20d5a2=_0x1669e3['allWrites'][_0x672488];_0x1669e3['allWrites']['splice'](_0x672488,0x1);let _0x5071fa=_0x20d5a2['visible'],_0x3f447b=!0x1,_0x39edde=_0x1669e3['allWrites']['length']-0x1;for(;_0x5071fa&&_0x39edde>=0x0;){const _0x1a87e3=_0x1669e3['allWrites'][_0x39edde];_0x1a87e3['visible']&&(_0x39edde>=_0x672488&&du(_0x1a87e3,_0x20d5a2['path'])?_0x5071fa=!0x1:G(_0x20d5a2['path'],_0x1a87e3['path'])&&(_0x3f447b=!0x0)),_0x39edde--;}if(_0x5071fa){if(_0x3f447b)return fu(_0x1669e3),!0x0;if(_0x20d5a2['snap'])_0x1669e3['visibleWrites']=or(_0x1669e3['visibleWrites'],_0x20d5a2['path']);else{const _0xa1d046=_0x20d5a2['children'];x(_0xa1d046,_0x35c35e=>{_0x1669e3['visibleWrites']=or(_0x1669e3['visibleWrites'],k(_0x20d5a2['path'],_0x35c35e));});}return!0x0;}else return!0x1;}function du(_0x57717f,_0x24c72d){if(_0x57717f['snap'])return G(_0x57717f['path'],_0x24c72d);for(const _0x5e029c in _0x57717f['children'])if(_0x57717f['children']['hasOwnProperty'](_0x5e029c)&&G(k(_0x57717f['path'],_0x5e029c),_0x24c72d))return!0x0;return!0x1;}function fu(_0x5dde40){_0x5dde40['visibleWrites']=Wo(_0x5dde40['allWrites'],pu,w()),_0x5dde40['allWrites']['length']>0x0?_0x5dde40['lastWriteId']=_0x5dde40['allWrites'][_0x5dde40['allWrites']['length']-0x1]['writeId']:_0x5dde40['lastWriteId']=-0x1;}function pu(_0x1610b8){return _0x1610b8['visible'];}function Wo(_0x3ec81e,_0x36ba8c,_0x32f6cd){let _0x364073=K['empty']();for(let _0x46c4bf=0x0;_0x46c4bf<_0x3ec81e['length'];++_0x46c4bf){const _0x51ee03=_0x3ec81e[_0x46c4bf];if(_0x36ba8c(_0x51ee03)){const _0x115e1c=_0x51ee03['path'];let _0x3d15ab;if(_0x51ee03['snap'])G(_0x32f6cd,_0x115e1c)?(_0x3d15ab=F(_0x32f6cd,_0x115e1c),_0x364073=Rt(_0x364073,_0x3d15ab,_0x51ee03['snap'])):G(_0x115e1c,_0x32f6cd)&&(_0x3d15ab=F(_0x115e1c,_0x32f6cd),_0x364073=Rt(_0x364073,w(),_0x51ee03['snap']['getChild'](_0x3d15ab)));else{if(_0x51ee03['children']){if(G(_0x32f6cd,_0x115e1c))_0x3d15ab=F(_0x32f6cd,_0x115e1c),_0x364073=bi(_0x364073,_0x3d15ab,_0x51ee03['children']);else{if(G(_0x115e1c,_0x32f6cd)){if(_0x3d15ab=F(_0x115e1c,_0x32f6cd),v(_0x3d15ab))_0x364073=bi(_0x364073,w(),_0x51ee03['children']);else{const _0x4b83ed=Me(_0x51ee03['children'],y(_0x3d15ab));if(_0x4b83ed){const _0x12e032=_0x4b83ed['getChild'](S(_0x3d15ab));_0x364073=Rt(_0x364073,w(),_0x12e032);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x364073;}function Bo(_0x563435,_0x2bad6e,_0x3f919a,_0x1c1b17,_0x5812e2){if(!_0x1c1b17&&!_0x5812e2){const _0x23f337=qe(_0x563435['visibleWrites'],_0x2bad6e);if(_0x23f337!=null)return _0x23f337;{const _0x410d5c=Ee(_0x563435['visibleWrites'],_0x2bad6e);if(Ai(_0x410d5c))return _0x3f919a;if(_0x3f919a==null&&!Ri(_0x410d5c,w()))return null;{const _0x53674e=_0x3f919a||g['EMPTY_NODE'];return at(_0x410d5c,_0x53674e);}}}else{const _0x25e9d1=Ee(_0x563435['visibleWrites'],_0x2bad6e);if(!_0x5812e2&&Ai(_0x25e9d1))return _0x3f919a;if(!_0x5812e2&&_0x3f919a==null&&!Ri(_0x25e9d1,w()))return null;{const _0x32d68e=function(_0x4b5d6f){return(_0x4b5d6f['visible']||_0x5812e2)&&(!_0x1c1b17||!~_0x1c1b17['indexOf'](_0x4b5d6f['writeId']))&&(G(_0x4b5d6f['path'],_0x2bad6e)||G(_0x2bad6e,_0x4b5d6f['path']));},_0x55d1ac=Wo(_0x563435['allWrites'],_0x32d68e,_0x2bad6e),_0x134dae=_0x3f919a||g['EMPTY_NODE'];return at(_0x55d1ac,_0x134dae);}}}function _u(_0x26fb49,_0x256d42,_0x372cf9){let _0x4145c1=g['EMPTY_NODE'];const _0x123b37=qe(_0x26fb49['visibleWrites'],_0x256d42);if(_0x123b37)return _0x123b37['isLeafNode']()||_0x123b37['forEachChild'](R,(_0x4f7249,_0x4d2d16)=>{_0x4145c1=_0x4145c1['updateImmediateChild'](_0x4f7249,_0x4d2d16);}),_0x4145c1;if(_0x372cf9){const _0x5811ae=Ee(_0x26fb49['visibleWrites'],_0x256d42);return _0x372cf9['forEachChild'](R,(_0x3af516,_0x12bb15)=>{const _0x174d68=at(Ee(_0x5811ae,new C(_0x3af516)),_0x12bb15);_0x4145c1=_0x4145c1['updateImmediateChild'](_0x3af516,_0x174d68);}),ar(_0x5811ae)['forEach'](_0x58f082=>{_0x4145c1=_0x4145c1['updateImmediateChild'](_0x58f082['name'],_0x58f082['node']);}),_0x4145c1;}else{const _0x44e0e0=Ee(_0x26fb49['visibleWrites'],_0x256d42);return ar(_0x44e0e0)['forEach'](_0x866a8d=>{_0x4145c1=_0x4145c1['updateImmediateChild'](_0x866a8d['name'],_0x866a8d['node']);}),_0x4145c1;}}function gu(_0x256ace,_0x1a3079,_0x1c2f45,_0x39ba44,_0x1a0b4c){f(_0x39ba44||_0x1a0b4c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3b6a10=k(_0x1a3079,_0x1c2f45);if(Ri(_0x256ace['visibleWrites'],_0x3b6a10))return null;{const _0x30a6ec=Ee(_0x256ace['visibleWrites'],_0x3b6a10);return Ai(_0x30a6ec)?_0x1a0b4c['getChild'](_0x1c2f45):at(_0x30a6ec,_0x1a0b4c['getChild'](_0x1c2f45));}}function mu(_0x22f98a,_0x3c977f,_0x4a36f7,_0x5b2d34){const _0x1398c3=k(_0x3c977f,_0x4a36f7),_0x47c9be=qe(_0x22f98a['visibleWrites'],_0x1398c3);if(_0x47c9be!=null)return _0x47c9be;if(_0x5b2d34['isCompleteForChild'](_0x4a36f7)){const _0x30e67e=Ee(_0x22f98a['visibleWrites'],_0x1398c3);return at(_0x30e67e,_0x5b2d34['getNode']()['getImmediateChild'](_0x4a36f7));}else return null;}function yu(_0x33c19f,_0x5e607c){return qe(_0x33c19f['visibleWrites'],_0x5e607c);}function vu(_0x4e7509,_0x57d917,_0x28cd50,_0x2561b4,_0x3ed5f5,_0x8febe6,_0xc3a283){let _0x59c0c6;const _0x58c9a4=Ee(_0x4e7509['visibleWrites'],_0x57d917),_0x5baf29=qe(_0x58c9a4,w());if(_0x5baf29!=null)_0x59c0c6=_0x5baf29;else{if(_0x28cd50!=null)_0x59c0c6=at(_0x58c9a4,_0x28cd50);else return[];}if(_0x59c0c6=_0x59c0c6['withIndex'](_0xc3a283),!_0x59c0c6['isEmpty']()&&!_0x59c0c6['isLeafNode']()){const _0x466f5c=[],_0x2b6eda=_0xc3a283['getCompare'](),_0x102fa3=_0x8febe6?_0x59c0c6['getReverseIteratorFrom'](_0x2561b4,_0xc3a283):_0x59c0c6['getIteratorFrom'](_0x2561b4,_0xc3a283);let _0x45452=_0x102fa3['getNext']();for(;_0x45452&&_0x466f5c['length']<_0x3ed5f5;)_0x2b6eda(_0x45452,_0x2561b4)!==0x0&&_0x466f5c['push'](_0x45452),_0x45452=_0x102fa3['getNext']();return _0x466f5c;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x58748c,_0x42c074,_0x52cf00,_0x3304de){return Bo(_0x58748c['writeTree'],_0x58748c['treePath'],_0x42c074,_0x52cf00,_0x3304de);}function is(_0x45b1e7,_0x3ef65c){return _u(_0x45b1e7['writeTree'],_0x45b1e7['treePath'],_0x3ef65c);}function cr(_0x372f32,_0x215349,_0x22c104,_0x34350c){return gu(_0x372f32['writeTree'],_0x372f32['treePath'],_0x215349,_0x22c104,_0x34350c);}function Tn(_0x270206,_0x28f361){return yu(_0x270206['writeTree'],k(_0x270206['treePath'],_0x28f361));}function Iu(_0x44852a,_0x35c4fa,_0x30b643,_0x165bb3,_0x486aa6,_0x2c7aff){return vu(_0x44852a['writeTree'],_0x44852a['treePath'],_0x35c4fa,_0x30b643,_0x165bb3,_0x486aa6,_0x2c7aff);}function ss(_0x5e4c8c,_0x3f74b1,_0x32bec8){return mu(_0x5e4c8c['writeTree'],_0x5e4c8c['treePath'],_0x3f74b1,_0x32bec8);}function Vo(_0x4ab935,_0x464c3b){return Ho(k(_0x4ab935['treePath'],_0x464c3b),_0x4ab935['writeTree']);}function Ho(_0x546b5d,_0xaf36be){return{'treePath':_0x546b5d,'writeTree':_0xaf36be};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x48dc1b){const _0x38487a=_0x48dc1b['type'],_0xe0db03=_0x48dc1b['childName'];f(_0x38487a==='child_added'||_0x38487a==='child_changed'||_0x38487a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xe0db03!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x39902f=this['changeMap']['get'](_0xe0db03);if(_0x39902f){const _0x223d7f=_0x39902f['type'];if(_0x38487a==='child_added'&&_0x223d7f==='child_removed')this['changeMap']['set'](_0xe0db03,Lt(_0xe0db03,_0x48dc1b['snapshotNode'],_0x39902f['snapshotNode']));else{if(_0x38487a==='child_removed'&&_0x223d7f==='child_added')this['changeMap']['delete'](_0xe0db03);else{if(_0x38487a==='child_removed'&&_0x223d7f==='child_changed')this['changeMap']['set'](_0xe0db03,Mt(_0xe0db03,_0x39902f['oldSnap']));else{if(_0x38487a==='child_changed'&&_0x223d7f==='child_added')this['changeMap']['set'](_0xe0db03,rt(_0xe0db03,_0x48dc1b['snapshotNode']));else{if(_0x38487a==='child_changed'&&_0x223d7f==='child_changed')this['changeMap']['set'](_0xe0db03,Lt(_0xe0db03,_0x48dc1b['snapshotNode'],_0x39902f['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x48dc1b+'\x20occurred\x20after\x20'+_0x39902f);}}}}}else this['changeMap']['set'](_0xe0db03,_0x48dc1b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x40bd70){return null;}['getChildAfterChild'](_0x278497,_0x546b42,_0xc06948){return null;}}const $o=new Cu();class rs{constructor(_0x2f9670,_0x4c6512,_0x4e5a92=null){this['writes_']=_0x2f9670,this['viewCache_']=_0x4c6512,this['optCompleteServerCache_']=_0x4e5a92;}['getCompleteChild'](_0x573b4c){const _0x1f87dc=this['viewCache_']['eventCache'];if(_0x1f87dc['isCompleteForChild'](_0x573b4c))return _0x1f87dc['getNode']()['getImmediateChild'](_0x573b4c);{const _0x49c24e=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x573b4c,_0x49c24e);}}['getChildAfterChild'](_0x1424d0,_0x18eaa3,_0x3cb955){const _0x56b68f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x25aaca=Iu(this['writes_'],_0x56b68f,_0x18eaa3,0x1,_0x3cb955,_0x1424d0);return _0x25aaca['length']===0x0?null:_0x25aaca[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x2b8a8d){return{'filter':_0x2b8a8d};}function Su(_0x1a37e7,_0x76a6b7){f(_0x76a6b7['eventCache']['getNode']()['isIndexed'](_0x1a37e7['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x76a6b7['serverCache']['getNode']()['isIndexed'](_0x1a37e7['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x3b6106,_0x5db9bb,_0x596835,_0x240d46,_0xe9dba4){const _0x5a08ef=new wu();let _0x2972b5,_0x919d34;if(_0x596835['type']===z['OVERWRITE']){const _0x38979d=_0x596835;_0x38979d['source']['fromUser']?_0x2972b5=ki(_0x3b6106,_0x5db9bb,_0x38979d['path'],_0x38979d['snap'],_0x240d46,_0xe9dba4,_0x5a08ef):(f(_0x38979d['source']['fromServer'],'Unknown\x20source.'),_0x919d34=_0x38979d['source']['tagged']||_0x5db9bb['serverCache']['isFiltered']()&&!v(_0x38979d['path']),_0x2972b5=Sn(_0x3b6106,_0x5db9bb,_0x38979d['path'],_0x38979d['snap'],_0x240d46,_0xe9dba4,_0x919d34,_0x5a08ef));}else{if(_0x596835['type']===z['MERGE']){const _0x2f4558=_0x596835;_0x2f4558['source']['fromUser']?_0x2972b5=Au(_0x3b6106,_0x5db9bb,_0x2f4558['path'],_0x2f4558['children'],_0x240d46,_0xe9dba4,_0x5a08ef):(f(_0x2f4558['source']['fromServer'],'Unknown\x20source.'),_0x919d34=_0x2f4558['source']['tagged']||_0x5db9bb['serverCache']['isFiltered'](),_0x2972b5=Ni(_0x3b6106,_0x5db9bb,_0x2f4558['path'],_0x2f4558['children'],_0x240d46,_0xe9dba4,_0x919d34,_0x5a08ef));}else{if(_0x596835['type']===z['ACK_USER_WRITE']){const _0x554952=_0x596835;_0x554952['revert']?_0x2972b5=Pu(_0x3b6106,_0x5db9bb,_0x554952['path'],_0x240d46,_0xe9dba4,_0x5a08ef):_0x2972b5=ku(_0x3b6106,_0x5db9bb,_0x554952['path'],_0x554952['affectedTree'],_0x240d46,_0xe9dba4,_0x5a08ef);}else{if(_0x596835['type']===z['LISTEN_COMPLETE'])_0x2972b5=Nu(_0x3b6106,_0x5db9bb,_0x596835['path'],_0x240d46,_0x5a08ef);else throw ht('Unknown\x20operation\x20type:\x20'+_0x596835['type']);}}}const _0x1f8931=_0x5a08ef['getChanges']();return Ru(_0x5db9bb,_0x2972b5,_0x1f8931),{'viewCache':_0x2972b5,'changes':_0x1f8931};}function Ru(_0x40b779,_0x241b39,_0x4a6d2f){const _0x22c1bb=_0x241b39['eventCache'];if(_0x22c1bb['isFullyInitialized']()){const _0x498e85=_0x22c1bb['getNode']()['isLeafNode']()||_0x22c1bb['getNode']()['isEmpty'](),_0xa9a0a=wn(_0x40b779);(_0x4a6d2f['length']>0x0||!_0x40b779['eventCache']['isFullyInitialized']()||_0x498e85&&!_0x22c1bb['getNode']()['equals'](_0xa9a0a)||!_0x22c1bb['getNode']()['getPriority']()['equals'](_0xa9a0a['getPriority']()))&&_0x4a6d2f['push'](Lo(wn(_0x241b39)));}}function Go(_0x40f365,_0x27353f,_0x19ffa2,_0x4fb01b,_0x2f23e4,_0x68cb35){const _0x2483ba=_0x27353f['eventCache'];if(Tn(_0x4fb01b,_0x19ffa2)!=null)return _0x27353f;{let _0x52e57a,_0x4ac35b;if(v(_0x19ffa2)){if(f(_0x27353f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x27353f['serverCache']['isFiltered']()){const _0xedb264=Be(_0x27353f),_0x213246=_0xedb264 instanceof g?_0xedb264:g['EMPTY_NODE'],_0x19393b=is(_0x4fb01b,_0x213246);_0x52e57a=_0x40f365['filter']['updateFullNode'](_0x27353f['eventCache']['getNode'](),_0x19393b,_0x68cb35);}else{const _0x2d0be8=Cn(_0x4fb01b,Be(_0x27353f));_0x52e57a=_0x40f365['filter']['updateFullNode'](_0x27353f['eventCache']['getNode'](),_0x2d0be8,_0x68cb35);}}else{const _0x19957a=y(_0x19ffa2);if(_0x19957a==='.priority'){f(Ce(_0x19ffa2)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1df121=_0x2483ba['getNode']();_0x4ac35b=_0x27353f['serverCache']['getNode']();const _0x244c0a=cr(_0x4fb01b,_0x19ffa2,_0x1df121,_0x4ac35b);_0x244c0a!=null?_0x52e57a=_0x40f365['filter']['updatePriority'](_0x1df121,_0x244c0a):_0x52e57a=_0x2483ba['getNode']();}else{const _0x22514e=S(_0x19ffa2);let _0x11f005;if(_0x2483ba['isCompleteForChild'](_0x19957a)){_0x4ac35b=_0x27353f['serverCache']['getNode']();const _0x34b7ef=cr(_0x4fb01b,_0x19ffa2,_0x2483ba['getNode'](),_0x4ac35b);_0x34b7ef!=null?_0x11f005=_0x2483ba['getNode']()['getImmediateChild'](_0x19957a)['updateChild'](_0x22514e,_0x34b7ef):_0x11f005=_0x2483ba['getNode']()['getImmediateChild'](_0x19957a);}else _0x11f005=ss(_0x4fb01b,_0x19957a,_0x27353f['serverCache']);_0x11f005!=null?_0x52e57a=_0x40f365['filter']['updateChild'](_0x2483ba['getNode'](),_0x19957a,_0x11f005,_0x22514e,_0x2f23e4,_0x68cb35):_0x52e57a=_0x2483ba['getNode']();}}return bt(_0x27353f,_0x52e57a,_0x2483ba['isFullyInitialized']()||v(_0x19ffa2),_0x40f365['filter']['filtersNodes']());}}function Sn(_0x52f01c,_0x311646,_0x15b77b,_0x439d62,_0x5691e4,_0x121e0c,_0x560bb9,_0x28f1d1){const _0x8cfb50=_0x311646['serverCache'];let _0x1bc6bc;const _0x1b0dfa=_0x560bb9?_0x52f01c['filter']:_0x52f01c['filter']['getIndexedFilter']();if(v(_0x15b77b))_0x1bc6bc=_0x1b0dfa['updateFullNode'](_0x8cfb50['getNode'](),_0x439d62,null);else{if(_0x1b0dfa['filtersNodes']()&&!_0x8cfb50['isFiltered']()){const _0x231d51=_0x8cfb50['getNode']()['updateChild'](_0x15b77b,_0x439d62);_0x1bc6bc=_0x1b0dfa['updateFullNode'](_0x8cfb50['getNode'](),_0x231d51,null);}else{const _0x3d6556=y(_0x15b77b);if(!_0x8cfb50['isCompleteForPath'](_0x15b77b)&&Ce(_0x15b77b)>0x1)return _0x311646;const _0x1713b1=S(_0x15b77b),_0x27ef20=_0x8cfb50['getNode']()['getImmediateChild'](_0x3d6556)['updateChild'](_0x1713b1,_0x439d62);_0x3d6556==='.priority'?_0x1bc6bc=_0x1b0dfa['updatePriority'](_0x8cfb50['getNode'](),_0x27ef20):_0x1bc6bc=_0x1b0dfa['updateChild'](_0x8cfb50['getNode'](),_0x3d6556,_0x27ef20,_0x1713b1,$o,null);}}const _0x581ec3=Fo(_0x311646,_0x1bc6bc,_0x8cfb50['isFullyInitialized']()||v(_0x15b77b),_0x1b0dfa['filtersNodes']()),_0x11cb89=new rs(_0x5691e4,_0x581ec3,_0x121e0c);return Go(_0x52f01c,_0x581ec3,_0x15b77b,_0x5691e4,_0x11cb89,_0x28f1d1);}function ki(_0x5f25d7,_0x3f7385,_0x43d052,_0x385b85,_0x2eea1f,_0x1e3b7e,_0x5d58bd){const _0x7b0e5b=_0x3f7385['eventCache'];let _0x30e3e6,_0x13841b;const _0x4cf233=new rs(_0x2eea1f,_0x3f7385,_0x1e3b7e);if(v(_0x43d052))_0x13841b=_0x5f25d7['filter']['updateFullNode'](_0x3f7385['eventCache']['getNode'](),_0x385b85,_0x5d58bd),_0x30e3e6=bt(_0x3f7385,_0x13841b,!0x0,_0x5f25d7['filter']['filtersNodes']());else{const _0x236d6a=y(_0x43d052);if(_0x236d6a==='.priority')_0x13841b=_0x5f25d7['filter']['updatePriority'](_0x3f7385['eventCache']['getNode'](),_0x385b85),_0x30e3e6=bt(_0x3f7385,_0x13841b,_0x7b0e5b['isFullyInitialized'](),_0x7b0e5b['isFiltered']());else{const _0xaf51e8=S(_0x43d052),_0x56de2a=_0x7b0e5b['getNode']()['getImmediateChild'](_0x236d6a);let _0x4d224c;if(v(_0xaf51e8))_0x4d224c=_0x385b85;else{const _0x4b21dd=_0x4cf233['getCompleteChild'](_0x236d6a);_0x4b21dd!=null?ji(_0xaf51e8)==='.priority'&&_0x4b21dd['getChild'](Ro(_0xaf51e8))['isEmpty']()?_0x4d224c=_0x4b21dd:_0x4d224c=_0x4b21dd['updateChild'](_0xaf51e8,_0x385b85):_0x4d224c=g['EMPTY_NODE'];}if(_0x56de2a['equals'](_0x4d224c))_0x30e3e6=_0x3f7385;else{const _0x3ea184=_0x5f25d7['filter']['updateChild'](_0x7b0e5b['getNode'](),_0x236d6a,_0x4d224c,_0xaf51e8,_0x4cf233,_0x5d58bd);_0x30e3e6=bt(_0x3f7385,_0x3ea184,_0x7b0e5b['isFullyInitialized'](),_0x5f25d7['filter']['filtersNodes']());}}}return _0x30e3e6;}function lr(_0x4b5a12,_0x4708c2){return _0x4b5a12['eventCache']['isCompleteForChild'](_0x4708c2);}function Au(_0x3d3436,_0x41130d,_0x41b25d,_0x54b021,_0x3131b4,_0x53d35c,_0x2d9848){let _0x421469=_0x41130d;return _0x54b021['foreach']((_0x359222,_0x48981f)=>{const _0x1abdd0=k(_0x41b25d,_0x359222);lr(_0x41130d,y(_0x1abdd0))&&(_0x421469=ki(_0x3d3436,_0x421469,_0x1abdd0,_0x48981f,_0x3131b4,_0x53d35c,_0x2d9848));}),_0x54b021['foreach']((_0x381d81,_0x4e911f)=>{const _0x2def48=k(_0x41b25d,_0x381d81);lr(_0x41130d,y(_0x2def48))||(_0x421469=ki(_0x3d3436,_0x421469,_0x2def48,_0x4e911f,_0x3131b4,_0x53d35c,_0x2d9848));}),_0x421469;}function hr(_0x30ff3e,_0x5736d4,_0x3eea93){return _0x3eea93['foreach']((_0x2cadd5,_0x7e12a7)=>{_0x5736d4=_0x5736d4['updateChild'](_0x2cadd5,_0x7e12a7);}),_0x5736d4;}function Ni(_0xa7e15d,_0x41cdde,_0x5d294c,_0x318afa,_0x44567e,_0x2cd91c,_0x471e50,_0x38b1aa){if(_0x41cdde['serverCache']['getNode']()['isEmpty']()&&!_0x41cdde['serverCache']['isFullyInitialized']())return _0x41cdde;let _0x2eec2e=_0x41cdde,_0x11c4d4;v(_0x5d294c)?_0x11c4d4=_0x318afa:_0x11c4d4=new b(null)['setTree'](_0x5d294c,_0x318afa);const _0x3b47a8=_0x41cdde['serverCache']['getNode']();return _0x11c4d4['children']['inorderTraversal']((_0x25d8a2,_0x3322d5)=>{if(_0x3b47a8['hasChild'](_0x25d8a2)){const _0x4fba7d=_0x41cdde['serverCache']['getNode']()['getImmediateChild'](_0x25d8a2),_0x19b14c=hr(_0xa7e15d,_0x4fba7d,_0x3322d5);_0x2eec2e=Sn(_0xa7e15d,_0x2eec2e,new C(_0x25d8a2),_0x19b14c,_0x44567e,_0x2cd91c,_0x471e50,_0x38b1aa);}}),_0x11c4d4['children']['inorderTraversal']((_0x159ef9,_0x2fba66)=>{const _0x3b38d5=!_0x41cdde['serverCache']['isCompleteForChild'](_0x159ef9)&&_0x2fba66['value']===null;if(!_0x3b47a8['hasChild'](_0x159ef9)&&!_0x3b38d5){const _0x5554df=_0x41cdde['serverCache']['getNode']()['getImmediateChild'](_0x159ef9),_0x114903=hr(_0xa7e15d,_0x5554df,_0x2fba66);_0x2eec2e=Sn(_0xa7e15d,_0x2eec2e,new C(_0x159ef9),_0x114903,_0x44567e,_0x2cd91c,_0x471e50,_0x38b1aa);}}),_0x2eec2e;}function ku(_0x19923d,_0x16cc0b,_0xb50ed1,_0x22b0d1,_0x17d350,_0x101b21,_0x455c09){if(Tn(_0x17d350,_0xb50ed1)!=null)return _0x16cc0b;const _0x2ba9d7=_0x16cc0b['serverCache']['isFiltered'](),_0x446fc7=_0x16cc0b['serverCache'];if(_0x22b0d1['value']!=null){if(v(_0xb50ed1)&&_0x446fc7['isFullyInitialized']()||_0x446fc7['isCompleteForPath'](_0xb50ed1))return Sn(_0x19923d,_0x16cc0b,_0xb50ed1,_0x446fc7['getNode']()['getChild'](_0xb50ed1),_0x17d350,_0x101b21,_0x2ba9d7,_0x455c09);if(v(_0xb50ed1)){let _0x5457ab=new b(null);return _0x446fc7['getNode']()['forEachChild'](ve,(_0x1a03e3,_0x3d9700)=>{_0x5457ab=_0x5457ab['set'](new C(_0x1a03e3),_0x3d9700);}),Ni(_0x19923d,_0x16cc0b,_0xb50ed1,_0x5457ab,_0x17d350,_0x101b21,_0x2ba9d7,_0x455c09);}else return _0x16cc0b;}else{let _0x95e5b8=new b(null);return _0x22b0d1['foreach']((_0xac1b09,_0x5e9097)=>{const _0x4fec98=k(_0xb50ed1,_0xac1b09);_0x446fc7['isCompleteForPath'](_0x4fec98)&&(_0x95e5b8=_0x95e5b8['set'](_0xac1b09,_0x446fc7['getNode']()['getChild'](_0x4fec98)));}),Ni(_0x19923d,_0x16cc0b,_0xb50ed1,_0x95e5b8,_0x17d350,_0x101b21,_0x2ba9d7,_0x455c09);}}function Nu(_0x47946a,_0x1cb7d0,_0x19f8f1,_0x310d36,_0x24e7e2){const _0x158995=_0x1cb7d0['serverCache'],_0x54139a=Fo(_0x1cb7d0,_0x158995['getNode'](),_0x158995['isFullyInitialized']()||v(_0x19f8f1),_0x158995['isFiltered']());return Go(_0x47946a,_0x54139a,_0x19f8f1,_0x310d36,$o,_0x24e7e2);}function Pu(_0x3bfead,_0x25b3cb,_0x43739a,_0x3c5bfb,_0x384bfb,_0x16a9fa){let _0x563029;if(Tn(_0x3c5bfb,_0x43739a)!=null)return _0x25b3cb;{const _0xba844d=new rs(_0x3c5bfb,_0x25b3cb,_0x384bfb),_0x30291d=_0x25b3cb['eventCache']['getNode']();let _0x55b570;if(v(_0x43739a)||y(_0x43739a)==='.priority'){let _0x5e95c7;if(_0x25b3cb['serverCache']['isFullyInitialized']())_0x5e95c7=Cn(_0x3c5bfb,Be(_0x25b3cb));else{const _0x3231cb=_0x25b3cb['serverCache']['getNode']();f(_0x3231cb instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5e95c7=is(_0x3c5bfb,_0x3231cb);}_0x5e95c7=_0x5e95c7,_0x55b570=_0x3bfead['filter']['updateFullNode'](_0x30291d,_0x5e95c7,_0x16a9fa);}else{const _0x11be8e=y(_0x43739a);let _0x14c925=ss(_0x3c5bfb,_0x11be8e,_0x25b3cb['serverCache']);_0x14c925==null&&_0x25b3cb['serverCache']['isCompleteForChild'](_0x11be8e)&&(_0x14c925=_0x30291d['getImmediateChild'](_0x11be8e)),_0x14c925!=null?_0x55b570=_0x3bfead['filter']['updateChild'](_0x30291d,_0x11be8e,_0x14c925,S(_0x43739a),_0xba844d,_0x16a9fa):_0x25b3cb['eventCache']['getNode']()['hasChild'](_0x11be8e)?_0x55b570=_0x3bfead['filter']['updateChild'](_0x30291d,_0x11be8e,g['EMPTY_NODE'],S(_0x43739a),_0xba844d,_0x16a9fa):_0x55b570=_0x30291d,_0x55b570['isEmpty']()&&_0x25b3cb['serverCache']['isFullyInitialized']()&&(_0x563029=Cn(_0x3c5bfb,Be(_0x25b3cb)),_0x563029['isLeafNode']()&&(_0x55b570=_0x3bfead['filter']['updateFullNode'](_0x55b570,_0x563029,_0x16a9fa)));}return _0x563029=_0x25b3cb['serverCache']['isFullyInitialized']()||Tn(_0x3c5bfb,w())!=null,bt(_0x25b3cb,_0x55b570,_0x563029,_0x3bfead['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x1ae89b,_0x18b973){this['query_']=_0x1ae89b,this['eventRegistrations_']=[];const _0xf35e60=this['query_']['_queryParams'],_0x12db0e=new Xi(_0xf35e60['getIndex']()),_0x2ee798=Kh(_0xf35e60);this['processor_']=Tu(_0x2ee798);const _0x20ddff=_0x18b973['serverCache'],_0x370a19=_0x18b973['eventCache'],_0xacf2e8=_0x12db0e['updateFullNode'](g['EMPTY_NODE'],_0x20ddff['getNode'](),null),_0x52020a=_0x2ee798['updateFullNode'](g['EMPTY_NODE'],_0x370a19['getNode'](),null),_0x19c2f6=new Te(_0xacf2e8,_0x20ddff['isFullyInitialized'](),_0x12db0e['filtersNodes']()),_0x19114a=new Te(_0x52020a,_0x370a19['isFullyInitialized'](),_0x2ee798['filtersNodes']());this['viewCache_']=Un(_0x19114a,_0x19c2f6),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0x5de339){return _0x5de339['viewCache_']['serverCache']['getNode']();}function Mu(_0x169ac2){return wn(_0x169ac2['viewCache_']);}function Lu(_0x285abb,_0x358631){const _0xe63273=Be(_0x285abb['viewCache_']);return _0xe63273&&(_0x285abb['query']['_queryParams']['loadsAllData']()||!v(_0x358631)&&!_0xe63273['getImmediateChild'](y(_0x358631))['isEmpty']())?_0xe63273['getChild'](_0x358631):null;}function ur(_0x3702c8){return _0x3702c8['eventRegistrations_']['length']===0x0;}function xu(_0x3addca,_0x550c78){_0x3addca['eventRegistrations_']['push'](_0x550c78);}function dr(_0x15d186,_0x4c5303,_0x34b337){const _0x265041=[];if(_0x34b337){f(_0x4c5303==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0xfafbc8=_0x15d186['query']['_path'];_0x15d186['eventRegistrations_']['forEach'](_0x3418ed=>{const _0x908644=_0x3418ed['createCancelEvent'](_0x34b337,_0xfafbc8);_0x908644&&_0x265041['push'](_0x908644);});}if(_0x4c5303){let _0x594910=[];for(let _0x8d37a7=0x0;_0x8d37a7<_0x15d186['eventRegistrations_']['length'];++_0x8d37a7){const _0x2170da=_0x15d186['eventRegistrations_'][_0x8d37a7];if(!_0x2170da['matches'](_0x4c5303))_0x594910['push'](_0x2170da);else{if(_0x4c5303['hasAnyCallback']()){_0x594910=_0x594910['concat'](_0x15d186['eventRegistrations_']['slice'](_0x8d37a7+0x1));break;}}}_0x15d186['eventRegistrations_']=_0x594910;}else _0x15d186['eventRegistrations_']=[];return _0x265041;}function fr(_0x206107,_0x30efa8,_0x558da5,_0x1421a1){_0x30efa8['type']===z['MERGE']&&_0x30efa8['source']['queryId']!==null&&(f(Be(_0x206107['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x206107['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x35023d=_0x206107['viewCache_'],_0x3d8994=bu(_0x206107['processor_'],_0x35023d,_0x30efa8,_0x558da5,_0x1421a1);return Su(_0x206107['processor_'],_0x3d8994['viewCache']),f(_0x3d8994['viewCache']['serverCache']['isFullyInitialized']()||!_0x35023d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x206107['viewCache_']=_0x3d8994['viewCache'],qo(_0x206107,_0x3d8994['changes'],_0x3d8994['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x299ad5,_0x37174b){const _0xe186bb=_0x299ad5['viewCache_']['eventCache'],_0x8ba6a1=[];return _0xe186bb['getNode']()['isLeafNode']()||_0xe186bb['getNode']()['forEachChild'](R,(_0x4855a3,_0x2703e4)=>{_0x8ba6a1['push'](rt(_0x4855a3,_0x2703e4));}),_0xe186bb['isFullyInitialized']()&&_0x8ba6a1['push'](Lo(_0xe186bb['getNode']())),qo(_0x299ad5,_0x8ba6a1,_0xe186bb['getNode'](),_0x37174b);}function qo(_0x4d7f13,_0x1201e1,_0x54b2eb,_0x59d292){const _0x3734f6=_0x59d292?[_0x59d292]:_0x4d7f13['eventRegistrations_'];return su(_0x4d7f13['eventGenerator_'],_0x1201e1,_0x54b2eb,_0x3734f6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x24c20d){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x24c20d;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x52e9d8){return _0x52e9d8['views']['size']===0x0;}function os(_0x1215d8,_0x37d88f,_0x594fc3,_0x4f6688){const _0x3fa044=_0x37d88f['source']['queryId'];if(_0x3fa044!==null){const _0x4a9445=_0x1215d8['views']['get'](_0x3fa044);return f(_0x4a9445!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x4a9445,_0x37d88f,_0x594fc3,_0x4f6688);}else{let _0x3865e2=[];for(const _0x4e6837 of _0x1215d8['views']['values']())_0x3865e2=_0x3865e2['concat'](fr(_0x4e6837,_0x37d88f,_0x594fc3,_0x4f6688));return _0x3865e2;}}function jo(_0x257ae2,_0x549653,_0x2fdb60,_0x394049,_0x1e2a5c){const _0x1069b5=_0x549653['_queryIdentifier'],_0x3bf001=_0x257ae2['views']['get'](_0x1069b5);if(!_0x3bf001){let _0x1600cc=Cn(_0x2fdb60,_0x1e2a5c?_0x394049:null),_0x12a484=!0x1;_0x1600cc?_0x12a484=!0x0:_0x394049 instanceof g?(_0x1600cc=is(_0x2fdb60,_0x394049),_0x12a484=!0x1):(_0x1600cc=g['EMPTY_NODE'],_0x12a484=!0x1);const _0xe06fdc=Un(new Te(_0x1600cc,_0x12a484,!0x1),new Te(_0x394049,_0x1e2a5c,!0x1));return new Ou(_0x549653,_0xe06fdc);}return _0x3bf001;}function Vu(_0x7f9baf,_0x208ffa,_0x120512,_0x14c0ec,_0x1f7afd,_0x59a5e1){const _0x5abd8c=jo(_0x7f9baf,_0x208ffa,_0x14c0ec,_0x1f7afd,_0x59a5e1);return _0x7f9baf['views']['has'](_0x208ffa['_queryIdentifier'])||_0x7f9baf['views']['set'](_0x208ffa['_queryIdentifier'],_0x5abd8c),xu(_0x5abd8c,_0x120512),Fu(_0x5abd8c,_0x120512);}function Hu(_0x77f254,_0x5dea29,_0x561993,_0x3f3f68){const _0x4bf4b0=_0x5dea29['_queryIdentifier'],_0x3066b4=[];let _0x142974=[];const _0x3b35cb=Se(_0x77f254);if(_0x4bf4b0==='default'){for(const [_0x5e71b7,_0x22c01b]of _0x77f254['views']['entries']())_0x142974=_0x142974['concat'](dr(_0x22c01b,_0x561993,_0x3f3f68)),ur(_0x22c01b)&&(_0x77f254['views']['delete'](_0x5e71b7),_0x22c01b['query']['_queryParams']['loadsAllData']()||_0x3066b4['push'](_0x22c01b['query']));}else{const _0x3e2583=_0x77f254['views']['get'](_0x4bf4b0);_0x3e2583&&(_0x142974=_0x142974['concat'](dr(_0x3e2583,_0x561993,_0x3f3f68)),ur(_0x3e2583)&&(_0x77f254['views']['delete'](_0x4bf4b0),_0x3e2583['query']['_queryParams']['loadsAllData']()||_0x3066b4['push'](_0x3e2583['query'])));}return _0x3b35cb&&!Se(_0x77f254)&&_0x3066b4['push'](new(Wu())(_0x5dea29['_repo'],_0x5dea29['_path'])),{'removed':_0x3066b4,'events':_0x142974};}function Ko(_0x3f5ef8){const _0x1ca2b9=[];for(const _0x54c761 of _0x3f5ef8['views']['values']())_0x54c761['query']['_queryParams']['loadsAllData']()||_0x1ca2b9['push'](_0x54c761);return _0x1ca2b9;}function Ie(_0x1bd1df,_0x289ee0){let _0x57d285=null;for(const _0x16b0b of _0x1bd1df['views']['values']())_0x57d285=_0x57d285||Lu(_0x16b0b,_0x289ee0);return _0x57d285;}function Yo(_0x278991,_0x47a527){if(_0x47a527['_queryParams']['loadsAllData']())return Bn(_0x278991);{const _0x3021a0=_0x47a527['_queryIdentifier'];return _0x278991['views']['get'](_0x3021a0);}}function Qo(_0x3b1317,_0x593674){return Yo(_0x3b1317,_0x593674)!=null;}function Se(_0x23508c){return Bn(_0x23508c)!=null;}function Bn(_0x497f3a){for(const _0x54f210 of _0x497f3a['views']['values']())if(_0x54f210['query']['_queryParams']['loadsAllData']())return _0x54f210;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x5bc967){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x5bc967;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x49c9df){this['listenProvider_']=_0x49c9df,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x189753,_0x4de8f6,_0x22e176,_0x59f788,_0x32482a){return cu(_0x189753['pendingWriteTree_'],_0x4de8f6,_0x22e176,_0x59f788,_0x32482a),_0x32482a?_t(_0x189753,new We(es(),_0x4de8f6,_0x22e176)):[];}function zu(_0x3f15ed,_0xcacb27,_0x3e941b,_0x5997ca){lu(_0x3f15ed['pendingWriteTree_'],_0xcacb27,_0x3e941b,_0x5997ca);const _0x166259=b['fromObject'](_0x3e941b);return _t(_0x3f15ed,new ot(es(),_0xcacb27,_0x166259));}function _e(_0x3cc4b2,_0x20e9ae,_0x4e52a8=!0x1){const _0x4f2cad=hu(_0x3cc4b2['pendingWriteTree_'],_0x20e9ae);if(uu(_0x3cc4b2['pendingWriteTree_'],_0x20e9ae)){let _0x3f0966=new b(null);return _0x4f2cad['snap']!=null?_0x3f0966=_0x3f0966['set'](w(),!0x0):x(_0x4f2cad['children'],_0x38ce74=>{_0x3f0966=_0x3f0966['set'](new C(_0x38ce74),!0x0);}),_t(_0x3cc4b2,new In(_0x4f2cad['path'],_0x3f0966,_0x4e52a8));}else return[];}function Kt(_0x169769,_0x5747af,_0x8ff068){return _t(_0x169769,new We(ts(),_0x5747af,_0x8ff068));}function ju(_0x2a0b50,_0x3adfae,_0x2f2d1b){const _0x5eb21f=b['fromObject'](_0x2f2d1b);return _t(_0x2a0b50,new ot(ts(),_0x3adfae,_0x5eb21f));}function Ku(_0x215f6e,_0x202ccc){return _t(_0x215f6e,new Ft(ts(),_0x202ccc));}function Yu(_0x3a640f,_0x21b351,_0x404040){const _0x26f23d=cs(_0x3a640f,_0x404040);if(_0x26f23d){const _0x6f44cb=ls(_0x26f23d),_0x4adfc9=_0x6f44cb['path'],_0x1f184a=_0x6f44cb['queryId'],_0x21e47e=F(_0x4adfc9,_0x21b351),_0x5c4aa6=new Ft(ns(_0x1f184a),_0x21e47e);return hs(_0x3a640f,_0x4adfc9,_0x5c4aa6);}else return[];}function An(_0x20da76,_0x5577a4,_0x34c3e9,_0x59ad45,_0x18a5dd=!0x1){const _0x2e2e42=_0x5577a4['_path'],_0x526e0d=_0x20da76['syncPointTree_']['get'](_0x2e2e42);let _0x3bd483=[];if(_0x526e0d&&(_0x5577a4['_queryIdentifier']==='default'||Qo(_0x526e0d,_0x5577a4))){const _0x39b3f0=Hu(_0x526e0d,_0x5577a4,_0x34c3e9,_0x59ad45);Bu(_0x526e0d)&&(_0x20da76['syncPointTree_']=_0x20da76['syncPointTree_']['remove'](_0x2e2e42));const _0x3a9671=_0x39b3f0['removed'];if(_0x3bd483=_0x39b3f0['events'],!_0x18a5dd){const _0x4464c2=_0x3a9671['findIndex'](_0x1adfec=>_0x1adfec['_queryParams']['loadsAllData']())!==-0x1,_0x2edbfb=_0x20da76['syncPointTree_']['findOnPath'](_0x2e2e42,(_0xbe0193,_0xfe6817)=>Se(_0xfe6817));if(_0x4464c2&&!_0x2edbfb){const _0x2da309=_0x20da76['syncPointTree_']['subtree'](_0x2e2e42);if(!_0x2da309['isEmpty']()){const _0x4c1f19=Xu(_0x2da309);for(let _0x188ce1=0x0;_0x188ce1<_0x4c1f19['length'];++_0x188ce1){const _0x3bce2f=_0x4c1f19[_0x188ce1],_0x56e2e5=_0x3bce2f['query'],_0x5ee794=ea(_0x20da76,_0x3bce2f);_0x20da76['listenProvider_']['startListening'](At(_0x56e2e5),Ut(_0x20da76,_0x56e2e5),_0x5ee794['hashFn'],_0x5ee794['onComplete']);}}}!_0x2edbfb&&_0x3a9671['length']>0x0&&!_0x59ad45&&(_0x4464c2?_0x20da76['listenProvider_']['stopListening'](At(_0x5577a4),null):_0x3a9671['forEach'](_0x155b7b=>{const _0x242f37=_0x20da76['queryToTagMap']['get'](Hn(_0x155b7b));_0x20da76['listenProvider_']['stopListening'](At(_0x155b7b),_0x242f37);}));}Zu(_0x20da76,_0x3a9671);}return _0x3bd483;}function Jo(_0x28ecb1,_0x9acbe6,_0x5d4ce9,_0x2002c5){const _0x2ad2c3=cs(_0x28ecb1,_0x2002c5);if(_0x2ad2c3!=null){const _0x457b26=ls(_0x2ad2c3),_0x3ac8df=_0x457b26['path'],_0x4861cd=_0x457b26['queryId'],_0x49ed6f=F(_0x3ac8df,_0x9acbe6),_0x39325a=new We(ns(_0x4861cd),_0x49ed6f,_0x5d4ce9);return hs(_0x28ecb1,_0x3ac8df,_0x39325a);}else return[];}function Qu(_0x5c7736,_0x2cafa1,_0x4c221d,_0x4be7e7){const _0x2f903b=cs(_0x5c7736,_0x4be7e7);if(_0x2f903b){const _0x55c885=ls(_0x2f903b),_0x3f87aa=_0x55c885['path'],_0x1ac3e0=_0x55c885['queryId'],_0x3900ea=F(_0x3f87aa,_0x2cafa1),_0x8ffa24=b['fromObject'](_0x4c221d),_0x1c804e=new ot(ns(_0x1ac3e0),_0x3900ea,_0x8ffa24);return hs(_0x5c7736,_0x3f87aa,_0x1c804e);}else return[];}function Pi(_0x52020c,_0x57ef3d,_0x3cae68,_0x30b45b=!0x1){const _0x5f5477=_0x57ef3d['_path'];let _0x434cbf=null,_0x10b8e9=!0x1;_0x52020c['syncPointTree_']['foreachOnPath'](_0x5f5477,(_0x4b2802,_0x121832)=>{const _0x81d40f=F(_0x4b2802,_0x5f5477);_0x434cbf=_0x434cbf||Ie(_0x121832,_0x81d40f),_0x10b8e9=_0x10b8e9||Se(_0x121832);});let _0x2e6764=_0x52020c['syncPointTree_']['get'](_0x5f5477);_0x2e6764?(_0x10b8e9=_0x10b8e9||Se(_0x2e6764),_0x434cbf=_0x434cbf||Ie(_0x2e6764,w())):(_0x2e6764=new zo(),_0x52020c['syncPointTree_']=_0x52020c['syncPointTree_']['set'](_0x5f5477,_0x2e6764));let _0x3c4a8c;_0x434cbf!=null?_0x3c4a8c=!0x0:(_0x3c4a8c=!0x1,_0x434cbf=g['EMPTY_NODE'],_0x52020c['syncPointTree_']['subtree'](_0x5f5477)['foreachChild']((_0x14e3fb,_0x5b9ead)=>{const _0x11327b=Ie(_0x5b9ead,w());_0x11327b&&(_0x434cbf=_0x434cbf['updateImmediateChild'](_0x14e3fb,_0x11327b));}));const _0x8d705d=Qo(_0x2e6764,_0x57ef3d);if(!_0x8d705d&&!_0x57ef3d['_queryParams']['loadsAllData']()){const _0x17ad67=Hn(_0x57ef3d);f(!_0x52020c['queryToTagMap']['has'](_0x17ad67),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x57a82b=ed();_0x52020c['queryToTagMap']['set'](_0x17ad67,_0x57a82b),_0x52020c['tagToQueryMap']['set'](_0x57a82b,_0x17ad67);}const _0x1628e5=Wn(_0x52020c['pendingWriteTree_'],_0x5f5477);let _0x26182a=Vu(_0x2e6764,_0x57ef3d,_0x3cae68,_0x1628e5,_0x434cbf,_0x3c4a8c);if(!_0x8d705d&&!_0x10b8e9&&!_0x30b45b){const _0x3cbaec=Yo(_0x2e6764,_0x57ef3d);_0x26182a=_0x26182a['concat'](td(_0x52020c,_0x57ef3d,_0x3cbaec));}return _0x26182a;}function Vn(_0x1a7d71,_0x5613d0,_0x55a95f){const _0x21ab24=_0x1a7d71['pendingWriteTree_'],_0x31f75f=_0x1a7d71['syncPointTree_']['findOnPath'](_0x5613d0,(_0x465452,_0x3ef004)=>{const _0x39cb69=F(_0x465452,_0x5613d0),_0x4407e9=Ie(_0x3ef004,_0x39cb69);if(_0x4407e9)return _0x4407e9;});return Bo(_0x21ab24,_0x5613d0,_0x31f75f,_0x55a95f,!0x0);}function Ju(_0x166b67,_0x2ff143){const _0x49e61a=_0x2ff143['_path'];let _0x359de0=null;_0x166b67['syncPointTree_']['foreachOnPath'](_0x49e61a,(_0xa8f112,_0x529a38)=>{const _0x2a9f6b=F(_0xa8f112,_0x49e61a);_0x359de0=_0x359de0||Ie(_0x529a38,_0x2a9f6b);});let _0x512d5b=_0x166b67['syncPointTree_']['get'](_0x49e61a);_0x512d5b?_0x359de0=_0x359de0||Ie(_0x512d5b,w()):(_0x512d5b=new zo(),_0x166b67['syncPointTree_']=_0x166b67['syncPointTree_']['set'](_0x49e61a,_0x512d5b));const _0x332387=_0x359de0!=null,_0x3dc5e7=_0x332387?new Te(_0x359de0,!0x0,!0x1):null,_0x37c27a=Wn(_0x166b67['pendingWriteTree_'],_0x2ff143['_path']),_0x404003=jo(_0x512d5b,_0x2ff143,_0x37c27a,_0x332387?_0x3dc5e7['getNode']():g['EMPTY_NODE'],_0x332387);return Mu(_0x404003);}function _t(_0x4aa6bd,_0x4e26cc){return Xo(_0x4e26cc,_0x4aa6bd['syncPointTree_'],null,Wn(_0x4aa6bd['pendingWriteTree_'],w()));}function Xo(_0x3563fc,_0x20c9ef,_0x58d61a,_0x489438){if(v(_0x3563fc['path']))return Zo(_0x3563fc,_0x20c9ef,_0x58d61a,_0x489438);{const _0x103382=_0x20c9ef['get'](w());_0x58d61a==null&&_0x103382!=null&&(_0x58d61a=Ie(_0x103382,w()));let _0x25839c=[];const _0x186a70=y(_0x3563fc['path']),_0x2fbc26=_0x3563fc['operationForChild'](_0x186a70),_0x505200=_0x20c9ef['children']['get'](_0x186a70);if(_0x505200&&_0x2fbc26){const _0x56047d=_0x58d61a?_0x58d61a['getImmediateChild'](_0x186a70):null,_0x449754=Vo(_0x489438,_0x186a70);_0x25839c=_0x25839c['concat'](Xo(_0x2fbc26,_0x505200,_0x56047d,_0x449754));}return _0x103382&&(_0x25839c=_0x25839c['concat'](os(_0x103382,_0x3563fc,_0x489438,_0x58d61a))),_0x25839c;}}function Zo(_0x4a2a56,_0x873825,_0x29d2a1,_0x2296d5){const _0x170313=_0x873825['get'](w());_0x29d2a1==null&&_0x170313!=null&&(_0x29d2a1=Ie(_0x170313,w()));let _0x3580f5=[];return _0x873825['children']['inorderTraversal']((_0x1bdcc4,_0x1b96d5)=>{const _0xc83296=_0x29d2a1?_0x29d2a1['getImmediateChild'](_0x1bdcc4):null,_0x3e6339=Vo(_0x2296d5,_0x1bdcc4),_0x421a35=_0x4a2a56['operationForChild'](_0x1bdcc4);_0x421a35&&(_0x3580f5=_0x3580f5['concat'](Zo(_0x421a35,_0x1b96d5,_0xc83296,_0x3e6339)));}),_0x170313&&(_0x3580f5=_0x3580f5['concat'](os(_0x170313,_0x4a2a56,_0x2296d5,_0x29d2a1))),_0x3580f5;}function ea(_0x3a1980,_0x57414f){const _0x74e619=_0x57414f['query'],_0x492df2=Ut(_0x3a1980,_0x74e619);return{'hashFn':()=>(Du(_0x57414f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3c23ab=>{if(_0x3c23ab==='ok')return _0x492df2?Yu(_0x3a1980,_0x74e619['_path'],_0x492df2):Ku(_0x3a1980,_0x74e619['_path']);{const _0x4cb875=Kl(_0x3c23ab,_0x74e619);return An(_0x3a1980,_0x74e619,null,_0x4cb875);}}};}function Ut(_0x5e139a,_0x39d6b5){const _0x595e4a=Hn(_0x39d6b5);return _0x5e139a['queryToTagMap']['get'](_0x595e4a);}function Hn(_0x22344d){return _0x22344d['_path']['toString']()+'$'+_0x22344d['_queryIdentifier'];}function cs(_0x3eab42,_0xe7ae26){return _0x3eab42['tagToQueryMap']['get'](_0xe7ae26);}function ls(_0x17b1e3){const _0x4145fa=_0x17b1e3['indexOf']('$');return f(_0x4145fa!==-0x1&&_0x4145fa<_0x17b1e3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x17b1e3['substr'](_0x4145fa+0x1),'path':new C(_0x17b1e3['substr'](0x0,_0x4145fa))};}function hs(_0x53e657,_0x2c0d01,_0xc40b08){const _0x31ca59=_0x53e657['syncPointTree_']['get'](_0x2c0d01);f(_0x31ca59,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2002e5=Wn(_0x53e657['pendingWriteTree_'],_0x2c0d01);return os(_0x31ca59,_0xc40b08,_0x2002e5,null);}function Xu(_0xa06371){return _0xa06371['fold']((_0x2666ee,_0xa646a3,_0x538868)=>{if(_0xa646a3&&Se(_0xa646a3))return[Bn(_0xa646a3)];{let _0x14a43d=[];return _0xa646a3&&(_0x14a43d=Ko(_0xa646a3)),x(_0x538868,(_0x38c980,_0x35ea83)=>{_0x14a43d=_0x14a43d['concat'](_0x35ea83);}),_0x14a43d;}});}function At(_0x384a16){return _0x384a16['_queryParams']['loadsAllData']()&&!_0x384a16['_queryParams']['isDefault']()?new(Gu())(_0x384a16['_repo'],_0x384a16['_path']):_0x384a16;}function Zu(_0x689b9d,_0x4a4816){for(let _0x528b1a=0x0;_0x528b1a<_0x4a4816['length'];++_0x528b1a){const _0x1a6cba=_0x4a4816[_0x528b1a];if(!_0x1a6cba['_queryParams']['loadsAllData']()){const _0x5e8be2=Hn(_0x1a6cba),_0x3b5019=_0x689b9d['queryToTagMap']['get'](_0x5e8be2);_0x689b9d['queryToTagMap']['delete'](_0x5e8be2),_0x689b9d['tagToQueryMap']['delete'](_0x3b5019);}}}function ed(){return qu++;}function td(_0x36eb0e,_0x2a9516,_0x3a867e){const _0x53a629=_0x2a9516['_path'],_0xc5290a=Ut(_0x36eb0e,_0x2a9516),_0x5dd883=ea(_0x36eb0e,_0x3a867e),_0x542229=_0x36eb0e['listenProvider_']['startListening'](At(_0x2a9516),_0xc5290a,_0x5dd883['hashFn'],_0x5dd883['onComplete']),_0x36848c=_0x36eb0e['syncPointTree_']['subtree'](_0x53a629);if(_0xc5290a)f(!Se(_0x36848c['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x170e77=_0x36848c['fold']((_0x266a4b,_0x3b67df,_0x40a551)=>{if(!v(_0x266a4b)&&_0x3b67df&&Se(_0x3b67df))return[Bn(_0x3b67df)['query']];{let _0x15eb32=[];return _0x3b67df&&(_0x15eb32=_0x15eb32['concat'](Ko(_0x3b67df)['map'](_0xc6baeb=>_0xc6baeb['query']))),x(_0x40a551,(_0x2a1624,_0x160b50)=>{_0x15eb32=_0x15eb32['concat'](_0x160b50);}),_0x15eb32;}});for(let _0x25ad1d=0x0;_0x25ad1d<_0x170e77['length'];++_0x25ad1d){const _0x395e4b=_0x170e77[_0x25ad1d];_0x36eb0e['listenProvider_']['stopListening'](At(_0x395e4b),Ut(_0x36eb0e,_0x395e4b));}}return _0x542229;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0xe8551f){this['node_']=_0xe8551f;}['getImmediateChild'](_0x3f0a09){const _0x265079=this['node_']['getImmediateChild'](_0x3f0a09);return new us(_0x265079);}['node'](){return this['node_'];}}class ds{constructor(_0x4d1217,_0x31281a){this['syncTree_']=_0x4d1217,this['path_']=_0x31281a;}['getImmediateChild'](_0x4f3c8a){const _0x76c7ec=k(this['path_'],_0x4f3c8a);return new ds(this['syncTree_'],_0x76c7ec);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0x5833de){return _0x5833de=_0x5833de||{},_0x5833de['timestamp']=_0x5833de['timestamp']||new Date()['getTime'](),_0x5833de;},_r=function(_0x210d4a,_0x3eb374,_0x1e9e1d){if(!_0x210d4a||typeof _0x210d4a!='object')return _0x210d4a;if(f('.sv'in _0x210d4a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x210d4a['.sv']=='string')return id(_0x210d4a['.sv'],_0x3eb374,_0x1e9e1d);if(typeof _0x210d4a['.sv']=='object')return sd(_0x210d4a['.sv'],_0x3eb374);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x210d4a,null,0x2));},id=function(_0x591404,_0x51d6ab,_0x541d0f){switch(_0x591404){case'timestamp':return _0x541d0f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x591404);}},sd=function(_0x33928b,_0x2ebdc3,_0xdcc220){_0x33928b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x33928b,null,0x2));const _0x4fa997=_0x33928b['increment'];typeof _0x4fa997!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4fa997);const _0x28dcd8=_0x2ebdc3['node']();if(f(_0x28dcd8!==null&&typeof _0x28dcd8<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x28dcd8['isLeafNode']())return _0x4fa997;const _0x140eb0=_0x28dcd8['getValue']();return typeof _0x140eb0!='number'?_0x4fa997:_0x140eb0+_0x4fa997;},ta=function(_0x33cedb,_0x338f21,_0x1068d4,_0x575f91){return ps(_0x338f21,new ds(_0x1068d4,_0x33cedb),_0x575f91);},fs=function(_0x47d68e,_0x1d600e,_0x598e27){return ps(_0x47d68e,new us(_0x1d600e),_0x598e27);};function ps(_0x4d726f,_0x2408ac,_0x529dd3){const _0xc651d6=_0x4d726f['getPriority']()['val'](),_0x22c76b=_r(_0xc651d6,_0x2408ac['getImmediateChild']('.priority'),_0x529dd3);let _0xa91c94;if(_0x4d726f['isLeafNode']()){const _0xa43e86=_0x4d726f,_0x24b6bb=_r(_0xa43e86['getValue'](),_0x2408ac,_0x529dd3);return _0x24b6bb!==_0xa43e86['getValue']()||_0x22c76b!==_0xa43e86['getPriority']()['val']()?new D(_0x24b6bb,A(_0x22c76b)):_0x4d726f;}else{const _0x233682=_0x4d726f;return _0xa91c94=_0x233682,_0x22c76b!==_0x233682['getPriority']()['val']()&&(_0xa91c94=_0xa91c94['updatePriority'](new D(_0x22c76b))),_0x233682['forEachChild'](R,(_0x31647b,_0x4205fb)=>{const _0x143b71=ps(_0x4205fb,_0x2408ac['getImmediateChild'](_0x31647b),_0x529dd3);_0x143b71!==_0x4205fb&&(_0xa91c94=_0xa91c94['updateImmediateChild'](_0x31647b,_0x143b71));}),_0xa91c94;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x59a140='',_0x4d7a32=null,_0x2bfc21={'children':{},'childCount':0x0}){this['name']=_0x59a140,this['parent']=_0x4d7a32,this['node']=_0x2bfc21;}}function $n(_0x330911,_0x29cedd){let _0x57a982=_0x29cedd instanceof C?_0x29cedd:new C(_0x29cedd),_0x5b2097=_0x330911,_0x3ba437=y(_0x57a982);for(;_0x3ba437!==null;){const _0x4e34d2=Me(_0x5b2097['node']['children'],_0x3ba437)||{'children':{},'childCount':0x0};_0x5b2097=new _s(_0x3ba437,_0x5b2097,_0x4e34d2),_0x57a982=S(_0x57a982),_0x3ba437=y(_0x57a982);}return _0x5b2097;}function ze(_0xedd077){return _0xedd077['node']['value'];}function gs(_0x36445b,_0x2c818f){_0x36445b['node']['value']=_0x2c818f,Oi(_0x36445b);}function na(_0x5e51df){return _0x5e51df['node']['childCount']>0x0;}function rd(_0x5e7590){return ze(_0x5e7590)===void 0x0&&!na(_0x5e7590);}function Gn(_0x253e45,_0x52832d){x(_0x253e45['node']['children'],(_0x49fdf8,_0xd8acc5)=>{_0x52832d(new _s(_0x49fdf8,_0x253e45,_0xd8acc5));});}function ia(_0x5d93f3,_0x4a5355,_0x372c1b,_0x51e161){_0x372c1b&&_0x4a5355(_0x5d93f3),Gn(_0x5d93f3,_0x21e601=>{ia(_0x21e601,_0x4a5355,!0x0);});}function od(_0x910342,_0x46adcc,_0x4a9f68){let _0x11adbf=_0x910342['parent'];for(;_0x11adbf!==null;){if(_0x46adcc(_0x11adbf))return!0x0;_0x11adbf=_0x11adbf['parent'];}return!0x1;}function Yt(_0x447ce6){return new C(_0x447ce6['parent']===null?_0x447ce6['name']:Yt(_0x447ce6['parent'])+'/'+_0x447ce6['name']);}function Oi(_0x3b8124){_0x3b8124['parent']!==null&&ad(_0x3b8124['parent'],_0x3b8124['name'],_0x3b8124);}function ad(_0x1fa0e4,_0x14e8ee,_0x4582be){const _0x779c7d=rd(_0x4582be),_0x48969a=Q(_0x1fa0e4['node']['children'],_0x14e8ee);_0x779c7d&&_0x48969a?(delete _0x1fa0e4['node']['children'][_0x14e8ee],_0x1fa0e4['node']['childCount']--,Oi(_0x1fa0e4)):!_0x779c7d&&!_0x48969a&&(_0x1fa0e4['node']['children'][_0x14e8ee]=_0x4582be['node'],_0x1fa0e4['node']['childCount']++,Oi(_0x1fa0e4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x4b1a76){return typeof _0x4b1a76=='string'&&_0x4b1a76['length']!==0x0&&!cd['test'](_0x4b1a76);},sa=function(_0x3d7c44){return typeof _0x3d7c44=='string'&&_0x3d7c44['length']!==0x0&&!ld['test'](_0x3d7c44);},hd=function(_0x3ac803){return _0x3ac803&&(_0x3ac803=_0x3ac803['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3ac803);},Wt=function(_0x2d0a17){return _0x2d0a17===null||typeof _0x2d0a17=='string'||typeof _0x2d0a17=='number'&&!xn(_0x2d0a17)||_0x2d0a17&&typeof _0x2d0a17=='object'&&Q(_0x2d0a17,'.sv');},Ve=function(_0x4e028b,_0x4fcfbb,_0x3055d0,_0x53f257){_0x53f257&&_0x4fcfbb===void 0x0||Qt(it(_0x4e028b,'value'),_0x4fcfbb,_0x3055d0);},Qt=function(_0x57b184,_0x207eac,_0x1649d2){const _0x21aac7=_0x1649d2 instanceof C?new Ah(_0x1649d2,_0x57b184):_0x1649d2;if(_0x207eac===void 0x0)throw new Error(_0x57b184+'contains\x20undefined\x20'+Pe(_0x21aac7));if(typeof _0x207eac=='function')throw new Error(_0x57b184+'contains\x20a\x20function\x20'+Pe(_0x21aac7)+'\x20with\x20contents\x20=\x20'+_0x207eac['toString']());if(xn(_0x207eac))throw new Error(_0x57b184+'contains\x20'+_0x207eac['toString']()+'\x20'+Pe(_0x21aac7));if(typeof _0x207eac=='string'&&_0x207eac['length']>ui/0x3&&Ln(_0x207eac)>ui)throw new Error(_0x57b184+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x21aac7)+'\x20(\x27'+_0x207eac['substring'](0x0,0x32)+'...\x27)');if(_0x207eac&&typeof _0x207eac=='object'){let _0x1ac071=!0x1,_0x3bdf30=!0x1;if(x(_0x207eac,(_0x513a42,_0x3bea80)=>{if(_0x513a42==='.value')_0x1ac071=!0x0;else{if(_0x513a42!=='.priority'&&_0x513a42!=='.sv'&&(_0x3bdf30=!0x0,!ms(_0x513a42)))throw new Error(_0x57b184+'\x20contains\x20an\x20invalid\x20key\x20('+_0x513a42+')\x20'+Pe(_0x21aac7)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x21aac7,_0x513a42),Qt(_0x57b184,_0x3bea80,_0x21aac7),Nh(_0x21aac7);}),_0x1ac071&&_0x3bdf30)throw new Error(_0x57b184+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x21aac7)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0x216f5b,_0x3fb5c3){let _0x386ca6,_0xe934a3;for(_0x386ca6=0x0;_0x386ca6<_0x3fb5c3['length'];_0x386ca6++){_0xe934a3=_0x3fb5c3[_0x386ca6];const _0x184bad=Dt(_0xe934a3);for(let _0x187a09=0x0;_0x187a09<_0x184bad['length'];_0x187a09++)if(!(_0x184bad[_0x187a09]==='.priority'&&_0x187a09===_0x184bad['length']-0x1)){if(!ms(_0x184bad[_0x187a09]))throw new Error(_0x216f5b+'contains\x20an\x20invalid\x20key\x20('+_0x184bad[_0x187a09]+')\x20in\x20path\x20'+_0xe934a3['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x3fb5c3['sort'](Rh);let _0x5022b3=null;for(_0x386ca6=0x0;_0x386ca6<_0x3fb5c3['length'];_0x386ca6++){if(_0xe934a3=_0x3fb5c3[_0x386ca6],_0x5022b3!==null&&G(_0x5022b3,_0xe934a3))throw new Error(_0x216f5b+'contains\x20a\x20path\x20'+_0x5022b3['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xe934a3['toString']());_0x5022b3=_0xe934a3;}},ra=function(_0x17f783,_0x398cb5,_0x5a85c0,_0x42721){const _0x731e89=it(_0x17f783,'values');if(!(_0x398cb5&&typeof _0x398cb5=='object')||Array['isArray'](_0x398cb5))throw new Error(_0x731e89+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x599128=[];x(_0x398cb5,(_0x3addec,_0x163005)=>{const _0x2120e7=new C(_0x3addec);if(Qt(_0x731e89,_0x163005,k(_0x5a85c0,_0x2120e7)),ji(_0x2120e7)==='.priority'&&!Wt(_0x163005))throw new Error(_0x731e89+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2120e7['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x599128['push'](_0x2120e7);}),ud(_0x731e89,_0x599128);},dd=function(_0x596707,_0xb5a9e,_0x361717){if(xn(_0xb5a9e))throw new Error(it(_0x596707,'priority')+'is\x20'+_0xb5a9e['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0xb5a9e))throw new Error(it(_0x596707,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x10cacb,_0x3504e1,_0x41bd83,_0xe4dfa4){if(!sa(_0x41bd83))throw new Error(it(_0x10cacb,_0x3504e1)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x41bd83+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0x3012a3,_0x4c53c2,_0x22e178,_0x24c9e1){_0x22e178&&(_0x22e178=_0x22e178['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x3012a3,_0x4c53c2,_0x22e178);},De=function(_0xd74bf9,_0x28de92){if(y(_0x28de92)==='.info')throw new Error(_0xd74bf9+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x3f8025,_0x48a75f){const _0x8a2e5b=_0x48a75f['path']['toString']();if(typeof _0x48a75f['repoInfo']['host']!='string'||_0x48a75f['repoInfo']['host']['length']===0x0||!ms(_0x48a75f['repoInfo']['namespace'])&&_0x48a75f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x8a2e5b['length']!==0x0&&!hd(_0x8a2e5b))throw new Error(it(_0x3f8025,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x23968d,_0x118ab0){let _0x1ae91d=null;for(let _0x10af8d=0x0;_0x10af8d<_0x118ab0['length'];_0x10af8d++){const _0x5edf49=_0x118ab0[_0x10af8d],_0x1ffe1c=_0x5edf49['getPath']();_0x1ae91d!==null&&!Ki(_0x1ffe1c,_0x1ae91d['path'])&&(_0x23968d['eventLists_']['push'](_0x1ae91d),_0x1ae91d=null),_0x1ae91d===null&&(_0x1ae91d={'events':[],'path':_0x1ffe1c}),_0x1ae91d['events']['push'](_0x5edf49);}_0x1ae91d&&_0x23968d['eventLists_']['push'](_0x1ae91d);}function oa(_0x1e8f86,_0x572a14,_0x458e41){qn(_0x1e8f86,_0x458e41),aa(_0x1e8f86,_0x577c19=>Ki(_0x577c19,_0x572a14));}function V(_0x304e70,_0x5eadae,_0x4fb771){qn(_0x304e70,_0x4fb771),aa(_0x304e70,_0xdc8f9a=>G(_0xdc8f9a,_0x5eadae)||G(_0x5eadae,_0xdc8f9a));}function aa(_0x1e1a11,_0x30ac74){_0x1e1a11['recursionDepth_']++;let _0x241272=!0x0;for(let _0x11e808=0x0;_0x11e808<_0x1e1a11['eventLists_']['length'];_0x11e808++){const _0x35682c=_0x1e1a11['eventLists_'][_0x11e808];if(_0x35682c){const _0x2b960a=_0x35682c['path'];_0x30ac74(_0x2b960a)?(gd(_0x1e1a11['eventLists_'][_0x11e808]),_0x1e1a11['eventLists_'][_0x11e808]=null):_0x241272=!0x1;}}_0x241272&&(_0x1e1a11['eventLists_']=[]),_0x1e1a11['recursionDepth_']--;}function gd(_0x2df96e){for(let _0xbfd089=0x0;_0xbfd089<_0x2df96e['events']['length'];_0xbfd089++){const _0x38a792=_0x2df96e['events'][_0xbfd089];if(_0x38a792!==null){_0x2df96e['events'][_0xbfd089]=null;const _0x624183=_0x38a792['getEventRunner']();Tt&&L('event:\x20'+_0x38a792['toString']()),ft(_0x624183);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x47827e,_0xfa7e74,_0x437d9c,_0x58d147){this['repoInfo_']=_0x47827e,this['forceRestClient_']=_0xfa7e74,this['authTokenProvider_']=_0x437d9c,this['appCheckProvider_']=_0x58d147,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0x3fdb9f,_0x238469,_0x27070f){if(_0x3fdb9f['stats_']=qi(_0x3fdb9f['repoInfo_']),_0x3fdb9f['forceRestClient_']||Xl())_0x3fdb9f['server_']=new vn(_0x3fdb9f['repoInfo_'],(_0x355438,_0x5767b8,_0x3c543e,_0x4ce2ca)=>{gr(_0x3fdb9f,_0x355438,_0x5767b8,_0x3c543e,_0x4ce2ca);},_0x3fdb9f['authTokenProvider_'],_0x3fdb9f['appCheckProvider_']),setTimeout(()=>mr(_0x3fdb9f,!0x0),0x0);else{if(typeof _0x27070f<'u'&&_0x27070f!==null){if(typeof _0x27070f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x27070f);}catch(_0x53d5df){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x53d5df);}}_0x3fdb9f['persistentConnection_']=new se(_0x3fdb9f['repoInfo_'],_0x238469,(_0x1ac183,_0x565b9c,_0x59b8fe,_0x11e0b5)=>{gr(_0x3fdb9f,_0x1ac183,_0x565b9c,_0x59b8fe,_0x11e0b5);},_0x3a68c6=>{mr(_0x3fdb9f,_0x3a68c6);},_0x43b2a5=>{Ed(_0x3fdb9f,_0x43b2a5);},_0x3fdb9f['authTokenProvider_'],_0x3fdb9f['appCheckProvider_'],_0x27070f),_0x3fdb9f['server_']=_0x3fdb9f['persistentConnection_'];}_0x3fdb9f['authTokenProvider_']['addTokenChangeListener'](_0x2e8c4d=>{_0x3fdb9f['server_']['refreshAuthToken'](_0x2e8c4d);}),_0x3fdb9f['appCheckProvider_']['addTokenChangeListener'](_0x3f44d6=>{_0x3fdb9f['server_']['refreshAppCheckToken'](_0x3f44d6['token']);}),_0x3fdb9f['statsReporter_']=ih(_0x3fdb9f['repoInfo_'],()=>new nu(_0x3fdb9f['stats_'],_0x3fdb9f['server_'])),_0x3fdb9f['infoData_']=new Jh(),_0x3fdb9f['infoSyncTree_']=new pr({'startListening':(_0x326d13,_0x46cf27,_0x8864e,_0x2521f7)=>{let _0x249bfe=[];const _0x17ed2f=_0x3fdb9f['infoData_']['getNode'](_0x326d13['_path']);return _0x17ed2f['isEmpty']()||(_0x249bfe=Kt(_0x3fdb9f['infoSyncTree_'],_0x326d13['_path'],_0x17ed2f),setTimeout(()=>{_0x2521f7('ok');},0x0)),_0x249bfe;},'stopListening':()=>{}}),vs(_0x3fdb9f,'connected',!0x1),_0x3fdb9f['serverSyncTree_']=new pr({'startListening':(_0x210e0a,_0x137a31,_0x23700e,_0xa52667)=>(_0x3fdb9f['server_']['listen'](_0x210e0a,_0x23700e,_0x137a31,(_0x51515a,_0x2942fc)=>{const _0x4cfafc=_0xa52667(_0x51515a,_0x2942fc);V(_0x3fdb9f['eventQueue_'],_0x210e0a['_path'],_0x4cfafc);}),[]),'stopListening':(_0x11a0f1,_0x934994)=>{_0x3fdb9f['server_']['unlisten'](_0x11a0f1,_0x934994);}});}function la(_0x188d0e){const _0x2dc4cd=_0x188d0e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2dc4cd;}function Jt(_0x3ec30f){return nd({'timestamp':la(_0x3ec30f)});}function gr(_0x79484d,_0x9a166e,_0x3c4a6b,_0x1deacd,_0x235231){_0x79484d['dataUpdateCount']++;const _0x2fe1e7=new C(_0x9a166e);_0x3c4a6b=_0x79484d['interceptServerDataCallback_']?_0x79484d['interceptServerDataCallback_'](_0x9a166e,_0x3c4a6b):_0x3c4a6b;let _0x11fb24=[];if(_0x235231){if(_0x1deacd){const _0x586fe6=_n(_0x3c4a6b,_0x2af62c=>A(_0x2af62c));_0x11fb24=Qu(_0x79484d['serverSyncTree_'],_0x2fe1e7,_0x586fe6,_0x235231);}else{const _0x206428=A(_0x3c4a6b);_0x11fb24=Jo(_0x79484d['serverSyncTree_'],_0x2fe1e7,_0x206428,_0x235231);}}else{if(_0x1deacd){const _0x1a18d0=_n(_0x3c4a6b,_0x169594=>A(_0x169594));_0x11fb24=ju(_0x79484d['serverSyncTree_'],_0x2fe1e7,_0x1a18d0);}else{const _0xf48962=A(_0x3c4a6b);_0x11fb24=Kt(_0x79484d['serverSyncTree_'],_0x2fe1e7,_0xf48962);}}let _0x368a8e=_0x2fe1e7;_0x11fb24['length']>0x0&&(_0x368a8e=ct(_0x79484d,_0x2fe1e7)),V(_0x79484d['eventQueue_'],_0x368a8e,_0x11fb24);}function mr(_0x1cd251,_0x4822b4){vs(_0x1cd251,'connected',_0x4822b4),_0x4822b4===!0x1&&Td(_0x1cd251);}function Ed(_0x5b2857,_0x27887d){x(_0x27887d,(_0x42b1d3,_0x155fe2)=>{vs(_0x5b2857,_0x42b1d3,_0x155fe2);});}function vs(_0x1b1596,_0x21c822,_0x5b9d05){const _0x34a1ad=new C('/.info/'+_0x21c822),_0x1e0292=A(_0x5b9d05);_0x1b1596['infoData_']['updateSnapshot'](_0x34a1ad,_0x1e0292);const _0x3b824b=Kt(_0x1b1596['infoSyncTree_'],_0x34a1ad,_0x1e0292);V(_0x1b1596['eventQueue_'],_0x34a1ad,_0x3b824b);}function zn(_0x2b2749){return _0x2b2749['nextWriteId_']++;}function Id(_0x543936,_0x46bd29,_0x16d7ee){const _0x30aa4d=Ju(_0x543936['serverSyncTree_'],_0x46bd29);return _0x30aa4d!=null?Promise['resolve'](_0x30aa4d):_0x543936['server_']['get'](_0x46bd29)['then'](_0x11db54=>{const _0x293797=A(_0x11db54)['withIndex'](_0x46bd29['_queryParams']['getIndex']());Pi(_0x543936['serverSyncTree_'],_0x46bd29,_0x16d7ee,!0x0);let _0x2605d9;if(_0x46bd29['_queryParams']['loadsAllData']())_0x2605d9=Kt(_0x543936['serverSyncTree_'],_0x46bd29['_path'],_0x293797);else{const _0x9064f0=Ut(_0x543936['serverSyncTree_'],_0x46bd29);_0x2605d9=Jo(_0x543936['serverSyncTree_'],_0x46bd29['_path'],_0x293797,_0x9064f0);}return V(_0x543936['eventQueue_'],_0x46bd29['_path'],_0x2605d9),An(_0x543936['serverSyncTree_'],_0x46bd29,_0x16d7ee,null,!0x0),_0x293797;},_0x8bf28=>(gt(_0x543936,'get\x20for\x20query\x20'+O(_0x46bd29)+'\x20failed:\x20'+_0x8bf28),Promise['reject'](new Error(_0x8bf28))));}function wd(_0x4ca837,_0x175fbe,_0x12d989,_0x147ec6,_0x4fcab5){gt(_0x4ca837,'set',{'path':_0x175fbe['toString'](),'value':_0x12d989,'priority':_0x147ec6});const _0x1ac19d=Jt(_0x4ca837),_0xaa7071=A(_0x12d989,_0x147ec6),_0x360503=Vn(_0x4ca837['serverSyncTree_'],_0x175fbe),_0x20137e=fs(_0xaa7071,_0x360503,_0x1ac19d),_0x56df54=zn(_0x4ca837),_0x293fcd=as(_0x4ca837['serverSyncTree_'],_0x175fbe,_0x20137e,_0x56df54,!0x0);qn(_0x4ca837['eventQueue_'],_0x293fcd),_0x4ca837['server_']['put'](_0x175fbe['toString'](),_0xaa7071['val'](!0x0),(_0x20f347,_0x4b6735)=>{const _0x1d52e3=_0x20f347==='ok';_0x1d52e3||U('set\x20at\x20'+_0x175fbe+'\x20failed:\x20'+_0x20f347);const _0x2d60a3=_e(_0x4ca837['serverSyncTree_'],_0x56df54,!_0x1d52e3);V(_0x4ca837['eventQueue_'],_0x175fbe,_0x2d60a3),be(_0x4ca837,_0x4fcab5,_0x20f347,_0x4b6735);});const _0x104454=Is(_0x4ca837,_0x175fbe);ct(_0x4ca837,_0x104454),V(_0x4ca837['eventQueue_'],_0x104454,[]);}function Cd(_0x55e491,_0x1e1f5f,_0x2c02f0,_0x3dc9c8){gt(_0x55e491,'update',{'path':_0x1e1f5f['toString'](),'value':_0x2c02f0});let _0x512760=!0x0;const _0x5620f9=Jt(_0x55e491),_0x14159={};if(x(_0x2c02f0,(_0x5552e4,_0xcd5c32)=>{_0x512760=!0x1,_0x14159[_0x5552e4]=ta(k(_0x1e1f5f,_0x5552e4),A(_0xcd5c32),_0x55e491['serverSyncTree_'],_0x5620f9);}),_0x512760)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x55e491,_0x3dc9c8,'ok',void 0x0);else{const _0x21e204=zn(_0x55e491),_0x22af92=zu(_0x55e491['serverSyncTree_'],_0x1e1f5f,_0x14159,_0x21e204);qn(_0x55e491['eventQueue_'],_0x22af92),_0x55e491['server_']['merge'](_0x1e1f5f['toString'](),_0x2c02f0,(_0x1a2bae,_0x445cb8)=>{const _0x42125a=_0x1a2bae==='ok';_0x42125a||U('update\x20at\x20'+_0x1e1f5f+'\x20failed:\x20'+_0x1a2bae);const _0x556cd0=_e(_0x55e491['serverSyncTree_'],_0x21e204,!_0x42125a),_0x5be174=_0x556cd0['length']>0x0?ct(_0x55e491,_0x1e1f5f):_0x1e1f5f;V(_0x55e491['eventQueue_'],_0x5be174,_0x556cd0),be(_0x55e491,_0x3dc9c8,_0x1a2bae,_0x445cb8);}),x(_0x2c02f0,_0x6fb972=>{const _0x349b12=Is(_0x55e491,k(_0x1e1f5f,_0x6fb972));ct(_0x55e491,_0x349b12);}),V(_0x55e491['eventQueue_'],_0x1e1f5f,[]);}}function Td(_0xebd28c){gt(_0xebd28c,'onDisconnectEvents');const _0xc5e513=Jt(_0xebd28c),_0x38cf33=En();Si(_0xebd28c['onDisconnect_'],w(),(_0x326557,_0x35e13a)=>{const _0x3cebe6=ta(_0x326557,_0x35e13a,_0xebd28c['serverSyncTree_'],_0xc5e513);pt(_0x38cf33,_0x326557,_0x3cebe6);});let _0x70ed4f=[];Si(_0x38cf33,w(),(_0x589dee,_0x41ae0d)=>{_0x70ed4f=_0x70ed4f['concat'](Kt(_0xebd28c['serverSyncTree_'],_0x589dee,_0x41ae0d));const _0x506dac=Is(_0xebd28c,_0x589dee);ct(_0xebd28c,_0x506dac);}),_0xebd28c['onDisconnect_']=En(),V(_0xebd28c['eventQueue_'],w(),_0x70ed4f);}function Sd(_0x2695b2,_0x1ecc37,_0x598ce5){_0x2695b2['server_']['onDisconnectCancel'](_0x1ecc37['toString'](),(_0x45fc61,_0x144836)=>{_0x45fc61==='ok'&&Ti(_0x2695b2['onDisconnect_'],_0x1ecc37),be(_0x2695b2,_0x598ce5,_0x45fc61,_0x144836);});}function yr(_0x5098f8,_0x50355f,_0x48d6bd,_0x4e7534){const _0x18f978=A(_0x48d6bd);_0x5098f8['server_']['onDisconnectPut'](_0x50355f['toString'](),_0x18f978['val'](!0x0),(_0x51bd69,_0x3a4357)=>{_0x51bd69==='ok'&&pt(_0x5098f8['onDisconnect_'],_0x50355f,_0x18f978),be(_0x5098f8,_0x4e7534,_0x51bd69,_0x3a4357);});}function bd(_0x208661,_0x45d5d8,_0xd18a01,_0x13ddd8,_0x52aa67){const _0x2cb1f9=A(_0xd18a01,_0x13ddd8);_0x208661['server_']['onDisconnectPut'](_0x45d5d8['toString'](),_0x2cb1f9['val'](!0x0),(_0x4fec35,_0x31eb69)=>{_0x4fec35==='ok'&&pt(_0x208661['onDisconnect_'],_0x45d5d8,_0x2cb1f9),be(_0x208661,_0x52aa67,_0x4fec35,_0x31eb69);});}function Rd(_0x382767,_0x50147c,_0x2f62f1,_0x5215c5){if(pn(_0x2f62f1)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x382767,_0x5215c5,'ok',void 0x0);return;}_0x382767['server_']['onDisconnectMerge'](_0x50147c['toString'](),_0x2f62f1,(_0x37be75,_0x3fb072)=>{_0x37be75==='ok'&&x(_0x2f62f1,(_0x3822e7,_0x548429)=>{const _0x370d51=A(_0x548429);pt(_0x382767['onDisconnect_'],k(_0x50147c,_0x3822e7),_0x370d51);}),be(_0x382767,_0x5215c5,_0x37be75,_0x3fb072);});}function Ad(_0x5a849d,_0x1869e0,_0x4dfe92){let _0x53fa78;y(_0x1869e0['_path'])==='.info'?_0x53fa78=Pi(_0x5a849d['infoSyncTree_'],_0x1869e0,_0x4dfe92):_0x53fa78=Pi(_0x5a849d['serverSyncTree_'],_0x1869e0,_0x4dfe92),oa(_0x5a849d['eventQueue_'],_0x1869e0['_path'],_0x53fa78);}function kd(_0x38ebb1,_0x2a86d7,_0x5aa846){let _0x424aa7;y(_0x2a86d7['_path'])==='.info'?_0x424aa7=An(_0x38ebb1['infoSyncTree_'],_0x2a86d7,_0x5aa846):_0x424aa7=An(_0x38ebb1['serverSyncTree_'],_0x2a86d7,_0x5aa846),oa(_0x38ebb1['eventQueue_'],_0x2a86d7['_path'],_0x424aa7);}function ha(_0x13b7fb){_0x13b7fb['persistentConnection_']&&_0x13b7fb['persistentConnection_']['interrupt'](ca);}function Nd(_0xb13b5b){_0xb13b5b['persistentConnection_']&&_0xb13b5b['persistentConnection_']['resume'](ca);}function gt(_0x1b6c92,..._0x2d9fb9){let _0x386fdd='';_0x1b6c92['persistentConnection_']&&(_0x386fdd=_0x1b6c92['persistentConnection_']['id']+':'),L(_0x386fdd,..._0x2d9fb9);}function be(_0x1be651,_0xd95665,_0x37618e,_0x5ab9a5){_0xd95665&&ft(()=>{if(_0x37618e==='ok')_0xd95665(null);else{const _0x2cd5b4=(_0x37618e||'error')['toUpperCase']();let _0x2447b6=_0x2cd5b4;_0x5ab9a5&&(_0x2447b6+=':\x20'+_0x5ab9a5);const _0xf72a7=new Error(_0x2447b6);_0xf72a7['code']=_0x2cd5b4,_0xd95665(_0xf72a7);}});}function Pd(_0x17f78e,_0x523edc,_0x3f0cd5,_0x435bd6,_0x31c9d1,_0x3a6999){gt(_0x17f78e,'transaction\x20on\x20'+_0x523edc);const _0x1b351e={'path':_0x523edc,'update':_0x3f0cd5,'onComplete':_0x435bd6,'status':null,'order':so(),'applyLocally':_0x3a6999,'retryCount':0x0,'unwatcher':_0x31c9d1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3e23e0=Es(_0x17f78e,_0x523edc,void 0x0);_0x1b351e['currentInputSnapshot']=_0x3e23e0;const _0xdb6f0c=_0x1b351e['update'](_0x3e23e0['val']());if(_0xdb6f0c===void 0x0)_0x1b351e['unwatcher'](),_0x1b351e['currentOutputSnapshotRaw']=null,_0x1b351e['currentOutputSnapshotResolved']=null,_0x1b351e['onComplete']&&_0x1b351e['onComplete'](null,!0x1,_0x1b351e['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0xdb6f0c,_0x1b351e['path']),_0x1b351e['status']=0x0;const _0xbe20e=$n(_0x17f78e['transactionQueueTree_'],_0x523edc),_0x2b20fb=ze(_0xbe20e)||[];_0x2b20fb['push'](_0x1b351e),gs(_0xbe20e,_0x2b20fb);let _0x402ee9;typeof _0xdb6f0c=='object'&&_0xdb6f0c!==null&&Q(_0xdb6f0c,'.priority')?(_0x402ee9=Me(_0xdb6f0c,'.priority'),f(Wt(_0x402ee9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x402ee9=(Vn(_0x17f78e['serverSyncTree_'],_0x523edc)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xf58cf2=Jt(_0x17f78e),_0x208a1f=A(_0xdb6f0c,_0x402ee9),_0x434b4c=fs(_0x208a1f,_0x3e23e0,_0xf58cf2);_0x1b351e['currentOutputSnapshotRaw']=_0x208a1f,_0x1b351e['currentOutputSnapshotResolved']=_0x434b4c,_0x1b351e['currentWriteId']=zn(_0x17f78e);const _0x46dcc5=as(_0x17f78e['serverSyncTree_'],_0x523edc,_0x434b4c,_0x1b351e['currentWriteId'],_0x1b351e['applyLocally']);V(_0x17f78e['eventQueue_'],_0x523edc,_0x46dcc5),jn(_0x17f78e,_0x17f78e['transactionQueueTree_']);}}function Es(_0x15d51c,_0x1fc3f9,_0x3ad593){return Vn(_0x15d51c['serverSyncTree_'],_0x1fc3f9,_0x3ad593)||g['EMPTY_NODE'];}function jn(_0x5d04ed,_0x3c95fe=_0x5d04ed['transactionQueueTree_']){if(_0x3c95fe||Kn(_0x5d04ed,_0x3c95fe),ze(_0x3c95fe)){const _0x5c513c=da(_0x5d04ed,_0x3c95fe);f(_0x5c513c['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5c513c['every'](_0x32a3e2=>_0x32a3e2['status']===0x0)&&Od(_0x5d04ed,Yt(_0x3c95fe),_0x5c513c);}else na(_0x3c95fe)&&Gn(_0x3c95fe,_0x3bf970=>{jn(_0x5d04ed,_0x3bf970);});}function Od(_0x3d7111,_0x17b266,_0x1b6515){const _0x56de14=_0x1b6515['map'](_0x44a908=>_0x44a908['currentWriteId']),_0x180303=Es(_0x3d7111,_0x17b266,_0x56de14);let _0x42ffb9=_0x180303;const _0x59ee5f=_0x180303['hash']();for(let _0x94d8f1=0x0;_0x94d8f1<_0x1b6515['length'];_0x94d8f1++){const _0xae3b49=_0x1b6515[_0x94d8f1];f(_0xae3b49['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xae3b49['status']=0x1,_0xae3b49['retryCount']++;const _0x309872=F(_0x17b266,_0xae3b49['path']);_0x42ffb9=_0x42ffb9['updateChild'](_0x309872,_0xae3b49['currentOutputSnapshotRaw']);}const _0x3158be=_0x42ffb9['val'](!0x0),_0x3014e4=_0x17b266;_0x3d7111['server_']['put'](_0x3014e4['toString'](),_0x3158be,_0x473e71=>{gt(_0x3d7111,'transaction\x20put\x20response',{'path':_0x3014e4['toString'](),'status':_0x473e71});let _0x2c12c3=[];if(_0x473e71==='ok'){const _0x10e78c=[];for(let _0x574342=0x0;_0x574342<_0x1b6515['length'];_0x574342++)_0x1b6515[_0x574342]['status']=0x2,_0x2c12c3=_0x2c12c3['concat'](_e(_0x3d7111['serverSyncTree_'],_0x1b6515[_0x574342]['currentWriteId'])),_0x1b6515[_0x574342]['onComplete']&&_0x10e78c['push'](()=>_0x1b6515[_0x574342]['onComplete'](null,!0x0,_0x1b6515[_0x574342]['currentOutputSnapshotResolved'])),_0x1b6515[_0x574342]['unwatcher']();Kn(_0x3d7111,$n(_0x3d7111['transactionQueueTree_'],_0x17b266)),jn(_0x3d7111,_0x3d7111['transactionQueueTree_']),V(_0x3d7111['eventQueue_'],_0x17b266,_0x2c12c3);for(let _0x10725f=0x0;_0x10725f<_0x10e78c['length'];_0x10725f++)ft(_0x10e78c[_0x10725f]);}else{if(_0x473e71==='datastale'){for(let _0x4a02f0=0x0;_0x4a02f0<_0x1b6515['length'];_0x4a02f0++)_0x1b6515[_0x4a02f0]['status']===0x3?_0x1b6515[_0x4a02f0]['status']=0x4:_0x1b6515[_0x4a02f0]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3014e4['toString']()+'\x20failed:\x20'+_0x473e71);for(let _0x282405=0x0;_0x282405<_0x1b6515['length'];_0x282405++)_0x1b6515[_0x282405]['status']=0x4,_0x1b6515[_0x282405]['abortReason']=_0x473e71;}ct(_0x3d7111,_0x17b266);}},_0x59ee5f);}function ct(_0x4b2f2c,_0x3c5312){const _0x6be313=ua(_0x4b2f2c,_0x3c5312),_0x3c2842=Yt(_0x6be313),_0x30856a=da(_0x4b2f2c,_0x6be313);return Dd(_0x4b2f2c,_0x30856a,_0x3c2842),_0x3c2842;}function Dd(_0x1c437f,_0x31df50,_0x37f342){if(_0x31df50['length']===0x0)return;const _0x2b663e=[];let _0xb90230=[];const _0x244141=_0x31df50['filter'](_0x59c0ff=>_0x59c0ff['status']===0x0)['map'](_0x11bfd4=>_0x11bfd4['currentWriteId']);for(let _0x39e291=0x0;_0x39e291<_0x31df50['length'];_0x39e291++){const _0x2a363f=_0x31df50[_0x39e291],_0x48d474=F(_0x37f342,_0x2a363f['path']);let _0xd919ee=!0x1,_0x57cfe7;if(f(_0x48d474!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2a363f['status']===0x4)_0xd919ee=!0x0,_0x57cfe7=_0x2a363f['abortReason'],_0xb90230=_0xb90230['concat'](_e(_0x1c437f['serverSyncTree_'],_0x2a363f['currentWriteId'],!0x0));else{if(_0x2a363f['status']===0x0){if(_0x2a363f['retryCount']>=md)_0xd919ee=!0x0,_0x57cfe7='maxretry',_0xb90230=_0xb90230['concat'](_e(_0x1c437f['serverSyncTree_'],_0x2a363f['currentWriteId'],!0x0));else{const _0xbd61f0=Es(_0x1c437f,_0x2a363f['path'],_0x244141);_0x2a363f['currentInputSnapshot']=_0xbd61f0;const _0x51ccc8=_0x31df50[_0x39e291]['update'](_0xbd61f0['val']());if(_0x51ccc8!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x51ccc8,_0x2a363f['path']);let _0x33c10b=A(_0x51ccc8);typeof _0x51ccc8=='object'&&_0x51ccc8!=null&&Q(_0x51ccc8,'.priority')||(_0x33c10b=_0x33c10b['updatePriority'](_0xbd61f0['getPriority']()));const _0x17a081=_0x2a363f['currentWriteId'],_0x4a89cc=Jt(_0x1c437f),_0x2c8367=fs(_0x33c10b,_0xbd61f0,_0x4a89cc);_0x2a363f['currentOutputSnapshotRaw']=_0x33c10b,_0x2a363f['currentOutputSnapshotResolved']=_0x2c8367,_0x2a363f['currentWriteId']=zn(_0x1c437f),_0x244141['splice'](_0x244141['indexOf'](_0x17a081),0x1),_0xb90230=_0xb90230['concat'](as(_0x1c437f['serverSyncTree_'],_0x2a363f['path'],_0x2c8367,_0x2a363f['currentWriteId'],_0x2a363f['applyLocally'])),_0xb90230=_0xb90230['concat'](_e(_0x1c437f['serverSyncTree_'],_0x17a081,!0x0));}else _0xd919ee=!0x0,_0x57cfe7='nodata',_0xb90230=_0xb90230['concat'](_e(_0x1c437f['serverSyncTree_'],_0x2a363f['currentWriteId'],!0x0));}}}V(_0x1c437f['eventQueue_'],_0x37f342,_0xb90230),_0xb90230=[],_0xd919ee&&(_0x31df50[_0x39e291]['status']=0x2,function(_0x5aa320){setTimeout(_0x5aa320,Math['floor'](0x0));}(_0x31df50[_0x39e291]['unwatcher']),_0x31df50[_0x39e291]['onComplete']&&(_0x57cfe7==='nodata'?_0x2b663e['push'](()=>_0x31df50[_0x39e291]['onComplete'](null,!0x1,_0x31df50[_0x39e291]['currentInputSnapshot'])):_0x2b663e['push'](()=>_0x31df50[_0x39e291]['onComplete'](new Error(_0x57cfe7),!0x1,null))));}Kn(_0x1c437f,_0x1c437f['transactionQueueTree_']);for(let _0x5acbcd=0x0;_0x5acbcd<_0x2b663e['length'];_0x5acbcd++)ft(_0x2b663e[_0x5acbcd]);jn(_0x1c437f,_0x1c437f['transactionQueueTree_']);}function ua(_0x506a2b,_0x36a669){let _0x10e4f3,_0x398c6c=_0x506a2b['transactionQueueTree_'];for(_0x10e4f3=y(_0x36a669);_0x10e4f3!==null&&ze(_0x398c6c)===void 0x0;)_0x398c6c=$n(_0x398c6c,_0x10e4f3),_0x36a669=S(_0x36a669),_0x10e4f3=y(_0x36a669);return _0x398c6c;}function da(_0x2a683d,_0x375ef5){const _0x2fc179=[];return fa(_0x2a683d,_0x375ef5,_0x2fc179),_0x2fc179['sort']((_0x5d2daa,_0x26a16f)=>_0x5d2daa['order']-_0x26a16f['order']),_0x2fc179;}function fa(_0x39fb9b,_0x25c812,_0x217e45){const _0x176449=ze(_0x25c812);if(_0x176449){for(let _0x2810a5=0x0;_0x2810a5<_0x176449['length'];_0x2810a5++)_0x217e45['push'](_0x176449[_0x2810a5]);}Gn(_0x25c812,_0x5b1690=>{fa(_0x39fb9b,_0x5b1690,_0x217e45);});}function Kn(_0x30955b,_0x43293a){const _0x336cc1=ze(_0x43293a);if(_0x336cc1){let _0x35fcdc=0x0;for(let _0x1b1406=0x0;_0x1b1406<_0x336cc1['length'];_0x1b1406++)_0x336cc1[_0x1b1406]['status']!==0x2&&(_0x336cc1[_0x35fcdc]=_0x336cc1[_0x1b1406],_0x35fcdc++);_0x336cc1['length']=_0x35fcdc,gs(_0x43293a,_0x336cc1['length']>0x0?_0x336cc1:void 0x0);}Gn(_0x43293a,_0x33eca4=>{Kn(_0x30955b,_0x33eca4);});}function Is(_0x5bca94,_0xcc28e7){const _0x29e5e3=Yt(ua(_0x5bca94,_0xcc28e7)),_0x2ad829=$n(_0x5bca94['transactionQueueTree_'],_0xcc28e7);return od(_0x2ad829,_0x24f688=>{di(_0x5bca94,_0x24f688);}),di(_0x5bca94,_0x2ad829),ia(_0x2ad829,_0x2c4c1d=>{di(_0x5bca94,_0x2c4c1d);}),_0x29e5e3;}function di(_0x307bed,_0x321740){const _0x4b6104=ze(_0x321740);if(_0x4b6104){const _0x4750fd=[];let _0x51d74e=[],_0x78a060=-0x1;for(let _0x4bdb0b=0x0;_0x4bdb0b<_0x4b6104['length'];_0x4bdb0b++)_0x4b6104[_0x4bdb0b]['status']===0x3||(_0x4b6104[_0x4bdb0b]['status']===0x1?(f(_0x78a060===_0x4bdb0b-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x78a060=_0x4bdb0b,_0x4b6104[_0x4bdb0b]['status']=0x3,_0x4b6104[_0x4bdb0b]['abortReason']='set'):(f(_0x4b6104[_0x4bdb0b]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4b6104[_0x4bdb0b]['unwatcher'](),_0x51d74e=_0x51d74e['concat'](_e(_0x307bed['serverSyncTree_'],_0x4b6104[_0x4bdb0b]['currentWriteId'],!0x0)),_0x4b6104[_0x4bdb0b]['onComplete']&&_0x4750fd['push'](_0x4b6104[_0x4bdb0b]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x78a060===-0x1?gs(_0x321740,void 0x0):_0x4b6104['length']=_0x78a060+0x1,V(_0x307bed['eventQueue_'],Yt(_0x321740),_0x51d74e);for(let _0x1e9a08=0x0;_0x1e9a08<_0x4750fd['length'];_0x1e9a08++)ft(_0x4750fd[_0x1e9a08]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x2ba6ae){let _0x1c108e='';const _0x1b0e65=_0x2ba6ae['split']('/');for(let _0x1bbe0b=0x0;_0x1bbe0b<_0x1b0e65['length'];_0x1bbe0b++)if(_0x1b0e65[_0x1bbe0b]['length']>0x0){let _0x2cbdf2=_0x1b0e65[_0x1bbe0b];try{_0x2cbdf2=decodeURIComponent(_0x2cbdf2['replace'](/\+/g,'\x20'));}catch{}_0x1c108e+='/'+_0x2cbdf2;}return _0x1c108e;}function Ld(_0x235b37){const _0xad5a7={};_0x235b37['charAt'](0x0)==='?'&&(_0x235b37=_0x235b37['substring'](0x1));for(const _0x49bc3c of _0x235b37['split']('&')){if(_0x49bc3c['length']===0x0)continue;const _0x59f9d0=_0x49bc3c['split']('=');_0x59f9d0['length']===0x2?_0xad5a7[decodeURIComponent(_0x59f9d0[0x0])]=decodeURIComponent(_0x59f9d0[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x49bc3c+'\x27\x20in\x20query\x20\x27'+_0x235b37+'\x27');}return _0xad5a7;}const vr=function(_0x307a0f,_0x2a521c){const _0x38feee=xd(_0x307a0f),_0x335b35=_0x38feee['namespace'];_0x38feee['domain']==='firebase.com'&&ae(_0x38feee['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x335b35||_0x335b35==='undefined')&&_0x38feee['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x38feee['secure']||$l();const _0x4294c7=_0x38feee['scheme']==='ws'||_0x38feee['scheme']==='wss';return{'repoInfo':new yo(_0x38feee['host'],_0x38feee['secure'],_0x335b35,_0x4294c7,_0x2a521c,'',_0x335b35!==_0x38feee['subdomain']),'path':new C(_0x38feee['pathString'])};},xd=function(_0x4f5d93){let _0x44f093='',_0x31c220='',_0x2684dd='',_0x19bcdf='',_0x133978='',_0x468920=!0x0,_0x256beb='https',_0x14c3e6=0x1bb;if(typeof _0x4f5d93=='string'){let _0x4ba9a2=_0x4f5d93['indexOf']('//');_0x4ba9a2>=0x0&&(_0x256beb=_0x4f5d93['substring'](0x0,_0x4ba9a2-0x1),_0x4f5d93=_0x4f5d93['substring'](_0x4ba9a2+0x2));let _0x41f641=_0x4f5d93['indexOf']('/');_0x41f641===-0x1&&(_0x41f641=_0x4f5d93['length']);let _0x104aef=_0x4f5d93['indexOf']('?');_0x104aef===-0x1&&(_0x104aef=_0x4f5d93['length']),_0x44f093=_0x4f5d93['substring'](0x0,Math['min'](_0x41f641,_0x104aef)),_0x41f641<_0x104aef&&(_0x19bcdf=Md(_0x4f5d93['substring'](_0x41f641,_0x104aef)));const _0x37ce15=Ld(_0x4f5d93['substring'](Math['min'](_0x4f5d93['length'],_0x104aef)));_0x4ba9a2=_0x44f093['indexOf'](':'),_0x4ba9a2>=0x0?(_0x468920=_0x256beb==='https'||_0x256beb==='wss',_0x14c3e6=parseInt(_0x44f093['substring'](_0x4ba9a2+0x1),0xa)):_0x4ba9a2=_0x44f093['length'];const _0x46e524=_0x44f093['slice'](0x0,_0x4ba9a2);if(_0x46e524['toLowerCase']()==='localhost')_0x31c220='localhost';else{if(_0x46e524['split']('.')['length']<=0x2)_0x31c220=_0x46e524;else{const _0x37c2b8=_0x44f093['indexOf']('.');_0x2684dd=_0x44f093['substring'](0x0,_0x37c2b8)['toLowerCase'](),_0x31c220=_0x44f093['substring'](_0x37c2b8+0x1),_0x133978=_0x2684dd;}}'ns'in _0x37ce15&&(_0x133978=_0x37ce15['ns']);}return{'host':_0x44f093,'port':_0x14c3e6,'domain':_0x31c220,'subdomain':_0x2684dd,'secure':_0x468920,'scheme':_0x256beb,'pathString':_0x19bcdf,'namespace':_0x133978};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x4f0de7=0x0;const _0x2055a6=[];return function(_0x590b76){const _0x4be1eb=_0x590b76===_0x4f0de7;_0x4f0de7=_0x590b76;let _0x52c936;const _0x68700f=new Array(0x8);for(_0x52c936=0x7;_0x52c936>=0x0;_0x52c936--)_0x68700f[_0x52c936]=Er['charAt'](_0x590b76%0x40),_0x590b76=Math['floor'](_0x590b76/0x40);f(_0x590b76===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x16c94a=_0x68700f['join']('');if(_0x4be1eb){for(_0x52c936=0xb;_0x52c936>=0x0&&_0x2055a6[_0x52c936]===0x3f;_0x52c936--)_0x2055a6[_0x52c936]=0x0;_0x2055a6[_0x52c936]++;}else{for(_0x52c936=0x0;_0x52c936<0xc;_0x52c936++)_0x2055a6[_0x52c936]=Math['floor'](Math['random']()*0x40);}for(_0x52c936=0x0;_0x52c936<0xc;_0x52c936++)_0x16c94a+=Er['charAt'](_0x2055a6[_0x52c936]);return f(_0x16c94a['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x16c94a;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0x1548eb,_0x117866,_0x3f1bd0,_0x2bae82){this['eventType']=_0x1548eb,this['eventRegistration']=_0x117866,this['snapshot']=_0x3f1bd0,this['prevName']=_0x2bae82;}['getPath'](){const _0x5d1188=this['snapshot']['ref'];return this['eventType']==='value'?_0x5d1188['_path']:_0x5d1188['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0x84a128,_0x26641f,_0x159b98){this['eventRegistration']=_0x84a128,this['error']=_0x26641f,this['path']=_0x159b98;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x5765d5,_0x5dff2e){this['snapshotCallback']=_0x5765d5,this['cancelCallback']=_0x5dff2e;}['onValue'](_0x49162f,_0x3419a3){this['snapshotCallback']['call'](null,_0x49162f,_0x3419a3);}['onCancel'](_0x24f6b8){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x24f6b8);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1df0b9){return this['snapshotCallback']===_0x1df0b9['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1df0b9['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1df0b9['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x24e54a,_0xa79750){this['_repo']=_0x24e54a,this['_path']=_0xa79750;}['cancel'](){const _0x3ddbd2=new H();return Sd(this['_repo'],this['_path'],_0x3ddbd2['wrapCallback'](()=>{})),_0x3ddbd2['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x47ea00=new H();return yr(this['_repo'],this['_path'],null,_0x47ea00['wrapCallback'](()=>{})),_0x47ea00['promise'];}['set'](_0x2f640a){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x2f640a,this['_path'],!0x1);const _0x5549e2=new H();return yr(this['_repo'],this['_path'],_0x2f640a,_0x5549e2['wrapCallback'](()=>{})),_0x5549e2['promise'];}['setWithPriority'](_0x22c471,_0x27e033){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x22c471,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x27e033);const _0x3241df=new H();return bd(this['_repo'],this['_path'],_0x22c471,_0x27e033,_0x3241df['wrapCallback'](()=>{})),_0x3241df['promise'];}['update'](_0x3142ff){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x3142ff,this['_path']);const _0x216712=new H();return Rd(this['_repo'],this['_path'],_0x3142ff,_0x216712['wrapCallback'](()=>{})),_0x216712['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x439d6c,_0xd7044f,_0x55f2f0,_0x10a4c2){this['_repo']=_0x439d6c,this['_path']=_0xd7044f,this['_queryParams']=_0x55f2f0,this['_orderByCalled']=_0x10a4c2;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x386ff2=sr(this['_queryParams']),_0x23a054=$i(_0x386ff2);return _0x23a054==='{}'?'default':_0x23a054;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x26fe7d){if(_0x26fe7d=N(_0x26fe7d),!(_0x26fe7d instanceof je))return!0x1;const _0x423627=this['_repo']===_0x26fe7d['_repo'],_0x2cefcd=Ki(this['_path'],_0x26fe7d['_path']),_0xbda0d=this['_queryIdentifier']===_0x26fe7d['_queryIdentifier'];return _0x423627&&_0x2cefcd&&_0xbda0d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1639bb,_0x35b810){if(_0x1639bb['_orderByCalled']===!0x0)throw new Error(_0x35b810+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x5d10df){let _0x4265ac=null,_0x39e940=null;if(_0x5d10df['hasStart']()&&(_0x4265ac=_0x5d10df['getIndexStartValue']()),_0x5d10df['hasEnd']()&&(_0x39e940=_0x5d10df['getIndexEndValue']()),_0x5d10df['getIndex']()===ve){const _0x466587='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3df674='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x5d10df['hasStart']()){if(_0x5d10df['getIndexStartName']()!==Ue)throw new Error(_0x466587);if(typeof _0x4265ac!='string')throw new Error(_0x3df674);}if(_0x5d10df['hasEnd']()){if(_0x5d10df['getIndexEndName']()!==we)throw new Error(_0x466587);if(typeof _0x39e940!='string')throw new Error(_0x3df674);}}else{if(_0x5d10df['getIndex']()===R){if(_0x4265ac!=null&&!Wt(_0x4265ac)||_0x39e940!=null&&!Wt(_0x39e940))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x5d10df['getIndex']()instanceof Ji||_0x5d10df['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4265ac!=null&&typeof _0x4265ac=='object'||_0x39e940!=null&&typeof _0x39e940=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x13b1a7){if(_0x13b1a7['hasStart']()&&_0x13b1a7['hasEnd']()&&_0x13b1a7['hasLimit']()&&!_0x13b1a7['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0x4d0b29,_0xa024ea){super(_0x4d0b29,_0xa024ea,new Zi(),!0x1);}get['parent'](){const _0x5edee8=Ro(this['_path']);return _0x5edee8===null?null:new ee(this['_repo'],_0x5edee8);}get['root'](){let _0x48db93=this;for(;_0x48db93['parent']!==null;)_0x48db93=_0x48db93['parent'];return _0x48db93;}}class lt{constructor(_0x434d41,_0x487f3d,_0x42e10e){this['_node']=_0x434d41,this['ref']=_0x487f3d,this['_index']=_0x42e10e;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x582d92){const _0x740e19=new C(_0x582d92),_0x5a415d=Bt(this['ref'],_0x582d92);return new lt(this['_node']['getChild'](_0x740e19),_0x5a415d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x528e16){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2631e0,_0x5cfce4)=>_0x528e16(new lt(_0x5cfce4,Bt(this['ref'],_0x2631e0),R)));}['hasChild'](_0x5296e6){const _0x3f8114=new C(_0x5296e6);return!this['_node']['getChild'](_0x3f8114)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x546ad9,_0x3bcda2){return _0x546ad9=N(_0x546ad9),_0x546ad9['_checkNotDeleted']('ref'),_0x3bcda2!==void 0x0?Bt(_0x546ad9['_root'],_0x3bcda2):_0x546ad9['_root'];}function Bt(_0x30077a,_0x8a8a41){return _0x30077a=N(_0x30077a),y(_0x30077a['_path'])===null?fd('child','path',_0x8a8a41):ys('child','path',_0x8a8a41),new ee(_0x30077a['_repo'],k(_0x30077a['_path'],_0x8a8a41));}function m_(_0x5e83cf){return _0x5e83cf=N(_0x5e83cf),new Bd(_0x5e83cf['_repo'],_0x5e83cf['_path']);}function y_(_0x3fe839,_0x5e99ec){_0x3fe839=N(_0x3fe839),De('push',_0x3fe839['_path']),Ve('push',_0x5e99ec,_0x3fe839['_path'],!0x0);const _0x5cce10=la(_0x3fe839['_repo']),_0x39b5b8=Fd(_0x5cce10),_0x30434f=Bt(_0x3fe839,_0x39b5b8),_0x562bc2=Bt(_0x3fe839,_0x39b5b8);let _0x17359b;return _0x5e99ec!=null?_0x17359b=Vd(_0x562bc2,_0x5e99ec)['then'](()=>_0x562bc2):_0x17359b=Promise['resolve'](_0x562bc2),_0x30434f['then']=_0x17359b['then']['bind'](_0x17359b),_0x30434f['catch']=_0x17359b['then']['bind'](_0x17359b,void 0x0),_0x30434f;}function Vd(_0x1f45b8,_0x4864ee){_0x1f45b8=N(_0x1f45b8),De('set',_0x1f45b8['_path']),Ve('set',_0x4864ee,_0x1f45b8['_path'],!0x1);const _0x5d0d0b=new H();return wd(_0x1f45b8['_repo'],_0x1f45b8['_path'],_0x4864ee,null,_0x5d0d0b['wrapCallback'](()=>{})),_0x5d0d0b['promise'];}function v_(_0x5368e1,_0x1df1e4){ra('update',_0x1df1e4,_0x5368e1['_path']);const _0x44db50=new H();return Cd(_0x5368e1['_repo'],_0x5368e1['_path'],_0x1df1e4,_0x44db50['wrapCallback'](()=>{})),_0x44db50['promise'];}function E_(_0xafc624){_0xafc624=N(_0xafc624);const _0x1df575=new pa(()=>{}),_0x3a2b90=new Qn(_0x1df575);return Id(_0xafc624['_repo'],_0xafc624,_0x3a2b90)['then'](_0x2fcd77=>new lt(_0x2fcd77,new ee(_0xafc624['_repo'],_0xafc624['_path']),_0xafc624['_queryParams']['getIndex']()));}class Qn{constructor(_0x3649a6){this['callbackContext']=_0x3649a6;}['respondsTo'](_0x197bb2){return _0x197bb2==='value';}['createEvent'](_0x33609c,_0x1e6f0a){const _0x35017f=_0x1e6f0a['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x33609c['snapshotNode'],new ee(_0x1e6f0a['_repo'],_0x1e6f0a['_path']),_0x35017f));}['getEventRunner'](_0x344c8e){return _0x344c8e['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x344c8e['error']):()=>this['callbackContext']['onValue'](_0x344c8e['snapshot'],null);}['createCancelEvent'](_0x252bf7,_0x47dd54){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x252bf7,_0x47dd54):null;}['matches'](_0x475163){return _0x475163 instanceof Qn?!_0x475163['callbackContext']||!this['callbackContext']?!0x0:_0x475163['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x297326,_0x12df4e,_0x45fc02,_0x1d6e6a,_0x27a4b0){const _0x39a247=new pa(_0x45fc02,void 0x0),_0x5d8ffd=new Qn(_0x39a247);return Ad(_0x297326['_repo'],_0x297326,_0x5d8ffd),()=>kd(_0x297326['_repo'],_0x297326,_0x5d8ffd);}function $d(_0xcebf97,_0x29a1f1,_0x3c32c9,_0x1a2d5a){return Hd(_0xcebf97,'value',_0x29a1f1);}class Xt{}class ma extends Xt{constructor(_0x3f28ad,_0x10cc1a){super(),this['_value']=_0x3f28ad,this['_key']=_0x10cc1a,this['type']='endAt';}['_apply'](_0x16d065){Ve('endAt',this['_value'],_0x16d065['_path'],!0x0);const _0x387659=Qh(_0x16d065['_queryParams'],this['_value'],this['_key']);if(ga(_0x387659),Yn(_0x387659),_0x16d065['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x16d065['_repo'],_0x16d065['_path'],_0x387659,_0x16d065['_orderByCalled']);}}function I_(_0x4dbe7a,_0x14430f){return new ma(_0x4dbe7a,_0x14430f);}class ya extends Xt{constructor(_0x30c9e3,_0x365f35){super(),this['_value']=_0x30c9e3,this['_key']=_0x365f35,this['type']='startAt';}['_apply'](_0x594ca5){Ve('startAt',this['_value'],_0x594ca5['_path'],!0x0);const _0x156eba=Yh(_0x594ca5['_queryParams'],this['_value'],this['_key']);if(ga(_0x156eba),Yn(_0x156eba),_0x594ca5['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x594ca5['_repo'],_0x594ca5['_path'],_0x156eba,_0x594ca5['_orderByCalled']);}}function w_(_0x58223f=null,_0x47c1a3){return new ya(_0x58223f,_0x47c1a3);}class Gd extends Xt{constructor(_0x43eb92){super(),this['_path']=_0x43eb92,this['type']='orderByChild';}['_apply'](_0x53a47d){_a(_0x53a47d,'orderByChild');const _0x37509a=new C(this['_path']);if(v(_0x37509a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x39dbc4=new Ji(_0x37509a),_0x13b2d0=xo(_0x53a47d['_queryParams'],_0x39dbc4);return Yn(_0x13b2d0),new je(_0x53a47d['_repo'],_0x53a47d['_path'],_0x13b2d0,!0x0);}}function C_(_0x236406){if(_0x236406==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x236406==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x236406==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x236406),new Gd(_0x236406);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2fa991){_a(_0x2fa991,'orderByKey');const _0x497b46=xo(_0x2fa991['_queryParams'],ve);return Yn(_0x497b46),new je(_0x2fa991['_repo'],_0x2fa991['_path'],_0x497b46,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0xbb0244,_0x43a13f){super(),this['_value']=_0xbb0244,this['_key']=_0x43a13f,this['type']='equalTo';}['_apply'](_0x7e3b51){if(Ve('equalTo',this['_value'],_0x7e3b51['_path'],!0x1),_0x7e3b51['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x7e3b51['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x7e3b51));}}function S_(_0x337e8f,_0x5193c9){return new zd(_0x337e8f,_0x5193c9);}function b_(_0x4c0b89,..._0x3eaae4){let _0xa6a3d9=N(_0x4c0b89);for(const _0xfcf7e4 of _0x3eaae4)_0xa6a3d9=_0xfcf7e4['_apply'](_0xa6a3d9);return _0xa6a3d9;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x1cce6b,_0xda2f55,_0x2402be,_0x395c64){const _0x34ba78=_0xda2f55['lastIndexOf'](':'),_0x4fc8b4=_0xda2f55['substring'](0x0,_0x34ba78),_0x30b6ee=Gt(_0x4fc8b4);_0x1cce6b['repoInfo_']=new yo(_0xda2f55,_0x30b6ee,_0x1cce6b['repoInfo_']['namespace'],_0x1cce6b['repoInfo_']['webSocketOnly'],_0x1cce6b['repoInfo_']['nodeAdmin'],_0x1cce6b['repoInfo_']['persistenceKey'],_0x1cce6b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2402be),_0x395c64&&(_0x1cce6b['authTokenProvider_']=_0x395c64);}function Qd(_0x515eaa,_0x8ae732,_0x170359,_0x4f9722,_0x3c5ade){let _0x5dd35b=_0x4f9722||_0x515eaa['options']['databaseURL'];_0x5dd35b===void 0x0&&(_0x515eaa['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x515eaa['options']['projectId']),_0x5dd35b=_0x515eaa['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4865d6=vr(_0x5dd35b,_0x3c5ade),_0x17b476=_0x4865d6['repoInfo'],_0x5a9f12;typeof process<'u'&&Bs&&(_0x5a9f12=Bs[jd]),_0x5a9f12?(_0x5dd35b='http://'+_0x5a9f12+'?ns='+_0x17b476['namespace'],_0x4865d6=vr(_0x5dd35b,_0x3c5ade),_0x17b476=_0x4865d6['repoInfo']):_0x4865d6['repoInfo']['secure'];const _0xf768de=new eh(_0x515eaa['name'],_0x515eaa['options'],_0x8ae732);pd('Invalid\x20Firebase\x20Database\x20URL',_0x4865d6),v(_0x4865d6['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4adfe8=Xd(_0x17b476,_0x515eaa,_0xf768de,new Zl(_0x515eaa,_0x170359));return new Zd(_0x4adfe8,_0x515eaa);}function Jd(_0x2907ef,_0x5b40b2){const _0x23face=Di[_0x5b40b2];(!_0x23face||_0x23face[_0x2907ef['key']]!==_0x2907ef)&&ae('Database\x20'+_0x5b40b2+'('+_0x2907ef['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2907ef),delete _0x23face[_0x2907ef['key']];}function Xd(_0x43cdae,_0x26474f,_0x178489,_0x48c930){let _0x4e4df2=Di[_0x26474f['name']];_0x4e4df2||(_0x4e4df2={},Di[_0x26474f['name']]=_0x4e4df2);let _0x201d1e=_0x4e4df2[_0x43cdae['toURLString']()];return _0x201d1e&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x201d1e=new yd(_0x43cdae,Kd,_0x178489,_0x48c930),_0x4e4df2[_0x43cdae['toURLString']()]=_0x201d1e,_0x201d1e;}class Zd{constructor(_0x226b64,_0x562ec2){this['_repoInternal']=_0x226b64,this['app']=_0x562ec2,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x202886){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x202886+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0x387762=Zr(),_0x3e9ef9){const _0x26655c=Hi(_0x387762,'database')['getImmediate']({'identifier':_0x3e9ef9});if(!_0x26655c['_instanceStarted']){const _0x480150=hc('database');_0x480150&&ef(_0x26655c,..._0x480150);}return _0x26655c;}function ef(_0xa25c80,_0xab95f6,_0x12b2b5,_0x37ecbb={}){_0xa25c80=N(_0xa25c80),_0xa25c80['_checkNotDeleted']('useEmulator');const _0x4c241e=_0xab95f6+':'+_0x12b2b5,_0xda64fe=_0xa25c80['_repoInternal'];if(_0xa25c80['_instanceStarted']){if(_0x4c241e===_0xa25c80['_repoInternal']['repoInfo_']['host']&&Le(_0x37ecbb,_0xda64fe['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x375fbb;if(_0xda64fe['repoInfo_']['nodeAdmin'])_0x37ecbb['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x375fbb=new an(an['OWNER']);else{if(_0x37ecbb['mockUserToken']){const _0xd3d20f=typeof _0x37ecbb['mockUserToken']=='string'?_0x37ecbb['mockUserToken']:uc(_0x37ecbb['mockUserToken'],_0xa25c80['app']['options']['projectId']);_0x375fbb=new an(_0xd3d20f);}}Gt(_0xab95f6)&&Qr(_0xab95f6),Yd(_0xda64fe,_0x4c241e,_0x37ecbb,_0x375fbb);}function A_(_0x1bff04){_0x1bff04=N(_0x1bff04),_0x1bff04['_checkNotDeleted']('goOffline'),ha(_0x1bff04['_repo']);}function k_(_0x5f550b){_0x5f550b=N(_0x5f550b),_0x5f550b['_checkNotDeleted']('goOnline'),Nd(_0x5f550b['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0xbd6f9b){Ul(dt),st(new xe('database',(_0x4903d5,{instanceIdentifier:_0x113527})=>{const _0x566c53=_0x4903d5['getProvider']('app')['getImmediate'](),_0x426fc9=_0x4903d5['getProvider']('auth-internal'),_0x6087fe=_0x4903d5['getProvider']('app-check-internal');return Qd(_0x566c53,_0x426fc9,_0x6087fe,_0x113527);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xbd6f9b),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0x342f45,_0x242e97){this['committed']=_0x342f45,this['snapshot']=_0x242e97;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x4af86e,_0x5d4708,_0xb05e7e){if(_0x4af86e=N(_0x4af86e),De('Reference.transaction',_0x4af86e['_path']),_0x4af86e['key']==='.length'||_0x4af86e['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4af86e['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3c5b00=!0x0,_0x20e1d5=new H(),_0x3db1c2=(_0x44b87f,_0x35f489,_0x39713a)=>{let _0x348dad=null;_0x44b87f?_0x20e1d5['reject'](_0x44b87f):(_0x348dad=new lt(_0x39713a,new ee(_0x4af86e['_repo'],_0x4af86e['_path']),R),_0x20e1d5['resolve'](new sf(_0x35f489,_0x348dad)));},_0x2c3167=$d(_0x4af86e,()=>{});return Pd(_0x4af86e['_repo'],_0x4af86e['_path'],_0x5d4708,_0x3db1c2,_0x2c3167,_0x3c5b00),_0x20e1d5['promise'];}se['prototype']['simpleListen']=function(_0x1d7612,_0x5a91c0){this['sendRequest']('q',{'p':_0x1d7612},_0x5a91c0);},se['prototype']['echo']=function(_0x52b7cd,_0x4b0c6f){this['sendRequest']('echo',{'d':_0x52b7cd},_0x4b0c6f);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0x5aedcc,..._0x537cab){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5aedcc,..._0x537cab);}function cn(_0x260ea0,..._0x1c95c5){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x260ea0,..._0x1c95c5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x312c9c,..._0x2e0e1d){throw ws(_0x312c9c,..._0x2e0e1d);}function X(_0x3bc2c0,..._0x1ef13f){return ws(_0x3bc2c0,..._0x1ef13f);}function Ia(_0x3c17ad,_0x4e8b9f,_0x1bc05a){const _0x42ff13={...rf(),[_0x4e8b9f]:_0x1bc05a};return new $t('auth','Firebase',_0x42ff13)['create'](_0x4e8b9f,{'appName':_0x3c17ad['name']});}function re(_0x5eb80e){return Ia(_0x5eb80e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x39e2a5,..._0x28c8f6){if(typeof _0x39e2a5!='string'){const _0x16566e=_0x28c8f6[0x0],_0x564b44=[..._0x28c8f6['slice'](0x1)];return _0x564b44[0x0]&&(_0x564b44[0x0]['appName']=_0x39e2a5['name']),_0x39e2a5['_errorFactory']['create'](_0x16566e,..._0x564b44);}return Ea['create'](_0x39e2a5,..._0x28c8f6);}function m(_0x3c7079,_0x2fa3cf,..._0x181a49){if(!_0x3c7079)throw ws(_0x2fa3cf,..._0x181a49);}function ne(_0x1c56fb){const _0x2e69bf='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1c56fb;throw cn(_0x2e69bf),new Error(_0x2e69bf);}function ce(_0x2ee926,_0x3fb52a){_0x2ee926||ne(_0x3fb52a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x391128;return typeof self<'u'&&((_0x391128=self['location'])==null?void 0x0:_0x391128['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x28e915;return typeof self<'u'&&((_0x28e915=self['location'])==null?void 0x0:_0x28e915['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0xb34e08=navigator;return _0xb34e08['languages']&&_0xb34e08['languages'][0x0]||_0xb34e08['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4c29b2,_0x4bcc42){this['shortDelay']=_0x4c29b2,this['longDelay']=_0x4bcc42,ce(_0x4bcc42>_0x4c29b2,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x489e50,_0x5ace93){ce(_0x489e50['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x7393e9}=_0x489e50['emulator'];return _0x5ace93?''+_0x7393e9+(_0x5ace93['startsWith']('/')?_0x5ace93['slice'](0x1):_0x5ace93):_0x7393e9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x593bba,_0xf03c28,_0x213d2b){this['fetchImpl']=_0x593bba,_0xf03c28&&(this['headersImpl']=_0xf03c28),_0x213d2b&&(this['responseImpl']=_0x213d2b);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x14b832,_0x2ecef0){return _0x14b832['tenantId']&&!_0x2ecef0['tenantId']?{..._0x2ecef0,'tenantId':_0x14b832['tenantId']}:_0x2ecef0;}async function ke(_0x2f8bc0,_0x20e78e,_0x268782,_0x1db7c4,_0xa8b928={}){return Ca(_0x2f8bc0,_0xa8b928,async()=>{let _0x23b505={},_0x46e98d={};_0x1db7c4&&(_0x20e78e==='GET'?_0x46e98d=_0x1db7c4:_0x23b505={'body':JSON['stringify'](_0x1db7c4)});const _0xfcae1b=ut({..._0x46e98d,'key':_0x2f8bc0['config']['apiKey']})['slice'](0x1),_0xee7f72=await _0x2f8bc0['_getAdditionalHeaders']();_0xee7f72['Content-Type']='application/json',_0x2f8bc0['languageCode']&&(_0xee7f72['X-Firebase-Locale']=_0x2f8bc0['languageCode']);const _0x3251f5={'method':_0x20e78e,'headers':_0xee7f72,..._0x23b505};return dc()||(_0x3251f5['referrerPolicy']='strict-origin-when-cross-origin'),_0x2f8bc0['emulatorConfig']&&Gt(_0x2f8bc0['emulatorConfig']['host'])&&(_0x3251f5['credentials']='include'),wa['fetch']()(await Ta(_0x2f8bc0,_0x2f8bc0['config']['apiHost'],_0x268782,_0xfcae1b),_0x3251f5);});}async function Ca(_0x41b06a,_0x46e730,_0x616fba){_0x41b06a['_canInitEmulator']=!0x1;const _0x4d9892={...hf,..._0x46e730};try{const _0x1ad48e=new pf(_0x41b06a),_0x19d885=await Promise['race']([_0x616fba(),_0x1ad48e['promise']]);_0x1ad48e['clearNetworkTimeout']();const _0x3cb481=await _0x19d885['json']();if('needConfirmation'in _0x3cb481)throw on(_0x41b06a,'account-exists-with-different-credential',_0x3cb481);if(_0x19d885['ok']&&!('errorMessage'in _0x3cb481))return _0x3cb481;{const _0x202336=_0x19d885['ok']?_0x3cb481['errorMessage']:_0x3cb481['error']['message'],[_0x297154,_0x4ada57]=_0x202336['split']('\x20:\x20');if(_0x297154==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x41b06a,'credential-already-in-use',_0x3cb481);if(_0x297154==='EMAIL_EXISTS')throw on(_0x41b06a,'email-already-in-use',_0x3cb481);if(_0x297154==='USER_DISABLED')throw on(_0x41b06a,'user-disabled',_0x3cb481);const _0x44a162=_0x4d9892[_0x297154]||_0x297154['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4ada57)throw Ia(_0x41b06a,_0x44a162,_0x4ada57);Y(_0x41b06a,_0x44a162);}}catch(_0x1c0a22){if(_0x1c0a22 instanceof Re)throw _0x1c0a22;Y(_0x41b06a,'network-request-failed',{'message':String(_0x1c0a22)});}}async function en(_0x22fbeb,_0x5299be,_0x310842,_0x791715,_0x35fead={}){const _0x51b059=await ke(_0x22fbeb,_0x5299be,_0x310842,_0x791715,_0x35fead);return'mfaPendingCredential'in _0x51b059&&Y(_0x22fbeb,'multi-factor-auth-required',{'_serverResponse':_0x51b059}),_0x51b059;}async function Ta(_0x5cb71a,_0x4fd386,_0x46b108,_0x37a2f4){const _0x575708=''+_0x4fd386+_0x46b108+'?'+_0x37a2f4,_0x1e96c0=_0x5cb71a,_0x450317=_0x1e96c0['config']['emulator']?Cs(_0x5cb71a['config'],_0x575708):_0x5cb71a['config']['apiScheme']+'://'+_0x575708;return uf['includes'](_0x46b108)&&(await _0x1e96c0['_persistenceManagerAvailable'],_0x1e96c0['_getPersistenceType']()==='COOKIE')?_0x1e96c0['_getPersistence']()['_getFinalTarget'](_0x450317)['toString']():_0x450317;}function ff(_0x54699a){switch(_0x54699a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x426103){this['auth']=_0x426103,this['timer']=null,this['promise']=new Promise((_0x3131e3,_0x2108f8)=>{this['timer']=setTimeout(()=>_0x2108f8(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x118f83,_0x2da5c6,_0x9c2a85){const _0x31c08f={'appName':_0x118f83['name']};_0x9c2a85['email']&&(_0x31c08f['email']=_0x9c2a85['email']),_0x9c2a85['phoneNumber']&&(_0x31c08f['phoneNumber']=_0x9c2a85['phoneNumber']);const _0x123f4d=X(_0x118f83,_0x2da5c6,_0x31c08f);return _0x123f4d['customData']['_tokenResponse']=_0x9c2a85,_0x123f4d;}function wr(_0xf9dd){return _0xf9dd!==void 0x0&&_0xf9dd['enterprise']!==void 0x0;}class _f{constructor(_0x41d4fa){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x41d4fa['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x41d4fa['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x41d4fa['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xf5e625){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4a3998 of this['recaptchaEnforcementState'])if(_0x4a3998['provider']&&_0x4a3998['provider']===_0xf5e625)return ff(_0x4a3998['enforcementState']);return null;}['isProviderEnabled'](_0x3558c9){return this['getProviderEnforcementState'](_0x3558c9)==='ENFORCE'||this['getProviderEnforcementState'](_0x3558c9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0xaeb3b5,_0x50df4a){return ke(_0xaeb3b5,'GET','/v2/recaptchaConfig',Ae(_0xaeb3b5,_0x50df4a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x2f8ec3,_0xee62d){return ke(_0x2f8ec3,'POST','/v1/accounts:delete',_0xee62d);}async function Nn(_0x278aff,_0x976b08){return ke(_0x278aff,'POST','/v1/accounts:lookup',_0x976b08);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x5e65df){if(_0x5e65df)try{const _0x3f7502=new Date(Number(_0x5e65df));if(!isNaN(_0x3f7502['getTime']()))return _0x3f7502['toUTCString']();}catch{}}async function yf(_0xfd2dcf,_0x542ee3=!0x1){const _0x244ae1=N(_0xfd2dcf),_0x4c6333=await _0x244ae1['getIdToken'](_0x542ee3),_0x33b889=Ts(_0x4c6333);m(_0x33b889&&_0x33b889['exp']&&_0x33b889['auth_time']&&_0x33b889['iat'],_0x244ae1['auth'],'internal-error');const _0x2e58db=typeof _0x33b889['firebase']=='object'?_0x33b889['firebase']:void 0x0,_0x399580=_0x2e58db==null?void 0x0:_0x2e58db['sign_in_provider'];return{'claims':_0x33b889,'token':_0x4c6333,'authTime':kt(fi(_0x33b889['auth_time'])),'issuedAtTime':kt(fi(_0x33b889['iat'])),'expirationTime':kt(fi(_0x33b889['exp'])),'signInProvider':_0x399580||null,'signInSecondFactor':(_0x2e58db==null?void 0x0:_0x2e58db['sign_in_second_factor'])||null};}function fi(_0x4ca5d8){return Number(_0x4ca5d8)*0x3e8;}function Ts(_0x4e24d2){const [_0x4da458,_0x99933a,_0x5ebfd9]=_0x4e24d2['split']('.');if(_0x4da458===void 0x0||_0x99933a===void 0x0||_0x5ebfd9===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x26f23c=fn(_0x99933a);return _0x26f23c?JSON['parse'](_0x26f23c):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3824b2){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3824b2==null?void 0x0:_0x3824b2['toString']()),null;}}function Cr(_0x56dce7){const _0x41c336=Ts(_0x56dce7);return m(_0x41c336,'internal-error'),m(typeof _0x41c336['exp']<'u','internal-error'),m(typeof _0x41c336['iat']<'u','internal-error'),Number(_0x41c336['exp'])-Number(_0x41c336['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x500ad5,_0x53ba5e,_0x1954fd=!0x1){if(_0x1954fd)return _0x53ba5e;try{return await _0x53ba5e;}catch(_0x274e8d){throw _0x274e8d instanceof Re&&vf(_0x274e8d)&&_0x500ad5['auth']['currentUser']===_0x500ad5&&await _0x500ad5['auth']['signOut'](),_0x274e8d;}}function vf({code:_0x10fe2d}){return _0x10fe2d==='auth/user-disabled'||_0x10fe2d==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0x53dfda){this['user']=_0x53dfda,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x457fe3){if(_0x457fe3){const _0x12a7ba=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x12a7ba;}else{this['errorBackoff']=0x7530;const _0x1fbf56=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1fbf56);}}['schedule'](_0x5a0d97=!0x1){if(!this['isRunning'])return;const _0x2f3bd3=this['getInterval'](_0x5a0d97);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2f3bd3);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1cad05){(_0x1cad05==null?void 0x0:_0x1cad05['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x1c1a8f,_0x263e74){this['createdAt']=_0x1c1a8f,this['lastLoginAt']=_0x263e74,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x35e02b){this['createdAt']=_0x35e02b['createdAt'],this['lastLoginAt']=_0x35e02b['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0xbad59f){var _0x140d92;const _0x121979=_0xbad59f['auth'],_0x469c0f=await _0xbad59f['getIdToken'](),_0x29f963=await Vt(_0xbad59f,Nn(_0x121979,{'idToken':_0x469c0f}));m(_0x29f963==null?void 0x0:_0x29f963['users']['length'],_0x121979,'internal-error');const _0xab5401=_0x29f963['users'][0x0];_0xbad59f['_notifyReloadListener'](_0xab5401);const _0x2a1dc6=(_0x140d92=_0xab5401['providerUserInfo'])!=null&&_0x140d92['length']?Sa(_0xab5401['providerUserInfo']):[],_0x40178e=wf(_0xbad59f['providerData'],_0x2a1dc6),_0x2c2c86=_0xbad59f['isAnonymous'],_0x1adb69=!(_0xbad59f['email']&&_0xab5401['passwordHash'])&&!(_0x40178e!=null&&_0x40178e['length']),_0x2c74a2=_0x2c2c86?_0x1adb69:!0x1,_0xbc799d={'uid':_0xab5401['localId'],'displayName':_0xab5401['displayName']||null,'photoURL':_0xab5401['photoUrl']||null,'email':_0xab5401['email']||null,'emailVerified':_0xab5401['emailVerified']||!0x1,'phoneNumber':_0xab5401['phoneNumber']||null,'tenantId':_0xab5401['tenantId']||null,'providerData':_0x40178e,'metadata':new Li(_0xab5401['createdAt'],_0xab5401['lastLoginAt']),'isAnonymous':_0x2c74a2};Object['assign'](_0xbad59f,_0xbc799d);}async function If(_0x2f7156){const _0x3f22d8=N(_0x2f7156);await Pn(_0x3f22d8),await _0x3f22d8['auth']['_persistUserIfCurrent'](_0x3f22d8),_0x3f22d8['auth']['_notifyListenersIfCurrent'](_0x3f22d8);}function wf(_0x43f3c9,_0x17be26){return[..._0x43f3c9['filter'](_0x491f0e=>!_0x17be26['some'](_0x4b1004=>_0x4b1004['providerId']===_0x491f0e['providerId'])),..._0x17be26];}function Sa(_0x279786){return _0x279786['map'](({providerId:_0xa22836,..._0x46afb6})=>({'providerId':_0xa22836,'uid':_0x46afb6['rawId']||'','displayName':_0x46afb6['displayName']||null,'email':_0x46afb6['email']||null,'phoneNumber':_0x46afb6['phoneNumber']||null,'photoURL':_0x46afb6['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x492ac5,_0x55bad7){const _0x553806=await Ca(_0x492ac5,{},async()=>{const _0x5917c9=ut({'grant_type':'refresh_token','refresh_token':_0x55bad7})['slice'](0x1),{tokenApiHost:_0xa310dd,apiKey:_0xeb8895}=_0x492ac5['config'],_0x14d1bd=await Ta(_0x492ac5,_0xa310dd,'/v1/token','key='+_0xeb8895),_0x1f6bb5=await _0x492ac5['_getAdditionalHeaders']();_0x1f6bb5['Content-Type']='application/x-www-form-urlencoded';const _0x30e1f0={'method':'POST','headers':_0x1f6bb5,'body':_0x5917c9};return _0x492ac5['emulatorConfig']&&Gt(_0x492ac5['emulatorConfig']['host'])&&(_0x30e1f0['credentials']='include'),wa['fetch']()(_0x14d1bd,_0x30e1f0);});return{'accessToken':_0x553806['access_token'],'expiresIn':_0x553806['expires_in'],'refreshToken':_0x553806['refresh_token']};}async function Tf(_0xb777b0,_0x126d73){return ke(_0xb777b0,'POST','/v2/accounts:revokeToken',Ae(_0xb777b0,_0x126d73));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xe7176d){m(_0xe7176d['idToken'],'internal-error'),m(typeof _0xe7176d['idToken']<'u','internal-error'),m(typeof _0xe7176d['refreshToken']<'u','internal-error');const _0x11d2df='expiresIn'in _0xe7176d&&typeof _0xe7176d['expiresIn']<'u'?Number(_0xe7176d['expiresIn']):Cr(_0xe7176d['idToken']);this['updateTokensAndExpiration'](_0xe7176d['idToken'],_0xe7176d['refreshToken'],_0x11d2df);}['updateFromIdToken'](_0x54c5f6){m(_0x54c5f6['length']!==0x0,'internal-error');const _0x45ea3e=Cr(_0x54c5f6);this['updateTokensAndExpiration'](_0x54c5f6,null,_0x45ea3e);}async['getToken'](_0x246780,_0x1f11e9=!0x1){return!_0x1f11e9&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x246780,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x246780,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x56745d,_0x2d6c45){const {accessToken:_0x5f25a8,refreshToken:_0x104cfd,expiresIn:_0x5bd967}=await Cf(_0x56745d,_0x2d6c45);this['updateTokensAndExpiration'](_0x5f25a8,_0x104cfd,Number(_0x5bd967));}['updateTokensAndExpiration'](_0x587894,_0x1d3090,_0x1e6dd9){this['refreshToken']=_0x1d3090||null,this['accessToken']=_0x587894||null,this['expirationTime']=Date['now']()+_0x1e6dd9*0x3e8;}static['fromJSON'](_0x4cde52,_0x218d30){const {refreshToken:_0x3aa66c,accessToken:_0x207503,expirationTime:_0x2f2514}=_0x218d30,_0x2b97df=new et();return _0x3aa66c&&(m(typeof _0x3aa66c=='string','internal-error',{'appName':_0x4cde52}),_0x2b97df['refreshToken']=_0x3aa66c),_0x207503&&(m(typeof _0x207503=='string','internal-error',{'appName':_0x4cde52}),_0x2b97df['accessToken']=_0x207503),_0x2f2514&&(m(typeof _0x2f2514=='number','internal-error',{'appName':_0x4cde52}),_0x2b97df['expirationTime']=_0x2f2514),_0x2b97df;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5ec73c){this['accessToken']=_0x5ec73c['accessToken'],this['refreshToken']=_0x5ec73c['refreshToken'],this['expirationTime']=_0x5ec73c['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1aeff2,_0x3dda54){m(typeof _0x1aeff2=='string'||typeof _0x1aeff2>'u','internal-error',{'appName':_0x3dda54});}class j{constructor({uid:_0x33d0ba,auth:_0xd97e9e,stsTokenManager:_0x50707a,..._0x244a60}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x33d0ba,this['auth']=_0xd97e9e,this['stsTokenManager']=_0x50707a,this['accessToken']=_0x50707a['accessToken'],this['displayName']=_0x244a60['displayName']||null,this['email']=_0x244a60['email']||null,this['emailVerified']=_0x244a60['emailVerified']||!0x1,this['phoneNumber']=_0x244a60['phoneNumber']||null,this['photoURL']=_0x244a60['photoURL']||null,this['isAnonymous']=_0x244a60['isAnonymous']||!0x1,this['tenantId']=_0x244a60['tenantId']||null,this['providerData']=_0x244a60['providerData']?[..._0x244a60['providerData']]:[],this['metadata']=new Li(_0x244a60['createdAt']||void 0x0,_0x244a60['lastLoginAt']||void 0x0);}async['getIdToken'](_0x403688){const _0x290e3f=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x403688));return m(_0x290e3f,this['auth'],'internal-error'),this['accessToken']!==_0x290e3f&&(this['accessToken']=_0x290e3f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x290e3f;}['getIdTokenResult'](_0x2aca5b){return yf(this,_0x2aca5b);}['reload'](){return If(this);}['_assign'](_0x5e5c22){this!==_0x5e5c22&&(m(this['uid']===_0x5e5c22['uid'],this['auth'],'internal-error'),this['displayName']=_0x5e5c22['displayName'],this['photoURL']=_0x5e5c22['photoURL'],this['email']=_0x5e5c22['email'],this['emailVerified']=_0x5e5c22['emailVerified'],this['phoneNumber']=_0x5e5c22['phoneNumber'],this['isAnonymous']=_0x5e5c22['isAnonymous'],this['tenantId']=_0x5e5c22['tenantId'],this['providerData']=_0x5e5c22['providerData']['map'](_0x9ff3ec=>({..._0x9ff3ec})),this['metadata']['_copy'](_0x5e5c22['metadata']),this['stsTokenManager']['_assign'](_0x5e5c22['stsTokenManager']));}['_clone'](_0x4a9b7d){const _0x1136dd=new j({...this,'auth':_0x4a9b7d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1136dd['metadata']['_copy'](this['metadata']),_0x1136dd;}['_onReload'](_0x46f593){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x46f593,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3060d2){this['reloadListener']?this['reloadListener'](_0x3060d2):this['reloadUserInfo']=_0x3060d2;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x59f725,_0xf784ce=!0x1){let _0x3925e2=!0x1;_0x59f725['idToken']&&_0x59f725['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x59f725),_0x3925e2=!0x0),_0xf784ce&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3925e2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2655e6=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x2655e6})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1d1ef5=>({..._0x1d1ef5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x379ba9,_0x28a49f){const _0x36c755=_0x28a49f['displayName']??void 0x0,_0x34901b=_0x28a49f['email']??void 0x0,_0x2c47ae=_0x28a49f['phoneNumber']??void 0x0,_0x270e8d=_0x28a49f['photoURL']??void 0x0,_0x51e9f2=_0x28a49f['tenantId']??void 0x0,_0x2ffbd3=_0x28a49f['_redirectEventId']??void 0x0,_0x4ebbcc=_0x28a49f['createdAt']??void 0x0,_0x53d60f=_0x28a49f['lastLoginAt']??void 0x0,{uid:_0x418289,emailVerified:_0x35dc19,isAnonymous:_0x279299,providerData:_0x4f583d,stsTokenManager:_0x43bbb0}=_0x28a49f;m(_0x418289&&_0x43bbb0,_0x379ba9,'internal-error');const _0x232f08=et['fromJSON'](this['name'],_0x43bbb0);m(typeof _0x418289=='string',_0x379ba9,'internal-error'),le(_0x36c755,_0x379ba9['name']),le(_0x34901b,_0x379ba9['name']),m(typeof _0x35dc19=='boolean',_0x379ba9,'internal-error'),m(typeof _0x279299=='boolean',_0x379ba9,'internal-error'),le(_0x2c47ae,_0x379ba9['name']),le(_0x270e8d,_0x379ba9['name']),le(_0x51e9f2,_0x379ba9['name']),le(_0x2ffbd3,_0x379ba9['name']),le(_0x4ebbcc,_0x379ba9['name']),le(_0x53d60f,_0x379ba9['name']);const _0x3a66fb=new j({'uid':_0x418289,'auth':_0x379ba9,'email':_0x34901b,'emailVerified':_0x35dc19,'displayName':_0x36c755,'isAnonymous':_0x279299,'photoURL':_0x270e8d,'phoneNumber':_0x2c47ae,'tenantId':_0x51e9f2,'stsTokenManager':_0x232f08,'createdAt':_0x4ebbcc,'lastLoginAt':_0x53d60f});return _0x4f583d&&Array['isArray'](_0x4f583d)&&(_0x3a66fb['providerData']=_0x4f583d['map'](_0x83901a=>({..._0x83901a}))),_0x2ffbd3&&(_0x3a66fb['_redirectEventId']=_0x2ffbd3),_0x3a66fb;}static async['_fromIdTokenResponse'](_0x306e3c,_0x7a9d33,_0x4020e1=!0x1){const _0x312fdc=new et();_0x312fdc['updateFromServerResponse'](_0x7a9d33);const _0x15f107=new j({'uid':_0x7a9d33['localId'],'auth':_0x306e3c,'stsTokenManager':_0x312fdc,'isAnonymous':_0x4020e1});return await Pn(_0x15f107),_0x15f107;}static async['_fromGetAccountInfoResponse'](_0x54c9c9,_0x1c203e,_0x575e12){const _0x301ad1=_0x1c203e['users'][0x0];m(_0x301ad1['localId']!==void 0x0,'internal-error');const _0x62f03b=_0x301ad1['providerUserInfo']!==void 0x0?Sa(_0x301ad1['providerUserInfo']):[],_0x217c1e=!(_0x301ad1['email']&&_0x301ad1['passwordHash'])&&!(_0x62f03b!=null&&_0x62f03b['length']),_0x5a7f6f=new et();_0x5a7f6f['updateFromIdToken'](_0x575e12);const _0x3fea2b=new j({'uid':_0x301ad1['localId'],'auth':_0x54c9c9,'stsTokenManager':_0x5a7f6f,'isAnonymous':_0x217c1e}),_0x71e0cd={'uid':_0x301ad1['localId'],'displayName':_0x301ad1['displayName']||null,'photoURL':_0x301ad1['photoUrl']||null,'email':_0x301ad1['email']||null,'emailVerified':_0x301ad1['emailVerified']||!0x1,'phoneNumber':_0x301ad1['phoneNumber']||null,'tenantId':_0x301ad1['tenantId']||null,'providerData':_0x62f03b,'metadata':new Li(_0x301ad1['createdAt'],_0x301ad1['lastLoginAt']),'isAnonymous':!(_0x301ad1['email']&&_0x301ad1['passwordHash'])&&!(_0x62f03b!=null&&_0x62f03b['length'])};return Object['assign'](_0x3fea2b,_0x71e0cd),_0x3fea2b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2dc4a8){ce(_0x2dc4a8 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x57b004=Tr['get'](_0x2dc4a8);return _0x57b004?(ce(_0x57b004 instanceof _0x2dc4a8,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x57b004):(_0x57b004=new _0x2dc4a8(),Tr['set'](_0x2dc4a8,_0x57b004),_0x57b004);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x57f121,_0xe2c755){this['storage'][_0x57f121]=_0xe2c755;}async['_get'](_0x1a14ae){const _0x3a02e9=this['storage'][_0x1a14ae];return _0x3a02e9===void 0x0?null:_0x3a02e9;}async['_remove'](_0x2fa120){delete this['storage'][_0x2fa120];}['_addListener'](_0x34fd2c,_0x11dc4e){}['_removeListener'](_0x166772,_0x6d421f){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x78ff63,_0x564dfb,_0x4edc6d){return'firebase:'+_0x78ff63+':'+_0x564dfb+':'+_0x4edc6d;}class tt{constructor(_0x37c832,_0x4c64ef,_0x5e390a){this['persistence']=_0x37c832,this['auth']=_0x4c64ef,this['userKey']=_0x5e390a;const {config:_0x5228c6,name:_0x247103}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x5228c6['apiKey'],_0x247103),this['fullPersistenceKey']=ln('persistence',_0x5228c6['apiKey'],_0x247103),this['boundEventHandler']=_0x4c64ef['_onStorageEvent']['bind'](_0x4c64ef),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4f0726){return this['persistence']['_set'](this['fullUserKey'],_0x4f0726['toJSON']());}async['getCurrentUser'](){const _0xd6f775=await this['persistence']['_get'](this['fullUserKey']);if(!_0xd6f775)return null;if(typeof _0xd6f775=='string'){const _0x11ccd6=await Nn(this['auth'],{'idToken':_0xd6f775})['catch'](()=>{});return _0x11ccd6?j['_fromGetAccountInfoResponse'](this['auth'],_0x11ccd6,_0xd6f775):null;}return j['_fromJSON'](this['auth'],_0xd6f775);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x34c915){if(this['persistence']===_0x34c915)return;const _0xee9960=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x34c915,_0xee9960)return this['setCurrentUser'](_0xee9960);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x37f13f,_0x4dd716,_0x740670='authUser'){if(!_0x4dd716['length'])return new tt(ie(Sr),_0x37f13f,_0x740670);const _0xfcec5f=(await Promise['all'](_0x4dd716['map'](async _0x2a0d8b=>{if(await _0x2a0d8b['_isAvailable']())return _0x2a0d8b;})))['filter'](_0x1dfb16=>_0x1dfb16);let _0x4189eb=_0xfcec5f[0x0]||ie(Sr);const _0x41b503=ln(_0x740670,_0x37f13f['config']['apiKey'],_0x37f13f['name']);let _0x4c6ccf=null;for(const _0x483b51 of _0x4dd716)try{const _0x3c4836=await _0x483b51['_get'](_0x41b503);if(_0x3c4836){let _0x11619f;if(typeof _0x3c4836=='string'){const _0x11da3f=await Nn(_0x37f13f,{'idToken':_0x3c4836})['catch'](()=>{});if(!_0x11da3f)break;_0x11619f=await j['_fromGetAccountInfoResponse'](_0x37f13f,_0x11da3f,_0x3c4836);}else _0x11619f=j['_fromJSON'](_0x37f13f,_0x3c4836);_0x483b51!==_0x4189eb&&(_0x4c6ccf=_0x11619f),_0x4189eb=_0x483b51;break;}}catch{}const _0x49bd95=_0xfcec5f['filter'](_0x511fab=>_0x511fab['_shouldAllowMigration']);return!_0x4189eb['_shouldAllowMigration']||!_0x49bd95['length']?new tt(_0x4189eb,_0x37f13f,_0x740670):(_0x4189eb=_0x49bd95[0x0],_0x4c6ccf&&await _0x4189eb['_set'](_0x41b503,_0x4c6ccf['toJSON']()),await Promise['all'](_0x4dd716['map'](async _0x2e2132=>{if(_0x2e2132!==_0x4189eb)try{await _0x2e2132['_remove'](_0x41b503);}catch{}})),new tt(_0x4189eb,_0x37f13f,_0x740670));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x276f34){const _0x713fa2=_0x276f34['toLowerCase']();if(_0x713fa2['includes']('opera/')||_0x713fa2['includes']('opr/')||_0x713fa2['includes']('opios/'))return'Opera';if(Na(_0x713fa2))return'IEMobile';if(_0x713fa2['includes']('msie')||_0x713fa2['includes']('trident/'))return'IE';if(_0x713fa2['includes']('edge/'))return'Edge';if(Ra(_0x713fa2))return'Firefox';if(_0x713fa2['includes']('silk/'))return'Silk';if(Oa(_0x713fa2))return'Blackberry';if(Da(_0x713fa2))return'Webos';if(Aa(_0x713fa2))return'Safari';if((_0x713fa2['includes']('chrome/')||ka(_0x713fa2))&&!_0x713fa2['includes']('edge/'))return'Chrome';if(Pa(_0x713fa2))return'Android';{const _0xbd1cdd=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3e5640=_0x276f34['match'](_0xbd1cdd);if((_0x3e5640==null?void 0x0:_0x3e5640['length'])===0x2)return _0x3e5640[0x1];}return'Other';}function Ra(_0x1747c5=W()){return/firefox\//i['test'](_0x1747c5);}function Aa(_0xd6e4bd=W()){const _0x3a930a=_0xd6e4bd['toLowerCase']();return _0x3a930a['includes']('safari/')&&!_0x3a930a['includes']('chrome/')&&!_0x3a930a['includes']('crios/')&&!_0x3a930a['includes']('android');}function ka(_0x35334f=W()){return/crios\//i['test'](_0x35334f);}function Na(_0x32b8e1=W()){return/iemobile/i['test'](_0x32b8e1);}function Pa(_0x2cf740=W()){return/android/i['test'](_0x2cf740);}function Oa(_0x2e2c7d=W()){return/blackberry/i['test'](_0x2e2c7d);}function Da(_0x394807=W()){return/webos/i['test'](_0x394807);}function Ss(_0x598396=W()){return/iphone|ipad|ipod/i['test'](_0x598396)||/macintosh/i['test'](_0x598396)&&/mobile/i['test'](_0x598396);}function Sf(_0x365389=W()){var _0x2cc8b9;return Ss(_0x365389)&&!!((_0x2cc8b9=window['navigator'])!=null&&_0x2cc8b9['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3cbca2=W()){return Ss(_0x3cbca2)||Pa(_0x3cbca2)||Da(_0x3cbca2)||Oa(_0x3cbca2)||/windows phone/i['test'](_0x3cbca2)||Na(_0x3cbca2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x3eab5d,_0x260798=[]){let _0xa3be75;switch(_0x3eab5d){case'Browser':_0xa3be75=br(W());break;case'Worker':_0xa3be75=br(W())+'-'+_0x3eab5d;break;default:_0xa3be75=_0x3eab5d;}const _0x56035a=_0x260798['length']?_0x260798['join'](','):'FirebaseCore-web';return _0xa3be75+'/JsCore/'+dt+'/'+_0x56035a;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x2d3a28){this['auth']=_0x2d3a28,this['queue']=[];}['pushCallback'](_0x2d1215,_0x2502e8){const _0x46ca1f=_0x77909f=>new Promise((_0x40a181,_0x579676)=>{try{const _0x32de79=_0x2d1215(_0x77909f);_0x40a181(_0x32de79);}catch(_0x4038b3){_0x579676(_0x4038b3);}});_0x46ca1f['onAbort']=_0x2502e8,this['queue']['push'](_0x46ca1f);const _0x45da56=this['queue']['length']-0x1;return()=>{this['queue'][_0x45da56]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1b3917){if(this['auth']['currentUser']===_0x1b3917)return;const _0x186d14=[];try{for(const _0x5b61ab of this['queue'])await _0x5b61ab(_0x1b3917),_0x5b61ab['onAbort']&&_0x186d14['push'](_0x5b61ab['onAbort']);}catch(_0x3d9c54){_0x186d14['reverse']();for(const _0x5c1751 of _0x186d14)try{_0x5c1751();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3d9c54==null?void 0x0:_0x3d9c54['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x1b9a8a,_0x4eb511={}){return ke(_0x1b9a8a,'GET','/v2/passwordPolicy',Ae(_0x1b9a8a,_0x4eb511));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x43237b){var _0x79ecb5;const _0xeefaf=_0x43237b['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xeefaf['minPasswordLength']??kf,_0xeefaf['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xeefaf['maxPasswordLength']),_0xeefaf['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xeefaf['containsLowercaseCharacter']),_0xeefaf['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xeefaf['containsUppercaseCharacter']),_0xeefaf['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xeefaf['containsNumericCharacter']),_0xeefaf['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xeefaf['containsNonAlphanumericCharacter']),this['enforcementState']=_0x43237b['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x79ecb5=_0x43237b['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x79ecb5['join'](''))??'',this['forceUpgradeOnSignin']=_0x43237b['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x43237b['schemaVersion'];}['validatePassword'](_0x42e9e8){const _0x320129={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x42e9e8,_0x320129),this['validatePasswordCharacterOptions'](_0x42e9e8,_0x320129),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['meetsMinPasswordLength']??!0x0),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['meetsMaxPasswordLength']??!0x0),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['containsLowercaseLetter']??!0x0),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['containsUppercaseLetter']??!0x0),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['containsNumericCharacter']??!0x0),_0x320129['isValid']&&(_0x320129['isValid']=_0x320129['containsNonAlphanumericCharacter']??!0x0),_0x320129;}['validatePasswordLengthOptions'](_0x3115f1,_0x554235){const _0x8d56b2=this['customStrengthOptions']['minPasswordLength'],_0x2a56f4=this['customStrengthOptions']['maxPasswordLength'];_0x8d56b2&&(_0x554235['meetsMinPasswordLength']=_0x3115f1['length']>=_0x8d56b2),_0x2a56f4&&(_0x554235['meetsMaxPasswordLength']=_0x3115f1['length']<=_0x2a56f4);}['validatePasswordCharacterOptions'](_0x3c0f23,_0x186998){this['updatePasswordCharacterOptionsStatuses'](_0x186998,!0x1,!0x1,!0x1,!0x1);let _0x4f12dd;for(let _0x5559eb=0x0;_0x5559eb<_0x3c0f23['length'];_0x5559eb++)_0x4f12dd=_0x3c0f23['charAt'](_0x5559eb),this['updatePasswordCharacterOptionsStatuses'](_0x186998,_0x4f12dd>='a'&&_0x4f12dd<='z',_0x4f12dd>='A'&&_0x4f12dd<='Z',_0x4f12dd>='0'&&_0x4f12dd<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4f12dd));}['updatePasswordCharacterOptionsStatuses'](_0x327937,_0x383058,_0x1ca95b,_0x164ce9,_0x543ce4){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x327937['containsLowercaseLetter']||(_0x327937['containsLowercaseLetter']=_0x383058)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x327937['containsUppercaseLetter']||(_0x327937['containsUppercaseLetter']=_0x1ca95b)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x327937['containsNumericCharacter']||(_0x327937['containsNumericCharacter']=_0x164ce9)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x327937['containsNonAlphanumericCharacter']||(_0x327937['containsNonAlphanumericCharacter']=_0x543ce4));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0x172711,_0x3115e1,_0x38bbe8,_0x132012){this['app']=_0x172711,this['heartbeatServiceProvider']=_0x3115e1,this['appCheckServiceProvider']=_0x38bbe8,this['config']=_0x132012,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x172711['name'],this['clientVersion']=_0x132012['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1dd1d1=>this['_resolvePersistenceManagerAvailable']=_0x1dd1d1);}['_initializeWithPersistence'](_0x3d879f,_0x476242){return _0x476242&&(this['_popupRedirectResolver']=ie(_0x476242)),this['_initializationPromise']=this['queue'](async()=>{var _0x26dcd0,_0x1170c6,_0x432291;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x3d879f),(_0x26dcd0=this['_resolvePersistenceManagerAvailable'])==null||_0x26dcd0['call'](this),!this['_deleted'])){if((_0x1170c6=this['_popupRedirectResolver'])!=null&&_0x1170c6['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x476242),this['lastNotifiedUid']=((_0x432291=this['currentUser'])==null?void 0x0:_0x432291['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x209a23=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x209a23)){if(this['currentUser']&&_0x209a23&&this['currentUser']['uid']===_0x209a23['uid']){this['_currentUser']['_assign'](_0x209a23),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x209a23,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x211d80){try{const _0x13220=await Nn(this,{'idToken':_0x211d80}),_0x2a0dff=await j['_fromGetAccountInfoResponse'](this,_0x13220,_0x211d80);await this['directlySetCurrentUser'](_0x2a0dff);}catch(_0xbce4e1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xbce4e1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xb03d72){var _0x560532;if($(this['app'])){const _0x2a776e=this['app']['settings']['authIdToken'];return _0x2a776e?new Promise(_0x4dd4ab=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2a776e)['then'](_0x4dd4ab,_0x4dd4ab));}):this['directlySetCurrentUser'](null);}const _0x1a18c2=await this['assertedPersistence']['getCurrentUser']();let _0x5c4139=_0x1a18c2,_0x4759db=!0x1;if(_0xb03d72&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x313e97=(_0x560532=this['redirectUser'])==null?void 0x0:_0x560532['_redirectEventId'],_0x467aef=_0x5c4139==null?void 0x0:_0x5c4139['_redirectEventId'],_0x33af6f=await this['tryRedirectSignIn'](_0xb03d72);(!_0x313e97||_0x313e97===_0x467aef)&&(_0x33af6f!=null&&_0x33af6f['user'])&&(_0x5c4139=_0x33af6f['user'],_0x4759db=!0x0);}if(!_0x5c4139)return this['directlySetCurrentUser'](null);if(!_0x5c4139['_redirectEventId']){if(_0x4759db)try{await this['beforeStateQueue']['runMiddleware'](_0x5c4139);}catch(_0x24e508){_0x5c4139=_0x1a18c2,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x24e508));}return _0x5c4139?this['reloadAndSetCurrentUserOrClear'](_0x5c4139):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5c4139['_redirectEventId']?this['directlySetCurrentUser'](_0x5c4139):this['reloadAndSetCurrentUserOrClear'](_0x5c4139);}async['tryRedirectSignIn'](_0x2c249d){let _0xccc942=null;try{_0xccc942=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2c249d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xccc942;}async['reloadAndSetCurrentUserOrClear'](_0x277a3f){try{await Pn(_0x277a3f);}catch(_0x274496){if((_0x274496==null?void 0x0:_0x274496['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x277a3f);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x9e066b){if($(this['app']))return Promise['reject'](re(this));const _0x57f1ee=_0x9e066b?N(_0x9e066b):null;return _0x57f1ee&&m(_0x57f1ee['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x57f1ee&&_0x57f1ee['_clone'](this));}async['_updateCurrentUser'](_0x2fa1ad,_0x19f5dc=!0x1){if(!this['_deleted'])return _0x2fa1ad&&m(this['tenantId']===_0x2fa1ad['tenantId'],this,'tenant-id-mismatch'),_0x19f5dc||await this['beforeStateQueue']['runMiddleware'](_0x2fa1ad),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2fa1ad),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x13c008){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x13c008));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3c6e6f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x170a82=this['_getPasswordPolicyInternal']();return _0x170a82['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x170a82['validatePassword'](_0x3c6e6f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x454659=await Af(this),_0x1dc23b=new Nf(_0x454659);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1dc23b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1dc23b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1fb3b8){this['_errorFactory']=new $t('auth','Firebase',_0x1fb3b8());}['onAuthStateChanged'](_0x5c5c78,_0x27042f,_0x408178){return this['registerStateListener'](this['authStateSubscription'],_0x5c5c78,_0x27042f,_0x408178);}['beforeAuthStateChanged'](_0x3f6443,_0x476ba3){return this['beforeStateQueue']['pushCallback'](_0x3f6443,_0x476ba3);}['onIdTokenChanged'](_0x20f36b,_0x542f71,_0x485fd9){return this['registerStateListener'](this['idTokenSubscription'],_0x20f36b,_0x542f71,_0x485fd9);}['authStateReady'](){return new Promise((_0x1a8205,_0x4d46f8)=>{if(this['currentUser'])_0x1a8205();else{const _0x52a023=this['onAuthStateChanged'](()=>{_0x52a023(),_0x1a8205();},_0x4d46f8);}});}async['revokeAccessToken'](_0x3c93b8){if(this['currentUser']){const _0xf955d2=await this['currentUser']['getIdToken'](),_0x1519cd={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3c93b8,'idToken':_0xf955d2};this['tenantId']!=null&&(_0x1519cd['tenantId']=this['tenantId']),await Tf(this,_0x1519cd);}}['toJSON'](){var _0x23bd4a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x23bd4a=this['_currentUser'])==null?void 0x0:_0x23bd4a['toJSON']()};}async['_setRedirectUser'](_0x5707f9,_0xd4476e){const _0x51d698=await this['getOrInitRedirectPersistenceManager'](_0xd4476e);return _0x5707f9===null?_0x51d698['removeCurrentUser']():_0x51d698['setCurrentUser'](_0x5707f9);}async['getOrInitRedirectPersistenceManager'](_0x5cd8c1){if(!this['redirectPersistenceManager']){const _0x498cc7=_0x5cd8c1&&ie(_0x5cd8c1)||this['_popupRedirectResolver'];m(_0x498cc7,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x498cc7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3a69b7){var _0x3c98e7,_0xdfbbea;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3c98e7=this['_currentUser'])==null?void 0x0:_0x3c98e7['_redirectEventId'])===_0x3a69b7?this['_currentUser']:((_0xdfbbea=this['redirectUser'])==null?void 0x0:_0xdfbbea['_redirectEventId'])===_0x3a69b7?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5e915c){if(_0x5e915c===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5e915c));}['_notifyListenersIfCurrent'](_0x472fae){_0x472fae===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x58dceb;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5ed757=((_0x58dceb=this['currentUser'])==null?void 0x0:_0x58dceb['uid'])??null;this['lastNotifiedUid']!==_0x5ed757&&(this['lastNotifiedUid']=_0x5ed757,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x55dfe8,_0x5e56cb,_0x43b733,_0x14ae9d){if(this['_deleted'])return()=>{};const _0xa1f21b=typeof _0x5e56cb=='function'?_0x5e56cb:_0x5e56cb['next']['bind'](_0x5e56cb);let _0x29967b=!0x1;const _0x133fe8=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x133fe8,this,'internal-error'),_0x133fe8['then'](()=>{_0x29967b||_0xa1f21b(this['currentUser']);}),typeof _0x5e56cb=='function'){const _0x45632a=_0x55dfe8['addObserver'](_0x5e56cb,_0x43b733,_0x14ae9d);return()=>{_0x29967b=!0x0,_0x45632a();};}else{const _0x5c4f4c=_0x55dfe8['addObserver'](_0x5e56cb);return()=>{_0x29967b=!0x0,_0x5c4f4c();};}}async['directlySetCurrentUser'](_0x41b9ab){this['currentUser']&&this['currentUser']!==_0x41b9ab&&this['_currentUser']['_stopProactiveRefresh'](),_0x41b9ab&&this['isProactiveRefreshEnabled']&&_0x41b9ab['_startProactiveRefresh'](),this['currentUser']=_0x41b9ab,_0x41b9ab?await this['assertedPersistence']['setCurrentUser'](_0x41b9ab):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x41e008){return this['operations']=this['operations']['then'](_0x41e008,_0x41e008),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x36dee1){!_0x36dee1||this['frameworks']['includes'](_0x36dee1)||(this['frameworks']['push'](_0x36dee1),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5061b3;const _0x204803={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x204803['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3835db=await((_0x5061b3=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5061b3['getHeartbeatsHeader']());_0x3835db&&(_0x204803['X-Firebase-Client']=_0x3835db);const _0x13e0cf=await this['_getAppCheckToken']();return _0x13e0cf&&(_0x204803['X-Firebase-AppCheck']=_0x13e0cf),_0x204803;}async['_getAppCheckToken'](){var _0x434205;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x229208=await((_0x434205=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x434205['getToken']());return _0x229208!=null&&_0x229208['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x229208['error']),_0x229208==null?void 0x0:_0x229208['token'];}}function Ke(_0x43f484){return N(_0x43f484);}class Rr{constructor(_0x3d1873){this['auth']=_0x3d1873,this['observer']=null,this['addObserver']=Tc(_0x5c97b2=>this['observer']=_0x5c97b2);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x563707){Jn=_0x563707;}function xa(_0x111010){return Jn['loadJS'](_0x111010);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x51c00d){return'__'+_0x51c00d+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x310d0a){_0x310d0a();}['execute'](_0x2626e4,_0x2cfd71){return Promise['resolve']('token');}['render'](_0x400752,_0x5f03d5){return'';}}class Ff{['ready'](_0x40de8e){_0x40de8e();}['execute'](_0x2b22b3,_0x4a1f03){return Promise['resolve']('token');}['render'](_0x2e06f8,_0xc5f8fb){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x1916ae){this['type']=Uf,this['auth']=Ke(_0x1916ae);}async['verify'](_0x58b77a='verify',_0x56cf53=!0x1){async function _0x1369d7(_0x33225b){if(!_0x56cf53){if(_0x33225b['tenantId']==null&&_0x33225b['_agentRecaptchaConfig']!=null)return _0x33225b['_agentRecaptchaConfig']['siteKey'];if(_0x33225b['tenantId']!=null&&_0x33225b['_tenantRecaptchaConfigs'][_0x33225b['tenantId']]!==void 0x0)return _0x33225b['_tenantRecaptchaConfigs'][_0x33225b['tenantId']]['siteKey'];}return new Promise(async(_0x9b7ea6,_0x233772)=>{gf(_0x33225b,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3b21ca=>{if(_0x3b21ca['recaptchaKey']===void 0x0)_0x233772(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5c49ac=new _f(_0x3b21ca);return _0x33225b['tenantId']==null?_0x33225b['_agentRecaptchaConfig']=_0x5c49ac:_0x33225b['_tenantRecaptchaConfigs'][_0x33225b['tenantId']]=_0x5c49ac,_0x9b7ea6(_0x5c49ac['siteKey']);}})['catch'](_0x5ebb1a=>{_0x233772(_0x5ebb1a);});});}function _0x552621(_0x45fb41,_0x20fcc0,_0x21f7d0){const _0x1b8ac4=window['grecaptcha'];wr(_0x1b8ac4)?_0x1b8ac4['enterprise']['ready'](()=>{_0x1b8ac4['enterprise']['execute'](_0x45fb41,{'action':_0x58b77a})['then'](_0xe810c2=>{_0x20fcc0(_0xe810c2);})['catch'](()=>{_0x20fcc0(Fa);});}):_0x21f7d0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3bfa5d,_0xf302b9)=>{_0x1369d7(this['auth'])['then'](async _0x457954=>{if(!_0x56cf53&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x552621(_0x457954,_0x3bfa5d,_0xf302b9);else{if(typeof window>'u'){_0xf302b9(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x183190=Df();_0x183190['length']!==0x0&&(_0x183190+=_0x457954+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x4c6f82;(_0x4c6f82=he['scriptInjectionDeferred'])==null||_0x4c6f82['resolve']();},xa(_0x183190)['then'](()=>{var _0x2c424d;return(_0x2c424d=he['scriptInjectionDeferred'])==null?void 0x0:_0x2c424d['promise'];})['then'](()=>{_0x552621(_0x457954,_0x3bfa5d,_0xf302b9);})['catch'](_0x3037c0=>{_0xf302b9(_0x3037c0);});}})['catch'](_0x1574f0=>{_0xf302b9(_0x1574f0);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x646b7b,_0x5fd2c,_0x28f0cc,_0x24efbc=!0x1,_0x1cdd8d=!0x1){const _0x1b5901=new he(_0x646b7b);let _0x1683c4;if(_0x1cdd8d)_0x1683c4=Fa;else try{_0x1683c4=await _0x1b5901['verify'](_0x28f0cc);}catch{_0x1683c4=await _0x1b5901['verify'](_0x28f0cc,!0x0);}const _0x427eb1={..._0x5fd2c};if(_0x28f0cc==='mfaSmsEnrollment'||_0x28f0cc==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x427eb1){const _0x2696c7=_0x427eb1['phoneEnrollmentInfo']['phoneNumber'],_0x1e6e76=_0x427eb1['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x427eb1,{'phoneEnrollmentInfo':{'phoneNumber':_0x2696c7,'recaptchaToken':_0x1e6e76,'captchaResponse':_0x1683c4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x427eb1){const _0x2960f7=_0x427eb1['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x427eb1,{'phoneSignInInfo':{'recaptchaToken':_0x2960f7,'captchaResponse':_0x1683c4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x427eb1;}return _0x24efbc?Object['assign'](_0x427eb1,{'captchaResp':_0x1683c4}):Object['assign'](_0x427eb1,{'captchaResponse':_0x1683c4}),Object['assign'](_0x427eb1,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x427eb1,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x427eb1;}async function xi(_0x1fe4d6,_0x110e30,_0x50a427,_0x494b18,_0x2829c5){var _0xe7a740;if((_0xe7a740=_0x1fe4d6['_getRecaptchaConfig']())!=null&&_0xe7a740['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x19a873=await kr(_0x1fe4d6,_0x110e30,_0x50a427,_0x50a427==='getOobCode');return _0x494b18(_0x1fe4d6,_0x19a873);}else return _0x494b18(_0x1fe4d6,_0x110e30)['catch'](async _0x1db294=>{if(_0x1db294['code']==='auth/missing-recaptcha-token'){console['log'](_0x50a427+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x489ed5=await kr(_0x1fe4d6,_0x110e30,_0x50a427,_0x50a427==='getOobCode');return _0x494b18(_0x1fe4d6,_0x489ed5);}else return Promise['reject'](_0x1db294);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0xb82891,_0x155b45){const _0x4bb847=Hi(_0xb82891,'auth');if(_0x4bb847['isInitialized']()){const _0x512b0e=_0x4bb847['getImmediate'](),_0x58818f=_0x4bb847['getOptions']();if(Le(_0x58818f,_0x155b45??{}))return _0x512b0e;Y(_0x512b0e,'already-initialized');}return _0x4bb847['initialize']({'options':_0x155b45});}function Bf(_0x3440c0,_0xbe369b){const _0x107f11=(_0xbe369b==null?void 0x0:_0xbe369b['persistence'])||[],_0x10b3c1=(Array['isArray'](_0x107f11)?_0x107f11:[_0x107f11])['map'](ie);_0xbe369b!=null&&_0xbe369b['errorMap']&&_0x3440c0['_updateErrorMap'](_0xbe369b['errorMap']),_0x3440c0['_initializeWithPersistence'](_0x10b3c1,_0xbe369b==null?void 0x0:_0xbe369b['popupRedirectResolver']);}function Vf(_0x400811,_0x5500f9,_0x4e3622){const _0x58fe3a=Ke(_0x400811);m(/^https?:\/\//['test'](_0x5500f9),_0x58fe3a,'invalid-emulator-scheme');const _0x3075c2=!0x1,_0x2b5df0=Ua(_0x5500f9),{host:_0x2414b7,port:_0x325f8d}=Hf(_0x5500f9),_0x5b6718=_0x325f8d===null?'':':'+_0x325f8d,_0x3f71c3={'url':_0x2b5df0+'//'+_0x2414b7+_0x5b6718+'/'},_0x5c0d90=Object['freeze']({'host':_0x2414b7,'port':_0x325f8d,'protocol':_0x2b5df0['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3075c2})});if(!_0x58fe3a['_canInitEmulator']){m(_0x58fe3a['config']['emulator']&&_0x58fe3a['emulatorConfig'],_0x58fe3a,'emulator-config-failed'),m(Le(_0x3f71c3,_0x58fe3a['config']['emulator'])&&Le(_0x5c0d90,_0x58fe3a['emulatorConfig']),_0x58fe3a,'emulator-config-failed');return;}_0x58fe3a['config']['emulator']=_0x3f71c3,_0x58fe3a['emulatorConfig']=_0x5c0d90,_0x58fe3a['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x2414b7)?Qr(_0x2b5df0+'//'+_0x2414b7+_0x5b6718):$f();}function Ua(_0x5231c6){const _0x1a4bfe=_0x5231c6['indexOf'](':');return _0x1a4bfe<0x0?'':_0x5231c6['substr'](0x0,_0x1a4bfe+0x1);}function Hf(_0x3b65e1){const _0x2b5d8f=Ua(_0x3b65e1),_0x3037a1=/(\/\/)?([^?#/]+)/['exec'](_0x3b65e1['substr'](_0x2b5d8f['length']));if(!_0x3037a1)return{'host':'','port':null};const _0x130133=_0x3037a1[0x2]['split']('@')['pop']()||'',_0x182b78=/^(\[[^\]]+\])(:|$)/['exec'](_0x130133);if(_0x182b78){const _0x36effd=_0x182b78[0x1];return{'host':_0x36effd,'port':Nr(_0x130133['substr'](_0x36effd['length']+0x1))};}else{const [_0x413359,_0x30954a]=_0x130133['split'](':');return{'host':_0x413359,'port':Nr(_0x30954a)};}}function Nr(_0x5d879e){if(!_0x5d879e)return null;const _0x2fd902=Number(_0x5d879e);return isNaN(_0x2fd902)?null:_0x2fd902;}function $f(){function _0x57180e(){const _0x296870=document['createElement']('p'),_0x2f4e2b=_0x296870['style'];_0x296870['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2f4e2b['position']='fixed',_0x2f4e2b['width']='100%',_0x2f4e2b['backgroundColor']='#ffffff',_0x2f4e2b['border']='.1em\x20solid\x20#000000',_0x2f4e2b['color']='#b50000',_0x2f4e2b['bottom']='0px',_0x2f4e2b['left']='0px',_0x2f4e2b['margin']='0px',_0x2f4e2b['zIndex']='10000',_0x2f4e2b['textAlign']='center',_0x296870['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x296870);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x57180e):_0x57180e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x37767c,_0x118a88){this['providerId']=_0x37767c,this['signInMethod']=_0x118a88;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x48c484){return ne('not\x20implemented');}['_linkToIdToken'](_0xe06d0b,_0x48694a){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1fbf71){return ne('not\x20implemented');}}async function Gf(_0x135c5e,_0x4406ed){return ke(_0x135c5e,'POST','/v1/accounts:signUp',_0x4406ed);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5f0177,_0x1bf376){return en(_0x5f0177,'POST','/v1/accounts:signInWithPassword',Ae(_0x5f0177,_0x1bf376));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3c405f,_0x38ffdb){return en(_0x3c405f,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x3c405f,_0x38ffdb));}async function jf(_0x225618,_0x46639d){return en(_0x225618,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x225618,_0x46639d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x2e2f5c,_0x44ee6f,_0x270ceb,_0x509001=null){super('password',_0x270ceb),this['_email']=_0x2e2f5c,this['_password']=_0x44ee6f,this['_tenantId']=_0x509001;}static['_fromEmailAndPassword'](_0x47ea7d,_0x5f1fe8){return new Ht(_0x47ea7d,_0x5f1fe8,'password');}static['_fromEmailAndCode'](_0x4de9b,_0x1d7fd9,_0x3703d6=null){return new Ht(_0x4de9b,_0x1d7fd9,'emailLink',_0x3703d6);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1c30fb){const _0x25814d=typeof _0x1c30fb=='string'?JSON['parse'](_0x1c30fb):_0x1c30fb;if(_0x25814d!=null&&_0x25814d['email']&&(_0x25814d!=null&&_0x25814d['password'])){if(_0x25814d['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x25814d['email'],_0x25814d['password']);if(_0x25814d['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x25814d['email'],_0x25814d['password'],_0x25814d['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5d2c7e){switch(this['signInMethod']){case'password':const _0x4830ce={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5d2c7e,_0x4830ce,'signInWithPassword',qf);case'emailLink':return zf(_0x5d2c7e,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5d2c7e,'internal-error');}}async['_linkToIdToken'](_0x1adc89,_0x48b728){switch(this['signInMethod']){case'password':const _0x4dd082={'idToken':_0x48b728,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1adc89,_0x4dd082,'signUpPassword',Gf);case'emailLink':return jf(_0x1adc89,{'idToken':_0x48b728,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1adc89,'internal-error');}}['_getReauthenticationResolver'](_0x385a7e){return this['_getIdTokenResponse'](_0x385a7e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x3ca721,_0x58b2cd){return en(_0x3ca721,'POST','/v1/accounts:signInWithIdp',Ae(_0x3ca721,_0x58b2cd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2f1462){const _0x2407b0=new He(_0x2f1462['providerId'],_0x2f1462['signInMethod']);return _0x2f1462['idToken']||_0x2f1462['accessToken']?(_0x2f1462['idToken']&&(_0x2407b0['idToken']=_0x2f1462['idToken']),_0x2f1462['accessToken']&&(_0x2407b0['accessToken']=_0x2f1462['accessToken']),_0x2f1462['nonce']&&!_0x2f1462['pendingToken']&&(_0x2407b0['nonce']=_0x2f1462['nonce']),_0x2f1462['pendingToken']&&(_0x2407b0['pendingToken']=_0x2f1462['pendingToken'])):_0x2f1462['oauthToken']&&_0x2f1462['oauthTokenSecret']?(_0x2407b0['accessToken']=_0x2f1462['oauthToken'],_0x2407b0['secret']=_0x2f1462['oauthTokenSecret']):Y('argument-error'),_0x2407b0;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x560f7c){const _0x36fad2=typeof _0x560f7c=='string'?JSON['parse'](_0x560f7c):_0x560f7c,{providerId:_0x25a5d8,signInMethod:_0x39de1d,..._0x595e5f}=_0x36fad2;if(!_0x25a5d8||!_0x39de1d)return null;const _0xe8ac3a=new He(_0x25a5d8,_0x39de1d);return _0xe8ac3a['idToken']=_0x595e5f['idToken']||void 0x0,_0xe8ac3a['accessToken']=_0x595e5f['accessToken']||void 0x0,_0xe8ac3a['secret']=_0x595e5f['secret'],_0xe8ac3a['nonce']=_0x595e5f['nonce'],_0xe8ac3a['pendingToken']=_0x595e5f['pendingToken']||null,_0xe8ac3a;}['_getIdTokenResponse'](_0x5aad85){const _0x206fc4=this['buildRequest']();return nt(_0x5aad85,_0x206fc4);}['_linkToIdToken'](_0x403ed2,_0x221ecb){const _0x194c15=this['buildRequest']();return _0x194c15['idToken']=_0x221ecb,nt(_0x403ed2,_0x194c15);}['_getReauthenticationResolver'](_0x5c83c8){const _0x276b68=this['buildRequest']();return _0x276b68['autoCreate']=!0x1,nt(_0x5c83c8,_0x276b68);}['buildRequest'](){const _0x399649={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x399649['pendingToken']=this['pendingToken'];else{const _0x5240d5={};this['idToken']&&(_0x5240d5['id_token']=this['idToken']),this['accessToken']&&(_0x5240d5['access_token']=this['accessToken']),this['secret']&&(_0x5240d5['oauth_token_secret']=this['secret']),_0x5240d5['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5240d5['nonce']=this['nonce']),_0x399649['postBody']=ut(_0x5240d5);}return _0x399649;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0x515012){switch(_0x515012){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x1888e9){const _0x275d88=wt(Ct(_0x1888e9))['link'],_0x42b917=_0x275d88?wt(Ct(_0x275d88))['deep_link_id']:null,_0x31cf23=wt(Ct(_0x1888e9))['deep_link_id'];return(_0x31cf23?wt(Ct(_0x31cf23))['link']:null)||_0x31cf23||_0x42b917||_0x275d88||_0x1888e9;}class Rs{constructor(_0x5db88e){const _0x1bf259=wt(Ct(_0x5db88e)),_0x28c740=_0x1bf259['apiKey']??null,_0x5a64ea=_0x1bf259['oobCode']??null,_0x332702=Yf(_0x1bf259['mode']??null);m(_0x28c740&&_0x5a64ea&&_0x332702,'argument-error'),this['apiKey']=_0x28c740,this['operation']=_0x332702,this['code']=_0x5a64ea,this['continueUrl']=_0x1bf259['continueUrl']??null,this['languageCode']=_0x1bf259['lang']??null,this['tenantId']=_0x1bf259['tenantId']??null;}static['parseLink'](_0xcd0511){const _0x1686eb=Qf(_0xcd0511);try{return new Rs(_0x1686eb);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x30408d,_0x4f70dc){return Ht['_fromEmailAndPassword'](_0x30408d,_0x4f70dc);}static['credentialWithLink'](_0x4db855,_0x2056d3){const _0x5cdacb=Rs['parseLink'](_0x2056d3);return m(_0x5cdacb,'argument-error'),Ht['_fromEmailAndCode'](_0x4db855,_0x5cdacb['code'],_0x5cdacb['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x58b648){this['providerId']=_0x58b648,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3e4c90){this['defaultLanguageCode']=_0x3e4c90;}['setCustomParameters'](_0x1fdbbc){return this['customParameters']=_0x1fdbbc,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1c058b){return this['scopes']['includes'](_0x1c058b)||this['scopes']['push'](_0x1c058b),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x17dcdb){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x17dcdb});}static['credentialFromResult'](_0x2a7787){return ue['credentialFromTaggedObject'](_0x2a7787);}static['credentialFromError'](_0x459560){return ue['credentialFromTaggedObject'](_0x459560['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x33ec44}){if(!_0x33ec44||!('oauthAccessToken'in _0x33ec44)||!_0x33ec44['oauthAccessToken'])return null;try{return ue['credential'](_0x33ec44['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x51310e,_0x12a6ac){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x51310e,'accessToken':_0x12a6ac});}static['credentialFromResult'](_0x25cec5){return de['credentialFromTaggedObject'](_0x25cec5);}static['credentialFromError'](_0x3ddeaf){return de['credentialFromTaggedObject'](_0x3ddeaf['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x461ef4}){if(!_0x461ef4)return null;const {oauthIdToken:_0x3008d6,oauthAccessToken:_0x3cdec9}=_0x461ef4;if(!_0x3008d6&&!_0x3cdec9)return null;try{return de['credential'](_0x3008d6,_0x3cdec9);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0xd48079){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xd48079});}static['credentialFromResult'](_0x44c78e){return fe['credentialFromTaggedObject'](_0x44c78e);}static['credentialFromError'](_0x97a04c){return fe['credentialFromTaggedObject'](_0x97a04c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x200a6f}){if(!_0x200a6f||!('oauthAccessToken'in _0x200a6f)||!_0x200a6f['oauthAccessToken'])return null;try{return fe['credential'](_0x200a6f['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4d0ba2,_0x38d41c){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4d0ba2,'oauthTokenSecret':_0x38d41c});}static['credentialFromResult'](_0x21c8ef){return pe['credentialFromTaggedObject'](_0x21c8ef);}static['credentialFromError'](_0x38b329){return pe['credentialFromTaggedObject'](_0x38b329['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x117042}){if(!_0x117042)return null;const {oauthAccessToken:_0xdc0a6,oauthTokenSecret:_0x3c3c3c}=_0x117042;if(!_0xdc0a6||!_0x3c3c3c)return null;try{return pe['credential'](_0xdc0a6,_0x3c3c3c);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x3c68e5,_0x64c9c8){return en(_0x3c68e5,'POST','/v1/accounts:signUp',Ae(_0x3c68e5,_0x64c9c8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x2c28dc){this['user']=_0x2c28dc['user'],this['providerId']=_0x2c28dc['providerId'],this['_tokenResponse']=_0x2c28dc['_tokenResponse'],this['operationType']=_0x2c28dc['operationType'];}static async['_fromIdTokenResponse'](_0x5de599,_0x4c05c7,_0x23e073,_0x473d3d=!0x1){const _0x4c8475=await j['_fromIdTokenResponse'](_0x5de599,_0x23e073,_0x473d3d),_0x503e11=Pr(_0x23e073);return new $e({'user':_0x4c8475,'providerId':_0x503e11,'_tokenResponse':_0x23e073,'operationType':_0x4c05c7});}static async['_forOperation'](_0x2b883e,_0x18552a,_0x27981a){await _0x2b883e['_updateTokensIfNecessary'](_0x27981a,!0x0);const _0x1e0496=Pr(_0x27981a);return new $e({'user':_0x2b883e,'providerId':_0x1e0496,'_tokenResponse':_0x27981a,'operationType':_0x18552a});}}function Pr(_0x2699b7){return _0x2699b7['providerId']?_0x2699b7['providerId']:'phoneNumber'in _0x2699b7?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x42317d,_0x53d4cc,_0x1eb1c2,_0x404cd3){super(_0x53d4cc['code'],_0x53d4cc['message']),this['operationType']=_0x1eb1c2,this['user']=_0x404cd3,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x42317d['name'],'tenantId':_0x42317d['tenantId']??void 0x0,'_serverResponse':_0x53d4cc['customData']['_serverResponse'],'operationType':_0x1eb1c2};}static['_fromErrorAndOperation'](_0x246288,_0x250089,_0x2698ec,_0x409a1e){return new On(_0x246288,_0x250089,_0x2698ec,_0x409a1e);}}function Ba(_0xda085f,_0x382895,_0x471852,_0x12dd97){return(_0x382895==='reauthenticate'?_0x471852['_getReauthenticationResolver'](_0xda085f):_0x471852['_getIdTokenResponse'](_0xda085f))['catch'](_0x747b60=>{throw _0x747b60['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0xda085f,_0x747b60,_0x382895,_0x12dd97):_0x747b60;});}async function Xf(_0x54f4e9,_0x3df9b8,_0x3591bd=!0x1){const _0x467ffe=await Vt(_0x54f4e9,_0x3df9b8['_linkToIdToken'](_0x54f4e9['auth'],await _0x54f4e9['getIdToken']()),_0x3591bd);return $e['_forOperation'](_0x54f4e9,'link',_0x467ffe);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2048e,_0x5a45d4,_0x5798cc=!0x1){const {auth:_0x3e1184}=_0x2048e;if($(_0x3e1184['app']))return Promise['reject'](re(_0x3e1184));const _0x3fbbde='reauthenticate';try{const _0x4ee74b=await Vt(_0x2048e,Ba(_0x3e1184,_0x3fbbde,_0x5a45d4,_0x2048e),_0x5798cc);m(_0x4ee74b['idToken'],_0x3e1184,'internal-error');const _0x27e4df=Ts(_0x4ee74b['idToken']);m(_0x27e4df,_0x3e1184,'internal-error');const {sub:_0x58a635}=_0x27e4df;return m(_0x2048e['uid']===_0x58a635,_0x3e1184,'user-mismatch'),$e['_forOperation'](_0x2048e,_0x3fbbde,_0x4ee74b);}catch(_0x3454d4){throw(_0x3454d4==null?void 0x0:_0x3454d4['code'])==='auth/user-not-found'&&Y(_0x3e1184,'user-mismatch'),_0x3454d4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4da228,_0x38138d,_0x11b082=!0x1){if($(_0x4da228['app']))return Promise['reject'](re(_0x4da228));const _0x569692='signIn',_0x4d223d=await Ba(_0x4da228,_0x569692,_0x38138d),_0x116fe7=await $e['_fromIdTokenResponse'](_0x4da228,_0x569692,_0x4d223d);return _0x11b082||await _0x4da228['_updateCurrentUser'](_0x116fe7['user']),_0x116fe7;}async function ep(_0x399851,_0x559a09){return Va(Ke(_0x399851),_0x559a09);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x77af03){const _0x21fb9d=Ke(_0x77af03);_0x21fb9d['_getPasswordPolicyInternal']()&&await _0x21fb9d['_updatePasswordPolicy']();}async function O_(_0x1144df,_0x5a6612,_0x323eba){if($(_0x1144df['app']))return Promise['reject'](re(_0x1144df));const _0x15f1a7=Ke(_0x1144df),_0x57a48b=await xi(_0x15f1a7,{'returnSecureToken':!0x0,'email':_0x5a6612,'password':_0x323eba,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0xd33ce0=>{throw _0xd33ce0['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1144df),_0xd33ce0;}),_0x1f2ce2=await $e['_fromIdTokenResponse'](_0x15f1a7,'signIn',_0x57a48b);return await _0x15f1a7['_updateCurrentUser'](_0x1f2ce2['user']),_0x1f2ce2;}function D_(_0x3c009f,_0x561db1,_0x218a22){return $(_0x3c009f['app'])?Promise['reject'](re(_0x3c009f)):ep(N(_0x3c009f),mt['credential'](_0x561db1,_0x218a22))['catch'](async _0x4f5499=>{throw _0x4f5499['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3c009f),_0x4f5499;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x1d8adc,_0x35e0ba){return N(_0x1d8adc)['setPersistence'](_0x35e0ba);}function tp(_0x1db100,_0x37dfab,_0xe52448,_0x5a1421){return N(_0x1db100)['onIdTokenChanged'](_0x37dfab,_0xe52448,_0x5a1421);}function np(_0x4811ec,_0x8a96e9,_0x553730){return N(_0x4811ec)['beforeAuthStateChanged'](_0x8a96e9,_0x553730);}function L_(_0x5627c6,_0x3cbabd,_0x2adcff,_0x295a81){return N(_0x5627c6)['onAuthStateChanged'](_0x3cbabd,_0x2adcff,_0x295a81);}function x_(_0x4f2c9b){return N(_0x4f2c9b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5bda61,_0x3fbecd){this['storageRetriever']=_0x5bda61,this['type']=_0x3fbecd;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2d253b,_0x2b9a02){return this['storage']['setItem'](_0x2d253b,JSON['stringify'](_0x2b9a02)),Promise['resolve']();}['_get'](_0x80c8ee){const _0x5665a7=this['storage']['getItem'](_0x80c8ee);return Promise['resolve'](_0x5665a7?JSON['parse'](_0x5665a7):null);}['_remove'](_0xbc6974){return this['storage']['removeItem'](_0xbc6974),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x388c42,_0x1606be)=>this['onStorageEvent'](_0x388c42,_0x1606be),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2c836e){for(const _0x59ac58 of Object['keys'](this['listeners'])){const _0x18a307=this['storage']['getItem'](_0x59ac58),_0x5d6a13=this['localCache'][_0x59ac58];_0x18a307!==_0x5d6a13&&_0x2c836e(_0x59ac58,_0x5d6a13,_0x18a307);}}['onStorageEvent'](_0x392ee7,_0x43f4cd=!0x1){if(!_0x392ee7['key']){this['forAllChangedKeys']((_0x3c1d5f,_0x4f2ec4,_0x1e2033)=>{this['notifyListeners'](_0x3c1d5f,_0x1e2033);});return;}const _0x428c1a=_0x392ee7['key'];_0x43f4cd?this['detachListener']():this['stopPolling']();const _0x23c369=()=>{const _0x5ba584=this['storage']['getItem'](_0x428c1a);!_0x43f4cd&&this['localCache'][_0x428c1a]===_0x5ba584||this['notifyListeners'](_0x428c1a,_0x5ba584);},_0x16a011=this['storage']['getItem'](_0x428c1a);bf()&&_0x16a011!==_0x392ee7['newValue']&&_0x392ee7['newValue']!==_0x392ee7['oldValue']?setTimeout(_0x23c369,sp):_0x23c369();}['notifyListeners'](_0x290336,_0xf42013){this['localCache'][_0x290336]=_0xf42013;const _0x4f49ae=this['listeners'][_0x290336];if(_0x4f49ae){for(const _0x4ed3e9 of Array['from'](_0x4f49ae))_0x4ed3e9(_0xf42013&&JSON['parse'](_0xf42013));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x142805,_0x4ecd27,_0x27da23)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x142805,'oldValue':_0x4ecd27,'newValue':_0x27da23}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x108648,_0x35af6e){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x108648]||(this['listeners'][_0x108648]=new Set(),this['localCache'][_0x108648]=this['storage']['getItem'](_0x108648)),this['listeners'][_0x108648]['add'](_0x35af6e);}['_removeListener'](_0xeccca2,_0x3c1521){this['listeners'][_0xeccca2]&&(this['listeners'][_0xeccca2]['delete'](_0x3c1521),this['listeners'][_0xeccca2]['size']===0x0&&delete this['listeners'][_0xeccca2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4e7ca1,_0x376b69){await super['_set'](_0x4e7ca1,_0x376b69),this['localCache'][_0x4e7ca1]=JSON['stringify'](_0x376b69);}async['_get'](_0x454bb9){const _0x331bf4=await super['_get'](_0x454bb9);return this['localCache'][_0x454bb9]=JSON['stringify'](_0x331bf4),_0x331bf4;}async['_remove'](_0x1debfd){await super['_remove'](_0x1debfd),delete this['localCache'][_0x1debfd];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x6f7905,_0x2df46f){}['_removeListener'](_0x420cdc,_0x2ebada){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x1f0c53){return Promise['all'](_0x1f0c53['map'](async _0x582663=>{try{return{'fulfilled':!0x0,'value':await _0x582663};}catch(_0x45f7bb){return{'fulfilled':!0x1,'reason':_0x45f7bb};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x5eef41){this['eventTarget']=_0x5eef41,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x17662c){const _0x9217f4=this['receivers']['find'](_0x4f3744=>_0x4f3744['isListeningto'](_0x17662c));if(_0x9217f4)return _0x9217f4;const _0x59165a=new Xn(_0x17662c);return this['receivers']['push'](_0x59165a),_0x59165a;}['isListeningto'](_0x10e0f3){return this['eventTarget']===_0x10e0f3;}async['handleEvent'](_0x3e7759){const _0x1998ca=_0x3e7759,{eventId:_0x38f948,eventType:_0x35493c,data:_0xcf7aaf}=_0x1998ca['data'],_0xe58cf2=this['handlersMap'][_0x35493c];if(!(_0xe58cf2!=null&&_0xe58cf2['size']))return;_0x1998ca['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x38f948,'eventType':_0x35493c});const _0x3fd000=Array['from'](_0xe58cf2)['map'](async _0x12e76e=>_0x12e76e(_0x1998ca['origin'],_0xcf7aaf)),_0x4d091e=await op(_0x3fd000);_0x1998ca['ports'][0x0]['postMessage']({'status':'done','eventId':_0x38f948,'eventType':_0x35493c,'response':_0x4d091e});}['_subscribe'](_0x40572c,_0x248a62){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x40572c]||(this['handlersMap'][_0x40572c]=new Set()),this['handlersMap'][_0x40572c]['add'](_0x248a62);}['_unsubscribe'](_0x23cd73,_0x433821){this['handlersMap'][_0x23cd73]&&_0x433821&&this['handlersMap'][_0x23cd73]['delete'](_0x433821),(!_0x433821||this['handlersMap'][_0x23cd73]['size']===0x0)&&delete this['handlersMap'][_0x23cd73],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x502a5c='',_0x516239=0xa){let _0x5e1ad1='';for(let _0x590fdb=0x0;_0x590fdb<_0x516239;_0x590fdb++)_0x5e1ad1+=Math['floor'](Math['random']()*0xa);return _0x502a5c+_0x5e1ad1;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0xb7c55f){this['target']=_0xb7c55f,this['handlers']=new Set();}['removeMessageHandler'](_0x5a833c){_0x5a833c['messageChannel']&&(_0x5a833c['messageChannel']['port1']['removeEventListener']('message',_0x5a833c['onMessage']),_0x5a833c['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5a833c);}async['_send'](_0x133619,_0x12c20f,_0x368f45=0x32){const _0x3ced6f=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3ced6f)throw new Error('connection_unavailable');let _0x3fae80,_0x311202;return new Promise((_0x18ac4e,_0x19d58d)=>{const _0x299888=As('',0x14);_0x3ced6f['port1']['start']();const _0x3301d7=setTimeout(()=>{_0x19d58d(new Error('unsupported_event'));},_0x368f45);_0x311202={'messageChannel':_0x3ced6f,'onMessage'(_0x1512c1){const _0x4311de=_0x1512c1;if(_0x4311de['data']['eventId']===_0x299888)switch(_0x4311de['data']['status']){case'ack':clearTimeout(_0x3301d7),_0x3fae80=setTimeout(()=>{_0x19d58d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3fae80),_0x18ac4e(_0x4311de['data']['response']);break;default:clearTimeout(_0x3301d7),clearTimeout(_0x3fae80),_0x19d58d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x311202),_0x3ced6f['port1']['addEventListener']('message',_0x311202['onMessage']),this['target']['postMessage']({'eventType':_0x133619,'eventId':_0x299888,'data':_0x12c20f},[_0x3ced6f['port2']]);})['finally'](()=>{_0x311202&&this['removeMessageHandler'](_0x311202);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0x1fd5e3){Z()['location']['href']=_0x1fd5e3;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x3ef423;return((_0x3ef423=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3ef423['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x58ab25){this['request']=_0x58ab25;}['toPromise'](){return new Promise((_0x37cac8,_0x3a5f89)=>{this['request']['addEventListener']('success',()=>{_0x37cac8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3a5f89(this['request']['error']);});});}}function Zn(_0x497f6e,_0x2ebc82){return _0x497f6e['transaction']([Mn],_0x2ebc82?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x497be3=indexedDB['deleteDatabase'](Ka);return new nn(_0x497be3)['toPromise']();}function Qa(){const _0x12671c=indexedDB['open'](Ka,dp);return new Promise((_0x3b4768,_0x3dbcb7)=>{_0x12671c['addEventListener']('error',()=>{_0x3dbcb7(_0x12671c['error']);}),_0x12671c['addEventListener']('upgradeneeded',()=>{const _0x1cc465=_0x12671c['result'];try{_0x1cc465['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x5e02d3){_0x3dbcb7(_0x5e02d3);}}),_0x12671c['addEventListener']('success',async()=>{const _0x41f7dc=_0x12671c['result'];_0x41f7dc['objectStoreNames']['contains'](Mn)?_0x3b4768(_0x41f7dc):(_0x41f7dc['close'](),await fp(),_0x3b4768(await Qa()));});});}async function Or(_0x5148d7,_0x45d1fe,_0x1aa430){const _0x488f46=Zn(_0x5148d7,!0x0)['put']({[Ya]:_0x45d1fe,'value':_0x1aa430});return new nn(_0x488f46)['toPromise']();}async function pp(_0x182ee2,_0x1b098b){const _0x1fe599=Zn(_0x182ee2,!0x1)['get'](_0x1b098b),_0x5a955f=await new nn(_0x1fe599)['toPromise']();return _0x5a955f===void 0x0?null:_0x5a955f['value'];}function Dr(_0x3059a5,_0xa4646e){const _0x59a10d=Zn(_0x3059a5,!0x0)['delete'](_0xa4646e);return new nn(_0x59a10d)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x179381){let _0x3f79d9=0x0;for(;;)try{const _0x57f8c1=await this['_openDb']();return await _0x179381(_0x57f8c1);}catch(_0x1b272f){if(_0x3f79d9++>gp)throw _0x1b272f;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0xbcb858,_0x13ab14)=>({'keyProcessed':(await this['_poll']())['includes'](_0x13ab14['key'])})),this['receiver']['_subscribe']('ping',async(_0x377ac2,_0x5ab727)=>['keyChanged']);}async['initializeSender'](){var _0x4976e2,_0x93129c;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0x57eeb1=await this['sender']['_send']('ping',{},0x320);_0x57eeb1&&(_0x4976e2=_0x57eeb1[0x0])!=null&&_0x4976e2['fulfilled']&&(_0x93129c=_0x57eeb1[0x0])!=null&&_0x93129c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1126cd){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1126cd},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x224183=>{await Or(_0x224183,Dn,'1'),await Dr(_0x224183,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x143710){this['pendingWrites']++;try{await _0x143710();}finally{this['pendingWrites']--;}}async['_set'](_0x58c055,_0x5ab5db){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4dd78d=>Or(_0x4dd78d,_0x58c055,_0x5ab5db)),this['localCache'][_0x58c055]=_0x5ab5db,this['notifyServiceWorker'](_0x58c055)));}async['_get'](_0x2b8f37){const _0x5043b7=await this['_withRetries'](_0x5c0e7f=>pp(_0x5c0e7f,_0x2b8f37));return this['localCache'][_0x2b8f37]=_0x5043b7,_0x5043b7;}async['_remove'](_0x4291ba){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x59e4fe=>Dr(_0x59e4fe,_0x4291ba)),delete this['localCache'][_0x4291ba],this['notifyServiceWorker'](_0x4291ba)));}async['_poll'](){const _0x99faec=await this['_withRetries'](_0x283e3d=>{const _0x4ac443=Zn(_0x283e3d,!0x1)['getAll']();return new nn(_0x4ac443)['toPromise']();});if(!_0x99faec)return[];if(this['pendingWrites']!==0x0)return[];const _0x119bd8=[],_0x38602f=new Set();if(_0x99faec['length']!==0x0){for(const {fbase_key:_0x291189,value:_0x31f2e8}of _0x99faec)_0x38602f['add'](_0x291189),JSON['stringify'](this['localCache'][_0x291189])!==JSON['stringify'](_0x31f2e8)&&(this['notifyListeners'](_0x291189,_0x31f2e8),_0x119bd8['push'](_0x291189));}for(const _0x2b56cf of Object['keys'](this['localCache']))this['localCache'][_0x2b56cf]&&!_0x38602f['has'](_0x2b56cf)&&(this['notifyListeners'](_0x2b56cf,null),_0x119bd8['push'](_0x2b56cf));return _0x119bd8;}['notifyListeners'](_0x4fe325,_0x1b7d6d){this['localCache'][_0x4fe325]=_0x1b7d6d;const _0x17bda9=this['listeners'][_0x4fe325];if(_0x17bda9){for(const _0x2878da of Array['from'](_0x17bda9))_0x2878da(_0x1b7d6d);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2ff556,_0xcac8ec){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2ff556]||(this['listeners'][_0x2ff556]=new Set(),this['_get'](_0x2ff556)),this['listeners'][_0x2ff556]['add'](_0xcac8ec);}['_removeListener'](_0x4f54ca,_0xabddfb){this['listeners'][_0x4f54ca]&&(this['listeners'][_0x4f54ca]['delete'](_0xabddfb),this['listeners'][_0x4f54ca]['size']===0x0&&delete this['listeners'][_0x4f54ca]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0x41e2fc,_0x3575b6){return _0x3575b6?ie(_0x3575b6):(m(_0x41e2fc['_popupRedirectResolver'],_0x41e2fc,'argument-error'),_0x41e2fc['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1e6a59){super('custom','custom'),this['params']=_0x1e6a59;}['_getIdTokenResponse'](_0x46ec58){return nt(_0x46ec58,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1f8571,_0x398f7e){return nt(_0x1f8571,this['_buildIdpRequest'](_0x398f7e));}['_getReauthenticationResolver'](_0xc4ddd5){return nt(_0xc4ddd5,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x18a609){const _0x2bbe30={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x18a609&&(_0x2bbe30['idToken']=_0x18a609),_0x2bbe30;}}function vp(_0x3e7f3d){return Va(_0x3e7f3d['auth'],new ks(_0x3e7f3d),_0x3e7f3d['bypassAuthState']);}function Ep(_0x1557d9){const {auth:_0x3cc64b,user:_0x428036}=_0x1557d9;return m(_0x428036,_0x3cc64b,'internal-error'),Zf(_0x428036,new ks(_0x1557d9),_0x1557d9['bypassAuthState']);}async function Ip(_0x43c95d){const {auth:_0x28fc76,user:_0xa921c0}=_0x43c95d;return m(_0xa921c0,_0x28fc76,'internal-error'),Xf(_0xa921c0,new ks(_0x43c95d),_0x43c95d['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3ee90d,_0x497da0,_0x77de7b,_0x4f0069,_0x2240d4=!0x1){this['auth']=_0x3ee90d,this['resolver']=_0x77de7b,this['user']=_0x4f0069,this['bypassAuthState']=_0x2240d4,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x497da0)?_0x497da0:[_0x497da0];}['execute'](){return new Promise(async(_0x34122f,_0x31fd8b)=>{this['pendingPromise']={'resolve':_0x34122f,'reject':_0x31fd8b};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x42d530){this['reject'](_0x42d530);}});}async['onAuthEvent'](_0x441cfe){const {urlResponse:_0x45bc90,sessionId:_0xf75b31,postBody:_0x278161,tenantId:_0x25d472,error:_0xaa7108,type:_0x271390}=_0x441cfe;if(_0xaa7108){this['reject'](_0xaa7108);return;}const _0x573597={'auth':this['auth'],'requestUri':_0x45bc90,'sessionId':_0xf75b31,'tenantId':_0x25d472||void 0x0,'postBody':_0x278161||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x271390)(_0x573597));}catch(_0x358681){this['reject'](_0x358681);}}['onError'](_0x424a5a){this['reject'](_0x424a5a);}['getIdpTask'](_0x2ee005){switch(_0x2ee005){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0x226e5a){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x226e5a),this['unregisterAndCleanUp']();}['reject'](_0xefc20){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xefc20),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x373943,_0x30badb,_0x1c3865,_0x2473dc,_0x3f776f){super(_0x373943,_0x30badb,_0x2473dc,_0x3f776f),this['provider']=_0x1c3865,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x20cc6d=await this['execute']();return m(_0x20cc6d,this['auth'],'internal-error'),_0x20cc6d;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x161ca2=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x161ca2),this['authWindow']['associatedEvent']=_0x161ca2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x21d4ae=>{this['reject'](_0x21d4ae);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x775dc=>{_0x775dc||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x17e8a1;return((_0x17e8a1=this['authWindow'])==null?void 0x0:_0x17e8a1['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5b3233=()=>{var _0x170f6f,_0x35a982;if((_0x35a982=(_0x170f6f=this['authWindow'])==null?void 0x0:_0x170f6f['window'])!=null&&_0x35a982['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5b3233,wp['get']());};_0x5b3233();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x50c6f,_0x24403d,_0x51407a=!0x1){super(_0x50c6f,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x24403d,void 0x0,_0x51407a),this['eventId']=null;}async['execute'](){let _0xccf67f=hn['get'](this['auth']['_key']());if(!_0xccf67f){try{const _0x3c6a0d=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0xccf67f=()=>Promise['resolve'](_0x3c6a0d);}catch(_0x5b34b6){_0xccf67f=()=>Promise['reject'](_0x5b34b6);}hn['set'](this['auth']['_key'](),_0xccf67f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xccf67f();}async['onAuthEvent'](_0x56aeb9){if(_0x56aeb9['type']==='signInViaRedirect')return super['onAuthEvent'](_0x56aeb9);if(_0x56aeb9['type']==='unknown'){this['resolve'](null);return;}if(_0x56aeb9['eventId']){const _0x280b64=await this['auth']['_redirectUserForId'](_0x56aeb9['eventId']);if(_0x280b64)return this['user']=_0x280b64,super['onAuthEvent'](_0x56aeb9);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0x3e7587,_0x4170e3){const _0x195d43=Ap(_0x4170e3),_0x5bdc82=Rp(_0x3e7587);if(!await _0x5bdc82['_isAvailable']())return!0x1;const _0x445cd2=await _0x5bdc82['_get'](_0x195d43)==='true';return await _0x5bdc82['_remove'](_0x195d43),_0x445cd2;}function bp(_0x4ad6ab,_0x37bd0a){hn['set'](_0x4ad6ab['_key'](),_0x37bd0a);}function Rp(_0x3c218a){return ie(_0x3c218a['_redirectPersistence']);}function Ap(_0x1cfaba){return ln(Cp,_0x1cfaba['config']['apiKey'],_0x1cfaba['name']);}async function kp(_0x251ed3,_0x2f57a8,_0x436e95=!0x1){if($(_0x251ed3['app']))return Promise['reject'](re(_0x251ed3));const _0x3b6775=Ke(_0x251ed3),_0x2bd603=yp(_0x3b6775,_0x2f57a8),_0x499742=await new Tp(_0x3b6775,_0x2bd603,_0x436e95)['execute']();return _0x499742&&!_0x436e95&&(delete _0x499742['user']['_redirectEventId'],await _0x3b6775['_persistUserIfCurrent'](_0x499742['user']),await _0x3b6775['_setRedirectUser'](null,_0x2f57a8)),_0x499742;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x48caa0){this['auth']=_0x48caa0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x5f2aa8){this['consumers']['add'](_0x5f2aa8),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x5f2aa8)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x5f2aa8),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2ca372){this['consumers']['delete'](_0x2ca372);}['onEvent'](_0x5b1ebb){if(this['hasEventBeenHandled'](_0x5b1ebb))return!0x1;let _0x16bc0d=!0x1;return this['consumers']['forEach'](_0x56a620=>{this['isEventForConsumer'](_0x5b1ebb,_0x56a620)&&(_0x16bc0d=!0x0,this['sendToConsumer'](_0x5b1ebb,_0x56a620),this['saveEventToCache'](_0x5b1ebb));}),this['hasHandledPotentialRedirect']||!Op(_0x5b1ebb)||(this['hasHandledPotentialRedirect']=!0x0,_0x16bc0d||(this['queuedRedirectEvent']=_0x5b1ebb,_0x16bc0d=!0x0)),_0x16bc0d;}['sendToConsumer'](_0x455a22,_0x3db671){var _0x5cc765;if(_0x455a22['error']&&!Za(_0x455a22)){const _0x4a1eaf=((_0x5cc765=_0x455a22['error']['code'])==null?void 0x0:_0x5cc765['split']('auth/')[0x1])||'internal-error';_0x3db671['onError'](X(this['auth'],_0x4a1eaf));}else _0x3db671['onAuthEvent'](_0x455a22);}['isEventForConsumer'](_0x52760c,_0x226eb5){const _0x5457d7=_0x226eb5['eventId']===null||!!_0x52760c['eventId']&&_0x52760c['eventId']===_0x226eb5['eventId'];return _0x226eb5['filter']['includes'](_0x52760c['type'])&&_0x5457d7;}['hasEventBeenHandled'](_0x2490e7){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2490e7));}['saveEventToCache'](_0x127e6f){this['cachedEventUids']['add'](Mr(_0x127e6f)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x6420d7){return[_0x6420d7['type'],_0x6420d7['eventId'],_0x6420d7['sessionId'],_0x6420d7['tenantId']]['filter'](_0x31fa4b=>_0x31fa4b)['join']('-');}function Za({type:_0x33b5a4,error:_0x775a24}){return _0x33b5a4==='unknown'&&(_0x775a24==null?void 0x0:_0x775a24['code'])==='auth/no-auth-event';}function Op(_0x3406a3){switch(_0x3406a3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3406a3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x481e0b,_0x20631c={}){return ke(_0x481e0b,'GET','/v1/projects',_0x20631c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x4d8944){if(_0x4d8944['config']['emulator'])return;const {authorizedDomains:_0x5d8ce0}=await Dp(_0x4d8944);for(const _0x16ea23 of _0x5d8ce0)try{if(Fp(_0x16ea23))return;}catch{}Y(_0x4d8944,'unauthorized-domain');}function Fp(_0x223b79){const _0x4cf8ae=Mi(),{protocol:_0x56ec0e,hostname:_0x45ffa1}=new URL(_0x4cf8ae);if(_0x223b79['startsWith']('chrome-extension://')){const _0x57b1f4=new URL(_0x223b79);return _0x57b1f4['hostname']===''&&_0x45ffa1===''?_0x56ec0e==='chrome-extension:'&&_0x223b79['replace']('chrome-extension://','')===_0x4cf8ae['replace']('chrome-extension://',''):_0x56ec0e==='chrome-extension:'&&_0x57b1f4['hostname']===_0x45ffa1;}if(!Lp['test'](_0x56ec0e))return!0x1;if(Mp['test'](_0x223b79))return _0x45ffa1===_0x223b79;const _0x462cca=_0x223b79['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x462cca+'|'+_0x462cca+')$','i')['test'](_0x45ffa1);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0x13f649=Z()['___jsl'];if(_0x13f649!=null&&_0x13f649['H']){for(const _0x554488 of Object['keys'](_0x13f649['H']))if(_0x13f649['H'][_0x554488]['r']=_0x13f649['H'][_0x554488]['r']||[],_0x13f649['H'][_0x554488]['L']=_0x13f649['H'][_0x554488]['L']||[],_0x13f649['H'][_0x554488]['r']=[..._0x13f649['H'][_0x554488]['L']],_0x13f649['CP']){for(let _0x3c1206=0x0;_0x3c1206<_0x13f649['CP']['length'];_0x3c1206++)_0x13f649['CP'][_0x3c1206]=null;}}}function Wp(_0x283454){return new Promise((_0x257330,_0x949fbd)=>{var _0x30760c,_0x170e38,_0x27854e;function _0x1d7f92(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x257330(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x949fbd(X(_0x283454,'network-request-failed'));},'timeout':Up['get']()});}if((_0x170e38=(_0x30760c=Z()['gapi'])==null?void 0x0:_0x30760c['iframes'])!=null&&_0x170e38['Iframe'])_0x257330(gapi['iframes']['getContext']());else{if((_0x27854e=Z()['gapi'])!=null&&_0x27854e['load'])_0x1d7f92();else{const _0x2eefc3=Lf('iframefcb');return Z()[_0x2eefc3]=()=>{gapi['load']?_0x1d7f92():_0x949fbd(X(_0x283454,'network-request-failed'));},xa(Mf()+'?onload='+_0x2eefc3)['catch'](_0xfa9471=>_0x949fbd(_0xfa9471));}}})['catch'](_0x151a5c=>{throw un=null,_0x151a5c;});}let un=null;function Bp(_0x29d649){return un=un||Wp(_0x29d649),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0xf963ca){const _0x51c444=_0xf963ca['config'];m(_0x51c444['authDomain'],_0xf963ca,'auth-domain-config-required');const _0x3e2103=_0x51c444['emulator']?Cs(_0x51c444,$p):'https://'+_0xf963ca['config']['authDomain']+'/'+Hp,_0x4cc59b={'apiKey':_0x51c444['apiKey'],'appName':_0xf963ca['name'],'v':dt},_0x31bc0e=qp['get'](_0xf963ca['config']['apiHost']);_0x31bc0e&&(_0x4cc59b['eid']=_0x31bc0e);const _0x481600=_0xf963ca['_getFrameworks']();return _0x481600['length']&&(_0x4cc59b['fw']=_0x481600['join'](',')),_0x3e2103+'?'+ut(_0x4cc59b)['slice'](0x1);}async function jp(_0x443880){const _0x530168=await Bp(_0x443880),_0x161189=Z()['gapi'];return m(_0x161189,_0x443880,'internal-error'),_0x530168['open']({'where':document['body'],'url':zp(_0x443880),'messageHandlersFilter':_0x161189['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0x56b263=>new Promise(async(_0x20867,_0x1347b3)=>{await _0x56b263['restyle']({'setHideOnLeave':!0x1});const _0x20ad5e=X(_0x443880,'network-request-failed'),_0x366613=Z()['setTimeout'](()=>{_0x1347b3(_0x20ad5e);},Vp['get']());function _0x12629f(){Z()['clearTimeout'](_0x366613),_0x20867(_0x56b263);}_0x56b263['ping'](_0x12629f)['then'](_0x12629f,()=>{_0x1347b3(_0x20ad5e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x4011d5){this['window']=_0x4011d5,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x1b92d1,_0x576d61,_0x3f39e4,_0x9d8579=Yp,_0x35ac7c=Qp){const _0x1181f7=Math['max']((window['screen']['availHeight']-_0x35ac7c)/0x2,0x0)['toString'](),_0x4ded65=Math['max']((window['screen']['availWidth']-_0x9d8579)/0x2,0x0)['toString']();let _0x5b6ebb='';const _0x494f0d={...Kp,'width':_0x9d8579['toString'](),'height':_0x35ac7c['toString'](),'top':_0x1181f7,'left':_0x4ded65},_0x5147e6=W()['toLowerCase']();_0x3f39e4&&(_0x5b6ebb=ka(_0x5147e6)?Jp:_0x3f39e4),Ra(_0x5147e6)&&(_0x576d61=_0x576d61||Xp,_0x494f0d['scrollbars']='yes');const _0x4e8f60=Object['entries'](_0x494f0d)['reduce']((_0x1e56d2,[_0x2ab3f0,_0xac30a6])=>''+_0x1e56d2+_0x2ab3f0+'='+_0xac30a6+',','');if(Sf(_0x5147e6)&&_0x5b6ebb!=='_self')return e_(_0x576d61||'',_0x5b6ebb),new xr(null);const _0x2d579c=window['open'](_0x576d61||'',_0x5b6ebb,_0x4e8f60);m(_0x2d579c,_0x1b92d1,'popup-blocked');try{_0x2d579c['focus']();}catch{}return new xr(_0x2d579c);}function e_(_0x298a1e,_0xa68554){const _0x198930=document['createElement']('a');_0x198930['href']=_0x298a1e,_0x198930['target']=_0xa68554;const _0x439a8b=document['createEvent']('MouseEvent');_0x439a8b['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x198930['dispatchEvent'](_0x439a8b);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0x229b3b,_0x2ed68c,_0x133399,_0xdfc4be,_0x77b256,_0x1eb4e3){m(_0x229b3b['config']['authDomain'],_0x229b3b,'auth-domain-config-required'),m(_0x229b3b['config']['apiKey'],_0x229b3b,'invalid-api-key');const _0x284759={'apiKey':_0x229b3b['config']['apiKey'],'appName':_0x229b3b['name'],'authType':_0x133399,'redirectUrl':_0xdfc4be,'v':dt,'eventId':_0x77b256};if(_0x2ed68c instanceof Wa){_0x2ed68c['setDefaultLanguage'](_0x229b3b['languageCode']),_0x284759['providerId']=_0x2ed68c['providerId']||'',pn(_0x2ed68c['getCustomParameters']())||(_0x284759['customParameters']=JSON['stringify'](_0x2ed68c['getCustomParameters']()));for(const [_0x46179d,_0x203e78]of Object['entries']({}))_0x284759[_0x46179d]=_0x203e78;}if(_0x2ed68c instanceof tn){const _0x1dd6c9=_0x2ed68c['getScopes']()['filter'](_0x329271=>_0x329271!=='');_0x1dd6c9['length']>0x0&&(_0x284759['scopes']=_0x1dd6c9['join'](','));}_0x229b3b['tenantId']&&(_0x284759['tid']=_0x229b3b['tenantId']);const _0x2ba968=_0x284759;for(const _0x44adc5 of Object['keys'](_0x2ba968))_0x2ba968[_0x44adc5]===void 0x0&&delete _0x2ba968[_0x44adc5];const _0x21c4a9=await _0x229b3b['_getAppCheckToken'](),_0x5420b7=_0x21c4a9?'#'+i_+'='+encodeURIComponent(_0x21c4a9):'';return s_(_0x229b3b)+'?'+ut(_0x2ba968)['slice'](0x1)+_0x5420b7;}function s_({config:_0x392b51}){return _0x392b51['emulator']?Cs(_0x392b51,n_):'https://'+_0x392b51['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x52246e,_0x57f768,_0x1f04af,_0x1edb50){var _0x245731;ce((_0x245731=this['eventManagers'][_0x52246e['_key']()])==null?void 0x0:_0x245731['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x165ab0=await Fr(_0x52246e,_0x57f768,_0x1f04af,Mi(),_0x1edb50);return Zp(_0x52246e,_0x165ab0,As());}async['_openRedirect'](_0x4c5cf2,_0x3fdc5c,_0x37fb4e,_0x334450){await this['_originValidation'](_0x4c5cf2);const _0x5dc326=await Fr(_0x4c5cf2,_0x3fdc5c,_0x37fb4e,Mi(),_0x334450);return cp(_0x5dc326),new Promise(()=>{});}['_initialize'](_0x5323d1){const _0x3c0211=_0x5323d1['_key']();if(this['eventManagers'][_0x3c0211]){const {manager:_0x4e72f5,promise:_0x19e3f5}=this['eventManagers'][_0x3c0211];return _0x4e72f5?Promise['resolve'](_0x4e72f5):(ce(_0x19e3f5,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x19e3f5);}const _0x5d569d=this['initAndGetManager'](_0x5323d1);return this['eventManagers'][_0x3c0211]={'promise':_0x5d569d},_0x5d569d['catch'](()=>{delete this['eventManagers'][_0x3c0211];}),_0x5d569d;}async['initAndGetManager'](_0x1affd4){const _0x13618c=await jp(_0x1affd4),_0x117d2a=new Pp(_0x1affd4);return _0x13618c['register']('authEvent',_0x3c2a37=>(m(_0x3c2a37==null?void 0x0:_0x3c2a37['authEvent'],_0x1affd4,'invalid-auth-event'),{'status':_0x117d2a['onEvent'](_0x3c2a37['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1affd4['_key']()]={'manager':_0x117d2a},this['iframes'][_0x1affd4['_key']()]=_0x13618c,_0x117d2a;}['_isIframeWebStorageSupported'](_0x117107,_0x1233a4){this['iframes'][_0x117107['_key']()]['send'](pi,{'type':pi},_0x5cdff0=>{var _0x3ccf6d;const _0x5cd8ca=(_0x3ccf6d=_0x5cdff0==null?void 0x0:_0x5cdff0[0x0])==null?void 0x0:_0x3ccf6d[pi];_0x5cd8ca!==void 0x0&&_0x1233a4(!!_0x5cd8ca),Y(_0x117107,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x412062){const _0x1340ac=_0x412062['_key']();return this['originValidationPromises'][_0x1340ac]||(this['originValidationPromises'][_0x1340ac]=xp(_0x412062)),this['originValidationPromises'][_0x1340ac];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0xd82ff0){this['auth']=_0xd82ff0,this['internalListeners']=new Map();}['getUid'](){var _0x1e3941;return this['assertAuthConfigured'](),((_0x1e3941=this['auth']['currentUser'])==null?void 0x0:_0x1e3941['uid'])||null;}async['getToken'](_0x3278e8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3278e8)}:null;}['addAuthTokenListener'](_0x18b6e8){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x18b6e8))return;const _0x5c5e81=this['auth']['onIdTokenChanged'](_0x25cc5c=>{_0x18b6e8((_0x25cc5c==null?void 0x0:_0x25cc5c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x18b6e8,_0x5c5e81),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x580c2a){this['assertAuthConfigured']();const _0x576277=this['internalListeners']['get'](_0x580c2a);_0x576277&&(this['internalListeners']['delete'](_0x580c2a),_0x576277(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x274b69){switch(_0x274b69){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x4c4231){st(new xe('auth',(_0x35b225,{options:_0x3ed5c4})=>{const _0x332c22=_0x35b225['getProvider']('app')['getImmediate'](),_0x29039b=_0x35b225['getProvider']('heartbeat'),_0x45f39b=_0x35b225['getProvider']('app-check-internal'),{apiKey:_0x594cf7,authDomain:_0x39822a}=_0x332c22['options'];m(_0x594cf7&&!_0x594cf7['includes'](':'),'invalid-api-key',{'appName':_0x332c22['name']});const _0x13981={'apiKey':_0x594cf7,'authDomain':_0x39822a,'clientPlatform':_0x4c4231,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4c4231)},_0x48694d=new Pf(_0x332c22,_0x29039b,_0x45f39b,_0x13981);return Bf(_0x48694d,_0x3ed5c4),_0x48694d;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3bb9a2,_0x2efadb,_0x3ac055)=>{_0x3bb9a2['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x4419b9=>{const _0x178577=Ke(_0x4419b9['getProvider']('auth')['getImmediate']());return(_0x3f7e74=>new a_(_0x3f7e74))(_0x178577);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x4c4231)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x573e99=>async _0x85ceff=>{const _0x252206=_0x85ceff&&await _0x85ceff['getIdTokenResult'](),_0xa1c692=_0x252206&&(new Date()['getTime']()-Date['parse'](_0x252206['issuedAtTime']))/0x3e8;if(_0xa1c692&&_0xa1c692>u_)return;const _0x69295b=_0x252206==null?void 0x0:_0x252206['token'];Br!==_0x69295b&&(Br=_0x69295b,await fetch(_0x573e99,{'method':_0x69295b?'POST':'DELETE','headers':_0x69295b?{'Authorization':'Bearer\x20'+_0x69295b}:{}}));};function F_(_0x323d78=Zr()){const _0x13d3ba=Hi(_0x323d78,'auth');if(_0x13d3ba['isInitialized']())return _0x13d3ba['getImmediate']();const _0x1717fa=Wf(_0x323d78,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0x489c1b=jr('authTokenSyncURL');if(_0x489c1b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x20e2ce=new URL(_0x489c1b,location['origin']);if(location['origin']===_0x20e2ce['origin']){const _0x1961e4=d_(_0x20e2ce['toString']());np(_0x1717fa,_0x1961e4,()=>_0x1961e4(_0x1717fa['currentUser'])),tp(_0x1717fa,_0xbeb51=>_0x1961e4(_0xbeb51));}}const _0x2a2663=qr('auth');return _0x2a2663&&Vf(_0x1717fa,'http://'+_0x2a2663),_0x1717fa;}function f_(){var _0x15bf5d;return((_0x15bf5d=document['getElementsByTagName']('head'))==null?void 0x0:_0x15bf5d[0x0])??document;}Of({'loadJS'(_0x117d8b){return new Promise((_0x3cfec4,_0x5c7012)=>{const _0x542288=document['createElement']('script');_0x542288['setAttribute']('src',_0x117d8b),_0x542288['onload']=_0x3cfec4,_0x542288['onerror']=_0x343e8a=>{const _0x284908=X('internal-error');_0x284908['customData']=_0x343e8a,_0x5c7012(_0x284908);},_0x542288['type']='text/javascript',_0x542288['charset']='UTF-8',f_()['appendChild'](_0x542288);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{x_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,__ as h,Sl as i,Vd as j,N_ as k,$d as l,A_ as m,L_ as n,m_ as o,k_ as p,b_ as q,g_ as r,M_ as s,C_ as t,v_ as u,S_ as v,Bt as w,y_ as x,P_ as y,O_ as z};