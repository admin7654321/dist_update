const tc=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4ee3e1,_0x491949){if(!_0x4ee3e1)throw ht(_0x491949);},ht=function(_0x20c4f8){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x20c4f8);},Hr=function(_0x3627c1){const _0x2eb0ab=[];let _0x2556ec=0x0;for(let _0x5df7c5=0x0;_0x5df7c5<_0x3627c1['length'];_0x5df7c5++){let _0x109120=_0x3627c1['charCodeAt'](_0x5df7c5);_0x109120<0x80?_0x2eb0ab[_0x2556ec++]=_0x109120:_0x109120<0x800?(_0x2eb0ab[_0x2556ec++]=_0x109120>>0x6|0xc0,_0x2eb0ab[_0x2556ec++]=_0x109120&0x3f|0x80):(_0x109120&0xfc00)===0xd800&&_0x5df7c5+0x1<_0x3627c1['length']&&(_0x3627c1['charCodeAt'](_0x5df7c5+0x1)&0xfc00)===0xdc00?(_0x109120=0x10000+((_0x109120&0x3ff)<<0xa)+(_0x3627c1['charCodeAt'](++_0x5df7c5)&0x3ff),_0x2eb0ab[_0x2556ec++]=_0x109120>>0x12|0xf0,_0x2eb0ab[_0x2556ec++]=_0x109120>>0xc&0x3f|0x80,_0x2eb0ab[_0x2556ec++]=_0x109120>>0x6&0x3f|0x80,_0x2eb0ab[_0x2556ec++]=_0x109120&0x3f|0x80):(_0x2eb0ab[_0x2556ec++]=_0x109120>>0xc|0xe0,_0x2eb0ab[_0x2556ec++]=_0x109120>>0x6&0x3f|0x80,_0x2eb0ab[_0x2556ec++]=_0x109120&0x3f|0x80);}return _0x2eb0ab;},nc=function(_0x3d1d0a){const _0x3731be=[];let _0x225350=0x0,_0x236c6e=0x0;for(;_0x225350<_0x3d1d0a['length'];){const _0x4179f1=_0x3d1d0a[_0x225350++];if(_0x4179f1<0x80)_0x3731be[_0x236c6e++]=String['fromCharCode'](_0x4179f1);else{if(_0x4179f1>0xbf&&_0x4179f1<0xe0){const _0x37b137=_0x3d1d0a[_0x225350++];_0x3731be[_0x236c6e++]=String['fromCharCode']((_0x4179f1&0x1f)<<0x6|_0x37b137&0x3f);}else{if(_0x4179f1>0xef&&_0x4179f1<0x16d){const _0x4d3779=_0x3d1d0a[_0x225350++],_0x289857=_0x3d1d0a[_0x225350++],_0x483a4b=_0x3d1d0a[_0x225350++],_0x5c16ef=((_0x4179f1&0x7)<<0x12|(_0x4d3779&0x3f)<<0xc|(_0x289857&0x3f)<<0x6|_0x483a4b&0x3f)-0x10000;_0x3731be[_0x236c6e++]=String['fromCharCode'](0xd800+(_0x5c16ef>>0xa)),_0x3731be[_0x236c6e++]=String['fromCharCode'](0xdc00+(_0x5c16ef&0x3ff));}else{const _0x48199a=_0x3d1d0a[_0x225350++],_0x5a2704=_0x3d1d0a[_0x225350++];_0x3731be[_0x236c6e++]=String['fromCharCode']((_0x4179f1&0xf)<<0xc|(_0x48199a&0x3f)<<0x6|_0x5a2704&0x3f);}}}}return _0x3731be['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3a49f2,_0x20a640){if(!Array['isArray'](_0x3a49f2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x43efb0=_0x20a640?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1c702d=[];for(let _0x5254a0=0x0;_0x5254a0<_0x3a49f2['length'];_0x5254a0+=0x3){const _0xa7e45f=_0x3a49f2[_0x5254a0],_0x540602=_0x5254a0+0x1<_0x3a49f2['length'],_0x26f0ec=_0x540602?_0x3a49f2[_0x5254a0+0x1]:0x0,_0x3fcb9a=_0x5254a0+0x2<_0x3a49f2['length'],_0x1cb972=_0x3fcb9a?_0x3a49f2[_0x5254a0+0x2]:0x0,_0x4e577f=_0xa7e45f>>0x2,_0x5df193=(_0xa7e45f&0x3)<<0x4|_0x26f0ec>>0x4;let _0x4b1736=(_0x26f0ec&0xf)<<0x2|_0x1cb972>>0x6,_0x46a34c=_0x1cb972&0x3f;_0x3fcb9a||(_0x46a34c=0x40,_0x540602||(_0x4b1736=0x40)),_0x1c702d['push'](_0x43efb0[_0x4e577f],_0x43efb0[_0x5df193],_0x43efb0[_0x4b1736],_0x43efb0[_0x46a34c]);}return _0x1c702d['join']('');},'encodeString'(_0x5c0989,_0x3d2d11){return this['HAS_NATIVE_SUPPORT']&&!_0x3d2d11?btoa(_0x5c0989):this['encodeByteArray'](Hr(_0x5c0989),_0x3d2d11);},'decodeString'(_0x2dc239,_0x89ddd3){return this['HAS_NATIVE_SUPPORT']&&!_0x89ddd3?atob(_0x2dc239):nc(this['decodeStringToByteArray'](_0x2dc239,_0x89ddd3));},'decodeStringToByteArray'(_0x4f2af1,_0x4e05f7){this['init_']();const _0x16132d=_0x4e05f7?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x21c6e0=[];for(let _0x2a0f7e=0x0;_0x2a0f7e<_0x4f2af1['length'];){const _0x3a572f=_0x16132d[_0x4f2af1['charAt'](_0x2a0f7e++)],_0x3577b2=_0x2a0f7e<_0x4f2af1['length']?_0x16132d[_0x4f2af1['charAt'](_0x2a0f7e)]:0x0;++_0x2a0f7e;const _0x18a8c3=_0x2a0f7e<_0x4f2af1['length']?_0x16132d[_0x4f2af1['charAt'](_0x2a0f7e)]:0x40;++_0x2a0f7e;const _0x5d2caf=_0x2a0f7e<_0x4f2af1['length']?_0x16132d[_0x4f2af1['charAt'](_0x2a0f7e)]:0x40;if(++_0x2a0f7e,_0x3a572f==null||_0x3577b2==null||_0x18a8c3==null||_0x5d2caf==null)throw new ic();const _0x9c1cdf=_0x3a572f<<0x2|_0x3577b2>>0x4;if(_0x21c6e0['push'](_0x9c1cdf),_0x18a8c3!==0x40){const _0x1b6f90=_0x3577b2<<0x4&0xf0|_0x18a8c3>>0x2;if(_0x21c6e0['push'](_0x1b6f90),_0x5d2caf!==0x40){const _0x1e2773=_0x18a8c3<<0x6&0xc0|_0x5d2caf;_0x21c6e0['push'](_0x1e2773);}}}return _0x21c6e0;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xfff878=0x0;_0xfff878<this['ENCODED_VALS']['length'];_0xfff878++)this['byteToCharMap_'][_0xfff878]=this['ENCODED_VALS']['charAt'](_0xfff878),this['charToByteMap_'][this['byteToCharMap_'][_0xfff878]]=_0xfff878,this['byteToCharMapWebSafe_'][_0xfff878]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfff878),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xfff878]]=_0xfff878,_0xfff878>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfff878)]=_0xfff878,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xfff878)]=_0xfff878);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3e6065){const _0x2e0b2b=Hr(_0x3e6065);return Fi['encodeByteArray'](_0x2e0b2b,!0x0);},dn=function(_0x77d937){return $r(_0x77d937)['replace'](/\./g,'');},fn=function(_0x3af27f){try{return Fi['decodeString'](_0x3af27f,!0x0);}catch(_0x6d2810){console['error']('base64Decode\x20failed:\x20',_0x6d2810);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x48ee7b){return Gr(void 0x0,_0x48ee7b);}function Gr(_0x4e9acd,_0x4107f9){if(!(_0x4107f9 instanceof Object))return _0x4107f9;switch(_0x4107f9['constructor']){case Date:const _0x2aaf45=_0x4107f9;return new Date(_0x2aaf45['getTime']());case Object:_0x4e9acd===void 0x0&&(_0x4e9acd={});break;case Array:_0x4e9acd=[];break;default:return _0x4107f9;}for(const _0x102074 in _0x4107f9)!_0x4107f9['hasOwnProperty'](_0x102074)||!rc(_0x102074)||(_0x4e9acd[_0x102074]=Gr(_0x4e9acd[_0x102074],_0x4107f9[_0x102074]));return _0x4e9acd;}function rc(_0x5408cf){return _0x5408cf!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3ef99b=Ns['__FIREBASE_DEFAULTS__'];if(_0x3ef99b)return JSON['parse'](_0x3ef99b);},lc=()=>{if(typeof document>'u')return;let _0x4bc5a3;try{_0x4bc5a3=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5ec9e5=_0x4bc5a3&&fn(_0x4bc5a3[0x1]);return _0x5ec9e5&&JSON['parse'](_0x5ec9e5);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x14e017){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x14e017);return;}},qr=_0x44cdd8=>{var _0x2a539f,_0x43f73c;return(_0x43f73c=(_0x2a539f=Ui())==null?void 0x0:_0x2a539f['emulatorHosts'])==null?void 0x0:_0x43f73c[_0x44cdd8];},hc=_0x40524d=>{const _0x4eaf74=qr(_0x40524d);if(!_0x4eaf74)return;const _0xcaee0=_0x4eaf74['lastIndexOf'](':');if(_0xcaee0<=0x0||_0xcaee0+0x1===_0x4eaf74['length'])throw new Error('Invalid\x20host\x20'+_0x4eaf74+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4fc56d=parseInt(_0x4eaf74['substring'](_0xcaee0+0x1),0xa);return _0x4eaf74[0x0]==='['?[_0x4eaf74['substring'](0x1,_0xcaee0-0x1),_0x4fc56d]:[_0x4eaf74['substring'](0x0,_0xcaee0),_0x4fc56d];},zr=()=>{var _0x925ddd;return(_0x925ddd=Ui())==null?void 0x0:_0x925ddd['config'];},jr=_0x5b40f5=>{var _0x2ac4bd;return(_0x2ac4bd=Ui())==null?void 0x0:_0x2ac4bd['_'+_0x5b40f5];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x81461d,_0xcc4f16)=>{this['resolve']=_0x81461d,this['reject']=_0xcc4f16;});}['wrapCallback'](_0xced811){return(_0xb72de4,_0x36f4f6)=>{_0xb72de4?this['reject'](_0xb72de4):this['resolve'](_0x36f4f6),typeof _0xced811=='function'&&(this['promise']['catch'](()=>{}),_0xced811['length']===0x1?_0xced811(_0xb72de4):_0xced811(_0xb72de4,_0x36f4f6));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x280515,_0x104791){if(_0x280515['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x58e5af={'alg':'none','type':'JWT'},_0x3525e8=_0x104791||'demo-project',_0x3be000=_0x280515['iat']||0x0,_0x3c6940=_0x280515['sub']||_0x280515['user_id'];if(!_0x3c6940)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xdb817b={'iss':'https://securetoken.google.com/'+_0x3525e8,'aud':_0x3525e8,'iat':_0x3be000,'exp':_0x3be000+0xe10,'auth_time':_0x3be000,'sub':_0x3c6940,'user_id':_0x3c6940,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x280515};return[dn(JSON['stringify'](_0x58e5af)),dn(JSON['stringify'](_0xdb817b)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5abb9a=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5abb9a=='object'&&_0x5abb9a['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x46ba55=W();return _0x46ba55['indexOf']('MSIE\x20')>=0x0||_0x46ba55['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x507854,_0x1983ec)=>{try{let _0x3d9a99=!0x0;const _0xec6b53='validate-browser-context-for-indexeddb-analytics-module',_0x3e0e4e=self['indexedDB']['open'](_0xec6b53);_0x3e0e4e['onsuccess']=()=>{_0x3e0e4e['result']['close'](),_0x3d9a99||self['indexedDB']['deleteDatabase'](_0xec6b53),_0x507854(!0x0);},_0x3e0e4e['onupgradeneeded']=()=>{_0x3d9a99=!0x1;},_0x3e0e4e['onerror']=()=>{var _0x5e51e5;_0x1983ec(((_0x5e51e5=_0x3e0e4e['error'])==null?void 0x0:_0x5e51e5['message'])||'');};}catch(_0x30b1b8){_0x1983ec(_0x30b1b8);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x4fd497,_0x37c060,_0x45e362){super(_0x37c060),this['code']=_0x4fd497,this['customData']=_0x45e362,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x5a8f20,_0x37bfdd,_0x370caa){this['service']=_0x5a8f20,this['serviceName']=_0x37bfdd,this['errors']=_0x370caa;}['create'](_0x566ef0,..._0x3e0222){const _0x33fcb7=_0x3e0222[0x0]||{},_0x23206b=this['service']+'/'+_0x566ef0,_0x18b89a=this['errors'][_0x566ef0],_0x14d6ff=_0x18b89a?vc(_0x18b89a,_0x33fcb7):'Error',_0x5cde04=this['serviceName']+':\x20'+_0x14d6ff+'\x20('+_0x23206b+').';return new Re(_0x23206b,_0x5cde04,_0x33fcb7);}}function vc(_0x27331d,_0x127117){return _0x27331d['replace'](Ec,(_0xaee519,_0x2d12a7)=>{const _0x1fab5e=_0x127117[_0x2d12a7];return _0x1fab5e!=null?String(_0x1fab5e):'<'+_0x2d12a7+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x24bc79){return JSON['parse'](_0x24bc79);}function O(_0x52dc97){return JSON['stringify'](_0x52dc97);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5cf8e6){let _0xf6b423={},_0x173cfe={},_0xd9ca6a={},_0x4d7444='';try{const _0x351e49=_0x5cf8e6['split']('.');_0xf6b423=Nt(fn(_0x351e49[0x0])||''),_0x173cfe=Nt(fn(_0x351e49[0x1])||''),_0x4d7444=_0x351e49[0x2],_0xd9ca6a=_0x173cfe['d']||{},delete _0x173cfe['d'];}catch{}return{'header':_0xf6b423,'claims':_0x173cfe,'data':_0xd9ca6a,'signature':_0x4d7444};},Ic=function(_0xdad2f5){const _0x43d835=Yr(_0xdad2f5),_0x1d68cc=_0x43d835['claims'];return!!_0x1d68cc&&typeof _0x1d68cc=='object'&&_0x1d68cc['hasOwnProperty']('iat');},wc=function(_0x49a914){const _0x278b1e=Yr(_0x49a914)['claims'];return typeof _0x278b1e=='object'&&_0x278b1e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1914c9,_0x3b59c3){return Object['prototype']['hasOwnProperty']['call'](_0x1914c9,_0x3b59c3);}function Me(_0x225bf3,_0xe2f457){if(Object['prototype']['hasOwnProperty']['call'](_0x225bf3,_0xe2f457))return _0x225bf3[_0xe2f457];}function pn(_0x11c134){for(const _0x2a267d in _0x11c134)if(Object['prototype']['hasOwnProperty']['call'](_0x11c134,_0x2a267d))return!0x1;return!0x0;}function _n(_0x283b8b,_0x2fd0c4,_0x4a93f2){const _0x10298d={};for(const _0x9f4ae2 in _0x283b8b)Object['prototype']['hasOwnProperty']['call'](_0x283b8b,_0x9f4ae2)&&(_0x10298d[_0x9f4ae2]=_0x2fd0c4['call'](_0x4a93f2,_0x283b8b[_0x9f4ae2],_0x9f4ae2,_0x283b8b));return _0x10298d;}function Le(_0x421c5e,_0x1d0078){if(_0x421c5e===_0x1d0078)return!0x0;const _0x41832e=Object['keys'](_0x421c5e),_0x57bfbc=Object['keys'](_0x1d0078);for(const _0xfc82c4 of _0x41832e){if(!_0x57bfbc['includes'](_0xfc82c4))return!0x1;const _0x5dd1db=_0x421c5e[_0xfc82c4],_0x25ceac=_0x1d0078[_0xfc82c4];if(Ps(_0x5dd1db)&&Ps(_0x25ceac)){if(!Le(_0x5dd1db,_0x25ceac))return!0x1;}else{if(_0x5dd1db!==_0x25ceac)return!0x1;}}for(const _0x2cb44c of _0x57bfbc)if(!_0x41832e['includes'](_0x2cb44c))return!0x1;return!0x0;}function Ps(_0x57780f){return _0x57780f!==null&&typeof _0x57780f=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x489b4a){const _0x4f95cb=[];for(const [_0x5cfa6e,_0x1ddc2e]of Object['entries'](_0x489b4a))Array['isArray'](_0x1ddc2e)?_0x1ddc2e['forEach'](_0x4dcfc8=>{_0x4f95cb['push'](encodeURIComponent(_0x5cfa6e)+'='+encodeURIComponent(_0x4dcfc8));}):_0x4f95cb['push'](encodeURIComponent(_0x5cfa6e)+'='+encodeURIComponent(_0x1ddc2e));return _0x4f95cb['length']?'&'+_0x4f95cb['join']('&'):'';}function wt(_0x238ac7){const _0x135293={};return _0x238ac7['replace'](/^\?/,'')['split']('&')['forEach'](_0x5055b3=>{if(_0x5055b3){const [_0x405ede,_0xeff841]=_0x5055b3['split']('=');_0x135293[decodeURIComponent(_0x405ede)]=decodeURIComponent(_0xeff841);}}),_0x135293;}function Ct(_0x3bf169){const _0x43faf8=_0x3bf169['indexOf']('?');if(!_0x43faf8)return'';const _0x368e14=_0x3bf169['indexOf']('#',_0x43faf8);return _0x3bf169['substring'](_0x43faf8,_0x368e14>0x0?_0x368e14:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x150fea=0x1;_0x150fea<this['blockSize'];++_0x150fea)this['pad_'][_0x150fea]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1934d3,_0x2d46e7){_0x2d46e7||(_0x2d46e7=0x0);const _0x2a22dc=this['W_'];if(typeof _0x1934d3=='string'){for(let _0x29594f=0x0;_0x29594f<0x10;_0x29594f++)_0x2a22dc[_0x29594f]=_0x1934d3['charCodeAt'](_0x2d46e7)<<0x18|_0x1934d3['charCodeAt'](_0x2d46e7+0x1)<<0x10|_0x1934d3['charCodeAt'](_0x2d46e7+0x2)<<0x8|_0x1934d3['charCodeAt'](_0x2d46e7+0x3),_0x2d46e7+=0x4;}else{for(let _0x493e4d=0x0;_0x493e4d<0x10;_0x493e4d++)_0x2a22dc[_0x493e4d]=_0x1934d3[_0x2d46e7]<<0x18|_0x1934d3[_0x2d46e7+0x1]<<0x10|_0x1934d3[_0x2d46e7+0x2]<<0x8|_0x1934d3[_0x2d46e7+0x3],_0x2d46e7+=0x4;}for(let _0x31b2b2=0x10;_0x31b2b2<0x50;_0x31b2b2++){const _0xe344fd=_0x2a22dc[_0x31b2b2-0x3]^_0x2a22dc[_0x31b2b2-0x8]^_0x2a22dc[_0x31b2b2-0xe]^_0x2a22dc[_0x31b2b2-0x10];_0x2a22dc[_0x31b2b2]=(_0xe344fd<<0x1|_0xe344fd>>>0x1f)&0xffffffff;}let _0x27c30b=this['chain_'][0x0],_0x46268c=this['chain_'][0x1],_0x4649e4=this['chain_'][0x2],_0x3e40b2=this['chain_'][0x3],_0x5df608=this['chain_'][0x4],_0xb59c0b,_0x95db1a;for(let _0x286dff=0x0;_0x286dff<0x50;_0x286dff++){_0x286dff<0x28?_0x286dff<0x14?(_0xb59c0b=_0x3e40b2^_0x46268c&(_0x4649e4^_0x3e40b2),_0x95db1a=0x5a827999):(_0xb59c0b=_0x46268c^_0x4649e4^_0x3e40b2,_0x95db1a=0x6ed9eba1):_0x286dff<0x3c?(_0xb59c0b=_0x46268c&_0x4649e4|_0x3e40b2&(_0x46268c|_0x4649e4),_0x95db1a=0x8f1bbcdc):(_0xb59c0b=_0x46268c^_0x4649e4^_0x3e40b2,_0x95db1a=0xca62c1d6);const _0xa246d6=(_0x27c30b<<0x5|_0x27c30b>>>0x1b)+_0xb59c0b+_0x5df608+_0x95db1a+_0x2a22dc[_0x286dff]&0xffffffff;_0x5df608=_0x3e40b2,_0x3e40b2=_0x4649e4,_0x4649e4=(_0x46268c<<0x1e|_0x46268c>>>0x2)&0xffffffff,_0x46268c=_0x27c30b,_0x27c30b=_0xa246d6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x27c30b&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x46268c&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4649e4&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3e40b2&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5df608&0xffffffff;}['update'](_0x5c3b30,_0x381bb1){if(_0x5c3b30==null)return;_0x381bb1===void 0x0&&(_0x381bb1=_0x5c3b30['length']);const _0x14f7e1=_0x381bb1-this['blockSize'];let _0x4cbabd=0x0;const _0x203ff0=this['buf_'];let _0x25f183=this['inbuf_'];for(;_0x4cbabd<_0x381bb1;){if(_0x25f183===0x0){for(;_0x4cbabd<=_0x14f7e1;)this['compress_'](_0x5c3b30,_0x4cbabd),_0x4cbabd+=this['blockSize'];}if(typeof _0x5c3b30=='string'){for(;_0x4cbabd<_0x381bb1;)if(_0x203ff0[_0x25f183]=_0x5c3b30['charCodeAt'](_0x4cbabd),++_0x25f183,++_0x4cbabd,_0x25f183===this['blockSize']){this['compress_'](_0x203ff0),_0x25f183=0x0;break;}}else{for(;_0x4cbabd<_0x381bb1;)if(_0x203ff0[_0x25f183]=_0x5c3b30[_0x4cbabd],++_0x25f183,++_0x4cbabd,_0x25f183===this['blockSize']){this['compress_'](_0x203ff0),_0x25f183=0x0;break;}}}this['inbuf_']=_0x25f183,this['total_']+=_0x381bb1;}['digest'](){const _0x44ad26=[];let _0x3415f7=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x41c44f=this['blockSize']-0x1;_0x41c44f>=0x38;_0x41c44f--)this['buf_'][_0x41c44f]=_0x3415f7&0xff,_0x3415f7/=0x100;this['compress_'](this['buf_']);let _0x1e1aef=0x0;for(let _0x63690a=0x0;_0x63690a<0x5;_0x63690a++)for(let _0x130e81=0x18;_0x130e81>=0x0;_0x130e81-=0x8)_0x44ad26[_0x1e1aef]=this['chain_'][_0x63690a]>>_0x130e81&0xff,++_0x1e1aef;return _0x44ad26;}}function Tc(_0x3c7cae,_0x504ebf){const _0x18f006=new Sc(_0x3c7cae,_0x504ebf);return _0x18f006['subscribe']['bind'](_0x18f006);}class Sc{constructor(_0x22a328,_0x3f6cc4){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3f6cc4,this['task']['then'](()=>{_0x22a328(this);})['catch'](_0x506efa=>{this['error'](_0x506efa);});}['next'](_0x54c2c1){this['forEachObserver'](_0x5ea48f=>{_0x5ea48f['next'](_0x54c2c1);});}['error'](_0x2307dd){this['forEachObserver'](_0x1759d9=>{_0x1759d9['error'](_0x2307dd);}),this['close'](_0x2307dd);}['complete'](){this['forEachObserver'](_0x4fc676=>{_0x4fc676['complete']();}),this['close']();}['subscribe'](_0x1ca1d0,_0x55045c,_0x1b2970){let _0x6cb92a;if(_0x1ca1d0===void 0x0&&_0x55045c===void 0x0&&_0x1b2970===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1ca1d0,['next','error','complete'])?_0x6cb92a=_0x1ca1d0:_0x6cb92a={'next':_0x1ca1d0,'error':_0x55045c,'complete':_0x1b2970},_0x6cb92a['next']===void 0x0&&(_0x6cb92a['next']=ti),_0x6cb92a['error']===void 0x0&&(_0x6cb92a['error']=ti),_0x6cb92a['complete']===void 0x0&&(_0x6cb92a['complete']=ti);const _0x4d254b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x6cb92a['error'](this['finalError']):_0x6cb92a['complete']();}catch{}}),this['observers']['push'](_0x6cb92a),_0x4d254b;}['unsubscribeOne'](_0x4d312d){this['observers']===void 0x0||this['observers'][_0x4d312d]===void 0x0||(delete this['observers'][_0x4d312d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xa9f799){if(!this['finalized']){for(let _0x522655=0x0;_0x522655<this['observers']['length'];_0x522655++)this['sendOne'](_0x522655,_0xa9f799);}}['sendOne'](_0x4dfe8d,_0x5dd093){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4dfe8d]!==void 0x0)try{_0x5dd093(this['observers'][_0x4dfe8d]);}catch(_0x804695){typeof console<'u'&&console['error']&&console['error'](_0x804695);}});}['close'](_0xbd20cc){this['finalized']||(this['finalized']=!0x0,_0xbd20cc!==void 0x0&&(this['finalError']=_0xbd20cc),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1125fd,_0x279e20){if(typeof _0x1125fd!='object'||_0x1125fd===null)return!0x1;for(const _0x3d0b54 of _0x279e20)if(_0x3d0b54 in _0x1125fd&&typeof _0x1125fd[_0x3d0b54]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x4e7157,_0x5be9ee){return _0x4e7157+'\x20failed:\x20'+_0x5be9ee+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x27dd9c){const _0x4078c1=[];let _0x38c2f5=0x0;for(let _0x236da3=0x0;_0x236da3<_0x27dd9c['length'];_0x236da3++){let _0x25ef8e=_0x27dd9c['charCodeAt'](_0x236da3);if(_0x25ef8e>=0xd800&&_0x25ef8e<=0xdbff){const _0x168490=_0x25ef8e-0xd800;_0x236da3++,f(_0x236da3<_0x27dd9c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1700eb=_0x27dd9c['charCodeAt'](_0x236da3)-0xdc00;_0x25ef8e=0x10000+(_0x168490<<0xa)+_0x1700eb;}_0x25ef8e<0x80?_0x4078c1[_0x38c2f5++]=_0x25ef8e:_0x25ef8e<0x800?(_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0x6|0xc0,_0x4078c1[_0x38c2f5++]=_0x25ef8e&0x3f|0x80):_0x25ef8e<0x10000?(_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0xc|0xe0,_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0x6&0x3f|0x80,_0x4078c1[_0x38c2f5++]=_0x25ef8e&0x3f|0x80):(_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0x12|0xf0,_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0xc&0x3f|0x80,_0x4078c1[_0x38c2f5++]=_0x25ef8e>>0x6&0x3f|0x80,_0x4078c1[_0x38c2f5++]=_0x25ef8e&0x3f|0x80);}return _0x4078c1;},Ln=function(_0x59759b){let _0x125aa4=0x0;for(let _0x1b6b11=0x0;_0x1b6b11<_0x59759b['length'];_0x1b6b11++){const _0x4076ab=_0x59759b['charCodeAt'](_0x1b6b11);_0x4076ab<0x80?_0x125aa4++:_0x4076ab<0x800?_0x125aa4+=0x2:_0x4076ab>=0xd800&&_0x4076ab<=0xdbff?(_0x125aa4+=0x4,_0x1b6b11++):_0x125aa4+=0x3;}return _0x125aa4;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x51866a){return _0x51866a&&_0x51866a['_delegate']?_0x51866a['_delegate']:_0x51866a;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x23402b){try{return(_0x23402b['startsWith']('http://')||_0x23402b['startsWith']('https://')?new URL(_0x23402b)['hostname']:_0x23402b)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x49bb08){return(await fetch(_0x49bb08,{'credentials':'include'}))['ok'];}class xe{constructor(_0x6f9f8c,_0x2998cc,_0x400a92){this['name']=_0x6f9f8c,this['instanceFactory']=_0x2998cc,this['type']=_0x400a92,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x56581b){return this['instantiationMode']=_0x56581b,this;}['setMultipleInstances'](_0x5c3f28){return this['multipleInstances']=_0x5c3f28,this;}['setServiceProps'](_0x33b708){return this['serviceProps']=_0x33b708,this;}['setInstanceCreatedCallback'](_0x7714ea){return this['onInstanceCreated']=_0x7714ea,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5c812f,_0x167094){this['name']=_0x5c812f,this['container']=_0x167094,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x379e5f){const _0x1a58b9=this['normalizeInstanceIdentifier'](_0x379e5f);if(!this['instancesDeferred']['has'](_0x1a58b9)){const _0x33886d=new H();if(this['instancesDeferred']['set'](_0x1a58b9,_0x33886d),this['isInitialized'](_0x1a58b9)||this['shouldAutoInitialize']())try{const _0x118f4f=this['getOrInitializeService']({'instanceIdentifier':_0x1a58b9});_0x118f4f&&_0x33886d['resolve'](_0x118f4f);}catch{}}return this['instancesDeferred']['get'](_0x1a58b9)['promise'];}['getImmediate'](_0x3f5cea){const _0x50fc2e=this['normalizeInstanceIdentifier'](_0x3f5cea==null?void 0x0:_0x3f5cea['identifier']),_0x265291=(_0x3f5cea==null?void 0x0:_0x3f5cea['optional'])??!0x1;if(this['isInitialized'](_0x50fc2e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x50fc2e});}catch(_0x401860){if(_0x265291)return null;throw _0x401860;}else{if(_0x265291)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1bd961){if(_0x1bd961['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1bd961['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1bd961,!!this['shouldAutoInitialize']()){if(Nc(_0x1bd961))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x202d76,_0x2348d8]of this['instancesDeferred']['entries']()){const _0x28d625=this['normalizeInstanceIdentifier'](_0x202d76);try{const _0x19856c=this['getOrInitializeService']({'instanceIdentifier':_0x28d625});_0x2348d8['resolve'](_0x19856c);}catch{}}}}['clearInstance'](_0x11bc01=Ne){this['instancesDeferred']['delete'](_0x11bc01),this['instancesOptions']['delete'](_0x11bc01),this['instances']['delete'](_0x11bc01);}async['delete'](){const _0x448496=Array['from'](this['instances']['values']());await Promise['all']([..._0x448496['filter'](_0x42e2c3=>'INTERNAL'in _0x42e2c3)['map'](_0x1c697f=>_0x1c697f['INTERNAL']['delete']()),..._0x448496['filter'](_0x46c9d6=>'_delete'in _0x46c9d6)['map'](_0x4504e4=>_0x4504e4['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xdcb89f=Ne){return this['instances']['has'](_0xdcb89f);}['getOptions'](_0x436951=Ne){return this['instancesOptions']['get'](_0x436951)||{};}['initialize'](_0x4f629a={}){const {options:_0x35c4e2={}}=_0x4f629a,_0x22f83d=this['normalizeInstanceIdentifier'](_0x4f629a['instanceIdentifier']);if(this['isInitialized'](_0x22f83d))throw Error(this['name']+'('+_0x22f83d+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2cfb15=this['getOrInitializeService']({'instanceIdentifier':_0x22f83d,'options':_0x35c4e2});for(const [_0x5f0742,_0x517e12]of this['instancesDeferred']['entries']()){const _0x274a10=this['normalizeInstanceIdentifier'](_0x5f0742);_0x22f83d===_0x274a10&&_0x517e12['resolve'](_0x2cfb15);}return _0x2cfb15;}['onInit'](_0x247968,_0x24182a){const _0x1d1e3c=this['normalizeInstanceIdentifier'](_0x24182a),_0x3bfc9e=this['onInitCallbacks']['get'](_0x1d1e3c)??new Set();_0x3bfc9e['add'](_0x247968),this['onInitCallbacks']['set'](_0x1d1e3c,_0x3bfc9e);const _0x5cbd32=this['instances']['get'](_0x1d1e3c);return _0x5cbd32&&_0x247968(_0x5cbd32,_0x1d1e3c),()=>{_0x3bfc9e['delete'](_0x247968);};}['invokeOnInitCallbacks'](_0x3cc405,_0x15a9b4){const _0x8fe18=this['onInitCallbacks']['get'](_0x15a9b4);if(_0x8fe18){for(const _0x2f83de of _0x8fe18)try{_0x2f83de(_0x3cc405,_0x15a9b4);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x749851,options:_0x211634={}}){let _0x57fa31=this['instances']['get'](_0x749851);if(!_0x57fa31&&this['component']&&(_0x57fa31=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x749851),'options':_0x211634}),this['instances']['set'](_0x749851,_0x57fa31),this['instancesOptions']['set'](_0x749851,_0x211634),this['invokeOnInitCallbacks'](_0x57fa31,_0x749851),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x749851,_0x57fa31);}catch{}return _0x57fa31||null;}['normalizeInstanceIdentifier'](_0x4970f8=Ne){return this['component']?this['component']['multipleInstances']?_0x4970f8:Ne:_0x4970f8;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0xc58e1d){return _0xc58e1d===Ne?void 0x0:_0xc58e1d;}function Nc(_0x7bad0e){return _0x7bad0e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x2439ae){this['name']=_0x2439ae,this['providers']=new Map();}['addComponent'](_0x737bb){const _0xa113dd=this['getProvider'](_0x737bb['name']);if(_0xa113dd['isComponentSet']())throw new Error('Component\x20'+_0x737bb['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xa113dd['setComponent'](_0x737bb);}['addOrOverwriteComponent'](_0x1c6bf1){this['getProvider'](_0x1c6bf1['name'])['isComponentSet']()&&this['providers']['delete'](_0x1c6bf1['name']),this['addComponent'](_0x1c6bf1);}['getProvider'](_0x10348a){if(this['providers']['has'](_0x10348a))return this['providers']['get'](_0x10348a);const _0xabc10e=new Ac(_0x10348a,this);return this['providers']['set'](_0x10348a,_0xabc10e),_0xabc10e;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3c0308){_0x3c0308[_0x3c0308['DEBUG']=0x0]='DEBUG',_0x3c0308[_0x3c0308['VERBOSE']=0x1]='VERBOSE',_0x3c0308[_0x3c0308['INFO']=0x2]='INFO',_0x3c0308[_0x3c0308['WARN']=0x3]='WARN',_0x3c0308[_0x3c0308['ERROR']=0x4]='ERROR',_0x3c0308[_0x3c0308['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x2a4ca2,_0x4c4ceb,..._0x398877)=>{if(_0x4c4ceb<_0x2a4ca2['logLevel'])return;const _0x2cfe0a=new Date()['toISOString'](),_0x4b9b72=Mc[_0x4c4ceb];if(_0x4b9b72)console[_0x4b9b72]('['+_0x2cfe0a+']\x20\x20'+_0x2a4ca2['name']+':',..._0x398877);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4c4ceb+')');};class Bi{constructor(_0xff0b85){this['name']=_0xff0b85,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x91af1){if(!(_0x91af1 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x91af1+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x91af1;}['setLogLevel'](_0x46331e){this['_logLevel']=typeof _0x46331e=='string'?Oc[_0x46331e]:_0x46331e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x20a0d3){if(typeof _0x20a0d3!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x20a0d3;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x260057){this['_userLogHandler']=_0x260057;}['debug'](..._0x112c16){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x112c16),this['_logHandler'](this,T['DEBUG'],..._0x112c16);}['log'](..._0x5b0edf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5b0edf),this['_logHandler'](this,T['VERBOSE'],..._0x5b0edf);}['info'](..._0xbcd015){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xbcd015),this['_logHandler'](this,T['INFO'],..._0xbcd015);}['warn'](..._0xcdaa7d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xcdaa7d),this['_logHandler'](this,T['WARN'],..._0xcdaa7d);}['error'](..._0x2e7dba){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2e7dba),this['_logHandler'](this,T['ERROR'],..._0x2e7dba);}}const xc=(_0x338581,_0x5ecd7c)=>_0x5ecd7c['some'](_0x684cf5=>_0x338581 instanceof _0x684cf5);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x1f2753){const _0x120f94=new Promise((_0x2b4e5b,_0x469061)=>{const _0x410e4f=()=>{_0x1f2753['removeEventListener']('success',_0x324862),_0x1f2753['removeEventListener']('error',_0x573814);},_0x324862=()=>{_0x2b4e5b(ge(_0x1f2753['result'])),_0x410e4f();},_0x573814=()=>{_0x469061(_0x1f2753['error']),_0x410e4f();};_0x1f2753['addEventListener']('success',_0x324862),_0x1f2753['addEventListener']('error',_0x573814);});return _0x120f94['then'](_0xd998ba=>{_0xd998ba instanceof IDBCursor&&Jr['set'](_0xd998ba,_0x1f2753);})['catch'](()=>{}),Vi['set'](_0x120f94,_0x1f2753),_0x120f94;}function Bc(_0x40f243){if(_i['has'](_0x40f243))return;const _0x1d64f7=new Promise((_0x28bee3,_0x15a3a4)=>{const _0x542895=()=>{_0x40f243['removeEventListener']('complete',_0x1a4384),_0x40f243['removeEventListener']('error',_0x198619),_0x40f243['removeEventListener']('abort',_0x198619);},_0x1a4384=()=>{_0x28bee3(),_0x542895();},_0x198619=()=>{_0x15a3a4(_0x40f243['error']||new DOMException('AbortError','AbortError')),_0x542895();};_0x40f243['addEventListener']('complete',_0x1a4384),_0x40f243['addEventListener']('error',_0x198619),_0x40f243['addEventListener']('abort',_0x198619);});_i['set'](_0x40f243,_0x1d64f7);}let gi={'get'(_0xad283a,_0x4f3181,_0x1f8452){if(_0xad283a instanceof IDBTransaction){if(_0x4f3181==='done')return _i['get'](_0xad283a);if(_0x4f3181==='objectStoreNames')return _0xad283a['objectStoreNames']||Xr['get'](_0xad283a);if(_0x4f3181==='store')return _0x1f8452['objectStoreNames'][0x1]?void 0x0:_0x1f8452['objectStore'](_0x1f8452['objectStoreNames'][0x0]);}return ge(_0xad283a[_0x4f3181]);},'set'(_0x339f17,_0x2aef57,_0x44f575){return _0x339f17[_0x2aef57]=_0x44f575,!0x0;},'has'(_0x1c971a,_0x4dcc25){return _0x1c971a instanceof IDBTransaction&&(_0x4dcc25==='done'||_0x4dcc25==='store')?!0x0:_0x4dcc25 in _0x1c971a;}};function Vc(_0x333adf){gi=_0x333adf(gi);}function Hc(_0x122eef){return _0x122eef===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x29ff65,..._0x1313e2){const _0x2ea0bc=_0x122eef['call'](ii(this),_0x29ff65,..._0x1313e2);return Xr['set'](_0x2ea0bc,_0x29ff65['sort']?_0x29ff65['sort']():[_0x29ff65]),ge(_0x2ea0bc);}:Uc()['includes'](_0x122eef)?function(..._0x4d463d){return _0x122eef['apply'](ii(this),_0x4d463d),ge(Jr['get'](this));}:function(..._0x596092){return ge(_0x122eef['apply'](ii(this),_0x596092));};}function $c(_0x59388a){return typeof _0x59388a=='function'?Hc(_0x59388a):(_0x59388a instanceof IDBTransaction&&Bc(_0x59388a),xc(_0x59388a,Fc())?new Proxy(_0x59388a,gi):_0x59388a);}function ge(_0x21530f){if(_0x21530f instanceof IDBRequest)return Wc(_0x21530f);if(ni['has'](_0x21530f))return ni['get'](_0x21530f);const _0x2c0adf=$c(_0x21530f);return _0x2c0adf!==_0x21530f&&(ni['set'](_0x21530f,_0x2c0adf),Vi['set'](_0x2c0adf,_0x21530f)),_0x2c0adf;}const ii=_0x1b3d38=>Vi['get'](_0x1b3d38);function Gc(_0x3bf532,_0x2b4171,{blocked:_0xaf66e7,upgrade:_0x102c2a,blocking:_0x470813,terminated:_0x2d316e}={}){const _0x48884c=indexedDB['open'](_0x3bf532,_0x2b4171),_0x7b6e13=ge(_0x48884c);return _0x102c2a&&_0x48884c['addEventListener']('upgradeneeded',_0x41e4de=>{_0x102c2a(ge(_0x48884c['result']),_0x41e4de['oldVersion'],_0x41e4de['newVersion'],ge(_0x48884c['transaction']),_0x41e4de);}),_0xaf66e7&&_0x48884c['addEventListener']('blocked',_0x5d484c=>_0xaf66e7(_0x5d484c['oldVersion'],_0x5d484c['newVersion'],_0x5d484c)),_0x7b6e13['then'](_0x9ab332=>{_0x2d316e&&_0x9ab332['addEventListener']('close',()=>_0x2d316e()),_0x470813&&_0x9ab332['addEventListener']('versionchange',_0x54504c=>_0x470813(_0x54504c['oldVersion'],_0x54504c['newVersion'],_0x54504c));})['catch'](()=>{}),_0x7b6e13;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x33aebe,_0x450773){if(!(_0x33aebe instanceof IDBDatabase&&!(_0x450773 in _0x33aebe)&&typeof _0x450773=='string'))return;if(si['get'](_0x450773))return si['get'](_0x450773);const _0x26e9d9=_0x450773['replace'](/FromIndex$/,''),_0x33a3f6=_0x450773!==_0x26e9d9,_0x198ef9=zc['includes'](_0x26e9d9);if(!(_0x26e9d9 in(_0x33a3f6?IDBIndex:IDBObjectStore)['prototype'])||!(_0x198ef9||qc['includes'](_0x26e9d9)))return;const _0x2f28fa=async function(_0x7ff5dc,..._0x36953e){const _0x405715=this['transaction'](_0x7ff5dc,_0x198ef9?'readwrite':'readonly');let _0x42e7f2=_0x405715['store'];return _0x33a3f6&&(_0x42e7f2=_0x42e7f2['index'](_0x36953e['shift']())),(await Promise['all']([_0x42e7f2[_0x26e9d9](..._0x36953e),_0x198ef9&&_0x405715['done']]))[0x0];};return si['set'](_0x450773,_0x2f28fa),_0x2f28fa;}Vc(_0xaf17bd=>({..._0xaf17bd,'get':(_0x1218b1,_0x37a81b,_0x46c443)=>Ms(_0x1218b1,_0x37a81b)||_0xaf17bd['get'](_0x1218b1,_0x37a81b,_0x46c443),'has':(_0x486636,_0x386546)=>!!Ms(_0x486636,_0x386546)||_0xaf17bd['has'](_0x486636,_0x386546)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4eac3d){this['container']=_0x4eac3d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x9db885=>{if(Kc(_0x9db885)){const _0x168f39=_0x9db885['getImmediate']();return _0x168f39['library']+'/'+_0x168f39['version'];}else return null;})['filter'](_0x4212a5=>_0x4212a5)['join']('\x20');}}function Kc(_0x50493a){const _0x57e051=_0x50493a['getComponent']();return(_0x57e051==null?void 0x0:_0x57e051['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Fe=new Map(),vi=new Map(),Ei=new Map();function xs(_0x1630d5,_0x1ca0e7){try{_0x1630d5['container']['addComponent'](_0x1ca0e7);}catch(_0x3bdd06){oe['debug']('Component\x20'+_0x1ca0e7['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1630d5['name'],_0x3bdd06);}}function st(_0x4a0def){const _0x27610e=_0x4a0def['name'];if(Ei['has'](_0x27610e))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x27610e+'.'),!0x1;Ei['set'](_0x27610e,_0x4a0def);for(const _0x1e100a of Fe['values']())xs(_0x1e100a,_0x4a0def);for(const _0x39580b of vi['values']())xs(_0x39580b,_0x4a0def);return!0x0;}function Hi(_0x1e72f8,_0x212603){const _0x217fe4=_0x1e72f8['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x217fe4&&_0x217fe4['triggerHeartbeat'](),_0x1e72f8['container']['getProvider'](_0x212603);}function $(_0x6807cd){return _0x6807cd==null?!0x1:_0x6807cd['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x580c0c,_0x137afd,_0x3d2c2a){this['_isDeleted']=!0x1,this['_options']={..._0x580c0c},this['_config']={..._0x137afd},this['_name']=_0x137afd['name'],this['_automaticDataCollectionEnabled']=_0x137afd['automaticDataCollectionEnabled'],this['_container']=_0x3d2c2a,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x122273){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x122273;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x385a0e){this['_isDeleted']=_0x385a0e;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x9f1dad,_0x102fc3={}){let _0x11bd4f=_0x9f1dad;typeof _0x102fc3!='object'&&(_0x102fc3={'name':_0x102fc3});const _0xed1734={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x102fc3},_0x107f82=_0xed1734['name'];if(typeof _0x107f82!='string'||!_0x107f82)throw me['create']('bad-app-name',{'appName':String(_0x107f82)});if(_0x11bd4f||(_0x11bd4f=zr()),!_0x11bd4f)throw me['create']('no-options');const _0xacdfb0=Fe['get'](_0x107f82);if(_0xacdfb0){if(Le(_0x11bd4f,_0xacdfb0['options'])&&Le(_0xed1734,_0xacdfb0['config']))return _0xacdfb0;throw me['create']('duplicate-app',{'appName':_0x107f82});}const _0x1b5cf3=new Pc(_0x107f82);for(const _0x3015af of Ei['values']())_0x1b5cf3['addComponent'](_0x3015af);const _0x1b61f1=new Tl(_0x11bd4f,_0xed1734,_0x1b5cf3);return Fe['set'](_0x107f82,_0x1b61f1),_0x1b61f1;}function Zr(_0x11648c=yi){const _0x4293f1=Fe['get'](_0x11648c);if(!_0x4293f1&&_0x11648c===yi&&zr())return Sl();if(!_0x4293f1)throw me['create']('no-app',{'appName':_0x11648c});return _0x4293f1;}function p_(){return Array['from'](Fe['values']());}async function __(_0x3adfae){let _0x395105=!0x1;const _0xbebbfe=_0x3adfae['name'];Fe['has'](_0xbebbfe)?(_0x395105=!0x0,Fe['delete'](_0xbebbfe)):vi['has'](_0xbebbfe)&&_0x3adfae['decRefCount']()<=0x0&&(vi['delete'](_0xbebbfe),_0x395105=!0x0),_0x395105&&(await Promise['all'](_0x3adfae['container']['getProviders']()['map'](_0x599451=>_0x599451['delete']())),_0x3adfae['isDeleted']=!0x0);}function ye(_0x428020,_0x381d2d,_0x536e37){let _0x5621d0=wl[_0x428020]??_0x428020;_0x536e37&&(_0x5621d0+='-'+_0x536e37);const _0x4edabc=_0x5621d0['match'](/\s|\//),_0x185216=_0x381d2d['match'](/\s|\//);if(_0x4edabc||_0x185216){const _0x51b854=['Unable\x20to\x20register\x20library\x20\x22'+_0x5621d0+'\x22\x20with\x20version\x20\x22'+_0x381d2d+'\x22:'];_0x4edabc&&_0x51b854['push']('library\x20name\x20\x22'+_0x5621d0+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4edabc&&_0x185216&&_0x51b854['push']('and'),_0x185216&&_0x51b854['push']('version\x20name\x20\x22'+_0x381d2d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x51b854['join']('\x20'));return;}st(new xe(_0x5621d0+'-version',()=>({'library':_0x5621d0,'version':_0x381d2d}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Pt='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x14c475,_0x4f792b)=>{switch(_0x4f792b){case 0x0:try{_0x14c475['createObjectStore'](Pt);}catch(_0x3fe2e7){console['warn'](_0x3fe2e7);}}}})['catch'](_0x40aa57=>{throw me['create']('idb-open',{'originalErrorMessage':_0x40aa57['message']});})),ri;}async function Al(_0x530be9){try{const _0x1e9fed=(await eo())['transaction'](Pt),_0x2be8ad=await _0x1e9fed['objectStore'](Pt)['get'](to(_0x530be9));return await _0x1e9fed['done'],_0x2be8ad;}catch(_0x4e7e8b){if(_0x4e7e8b instanceof Re)oe['warn'](_0x4e7e8b['message']);else{const _0x3c8ef5=me['create']('idb-get',{'originalErrorMessage':_0x4e7e8b==null?void 0x0:_0x4e7e8b['message']});oe['warn'](_0x3c8ef5['message']);}}}async function Fs(_0x4cb46a,_0x53ceb5){try{const _0x1c0239=(await eo())['transaction'](Pt,'readwrite');await _0x1c0239['objectStore'](Pt)['put'](_0x53ceb5,to(_0x4cb46a)),await _0x1c0239['done'];}catch(_0xad6838){if(_0xad6838 instanceof Re)oe['warn'](_0xad6838['message']);else{const _0x32eb16=me['create']('idb-set',{'originalErrorMessage':_0xad6838==null?void 0x0:_0xad6838['message']});oe['warn'](_0x32eb16['message']);}}}function to(_0x29e2e3){return _0x29e2e3['name']+'!'+_0x29e2e3['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x2a773b){this['container']=_0x2a773b,this['_heartbeatsCache']=null;const _0x2aec44=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2aec44),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1fa2a1=>(this['_heartbeatsCache']=_0x1fa2a1,_0x1fa2a1));}async['triggerHeartbeat'](){var _0x22edcf,_0x4b575c;try{const _0x32d8d4=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3c984c=Us();if(((_0x22edcf=this['_heartbeatsCache'])==null?void 0x0:_0x22edcf['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4b575c=this['_heartbeatsCache'])==null?void 0x0:_0x4b575c['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3c984c||this['_heartbeatsCache']['heartbeats']['some'](_0x39ded4=>_0x39ded4['date']===_0x3c984c))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3c984c,'agent':_0x32d8d4}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x39a028=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x39a028,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x11b0ee){oe['warn'](_0x11b0ee);}}async['getHeartbeatsHeader'](){var _0x715628;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x715628=this['_heartbeatsCache'])==null?void 0x0:_0x715628['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x16370c=Us(),{heartbeatsToSend:_0x4eb78f,unsentEntries:_0x4cbaf7}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3dab08=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4eb78f}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x16370c,_0x4cbaf7['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4cbaf7,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3dab08;}catch(_0x5f899f){return oe['warn'](_0x5f899f),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x4712c9,_0x270a86=kl){const _0x3aa7c6=[];let _0x6ecd33=_0x4712c9['slice']();for(const _0x3702fe of _0x4712c9){const _0x352476=_0x3aa7c6['find'](_0x3dba87=>_0x3dba87['agent']===_0x3702fe['agent']);if(_0x352476){if(_0x352476['dates']['push'](_0x3702fe['date']),Ws(_0x3aa7c6)>_0x270a86){_0x352476['dates']['pop']();break;}}else{if(_0x3aa7c6['push']({'agent':_0x3702fe['agent'],'dates':[_0x3702fe['date']]}),Ws(_0x3aa7c6)>_0x270a86){_0x3aa7c6['pop']();break;}}_0x6ecd33=_0x6ecd33['slice'](0x1);}return{'heartbeatsToSend':_0x3aa7c6,'unsentEntries':_0x6ecd33};}class Dl{constructor(_0x226fbf){this['app']=_0x226fbf,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4b9ab8=await Al(this['app']);return _0x4b9ab8!=null&&_0x4b9ab8['heartbeats']?_0x4b9ab8:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x511c2e){if(await this['_canUseIndexedDBPromise']){const _0x424e26=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x511c2e['lastSentHeartbeatDate']??_0x424e26['lastSentHeartbeatDate'],'heartbeats':_0x511c2e['heartbeats']});}else return;}async['add'](_0xf4e17){if(await this['_canUseIndexedDBPromise']){const _0xf08686=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xf4e17['lastSentHeartbeatDate']??_0xf08686['lastSentHeartbeatDate'],'heartbeats':[..._0xf08686['heartbeats'],..._0xf4e17['heartbeats']]});}else return;}}function Ws(_0x56c1f4){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x56c1f4}))['length'];}function Ml(_0xc48ccf){if(_0xc48ccf['length']===0x0)return-0x1;let _0x2ea652=0x0,_0x2d3f61=_0xc48ccf[0x0]['date'];for(let _0x27df03=0x1;_0x27df03<_0xc48ccf['length'];_0x27df03++)_0xc48ccf[_0x27df03]['date']<_0x2d3f61&&(_0x2d3f61=_0xc48ccf[_0x27df03]['date'],_0x2ea652=_0x27df03);return _0x2ea652;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x9a69ea){st(new xe('platform-logger',_0x4e67c6=>new jc(_0x4e67c6),'PRIVATE')),st(new xe('heartbeat',_0x982479=>new Pl(_0x982479),'PRIVATE')),ye(mi,Ls,_0x9a69ea),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5049c7){no=_0x5049c7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x37cb29){this['domStorage_']=_0x37cb29,this['prefix_']='firebase:';}['set'](_0x2e7160,_0x5d34eb){_0x5d34eb==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2e7160)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2e7160),O(_0x5d34eb));}['get'](_0x1e2873){const _0x7f344c=this['domStorage_']['getItem'](this['prefixedName_'](_0x1e2873));return _0x7f344c==null?null:Nt(_0x7f344c);}['remove'](_0x2e370f){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2e370f));}['prefixedName_'](_0x12e091){return this['prefix_']+_0x12e091;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4d0696,_0x37cd21){_0x37cd21==null?delete this['cache_'][_0x4d0696]:this['cache_'][_0x4d0696]=_0x37cd21;}['get'](_0x46ca79){return Q(this['cache_'],_0x46ca79)?this['cache_'][_0x46ca79]:null;}['remove'](_0x5220a9){delete this['cache_'][_0x5220a9];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x5e3e4d){try{if(typeof window<'u'&&typeof window[_0x5e3e4d]<'u'){const _0x276154=window[_0x5e3e4d];return _0x276154['setItem']('firebase:sentinel','cache'),_0x276154['removeItem']('firebase:sentinel'),new Wl(_0x276154);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x13294d=0x1;return function(){return _0x13294d++;};}()),ro=function(_0x2757f2){const _0x57601f=Rc(_0x2757f2),_0x24392e=new Cc();_0x24392e['update'](_0x57601f);const _0x45f0e9=_0x24392e['digest']();return Fi['encodeByteArray'](_0x45f0e9);},qt=function(..._0x1a09bc){let _0x2286a0='';for(let _0x1db1ed=0x0;_0x1db1ed<_0x1a09bc['length'];_0x1db1ed++){const _0x4ed7ee=_0x1a09bc[_0x1db1ed];Array['isArray'](_0x4ed7ee)||_0x4ed7ee&&typeof _0x4ed7ee=='object'&&typeof _0x4ed7ee['length']=='number'?_0x2286a0+=qt['apply'](null,_0x4ed7ee):typeof _0x4ed7ee=='object'?_0x2286a0+=O(_0x4ed7ee):_0x2286a0+=_0x4ed7ee,_0x2286a0+='\x20';}return _0x2286a0;};let Tt=null,$s=!0x0;const Hl=function(_0x3071ec,_0x3ae92d){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],Tt=Ze['log']['bind'](Ze);},L=function(..._0x505994){if($s===!0x0&&($s=!0x1,Tt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),Tt){const _0x59f76d=qt['apply'](null,_0x505994);Tt(_0x59f76d);}},zt=function(_0x530f70){return function(..._0x296ec1){L(_0x530f70,..._0x296ec1);};},Ii=function(..._0x4429c4){const _0x41e5d6='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x4429c4);Ze['error'](_0x41e5d6);},ae=function(..._0x5ca1e4){const _0x2853e6='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x5ca1e4);throw Ze['error'](_0x2853e6),new Error(_0x2853e6);},U=function(..._0x1a899b){const _0x202a0a='FIREBASE\x20WARNING:\x20'+qt(..._0x1a899b);Ze['warn'](_0x202a0a);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x471c70){return typeof _0x471c70=='number'&&(_0x471c70!==_0x471c70||_0x471c70===Number['POSITIVE_INFINITY']||_0x471c70===Number['NEGATIVE_INFINITY']);},Gl=function(_0xad746f){if(document['readyState']==='complete')_0xad746f();else{let _0x21ad6a=!0x1;const _0x16e4a3=function(){if(!document['body']){setTimeout(_0x16e4a3,Math['floor'](0xa));return;}_0x21ad6a||(_0x21ad6a=!0x0,_0xad746f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x16e4a3,!0x1),window['addEventListener']('load',_0x16e4a3,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x16e4a3();}),window['attachEvent']('onload',_0x16e4a3));}},Ue='[MIN_NAME]',we='[MAX_NAME]',Ge=function(_0x244a7e,_0xdc8e5b){if(_0x244a7e===_0xdc8e5b)return 0x0;if(_0x244a7e===Ue||_0xdc8e5b===we)return-0x1;if(_0xdc8e5b===Ue||_0x244a7e===we)return 0x1;{const _0x54b7d5=Gs(_0x244a7e),_0x2bd9f5=Gs(_0xdc8e5b);return _0x54b7d5!==null?_0x2bd9f5!==null?_0x54b7d5-_0x2bd9f5===0x0?_0x244a7e['length']-_0xdc8e5b['length']:_0x54b7d5-_0x2bd9f5:-0x1:_0x2bd9f5!==null?0x1:_0x244a7e<_0xdc8e5b?-0x1:0x1;}},ql=function(_0x5d5b8d,_0x94e107){return _0x5d5b8d===_0x94e107?0x0:_0x5d5b8d<_0x94e107?-0x1:0x1;},yt=function(_0x52e2f2,_0x377ade){if(_0x377ade&&_0x52e2f2 in _0x377ade)return _0x377ade[_0x52e2f2];throw new Error('Missing\x20required\x20key\x20('+_0x52e2f2+')\x20in\x20object:\x20'+O(_0x377ade));},$i=function(_0x26dd8e){if(typeof _0x26dd8e!='object'||_0x26dd8e===null)return O(_0x26dd8e);const _0x3855bc=[];for(const _0x15c5bd in _0x26dd8e)_0x3855bc['push'](_0x15c5bd);_0x3855bc['sort']();let _0x282296='{';for(let _0x8984de=0x0;_0x8984de<_0x3855bc['length'];_0x8984de++)_0x8984de!==0x0&&(_0x282296+=','),_0x282296+=O(_0x3855bc[_0x8984de]),_0x282296+=':',_0x282296+=$i(_0x26dd8e[_0x3855bc[_0x8984de]]);return _0x282296+='}',_0x282296;},oo=function(_0x19dedb,_0x241001){const _0x5db493=_0x19dedb['length'];if(_0x5db493<=_0x241001)return[_0x19dedb];const _0xd7d08b=[];for(let _0x2ba91b=0x0;_0x2ba91b<_0x5db493;_0x2ba91b+=_0x241001)_0x2ba91b+_0x241001>_0x5db493?_0xd7d08b['push'](_0x19dedb['substring'](_0x2ba91b,_0x5db493)):_0xd7d08b['push'](_0x19dedb['substring'](_0x2ba91b,_0x2ba91b+_0x241001));return _0xd7d08b;};function x(_0x40f507,_0x1e516c){for(const _0x3030ed in _0x40f507)_0x40f507['hasOwnProperty'](_0x3030ed)&&_0x1e516c(_0x3030ed,_0x40f507[_0x3030ed]);}const ao=function(_0x5082f6){f(!xn(_0x5082f6),'Invalid\x20JSON\x20number');const _0x3d1b73=0xb,_0x33af8f=0x34,_0x53eff3=(0x1<<_0x3d1b73-0x1)-0x1;let _0x177d5d,_0x2b4058,_0x4f0e73,_0x526236,_0x22a989;_0x5082f6===0x0?(_0x2b4058=0x0,_0x4f0e73=0x0,_0x177d5d=0x1/_0x5082f6===-0x1/0x0?0x1:0x0):(_0x177d5d=_0x5082f6<0x0,_0x5082f6=Math['abs'](_0x5082f6),_0x5082f6>=Math['pow'](0x2,0x1-_0x53eff3)?(_0x526236=Math['min'](Math['floor'](Math['log'](_0x5082f6)/Math['LN2']),_0x53eff3),_0x2b4058=_0x526236+_0x53eff3,_0x4f0e73=Math['round'](_0x5082f6*Math['pow'](0x2,_0x33af8f-_0x526236)-Math['pow'](0x2,_0x33af8f))):(_0x2b4058=0x0,_0x4f0e73=Math['round'](_0x5082f6/Math['pow'](0x2,0x1-_0x53eff3-_0x33af8f))));const _0x516339=[];for(_0x22a989=_0x33af8f;_0x22a989;_0x22a989-=0x1)_0x516339['push'](_0x4f0e73%0x2?0x1:0x0),_0x4f0e73=Math['floor'](_0x4f0e73/0x2);for(_0x22a989=_0x3d1b73;_0x22a989;_0x22a989-=0x1)_0x516339['push'](_0x2b4058%0x2?0x1:0x0),_0x2b4058=Math['floor'](_0x2b4058/0x2);_0x516339['push'](_0x177d5d?0x1:0x0),_0x516339['reverse']();const _0x1d3a57=_0x516339['join']('');let _0x5da934='';for(_0x22a989=0x0;_0x22a989<0x40;_0x22a989+=0x8){let _0x3ad32d=parseInt(_0x1d3a57['substr'](_0x22a989,0x8),0x2)['toString'](0x10);_0x3ad32d['length']===0x1&&(_0x3ad32d='0'+_0x3ad32d),_0x5da934=_0x5da934+_0x3ad32d;}return _0x5da934['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x311de9,_0x12f2f5){let _0x362af6='Unknown\x20Error';_0x311de9==='too_big'?_0x362af6='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x311de9==='permission_denied'?_0x362af6='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x311de9==='unavailable'&&(_0x362af6='The\x20service\x20is\x20unavailable');const _0xf6b77d=new Error(_0x311de9+'\x20at\x20'+_0x12f2f5['_path']['toString']()+':\x20'+_0x362af6);return _0xf6b77d['code']=_0x311de9['toUpperCase'](),_0xf6b77d;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x331722){if(Yl['test'](_0x331722)){const _0x582360=Number(_0x331722);if(_0x582360>=Ql&&_0x582360<=Jl)return _0x582360;}return null;},ft=function(_0x284c37){try{_0x284c37();}catch(_0x58af8d){setTimeout(()=>{const _0x5b4396=_0x58af8d['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5b4396),_0x58af8d;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x211e01,_0x28f171){const _0xc87a19=setTimeout(_0x211e01,_0x28f171);return typeof _0xc87a19=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xc87a19):typeof _0xc87a19=='object'&&_0xc87a19['unref']&&_0xc87a19['unref'](),_0xc87a19;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x35bac6,_0x6358cd){this['appCheckProvider']=_0x6358cd,this['appName']=_0x35bac6['name'],$(_0x35bac6)&&_0x35bac6['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x35bac6['settings']['appCheckToken']),this['appCheck']=_0x6358cd==null?void 0x0:_0x6358cd['getImmediate']({'optional':!0x0}),this['appCheck']||_0x6358cd==null||_0x6358cd['get']()['then'](_0x583f17=>this['appCheck']=_0x583f17);}['getToken'](_0x19de4a){if(this['serverAppAppCheckToken']){if(_0x19de4a)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x19de4a):new Promise((_0x543de1,_0x194ab1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x19de4a)['then'](_0x543de1,_0x194ab1):_0x543de1(null);},0x0);});}['addTokenChangeListener'](_0x4f8dd6){var _0x35f128;(_0x35f128=this['appCheckProvider'])==null||_0x35f128['get']()['then'](_0x43a918=>_0x43a918['addTokenListener'](_0x4f8dd6));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x57696f,_0x282e09,_0x5e7fcd){this['appName_']=_0x57696f,this['firebaseOptions_']=_0x282e09,this['authProvider_']=_0x5e7fcd,this['auth_']=null,this['auth_']=_0x5e7fcd['getImmediate']({'optional':!0x0}),this['auth_']||_0x5e7fcd['onInit'](_0x586bba=>this['auth_']=_0x586bba);}['getToken'](_0x36f127){return this['auth_']?this['auth_']['getToken'](_0x36f127)['catch'](_0x163851=>_0x163851&&_0x163851['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x163851)):new Promise((_0x41fb8a,_0x3089b8)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x36f127)['then'](_0x41fb8a,_0x3089b8):_0x41fb8a(null);},0x0);});}['addTokenChangeListener'](_0x2172e9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2172e9):this['authProvider_']['get']()['then'](_0x31c659=>_0x31c659['addAuthTokenListener'](_0x2172e9));}['removeTokenChangeListener'](_0x1e5dd5){this['authProvider_']['get']()['then'](_0x3bee4f=>_0x3bee4f['removeAuthTokenListener'](_0x1e5dd5));}['notifyForInvalidToken'](){let _0x3fea1a='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3fea1a+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3fea1a+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3fea1a+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3fea1a);}}class an{constructor(_0x2ae2aa){this['accessToken']=_0x2ae2aa;}['getToken'](_0x564f3a){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x667e10){_0x667e10(this['accessToken']);}['removeTokenChangeListener'](_0xc9eb32){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4342ae,_0x236e45,_0x1853b9,_0x1453d0,_0x229385=!0x1,_0x19bc76='',_0x15a025=!0x1,_0x275dda=!0x1,_0x58a79a=null){this['secure']=_0x236e45,this['namespace']=_0x1853b9,this['webSocketOnly']=_0x1453d0,this['nodeAdmin']=_0x229385,this['persistenceKey']=_0x19bc76,this['includeNamespaceInQueryParams']=_0x15a025,this['isUsingEmulator']=_0x275dda,this['emulatorOptions']=_0x58a79a,this['_host']=_0x4342ae['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x4342ae)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5bb098){_0x5bb098!==this['internalHost']&&(this['internalHost']=_0x5bb098,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x6891c9=this['toURLString']();return this['persistenceKey']&&(_0x6891c9+='<'+this['persistenceKey']+'>'),_0x6891c9;}['toURLString'](){const _0x4a897c=this['secure']?'https://':'http://',_0x2a4010=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4a897c+this['host']+'/'+_0x2a4010;}}function th(_0x21d6bc){return _0x21d6bc['host']!==_0x21d6bc['internalHost']||_0x21d6bc['isCustomHost']()||_0x21d6bc['includeNamespaceInQueryParams'];}function vo(_0x10b029,_0x398011,_0x488387){f(typeof _0x398011=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x488387=='object','typeof\x20params\x20must\x20==\x20object');let _0x57255d;if(_0x398011===go)_0x57255d=(_0x10b029['secure']?'wss://':'ws://')+_0x10b029['internalHost']+'/.ws?';else{if(_0x398011===mo)_0x57255d=(_0x10b029['secure']?'https://':'http://')+_0x10b029['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x398011);}th(_0x10b029)&&(_0x488387['ns']=_0x10b029['namespace']);const _0x1df567=[];return x(_0x488387,(_0x44cb78,_0x9b68ad)=>{_0x1df567['push'](_0x44cb78+'='+_0x9b68ad);}),_0x57255d+_0x1df567['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x8b79f8,_0xbd7622=0x1){Q(this['counters_'],_0x8b79f8)||(this['counters_'][_0x8b79f8]=0x0),this['counters_'][_0x8b79f8]+=_0xbd7622;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x47cfe1){const _0x7b7fbf=_0x47cfe1['toString']();return oi[_0x7b7fbf]||(oi[_0x7b7fbf]=new nh()),oi[_0x7b7fbf];}function ih(_0xc73577,_0x306778){const _0x29c90a=_0xc73577['toString']();return ai[_0x29c90a]||(ai[_0x29c90a]=_0x306778()),ai[_0x29c90a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3ab5c1){this['onMessage_']=_0x3ab5c1,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2ab08e,_0x530717){this['closeAfterResponse']=_0x2ab08e,this['onClose']=_0x530717,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x522e5f,_0x15fbe4){for(this['pendingResponses'][_0x522e5f]=_0x15fbe4;this['pendingResponses'][this['currentResponseNum']];){const _0x510f7a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x156330=0x0;_0x156330<_0x510f7a['length'];++_0x156330)_0x510f7a[_0x156330]&&ft(()=>{this['onMessage_'](_0x510f7a[_0x156330]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x5067f8,_0x65f2b9,_0x548c1f,_0xad8f95,_0x5bcf29,_0x3f2dad,_0x520756){this['connId']=_0x5067f8,this['repoInfo']=_0x65f2b9,this['applicationId']=_0x548c1f,this['appCheckToken']=_0xad8f95,this['authToken']=_0x5bcf29,this['transportSessionId']=_0x3f2dad,this['lastSessionId']=_0x520756,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x5067f8),this['stats_']=qi(_0x65f2b9),this['urlFn']=_0x1de499=>(this['appCheckToken']&&(_0x1de499[wi]=this['appCheckToken']),vo(_0x65f2b9,mo,_0x1de499));}['open'](_0x4a201a,_0x3e0474){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3e0474,this['myPacketOrderer']=new sh(_0x4a201a),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x3f56b6)=>{const [_0x517220,_0x18acc8,_0x518fc7,_0x367bc4,_0x53da0c]=_0x3f56b6;if(this['incrementIncomingBytes_'](_0x3f56b6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x517220===qs)this['id']=_0x18acc8,this['password']=_0x518fc7;else{if(_0x517220===rh)_0x18acc8?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x18acc8,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x517220);}}},(..._0x1fe251)=>{const [_0x13f3e6,_0x2b910b]=_0x1fe251;this['incrementIncomingBytes_'](_0x1fe251),this['myPacketOrderer']['handleResponse'](_0x13f3e6,_0x2b910b);},()=>{this['onClosed_']();},this['urlFn']);const _0x14bb16={};_0x14bb16[qs]='t',_0x14bb16[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x14bb16[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x14bb16[co]=Gi,this['transportSessionId']&&(_0x14bb16[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x14bb16[po]=this['lastSessionId']),this['applicationId']&&(_0x14bb16[_o]=this['applicationId']),this['appCheckToken']&&(_0x14bb16[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x14bb16[ho]=uo);const _0x57b661=this['urlFn'](_0x14bb16);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x57b661),this['scriptTagHolder']['addTag'](_0x57b661,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x961041){const _0x801358=O(_0x961041);this['bytesSent']+=_0x801358['length'],this['stats_']['incrementCounter']('bytes_sent',_0x801358['length']);const _0x46b42c=$r(_0x801358),_0x355d98=oo(_0x46b42c,fh);for(let _0x15af01=0x0;_0x15af01<_0x355d98['length'];_0x15af01++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x355d98['length'],_0x355d98[_0x15af01]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x295e4a,_0x20b830){this['myDisconnFrame']=document['createElement']('iframe');const _0x5e1020={};_0x5e1020[dh]='t',_0x5e1020[Eo]=_0x295e4a,_0x5e1020[Io]=_0x20b830,this['myDisconnFrame']['src']=this['urlFn'](_0x5e1020),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x53463c){const _0x2a7cc7=O(_0x53463c)['length'];this['bytesReceived']+=_0x2a7cc7,this['stats_']['incrementCounter']('bytes_received',_0x2a7cc7);}}class zi{constructor(_0xcb110a,_0x16ad67,_0x437431,_0x331b59){this['onDisconnect']=_0x437431,this['urlFn']=_0x331b59,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xcb110a,window[ah+this['uniqueCallbackIdentifier']]=_0x16ad67,this['myIFrame']=zi['createIFrame_']();let _0x58431d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x58431d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5a1cbf='<html><body>'+_0x58431d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5a1cbf),this['myIFrame']['doc']['close']();}catch(_0x2da986){L('frame\x20writing\x20exception'),_0x2da986['stack']&&L(_0x2da986['stack']),L(_0x2da986);}}}static['createIFrame_'](){const _0x204ac7=document['createElement']('iframe');if(_0x204ac7['style']['display']='none',document['body']){document['body']['appendChild'](_0x204ac7);try{_0x204ac7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x51ed0f=document['domain'];_0x204ac7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x51ed0f+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x204ac7['contentDocument']?_0x204ac7['doc']=_0x204ac7['contentDocument']:_0x204ac7['contentWindow']?_0x204ac7['doc']=_0x204ac7['contentWindow']['document']:_0x204ac7['document']&&(_0x204ac7['doc']=_0x204ac7['document']),_0x204ac7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3b7017=this['onDisconnect'];_0x3b7017&&(this['onDisconnect']=null,_0x3b7017());}['startLongPoll'](_0x468c3c,_0x44fa2c){for(this['myID']=_0x468c3c,this['myPW']=_0x44fa2c,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3d52a2={};_0x3d52a2[Eo]=this['myID'],_0x3d52a2[Io]=this['myPW'],_0x3d52a2[wo]=this['currentSerial'];let _0x2bd60a=this['urlFn'](_0x3d52a2),_0x320c32='',_0x41821e=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x320c32['length']<=Co;){const _0x2fbe96=this['pendingSegs']['shift']();_0x320c32=_0x320c32+'&'+lh+_0x41821e+'='+_0x2fbe96['seg']+'&'+hh+_0x41821e+'='+_0x2fbe96['ts']+'&'+uh+_0x41821e+'='+_0x2fbe96['d'],_0x41821e++;}return _0x2bd60a=_0x2bd60a+_0x320c32,this['addLongPollTag_'](_0x2bd60a,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xc237db,_0x57f0ef,_0x395220){this['pendingSegs']['push']({'seg':_0xc237db,'ts':_0x57f0ef,'d':_0x395220}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x394dd1,_0x2836e7){this['outstandingRequests']['add'](_0x2836e7);const _0x83230f=()=>{this['outstandingRequests']['delete'](_0x2836e7),this['newRequest_']();},_0x41ad96=setTimeout(_0x83230f,Math['floor'](ph)),_0x473a8b=()=>{clearTimeout(_0x41ad96),_0x83230f();};this['addTag'](_0x394dd1,_0x473a8b);}['addTag'](_0xf427f5,_0x26f971){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4a21c6=this['myIFrame']['doc']['createElement']('script');_0x4a21c6['type']='text/javascript',_0x4a21c6['async']=!0x0,_0x4a21c6['src']=_0xf427f5,_0x4a21c6['onload']=_0x4a21c6['onreadystatechange']=function(){const _0x2c83ba=_0x4a21c6['readyState'];(!_0x2c83ba||_0x2c83ba==='loaded'||_0x2c83ba==='complete')&&(_0x4a21c6['onload']=_0x4a21c6['onreadystatechange']=null,_0x4a21c6['parentNode']&&_0x4a21c6['parentNode']['removeChild'](_0x4a21c6),_0x26f971());},_0x4a21c6['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xf427f5),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4a21c6);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2b6d14,_0x115b2a,_0x1b9cd0,_0xe77e5a,_0x2974cd,_0x3b4753,_0x177e40){this['connId']=_0x2b6d14,this['applicationId']=_0x1b9cd0,this['appCheckToken']=_0xe77e5a,this['authToken']=_0x2974cd,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=qi(_0x115b2a),this['connURL']=q['connectionURL_'](_0x115b2a,_0x3b4753,_0x177e40,_0xe77e5a,_0x1b9cd0),this['nodeAdmin']=_0x115b2a['nodeAdmin'];}static['connectionURL_'](_0x1c4ba2,_0x455ae4,_0x43c080,_0x448909,_0x44f83d){const _0x19533b={};return _0x19533b[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x19533b[ho]=uo),_0x455ae4&&(_0x19533b[lo]=_0x455ae4),_0x43c080&&(_0x19533b[po]=_0x43c080),_0x448909&&(_0x19533b[wi]=_0x448909),_0x44f83d&&(_0x19533b[_o]=_0x44f83d),vo(_0x1c4ba2,go,_0x19533b);}['open'](_0x4c6c14,_0x17c9fe){this['onDisconnect']=_0x17c9fe,this['onMessage']=_0x4c6c14,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x41c8bf;_c(),this['mySock']=new gn(this['connURL'],[],_0x41c8bf);}catch(_0x2de685){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2696c2=_0x2de685['message']||_0x2de685['data'];_0x2696c2&&this['log_'](_0x2696c2),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x23b964=>{this['handleIncomingFrame'](_0x23b964);},this['mySock']['onerror']=_0x29d784=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x557f85=_0x29d784['message']||_0x29d784['data'];_0x557f85&&this['log_'](_0x557f85),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x16567e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x167f6b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x469120=navigator['userAgent']['match'](_0x167f6b);_0x469120&&_0x469120['length']>0x1&&parseFloat(_0x469120[0x1])<4.4&&(_0x16567e=!0x0);}return!_0x16567e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2afa82){if(this['frames']['push'](_0x2afa82),this['frames']['length']===this['totalFrames']){const _0x49c248=this['frames']['join']('');this['frames']=null;const _0x6e41c8=Nt(_0x49c248);this['onMessage'](_0x6e41c8);}}['handleNewFrameCount_'](_0x4de452){this['totalFrames']=_0x4de452,this['frames']=[];}['extractFrameCount_'](_0x339168){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x339168['length']<=0x6){const _0x508836=Number(_0x339168);if(!isNaN(_0x508836))return this['handleNewFrameCount_'](_0x508836),null;}return this['handleNewFrameCount_'](0x1),_0x339168;}['handleIncomingFrame'](_0x4d2a68){if(this['mySock']===null)return;const _0x13ab48=_0x4d2a68['data'];if(this['bytesReceived']+=_0x13ab48['length'],this['stats_']['incrementCounter']('bytes_received',_0x13ab48['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x13ab48);else{const _0x5f28b0=this['extractFrameCount_'](_0x13ab48);_0x5f28b0!==null&&this['appendFrame_'](_0x5f28b0);}}['send'](_0x2298b5){this['resetKeepAlive']();const _0x5556c0=O(_0x2298b5);this['bytesSent']+=_0x5556c0['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5556c0['length']);const _0x36a558=oo(_0x5556c0,gh);_0x36a558['length']>0x1&&this['sendString_'](String(_0x36a558['length']));for(let _0xaacdc=0x0;_0xaacdc<_0x36a558['length'];_0xaacdc++)this['sendString_'](_0x36a558[_0xaacdc]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x102ece){try{this['mySock']['send'](_0x102ece);}catch(_0x13dfac){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x13dfac['message']||_0x13dfac['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5730f5){this['initTransports_'](_0x5730f5);}['initTransports_'](_0x3f3f28){const _0x3d8704=q&&q['isAvailable']();let _0x584eb4=_0x3d8704&&!q['previouslyFailed']();if(_0x3f3f28['webSocketOnly']&&(_0x3d8704||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x584eb4=!0x0),_0x584eb4)this['transports_']=[q];else{const _0x3a3018=this['transports_']=[];for(const _0x162cb2 of Ot['ALL_TRANSPORTS'])_0x162cb2&&_0x162cb2['isAvailable']()&&_0x3a3018['push'](_0x162cb2);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x14a4c5,_0x537e71,_0x1a7af1,_0x44afbd,_0x27c6b3,_0x1e9749,_0x5afad6,_0x16fa4a,_0x199a69,_0x149765){this['id']=_0x14a4c5,this['repoInfo_']=_0x537e71,this['applicationId_']=_0x1a7af1,this['appCheckToken_']=_0x44afbd,this['authToken_']=_0x27c6b3,this['onMessage_']=_0x1e9749,this['onReady_']=_0x5afad6,this['onDisconnect_']=_0x16fa4a,this['onKill_']=_0x199a69,this['lastSessionId']=_0x149765,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x537e71),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x503f04=this['transportManager_']['initialTransport']();this['conn_']=new _0x503f04(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x503f04['responsesRequiredToBeHealthy']||0x0;const _0x27addf=this['connReceiver_'](this['conn_']),_0x5035f7=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x27addf,_0x5035f7);},Math['floor'](0x0));const _0x14c090=_0x503f04['healthyTimeout']||0x0;_0x14c090>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x14c090)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x23f00d){return _0x6b1c2d=>{_0x23f00d===this['conn_']?this['onConnectionLost_'](_0x6b1c2d):_0x23f00d===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3cc756){return _0x9e074=>{this['state_']!==0x2&&(_0x3cc756===this['rx_']?this['onPrimaryMessageReceived_'](_0x9e074):_0x3cc756===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x9e074):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x6c96e1){const _0x79d5e9={'t':'d','d':_0x6c96e1};this['sendData_'](_0x79d5e9);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x504835){if(ci in _0x504835){const _0x27a454=_0x504835[ci];_0x27a454===Ys?this['upgradeIfSecondaryHealthy_']():_0x27a454===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x27a454===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3319da){const _0x5809f8=yt('t',_0x3319da),_0x44ae19=yt('d',_0x3319da);if(_0x5809f8==='c')this['onSecondaryControl_'](_0x44ae19);else{if(_0x5809f8==='d')this['pendingDataMessages']['push'](_0x44ae19);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5809f8);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4b4130){const _0x1abd64=yt('t',_0x4b4130),_0x2a7a1a=yt('d',_0x4b4130);_0x1abd64==='c'?this['onControl_'](_0x2a7a1a):_0x1abd64==='d'&&this['onDataMessage_'](_0x2a7a1a);}['onDataMessage_'](_0x1b2896){this['onPrimaryResponse_'](),this['onMessage_'](_0x1b2896);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x9f04e2){const _0x3e2937=yt(ci,_0x9f04e2);if(zs in _0x9f04e2){const _0xe141dd=_0x9f04e2[zs];if(_0x3e2937===Th){const _0x5049d7={..._0xe141dd};this['repoInfo_']['isUsingEmulator']&&(_0x5049d7['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5049d7);}else{if(_0x3e2937===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x9c667b=0x0;_0x9c667b<this['pendingDataMessages']['length'];++_0x9c667b)this['onDataMessage_'](this['pendingDataMessages'][_0x9c667b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3e2937===wh?this['onConnectionShutdown_'](_0xe141dd):_0x3e2937===js?this['onReset_'](_0xe141dd):_0x3e2937===Ch?Ii('Server\x20Error:\x20'+_0xe141dd):_0x3e2937===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x3e2937);}}}['onHandshake_'](_0x1ea412){const _0x2fa351=_0x1ea412['ts'],_0x43c81b=_0x1ea412['v'],_0x52ca22=_0x1ea412['h'];this['sessionId']=_0x1ea412['s'],this['repoInfo_']['host']=_0x52ca22,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2fa351),Gi!==_0x43c81b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5abc35=this['transportManager_']['upgradeTransport']();_0x5abc35&&this['startUpgrade_'](_0x5abc35);}['startUpgrade_'](_0x149e5e){this['secondaryConn_']=new _0x149e5e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x149e5e['responsesRequiredToBeHealthy']||0x0;const _0x141ee3=this['connReceiver_'](this['secondaryConn_']),_0x460ffc=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x141ee3,_0x460ffc),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x188c55){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x188c55),this['repoInfo_']['host']=_0x188c55,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5788a1,_0x545bb4){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5788a1,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x545bb4,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x152823=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x152823||this['rx_']===_0x152823)&&this['close']();}['onConnectionLost_'](_0x4cd8ec){this['conn_']=null,!_0x4cd8ec&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3fa9ca){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3fa9ca),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5224fe){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5224fe);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x422506,_0x5c78b2,_0x24472e,_0x2df5ad){}['merge'](_0x3c1cbb,_0x51ff48,_0xca0007,_0xfbcf15){}['refreshAuthToken'](_0x3c921b){}['refreshAppCheckToken'](_0xcb7a75){}['onDisconnectPut'](_0x2dfa18,_0x280a9f,_0x4a13d4){}['onDisconnectMerge'](_0x40b91a,_0x106697,_0x156871){}['onDisconnectCancel'](_0x3329ad,_0x307f82){}['reportStats'](_0x2d575d){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xf25be4){this['allowedEvents_']=_0xf25be4,this['listeners_']={},f(Array['isArray'](_0xf25be4)&&_0xf25be4['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x332ddd,..._0x486873){if(Array['isArray'](this['listeners_'][_0x332ddd])){const _0x5656c9=[...this['listeners_'][_0x332ddd]];for(let _0x69b636=0x0;_0x69b636<_0x5656c9['length'];_0x69b636++)_0x5656c9[_0x69b636]['callback']['apply'](_0x5656c9[_0x69b636]['context'],_0x486873);}}['on'](_0x530a62,_0x20d86f,_0x302dc5){this['validateEventType_'](_0x530a62),this['listeners_'][_0x530a62]=this['listeners_'][_0x530a62]||[],this['listeners_'][_0x530a62]['push']({'callback':_0x20d86f,'context':_0x302dc5});const _0x36ba0a=this['getInitialEvent'](_0x530a62);_0x36ba0a&&_0x20d86f['apply'](_0x302dc5,_0x36ba0a);}['off'](_0x5c13fc,_0x4b0e52,_0x195df3){this['validateEventType_'](_0x5c13fc);const _0x22a900=this['listeners_'][_0x5c13fc]||[];for(let _0x306474=0x0;_0x306474<_0x22a900['length'];_0x306474++)if(_0x22a900[_0x306474]['callback']===_0x4b0e52&&(!_0x195df3||_0x195df3===_0x22a900[_0x306474]['context'])){_0x22a900['splice'](_0x306474,0x1);return;}}['validateEventType_'](_0x580257){f(this['allowedEvents_']['find'](_0x10c8bf=>_0x10c8bf===_0x580257),'Unknown\x20event:\x20'+_0x580257);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xf47765){return f(_0xf47765==='online','Unknown\x20event\x20type:\x20'+_0xf47765),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x43198d,_0x137649){if(_0x137649===void 0x0){this['pieces_']=_0x43198d['split']('/');let _0x4d9caa=0x0;for(let _0x2496da=0x0;_0x2496da<this['pieces_']['length'];_0x2496da++)this['pieces_'][_0x2496da]['length']>0x0&&(this['pieces_'][_0x4d9caa]=this['pieces_'][_0x2496da],_0x4d9caa++);this['pieces_']['length']=_0x4d9caa,this['pieceNum_']=0x0;}else this['pieces_']=_0x43198d,this['pieceNum_']=_0x137649;}['toString'](){let _0x47411f='';for(let _0x126a1d=this['pieceNum_'];_0x126a1d<this['pieces_']['length'];_0x126a1d++)this['pieces_'][_0x126a1d]!==''&&(_0x47411f+='/'+this['pieces_'][_0x126a1d]);return _0x47411f||'/';}}function w(){return new C('');}function y(_0x299b9d){return _0x299b9d['pieceNum_']>=_0x299b9d['pieces_']['length']?null:_0x299b9d['pieces_'][_0x299b9d['pieceNum_']];}function Ce(_0xa82f77){return _0xa82f77['pieces_']['length']-_0xa82f77['pieceNum_'];}function S(_0x536d22){let _0x39d0f4=_0x536d22['pieceNum_'];return _0x39d0f4<_0x536d22['pieces_']['length']&&_0x39d0f4++,new C(_0x536d22['pieces_'],_0x39d0f4);}function ji(_0x596617){return _0x596617['pieceNum_']<_0x596617['pieces_']['length']?_0x596617['pieces_'][_0x596617['pieces_']['length']-0x1]:null;}function bh(_0x109d64){let _0x41fcfc='';for(let _0x259d24=_0x109d64['pieceNum_'];_0x259d24<_0x109d64['pieces_']['length'];_0x259d24++)_0x109d64['pieces_'][_0x259d24]!==''&&(_0x41fcfc+='/'+encodeURIComponent(String(_0x109d64['pieces_'][_0x259d24])));return _0x41fcfc||'/';}function Dt(_0x3bddea,_0x5b5319=0x0){return _0x3bddea['pieces_']['slice'](_0x3bddea['pieceNum_']+_0x5b5319);}function Ro(_0x298a36){if(_0x298a36['pieceNum_']>=_0x298a36['pieces_']['length'])return null;const _0x194c28=[];for(let _0x353cc9=_0x298a36['pieceNum_'];_0x353cc9<_0x298a36['pieces_']['length']-0x1;_0x353cc9++)_0x194c28['push'](_0x298a36['pieces_'][_0x353cc9]);return new C(_0x194c28,0x0);}function k(_0x3b49fd,_0x4c9ee5){const _0x252282=[];for(let _0x541787=_0x3b49fd['pieceNum_'];_0x541787<_0x3b49fd['pieces_']['length'];_0x541787++)_0x252282['push'](_0x3b49fd['pieces_'][_0x541787]);if(_0x4c9ee5 instanceof C){for(let _0x4fe17b=_0x4c9ee5['pieceNum_'];_0x4fe17b<_0x4c9ee5['pieces_']['length'];_0x4fe17b++)_0x252282['push'](_0x4c9ee5['pieces_'][_0x4fe17b]);}else{const _0x39f1e8=_0x4c9ee5['split']('/');for(let _0x185150=0x0;_0x185150<_0x39f1e8['length'];_0x185150++)_0x39f1e8[_0x185150]['length']>0x0&&_0x252282['push'](_0x39f1e8[_0x185150]);}return new C(_0x252282,0x0);}function v(_0x59a1fe){return _0x59a1fe['pieceNum_']>=_0x59a1fe['pieces_']['length'];}function F(_0x414e5a,_0x5092be){const _0x2f2fa4=y(_0x414e5a),_0x1abbb1=y(_0x5092be);if(_0x2f2fa4===null)return _0x5092be;if(_0x2f2fa4===_0x1abbb1)return F(S(_0x414e5a),S(_0x5092be));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5092be+')\x20is\x20not\x20within\x20outerPath\x20('+_0x414e5a+')');}function Rh(_0x28d159,_0x53acbe){const _0x463bac=Dt(_0x28d159,0x0),_0x2834d3=Dt(_0x53acbe,0x0);for(let _0xeb16e=0x0;_0xeb16e<_0x463bac['length']&&_0xeb16e<_0x2834d3['length'];_0xeb16e++){const _0x53e3e4=Ge(_0x463bac[_0xeb16e],_0x2834d3[_0xeb16e]);if(_0x53e3e4!==0x0)return _0x53e3e4;}return _0x463bac['length']===_0x2834d3['length']?0x0:_0x463bac['length']<_0x2834d3['length']?-0x1:0x1;}function Ki(_0x2c36d2,_0x3ba3e6){if(Ce(_0x2c36d2)!==Ce(_0x3ba3e6))return!0x1;for(let _0x58a109=_0x2c36d2['pieceNum_'],_0x3ac30e=_0x3ba3e6['pieceNum_'];_0x58a109<=_0x2c36d2['pieces_']['length'];_0x58a109++,_0x3ac30e++)if(_0x2c36d2['pieces_'][_0x58a109]!==_0x3ba3e6['pieces_'][_0x3ac30e])return!0x1;return!0x0;}function G(_0x433a63,_0xbc2e08){let _0x216771=_0x433a63['pieceNum_'],_0x2552d4=_0xbc2e08['pieceNum_'];if(Ce(_0x433a63)>Ce(_0xbc2e08))return!0x1;for(;_0x216771<_0x433a63['pieces_']['length'];){if(_0x433a63['pieces_'][_0x216771]!==_0xbc2e08['pieces_'][_0x2552d4])return!0x1;++_0x216771,++_0x2552d4;}return!0x0;}class Ah{constructor(_0x598bac,_0x107417){this['errorPrefix_']=_0x107417,this['parts_']=Dt(_0x598bac,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5b2c33=0x0;_0x5b2c33<this['parts_']['length'];_0x5b2c33++)this['byteLength_']+=Ln(this['parts_'][_0x5b2c33]);Ao(this);}}function kh(_0x78a33f,_0x3b12e0){_0x78a33f['parts_']['length']>0x0&&(_0x78a33f['byteLength_']+=0x1),_0x78a33f['parts_']['push'](_0x3b12e0),_0x78a33f['byteLength_']+=Ln(_0x3b12e0),Ao(_0x78a33f);}function Nh(_0x254212){const _0x225c1e=_0x254212['parts_']['pop']();_0x254212['byteLength_']-=Ln(_0x225c1e),_0x254212['parts_']['length']>0x0&&(_0x254212['byteLength_']-=0x1);}function Ao(_0x1de710){if(_0x1de710['byteLength_']>Zs)throw new Error(_0x1de710['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1de710['byteLength_']+').');if(_0x1de710['parts_']['length']>Xs)throw new Error(_0x1de710['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x1de710));}function Pe(_0x1170fd){return _0x1170fd['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1170fd['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x190162,_0xfeeca9;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xfeeca9='visibilitychange',_0x190162='hidden'):typeof document['mozHidden']<'u'?(_0xfeeca9='mozvisibilitychange',_0x190162='mozHidden'):typeof document['msHidden']<'u'?(_0xfeeca9='msvisibilitychange',_0x190162='msHidden'):typeof document['webkitHidden']<'u'&&(_0xfeeca9='webkitvisibilitychange',_0x190162='webkitHidden')),this['visible_']=!0x0,_0xfeeca9&&document['addEventListener'](_0xfeeca9,()=>{const _0x204206=!document[_0x190162];_0x204206!==this['visible_']&&(this['visible_']=_0x204206,this['trigger']('visible',_0x204206));},!0x1);}['getInitialEvent'](_0x5ef3fc){return f(_0x5ef3fc==='visible','Unknown\x20event\x20type:\x20'+_0x5ef3fc),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Ph=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2cdcb2,_0x3482c9,_0x3e5ec3,_0x400bf5,_0x3e61f1,_0x10b843,_0x5d1d8c,_0x46fc40){if(super(),this['repoInfo_']=_0x2cdcb2,this['applicationId_']=_0x3482c9,this['onDataUpdate_']=_0x3e5ec3,this['onConnectStatus_']=_0x400bf5,this['onServerInfoUpdate_']=_0x3e61f1,this['authTokenProvider_']=_0x10b843,this['appCheckTokenProvider_']=_0x5d1d8c,this['authOverride_']=_0x46fc40,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x46fc40)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2cdcb2['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x245aa2,_0x59aa29,_0x21f855){const _0xb9d079=++this['requestNumber_'],_0x328bcf={'r':_0xb9d079,'a':_0x245aa2,'b':_0x59aa29};this['log_'](O(_0x328bcf)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x328bcf),_0x21f855&&(this['requestCBHash_'][_0xb9d079]=_0x21f855);}['get'](_0x15a94b){this['initConnection_']();const _0x145cd1=new H(),_0x208b1f={'action':'g','request':{'p':_0x15a94b['_path']['toString'](),'q':_0x15a94b['_queryObject']},'onComplete':_0x22251b=>{const _0x809a07=_0x22251b['d'];_0x22251b['s']==='ok'?_0x145cd1['resolve'](_0x809a07):_0x145cd1['reject'](_0x809a07);}};this['outstandingGets_']['push'](_0x208b1f),this['outstandingGetCount_']++;const _0x180f8a=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x180f8a),_0x145cd1['promise'];}['listen'](_0x4c003c,_0x4bed74,_0x134734,_0x1239cd){this['initConnection_']();const _0x1497b6=_0x4c003c['_queryIdentifier'],_0x2ba9d6=_0x4c003c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2ba9d6+'\x20'+_0x1497b6),this['listens']['has'](_0x2ba9d6)||this['listens']['set'](_0x2ba9d6,new Map()),f(_0x4c003c['_queryParams']['isDefault']()||!_0x4c003c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2ba9d6)['has'](_0x1497b6),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x53d588={'onComplete':_0x1239cd,'hashFn':_0x4bed74,'query':_0x4c003c,'tag':_0x134734};this['listens']['get'](_0x2ba9d6)['set'](_0x1497b6,_0x53d588),this['connected_']&&this['sendListen_'](_0x53d588);}['sendGet_'](_0x397456){const _0x15018c=this['outstandingGets_'][_0x397456];this['sendRequest']('g',_0x15018c['request'],_0x1402f5=>{delete this['outstandingGets_'][_0x397456],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x15018c['onComplete']&&_0x15018c['onComplete'](_0x1402f5);});}['sendListen_'](_0x5dd2bb){const _0x822bcd=_0x5dd2bb['query'],_0x1b98f0=_0x822bcd['_path']['toString'](),_0x583d9c=_0x822bcd['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1b98f0+'\x20for\x20'+_0x583d9c);const _0x43bb42={'p':_0x1b98f0},_0x3ace7c='q';_0x5dd2bb['tag']&&(_0x43bb42['q']=_0x822bcd['_queryObject'],_0x43bb42['t']=_0x5dd2bb['tag']),_0x43bb42['h']=_0x5dd2bb['hashFn'](),this['sendRequest'](_0x3ace7c,_0x43bb42,_0x2c25f8=>{const _0x19dc25=_0x2c25f8['d'],_0x13d768=_0x2c25f8['s'];se['warnOnListenWarnings_'](_0x19dc25,_0x822bcd),(this['listens']['get'](_0x1b98f0)&&this['listens']['get'](_0x1b98f0)['get'](_0x583d9c))===_0x5dd2bb&&(this['log_']('listen\x20response',_0x2c25f8),_0x13d768!=='ok'&&this['removeListen_'](_0x1b98f0,_0x583d9c),_0x5dd2bb['onComplete']&&_0x5dd2bb['onComplete'](_0x13d768,_0x19dc25));});}static['warnOnListenWarnings_'](_0x383d3e,_0x49cc28){if(_0x383d3e&&typeof _0x383d3e=='object'&&Q(_0x383d3e,'w')){const _0x5bf83e=Me(_0x383d3e,'w');if(Array['isArray'](_0x5bf83e)&&~_0x5bf83e['indexOf']('no_index')){const _0x256cda='\x22.indexOn\x22:\x20\x22'+_0x49cc28['_queryParams']['getIndex']()['toString']()+'\x22',_0xdc0ec1=_0x49cc28['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x256cda+'\x20at\x20'+_0xdc0ec1+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x17d9fb){this['authToken_']=_0x17d9fb,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x17d9fb);}['reduceReconnectDelayIfAdminCredential_'](_0x4ed410){(_0x4ed410&&_0x4ed410['length']===0x28||wc(_0x4ed410))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x6ec88){this['appCheckToken_']=_0x6ec88,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5a9316=this['authToken_'],_0x253570=Ic(_0x5a9316)?'auth':'gauth',_0x4c42ea={'cred':_0x5a9316};this['authOverride_']===null?_0x4c42ea['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4c42ea['authvar']=this['authOverride_']),this['sendRequest'](_0x253570,_0x4c42ea,_0x5da466=>{const _0x9224e9=_0x5da466['s'],_0x2934bb=_0x5da466['d']||'error';this['authToken_']===_0x5a9316&&(_0x9224e9==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x9224e9,_0x2934bb));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3c5ab5=>{const _0xa789ad=_0x3c5ab5['s'],_0x1a29c9=_0x3c5ab5['d']||'error';_0xa789ad==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xa789ad,_0x1a29c9);});}['unlisten'](_0x215b9b,_0x422f76){const _0x5b9dd1=_0x215b9b['_path']['toString'](),_0x1e26c8=_0x215b9b['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5b9dd1+'\x20'+_0x1e26c8),f(_0x215b9b['_queryParams']['isDefault']()||!_0x215b9b['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5b9dd1,_0x1e26c8)&&this['connected_']&&this['sendUnlisten_'](_0x5b9dd1,_0x1e26c8,_0x215b9b['_queryObject'],_0x422f76);}['sendUnlisten_'](_0x3ff4aa,_0xb91bfc,_0x1309ae,_0x51a79d){this['log_']('Unlisten\x20on\x20'+_0x3ff4aa+'\x20for\x20'+_0xb91bfc);const _0x437c14={'p':_0x3ff4aa},_0x37fc33='n';_0x51a79d&&(_0x437c14['q']=_0x1309ae,_0x437c14['t']=_0x51a79d),this['sendRequest'](_0x37fc33,_0x437c14);}['onDisconnectPut'](_0x466bfd,_0x33e9f4,_0x51bbb5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x466bfd,_0x33e9f4,_0x51bbb5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x466bfd,'action':'o','data':_0x33e9f4,'onComplete':_0x51bbb5});}['onDisconnectMerge'](_0x49e336,_0x13c6ab,_0x1e7909){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x49e336,_0x13c6ab,_0x1e7909):this['onDisconnectRequestQueue_']['push']({'pathString':_0x49e336,'action':'om','data':_0x13c6ab,'onComplete':_0x1e7909});}['onDisconnectCancel'](_0x103b59,_0x1852e5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x103b59,null,_0x1852e5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x103b59,'action':'oc','data':null,'onComplete':_0x1852e5});}['sendOnDisconnect_'](_0x508028,_0x1a2001,_0x34dacd,_0x185c14){const _0x387bd1={'p':_0x1a2001,'d':_0x34dacd};this['log_']('onDisconnect\x20'+_0x508028,_0x387bd1),this['sendRequest'](_0x508028,_0x387bd1,_0x592b60=>{_0x185c14&&setTimeout(()=>{_0x185c14(_0x592b60['s'],_0x592b60['d']);},Math['floor'](0x0));});}['put'](_0x4565a2,_0x2460ef,_0x57b5b4,_0x5a9df0){this['putInternal']('p',_0x4565a2,_0x2460ef,_0x57b5b4,_0x5a9df0);}['merge'](_0xfda2a3,_0x394ec1,_0x3a1392,_0x5e28f8){this['putInternal']('m',_0xfda2a3,_0x394ec1,_0x3a1392,_0x5e28f8);}['putInternal'](_0x5c0636,_0x137c47,_0x27e160,_0x3c5b27,_0xf9d5ed){this['initConnection_']();const _0x50e8f5={'p':_0x137c47,'d':_0x27e160};_0xf9d5ed!==void 0x0&&(_0x50e8f5['h']=_0xf9d5ed),this['outstandingPuts_']['push']({'action':_0x5c0636,'request':_0x50e8f5,'onComplete':_0x3c5b27}),this['outstandingPutCount_']++;const _0x5da401=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5da401):this['log_']('Buffering\x20put:\x20'+_0x137c47);}['sendPut_'](_0x2a98c2){const _0x1196f4=this['outstandingPuts_'][_0x2a98c2]['action'],_0x74ff01=this['outstandingPuts_'][_0x2a98c2]['request'],_0x1b84cc=this['outstandingPuts_'][_0x2a98c2]['onComplete'];this['outstandingPuts_'][_0x2a98c2]['queued']=this['connected_'],this['sendRequest'](_0x1196f4,_0x74ff01,_0x184066=>{this['log_'](_0x1196f4+'\x20response',_0x184066),delete this['outstandingPuts_'][_0x2a98c2],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1b84cc&&_0x1b84cc(_0x184066['s'],_0x184066['d']);});}['reportStats'](_0x3923ed){if(this['connected_']){const _0x2520be={'c':_0x3923ed};this['log_']('reportStats',_0x2520be),this['sendRequest']('s',_0x2520be,_0x490ee4=>{if(_0x490ee4['s']!=='ok'){const _0x14e005=_0x490ee4['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x14e005);}});}}['onDataMessage_'](_0x43c0e8){if('r'in _0x43c0e8){this['log_']('from\x20server:\x20'+O(_0x43c0e8));const _0x349664=_0x43c0e8['r'],_0x404849=this['requestCBHash_'][_0x349664];_0x404849&&(delete this['requestCBHash_'][_0x349664],_0x404849(_0x43c0e8['b']));}else{if('error'in _0x43c0e8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x43c0e8['error'];'a'in _0x43c0e8&&this['onDataPush_'](_0x43c0e8['a'],_0x43c0e8['b']);}}['onDataPush_'](_0x3afb0e,_0x50748a){this['log_']('handleServerMessage',_0x3afb0e,_0x50748a),_0x3afb0e==='d'?this['onDataUpdate_'](_0x50748a['p'],_0x50748a['d'],!0x1,_0x50748a['t']):_0x3afb0e==='m'?this['onDataUpdate_'](_0x50748a['p'],_0x50748a['d'],!0x0,_0x50748a['t']):_0x3afb0e==='c'?this['onListenRevoked_'](_0x50748a['p'],_0x50748a['q']):_0x3afb0e==='ac'?this['onAuthRevoked_'](_0x50748a['s'],_0x50748a['d']):_0x3afb0e==='apc'?this['onAppCheckRevoked_'](_0x50748a['s'],_0x50748a['d']):_0x3afb0e==='sd'?this['onSecurityDebugPacket_'](_0x50748a):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3afb0e)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x119a06,_0xd73676){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x119a06),this['lastSessionId']=_0xd73676,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x42907d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x42907d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x49acb5){_0x49acb5&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x49acb5;}['onOnline_'](_0x500189){_0x500189?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5690ee=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xbeaa8b=Math['max'](0x0,this['reconnectDelay_']-_0x5690ee);_0xbeaa8b=Math['random']()*_0xbeaa8b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xbeaa8b+'ms'),this['scheduleConnect_'](_0xbeaa8b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x19b797=this['onDataMessage_']['bind'](this),_0xbdb15e=this['onReady_']['bind'](this),_0x3c5a2e=this['onRealtimeDisconnect_']['bind'](this),_0x3aace0=this['id']+':'+se['nextConnectionId_']++,_0x597243=this['lastSessionId'];let _0x562018=!0x1,_0x3ada73=null;const _0x7ab609=function(){_0x3ada73?_0x3ada73['close']():(_0x562018=!0x0,_0x3c5a2e());},_0x3c83b3=function(_0x133943){f(_0x3ada73,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3ada73['sendRequest'](_0x133943);};this['realtime_']={'close':_0x7ab609,'sendRequest':_0x3c83b3};const _0x408dbb=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x71626,_0x3550dd]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x408dbb),this['appCheckTokenProvider_']['getToken'](_0x408dbb)]);_0x562018?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x71626&&_0x71626['accessToken'],this['appCheckToken_']=_0x3550dd&&_0x3550dd['token'],_0x3ada73=new Sh(_0x3aace0,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x19b797,_0xbdb15e,_0x3c5a2e,_0x2c0038=>{U(_0x2c0038+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x597243));}catch(_0x3e4288){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3e4288),_0x562018||(this['repoInfo_']['nodeAdmin']&&U(_0x3e4288),_0x7ab609());}}}['interrupt'](_0x4c2701){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4c2701),this['interruptReasons_'][_0x4c2701]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2c571c){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2c571c),delete this['interruptReasons_'][_0x2c571c],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x43ea96){const _0x318f9b=_0x43ea96-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x318f9b});}['cancelSentTransactions_'](){for(let _0x3f19ad=0x0;_0x3f19ad<this['outstandingPuts_']['length'];_0x3f19ad++){const _0x7d56b=this['outstandingPuts_'][_0x3f19ad];_0x7d56b&&'h'in _0x7d56b['request']&&_0x7d56b['queued']&&(_0x7d56b['onComplete']&&_0x7d56b['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3f19ad],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3b2a3d,_0x5c685e){let _0x3d80b9;_0x5c685e?_0x3d80b9=_0x5c685e['map'](_0x21624f=>$i(_0x21624f))['join']('$'):_0x3d80b9='default';const _0x452981=this['removeListen_'](_0x3b2a3d,_0x3d80b9);_0x452981&&_0x452981['onComplete']&&_0x452981['onComplete']('permission_denied');}['removeListen_'](_0x57fcbe,_0x47f2a4){const _0x440988=new C(_0x57fcbe)['toString']();let _0x45681a;if(this['listens']['has'](_0x440988)){const _0x5c42b5=this['listens']['get'](_0x440988);_0x45681a=_0x5c42b5['get'](_0x47f2a4),_0x5c42b5['delete'](_0x47f2a4),_0x5c42b5['size']===0x0&&this['listens']['delete'](_0x440988);}else _0x45681a=void 0x0;return _0x45681a;}['onAuthRevoked_'](_0x52595a,_0x28a361){L('Auth\x20token\x20revoked:\x20'+_0x52595a+'/'+_0x28a361),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x52595a==='invalid_token'||_0x52595a==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x19c780,_0x24fe16){L('App\x20check\x20token\x20revoked:\x20'+_0x19c780+'/'+_0x24fe16),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x19c780==='invalid_token'||_0x19c780==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2d3624){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2d3624):'msg'in _0x2d3624&&console['log']('FIREBASE:\x20'+_0x2d3624['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x12ef4f of this['listens']['values']())for(const _0x38e918 of _0x12ef4f['values']())this['sendListen_'](_0x38e918);for(let _0x26aa87=0x0;_0x26aa87<this['outstandingPuts_']['length'];_0x26aa87++)this['outstandingPuts_'][_0x26aa87]&&this['sendPut_'](_0x26aa87);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4fafe0=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4fafe0['action'],_0x4fafe0['pathString'],_0x4fafe0['data'],_0x4fafe0['onComplete']);}for(let _0x22c58d=0x0;_0x22c58d<this['outstandingGets_']['length'];_0x22c58d++)this['outstandingGets_'][_0x22c58d]&&this['sendGet_'](_0x22c58d);}['sendConnectStats_'](){const _0x2ae47e={};let _0x1676f3='js';_0x2ae47e['sdk.'+_0x1676f3+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x2ae47e['framework.cordova']=0x1:Kr()&&(_0x2ae47e['framework.reactnative']=0x1),this['reportStats'](_0x2ae47e);}['shouldReconnect_'](){const _0x44ae3f=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x44ae3f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5608a2,_0x2a5287){this['name']=_0x5608a2,this['node']=_0x2a5287;}static['Wrap'](_0x10d7ee,_0x3b677a){return new E(_0x10d7ee,_0x3b677a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x43ea86,_0x213646){const _0x2b6be5=new E(Ue,_0x43ea86),_0x45541a=new E(Ue,_0x213646);return this['compare'](_0x2b6be5,_0x45541a)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2e418f){sn=_0x2e418f;}['compare'](_0x40f757,_0x203edc){return Ge(_0x40f757['name'],_0x203edc['name']);}['isDefinedOn'](_0x13583c){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xea9809,_0x378bb6){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x35030a,_0x5d07ce){return f(typeof _0x35030a=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x35030a,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x10bc2d,_0x1bfb93,_0x42a226,_0x308a0c,_0x1a6697=null){this['isReverse_']=_0x308a0c,this['resultGenerator_']=_0x1a6697,this['nodeStack_']=[];let _0x33544d=0x1;for(;!_0x10bc2d['isEmpty']();)if(_0x10bc2d=_0x10bc2d,_0x33544d=_0x1bfb93?_0x42a226(_0x10bc2d['key'],_0x1bfb93):0x1,_0x308a0c&&(_0x33544d*=-0x1),_0x33544d<0x0)this['isReverse_']?_0x10bc2d=_0x10bc2d['left']:_0x10bc2d=_0x10bc2d['right'];else{if(_0x33544d===0x0){this['nodeStack_']['push'](_0x10bc2d);break;}else this['nodeStack_']['push'](_0x10bc2d),this['isReverse_']?_0x10bc2d=_0x10bc2d['right']:_0x10bc2d=_0x10bc2d['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x593d8e=this['nodeStack_']['pop'](),_0x271956;if(this['resultGenerator_']?_0x271956=this['resultGenerator_'](_0x593d8e['key'],_0x593d8e['value']):_0x271956={'key':_0x593d8e['key'],'value':_0x593d8e['value']},this['isReverse_']){for(_0x593d8e=_0x593d8e['left'];!_0x593d8e['isEmpty']();)this['nodeStack_']['push'](_0x593d8e),_0x593d8e=_0x593d8e['right'];}else{for(_0x593d8e=_0x593d8e['right'];!_0x593d8e['isEmpty']();)this['nodeStack_']['push'](_0x593d8e),_0x593d8e=_0x593d8e['left'];}return _0x271956;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3ba0bb=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3ba0bb['key'],_0x3ba0bb['value']):{'key':_0x3ba0bb['key'],'value':_0x3ba0bb['value']};}}class M{constructor(_0x15ed19,_0x33b839,_0x3dc5ce,_0x4851a9,_0x1bc735){this['key']=_0x15ed19,this['value']=_0x33b839,this['color']=_0x3dc5ce??M['RED'],this['left']=_0x4851a9??B['EMPTY_NODE'],this['right']=_0x1bc735??B['EMPTY_NODE'];}['copy'](_0x18f169,_0xa20d17,_0x3a090f,_0x41fe04,_0x5d2793){return new M(_0x18f169??this['key'],_0xa20d17??this['value'],_0x3a090f??this['color'],_0x41fe04??this['left'],_0x5d2793??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x342f4a){return this['left']['inorderTraversal'](_0x342f4a)||!!_0x342f4a(this['key'],this['value'])||this['right']['inorderTraversal'](_0x342f4a);}['reverseTraversal'](_0x16c0d3){return this['right']['reverseTraversal'](_0x16c0d3)||_0x16c0d3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x16c0d3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x51b851,_0x1b0144,_0x7a242f){let _0x5e565f=this;const _0x2cdb1f=_0x7a242f(_0x51b851,_0x5e565f['key']);return _0x2cdb1f<0x0?_0x5e565f=_0x5e565f['copy'](null,null,null,_0x5e565f['left']['insert'](_0x51b851,_0x1b0144,_0x7a242f),null):_0x2cdb1f===0x0?_0x5e565f=_0x5e565f['copy'](null,_0x1b0144,null,null,null):_0x5e565f=_0x5e565f['copy'](null,null,null,null,_0x5e565f['right']['insert'](_0x51b851,_0x1b0144,_0x7a242f)),_0x5e565f['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x26d156=this;return!_0x26d156['left']['isRed_']()&&!_0x26d156['left']['left']['isRed_']()&&(_0x26d156=_0x26d156['moveRedLeft_']()),_0x26d156=_0x26d156['copy'](null,null,null,_0x26d156['left']['removeMin_'](),null),_0x26d156['fixUp_']();}['remove'](_0x58b924,_0x5806fc){let _0x1ec91a,_0x5a8814;if(_0x1ec91a=this,_0x5806fc(_0x58b924,_0x1ec91a['key'])<0x0)!_0x1ec91a['left']['isEmpty']()&&!_0x1ec91a['left']['isRed_']()&&!_0x1ec91a['left']['left']['isRed_']()&&(_0x1ec91a=_0x1ec91a['moveRedLeft_']()),_0x1ec91a=_0x1ec91a['copy'](null,null,null,_0x1ec91a['left']['remove'](_0x58b924,_0x5806fc),null);else{if(_0x1ec91a['left']['isRed_']()&&(_0x1ec91a=_0x1ec91a['rotateRight_']()),!_0x1ec91a['right']['isEmpty']()&&!_0x1ec91a['right']['isRed_']()&&!_0x1ec91a['right']['left']['isRed_']()&&(_0x1ec91a=_0x1ec91a['moveRedRight_']()),_0x5806fc(_0x58b924,_0x1ec91a['key'])===0x0){if(_0x1ec91a['right']['isEmpty']())return B['EMPTY_NODE'];_0x5a8814=_0x1ec91a['right']['min_'](),_0x1ec91a=_0x1ec91a['copy'](_0x5a8814['key'],_0x5a8814['value'],null,null,_0x1ec91a['right']['removeMin_']());}_0x1ec91a=_0x1ec91a['copy'](null,null,null,null,_0x1ec91a['right']['remove'](_0x58b924,_0x5806fc));}return _0x1ec91a['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5bcaf4=this;return _0x5bcaf4['right']['isRed_']()&&!_0x5bcaf4['left']['isRed_']()&&(_0x5bcaf4=_0x5bcaf4['rotateLeft_']()),_0x5bcaf4['left']['isRed_']()&&_0x5bcaf4['left']['left']['isRed_']()&&(_0x5bcaf4=_0x5bcaf4['rotateRight_']()),_0x5bcaf4['left']['isRed_']()&&_0x5bcaf4['right']['isRed_']()&&(_0x5bcaf4=_0x5bcaf4['colorFlip_']()),_0x5bcaf4;}['moveRedLeft_'](){let _0x389951=this['colorFlip_']();return _0x389951['right']['left']['isRed_']()&&(_0x389951=_0x389951['copy'](null,null,null,null,_0x389951['right']['rotateRight_']()),_0x389951=_0x389951['rotateLeft_'](),_0x389951=_0x389951['colorFlip_']()),_0x389951;}['moveRedRight_'](){let _0x1e5a5a=this['colorFlip_']();return _0x1e5a5a['left']['left']['isRed_']()&&(_0x1e5a5a=_0x1e5a5a['rotateRight_'](),_0x1e5a5a=_0x1e5a5a['colorFlip_']()),_0x1e5a5a;}['rotateLeft_'](){const _0x462a10=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x462a10,null);}['rotateRight_'](){const _0x4e128e=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4e128e);}['colorFlip_'](){const _0x4db6a8=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3a2ee1=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x4db6a8,_0x3a2ee1);}['checkMaxDepth_'](){const _0x45d119=this['check_']();return Math['pow'](0x2,_0x45d119)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2bcd91=this['left']['check_']();if(_0x2bcd91!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2bcd91+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x50b62a,_0x4cc60c,_0x310f77,_0x1df18e,_0x4aac10){return this;}['insert'](_0x351211,_0x2b2164,_0x2faa61){return new M(_0x351211,_0x2b2164,null);}['remove'](_0x2be6ac,_0x202efa){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5cb763){return!0x1;}['reverseTraversal'](_0x19d6b0){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x160f5b,_0x2137b1=B['EMPTY_NODE']){this['comparator_']=_0x160f5b,this['root_']=_0x2137b1;}['insert'](_0x5a691a,_0x3f8aa2){return new B(this['comparator_'],this['root_']['insert'](_0x5a691a,_0x3f8aa2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x14bb86){return new B(this['comparator_'],this['root_']['remove'](_0x14bb86,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4e8806){let _0x55b9cb,_0x1cd0eb=this['root_'];for(;!_0x1cd0eb['isEmpty']();){if(_0x55b9cb=this['comparator_'](_0x4e8806,_0x1cd0eb['key']),_0x55b9cb===0x0)return _0x1cd0eb['value'];_0x55b9cb<0x0?_0x1cd0eb=_0x1cd0eb['left']:_0x55b9cb>0x0&&(_0x1cd0eb=_0x1cd0eb['right']);}return null;}['getPredecessorKey'](_0x55e560){let _0x25e7f3,_0x28eea4=this['root_'],_0x45e622=null;for(;!_0x28eea4['isEmpty']();)if(_0x25e7f3=this['comparator_'](_0x55e560,_0x28eea4['key']),_0x25e7f3===0x0){if(_0x28eea4['left']['isEmpty']())return _0x45e622?_0x45e622['key']:null;for(_0x28eea4=_0x28eea4['left'];!_0x28eea4['right']['isEmpty']();)_0x28eea4=_0x28eea4['right'];return _0x28eea4['key'];}else _0x25e7f3<0x0?_0x28eea4=_0x28eea4['left']:_0x25e7f3>0x0&&(_0x45e622=_0x28eea4,_0x28eea4=_0x28eea4['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4cd4eb){return this['root_']['inorderTraversal'](_0x4cd4eb);}['reverseTraversal'](_0x4a7cc4){return this['root_']['reverseTraversal'](_0x4a7cc4);}['getIterator'](_0x164f8e){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x164f8e);}['getIteratorFrom'](_0x40fd03,_0x54b8b6){return new rn(this['root_'],_0x40fd03,this['comparator_'],!0x1,_0x54b8b6);}['getReverseIteratorFrom'](_0x4bb712,_0x3ae407){return new rn(this['root_'],_0x4bb712,this['comparator_'],!0x0,_0x3ae407);}['getReverseIterator'](_0x2fee48){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x2fee48);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1ee9cd,_0x171f3b){return Ge(_0x1ee9cd['name'],_0x171f3b['name']);}function Qi(_0x13f46b,_0x18009b){return Ge(_0x13f46b,_0x18009b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x3399ea){Ci=_0x3399ea;}const No=function(_0x280c38){return typeof _0x280c38=='number'?'number:'+ao(_0x280c38):'string:'+_0x280c38;},Po=function(_0x2ef35b){if(_0x2ef35b['isLeafNode']()){const _0x38519a=_0x2ef35b['val']();f(typeof _0x38519a=='string'||typeof _0x38519a=='number'||typeof _0x38519a=='object'&&Q(_0x38519a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2ef35b===Ci||_0x2ef35b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2ef35b===Ci||_0x2ef35b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0xe8ac49){nr=_0xe8ac49;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x2e1a41,_0x567c8d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2e1a41,this['priorityNode_']=_0x567c8d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4ec5d7){return new D(this['value_'],_0x4ec5d7);}['getImmediateChild'](_0x484603){return _0x484603==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3d1cc0){return v(_0x3d1cc0)?this:y(_0x3d1cc0)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2bf46a,_0x3c68dd){return null;}['updateImmediateChild'](_0x58aa76,_0x1086f2){return _0x58aa76==='.priority'?this['updatePriority'](_0x1086f2):_0x1086f2['isEmpty']()&&_0x58aa76!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x58aa76,_0x1086f2)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3a5562,_0x597609){const _0x28a116=y(_0x3a5562);return _0x28a116===null?_0x597609:_0x597609['isEmpty']()&&_0x28a116!=='.priority'?this:(f(_0x28a116!=='.priority'||Ce(_0x3a5562)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x28a116,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3a5562),_0x597609)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x45992b,_0x3db8fd){return!0x1;}['val'](_0x2e7645){return _0x2e7645&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4d720a='';this['priorityNode_']['isEmpty']()||(_0x4d720a+='priority:'+No(this['priorityNode_']['val']())+':');const _0x140764=typeof this['value_'];_0x4d720a+=_0x140764+':',_0x140764==='number'?_0x4d720a+=ao(this['value_']):_0x4d720a+=this['value_'],this['lazyHash_']=ro(_0x4d720a);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x23a5e5){return _0x23a5e5===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x23a5e5 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x23a5e5['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x23a5e5));}['compareToLeafNode_'](_0x1b6ce6){const _0x4b150f=typeof _0x1b6ce6['value_'],_0x14738b=typeof this['value_'],_0xb4f14a=D['VALUE_TYPE_ORDER']['indexOf'](_0x4b150f),_0x4accdf=D['VALUE_TYPE_ORDER']['indexOf'](_0x14738b);return f(_0xb4f14a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4b150f),f(_0x4accdf>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x14738b),_0xb4f14a===_0x4accdf?_0x14738b==='object'?0x0:this['value_']<_0x1b6ce6['value_']?-0x1:this['value_']===_0x1b6ce6['value_']?0x0:0x1:_0x4accdf-_0xb4f14a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x380425){if(_0x380425===this)return!0x0;if(_0x380425['isLeafNode']()){const _0x270784=_0x380425;return this['value_']===_0x270784['value_']&&this['priorityNode_']['equals'](_0x270784['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x20c732){Oo=_0x20c732;}function Wh(_0x523d87){Do=_0x523d87;}class Bh extends Fn{['compare'](_0x59f6a4,_0x8aa26e){const _0x34b447=_0x59f6a4['node']['getPriority'](),_0x5e70c=_0x8aa26e['node']['getPriority'](),_0x1e1140=_0x34b447['compareTo'](_0x5e70c);return _0x1e1140===0x0?Ge(_0x59f6a4['name'],_0x8aa26e['name']):_0x1e1140;}['isDefinedOn'](_0x15243d){return!_0x15243d['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5845d5,_0x47ee6b){return!_0x5845d5['getPriority']()['equals'](_0x47ee6b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x242903,_0x4559ca){const _0x258f4e=Oo(_0x242903);return new E(_0x4559ca,new D('[PRIORITY-POST]',_0x258f4e));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x519088){const _0x41e953=_0x28e5a6=>parseInt(Math['log'](_0x28e5a6)/Vh,0xa),_0x311ee5=_0x27d168=>parseInt(Array(_0x27d168+0x1)['join']('1'),0x2);this['count']=_0x41e953(_0x519088+0x1),this['current_']=this['count']-0x1;const _0x4aaf41=_0x311ee5(this['count']);this['bits_']=_0x519088+0x1&_0x4aaf41;}['nextBitIsOne'](){const _0x37738d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x37738d;}}const yn=function(_0x4b0c56,_0x49219a,_0xfa02c,_0x47ba19){_0x4b0c56['sort'](_0x49219a);const _0x51032b=function(_0x2c5dab,_0x40641e){const _0x22e4d4=_0x40641e-_0x2c5dab;let _0x587f7b,_0xb7b74e;if(_0x22e4d4===0x0)return null;if(_0x22e4d4===0x1)return _0x587f7b=_0x4b0c56[_0x2c5dab],_0xb7b74e=_0xfa02c?_0xfa02c(_0x587f7b):_0x587f7b,new M(_0xb7b74e,_0x587f7b['node'],M['BLACK'],null,null);{const _0x1f557a=parseInt(_0x22e4d4/0x2,0xa)+_0x2c5dab,_0x57f0dd=_0x51032b(_0x2c5dab,_0x1f557a),_0x10cb47=_0x51032b(_0x1f557a+0x1,_0x40641e);return _0x587f7b=_0x4b0c56[_0x1f557a],_0xb7b74e=_0xfa02c?_0xfa02c(_0x587f7b):_0x587f7b,new M(_0xb7b74e,_0x587f7b['node'],M['BLACK'],_0x57f0dd,_0x10cb47);}},_0x4bc5aa=function(_0x5f32a7){let _0x46a547=null,_0x2c7e35=null,_0x54e40c=_0x4b0c56['length'];const _0x211cec=function(_0x1be1c0,_0x4d89ae){const _0x1ca179=_0x54e40c-_0x1be1c0,_0x171094=_0x54e40c;_0x54e40c-=_0x1be1c0;const _0x5eb677=_0x51032b(_0x1ca179+0x1,_0x171094),_0x34a187=_0x4b0c56[_0x1ca179],_0x25634b=_0xfa02c?_0xfa02c(_0x34a187):_0x34a187;_0x4dcf76(new M(_0x25634b,_0x34a187['node'],_0x4d89ae,null,_0x5eb677));},_0x4dcf76=function(_0x4b76d9){_0x46a547?(_0x46a547['left']=_0x4b76d9,_0x46a547=_0x4b76d9):(_0x2c7e35=_0x4b76d9,_0x46a547=_0x4b76d9);};for(let _0x1b741f=0x0;_0x1b741f<_0x5f32a7['count'];++_0x1b741f){const _0xa1f5b3=_0x5f32a7['nextBitIsOne'](),_0x1d4b0f=Math['pow'](0x2,_0x5f32a7['count']-(_0x1b741f+0x1));_0xa1f5b3?_0x211cec(_0x1d4b0f,M['BLACK']):(_0x211cec(_0x1d4b0f,M['BLACK']),_0x211cec(_0x1d4b0f,M['RED']));}return _0x2c7e35;},_0x24b5b5=new Hh(_0x4b0c56['length']),_0x1ca6ec=_0x4bc5aa(_0x24b5b5);return new B(_0x47ba19||_0x49219a,_0x1ca6ec);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0xa4e5b0,_0x381fcf){this['indexes_']=_0xa4e5b0,this['indexSet_']=_0x381fcf;}['get'](_0x1371da){const _0x45408d=Me(this['indexes_'],_0x1371da);if(!_0x45408d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1371da);return _0x45408d instanceof B?_0x45408d:null;}['hasIndex'](_0x3818d1){return Q(this['indexSet_'],_0x3818d1['toString']());}['addIndex'](_0x3e9cec,_0x543b66){f(_0x3e9cec!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x19d6e4=[];let _0x547ccc=!0x1;const _0xb8f251=_0x543b66['getIterator'](E['Wrap']);let _0x11982a=_0xb8f251['getNext']();for(;_0x11982a;)_0x547ccc=_0x547ccc||_0x3e9cec['isDefinedOn'](_0x11982a['node']),_0x19d6e4['push'](_0x11982a),_0x11982a=_0xb8f251['getNext']();let _0x2f4c4a;_0x547ccc?_0x2f4c4a=yn(_0x19d6e4,_0x3e9cec['getCompare']()):_0x2f4c4a=Qe;const _0x9d5a67=_0x3e9cec['toString'](),_0x133d9c={...this['indexSet_']};_0x133d9c[_0x9d5a67]=_0x3e9cec;const _0x4b900c={...this['indexes_']};return _0x4b900c[_0x9d5a67]=_0x2f4c4a,new te(_0x4b900c,_0x133d9c);}['addToIndexes'](_0x3216ee,_0x141daa){const _0x4840d5=_n(this['indexes_'],(_0x14bfcb,_0x3b711d)=>{const _0x1e5951=Me(this['indexSet_'],_0x3b711d);if(f(_0x1e5951,'Missing\x20index\x20implementation\x20for\x20'+_0x3b711d),_0x14bfcb===Qe){if(_0x1e5951['isDefinedOn'](_0x3216ee['node'])){const _0x5cd0bd=[],_0x20eb79=_0x141daa['getIterator'](E['Wrap']);let _0x34e2e1=_0x20eb79['getNext']();for(;_0x34e2e1;)_0x34e2e1['name']!==_0x3216ee['name']&&_0x5cd0bd['push'](_0x34e2e1),_0x34e2e1=_0x20eb79['getNext']();return _0x5cd0bd['push'](_0x3216ee),yn(_0x5cd0bd,_0x1e5951['getCompare']());}else return Qe;}else{const _0x5756a8=_0x141daa['get'](_0x3216ee['name']);let _0x3033bb=_0x14bfcb;return _0x5756a8&&(_0x3033bb=_0x3033bb['remove'](new E(_0x3216ee['name'],_0x5756a8))),_0x3033bb['insert'](_0x3216ee,_0x3216ee['node']);}});return new te(_0x4840d5,this['indexSet_']);}['removeFromIndexes'](_0x1817cc,_0x3c6bf7){const _0x43042c=_n(this['indexes_'],_0x14e36a=>{if(_0x14e36a===Qe)return _0x14e36a;{const _0x4e9d0a=_0x3c6bf7['get'](_0x1817cc['name']);return _0x4e9d0a?_0x14e36a['remove'](new E(_0x1817cc['name'],_0x4e9d0a)):_0x14e36a;}});return new te(_0x43042c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Qi),null,te['Default']));}constructor(_0x3df0bf,_0x3884de,_0x47b6f7){this['children_']=_0x3df0bf,this['priorityNode_']=_0x3884de,this['indexMap_']=_0x47b6f7,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x58be6c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x58be6c,this['indexMap_']);}['getImmediateChild'](_0x4c8e09){if(_0x4c8e09==='.priority')return this['getPriority']();{const _0x330726=this['children_']['get'](_0x4c8e09);return _0x330726===null?Et:_0x330726;}}['getChild'](_0x224256){const _0x4641ab=y(_0x224256);return _0x4641ab===null?this:this['getImmediateChild'](_0x4641ab)['getChild'](S(_0x224256));}['hasChild'](_0x191039){return this['children_']['get'](_0x191039)!==null;}['updateImmediateChild'](_0x37b407,_0x1579a5){if(f(_0x1579a5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x37b407==='.priority')return this['updatePriority'](_0x1579a5);{const _0xaf5353=new E(_0x37b407,_0x1579a5);let _0x160656,_0x24af58;_0x1579a5['isEmpty']()?(_0x160656=this['children_']['remove'](_0x37b407),_0x24af58=this['indexMap_']['removeFromIndexes'](_0xaf5353,this['children_'])):(_0x160656=this['children_']['insert'](_0x37b407,_0x1579a5),_0x24af58=this['indexMap_']['addToIndexes'](_0xaf5353,this['children_']));const _0x11b628=_0x160656['isEmpty']()?Et:this['priorityNode_'];return new g(_0x160656,_0x11b628,_0x24af58);}}['updateChild'](_0x64c65e,_0x721f06){const _0x389e1a=y(_0x64c65e);if(_0x389e1a===null)return _0x721f06;{f(y(_0x64c65e)!=='.priority'||Ce(_0x64c65e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x45d507=this['getImmediateChild'](_0x389e1a)['updateChild'](S(_0x64c65e),_0x721f06);return this['updateImmediateChild'](_0x389e1a,_0x45d507);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x38a203){if(this['isEmpty']())return null;const _0x361012={};let _0x4226ab=0x0,_0x45e1a9=0x0,_0x108e97=!0x0;if(this['forEachChild'](R,(_0x1c7e76,_0x1cc0db)=>{_0x361012[_0x1c7e76]=_0x1cc0db['val'](_0x38a203),_0x4226ab++,_0x108e97&&g['INTEGER_REGEXP_']['test'](_0x1c7e76)?_0x45e1a9=Math['max'](_0x45e1a9,Number(_0x1c7e76)):_0x108e97=!0x1;}),!_0x38a203&&_0x108e97&&_0x45e1a9<0x2*_0x4226ab){const _0x1812de=[];for(const _0x220f09 in _0x361012)_0x1812de[_0x220f09]=_0x361012[_0x220f09];return _0x1812de;}else return _0x38a203&&!this['getPriority']()['isEmpty']()&&(_0x361012['.priority']=this['getPriority']()['val']()),_0x361012;}['hash'](){if(this['lazyHash_']===null){let _0x4fcc79='';this['getPriority']()['isEmpty']()||(_0x4fcc79+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1996eb,_0x510c0a)=>{const _0x26b7ae=_0x510c0a['hash']();_0x26b7ae!==''&&(_0x4fcc79+=':'+_0x1996eb+':'+_0x26b7ae);}),this['lazyHash_']=_0x4fcc79===''?'':ro(_0x4fcc79);}return this['lazyHash_'];}['getPredecessorChildName'](_0x408e14,_0x3cffc5,_0x2191c5){const _0x541b90=this['resolveIndex_'](_0x2191c5);if(_0x541b90){const _0x4faf22=_0x541b90['getPredecessorKey'](new E(_0x408e14,_0x3cffc5));return _0x4faf22?_0x4faf22['name']:null;}else return this['children_']['getPredecessorKey'](_0x408e14);}['getFirstChildName'](_0x5f450e){const _0x193ba3=this['resolveIndex_'](_0x5f450e);if(_0x193ba3){const _0x67f0d1=_0x193ba3['minKey']();return _0x67f0d1&&_0x67f0d1['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3e8b7a){const _0x339208=this['getFirstChildName'](_0x3e8b7a);return _0x339208?new E(_0x339208,this['children_']['get'](_0x339208)):null;}['getLastChildName'](_0x186b99){const _0x4fdbaa=this['resolveIndex_'](_0x186b99);if(_0x4fdbaa){const _0x575e51=_0x4fdbaa['maxKey']();return _0x575e51&&_0x575e51['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5dbd9a){const _0x41596b=this['getLastChildName'](_0x5dbd9a);return _0x41596b?new E(_0x41596b,this['children_']['get'](_0x41596b)):null;}['forEachChild'](_0x2eae29,_0x21232d){const _0x2b6fea=this['resolveIndex_'](_0x2eae29);return _0x2b6fea?_0x2b6fea['inorderTraversal'](_0x288c7b=>_0x21232d(_0x288c7b['name'],_0x288c7b['node'])):this['children_']['inorderTraversal'](_0x21232d);}['getIterator'](_0x53a58d){return this['getIteratorFrom'](_0x53a58d['minPost'](),_0x53a58d);}['getIteratorFrom'](_0x58c878,_0xc02d23){const _0x409de3=this['resolveIndex_'](_0xc02d23);if(_0x409de3)return _0x409de3['getIteratorFrom'](_0x58c878,_0x266788=>_0x266788);{const _0xf3f5c5=this['children_']['getIteratorFrom'](_0x58c878['name'],E['Wrap']);let _0x52f535=_0xf3f5c5['peek']();for(;_0x52f535!=null&&_0xc02d23['compare'](_0x52f535,_0x58c878)<0x0;)_0xf3f5c5['getNext'](),_0x52f535=_0xf3f5c5['peek']();return _0xf3f5c5;}}['getReverseIterator'](_0x342b20){return this['getReverseIteratorFrom'](_0x342b20['maxPost'](),_0x342b20);}['getReverseIteratorFrom'](_0x48a725,_0x3386ff){const _0xba09e6=this['resolveIndex_'](_0x3386ff);if(_0xba09e6)return _0xba09e6['getReverseIteratorFrom'](_0x48a725,_0xf94c20=>_0xf94c20);{const _0x5ec6e2=this['children_']['getReverseIteratorFrom'](_0x48a725['name'],E['Wrap']);let _0x5be965=_0x5ec6e2['peek']();for(;_0x5be965!=null&&_0x3386ff['compare'](_0x5be965,_0x48a725)>0x0;)_0x5ec6e2['getNext'](),_0x5be965=_0x5ec6e2['peek']();return _0x5ec6e2;}}['compareTo'](_0x54c9e5){return this['isEmpty']()?_0x54c9e5['isEmpty']()?0x0:-0x1:_0x54c9e5['isLeafNode']()||_0x54c9e5['isEmpty']()?0x1:_0x54c9e5===jt?-0x1:0x0;}['withIndex'](_0x1fbed9){if(_0x1fbed9===ve||this['indexMap_']['hasIndex'](_0x1fbed9))return this;{const _0x3ef54f=this['indexMap_']['addIndex'](_0x1fbed9,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3ef54f);}}['isIndexed'](_0x3bdc10){return _0x3bdc10===ve||this['indexMap_']['hasIndex'](_0x3bdc10);}['equals'](_0x428107){if(_0x428107===this)return!0x0;if(_0x428107['isLeafNode']())return!0x1;{const _0x8a7208=_0x428107;if(this['getPriority']()['equals'](_0x8a7208['getPriority']())){if(this['children_']['count']()===_0x8a7208['children_']['count']()){const _0x38a8a5=this['getIterator'](R),_0x12c52a=_0x8a7208['getIterator'](R);let _0x15a2f8=_0x38a8a5['getNext'](),_0x595f85=_0x12c52a['getNext']();for(;_0x15a2f8&&_0x595f85;){if(_0x15a2f8['name']!==_0x595f85['name']||!_0x15a2f8['node']['equals'](_0x595f85['node']))return!0x1;_0x15a2f8=_0x38a8a5['getNext'](),_0x595f85=_0x12c52a['getNext']();}return _0x15a2f8===null&&_0x595f85===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2edacc){return _0x2edacc===ve?null:this['indexMap_']['get'](_0x2edacc['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x268273){return _0x268273===this?0x0:0x1;}['equals'](_0x30d088){return _0x30d088===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2afecc){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(we,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(jt),Wh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x528691,_0x103181=null){if(_0x528691===null)return g['EMPTY_NODE'];if(typeof _0x528691=='object'&&'.priority'in _0x528691&&(_0x103181=_0x528691['.priority']),f(_0x103181===null||typeof _0x103181=='string'||typeof _0x103181=='number'||typeof _0x103181=='object'&&'.sv'in _0x103181,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x103181),typeof _0x528691=='object'&&'.value'in _0x528691&&_0x528691['.value']!==null&&(_0x528691=_0x528691['.value']),typeof _0x528691!='object'||'.sv'in _0x528691){const _0x743284=_0x528691;return new D(_0x743284,A(_0x103181));}if(!(_0x528691 instanceof Array)&&Gh){const _0x17f563=[];let _0x55742d=!0x1;if(x(_0x528691,(_0x4543ed,_0x1e1fed)=>{if(_0x4543ed['substring'](0x0,0x1)!=='.'){const _0x21917b=A(_0x1e1fed);_0x21917b['isEmpty']()||(_0x55742d=_0x55742d||!_0x21917b['getPriority']()['isEmpty'](),_0x17f563['push'](new E(_0x4543ed,_0x21917b)));}}),_0x17f563['length']===0x0)return g['EMPTY_NODE'];const _0x3607c3=yn(_0x17f563,xh,_0x7d959b=>_0x7d959b['name'],Qi);if(_0x55742d){const _0x19ac9e=yn(_0x17f563,R['getCompare']());return new g(_0x3607c3,A(_0x103181),new te({'.priority':_0x19ac9e},{'.priority':R}));}else return new g(_0x3607c3,A(_0x103181),te['Default']);}else{let _0x5ab802=g['EMPTY_NODE'];return x(_0x528691,(_0x59c5bc,_0x24770f)=>{if(Q(_0x528691,_0x59c5bc)&&_0x59c5bc['substring'](0x0,0x1)!=='.'){const _0x3ac858=A(_0x24770f);(_0x3ac858['isLeafNode']()||!_0x3ac858['isEmpty']())&&(_0x5ab802=_0x5ab802['updateImmediateChild'](_0x59c5bc,_0x3ac858));}}),_0x5ab802['updatePriority'](A(_0x103181));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x860928){super(),this['indexPath_']=_0x860928,f(!v(_0x860928)&&y(_0x860928)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1a449b){return _0x1a449b['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2101dd){return!_0x2101dd['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x24ab32,_0x57c9f4){const _0x287d1e=this['extractChild'](_0x24ab32['node']),_0x13c96b=this['extractChild'](_0x57c9f4['node']),_0x3c7414=_0x287d1e['compareTo'](_0x13c96b);return _0x3c7414===0x0?Ge(_0x24ab32['name'],_0x57c9f4['name']):_0x3c7414;}['makePost'](_0x43b7c0,_0x328f9b){const _0x4394b2=A(_0x43b7c0),_0x35751f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4394b2);return new E(_0x328f9b,_0x35751f);}['maxPost'](){const _0x53e637=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(we,_0x53e637);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x27910b,_0x2d44d0){const _0x1d13e4=_0x27910b['node']['compareTo'](_0x2d44d0['node']);return _0x1d13e4===0x0?Ge(_0x27910b['name'],_0x2d44d0['name']):_0x1d13e4;}['isDefinedOn'](_0x209deb){return!0x0;}['indexedValueChanged'](_0x71f872,_0x1d8e44){return!_0x71f872['equals'](_0x1d8e44);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4eb2bd,_0x107629){const _0x5010fb=A(_0x4eb2bd);return new E(_0x107629,_0x5010fb);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x333b3e){return{'type':'value','snapshotNode':_0x333b3e};}function rt(_0x582fe3,_0x31bcf6){return{'type':'child_added','snapshotNode':_0x31bcf6,'childName':_0x582fe3};}function Mt(_0x28f16d,_0x450220){return{'type':'child_removed','snapshotNode':_0x450220,'childName':_0x28f16d};}function Lt(_0x5104ba,_0x17c542,_0x3a7cc3){return{'type':'child_changed','snapshotNode':_0x17c542,'childName':_0x5104ba,'oldSnap':_0x3a7cc3};}function zh(_0x5567c4,_0x59d2a9){return{'type':'child_moved','snapshotNode':_0x59d2a9,'childName':_0x5567c4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x9ee0c5){this['index_']=_0x9ee0c5;}['updateChild'](_0x48e0e2,_0x3fdcbd,_0x5db79f,_0xa8d0ac,_0x34aad2,_0x197c7d){f(_0x48e0e2['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1cea0f=_0x48e0e2['getImmediateChild'](_0x3fdcbd);return _0x1cea0f['getChild'](_0xa8d0ac)['equals'](_0x5db79f['getChild'](_0xa8d0ac))&&_0x1cea0f['isEmpty']()===_0x5db79f['isEmpty']()||(_0x197c7d!=null&&(_0x5db79f['isEmpty']()?_0x48e0e2['hasChild'](_0x3fdcbd)?_0x197c7d['trackChildChange'](Mt(_0x3fdcbd,_0x1cea0f)):f(_0x48e0e2['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1cea0f['isEmpty']()?_0x197c7d['trackChildChange'](rt(_0x3fdcbd,_0x5db79f)):_0x197c7d['trackChildChange'](Lt(_0x3fdcbd,_0x5db79f,_0x1cea0f))),_0x48e0e2['isLeafNode']()&&_0x5db79f['isEmpty']())?_0x48e0e2:_0x48e0e2['updateImmediateChild'](_0x3fdcbd,_0x5db79f)['withIndex'](this['index_']);}['updateFullNode'](_0x2ecf64,_0x5946b8,_0x3ec680){return _0x3ec680!=null&&(_0x2ecf64['isLeafNode']()||_0x2ecf64['forEachChild'](R,(_0x708522,_0x3f653d)=>{_0x5946b8['hasChild'](_0x708522)||_0x3ec680['trackChildChange'](Mt(_0x708522,_0x3f653d));}),_0x5946b8['isLeafNode']()||_0x5946b8['forEachChild'](R,(_0x161820,_0x2a4014)=>{if(_0x2ecf64['hasChild'](_0x161820)){const _0x576e3b=_0x2ecf64['getImmediateChild'](_0x161820);_0x576e3b['equals'](_0x2a4014)||_0x3ec680['trackChildChange'](Lt(_0x161820,_0x2a4014,_0x576e3b));}else _0x3ec680['trackChildChange'](rt(_0x161820,_0x2a4014));})),_0x5946b8['withIndex'](this['index_']);}['updatePriority'](_0x4d94fc,_0x56b292){return _0x4d94fc['isEmpty']()?g['EMPTY_NODE']:_0x4d94fc['updatePriority'](_0x56b292);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x4509ef){this['indexedFilter_']=new Xi(_0x4509ef['getIndex']()),this['index_']=_0x4509ef['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x4509ef),this['endPost_']=xt['getEndPost_'](_0x4509ef),this['startIsInclusive_']=!_0x4509ef['startAfterSet_'],this['endIsInclusive_']=!_0x4509ef['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x407a6c){const _0x21084b=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x407a6c)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x407a6c)<0x0,_0x13a64b=this['endIsInclusive_']?this['index_']['compare'](_0x407a6c,this['getEndPost']())<=0x0:this['index_']['compare'](_0x407a6c,this['getEndPost']())<0x0;return _0x21084b&&_0x13a64b;}['updateChild'](_0x4fdc94,_0xbc1b9c,_0x229893,_0x1d730a,_0x4b6897,_0x38e27a){return this['matches'](new E(_0xbc1b9c,_0x229893))||(_0x229893=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4fdc94,_0xbc1b9c,_0x229893,_0x1d730a,_0x4b6897,_0x38e27a);}['updateFullNode'](_0x5d7c36,_0xef3448,_0x57402e){_0xef3448['isLeafNode']()&&(_0xef3448=g['EMPTY_NODE']);let _0x10a5c1=_0xef3448['withIndex'](this['index_']);_0x10a5c1=_0x10a5c1['updatePriority'](g['EMPTY_NODE']);const _0x4e7229=this;return _0xef3448['forEachChild'](R,(_0x2d1636,_0x152643)=>{_0x4e7229['matches'](new E(_0x2d1636,_0x152643))||(_0x10a5c1=_0x10a5c1['updateImmediateChild'](_0x2d1636,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5d7c36,_0x10a5c1,_0x57402e);}['updatePriority'](_0x34c72d,_0x12847b){return _0x34c72d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x123e8f){if(_0x123e8f['hasStart']()){const _0x1a9094=_0x123e8f['getIndexStartName']();return _0x123e8f['getIndex']()['makePost'](_0x123e8f['getIndexStartValue'](),_0x1a9094);}else return _0x123e8f['getIndex']()['minPost']();}static['getEndPost_'](_0xbc4e73){if(_0xbc4e73['hasEnd']()){const _0x55afc4=_0xbc4e73['getIndexEndName']();return _0xbc4e73['getIndex']()['makePost'](_0xbc4e73['getIndexEndValue'](),_0x55afc4);}else return _0xbc4e73['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x57ecd1){this['withinDirectionalStart']=_0x49bac4=>this['reverse_']?this['withinEndPost'](_0x49bac4):this['withinStartPost'](_0x49bac4),this['withinDirectionalEnd']=_0x150f8e=>this['reverse_']?this['withinStartPost'](_0x150f8e):this['withinEndPost'](_0x150f8e),this['withinStartPost']=_0x5768b7=>{const _0x51f66e=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5768b7);return this['startIsInclusive_']?_0x51f66e<=0x0:_0x51f66e<0x0;},this['withinEndPost']=_0x563f43=>{const _0xb89c75=this['index_']['compare'](_0x563f43,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xb89c75<=0x0:_0xb89c75<0x0;},this['rangedFilter_']=new xt(_0x57ecd1),this['index_']=_0x57ecd1['getIndex'](),this['limit_']=_0x57ecd1['getLimit'](),this['reverse_']=!_0x57ecd1['isViewFromLeft'](),this['startIsInclusive_']=!_0x57ecd1['startAfterSet_'],this['endIsInclusive_']=!_0x57ecd1['endBeforeSet_'];}['updateChild'](_0xcb5e9d,_0x4068e3,_0x3e9b66,_0x53f6c0,_0x5395c0,_0x5ec61d){return this['rangedFilter_']['matches'](new E(_0x4068e3,_0x3e9b66))||(_0x3e9b66=g['EMPTY_NODE']),_0xcb5e9d['getImmediateChild'](_0x4068e3)['equals'](_0x3e9b66)?_0xcb5e9d:_0xcb5e9d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xcb5e9d,_0x4068e3,_0x3e9b66,_0x53f6c0,_0x5395c0,_0x5ec61d):this['fullLimitUpdateChild_'](_0xcb5e9d,_0x4068e3,_0x3e9b66,_0x5395c0,_0x5ec61d);}['updateFullNode'](_0x394f7d,_0x17e93e,_0x4e4bba){let _0x577143;if(_0x17e93e['isLeafNode']()||_0x17e93e['isEmpty']())_0x577143=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x17e93e['numChildren']()&&_0x17e93e['isIndexed'](this['index_'])){_0x577143=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5df2fb;this['reverse_']?_0x5df2fb=_0x17e93e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5df2fb=_0x17e93e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3cb3e7=0x0;for(;_0x5df2fb['hasNext']()&&_0x3cb3e7<this['limit_'];){const _0x1f9932=_0x5df2fb['getNext']();if(this['withinDirectionalStart'](_0x1f9932)){if(this['withinDirectionalEnd'](_0x1f9932))_0x577143=_0x577143['updateImmediateChild'](_0x1f9932['name'],_0x1f9932['node']),_0x3cb3e7++;else break;}else continue;}}else{_0x577143=_0x17e93e['withIndex'](this['index_']),_0x577143=_0x577143['updatePriority'](g['EMPTY_NODE']);let _0x7f76dc;this['reverse_']?_0x7f76dc=_0x577143['getReverseIterator'](this['index_']):_0x7f76dc=_0x577143['getIterator'](this['index_']);let _0x29e743=0x0;for(;_0x7f76dc['hasNext']();){const _0x5c23d5=_0x7f76dc['getNext']();_0x29e743<this['limit_']&&this['withinDirectionalStart'](_0x5c23d5)&&this['withinDirectionalEnd'](_0x5c23d5)?_0x29e743++:_0x577143=_0x577143['updateImmediateChild'](_0x5c23d5['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x394f7d,_0x577143,_0x4e4bba);}['updatePriority'](_0x3b4da7,_0x52edf8){return _0x3b4da7;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2b9736,_0x5043d1,_0x5afa04,_0xba36e,_0x2a1f19){let _0x4c68d9;if(this['reverse_']){const _0x53dc6a=this['index_']['getCompare']();_0x4c68d9=(_0x44e1bb,_0x63f412)=>_0x53dc6a(_0x63f412,_0x44e1bb);}else _0x4c68d9=this['index_']['getCompare']();const _0x6e778a=_0x2b9736;f(_0x6e778a['numChildren']()===this['limit_'],'');const _0x5a6e09=new E(_0x5043d1,_0x5afa04),_0x42780a=this['reverse_']?_0x6e778a['getFirstChild'](this['index_']):_0x6e778a['getLastChild'](this['index_']),_0x5f1d92=this['rangedFilter_']['matches'](_0x5a6e09);if(_0x6e778a['hasChild'](_0x5043d1)){const _0x9a7ccd=_0x6e778a['getImmediateChild'](_0x5043d1);let _0x401af8=_0xba36e['getChildAfterChild'](this['index_'],_0x42780a,this['reverse_']);for(;_0x401af8!=null&&(_0x401af8['name']===_0x5043d1||_0x6e778a['hasChild'](_0x401af8['name']));)_0x401af8=_0xba36e['getChildAfterChild'](this['index_'],_0x401af8,this['reverse_']);const _0x205458=_0x401af8==null?0x1:_0x4c68d9(_0x401af8,_0x5a6e09);if(_0x5f1d92&&!_0x5afa04['isEmpty']()&&_0x205458>=0x0)return _0x2a1f19!=null&&_0x2a1f19['trackChildChange'](Lt(_0x5043d1,_0x5afa04,_0x9a7ccd)),_0x6e778a['updateImmediateChild'](_0x5043d1,_0x5afa04);{_0x2a1f19!=null&&_0x2a1f19['trackChildChange'](Mt(_0x5043d1,_0x9a7ccd));const _0x5c8d29=_0x6e778a['updateImmediateChild'](_0x5043d1,g['EMPTY_NODE']);return _0x401af8!=null&&this['rangedFilter_']['matches'](_0x401af8)?(_0x2a1f19!=null&&_0x2a1f19['trackChildChange'](rt(_0x401af8['name'],_0x401af8['node'])),_0x5c8d29['updateImmediateChild'](_0x401af8['name'],_0x401af8['node'])):_0x5c8d29;}}else return _0x5afa04['isEmpty']()?_0x2b9736:_0x5f1d92&&_0x4c68d9(_0x42780a,_0x5a6e09)>=0x0?(_0x2a1f19!=null&&(_0x2a1f19['trackChildChange'](Mt(_0x42780a['name'],_0x42780a['node'])),_0x2a1f19['trackChildChange'](rt(_0x5043d1,_0x5afa04))),_0x6e778a['updateImmediateChild'](_0x5043d1,_0x5afa04)['updateImmediateChild'](_0x42780a['name'],g['EMPTY_NODE'])):_0x2b9736;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x173d60=new Zi();return _0x173d60['limitSet_']=this['limitSet_'],_0x173d60['limit_']=this['limit_'],_0x173d60['startSet_']=this['startSet_'],_0x173d60['startAfterSet_']=this['startAfterSet_'],_0x173d60['indexStartValue_']=this['indexStartValue_'],_0x173d60['startNameSet_']=this['startNameSet_'],_0x173d60['indexStartName_']=this['indexStartName_'],_0x173d60['endSet_']=this['endSet_'],_0x173d60['endBeforeSet_']=this['endBeforeSet_'],_0x173d60['indexEndValue_']=this['indexEndValue_'],_0x173d60['endNameSet_']=this['endNameSet_'],_0x173d60['indexEndName_']=this['indexEndName_'],_0x173d60['index_']=this['index_'],_0x173d60['viewFrom_']=this['viewFrom_'],_0x173d60;}}function Kh(_0x2f3943){return _0x2f3943['loadsAllData']()?new Xi(_0x2f3943['getIndex']()):_0x2f3943['hasLimit']()?new jh(_0x2f3943):new xt(_0x2f3943);}function Yh(_0x381186,_0x561512,_0x53e1bc){const _0x46ef98=_0x381186['copy']();return _0x46ef98['startSet_']=!0x0,_0x561512===void 0x0&&(_0x561512=null),_0x46ef98['indexStartValue_']=_0x561512,_0x53e1bc!=null?(_0x46ef98['startNameSet_']=!0x0,_0x46ef98['indexStartName_']=_0x53e1bc):(_0x46ef98['startNameSet_']=!0x1,_0x46ef98['indexStartName_']=''),_0x46ef98;}function Qh(_0xc0bb7,_0xb2bfb5,_0x4ede70){const _0x25c7d1=_0xc0bb7['copy']();return _0x25c7d1['endSet_']=!0x0,_0xb2bfb5===void 0x0&&(_0xb2bfb5=null),_0x25c7d1['indexEndValue_']=_0xb2bfb5,_0x4ede70!==void 0x0?(_0x25c7d1['endNameSet_']=!0x0,_0x25c7d1['indexEndName_']=_0x4ede70):(_0x25c7d1['endNameSet_']=!0x1,_0x25c7d1['indexEndName_']=''),_0x25c7d1;}function xo(_0x1ac65c,_0x3ef506){const _0x30c0ab=_0x1ac65c['copy']();return _0x30c0ab['index_']=_0x3ef506,_0x30c0ab;}function ir(_0x115f02){const _0x44ff53={};if(_0x115f02['isDefault']())return _0x44ff53;let _0x38fd03;if(_0x115f02['index_']===R?_0x38fd03='$priority':_0x115f02['index_']===Mo?_0x38fd03='$value':_0x115f02['index_']===ve?_0x38fd03='$key':(f(_0x115f02['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x38fd03=_0x115f02['index_']['toString']()),_0x44ff53['orderBy']=O(_0x38fd03),_0x115f02['startSet_']){const _0x1fb462=_0x115f02['startAfterSet_']?'startAfter':'startAt';_0x44ff53[_0x1fb462]=O(_0x115f02['indexStartValue_']),_0x115f02['startNameSet_']&&(_0x44ff53[_0x1fb462]+=','+O(_0x115f02['indexStartName_']));}if(_0x115f02['endSet_']){const _0xa5e86e=_0x115f02['endBeforeSet_']?'endBefore':'endAt';_0x44ff53[_0xa5e86e]=O(_0x115f02['indexEndValue_']),_0x115f02['endNameSet_']&&(_0x44ff53[_0xa5e86e]+=','+O(_0x115f02['indexEndName_']));}return _0x115f02['limitSet_']&&(_0x115f02['isViewFromLeft']()?_0x44ff53['limitToFirst']=_0x115f02['limit_']:_0x44ff53['limitToLast']=_0x115f02['limit_']),_0x44ff53;}function sr(_0x3e0529){const _0x15e4c6={};if(_0x3e0529['startSet_']&&(_0x15e4c6['sp']=_0x3e0529['indexStartValue_'],_0x3e0529['startNameSet_']&&(_0x15e4c6['sn']=_0x3e0529['indexStartName_']),_0x15e4c6['sin']=!_0x3e0529['startAfterSet_']),_0x3e0529['endSet_']&&(_0x15e4c6['ep']=_0x3e0529['indexEndValue_'],_0x3e0529['endNameSet_']&&(_0x15e4c6['en']=_0x3e0529['indexEndName_']),_0x15e4c6['ein']=!_0x3e0529['endBeforeSet_']),_0x3e0529['limitSet_']){_0x15e4c6['l']=_0x3e0529['limit_'];let _0x553938=_0x3e0529['viewFrom_'];_0x553938===''&&(_0x3e0529['isViewFromLeft']()?_0x553938='l':_0x553938='r'),_0x15e4c6['vf']=_0x553938;}return _0x3e0529['index_']!==R&&(_0x15e4c6['i']=_0x3e0529['index_']['toString']()),_0x15e4c6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x1d2940){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x41c5ae,_0x5d6d17){return _0x5d6d17!==void 0x0?'tag$'+_0x5d6d17:(f(_0x41c5ae['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x41c5ae['_path']['toString']());}constructor(_0x1302b2,_0x1ef7ca,_0x314d11,_0x46014f){super(),this['repoInfo_']=_0x1302b2,this['onDataUpdate_']=_0x1ef7ca,this['authTokenProvider_']=_0x314d11,this['appCheckTokenProvider_']=_0x46014f,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x13243b,_0x3f1102,_0x271e34,_0x37f3d5){const _0x252be6=_0x13243b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x252be6+'\x20'+_0x13243b['_queryIdentifier']);const _0x38f635=vn['getListenId_'](_0x13243b,_0x271e34),_0x40eaaf={};this['listens_'][_0x38f635]=_0x40eaaf;const _0x35ec09=ir(_0x13243b['_queryParams']);this['restRequest_'](_0x252be6+'.json',_0x35ec09,(_0x19aadf,_0x1b5bf6)=>{let _0x1fb528=_0x1b5bf6;if(_0x19aadf===0x194&&(_0x1fb528=null,_0x19aadf=null),_0x19aadf===null&&this['onDataUpdate_'](_0x252be6,_0x1fb528,!0x1,_0x271e34),Me(this['listens_'],_0x38f635)===_0x40eaaf){let _0x9b373a;_0x19aadf?_0x19aadf===0x191?_0x9b373a='permission_denied':_0x9b373a='rest_error:'+_0x19aadf:_0x9b373a='ok',_0x37f3d5(_0x9b373a,null);}});}['unlisten'](_0x334764,_0x595adf){const _0x7a5ba5=vn['getListenId_'](_0x334764,_0x595adf);delete this['listens_'][_0x7a5ba5];}['get'](_0x438fe7){const _0x2b47d7=ir(_0x438fe7['_queryParams']),_0x1ed274=_0x438fe7['_path']['toString'](),_0x1c5592=new H();return this['restRequest_'](_0x1ed274+'.json',_0x2b47d7,(_0x46d7f3,_0x328d86)=>{let _0x131486=_0x328d86;_0x46d7f3===0x194&&(_0x131486=null,_0x46d7f3=null),_0x46d7f3===null?(this['onDataUpdate_'](_0x1ed274,_0x131486,!0x1,null),_0x1c5592['resolve'](_0x131486)):_0x1c5592['reject'](new Error(_0x131486));}),_0x1c5592['promise'];}['refreshAuthToken'](_0x37ece1){}['restRequest_'](_0x474bb0,_0x3e8a36={},_0x1e51fd){return _0x3e8a36['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x19b549,_0x327529])=>{_0x19b549&&_0x19b549['accessToken']&&(_0x3e8a36['auth']=_0x19b549['accessToken']),_0x327529&&_0x327529['token']&&(_0x3e8a36['ac']=_0x327529['token']);const _0x51c2f4=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x474bb0+'?ns='+this['repoInfo_']['namespace']+ut(_0x3e8a36);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x51c2f4);const _0x46dfb3=new XMLHttpRequest();_0x46dfb3['onreadystatechange']=()=>{if(_0x1e51fd&&_0x46dfb3['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x51c2f4+'\x20received.\x20status:',_0x46dfb3['status'],'response:',_0x46dfb3['responseText']);let _0x4656af=null;if(_0x46dfb3['status']>=0xc8&&_0x46dfb3['status']<0x12c){try{_0x4656af=Nt(_0x46dfb3['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x51c2f4+':\x20'+_0x46dfb3['responseText']);}_0x1e51fd(null,_0x4656af);}else _0x46dfb3['status']!==0x191&&_0x46dfb3['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x51c2f4+'\x20Status:\x20'+_0x46dfb3['status']),_0x1e51fd(_0x46dfb3['status']);_0x1e51fd=null;}},_0x46dfb3['open']('GET',_0x51c2f4,!0x0),_0x46dfb3['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x47d982){return this['rootNode_']['getChild'](_0x47d982);}['updateSnapshot'](_0x35586b,_0x188768){this['rootNode_']=this['rootNode_']['updateChild'](_0x35586b,_0x188768);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x448ac2,_0x590483,_0x5d333c){if(v(_0x590483))_0x448ac2['value']=_0x5d333c,_0x448ac2['children']['clear']();else{if(_0x448ac2['value']!==null)_0x448ac2['value']=_0x448ac2['value']['updateChild'](_0x590483,_0x5d333c);else{const _0x2c8bcb=y(_0x590483);_0x448ac2['children']['has'](_0x2c8bcb)||_0x448ac2['children']['set'](_0x2c8bcb,En());const _0x3d0cd1=_0x448ac2['children']['get'](_0x2c8bcb);_0x590483=S(_0x590483),pt(_0x3d0cd1,_0x590483,_0x5d333c);}}}function Ti(_0x1bfe39,_0x534af6){if(v(_0x534af6))return _0x1bfe39['value']=null,_0x1bfe39['children']['clear'](),!0x0;if(_0x1bfe39['value']!==null){if(_0x1bfe39['value']['isLeafNode']())return!0x1;{const _0x245d0a=_0x1bfe39['value'];return _0x1bfe39['value']=null,_0x245d0a['forEachChild'](R,(_0x187582,_0x1d6d0a)=>{pt(_0x1bfe39,new C(_0x187582),_0x1d6d0a);}),Ti(_0x1bfe39,_0x534af6);}}else{if(_0x1bfe39['children']['size']>0x0){const _0x4476f4=y(_0x534af6);return _0x534af6=S(_0x534af6),_0x1bfe39['children']['has'](_0x4476f4)&&Ti(_0x1bfe39['children']['get'](_0x4476f4),_0x534af6)&&_0x1bfe39['children']['delete'](_0x4476f4),_0x1bfe39['children']['size']===0x0;}else return!0x0;}}function Si(_0x51b16b,_0x410b07,_0x3d4221){_0x51b16b['value']!==null?_0x3d4221(_0x410b07,_0x51b16b['value']):Xh(_0x51b16b,(_0x4fcf45,_0x688f13)=>{const _0x517c8b=new C(_0x410b07['toString']()+'/'+_0x4fcf45);Si(_0x688f13,_0x517c8b,_0x3d4221);});}function Xh(_0x3d2138,_0x34534d){_0x3d2138['children']['forEach']((_0x2fdf96,_0x3d1ae0)=>{_0x34534d(_0x3d1ae0,_0x2fdf96);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zh{constructor(_0x30f386){this['collection_']=_0x30f386,this['last_']=null;}['get'](){const _0x43fdc6=this['collection_']['get'](),_0x531392={..._0x43fdc6};return this['last_']&&x(this['last_'],(_0x343bb3,_0x22f12b)=>{_0x531392[_0x343bb3]=_0x531392[_0x343bb3]-_0x22f12b;}),this['last_']=_0x43fdc6,_0x531392;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,eu=0x1e*0x3e8,tu=0x12c*0x3e8;class nu{constructor(_0x5ef3dd,_0x24630f){this['server_']=_0x24630f,this['statsToReport_']={},this['statsListener_']=new Zh(_0x5ef3dd);const _0x6e72f9=rr+(eu-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x6e72f9));}['reportStats_'](){const _0x58e73c=this['statsListener_']['get'](),_0x44da90={};let _0x20a08c=!0x1;x(_0x58e73c,(_0x8d420c,_0xda69ca)=>{_0xda69ca>0x0&&Q(this['statsToReport_'],_0x8d420c)&&(_0x44da90[_0x8d420c]=_0xda69ca,_0x20a08c=!0x0);}),_0x20a08c&&this['server_']['reportStats'](_0x44da90),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*tu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4944e5){_0x4944e5[_0x4944e5['OVERWRITE']=0x0]='OVERWRITE',_0x4944e5[_0x4944e5['MERGE']=0x1]='MERGE',_0x4944e5[_0x4944e5['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4944e5[_0x4944e5['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x7beaa5){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x7beaa5,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1bef2d,_0x57b65d,_0x3ebef3){this['path']=_0x1bef2d,this['affectedTree']=_0x57b65d,this['revert']=_0x3ebef3,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x21df55){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x28c62f=this['affectedTree']['subtree'](new C(_0x21df55));return new In(w(),_0x28c62f,this['revert']);}}else return f(y(this['path'])===_0x21df55,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x96f08b,_0x7c94c4){this['source']=_0x96f08b,this['path']=_0x7c94c4,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4dee7e){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x117696,_0x298a91,_0x34a030){this['source']=_0x117696,this['path']=_0x298a91,this['snap']=_0x34a030,this['type']=z['OVERWRITE'];}['operationForChild'](_0x57147d){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x57147d)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x1db6e3,_0x2ca1fd,_0x3ea829){this['source']=_0x1db6e3,this['path']=_0x2ca1fd,this['children']=_0x3ea829,this['type']=z['MERGE'];}['operationForChild'](_0x411bd9){if(v(this['path'])){const _0x1d69ae=this['children']['subtree'](new C(_0x411bd9));return _0x1d69ae['isEmpty']()?null:_0x1d69ae['value']?new We(this['source'],w(),_0x1d69ae['value']):new ot(this['source'],w(),_0x1d69ae);}else return f(y(this['path'])===_0x411bd9,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x346fa6,_0x5ef506,_0x21b548){this['node_']=_0x346fa6,this['fullyInitialized_']=_0x5ef506,this['filtered_']=_0x21b548;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x12814d){if(v(_0x12814d))return this['isFullyInitialized']()&&!this['filtered_'];const _0x29580e=y(_0x12814d);return this['isCompleteForChild'](_0x29580e);}['isCompleteForChild'](_0x383b4c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x383b4c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class iu{constructor(_0x23cb3d){this['query_']=_0x23cb3d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function su(_0x38345b,_0x4265ae,_0x5878ed,_0x4001e2){const _0x3aa730=[],_0x3700b0=[];return _0x4265ae['forEach'](_0x4e998c=>{_0x4e998c['type']==='child_changed'&&_0x38345b['index_']['indexedValueChanged'](_0x4e998c['oldSnap'],_0x4e998c['snapshotNode'])&&_0x3700b0['push'](zh(_0x4e998c['childName'],_0x4e998c['snapshotNode']));}),It(_0x38345b,_0x3aa730,'child_removed',_0x4265ae,_0x4001e2,_0x5878ed),It(_0x38345b,_0x3aa730,'child_added',_0x4265ae,_0x4001e2,_0x5878ed),It(_0x38345b,_0x3aa730,'child_moved',_0x3700b0,_0x4001e2,_0x5878ed),It(_0x38345b,_0x3aa730,'child_changed',_0x4265ae,_0x4001e2,_0x5878ed),It(_0x38345b,_0x3aa730,'value',_0x4265ae,_0x4001e2,_0x5878ed),_0x3aa730;}function It(_0xc7c853,_0x44e25b,_0x4a3249,_0x6baf1c,_0x49a910,_0xfb6ad6){const _0x376ea9=_0x6baf1c['filter'](_0x21daae=>_0x21daae['type']===_0x4a3249);_0x376ea9['sort']((_0x5c74e7,_0x53987d)=>ou(_0xc7c853,_0x5c74e7,_0x53987d)),_0x376ea9['forEach'](_0x2846b7=>{const _0x3aef59=ru(_0xc7c853,_0x2846b7,_0xfb6ad6);_0x49a910['forEach'](_0x2f4a06=>{_0x2f4a06['respondsTo'](_0x2846b7['type'])&&_0x44e25b['push'](_0x2f4a06['createEvent'](_0x3aef59,_0xc7c853['query_']));});});}function ru(_0xb66e3f,_0x18f0fe,_0x493ade){return _0x18f0fe['type']==='value'||_0x18f0fe['type']==='child_removed'||(_0x18f0fe['prevName']=_0x493ade['getPredecessorChildName'](_0x18f0fe['childName'],_0x18f0fe['snapshotNode'],_0xb66e3f['index_'])),_0x18f0fe;}function ou(_0x2e18d9,_0x3d0895,_0x5224fb){if(_0x3d0895['childName']==null||_0x5224fb['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x60e7ab=new E(_0x3d0895['childName'],_0x3d0895['snapshotNode']),_0x1b8c46=new E(_0x5224fb['childName'],_0x5224fb['snapshotNode']);return _0x2e18d9['index_']['compare'](_0x60e7ab,_0x1b8c46);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x26f773,_0x2d564f){return{'eventCache':_0x26f773,'serverCache':_0x2d564f};}function bt(_0x5f57c3,_0x39502f,_0x592270,_0x5d9ba0){return Un(new Te(_0x39502f,_0x592270,_0x5d9ba0),_0x5f57c3['serverCache']);}function Fo(_0x1e71b9,_0x2d2ec4,_0x4d1b4c,_0x7bc589){return Un(_0x1e71b9['eventCache'],new Te(_0x2d2ec4,_0x4d1b4c,_0x7bc589));}function wn(_0x49559e){return _0x49559e['eventCache']['isFullyInitialized']()?_0x49559e['eventCache']['getNode']():null;}function Be(_0x22d4f6){return _0x22d4f6['serverCache']['isFullyInitialized']()?_0x22d4f6['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const au=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0xe0660c){let _0x3264bc=new b(null);return x(_0xe0660c,(_0x3335ea,_0x3caf3d)=>{_0x3264bc=_0x3264bc['set'](new C(_0x3335ea),_0x3caf3d);}),_0x3264bc;}constructor(_0x142176,_0x4c5b16=au()){this['value']=_0x142176,this['children']=_0x4c5b16;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x47afc5,_0x5cc909){if(this['value']!=null&&_0x5cc909(this['value']))return{'path':w(),'value':this['value']};if(v(_0x47afc5))return null;{const _0x3e30e3=y(_0x47afc5),_0x40d8f9=this['children']['get'](_0x3e30e3);if(_0x40d8f9!==null){const _0x5dd69f=_0x40d8f9['findRootMostMatchingPathAndValue'](S(_0x47afc5),_0x5cc909);return _0x5dd69f!=null?{'path':k(new C(_0x3e30e3),_0x5dd69f['path']),'value':_0x5dd69f['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3e03e8){return this['findRootMostMatchingPathAndValue'](_0x3e03e8,()=>!0x0);}['subtree'](_0x3c495f){if(v(_0x3c495f))return this;{const _0x1f69ef=y(_0x3c495f),_0x25e6a1=this['children']['get'](_0x1f69ef);return _0x25e6a1!==null?_0x25e6a1['subtree'](S(_0x3c495f)):new b(null);}}['set'](_0x2850f8,_0x5a7222){if(v(_0x2850f8))return new b(_0x5a7222,this['children']);{const _0x3c8fcc=y(_0x2850f8),_0x403012=(this['children']['get'](_0x3c8fcc)||new b(null))['set'](S(_0x2850f8),_0x5a7222),_0x3206e3=this['children']['insert'](_0x3c8fcc,_0x403012);return new b(this['value'],_0x3206e3);}}['remove'](_0x5cd96c){if(v(_0x5cd96c))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0xb520c9=y(_0x5cd96c),_0x1aa3ff=this['children']['get'](_0xb520c9);if(_0x1aa3ff){const _0x2c7b54=_0x1aa3ff['remove'](S(_0x5cd96c));let _0x55bd11;return _0x2c7b54['isEmpty']()?_0x55bd11=this['children']['remove'](_0xb520c9):_0x55bd11=this['children']['insert'](_0xb520c9,_0x2c7b54),this['value']===null&&_0x55bd11['isEmpty']()?new b(null):new b(this['value'],_0x55bd11);}else return this;}}['get'](_0x14a626){if(v(_0x14a626))return this['value'];{const _0x376506=y(_0x14a626),_0x1e3ac2=this['children']['get'](_0x376506);return _0x1e3ac2?_0x1e3ac2['get'](S(_0x14a626)):null;}}['setTree'](_0x40d1ca,_0x2dbb37){if(v(_0x40d1ca))return _0x2dbb37;{const _0x8f8fcf=y(_0x40d1ca),_0x373757=(this['children']['get'](_0x8f8fcf)||new b(null))['setTree'](S(_0x40d1ca),_0x2dbb37);let _0x50525f;return _0x373757['isEmpty']()?_0x50525f=this['children']['remove'](_0x8f8fcf):_0x50525f=this['children']['insert'](_0x8f8fcf,_0x373757),new b(this['value'],_0x50525f);}}['fold'](_0x382a64){return this['fold_'](w(),_0x382a64);}['fold_'](_0x3df7fd,_0x22292f){const _0x4d1ca4={};return this['children']['inorderTraversal']((_0x174d77,_0x4e1b98)=>{_0x4d1ca4[_0x174d77]=_0x4e1b98['fold_'](k(_0x3df7fd,_0x174d77),_0x22292f);}),_0x22292f(_0x3df7fd,this['value'],_0x4d1ca4);}['findOnPath'](_0x5a5439,_0x2d5d73){return this['findOnPath_'](_0x5a5439,w(),_0x2d5d73);}['findOnPath_'](_0x15bf36,_0x4cdbbe,_0x3f4b2e){const _0x33119d=this['value']?_0x3f4b2e(_0x4cdbbe,this['value']):!0x1;if(_0x33119d)return _0x33119d;if(v(_0x15bf36))return null;{const _0x448376=y(_0x15bf36),_0xd062b1=this['children']['get'](_0x448376);return _0xd062b1?_0xd062b1['findOnPath_'](S(_0x15bf36),k(_0x4cdbbe,_0x448376),_0x3f4b2e):null;}}['foreachOnPath'](_0x2e20b4,_0x3655e8){return this['foreachOnPath_'](_0x2e20b4,w(),_0x3655e8);}['foreachOnPath_'](_0x741362,_0x3aaa41,_0x54f814){if(v(_0x741362))return this;{this['value']&&_0x54f814(_0x3aaa41,this['value']);const _0x4fa87d=y(_0x741362),_0x4fa15b=this['children']['get'](_0x4fa87d);return _0x4fa15b?_0x4fa15b['foreachOnPath_'](S(_0x741362),k(_0x3aaa41,_0x4fa87d),_0x54f814):new b(null);}}['foreach'](_0x5fc8df){this['foreach_'](w(),_0x5fc8df);}['foreach_'](_0x4cddc8,_0x2bbe48){this['children']['inorderTraversal']((_0x3b8d71,_0x35173c)=>{_0x35173c['foreach_'](k(_0x4cddc8,_0x3b8d71),_0x2bbe48);}),this['value']&&_0x2bbe48(_0x4cddc8,this['value']);}['foreachChild'](_0x586536){this['children']['inorderTraversal']((_0x438a7a,_0x2b91d0)=>{_0x2b91d0['value']&&_0x586536(_0x438a7a,_0x2b91d0['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x328c0f){this['writeTree_']=_0x328c0f;}static['empty'](){return new K(new b(null));}}function Rt(_0x25f069,_0xd7d46,_0x463dbf){if(v(_0xd7d46))return new K(new b(_0x463dbf));{const _0x23f166=_0x25f069['writeTree_']['findRootMostValueAndPath'](_0xd7d46);if(_0x23f166!=null){const _0x28b7d1=_0x23f166['path'];let _0x2ec79d=_0x23f166['value'];const _0x5575f1=F(_0x28b7d1,_0xd7d46);return _0x2ec79d=_0x2ec79d['updateChild'](_0x5575f1,_0x463dbf),new K(_0x25f069['writeTree_']['set'](_0x28b7d1,_0x2ec79d));}else{const _0x534b83=new b(_0x463dbf),_0x5ea58a=_0x25f069['writeTree_']['setTree'](_0xd7d46,_0x534b83);return new K(_0x5ea58a);}}}function bi(_0x24d310,_0x2bd5c3,_0x365dc0){let _0x401a14=_0x24d310;return x(_0x365dc0,(_0x39678b,_0x44270a)=>{_0x401a14=Rt(_0x401a14,k(_0x2bd5c3,_0x39678b),_0x44270a);}),_0x401a14;}function or(_0xdde60d,_0x2c0e29){if(v(_0x2c0e29))return K['empty']();{const _0x48b570=_0xdde60d['writeTree_']['setTree'](_0x2c0e29,new b(null));return new K(_0x48b570);}}function Ri(_0x353e66,_0x1d9bb2){return qe(_0x353e66,_0x1d9bb2)!=null;}function qe(_0x35398a,_0x231ae1){const _0x3a313d=_0x35398a['writeTree_']['findRootMostValueAndPath'](_0x231ae1);return _0x3a313d!=null?_0x35398a['writeTree_']['get'](_0x3a313d['path'])['getChild'](F(_0x3a313d['path'],_0x231ae1)):null;}function ar(_0x4827ec){const _0x55125c=[],_0x17be5c=_0x4827ec['writeTree_']['value'];return _0x17be5c!=null?_0x17be5c['isLeafNode']()||_0x17be5c['forEachChild'](R,(_0x5f4202,_0x504dc9)=>{_0x55125c['push'](new E(_0x5f4202,_0x504dc9));}):_0x4827ec['writeTree_']['children']['inorderTraversal']((_0xa9ec3,_0x1470ca)=>{_0x1470ca['value']!=null&&_0x55125c['push'](new E(_0xa9ec3,_0x1470ca['value']));}),_0x55125c;}function Ee(_0x106145,_0x490a31){if(v(_0x490a31))return _0x106145;{const _0x2089ef=qe(_0x106145,_0x490a31);return _0x2089ef!=null?new K(new b(_0x2089ef)):new K(_0x106145['writeTree_']['subtree'](_0x490a31));}}function Ai(_0x25a975){return _0x25a975['writeTree_']['isEmpty']();}function at(_0x3d77ce,_0x39b031){return Uo(w(),_0x3d77ce['writeTree_'],_0x39b031);}function Uo(_0x479e5b,_0x598dad,_0x15bc33){if(_0x598dad['value']!=null)return _0x15bc33['updateChild'](_0x479e5b,_0x598dad['value']);{let _0x877517=null;return _0x598dad['children']['inorderTraversal']((_0x2d0d40,_0x3b9172)=>{_0x2d0d40==='.priority'?(f(_0x3b9172['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x877517=_0x3b9172['value']):_0x15bc33=Uo(k(_0x479e5b,_0x2d0d40),_0x3b9172,_0x15bc33);}),!_0x15bc33['getChild'](_0x479e5b)['isEmpty']()&&_0x877517!==null&&(_0x15bc33=_0x15bc33['updateChild'](k(_0x479e5b,'.priority'),_0x877517)),_0x15bc33;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5d7c07,_0x5d08f4){return Ho(_0x5d08f4,_0x5d7c07);}function cu(_0x15b8c7,_0x556540,_0x19ce6b,_0x186ce0,_0x11aea5){f(_0x186ce0>_0x15b8c7['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x11aea5===void 0x0&&(_0x11aea5=!0x0),_0x15b8c7['allWrites']['push']({'path':_0x556540,'snap':_0x19ce6b,'writeId':_0x186ce0,'visible':_0x11aea5}),_0x11aea5&&(_0x15b8c7['visibleWrites']=Rt(_0x15b8c7['visibleWrites'],_0x556540,_0x19ce6b)),_0x15b8c7['lastWriteId']=_0x186ce0;}function lu(_0x1adc18,_0x3729b5,_0x54ce85,_0xb0c86a){f(_0xb0c86a>_0x1adc18['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1adc18['allWrites']['push']({'path':_0x3729b5,'children':_0x54ce85,'writeId':_0xb0c86a,'visible':!0x0}),_0x1adc18['visibleWrites']=bi(_0x1adc18['visibleWrites'],_0x3729b5,_0x54ce85),_0x1adc18['lastWriteId']=_0xb0c86a;}function hu(_0x4e75dd,_0x41edce){for(let _0x63f5d0=0x0;_0x63f5d0<_0x4e75dd['allWrites']['length'];_0x63f5d0++){const _0x1bd7a6=_0x4e75dd['allWrites'][_0x63f5d0];if(_0x1bd7a6['writeId']===_0x41edce)return _0x1bd7a6;}return null;}function uu(_0x4687f2,_0xc66b26){const _0x4bc6b1=_0x4687f2['allWrites']['findIndex'](_0x203e22=>_0x203e22['writeId']===_0xc66b26);f(_0x4bc6b1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x239fa6=_0x4687f2['allWrites'][_0x4bc6b1];_0x4687f2['allWrites']['splice'](_0x4bc6b1,0x1);let _0x5f5700=_0x239fa6['visible'],_0x1237c8=!0x1,_0x454bd9=_0x4687f2['allWrites']['length']-0x1;for(;_0x5f5700&&_0x454bd9>=0x0;){const _0x563df4=_0x4687f2['allWrites'][_0x454bd9];_0x563df4['visible']&&(_0x454bd9>=_0x4bc6b1&&du(_0x563df4,_0x239fa6['path'])?_0x5f5700=!0x1:G(_0x239fa6['path'],_0x563df4['path'])&&(_0x1237c8=!0x0)),_0x454bd9--;}if(_0x5f5700){if(_0x1237c8)return fu(_0x4687f2),!0x0;if(_0x239fa6['snap'])_0x4687f2['visibleWrites']=or(_0x4687f2['visibleWrites'],_0x239fa6['path']);else{const _0x35da4d=_0x239fa6['children'];x(_0x35da4d,_0x4b3c2c=>{_0x4687f2['visibleWrites']=or(_0x4687f2['visibleWrites'],k(_0x239fa6['path'],_0x4b3c2c));});}return!0x0;}else return!0x1;}function du(_0x4bf248,_0x1c4f35){if(_0x4bf248['snap'])return G(_0x4bf248['path'],_0x1c4f35);for(const _0x7a5c29 in _0x4bf248['children'])if(_0x4bf248['children']['hasOwnProperty'](_0x7a5c29)&&G(k(_0x4bf248['path'],_0x7a5c29),_0x1c4f35))return!0x0;return!0x1;}function fu(_0x116ba1){_0x116ba1['visibleWrites']=Wo(_0x116ba1['allWrites'],pu,w()),_0x116ba1['allWrites']['length']>0x0?_0x116ba1['lastWriteId']=_0x116ba1['allWrites'][_0x116ba1['allWrites']['length']-0x1]['writeId']:_0x116ba1['lastWriteId']=-0x1;}function pu(_0x461fa1){return _0x461fa1['visible'];}function Wo(_0x4dda81,_0x56a75f,_0x1d9fcf){let _0x952dac=K['empty']();for(let _0x2915f8=0x0;_0x2915f8<_0x4dda81['length'];++_0x2915f8){const _0x3c4f7b=_0x4dda81[_0x2915f8];if(_0x56a75f(_0x3c4f7b)){const _0x259a3a=_0x3c4f7b['path'];let _0x2c2b95;if(_0x3c4f7b['snap'])G(_0x1d9fcf,_0x259a3a)?(_0x2c2b95=F(_0x1d9fcf,_0x259a3a),_0x952dac=Rt(_0x952dac,_0x2c2b95,_0x3c4f7b['snap'])):G(_0x259a3a,_0x1d9fcf)&&(_0x2c2b95=F(_0x259a3a,_0x1d9fcf),_0x952dac=Rt(_0x952dac,w(),_0x3c4f7b['snap']['getChild'](_0x2c2b95)));else{if(_0x3c4f7b['children']){if(G(_0x1d9fcf,_0x259a3a))_0x2c2b95=F(_0x1d9fcf,_0x259a3a),_0x952dac=bi(_0x952dac,_0x2c2b95,_0x3c4f7b['children']);else{if(G(_0x259a3a,_0x1d9fcf)){if(_0x2c2b95=F(_0x259a3a,_0x1d9fcf),v(_0x2c2b95))_0x952dac=bi(_0x952dac,w(),_0x3c4f7b['children']);else{const _0x12dab6=Me(_0x3c4f7b['children'],y(_0x2c2b95));if(_0x12dab6){const _0x1bcc27=_0x12dab6['getChild'](S(_0x2c2b95));_0x952dac=Rt(_0x952dac,w(),_0x1bcc27);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x952dac;}function Bo(_0x459b56,_0x9db3a8,_0x57010b,_0x1f62fe,_0x5c72a2){if(!_0x1f62fe&&!_0x5c72a2){const _0x310253=qe(_0x459b56['visibleWrites'],_0x9db3a8);if(_0x310253!=null)return _0x310253;{const _0x502a1f=Ee(_0x459b56['visibleWrites'],_0x9db3a8);if(Ai(_0x502a1f))return _0x57010b;if(_0x57010b==null&&!Ri(_0x502a1f,w()))return null;{const _0x31e828=_0x57010b||g['EMPTY_NODE'];return at(_0x502a1f,_0x31e828);}}}else{const _0x17cfbd=Ee(_0x459b56['visibleWrites'],_0x9db3a8);if(!_0x5c72a2&&Ai(_0x17cfbd))return _0x57010b;if(!_0x5c72a2&&_0x57010b==null&&!Ri(_0x17cfbd,w()))return null;{const _0x282c5c=function(_0xe42a85){return(_0xe42a85['visible']||_0x5c72a2)&&(!_0x1f62fe||!~_0x1f62fe['indexOf'](_0xe42a85['writeId']))&&(G(_0xe42a85['path'],_0x9db3a8)||G(_0x9db3a8,_0xe42a85['path']));},_0x374a59=Wo(_0x459b56['allWrites'],_0x282c5c,_0x9db3a8),_0x3feb5f=_0x57010b||g['EMPTY_NODE'];return at(_0x374a59,_0x3feb5f);}}}function _u(_0x49eecb,_0x1d7705,_0x3e1faf){let _0x1d1bc8=g['EMPTY_NODE'];const _0x10c05b=qe(_0x49eecb['visibleWrites'],_0x1d7705);if(_0x10c05b)return _0x10c05b['isLeafNode']()||_0x10c05b['forEachChild'](R,(_0x54a8ee,_0x3ebb5d)=>{_0x1d1bc8=_0x1d1bc8['updateImmediateChild'](_0x54a8ee,_0x3ebb5d);}),_0x1d1bc8;if(_0x3e1faf){const _0x35e58a=Ee(_0x49eecb['visibleWrites'],_0x1d7705);return _0x3e1faf['forEachChild'](R,(_0x28977c,_0x5b4a5d)=>{const _0x301400=at(Ee(_0x35e58a,new C(_0x28977c)),_0x5b4a5d);_0x1d1bc8=_0x1d1bc8['updateImmediateChild'](_0x28977c,_0x301400);}),ar(_0x35e58a)['forEach'](_0xf60470=>{_0x1d1bc8=_0x1d1bc8['updateImmediateChild'](_0xf60470['name'],_0xf60470['node']);}),_0x1d1bc8;}else{const _0x410435=Ee(_0x49eecb['visibleWrites'],_0x1d7705);return ar(_0x410435)['forEach'](_0x2afb9c=>{_0x1d1bc8=_0x1d1bc8['updateImmediateChild'](_0x2afb9c['name'],_0x2afb9c['node']);}),_0x1d1bc8;}}function gu(_0x42a6f0,_0x355ee3,_0x236a7a,_0x35a736,_0x5c1abc){f(_0x35a736||_0x5c1abc,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2602b1=k(_0x355ee3,_0x236a7a);if(Ri(_0x42a6f0['visibleWrites'],_0x2602b1))return null;{const _0x19a83a=Ee(_0x42a6f0['visibleWrites'],_0x2602b1);return Ai(_0x19a83a)?_0x5c1abc['getChild'](_0x236a7a):at(_0x19a83a,_0x5c1abc['getChild'](_0x236a7a));}}function mu(_0x560ac8,_0x21ea6d,_0x25aa77,_0x1ef708){const _0x4efc11=k(_0x21ea6d,_0x25aa77),_0x7003c0=qe(_0x560ac8['visibleWrites'],_0x4efc11);if(_0x7003c0!=null)return _0x7003c0;if(_0x1ef708['isCompleteForChild'](_0x25aa77)){const _0x139cdd=Ee(_0x560ac8['visibleWrites'],_0x4efc11);return at(_0x139cdd,_0x1ef708['getNode']()['getImmediateChild'](_0x25aa77));}else return null;}function yu(_0x2a0f7b,_0x5bf8f1){return qe(_0x2a0f7b['visibleWrites'],_0x5bf8f1);}function vu(_0x4569dd,_0xde6151,_0xbc8bc5,_0xaa1748,_0x1a9499,_0x20f468,_0x388800){let _0x34eff8;const _0x3f19f6=Ee(_0x4569dd['visibleWrites'],_0xde6151),_0x55d957=qe(_0x3f19f6,w());if(_0x55d957!=null)_0x34eff8=_0x55d957;else{if(_0xbc8bc5!=null)_0x34eff8=at(_0x3f19f6,_0xbc8bc5);else return[];}if(_0x34eff8=_0x34eff8['withIndex'](_0x388800),!_0x34eff8['isEmpty']()&&!_0x34eff8['isLeafNode']()){const _0x51c4f6=[],_0xffe8c=_0x388800['getCompare'](),_0x2179e5=_0x20f468?_0x34eff8['getReverseIteratorFrom'](_0xaa1748,_0x388800):_0x34eff8['getIteratorFrom'](_0xaa1748,_0x388800);let _0x523adb=_0x2179e5['getNext']();for(;_0x523adb&&_0x51c4f6['length']<_0x1a9499;)_0xffe8c(_0x523adb,_0xaa1748)!==0x0&&_0x51c4f6['push'](_0x523adb),_0x523adb=_0x2179e5['getNext']();return _0x51c4f6;}else return[];}function Eu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x197e06,_0x2ff3f7,_0x1c258d,_0x5dc577){return Bo(_0x197e06['writeTree'],_0x197e06['treePath'],_0x2ff3f7,_0x1c258d,_0x5dc577);}function is(_0x20d37c,_0x509691){return _u(_0x20d37c['writeTree'],_0x20d37c['treePath'],_0x509691);}function cr(_0xe20e82,_0x30d556,_0x1a47ce,_0x35475e){return gu(_0xe20e82['writeTree'],_0xe20e82['treePath'],_0x30d556,_0x1a47ce,_0x35475e);}function Tn(_0x1dc591,_0x53c999){return yu(_0x1dc591['writeTree'],k(_0x1dc591['treePath'],_0x53c999));}function Iu(_0x4e6c30,_0x5ad38e,_0x17e0d8,_0x3ef89c,_0x4623f8,_0x432a68){return vu(_0x4e6c30['writeTree'],_0x4e6c30['treePath'],_0x5ad38e,_0x17e0d8,_0x3ef89c,_0x4623f8,_0x432a68);}function ss(_0x403c89,_0xe68732,_0x3b91d6){return mu(_0x403c89['writeTree'],_0x403c89['treePath'],_0xe68732,_0x3b91d6);}function Vo(_0x59ee05,_0x3f3429){return Ho(k(_0x59ee05['treePath'],_0x3f3429),_0x59ee05['writeTree']);}function Ho(_0x3b7cd4,_0x13112a){return{'treePath':_0x3b7cd4,'writeTree':_0x13112a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3b6971){const _0xd29849=_0x3b6971['type'],_0x2819ae=_0x3b6971['childName'];f(_0xd29849==='child_added'||_0xd29849==='child_changed'||_0xd29849==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2819ae!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4b212f=this['changeMap']['get'](_0x2819ae);if(_0x4b212f){const _0x4c2d22=_0x4b212f['type'];if(_0xd29849==='child_added'&&_0x4c2d22==='child_removed')this['changeMap']['set'](_0x2819ae,Lt(_0x2819ae,_0x3b6971['snapshotNode'],_0x4b212f['snapshotNode']));else{if(_0xd29849==='child_removed'&&_0x4c2d22==='child_added')this['changeMap']['delete'](_0x2819ae);else{if(_0xd29849==='child_removed'&&_0x4c2d22==='child_changed')this['changeMap']['set'](_0x2819ae,Mt(_0x2819ae,_0x4b212f['oldSnap']));else{if(_0xd29849==='child_changed'&&_0x4c2d22==='child_added')this['changeMap']['set'](_0x2819ae,rt(_0x2819ae,_0x3b6971['snapshotNode']));else{if(_0xd29849==='child_changed'&&_0x4c2d22==='child_changed')this['changeMap']['set'](_0x2819ae,Lt(_0x2819ae,_0x3b6971['snapshotNode'],_0x4b212f['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x3b6971+'\x20occurred\x20after\x20'+_0x4b212f);}}}}}else this['changeMap']['set'](_0x2819ae,_0x3b6971);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{['getCompleteChild'](_0x5a9a4a){return null;}['getChildAfterChild'](_0x474b6b,_0x31acfb,_0x5161a8){return null;}}const $o=new Cu();class rs{constructor(_0x5efa53,_0x430265,_0x599c3b=null){this['writes_']=_0x5efa53,this['viewCache_']=_0x430265,this['optCompleteServerCache_']=_0x599c3b;}['getCompleteChild'](_0x2cc031){const _0x2a8d5e=this['viewCache_']['eventCache'];if(_0x2a8d5e['isCompleteForChild'](_0x2cc031))return _0x2a8d5e['getNode']()['getImmediateChild'](_0x2cc031);{const _0x549032=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2cc031,_0x549032);}}['getChildAfterChild'](_0x1989d1,_0x59a2d0,_0x494824){const _0x3ec6ac=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x4c1e6c=Iu(this['writes_'],_0x3ec6ac,_0x59a2d0,0x1,_0x494824,_0x1989d1);return _0x4c1e6c['length']===0x0?null:_0x4c1e6c[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Tu(_0x264957){return{'filter':_0x264957};}function Su(_0x11e65a,_0x4d50b4){f(_0x4d50b4['eventCache']['getNode']()['isIndexed'](_0x11e65a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4d50b4['serverCache']['getNode']()['isIndexed'](_0x11e65a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function bu(_0x2e9313,_0x58f6e3,_0x316d50,_0x42d05d,_0x245ba4){const _0x474794=new wu();let _0xbd62f0,_0x1095b2;if(_0x316d50['type']===z['OVERWRITE']){const _0x69ead8=_0x316d50;_0x69ead8['source']['fromUser']?_0xbd62f0=ki(_0x2e9313,_0x58f6e3,_0x69ead8['path'],_0x69ead8['snap'],_0x42d05d,_0x245ba4,_0x474794):(f(_0x69ead8['source']['fromServer'],'Unknown\x20source.'),_0x1095b2=_0x69ead8['source']['tagged']||_0x58f6e3['serverCache']['isFiltered']()&&!v(_0x69ead8['path']),_0xbd62f0=Sn(_0x2e9313,_0x58f6e3,_0x69ead8['path'],_0x69ead8['snap'],_0x42d05d,_0x245ba4,_0x1095b2,_0x474794));}else{if(_0x316d50['type']===z['MERGE']){const _0x52e704=_0x316d50;_0x52e704['source']['fromUser']?_0xbd62f0=Au(_0x2e9313,_0x58f6e3,_0x52e704['path'],_0x52e704['children'],_0x42d05d,_0x245ba4,_0x474794):(f(_0x52e704['source']['fromServer'],'Unknown\x20source.'),_0x1095b2=_0x52e704['source']['tagged']||_0x58f6e3['serverCache']['isFiltered'](),_0xbd62f0=Ni(_0x2e9313,_0x58f6e3,_0x52e704['path'],_0x52e704['children'],_0x42d05d,_0x245ba4,_0x1095b2,_0x474794));}else{if(_0x316d50['type']===z['ACK_USER_WRITE']){const _0x1e6717=_0x316d50;_0x1e6717['revert']?_0xbd62f0=Pu(_0x2e9313,_0x58f6e3,_0x1e6717['path'],_0x42d05d,_0x245ba4,_0x474794):_0xbd62f0=ku(_0x2e9313,_0x58f6e3,_0x1e6717['path'],_0x1e6717['affectedTree'],_0x42d05d,_0x245ba4,_0x474794);}else{if(_0x316d50['type']===z['LISTEN_COMPLETE'])_0xbd62f0=Nu(_0x2e9313,_0x58f6e3,_0x316d50['path'],_0x42d05d,_0x474794);else throw ht('Unknown\x20operation\x20type:\x20'+_0x316d50['type']);}}}const _0x4d757f=_0x474794['getChanges']();return Ru(_0x58f6e3,_0xbd62f0,_0x4d757f),{'viewCache':_0xbd62f0,'changes':_0x4d757f};}function Ru(_0x2c319f,_0x142c01,_0x589519){const _0x11a4ac=_0x142c01['eventCache'];if(_0x11a4ac['isFullyInitialized']()){const _0x3dfe4f=_0x11a4ac['getNode']()['isLeafNode']()||_0x11a4ac['getNode']()['isEmpty'](),_0x220f06=wn(_0x2c319f);(_0x589519['length']>0x0||!_0x2c319f['eventCache']['isFullyInitialized']()||_0x3dfe4f&&!_0x11a4ac['getNode']()['equals'](_0x220f06)||!_0x11a4ac['getNode']()['getPriority']()['equals'](_0x220f06['getPriority']()))&&_0x589519['push'](Lo(wn(_0x142c01)));}}function Go(_0x495bc5,_0x25e0d0,_0x3fe1d9,_0x4eaf99,_0x2a419f,_0x59047e){const _0x49a7b9=_0x25e0d0['eventCache'];if(Tn(_0x4eaf99,_0x3fe1d9)!=null)return _0x25e0d0;{let _0x41b1be,_0x3fdd34;if(v(_0x3fe1d9)){if(f(_0x25e0d0['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x25e0d0['serverCache']['isFiltered']()){const _0x3c3f82=Be(_0x25e0d0),_0x1f8b79=_0x3c3f82 instanceof g?_0x3c3f82:g['EMPTY_NODE'],_0x2c46db=is(_0x4eaf99,_0x1f8b79);_0x41b1be=_0x495bc5['filter']['updateFullNode'](_0x25e0d0['eventCache']['getNode'](),_0x2c46db,_0x59047e);}else{const _0x1d1844=Cn(_0x4eaf99,Be(_0x25e0d0));_0x41b1be=_0x495bc5['filter']['updateFullNode'](_0x25e0d0['eventCache']['getNode'](),_0x1d1844,_0x59047e);}}else{const _0x527881=y(_0x3fe1d9);if(_0x527881==='.priority'){f(Ce(_0x3fe1d9)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x118e8b=_0x49a7b9['getNode']();_0x3fdd34=_0x25e0d0['serverCache']['getNode']();const _0x1bab6e=cr(_0x4eaf99,_0x3fe1d9,_0x118e8b,_0x3fdd34);_0x1bab6e!=null?_0x41b1be=_0x495bc5['filter']['updatePriority'](_0x118e8b,_0x1bab6e):_0x41b1be=_0x49a7b9['getNode']();}else{const _0x1d4d78=S(_0x3fe1d9);let _0x541e97;if(_0x49a7b9['isCompleteForChild'](_0x527881)){_0x3fdd34=_0x25e0d0['serverCache']['getNode']();const _0x4f67b4=cr(_0x4eaf99,_0x3fe1d9,_0x49a7b9['getNode'](),_0x3fdd34);_0x4f67b4!=null?_0x541e97=_0x49a7b9['getNode']()['getImmediateChild'](_0x527881)['updateChild'](_0x1d4d78,_0x4f67b4):_0x541e97=_0x49a7b9['getNode']()['getImmediateChild'](_0x527881);}else _0x541e97=ss(_0x4eaf99,_0x527881,_0x25e0d0['serverCache']);_0x541e97!=null?_0x41b1be=_0x495bc5['filter']['updateChild'](_0x49a7b9['getNode'](),_0x527881,_0x541e97,_0x1d4d78,_0x2a419f,_0x59047e):_0x41b1be=_0x49a7b9['getNode']();}}return bt(_0x25e0d0,_0x41b1be,_0x49a7b9['isFullyInitialized']()||v(_0x3fe1d9),_0x495bc5['filter']['filtersNodes']());}}function Sn(_0x4de3ed,_0x1ad53a,_0x480382,_0x3a3a94,_0x3f3e61,_0x5b9445,_0x1e9f7e,_0x1f834c){const _0x35b9f4=_0x1ad53a['serverCache'];let _0x1e3af8;const _0x2b0c22=_0x1e9f7e?_0x4de3ed['filter']:_0x4de3ed['filter']['getIndexedFilter']();if(v(_0x480382))_0x1e3af8=_0x2b0c22['updateFullNode'](_0x35b9f4['getNode'](),_0x3a3a94,null);else{if(_0x2b0c22['filtersNodes']()&&!_0x35b9f4['isFiltered']()){const _0x20015f=_0x35b9f4['getNode']()['updateChild'](_0x480382,_0x3a3a94);_0x1e3af8=_0x2b0c22['updateFullNode'](_0x35b9f4['getNode'](),_0x20015f,null);}else{const _0x5f5a67=y(_0x480382);if(!_0x35b9f4['isCompleteForPath'](_0x480382)&&Ce(_0x480382)>0x1)return _0x1ad53a;const _0x4a41c1=S(_0x480382),_0x3ffa54=_0x35b9f4['getNode']()['getImmediateChild'](_0x5f5a67)['updateChild'](_0x4a41c1,_0x3a3a94);_0x5f5a67==='.priority'?_0x1e3af8=_0x2b0c22['updatePriority'](_0x35b9f4['getNode'](),_0x3ffa54):_0x1e3af8=_0x2b0c22['updateChild'](_0x35b9f4['getNode'](),_0x5f5a67,_0x3ffa54,_0x4a41c1,$o,null);}}const _0x25a77e=Fo(_0x1ad53a,_0x1e3af8,_0x35b9f4['isFullyInitialized']()||v(_0x480382),_0x2b0c22['filtersNodes']()),_0x2e4f81=new rs(_0x3f3e61,_0x25a77e,_0x5b9445);return Go(_0x4de3ed,_0x25a77e,_0x480382,_0x3f3e61,_0x2e4f81,_0x1f834c);}function ki(_0x4d5b65,_0x202f6a,_0x5de405,_0x303141,_0x1a2491,_0x5bb489,_0x31dc17){const _0x5a4c59=_0x202f6a['eventCache'];let _0x312e6c,_0x182d66;const _0x3ba854=new rs(_0x1a2491,_0x202f6a,_0x5bb489);if(v(_0x5de405))_0x182d66=_0x4d5b65['filter']['updateFullNode'](_0x202f6a['eventCache']['getNode'](),_0x303141,_0x31dc17),_0x312e6c=bt(_0x202f6a,_0x182d66,!0x0,_0x4d5b65['filter']['filtersNodes']());else{const _0x1233d8=y(_0x5de405);if(_0x1233d8==='.priority')_0x182d66=_0x4d5b65['filter']['updatePriority'](_0x202f6a['eventCache']['getNode'](),_0x303141),_0x312e6c=bt(_0x202f6a,_0x182d66,_0x5a4c59['isFullyInitialized'](),_0x5a4c59['isFiltered']());else{const _0x30de42=S(_0x5de405),_0x1d26c3=_0x5a4c59['getNode']()['getImmediateChild'](_0x1233d8);let _0x40bc64;if(v(_0x30de42))_0x40bc64=_0x303141;else{const _0x82cf70=_0x3ba854['getCompleteChild'](_0x1233d8);_0x82cf70!=null?ji(_0x30de42)==='.priority'&&_0x82cf70['getChild'](Ro(_0x30de42))['isEmpty']()?_0x40bc64=_0x82cf70:_0x40bc64=_0x82cf70['updateChild'](_0x30de42,_0x303141):_0x40bc64=g['EMPTY_NODE'];}if(_0x1d26c3['equals'](_0x40bc64))_0x312e6c=_0x202f6a;else{const _0x2478b5=_0x4d5b65['filter']['updateChild'](_0x5a4c59['getNode'](),_0x1233d8,_0x40bc64,_0x30de42,_0x3ba854,_0x31dc17);_0x312e6c=bt(_0x202f6a,_0x2478b5,_0x5a4c59['isFullyInitialized'](),_0x4d5b65['filter']['filtersNodes']());}}}return _0x312e6c;}function lr(_0x3854af,_0x24893b){return _0x3854af['eventCache']['isCompleteForChild'](_0x24893b);}function Au(_0x490299,_0x217cdb,_0x25aa7f,_0xada06a,_0x19e77d,_0x289ba1,_0x49973b){let _0x4c7d41=_0x217cdb;return _0xada06a['foreach']((_0x286a8b,_0x3a8743)=>{const _0x154921=k(_0x25aa7f,_0x286a8b);lr(_0x217cdb,y(_0x154921))&&(_0x4c7d41=ki(_0x490299,_0x4c7d41,_0x154921,_0x3a8743,_0x19e77d,_0x289ba1,_0x49973b));}),_0xada06a['foreach']((_0x1b0204,_0xa4d603)=>{const _0x314874=k(_0x25aa7f,_0x1b0204);lr(_0x217cdb,y(_0x314874))||(_0x4c7d41=ki(_0x490299,_0x4c7d41,_0x314874,_0xa4d603,_0x19e77d,_0x289ba1,_0x49973b));}),_0x4c7d41;}function hr(_0x18e3a0,_0x11f89e,_0x4c7362){return _0x4c7362['foreach']((_0x4dee20,_0x337f7b)=>{_0x11f89e=_0x11f89e['updateChild'](_0x4dee20,_0x337f7b);}),_0x11f89e;}function Ni(_0x1dcec6,_0x44822a,_0x289d46,_0x5ebb64,_0x228b73,_0xdf1aec,_0x1db2f4,_0x5d8eb3){if(_0x44822a['serverCache']['getNode']()['isEmpty']()&&!_0x44822a['serverCache']['isFullyInitialized']())return _0x44822a;let _0x26381b=_0x44822a,_0x432b74;v(_0x289d46)?_0x432b74=_0x5ebb64:_0x432b74=new b(null)['setTree'](_0x289d46,_0x5ebb64);const _0x3a6f63=_0x44822a['serverCache']['getNode']();return _0x432b74['children']['inorderTraversal']((_0x35c43a,_0x304a8b)=>{if(_0x3a6f63['hasChild'](_0x35c43a)){const _0x2a8b31=_0x44822a['serverCache']['getNode']()['getImmediateChild'](_0x35c43a),_0x3c834b=hr(_0x1dcec6,_0x2a8b31,_0x304a8b);_0x26381b=Sn(_0x1dcec6,_0x26381b,new C(_0x35c43a),_0x3c834b,_0x228b73,_0xdf1aec,_0x1db2f4,_0x5d8eb3);}}),_0x432b74['children']['inorderTraversal']((_0x509610,_0x10baa9)=>{const _0x491d0d=!_0x44822a['serverCache']['isCompleteForChild'](_0x509610)&&_0x10baa9['value']===null;if(!_0x3a6f63['hasChild'](_0x509610)&&!_0x491d0d){const _0x3f80bd=_0x44822a['serverCache']['getNode']()['getImmediateChild'](_0x509610),_0x1da321=hr(_0x1dcec6,_0x3f80bd,_0x10baa9);_0x26381b=Sn(_0x1dcec6,_0x26381b,new C(_0x509610),_0x1da321,_0x228b73,_0xdf1aec,_0x1db2f4,_0x5d8eb3);}}),_0x26381b;}function ku(_0x5c7cec,_0x1280e1,_0x263bbe,_0x36c366,_0x12911b,_0x2e7f1c,_0x278a71){if(Tn(_0x12911b,_0x263bbe)!=null)return _0x1280e1;const _0x584fa9=_0x1280e1['serverCache']['isFiltered'](),_0x106a4c=_0x1280e1['serverCache'];if(_0x36c366['value']!=null){if(v(_0x263bbe)&&_0x106a4c['isFullyInitialized']()||_0x106a4c['isCompleteForPath'](_0x263bbe))return Sn(_0x5c7cec,_0x1280e1,_0x263bbe,_0x106a4c['getNode']()['getChild'](_0x263bbe),_0x12911b,_0x2e7f1c,_0x584fa9,_0x278a71);if(v(_0x263bbe)){let _0x340595=new b(null);return _0x106a4c['getNode']()['forEachChild'](ve,(_0x228aa8,_0x48d5f4)=>{_0x340595=_0x340595['set'](new C(_0x228aa8),_0x48d5f4);}),Ni(_0x5c7cec,_0x1280e1,_0x263bbe,_0x340595,_0x12911b,_0x2e7f1c,_0x584fa9,_0x278a71);}else return _0x1280e1;}else{let _0x420861=new b(null);return _0x36c366['foreach']((_0x2cbc3c,_0x4832da)=>{const _0x559b19=k(_0x263bbe,_0x2cbc3c);_0x106a4c['isCompleteForPath'](_0x559b19)&&(_0x420861=_0x420861['set'](_0x2cbc3c,_0x106a4c['getNode']()['getChild'](_0x559b19)));}),Ni(_0x5c7cec,_0x1280e1,_0x263bbe,_0x420861,_0x12911b,_0x2e7f1c,_0x584fa9,_0x278a71);}}function Nu(_0xf9818d,_0x13f4f5,_0xf211f,_0x4deeb7,_0x5d6cca){const _0x289f70=_0x13f4f5['serverCache'],_0xf90a99=Fo(_0x13f4f5,_0x289f70['getNode'](),_0x289f70['isFullyInitialized']()||v(_0xf211f),_0x289f70['isFiltered']());return Go(_0xf9818d,_0xf90a99,_0xf211f,_0x4deeb7,$o,_0x5d6cca);}function Pu(_0x2c1baf,_0x2641dd,_0x2ed693,_0x2739eb,_0x36da46,_0x1a4755){let _0x34bbb5;if(Tn(_0x2739eb,_0x2ed693)!=null)return _0x2641dd;{const _0x5b39fc=new rs(_0x2739eb,_0x2641dd,_0x36da46),_0x208707=_0x2641dd['eventCache']['getNode']();let _0x407f8c;if(v(_0x2ed693)||y(_0x2ed693)==='.priority'){let _0x15dc96;if(_0x2641dd['serverCache']['isFullyInitialized']())_0x15dc96=Cn(_0x2739eb,Be(_0x2641dd));else{const _0x5a298b=_0x2641dd['serverCache']['getNode']();f(_0x5a298b instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x15dc96=is(_0x2739eb,_0x5a298b);}_0x15dc96=_0x15dc96,_0x407f8c=_0x2c1baf['filter']['updateFullNode'](_0x208707,_0x15dc96,_0x1a4755);}else{const _0x22c632=y(_0x2ed693);let _0x57ac4=ss(_0x2739eb,_0x22c632,_0x2641dd['serverCache']);_0x57ac4==null&&_0x2641dd['serverCache']['isCompleteForChild'](_0x22c632)&&(_0x57ac4=_0x208707['getImmediateChild'](_0x22c632)),_0x57ac4!=null?_0x407f8c=_0x2c1baf['filter']['updateChild'](_0x208707,_0x22c632,_0x57ac4,S(_0x2ed693),_0x5b39fc,_0x1a4755):_0x2641dd['eventCache']['getNode']()['hasChild'](_0x22c632)?_0x407f8c=_0x2c1baf['filter']['updateChild'](_0x208707,_0x22c632,g['EMPTY_NODE'],S(_0x2ed693),_0x5b39fc,_0x1a4755):_0x407f8c=_0x208707,_0x407f8c['isEmpty']()&&_0x2641dd['serverCache']['isFullyInitialized']()&&(_0x34bbb5=Cn(_0x2739eb,Be(_0x2641dd)),_0x34bbb5['isLeafNode']()&&(_0x407f8c=_0x2c1baf['filter']['updateFullNode'](_0x407f8c,_0x34bbb5,_0x1a4755)));}return _0x34bbb5=_0x2641dd['serverCache']['isFullyInitialized']()||Tn(_0x2739eb,w())!=null,bt(_0x2641dd,_0x407f8c,_0x34bbb5,_0x2c1baf['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ou{constructor(_0x2d7832,_0x4cc2a4){this['query_']=_0x2d7832,this['eventRegistrations_']=[];const _0x543877=this['query_']['_queryParams'],_0x43f5b5=new Xi(_0x543877['getIndex']()),_0x2971cc=Kh(_0x543877);this['processor_']=Tu(_0x2971cc);const _0x1bf1a3=_0x4cc2a4['serverCache'],_0x8bb7d4=_0x4cc2a4['eventCache'],_0x10d511=_0x43f5b5['updateFullNode'](g['EMPTY_NODE'],_0x1bf1a3['getNode'](),null),_0x158859=_0x2971cc['updateFullNode'](g['EMPTY_NODE'],_0x8bb7d4['getNode'](),null),_0x13636f=new Te(_0x10d511,_0x1bf1a3['isFullyInitialized'](),_0x43f5b5['filtersNodes']()),_0xc1ce19=new Te(_0x158859,_0x8bb7d4['isFullyInitialized'](),_0x2971cc['filtersNodes']());this['viewCache_']=Un(_0xc1ce19,_0x13636f),this['eventGenerator_']=new iu(this['query_']);}get['query'](){return this['query_'];}}function Du(_0x41e47d){return _0x41e47d['viewCache_']['serverCache']['getNode']();}function Mu(_0x1a6d45){return wn(_0x1a6d45['viewCache_']);}function Lu(_0x848d4c,_0x2374c1){const _0x2f067a=Be(_0x848d4c['viewCache_']);return _0x2f067a&&(_0x848d4c['query']['_queryParams']['loadsAllData']()||!v(_0x2374c1)&&!_0x2f067a['getImmediateChild'](y(_0x2374c1))['isEmpty']())?_0x2f067a['getChild'](_0x2374c1):null;}function ur(_0x4a64c3){return _0x4a64c3['eventRegistrations_']['length']===0x0;}function xu(_0x3b39bd,_0x2bfa86){_0x3b39bd['eventRegistrations_']['push'](_0x2bfa86);}function dr(_0x1b9ca2,_0x8d8829,_0x2f733f){const _0x168a33=[];if(_0x2f733f){f(_0x8d8829==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2aca06=_0x1b9ca2['query']['_path'];_0x1b9ca2['eventRegistrations_']['forEach'](_0x5d3378=>{const _0x142cef=_0x5d3378['createCancelEvent'](_0x2f733f,_0x2aca06);_0x142cef&&_0x168a33['push'](_0x142cef);});}if(_0x8d8829){let _0x494c9b=[];for(let _0x304e36=0x0;_0x304e36<_0x1b9ca2['eventRegistrations_']['length'];++_0x304e36){const _0x408173=_0x1b9ca2['eventRegistrations_'][_0x304e36];if(!_0x408173['matches'](_0x8d8829))_0x494c9b['push'](_0x408173);else{if(_0x8d8829['hasAnyCallback']()){_0x494c9b=_0x494c9b['concat'](_0x1b9ca2['eventRegistrations_']['slice'](_0x304e36+0x1));break;}}}_0x1b9ca2['eventRegistrations_']=_0x494c9b;}else _0x1b9ca2['eventRegistrations_']=[];return _0x168a33;}function fr(_0x5d8bfb,_0x5a56b7,_0x5be596,_0x229624){_0x5a56b7['type']===z['MERGE']&&_0x5a56b7['source']['queryId']!==null&&(f(Be(_0x5d8bfb['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x5d8bfb['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3dab58=_0x5d8bfb['viewCache_'],_0x5f3e6d=bu(_0x5d8bfb['processor_'],_0x3dab58,_0x5a56b7,_0x5be596,_0x229624);return Su(_0x5d8bfb['processor_'],_0x5f3e6d['viewCache']),f(_0x5f3e6d['viewCache']['serverCache']['isFullyInitialized']()||!_0x3dab58['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5d8bfb['viewCache_']=_0x5f3e6d['viewCache'],qo(_0x5d8bfb,_0x5f3e6d['changes'],_0x5f3e6d['viewCache']['eventCache']['getNode'](),null);}function Fu(_0x5bb22d,_0x4e71ee){const _0x5ca9a5=_0x5bb22d['viewCache_']['eventCache'],_0x1afbc7=[];return _0x5ca9a5['getNode']()['isLeafNode']()||_0x5ca9a5['getNode']()['forEachChild'](R,(_0x3b0dec,_0x417efa)=>{_0x1afbc7['push'](rt(_0x3b0dec,_0x417efa));}),_0x5ca9a5['isFullyInitialized']()&&_0x1afbc7['push'](Lo(_0x5ca9a5['getNode']())),qo(_0x5bb22d,_0x1afbc7,_0x5ca9a5['getNode'](),_0x4e71ee);}function qo(_0x5b7245,_0x11e611,_0x4d52f8,_0x1ff1bb){const _0x17557e=_0x1ff1bb?[_0x1ff1bb]:_0x5b7245['eventRegistrations_'];return su(_0x5b7245['eventGenerator_'],_0x11e611,_0x4d52f8,_0x17557e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Uu(_0x2ce705){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x2ce705;}function Wu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Bu(_0x3ec954){return _0x3ec954['views']['size']===0x0;}function os(_0x213ff7,_0x2297c8,_0x5b2a0e,_0x54b798){const _0xa5a438=_0x2297c8['source']['queryId'];if(_0xa5a438!==null){const _0x482699=_0x213ff7['views']['get'](_0xa5a438);return f(_0x482699!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x482699,_0x2297c8,_0x5b2a0e,_0x54b798);}else{let _0x1682d2=[];for(const _0x5229c6 of _0x213ff7['views']['values']())_0x1682d2=_0x1682d2['concat'](fr(_0x5229c6,_0x2297c8,_0x5b2a0e,_0x54b798));return _0x1682d2;}}function jo(_0x272c41,_0x3fb6a6,_0x38ffae,_0x5187c9,_0x3b9fef){const _0x5b2a26=_0x3fb6a6['_queryIdentifier'],_0x50df37=_0x272c41['views']['get'](_0x5b2a26);if(!_0x50df37){let _0x1c262b=Cn(_0x38ffae,_0x3b9fef?_0x5187c9:null),_0x4664ad=!0x1;_0x1c262b?_0x4664ad=!0x0:_0x5187c9 instanceof g?(_0x1c262b=is(_0x38ffae,_0x5187c9),_0x4664ad=!0x1):(_0x1c262b=g['EMPTY_NODE'],_0x4664ad=!0x1);const _0x55092a=Un(new Te(_0x1c262b,_0x4664ad,!0x1),new Te(_0x5187c9,_0x3b9fef,!0x1));return new Ou(_0x3fb6a6,_0x55092a);}return _0x50df37;}function Vu(_0x1fadc9,_0x436959,_0x1828ce,_0x39203d,_0x2f3695,_0x2740b2){const _0x55ca7c=jo(_0x1fadc9,_0x436959,_0x39203d,_0x2f3695,_0x2740b2);return _0x1fadc9['views']['has'](_0x436959['_queryIdentifier'])||_0x1fadc9['views']['set'](_0x436959['_queryIdentifier'],_0x55ca7c),xu(_0x55ca7c,_0x1828ce),Fu(_0x55ca7c,_0x1828ce);}function Hu(_0x450599,_0x54713f,_0xbeb9d9,_0x36a85a){const _0x372b3a=_0x54713f['_queryIdentifier'],_0xc3fe9b=[];let _0x5bae96=[];const _0x23f935=Se(_0x450599);if(_0x372b3a==='default'){for(const [_0x583919,_0x14ac2c]of _0x450599['views']['entries']())_0x5bae96=_0x5bae96['concat'](dr(_0x14ac2c,_0xbeb9d9,_0x36a85a)),ur(_0x14ac2c)&&(_0x450599['views']['delete'](_0x583919),_0x14ac2c['query']['_queryParams']['loadsAllData']()||_0xc3fe9b['push'](_0x14ac2c['query']));}else{const _0x42b8f4=_0x450599['views']['get'](_0x372b3a);_0x42b8f4&&(_0x5bae96=_0x5bae96['concat'](dr(_0x42b8f4,_0xbeb9d9,_0x36a85a)),ur(_0x42b8f4)&&(_0x450599['views']['delete'](_0x372b3a),_0x42b8f4['query']['_queryParams']['loadsAllData']()||_0xc3fe9b['push'](_0x42b8f4['query'])));}return _0x23f935&&!Se(_0x450599)&&_0xc3fe9b['push'](new(Wu())(_0x54713f['_repo'],_0x54713f['_path'])),{'removed':_0xc3fe9b,'events':_0x5bae96};}function Ko(_0x1d471c){const _0x82b018=[];for(const _0x4c9c1d of _0x1d471c['views']['values']())_0x4c9c1d['query']['_queryParams']['loadsAllData']()||_0x82b018['push'](_0x4c9c1d);return _0x82b018;}function Ie(_0x131686,_0xd1ad71){let _0x381531=null;for(const _0x3c34a2 of _0x131686['views']['values']())_0x381531=_0x381531||Lu(_0x3c34a2,_0xd1ad71);return _0x381531;}function Yo(_0x447344,_0x26f3a7){if(_0x26f3a7['_queryParams']['loadsAllData']())return Bn(_0x447344);{const _0x498599=_0x26f3a7['_queryIdentifier'];return _0x447344['views']['get'](_0x498599);}}function Qo(_0x5a47bc,_0x1fb9e1){return Yo(_0x5a47bc,_0x1fb9e1)!=null;}function Se(_0x1caff0){return Bn(_0x1caff0)!=null;}function Bn(_0x20deb6){for(const _0x4f9982 of _0x20deb6['views']['values']())if(_0x4f9982['query']['_queryParams']['loadsAllData']())return _0x4f9982;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function $u(_0x559c88){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x559c88;}function Gu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let qu=0x1;class pr{constructor(_0x27c9c1){this['listenProvider_']=_0x27c9c1,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Eu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x210baa,_0x5ce448,_0x13221f,_0x2d0a19,_0x444fef){return cu(_0x210baa['pendingWriteTree_'],_0x5ce448,_0x13221f,_0x2d0a19,_0x444fef),_0x444fef?_t(_0x210baa,new We(es(),_0x5ce448,_0x13221f)):[];}function zu(_0x1ed579,_0x310fc5,_0xc3bf93,_0x554c9c){lu(_0x1ed579['pendingWriteTree_'],_0x310fc5,_0xc3bf93,_0x554c9c);const _0x17f221=b['fromObject'](_0xc3bf93);return _t(_0x1ed579,new ot(es(),_0x310fc5,_0x17f221));}function _e(_0x1acea1,_0x45f056,_0x45c1ff=!0x1){const _0x276845=hu(_0x1acea1['pendingWriteTree_'],_0x45f056);if(uu(_0x1acea1['pendingWriteTree_'],_0x45f056)){let _0x55ece4=new b(null);return _0x276845['snap']!=null?_0x55ece4=_0x55ece4['set'](w(),!0x0):x(_0x276845['children'],_0x50661e=>{_0x55ece4=_0x55ece4['set'](new C(_0x50661e),!0x0);}),_t(_0x1acea1,new In(_0x276845['path'],_0x55ece4,_0x45c1ff));}else return[];}function Kt(_0x513e2e,_0x27e3c4,_0x5b3421){return _t(_0x513e2e,new We(ts(),_0x27e3c4,_0x5b3421));}function ju(_0x166c59,_0xe4d18d,_0x547d88){const _0x3e4bbd=b['fromObject'](_0x547d88);return _t(_0x166c59,new ot(ts(),_0xe4d18d,_0x3e4bbd));}function Ku(_0x5e4b00,_0x506ce8){return _t(_0x5e4b00,new Ft(ts(),_0x506ce8));}function Yu(_0x4b8d74,_0x4ecadc,_0x7fba92){const _0xdfedfd=cs(_0x4b8d74,_0x7fba92);if(_0xdfedfd){const _0x2d689f=ls(_0xdfedfd),_0x1d0f72=_0x2d689f['path'],_0x285fad=_0x2d689f['queryId'],_0x2fcd07=F(_0x1d0f72,_0x4ecadc),_0x40446a=new Ft(ns(_0x285fad),_0x2fcd07);return hs(_0x4b8d74,_0x1d0f72,_0x40446a);}else return[];}function An(_0x4f9296,_0x4b0245,_0x9d6e4d,_0x33d59c,_0x23b7a5=!0x1){const _0x3a4b58=_0x4b0245['_path'],_0x739ea=_0x4f9296['syncPointTree_']['get'](_0x3a4b58);let _0x293a29=[];if(_0x739ea&&(_0x4b0245['_queryIdentifier']==='default'||Qo(_0x739ea,_0x4b0245))){const _0x5c77ee=Hu(_0x739ea,_0x4b0245,_0x9d6e4d,_0x33d59c);Bu(_0x739ea)&&(_0x4f9296['syncPointTree_']=_0x4f9296['syncPointTree_']['remove'](_0x3a4b58));const _0x525613=_0x5c77ee['removed'];if(_0x293a29=_0x5c77ee['events'],!_0x23b7a5){const _0x1b268e=_0x525613['findIndex'](_0x44287b=>_0x44287b['_queryParams']['loadsAllData']())!==-0x1,_0x324ff9=_0x4f9296['syncPointTree_']['findOnPath'](_0x3a4b58,(_0x2361eb,_0x58a404)=>Se(_0x58a404));if(_0x1b268e&&!_0x324ff9){const _0x14b131=_0x4f9296['syncPointTree_']['subtree'](_0x3a4b58);if(!_0x14b131['isEmpty']()){const _0x3175ac=Xu(_0x14b131);for(let _0x3d61b4=0x0;_0x3d61b4<_0x3175ac['length'];++_0x3d61b4){const _0x119e20=_0x3175ac[_0x3d61b4],_0x1898c9=_0x119e20['query'],_0x45de2a=ea(_0x4f9296,_0x119e20);_0x4f9296['listenProvider_']['startListening'](At(_0x1898c9),Ut(_0x4f9296,_0x1898c9),_0x45de2a['hashFn'],_0x45de2a['onComplete']);}}}!_0x324ff9&&_0x525613['length']>0x0&&!_0x33d59c&&(_0x1b268e?_0x4f9296['listenProvider_']['stopListening'](At(_0x4b0245),null):_0x525613['forEach'](_0x45d7fa=>{const _0x36edd1=_0x4f9296['queryToTagMap']['get'](Hn(_0x45d7fa));_0x4f9296['listenProvider_']['stopListening'](At(_0x45d7fa),_0x36edd1);}));}Zu(_0x4f9296,_0x525613);}return _0x293a29;}function Jo(_0x2aac05,_0x366946,_0x387a33,_0x5c454e){const _0x28524a=cs(_0x2aac05,_0x5c454e);if(_0x28524a!=null){const _0x4df5c2=ls(_0x28524a),_0x3a0e4e=_0x4df5c2['path'],_0x3f6ec3=_0x4df5c2['queryId'],_0x22a6f6=F(_0x3a0e4e,_0x366946),_0x810652=new We(ns(_0x3f6ec3),_0x22a6f6,_0x387a33);return hs(_0x2aac05,_0x3a0e4e,_0x810652);}else return[];}function Qu(_0x3ba6c7,_0x402ef8,_0x5ba903,_0x1eeb10){const _0x26a0d2=cs(_0x3ba6c7,_0x1eeb10);if(_0x26a0d2){const _0x4d6cb3=ls(_0x26a0d2),_0x3d5ff8=_0x4d6cb3['path'],_0x37aaef=_0x4d6cb3['queryId'],_0x69c2d5=F(_0x3d5ff8,_0x402ef8),_0x2dc51d=b['fromObject'](_0x5ba903),_0xe8d59e=new ot(ns(_0x37aaef),_0x69c2d5,_0x2dc51d);return hs(_0x3ba6c7,_0x3d5ff8,_0xe8d59e);}else return[];}function Pi(_0x58169b,_0x5b8395,_0x35c24b,_0xe72f07=!0x1){const _0x5ef08b=_0x5b8395['_path'];let _0x598f21=null,_0x1387ef=!0x1;_0x58169b['syncPointTree_']['foreachOnPath'](_0x5ef08b,(_0x573cd4,_0x595075)=>{const _0x34a279=F(_0x573cd4,_0x5ef08b);_0x598f21=_0x598f21||Ie(_0x595075,_0x34a279),_0x1387ef=_0x1387ef||Se(_0x595075);});let _0x205739=_0x58169b['syncPointTree_']['get'](_0x5ef08b);_0x205739?(_0x1387ef=_0x1387ef||Se(_0x205739),_0x598f21=_0x598f21||Ie(_0x205739,w())):(_0x205739=new zo(),_0x58169b['syncPointTree_']=_0x58169b['syncPointTree_']['set'](_0x5ef08b,_0x205739));let _0x3ccaee;_0x598f21!=null?_0x3ccaee=!0x0:(_0x3ccaee=!0x1,_0x598f21=g['EMPTY_NODE'],_0x58169b['syncPointTree_']['subtree'](_0x5ef08b)['foreachChild']((_0x48c72c,_0x28ef7c)=>{const _0x439c57=Ie(_0x28ef7c,w());_0x439c57&&(_0x598f21=_0x598f21['updateImmediateChild'](_0x48c72c,_0x439c57));}));const _0x1b20a3=Qo(_0x205739,_0x5b8395);if(!_0x1b20a3&&!_0x5b8395['_queryParams']['loadsAllData']()){const _0x21f820=Hn(_0x5b8395);f(!_0x58169b['queryToTagMap']['has'](_0x21f820),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2456b6=ed();_0x58169b['queryToTagMap']['set'](_0x21f820,_0x2456b6),_0x58169b['tagToQueryMap']['set'](_0x2456b6,_0x21f820);}const _0x1486d7=Wn(_0x58169b['pendingWriteTree_'],_0x5ef08b);let _0x4e5f6c=Vu(_0x205739,_0x5b8395,_0x35c24b,_0x1486d7,_0x598f21,_0x3ccaee);if(!_0x1b20a3&&!_0x1387ef&&!_0xe72f07){const _0x554efe=Yo(_0x205739,_0x5b8395);_0x4e5f6c=_0x4e5f6c['concat'](td(_0x58169b,_0x5b8395,_0x554efe));}return _0x4e5f6c;}function Vn(_0x2b8b31,_0x5c5458,_0x2f1d66){const _0x213b86=_0x2b8b31['pendingWriteTree_'],_0x5ccbbb=_0x2b8b31['syncPointTree_']['findOnPath'](_0x5c5458,(_0x4575ee,_0x3e473a)=>{const _0x2405e6=F(_0x4575ee,_0x5c5458),_0x2aa3a4=Ie(_0x3e473a,_0x2405e6);if(_0x2aa3a4)return _0x2aa3a4;});return Bo(_0x213b86,_0x5c5458,_0x5ccbbb,_0x2f1d66,!0x0);}function Ju(_0x495592,_0x55ee3f){const _0x300944=_0x55ee3f['_path'];let _0x108f0f=null;_0x495592['syncPointTree_']['foreachOnPath'](_0x300944,(_0x27ebe6,_0x1eb6e6)=>{const _0x5650c6=F(_0x27ebe6,_0x300944);_0x108f0f=_0x108f0f||Ie(_0x1eb6e6,_0x5650c6);});let _0x3e63cf=_0x495592['syncPointTree_']['get'](_0x300944);_0x3e63cf?_0x108f0f=_0x108f0f||Ie(_0x3e63cf,w()):(_0x3e63cf=new zo(),_0x495592['syncPointTree_']=_0x495592['syncPointTree_']['set'](_0x300944,_0x3e63cf));const _0x3a6e8e=_0x108f0f!=null,_0x3f73ca=_0x3a6e8e?new Te(_0x108f0f,!0x0,!0x1):null,_0x16ae83=Wn(_0x495592['pendingWriteTree_'],_0x55ee3f['_path']),_0x1c5fd3=jo(_0x3e63cf,_0x55ee3f,_0x16ae83,_0x3a6e8e?_0x3f73ca['getNode']():g['EMPTY_NODE'],_0x3a6e8e);return Mu(_0x1c5fd3);}function _t(_0x304d3d,_0x34dfa5){return Xo(_0x34dfa5,_0x304d3d['syncPointTree_'],null,Wn(_0x304d3d['pendingWriteTree_'],w()));}function Xo(_0x57f147,_0x2f494e,_0x180fbd,_0x3276ab){if(v(_0x57f147['path']))return Zo(_0x57f147,_0x2f494e,_0x180fbd,_0x3276ab);{const _0x15594f=_0x2f494e['get'](w());_0x180fbd==null&&_0x15594f!=null&&(_0x180fbd=Ie(_0x15594f,w()));let _0x52d080=[];const _0x3c537b=y(_0x57f147['path']),_0x5f0319=_0x57f147['operationForChild'](_0x3c537b),_0xf1d066=_0x2f494e['children']['get'](_0x3c537b);if(_0xf1d066&&_0x5f0319){const _0xebb760=_0x180fbd?_0x180fbd['getImmediateChild'](_0x3c537b):null,_0x3d822a=Vo(_0x3276ab,_0x3c537b);_0x52d080=_0x52d080['concat'](Xo(_0x5f0319,_0xf1d066,_0xebb760,_0x3d822a));}return _0x15594f&&(_0x52d080=_0x52d080['concat'](os(_0x15594f,_0x57f147,_0x3276ab,_0x180fbd))),_0x52d080;}}function Zo(_0x3e748f,_0x4fe9ed,_0x5db43c,_0x6236e7){const _0x5b7f9e=_0x4fe9ed['get'](w());_0x5db43c==null&&_0x5b7f9e!=null&&(_0x5db43c=Ie(_0x5b7f9e,w()));let _0x2cfd6b=[];return _0x4fe9ed['children']['inorderTraversal']((_0x1848b9,_0x3a2263)=>{const _0x41d80b=_0x5db43c?_0x5db43c['getImmediateChild'](_0x1848b9):null,_0x23ec32=Vo(_0x6236e7,_0x1848b9),_0x225f93=_0x3e748f['operationForChild'](_0x1848b9);_0x225f93&&(_0x2cfd6b=_0x2cfd6b['concat'](Zo(_0x225f93,_0x3a2263,_0x41d80b,_0x23ec32)));}),_0x5b7f9e&&(_0x2cfd6b=_0x2cfd6b['concat'](os(_0x5b7f9e,_0x3e748f,_0x6236e7,_0x5db43c))),_0x2cfd6b;}function ea(_0x6a05d7,_0x270c4f){const _0x3ff95b=_0x270c4f['query'],_0x2df0be=Ut(_0x6a05d7,_0x3ff95b);return{'hashFn':()=>(Du(_0x270c4f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x21572c=>{if(_0x21572c==='ok')return _0x2df0be?Yu(_0x6a05d7,_0x3ff95b['_path'],_0x2df0be):Ku(_0x6a05d7,_0x3ff95b['_path']);{const _0x5e99a5=Kl(_0x21572c,_0x3ff95b);return An(_0x6a05d7,_0x3ff95b,null,_0x5e99a5);}}};}function Ut(_0x53337e,_0x2f778a){const _0x57cce7=Hn(_0x2f778a);return _0x53337e['queryToTagMap']['get'](_0x57cce7);}function Hn(_0x1a50b7){return _0x1a50b7['_path']['toString']()+'$'+_0x1a50b7['_queryIdentifier'];}function cs(_0x4fe56a,_0x3185dd){return _0x4fe56a['tagToQueryMap']['get'](_0x3185dd);}function ls(_0x298beb){const _0x563aff=_0x298beb['indexOf']('$');return f(_0x563aff!==-0x1&&_0x563aff<_0x298beb['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x298beb['substr'](_0x563aff+0x1),'path':new C(_0x298beb['substr'](0x0,_0x563aff))};}function hs(_0x230cf6,_0xabb4f9,_0x268d4e){const _0x3f4f5c=_0x230cf6['syncPointTree_']['get'](_0xabb4f9);f(_0x3f4f5c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3ae14b=Wn(_0x230cf6['pendingWriteTree_'],_0xabb4f9);return os(_0x3f4f5c,_0x268d4e,_0x3ae14b,null);}function Xu(_0x33a76b){return _0x33a76b['fold']((_0x4e34d2,_0x29e223,_0xa1c52c)=>{if(_0x29e223&&Se(_0x29e223))return[Bn(_0x29e223)];{let _0x218e38=[];return _0x29e223&&(_0x218e38=Ko(_0x29e223)),x(_0xa1c52c,(_0x12adbb,_0xf5550b)=>{_0x218e38=_0x218e38['concat'](_0xf5550b);}),_0x218e38;}});}function At(_0x1c11ce){return _0x1c11ce['_queryParams']['loadsAllData']()&&!_0x1c11ce['_queryParams']['isDefault']()?new(Gu())(_0x1c11ce['_repo'],_0x1c11ce['_path']):_0x1c11ce;}function Zu(_0x1e74d0,_0xe2b4d4){for(let _0x5de779=0x0;_0x5de779<_0xe2b4d4['length'];++_0x5de779){const _0x2f9314=_0xe2b4d4[_0x5de779];if(!_0x2f9314['_queryParams']['loadsAllData']()){const _0x25e4bc=Hn(_0x2f9314),_0x2a879a=_0x1e74d0['queryToTagMap']['get'](_0x25e4bc);_0x1e74d0['queryToTagMap']['delete'](_0x25e4bc),_0x1e74d0['tagToQueryMap']['delete'](_0x2a879a);}}}function ed(){return qu++;}function td(_0x9101dc,_0x356c6d,_0x56b321){const _0x3ac87a=_0x356c6d['_path'],_0x12398d=Ut(_0x9101dc,_0x356c6d),_0x1995f6=ea(_0x9101dc,_0x56b321),_0x129c01=_0x9101dc['listenProvider_']['startListening'](At(_0x356c6d),_0x12398d,_0x1995f6['hashFn'],_0x1995f6['onComplete']),_0x8d498f=_0x9101dc['syncPointTree_']['subtree'](_0x3ac87a);if(_0x12398d)f(!Se(_0x8d498f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x41b895=_0x8d498f['fold']((_0x96824c,_0x56effb,_0x1d8c36)=>{if(!v(_0x96824c)&&_0x56effb&&Se(_0x56effb))return[Bn(_0x56effb)['query']];{let _0x4be5cc=[];return _0x56effb&&(_0x4be5cc=_0x4be5cc['concat'](Ko(_0x56effb)['map'](_0x22d478=>_0x22d478['query']))),x(_0x1d8c36,(_0x3e9d2d,_0x425ad1)=>{_0x4be5cc=_0x4be5cc['concat'](_0x425ad1);}),_0x4be5cc;}});for(let _0x16bdfd=0x0;_0x16bdfd<_0x41b895['length'];++_0x16bdfd){const _0x1ba0d1=_0x41b895[_0x16bdfd];_0x9101dc['listenProvider_']['stopListening'](At(_0x1ba0d1),Ut(_0x9101dc,_0x1ba0d1));}}return _0x129c01;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x1c87b5){this['node_']=_0x1c87b5;}['getImmediateChild'](_0x5c5c41){const _0x48eca6=this['node_']['getImmediateChild'](_0x5c5c41);return new us(_0x48eca6);}['node'](){return this['node_'];}}class ds{constructor(_0x364936,_0x34c7c4){this['syncTree_']=_0x364936,this['path_']=_0x34c7c4;}['getImmediateChild'](_0x3e50e2){const _0x108c5b=k(this['path_'],_0x3e50e2);return new ds(this['syncTree_'],_0x108c5b);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const nd=function(_0xb5f46a){return _0xb5f46a=_0xb5f46a||{},_0xb5f46a['timestamp']=_0xb5f46a['timestamp']||new Date()['getTime'](),_0xb5f46a;},_r=function(_0x3d0c14,_0x4b1953,_0x79554a){if(!_0x3d0c14||typeof _0x3d0c14!='object')return _0x3d0c14;if(f('.sv'in _0x3d0c14,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3d0c14['.sv']=='string')return id(_0x3d0c14['.sv'],_0x4b1953,_0x79554a);if(typeof _0x3d0c14['.sv']=='object')return sd(_0x3d0c14['.sv'],_0x4b1953);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3d0c14,null,0x2));},id=function(_0x1df58a,_0x588abe,_0x2f3729){switch(_0x1df58a){case'timestamp':return _0x2f3729['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1df58a);}},sd=function(_0xc6e1da,_0x730e49,_0x469229){_0xc6e1da['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xc6e1da,null,0x2));const _0x47f508=_0xc6e1da['increment'];typeof _0x47f508!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x47f508);const _0x54b2d7=_0x730e49['node']();if(f(_0x54b2d7!==null&&typeof _0x54b2d7<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x54b2d7['isLeafNode']())return _0x47f508;const _0x436827=_0x54b2d7['getValue']();return typeof _0x436827!='number'?_0x47f508:_0x436827+_0x47f508;},ta=function(_0x3a1bd0,_0x416f76,_0x3c554b,_0xfd6ef8){return ps(_0x416f76,new ds(_0x3c554b,_0x3a1bd0),_0xfd6ef8);},fs=function(_0x50eddf,_0x5bd9d1,_0x18ba0e){return ps(_0x50eddf,new us(_0x5bd9d1),_0x18ba0e);};function ps(_0x4e7e0c,_0x9d7aae,_0x23c751){const _0x397938=_0x4e7e0c['getPriority']()['val'](),_0x5d2c80=_r(_0x397938,_0x9d7aae['getImmediateChild']('.priority'),_0x23c751);let _0x2377c3;if(_0x4e7e0c['isLeafNode']()){const _0x120714=_0x4e7e0c,_0x2d5488=_r(_0x120714['getValue'](),_0x9d7aae,_0x23c751);return _0x2d5488!==_0x120714['getValue']()||_0x5d2c80!==_0x120714['getPriority']()['val']()?new D(_0x2d5488,A(_0x5d2c80)):_0x4e7e0c;}else{const _0xa1aa2b=_0x4e7e0c;return _0x2377c3=_0xa1aa2b,_0x5d2c80!==_0xa1aa2b['getPriority']()['val']()&&(_0x2377c3=_0x2377c3['updatePriority'](new D(_0x5d2c80))),_0xa1aa2b['forEachChild'](R,(_0x29eebb,_0x8527da)=>{const _0x3aeddc=ps(_0x8527da,_0x9d7aae['getImmediateChild'](_0x29eebb),_0x23c751);_0x3aeddc!==_0x8527da&&(_0x2377c3=_0x2377c3['updateImmediateChild'](_0x29eebb,_0x3aeddc));}),_0x2377c3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x1f43a2='',_0x5c7352=null,_0x3474ad={'children':{},'childCount':0x0}){this['name']=_0x1f43a2,this['parent']=_0x5c7352,this['node']=_0x3474ad;}}function $n(_0x570e12,_0x526b6e){let _0x44be14=_0x526b6e instanceof C?_0x526b6e:new C(_0x526b6e),_0x273f7f=_0x570e12,_0x2451fc=y(_0x44be14);for(;_0x2451fc!==null;){const _0x23006b=Me(_0x273f7f['node']['children'],_0x2451fc)||{'children':{},'childCount':0x0};_0x273f7f=new _s(_0x2451fc,_0x273f7f,_0x23006b),_0x44be14=S(_0x44be14),_0x2451fc=y(_0x44be14);}return _0x273f7f;}function ze(_0x57e968){return _0x57e968['node']['value'];}function gs(_0x3a020e,_0x437a96){_0x3a020e['node']['value']=_0x437a96,Oi(_0x3a020e);}function na(_0x271730){return _0x271730['node']['childCount']>0x0;}function rd(_0x45cb73){return ze(_0x45cb73)===void 0x0&&!na(_0x45cb73);}function Gn(_0x4116d0,_0x14934b){x(_0x4116d0['node']['children'],(_0x4536db,_0x121b60)=>{_0x14934b(new _s(_0x4536db,_0x4116d0,_0x121b60));});}function ia(_0x1e13b6,_0x19f823,_0x4c463c,_0x48624d){_0x4c463c&&_0x19f823(_0x1e13b6),Gn(_0x1e13b6,_0x42634e=>{ia(_0x42634e,_0x19f823,!0x0);});}function od(_0x302f34,_0x34ccf9,_0x2047d2){let _0x256555=_0x302f34['parent'];for(;_0x256555!==null;){if(_0x34ccf9(_0x256555))return!0x0;_0x256555=_0x256555['parent'];}return!0x1;}function Yt(_0x19babb){return new C(_0x19babb['parent']===null?_0x19babb['name']:Yt(_0x19babb['parent'])+'/'+_0x19babb['name']);}function Oi(_0xd471ba){_0xd471ba['parent']!==null&&ad(_0xd471ba['parent'],_0xd471ba['name'],_0xd471ba);}function ad(_0x4574f2,_0x2c2716,_0x50518a){const _0x17bb20=rd(_0x50518a),_0x1d3aeb=Q(_0x4574f2['node']['children'],_0x2c2716);_0x17bb20&&_0x1d3aeb?(delete _0x4574f2['node']['children'][_0x2c2716],_0x4574f2['node']['childCount']--,Oi(_0x4574f2)):!_0x17bb20&&!_0x1d3aeb&&(_0x4574f2['node']['children'][_0x2c2716]=_0x50518a['node'],_0x4574f2['node']['childCount']++,Oi(_0x4574f2));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cd=/[\[\].#$\/\u0000-\u001F\u007F]/,ld=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x145fde){return typeof _0x145fde=='string'&&_0x145fde['length']!==0x0&&!cd['test'](_0x145fde);},sa=function(_0x4a6691){return typeof _0x4a6691=='string'&&_0x4a6691['length']!==0x0&&!ld['test'](_0x4a6691);},hd=function(_0x3a5dc6){return _0x3a5dc6&&(_0x3a5dc6=_0x3a5dc6['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3a5dc6);},Wt=function(_0x5e890e){return _0x5e890e===null||typeof _0x5e890e=='string'||typeof _0x5e890e=='number'&&!xn(_0x5e890e)||_0x5e890e&&typeof _0x5e890e=='object'&&Q(_0x5e890e,'.sv');},Ve=function(_0x278688,_0x4c192c,_0x219c9b,_0x362d78){_0x362d78&&_0x4c192c===void 0x0||Qt(it(_0x278688,'value'),_0x4c192c,_0x219c9b);},Qt=function(_0x268ab2,_0x14c938,_0x4ce1b4){const _0x50becf=_0x4ce1b4 instanceof C?new Ah(_0x4ce1b4,_0x268ab2):_0x4ce1b4;if(_0x14c938===void 0x0)throw new Error(_0x268ab2+'contains\x20undefined\x20'+Pe(_0x50becf));if(typeof _0x14c938=='function')throw new Error(_0x268ab2+'contains\x20a\x20function\x20'+Pe(_0x50becf)+'\x20with\x20contents\x20=\x20'+_0x14c938['toString']());if(xn(_0x14c938))throw new Error(_0x268ab2+'contains\x20'+_0x14c938['toString']()+'\x20'+Pe(_0x50becf));if(typeof _0x14c938=='string'&&_0x14c938['length']>ui/0x3&&Ln(_0x14c938)>ui)throw new Error(_0x268ab2+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x50becf)+'\x20(\x27'+_0x14c938['substring'](0x0,0x32)+'...\x27)');if(_0x14c938&&typeof _0x14c938=='object'){let _0x43f163=!0x1,_0x502cd4=!0x1;if(x(_0x14c938,(_0x4e1d20,_0x474a71)=>{if(_0x4e1d20==='.value')_0x43f163=!0x0;else{if(_0x4e1d20!=='.priority'&&_0x4e1d20!=='.sv'&&(_0x502cd4=!0x0,!ms(_0x4e1d20)))throw new Error(_0x268ab2+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4e1d20+')\x20'+Pe(_0x50becf)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x50becf,_0x4e1d20),Qt(_0x268ab2,_0x474a71,_0x50becf),Nh(_0x50becf);}),_0x43f163&&_0x502cd4)throw new Error(_0x268ab2+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x50becf)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ud=function(_0x4a8b5a,_0x460905){let _0x427799,_0x3b8168;for(_0x427799=0x0;_0x427799<_0x460905['length'];_0x427799++){_0x3b8168=_0x460905[_0x427799];const _0x38512b=Dt(_0x3b8168);for(let _0x55fac6=0x0;_0x55fac6<_0x38512b['length'];_0x55fac6++)if(!(_0x38512b[_0x55fac6]==='.priority'&&_0x55fac6===_0x38512b['length']-0x1)){if(!ms(_0x38512b[_0x55fac6]))throw new Error(_0x4a8b5a+'contains\x20an\x20invalid\x20key\x20('+_0x38512b[_0x55fac6]+')\x20in\x20path\x20'+_0x3b8168['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x460905['sort'](Rh);let _0x538aeb=null;for(_0x427799=0x0;_0x427799<_0x460905['length'];_0x427799++){if(_0x3b8168=_0x460905[_0x427799],_0x538aeb!==null&&G(_0x538aeb,_0x3b8168))throw new Error(_0x4a8b5a+'contains\x20a\x20path\x20'+_0x538aeb['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3b8168['toString']());_0x538aeb=_0x3b8168;}},ra=function(_0x324e5c,_0x2e2bff,_0x2fbd15,_0x24a1f5){const _0xab3f7e=it(_0x324e5c,'values');if(!(_0x2e2bff&&typeof _0x2e2bff=='object')||Array['isArray'](_0x2e2bff))throw new Error(_0xab3f7e+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2de680=[];x(_0x2e2bff,(_0x55da2f,_0x25fbc8)=>{const _0x32ad17=new C(_0x55da2f);if(Qt(_0xab3f7e,_0x25fbc8,k(_0x2fbd15,_0x32ad17)),ji(_0x32ad17)==='.priority'&&!Wt(_0x25fbc8))throw new Error(_0xab3f7e+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x32ad17['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2de680['push'](_0x32ad17);}),ud(_0xab3f7e,_0x2de680);},dd=function(_0x20bd06,_0x277f29,_0x6794b2){if(xn(_0x277f29))throw new Error(it(_0x20bd06,'priority')+'is\x20'+_0x277f29['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x277f29))throw new Error(it(_0x20bd06,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x24387f,_0x1e6abb,_0x5c372e,_0x1fba33){if(!sa(_0x5c372e))throw new Error(it(_0x24387f,_0x1e6abb)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5c372e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},fd=function(_0x35999c,_0x21a5c4,_0x1af8df,_0x52f46e){_0x1af8df&&(_0x1af8df=_0x1af8df['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x35999c,_0x21a5c4,_0x1af8df);},De=function(_0x4c698c,_0x426e27){if(y(_0x426e27)==='.info')throw new Error(_0x4c698c+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},pd=function(_0x3fbfa3,_0x288da8){const _0x26a261=_0x288da8['path']['toString']();if(typeof _0x288da8['repoInfo']['host']!='string'||_0x288da8['repoInfo']['host']['length']===0x0||!ms(_0x288da8['repoInfo']['namespace'])&&_0x288da8['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x26a261['length']!==0x0&&!hd(_0x26a261))throw new Error(it(_0x3fbfa3,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _d{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0xd31085,_0x372541){let _0x144707=null;for(let _0x54da9b=0x0;_0x54da9b<_0x372541['length'];_0x54da9b++){const _0x47b1f0=_0x372541[_0x54da9b],_0x1e3a80=_0x47b1f0['getPath']();_0x144707!==null&&!Ki(_0x1e3a80,_0x144707['path'])&&(_0xd31085['eventLists_']['push'](_0x144707),_0x144707=null),_0x144707===null&&(_0x144707={'events':[],'path':_0x1e3a80}),_0x144707['events']['push'](_0x47b1f0);}_0x144707&&_0xd31085['eventLists_']['push'](_0x144707);}function oa(_0x6bf4e1,_0x4b8083,_0x2fb4ce){qn(_0x6bf4e1,_0x2fb4ce),aa(_0x6bf4e1,_0x4100c5=>Ki(_0x4100c5,_0x4b8083));}function V(_0x4bf492,_0x5a755b,_0x81e5b3){qn(_0x4bf492,_0x81e5b3),aa(_0x4bf492,_0x654780=>G(_0x654780,_0x5a755b)||G(_0x5a755b,_0x654780));}function aa(_0x2383c8,_0x2b256c){_0x2383c8['recursionDepth_']++;let _0x56809f=!0x0;for(let _0x7761b9=0x0;_0x7761b9<_0x2383c8['eventLists_']['length'];_0x7761b9++){const _0x3f0119=_0x2383c8['eventLists_'][_0x7761b9];if(_0x3f0119){const _0x358b2e=_0x3f0119['path'];_0x2b256c(_0x358b2e)?(gd(_0x2383c8['eventLists_'][_0x7761b9]),_0x2383c8['eventLists_'][_0x7761b9]=null):_0x56809f=!0x1;}}_0x56809f&&(_0x2383c8['eventLists_']=[]),_0x2383c8['recursionDepth_']--;}function gd(_0x42e036){for(let _0x168899=0x0;_0x168899<_0x42e036['events']['length'];_0x168899++){const _0x4ac727=_0x42e036['events'][_0x168899];if(_0x4ac727!==null){_0x42e036['events'][_0x168899]=null;const _0xfbb24e=_0x4ac727['getEventRunner']();Tt&&L('event:\x20'+_0x4ac727['toString']()),ft(_0xfbb24e);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',md=0x19;class yd{constructor(_0x473e97,_0x20836a,_0x57bc83,_0x596008){this['repoInfo_']=_0x473e97,this['forceRestClient_']=_0x20836a,this['authTokenProvider_']=_0x57bc83,this['appCheckProvider_']=_0x596008,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new _d(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function vd(_0xf53d51,_0xdc21cd,_0x42a32b){if(_0xf53d51['stats_']=qi(_0xf53d51['repoInfo_']),_0xf53d51['forceRestClient_']||Xl())_0xf53d51['server_']=new vn(_0xf53d51['repoInfo_'],(_0x125d78,_0x7f0e61,_0x365ad5,_0x3731ba)=>{gr(_0xf53d51,_0x125d78,_0x7f0e61,_0x365ad5,_0x3731ba);},_0xf53d51['authTokenProvider_'],_0xf53d51['appCheckProvider_']),setTimeout(()=>mr(_0xf53d51,!0x0),0x0);else{if(typeof _0x42a32b<'u'&&_0x42a32b!==null){if(typeof _0x42a32b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x42a32b);}catch(_0x3f64b4){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3f64b4);}}_0xf53d51['persistentConnection_']=new se(_0xf53d51['repoInfo_'],_0xdc21cd,(_0x359833,_0x278834,_0x238007,_0x34f8c3)=>{gr(_0xf53d51,_0x359833,_0x278834,_0x238007,_0x34f8c3);},_0x22a923=>{mr(_0xf53d51,_0x22a923);},_0x2bc893=>{Ed(_0xf53d51,_0x2bc893);},_0xf53d51['authTokenProvider_'],_0xf53d51['appCheckProvider_'],_0x42a32b),_0xf53d51['server_']=_0xf53d51['persistentConnection_'];}_0xf53d51['authTokenProvider_']['addTokenChangeListener'](_0x567777=>{_0xf53d51['server_']['refreshAuthToken'](_0x567777);}),_0xf53d51['appCheckProvider_']['addTokenChangeListener'](_0x3861ce=>{_0xf53d51['server_']['refreshAppCheckToken'](_0x3861ce['token']);}),_0xf53d51['statsReporter_']=ih(_0xf53d51['repoInfo_'],()=>new nu(_0xf53d51['stats_'],_0xf53d51['server_'])),_0xf53d51['infoData_']=new Jh(),_0xf53d51['infoSyncTree_']=new pr({'startListening':(_0x2d3964,_0x716d91,_0x444c0a,_0x572466)=>{let _0x59bfbf=[];const _0x2f1b96=_0xf53d51['infoData_']['getNode'](_0x2d3964['_path']);return _0x2f1b96['isEmpty']()||(_0x59bfbf=Kt(_0xf53d51['infoSyncTree_'],_0x2d3964['_path'],_0x2f1b96),setTimeout(()=>{_0x572466('ok');},0x0)),_0x59bfbf;},'stopListening':()=>{}}),vs(_0xf53d51,'connected',!0x1),_0xf53d51['serverSyncTree_']=new pr({'startListening':(_0x42e637,_0x4118ce,_0x5c4da9,_0x5477bd)=>(_0xf53d51['server_']['listen'](_0x42e637,_0x5c4da9,_0x4118ce,(_0x255301,_0x26ce53)=>{const _0x14ffb5=_0x5477bd(_0x255301,_0x26ce53);V(_0xf53d51['eventQueue_'],_0x42e637['_path'],_0x14ffb5);}),[]),'stopListening':(_0x4cfd2d,_0x334682)=>{_0xf53d51['server_']['unlisten'](_0x4cfd2d,_0x334682);}});}function la(_0x22ad64){const _0x2eda18=_0x22ad64['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2eda18;}function Jt(_0x589709){return nd({'timestamp':la(_0x589709)});}function gr(_0x4ab86f,_0x33d109,_0x23b3e9,_0x4446dd,_0x4d008a){_0x4ab86f['dataUpdateCount']++;const _0x12ff20=new C(_0x33d109);_0x23b3e9=_0x4ab86f['interceptServerDataCallback_']?_0x4ab86f['interceptServerDataCallback_'](_0x33d109,_0x23b3e9):_0x23b3e9;let _0x1b4d93=[];if(_0x4d008a){if(_0x4446dd){const _0x21ed50=_n(_0x23b3e9,_0x4bd954=>A(_0x4bd954));_0x1b4d93=Qu(_0x4ab86f['serverSyncTree_'],_0x12ff20,_0x21ed50,_0x4d008a);}else{const _0x41fc66=A(_0x23b3e9);_0x1b4d93=Jo(_0x4ab86f['serverSyncTree_'],_0x12ff20,_0x41fc66,_0x4d008a);}}else{if(_0x4446dd){const _0x5a5b53=_n(_0x23b3e9,_0x526a45=>A(_0x526a45));_0x1b4d93=ju(_0x4ab86f['serverSyncTree_'],_0x12ff20,_0x5a5b53);}else{const _0x4e29c7=A(_0x23b3e9);_0x1b4d93=Kt(_0x4ab86f['serverSyncTree_'],_0x12ff20,_0x4e29c7);}}let _0x336681=_0x12ff20;_0x1b4d93['length']>0x0&&(_0x336681=ct(_0x4ab86f,_0x12ff20)),V(_0x4ab86f['eventQueue_'],_0x336681,_0x1b4d93);}function mr(_0x4d571f,_0x2f9c6f){vs(_0x4d571f,'connected',_0x2f9c6f),_0x2f9c6f===!0x1&&Td(_0x4d571f);}function Ed(_0xde9637,_0x54799d){x(_0x54799d,(_0x4accc3,_0xb14050)=>{vs(_0xde9637,_0x4accc3,_0xb14050);});}function vs(_0x380745,_0x5ee929,_0x56d0c9){const _0x232601=new C('/.info/'+_0x5ee929),_0x419320=A(_0x56d0c9);_0x380745['infoData_']['updateSnapshot'](_0x232601,_0x419320);const _0x1136a6=Kt(_0x380745['infoSyncTree_'],_0x232601,_0x419320);V(_0x380745['eventQueue_'],_0x232601,_0x1136a6);}function zn(_0x48b2df){return _0x48b2df['nextWriteId_']++;}function Id(_0x1f0a0b,_0x16a881,_0x4c03f7){const _0x4d1cfa=Ju(_0x1f0a0b['serverSyncTree_'],_0x16a881);return _0x4d1cfa!=null?Promise['resolve'](_0x4d1cfa):_0x1f0a0b['server_']['get'](_0x16a881)['then'](_0x3bf327=>{const _0x525692=A(_0x3bf327)['withIndex'](_0x16a881['_queryParams']['getIndex']());Pi(_0x1f0a0b['serverSyncTree_'],_0x16a881,_0x4c03f7,!0x0);let _0x1286f8;if(_0x16a881['_queryParams']['loadsAllData']())_0x1286f8=Kt(_0x1f0a0b['serverSyncTree_'],_0x16a881['_path'],_0x525692);else{const _0x3e2055=Ut(_0x1f0a0b['serverSyncTree_'],_0x16a881);_0x1286f8=Jo(_0x1f0a0b['serverSyncTree_'],_0x16a881['_path'],_0x525692,_0x3e2055);}return V(_0x1f0a0b['eventQueue_'],_0x16a881['_path'],_0x1286f8),An(_0x1f0a0b['serverSyncTree_'],_0x16a881,_0x4c03f7,null,!0x0),_0x525692;},_0x200f05=>(gt(_0x1f0a0b,'get\x20for\x20query\x20'+O(_0x16a881)+'\x20failed:\x20'+_0x200f05),Promise['reject'](new Error(_0x200f05))));}function wd(_0x407cae,_0x235af2,_0x1270c7,_0x209235,_0x16b18c){gt(_0x407cae,'set',{'path':_0x235af2['toString'](),'value':_0x1270c7,'priority':_0x209235});const _0x539cf0=Jt(_0x407cae),_0x2cc0ff=A(_0x1270c7,_0x209235),_0x2f278e=Vn(_0x407cae['serverSyncTree_'],_0x235af2),_0x516176=fs(_0x2cc0ff,_0x2f278e,_0x539cf0),_0x5b8a91=zn(_0x407cae),_0x20c62c=as(_0x407cae['serverSyncTree_'],_0x235af2,_0x516176,_0x5b8a91,!0x0);qn(_0x407cae['eventQueue_'],_0x20c62c),_0x407cae['server_']['put'](_0x235af2['toString'](),_0x2cc0ff['val'](!0x0),(_0x212ba2,_0xf4cdb1)=>{const _0x94da7f=_0x212ba2==='ok';_0x94da7f||U('set\x20at\x20'+_0x235af2+'\x20failed:\x20'+_0x212ba2);const _0x31d54d=_e(_0x407cae['serverSyncTree_'],_0x5b8a91,!_0x94da7f);V(_0x407cae['eventQueue_'],_0x235af2,_0x31d54d),be(_0x407cae,_0x16b18c,_0x212ba2,_0xf4cdb1);});const _0x21134d=Is(_0x407cae,_0x235af2);ct(_0x407cae,_0x21134d),V(_0x407cae['eventQueue_'],_0x21134d,[]);}function Cd(_0x5370b7,_0x26bdd9,_0x2071f5,_0x200eeb){gt(_0x5370b7,'update',{'path':_0x26bdd9['toString'](),'value':_0x2071f5});let _0x4b6bd1=!0x0;const _0x1a8c41=Jt(_0x5370b7),_0x27347a={};if(x(_0x2071f5,(_0x187e5a,_0x564834)=>{_0x4b6bd1=!0x1,_0x27347a[_0x187e5a]=ta(k(_0x26bdd9,_0x187e5a),A(_0x564834),_0x5370b7['serverSyncTree_'],_0x1a8c41);}),_0x4b6bd1)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x5370b7,_0x200eeb,'ok',void 0x0);else{const _0x150948=zn(_0x5370b7),_0x118791=zu(_0x5370b7['serverSyncTree_'],_0x26bdd9,_0x27347a,_0x150948);qn(_0x5370b7['eventQueue_'],_0x118791),_0x5370b7['server_']['merge'](_0x26bdd9['toString'](),_0x2071f5,(_0x3412aa,_0x2c584e)=>{const _0x45a80b=_0x3412aa==='ok';_0x45a80b||U('update\x20at\x20'+_0x26bdd9+'\x20failed:\x20'+_0x3412aa);const _0x134577=_e(_0x5370b7['serverSyncTree_'],_0x150948,!_0x45a80b),_0x58aac4=_0x134577['length']>0x0?ct(_0x5370b7,_0x26bdd9):_0x26bdd9;V(_0x5370b7['eventQueue_'],_0x58aac4,_0x134577),be(_0x5370b7,_0x200eeb,_0x3412aa,_0x2c584e);}),x(_0x2071f5,_0x4f15e1=>{const _0x47544f=Is(_0x5370b7,k(_0x26bdd9,_0x4f15e1));ct(_0x5370b7,_0x47544f);}),V(_0x5370b7['eventQueue_'],_0x26bdd9,[]);}}function Td(_0x153e77){gt(_0x153e77,'onDisconnectEvents');const _0x107feb=Jt(_0x153e77),_0x59b19e=En();Si(_0x153e77['onDisconnect_'],w(),(_0x1ef7e0,_0x3bef1d)=>{const _0xcf0225=ta(_0x1ef7e0,_0x3bef1d,_0x153e77['serverSyncTree_'],_0x107feb);pt(_0x59b19e,_0x1ef7e0,_0xcf0225);});let _0xf1471e=[];Si(_0x59b19e,w(),(_0x2e0163,_0x16e7aa)=>{_0xf1471e=_0xf1471e['concat'](Kt(_0x153e77['serverSyncTree_'],_0x2e0163,_0x16e7aa));const _0x3a9113=Is(_0x153e77,_0x2e0163);ct(_0x153e77,_0x3a9113);}),_0x153e77['onDisconnect_']=En(),V(_0x153e77['eventQueue_'],w(),_0xf1471e);}function Sd(_0x4436e9,_0x98fe1b,_0x22a500){_0x4436e9['server_']['onDisconnectCancel'](_0x98fe1b['toString'](),(_0x1c03a6,_0xbb3598)=>{_0x1c03a6==='ok'&&Ti(_0x4436e9['onDisconnect_'],_0x98fe1b),be(_0x4436e9,_0x22a500,_0x1c03a6,_0xbb3598);});}function yr(_0x457841,_0x2ddc0c,_0x51114c,_0xa7e269){const _0x2196aa=A(_0x51114c);_0x457841['server_']['onDisconnectPut'](_0x2ddc0c['toString'](),_0x2196aa['val'](!0x0),(_0x3a0d65,_0x38349d)=>{_0x3a0d65==='ok'&&pt(_0x457841['onDisconnect_'],_0x2ddc0c,_0x2196aa),be(_0x457841,_0xa7e269,_0x3a0d65,_0x38349d);});}function bd(_0x4e9bac,_0x53098e,_0x516fdf,_0x5c85e2,_0xc654ef){const _0x1c90c7=A(_0x516fdf,_0x5c85e2);_0x4e9bac['server_']['onDisconnectPut'](_0x53098e['toString'](),_0x1c90c7['val'](!0x0),(_0x2404ed,_0x23b4ae)=>{_0x2404ed==='ok'&&pt(_0x4e9bac['onDisconnect_'],_0x53098e,_0x1c90c7),be(_0x4e9bac,_0xc654ef,_0x2404ed,_0x23b4ae);});}function Rd(_0x2c9bfc,_0x108394,_0x2abe64,_0x4a65a9){if(pn(_0x2abe64)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2c9bfc,_0x4a65a9,'ok',void 0x0);return;}_0x2c9bfc['server_']['onDisconnectMerge'](_0x108394['toString'](),_0x2abe64,(_0x23b8fb,_0x4defbb)=>{_0x23b8fb==='ok'&&x(_0x2abe64,(_0x16cf57,_0x32c0c1)=>{const _0x5a4aec=A(_0x32c0c1);pt(_0x2c9bfc['onDisconnect_'],k(_0x108394,_0x16cf57),_0x5a4aec);}),be(_0x2c9bfc,_0x4a65a9,_0x23b8fb,_0x4defbb);});}function Ad(_0x50d084,_0xff5564,_0x4ca771){let _0xd467a5;y(_0xff5564['_path'])==='.info'?_0xd467a5=Pi(_0x50d084['infoSyncTree_'],_0xff5564,_0x4ca771):_0xd467a5=Pi(_0x50d084['serverSyncTree_'],_0xff5564,_0x4ca771),oa(_0x50d084['eventQueue_'],_0xff5564['_path'],_0xd467a5);}function kd(_0x5230af,_0x6c4e48,_0xcc07ef){let _0x29cf08;y(_0x6c4e48['_path'])==='.info'?_0x29cf08=An(_0x5230af['infoSyncTree_'],_0x6c4e48,_0xcc07ef):_0x29cf08=An(_0x5230af['serverSyncTree_'],_0x6c4e48,_0xcc07ef),oa(_0x5230af['eventQueue_'],_0x6c4e48['_path'],_0x29cf08);}function ha(_0x5c164e){_0x5c164e['persistentConnection_']&&_0x5c164e['persistentConnection_']['interrupt'](ca);}function Nd(_0x242b6d){_0x242b6d['persistentConnection_']&&_0x242b6d['persistentConnection_']['resume'](ca);}function gt(_0x42ced3,..._0x107471){let _0x43b250='';_0x42ced3['persistentConnection_']&&(_0x43b250=_0x42ced3['persistentConnection_']['id']+':'),L(_0x43b250,..._0x107471);}function be(_0x2a9bba,_0x146aab,_0xc92b0e,_0x3ae2d4){_0x146aab&&ft(()=>{if(_0xc92b0e==='ok')_0x146aab(null);else{const _0x5a4f70=(_0xc92b0e||'error')['toUpperCase']();let _0x5ec0da=_0x5a4f70;_0x3ae2d4&&(_0x5ec0da+=':\x20'+_0x3ae2d4);const _0x15f5f1=new Error(_0x5ec0da);_0x15f5f1['code']=_0x5a4f70,_0x146aab(_0x15f5f1);}});}function Pd(_0x329b88,_0x19c253,_0x3c57a4,_0x26e60d,_0x2103d3,_0x240d30){gt(_0x329b88,'transaction\x20on\x20'+_0x19c253);const _0xd607ac={'path':_0x19c253,'update':_0x3c57a4,'onComplete':_0x26e60d,'status':null,'order':so(),'applyLocally':_0x240d30,'retryCount':0x0,'unwatcher':_0x2103d3,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1287bd=Es(_0x329b88,_0x19c253,void 0x0);_0xd607ac['currentInputSnapshot']=_0x1287bd;const _0x11f3e3=_0xd607ac['update'](_0x1287bd['val']());if(_0x11f3e3===void 0x0)_0xd607ac['unwatcher'](),_0xd607ac['currentOutputSnapshotRaw']=null,_0xd607ac['currentOutputSnapshotResolved']=null,_0xd607ac['onComplete']&&_0xd607ac['onComplete'](null,!0x1,_0xd607ac['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x11f3e3,_0xd607ac['path']),_0xd607ac['status']=0x0;const _0x491d8b=$n(_0x329b88['transactionQueueTree_'],_0x19c253),_0x1f1753=ze(_0x491d8b)||[];_0x1f1753['push'](_0xd607ac),gs(_0x491d8b,_0x1f1753);let _0x5d70c2;typeof _0x11f3e3=='object'&&_0x11f3e3!==null&&Q(_0x11f3e3,'.priority')?(_0x5d70c2=Me(_0x11f3e3,'.priority'),f(Wt(_0x5d70c2),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5d70c2=(Vn(_0x329b88['serverSyncTree_'],_0x19c253)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1ccf79=Jt(_0x329b88),_0x384930=A(_0x11f3e3,_0x5d70c2),_0x433526=fs(_0x384930,_0x1287bd,_0x1ccf79);_0xd607ac['currentOutputSnapshotRaw']=_0x384930,_0xd607ac['currentOutputSnapshotResolved']=_0x433526,_0xd607ac['currentWriteId']=zn(_0x329b88);const _0x2cb585=as(_0x329b88['serverSyncTree_'],_0x19c253,_0x433526,_0xd607ac['currentWriteId'],_0xd607ac['applyLocally']);V(_0x329b88['eventQueue_'],_0x19c253,_0x2cb585),jn(_0x329b88,_0x329b88['transactionQueueTree_']);}}function Es(_0x27e84b,_0xd59990,_0x28087d){return Vn(_0x27e84b['serverSyncTree_'],_0xd59990,_0x28087d)||g['EMPTY_NODE'];}function jn(_0x172dd6,_0x2258e4=_0x172dd6['transactionQueueTree_']){if(_0x2258e4||Kn(_0x172dd6,_0x2258e4),ze(_0x2258e4)){const _0x25feb4=da(_0x172dd6,_0x2258e4);f(_0x25feb4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x25feb4['every'](_0x4eac17=>_0x4eac17['status']===0x0)&&Od(_0x172dd6,Yt(_0x2258e4),_0x25feb4);}else na(_0x2258e4)&&Gn(_0x2258e4,_0x47a90b=>{jn(_0x172dd6,_0x47a90b);});}function Od(_0x344495,_0x274085,_0x529f70){const _0x2438a5=_0x529f70['map'](_0x3cd049=>_0x3cd049['currentWriteId']),_0x215724=Es(_0x344495,_0x274085,_0x2438a5);let _0x9d6aea=_0x215724;const _0x23e69d=_0x215724['hash']();for(let _0x48f0f4=0x0;_0x48f0f4<_0x529f70['length'];_0x48f0f4++){const _0x278e15=_0x529f70[_0x48f0f4];f(_0x278e15['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x278e15['status']=0x1,_0x278e15['retryCount']++;const _0x2ed8f5=F(_0x274085,_0x278e15['path']);_0x9d6aea=_0x9d6aea['updateChild'](_0x2ed8f5,_0x278e15['currentOutputSnapshotRaw']);}const _0xa9d09d=_0x9d6aea['val'](!0x0),_0x22eb38=_0x274085;_0x344495['server_']['put'](_0x22eb38['toString'](),_0xa9d09d,_0x258d85=>{gt(_0x344495,'transaction\x20put\x20response',{'path':_0x22eb38['toString'](),'status':_0x258d85});let _0x194458=[];if(_0x258d85==='ok'){const _0x430308=[];for(let _0xcb3335=0x0;_0xcb3335<_0x529f70['length'];_0xcb3335++)_0x529f70[_0xcb3335]['status']=0x2,_0x194458=_0x194458['concat'](_e(_0x344495['serverSyncTree_'],_0x529f70[_0xcb3335]['currentWriteId'])),_0x529f70[_0xcb3335]['onComplete']&&_0x430308['push'](()=>_0x529f70[_0xcb3335]['onComplete'](null,!0x0,_0x529f70[_0xcb3335]['currentOutputSnapshotResolved'])),_0x529f70[_0xcb3335]['unwatcher']();Kn(_0x344495,$n(_0x344495['transactionQueueTree_'],_0x274085)),jn(_0x344495,_0x344495['transactionQueueTree_']),V(_0x344495['eventQueue_'],_0x274085,_0x194458);for(let _0x10a072=0x0;_0x10a072<_0x430308['length'];_0x10a072++)ft(_0x430308[_0x10a072]);}else{if(_0x258d85==='datastale'){for(let _0x548935=0x0;_0x548935<_0x529f70['length'];_0x548935++)_0x529f70[_0x548935]['status']===0x3?_0x529f70[_0x548935]['status']=0x4:_0x529f70[_0x548935]['status']=0x0;}else{U('transaction\x20at\x20'+_0x22eb38['toString']()+'\x20failed:\x20'+_0x258d85);for(let _0x164a75=0x0;_0x164a75<_0x529f70['length'];_0x164a75++)_0x529f70[_0x164a75]['status']=0x4,_0x529f70[_0x164a75]['abortReason']=_0x258d85;}ct(_0x344495,_0x274085);}},_0x23e69d);}function ct(_0x2278ed,_0x1150b5){const _0x1b9cf6=ua(_0x2278ed,_0x1150b5),_0x4d5e6b=Yt(_0x1b9cf6),_0x35d6f6=da(_0x2278ed,_0x1b9cf6);return Dd(_0x2278ed,_0x35d6f6,_0x4d5e6b),_0x4d5e6b;}function Dd(_0xb69b8f,_0x68870c,_0x33858d){if(_0x68870c['length']===0x0)return;const _0x3fab57=[];let _0x33e8af=[];const _0x861a80=_0x68870c['filter'](_0x1f368c=>_0x1f368c['status']===0x0)['map'](_0x1e5b48=>_0x1e5b48['currentWriteId']);for(let _0xebb8a5=0x0;_0xebb8a5<_0x68870c['length'];_0xebb8a5++){const _0x198367=_0x68870c[_0xebb8a5],_0x4feb8b=F(_0x33858d,_0x198367['path']);let _0x348091=!0x1,_0xb9db9a;if(f(_0x4feb8b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x198367['status']===0x4)_0x348091=!0x0,_0xb9db9a=_0x198367['abortReason'],_0x33e8af=_0x33e8af['concat'](_e(_0xb69b8f['serverSyncTree_'],_0x198367['currentWriteId'],!0x0));else{if(_0x198367['status']===0x0){if(_0x198367['retryCount']>=md)_0x348091=!0x0,_0xb9db9a='maxretry',_0x33e8af=_0x33e8af['concat'](_e(_0xb69b8f['serverSyncTree_'],_0x198367['currentWriteId'],!0x0));else{const _0x42c9e6=Es(_0xb69b8f,_0x198367['path'],_0x861a80);_0x198367['currentInputSnapshot']=_0x42c9e6;const _0x11afb2=_0x68870c[_0xebb8a5]['update'](_0x42c9e6['val']());if(_0x11afb2!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x11afb2,_0x198367['path']);let _0x37dcc4=A(_0x11afb2);typeof _0x11afb2=='object'&&_0x11afb2!=null&&Q(_0x11afb2,'.priority')||(_0x37dcc4=_0x37dcc4['updatePriority'](_0x42c9e6['getPriority']()));const _0x46671c=_0x198367['currentWriteId'],_0x3217e9=Jt(_0xb69b8f),_0x21dc2f=fs(_0x37dcc4,_0x42c9e6,_0x3217e9);_0x198367['currentOutputSnapshotRaw']=_0x37dcc4,_0x198367['currentOutputSnapshotResolved']=_0x21dc2f,_0x198367['currentWriteId']=zn(_0xb69b8f),_0x861a80['splice'](_0x861a80['indexOf'](_0x46671c),0x1),_0x33e8af=_0x33e8af['concat'](as(_0xb69b8f['serverSyncTree_'],_0x198367['path'],_0x21dc2f,_0x198367['currentWriteId'],_0x198367['applyLocally'])),_0x33e8af=_0x33e8af['concat'](_e(_0xb69b8f['serverSyncTree_'],_0x46671c,!0x0));}else _0x348091=!0x0,_0xb9db9a='nodata',_0x33e8af=_0x33e8af['concat'](_e(_0xb69b8f['serverSyncTree_'],_0x198367['currentWriteId'],!0x0));}}}V(_0xb69b8f['eventQueue_'],_0x33858d,_0x33e8af),_0x33e8af=[],_0x348091&&(_0x68870c[_0xebb8a5]['status']=0x2,function(_0x1a2f80){setTimeout(_0x1a2f80,Math['floor'](0x0));}(_0x68870c[_0xebb8a5]['unwatcher']),_0x68870c[_0xebb8a5]['onComplete']&&(_0xb9db9a==='nodata'?_0x3fab57['push'](()=>_0x68870c[_0xebb8a5]['onComplete'](null,!0x1,_0x68870c[_0xebb8a5]['currentInputSnapshot'])):_0x3fab57['push'](()=>_0x68870c[_0xebb8a5]['onComplete'](new Error(_0xb9db9a),!0x1,null))));}Kn(_0xb69b8f,_0xb69b8f['transactionQueueTree_']);for(let _0x1cbe7d=0x0;_0x1cbe7d<_0x3fab57['length'];_0x1cbe7d++)ft(_0x3fab57[_0x1cbe7d]);jn(_0xb69b8f,_0xb69b8f['transactionQueueTree_']);}function ua(_0x4a79de,_0x4c0dd5){let _0x18f178,_0x3e3a73=_0x4a79de['transactionQueueTree_'];for(_0x18f178=y(_0x4c0dd5);_0x18f178!==null&&ze(_0x3e3a73)===void 0x0;)_0x3e3a73=$n(_0x3e3a73,_0x18f178),_0x4c0dd5=S(_0x4c0dd5),_0x18f178=y(_0x4c0dd5);return _0x3e3a73;}function da(_0x57159b,_0xe4b66e){const _0x379225=[];return fa(_0x57159b,_0xe4b66e,_0x379225),_0x379225['sort']((_0x4714a8,_0xf5d066)=>_0x4714a8['order']-_0xf5d066['order']),_0x379225;}function fa(_0x1b31e2,_0xe055c0,_0x4a2b84){const _0x585b33=ze(_0xe055c0);if(_0x585b33){for(let _0x34d179=0x0;_0x34d179<_0x585b33['length'];_0x34d179++)_0x4a2b84['push'](_0x585b33[_0x34d179]);}Gn(_0xe055c0,_0x188b03=>{fa(_0x1b31e2,_0x188b03,_0x4a2b84);});}function Kn(_0x1fe063,_0x5d4e9f){const _0x7cc3f8=ze(_0x5d4e9f);if(_0x7cc3f8){let _0x544561=0x0;for(let _0x5dfbae=0x0;_0x5dfbae<_0x7cc3f8['length'];_0x5dfbae++)_0x7cc3f8[_0x5dfbae]['status']!==0x2&&(_0x7cc3f8[_0x544561]=_0x7cc3f8[_0x5dfbae],_0x544561++);_0x7cc3f8['length']=_0x544561,gs(_0x5d4e9f,_0x7cc3f8['length']>0x0?_0x7cc3f8:void 0x0);}Gn(_0x5d4e9f,_0x121932=>{Kn(_0x1fe063,_0x121932);});}function Is(_0x5cece3,_0xee4ff){const _0x4e31a6=Yt(ua(_0x5cece3,_0xee4ff)),_0x18efc7=$n(_0x5cece3['transactionQueueTree_'],_0xee4ff);return od(_0x18efc7,_0x471e27=>{di(_0x5cece3,_0x471e27);}),di(_0x5cece3,_0x18efc7),ia(_0x18efc7,_0x28e433=>{di(_0x5cece3,_0x28e433);}),_0x4e31a6;}function di(_0x5c5a4f,_0x4a3d5f){const _0x56a8d0=ze(_0x4a3d5f);if(_0x56a8d0){const _0x3ef318=[];let _0x19311d=[],_0x155de3=-0x1;for(let _0x34e23f=0x0;_0x34e23f<_0x56a8d0['length'];_0x34e23f++)_0x56a8d0[_0x34e23f]['status']===0x3||(_0x56a8d0[_0x34e23f]['status']===0x1?(f(_0x155de3===_0x34e23f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x155de3=_0x34e23f,_0x56a8d0[_0x34e23f]['status']=0x3,_0x56a8d0[_0x34e23f]['abortReason']='set'):(f(_0x56a8d0[_0x34e23f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x56a8d0[_0x34e23f]['unwatcher'](),_0x19311d=_0x19311d['concat'](_e(_0x5c5a4f['serverSyncTree_'],_0x56a8d0[_0x34e23f]['currentWriteId'],!0x0)),_0x56a8d0[_0x34e23f]['onComplete']&&_0x3ef318['push'](_0x56a8d0[_0x34e23f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x155de3===-0x1?gs(_0x4a3d5f,void 0x0):_0x56a8d0['length']=_0x155de3+0x1,V(_0x5c5a4f['eventQueue_'],Yt(_0x4a3d5f),_0x19311d);for(let _0xd2a95=0x0;_0xd2a95<_0x3ef318['length'];_0xd2a95++)ft(_0x3ef318[_0xd2a95]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Md(_0x22907a){let _0x1b02b0='';const _0x4ba5b2=_0x22907a['split']('/');for(let _0x44e4f3=0x0;_0x44e4f3<_0x4ba5b2['length'];_0x44e4f3++)if(_0x4ba5b2[_0x44e4f3]['length']>0x0){let _0x254ca4=_0x4ba5b2[_0x44e4f3];try{_0x254ca4=decodeURIComponent(_0x254ca4['replace'](/\+/g,'\x20'));}catch{}_0x1b02b0+='/'+_0x254ca4;}return _0x1b02b0;}function Ld(_0x2595f1){const _0x22dd77={};_0x2595f1['charAt'](0x0)==='?'&&(_0x2595f1=_0x2595f1['substring'](0x1));for(const _0x50a182 of _0x2595f1['split']('&')){if(_0x50a182['length']===0x0)continue;const _0x1b24c9=_0x50a182['split']('=');_0x1b24c9['length']===0x2?_0x22dd77[decodeURIComponent(_0x1b24c9[0x0])]=decodeURIComponent(_0x1b24c9[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x50a182+'\x27\x20in\x20query\x20\x27'+_0x2595f1+'\x27');}return _0x22dd77;}const vr=function(_0x3e2a39,_0x4b447b){const _0x4c5fba=xd(_0x3e2a39),_0x5c7d43=_0x4c5fba['namespace'];_0x4c5fba['domain']==='firebase.com'&&ae(_0x4c5fba['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5c7d43||_0x5c7d43==='undefined')&&_0x4c5fba['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4c5fba['secure']||$l();const _0x256c7d=_0x4c5fba['scheme']==='ws'||_0x4c5fba['scheme']==='wss';return{'repoInfo':new yo(_0x4c5fba['host'],_0x4c5fba['secure'],_0x5c7d43,_0x256c7d,_0x4b447b,'',_0x5c7d43!==_0x4c5fba['subdomain']),'path':new C(_0x4c5fba['pathString'])};},xd=function(_0xec0b66){let _0x44c3b='',_0x2334f8='',_0x2c68d6='',_0x41d52c='',_0x595dda='',_0x5a9e5f=!0x0,_0x6380ce='https',_0x28cadf=0x1bb;if(typeof _0xec0b66=='string'){let _0x139b89=_0xec0b66['indexOf']('//');_0x139b89>=0x0&&(_0x6380ce=_0xec0b66['substring'](0x0,_0x139b89-0x1),_0xec0b66=_0xec0b66['substring'](_0x139b89+0x2));let _0x43711f=_0xec0b66['indexOf']('/');_0x43711f===-0x1&&(_0x43711f=_0xec0b66['length']);let _0x5adf70=_0xec0b66['indexOf']('?');_0x5adf70===-0x1&&(_0x5adf70=_0xec0b66['length']),_0x44c3b=_0xec0b66['substring'](0x0,Math['min'](_0x43711f,_0x5adf70)),_0x43711f<_0x5adf70&&(_0x41d52c=Md(_0xec0b66['substring'](_0x43711f,_0x5adf70)));const _0x3a9ebd=Ld(_0xec0b66['substring'](Math['min'](_0xec0b66['length'],_0x5adf70)));_0x139b89=_0x44c3b['indexOf'](':'),_0x139b89>=0x0?(_0x5a9e5f=_0x6380ce==='https'||_0x6380ce==='wss',_0x28cadf=parseInt(_0x44c3b['substring'](_0x139b89+0x1),0xa)):_0x139b89=_0x44c3b['length'];const _0x2392ac=_0x44c3b['slice'](0x0,_0x139b89);if(_0x2392ac['toLowerCase']()==='localhost')_0x2334f8='localhost';else{if(_0x2392ac['split']('.')['length']<=0x2)_0x2334f8=_0x2392ac;else{const _0x679c29=_0x44c3b['indexOf']('.');_0x2c68d6=_0x44c3b['substring'](0x0,_0x679c29)['toLowerCase'](),_0x2334f8=_0x44c3b['substring'](_0x679c29+0x1),_0x595dda=_0x2c68d6;}}'ns'in _0x3a9ebd&&(_0x595dda=_0x3a9ebd['ns']);}return{'host':_0x44c3b,'port':_0x28cadf,'domain':_0x2334f8,'subdomain':_0x2c68d6,'secure':_0x5a9e5f,'scheme':_0x6380ce,'pathString':_0x41d52c,'namespace':_0x595dda};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Fd=(function(){let _0x53fd2b=0x0;const _0x318768=[];return function(_0x443d12){const _0x1527b0=_0x443d12===_0x53fd2b;_0x53fd2b=_0x443d12;let _0x47e5c5;const _0x142e7e=new Array(0x8);for(_0x47e5c5=0x7;_0x47e5c5>=0x0;_0x47e5c5--)_0x142e7e[_0x47e5c5]=Er['charAt'](_0x443d12%0x40),_0x443d12=Math['floor'](_0x443d12/0x40);f(_0x443d12===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x257693=_0x142e7e['join']('');if(_0x1527b0){for(_0x47e5c5=0xb;_0x47e5c5>=0x0&&_0x318768[_0x47e5c5]===0x3f;_0x47e5c5--)_0x318768[_0x47e5c5]=0x0;_0x318768[_0x47e5c5]++;}else{for(_0x47e5c5=0x0;_0x47e5c5<0xc;_0x47e5c5++)_0x318768[_0x47e5c5]=Math['floor'](Math['random']()*0x40);}for(_0x47e5c5=0x0;_0x47e5c5<0xc;_0x47e5c5++)_0x257693+=Er['charAt'](_0x318768[_0x47e5c5]);return f(_0x257693['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x257693;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ud{constructor(_0x5f5024,_0x11275b,_0x38454e,_0x5a4aa0){this['eventType']=_0x5f5024,this['eventRegistration']=_0x11275b,this['snapshot']=_0x38454e,this['prevName']=_0x5a4aa0;}['getPath'](){const _0x3770b5=this['snapshot']['ref'];return this['eventType']==='value'?_0x3770b5['_path']:_0x3770b5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Wd{constructor(_0x501507,_0x5135d4,_0x399a01){this['eventRegistration']=_0x501507,this['error']=_0x5135d4,this['path']=_0x399a01;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4ec5aa,_0x232534){this['snapshotCallback']=_0x4ec5aa,this['cancelCallback']=_0x232534;}['onValue'](_0x4e8e12,_0x10fa2d){this['snapshotCallback']['call'](null,_0x4e8e12,_0x10fa2d);}['onCancel'](_0x105816){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x105816);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4d8459){return this['snapshotCallback']===_0x4d8459['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4d8459['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4d8459['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bd{constructor(_0x304718,_0x2530a4){this['_repo']=_0x304718,this['_path']=_0x2530a4;}['cancel'](){const _0x37d9ca=new H();return Sd(this['_repo'],this['_path'],_0x37d9ca['wrapCallback'](()=>{})),_0x37d9ca['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x79cbd7=new H();return yr(this['_repo'],this['_path'],null,_0x79cbd7['wrapCallback'](()=>{})),_0x79cbd7['promise'];}['set'](_0x41db09){De('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x41db09,this['_path'],!0x1);const _0x2cefb2=new H();return yr(this['_repo'],this['_path'],_0x41db09,_0x2cefb2['wrapCallback'](()=>{})),_0x2cefb2['promise'];}['setWithPriority'](_0x4576f7,_0x25969c){De('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x4576f7,this['_path'],!0x1),dd('OnDisconnect.setWithPriority',_0x25969c);const _0x4b0a2b=new H();return bd(this['_repo'],this['_path'],_0x4576f7,_0x25969c,_0x4b0a2b['wrapCallback'](()=>{})),_0x4b0a2b['promise'];}['update'](_0xd36beb){De('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0xd36beb,this['_path']);const _0x37ae7e=new H();return Rd(this['_repo'],this['_path'],_0xd36beb,_0x37ae7e['wrapCallback'](()=>{})),_0x37ae7e['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class je{constructor(_0x26b6d6,_0x1007cd,_0x1bef6d,_0x2b0710){this['_repo']=_0x26b6d6,this['_path']=_0x1007cd,this['_queryParams']=_0x1bef6d,this['_orderByCalled']=_0x2b0710;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x464c97=sr(this['_queryParams']),_0x3dcac7=$i(_0x464c97);return _0x3dcac7==='{}'?'default':_0x3dcac7;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1b97ec){if(_0x1b97ec=N(_0x1b97ec),!(_0x1b97ec instanceof je))return!0x1;const _0x29a8de=this['_repo']===_0x1b97ec['_repo'],_0xa10009=Ki(this['_path'],_0x1b97ec['_path']),_0x13887a=this['_queryIdentifier']===_0x1b97ec['_queryIdentifier'];return _0x29a8de&&_0xa10009&&_0x13887a;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x120b8c,_0x3dc437){if(_0x120b8c['_orderByCalled']===!0x0)throw new Error(_0x3dc437+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x3379dd){let _0x556e3a=null,_0x26cc2b=null;if(_0x3379dd['hasStart']()&&(_0x556e3a=_0x3379dd['getIndexStartValue']()),_0x3379dd['hasEnd']()&&(_0x26cc2b=_0x3379dd['getIndexEndValue']()),_0x3379dd['getIndex']()===ve){const _0x302012='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2ab7cb='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3379dd['hasStart']()){if(_0x3379dd['getIndexStartName']()!==Ue)throw new Error(_0x302012);if(typeof _0x556e3a!='string')throw new Error(_0x2ab7cb);}if(_0x3379dd['hasEnd']()){if(_0x3379dd['getIndexEndName']()!==we)throw new Error(_0x302012);if(typeof _0x26cc2b!='string')throw new Error(_0x2ab7cb);}}else{if(_0x3379dd['getIndex']()===R){if(_0x556e3a!=null&&!Wt(_0x556e3a)||_0x26cc2b!=null&&!Wt(_0x26cc2b))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3379dd['getIndex']()instanceof Ji||_0x3379dd['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x556e3a!=null&&typeof _0x556e3a=='object'||_0x26cc2b!=null&&typeof _0x26cc2b=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x22d2f5){if(_0x22d2f5['hasStart']()&&_0x22d2f5['hasEnd']()&&_0x22d2f5['hasLimit']()&&!_0x22d2f5['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends je{constructor(_0x545edb,_0xe02f23){super(_0x545edb,_0xe02f23,new Zi(),!0x1);}get['parent'](){const _0x453783=Ro(this['_path']);return _0x453783===null?null:new ee(this['_repo'],_0x453783);}get['root'](){let _0x40d532=this;for(;_0x40d532['parent']!==null;)_0x40d532=_0x40d532['parent'];return _0x40d532;}}class lt{constructor(_0x39d34a,_0x37aacd,_0x1643b0){this['_node']=_0x39d34a,this['ref']=_0x37aacd,this['_index']=_0x1643b0;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x14e567){const _0x3d1490=new C(_0x14e567),_0x4fb40e=Bt(this['ref'],_0x14e567);return new lt(this['_node']['getChild'](_0x3d1490),_0x4fb40e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1d87a3){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2ce2d0,_0x85e5e4)=>_0x1d87a3(new lt(_0x85e5e4,Bt(this['ref'],_0x2ce2d0),R)));}['hasChild'](_0x50bb89){const _0x548d82=new C(_0x50bb89);return!this['_node']['getChild'](_0x548d82)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function g_(_0x27359c,_0x531caa){return _0x27359c=N(_0x27359c),_0x27359c['_checkNotDeleted']('ref'),_0x531caa!==void 0x0?Bt(_0x27359c['_root'],_0x531caa):_0x27359c['_root'];}function Bt(_0x1e1d8a,_0x23b544){return _0x1e1d8a=N(_0x1e1d8a),y(_0x1e1d8a['_path'])===null?fd('child','path',_0x23b544):ys('child','path',_0x23b544),new ee(_0x1e1d8a['_repo'],k(_0x1e1d8a['_path'],_0x23b544));}function m_(_0x4e510c){return _0x4e510c=N(_0x4e510c),new Bd(_0x4e510c['_repo'],_0x4e510c['_path']);}function y_(_0x34acea,_0x2d194e){_0x34acea=N(_0x34acea),De('push',_0x34acea['_path']),Ve('push',_0x2d194e,_0x34acea['_path'],!0x0);const _0x42675d=la(_0x34acea['_repo']),_0x254898=Fd(_0x42675d),_0x35058a=Bt(_0x34acea,_0x254898),_0x3a97e7=Bt(_0x34acea,_0x254898);let _0x510c74;return _0x2d194e!=null?_0x510c74=Vd(_0x3a97e7,_0x2d194e)['then'](()=>_0x3a97e7):_0x510c74=Promise['resolve'](_0x3a97e7),_0x35058a['then']=_0x510c74['then']['bind'](_0x510c74),_0x35058a['catch']=_0x510c74['then']['bind'](_0x510c74,void 0x0),_0x35058a;}function Vd(_0x4aacb2,_0x223c7b){_0x4aacb2=N(_0x4aacb2),De('set',_0x4aacb2['_path']),Ve('set',_0x223c7b,_0x4aacb2['_path'],!0x1);const _0x10d8e6=new H();return wd(_0x4aacb2['_repo'],_0x4aacb2['_path'],_0x223c7b,null,_0x10d8e6['wrapCallback'](()=>{})),_0x10d8e6['promise'];}function v_(_0x5dcbd8,_0x2f0ef2){ra('update',_0x2f0ef2,_0x5dcbd8['_path']);const _0xf28727=new H();return Cd(_0x5dcbd8['_repo'],_0x5dcbd8['_path'],_0x2f0ef2,_0xf28727['wrapCallback'](()=>{})),_0xf28727['promise'];}function E_(_0x45816c){_0x45816c=N(_0x45816c);const _0x4ad7b6=new pa(()=>{}),_0x2c05dd=new Qn(_0x4ad7b6);return Id(_0x45816c['_repo'],_0x45816c,_0x2c05dd)['then'](_0x8e0ed=>new lt(_0x8e0ed,new ee(_0x45816c['_repo'],_0x45816c['_path']),_0x45816c['_queryParams']['getIndex']()));}class Qn{constructor(_0x17e55f){this['callbackContext']=_0x17e55f;}['respondsTo'](_0x2f7a65){return _0x2f7a65==='value';}['createEvent'](_0x5e2ab8,_0x3b3809){const _0x128bd5=_0x3b3809['_queryParams']['getIndex']();return new Ud('value',this,new lt(_0x5e2ab8['snapshotNode'],new ee(_0x3b3809['_repo'],_0x3b3809['_path']),_0x128bd5));}['getEventRunner'](_0x354c47){return _0x354c47['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x354c47['error']):()=>this['callbackContext']['onValue'](_0x354c47['snapshot'],null);}['createCancelEvent'](_0x19264c,_0x426c23){return this['callbackContext']['hasCancelCallback']?new Wd(this,_0x19264c,_0x426c23):null;}['matches'](_0x51dcb0){return _0x51dcb0 instanceof Qn?!_0x51dcb0['callbackContext']||!this['callbackContext']?!0x0:_0x51dcb0['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Hd(_0x26a770,_0x41727c,_0x51c30a,_0x90b093,_0x466587){const _0x104d12=new pa(_0x51c30a,void 0x0),_0x31a657=new Qn(_0x104d12);return Ad(_0x26a770['_repo'],_0x26a770,_0x31a657),()=>kd(_0x26a770['_repo'],_0x26a770,_0x31a657);}function $d(_0x2a9515,_0x4ffe66,_0x5cdf11,_0x5e6c55){return Hd(_0x2a9515,'value',_0x4ffe66);}class Xt{}class ma extends Xt{constructor(_0x3cbf86,_0x14a998){super(),this['_value']=_0x3cbf86,this['_key']=_0x14a998,this['type']='endAt';}['_apply'](_0x43d1b){Ve('endAt',this['_value'],_0x43d1b['_path'],!0x0);const _0x3b0335=Qh(_0x43d1b['_queryParams'],this['_value'],this['_key']);if(ga(_0x3b0335),Yn(_0x3b0335),_0x43d1b['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new je(_0x43d1b['_repo'],_0x43d1b['_path'],_0x3b0335,_0x43d1b['_orderByCalled']);}}function I_(_0x3793ed,_0x2cecf9){return new ma(_0x3793ed,_0x2cecf9);}class ya extends Xt{constructor(_0x3d6fd8,_0x1694be){super(),this['_value']=_0x3d6fd8,this['_key']=_0x1694be,this['type']='startAt';}['_apply'](_0x499853){Ve('startAt',this['_value'],_0x499853['_path'],!0x0);const _0x4904d2=Yh(_0x499853['_queryParams'],this['_value'],this['_key']);if(ga(_0x4904d2),Yn(_0x4904d2),_0x499853['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new je(_0x499853['_repo'],_0x499853['_path'],_0x4904d2,_0x499853['_orderByCalled']);}}function w_(_0x7478dd=null,_0x135137){return new ya(_0x7478dd,_0x135137);}class Gd extends Xt{constructor(_0x29a617){super(),this['_path']=_0x29a617,this['type']='orderByChild';}['_apply'](_0x1b1f74){_a(_0x1b1f74,'orderByChild');const _0x20563e=new C(this['_path']);if(v(_0x20563e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x15c062=new Ji(_0x20563e),_0x21841=xo(_0x1b1f74['_queryParams'],_0x15c062);return Yn(_0x21841),new je(_0x1b1f74['_repo'],_0x1b1f74['_path'],_0x21841,!0x0);}}function C_(_0x4dd798){if(_0x4dd798==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4dd798==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4dd798==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x4dd798),new Gd(_0x4dd798);}class qd extends Xt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x359a54){_a(_0x359a54,'orderByKey');const _0x354f84=xo(_0x359a54['_queryParams'],ve);return Yn(_0x354f84),new je(_0x359a54['_repo'],_0x359a54['_path'],_0x354f84,!0x0);}}function T_(){return new qd();}class zd extends Xt{constructor(_0x4346ff,_0x4f0809){super(),this['_value']=_0x4346ff,this['_key']=_0x4f0809,this['type']='equalTo';}['_apply'](_0x1e6b60){if(Ve('equalTo',this['_value'],_0x1e6b60['_path'],!0x1),_0x1e6b60['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1e6b60['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1e6b60));}}function S_(_0x56bb52,_0xfea53e){return new zd(_0x56bb52,_0xfea53e);}function b_(_0x1e9f48,..._0x3515a0){let _0xe99122=N(_0x1e9f48);for(const _0x9eee49 of _0x3515a0)_0xe99122=_0x9eee49['_apply'](_0xe99122);return _0xe99122;}Uu(ee),$u(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Kd=!0x1;function Yd(_0x3f7c58,_0xf82434,_0x143594,_0x5a7ba8){const _0x58e7a4=_0xf82434['lastIndexOf'](':'),_0x2210bd=_0xf82434['substring'](0x0,_0x58e7a4),_0x800f27=Gt(_0x2210bd);_0x3f7c58['repoInfo_']=new yo(_0xf82434,_0x800f27,_0x3f7c58['repoInfo_']['namespace'],_0x3f7c58['repoInfo_']['webSocketOnly'],_0x3f7c58['repoInfo_']['nodeAdmin'],_0x3f7c58['repoInfo_']['persistenceKey'],_0x3f7c58['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x143594),_0x5a7ba8&&(_0x3f7c58['authTokenProvider_']=_0x5a7ba8);}function Qd(_0x97768e,_0x19393c,_0x78a8a,_0x589add,_0x10f57e){let _0x35a366=_0x589add||_0x97768e['options']['databaseURL'];_0x35a366===void 0x0&&(_0x97768e['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x97768e['options']['projectId']),_0x35a366=_0x97768e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2cb5a1=vr(_0x35a366,_0x10f57e),_0x44d50f=_0x2cb5a1['repoInfo'],_0x2f4ad5;typeof process<'u'&&Bs&&(_0x2f4ad5=Bs[jd]),_0x2f4ad5?(_0x35a366='http://'+_0x2f4ad5+'?ns='+_0x44d50f['namespace'],_0x2cb5a1=vr(_0x35a366,_0x10f57e),_0x44d50f=_0x2cb5a1['repoInfo']):_0x2cb5a1['repoInfo']['secure'];const _0x4aea92=new eh(_0x97768e['name'],_0x97768e['options'],_0x19393c);pd('Invalid\x20Firebase\x20Database\x20URL',_0x2cb5a1),v(_0x2cb5a1['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x498d77=Xd(_0x44d50f,_0x97768e,_0x4aea92,new Zl(_0x97768e,_0x78a8a));return new Zd(_0x498d77,_0x97768e);}function Jd(_0x4e9cbb,_0x3e9f8a){const _0xbb5404=Di[_0x3e9f8a];(!_0xbb5404||_0xbb5404[_0x4e9cbb['key']]!==_0x4e9cbb)&&ae('Database\x20'+_0x3e9f8a+'('+_0x4e9cbb['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4e9cbb),delete _0xbb5404[_0x4e9cbb['key']];}function Xd(_0x11f02f,_0x54914e,_0x1c6d03,_0x4c8634){let _0x29630f=Di[_0x54914e['name']];_0x29630f||(_0x29630f={},Di[_0x54914e['name']]=_0x29630f);let _0x4e6373=_0x29630f[_0x11f02f['toURLString']()];return _0x4e6373&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4e6373=new yd(_0x11f02f,Kd,_0x1c6d03,_0x4c8634),_0x29630f[_0x11f02f['toURLString']()]=_0x4e6373,_0x4e6373;}class Zd{constructor(_0x3828e0,_0x233280){this['_repoInternal']=_0x3828e0,this['app']=_0x233280,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(vd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Jd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x56968e){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x56968e+'\x20on\x20a\x20deleted\x20database.');}}function R_(_0x1b02af=Zr(),_0x2a078f){const _0x208d8f=Hi(_0x1b02af,'database')['getImmediate']({'identifier':_0x2a078f});if(!_0x208d8f['_instanceStarted']){const _0x134b5b=hc('database');_0x134b5b&&ef(_0x208d8f,..._0x134b5b);}return _0x208d8f;}function ef(_0xe4771,_0x2f0e93,_0x41ddea,_0x40e8ff={}){_0xe4771=N(_0xe4771),_0xe4771['_checkNotDeleted']('useEmulator');const _0x1ebdee=_0x2f0e93+':'+_0x41ddea,_0x2e16a0=_0xe4771['_repoInternal'];if(_0xe4771['_instanceStarted']){if(_0x1ebdee===_0xe4771['_repoInternal']['repoInfo_']['host']&&Le(_0x40e8ff,_0x2e16a0['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x56ed24;if(_0x2e16a0['repoInfo_']['nodeAdmin'])_0x40e8ff['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x56ed24=new an(an['OWNER']);else{if(_0x40e8ff['mockUserToken']){const _0x495690=typeof _0x40e8ff['mockUserToken']=='string'?_0x40e8ff['mockUserToken']:uc(_0x40e8ff['mockUserToken'],_0xe4771['app']['options']['projectId']);_0x56ed24=new an(_0x495690);}}Gt(_0x2f0e93)&&Qr(_0x2f0e93),Yd(_0x2e16a0,_0x1ebdee,_0x40e8ff,_0x56ed24);}function A_(_0x3c742a){_0x3c742a=N(_0x3c742a),_0x3c742a['_checkNotDeleted']('goOffline'),ha(_0x3c742a['_repo']);}function k_(_0xf738a4){_0xf738a4=N(_0xf738a4),_0xf738a4['_checkNotDeleted']('goOnline'),Nd(_0xf738a4['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(_0x1a836a){Ul(dt),st(new xe('database',(_0x1fd0b6,{instanceIdentifier:_0xcbc03b})=>{const _0x2e8706=_0x1fd0b6['getProvider']('app')['getImmediate'](),_0x5e09a2=_0x1fd0b6['getProvider']('auth-internal'),_0x12f74d=_0x1fd0b6['getProvider']('app-check-internal');return Qd(_0x2e8706,_0x5e09a2,_0x12f74d,_0xcbc03b);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x1a836a),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const nf={'.sv':'timestamp'};function N_(){return nf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sf{constructor(_0x216736,_0x1d4eec){this['committed']=_0x216736,this['snapshot']=_0x1d4eec;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function P_(_0x44e994,_0x329c6d,_0x20a8bb){if(_0x44e994=N(_0x44e994),De('Reference.transaction',_0x44e994['_path']),_0x44e994['key']==='.length'||_0x44e994['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x44e994['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1a745d=!0x0,_0x6b3f4=new H(),_0x41bdb7=(_0xa703d6,_0x3b37d2,_0x4197a0)=>{let _0x1df6a1=null;_0xa703d6?_0x6b3f4['reject'](_0xa703d6):(_0x1df6a1=new lt(_0x4197a0,new ee(_0x44e994['_repo'],_0x44e994['_path']),R),_0x6b3f4['resolve'](new sf(_0x3b37d2,_0x1df6a1)));},_0x4469e1=$d(_0x44e994,()=>{});return Pd(_0x44e994['_repo'],_0x44e994['_path'],_0x329c6d,_0x41bdb7,_0x4469e1,_0x1a745d),_0x6b3f4['promise'];}se['prototype']['simpleListen']=function(_0xe18523,_0x36e71f){this['sendRequest']('q',{'p':_0xe18523},_0x36e71f);},se['prototype']['echo']=function(_0x36d086,_0x35e099){this['sendRequest']('echo',{'d':_0x36d086},_0x35e099);},tf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const rf=va,Ea=new $t('auth','Firebase',va()),kn=new Bi('@firebase/auth');function of(_0x3e3a48,..._0x508c1b){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x3e3a48,..._0x508c1b);}function cn(_0x2c6b1d,..._0x8d9b09){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x2c6b1d,..._0x8d9b09);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3ed014,..._0x401a58){throw ws(_0x3ed014,..._0x401a58);}function X(_0x3718a2,..._0x272f5e){return ws(_0x3718a2,..._0x272f5e);}function Ia(_0xfff076,_0x15a6c4,_0x569e4d){const _0x4e2646={...rf(),[_0x15a6c4]:_0x569e4d};return new $t('auth','Firebase',_0x4e2646)['create'](_0x15a6c4,{'appName':_0xfff076['name']});}function re(_0x536b9a){return Ia(_0x536b9a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1083e2,..._0x493610){if(typeof _0x1083e2!='string'){const _0x2f21e2=_0x493610[0x0],_0xaa5898=[..._0x493610['slice'](0x1)];return _0xaa5898[0x0]&&(_0xaa5898[0x0]['appName']=_0x1083e2['name']),_0x1083e2['_errorFactory']['create'](_0x2f21e2,..._0xaa5898);}return Ea['create'](_0x1083e2,..._0x493610);}function m(_0x9bc658,_0x44b97b,..._0x1ef9fa){if(!_0x9bc658)throw ws(_0x44b97b,..._0x1ef9fa);}function ne(_0x15895e){const _0x4c5cde='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x15895e;throw cn(_0x4c5cde),new Error(_0x4c5cde);}function ce(_0x38246c,_0xa6ca9d){_0x38246c||ne(_0xa6ca9d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x4bd743;return typeof self<'u'&&((_0x4bd743=self['location'])==null?void 0x0:_0x4bd743['href'])||'';}function af(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x555420;return typeof self<'u'&&((_0x555420=self['location'])==null?void 0x0:_0x555420['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(af()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function lf(){if(typeof navigator>'u')return null;const _0x2956b6=navigator;return _0x2956b6['languages']&&_0x2956b6['languages'][0x0]||_0x2956b6['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2810da,_0x63d757){this['shortDelay']=_0x2810da,this['longDelay']=_0x63d757,ce(_0x63d757>_0x2810da,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return cf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x5c77ab,_0x790a8a){ce(_0x5c77ab['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xa587c6}=_0x5c77ab['emulator'];return _0x790a8a?''+_0xa587c6+(_0x790a8a['startsWith']('/')?_0x790a8a['slice'](0x1):_0x790a8a):_0xa587c6;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3fdf0a,_0x254db6,_0x18b7f8){this['fetchImpl']=_0x3fdf0a,_0x254db6&&(this['headersImpl']=_0x254db6),_0x18b7f8&&(this['responseImpl']=_0x18b7f8);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},uf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],df=new Zt(0x7530,0xea60);function Ae(_0x5bbd38,_0xa5fc7e){return _0x5bbd38['tenantId']&&!_0xa5fc7e['tenantId']?{..._0xa5fc7e,'tenantId':_0x5bbd38['tenantId']}:_0xa5fc7e;}async function ke(_0x4b74a9,_0x1ad65e,_0x2090ae,_0x1f505b,_0xefeb02={}){return Ca(_0x4b74a9,_0xefeb02,async()=>{let _0xad7a02={},_0xa7c900={};_0x1f505b&&(_0x1ad65e==='GET'?_0xa7c900=_0x1f505b:_0xad7a02={'body':JSON['stringify'](_0x1f505b)});const _0x54a779=ut({..._0xa7c900,'key':_0x4b74a9['config']['apiKey']})['slice'](0x1),_0x1c6f73=await _0x4b74a9['_getAdditionalHeaders']();_0x1c6f73['Content-Type']='application/json',_0x4b74a9['languageCode']&&(_0x1c6f73['X-Firebase-Locale']=_0x4b74a9['languageCode']);const _0x282f95={'method':_0x1ad65e,'headers':_0x1c6f73,..._0xad7a02};return dc()||(_0x282f95['referrerPolicy']='strict-origin-when-cross-origin'),_0x4b74a9['emulatorConfig']&&Gt(_0x4b74a9['emulatorConfig']['host'])&&(_0x282f95['credentials']='include'),wa['fetch']()(await Ta(_0x4b74a9,_0x4b74a9['config']['apiHost'],_0x2090ae,_0x54a779),_0x282f95);});}async function Ca(_0x4e0249,_0x1f6dc3,_0x423fce){_0x4e0249['_canInitEmulator']=!0x1;const _0x2bd72b={...hf,..._0x1f6dc3};try{const _0x280bd4=new pf(_0x4e0249),_0x425ddf=await Promise['race']([_0x423fce(),_0x280bd4['promise']]);_0x280bd4['clearNetworkTimeout']();const _0x1b30d0=await _0x425ddf['json']();if('needConfirmation'in _0x1b30d0)throw on(_0x4e0249,'account-exists-with-different-credential',_0x1b30d0);if(_0x425ddf['ok']&&!('errorMessage'in _0x1b30d0))return _0x1b30d0;{const _0x58441e=_0x425ddf['ok']?_0x1b30d0['errorMessage']:_0x1b30d0['error']['message'],[_0x142c7c,_0x2d2cd5]=_0x58441e['split']('\x20:\x20');if(_0x142c7c==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x4e0249,'credential-already-in-use',_0x1b30d0);if(_0x142c7c==='EMAIL_EXISTS')throw on(_0x4e0249,'email-already-in-use',_0x1b30d0);if(_0x142c7c==='USER_DISABLED')throw on(_0x4e0249,'user-disabled',_0x1b30d0);const _0x1a1af7=_0x2bd72b[_0x142c7c]||_0x142c7c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2d2cd5)throw Ia(_0x4e0249,_0x1a1af7,_0x2d2cd5);Y(_0x4e0249,_0x1a1af7);}}catch(_0x57c644){if(_0x57c644 instanceof Re)throw _0x57c644;Y(_0x4e0249,'network-request-failed',{'message':String(_0x57c644)});}}async function en(_0x2c94a1,_0x3a9733,_0x4efdc8,_0x37ca98,_0x4c32e5={}){const _0x526a04=await ke(_0x2c94a1,_0x3a9733,_0x4efdc8,_0x37ca98,_0x4c32e5);return'mfaPendingCredential'in _0x526a04&&Y(_0x2c94a1,'multi-factor-auth-required',{'_serverResponse':_0x526a04}),_0x526a04;}async function Ta(_0x59ea09,_0x138954,_0x28af24,_0x4f59c3){const _0x222d0c=''+_0x138954+_0x28af24+'?'+_0x4f59c3,_0x4e1b92=_0x59ea09,_0x6eb6=_0x4e1b92['config']['emulator']?Cs(_0x59ea09['config'],_0x222d0c):_0x59ea09['config']['apiScheme']+'://'+_0x222d0c;return uf['includes'](_0x28af24)&&(await _0x4e1b92['_persistenceManagerAvailable'],_0x4e1b92['_getPersistenceType']()==='COOKIE')?_0x4e1b92['_getPersistence']()['_getFinalTarget'](_0x6eb6)['toString']():_0x6eb6;}function ff(_0x24545e){switch(_0x24545e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class pf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2e4168){this['auth']=_0x2e4168,this['timer']=null,this['promise']=new Promise((_0x129c69,_0x564b2d)=>{this['timer']=setTimeout(()=>_0x564b2d(X(this['auth'],'network-request-failed')),df['get']());});}}function on(_0x506bcb,_0x2bb5c6,_0x1261a1){const _0x319247={'appName':_0x506bcb['name']};_0x1261a1['email']&&(_0x319247['email']=_0x1261a1['email']),_0x1261a1['phoneNumber']&&(_0x319247['phoneNumber']=_0x1261a1['phoneNumber']);const _0x57b7b1=X(_0x506bcb,_0x2bb5c6,_0x319247);return _0x57b7b1['customData']['_tokenResponse']=_0x1261a1,_0x57b7b1;}function wr(_0x5ace75){return _0x5ace75!==void 0x0&&_0x5ace75['enterprise']!==void 0x0;}class _f{constructor(_0x305068){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x305068['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x305068['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x305068['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x26ba02){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x54d0b3 of this['recaptchaEnforcementState'])if(_0x54d0b3['provider']&&_0x54d0b3['provider']===_0x26ba02)return ff(_0x54d0b3['enforcementState']);return null;}['isProviderEnabled'](_0x43fe11){return this['getProviderEnforcementState'](_0x43fe11)==='ENFORCE'||this['getProviderEnforcementState'](_0x43fe11)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function gf(_0x248554,_0x67f39){return ke(_0x248554,'GET','/v2/recaptchaConfig',Ae(_0x248554,_0x67f39));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x15911e,_0x461fd7){return ke(_0x15911e,'POST','/v1/accounts:delete',_0x461fd7);}async function Nn(_0x80a558,_0x2e6045){return ke(_0x80a558,'POST','/v1/accounts:lookup',_0x2e6045);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x4b2acf){if(_0x4b2acf)try{const _0x33a8de=new Date(Number(_0x4b2acf));if(!isNaN(_0x33a8de['getTime']()))return _0x33a8de['toUTCString']();}catch{}}async function yf(_0x276445,_0x4c2b9f=!0x1){const _0x2aabcd=N(_0x276445),_0x486517=await _0x2aabcd['getIdToken'](_0x4c2b9f),_0x56c554=Ts(_0x486517);m(_0x56c554&&_0x56c554['exp']&&_0x56c554['auth_time']&&_0x56c554['iat'],_0x2aabcd['auth'],'internal-error');const _0x494369=typeof _0x56c554['firebase']=='object'?_0x56c554['firebase']:void 0x0,_0x329156=_0x494369==null?void 0x0:_0x494369['sign_in_provider'];return{'claims':_0x56c554,'token':_0x486517,'authTime':kt(fi(_0x56c554['auth_time'])),'issuedAtTime':kt(fi(_0x56c554['iat'])),'expirationTime':kt(fi(_0x56c554['exp'])),'signInProvider':_0x329156||null,'signInSecondFactor':(_0x494369==null?void 0x0:_0x494369['sign_in_second_factor'])||null};}function fi(_0x1f695e){return Number(_0x1f695e)*0x3e8;}function Ts(_0x5280ea){const [_0x16b460,_0x3c28db,_0x9ca273]=_0x5280ea['split']('.');if(_0x16b460===void 0x0||_0x3c28db===void 0x0||_0x9ca273===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3bf6ff=fn(_0x3c28db);return _0x3bf6ff?JSON['parse'](_0x3bf6ff):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x15cf6){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x15cf6==null?void 0x0:_0x15cf6['toString']()),null;}}function Cr(_0x39b379){const _0x111dda=Ts(_0x39b379);return m(_0x111dda,'internal-error'),m(typeof _0x111dda['exp']<'u','internal-error'),m(typeof _0x111dda['iat']<'u','internal-error'),Number(_0x111dda['exp'])-Number(_0x111dda['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x5a73f3,_0x6e6d31,_0x2747fc=!0x1){if(_0x2747fc)return _0x6e6d31;try{return await _0x6e6d31;}catch(_0x41e4bf){throw _0x41e4bf instanceof Re&&vf(_0x41e4bf)&&_0x5a73f3['auth']['currentUser']===_0x5a73f3&&await _0x5a73f3['auth']['signOut'](),_0x41e4bf;}}function vf({code:_0x34e321}){return _0x34e321==='auth/user-disabled'||_0x34e321==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ef{constructor(_0x10ec17){this['user']=_0x10ec17,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x52e7fb){if(_0x52e7fb){const _0x60b521=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x60b521;}else{this['errorBackoff']=0x7530;const _0x4a3f5f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4a3f5f);}}['schedule'](_0x529936=!0x1){if(!this['isRunning'])return;const _0x3d7759=this['getInterval'](_0x529936);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3d7759);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x334876){(_0x334876==null?void 0x0:_0x334876['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x56dc1d,_0x47065d){this['createdAt']=_0x56dc1d,this['lastLoginAt']=_0x47065d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x4d3a81){this['createdAt']=_0x4d3a81['createdAt'],this['lastLoginAt']=_0x4d3a81['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pn(_0x28798f){var _0x3826a8;const _0x1f30e6=_0x28798f['auth'],_0xf1b7a8=await _0x28798f['getIdToken'](),_0x4891d4=await Vt(_0x28798f,Nn(_0x1f30e6,{'idToken':_0xf1b7a8}));m(_0x4891d4==null?void 0x0:_0x4891d4['users']['length'],_0x1f30e6,'internal-error');const _0x2c2723=_0x4891d4['users'][0x0];_0x28798f['_notifyReloadListener'](_0x2c2723);const _0x3bdd69=(_0x3826a8=_0x2c2723['providerUserInfo'])!=null&&_0x3826a8['length']?Sa(_0x2c2723['providerUserInfo']):[],_0x4e225a=wf(_0x28798f['providerData'],_0x3bdd69),_0x3cde7f=_0x28798f['isAnonymous'],_0x46c4ef=!(_0x28798f['email']&&_0x2c2723['passwordHash'])&&!(_0x4e225a!=null&&_0x4e225a['length']),_0x350c46=_0x3cde7f?_0x46c4ef:!0x1,_0x592920={'uid':_0x2c2723['localId'],'displayName':_0x2c2723['displayName']||null,'photoURL':_0x2c2723['photoUrl']||null,'email':_0x2c2723['email']||null,'emailVerified':_0x2c2723['emailVerified']||!0x1,'phoneNumber':_0x2c2723['phoneNumber']||null,'tenantId':_0x2c2723['tenantId']||null,'providerData':_0x4e225a,'metadata':new Li(_0x2c2723['createdAt'],_0x2c2723['lastLoginAt']),'isAnonymous':_0x350c46};Object['assign'](_0x28798f,_0x592920);}async function If(_0x5d92b1){const _0x331070=N(_0x5d92b1);await Pn(_0x331070),await _0x331070['auth']['_persistUserIfCurrent'](_0x331070),_0x331070['auth']['_notifyListenersIfCurrent'](_0x331070);}function wf(_0xba9831,_0x48fa54){return[..._0xba9831['filter'](_0x1e6214=>!_0x48fa54['some'](_0x1099d8=>_0x1099d8['providerId']===_0x1e6214['providerId'])),..._0x48fa54];}function Sa(_0x213080){return _0x213080['map'](({providerId:_0x58a1aa,..._0x1b098b})=>({'providerId':_0x58a1aa,'uid':_0x1b098b['rawId']||'','displayName':_0x1b098b['displayName']||null,'email':_0x1b098b['email']||null,'phoneNumber':_0x1b098b['phoneNumber']||null,'photoURL':_0x1b098b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x52c034,_0x5ba4ff){const _0x48996c=await Ca(_0x52c034,{},async()=>{const _0x21dc6c=ut({'grant_type':'refresh_token','refresh_token':_0x5ba4ff})['slice'](0x1),{tokenApiHost:_0x568371,apiKey:_0x40e8e8}=_0x52c034['config'],_0x59c162=await Ta(_0x52c034,_0x568371,'/v1/token','key='+_0x40e8e8),_0x254267=await _0x52c034['_getAdditionalHeaders']();_0x254267['Content-Type']='application/x-www-form-urlencoded';const _0x29e054={'method':'POST','headers':_0x254267,'body':_0x21dc6c};return _0x52c034['emulatorConfig']&&Gt(_0x52c034['emulatorConfig']['host'])&&(_0x29e054['credentials']='include'),wa['fetch']()(_0x59c162,_0x29e054);});return{'accessToken':_0x48996c['access_token'],'expiresIn':_0x48996c['expires_in'],'refreshToken':_0x48996c['refresh_token']};}async function Tf(_0x4c5d1e,_0x281be8){return ke(_0x4c5d1e,'POST','/v2/accounts:revokeToken',Ae(_0x4c5d1e,_0x281be8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x48330d){m(_0x48330d['idToken'],'internal-error'),m(typeof _0x48330d['idToken']<'u','internal-error'),m(typeof _0x48330d['refreshToken']<'u','internal-error');const _0xd27fac='expiresIn'in _0x48330d&&typeof _0x48330d['expiresIn']<'u'?Number(_0x48330d['expiresIn']):Cr(_0x48330d['idToken']);this['updateTokensAndExpiration'](_0x48330d['idToken'],_0x48330d['refreshToken'],_0xd27fac);}['updateFromIdToken'](_0x1703b4){m(_0x1703b4['length']!==0x0,'internal-error');const _0xa252dc=Cr(_0x1703b4);this['updateTokensAndExpiration'](_0x1703b4,null,_0xa252dc);}async['getToken'](_0x2a09cd,_0x351d3c=!0x1){return!_0x351d3c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2a09cd,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2a09cd,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x431fbf,_0xd00710){const {accessToken:_0x7af2b9,refreshToken:_0x2ff4b0,expiresIn:_0x476438}=await Cf(_0x431fbf,_0xd00710);this['updateTokensAndExpiration'](_0x7af2b9,_0x2ff4b0,Number(_0x476438));}['updateTokensAndExpiration'](_0x47f652,_0x27988e,_0x151756){this['refreshToken']=_0x27988e||null,this['accessToken']=_0x47f652||null,this['expirationTime']=Date['now']()+_0x151756*0x3e8;}static['fromJSON'](_0x11f526,_0x124d5c){const {refreshToken:_0x8f541f,accessToken:_0x50fdf1,expirationTime:_0x50eafa}=_0x124d5c,_0x13d20a=new et();return _0x8f541f&&(m(typeof _0x8f541f=='string','internal-error',{'appName':_0x11f526}),_0x13d20a['refreshToken']=_0x8f541f),_0x50fdf1&&(m(typeof _0x50fdf1=='string','internal-error',{'appName':_0x11f526}),_0x13d20a['accessToken']=_0x50fdf1),_0x50eafa&&(m(typeof _0x50eafa=='number','internal-error',{'appName':_0x11f526}),_0x13d20a['expirationTime']=_0x50eafa),_0x13d20a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3d8790){this['accessToken']=_0x3d8790['accessToken'],this['refreshToken']=_0x3d8790['refreshToken'],this['expirationTime']=_0x3d8790['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1cc4c9,_0x43a833){m(typeof _0x1cc4c9=='string'||typeof _0x1cc4c9>'u','internal-error',{'appName':_0x43a833});}class j{constructor({uid:_0x1c804f,auth:_0x1a31b5,stsTokenManager:_0x313f18,..._0x183ef6}){this['providerId']='firebase',this['proactiveRefresh']=new Ef(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1c804f,this['auth']=_0x1a31b5,this['stsTokenManager']=_0x313f18,this['accessToken']=_0x313f18['accessToken'],this['displayName']=_0x183ef6['displayName']||null,this['email']=_0x183ef6['email']||null,this['emailVerified']=_0x183ef6['emailVerified']||!0x1,this['phoneNumber']=_0x183ef6['phoneNumber']||null,this['photoURL']=_0x183ef6['photoURL']||null,this['isAnonymous']=_0x183ef6['isAnonymous']||!0x1,this['tenantId']=_0x183ef6['tenantId']||null,this['providerData']=_0x183ef6['providerData']?[..._0x183ef6['providerData']]:[],this['metadata']=new Li(_0x183ef6['createdAt']||void 0x0,_0x183ef6['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5c6c5d){const _0x1025ce=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x5c6c5d));return m(_0x1025ce,this['auth'],'internal-error'),this['accessToken']!==_0x1025ce&&(this['accessToken']=_0x1025ce,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1025ce;}['getIdTokenResult'](_0x3ed753){return yf(this,_0x3ed753);}['reload'](){return If(this);}['_assign'](_0x21813b){this!==_0x21813b&&(m(this['uid']===_0x21813b['uid'],this['auth'],'internal-error'),this['displayName']=_0x21813b['displayName'],this['photoURL']=_0x21813b['photoURL'],this['email']=_0x21813b['email'],this['emailVerified']=_0x21813b['emailVerified'],this['phoneNumber']=_0x21813b['phoneNumber'],this['isAnonymous']=_0x21813b['isAnonymous'],this['tenantId']=_0x21813b['tenantId'],this['providerData']=_0x21813b['providerData']['map'](_0x4f9151=>({..._0x4f9151})),this['metadata']['_copy'](_0x21813b['metadata']),this['stsTokenManager']['_assign'](_0x21813b['stsTokenManager']));}['_clone'](_0x5ee0c1){const _0x56425d=new j({...this,'auth':_0x5ee0c1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x56425d['metadata']['_copy'](this['metadata']),_0x56425d;}['_onReload'](_0x5c7ea0){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5c7ea0,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3bfa3a){this['reloadListener']?this['reloadListener'](_0x3bfa3a):this['reloadUserInfo']=_0x3bfa3a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3819dc,_0x850fbf=!0x1){let _0x19700e=!0x1;_0x3819dc['idToken']&&_0x3819dc['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3819dc),_0x19700e=!0x0),_0x850fbf&&await Pn(this),await this['auth']['_persistUserIfCurrent'](this),_0x19700e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4b1a1b=await this['getIdToken']();return await Vt(this,mf(this['auth'],{'idToken':_0x4b1a1b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xcee721=>({..._0xcee721})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5438f4,_0x57586b){const _0x7b3a3e=_0x57586b['displayName']??void 0x0,_0x72ecdf=_0x57586b['email']??void 0x0,_0x1ed94a=_0x57586b['phoneNumber']??void 0x0,_0x44f7c3=_0x57586b['photoURL']??void 0x0,_0x243387=_0x57586b['tenantId']??void 0x0,_0x50bed4=_0x57586b['_redirectEventId']??void 0x0,_0x59dfd8=_0x57586b['createdAt']??void 0x0,_0x250b21=_0x57586b['lastLoginAt']??void 0x0,{uid:_0x14dbd2,emailVerified:_0x111afc,isAnonymous:_0x346edc,providerData:_0x4be702,stsTokenManager:_0x597284}=_0x57586b;m(_0x14dbd2&&_0x597284,_0x5438f4,'internal-error');const _0x5155d6=et['fromJSON'](this['name'],_0x597284);m(typeof _0x14dbd2=='string',_0x5438f4,'internal-error'),le(_0x7b3a3e,_0x5438f4['name']),le(_0x72ecdf,_0x5438f4['name']),m(typeof _0x111afc=='boolean',_0x5438f4,'internal-error'),m(typeof _0x346edc=='boolean',_0x5438f4,'internal-error'),le(_0x1ed94a,_0x5438f4['name']),le(_0x44f7c3,_0x5438f4['name']),le(_0x243387,_0x5438f4['name']),le(_0x50bed4,_0x5438f4['name']),le(_0x59dfd8,_0x5438f4['name']),le(_0x250b21,_0x5438f4['name']);const _0x2beb65=new j({'uid':_0x14dbd2,'auth':_0x5438f4,'email':_0x72ecdf,'emailVerified':_0x111afc,'displayName':_0x7b3a3e,'isAnonymous':_0x346edc,'photoURL':_0x44f7c3,'phoneNumber':_0x1ed94a,'tenantId':_0x243387,'stsTokenManager':_0x5155d6,'createdAt':_0x59dfd8,'lastLoginAt':_0x250b21});return _0x4be702&&Array['isArray'](_0x4be702)&&(_0x2beb65['providerData']=_0x4be702['map'](_0x561b44=>({..._0x561b44}))),_0x50bed4&&(_0x2beb65['_redirectEventId']=_0x50bed4),_0x2beb65;}static async['_fromIdTokenResponse'](_0x238bf2,_0x53e5e2,_0x3251e2=!0x1){const _0x4a2f60=new et();_0x4a2f60['updateFromServerResponse'](_0x53e5e2);const _0x25560b=new j({'uid':_0x53e5e2['localId'],'auth':_0x238bf2,'stsTokenManager':_0x4a2f60,'isAnonymous':_0x3251e2});return await Pn(_0x25560b),_0x25560b;}static async['_fromGetAccountInfoResponse'](_0x45ffb7,_0x56595e,_0x2567b9){const _0x24541c=_0x56595e['users'][0x0];m(_0x24541c['localId']!==void 0x0,'internal-error');const _0x2ae475=_0x24541c['providerUserInfo']!==void 0x0?Sa(_0x24541c['providerUserInfo']):[],_0x5d6bdc=!(_0x24541c['email']&&_0x24541c['passwordHash'])&&!(_0x2ae475!=null&&_0x2ae475['length']),_0x466b5e=new et();_0x466b5e['updateFromIdToken'](_0x2567b9);const _0x576220=new j({'uid':_0x24541c['localId'],'auth':_0x45ffb7,'stsTokenManager':_0x466b5e,'isAnonymous':_0x5d6bdc}),_0x418edb={'uid':_0x24541c['localId'],'displayName':_0x24541c['displayName']||null,'photoURL':_0x24541c['photoUrl']||null,'email':_0x24541c['email']||null,'emailVerified':_0x24541c['emailVerified']||!0x1,'phoneNumber':_0x24541c['phoneNumber']||null,'tenantId':_0x24541c['tenantId']||null,'providerData':_0x2ae475,'metadata':new Li(_0x24541c['createdAt'],_0x24541c['lastLoginAt']),'isAnonymous':!(_0x24541c['email']&&_0x24541c['passwordHash'])&&!(_0x2ae475!=null&&_0x2ae475['length'])};return Object['assign'](_0x576220,_0x418edb),_0x576220;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x9f2562){ce(_0x9f2562 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x240b31=Tr['get'](_0x9f2562);return _0x240b31?(ce(_0x240b31 instanceof _0x9f2562,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x240b31):(_0x240b31=new _0x9f2562(),Tr['set'](_0x9f2562,_0x240b31),_0x240b31);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5c3a8e,_0x51b88c){this['storage'][_0x5c3a8e]=_0x51b88c;}async['_get'](_0x190d2b){const _0x4baad8=this['storage'][_0x190d2b];return _0x4baad8===void 0x0?null:_0x4baad8;}async['_remove'](_0xaf8271){delete this['storage'][_0xaf8271];}['_addListener'](_0x57df16,_0xf146e6){}['_removeListener'](_0x534f5e,_0x5502bb){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3d674f,_0x3eb9e1,_0x266ef0){return'firebase:'+_0x3d674f+':'+_0x3eb9e1+':'+_0x266ef0;}class tt{constructor(_0x3c13bd,_0x397de5,_0x6f27e){this['persistence']=_0x3c13bd,this['auth']=_0x397de5,this['userKey']=_0x6f27e;const {config:_0xc885af,name:_0x5703fb}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0xc885af['apiKey'],_0x5703fb),this['fullPersistenceKey']=ln('persistence',_0xc885af['apiKey'],_0x5703fb),this['boundEventHandler']=_0x397de5['_onStorageEvent']['bind'](_0x397de5),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4ae4b5){return this['persistence']['_set'](this['fullUserKey'],_0x4ae4b5['toJSON']());}async['getCurrentUser'](){const _0x14405f=await this['persistence']['_get'](this['fullUserKey']);if(!_0x14405f)return null;if(typeof _0x14405f=='string'){const _0x3364fc=await Nn(this['auth'],{'idToken':_0x14405f})['catch'](()=>{});return _0x3364fc?j['_fromGetAccountInfoResponse'](this['auth'],_0x3364fc,_0x14405f):null;}return j['_fromJSON'](this['auth'],_0x14405f);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x936a75){if(this['persistence']===_0x936a75)return;const _0x190bf0=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x936a75,_0x190bf0)return this['setCurrentUser'](_0x190bf0);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x423ff8,_0x32c8dc,_0x58ef3f='authUser'){if(!_0x32c8dc['length'])return new tt(ie(Sr),_0x423ff8,_0x58ef3f);const _0x154bbd=(await Promise['all'](_0x32c8dc['map'](async _0x296b04=>{if(await _0x296b04['_isAvailable']())return _0x296b04;})))['filter'](_0x3a67d0=>_0x3a67d0);let _0x4422e7=_0x154bbd[0x0]||ie(Sr);const _0x3bb2f8=ln(_0x58ef3f,_0x423ff8['config']['apiKey'],_0x423ff8['name']);let _0x45d028=null;for(const _0x5e4f43 of _0x32c8dc)try{const _0x55d03d=await _0x5e4f43['_get'](_0x3bb2f8);if(_0x55d03d){let _0x48fccb;if(typeof _0x55d03d=='string'){const _0x227d7d=await Nn(_0x423ff8,{'idToken':_0x55d03d})['catch'](()=>{});if(!_0x227d7d)break;_0x48fccb=await j['_fromGetAccountInfoResponse'](_0x423ff8,_0x227d7d,_0x55d03d);}else _0x48fccb=j['_fromJSON'](_0x423ff8,_0x55d03d);_0x5e4f43!==_0x4422e7&&(_0x45d028=_0x48fccb),_0x4422e7=_0x5e4f43;break;}}catch{}const _0x1aece5=_0x154bbd['filter'](_0x5b848e=>_0x5b848e['_shouldAllowMigration']);return!_0x4422e7['_shouldAllowMigration']||!_0x1aece5['length']?new tt(_0x4422e7,_0x423ff8,_0x58ef3f):(_0x4422e7=_0x1aece5[0x0],_0x45d028&&await _0x4422e7['_set'](_0x3bb2f8,_0x45d028['toJSON']()),await Promise['all'](_0x32c8dc['map'](async _0x84f1bc=>{if(_0x84f1bc!==_0x4422e7)try{await _0x84f1bc['_remove'](_0x3bb2f8);}catch{}})),new tt(_0x4422e7,_0x423ff8,_0x58ef3f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x29dbbe){const _0x16e732=_0x29dbbe['toLowerCase']();if(_0x16e732['includes']('opera/')||_0x16e732['includes']('opr/')||_0x16e732['includes']('opios/'))return'Opera';if(Na(_0x16e732))return'IEMobile';if(_0x16e732['includes']('msie')||_0x16e732['includes']('trident/'))return'IE';if(_0x16e732['includes']('edge/'))return'Edge';if(Ra(_0x16e732))return'Firefox';if(_0x16e732['includes']('silk/'))return'Silk';if(Oa(_0x16e732))return'Blackberry';if(Da(_0x16e732))return'Webos';if(Aa(_0x16e732))return'Safari';if((_0x16e732['includes']('chrome/')||ka(_0x16e732))&&!_0x16e732['includes']('edge/'))return'Chrome';if(Pa(_0x16e732))return'Android';{const _0x59eecd=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2947b8=_0x29dbbe['match'](_0x59eecd);if((_0x2947b8==null?void 0x0:_0x2947b8['length'])===0x2)return _0x2947b8[0x1];}return'Other';}function Ra(_0x5058ab=W()){return/firefox\//i['test'](_0x5058ab);}function Aa(_0x379d85=W()){const _0x5bdcef=_0x379d85['toLowerCase']();return _0x5bdcef['includes']('safari/')&&!_0x5bdcef['includes']('chrome/')&&!_0x5bdcef['includes']('crios/')&&!_0x5bdcef['includes']('android');}function ka(_0xaaca37=W()){return/crios\//i['test'](_0xaaca37);}function Na(_0x2dfdd5=W()){return/iemobile/i['test'](_0x2dfdd5);}function Pa(_0x10bbfd=W()){return/android/i['test'](_0x10bbfd);}function Oa(_0x9f8eca=W()){return/blackberry/i['test'](_0x9f8eca);}function Da(_0x5b927e=W()){return/webos/i['test'](_0x5b927e);}function Ss(_0x2ac99b=W()){return/iphone|ipad|ipod/i['test'](_0x2ac99b)||/macintosh/i['test'](_0x2ac99b)&&/mobile/i['test'](_0x2ac99b);}function Sf(_0x591ee3=W()){var _0x531aca;return Ss(_0x591ee3)&&!!((_0x531aca=window['navigator'])!=null&&_0x531aca['standalone']);}function bf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5d7fdc=W()){return Ss(_0x5d7fdc)||Pa(_0x5d7fdc)||Da(_0x5d7fdc)||Oa(_0x5d7fdc)||/windows phone/i['test'](_0x5d7fdc)||Na(_0x5d7fdc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x9dc1f5,_0x149a72=[]){let _0x3e304c;switch(_0x9dc1f5){case'Browser':_0x3e304c=br(W());break;case'Worker':_0x3e304c=br(W())+'-'+_0x9dc1f5;break;default:_0x3e304c=_0x9dc1f5;}const _0x136590=_0x149a72['length']?_0x149a72['join'](','):'FirebaseCore-web';return _0x3e304c+'/JsCore/'+dt+'/'+_0x136590;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rf{constructor(_0x5177cd){this['auth']=_0x5177cd,this['queue']=[];}['pushCallback'](_0x38a989,_0x364f06){const _0x4c4cf6=_0x2c4510=>new Promise((_0x13e6af,_0x5222dc)=>{try{const _0x402425=_0x38a989(_0x2c4510);_0x13e6af(_0x402425);}catch(_0x4b8f9d){_0x5222dc(_0x4b8f9d);}});_0x4c4cf6['onAbort']=_0x364f06,this['queue']['push'](_0x4c4cf6);const _0x5180cd=this['queue']['length']-0x1;return()=>{this['queue'][_0x5180cd]=()=>Promise['resolve']();};}async['runMiddleware'](_0x20ffa7){if(this['auth']['currentUser']===_0x20ffa7)return;const _0x4ff7a5=[];try{for(const _0x13bb99 of this['queue'])await _0x13bb99(_0x20ffa7),_0x13bb99['onAbort']&&_0x4ff7a5['push'](_0x13bb99['onAbort']);}catch(_0x9d3ee8){_0x4ff7a5['reverse']();for(const _0x15b384 of _0x4ff7a5)try{_0x15b384();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x9d3ee8==null?void 0x0:_0x9d3ee8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x2e5a00,_0x1478a1={}){return ke(_0x2e5a00,'GET','/v2/passwordPolicy',Ae(_0x2e5a00,_0x1478a1));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kf=0x6;class Nf{constructor(_0x1ecf11){var _0x134602;const _0x6fb8cb=_0x1ecf11['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x6fb8cb['minPasswordLength']??kf,_0x6fb8cb['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x6fb8cb['maxPasswordLength']),_0x6fb8cb['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x6fb8cb['containsLowercaseCharacter']),_0x6fb8cb['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x6fb8cb['containsUppercaseCharacter']),_0x6fb8cb['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x6fb8cb['containsNumericCharacter']),_0x6fb8cb['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x6fb8cb['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1ecf11['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x134602=_0x1ecf11['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x134602['join'](''))??'',this['forceUpgradeOnSignin']=_0x1ecf11['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1ecf11['schemaVersion'];}['validatePassword'](_0x11f894){const _0x3d3351={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x11f894,_0x3d3351),this['validatePasswordCharacterOptions'](_0x11f894,_0x3d3351),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['meetsMinPasswordLength']??!0x0),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['meetsMaxPasswordLength']??!0x0),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['containsLowercaseLetter']??!0x0),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['containsUppercaseLetter']??!0x0),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['containsNumericCharacter']??!0x0),_0x3d3351['isValid']&&(_0x3d3351['isValid']=_0x3d3351['containsNonAlphanumericCharacter']??!0x0),_0x3d3351;}['validatePasswordLengthOptions'](_0x145a5e,_0xab198c){const _0x5cb50d=this['customStrengthOptions']['minPasswordLength'],_0x40f688=this['customStrengthOptions']['maxPasswordLength'];_0x5cb50d&&(_0xab198c['meetsMinPasswordLength']=_0x145a5e['length']>=_0x5cb50d),_0x40f688&&(_0xab198c['meetsMaxPasswordLength']=_0x145a5e['length']<=_0x40f688);}['validatePasswordCharacterOptions'](_0x584173,_0x411937){this['updatePasswordCharacterOptionsStatuses'](_0x411937,!0x1,!0x1,!0x1,!0x1);let _0x36d640;for(let _0x299a0a=0x0;_0x299a0a<_0x584173['length'];_0x299a0a++)_0x36d640=_0x584173['charAt'](_0x299a0a),this['updatePasswordCharacterOptionsStatuses'](_0x411937,_0x36d640>='a'&&_0x36d640<='z',_0x36d640>='A'&&_0x36d640<='Z',_0x36d640>='0'&&_0x36d640<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x36d640));}['updatePasswordCharacterOptionsStatuses'](_0x69a885,_0x217328,_0x4ad536,_0x475df2,_0x123b3f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x69a885['containsLowercaseLetter']||(_0x69a885['containsLowercaseLetter']=_0x217328)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x69a885['containsUppercaseLetter']||(_0x69a885['containsUppercaseLetter']=_0x4ad536)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x69a885['containsNumericCharacter']||(_0x69a885['containsNumericCharacter']=_0x475df2)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x69a885['containsNonAlphanumericCharacter']||(_0x69a885['containsNonAlphanumericCharacter']=_0x123b3f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pf{constructor(_0x228f4e,_0x169259,_0x3c0173,_0x1774aa){this['app']=_0x228f4e,this['heartbeatServiceProvider']=_0x169259,this['appCheckServiceProvider']=_0x3c0173,this['config']=_0x1774aa,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Rf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x228f4e['name'],this['clientVersion']=_0x1774aa['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x15b355=>this['_resolvePersistenceManagerAvailable']=_0x15b355);}['_initializeWithPersistence'](_0x263ba2,_0x2eb011){return _0x2eb011&&(this['_popupRedirectResolver']=ie(_0x2eb011)),this['_initializationPromise']=this['queue'](async()=>{var _0x4c22e9,_0x4cfde5,_0x4bdb55;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x263ba2),(_0x4c22e9=this['_resolvePersistenceManagerAvailable'])==null||_0x4c22e9['call'](this),!this['_deleted'])){if((_0x4cfde5=this['_popupRedirectResolver'])!=null&&_0x4cfde5['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2eb011),this['lastNotifiedUid']=((_0x4bdb55=this['currentUser'])==null?void 0x0:_0x4bdb55['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x46cf8e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x46cf8e)){if(this['currentUser']&&_0x46cf8e&&this['currentUser']['uid']===_0x46cf8e['uid']){this['_currentUser']['_assign'](_0x46cf8e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x46cf8e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x10951f){try{const _0x1f77c8=await Nn(this,{'idToken':_0x10951f}),_0x106767=await j['_fromGetAccountInfoResponse'](this,_0x1f77c8,_0x10951f);await this['directlySetCurrentUser'](_0x106767);}catch(_0x28d13f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x28d13f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2e895e){var _0x2c76ef;if($(this['app'])){const _0x291de4=this['app']['settings']['authIdToken'];return _0x291de4?new Promise(_0x1f196e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x291de4)['then'](_0x1f196e,_0x1f196e));}):this['directlySetCurrentUser'](null);}const _0x216800=await this['assertedPersistence']['getCurrentUser']();let _0x2b24ee=_0x216800,_0x47c13e=!0x1;if(_0x2e895e&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x22522a=(_0x2c76ef=this['redirectUser'])==null?void 0x0:_0x2c76ef['_redirectEventId'],_0x541d05=_0x2b24ee==null?void 0x0:_0x2b24ee['_redirectEventId'],_0x24fe6d=await this['tryRedirectSignIn'](_0x2e895e);(!_0x22522a||_0x22522a===_0x541d05)&&(_0x24fe6d!=null&&_0x24fe6d['user'])&&(_0x2b24ee=_0x24fe6d['user'],_0x47c13e=!0x0);}if(!_0x2b24ee)return this['directlySetCurrentUser'](null);if(!_0x2b24ee['_redirectEventId']){if(_0x47c13e)try{await this['beforeStateQueue']['runMiddleware'](_0x2b24ee);}catch(_0x2c169d){_0x2b24ee=_0x216800,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2c169d));}return _0x2b24ee?this['reloadAndSetCurrentUserOrClear'](_0x2b24ee):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2b24ee['_redirectEventId']?this['directlySetCurrentUser'](_0x2b24ee):this['reloadAndSetCurrentUserOrClear'](_0x2b24ee);}async['tryRedirectSignIn'](_0x444e42){let _0x52db60=null;try{_0x52db60=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x444e42,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x52db60;}async['reloadAndSetCurrentUserOrClear'](_0x122dac){try{await Pn(_0x122dac);}catch(_0x32e375){if((_0x32e375==null?void 0x0:_0x32e375['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x122dac);}['useDeviceLanguage'](){this['languageCode']=lf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x271cb7){if($(this['app']))return Promise['reject'](re(this));const _0x492f70=_0x271cb7?N(_0x271cb7):null;return _0x492f70&&m(_0x492f70['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x492f70&&_0x492f70['_clone'](this));}async['_updateCurrentUser'](_0x21d251,_0x4df235=!0x1){if(!this['_deleted'])return _0x21d251&&m(this['tenantId']===_0x21d251['tenantId'],this,'tenant-id-mismatch'),_0x4df235||await this['beforeStateQueue']['runMiddleware'](_0x21d251),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x21d251),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x279882){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x279882));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x198826){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3139ce=this['_getPasswordPolicyInternal']();return _0x3139ce['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3139ce['validatePassword'](_0x198826);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4f7cd5=await Af(this),_0x1f9876=new Nf(_0x4f7cd5);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1f9876:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1f9876;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x183ce4){this['_errorFactory']=new $t('auth','Firebase',_0x183ce4());}['onAuthStateChanged'](_0x3e3420,_0x53f09d,_0x3f732b){return this['registerStateListener'](this['authStateSubscription'],_0x3e3420,_0x53f09d,_0x3f732b);}['beforeAuthStateChanged'](_0x4aef58,_0x112a09){return this['beforeStateQueue']['pushCallback'](_0x4aef58,_0x112a09);}['onIdTokenChanged'](_0x17aad7,_0x549e41,_0x54d598){return this['registerStateListener'](this['idTokenSubscription'],_0x17aad7,_0x549e41,_0x54d598);}['authStateReady'](){return new Promise((_0x2c74a5,_0x259a9b)=>{if(this['currentUser'])_0x2c74a5();else{const _0x46426c=this['onAuthStateChanged'](()=>{_0x46426c(),_0x2c74a5();},_0x259a9b);}});}async['revokeAccessToken'](_0xb70a35){if(this['currentUser']){const _0x195828=await this['currentUser']['getIdToken'](),_0x1cbef1={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0xb70a35,'idToken':_0x195828};this['tenantId']!=null&&(_0x1cbef1['tenantId']=this['tenantId']),await Tf(this,_0x1cbef1);}}['toJSON'](){var _0x46355a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x46355a=this['_currentUser'])==null?void 0x0:_0x46355a['toJSON']()};}async['_setRedirectUser'](_0x57c99d,_0x172bbc){const _0x11cf57=await this['getOrInitRedirectPersistenceManager'](_0x172bbc);return _0x57c99d===null?_0x11cf57['removeCurrentUser']():_0x11cf57['setCurrentUser'](_0x57c99d);}async['getOrInitRedirectPersistenceManager'](_0x14cee1){if(!this['redirectPersistenceManager']){const _0x5eb935=_0x14cee1&&ie(_0x14cee1)||this['_popupRedirectResolver'];m(_0x5eb935,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x5eb935['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x15a889){var _0x4afea1,_0x338261;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4afea1=this['_currentUser'])==null?void 0x0:_0x4afea1['_redirectEventId'])===_0x15a889?this['_currentUser']:((_0x338261=this['redirectUser'])==null?void 0x0:_0x338261['_redirectEventId'])===_0x15a889?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4270b1){if(_0x4270b1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4270b1));}['_notifyListenersIfCurrent'](_0x43dc9b){_0x43dc9b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x47f9d8;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x92a0f=((_0x47f9d8=this['currentUser'])==null?void 0x0:_0x47f9d8['uid'])??null;this['lastNotifiedUid']!==_0x92a0f&&(this['lastNotifiedUid']=_0x92a0f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x476059,_0x5ad1a8,_0x5a6b94,_0x54d9f4){if(this['_deleted'])return()=>{};const _0x580692=typeof _0x5ad1a8=='function'?_0x5ad1a8:_0x5ad1a8['next']['bind'](_0x5ad1a8);let _0x32a163=!0x1;const _0x561735=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x561735,this,'internal-error'),_0x561735['then'](()=>{_0x32a163||_0x580692(this['currentUser']);}),typeof _0x5ad1a8=='function'){const _0x35884a=_0x476059['addObserver'](_0x5ad1a8,_0x5a6b94,_0x54d9f4);return()=>{_0x32a163=!0x0,_0x35884a();};}else{const _0x7e1094=_0x476059['addObserver'](_0x5ad1a8);return()=>{_0x32a163=!0x0,_0x7e1094();};}}async['directlySetCurrentUser'](_0x389fe5){this['currentUser']&&this['currentUser']!==_0x389fe5&&this['_currentUser']['_stopProactiveRefresh'](),_0x389fe5&&this['isProactiveRefreshEnabled']&&_0x389fe5['_startProactiveRefresh'](),this['currentUser']=_0x389fe5,_0x389fe5?await this['assertedPersistence']['setCurrentUser'](_0x389fe5):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x235ae7){return this['operations']=this['operations']['then'](_0x235ae7,_0x235ae7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4b8963){!_0x4b8963||this['frameworks']['includes'](_0x4b8963)||(this['frameworks']['push'](_0x4b8963),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x476374;const _0x50e632={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x50e632['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x54811b=await((_0x476374=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x476374['getHeartbeatsHeader']());_0x54811b&&(_0x50e632['X-Firebase-Client']=_0x54811b);const _0x2d6a22=await this['_getAppCheckToken']();return _0x2d6a22&&(_0x50e632['X-Firebase-AppCheck']=_0x2d6a22),_0x50e632;}async['_getAppCheckToken'](){var _0x35cfaf;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5995b7=await((_0x35cfaf=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x35cfaf['getToken']());return _0x5995b7!=null&&_0x5995b7['error']&&of('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5995b7['error']),_0x5995b7==null?void 0x0:_0x5995b7['token'];}}function Ke(_0x298c3a){return N(_0x298c3a);}class Rr{constructor(_0x410fc8){this['auth']=_0x410fc8,this['observer']=null,this['addObserver']=Tc(_0xe69b60=>this['observer']=_0xe69b60);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Of(_0x4ab630){Jn=_0x4ab630;}function xa(_0x150c6e){return Jn['loadJS'](_0x150c6e);}function Df(){return Jn['recaptchaEnterpriseScript'];}function Mf(){return Jn['gapiScript'];}function Lf(_0x1d9556){return'__'+_0x1d9556+Math['floor'](Math['random']()*0xf4240);}class xf{constructor(){this['enterprise']=new Ff();}['ready'](_0x43966e){_0x43966e();}['execute'](_0xbf0f19,_0x1b3ba8){return Promise['resolve']('token');}['render'](_0x67d844,_0xff275f){return'';}}class Ff{['ready'](_0x336afa){_0x336afa();}['execute'](_0x5171a0,_0x211e29){return Promise['resolve']('token');}['render'](_0x14069d,_0x110e61){return'';}}const Uf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x18a690){this['type']=Uf,this['auth']=Ke(_0x18a690);}async['verify'](_0x2610bf='verify',_0x3dd53c=!0x1){async function _0xf7f2a6(_0x1ef698){if(!_0x3dd53c){if(_0x1ef698['tenantId']==null&&_0x1ef698['_agentRecaptchaConfig']!=null)return _0x1ef698['_agentRecaptchaConfig']['siteKey'];if(_0x1ef698['tenantId']!=null&&_0x1ef698['_tenantRecaptchaConfigs'][_0x1ef698['tenantId']]!==void 0x0)return _0x1ef698['_tenantRecaptchaConfigs'][_0x1ef698['tenantId']]['siteKey'];}return new Promise(async(_0x187c4e,_0x39a069)=>{gf(_0x1ef698,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1e6f7b=>{if(_0x1e6f7b['recaptchaKey']===void 0x0)_0x39a069(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x328bb2=new _f(_0x1e6f7b);return _0x1ef698['tenantId']==null?_0x1ef698['_agentRecaptchaConfig']=_0x328bb2:_0x1ef698['_tenantRecaptchaConfigs'][_0x1ef698['tenantId']]=_0x328bb2,_0x187c4e(_0x328bb2['siteKey']);}})['catch'](_0x3f6b33=>{_0x39a069(_0x3f6b33);});});}function _0x28aca8(_0xa7354a,_0x53501d,_0x1d6c32){const _0x34ab76=window['grecaptcha'];wr(_0x34ab76)?_0x34ab76['enterprise']['ready'](()=>{_0x34ab76['enterprise']['execute'](_0xa7354a,{'action':_0x2610bf})['then'](_0x33d08b=>{_0x53501d(_0x33d08b);})['catch'](()=>{_0x53501d(Fa);});}):_0x1d6c32(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new xf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x54e1af,_0x2b604e)=>{_0xf7f2a6(this['auth'])['then'](async _0x5097a2=>{if(!_0x3dd53c&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x28aca8(_0x5097a2,_0x54e1af,_0x2b604e);else{if(typeof window>'u'){_0x2b604e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4215f4=Df();_0x4215f4['length']!==0x0&&(_0x4215f4+=_0x5097a2+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0xaa50c;(_0xaa50c=he['scriptInjectionDeferred'])==null||_0xaa50c['resolve']();},xa(_0x4215f4)['then'](()=>{var _0x3838ae;return(_0x3838ae=he['scriptInjectionDeferred'])==null?void 0x0:_0x3838ae['promise'];})['then'](()=>{_0x28aca8(_0x5097a2,_0x54e1af,_0x2b604e);})['catch'](_0x2048e1=>{_0x2b604e(_0x2048e1);});}})['catch'](_0x2c138e=>{_0x2b604e(_0x2c138e);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x19d1e4,_0x1cebc8,_0x599a82,_0x4fdebe=!0x1,_0x375943=!0x1){const _0x4d5ad3=new he(_0x19d1e4);let _0x18a9df;if(_0x375943)_0x18a9df=Fa;else try{_0x18a9df=await _0x4d5ad3['verify'](_0x599a82);}catch{_0x18a9df=await _0x4d5ad3['verify'](_0x599a82,!0x0);}const _0x3de7a0={..._0x1cebc8};if(_0x599a82==='mfaSmsEnrollment'||_0x599a82==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3de7a0){const _0x46d441=_0x3de7a0['phoneEnrollmentInfo']['phoneNumber'],_0x4c248e=_0x3de7a0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3de7a0,{'phoneEnrollmentInfo':{'phoneNumber':_0x46d441,'recaptchaToken':_0x4c248e,'captchaResponse':_0x18a9df,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3de7a0){const _0xcf6836=_0x3de7a0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3de7a0,{'phoneSignInInfo':{'recaptchaToken':_0xcf6836,'captchaResponse':_0x18a9df,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3de7a0;}return _0x4fdebe?Object['assign'](_0x3de7a0,{'captchaResp':_0x18a9df}):Object['assign'](_0x3de7a0,{'captchaResponse':_0x18a9df}),Object['assign'](_0x3de7a0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3de7a0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3de7a0;}async function xi(_0x57a764,_0x1a54fc,_0x3068c5,_0x51fb05,_0x296d3a){var _0x1fc72f;if((_0x1fc72f=_0x57a764['_getRecaptchaConfig']())!=null&&_0x1fc72f['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3a8b95=await kr(_0x57a764,_0x1a54fc,_0x3068c5,_0x3068c5==='getOobCode');return _0x51fb05(_0x57a764,_0x3a8b95);}else return _0x51fb05(_0x57a764,_0x1a54fc)['catch'](async _0x591eba=>{if(_0x591eba['code']==='auth/missing-recaptcha-token'){console['log'](_0x3068c5+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3df4d4=await kr(_0x57a764,_0x1a54fc,_0x3068c5,_0x3068c5==='getOobCode');return _0x51fb05(_0x57a764,_0x3df4d4);}else return Promise['reject'](_0x591eba);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wf(_0xc9a110,_0x44a8db){const _0x2a7b6f=Hi(_0xc9a110,'auth');if(_0x2a7b6f['isInitialized']()){const _0x5cd2b5=_0x2a7b6f['getImmediate'](),_0x5cf46c=_0x2a7b6f['getOptions']();if(Le(_0x5cf46c,_0x44a8db??{}))return _0x5cd2b5;Y(_0x5cd2b5,'already-initialized');}return _0x2a7b6f['initialize']({'options':_0x44a8db});}function Bf(_0x7fc19,_0x26b7c9){const _0x67def2=(_0x26b7c9==null?void 0x0:_0x26b7c9['persistence'])||[],_0x4f4a6e=(Array['isArray'](_0x67def2)?_0x67def2:[_0x67def2])['map'](ie);_0x26b7c9!=null&&_0x26b7c9['errorMap']&&_0x7fc19['_updateErrorMap'](_0x26b7c9['errorMap']),_0x7fc19['_initializeWithPersistence'](_0x4f4a6e,_0x26b7c9==null?void 0x0:_0x26b7c9['popupRedirectResolver']);}function Vf(_0x54762e,_0x8e2c14,_0x4d0c8b){const _0x2b6f92=Ke(_0x54762e);m(/^https?:\/\//['test'](_0x8e2c14),_0x2b6f92,'invalid-emulator-scheme');const _0x3b64c6=!0x1,_0x2bf327=Ua(_0x8e2c14),{host:_0x46f911,port:_0x34169d}=Hf(_0x8e2c14),_0x5e290e=_0x34169d===null?'':':'+_0x34169d,_0x14ea30={'url':_0x2bf327+'//'+_0x46f911+_0x5e290e+'/'},_0x52c82f=Object['freeze']({'host':_0x46f911,'port':_0x34169d,'protocol':_0x2bf327['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3b64c6})});if(!_0x2b6f92['_canInitEmulator']){m(_0x2b6f92['config']['emulator']&&_0x2b6f92['emulatorConfig'],_0x2b6f92,'emulator-config-failed'),m(Le(_0x14ea30,_0x2b6f92['config']['emulator'])&&Le(_0x52c82f,_0x2b6f92['emulatorConfig']),_0x2b6f92,'emulator-config-failed');return;}_0x2b6f92['config']['emulator']=_0x14ea30,_0x2b6f92['emulatorConfig']=_0x52c82f,_0x2b6f92['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x46f911)?Qr(_0x2bf327+'//'+_0x46f911+_0x5e290e):$f();}function Ua(_0xf55eb2){const _0x1cb5b0=_0xf55eb2['indexOf'](':');return _0x1cb5b0<0x0?'':_0xf55eb2['substr'](0x0,_0x1cb5b0+0x1);}function Hf(_0xd7cfb9){const _0x180755=Ua(_0xd7cfb9),_0x3859da=/(\/\/)?([^?#/]+)/['exec'](_0xd7cfb9['substr'](_0x180755['length']));if(!_0x3859da)return{'host':'','port':null};const _0x5162b8=_0x3859da[0x2]['split']('@')['pop']()||'',_0x402a20=/^(\[[^\]]+\])(:|$)/['exec'](_0x5162b8);if(_0x402a20){const _0x588177=_0x402a20[0x1];return{'host':_0x588177,'port':Nr(_0x5162b8['substr'](_0x588177['length']+0x1))};}else{const [_0x358664,_0x1f338b]=_0x5162b8['split'](':');return{'host':_0x358664,'port':Nr(_0x1f338b)};}}function Nr(_0x52b4a0){if(!_0x52b4a0)return null;const _0x6bd104=Number(_0x52b4a0);return isNaN(_0x6bd104)?null:_0x6bd104;}function $f(){function _0x547a4e(){const _0x820b8a=document['createElement']('p'),_0x37b9a7=_0x820b8a['style'];_0x820b8a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x37b9a7['position']='fixed',_0x37b9a7['width']='100%',_0x37b9a7['backgroundColor']='#ffffff',_0x37b9a7['border']='.1em\x20solid\x20#000000',_0x37b9a7['color']='#b50000',_0x37b9a7['bottom']='0px',_0x37b9a7['left']='0px',_0x37b9a7['margin']='0px',_0x37b9a7['zIndex']='10000',_0x37b9a7['textAlign']='center',_0x820b8a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x820b8a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x547a4e):_0x547a4e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x9d0e9,_0x43e3bf){this['providerId']=_0x9d0e9,this['signInMethod']=_0x43e3bf;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x56c56f){return ne('not\x20implemented');}['_linkToIdToken'](_0x4ac706,_0x23e5e5){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2a6a81){return ne('not\x20implemented');}}async function Gf(_0x19916e,_0x15bb0d){return ke(_0x19916e,'POST','/v1/accounts:signUp',_0x15bb0d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5407fc,_0x2c1329){return en(_0x5407fc,'POST','/v1/accounts:signInWithPassword',Ae(_0x5407fc,_0x2c1329));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x50718b,_0x46517f){return en(_0x50718b,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x50718b,_0x46517f));}async function jf(_0x37da89,_0x3211bd){return en(_0x37da89,'POST','/v1/accounts:signInWithEmailLink',Ae(_0x37da89,_0x3211bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x34bdc9,_0x39b0fa,_0x3e7ec0,_0x4e0dc2=null){super('password',_0x3e7ec0),this['_email']=_0x34bdc9,this['_password']=_0x39b0fa,this['_tenantId']=_0x4e0dc2;}static['_fromEmailAndPassword'](_0x570684,_0x317e75){return new Ht(_0x570684,_0x317e75,'password');}static['_fromEmailAndCode'](_0x54b103,_0x2f7eb2,_0x10c5b4=null){return new Ht(_0x54b103,_0x2f7eb2,'emailLink',_0x10c5b4);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x15d3bd){const _0x5a2075=typeof _0x15d3bd=='string'?JSON['parse'](_0x15d3bd):_0x15d3bd;if(_0x5a2075!=null&&_0x5a2075['email']&&(_0x5a2075!=null&&_0x5a2075['password'])){if(_0x5a2075['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5a2075['email'],_0x5a2075['password']);if(_0x5a2075['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5a2075['email'],_0x5a2075['password'],_0x5a2075['tenantId']);}return null;}async['_getIdTokenResponse'](_0x14c03c){switch(this['signInMethod']){case'password':const _0x2018e4={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x14c03c,_0x2018e4,'signInWithPassword',qf);case'emailLink':return zf(_0x14c03c,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x14c03c,'internal-error');}}async['_linkToIdToken'](_0x4304f3,_0x469a88){switch(this['signInMethod']){case'password':const _0x49b5f2={'idToken':_0x469a88,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4304f3,_0x49b5f2,'signUpPassword',Gf);case'emailLink':return jf(_0x4304f3,{'idToken':_0x469a88,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4304f3,'internal-error');}}['_getReauthenticationResolver'](_0x2f46d0){return this['_getIdTokenResponse'](_0x2f46d0);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2f2bae,_0x247cf6){return en(_0x2f2bae,'POST','/v1/accounts:signInWithIdp',Ae(_0x2f2bae,_0x247cf6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1e0c66){const _0x1088f9=new He(_0x1e0c66['providerId'],_0x1e0c66['signInMethod']);return _0x1e0c66['idToken']||_0x1e0c66['accessToken']?(_0x1e0c66['idToken']&&(_0x1088f9['idToken']=_0x1e0c66['idToken']),_0x1e0c66['accessToken']&&(_0x1088f9['accessToken']=_0x1e0c66['accessToken']),_0x1e0c66['nonce']&&!_0x1e0c66['pendingToken']&&(_0x1088f9['nonce']=_0x1e0c66['nonce']),_0x1e0c66['pendingToken']&&(_0x1088f9['pendingToken']=_0x1e0c66['pendingToken'])):_0x1e0c66['oauthToken']&&_0x1e0c66['oauthTokenSecret']?(_0x1088f9['accessToken']=_0x1e0c66['oauthToken'],_0x1088f9['secret']=_0x1e0c66['oauthTokenSecret']):Y('argument-error'),_0x1088f9;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2be7e9){const _0x226028=typeof _0x2be7e9=='string'?JSON['parse'](_0x2be7e9):_0x2be7e9,{providerId:_0x4a8aed,signInMethod:_0x1ffddc,..._0x80ce17}=_0x226028;if(!_0x4a8aed||!_0x1ffddc)return null;const _0x4a7be2=new He(_0x4a8aed,_0x1ffddc);return _0x4a7be2['idToken']=_0x80ce17['idToken']||void 0x0,_0x4a7be2['accessToken']=_0x80ce17['accessToken']||void 0x0,_0x4a7be2['secret']=_0x80ce17['secret'],_0x4a7be2['nonce']=_0x80ce17['nonce'],_0x4a7be2['pendingToken']=_0x80ce17['pendingToken']||null,_0x4a7be2;}['_getIdTokenResponse'](_0x32aa78){const _0x3244b8=this['buildRequest']();return nt(_0x32aa78,_0x3244b8);}['_linkToIdToken'](_0x5ede3a,_0x381cef){const _0x40c3ef=this['buildRequest']();return _0x40c3ef['idToken']=_0x381cef,nt(_0x5ede3a,_0x40c3ef);}['_getReauthenticationResolver'](_0x29e237){const _0x4b4f57=this['buildRequest']();return _0x4b4f57['autoCreate']=!0x1,nt(_0x29e237,_0x4b4f57);}['buildRequest'](){const _0x35b0bb={'requestUri':Kf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x35b0bb['pendingToken']=this['pendingToken'];else{const _0x51b5f4={};this['idToken']&&(_0x51b5f4['id_token']=this['idToken']),this['accessToken']&&(_0x51b5f4['access_token']=this['accessToken']),this['secret']&&(_0x51b5f4['oauth_token_secret']=this['secret']),_0x51b5f4['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x51b5f4['nonce']=this['nonce']),_0x35b0bb['postBody']=ut(_0x51b5f4);}return _0x35b0bb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Yf(_0xc5ab24){switch(_0xc5ab24){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Qf(_0x204779){const _0x5502eb=wt(Ct(_0x204779))['link'],_0x26b747=_0x5502eb?wt(Ct(_0x5502eb))['deep_link_id']:null,_0xf00229=wt(Ct(_0x204779))['deep_link_id'];return(_0xf00229?wt(Ct(_0xf00229))['link']:null)||_0xf00229||_0x26b747||_0x5502eb||_0x204779;}class Rs{constructor(_0xa68260){const _0x502448=wt(Ct(_0xa68260)),_0xdb4ed2=_0x502448['apiKey']??null,_0x4a253f=_0x502448['oobCode']??null,_0x53caa7=Yf(_0x502448['mode']??null);m(_0xdb4ed2&&_0x4a253f&&_0x53caa7,'argument-error'),this['apiKey']=_0xdb4ed2,this['operation']=_0x53caa7,this['code']=_0x4a253f,this['continueUrl']=_0x502448['continueUrl']??null,this['languageCode']=_0x502448['lang']??null,this['tenantId']=_0x502448['tenantId']??null;}static['parseLink'](_0x219d96){const _0x13d82f=Qf(_0x219d96);try{return new Rs(_0x13d82f);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x25a318,_0x2f651c){return Ht['_fromEmailAndPassword'](_0x25a318,_0x2f651c);}static['credentialWithLink'](_0x539e78,_0xcf586a){const _0x5161cf=Rs['parseLink'](_0xcf586a);return m(_0x5161cf,'argument-error'),Ht['_fromEmailAndCode'](_0x539e78,_0x5161cf['code'],_0x5161cf['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0xc4175b){this['providerId']=_0xc4175b,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1ae85b){this['defaultLanguageCode']=_0x1ae85b;}['setCustomParameters'](_0x35f18d){return this['customParameters']=_0x35f18d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x424eb5){return this['scopes']['includes'](_0x424eb5)||this['scopes']['push'](_0x424eb5),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x12b2c5){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x12b2c5});}static['credentialFromResult'](_0x59e17b){return ue['credentialFromTaggedObject'](_0x59e17b);}static['credentialFromError'](_0x588dab){return ue['credentialFromTaggedObject'](_0x588dab['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x12fc6e}){if(!_0x12fc6e||!('oauthAccessToken'in _0x12fc6e)||!_0x12fc6e['oauthAccessToken'])return null;try{return ue['credential'](_0x12fc6e['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x41f97f,_0x5611a9){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x41f97f,'accessToken':_0x5611a9});}static['credentialFromResult'](_0x389f69){return de['credentialFromTaggedObject'](_0x389f69);}static['credentialFromError'](_0x505e2d){return de['credentialFromTaggedObject'](_0x505e2d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2361fe}){if(!_0x2361fe)return null;const {oauthIdToken:_0x547c2f,oauthAccessToken:_0x266025}=_0x2361fe;if(!_0x547c2f&&!_0x266025)return null;try{return de['credential'](_0x547c2f,_0x266025);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x437773){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x437773});}static['credentialFromResult'](_0x10cff2){return fe['credentialFromTaggedObject'](_0x10cff2);}static['credentialFromError'](_0x2b7508){return fe['credentialFromTaggedObject'](_0x2b7508['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2f5ae4}){if(!_0x2f5ae4||!('oauthAccessToken'in _0x2f5ae4)||!_0x2f5ae4['oauthAccessToken'])return null;try{return fe['credential'](_0x2f5ae4['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0xd41c7f,_0x2bbcc7){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0xd41c7f,'oauthTokenSecret':_0x2bbcc7});}static['credentialFromResult'](_0x1eb3e2){return pe['credentialFromTaggedObject'](_0x1eb3e2);}static['credentialFromError'](_0x2f7a3a){return pe['credentialFromTaggedObject'](_0x2f7a3a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x27bcbe}){if(!_0x27bcbe)return null;const {oauthAccessToken:_0x3f7e5b,oauthTokenSecret:_0x32efb3}=_0x27bcbe;if(!_0x3f7e5b||!_0x32efb3)return null;try{return pe['credential'](_0x3f7e5b,_0x32efb3);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x53d8f7,_0x3a7432){return en(_0x53d8f7,'POST','/v1/accounts:signUp',Ae(_0x53d8f7,_0x3a7432));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x4a5cc6){this['user']=_0x4a5cc6['user'],this['providerId']=_0x4a5cc6['providerId'],this['_tokenResponse']=_0x4a5cc6['_tokenResponse'],this['operationType']=_0x4a5cc6['operationType'];}static async['_fromIdTokenResponse'](_0xe980d2,_0x5b718b,_0x40e52d,_0x3b09d5=!0x1){const _0x5df1d6=await j['_fromIdTokenResponse'](_0xe980d2,_0x40e52d,_0x3b09d5),_0x3bc53e=Pr(_0x40e52d);return new $e({'user':_0x5df1d6,'providerId':_0x3bc53e,'_tokenResponse':_0x40e52d,'operationType':_0x5b718b});}static async['_forOperation'](_0x44ce73,_0xa6e210,_0x87b1cb){await _0x44ce73['_updateTokensIfNecessary'](_0x87b1cb,!0x0);const _0x4daddb=Pr(_0x87b1cb);return new $e({'user':_0x44ce73,'providerId':_0x4daddb,'_tokenResponse':_0x87b1cb,'operationType':_0xa6e210});}}function Pr(_0x5ce2a9){return _0x5ce2a9['providerId']?_0x5ce2a9['providerId']:'phoneNumber'in _0x5ce2a9?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x46d3c5,_0x189a13,_0x3b4eae,_0x2bbbd1){super(_0x189a13['code'],_0x189a13['message']),this['operationType']=_0x3b4eae,this['user']=_0x2bbbd1,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x46d3c5['name'],'tenantId':_0x46d3c5['tenantId']??void 0x0,'_serverResponse':_0x189a13['customData']['_serverResponse'],'operationType':_0x3b4eae};}static['_fromErrorAndOperation'](_0x3af674,_0x368131,_0x26c1f4,_0xc05b1f){return new On(_0x3af674,_0x368131,_0x26c1f4,_0xc05b1f);}}function Ba(_0x4a3ade,_0x284986,_0x1c9235,_0x474298){return(_0x284986==='reauthenticate'?_0x1c9235['_getReauthenticationResolver'](_0x4a3ade):_0x1c9235['_getIdTokenResponse'](_0x4a3ade))['catch'](_0x324c12=>{throw _0x324c12['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4a3ade,_0x324c12,_0x284986,_0x474298):_0x324c12;});}async function Xf(_0x537f98,_0x3e9025,_0x22c237=!0x1){const _0x429bf5=await Vt(_0x537f98,_0x3e9025['_linkToIdToken'](_0x537f98['auth'],await _0x537f98['getIdToken']()),_0x22c237);return $e['_forOperation'](_0x537f98,'link',_0x429bf5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3e67c9,_0x3e416a,_0x27ca06=!0x1){const {auth:_0x33d481}=_0x3e67c9;if($(_0x33d481['app']))return Promise['reject'](re(_0x33d481));const _0x4f536a='reauthenticate';try{const _0x719830=await Vt(_0x3e67c9,Ba(_0x33d481,_0x4f536a,_0x3e416a,_0x3e67c9),_0x27ca06);m(_0x719830['idToken'],_0x33d481,'internal-error');const _0x54069c=Ts(_0x719830['idToken']);m(_0x54069c,_0x33d481,'internal-error');const {sub:_0x2d7407}=_0x54069c;return m(_0x3e67c9['uid']===_0x2d7407,_0x33d481,'user-mismatch'),$e['_forOperation'](_0x3e67c9,_0x4f536a,_0x719830);}catch(_0x2303ca){throw(_0x2303ca==null?void 0x0:_0x2303ca['code'])==='auth/user-not-found'&&Y(_0x33d481,'user-mismatch'),_0x2303ca;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2361cc,_0x3aa2b2,_0x2dbc70=!0x1){if($(_0x2361cc['app']))return Promise['reject'](re(_0x2361cc));const _0xd00958='signIn',_0x199841=await Ba(_0x2361cc,_0xd00958,_0x3aa2b2),_0x543fb0=await $e['_fromIdTokenResponse'](_0x2361cc,_0xd00958,_0x199841);return _0x2dbc70||await _0x2361cc['_updateCurrentUser'](_0x543fb0['user']),_0x543fb0;}async function ep(_0x547b86,_0x2654fe){return Va(Ke(_0x547b86),_0x2654fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x953668){const _0x46435c=Ke(_0x953668);_0x46435c['_getPasswordPolicyInternal']()&&await _0x46435c['_updatePasswordPolicy']();}async function O_(_0x3eec32,_0x432f68,_0x494c97){if($(_0x3eec32['app']))return Promise['reject'](re(_0x3eec32));const _0x20338a=Ke(_0x3eec32),_0x1c2992=await xi(_0x20338a,{'returnSecureToken':!0x0,'email':_0x432f68,'password':_0x494c97,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Jf)['catch'](_0x176a5e=>{throw _0x176a5e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3eec32),_0x176a5e;}),_0x1f3f2c=await $e['_fromIdTokenResponse'](_0x20338a,'signIn',_0x1c2992);return await _0x20338a['_updateCurrentUser'](_0x1f3f2c['user']),_0x1f3f2c;}function D_(_0x5e6dd7,_0x2ef099,_0x4ac2bf){return $(_0x5e6dd7['app'])?Promise['reject'](re(_0x5e6dd7)):ep(N(_0x5e6dd7),mt['credential'](_0x2ef099,_0x4ac2bf))['catch'](async _0x183322=>{throw _0x183322['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5e6dd7),_0x183322;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M_(_0x54112a,_0xce5a90){return N(_0x54112a)['setPersistence'](_0xce5a90);}function tp(_0x41d261,_0x2c12ff,_0x383db6,_0x3c6e97){return N(_0x41d261)['onIdTokenChanged'](_0x2c12ff,_0x383db6,_0x3c6e97);}function np(_0x3c1c58,_0x1927ad,_0x47d3c6){return N(_0x3c1c58)['beforeAuthStateChanged'](_0x1927ad,_0x47d3c6);}function L_(_0x20fa18,_0x35be9e,_0x4284f0,_0x3985ba){return N(_0x20fa18)['onAuthStateChanged'](_0x35be9e,_0x4284f0,_0x3985ba);}function x_(_0x17a2b0){return N(_0x17a2b0)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4e5e39,_0x6aba44){this['storageRetriever']=_0x4e5e39,this['type']=_0x6aba44;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x54d1b7,_0x4cca12){return this['storage']['setItem'](_0x54d1b7,JSON['stringify'](_0x4cca12)),Promise['resolve']();}['_get'](_0x288cf0){const _0x5c45da=this['storage']['getItem'](_0x288cf0);return Promise['resolve'](_0x5c45da?JSON['parse'](_0x5c45da):null);}['_remove'](_0x40fdbd){return this['storage']['removeItem'](_0x40fdbd),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ip=0x3e8,sp=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x17a2f3,_0x45419d)=>this['onStorageEvent'](_0x17a2f3,_0x45419d),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x283f00){for(const _0x51580f of Object['keys'](this['listeners'])){const _0xfab163=this['storage']['getItem'](_0x51580f),_0x1cb888=this['localCache'][_0x51580f];_0xfab163!==_0x1cb888&&_0x283f00(_0x51580f,_0x1cb888,_0xfab163);}}['onStorageEvent'](_0x5474ff,_0x4e8159=!0x1){if(!_0x5474ff['key']){this['forAllChangedKeys']((_0x1ace93,_0xcb4fb0,_0x4880ee)=>{this['notifyListeners'](_0x1ace93,_0x4880ee);});return;}const _0x31a865=_0x5474ff['key'];_0x4e8159?this['detachListener']():this['stopPolling']();const _0x410a9c=()=>{const _0x414f35=this['storage']['getItem'](_0x31a865);!_0x4e8159&&this['localCache'][_0x31a865]===_0x414f35||this['notifyListeners'](_0x31a865,_0x414f35);},_0x10d996=this['storage']['getItem'](_0x31a865);bf()&&_0x10d996!==_0x5474ff['newValue']&&_0x5474ff['newValue']!==_0x5474ff['oldValue']?setTimeout(_0x410a9c,sp):_0x410a9c();}['notifyListeners'](_0x5d0ce0,_0x1f5f0e){this['localCache'][_0x5d0ce0]=_0x1f5f0e;const _0x1a2720=this['listeners'][_0x5d0ce0];if(_0x1a2720){for(const _0x46fa9b of Array['from'](_0x1a2720))_0x46fa9b(_0x1f5f0e&&JSON['parse'](_0x1f5f0e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4de3c6,_0x3c41cd,_0x46fce6)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4de3c6,'oldValue':_0x3c41cd,'newValue':_0x46fce6}),!0x0);});},ip);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3e15e3,_0x2abea9){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3e15e3]||(this['listeners'][_0x3e15e3]=new Set(),this['localCache'][_0x3e15e3]=this['storage']['getItem'](_0x3e15e3)),this['listeners'][_0x3e15e3]['add'](_0x2abea9);}['_removeListener'](_0x2eaa73,_0x12265a){this['listeners'][_0x2eaa73]&&(this['listeners'][_0x2eaa73]['delete'](_0x12265a),this['listeners'][_0x2eaa73]['size']===0x0&&delete this['listeners'][_0x2eaa73]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x590679,_0x535992){await super['_set'](_0x590679,_0x535992),this['localCache'][_0x590679]=JSON['stringify'](_0x535992);}async['_get'](_0xbf78d3){const _0x466de6=await super['_get'](_0xbf78d3);return this['localCache'][_0xbf78d3]=JSON['stringify'](_0x466de6),_0x466de6;}async['_remove'](_0xd86ea4){await super['_remove'](_0xd86ea4),delete this['localCache'][_0xd86ea4];}}Ga['type']='LOCAL';const rp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2d7b18,_0x236d08){}['_removeListener'](_0x170693,_0x5361c4){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function op(_0x14a711){return Promise['all'](_0x14a711['map'](async _0x5533e6=>{try{return{'fulfilled':!0x0,'value':await _0x5533e6};}catch(_0x36c7f0){return{'fulfilled':!0x1,'reason':_0x36c7f0};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1fd180){this['eventTarget']=_0x1fd180,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5287c8){const _0x474f50=this['receivers']['find'](_0x5c6ddf=>_0x5c6ddf['isListeningto'](_0x5287c8));if(_0x474f50)return _0x474f50;const _0x42ab4a=new Xn(_0x5287c8);return this['receivers']['push'](_0x42ab4a),_0x42ab4a;}['isListeningto'](_0x424a08){return this['eventTarget']===_0x424a08;}async['handleEvent'](_0x407443){const _0x4f8a02=_0x407443,{eventId:_0x244c95,eventType:_0x6dea13,data:_0x4feb4f}=_0x4f8a02['data'],_0x3d1f66=this['handlersMap'][_0x6dea13];if(!(_0x3d1f66!=null&&_0x3d1f66['size']))return;_0x4f8a02['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x244c95,'eventType':_0x6dea13});const _0xc6275c=Array['from'](_0x3d1f66)['map'](async _0x3c22e8=>_0x3c22e8(_0x4f8a02['origin'],_0x4feb4f)),_0x192507=await op(_0xc6275c);_0x4f8a02['ports'][0x0]['postMessage']({'status':'done','eventId':_0x244c95,'eventType':_0x6dea13,'response':_0x192507});}['_subscribe'](_0x19280b,_0x5edff6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x19280b]||(this['handlersMap'][_0x19280b]=new Set()),this['handlersMap'][_0x19280b]['add'](_0x5edff6);}['_unsubscribe'](_0x599086,_0x135775){this['handlersMap'][_0x599086]&&_0x135775&&this['handlersMap'][_0x599086]['delete'](_0x135775),(!_0x135775||this['handlersMap'][_0x599086]['size']===0x0)&&delete this['handlersMap'][_0x599086],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4183dc='',_0x2e8c14=0xa){let _0x5558f7='';for(let _0x37ff79=0x0;_0x37ff79<_0x2e8c14;_0x37ff79++)_0x5558f7+=Math['floor'](Math['random']()*0xa);return _0x4183dc+_0x5558f7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ap{constructor(_0x380dd2){this['target']=_0x380dd2,this['handlers']=new Set();}['removeMessageHandler'](_0x25d843){_0x25d843['messageChannel']&&(_0x25d843['messageChannel']['port1']['removeEventListener']('message',_0x25d843['onMessage']),_0x25d843['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x25d843);}async['_send'](_0x58ad92,_0x413090,_0x5540bd=0x32){const _0x4b2c45=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4b2c45)throw new Error('connection_unavailable');let _0x159fef,_0x359e33;return new Promise((_0x511cf9,_0xa9d2f4)=>{const _0x151937=As('',0x14);_0x4b2c45['port1']['start']();const _0x1677d1=setTimeout(()=>{_0xa9d2f4(new Error('unsupported_event'));},_0x5540bd);_0x359e33={'messageChannel':_0x4b2c45,'onMessage'(_0x4a0ac6){const _0x413d5c=_0x4a0ac6;if(_0x413d5c['data']['eventId']===_0x151937)switch(_0x413d5c['data']['status']){case'ack':clearTimeout(_0x1677d1),_0x159fef=setTimeout(()=>{_0xa9d2f4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x159fef),_0x511cf9(_0x413d5c['data']['response']);break;default:clearTimeout(_0x1677d1),clearTimeout(_0x159fef),_0xa9d2f4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x359e33),_0x4b2c45['port1']['addEventListener']('message',_0x359e33['onMessage']),this['target']['postMessage']({'eventType':_0x58ad92,'eventId':_0x151937,'data':_0x413090},[_0x4b2c45['port2']]);})['finally'](()=>{_0x359e33&&this['removeMessageHandler'](_0x359e33);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function cp(_0x59ab9b){Z()['location']['href']=_0x59ab9b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function lp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function hp(){var _0x5bc4c0;return((_0x5bc4c0=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5bc4c0['controller'])||null;}function up(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',dp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0xfd43be){this['request']=_0xfd43be;}['toPromise'](){return new Promise((_0x31f170,_0xdf1ada)=>{this['request']['addEventListener']('success',()=>{_0x31f170(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xdf1ada(this['request']['error']);});});}}function Zn(_0x3cad0b,_0x3b2d46){return _0x3cad0b['transaction']([Mn],_0x3b2d46?'readwrite':'readonly')['objectStore'](Mn);}function fp(){const _0x1c9f35=indexedDB['deleteDatabase'](Ka);return new nn(_0x1c9f35)['toPromise']();}function Qa(){const _0x453551=indexedDB['open'](Ka,dp);return new Promise((_0x521862,_0x21b021)=>{_0x453551['addEventListener']('error',()=>{_0x21b021(_0x453551['error']);}),_0x453551['addEventListener']('upgradeneeded',()=>{const _0x2d92e3=_0x453551['result'];try{_0x2d92e3['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x976cc4){_0x21b021(_0x976cc4);}}),_0x453551['addEventListener']('success',async()=>{const _0x19fa78=_0x453551['result'];_0x19fa78['objectStoreNames']['contains'](Mn)?_0x521862(_0x19fa78):(_0x19fa78['close'](),await fp(),_0x521862(await Qa()));});});}async function Or(_0x1db717,_0x17b39c,_0x1e4ed2){const _0x2aedf5=Zn(_0x1db717,!0x0)['put']({[Ya]:_0x17b39c,'value':_0x1e4ed2});return new nn(_0x2aedf5)['toPromise']();}async function pp(_0x108640,_0x3dc307){const _0x434563=Zn(_0x108640,!0x1)['get'](_0x3dc307),_0x150bb8=await new nn(_0x434563)['toPromise']();return _0x150bb8===void 0x0?null:_0x150bb8['value'];}function Dr(_0x41f0de,_0x1e43e8){const _0x31b083=Zn(_0x41f0de,!0x0)['delete'](_0x1e43e8);return new nn(_0x31b083)['toPromise']();}const _p=0x320,gp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x58e1cd){let _0x1aba45=0x0;for(;;)try{const _0x57656e=await this['_openDb']();return await _0x58e1cd(_0x57656e);}catch(_0x27bd42){if(_0x1aba45++>gp)throw _0x27bd42;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](up()),this['receiver']['_subscribe']('keyChanged',async(_0x528936,_0x1dfbc5)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1dfbc5['key'])})),this['receiver']['_subscribe']('ping',async(_0x5adc05,_0x2f6144)=>['keyChanged']);}async['initializeSender'](){var _0x128361,_0x757a58;if(this['activeServiceWorker']=await lp(),!this['activeServiceWorker'])return;this['sender']=new ap(this['activeServiceWorker']);const _0xb28921=await this['sender']['_send']('ping',{},0x320);_0xb28921&&(_0x128361=_0xb28921[0x0])!=null&&_0x128361['fulfilled']&&(_0x757a58=_0xb28921[0x0])!=null&&_0x757a58['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3b781c){if(!(!this['sender']||!this['activeServiceWorker']||hp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3b781c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4cee64=>{await Or(_0x4cee64,Dn,'1'),await Dr(_0x4cee64,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4bbb95){this['pendingWrites']++;try{await _0x4bbb95();}finally{this['pendingWrites']--;}}async['_set'](_0x14aa62,_0x48b28c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x16c335=>Or(_0x16c335,_0x14aa62,_0x48b28c)),this['localCache'][_0x14aa62]=_0x48b28c,this['notifyServiceWorker'](_0x14aa62)));}async['_get'](_0x44717f){const _0x4be0bd=await this['_withRetries'](_0x150c1a=>pp(_0x150c1a,_0x44717f));return this['localCache'][_0x44717f]=_0x4be0bd,_0x4be0bd;}async['_remove'](_0x358542){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xc9dae4=>Dr(_0xc9dae4,_0x358542)),delete this['localCache'][_0x358542],this['notifyServiceWorker'](_0x358542)));}async['_poll'](){const _0x3a445e=await this['_withRetries'](_0x1ada88=>{const _0x2ac9da=Zn(_0x1ada88,!0x1)['getAll']();return new nn(_0x2ac9da)['toPromise']();});if(!_0x3a445e)return[];if(this['pendingWrites']!==0x0)return[];const _0x240d2a=[],_0xc11b63=new Set();if(_0x3a445e['length']!==0x0){for(const {fbase_key:_0x5f5b63,value:_0x2498c1}of _0x3a445e)_0xc11b63['add'](_0x5f5b63),JSON['stringify'](this['localCache'][_0x5f5b63])!==JSON['stringify'](_0x2498c1)&&(this['notifyListeners'](_0x5f5b63,_0x2498c1),_0x240d2a['push'](_0x5f5b63));}for(const _0x341048 of Object['keys'](this['localCache']))this['localCache'][_0x341048]&&!_0xc11b63['has'](_0x341048)&&(this['notifyListeners'](_0x341048,null),_0x240d2a['push'](_0x341048));return _0x240d2a;}['notifyListeners'](_0x597f34,_0x2cad73){this['localCache'][_0x597f34]=_0x2cad73;const _0x37f7d0=this['listeners'][_0x597f34];if(_0x37f7d0){for(const _0x15a912 of Array['from'](_0x37f7d0))_0x15a912(_0x2cad73);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),_p);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x551df8,_0x3a601f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x551df8]||(this['listeners'][_0x551df8]=new Set(),this['_get'](_0x551df8)),this['listeners'][_0x551df8]['add'](_0x3a601f);}['_removeListener'](_0xe8f374,_0x11b30d){this['listeners'][_0xe8f374]&&(this['listeners'][_0xe8f374]['delete'](_0x11b30d),this['listeners'][_0xe8f374]['size']===0x0&&delete this['listeners'][_0xe8f374]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const mp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function yp(_0x510056,_0xfa1136){return _0xfa1136?ie(_0xfa1136):(m(_0x510056['_popupRedirectResolver'],_0x510056,'argument-error'),_0x510056['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1c5cda){super('custom','custom'),this['params']=_0x1c5cda;}['_getIdTokenResponse'](_0x48e921){return nt(_0x48e921,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3d2830,_0x149a8e){return nt(_0x3d2830,this['_buildIdpRequest'](_0x149a8e));}['_getReauthenticationResolver'](_0x47d57f){return nt(_0x47d57f,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xaa5f4e){const _0xb1d0e8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xaa5f4e&&(_0xb1d0e8['idToken']=_0xaa5f4e),_0xb1d0e8;}}function vp(_0xf40ab9){return Va(_0xf40ab9['auth'],new ks(_0xf40ab9),_0xf40ab9['bypassAuthState']);}function Ep(_0x3d7e0c){const {auth:_0x55d89a,user:_0x1b2073}=_0x3d7e0c;return m(_0x1b2073,_0x55d89a,'internal-error'),Zf(_0x1b2073,new ks(_0x3d7e0c),_0x3d7e0c['bypassAuthState']);}async function Ip(_0x4299b0){const {auth:_0x36b75f,user:_0x2a5846}=_0x4299b0;return m(_0x2a5846,_0x36b75f,'internal-error'),Xf(_0x2a5846,new ks(_0x4299b0),_0x4299b0['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x432256,_0x3bf85a,_0x5a49ec,_0x2263a8,_0xb8d676=!0x1){this['auth']=_0x432256,this['resolver']=_0x5a49ec,this['user']=_0x2263a8,this['bypassAuthState']=_0xb8d676,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3bf85a)?_0x3bf85a:[_0x3bf85a];}['execute'](){return new Promise(async(_0xabe13b,_0x2bf0a3)=>{this['pendingPromise']={'resolve':_0xabe13b,'reject':_0x2bf0a3};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xa970d9){this['reject'](_0xa970d9);}});}async['onAuthEvent'](_0x3b8b1d){const {urlResponse:_0x6a331b,sessionId:_0x554612,postBody:_0x284aa9,tenantId:_0x116c8e,error:_0x587223,type:_0x2de12c}=_0x3b8b1d;if(_0x587223){this['reject'](_0x587223);return;}const _0x515053={'auth':this['auth'],'requestUri':_0x6a331b,'sessionId':_0x554612,'tenantId':_0x116c8e||void 0x0,'postBody':_0x284aa9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2de12c)(_0x515053));}catch(_0x1db624){this['reject'](_0x1db624);}}['onError'](_0x48150d){this['reject'](_0x48150d);}['getIdpTask'](_0x4f02c6){switch(_0x4f02c6){case'signInViaPopup':case'signInViaRedirect':return vp;case'linkViaPopup':case'linkViaRedirect':return Ip;case'reauthViaPopup':case'reauthViaRedirect':return Ep;default:Y(this['auth'],'internal-error');}}['resolve'](_0xa71765){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xa71765),this['unregisterAndCleanUp']();}['reject'](_0x370bb7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x370bb7),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x14f711,_0x56630d,_0x34b45e,_0x3bd409,_0x1bf53c){super(_0x14f711,_0x56630d,_0x3bd409,_0x1bf53c),this['provider']=_0x34b45e,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3c75a1=await this['execute']();return m(_0x3c75a1,this['auth'],'internal-error'),_0x3c75a1;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x273c83=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x273c83),this['authWindow']['associatedEvent']=_0x273c83,this['resolver']['_originValidation'](this['auth'])['catch'](_0x438652=>{this['reject'](_0x438652);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4044b3=>{_0x4044b3||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xc93662;return((_0xc93662=this['authWindow'])==null?void 0x0:_0xc93662['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4066f1=()=>{var _0x50a87c,_0x262cc6;if((_0x262cc6=(_0x50a87c=this['authWindow'])==null?void 0x0:_0x50a87c['window'])!=null&&_0x262cc6['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4066f1,wp['get']());};_0x4066f1();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cp='pendingRedirect',hn=new Map();class Tp extends Xa{constructor(_0x544957,_0x4f6c7d,_0x24b28f=!0x1){super(_0x544957,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4f6c7d,void 0x0,_0x24b28f),this['eventId']=null;}async['execute'](){let _0x5ae7c4=hn['get'](this['auth']['_key']());if(!_0x5ae7c4){try{const _0x533464=await Sp(this['resolver'],this['auth'])?await super['execute']():null;_0x5ae7c4=()=>Promise['resolve'](_0x533464);}catch(_0x3483f4){_0x5ae7c4=()=>Promise['reject'](_0x3483f4);}hn['set'](this['auth']['_key'](),_0x5ae7c4);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5ae7c4();}async['onAuthEvent'](_0x48665b){if(_0x48665b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x48665b);if(_0x48665b['type']==='unknown'){this['resolve'](null);return;}if(_0x48665b['eventId']){const _0x34ae45=await this['auth']['_redirectUserForId'](_0x48665b['eventId']);if(_0x34ae45)return this['user']=_0x34ae45,super['onAuthEvent'](_0x48665b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Sp(_0x5edc26,_0x1cb469){const _0x11aed0=Ap(_0x1cb469),_0x245dcb=Rp(_0x5edc26);if(!await _0x245dcb['_isAvailable']())return!0x1;const _0x54a6fe=await _0x245dcb['_get'](_0x11aed0)==='true';return await _0x245dcb['_remove'](_0x11aed0),_0x54a6fe;}function bp(_0x41083b,_0x3101dd){hn['set'](_0x41083b['_key'](),_0x3101dd);}function Rp(_0x294318){return ie(_0x294318['_redirectPersistence']);}function Ap(_0x4581fc){return ln(Cp,_0x4581fc['config']['apiKey'],_0x4581fc['name']);}async function kp(_0x111dec,_0x220858,_0x48dfb8=!0x1){if($(_0x111dec['app']))return Promise['reject'](re(_0x111dec));const _0x84705d=Ke(_0x111dec),_0x2001ec=yp(_0x84705d,_0x220858),_0x549013=await new Tp(_0x84705d,_0x2001ec,_0x48dfb8)['execute']();return _0x549013&&!_0x48dfb8&&(delete _0x549013['user']['_redirectEventId'],await _0x84705d['_persistUserIfCurrent'](_0x549013['user']),await _0x84705d['_setRedirectUser'](null,_0x220858)),_0x549013;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Np=0x258*0x3e8;class Pp{constructor(_0x54e1d9){this['auth']=_0x54e1d9,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4dbbd3){this['consumers']['add'](_0x4dbbd3),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4dbbd3)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4dbbd3),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x27c356){this['consumers']['delete'](_0x27c356);}['onEvent'](_0x59c4ea){if(this['hasEventBeenHandled'](_0x59c4ea))return!0x1;let _0x48ae50=!0x1;return this['consumers']['forEach'](_0x168f9c=>{this['isEventForConsumer'](_0x59c4ea,_0x168f9c)&&(_0x48ae50=!0x0,this['sendToConsumer'](_0x59c4ea,_0x168f9c),this['saveEventToCache'](_0x59c4ea));}),this['hasHandledPotentialRedirect']||!Op(_0x59c4ea)||(this['hasHandledPotentialRedirect']=!0x0,_0x48ae50||(this['queuedRedirectEvent']=_0x59c4ea,_0x48ae50=!0x0)),_0x48ae50;}['sendToConsumer'](_0x311356,_0x1bf282){var _0x2801a4;if(_0x311356['error']&&!Za(_0x311356)){const _0xe9222f=((_0x2801a4=_0x311356['error']['code'])==null?void 0x0:_0x2801a4['split']('auth/')[0x1])||'internal-error';_0x1bf282['onError'](X(this['auth'],_0xe9222f));}else _0x1bf282['onAuthEvent'](_0x311356);}['isEventForConsumer'](_0x280f7b,_0x5ca25a){const _0x593a35=_0x5ca25a['eventId']===null||!!_0x280f7b['eventId']&&_0x280f7b['eventId']===_0x5ca25a['eventId'];return _0x5ca25a['filter']['includes'](_0x280f7b['type'])&&_0x593a35;}['hasEventBeenHandled'](_0x1ed0b0){return Date['now']()-this['lastProcessedEventTime']>=Np&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1ed0b0));}['saveEventToCache'](_0x55175b){this['cachedEventUids']['add'](Mr(_0x55175b)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x340a28){return[_0x340a28['type'],_0x340a28['eventId'],_0x340a28['sessionId'],_0x340a28['tenantId']]['filter'](_0x545da7=>_0x545da7)['join']('-');}function Za({type:_0xfa5843,error:_0xa84757}){return _0xfa5843==='unknown'&&(_0xa84757==null?void 0x0:_0xa84757['code'])==='auth/no-auth-event';}function Op(_0x47c358){switch(_0x47c358['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x47c358);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Dp(_0x2e5991,_0x572489={}){return ke(_0x2e5991,'GET','/v1/projects',_0x572489);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Lp=/^https?/;async function xp(_0x3b10fd){if(_0x3b10fd['config']['emulator'])return;const {authorizedDomains:_0x5660f1}=await Dp(_0x3b10fd);for(const _0x45e5d8 of _0x5660f1)try{if(Fp(_0x45e5d8))return;}catch{}Y(_0x3b10fd,'unauthorized-domain');}function Fp(_0x2d0b31){const _0x4aef07=Mi(),{protocol:_0x3fe7cb,hostname:_0x4003d3}=new URL(_0x4aef07);if(_0x2d0b31['startsWith']('chrome-extension://')){const _0x4c9104=new URL(_0x2d0b31);return _0x4c9104['hostname']===''&&_0x4003d3===''?_0x3fe7cb==='chrome-extension:'&&_0x2d0b31['replace']('chrome-extension://','')===_0x4aef07['replace']('chrome-extension://',''):_0x3fe7cb==='chrome-extension:'&&_0x4c9104['hostname']===_0x4003d3;}if(!Lp['test'](_0x3fe7cb))return!0x1;if(Mp['test'](_0x2d0b31))return _0x4003d3===_0x2d0b31;const _0x2a784b=_0x2d0b31['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2a784b+'|'+_0x2a784b+')$','i')['test'](_0x4003d3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Up=new Zt(0x7530,0xea60);function Lr(){const _0x78eb28=Z()['___jsl'];if(_0x78eb28!=null&&_0x78eb28['H']){for(const _0x5afafc of Object['keys'](_0x78eb28['H']))if(_0x78eb28['H'][_0x5afafc]['r']=_0x78eb28['H'][_0x5afafc]['r']||[],_0x78eb28['H'][_0x5afafc]['L']=_0x78eb28['H'][_0x5afafc]['L']||[],_0x78eb28['H'][_0x5afafc]['r']=[..._0x78eb28['H'][_0x5afafc]['L']],_0x78eb28['CP']){for(let _0xbab46d=0x0;_0xbab46d<_0x78eb28['CP']['length'];_0xbab46d++)_0x78eb28['CP'][_0xbab46d]=null;}}}function Wp(_0x5329c1){return new Promise((_0x2c8507,_0xbdd0c9)=>{var _0x575986,_0x31b7bb,_0x231a59;function _0x1197e2(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2c8507(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0xbdd0c9(X(_0x5329c1,'network-request-failed'));},'timeout':Up['get']()});}if((_0x31b7bb=(_0x575986=Z()['gapi'])==null?void 0x0:_0x575986['iframes'])!=null&&_0x31b7bb['Iframe'])_0x2c8507(gapi['iframes']['getContext']());else{if((_0x231a59=Z()['gapi'])!=null&&_0x231a59['load'])_0x1197e2();else{const _0x1c54bc=Lf('iframefcb');return Z()[_0x1c54bc]=()=>{gapi['load']?_0x1197e2():_0xbdd0c9(X(_0x5329c1,'network-request-failed'));},xa(Mf()+'?onload='+_0x1c54bc)['catch'](_0x52e45a=>_0xbdd0c9(_0x52e45a));}}})['catch'](_0x1c1306=>{throw un=null,_0x1c1306;});}let un=null;function Bp(_0x45e117){return un=un||Wp(_0x45e117),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vp=new Zt(0x1388,0x3a98),Hp='__/auth/iframe',$p='emulator/auth/iframe',Gp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function zp(_0x35bdc7){const _0x53c5e5=_0x35bdc7['config'];m(_0x53c5e5['authDomain'],_0x35bdc7,'auth-domain-config-required');const _0x516635=_0x53c5e5['emulator']?Cs(_0x53c5e5,$p):'https://'+_0x35bdc7['config']['authDomain']+'/'+Hp,_0x587660={'apiKey':_0x53c5e5['apiKey'],'appName':_0x35bdc7['name'],'v':dt},_0x1974b1=qp['get'](_0x35bdc7['config']['apiHost']);_0x1974b1&&(_0x587660['eid']=_0x1974b1);const _0x2f52be=_0x35bdc7['_getFrameworks']();return _0x2f52be['length']&&(_0x587660['fw']=_0x2f52be['join'](',')),_0x516635+'?'+ut(_0x587660)['slice'](0x1);}async function jp(_0x5d2e6b){const _0x11a52b=await Bp(_0x5d2e6b),_0x1dcca7=Z()['gapi'];return m(_0x1dcca7,_0x5d2e6b,'internal-error'),_0x11a52b['open']({'where':document['body'],'url':zp(_0x5d2e6b),'messageHandlersFilter':_0x1dcca7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Gp,'dontclear':!0x0},_0x41c8c6=>new Promise(async(_0x5acc04,_0x51c69b)=>{await _0x41c8c6['restyle']({'setHideOnLeave':!0x1});const _0x954d19=X(_0x5d2e6b,'network-request-failed'),_0x1d3737=Z()['setTimeout'](()=>{_0x51c69b(_0x954d19);},Vp['get']());function _0xe57232(){Z()['clearTimeout'](_0x1d3737),_0x5acc04(_0x41c8c6);}_0x41c8c6['ping'](_0xe57232)['then'](_0xe57232,()=>{_0x51c69b(_0x954d19);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Kp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Yp=0x1f4,Qp=0x258,Jp='_blank',Xp='http://localhost';class xr{constructor(_0x363db8){this['window']=_0x363db8,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Zp(_0x37fe95,_0x32d54e,_0x4500ee,_0x23d73c=Yp,_0x3d856f=Qp){const _0x373fe1=Math['max']((window['screen']['availHeight']-_0x3d856f)/0x2,0x0)['toString'](),_0x2b1b24=Math['max']((window['screen']['availWidth']-_0x23d73c)/0x2,0x0)['toString']();let _0x98c74='';const _0x4b115a={...Kp,'width':_0x23d73c['toString'](),'height':_0x3d856f['toString'](),'top':_0x373fe1,'left':_0x2b1b24},_0x31edc8=W()['toLowerCase']();_0x4500ee&&(_0x98c74=ka(_0x31edc8)?Jp:_0x4500ee),Ra(_0x31edc8)&&(_0x32d54e=_0x32d54e||Xp,_0x4b115a['scrollbars']='yes');const _0xcd6522=Object['entries'](_0x4b115a)['reduce']((_0x2e66c5,[_0x37e8af,_0x574687])=>''+_0x2e66c5+_0x37e8af+'='+_0x574687+',','');if(Sf(_0x31edc8)&&_0x98c74!=='_self')return e_(_0x32d54e||'',_0x98c74),new xr(null);const _0x134600=window['open'](_0x32d54e||'',_0x98c74,_0xcd6522);m(_0x134600,_0x37fe95,'popup-blocked');try{_0x134600['focus']();}catch{}return new xr(_0x134600);}function e_(_0x1ec927,_0x52d754){const _0x137e3f=document['createElement']('a');_0x137e3f['href']=_0x1ec927,_0x137e3f['target']=_0x52d754;const _0xbffef1=document['createEvent']('MouseEvent');_0xbffef1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x137e3f['dispatchEvent'](_0xbffef1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const t_='__/auth/handler',n_='emulator/auth/handler',i_=encodeURIComponent('fac');async function Fr(_0x112563,_0x5a0f0a,_0x3c2c89,_0x185743,_0x461d73,_0x51f1f9){m(_0x112563['config']['authDomain'],_0x112563,'auth-domain-config-required'),m(_0x112563['config']['apiKey'],_0x112563,'invalid-api-key');const _0x31f14a={'apiKey':_0x112563['config']['apiKey'],'appName':_0x112563['name'],'authType':_0x3c2c89,'redirectUrl':_0x185743,'v':dt,'eventId':_0x461d73};if(_0x5a0f0a instanceof Wa){_0x5a0f0a['setDefaultLanguage'](_0x112563['languageCode']),_0x31f14a['providerId']=_0x5a0f0a['providerId']||'',pn(_0x5a0f0a['getCustomParameters']())||(_0x31f14a['customParameters']=JSON['stringify'](_0x5a0f0a['getCustomParameters']()));for(const [_0x5d8daa,_0x50163a]of Object['entries']({}))_0x31f14a[_0x5d8daa]=_0x50163a;}if(_0x5a0f0a instanceof tn){const _0x903610=_0x5a0f0a['getScopes']()['filter'](_0x47cac7=>_0x47cac7!=='');_0x903610['length']>0x0&&(_0x31f14a['scopes']=_0x903610['join'](','));}_0x112563['tenantId']&&(_0x31f14a['tid']=_0x112563['tenantId']);const _0x3da26e=_0x31f14a;for(const _0x436f90 of Object['keys'](_0x3da26e))_0x3da26e[_0x436f90]===void 0x0&&delete _0x3da26e[_0x436f90];const _0x5b7ca4=await _0x112563['_getAppCheckToken'](),_0x1613d7=_0x5b7ca4?'#'+i_+'='+encodeURIComponent(_0x5b7ca4):'';return s_(_0x112563)+'?'+ut(_0x3da26e)['slice'](0x1)+_0x1613d7;}function s_({config:_0x373895}){return _0x373895['emulator']?Cs(_0x373895,n_):'https://'+_0x373895['authDomain']+'/'+t_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class r_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=kp,this['_overrideRedirectResult']=bp;}async['_openPopup'](_0x549cd0,_0x36cd2d,_0x3c8c69,_0x4a59f5){var _0x44e55b;ce((_0x44e55b=this['eventManagers'][_0x549cd0['_key']()])==null?void 0x0:_0x44e55b['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2fa08e=await Fr(_0x549cd0,_0x36cd2d,_0x3c8c69,Mi(),_0x4a59f5);return Zp(_0x549cd0,_0x2fa08e,As());}async['_openRedirect'](_0xf8b5f4,_0xb6f2ee,_0x285faa,_0x547d27){await this['_originValidation'](_0xf8b5f4);const _0x21d6e1=await Fr(_0xf8b5f4,_0xb6f2ee,_0x285faa,Mi(),_0x547d27);return cp(_0x21d6e1),new Promise(()=>{});}['_initialize'](_0x31923f){const _0x174813=_0x31923f['_key']();if(this['eventManagers'][_0x174813]){const {manager:_0x3e8f5b,promise:_0x3828ea}=this['eventManagers'][_0x174813];return _0x3e8f5b?Promise['resolve'](_0x3e8f5b):(ce(_0x3828ea,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3828ea);}const _0x51e640=this['initAndGetManager'](_0x31923f);return this['eventManagers'][_0x174813]={'promise':_0x51e640},_0x51e640['catch'](()=>{delete this['eventManagers'][_0x174813];}),_0x51e640;}async['initAndGetManager'](_0x509e52){const _0x3b3d63=await jp(_0x509e52),_0x2b8c72=new Pp(_0x509e52);return _0x3b3d63['register']('authEvent',_0x190a5d=>(m(_0x190a5d==null?void 0x0:_0x190a5d['authEvent'],_0x509e52,'invalid-auth-event'),{'status':_0x2b8c72['onEvent'](_0x190a5d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x509e52['_key']()]={'manager':_0x2b8c72},this['iframes'][_0x509e52['_key']()]=_0x3b3d63,_0x2b8c72;}['_isIframeWebStorageSupported'](_0x272b65,_0x22b49a){this['iframes'][_0x272b65['_key']()]['send'](pi,{'type':pi},_0x578acf=>{var _0x55bba7;const _0xe6968c=(_0x55bba7=_0x578acf==null?void 0x0:_0x578acf[0x0])==null?void 0x0:_0x55bba7[pi];_0xe6968c!==void 0x0&&_0x22b49a(!!_0xe6968c),Y(_0x272b65,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1dd371){const _0x40ebc4=_0x1dd371['_key']();return this['originValidationPromises'][_0x40ebc4]||(this['originValidationPromises'][_0x40ebc4]=xp(_0x1dd371)),this['originValidationPromises'][_0x40ebc4];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const o_=r_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a_{constructor(_0xbd7b34){this['auth']=_0xbd7b34,this['internalListeners']=new Map();}['getUid'](){var _0x3d6cd3;return this['assertAuthConfigured'](),((_0x3d6cd3=this['auth']['currentUser'])==null?void 0x0:_0x3d6cd3['uid'])||null;}async['getToken'](_0x266c7f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x266c7f)}:null;}['addAuthTokenListener'](_0x3fce0b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3fce0b))return;const _0x23120c=this['auth']['onIdTokenChanged'](_0x499ed4=>{_0x3fce0b((_0x499ed4==null?void 0x0:_0x499ed4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3fce0b,_0x23120c),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5a7da3){this['assertAuthConfigured']();const _0x20e898=this['internalListeners']['get'](_0x5a7da3);_0x20e898&&(this['internalListeners']['delete'](_0x5a7da3),_0x20e898(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c_(_0x2c9758){switch(_0x2c9758){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function l_(_0x3fc6d9){st(new xe('auth',(_0x1ec34a,{options:_0x31de26})=>{const _0x1cee46=_0x1ec34a['getProvider']('app')['getImmediate'](),_0xa0531c=_0x1ec34a['getProvider']('heartbeat'),_0x1eb4b9=_0x1ec34a['getProvider']('app-check-internal'),{apiKey:_0x41961b,authDomain:_0x14911f}=_0x1cee46['options'];m(_0x41961b&&!_0x41961b['includes'](':'),'invalid-api-key',{'appName':_0x1cee46['name']});const _0xe891c6={'apiKey':_0x41961b,'authDomain':_0x14911f,'clientPlatform':_0x3fc6d9,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3fc6d9)},_0x5b6c59=new Pf(_0x1cee46,_0xa0531c,_0x1eb4b9,_0xe891c6);return Bf(_0x5b6c59,_0x31de26),_0x5b6c59;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1400b3,_0x226684,_0x126863)=>{_0x1400b3['getProvider']('auth-internal')['initialize']();})),st(new xe('auth-internal',_0x367ec6=>{const _0x584d64=Ke(_0x367ec6['getProvider']('auth')['getImmediate']());return(_0x500b7e=>new a_(_0x500b7e))(_0x584d64);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,c_(_0x3fc6d9)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const h_=0x12c,u_=jr('authIdTokenMaxAge')||h_;let Br=null;const d_=_0x541583=>async _0x23a03d=>{const _0x568e69=_0x23a03d&&await _0x23a03d['getIdTokenResult'](),_0x371304=_0x568e69&&(new Date()['getTime']()-Date['parse'](_0x568e69['issuedAtTime']))/0x3e8;if(_0x371304&&_0x371304>u_)return;const _0x558dd2=_0x568e69==null?void 0x0:_0x568e69['token'];Br!==_0x558dd2&&(Br=_0x558dd2,await fetch(_0x541583,{'method':_0x558dd2?'POST':'DELETE','headers':_0x558dd2?{'Authorization':'Bearer\x20'+_0x558dd2}:{}}));};function F_(_0xb72816=Zr()){const _0x2476e7=Hi(_0xb72816,'auth');if(_0x2476e7['isInitialized']())return _0x2476e7['getImmediate']();const _0x3ea0c8=Wf(_0xb72816,{'popupRedirectResolver':o_,'persistence':[mp,rp,za]}),_0x1d796f=jr('authTokenSyncURL');if(_0x1d796f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2a4eba=new URL(_0x1d796f,location['origin']);if(location['origin']===_0x2a4eba['origin']){const _0x5cdcbe=d_(_0x2a4eba['toString']());np(_0x3ea0c8,_0x5cdcbe,()=>_0x5cdcbe(_0x3ea0c8['currentUser'])),tp(_0x3ea0c8,_0x36493e=>_0x5cdcbe(_0x36493e));}}const _0x2dabb8=qr('auth');return _0x2dabb8&&Vf(_0x3ea0c8,'http://'+_0x2dabb8),_0x3ea0c8;}function f_(){var _0x9e1d1;return((_0x9e1d1=document['getElementsByTagName']('head'))==null?void 0x0:_0x9e1d1[0x0])??document;}Of({'loadJS'(_0x526170){return new Promise((_0x168764,_0xe85102)=>{const _0x39151b=document['createElement']('script');_0x39151b['setAttribute']('src',_0x526170),_0x39151b['onload']=_0x168764,_0x39151b['onerror']=_0x27abe2=>{const _0x5cf734=X('internal-error');_0x5cf734['customData']=_0x27abe2,_0xe85102(_0x5cf734);},_0x39151b['type']='text/javascript',_0x39151b['charset']='UTF-8',f_()['appendChild'](_0x39151b);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),l_('Browser');export{O_ as A,T_ as B,w_ as C,I_ as D,R_ as a,F_ as b,rp as c,Zr as d,E_ as e,D_ as f,p_ as g,x_ as h,Sl as i,__ as j,Vd as k,N_ as l,$d as m,A_ as n,m_ as o,L_ as p,k_ as q,g_ as r,M_ as s,b_ as t,v_ as u,C_ as v,S_ as w,Bt as x,y_ as y,P_ as z};