const Ja=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x37c6fb,_0x1c2364){if(!_0x37c6fb)throw lt(_0x1c2364);},lt=function(_0x4957a8){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4957a8);},Hr=function(_0x2f4401){const _0x551479=[];let _0x51395c=0x0;for(let _0x12daf3=0x0;_0x12daf3<_0x2f4401['length'];_0x12daf3++){let _0x46f7bc=_0x2f4401['charCodeAt'](_0x12daf3);_0x46f7bc<0x80?_0x551479[_0x51395c++]=_0x46f7bc:_0x46f7bc<0x800?(_0x551479[_0x51395c++]=_0x46f7bc>>0x6|0xc0,_0x551479[_0x51395c++]=_0x46f7bc&0x3f|0x80):(_0x46f7bc&0xfc00)===0xd800&&_0x12daf3+0x1<_0x2f4401['length']&&(_0x2f4401['charCodeAt'](_0x12daf3+0x1)&0xfc00)===0xdc00?(_0x46f7bc=0x10000+((_0x46f7bc&0x3ff)<<0xa)+(_0x2f4401['charCodeAt'](++_0x12daf3)&0x3ff),_0x551479[_0x51395c++]=_0x46f7bc>>0x12|0xf0,_0x551479[_0x51395c++]=_0x46f7bc>>0xc&0x3f|0x80,_0x551479[_0x51395c++]=_0x46f7bc>>0x6&0x3f|0x80,_0x551479[_0x51395c++]=_0x46f7bc&0x3f|0x80):(_0x551479[_0x51395c++]=_0x46f7bc>>0xc|0xe0,_0x551479[_0x51395c++]=_0x46f7bc>>0x6&0x3f|0x80,_0x551479[_0x51395c++]=_0x46f7bc&0x3f|0x80);}return _0x551479;},Xa=function(_0x15483e){const _0x252b66=[];let _0x13f13f=0x0,_0x3f8022=0x0;for(;_0x13f13f<_0x15483e['length'];){const _0x38ce72=_0x15483e[_0x13f13f++];if(_0x38ce72<0x80)_0x252b66[_0x3f8022++]=String['fromCharCode'](_0x38ce72);else{if(_0x38ce72>0xbf&&_0x38ce72<0xe0){const _0x1c6d96=_0x15483e[_0x13f13f++];_0x252b66[_0x3f8022++]=String['fromCharCode']((_0x38ce72&0x1f)<<0x6|_0x1c6d96&0x3f);}else{if(_0x38ce72>0xef&&_0x38ce72<0x16d){const _0x1b2ad5=_0x15483e[_0x13f13f++],_0x443243=_0x15483e[_0x13f13f++],_0x4d4e78=_0x15483e[_0x13f13f++],_0x593785=((_0x38ce72&0x7)<<0x12|(_0x1b2ad5&0x3f)<<0xc|(_0x443243&0x3f)<<0x6|_0x4d4e78&0x3f)-0x10000;_0x252b66[_0x3f8022++]=String['fromCharCode'](0xd800+(_0x593785>>0xa)),_0x252b66[_0x3f8022++]=String['fromCharCode'](0xdc00+(_0x593785&0x3ff));}else{const _0x48a2b7=_0x15483e[_0x13f13f++],_0x3338e2=_0x15483e[_0x13f13f++];_0x252b66[_0x3f8022++]=String['fromCharCode']((_0x38ce72&0xf)<<0xc|(_0x48a2b7&0x3f)<<0x6|_0x3338e2&0x3f);}}}}return _0x252b66['join']('');},xi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x41b07b,_0x5a202e){if(!Array['isArray'](_0x41b07b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x48669c=_0x5a202e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x458215=[];for(let _0x18fc88=0x0;_0x18fc88<_0x41b07b['length'];_0x18fc88+=0x3){const _0x5eff12=_0x41b07b[_0x18fc88],_0x5652d4=_0x18fc88+0x1<_0x41b07b['length'],_0x1ccef8=_0x5652d4?_0x41b07b[_0x18fc88+0x1]:0x0,_0xa3deaa=_0x18fc88+0x2<_0x41b07b['length'],_0x2b3466=_0xa3deaa?_0x41b07b[_0x18fc88+0x2]:0x0,_0x4febff=_0x5eff12>>0x2,_0x7063d0=(_0x5eff12&0x3)<<0x4|_0x1ccef8>>0x4;let _0x426aea=(_0x1ccef8&0xf)<<0x2|_0x2b3466>>0x6,_0xd1c48a=_0x2b3466&0x3f;_0xa3deaa||(_0xd1c48a=0x40,_0x5652d4||(_0x426aea=0x40)),_0x458215['push'](_0x48669c[_0x4febff],_0x48669c[_0x7063d0],_0x48669c[_0x426aea],_0x48669c[_0xd1c48a]);}return _0x458215['join']('');},'encodeString'(_0x4d6eef,_0x127a6e){return this['HAS_NATIVE_SUPPORT']&&!_0x127a6e?btoa(_0x4d6eef):this['encodeByteArray'](Hr(_0x4d6eef),_0x127a6e);},'decodeString'(_0x30a577,_0x232146){return this['HAS_NATIVE_SUPPORT']&&!_0x232146?atob(_0x30a577):Xa(this['decodeStringToByteArray'](_0x30a577,_0x232146));},'decodeStringToByteArray'(_0x1b3ff3,_0xe8e94c){this['init_']();const _0x67ca74=_0xe8e94c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4e979e=[];for(let _0x564bc9=0x0;_0x564bc9<_0x1b3ff3['length'];){const _0x5889f0=_0x67ca74[_0x1b3ff3['charAt'](_0x564bc9++)],_0x238fa4=_0x564bc9<_0x1b3ff3['length']?_0x67ca74[_0x1b3ff3['charAt'](_0x564bc9)]:0x0;++_0x564bc9;const _0x1b17f2=_0x564bc9<_0x1b3ff3['length']?_0x67ca74[_0x1b3ff3['charAt'](_0x564bc9)]:0x40;++_0x564bc9;const _0x1173f8=_0x564bc9<_0x1b3ff3['length']?_0x67ca74[_0x1b3ff3['charAt'](_0x564bc9)]:0x40;if(++_0x564bc9,_0x5889f0==null||_0x238fa4==null||_0x1b17f2==null||_0x1173f8==null)throw new Za();const _0x3c5981=_0x5889f0<<0x2|_0x238fa4>>0x4;if(_0x4e979e['push'](_0x3c5981),_0x1b17f2!==0x40){const _0x1276f1=_0x238fa4<<0x4&0xf0|_0x1b17f2>>0x2;if(_0x4e979e['push'](_0x1276f1),_0x1173f8!==0x40){const _0x5a21c6=_0x1b17f2<<0x6&0xc0|_0x1173f8;_0x4e979e['push'](_0x5a21c6);}}}return _0x4e979e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x403521=0x0;_0x403521<this['ENCODED_VALS']['length'];_0x403521++)this['byteToCharMap_'][_0x403521]=this['ENCODED_VALS']['charAt'](_0x403521),this['charToByteMap_'][this['byteToCharMap_'][_0x403521]]=_0x403521,this['byteToCharMapWebSafe_'][_0x403521]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x403521),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x403521]]=_0x403521,_0x403521>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x403521)]=_0x403521,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x403521)]=_0x403521);}}};class Za extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3dc33e){const _0x87c1a5=Hr(_0x3dc33e);return xi['encodeByteArray'](_0x87c1a5,!0x0);},un=function(_0x5cc2eb){return $r(_0x5cc2eb)['replace'](/\./g,'');},dn=function(_0x1dfd8b){try{return xi['decodeString'](_0x1dfd8b,!0x0);}catch(_0x5ba62a){console['error']('base64Decode\x20failed:\x20',_0x5ba62a);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ec(_0x3159d2){return Gr(void 0x0,_0x3159d2);}function Gr(_0x1830df,_0xe222d7){if(!(_0xe222d7 instanceof Object))return _0xe222d7;switch(_0xe222d7['constructor']){case Date:const _0x2a02ba=_0xe222d7;return new Date(_0x2a02ba['getTime']());case Object:_0x1830df===void 0x0&&(_0x1830df={});break;case Array:_0x1830df=[];break;default:return _0xe222d7;}for(const _0x5c11a0 in _0xe222d7)!_0xe222d7['hasOwnProperty'](_0x5c11a0)||!tc(_0x5c11a0)||(_0x1830df[_0x5c11a0]=Gr(_0x1830df[_0x5c11a0],_0xe222d7[_0x5c11a0]));return _0x1830df;}function tc(_0x2f6c66){return _0x2f6c66!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ic=()=>nc()['__FIREBASE_DEFAULTS__'],sc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3bd39f=Ns['__FIREBASE_DEFAULTS__'];if(_0x3bd39f)return JSON['parse'](_0x3bd39f);},rc=()=>{if(typeof document>'u')return;let _0x4de027;try{_0x4de027=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x57309d=_0x4de027&&dn(_0x4de027[0x1]);return _0x57309d&&JSON['parse'](_0x57309d);},Fi=()=>{try{return Ja()||ic()||sc()||rc();}catch(_0x4d695e){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4d695e);return;}},qr=_0xee7e3=>{var _0x232b96,_0x1470fe;return(_0x1470fe=(_0x232b96=Fi())==null?void 0x0:_0x232b96['emulatorHosts'])==null?void 0x0:_0x1470fe[_0xee7e3];},oc=_0x5b688b=>{const _0x2e0574=qr(_0x5b688b);if(!_0x2e0574)return;const _0x216be1=_0x2e0574['lastIndexOf'](':');if(_0x216be1<=0x0||_0x216be1+0x1===_0x2e0574['length'])throw new Error('Invalid\x20host\x20'+_0x2e0574+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1bb469=parseInt(_0x2e0574['substring'](_0x216be1+0x1),0xa);return _0x2e0574[0x0]==='['?[_0x2e0574['substring'](0x1,_0x216be1-0x1),_0x1bb469]:[_0x2e0574['substring'](0x0,_0x216be1),_0x1bb469];},zr=()=>{var _0x2489df;return(_0x2489df=Fi())==null?void 0x0:_0x2489df['config'];},jr=_0x6ff7da=>{var _0x28ff91;return(_0x28ff91=Fi())==null?void 0x0:_0x28ff91['_'+_0x6ff7da];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x56c149,_0x2bf580)=>{this['resolve']=_0x56c149,this['reject']=_0x2bf580;});}['wrapCallback'](_0x147d37){return(_0xbd9a23,_0x444fc3)=>{_0xbd9a23?this['reject'](_0xbd9a23):this['resolve'](_0x444fc3),typeof _0x147d37=='function'&&(this['promise']['catch'](()=>{}),_0x147d37['length']===0x1?_0x147d37(_0xbd9a23):_0x147d37(_0xbd9a23,_0x444fc3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ac(_0x257318,_0x5c8f9b){if(_0x257318['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5db872={'alg':'none','type':'JWT'},_0x3f313f=_0x5c8f9b||'demo-project',_0x3bfb79=_0x257318['iat']||0x0,_0xf0255a=_0x257318['sub']||_0x257318['user_id'];if(!_0xf0255a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x36f76a={'iss':'https://securetoken.google.com/'+_0x3f313f,'aud':_0x3f313f,'iat':_0x3bfb79,'exp':_0x3bfb79+0xe10,'auth_time':_0x3bfb79,'sub':_0xf0255a,'user_id':_0xf0255a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x257318};return[un(JSON['stringify'](_0x5db872)),un(JSON['stringify'](_0x36f76a)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Ui(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function cc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function lc(){const _0x1ec1b6=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1ec1b6=='object'&&_0x1ec1b6['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function hc(){const _0x21af6f=W();return _0x21af6f['indexOf']('MSIE\x20')>=0x0||_0x21af6f['indexOf']('Trident/')>=0x0;}function uc(){return Vr['NODE_ADMIN']===!0x0;}function dc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function fc(){return new Promise((_0x2e46bd,_0x21432f)=>{try{let _0xd4f416=!0x0;const _0x1623a7='validate-browser-context-for-indexeddb-analytics-module',_0x1e76b2=self['indexedDB']['open'](_0x1623a7);_0x1e76b2['onsuccess']=()=>{_0x1e76b2['result']['close'](),_0xd4f416||self['indexedDB']['deleteDatabase'](_0x1623a7),_0x2e46bd(!0x0);},_0x1e76b2['onupgradeneeded']=()=>{_0xd4f416=!0x1;},_0x1e76b2['onerror']=()=>{var _0x5384bb;_0x21432f(((_0x5384bb=_0x1e76b2['error'])==null?void 0x0:_0x5384bb['message'])||'');};}catch(_0x1736ed){_0x21432f(_0x1736ed);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pc='FirebaseError';class be extends Error{constructor(_0x566ed0,_0x533cc2,_0x539905){super(_0x533cc2),this['code']=_0x566ed0,this['customData']=_0x539905,this['name']=pc,Object['setPrototypeOf'](this,be['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0xe9835b,_0x31fd7e,_0xb81170){this['service']=_0xe9835b,this['serviceName']=_0x31fd7e,this['errors']=_0xb81170;}['create'](_0x24a8d5,..._0x47b650){const _0x1053a3=_0x47b650[0x0]||{},_0x43c026=this['service']+'/'+_0x24a8d5,_0x118be2=this['errors'][_0x24a8d5],_0x1f9eed=_0x118be2?_c(_0x118be2,_0x1053a3):'Error',_0x56fd8d=this['serviceName']+':\x20'+_0x1f9eed+'\x20('+_0x43c026+').';return new be(_0x43c026,_0x56fd8d,_0x1053a3);}}function _c(_0x324557,_0x1654a0){return _0x324557['replace'](gc,(_0x4b2bd8,_0xf3c46b)=>{const _0x3ff2cd=_0x1654a0[_0xf3c46b];return _0x3ff2cd!=null?String(_0x3ff2cd):'<'+_0xf3c46b+'?>';});}const gc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x49ad98){return JSON['parse'](_0x49ad98);}function O(_0x3e4667){return JSON['stringify'](_0x3e4667);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5bbfe9){let _0x23deea={},_0x5285e1={},_0x92c172={},_0x28cfb='';try{const _0x28ca5f=_0x5bbfe9['split']('.');_0x23deea=Nt(dn(_0x28ca5f[0x0])||''),_0x5285e1=Nt(dn(_0x28ca5f[0x1])||''),_0x28cfb=_0x28ca5f[0x2],_0x92c172=_0x5285e1['d']||{},delete _0x5285e1['d'];}catch{}return{'header':_0x23deea,'claims':_0x5285e1,'data':_0x92c172,'signature':_0x28cfb};},mc=function(_0x45794e){const _0x207439=Yr(_0x45794e),_0x30828a=_0x207439['claims'];return!!_0x30828a&&typeof _0x30828a=='object'&&_0x30828a['hasOwnProperty']('iat');},yc=function(_0x163be5){const _0x14bb3a=Yr(_0x163be5)['claims'];return typeof _0x14bb3a=='object'&&_0x14bb3a['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x517ce8,_0x47a789){return Object['prototype']['hasOwnProperty']['call'](_0x517ce8,_0x47a789);}function Me(_0xfce4b3,_0x105a40){if(Object['prototype']['hasOwnProperty']['call'](_0xfce4b3,_0x105a40))return _0xfce4b3[_0x105a40];}function fn(_0x2d6978){for(const _0x4371c5 in _0x2d6978)if(Object['prototype']['hasOwnProperty']['call'](_0x2d6978,_0x4371c5))return!0x1;return!0x0;}function pn(_0x571e44,_0xdb5d7f,_0x2f770a){const _0x382e16={};for(const _0x757d58 in _0x571e44)Object['prototype']['hasOwnProperty']['call'](_0x571e44,_0x757d58)&&(_0x382e16[_0x757d58]=_0xdb5d7f['call'](_0x2f770a,_0x571e44[_0x757d58],_0x757d58,_0x571e44));return _0x382e16;}function Le(_0x4d11c2,_0x8ab1c8){if(_0x4d11c2===_0x8ab1c8)return!0x0;const _0x4f476d=Object['keys'](_0x4d11c2),_0x909374=Object['keys'](_0x8ab1c8);for(const _0x391289 of _0x4f476d){if(!_0x909374['includes'](_0x391289))return!0x1;const _0x2461d2=_0x4d11c2[_0x391289],_0x471213=_0x8ab1c8[_0x391289];if(Ps(_0x2461d2)&&Ps(_0x471213)){if(!Le(_0x2461d2,_0x471213))return!0x1;}else{if(_0x2461d2!==_0x471213)return!0x1;}}for(const _0xc93d68 of _0x909374)if(!_0x4f476d['includes'](_0xc93d68))return!0x1;return!0x0;}function Ps(_0x244d17){return _0x244d17!==null&&typeof _0x244d17=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ht(_0x4887ba){const _0xa4dcb2=[];for(const [_0x5e8fed,_0xdf0666]of Object['entries'](_0x4887ba))Array['isArray'](_0xdf0666)?_0xdf0666['forEach'](_0x54f1a3=>{_0xa4dcb2['push'](encodeURIComponent(_0x5e8fed)+'='+encodeURIComponent(_0x54f1a3));}):_0xa4dcb2['push'](encodeURIComponent(_0x5e8fed)+'='+encodeURIComponent(_0xdf0666));return _0xa4dcb2['length']?'&'+_0xa4dcb2['join']('&'):'';}function wt(_0x460b94){const _0x33449b={};return _0x460b94['replace'](/^\?/,'')['split']('&')['forEach'](_0x25ade2=>{if(_0x25ade2){const [_0x122a08,_0x3ad076]=_0x25ade2['split']('=');_0x33449b[decodeURIComponent(_0x122a08)]=decodeURIComponent(_0x3ad076);}}),_0x33449b;}function Ct(_0x2bc7da){const _0x571362=_0x2bc7da['indexOf']('?');if(!_0x571362)return'';const _0x363682=_0x2bc7da['indexOf']('#',_0x571362);return _0x2bc7da['substring'](_0x571362,_0x363682>0x0?_0x363682:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1d77e0=0x1;_0x1d77e0<this['blockSize'];++_0x1d77e0)this['pad_'][_0x1d77e0]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3c4738,_0xa4c87f){_0xa4c87f||(_0xa4c87f=0x0);const _0x2d184a=this['W_'];if(typeof _0x3c4738=='string'){for(let _0x5bdd25=0x0;_0x5bdd25<0x10;_0x5bdd25++)_0x2d184a[_0x5bdd25]=_0x3c4738['charCodeAt'](_0xa4c87f)<<0x18|_0x3c4738['charCodeAt'](_0xa4c87f+0x1)<<0x10|_0x3c4738['charCodeAt'](_0xa4c87f+0x2)<<0x8|_0x3c4738['charCodeAt'](_0xa4c87f+0x3),_0xa4c87f+=0x4;}else{for(let _0x5e8535=0x0;_0x5e8535<0x10;_0x5e8535++)_0x2d184a[_0x5e8535]=_0x3c4738[_0xa4c87f]<<0x18|_0x3c4738[_0xa4c87f+0x1]<<0x10|_0x3c4738[_0xa4c87f+0x2]<<0x8|_0x3c4738[_0xa4c87f+0x3],_0xa4c87f+=0x4;}for(let _0xf8b36c=0x10;_0xf8b36c<0x50;_0xf8b36c++){const _0x2ecf75=_0x2d184a[_0xf8b36c-0x3]^_0x2d184a[_0xf8b36c-0x8]^_0x2d184a[_0xf8b36c-0xe]^_0x2d184a[_0xf8b36c-0x10];_0x2d184a[_0xf8b36c]=(_0x2ecf75<<0x1|_0x2ecf75>>>0x1f)&0xffffffff;}let _0x4fa29b=this['chain_'][0x0],_0x2b7507=this['chain_'][0x1],_0x310007=this['chain_'][0x2],_0x2c8ea5=this['chain_'][0x3],_0x197608=this['chain_'][0x4],_0x3609cf,_0xf3437;for(let _0x5a9c8e=0x0;_0x5a9c8e<0x50;_0x5a9c8e++){_0x5a9c8e<0x28?_0x5a9c8e<0x14?(_0x3609cf=_0x2c8ea5^_0x2b7507&(_0x310007^_0x2c8ea5),_0xf3437=0x5a827999):(_0x3609cf=_0x2b7507^_0x310007^_0x2c8ea5,_0xf3437=0x6ed9eba1):_0x5a9c8e<0x3c?(_0x3609cf=_0x2b7507&_0x310007|_0x2c8ea5&(_0x2b7507|_0x310007),_0xf3437=0x8f1bbcdc):(_0x3609cf=_0x2b7507^_0x310007^_0x2c8ea5,_0xf3437=0xca62c1d6);const _0x402e59=(_0x4fa29b<<0x5|_0x4fa29b>>>0x1b)+_0x3609cf+_0x197608+_0xf3437+_0x2d184a[_0x5a9c8e]&0xffffffff;_0x197608=_0x2c8ea5,_0x2c8ea5=_0x310007,_0x310007=(_0x2b7507<<0x1e|_0x2b7507>>>0x2)&0xffffffff,_0x2b7507=_0x4fa29b,_0x4fa29b=_0x402e59;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4fa29b&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2b7507&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x310007&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2c8ea5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x197608&0xffffffff;}['update'](_0x52fc43,_0x157433){if(_0x52fc43==null)return;_0x157433===void 0x0&&(_0x157433=_0x52fc43['length']);const _0x1f0b36=_0x157433-this['blockSize'];let _0x1cec9d=0x0;const _0x2eff68=this['buf_'];let _0x35e038=this['inbuf_'];for(;_0x1cec9d<_0x157433;){if(_0x35e038===0x0){for(;_0x1cec9d<=_0x1f0b36;)this['compress_'](_0x52fc43,_0x1cec9d),_0x1cec9d+=this['blockSize'];}if(typeof _0x52fc43=='string'){for(;_0x1cec9d<_0x157433;)if(_0x2eff68[_0x35e038]=_0x52fc43['charCodeAt'](_0x1cec9d),++_0x35e038,++_0x1cec9d,_0x35e038===this['blockSize']){this['compress_'](_0x2eff68),_0x35e038=0x0;break;}}else{for(;_0x1cec9d<_0x157433;)if(_0x2eff68[_0x35e038]=_0x52fc43[_0x1cec9d],++_0x35e038,++_0x1cec9d,_0x35e038===this['blockSize']){this['compress_'](_0x2eff68),_0x35e038=0x0;break;}}}this['inbuf_']=_0x35e038,this['total_']+=_0x157433;}['digest'](){const _0x283439=[];let _0x4c949e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2f73b3=this['blockSize']-0x1;_0x2f73b3>=0x38;_0x2f73b3--)this['buf_'][_0x2f73b3]=_0x4c949e&0xff,_0x4c949e/=0x100;this['compress_'](this['buf_']);let _0xd77d8f=0x0;for(let _0x11e34d=0x0;_0x11e34d<0x5;_0x11e34d++)for(let _0x1784c3=0x18;_0x1784c3>=0x0;_0x1784c3-=0x8)_0x283439[_0xd77d8f]=this['chain_'][_0x11e34d]>>_0x1784c3&0xff,++_0xd77d8f;return _0x283439;}}function Ec(_0x2e3fba,_0x2692cd){const _0x1e31ca=new Ic(_0x2e3fba,_0x2692cd);return _0x1e31ca['subscribe']['bind'](_0x1e31ca);}class Ic{constructor(_0x1dd848,_0x3ec24e){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3ec24e,this['task']['then'](()=>{_0x1dd848(this);})['catch'](_0x3aab74=>{this['error'](_0x3aab74);});}['next'](_0x148df4){this['forEachObserver'](_0x33f615=>{_0x33f615['next'](_0x148df4);});}['error'](_0x27e5dc){this['forEachObserver'](_0x190701=>{_0x190701['error'](_0x27e5dc);}),this['close'](_0x27e5dc);}['complete'](){this['forEachObserver'](_0x17cd9f=>{_0x17cd9f['complete']();}),this['close']();}['subscribe'](_0xee63ad,_0x44e844,_0x11d232){let _0x454406;if(_0xee63ad===void 0x0&&_0x44e844===void 0x0&&_0x11d232===void 0x0)throw new Error('Missing\x20Observer.');wc(_0xee63ad,['next','error','complete'])?_0x454406=_0xee63ad:_0x454406={'next':_0xee63ad,'error':_0x44e844,'complete':_0x11d232},_0x454406['next']===void 0x0&&(_0x454406['next']=ei),_0x454406['error']===void 0x0&&(_0x454406['error']=ei),_0x454406['complete']===void 0x0&&(_0x454406['complete']=ei);const _0x177975=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x454406['error'](this['finalError']):_0x454406['complete']();}catch{}}),this['observers']['push'](_0x454406),_0x177975;}['unsubscribeOne'](_0xddbc84){this['observers']===void 0x0||this['observers'][_0xddbc84]===void 0x0||(delete this['observers'][_0xddbc84],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3aed7e){if(!this['finalized']){for(let _0x18cf6e=0x0;_0x18cf6e<this['observers']['length'];_0x18cf6e++)this['sendOne'](_0x18cf6e,_0x3aed7e);}}['sendOne'](_0x249527,_0x3454cd){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x249527]!==void 0x0)try{_0x3454cd(this['observers'][_0x249527]);}catch(_0x29b187){typeof console<'u'&&console['error']&&console['error'](_0x29b187);}});}['close'](_0x158789){this['finalized']||(this['finalized']=!0x0,_0x158789!==void 0x0&&(this['finalError']=_0x158789),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function wc(_0x3d1641,_0x28d141){if(typeof _0x3d1641!='object'||_0x3d1641===null)return!0x1;for(const _0x3b6475 of _0x28d141)if(_0x3b6475 in _0x3d1641&&typeof _0x3d1641[_0x3b6475]=='function')return!0x0;return!0x1;}function ei(){}function nt(_0x5bdde3,_0x3a5630){return _0x5bdde3+'\x20failed:\x20'+_0x3a5630+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cc=function(_0x471da5){const _0x1d6a06=[];let _0x16edcb=0x0;for(let _0x342868=0x0;_0x342868<_0x471da5['length'];_0x342868++){let _0x5f2134=_0x471da5['charCodeAt'](_0x342868);if(_0x5f2134>=0xd800&&_0x5f2134<=0xdbff){const _0x2d8804=_0x5f2134-0xd800;_0x342868++,f(_0x342868<_0x471da5['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2cfce4=_0x471da5['charCodeAt'](_0x342868)-0xdc00;_0x5f2134=0x10000+(_0x2d8804<<0xa)+_0x2cfce4;}_0x5f2134<0x80?_0x1d6a06[_0x16edcb++]=_0x5f2134:_0x5f2134<0x800?(_0x1d6a06[_0x16edcb++]=_0x5f2134>>0x6|0xc0,_0x1d6a06[_0x16edcb++]=_0x5f2134&0x3f|0x80):_0x5f2134<0x10000?(_0x1d6a06[_0x16edcb++]=_0x5f2134>>0xc|0xe0,_0x1d6a06[_0x16edcb++]=_0x5f2134>>0x6&0x3f|0x80,_0x1d6a06[_0x16edcb++]=_0x5f2134&0x3f|0x80):(_0x1d6a06[_0x16edcb++]=_0x5f2134>>0x12|0xf0,_0x1d6a06[_0x16edcb++]=_0x5f2134>>0xc&0x3f|0x80,_0x1d6a06[_0x16edcb++]=_0x5f2134>>0x6&0x3f|0x80,_0x1d6a06[_0x16edcb++]=_0x5f2134&0x3f|0x80);}return _0x1d6a06;},Mn=function(_0xd8cde4){let _0x11aeaf=0x0;for(let _0x3fa0f7=0x0;_0x3fa0f7<_0xd8cde4['length'];_0x3fa0f7++){const _0x4e5abf=_0xd8cde4['charCodeAt'](_0x3fa0f7);_0x4e5abf<0x80?_0x11aeaf++:_0x4e5abf<0x800?_0x11aeaf+=0x2:_0x4e5abf>=0xd800&&_0x4e5abf<=0xdbff?(_0x11aeaf+=0x4,_0x3fa0f7++):_0x11aeaf+=0x3;}return _0x11aeaf;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x47753b){return _0x47753b&&_0x47753b['_delegate']?_0x47753b['_delegate']:_0x47753b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x68f051){try{return(_0x68f051['startsWith']('http://')||_0x68f051['startsWith']('https://')?new URL(_0x68f051)['hostname']:_0x68f051)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x39fd3b){return(await fetch(_0x39fd3b,{'credentials':'include'}))['ok'];}class xe{constructor(_0x418130,_0x1a1999,_0x301250){this['name']=_0x418130,this['instanceFactory']=_0x1a1999,this['type']=_0x301250,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x44bbf6){return this['instantiationMode']=_0x44bbf6,this;}['setMultipleInstances'](_0xbfb613){return this['multipleInstances']=_0xbfb613,this;}['setServiceProps'](_0x4ad84f){return this['serviceProps']=_0x4ad84f,this;}['setInstanceCreatedCallback'](_0x188d70){return this['onInstanceCreated']=_0x188d70,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tc{constructor(_0x3b882f,_0x357c27){this['name']=_0x3b882f,this['container']=_0x357c27,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3bf84d){const _0x1e49f1=this['normalizeInstanceIdentifier'](_0x3bf84d);if(!this['instancesDeferred']['has'](_0x1e49f1)){const _0xad7b4=new H();if(this['instancesDeferred']['set'](_0x1e49f1,_0xad7b4),this['isInitialized'](_0x1e49f1)||this['shouldAutoInitialize']())try{const _0x5cdda0=this['getOrInitializeService']({'instanceIdentifier':_0x1e49f1});_0x5cdda0&&_0xad7b4['resolve'](_0x5cdda0);}catch{}}return this['instancesDeferred']['get'](_0x1e49f1)['promise'];}['getImmediate'](_0x4dbacb){const _0x1f4cc8=this['normalizeInstanceIdentifier'](_0x4dbacb==null?void 0x0:_0x4dbacb['identifier']),_0x5db048=(_0x4dbacb==null?void 0x0:_0x4dbacb['optional'])??!0x1;if(this['isInitialized'](_0x1f4cc8)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1f4cc8});}catch(_0x34f125){if(_0x5db048)return null;throw _0x34f125;}else{if(_0x5db048)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1caeef){if(_0x1caeef['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1caeef['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1caeef,!!this['shouldAutoInitialize']()){if(bc(_0x1caeef))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1e233d,_0x57cfb4]of this['instancesDeferred']['entries']()){const _0x4ff4fe=this['normalizeInstanceIdentifier'](_0x1e233d);try{const _0xeee7a=this['getOrInitializeService']({'instanceIdentifier':_0x4ff4fe});_0x57cfb4['resolve'](_0xeee7a);}catch{}}}}['clearInstance'](_0x3a512e=ke){this['instancesDeferred']['delete'](_0x3a512e),this['instancesOptions']['delete'](_0x3a512e),this['instances']['delete'](_0x3a512e);}async['delete'](){const _0x2c1e45=Array['from'](this['instances']['values']());await Promise['all']([..._0x2c1e45['filter'](_0x300574=>'INTERNAL'in _0x300574)['map'](_0x30d31e=>_0x30d31e['INTERNAL']['delete']()),..._0x2c1e45['filter'](_0x3a9ed0=>'_delete'in _0x3a9ed0)['map'](_0x1fe62c=>_0x1fe62c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x58910b=ke){return this['instances']['has'](_0x58910b);}['getOptions'](_0x168e2b=ke){return this['instancesOptions']['get'](_0x168e2b)||{};}['initialize'](_0x3470c8={}){const {options:_0x360f71={}}=_0x3470c8,_0x4aafc1=this['normalizeInstanceIdentifier'](_0x3470c8['instanceIdentifier']);if(this['isInitialized'](_0x4aafc1))throw Error(this['name']+'('+_0x4aafc1+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2f1f8e=this['getOrInitializeService']({'instanceIdentifier':_0x4aafc1,'options':_0x360f71});for(const [_0x3dd197,_0x114616]of this['instancesDeferred']['entries']()){const _0x40a03f=this['normalizeInstanceIdentifier'](_0x3dd197);_0x4aafc1===_0x40a03f&&_0x114616['resolve'](_0x2f1f8e);}return _0x2f1f8e;}['onInit'](_0xdb2da,_0x207e9f){const _0x3aa139=this['normalizeInstanceIdentifier'](_0x207e9f),_0x5f51be=this['onInitCallbacks']['get'](_0x3aa139)??new Set();_0x5f51be['add'](_0xdb2da),this['onInitCallbacks']['set'](_0x3aa139,_0x5f51be);const _0x28ebdb=this['instances']['get'](_0x3aa139);return _0x28ebdb&&_0xdb2da(_0x28ebdb,_0x3aa139),()=>{_0x5f51be['delete'](_0xdb2da);};}['invokeOnInitCallbacks'](_0x24d7c7,_0x29dc75){const _0x15493c=this['onInitCallbacks']['get'](_0x29dc75);if(_0x15493c){for(const _0x3c6e2a of _0x15493c)try{_0x3c6e2a(_0x24d7c7,_0x29dc75);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4bbd66,options:_0x35e38b={}}){let _0x5a0712=this['instances']['get'](_0x4bbd66);if(!_0x5a0712&&this['component']&&(_0x5a0712=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':Sc(_0x4bbd66),'options':_0x35e38b}),this['instances']['set'](_0x4bbd66,_0x5a0712),this['instancesOptions']['set'](_0x4bbd66,_0x35e38b),this['invokeOnInitCallbacks'](_0x5a0712,_0x4bbd66),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4bbd66,_0x5a0712);}catch{}return _0x5a0712||null;}['normalizeInstanceIdentifier'](_0x127ef1=ke){return this['component']?this['component']['multipleInstances']?_0x127ef1:ke:_0x127ef1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function Sc(_0x2a97fd){return _0x2a97fd===ke?void 0x0:_0x2a97fd;}function bc(_0x331b42){return _0x331b42['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rc{constructor(_0x138c7f){this['name']=_0x138c7f,this['providers']=new Map();}['addComponent'](_0x5f0b76){const _0x35e667=this['getProvider'](_0x5f0b76['name']);if(_0x35e667['isComponentSet']())throw new Error('Component\x20'+_0x5f0b76['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x35e667['setComponent'](_0x5f0b76);}['addOrOverwriteComponent'](_0x1a07e9){this['getProvider'](_0x1a07e9['name'])['isComponentSet']()&&this['providers']['delete'](_0x1a07e9['name']),this['addComponent'](_0x1a07e9);}['getProvider'](_0x3b5088){if(this['providers']['has'](_0x3b5088))return this['providers']['get'](_0x3b5088);const _0x3487f2=new Tc(_0x3b5088,this);return this['providers']['set'](_0x3b5088,_0x3487f2),_0x3487f2;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x493da5){_0x493da5[_0x493da5['DEBUG']=0x0]='DEBUG',_0x493da5[_0x493da5['VERBOSE']=0x1]='VERBOSE',_0x493da5[_0x493da5['INFO']=0x2]='INFO',_0x493da5[_0x493da5['WARN']=0x3]='WARN',_0x493da5[_0x493da5['ERROR']=0x4]='ERROR',_0x493da5[_0x493da5['SILENT']=0x5]='SILENT';}(T||(T={})));const Ac={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},kc=T['INFO'],Nc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Pc=(_0x52c412,_0x59305a,..._0x1ebe3e)=>{if(_0x59305a<_0x52c412['logLevel'])return;const _0x3d8377=new Date()['toISOString'](),_0x5f2bbf=Nc[_0x59305a];if(_0x5f2bbf)console[_0x5f2bbf]('['+_0x3d8377+']\x20\x20'+_0x52c412['name']+':',..._0x1ebe3e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x59305a+')');};class Wi{constructor(_0x543ad9){this['name']=_0x543ad9,this['_logLevel']=kc,this['_logHandler']=Pc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x25ec99){if(!(_0x25ec99 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x25ec99+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x25ec99;}['setLogLevel'](_0x2c777a){this['_logLevel']=typeof _0x2c777a=='string'?Ac[_0x2c777a]:_0x2c777a;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x59b5f0){if(typeof _0x59b5f0!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x59b5f0;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3dabcd){this['_userLogHandler']=_0x3dabcd;}['debug'](..._0x365dc3){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x365dc3),this['_logHandler'](this,T['DEBUG'],..._0x365dc3);}['log'](..._0x4537e4){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4537e4),this['_logHandler'](this,T['VERBOSE'],..._0x4537e4);}['info'](..._0x5848eb){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5848eb),this['_logHandler'](this,T['INFO'],..._0x5848eb);}['warn'](..._0x4db5cd){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4db5cd),this['_logHandler'](this,T['WARN'],..._0x4db5cd);}['error'](..._0x5c711c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5c711c),this['_logHandler'](this,T['ERROR'],..._0x5c711c);}}const Oc=(_0x5d7b16,_0x3681c0)=>_0x3681c0['some'](_0x480cc7=>_0x5d7b16 instanceof _0x480cc7);let Os,Ds;function Dc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Mc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),pi=new WeakMap(),Xr=new WeakMap(),ti=new WeakMap(),Bi=new WeakMap();function Lc(_0x5409bd){const _0xe737b7=new Promise((_0x205984,_0x54a836)=>{const _0x330be7=()=>{_0x5409bd['removeEventListener']('success',_0x1bba33),_0x5409bd['removeEventListener']('error',_0x4bdbe1);},_0x1bba33=()=>{_0x205984(ge(_0x5409bd['result'])),_0x330be7();},_0x4bdbe1=()=>{_0x54a836(_0x5409bd['error']),_0x330be7();};_0x5409bd['addEventListener']('success',_0x1bba33),_0x5409bd['addEventListener']('error',_0x4bdbe1);});return _0xe737b7['then'](_0x53ae49=>{_0x53ae49 instanceof IDBCursor&&Jr['set'](_0x53ae49,_0x5409bd);})['catch'](()=>{}),Bi['set'](_0xe737b7,_0x5409bd),_0xe737b7;}function xc(_0x9dcf24){if(pi['has'](_0x9dcf24))return;const _0x4bfa89=new Promise((_0x2079db,_0x2bad2c)=>{const _0x57698c=()=>{_0x9dcf24['removeEventListener']('complete',_0x68aa8f),_0x9dcf24['removeEventListener']('error',_0x54fc7d),_0x9dcf24['removeEventListener']('abort',_0x54fc7d);},_0x68aa8f=()=>{_0x2079db(),_0x57698c();},_0x54fc7d=()=>{_0x2bad2c(_0x9dcf24['error']||new DOMException('AbortError','AbortError')),_0x57698c();};_0x9dcf24['addEventListener']('complete',_0x68aa8f),_0x9dcf24['addEventListener']('error',_0x54fc7d),_0x9dcf24['addEventListener']('abort',_0x54fc7d);});pi['set'](_0x9dcf24,_0x4bfa89);}let _i={'get'(_0x46dac7,_0xadb1f7,_0x306d44){if(_0x46dac7 instanceof IDBTransaction){if(_0xadb1f7==='done')return pi['get'](_0x46dac7);if(_0xadb1f7==='objectStoreNames')return _0x46dac7['objectStoreNames']||Xr['get'](_0x46dac7);if(_0xadb1f7==='store')return _0x306d44['objectStoreNames'][0x1]?void 0x0:_0x306d44['objectStore'](_0x306d44['objectStoreNames'][0x0]);}return ge(_0x46dac7[_0xadb1f7]);},'set'(_0x4deb50,_0x5e6cab,_0x48c6a4){return _0x4deb50[_0x5e6cab]=_0x48c6a4,!0x0;},'has'(_0x5ece16,_0x29137c){return _0x5ece16 instanceof IDBTransaction&&(_0x29137c==='done'||_0x29137c==='store')?!0x0:_0x29137c in _0x5ece16;}};function Fc(_0x433e97){_i=_0x433e97(_i);}function Uc(_0x16176c){return _0x16176c===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x47b4a6,..._0x38be18){const _0x3dad3=_0x16176c['call'](ni(this),_0x47b4a6,..._0x38be18);return Xr['set'](_0x3dad3,_0x47b4a6['sort']?_0x47b4a6['sort']():[_0x47b4a6]),ge(_0x3dad3);}:Mc()['includes'](_0x16176c)?function(..._0x7866a1){return _0x16176c['apply'](ni(this),_0x7866a1),ge(Jr['get'](this));}:function(..._0x33cdc6){return ge(_0x16176c['apply'](ni(this),_0x33cdc6));};}function Wc(_0x3b8a0f){return typeof _0x3b8a0f=='function'?Uc(_0x3b8a0f):(_0x3b8a0f instanceof IDBTransaction&&xc(_0x3b8a0f),Oc(_0x3b8a0f,Dc())?new Proxy(_0x3b8a0f,_i):_0x3b8a0f);}function ge(_0x46a256){if(_0x46a256 instanceof IDBRequest)return Lc(_0x46a256);if(ti['has'](_0x46a256))return ti['get'](_0x46a256);const _0x444a4a=Wc(_0x46a256);return _0x444a4a!==_0x46a256&&(ti['set'](_0x46a256,_0x444a4a),Bi['set'](_0x444a4a,_0x46a256)),_0x444a4a;}const ni=_0x119390=>Bi['get'](_0x119390);function Bc(_0x8c432e,_0x18df9a,{blocked:_0x3478f2,upgrade:_0x1fa81a,blocking:_0x4456ab,terminated:_0x51528b}={}){const _0xa9ff21=indexedDB['open'](_0x8c432e,_0x18df9a),_0x1e64e4=ge(_0xa9ff21);return _0x1fa81a&&_0xa9ff21['addEventListener']('upgradeneeded',_0x432649=>{_0x1fa81a(ge(_0xa9ff21['result']),_0x432649['oldVersion'],_0x432649['newVersion'],ge(_0xa9ff21['transaction']),_0x432649);}),_0x3478f2&&_0xa9ff21['addEventListener']('blocked',_0x5c934b=>_0x3478f2(_0x5c934b['oldVersion'],_0x5c934b['newVersion'],_0x5c934b)),_0x1e64e4['then'](_0x3dd007=>{_0x51528b&&_0x3dd007['addEventListener']('close',()=>_0x51528b()),_0x4456ab&&_0x3dd007['addEventListener']('versionchange',_0x1dd345=>_0x4456ab(_0x1dd345['oldVersion'],_0x1dd345['newVersion'],_0x1dd345));})['catch'](()=>{}),_0x1e64e4;}const Vc=['get','getKey','getAll','getAllKeys','count'],Hc=['put','add','delete','clear'],ii=new Map();function Ms(_0x3e146c,_0x1ab2d9){if(!(_0x3e146c instanceof IDBDatabase&&!(_0x1ab2d9 in _0x3e146c)&&typeof _0x1ab2d9=='string'))return;if(ii['get'](_0x1ab2d9))return ii['get'](_0x1ab2d9);const _0x557d1c=_0x1ab2d9['replace'](/FromIndex$/,''),_0x5c2573=_0x1ab2d9!==_0x557d1c,_0x28e410=Hc['includes'](_0x557d1c);if(!(_0x557d1c in(_0x5c2573?IDBIndex:IDBObjectStore)['prototype'])||!(_0x28e410||Vc['includes'](_0x557d1c)))return;const _0x1b41d3=async function(_0x553080,..._0x1cd790){const _0x4c1bf6=this['transaction'](_0x553080,_0x28e410?'readwrite':'readonly');let _0xb834b0=_0x4c1bf6['store'];return _0x5c2573&&(_0xb834b0=_0xb834b0['index'](_0x1cd790['shift']())),(await Promise['all']([_0xb834b0[_0x557d1c](..._0x1cd790),_0x28e410&&_0x4c1bf6['done']]))[0x0];};return ii['set'](_0x1ab2d9,_0x1b41d3),_0x1b41d3;}Fc(_0x45513a=>({..._0x45513a,'get':(_0x4b1828,_0x3a0941,_0x13a502)=>Ms(_0x4b1828,_0x3a0941)||_0x45513a['get'](_0x4b1828,_0x3a0941,_0x13a502),'has':(_0x45719d,_0x4f80f1)=>!!Ms(_0x45719d,_0x4f80f1)||_0x45513a['has'](_0x45719d,_0x4f80f1)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $c{constructor(_0x3f0558){this['container']=_0x3f0558;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3a6c6c=>{if(Gc(_0x3a6c6c)){const _0x1d8ec1=_0x3a6c6c['getImmediate']();return _0x1d8ec1['library']+'/'+_0x1d8ec1['version'];}else return null;})['filter'](_0x2f4834=>_0x2f4834)['join']('\x20');}}function Gc(_0x3a16e6){const _0x23e58b=_0x3a16e6['getComponent']();return(_0x23e58b==null?void 0x0:_0x23e58b['type'])==='VERSION';}const gi='@firebase/app',Ls='0.15.1',oe=new Wi('@firebase/app'),qc='@firebase/app-compat',zc='@firebase/analytics-compat',jc='@firebase/analytics',Kc='@firebase/app-check-compat',Yc='@firebase/app-check',Qc='@firebase/auth',Jc='@firebase/auth-compat',Xc='@firebase/database',Zc='@firebase/data-connect',el='@firebase/database-compat',tl='@firebase/functions',nl='@firebase/functions-compat',il='@firebase/installations',sl='@firebase/installations-compat',rl='@firebase/messaging',ol='@firebase/messaging-compat',al='@firebase/performance',cl='@firebase/performance-compat',ll='@firebase/remote-config',hl='@firebase/remote-config-compat',ul='@firebase/storage',dl='@firebase/storage-compat',fl='@firebase/firestore',pl='@firebase/ai',_l='@firebase/firestore-compat',gl='firebase',ml='12.16.0',mi='[DEFAULT]',yl={[gi]:'fire-core',[qc]:'fire-core-compat',[jc]:'fire-analytics',[zc]:'fire-analytics-compat',[Yc]:'fire-app-check',[Kc]:'fire-app-check-compat',[Qc]:'fire-auth',[Jc]:'fire-auth-compat',[Xc]:'fire-rtdb',[Zc]:'fire-data-connect',[el]:'fire-rtdb-compat',[tl]:'fire-fn',[nl]:'fire-fn-compat',[il]:'fire-iid',[sl]:'fire-iid-compat',[rl]:'fire-fcm',[ol]:'fire-fcm-compat',[al]:'fire-perf',[cl]:'fire-perf-compat',[ll]:'fire-rc',[hl]:'fire-rc-compat',[ul]:'fire-gcs',[dl]:'fire-gcs-compat',[fl]:'fire-fst',[_l]:'fire-fst-compat',[pl]:'fire-vertex','fire-js':'fire-js',[gl]:'fire-js-all'},Fe=new Map(),yi=new Map(),vi=new Map();function xs(_0x1ebf8a,_0x219274){try{_0x1ebf8a['container']['addComponent'](_0x219274);}catch(_0x4309ba){oe['debug']('Component\x20'+_0x219274['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1ebf8a['name'],_0x4309ba);}}function it(_0x16f51d){const _0x120dfd=_0x16f51d['name'];if(vi['has'](_0x120dfd))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x120dfd+'.'),!0x1;vi['set'](_0x120dfd,_0x16f51d);for(const _0x2b62e0 of Fe['values']())xs(_0x2b62e0,_0x16f51d);for(const _0x356db9 of yi['values']())xs(_0x356db9,_0x16f51d);return!0x0;}function Vi(_0x4583bb,_0x6ae6a4){const _0x5b2cbb=_0x4583bb['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5b2cbb&&_0x5b2cbb['triggerHeartbeat'](),_0x4583bb['container']['getProvider'](_0x6ae6a4);}function $(_0x302229){return _0x302229==null?!0x1:_0x302229['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',vl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class El{constructor(_0x4aff64,_0x4833c5,_0x5a97e6){this['_isDeleted']=!0x1,this['_options']={..._0x4aff64},this['_config']={..._0x4833c5},this['_name']=_0x4833c5['name'],this['_automaticDataCollectionEnabled']=_0x4833c5['automaticDataCollectionEnabled'],this['_container']=_0x5a97e6,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x196bb3){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x196bb3;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1b135c){this['_isDeleted']=_0x1b135c;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ut=ml;function Il(_0x3c7708,_0x30b2d1={}){let _0x375576=_0x3c7708;typeof _0x30b2d1!='object'&&(_0x30b2d1={'name':_0x30b2d1});const _0x5b3b4c={'name':mi,'automaticDataCollectionEnabled':!0x0,..._0x30b2d1},_0x31e0b4=_0x5b3b4c['name'];if(typeof _0x31e0b4!='string'||!_0x31e0b4)throw me['create']('bad-app-name',{'appName':String(_0x31e0b4)});if(_0x375576||(_0x375576=zr()),!_0x375576)throw me['create']('no-options');const _0x3b89cc=Fe['get'](_0x31e0b4);if(_0x3b89cc){if(Le(_0x375576,_0x3b89cc['options'])&&Le(_0x5b3b4c,_0x3b89cc['config']))return _0x3b89cc;throw me['create']('duplicate-app',{'appName':_0x31e0b4});}const _0x18f8c6=new Rc(_0x31e0b4);for(const _0x3f61a0 of vi['values']())_0x18f8c6['addComponent'](_0x3f61a0);const _0x246b56=new El(_0x375576,_0x5b3b4c,_0x18f8c6);return Fe['set'](_0x31e0b4,_0x246b56),_0x246b56;}function Zr(_0xa81956=mi){const _0x46591e=Fe['get'](_0xa81956);if(!_0x46591e&&_0xa81956===mi&&zr())return Il();if(!_0x46591e)throw me['create']('no-app',{'appName':_0xa81956});return _0x46591e;}function f_(){return Array['from'](Fe['values']());}async function p_(_0x39051c){let _0x42d2cb=!0x1;const _0x507c8b=_0x39051c['name'];Fe['has'](_0x507c8b)?(_0x42d2cb=!0x0,Fe['delete'](_0x507c8b)):yi['has'](_0x507c8b)&&_0x39051c['decRefCount']()<=0x0&&(yi['delete'](_0x507c8b),_0x42d2cb=!0x0),_0x42d2cb&&(await Promise['all'](_0x39051c['container']['getProviders']()['map'](_0x5b174b=>_0x5b174b['delete']())),_0x39051c['isDeleted']=!0x0);}function ye(_0x5a675f,_0x5925bc,_0x160435){let _0x52fe4a=yl[_0x5a675f]??_0x5a675f;_0x160435&&(_0x52fe4a+='-'+_0x160435);const _0x2b3576=_0x52fe4a['match'](/\s|\//),_0xbfc021=_0x5925bc['match'](/\s|\//);if(_0x2b3576||_0xbfc021){const _0x241c87=['Unable\x20to\x20register\x20library\x20\x22'+_0x52fe4a+'\x22\x20with\x20version\x20\x22'+_0x5925bc+'\x22:'];_0x2b3576&&_0x241c87['push']('library\x20name\x20\x22'+_0x52fe4a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2b3576&&_0xbfc021&&_0x241c87['push']('and'),_0xbfc021&&_0x241c87['push']('version\x20name\x20\x22'+_0x5925bc+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x241c87['join']('\x20'));return;}it(new xe(_0x52fe4a+'-version',()=>({'library':_0x52fe4a,'version':_0x5925bc}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wl='firebase-heartbeat-database',Cl=0x1,Pt='firebase-heartbeat-store';let si=null;function eo(){return si||(si=Bc(wl,Cl,{'upgrade':(_0x2ea1e8,_0x34012e)=>{switch(_0x34012e){case 0x0:try{_0x2ea1e8['createObjectStore'](Pt);}catch(_0x5d392b){console['warn'](_0x5d392b);}}}})['catch'](_0x1d39c1=>{throw me['create']('idb-open',{'originalErrorMessage':_0x1d39c1['message']});})),si;}async function Tl(_0x150a66){try{const _0x45fef6=(await eo())['transaction'](Pt),_0x49317f=await _0x45fef6['objectStore'](Pt)['get'](to(_0x150a66));return await _0x45fef6['done'],_0x49317f;}catch(_0x327842){if(_0x327842 instanceof be)oe['warn'](_0x327842['message']);else{const _0x9a1118=me['create']('idb-get',{'originalErrorMessage':_0x327842==null?void 0x0:_0x327842['message']});oe['warn'](_0x9a1118['message']);}}}async function Fs(_0x4d4a0b,_0x460a30){try{const _0x2c455a=(await eo())['transaction'](Pt,'readwrite');await _0x2c455a['objectStore'](Pt)['put'](_0x460a30,to(_0x4d4a0b)),await _0x2c455a['done'];}catch(_0x224e60){if(_0x224e60 instanceof be)oe['warn'](_0x224e60['message']);else{const _0x278f98=me['create']('idb-set',{'originalErrorMessage':_0x224e60==null?void 0x0:_0x224e60['message']});oe['warn'](_0x278f98['message']);}}}function to(_0x46b55d){return _0x46b55d['name']+'!'+_0x46b55d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sl=0x400,bl=0x1e;class Rl{constructor(_0x1e4f75){this['container']=_0x1e4f75,this['_heartbeatsCache']=null;const _0x385b92=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new kl(_0x385b92),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4dd988=>(this['_heartbeatsCache']=_0x4dd988,_0x4dd988));}async['triggerHeartbeat'](){var _0x869b39,_0x54206a;try{const _0x5a5670=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xcc6a8a=Us();if(((_0x869b39=this['_heartbeatsCache'])==null?void 0x0:_0x869b39['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x54206a=this['_heartbeatsCache'])==null?void 0x0:_0x54206a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xcc6a8a||this['_heartbeatsCache']['heartbeats']['some'](_0x4c7213=>_0x4c7213['date']===_0xcc6a8a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xcc6a8a,'agent':_0x5a5670}),this['_heartbeatsCache']['heartbeats']['length']>bl){const _0x337126=Nl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x337126,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2a88ff){oe['warn'](_0x2a88ff);}}async['getHeartbeatsHeader'](){var _0x1ae200;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1ae200=this['_heartbeatsCache'])==null?void 0x0:_0x1ae200['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x263e3e=Us(),{heartbeatsToSend:_0x4dc31c,unsentEntries:_0x201543}=Al(this['_heartbeatsCache']['heartbeats']),_0x59d2ba=un(JSON['stringify']({'version':0x2,'heartbeats':_0x4dc31c}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x263e3e,_0x201543['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x201543,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x59d2ba;}catch(_0x25d1ae){return oe['warn'](_0x25d1ae),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Al(_0x247865,_0x227cf2=Sl){const _0x1c4b43=[];let _0x4ea877=_0x247865['slice']();for(const _0x156eb0 of _0x247865){const _0x4e69c6=_0x1c4b43['find'](_0x381582=>_0x381582['agent']===_0x156eb0['agent']);if(_0x4e69c6){if(_0x4e69c6['dates']['push'](_0x156eb0['date']),Ws(_0x1c4b43)>_0x227cf2){_0x4e69c6['dates']['pop']();break;}}else{if(_0x1c4b43['push']({'agent':_0x156eb0['agent'],'dates':[_0x156eb0['date']]}),Ws(_0x1c4b43)>_0x227cf2){_0x1c4b43['pop']();break;}}_0x4ea877=_0x4ea877['slice'](0x1);}return{'heartbeatsToSend':_0x1c4b43,'unsentEntries':_0x4ea877};}class kl{constructor(_0x26ad3f){this['app']=_0x26ad3f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return dc()?fc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x39cfe1=await Tl(this['app']);return _0x39cfe1!=null&&_0x39cfe1['heartbeats']?_0x39cfe1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x484fb){if(await this['_canUseIndexedDBPromise']){const _0x4dd7f3=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x484fb['lastSentHeartbeatDate']??_0x4dd7f3['lastSentHeartbeatDate'],'heartbeats':_0x484fb['heartbeats']});}else return;}async['add'](_0x31307){if(await this['_canUseIndexedDBPromise']){const _0x3e31cd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x31307['lastSentHeartbeatDate']??_0x3e31cd['lastSentHeartbeatDate'],'heartbeats':[..._0x3e31cd['heartbeats'],..._0x31307['heartbeats']]});}else return;}}function Ws(_0x494395){return un(JSON['stringify']({'version':0x2,'heartbeats':_0x494395}))['length'];}function Nl(_0x396953){if(_0x396953['length']===0x0)return-0x1;let _0x29cb76=0x0,_0x5dd684=_0x396953[0x0]['date'];for(let _0x12a74a=0x1;_0x12a74a<_0x396953['length'];_0x12a74a++)_0x396953[_0x12a74a]['date']<_0x5dd684&&(_0x5dd684=_0x396953[_0x12a74a]['date'],_0x29cb76=_0x12a74a);return _0x29cb76;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pl(_0x10532b){it(new xe('platform-logger',_0xe3ea98=>new $c(_0xe3ea98),'PRIVATE')),it(new xe('heartbeat',_0x3e132b=>new Rl(_0x3e132b),'PRIVATE')),ye(gi,Ls,_0x10532b),ye(gi,Ls,'esm2020'),ye('fire-js','');}Pl('');var Ol='firebase',Dl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(Ol,Dl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ml(_0x294851){no=_0x294851;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ll{constructor(_0x93309d){this['domStorage_']=_0x93309d,this['prefix_']='firebase:';}['set'](_0x38126f,_0x5b0df0){_0x5b0df0==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x38126f)):this['domStorage_']['setItem'](this['prefixedName_'](_0x38126f),O(_0x5b0df0));}['get'](_0x1bb71a){const _0x164787=this['domStorage_']['getItem'](this['prefixedName_'](_0x1bb71a));return _0x164787==null?null:Nt(_0x164787);}['remove'](_0x10ba1b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x10ba1b));}['prefixedName_'](_0x419bf5){return this['prefix_']+_0x419bf5;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x558e76,_0x4650a3){_0x4650a3==null?delete this['cache_'][_0x558e76]:this['cache_'][_0x558e76]=_0x4650a3;}['get'](_0x1b1832){return Q(this['cache_'],_0x1b1832)?this['cache_'][_0x1b1832]:null;}['remove'](_0x18eaef){delete this['cache_'][_0x18eaef];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1e9ee3){try{if(typeof window<'u'&&typeof window[_0x1e9ee3]<'u'){const _0x5b55e8=window[_0x1e9ee3];return _0x5b55e8['setItem']('firebase:sentinel','cache'),_0x5b55e8['removeItem']('firebase:sentinel'),new Ll(_0x5b55e8);}}catch{}return new xl();},Pe=io('localStorage'),Fl=io('sessionStorage'),Xe=new Wi('@firebase/database'),so=(function(){let _0x2047e3=0x1;return function(){return _0x2047e3++;};}()),ro=function(_0x284e97){const _0x24f65a=Cc(_0x284e97),_0x5587a8=new vc();_0x5587a8['update'](_0x24f65a);const _0x4e53cc=_0x5587a8['digest']();return xi['encodeByteArray'](_0x4e53cc);},qt=function(..._0x48c992){let _0x3f81e2='';for(let _0x161a1e=0x0;_0x161a1e<_0x48c992['length'];_0x161a1e++){const _0xa5a60e=_0x48c992[_0x161a1e];Array['isArray'](_0xa5a60e)||_0xa5a60e&&typeof _0xa5a60e=='object'&&typeof _0xa5a60e['length']=='number'?_0x3f81e2+=qt['apply'](null,_0xa5a60e):typeof _0xa5a60e=='object'?_0x3f81e2+=O(_0xa5a60e):_0x3f81e2+=_0xa5a60e,_0x3f81e2+='\x20';}return _0x3f81e2;};let Tt=null,$s=!0x0;const Ul=function(_0x4e1549,_0x178c97){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Xe['logLevel']=T['VERBOSE'],Tt=Xe['log']['bind'](Xe);},L=function(..._0x480ddd){if($s===!0x0&&($s=!0x1,Tt===null&&Fl['get']('logging_enabled')===!0x0&&Ul()),Tt){const _0xc3e0db=qt['apply'](null,_0x480ddd);Tt(_0xc3e0db);}},zt=function(_0x2aa56e){return function(..._0x5422be){L(_0x2aa56e,..._0x5422be);};},Ei=function(..._0x54a507){const _0xdd3119='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x54a507);Xe['error'](_0xdd3119);},ae=function(..._0x3d932d){const _0x3f96e3='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x3d932d);throw Xe['error'](_0x3f96e3),new Error(_0x3f96e3);},U=function(..._0x77f419){const _0x3546f9='FIREBASE\x20WARNING:\x20'+qt(..._0x77f419);Xe['warn'](_0x3546f9);},Wl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Ln=function(_0x50a432){return typeof _0x50a432=='number'&&(_0x50a432!==_0x50a432||_0x50a432===Number['POSITIVE_INFINITY']||_0x50a432===Number['NEGATIVE_INFINITY']);},Bl=function(_0x4b03f4){if(document['readyState']==='complete')_0x4b03f4();else{let _0xd173b9=!0x1;const _0x590430=function(){if(!document['body']){setTimeout(_0x590430,Math['floor'](0xa));return;}_0xd173b9||(_0xd173b9=!0x0,_0x4b03f4());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x590430,!0x1),window['addEventListener']('load',_0x590430,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x590430();}),window['attachEvent']('onload',_0x590430));}},Ue='[MIN_NAME]',Ie='[MAX_NAME]',Ge=function(_0x4472ea,_0xd220aa){if(_0x4472ea===_0xd220aa)return 0x0;if(_0x4472ea===Ue||_0xd220aa===Ie)return-0x1;if(_0xd220aa===Ue||_0x4472ea===Ie)return 0x1;{const _0x50858c=Gs(_0x4472ea),_0x3affaf=Gs(_0xd220aa);return _0x50858c!==null?_0x3affaf!==null?_0x50858c-_0x3affaf===0x0?_0x4472ea['length']-_0xd220aa['length']:_0x50858c-_0x3affaf:-0x1:_0x3affaf!==null?0x1:_0x4472ea<_0xd220aa?-0x1:0x1;}},Vl=function(_0x54f56a,_0x3bd67e){return _0x54f56a===_0x3bd67e?0x0:_0x54f56a<_0x3bd67e?-0x1:0x1;},yt=function(_0x4e58bc,_0x48fa72){if(_0x48fa72&&_0x4e58bc in _0x48fa72)return _0x48fa72[_0x4e58bc];throw new Error('Missing\x20required\x20key\x20('+_0x4e58bc+')\x20in\x20object:\x20'+O(_0x48fa72));},Hi=function(_0x42b1e4){if(typeof _0x42b1e4!='object'||_0x42b1e4===null)return O(_0x42b1e4);const _0x942458=[];for(const _0x2b87d8 in _0x42b1e4)_0x942458['push'](_0x2b87d8);_0x942458['sort']();let _0x10df9f='{';for(let _0x8e5726=0x0;_0x8e5726<_0x942458['length'];_0x8e5726++)_0x8e5726!==0x0&&(_0x10df9f+=','),_0x10df9f+=O(_0x942458[_0x8e5726]),_0x10df9f+=':',_0x10df9f+=Hi(_0x42b1e4[_0x942458[_0x8e5726]]);return _0x10df9f+='}',_0x10df9f;},oo=function(_0x1e0f1e,_0x17482e){const _0x12d561=_0x1e0f1e['length'];if(_0x12d561<=_0x17482e)return[_0x1e0f1e];const _0x518c78=[];for(let _0x22c15e=0x0;_0x22c15e<_0x12d561;_0x22c15e+=_0x17482e)_0x22c15e+_0x17482e>_0x12d561?_0x518c78['push'](_0x1e0f1e['substring'](_0x22c15e,_0x12d561)):_0x518c78['push'](_0x1e0f1e['substring'](_0x22c15e,_0x22c15e+_0x17482e));return _0x518c78;};function x(_0x1d5853,_0xf8a702){for(const _0x3e2e1d in _0x1d5853)_0x1d5853['hasOwnProperty'](_0x3e2e1d)&&_0xf8a702(_0x3e2e1d,_0x1d5853[_0x3e2e1d]);}const ao=function(_0x3d1320){f(!Ln(_0x3d1320),'Invalid\x20JSON\x20number');const _0x452b78=0xb,_0x2c77df=0x34,_0x5c63fa=(0x1<<_0x452b78-0x1)-0x1;let _0x527a71,_0x39fc79,_0x1d3086,_0x1be00c,_0x1ed195;_0x3d1320===0x0?(_0x39fc79=0x0,_0x1d3086=0x0,_0x527a71=0x1/_0x3d1320===-0x1/0x0?0x1:0x0):(_0x527a71=_0x3d1320<0x0,_0x3d1320=Math['abs'](_0x3d1320),_0x3d1320>=Math['pow'](0x2,0x1-_0x5c63fa)?(_0x1be00c=Math['min'](Math['floor'](Math['log'](_0x3d1320)/Math['LN2']),_0x5c63fa),_0x39fc79=_0x1be00c+_0x5c63fa,_0x1d3086=Math['round'](_0x3d1320*Math['pow'](0x2,_0x2c77df-_0x1be00c)-Math['pow'](0x2,_0x2c77df))):(_0x39fc79=0x0,_0x1d3086=Math['round'](_0x3d1320/Math['pow'](0x2,0x1-_0x5c63fa-_0x2c77df))));const _0x5628d4=[];for(_0x1ed195=_0x2c77df;_0x1ed195;_0x1ed195-=0x1)_0x5628d4['push'](_0x1d3086%0x2?0x1:0x0),_0x1d3086=Math['floor'](_0x1d3086/0x2);for(_0x1ed195=_0x452b78;_0x1ed195;_0x1ed195-=0x1)_0x5628d4['push'](_0x39fc79%0x2?0x1:0x0),_0x39fc79=Math['floor'](_0x39fc79/0x2);_0x5628d4['push'](_0x527a71?0x1:0x0),_0x5628d4['reverse']();const _0xfea1d2=_0x5628d4['join']('');let _0x4afca2='';for(_0x1ed195=0x0;_0x1ed195<0x40;_0x1ed195+=0x8){let _0x1a35d0=parseInt(_0xfea1d2['substr'](_0x1ed195,0x8),0x2)['toString'](0x10);_0x1a35d0['length']===0x1&&(_0x1a35d0='0'+_0x1a35d0),_0x4afca2=_0x4afca2+_0x1a35d0;}return _0x4afca2['toLowerCase']();},Hl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},$l=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Gl(_0x23762d,_0x314ddd){let _0xe710e4='Unknown\x20Error';_0x23762d==='too_big'?_0xe710e4='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x23762d==='permission_denied'?_0xe710e4='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x23762d==='unavailable'&&(_0xe710e4='The\x20service\x20is\x20unavailable');const _0x47a971=new Error(_0x23762d+'\x20at\x20'+_0x314ddd['_path']['toString']()+':\x20'+_0xe710e4);return _0x47a971['code']=_0x23762d['toUpperCase'](),_0x47a971;}const ql=new RegExp('^-?(0*)\x5cd{1,10}$'),zl=-0x80000000,jl=0x7fffffff,Gs=function(_0x30ef9f){if(ql['test'](_0x30ef9f)){const _0x526631=Number(_0x30ef9f);if(_0x526631>=zl&&_0x526631<=jl)return _0x526631;}return null;},dt=function(_0x21c594){try{_0x21c594();}catch(_0x2d3547){setTimeout(()=>{const _0x26da07=_0x2d3547['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x26da07),_0x2d3547;},Math['floor'](0x0));}},Kl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0xa0dd1b,_0x5985f8){const _0x7e3d96=setTimeout(_0xa0dd1b,_0x5985f8);return typeof _0x7e3d96=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x7e3d96):typeof _0x7e3d96=='object'&&_0x7e3d96['unref']&&_0x7e3d96['unref'](),_0x7e3d96;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yl{constructor(_0x31d320,_0x4167d8){this['appCheckProvider']=_0x4167d8,this['appName']=_0x31d320['name'],$(_0x31d320)&&_0x31d320['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x31d320['settings']['appCheckToken']),this['appCheck']=_0x4167d8==null?void 0x0:_0x4167d8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4167d8==null||_0x4167d8['get']()['then'](_0x22c75b=>this['appCheck']=_0x22c75b);}['getToken'](_0x1a51c7){if(this['serverAppAppCheckToken']){if(_0x1a51c7)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1a51c7):new Promise((_0x31404c,_0x4f3dcb)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1a51c7)['then'](_0x31404c,_0x4f3dcb):_0x31404c(null);},0x0);});}['addTokenChangeListener'](_0x347eba){var _0x1e6069;(_0x1e6069=this['appCheckProvider'])==null||_0x1e6069['get']()['then'](_0x1e96f7=>_0x1e96f7['addTokenListener'](_0x347eba));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x35a8a4,_0x519a41,_0x26a5be){this['appName_']=_0x35a8a4,this['firebaseOptions_']=_0x519a41,this['authProvider_']=_0x26a5be,this['auth_']=null,this['auth_']=_0x26a5be['getImmediate']({'optional':!0x0}),this['auth_']||_0x26a5be['onInit'](_0x419873=>this['auth_']=_0x419873);}['getToken'](_0x436f77){return this['auth_']?this['auth_']['getToken'](_0x436f77)['catch'](_0x53e6f5=>_0x53e6f5&&_0x53e6f5['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x53e6f5)):new Promise((_0x1aae99,_0xc85439)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x436f77)['then'](_0x1aae99,_0xc85439):_0x1aae99(null);},0x0);});}['addTokenChangeListener'](_0x52591c){this['auth_']?this['auth_']['addAuthTokenListener'](_0x52591c):this['authProvider_']['get']()['then'](_0x3c5f51=>_0x3c5f51['addAuthTokenListener'](_0x52591c));}['removeTokenChangeListener'](_0x479568){this['authProvider_']['get']()['then'](_0x38c9d4=>_0x38c9d4['removeAuthTokenListener'](_0x479568));}['notifyForInvalidToken'](){let _0x16a7c4='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x16a7c4+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x16a7c4+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x16a7c4+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x16a7c4);}}class on{constructor(_0x4b8010){this['accessToken']=_0x4b8010;}['getToken'](_0x521aeb){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xb29b97){_0xb29b97(this['accessToken']);}['removeTokenChangeListener'](_0x517969){}['notifyForInvalidToken'](){}}on['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',Ii='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5164a8,_0x3cb872,_0x30366d,_0x419874,_0x54ec00=!0x1,_0x1164ad='',_0x15e4a3=!0x1,_0x578344=!0x1,_0x38fcaf=null){this['secure']=_0x3cb872,this['namespace']=_0x30366d,this['webSocketOnly']=_0x419874,this['nodeAdmin']=_0x54ec00,this['persistenceKey']=_0x1164ad,this['includeNamespaceInQueryParams']=_0x15e4a3,this['isUsingEmulator']=_0x578344,this['emulatorOptions']=_0x38fcaf,this['_host']=_0x5164a8['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x5164a8)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x488856){_0x488856!==this['internalHost']&&(this['internalHost']=_0x488856,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1e848b=this['toURLString']();return this['persistenceKey']&&(_0x1e848b+='<'+this['persistenceKey']+'>'),_0x1e848b;}['toURLString'](){const _0x3e997c=this['secure']?'https://':'http://',_0x231488=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3e997c+this['host']+'/'+_0x231488;}}function Jl(_0x7ad51c){return _0x7ad51c['host']!==_0x7ad51c['internalHost']||_0x7ad51c['isCustomHost']()||_0x7ad51c['includeNamespaceInQueryParams'];}function vo(_0x151f6d,_0x28dd31,_0x1d3cd0){f(typeof _0x28dd31=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1d3cd0=='object','typeof\x20params\x20must\x20==\x20object');let _0x350b2c;if(_0x28dd31===go)_0x350b2c=(_0x151f6d['secure']?'wss://':'ws://')+_0x151f6d['internalHost']+'/.ws?';else{if(_0x28dd31===mo)_0x350b2c=(_0x151f6d['secure']?'https://':'http://')+_0x151f6d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x28dd31);}Jl(_0x151f6d)&&(_0x1d3cd0['ns']=_0x151f6d['namespace']);const _0x1c0341=[];return x(_0x1d3cd0,(_0x48a630,_0x450f6a)=>{_0x1c0341['push'](_0x48a630+'='+_0x450f6a);}),_0x350b2c+_0x1c0341['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xl{constructor(){this['counters_']={};}['incrementCounter'](_0x23ad68,_0x468d06=0x1){Q(this['counters_'],_0x23ad68)||(this['counters_'][_0x23ad68]=0x0),this['counters_'][_0x23ad68]+=_0x468d06;}['get'](){return ec(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ri={},oi={};function Gi(_0x1ee590){const _0x1365e7=_0x1ee590['toString']();return ri[_0x1365e7]||(ri[_0x1365e7]=new Xl()),ri[_0x1365e7];}function Zl(_0x1ac2f7,_0x5be9c0){const _0x407e47=_0x1ac2f7['toString']();return oi[_0x407e47]||(oi[_0x407e47]=_0x5be9c0()),oi[_0x407e47];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xe0e099){this['onMessage_']=_0xe0e099,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x58c8f8,_0x487f0a){this['closeAfterResponse']=_0x58c8f8,this['onClose']=_0x487f0a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3be3a5,_0x743679){for(this['pendingResponses'][_0x3be3a5]=_0x743679;this['pendingResponses'][this['currentResponseNum']];){const _0x2ce1ad=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x271d7e=0x0;_0x271d7e<_0x2ce1ad['length'];++_0x271d7e)_0x2ce1ad[_0x271d7e]&&dt(()=>{this['onMessage_'](_0x2ce1ad[_0x271d7e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',th='close',nh='pLPCommand',ih='pRTLPCB',Eo='id',Io='pw',wo='ser',sh='cb',rh='seg',oh='ts',ah='d',ch='dframe',Co=0x74e,To=0x1e,lh=Co-To,hh=0x61a8,uh=0x7530;class Qe{constructor(_0x877cc3,_0x11d5bb,_0x2f1d69,_0x24960c,_0x2efc5f,_0x23b581,_0x32b6ba){this['connId']=_0x877cc3,this['repoInfo']=_0x11d5bb,this['applicationId']=_0x2f1d69,this['appCheckToken']=_0x24960c,this['authToken']=_0x2efc5f,this['transportSessionId']=_0x23b581,this['lastSessionId']=_0x32b6ba,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x877cc3),this['stats_']=Gi(_0x11d5bb),this['urlFn']=_0x566712=>(this['appCheckToken']&&(_0x566712[Ii]=this['appCheckToken']),vo(_0x11d5bb,mo,_0x566712));}['open'](_0x3d21c1,_0x2c040f){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2c040f,this['myPacketOrderer']=new eh(_0x3d21c1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](uh)),Bl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x32d9b2)=>{const [_0x418f08,_0x2fe45d,_0x490ab6,_0x1cf4d2,_0x116257]=_0x32d9b2;if(this['incrementIncomingBytes_'](_0x32d9b2),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x418f08===qs)this['id']=_0x2fe45d,this['password']=_0x490ab6;else{if(_0x418f08===th)_0x2fe45d?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2fe45d,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x418f08);}}},(..._0x1768de)=>{const [_0x7b872c,_0x4af962]=_0x1768de;this['incrementIncomingBytes_'](_0x1768de),this['myPacketOrderer']['handleResponse'](_0x7b872c,_0x4af962);},()=>{this['onClosed_']();},this['urlFn']);const _0x2ecb93={};_0x2ecb93[qs]='t',_0x2ecb93[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2ecb93[sh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2ecb93[co]=$i,this['transportSessionId']&&(_0x2ecb93[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x2ecb93[po]=this['lastSessionId']),this['applicationId']&&(_0x2ecb93[_o]=this['applicationId']),this['appCheckToken']&&(_0x2ecb93[Ii]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2ecb93[ho]=uo);const _0x3b6729=this['urlFn'](_0x2ecb93);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3b6729),this['scriptTagHolder']['addTag'](_0x3b6729,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Qe['forceAllow_']=!0x0;}static['forceDisallow'](){Qe['forceDisallow_']=!0x0;}static['isAvailable'](){return Qe['forceAllow_']?!0x0:!Qe['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!Hl()&&!$l();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2e6506){const _0x507bc0=O(_0x2e6506);this['bytesSent']+=_0x507bc0['length'],this['stats_']['incrementCounter']('bytes_sent',_0x507bc0['length']);const _0x589810=$r(_0x507bc0),_0x6338f=oo(_0x589810,lh);for(let _0x66f02f=0x0;_0x66f02f<_0x6338f['length'];_0x66f02f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x6338f['length'],_0x6338f[_0x66f02f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3c5035,_0xd78214){this['myDisconnFrame']=document['createElement']('iframe');const _0x54a33a={};_0x54a33a[ch]='t',_0x54a33a[Eo]=_0x3c5035,_0x54a33a[Io]=_0xd78214,this['myDisconnFrame']['src']=this['urlFn'](_0x54a33a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x51f6e2){const _0x33754a=O(_0x51f6e2)['length'];this['bytesReceived']+=_0x33754a,this['stats_']['incrementCounter']('bytes_received',_0x33754a);}}class qi{constructor(_0x1656a8,_0x62816c,_0x308952,_0x105939){this['onDisconnect']=_0x308952,this['urlFn']=_0x105939,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[nh+this['uniqueCallbackIdentifier']]=_0x1656a8,window[ih+this['uniqueCallbackIdentifier']]=_0x62816c,this['myIFrame']=qi['createIFrame_']();let _0x4f515b='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4f515b='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x28453a='<html><body>'+_0x4f515b+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x28453a),this['myIFrame']['doc']['close']();}catch(_0x4752aa){L('frame\x20writing\x20exception'),_0x4752aa['stack']&&L(_0x4752aa['stack']),L(_0x4752aa);}}}static['createIFrame_'](){const _0x7dd9ca=document['createElement']('iframe');if(_0x7dd9ca['style']['display']='none',document['body']){document['body']['appendChild'](_0x7dd9ca);try{_0x7dd9ca['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x44221c=document['domain'];_0x7dd9ca['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x44221c+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x7dd9ca['contentDocument']?_0x7dd9ca['doc']=_0x7dd9ca['contentDocument']:_0x7dd9ca['contentWindow']?_0x7dd9ca['doc']=_0x7dd9ca['contentWindow']['document']:_0x7dd9ca['document']&&(_0x7dd9ca['doc']=_0x7dd9ca['document']),_0x7dd9ca;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x13f259=this['onDisconnect'];_0x13f259&&(this['onDisconnect']=null,_0x13f259());}['startLongPoll'](_0xc185ee,_0xad88cf){for(this['myID']=_0xc185ee,this['myPW']=_0xad88cf,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2a93ee={};_0x2a93ee[Eo]=this['myID'],_0x2a93ee[Io]=this['myPW'],_0x2a93ee[wo]=this['currentSerial'];let _0x4a2e65=this['urlFn'](_0x2a93ee),_0x334e89='',_0x3081d3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x334e89['length']<=Co;){const _0x427cff=this['pendingSegs']['shift']();_0x334e89=_0x334e89+'&'+rh+_0x3081d3+'='+_0x427cff['seg']+'&'+oh+_0x3081d3+'='+_0x427cff['ts']+'&'+ah+_0x3081d3+'='+_0x427cff['d'],_0x3081d3++;}return _0x4a2e65=_0x4a2e65+_0x334e89,this['addLongPollTag_'](_0x4a2e65,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x6e3984,_0xf9dc5b,_0x818b39){this['pendingSegs']['push']({'seg':_0x6e3984,'ts':_0xf9dc5b,'d':_0x818b39}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5ad21b,_0x1fa713){this['outstandingRequests']['add'](_0x1fa713);const _0x28784e=()=>{this['outstandingRequests']['delete'](_0x1fa713),this['newRequest_']();},_0x1135ad=setTimeout(_0x28784e,Math['floor'](hh)),_0x16e777=()=>{clearTimeout(_0x1135ad),_0x28784e();};this['addTag'](_0x5ad21b,_0x16e777);}['addTag'](_0xeb289f,_0x32b26b){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x839f3f=this['myIFrame']['doc']['createElement']('script');_0x839f3f['type']='text/javascript',_0x839f3f['async']=!0x0,_0x839f3f['src']=_0xeb289f,_0x839f3f['onload']=_0x839f3f['onreadystatechange']=function(){const _0x362135=_0x839f3f['readyState'];(!_0x362135||_0x362135==='loaded'||_0x362135==='complete')&&(_0x839f3f['onload']=_0x839f3f['onreadystatechange']=null,_0x839f3f['parentNode']&&_0x839f3f['parentNode']['removeChild'](_0x839f3f),_0x32b26b());},_0x839f3f['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xeb289f),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x839f3f);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dh=0x4000,fh=0xafc8;let _n=null;typeof MozWebSocket<'u'?_n=MozWebSocket:typeof WebSocket<'u'&&(_n=WebSocket);class q{constructor(_0x57927a,_0x5015d9,_0x1aae6c,_0x19fc4d,_0x1a0285,_0x4b9633,_0x35f165){this['connId']=_0x57927a,this['applicationId']=_0x1aae6c,this['appCheckToken']=_0x19fc4d,this['authToken']=_0x1a0285,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=Gi(_0x5015d9),this['connURL']=q['connectionURL_'](_0x5015d9,_0x4b9633,_0x35f165,_0x19fc4d,_0x1aae6c),this['nodeAdmin']=_0x5015d9['nodeAdmin'];}static['connectionURL_'](_0x47e8ae,_0x3b571f,_0x24d00d,_0xb951b4,_0x5277c5){const _0x3232a8={};return _0x3232a8[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3232a8[ho]=uo),_0x3b571f&&(_0x3232a8[lo]=_0x3b571f),_0x24d00d&&(_0x3232a8[po]=_0x24d00d),_0xb951b4&&(_0x3232a8[Ii]=_0xb951b4),_0x5277c5&&(_0x3232a8[_o]=_0x5277c5),vo(_0x47e8ae,go,_0x3232a8);}['open'](_0x10d75a,_0x52bc77){this['onDisconnect']=_0x52bc77,this['onMessage']=_0x10d75a,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x2e89b5;uc(),this['mySock']=new _n(this['connURL'],[],_0x2e89b5);}catch(_0x4881a1){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x38904b=_0x4881a1['message']||_0x4881a1['data'];_0x38904b&&this['log_'](_0x38904b),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x129807=>{this['handleIncomingFrame'](_0x129807);},this['mySock']['onerror']=_0x5dcec3=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x180713=_0x5dcec3['message']||_0x5dcec3['data'];_0x180713&&this['log_'](_0x180713),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3aca13=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4d0810=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x20ece1=navigator['userAgent']['match'](_0x4d0810);_0x20ece1&&_0x20ece1['length']>0x1&&parseFloat(_0x20ece1[0x1])<4.4&&(_0x3aca13=!0x0);}return!_0x3aca13&&_n!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2089a6){if(this['frames']['push'](_0x2089a6),this['frames']['length']===this['totalFrames']){const _0x20e86c=this['frames']['join']('');this['frames']=null;const _0x3596a9=Nt(_0x20e86c);this['onMessage'](_0x3596a9);}}['handleNewFrameCount_'](_0x342628){this['totalFrames']=_0x342628,this['frames']=[];}['extractFrameCount_'](_0x2d7246){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2d7246['length']<=0x6){const _0x34c70a=Number(_0x2d7246);if(!isNaN(_0x34c70a))return this['handleNewFrameCount_'](_0x34c70a),null;}return this['handleNewFrameCount_'](0x1),_0x2d7246;}['handleIncomingFrame'](_0x4e76df){if(this['mySock']===null)return;const _0x2d65d5=_0x4e76df['data'];if(this['bytesReceived']+=_0x2d65d5['length'],this['stats_']['incrementCounter']('bytes_received',_0x2d65d5['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2d65d5);else{const _0x54c25d=this['extractFrameCount_'](_0x2d65d5);_0x54c25d!==null&&this['appendFrame_'](_0x54c25d);}}['send'](_0x1e3b56){this['resetKeepAlive']();const _0x4c7b85=O(_0x1e3b56);this['bytesSent']+=_0x4c7b85['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4c7b85['length']);const _0x4445f3=oo(_0x4c7b85,dh);_0x4445f3['length']>0x1&&this['sendString_'](String(_0x4445f3['length']));for(let _0x403e54=0x0;_0x403e54<_0x4445f3['length'];_0x403e54++)this['sendString_'](_0x4445f3[_0x403e54]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](fh));}['sendString_'](_0x4864f6){try{this['mySock']['send'](_0x4864f6);}catch(_0x28e480){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x28e480['message']||_0x28e480['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Qe,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x47470b){this['initTransports_'](_0x47470b);}['initTransports_'](_0xaafbf8){const _0x287036=q&&q['isAvailable']();let _0x5b7597=_0x287036&&!q['previouslyFailed']();if(_0xaafbf8['webSocketOnly']&&(_0x287036||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5b7597=!0x0),_0x5b7597)this['transports_']=[q];else{const _0x386c26=this['transports_']=[];for(const _0xcca3e5 of Ot['ALL_TRANSPORTS'])_0xcca3e5&&_0xcca3e5['isAvailable']()&&_0x386c26['push'](_0xcca3e5);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ph=0xea60,_h=0x1388,gh=0xa*0x400,mh=0x64*0x400,ai='t',zs='d',yh='s',js='r',vh='e',Ks='o',Ys='a',Qs='n',Js='p',Eh='h';class Ih{constructor(_0x20a348,_0x41ed14,_0xee333d,_0x364b91,_0x1442cb,_0x145434,_0x279cb4,_0xa8a37d,_0x589d15,_0x1c9cdb){this['id']=_0x20a348,this['repoInfo_']=_0x41ed14,this['applicationId_']=_0xee333d,this['appCheckToken_']=_0x364b91,this['authToken_']=_0x1442cb,this['onMessage_']=_0x145434,this['onReady_']=_0x279cb4,this['onDisconnect_']=_0xa8a37d,this['onKill_']=_0x589d15,this['lastSessionId']=_0x1c9cdb,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x41ed14),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x503274=this['transportManager_']['initialTransport']();this['conn_']=new _0x503274(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x503274['responsesRequiredToBeHealthy']||0x0;const _0xd925df=this['connReceiver_'](this['conn_']),_0x154964=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xd925df,_0x154964);},Math['floor'](0x0));const _0x316482=_0x503274['healthyTimeout']||0x0;_0x316482>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>mh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>gh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x316482)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4a0eae){return _0x3f0fd1=>{_0x4a0eae===this['conn_']?this['onConnectionLost_'](_0x3f0fd1):_0x4a0eae===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x412b26){return _0x4d90e5=>{this['state_']!==0x2&&(_0x412b26===this['rx_']?this['onPrimaryMessageReceived_'](_0x4d90e5):_0x412b26===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4d90e5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x38ed07){const _0x28c872={'t':'d','d':_0x38ed07};this['sendData_'](_0x28c872);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x349916){if(ai in _0x349916){const _0x1e687b=_0x349916[ai];_0x1e687b===Ys?this['upgradeIfSecondaryHealthy_']():_0x1e687b===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1e687b===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x14affc){const _0x591f30=yt('t',_0x14affc),_0x175166=yt('d',_0x14affc);if(_0x591f30==='c')this['onSecondaryControl_'](_0x175166);else{if(_0x591f30==='d')this['pendingDataMessages']['push'](_0x175166);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x591f30);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x12cc4b){const _0x58bc36=yt('t',_0x12cc4b),_0x3ad013=yt('d',_0x12cc4b);_0x58bc36==='c'?this['onControl_'](_0x3ad013):_0x58bc36==='d'&&this['onDataMessage_'](_0x3ad013);}['onDataMessage_'](_0x396aea){this['onPrimaryResponse_'](),this['onMessage_'](_0x396aea);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4c4c64){const _0x38ccc1=yt(ai,_0x4c4c64);if(zs in _0x4c4c64){const _0xe6e6fb=_0x4c4c64[zs];if(_0x38ccc1===Eh){const _0xc40166={..._0xe6e6fb};this['repoInfo_']['isUsingEmulator']&&(_0xc40166['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xc40166);}else{if(_0x38ccc1===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x598152=0x0;_0x598152<this['pendingDataMessages']['length'];++_0x598152)this['onDataMessage_'](this['pendingDataMessages'][_0x598152]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x38ccc1===yh?this['onConnectionShutdown_'](_0xe6e6fb):_0x38ccc1===js?this['onReset_'](_0xe6e6fb):_0x38ccc1===vh?Ei('Server\x20Error:\x20'+_0xe6e6fb):_0x38ccc1===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ei('Unknown\x20control\x20packet\x20command:\x20'+_0x38ccc1);}}}['onHandshake_'](_0x5c5903){const _0x5ef3cd=_0x5c5903['ts'],_0x253596=_0x5c5903['v'],_0x2fbd0d=_0x5c5903['h'];this['sessionId']=_0x5c5903['s'],this['repoInfo_']['host']=_0x2fbd0d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5ef3cd),$i!==_0x253596&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x18fb71=this['transportManager_']['upgradeTransport']();_0x18fb71&&this['startUpgrade_'](_0x18fb71);}['startUpgrade_'](_0x4e80cb){this['secondaryConn_']=new _0x4e80cb(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4e80cb['responsesRequiredToBeHealthy']||0x0;const _0x12e80a=this['connReceiver_'](this['secondaryConn_']),_0x553939=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x12e80a,_0x553939),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](ph));}['onReset_'](_0x54b9d8){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x54b9d8),this['repoInfo_']['host']=_0x54b9d8,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x43fb94,_0x2e25dd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x43fb94,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2e25dd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](_h));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x325733=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x325733||this['rx_']===_0x325733)&&this['close']();}['onConnectionLost_'](_0x115715){this['conn_']=null,!_0x115715&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x51c6ec){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x51c6ec),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4199de){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4199de);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1570c8,_0x58a375,_0x454a7e,_0x17508d){}['merge'](_0x2b813d,_0x193bd6,_0x35d16f,_0x55ab54){}['refreshAuthToken'](_0x6860fb){}['refreshAppCheckToken'](_0x21726a){}['onDisconnectPut'](_0x4b1049,_0x22cbde,_0x46023c){}['onDisconnectMerge'](_0x3a4e00,_0x1157f9,_0x52cf79){}['onDisconnectCancel'](_0xc55249,_0x45ad1f){}['reportStats'](_0x3ded82){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2b7ef2){this['allowedEvents_']=_0x2b7ef2,this['listeners_']={},f(Array['isArray'](_0x2b7ef2)&&_0x2b7ef2['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3aec79,..._0x499ac1){if(Array['isArray'](this['listeners_'][_0x3aec79])){const _0xa5441b=[...this['listeners_'][_0x3aec79]];for(let _0x1ace41=0x0;_0x1ace41<_0xa5441b['length'];_0x1ace41++)_0xa5441b[_0x1ace41]['callback']['apply'](_0xa5441b[_0x1ace41]['context'],_0x499ac1);}}['on'](_0x136d11,_0x477778,_0x490b29){this['validateEventType_'](_0x136d11),this['listeners_'][_0x136d11]=this['listeners_'][_0x136d11]||[],this['listeners_'][_0x136d11]['push']({'callback':_0x477778,'context':_0x490b29});const _0x27d03b=this['getInitialEvent'](_0x136d11);_0x27d03b&&_0x477778['apply'](_0x490b29,_0x27d03b);}['off'](_0x2f284b,_0x49fb7a,_0xe21286){this['validateEventType_'](_0x2f284b);const _0x43f4e2=this['listeners_'][_0x2f284b]||[];for(let _0x3a4d26=0x0;_0x3a4d26<_0x43f4e2['length'];_0x3a4d26++)if(_0x43f4e2[_0x3a4d26]['callback']===_0x49fb7a&&(!_0xe21286||_0xe21286===_0x43f4e2[_0x3a4d26]['context'])){_0x43f4e2['splice'](_0x3a4d26,0x1);return;}}['validateEventType_'](_0x2c391e){f(this['allowedEvents_']['find'](_0x9deeeb=>_0x9deeeb===_0x2c391e),'Unknown\x20event:\x20'+_0x2c391e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn extends bo{static['getInstance'](){return new gn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Ui()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5c723d){return f(_0x5c723d==='online','Unknown\x20event\x20type:\x20'+_0x5c723d),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2fe16a,_0x4ed656){if(_0x4ed656===void 0x0){this['pieces_']=_0x2fe16a['split']('/');let _0x5583fb=0x0;for(let _0x67950e=0x0;_0x67950e<this['pieces_']['length'];_0x67950e++)this['pieces_'][_0x67950e]['length']>0x0&&(this['pieces_'][_0x5583fb]=this['pieces_'][_0x67950e],_0x5583fb++);this['pieces_']['length']=_0x5583fb,this['pieceNum_']=0x0;}else this['pieces_']=_0x2fe16a,this['pieceNum_']=_0x4ed656;}['toString'](){let _0x5a0bea='';for(let _0x362223=this['pieceNum_'];_0x362223<this['pieces_']['length'];_0x362223++)this['pieces_'][_0x362223]!==''&&(_0x5a0bea+='/'+this['pieces_'][_0x362223]);return _0x5a0bea||'/';}}function w(){return new C('');}function y(_0x58a10b){return _0x58a10b['pieceNum_']>=_0x58a10b['pieces_']['length']?null:_0x58a10b['pieces_'][_0x58a10b['pieceNum_']];}function we(_0xb88fef){return _0xb88fef['pieces_']['length']-_0xb88fef['pieceNum_'];}function S(_0x4c79db){let _0x3a0f94=_0x4c79db['pieceNum_'];return _0x3a0f94<_0x4c79db['pieces_']['length']&&_0x3a0f94++,new C(_0x4c79db['pieces_'],_0x3a0f94);}function zi(_0x4003ba){return _0x4003ba['pieceNum_']<_0x4003ba['pieces_']['length']?_0x4003ba['pieces_'][_0x4003ba['pieces_']['length']-0x1]:null;}function wh(_0x2df217){let _0x12d205='';for(let _0x424b11=_0x2df217['pieceNum_'];_0x424b11<_0x2df217['pieces_']['length'];_0x424b11++)_0x2df217['pieces_'][_0x424b11]!==''&&(_0x12d205+='/'+encodeURIComponent(String(_0x2df217['pieces_'][_0x424b11])));return _0x12d205||'/';}function Dt(_0x2f6443,_0x4a095e=0x0){return _0x2f6443['pieces_']['slice'](_0x2f6443['pieceNum_']+_0x4a095e);}function Ro(_0x249f74){if(_0x249f74['pieceNum_']>=_0x249f74['pieces_']['length'])return null;const _0x34a30b=[];for(let _0x1134f1=_0x249f74['pieceNum_'];_0x1134f1<_0x249f74['pieces_']['length']-0x1;_0x1134f1++)_0x34a30b['push'](_0x249f74['pieces_'][_0x1134f1]);return new C(_0x34a30b,0x0);}function k(_0x4bfe49,_0x580a97){const _0x883b46=[];for(let _0x1ab481=_0x4bfe49['pieceNum_'];_0x1ab481<_0x4bfe49['pieces_']['length'];_0x1ab481++)_0x883b46['push'](_0x4bfe49['pieces_'][_0x1ab481]);if(_0x580a97 instanceof C){for(let _0x887152=_0x580a97['pieceNum_'];_0x887152<_0x580a97['pieces_']['length'];_0x887152++)_0x883b46['push'](_0x580a97['pieces_'][_0x887152]);}else{const _0x85cf30=_0x580a97['split']('/');for(let _0x577248=0x0;_0x577248<_0x85cf30['length'];_0x577248++)_0x85cf30[_0x577248]['length']>0x0&&_0x883b46['push'](_0x85cf30[_0x577248]);}return new C(_0x883b46,0x0);}function v(_0x325ec3){return _0x325ec3['pieceNum_']>=_0x325ec3['pieces_']['length'];}function F(_0x3c269a,_0x15eeb6){const _0x128754=y(_0x3c269a),_0x5ef332=y(_0x15eeb6);if(_0x128754===null)return _0x15eeb6;if(_0x128754===_0x5ef332)return F(S(_0x3c269a),S(_0x15eeb6));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x15eeb6+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3c269a+')');}function Ch(_0x14a6c2,_0x6174df){const _0x42f7a5=Dt(_0x14a6c2,0x0),_0x1bfae4=Dt(_0x6174df,0x0);for(let _0x50cc4a=0x0;_0x50cc4a<_0x42f7a5['length']&&_0x50cc4a<_0x1bfae4['length'];_0x50cc4a++){const _0x17c8f6=Ge(_0x42f7a5[_0x50cc4a],_0x1bfae4[_0x50cc4a]);if(_0x17c8f6!==0x0)return _0x17c8f6;}return _0x42f7a5['length']===_0x1bfae4['length']?0x0:_0x42f7a5['length']<_0x1bfae4['length']?-0x1:0x1;}function ji(_0x5d4758,_0x5bbaba){if(we(_0x5d4758)!==we(_0x5bbaba))return!0x1;for(let _0x5d27d6=_0x5d4758['pieceNum_'],_0x50d796=_0x5bbaba['pieceNum_'];_0x5d27d6<=_0x5d4758['pieces_']['length'];_0x5d27d6++,_0x50d796++)if(_0x5d4758['pieces_'][_0x5d27d6]!==_0x5bbaba['pieces_'][_0x50d796])return!0x1;return!0x0;}function G(_0x30e96a,_0x4232c6){let _0x4fed4d=_0x30e96a['pieceNum_'],_0x51b387=_0x4232c6['pieceNum_'];if(we(_0x30e96a)>we(_0x4232c6))return!0x1;for(;_0x4fed4d<_0x30e96a['pieces_']['length'];){if(_0x30e96a['pieces_'][_0x4fed4d]!==_0x4232c6['pieces_'][_0x51b387])return!0x1;++_0x4fed4d,++_0x51b387;}return!0x0;}class Th{constructor(_0x4e6f1f,_0x31a64a){this['errorPrefix_']=_0x31a64a,this['parts_']=Dt(_0x4e6f1f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x16d46f=0x0;_0x16d46f<this['parts_']['length'];_0x16d46f++)this['byteLength_']+=Mn(this['parts_'][_0x16d46f]);Ao(this);}}function Sh(_0x4577b2,_0x29a018){_0x4577b2['parts_']['length']>0x0&&(_0x4577b2['byteLength_']+=0x1),_0x4577b2['parts_']['push'](_0x29a018),_0x4577b2['byteLength_']+=Mn(_0x29a018),Ao(_0x4577b2);}function bh(_0x8b6945){const _0x308e92=_0x8b6945['parts_']['pop']();_0x8b6945['byteLength_']-=Mn(_0x308e92),_0x8b6945['parts_']['length']>0x0&&(_0x8b6945['byteLength_']-=0x1);}function Ao(_0x2251e7){if(_0x2251e7['byteLength_']>Zs)throw new Error(_0x2251e7['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x2251e7['byteLength_']+').');if(_0x2251e7['parts_']['length']>Xs)throw new Error(_0x2251e7['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x2251e7));}function Ne(_0x147abe){return _0x147abe['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x147abe['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x46ae88,_0x4278b3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4278b3='visibilitychange',_0x46ae88='hidden'):typeof document['mozHidden']<'u'?(_0x4278b3='mozvisibilitychange',_0x46ae88='mozHidden'):typeof document['msHidden']<'u'?(_0x4278b3='msvisibilitychange',_0x46ae88='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4278b3='webkitvisibilitychange',_0x46ae88='webkitHidden')),this['visible_']=!0x0,_0x4278b3&&document['addEventListener'](_0x4278b3,()=>{const _0x4d1a57=!document[_0x46ae88];_0x4d1a57!==this['visible_']&&(this['visible_']=_0x4d1a57,this['trigger']('visible',_0x4d1a57));},!0x1);}['getInitialEvent'](_0x1b3dcb){return f(_0x1b3dcb==='visible','Unknown\x20event\x20type:\x20'+_0x1b3dcb),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Rh=0x12c*0x3e8,er=0x1e*0x3e8,Ah=1.3,kh=0x7530,Nh='server_kill',tr=0x3;class se extends So{constructor(_0x3b5a20,_0x784afb,_0x1f7b59,_0x297ac8,_0x1ba476,_0x2de413,_0x53058b,_0x38ad50){if(super(),this['repoInfo_']=_0x3b5a20,this['applicationId_']=_0x784afb,this['onDataUpdate_']=_0x1f7b59,this['onConnectStatus_']=_0x297ac8,this['onServerInfoUpdate_']=_0x1ba476,this['authTokenProvider_']=_0x2de413,this['appCheckTokenProvider_']=_0x53058b,this['authOverride_']=_0x38ad50,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Rh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x38ad50)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x3b5a20['host']['indexOf']('fblocal')===-0x1&&gn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x19c312,_0x5d60a2,_0x46be65){const _0x1354c4=++this['requestNumber_'],_0x5207ec={'r':_0x1354c4,'a':_0x19c312,'b':_0x5d60a2};this['log_'](O(_0x5207ec)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5207ec),_0x46be65&&(this['requestCBHash_'][_0x1354c4]=_0x46be65);}['get'](_0x4b3f09){this['initConnection_']();const _0x321683=new H(),_0x4af185={'action':'g','request':{'p':_0x4b3f09['_path']['toString'](),'q':_0x4b3f09['_queryObject']},'onComplete':_0x538c96=>{const _0x104952=_0x538c96['d'];_0x538c96['s']==='ok'?_0x321683['resolve'](_0x104952):_0x321683['reject'](_0x104952);}};this['outstandingGets_']['push'](_0x4af185),this['outstandingGetCount_']++;const _0x25d2b8=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x25d2b8),_0x321683['promise'];}['listen'](_0xfcd942,_0x47721f,_0x212198,_0x51072e){this['initConnection_']();const _0x3185eb=_0xfcd942['_queryIdentifier'],_0x4021eb=_0xfcd942['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4021eb+'\x20'+_0x3185eb),this['listens']['has'](_0x4021eb)||this['listens']['set'](_0x4021eb,new Map()),f(_0xfcd942['_queryParams']['isDefault']()||!_0xfcd942['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4021eb)['has'](_0x3185eb),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2eeabc={'onComplete':_0x51072e,'hashFn':_0x47721f,'query':_0xfcd942,'tag':_0x212198};this['listens']['get'](_0x4021eb)['set'](_0x3185eb,_0x2eeabc),this['connected_']&&this['sendListen_'](_0x2eeabc);}['sendGet_'](_0x18c150){const _0x1746fd=this['outstandingGets_'][_0x18c150];this['sendRequest']('g',_0x1746fd['request'],_0x4724f4=>{delete this['outstandingGets_'][_0x18c150],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1746fd['onComplete']&&_0x1746fd['onComplete'](_0x4724f4);});}['sendListen_'](_0x5430a3){const _0x1c05a8=_0x5430a3['query'],_0x286f38=_0x1c05a8['_path']['toString'](),_0x1d2dd8=_0x1c05a8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x286f38+'\x20for\x20'+_0x1d2dd8);const _0x54f1e5={'p':_0x286f38},_0x1982b7='q';_0x5430a3['tag']&&(_0x54f1e5['q']=_0x1c05a8['_queryObject'],_0x54f1e5['t']=_0x5430a3['tag']),_0x54f1e5['h']=_0x5430a3['hashFn'](),this['sendRequest'](_0x1982b7,_0x54f1e5,_0x2dbabb=>{const _0x26f1a2=_0x2dbabb['d'],_0xc3cb93=_0x2dbabb['s'];se['warnOnListenWarnings_'](_0x26f1a2,_0x1c05a8),(this['listens']['get'](_0x286f38)&&this['listens']['get'](_0x286f38)['get'](_0x1d2dd8))===_0x5430a3&&(this['log_']('listen\x20response',_0x2dbabb),_0xc3cb93!=='ok'&&this['removeListen_'](_0x286f38,_0x1d2dd8),_0x5430a3['onComplete']&&_0x5430a3['onComplete'](_0xc3cb93,_0x26f1a2));});}static['warnOnListenWarnings_'](_0x214ce2,_0x5359f7){if(_0x214ce2&&typeof _0x214ce2=='object'&&Q(_0x214ce2,'w')){const _0x281aae=Me(_0x214ce2,'w');if(Array['isArray'](_0x281aae)&&~_0x281aae['indexOf']('no_index')){const _0x3c378e='\x22.indexOn\x22:\x20\x22'+_0x5359f7['_queryParams']['getIndex']()['toString']()+'\x22',_0x3a9c0b=_0x5359f7['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3c378e+'\x20at\x20'+_0x3a9c0b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2e8a8f){this['authToken_']=_0x2e8a8f,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2e8a8f);}['reduceReconnectDelayIfAdminCredential_'](_0x196c2e){(_0x196c2e&&_0x196c2e['length']===0x28||yc(_0x196c2e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x389ebd){this['appCheckToken_']=_0x389ebd,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xe4890e=this['authToken_'],_0x538833=mc(_0xe4890e)?'auth':'gauth',_0x4d9682={'cred':_0xe4890e};this['authOverride_']===null?_0x4d9682['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4d9682['authvar']=this['authOverride_']),this['sendRequest'](_0x538833,_0x4d9682,_0x2e4a75=>{const _0x29d497=_0x2e4a75['s'],_0x160090=_0x2e4a75['d']||'error';this['authToken_']===_0xe4890e&&(_0x29d497==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x29d497,_0x160090));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x188a30=>{const _0x2e97cf=_0x188a30['s'],_0x27e698=_0x188a30['d']||'error';_0x2e97cf==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2e97cf,_0x27e698);});}['unlisten'](_0x59e310,_0x39c5a3){const _0x31be49=_0x59e310['_path']['toString'](),_0x549414=_0x59e310['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x31be49+'\x20'+_0x549414),f(_0x59e310['_queryParams']['isDefault']()||!_0x59e310['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x31be49,_0x549414)&&this['connected_']&&this['sendUnlisten_'](_0x31be49,_0x549414,_0x59e310['_queryObject'],_0x39c5a3);}['sendUnlisten_'](_0x1c68a5,_0xe2ed14,_0x3d8e76,_0x2e240a){this['log_']('Unlisten\x20on\x20'+_0x1c68a5+'\x20for\x20'+_0xe2ed14);const _0x3a9662={'p':_0x1c68a5},_0x7043d1='n';_0x2e240a&&(_0x3a9662['q']=_0x3d8e76,_0x3a9662['t']=_0x2e240a),this['sendRequest'](_0x7043d1,_0x3a9662);}['onDisconnectPut'](_0x1cf067,_0x3487b9,_0x364a74){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1cf067,_0x3487b9,_0x364a74):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1cf067,'action':'o','data':_0x3487b9,'onComplete':_0x364a74});}['onDisconnectMerge'](_0x34ad58,_0x76f174,_0x4aee31){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x34ad58,_0x76f174,_0x4aee31):this['onDisconnectRequestQueue_']['push']({'pathString':_0x34ad58,'action':'om','data':_0x76f174,'onComplete':_0x4aee31});}['onDisconnectCancel'](_0x239531,_0xa34c0b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x239531,null,_0xa34c0b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x239531,'action':'oc','data':null,'onComplete':_0xa34c0b});}['sendOnDisconnect_'](_0x396b69,_0x2da174,_0x5d43fe,_0x575ef3){const _0x9370d4={'p':_0x2da174,'d':_0x5d43fe};this['log_']('onDisconnect\x20'+_0x396b69,_0x9370d4),this['sendRequest'](_0x396b69,_0x9370d4,_0x49e166=>{_0x575ef3&&setTimeout(()=>{_0x575ef3(_0x49e166['s'],_0x49e166['d']);},Math['floor'](0x0));});}['put'](_0x44b571,_0x1cd57d,_0x507235,_0x215ade){this['putInternal']('p',_0x44b571,_0x1cd57d,_0x507235,_0x215ade);}['merge'](_0x5d1426,_0x38b059,_0x1a4df5,_0x325b80){this['putInternal']('m',_0x5d1426,_0x38b059,_0x1a4df5,_0x325b80);}['putInternal'](_0x393555,_0xb5b1c8,_0x527a76,_0x1359a7,_0x43903e){this['initConnection_']();const _0x3bcbf3={'p':_0xb5b1c8,'d':_0x527a76};_0x43903e!==void 0x0&&(_0x3bcbf3['h']=_0x43903e),this['outstandingPuts_']['push']({'action':_0x393555,'request':_0x3bcbf3,'onComplete':_0x1359a7}),this['outstandingPutCount_']++;const _0x11fb25=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x11fb25):this['log_']('Buffering\x20put:\x20'+_0xb5b1c8);}['sendPut_'](_0x3de433){const _0x55c481=this['outstandingPuts_'][_0x3de433]['action'],_0x9a2408=this['outstandingPuts_'][_0x3de433]['request'],_0x27554c=this['outstandingPuts_'][_0x3de433]['onComplete'];this['outstandingPuts_'][_0x3de433]['queued']=this['connected_'],this['sendRequest'](_0x55c481,_0x9a2408,_0x1408b2=>{this['log_'](_0x55c481+'\x20response',_0x1408b2),delete this['outstandingPuts_'][_0x3de433],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x27554c&&_0x27554c(_0x1408b2['s'],_0x1408b2['d']);});}['reportStats'](_0x3198b0){if(this['connected_']){const _0x5df7d8={'c':_0x3198b0};this['log_']('reportStats',_0x5df7d8),this['sendRequest']('s',_0x5df7d8,_0x40ed36=>{if(_0x40ed36['s']!=='ok'){const _0x24bde2=_0x40ed36['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x24bde2);}});}}['onDataMessage_'](_0x533d0a){if('r'in _0x533d0a){this['log_']('from\x20server:\x20'+O(_0x533d0a));const _0x111e1e=_0x533d0a['r'],_0x1b68d3=this['requestCBHash_'][_0x111e1e];_0x1b68d3&&(delete this['requestCBHash_'][_0x111e1e],_0x1b68d3(_0x533d0a['b']));}else{if('error'in _0x533d0a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x533d0a['error'];'a'in _0x533d0a&&this['onDataPush_'](_0x533d0a['a'],_0x533d0a['b']);}}['onDataPush_'](_0x201878,_0x479111){this['log_']('handleServerMessage',_0x201878,_0x479111),_0x201878==='d'?this['onDataUpdate_'](_0x479111['p'],_0x479111['d'],!0x1,_0x479111['t']):_0x201878==='m'?this['onDataUpdate_'](_0x479111['p'],_0x479111['d'],!0x0,_0x479111['t']):_0x201878==='c'?this['onListenRevoked_'](_0x479111['p'],_0x479111['q']):_0x201878==='ac'?this['onAuthRevoked_'](_0x479111['s'],_0x479111['d']):_0x201878==='apc'?this['onAppCheckRevoked_'](_0x479111['s'],_0x479111['d']):_0x201878==='sd'?this['onSecurityDebugPacket_'](_0x479111):Ei('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x201878)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x59bb9c,_0xd22d9d){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x59bb9c),this['lastSessionId']=_0xd22d9d,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1bca2f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1bca2f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x32b5e3){_0x32b5e3&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x32b5e3;}['onOnline_'](_0x5039f6){_0x5039f6?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>kh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x218333=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3b6c4f=Math['max'](0x0,this['reconnectDelay_']-_0x218333);_0x3b6c4f=Math['random']()*_0x3b6c4f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3b6c4f+'ms'),this['scheduleConnect_'](_0x3b6c4f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Ah);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x46e13c=this['onDataMessage_']['bind'](this),_0x5dd921=this['onReady_']['bind'](this),_0xac33fa=this['onRealtimeDisconnect_']['bind'](this),_0x451e3c=this['id']+':'+se['nextConnectionId_']++,_0x385af9=this['lastSessionId'];let _0x2aa04b=!0x1,_0x23d83a=null;const _0x1990f3=function(){_0x23d83a?_0x23d83a['close']():(_0x2aa04b=!0x0,_0xac33fa());},_0x11fa99=function(_0x2bc105){f(_0x23d83a,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x23d83a['sendRequest'](_0x2bc105);};this['realtime_']={'close':_0x1990f3,'sendRequest':_0x11fa99};const _0x3e5624=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3167ea,_0xd64ced]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3e5624),this['appCheckTokenProvider_']['getToken'](_0x3e5624)]);_0x2aa04b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3167ea&&_0x3167ea['accessToken'],this['appCheckToken_']=_0xd64ced&&_0xd64ced['token'],_0x23d83a=new Ih(_0x451e3c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x46e13c,_0x5dd921,_0xac33fa,_0x33c4eb=>{U(_0x33c4eb+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Nh);},_0x385af9));}catch(_0x45c23e){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x45c23e),_0x2aa04b||(this['repoInfo_']['nodeAdmin']&&U(_0x45c23e),_0x1990f3());}}}['interrupt'](_0x14b9a6){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x14b9a6),this['interruptReasons_'][_0x14b9a6]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x339109){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x339109),delete this['interruptReasons_'][_0x339109],fn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x11ef1e){const _0x23f4b0=_0x11ef1e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x23f4b0});}['cancelSentTransactions_'](){for(let _0xe489ae=0x0;_0xe489ae<this['outstandingPuts_']['length'];_0xe489ae++){const _0x594ce1=this['outstandingPuts_'][_0xe489ae];_0x594ce1&&'h'in _0x594ce1['request']&&_0x594ce1['queued']&&(_0x594ce1['onComplete']&&_0x594ce1['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xe489ae],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x151954,_0x3f271e){let _0x282237;_0x3f271e?_0x282237=_0x3f271e['map'](_0x2a4cfd=>Hi(_0x2a4cfd))['join']('$'):_0x282237='default';const _0x57baaa=this['removeListen_'](_0x151954,_0x282237);_0x57baaa&&_0x57baaa['onComplete']&&_0x57baaa['onComplete']('permission_denied');}['removeListen_'](_0x2b3c4f,_0xc34920){const _0x5ca63e=new C(_0x2b3c4f)['toString']();let _0x39d65b;if(this['listens']['has'](_0x5ca63e)){const _0x1d4d31=this['listens']['get'](_0x5ca63e);_0x39d65b=_0x1d4d31['get'](_0xc34920),_0x1d4d31['delete'](_0xc34920),_0x1d4d31['size']===0x0&&this['listens']['delete'](_0x5ca63e);}else _0x39d65b=void 0x0;return _0x39d65b;}['onAuthRevoked_'](_0x318630,_0x11bab6){L('Auth\x20token\x20revoked:\x20'+_0x318630+'/'+_0x11bab6),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x318630==='invalid_token'||_0x318630==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x388d2c,_0x2f68d8){L('App\x20check\x20token\x20revoked:\x20'+_0x388d2c+'/'+_0x2f68d8),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x388d2c==='invalid_token'||_0x388d2c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x385fea){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x385fea):'msg'in _0x385fea&&console['log']('FIREBASE:\x20'+_0x385fea['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5603de of this['listens']['values']())for(const _0x5d0e12 of _0x5603de['values']())this['sendListen_'](_0x5d0e12);for(let _0x368989=0x0;_0x368989<this['outstandingPuts_']['length'];_0x368989++)this['outstandingPuts_'][_0x368989]&&this['sendPut_'](_0x368989);for(;this['onDisconnectRequestQueue_']['length'];){const _0x5abcb5=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x5abcb5['action'],_0x5abcb5['pathString'],_0x5abcb5['data'],_0x5abcb5['onComplete']);}for(let _0x163b10=0x0;_0x163b10<this['outstandingGets_']['length'];_0x163b10++)this['outstandingGets_'][_0x163b10]&&this['sendGet_'](_0x163b10);}['sendConnectStats_'](){const _0x460f77={};let _0x11a028='js';_0x460f77['sdk.'+_0x11a028+'.'+no['replace'](/\./g,'-')]=0x1,Ui()?_0x460f77['framework.cordova']=0x1:Kr()&&(_0x460f77['framework.reactnative']=0x1),this['reportStats'](_0x460f77);}['shouldReconnect_'](){const _0x4d4f3e=gn['getInstance']()['currentlyOnline']();return fn(this['interruptReasons_'])&&_0x4d4f3e;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4e8610,_0x2b8f3f){this['name']=_0x4e8610,this['node']=_0x2b8f3f;}static['Wrap'](_0x378932,_0x358dd5){return new E(_0x378932,_0x358dd5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1a5ff2,_0x588986){const _0x1f5479=new E(Ue,_0x1a5ff2),_0x2957ed=new E(Ue,_0x588986);return this['compare'](_0x1f5479,_0x2957ed)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nn;class ko extends xn{static get['__EMPTY_NODE'](){return nn;}static set['__EMPTY_NODE'](_0x4734f4){nn=_0x4734f4;}['compare'](_0x3c41d5,_0x42fcdb){return Ge(_0x3c41d5['name'],_0x42fcdb['name']);}['isDefinedOn'](_0x185502){throw lt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x266f7d,_0x1edba2){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,nn);}['makePost'](_0x261547,_0x11e242){return f(typeof _0x261547=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x261547,nn);}['toString'](){return'.key';}}const De=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sn{constructor(_0x50e2f9,_0x455cce,_0x587902,_0x3fd8df,_0x31bbc4=null){this['isReverse_']=_0x3fd8df,this['resultGenerator_']=_0x31bbc4,this['nodeStack_']=[];let _0x3c2da7=0x1;for(;!_0x50e2f9['isEmpty']();)if(_0x50e2f9=_0x50e2f9,_0x3c2da7=_0x455cce?_0x587902(_0x50e2f9['key'],_0x455cce):0x1,_0x3fd8df&&(_0x3c2da7*=-0x1),_0x3c2da7<0x0)this['isReverse_']?_0x50e2f9=_0x50e2f9['left']:_0x50e2f9=_0x50e2f9['right'];else{if(_0x3c2da7===0x0){this['nodeStack_']['push'](_0x50e2f9);break;}else this['nodeStack_']['push'](_0x50e2f9),this['isReverse_']?_0x50e2f9=_0x50e2f9['right']:_0x50e2f9=_0x50e2f9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4ef1f2=this['nodeStack_']['pop'](),_0x556ecf;if(this['resultGenerator_']?_0x556ecf=this['resultGenerator_'](_0x4ef1f2['key'],_0x4ef1f2['value']):_0x556ecf={'key':_0x4ef1f2['key'],'value':_0x4ef1f2['value']},this['isReverse_']){for(_0x4ef1f2=_0x4ef1f2['left'];!_0x4ef1f2['isEmpty']();)this['nodeStack_']['push'](_0x4ef1f2),_0x4ef1f2=_0x4ef1f2['right'];}else{for(_0x4ef1f2=_0x4ef1f2['right'];!_0x4ef1f2['isEmpty']();)this['nodeStack_']['push'](_0x4ef1f2),_0x4ef1f2=_0x4ef1f2['left'];}return _0x556ecf;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x65419e=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x65419e['key'],_0x65419e['value']):{'key':_0x65419e['key'],'value':_0x65419e['value']};}}class M{constructor(_0x3fa380,_0x5b56d0,_0x153856,_0x14515f,_0x99e44f){this['key']=_0x3fa380,this['value']=_0x5b56d0,this['color']=_0x153856??M['RED'],this['left']=_0x14515f??B['EMPTY_NODE'],this['right']=_0x99e44f??B['EMPTY_NODE'];}['copy'](_0x36ffcb,_0x45fde4,_0x6424fb,_0x2c9192,_0x67bace){return new M(_0x36ffcb??this['key'],_0x45fde4??this['value'],_0x6424fb??this['color'],_0x2c9192??this['left'],_0x67bace??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3d9cd9){return this['left']['inorderTraversal'](_0x3d9cd9)||!!_0x3d9cd9(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3d9cd9);}['reverseTraversal'](_0x5dd6f0){return this['right']['reverseTraversal'](_0x5dd6f0)||_0x5dd6f0(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5dd6f0);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1f3782,_0x2df85f,_0x5abdb7){let _0x293b58=this;const _0x195867=_0x5abdb7(_0x1f3782,_0x293b58['key']);return _0x195867<0x0?_0x293b58=_0x293b58['copy'](null,null,null,_0x293b58['left']['insert'](_0x1f3782,_0x2df85f,_0x5abdb7),null):_0x195867===0x0?_0x293b58=_0x293b58['copy'](null,_0x2df85f,null,null,null):_0x293b58=_0x293b58['copy'](null,null,null,null,_0x293b58['right']['insert'](_0x1f3782,_0x2df85f,_0x5abdb7)),_0x293b58['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1bd593=this;return!_0x1bd593['left']['isRed_']()&&!_0x1bd593['left']['left']['isRed_']()&&(_0x1bd593=_0x1bd593['moveRedLeft_']()),_0x1bd593=_0x1bd593['copy'](null,null,null,_0x1bd593['left']['removeMin_'](),null),_0x1bd593['fixUp_']();}['remove'](_0x3f5336,_0x6a1ebf){let _0x5e2974,_0x288a64;if(_0x5e2974=this,_0x6a1ebf(_0x3f5336,_0x5e2974['key'])<0x0)!_0x5e2974['left']['isEmpty']()&&!_0x5e2974['left']['isRed_']()&&!_0x5e2974['left']['left']['isRed_']()&&(_0x5e2974=_0x5e2974['moveRedLeft_']()),_0x5e2974=_0x5e2974['copy'](null,null,null,_0x5e2974['left']['remove'](_0x3f5336,_0x6a1ebf),null);else{if(_0x5e2974['left']['isRed_']()&&(_0x5e2974=_0x5e2974['rotateRight_']()),!_0x5e2974['right']['isEmpty']()&&!_0x5e2974['right']['isRed_']()&&!_0x5e2974['right']['left']['isRed_']()&&(_0x5e2974=_0x5e2974['moveRedRight_']()),_0x6a1ebf(_0x3f5336,_0x5e2974['key'])===0x0){if(_0x5e2974['right']['isEmpty']())return B['EMPTY_NODE'];_0x288a64=_0x5e2974['right']['min_'](),_0x5e2974=_0x5e2974['copy'](_0x288a64['key'],_0x288a64['value'],null,null,_0x5e2974['right']['removeMin_']());}_0x5e2974=_0x5e2974['copy'](null,null,null,null,_0x5e2974['right']['remove'](_0x3f5336,_0x6a1ebf));}return _0x5e2974['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x12a922=this;return _0x12a922['right']['isRed_']()&&!_0x12a922['left']['isRed_']()&&(_0x12a922=_0x12a922['rotateLeft_']()),_0x12a922['left']['isRed_']()&&_0x12a922['left']['left']['isRed_']()&&(_0x12a922=_0x12a922['rotateRight_']()),_0x12a922['left']['isRed_']()&&_0x12a922['right']['isRed_']()&&(_0x12a922=_0x12a922['colorFlip_']()),_0x12a922;}['moveRedLeft_'](){let _0x40b755=this['colorFlip_']();return _0x40b755['right']['left']['isRed_']()&&(_0x40b755=_0x40b755['copy'](null,null,null,null,_0x40b755['right']['rotateRight_']()),_0x40b755=_0x40b755['rotateLeft_'](),_0x40b755=_0x40b755['colorFlip_']()),_0x40b755;}['moveRedRight_'](){let _0x5e1a00=this['colorFlip_']();return _0x5e1a00['left']['left']['isRed_']()&&(_0x5e1a00=_0x5e1a00['rotateRight_'](),_0x5e1a00=_0x5e1a00['colorFlip_']()),_0x5e1a00;}['rotateLeft_'](){const _0x1cd374=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1cd374,null);}['rotateRight_'](){const _0x2095b3=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2095b3);}['colorFlip_'](){const _0xbeb1c3=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x514b9e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xbeb1c3,_0x514b9e);}['checkMaxDepth_'](){const _0x2cc959=this['check_']();return Math['pow'](0x2,_0x2cc959)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2ec0e8=this['left']['check_']();if(_0x2ec0e8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2ec0e8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Ph{['copy'](_0x3ae9fa,_0x506f98,_0xd700c1,_0x468cd0,_0x5f348f){return this;}['insert'](_0x462ddf,_0x1b0eb2,_0x52dd62){return new M(_0x462ddf,_0x1b0eb2,null);}['remove'](_0x503052,_0x4b26ee){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xc2d175){return!0x1;}['reverseTraversal'](_0x17f468){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x401683,_0x47c571=B['EMPTY_NODE']){this['comparator_']=_0x401683,this['root_']=_0x47c571;}['insert'](_0x187a18,_0x42d1a2){return new B(this['comparator_'],this['root_']['insert'](_0x187a18,_0x42d1a2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3bff07){return new B(this['comparator_'],this['root_']['remove'](_0x3bff07,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x167068){let _0xb3ef89,_0xe628e1=this['root_'];for(;!_0xe628e1['isEmpty']();){if(_0xb3ef89=this['comparator_'](_0x167068,_0xe628e1['key']),_0xb3ef89===0x0)return _0xe628e1['value'];_0xb3ef89<0x0?_0xe628e1=_0xe628e1['left']:_0xb3ef89>0x0&&(_0xe628e1=_0xe628e1['right']);}return null;}['getPredecessorKey'](_0x11ba34){let _0x829ed3,_0x29e1ee=this['root_'],_0x33de28=null;for(;!_0x29e1ee['isEmpty']();)if(_0x829ed3=this['comparator_'](_0x11ba34,_0x29e1ee['key']),_0x829ed3===0x0){if(_0x29e1ee['left']['isEmpty']())return _0x33de28?_0x33de28['key']:null;for(_0x29e1ee=_0x29e1ee['left'];!_0x29e1ee['right']['isEmpty']();)_0x29e1ee=_0x29e1ee['right'];return _0x29e1ee['key'];}else _0x829ed3<0x0?_0x29e1ee=_0x29e1ee['left']:_0x829ed3>0x0&&(_0x33de28=_0x29e1ee,_0x29e1ee=_0x29e1ee['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3c1846){return this['root_']['inorderTraversal'](_0x3c1846);}['reverseTraversal'](_0x35237f){return this['root_']['reverseTraversal'](_0x35237f);}['getIterator'](_0x5eddbd){return new sn(this['root_'],null,this['comparator_'],!0x1,_0x5eddbd);}['getIteratorFrom'](_0x3fdd33,_0x38cb26){return new sn(this['root_'],_0x3fdd33,this['comparator_'],!0x1,_0x38cb26);}['getReverseIteratorFrom'](_0x2f5fcc,_0xee69ad){return new sn(this['root_'],_0x2f5fcc,this['comparator_'],!0x0,_0xee69ad);}['getReverseIterator'](_0x12f039){return new sn(this['root_'],null,this['comparator_'],!0x0,_0x12f039);}}B['EMPTY_NODE']=new Ph();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oh(_0x352c86,_0x579a4d){return Ge(_0x352c86['name'],_0x579a4d['name']);}function Yi(_0x5c082d,_0x140d2e){return Ge(_0x5c082d,_0x140d2e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wi;function Dh(_0x333905){wi=_0x333905;}const No=function(_0x1fd2f5){return typeof _0x1fd2f5=='number'?'number:'+ao(_0x1fd2f5):'string:'+_0x1fd2f5;},Po=function(_0x23fef5){if(_0x23fef5['isLeafNode']()){const _0x40cf38=_0x23fef5['val']();f(typeof _0x40cf38=='string'||typeof _0x40cf38=='number'||typeof _0x40cf38=='object'&&Q(_0x40cf38,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x23fef5===wi||_0x23fef5['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x23fef5===wi||_0x23fef5['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x23621b){nr=_0x23621b;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x32db80,_0x4c9bff=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x32db80,this['priorityNode_']=_0x4c9bff,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x169f28){return new D(this['value_'],_0x169f28);}['getImmediateChild'](_0x4dcda6){return _0x4dcda6==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x414b87){return v(_0x414b87)?this:y(_0x414b87)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1af30d,_0xfba17c){return null;}['updateImmediateChild'](_0x5e6c19,_0x1fb0c0){return _0x5e6c19==='.priority'?this['updatePriority'](_0x1fb0c0):_0x1fb0c0['isEmpty']()&&_0x5e6c19!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5e6c19,_0x1fb0c0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x23d082,_0xb68df5){const _0x31a65e=y(_0x23d082);return _0x31a65e===null?_0xb68df5:_0xb68df5['isEmpty']()&&_0x31a65e!=='.priority'?this:(f(_0x31a65e!=='.priority'||we(_0x23d082)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x31a65e,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x23d082),_0xb68df5)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2d6930,_0x1fae7b){return!0x1;}['val'](_0x17927b){return _0x17927b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x345a30='';this['priorityNode_']['isEmpty']()||(_0x345a30+='priority:'+No(this['priorityNode_']['val']())+':');const _0x5922da=typeof this['value_'];_0x345a30+=_0x5922da+':',_0x5922da==='number'?_0x345a30+=ao(this['value_']):_0x345a30+=this['value_'],this['lazyHash_']=ro(_0x345a30);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4ea108){return _0x4ea108===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4ea108 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4ea108['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4ea108));}['compareToLeafNode_'](_0xfe8b2b){const _0x3431a1=typeof _0xfe8b2b['value_'],_0x3ac79c=typeof this['value_'],_0x2a0747=D['VALUE_TYPE_ORDER']['indexOf'](_0x3431a1),_0x31a8d9=D['VALUE_TYPE_ORDER']['indexOf'](_0x3ac79c);return f(_0x2a0747>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3431a1),f(_0x31a8d9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3ac79c),_0x2a0747===_0x31a8d9?_0x3ac79c==='object'?0x0:this['value_']<_0xfe8b2b['value_']?-0x1:this['value_']===_0xfe8b2b['value_']?0x0:0x1:_0x31a8d9-_0x2a0747;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2442a2){if(_0x2442a2===this)return!0x0;if(_0x2442a2['isLeafNode']()){const _0x1fd4b1=_0x2442a2;return this['value_']===_0x1fd4b1['value_']&&this['priorityNode_']['equals'](_0x1fd4b1['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Mh(_0x4bc947){Oo=_0x4bc947;}function Lh(_0x3e596b){Do=_0x3e596b;}class xh extends xn{['compare'](_0x18db82,_0x48ade3){const _0x1a8ac2=_0x18db82['node']['getPriority'](),_0x39579f=_0x48ade3['node']['getPriority'](),_0x83f58b=_0x1a8ac2['compareTo'](_0x39579f);return _0x83f58b===0x0?Ge(_0x18db82['name'],_0x48ade3['name']):_0x83f58b;}['isDefinedOn'](_0x3f4d24){return!_0x3f4d24['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5a8b44,_0x36cbdb){return!_0x5a8b44['getPriority']()['equals'](_0x36cbdb['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4de0c7,_0x426571){const _0x24ac4b=Oo(_0x4de0c7);return new E(_0x426571,new D('[PRIORITY-POST]',_0x24ac4b));}['toString'](){return'.priority';}}const R=new xh(),Fh=Math['log'](0x2);class Uh{constructor(_0x3e0459){const _0x5dc791=_0x205cfe=>parseInt(Math['log'](_0x205cfe)/Fh,0xa),_0x6c3a7e=_0x159662=>parseInt(Array(_0x159662+0x1)['join']('1'),0x2);this['count']=_0x5dc791(_0x3e0459+0x1),this['current_']=this['count']-0x1;const _0x4339a5=_0x6c3a7e(this['count']);this['bits_']=_0x3e0459+0x1&_0x4339a5;}['nextBitIsOne'](){const _0x2b1343=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2b1343;}}const mn=function(_0x4bdb32,_0x28fe04,_0x1f8ccb,_0x2a4fbe){_0x4bdb32['sort'](_0x28fe04);const _0xb65f3b=function(_0xd8d38f,_0x3d9ff3){const _0x50bdd6=_0x3d9ff3-_0xd8d38f;let _0x41da11,_0x4f3c4d;if(_0x50bdd6===0x0)return null;if(_0x50bdd6===0x1)return _0x41da11=_0x4bdb32[_0xd8d38f],_0x4f3c4d=_0x1f8ccb?_0x1f8ccb(_0x41da11):_0x41da11,new M(_0x4f3c4d,_0x41da11['node'],M['BLACK'],null,null);{const _0x2d8eeb=parseInt(_0x50bdd6/0x2,0xa)+_0xd8d38f,_0x3199d0=_0xb65f3b(_0xd8d38f,_0x2d8eeb),_0x5e4477=_0xb65f3b(_0x2d8eeb+0x1,_0x3d9ff3);return _0x41da11=_0x4bdb32[_0x2d8eeb],_0x4f3c4d=_0x1f8ccb?_0x1f8ccb(_0x41da11):_0x41da11,new M(_0x4f3c4d,_0x41da11['node'],M['BLACK'],_0x3199d0,_0x5e4477);}},_0x3c5c65=function(_0x1456a7){let _0x5e4095=null,_0x3b259e=null,_0x2b663a=_0x4bdb32['length'];const _0x44fd23=function(_0x304af9,_0x245858){const _0x14b2ae=_0x2b663a-_0x304af9,_0x15a9d6=_0x2b663a;_0x2b663a-=_0x304af9;const _0x1c2def=_0xb65f3b(_0x14b2ae+0x1,_0x15a9d6),_0x55d33c=_0x4bdb32[_0x14b2ae],_0x526055=_0x1f8ccb?_0x1f8ccb(_0x55d33c):_0x55d33c;_0x5db732(new M(_0x526055,_0x55d33c['node'],_0x245858,null,_0x1c2def));},_0x5db732=function(_0x148bf0){_0x5e4095?(_0x5e4095['left']=_0x148bf0,_0x5e4095=_0x148bf0):(_0x3b259e=_0x148bf0,_0x5e4095=_0x148bf0);};for(let _0x3c7759=0x0;_0x3c7759<_0x1456a7['count'];++_0x3c7759){const _0x4adcb5=_0x1456a7['nextBitIsOne'](),_0x46ee83=Math['pow'](0x2,_0x1456a7['count']-(_0x3c7759+0x1));_0x4adcb5?_0x44fd23(_0x46ee83,M['BLACK']):(_0x44fd23(_0x46ee83,M['BLACK']),_0x44fd23(_0x46ee83,M['RED']));}return _0x3b259e;},_0x43f23e=new Uh(_0x4bdb32['length']),_0x30c716=_0x3c5c65(_0x43f23e);return new B(_0x2a4fbe||_0x28fe04,_0x30c716);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ci;const Ye={};class te{static get['Default'](){return f(Ye&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ci=ci||new te({'.priority':Ye},{'.priority':R}),ci;}constructor(_0x480f2b,_0x206a68){this['indexes_']=_0x480f2b,this['indexSet_']=_0x206a68;}['get'](_0x3d366c){const _0x111ee0=Me(this['indexes_'],_0x3d366c);if(!_0x111ee0)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3d366c);return _0x111ee0 instanceof B?_0x111ee0:null;}['hasIndex'](_0x4e8d4c){return Q(this['indexSet_'],_0x4e8d4c['toString']());}['addIndex'](_0x4a7355,_0x65f2b8){f(_0x4a7355!==De,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xe6ff94=[];let _0x4d3a56=!0x1;const _0xcd7a5b=_0x65f2b8['getIterator'](E['Wrap']);let _0x30c46b=_0xcd7a5b['getNext']();for(;_0x30c46b;)_0x4d3a56=_0x4d3a56||_0x4a7355['isDefinedOn'](_0x30c46b['node']),_0xe6ff94['push'](_0x30c46b),_0x30c46b=_0xcd7a5b['getNext']();let _0x5278be;_0x4d3a56?_0x5278be=mn(_0xe6ff94,_0x4a7355['getCompare']()):_0x5278be=Ye;const _0xf34bda=_0x4a7355['toString'](),_0x4d6933={...this['indexSet_']};_0x4d6933[_0xf34bda]=_0x4a7355;const _0xa9b186={...this['indexes_']};return _0xa9b186[_0xf34bda]=_0x5278be,new te(_0xa9b186,_0x4d6933);}['addToIndexes'](_0x581e36,_0xa37c7f){const _0x2f2b9e=pn(this['indexes_'],(_0x4abd17,_0x55ab57)=>{const _0x5a7e48=Me(this['indexSet_'],_0x55ab57);if(f(_0x5a7e48,'Missing\x20index\x20implementation\x20for\x20'+_0x55ab57),_0x4abd17===Ye){if(_0x5a7e48['isDefinedOn'](_0x581e36['node'])){const _0x34cb87=[],_0x2c4ee6=_0xa37c7f['getIterator'](E['Wrap']);let _0x418422=_0x2c4ee6['getNext']();for(;_0x418422;)_0x418422['name']!==_0x581e36['name']&&_0x34cb87['push'](_0x418422),_0x418422=_0x2c4ee6['getNext']();return _0x34cb87['push'](_0x581e36),mn(_0x34cb87,_0x5a7e48['getCompare']());}else return Ye;}else{const _0x5204d0=_0xa37c7f['get'](_0x581e36['name']);let _0xc8f5a0=_0x4abd17;return _0x5204d0&&(_0xc8f5a0=_0xc8f5a0['remove'](new E(_0x581e36['name'],_0x5204d0))),_0xc8f5a0['insert'](_0x581e36,_0x581e36['node']);}});return new te(_0x2f2b9e,this['indexSet_']);}['removeFromIndexes'](_0x1c97a9,_0x3f8a79){const _0x1b6552=pn(this['indexes_'],_0x13ed3a=>{if(_0x13ed3a===Ye)return _0x13ed3a;{const _0x559434=_0x3f8a79['get'](_0x1c97a9['name']);return _0x559434?_0x13ed3a['remove'](new E(_0x1c97a9['name'],_0x559434)):_0x13ed3a;}});return new te(_0x1b6552,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Yi),null,te['Default']));}constructor(_0x4ae3a7,_0x592321,_0x4b7151){this['children_']=_0x4ae3a7,this['priorityNode_']=_0x592321,this['indexMap_']=_0x4b7151,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x5095a1){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5095a1,this['indexMap_']);}['getImmediateChild'](_0x4ad392){if(_0x4ad392==='.priority')return this['getPriority']();{const _0x33ab8b=this['children_']['get'](_0x4ad392);return _0x33ab8b===null?Et:_0x33ab8b;}}['getChild'](_0x2a614b){const _0x268d3a=y(_0x2a614b);return _0x268d3a===null?this:this['getImmediateChild'](_0x268d3a)['getChild'](S(_0x2a614b));}['hasChild'](_0x4572ce){return this['children_']['get'](_0x4572ce)!==null;}['updateImmediateChild'](_0x791891,_0x8ba6ea){if(f(_0x8ba6ea,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x791891==='.priority')return this['updatePriority'](_0x8ba6ea);{const _0x103845=new E(_0x791891,_0x8ba6ea);let _0x509cac,_0x2125c5;_0x8ba6ea['isEmpty']()?(_0x509cac=this['children_']['remove'](_0x791891),_0x2125c5=this['indexMap_']['removeFromIndexes'](_0x103845,this['children_'])):(_0x509cac=this['children_']['insert'](_0x791891,_0x8ba6ea),_0x2125c5=this['indexMap_']['addToIndexes'](_0x103845,this['children_']));const _0x45a01a=_0x509cac['isEmpty']()?Et:this['priorityNode_'];return new g(_0x509cac,_0x45a01a,_0x2125c5);}}['updateChild'](_0x3aec37,_0x55bdcc){const _0x4c3447=y(_0x3aec37);if(_0x4c3447===null)return _0x55bdcc;{f(y(_0x3aec37)!=='.priority'||we(_0x3aec37)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x37dd1f=this['getImmediateChild'](_0x4c3447)['updateChild'](S(_0x3aec37),_0x55bdcc);return this['updateImmediateChild'](_0x4c3447,_0x37dd1f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3edb9a){if(this['isEmpty']())return null;const _0x2bd338={};let _0x59acb5=0x0,_0x3e92e3=0x0,_0x1d123b=!0x0;if(this['forEachChild'](R,(_0x34f9d8,_0xf530a3)=>{_0x2bd338[_0x34f9d8]=_0xf530a3['val'](_0x3edb9a),_0x59acb5++,_0x1d123b&&g['INTEGER_REGEXP_']['test'](_0x34f9d8)?_0x3e92e3=Math['max'](_0x3e92e3,Number(_0x34f9d8)):_0x1d123b=!0x1;}),!_0x3edb9a&&_0x1d123b&&_0x3e92e3<0x2*_0x59acb5){const _0x41a3c4=[];for(const _0x5777b2 in _0x2bd338)_0x41a3c4[_0x5777b2]=_0x2bd338[_0x5777b2];return _0x41a3c4;}else return _0x3edb9a&&!this['getPriority']()['isEmpty']()&&(_0x2bd338['.priority']=this['getPriority']()['val']()),_0x2bd338;}['hash'](){if(this['lazyHash_']===null){let _0x488631='';this['getPriority']()['isEmpty']()||(_0x488631+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x586299,_0x2f1cf5)=>{const _0x3a2ea1=_0x2f1cf5['hash']();_0x3a2ea1!==''&&(_0x488631+=':'+_0x586299+':'+_0x3a2ea1);}),this['lazyHash_']=_0x488631===''?'':ro(_0x488631);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1ff172,_0xe753ce,_0x1c2f61){const _0x47834c=this['resolveIndex_'](_0x1c2f61);if(_0x47834c){const _0x2c20ae=_0x47834c['getPredecessorKey'](new E(_0x1ff172,_0xe753ce));return _0x2c20ae?_0x2c20ae['name']:null;}else return this['children_']['getPredecessorKey'](_0x1ff172);}['getFirstChildName'](_0x5a709f){const _0xd248c1=this['resolveIndex_'](_0x5a709f);if(_0xd248c1){const _0x2db3d2=_0xd248c1['minKey']();return _0x2db3d2&&_0x2db3d2['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x127051){const _0x136bfa=this['getFirstChildName'](_0x127051);return _0x136bfa?new E(_0x136bfa,this['children_']['get'](_0x136bfa)):null;}['getLastChildName'](_0x4f2319){const _0x5d46a2=this['resolveIndex_'](_0x4f2319);if(_0x5d46a2){const _0x1e4411=_0x5d46a2['maxKey']();return _0x1e4411&&_0x1e4411['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x57ef37){const _0x527f00=this['getLastChildName'](_0x57ef37);return _0x527f00?new E(_0x527f00,this['children_']['get'](_0x527f00)):null;}['forEachChild'](_0x531d7a,_0x600b78){const _0x4fc8bb=this['resolveIndex_'](_0x531d7a);return _0x4fc8bb?_0x4fc8bb['inorderTraversal'](_0x44d0ce=>_0x600b78(_0x44d0ce['name'],_0x44d0ce['node'])):this['children_']['inorderTraversal'](_0x600b78);}['getIterator'](_0x486b41){return this['getIteratorFrom'](_0x486b41['minPost'](),_0x486b41);}['getIteratorFrom'](_0x14f1db,_0x20cc65){const _0x188639=this['resolveIndex_'](_0x20cc65);if(_0x188639)return _0x188639['getIteratorFrom'](_0x14f1db,_0x1df259=>_0x1df259);{const _0x2252f4=this['children_']['getIteratorFrom'](_0x14f1db['name'],E['Wrap']);let _0x143e74=_0x2252f4['peek']();for(;_0x143e74!=null&&_0x20cc65['compare'](_0x143e74,_0x14f1db)<0x0;)_0x2252f4['getNext'](),_0x143e74=_0x2252f4['peek']();return _0x2252f4;}}['getReverseIterator'](_0x594fa3){return this['getReverseIteratorFrom'](_0x594fa3['maxPost'](),_0x594fa3);}['getReverseIteratorFrom'](_0x57a7fc,_0x5f5763){const _0x653dec=this['resolveIndex_'](_0x5f5763);if(_0x653dec)return _0x653dec['getReverseIteratorFrom'](_0x57a7fc,_0x3960bb=>_0x3960bb);{const _0x3fc007=this['children_']['getReverseIteratorFrom'](_0x57a7fc['name'],E['Wrap']);let _0x4e77d7=_0x3fc007['peek']();for(;_0x4e77d7!=null&&_0x5f5763['compare'](_0x4e77d7,_0x57a7fc)>0x0;)_0x3fc007['getNext'](),_0x4e77d7=_0x3fc007['peek']();return _0x3fc007;}}['compareTo'](_0x4b2574){return this['isEmpty']()?_0x4b2574['isEmpty']()?0x0:-0x1:_0x4b2574['isLeafNode']()||_0x4b2574['isEmpty']()?0x1:_0x4b2574===jt?-0x1:0x0;}['withIndex'](_0xe226ca){if(_0xe226ca===De||this['indexMap_']['hasIndex'](_0xe226ca))return this;{const _0x2a9734=this['indexMap_']['addIndex'](_0xe226ca,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2a9734);}}['isIndexed'](_0x3fbece){return _0x3fbece===De||this['indexMap_']['hasIndex'](_0x3fbece);}['equals'](_0x5d3404){if(_0x5d3404===this)return!0x0;if(_0x5d3404['isLeafNode']())return!0x1;{const _0x4a28f9=_0x5d3404;if(this['getPriority']()['equals'](_0x4a28f9['getPriority']())){if(this['children_']['count']()===_0x4a28f9['children_']['count']()){const _0x47dc29=this['getIterator'](R),_0x55d436=_0x4a28f9['getIterator'](R);let _0x2e6c31=_0x47dc29['getNext'](),_0x3297ab=_0x55d436['getNext']();for(;_0x2e6c31&&_0x3297ab;){if(_0x2e6c31['name']!==_0x3297ab['name']||!_0x2e6c31['node']['equals'](_0x3297ab['node']))return!0x1;_0x2e6c31=_0x47dc29['getNext'](),_0x3297ab=_0x55d436['getNext']();}return _0x2e6c31===null&&_0x3297ab===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x206bfa){return _0x206bfa===De?null:this['indexMap_']['get'](_0x206bfa['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Wh extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3a0f69){return _0x3a0f69===this?0x0:0x1;}['equals'](_0x169de4){return _0x169de4===this;}['getPriority'](){return this;}['getImmediateChild'](_0x128231){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new Wh();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Dh(jt),Lh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bh=!0x0;function A(_0x50fb9f,_0x2a5db4=null){if(_0x50fb9f===null)return g['EMPTY_NODE'];if(typeof _0x50fb9f=='object'&&'.priority'in _0x50fb9f&&(_0x2a5db4=_0x50fb9f['.priority']),f(_0x2a5db4===null||typeof _0x2a5db4=='string'||typeof _0x2a5db4=='number'||typeof _0x2a5db4=='object'&&'.sv'in _0x2a5db4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2a5db4),typeof _0x50fb9f=='object'&&'.value'in _0x50fb9f&&_0x50fb9f['.value']!==null&&(_0x50fb9f=_0x50fb9f['.value']),typeof _0x50fb9f!='object'||'.sv'in _0x50fb9f){const _0x2d3647=_0x50fb9f;return new D(_0x2d3647,A(_0x2a5db4));}if(!(_0x50fb9f instanceof Array)&&Bh){const _0x1aa9fe=[];let _0x5eee22=!0x1;if(x(_0x50fb9f,(_0x2648a3,_0x2669d9)=>{if(_0x2648a3['substring'](0x0,0x1)!=='.'){const _0x3f8364=A(_0x2669d9);_0x3f8364['isEmpty']()||(_0x5eee22=_0x5eee22||!_0x3f8364['getPriority']()['isEmpty'](),_0x1aa9fe['push'](new E(_0x2648a3,_0x3f8364)));}}),_0x1aa9fe['length']===0x0)return g['EMPTY_NODE'];const _0x35e4d4=mn(_0x1aa9fe,Oh,_0x3fc1cc=>_0x3fc1cc['name'],Yi);if(_0x5eee22){const _0xf0887b=mn(_0x1aa9fe,R['getCompare']());return new g(_0x35e4d4,A(_0x2a5db4),new te({'.priority':_0xf0887b},{'.priority':R}));}else return new g(_0x35e4d4,A(_0x2a5db4),te['Default']);}else{let _0x4bea2e=g['EMPTY_NODE'];return x(_0x50fb9f,(_0x2e9305,_0x23710e)=>{if(Q(_0x50fb9f,_0x2e9305)&&_0x2e9305['substring'](0x0,0x1)!=='.'){const _0x4debac=A(_0x23710e);(_0x4debac['isLeafNode']()||!_0x4debac['isEmpty']())&&(_0x4bea2e=_0x4bea2e['updateImmediateChild'](_0x2e9305,_0x4debac));}}),_0x4bea2e['updatePriority'](A(_0x2a5db4));}}Mh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends xn{constructor(_0x3b7abd){super(),this['indexPath_']=_0x3b7abd,f(!v(_0x3b7abd)&&y(_0x3b7abd)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4fe49b){return _0x4fe49b['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1cdb7c){return!_0x1cdb7c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2535ca,_0x3fd752){const _0x36fc63=this['extractChild'](_0x2535ca['node']),_0x59286b=this['extractChild'](_0x3fd752['node']),_0x36c3c6=_0x36fc63['compareTo'](_0x59286b);return _0x36c3c6===0x0?Ge(_0x2535ca['name'],_0x3fd752['name']):_0x36c3c6;}['makePost'](_0x472ade,_0x30c7da){const _0x3529ac=A(_0x472ade),_0x360d90=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3529ac);return new E(_0x30c7da,_0x360d90);}['maxPost'](){const _0x14b6c5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(Ie,_0x14b6c5);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vh extends xn{['compare'](_0xbb93d5,_0x35c763){const _0x404662=_0xbb93d5['node']['compareTo'](_0x35c763['node']);return _0x404662===0x0?Ge(_0xbb93d5['name'],_0x35c763['name']):_0x404662;}['isDefinedOn'](_0x53f883){return!0x0;}['indexedValueChanged'](_0x3385d0,_0x16d4f4){return!_0x3385d0['equals'](_0x16d4f4);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x58680e,_0x57fa47){const _0x2e4471=A(_0x58680e);return new E(_0x57fa47,_0x2e4471);}['toString'](){return'.value';}}const Mo=new Vh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x26a5a6){return{'type':'value','snapshotNode':_0x26a5a6};}function st(_0x298411,_0x22a9ef){return{'type':'child_added','snapshotNode':_0x22a9ef,'childName':_0x298411};}function Mt(_0x228330,_0x45d7f0){return{'type':'child_removed','snapshotNode':_0x45d7f0,'childName':_0x228330};}function Lt(_0x5a9cbe,_0x465751,_0x1f9ec4){return{'type':'child_changed','snapshotNode':_0x465751,'childName':_0x5a9cbe,'oldSnap':_0x1f9ec4};}function Hh(_0x25d37c,_0x872c9f){return{'type':'child_moved','snapshotNode':_0x872c9f,'childName':_0x25d37c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0xfa3ef7){this['index_']=_0xfa3ef7;}['updateChild'](_0x1bbaa3,_0x42a60b,_0x16965c,_0x3d1d59,_0x3262bf,_0xeebeaa){f(_0x1bbaa3['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1f95f5=_0x1bbaa3['getImmediateChild'](_0x42a60b);return _0x1f95f5['getChild'](_0x3d1d59)['equals'](_0x16965c['getChild'](_0x3d1d59))&&_0x1f95f5['isEmpty']()===_0x16965c['isEmpty']()||(_0xeebeaa!=null&&(_0x16965c['isEmpty']()?_0x1bbaa3['hasChild'](_0x42a60b)?_0xeebeaa['trackChildChange'](Mt(_0x42a60b,_0x1f95f5)):f(_0x1bbaa3['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1f95f5['isEmpty']()?_0xeebeaa['trackChildChange'](st(_0x42a60b,_0x16965c)):_0xeebeaa['trackChildChange'](Lt(_0x42a60b,_0x16965c,_0x1f95f5))),_0x1bbaa3['isLeafNode']()&&_0x16965c['isEmpty']())?_0x1bbaa3:_0x1bbaa3['updateImmediateChild'](_0x42a60b,_0x16965c)['withIndex'](this['index_']);}['updateFullNode'](_0x3e6a7f,_0x3a4da2,_0x7e1ca3){return _0x7e1ca3!=null&&(_0x3e6a7f['isLeafNode']()||_0x3e6a7f['forEachChild'](R,(_0x190b1c,_0x10e2f6)=>{_0x3a4da2['hasChild'](_0x190b1c)||_0x7e1ca3['trackChildChange'](Mt(_0x190b1c,_0x10e2f6));}),_0x3a4da2['isLeafNode']()||_0x3a4da2['forEachChild'](R,(_0x24da02,_0x5614b8)=>{if(_0x3e6a7f['hasChild'](_0x24da02)){const _0x4ffd74=_0x3e6a7f['getImmediateChild'](_0x24da02);_0x4ffd74['equals'](_0x5614b8)||_0x7e1ca3['trackChildChange'](Lt(_0x24da02,_0x5614b8,_0x4ffd74));}else _0x7e1ca3['trackChildChange'](st(_0x24da02,_0x5614b8));})),_0x3a4da2['withIndex'](this['index_']);}['updatePriority'](_0x1f96a2,_0x39dbac){return _0x1f96a2['isEmpty']()?g['EMPTY_NODE']:_0x1f96a2['updatePriority'](_0x39dbac);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x27042f){this['indexedFilter_']=new Ji(_0x27042f['getIndex']()),this['index_']=_0x27042f['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x27042f),this['endPost_']=xt['getEndPost_'](_0x27042f),this['startIsInclusive_']=!_0x27042f['startAfterSet_'],this['endIsInclusive_']=!_0x27042f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x37c166){const _0x4b7597=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x37c166)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x37c166)<0x0,_0x54c321=this['endIsInclusive_']?this['index_']['compare'](_0x37c166,this['getEndPost']())<=0x0:this['index_']['compare'](_0x37c166,this['getEndPost']())<0x0;return _0x4b7597&&_0x54c321;}['updateChild'](_0x1a8558,_0x1b767b,_0x5a1fdd,_0x442038,_0x1ac1df,_0x8f5a88){return this['matches'](new E(_0x1b767b,_0x5a1fdd))||(_0x5a1fdd=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1a8558,_0x1b767b,_0x5a1fdd,_0x442038,_0x1ac1df,_0x8f5a88);}['updateFullNode'](_0x15d514,_0x356a66,_0x210f94){_0x356a66['isLeafNode']()&&(_0x356a66=g['EMPTY_NODE']);let _0xf92868=_0x356a66['withIndex'](this['index_']);_0xf92868=_0xf92868['updatePriority'](g['EMPTY_NODE']);const _0x211163=this;return _0x356a66['forEachChild'](R,(_0xe3b5b,_0x1c02ce)=>{_0x211163['matches'](new E(_0xe3b5b,_0x1c02ce))||(_0xf92868=_0xf92868['updateImmediateChild'](_0xe3b5b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x15d514,_0xf92868,_0x210f94);}['updatePriority'](_0x1cb0ae,_0x25239c){return _0x1cb0ae;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xc2b65c){if(_0xc2b65c['hasStart']()){const _0x14c66c=_0xc2b65c['getIndexStartName']();return _0xc2b65c['getIndex']()['makePost'](_0xc2b65c['getIndexStartValue'](),_0x14c66c);}else return _0xc2b65c['getIndex']()['minPost']();}static['getEndPost_'](_0xdf2bab){if(_0xdf2bab['hasEnd']()){const _0x2b0417=_0xdf2bab['getIndexEndName']();return _0xdf2bab['getIndex']()['makePost'](_0xdf2bab['getIndexEndValue'](),_0x2b0417);}else return _0xdf2bab['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $h{constructor(_0x210d76){this['withinDirectionalStart']=_0x5c3b9f=>this['reverse_']?this['withinEndPost'](_0x5c3b9f):this['withinStartPost'](_0x5c3b9f),this['withinDirectionalEnd']=_0x587b96=>this['reverse_']?this['withinStartPost'](_0x587b96):this['withinEndPost'](_0x587b96),this['withinStartPost']=_0x228c3d=>{const _0xceabe=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x228c3d);return this['startIsInclusive_']?_0xceabe<=0x0:_0xceabe<0x0;},this['withinEndPost']=_0x42725b=>{const _0x56365b=this['index_']['compare'](_0x42725b,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x56365b<=0x0:_0x56365b<0x0;},this['rangedFilter_']=new xt(_0x210d76),this['index_']=_0x210d76['getIndex'](),this['limit_']=_0x210d76['getLimit'](),this['reverse_']=!_0x210d76['isViewFromLeft'](),this['startIsInclusive_']=!_0x210d76['startAfterSet_'],this['endIsInclusive_']=!_0x210d76['endBeforeSet_'];}['updateChild'](_0x28a9af,_0x179fc8,_0x1329f1,_0x4795cc,_0x53d28c,_0x3814f2){return this['rangedFilter_']['matches'](new E(_0x179fc8,_0x1329f1))||(_0x1329f1=g['EMPTY_NODE']),_0x28a9af['getImmediateChild'](_0x179fc8)['equals'](_0x1329f1)?_0x28a9af:_0x28a9af['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x28a9af,_0x179fc8,_0x1329f1,_0x4795cc,_0x53d28c,_0x3814f2):this['fullLimitUpdateChild_'](_0x28a9af,_0x179fc8,_0x1329f1,_0x53d28c,_0x3814f2);}['updateFullNode'](_0x4b0289,_0xee0984,_0xa8491e){let _0x53e103;if(_0xee0984['isLeafNode']()||_0xee0984['isEmpty']())_0x53e103=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xee0984['numChildren']()&&_0xee0984['isIndexed'](this['index_'])){_0x53e103=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5c4271;this['reverse_']?_0x5c4271=_0xee0984['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5c4271=_0xee0984['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x45f1e2=0x0;for(;_0x5c4271['hasNext']()&&_0x45f1e2<this['limit_'];){const _0x45fe0f=_0x5c4271['getNext']();if(this['withinDirectionalStart'](_0x45fe0f)){if(this['withinDirectionalEnd'](_0x45fe0f))_0x53e103=_0x53e103['updateImmediateChild'](_0x45fe0f['name'],_0x45fe0f['node']),_0x45f1e2++;else break;}else continue;}}else{_0x53e103=_0xee0984['withIndex'](this['index_']),_0x53e103=_0x53e103['updatePriority'](g['EMPTY_NODE']);let _0x319b59;this['reverse_']?_0x319b59=_0x53e103['getReverseIterator'](this['index_']):_0x319b59=_0x53e103['getIterator'](this['index_']);let _0x1bec58=0x0;for(;_0x319b59['hasNext']();){const _0x461f34=_0x319b59['getNext']();_0x1bec58<this['limit_']&&this['withinDirectionalStart'](_0x461f34)&&this['withinDirectionalEnd'](_0x461f34)?_0x1bec58++:_0x53e103=_0x53e103['updateImmediateChild'](_0x461f34['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4b0289,_0x53e103,_0xa8491e);}['updatePriority'](_0x392584,_0x34e964){return _0x392584;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x240b06,_0x5a890b,_0x488281,_0x6331ca,_0x4372e1){let _0x25a52b;if(this['reverse_']){const _0x2fe8a8=this['index_']['getCompare']();_0x25a52b=(_0xb91f83,_0x3777fd)=>_0x2fe8a8(_0x3777fd,_0xb91f83);}else _0x25a52b=this['index_']['getCompare']();const _0x57505a=_0x240b06;f(_0x57505a['numChildren']()===this['limit_'],'');const _0x2bab7c=new E(_0x5a890b,_0x488281),_0x2927b8=this['reverse_']?_0x57505a['getFirstChild'](this['index_']):_0x57505a['getLastChild'](this['index_']),_0x266c0b=this['rangedFilter_']['matches'](_0x2bab7c);if(_0x57505a['hasChild'](_0x5a890b)){const _0x4f7b7d=_0x57505a['getImmediateChild'](_0x5a890b);let _0x4fcff0=_0x6331ca['getChildAfterChild'](this['index_'],_0x2927b8,this['reverse_']);for(;_0x4fcff0!=null&&(_0x4fcff0['name']===_0x5a890b||_0x57505a['hasChild'](_0x4fcff0['name']));)_0x4fcff0=_0x6331ca['getChildAfterChild'](this['index_'],_0x4fcff0,this['reverse_']);const _0x4216b4=_0x4fcff0==null?0x1:_0x25a52b(_0x4fcff0,_0x2bab7c);if(_0x266c0b&&!_0x488281['isEmpty']()&&_0x4216b4>=0x0)return _0x4372e1!=null&&_0x4372e1['trackChildChange'](Lt(_0x5a890b,_0x488281,_0x4f7b7d)),_0x57505a['updateImmediateChild'](_0x5a890b,_0x488281);{_0x4372e1!=null&&_0x4372e1['trackChildChange'](Mt(_0x5a890b,_0x4f7b7d));const _0x5cb908=_0x57505a['updateImmediateChild'](_0x5a890b,g['EMPTY_NODE']);return _0x4fcff0!=null&&this['rangedFilter_']['matches'](_0x4fcff0)?(_0x4372e1!=null&&_0x4372e1['trackChildChange'](st(_0x4fcff0['name'],_0x4fcff0['node'])),_0x5cb908['updateImmediateChild'](_0x4fcff0['name'],_0x4fcff0['node'])):_0x5cb908;}}else return _0x488281['isEmpty']()?_0x240b06:_0x266c0b&&_0x25a52b(_0x2927b8,_0x2bab7c)>=0x0?(_0x4372e1!=null&&(_0x4372e1['trackChildChange'](Mt(_0x2927b8['name'],_0x2927b8['node'])),_0x4372e1['trackChildChange'](st(_0x5a890b,_0x488281))),_0x57505a['updateImmediateChild'](_0x5a890b,_0x488281)['updateImmediateChild'](_0x2927b8['name'],g['EMPTY_NODE'])):_0x240b06;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xb6db5e=new Xi();return _0xb6db5e['limitSet_']=this['limitSet_'],_0xb6db5e['limit_']=this['limit_'],_0xb6db5e['startSet_']=this['startSet_'],_0xb6db5e['startAfterSet_']=this['startAfterSet_'],_0xb6db5e['indexStartValue_']=this['indexStartValue_'],_0xb6db5e['startNameSet_']=this['startNameSet_'],_0xb6db5e['indexStartName_']=this['indexStartName_'],_0xb6db5e['endSet_']=this['endSet_'],_0xb6db5e['endBeforeSet_']=this['endBeforeSet_'],_0xb6db5e['indexEndValue_']=this['indexEndValue_'],_0xb6db5e['endNameSet_']=this['endNameSet_'],_0xb6db5e['indexEndName_']=this['indexEndName_'],_0xb6db5e['index_']=this['index_'],_0xb6db5e['viewFrom_']=this['viewFrom_'],_0xb6db5e;}}function Gh(_0x30a1ec){return _0x30a1ec['loadsAllData']()?new Ji(_0x30a1ec['getIndex']()):_0x30a1ec['hasLimit']()?new $h(_0x30a1ec):new xt(_0x30a1ec);}function qh(_0x530f6e,_0x61acdb,_0x53223a){const _0x20c781=_0x530f6e['copy']();return _0x20c781['startSet_']=!0x0,_0x61acdb===void 0x0&&(_0x61acdb=null),_0x20c781['indexStartValue_']=_0x61acdb,_0x53223a!=null?(_0x20c781['startNameSet_']=!0x0,_0x20c781['indexStartName_']=_0x53223a):(_0x20c781['startNameSet_']=!0x1,_0x20c781['indexStartName_']=''),_0x20c781;}function zh(_0x4c3b59,_0x29a39b,_0x5b0016){const _0x3cf6e2=_0x4c3b59['copy']();return _0x3cf6e2['endSet_']=!0x0,_0x29a39b===void 0x0&&(_0x29a39b=null),_0x3cf6e2['indexEndValue_']=_0x29a39b,_0x5b0016!==void 0x0?(_0x3cf6e2['endNameSet_']=!0x0,_0x3cf6e2['indexEndName_']=_0x5b0016):(_0x3cf6e2['endNameSet_']=!0x1,_0x3cf6e2['indexEndName_']=''),_0x3cf6e2;}function jh(_0x369e49,_0x48cae8){const _0x2bcce5=_0x369e49['copy']();return _0x2bcce5['index_']=_0x48cae8,_0x2bcce5;}function ir(_0x5dace6){const _0x279cd7={};if(_0x5dace6['isDefault']())return _0x279cd7;let _0x3fe58f;if(_0x5dace6['index_']===R?_0x3fe58f='$priority':_0x5dace6['index_']===Mo?_0x3fe58f='$value':_0x5dace6['index_']===De?_0x3fe58f='$key':(f(_0x5dace6['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x3fe58f=_0x5dace6['index_']['toString']()),_0x279cd7['orderBy']=O(_0x3fe58f),_0x5dace6['startSet_']){const _0x4507a4=_0x5dace6['startAfterSet_']?'startAfter':'startAt';_0x279cd7[_0x4507a4]=O(_0x5dace6['indexStartValue_']),_0x5dace6['startNameSet_']&&(_0x279cd7[_0x4507a4]+=','+O(_0x5dace6['indexStartName_']));}if(_0x5dace6['endSet_']){const _0x4dc60f=_0x5dace6['endBeforeSet_']?'endBefore':'endAt';_0x279cd7[_0x4dc60f]=O(_0x5dace6['indexEndValue_']),_0x5dace6['endNameSet_']&&(_0x279cd7[_0x4dc60f]+=','+O(_0x5dace6['indexEndName_']));}return _0x5dace6['limitSet_']&&(_0x5dace6['isViewFromLeft']()?_0x279cd7['limitToFirst']=_0x5dace6['limit_']:_0x279cd7['limitToLast']=_0x5dace6['limit_']),_0x279cd7;}function sr(_0x16ceed){const _0x2761f5={};if(_0x16ceed['startSet_']&&(_0x2761f5['sp']=_0x16ceed['indexStartValue_'],_0x16ceed['startNameSet_']&&(_0x2761f5['sn']=_0x16ceed['indexStartName_']),_0x2761f5['sin']=!_0x16ceed['startAfterSet_']),_0x16ceed['endSet_']&&(_0x2761f5['ep']=_0x16ceed['indexEndValue_'],_0x16ceed['endNameSet_']&&(_0x2761f5['en']=_0x16ceed['indexEndName_']),_0x2761f5['ein']=!_0x16ceed['endBeforeSet_']),_0x16ceed['limitSet_']){_0x2761f5['l']=_0x16ceed['limit_'];let _0x351843=_0x16ceed['viewFrom_'];_0x351843===''&&(_0x16ceed['isViewFromLeft']()?_0x351843='l':_0x351843='r'),_0x2761f5['vf']=_0x351843;}return _0x16ceed['index_']!==R&&(_0x2761f5['i']=_0x16ceed['index_']['toString']()),_0x2761f5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yn extends So{['reportStats'](_0x152d1e){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x113c07,_0x15c62a){return _0x15c62a!==void 0x0?'tag$'+_0x15c62a:(f(_0x113c07['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x113c07['_path']['toString']());}constructor(_0x279895,_0x672673,_0x50ea75,_0x34946c){super(),this['repoInfo_']=_0x279895,this['onDataUpdate_']=_0x672673,this['authTokenProvider_']=_0x50ea75,this['appCheckTokenProvider_']=_0x34946c,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x57f32d,_0x232f91,_0x1c6e68,_0x3cf05f){const _0x5dd6c3=_0x57f32d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5dd6c3+'\x20'+_0x57f32d['_queryIdentifier']);const _0x595d2c=yn['getListenId_'](_0x57f32d,_0x1c6e68),_0x592963={};this['listens_'][_0x595d2c]=_0x592963;const _0x32947d=ir(_0x57f32d['_queryParams']);this['restRequest_'](_0x5dd6c3+'.json',_0x32947d,(_0x1472ab,_0x3695d6)=>{let _0x48f7a6=_0x3695d6;if(_0x1472ab===0x194&&(_0x48f7a6=null,_0x1472ab=null),_0x1472ab===null&&this['onDataUpdate_'](_0x5dd6c3,_0x48f7a6,!0x1,_0x1c6e68),Me(this['listens_'],_0x595d2c)===_0x592963){let _0x2184ca;_0x1472ab?_0x1472ab===0x191?_0x2184ca='permission_denied':_0x2184ca='rest_error:'+_0x1472ab:_0x2184ca='ok',_0x3cf05f(_0x2184ca,null);}});}['unlisten'](_0x333eef,_0x545287){const _0x36a29d=yn['getListenId_'](_0x333eef,_0x545287);delete this['listens_'][_0x36a29d];}['get'](_0x2d3294){const _0x5c0af4=ir(_0x2d3294['_queryParams']),_0x439bc4=_0x2d3294['_path']['toString'](),_0x3474d8=new H();return this['restRequest_'](_0x439bc4+'.json',_0x5c0af4,(_0x58306b,_0x51af31)=>{let _0x3cd69f=_0x51af31;_0x58306b===0x194&&(_0x3cd69f=null,_0x58306b=null),_0x58306b===null?(this['onDataUpdate_'](_0x439bc4,_0x3cd69f,!0x1,null),_0x3474d8['resolve'](_0x3cd69f)):_0x3474d8['reject'](new Error(_0x3cd69f));}),_0x3474d8['promise'];}['refreshAuthToken'](_0xe0c26d){}['restRequest_'](_0x219351,_0x23c72b={},_0x4bf3c0){return _0x23c72b['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x193a0c,_0x5a2d8c])=>{_0x193a0c&&_0x193a0c['accessToken']&&(_0x23c72b['auth']=_0x193a0c['accessToken']),_0x5a2d8c&&_0x5a2d8c['token']&&(_0x23c72b['ac']=_0x5a2d8c['token']);const _0x4d851a=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x219351+'?ns='+this['repoInfo_']['namespace']+ht(_0x23c72b);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4d851a);const _0x3bb603=new XMLHttpRequest();_0x3bb603['onreadystatechange']=()=>{if(_0x4bf3c0&&_0x3bb603['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4d851a+'\x20received.\x20status:',_0x3bb603['status'],'response:',_0x3bb603['responseText']);let _0x378f9f=null;if(_0x3bb603['status']>=0xc8&&_0x3bb603['status']<0x12c){try{_0x378f9f=Nt(_0x3bb603['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4d851a+':\x20'+_0x3bb603['responseText']);}_0x4bf3c0(null,_0x378f9f);}else _0x3bb603['status']!==0x191&&_0x3bb603['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4d851a+'\x20Status:\x20'+_0x3bb603['status']),_0x4bf3c0(_0x3bb603['status']);_0x4bf3c0=null;}},_0x3bb603['open']('GET',_0x4d851a,!0x0),_0x3bb603['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x12fe4d){return this['rootNode_']['getChild'](_0x12fe4d);}['updateSnapshot'](_0x1239bd,_0x441989){this['rootNode_']=this['rootNode_']['updateChild'](_0x1239bd,_0x441989);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function vn(){return{'value':null,'children':new Map()};}function ft(_0x2e79f7,_0x5ab4fb,_0x46a854){if(v(_0x5ab4fb))_0x2e79f7['value']=_0x46a854,_0x2e79f7['children']['clear']();else{if(_0x2e79f7['value']!==null)_0x2e79f7['value']=_0x2e79f7['value']['updateChild'](_0x5ab4fb,_0x46a854);else{const _0x4a7fe5=y(_0x5ab4fb);_0x2e79f7['children']['has'](_0x4a7fe5)||_0x2e79f7['children']['set'](_0x4a7fe5,vn());const _0x2811c8=_0x2e79f7['children']['get'](_0x4a7fe5);_0x5ab4fb=S(_0x5ab4fb),ft(_0x2811c8,_0x5ab4fb,_0x46a854);}}}function Ci(_0x3d579d,_0x4017af){if(v(_0x4017af))return _0x3d579d['value']=null,_0x3d579d['children']['clear'](),!0x0;if(_0x3d579d['value']!==null){if(_0x3d579d['value']['isLeafNode']())return!0x1;{const _0xd9d5e1=_0x3d579d['value'];return _0x3d579d['value']=null,_0xd9d5e1['forEachChild'](R,(_0x3a2b56,_0x1106c3)=>{ft(_0x3d579d,new C(_0x3a2b56),_0x1106c3);}),Ci(_0x3d579d,_0x4017af);}}else{if(_0x3d579d['children']['size']>0x0){const _0x3210d3=y(_0x4017af);return _0x4017af=S(_0x4017af),_0x3d579d['children']['has'](_0x3210d3)&&Ci(_0x3d579d['children']['get'](_0x3210d3),_0x4017af)&&_0x3d579d['children']['delete'](_0x3210d3),_0x3d579d['children']['size']===0x0;}else return!0x0;}}function Ti(_0x12bc92,_0x3bcf24,_0x52a918){_0x12bc92['value']!==null?_0x52a918(_0x3bcf24,_0x12bc92['value']):Yh(_0x12bc92,(_0xca1bf0,_0x91d2a6)=>{const _0x4fa2bb=new C(_0x3bcf24['toString']()+'/'+_0xca1bf0);Ti(_0x91d2a6,_0x4fa2bb,_0x52a918);});}function Yh(_0x30cfe9,_0x2e21da){_0x30cfe9['children']['forEach']((_0x2ddcaf,_0x2d67c9)=>{_0x2e21da(_0x2d67c9,_0x2ddcaf);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qh{constructor(_0x162145){this['collection_']=_0x162145,this['last_']=null;}['get'](){const _0x5f2b41=this['collection_']['get'](),_0x230904={..._0x5f2b41};return this['last_']&&x(this['last_'],(_0x2c9c4d,_0x3e497c)=>{_0x230904[_0x2c9c4d]=_0x230904[_0x2c9c4d]-_0x3e497c;}),this['last_']=_0x5f2b41,_0x230904;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,Jh=0x1e*0x3e8,Xh=0x12c*0x3e8;class Zh{constructor(_0x45c325,_0x40cf29){this['server_']=_0x40cf29,this['statsToReport_']={},this['statsListener_']=new Qh(_0x45c325);const _0x2f6c4d=rr+(Jh-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x2f6c4d));}['reportStats_'](){const _0x3da349=this['statsListener_']['get'](),_0x8c0980={};let _0x33ceb4=!0x1;x(_0x3da349,(_0x460ff7,_0xe2a275)=>{_0xe2a275>0x0&&Q(this['statsToReport_'],_0x460ff7)&&(_0x8c0980[_0x460ff7]=_0xe2a275,_0x33ceb4=!0x0);}),_0x33ceb4&&this['server_']['reportStats'](_0x8c0980),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Xh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x25e572){_0x25e572[_0x25e572['OVERWRITE']=0x0]='OVERWRITE',_0x25e572[_0x25e572['MERGE']=0x1]='MERGE',_0x25e572[_0x25e572['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x25e572[_0x25e572['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x56ebe9){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x56ebe9,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class En{constructor(_0x3754fa,_0x33b0b8,_0x5e10df){this['path']=_0x3754fa,this['affectedTree']=_0x33b0b8,this['revert']=_0x5e10df,this['type']=z['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x586cf6){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x46568a=this['affectedTree']['subtree'](new C(_0x586cf6));return new En(w(),_0x46568a,this['revert']);}}else return f(y(this['path'])===_0x586cf6,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new En(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2043af,_0x1fa113){this['source']=_0x2043af,this['path']=_0x1fa113,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1bc6c2){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x15c88f,_0x41539e,_0x2381a9){this['source']=_0x15c88f,this['path']=_0x41539e,this['snap']=_0x2381a9,this['type']=z['OVERWRITE'];}['operationForChild'](_0x469a76){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x469a76)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rt{constructor(_0x52e17f,_0x4351a4,_0x14ec66){this['source']=_0x52e17f,this['path']=_0x4351a4,this['children']=_0x14ec66,this['type']=z['MERGE'];}['operationForChild'](_0x5e2fc7){if(v(this['path'])){const _0xc855ba=this['children']['subtree'](new C(_0x5e2fc7));return _0xc855ba['isEmpty']()?null:_0xc855ba['value']?new We(this['source'],w(),_0xc855ba['value']):new rt(this['source'],w(),_0xc855ba);}else return f(y(this['path'])===_0x5e2fc7,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new rt(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2dd995,_0x5a199b,_0x599f57){this['node_']=_0x2dd995,this['fullyInitialized_']=_0x5a199b,this['filtered_']=_0x599f57;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4a9d41){if(v(_0x4a9d41))return this['isFullyInitialized']()&&!this['filtered_'];const _0x537d59=y(_0x4a9d41);return this['isCompleteForChild'](_0x537d59);}['isCompleteForChild'](_0x207ad9){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x207ad9);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x159a9e){this['query_']=_0x159a9e,this['index_']=this['query_']['_queryParams']['getIndex']();}}function tu(_0x32d3fc,_0x305367,_0x444e50,_0xb5f5ee){const _0x6b142c=[],_0x3cab0e=[];return _0x305367['forEach'](_0x5e0817=>{_0x5e0817['type']==='child_changed'&&_0x32d3fc['index_']['indexedValueChanged'](_0x5e0817['oldSnap'],_0x5e0817['snapshotNode'])&&_0x3cab0e['push'](Hh(_0x5e0817['childName'],_0x5e0817['snapshotNode']));}),It(_0x32d3fc,_0x6b142c,'child_removed',_0x305367,_0xb5f5ee,_0x444e50),It(_0x32d3fc,_0x6b142c,'child_added',_0x305367,_0xb5f5ee,_0x444e50),It(_0x32d3fc,_0x6b142c,'child_moved',_0x3cab0e,_0xb5f5ee,_0x444e50),It(_0x32d3fc,_0x6b142c,'child_changed',_0x305367,_0xb5f5ee,_0x444e50),It(_0x32d3fc,_0x6b142c,'value',_0x305367,_0xb5f5ee,_0x444e50),_0x6b142c;}function It(_0x505be3,_0x54e904,_0x2cd131,_0x49a507,_0xec09b9,_0x3c6573){const _0x4c9fab=_0x49a507['filter'](_0xb7b59d=>_0xb7b59d['type']===_0x2cd131);_0x4c9fab['sort']((_0x395f5e,_0x47f815)=>iu(_0x505be3,_0x395f5e,_0x47f815)),_0x4c9fab['forEach'](_0x469401=>{const _0x4bdcac=nu(_0x505be3,_0x469401,_0x3c6573);_0xec09b9['forEach'](_0x242ba3=>{_0x242ba3['respondsTo'](_0x469401['type'])&&_0x54e904['push'](_0x242ba3['createEvent'](_0x4bdcac,_0x505be3['query_']));});});}function nu(_0x22aa1a,_0x244258,_0x27cba6){return _0x244258['type']==='value'||_0x244258['type']==='child_removed'||(_0x244258['prevName']=_0x27cba6['getPredecessorChildName'](_0x244258['childName'],_0x244258['snapshotNode'],_0x22aa1a['index_'])),_0x244258;}function iu(_0x3ac7cc,_0x3b503c,_0x5a7e34){if(_0x3b503c['childName']==null||_0x5a7e34['childName']==null)throw lt('Should\x20only\x20compare\x20child_\x20events.');const _0x1f4935=new E(_0x3b503c['childName'],_0x3b503c['snapshotNode']),_0x428191=new E(_0x5a7e34['childName'],_0x5a7e34['snapshotNode']);return _0x3ac7cc['index_']['compare'](_0x1f4935,_0x428191);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Fn(_0x398fd1,_0x58476d){return{'eventCache':_0x398fd1,'serverCache':_0x58476d};}function bt(_0x3f99f5,_0x3e289d,_0x15ce93,_0x376407){return Fn(new Ce(_0x3e289d,_0x15ce93,_0x376407),_0x3f99f5['serverCache']);}function xo(_0x547814,_0x23eda3,_0x542097,_0x226ab3){return Fn(_0x547814['eventCache'],new Ce(_0x23eda3,_0x542097,_0x226ab3));}function In(_0x43a037){return _0x43a037['eventCache']['isFullyInitialized']()?_0x43a037['eventCache']['getNode']():null;}function Be(_0xe4077c){return _0xe4077c['serverCache']['isFullyInitialized']()?_0xe4077c['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const su=()=>(li||(li=new B(Vl)),li);class b{static['fromObject'](_0x26c77c){let _0x52471f=new b(null);return x(_0x26c77c,(_0x2cef3f,_0xbc82b)=>{_0x52471f=_0x52471f['set'](new C(_0x2cef3f),_0xbc82b);}),_0x52471f;}constructor(_0x2c676d,_0x280ef1=su()){this['value']=_0x2c676d,this['children']=_0x280ef1;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x428bc8,_0x5307e9){if(this['value']!=null&&_0x5307e9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x428bc8))return null;{const _0x4e5beb=y(_0x428bc8),_0x46653d=this['children']['get'](_0x4e5beb);if(_0x46653d!==null){const _0x44114f=_0x46653d['findRootMostMatchingPathAndValue'](S(_0x428bc8),_0x5307e9);return _0x44114f!=null?{'path':k(new C(_0x4e5beb),_0x44114f['path']),'value':_0x44114f['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x473b80){return this['findRootMostMatchingPathAndValue'](_0x473b80,()=>!0x0);}['subtree'](_0x313749){if(v(_0x313749))return this;{const _0x44c592=y(_0x313749),_0x28c4dd=this['children']['get'](_0x44c592);return _0x28c4dd!==null?_0x28c4dd['subtree'](S(_0x313749)):new b(null);}}['set'](_0x16b51a,_0x37090f){if(v(_0x16b51a))return new b(_0x37090f,this['children']);{const _0x4826f4=y(_0x16b51a),_0x3ccf20=(this['children']['get'](_0x4826f4)||new b(null))['set'](S(_0x16b51a),_0x37090f),_0x164db4=this['children']['insert'](_0x4826f4,_0x3ccf20);return new b(this['value'],_0x164db4);}}['remove'](_0x53df6c){if(v(_0x53df6c))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2dd1d7=y(_0x53df6c),_0x18bbc8=this['children']['get'](_0x2dd1d7);if(_0x18bbc8){const _0x22f3b7=_0x18bbc8['remove'](S(_0x53df6c));let _0x221795;return _0x22f3b7['isEmpty']()?_0x221795=this['children']['remove'](_0x2dd1d7):_0x221795=this['children']['insert'](_0x2dd1d7,_0x22f3b7),this['value']===null&&_0x221795['isEmpty']()?new b(null):new b(this['value'],_0x221795);}else return this;}}['get'](_0x197a3e){if(v(_0x197a3e))return this['value'];{const _0x3151de=y(_0x197a3e),_0x3dee62=this['children']['get'](_0x3151de);return _0x3dee62?_0x3dee62['get'](S(_0x197a3e)):null;}}['setTree'](_0x5c540d,_0x24bc3b){if(v(_0x5c540d))return _0x24bc3b;{const _0x5e5b11=y(_0x5c540d),_0x138775=(this['children']['get'](_0x5e5b11)||new b(null))['setTree'](S(_0x5c540d),_0x24bc3b);let _0x2d82bb;return _0x138775['isEmpty']()?_0x2d82bb=this['children']['remove'](_0x5e5b11):_0x2d82bb=this['children']['insert'](_0x5e5b11,_0x138775),new b(this['value'],_0x2d82bb);}}['fold'](_0x14591b){return this['fold_'](w(),_0x14591b);}['fold_'](_0x2e360d,_0x31ceec){const _0x1c9245={};return this['children']['inorderTraversal']((_0x4a2e6e,_0x4cc09b)=>{_0x1c9245[_0x4a2e6e]=_0x4cc09b['fold_'](k(_0x2e360d,_0x4a2e6e),_0x31ceec);}),_0x31ceec(_0x2e360d,this['value'],_0x1c9245);}['findOnPath'](_0x474a91,_0x253a07){return this['findOnPath_'](_0x474a91,w(),_0x253a07);}['findOnPath_'](_0x5526b7,_0x5488fd,_0x1530ad){const _0x4c90d2=this['value']?_0x1530ad(_0x5488fd,this['value']):!0x1;if(_0x4c90d2)return _0x4c90d2;if(v(_0x5526b7))return null;{const _0xf7295d=y(_0x5526b7),_0x1bcc29=this['children']['get'](_0xf7295d);return _0x1bcc29?_0x1bcc29['findOnPath_'](S(_0x5526b7),k(_0x5488fd,_0xf7295d),_0x1530ad):null;}}['foreachOnPath'](_0x45b58c,_0x5b8f25){return this['foreachOnPath_'](_0x45b58c,w(),_0x5b8f25);}['foreachOnPath_'](_0x4bc9c6,_0x556510,_0x279b69){if(v(_0x4bc9c6))return this;{this['value']&&_0x279b69(_0x556510,this['value']);const _0x121014=y(_0x4bc9c6),_0x3002ff=this['children']['get'](_0x121014);return _0x3002ff?_0x3002ff['foreachOnPath_'](S(_0x4bc9c6),k(_0x556510,_0x121014),_0x279b69):new b(null);}}['foreach'](_0x1a8956){this['foreach_'](w(),_0x1a8956);}['foreach_'](_0x190305,_0x3093a3){this['children']['inorderTraversal']((_0x2b228b,_0x37e5a0)=>{_0x37e5a0['foreach_'](k(_0x190305,_0x2b228b),_0x3093a3);}),this['value']&&_0x3093a3(_0x190305,this['value']);}['foreachChild'](_0x286c28){this['children']['inorderTraversal']((_0x2f0147,_0x1b9ca2)=>{_0x1b9ca2['value']&&_0x286c28(_0x2f0147,_0x1b9ca2['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x3056e0){this['writeTree_']=_0x3056e0;}static['empty'](){return new K(new b(null));}}function Rt(_0x3b8124,_0x2235eb,_0x28b8c9){if(v(_0x2235eb))return new K(new b(_0x28b8c9));{const _0x3ffd80=_0x3b8124['writeTree_']['findRootMostValueAndPath'](_0x2235eb);if(_0x3ffd80!=null){const _0x30c8e7=_0x3ffd80['path'];let _0x14bb85=_0x3ffd80['value'];const _0x16fa5d=F(_0x30c8e7,_0x2235eb);return _0x14bb85=_0x14bb85['updateChild'](_0x16fa5d,_0x28b8c9),new K(_0x3b8124['writeTree_']['set'](_0x30c8e7,_0x14bb85));}else{const _0x1c5afb=new b(_0x28b8c9),_0x223d60=_0x3b8124['writeTree_']['setTree'](_0x2235eb,_0x1c5afb);return new K(_0x223d60);}}}function Si(_0x134d86,_0xc44fdd,_0xd8c09b){let _0x3316b4=_0x134d86;return x(_0xd8c09b,(_0x229c5b,_0x350bff)=>{_0x3316b4=Rt(_0x3316b4,k(_0xc44fdd,_0x229c5b),_0x350bff);}),_0x3316b4;}function or(_0x384bb2,_0x280f98){if(v(_0x280f98))return K['empty']();{const _0x1f3e5c=_0x384bb2['writeTree_']['setTree'](_0x280f98,new b(null));return new K(_0x1f3e5c);}}function bi(_0x1c3061,_0x188c01){return qe(_0x1c3061,_0x188c01)!=null;}function qe(_0x2ff9e0,_0x5ac6f9){const _0x1b2e7e=_0x2ff9e0['writeTree_']['findRootMostValueAndPath'](_0x5ac6f9);return _0x1b2e7e!=null?_0x2ff9e0['writeTree_']['get'](_0x1b2e7e['path'])['getChild'](F(_0x1b2e7e['path'],_0x5ac6f9)):null;}function ar(_0x533602){const _0x217bde=[],_0x4f790d=_0x533602['writeTree_']['value'];return _0x4f790d!=null?_0x4f790d['isLeafNode']()||_0x4f790d['forEachChild'](R,(_0x39e30f,_0x5bc9ec)=>{_0x217bde['push'](new E(_0x39e30f,_0x5bc9ec));}):_0x533602['writeTree_']['children']['inorderTraversal']((_0x16a513,_0xc2caaa)=>{_0xc2caaa['value']!=null&&_0x217bde['push'](new E(_0x16a513,_0xc2caaa['value']));}),_0x217bde;}function ve(_0x30e2b9,_0x443dbd){if(v(_0x443dbd))return _0x30e2b9;{const _0x1c4fe1=qe(_0x30e2b9,_0x443dbd);return _0x1c4fe1!=null?new K(new b(_0x1c4fe1)):new K(_0x30e2b9['writeTree_']['subtree'](_0x443dbd));}}function Ri(_0x48d844){return _0x48d844['writeTree_']['isEmpty']();}function ot(_0x18ce3a,_0x231444){return Fo(w(),_0x18ce3a['writeTree_'],_0x231444);}function Fo(_0x2c9edd,_0xbcfa5c,_0x1b97a0){if(_0xbcfa5c['value']!=null)return _0x1b97a0['updateChild'](_0x2c9edd,_0xbcfa5c['value']);{let _0xd7de45=null;return _0xbcfa5c['children']['inorderTraversal']((_0x145f9e,_0x14d544)=>{_0x145f9e==='.priority'?(f(_0x14d544['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xd7de45=_0x14d544['value']):_0x1b97a0=Fo(k(_0x2c9edd,_0x145f9e),_0x14d544,_0x1b97a0);}),!_0x1b97a0['getChild'](_0x2c9edd)['isEmpty']()&&_0xd7de45!==null&&(_0x1b97a0=_0x1b97a0['updateChild'](k(_0x2c9edd,'.priority'),_0xd7de45)),_0x1b97a0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x188fec,_0x116da1){return Vo(_0x116da1,_0x188fec);}function ru(_0x3152cf,_0x587515,_0x5330bf,_0x5a3e67,_0x1c0d9d){f(_0x5a3e67>_0x3152cf['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1c0d9d===void 0x0&&(_0x1c0d9d=!0x0),_0x3152cf['allWrites']['push']({'path':_0x587515,'snap':_0x5330bf,'writeId':_0x5a3e67,'visible':_0x1c0d9d}),_0x1c0d9d&&(_0x3152cf['visibleWrites']=Rt(_0x3152cf['visibleWrites'],_0x587515,_0x5330bf)),_0x3152cf['lastWriteId']=_0x5a3e67;}function ou(_0x4e2602,_0x20ba8a,_0x4306bb,_0x4b6afc){f(_0x4b6afc>_0x4e2602['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4e2602['allWrites']['push']({'path':_0x20ba8a,'children':_0x4306bb,'writeId':_0x4b6afc,'visible':!0x0}),_0x4e2602['visibleWrites']=Si(_0x4e2602['visibleWrites'],_0x20ba8a,_0x4306bb),_0x4e2602['lastWriteId']=_0x4b6afc;}function au(_0x2c255e,_0x11d9fd){for(let _0x355187=0x0;_0x355187<_0x2c255e['allWrites']['length'];_0x355187++){const _0x985b88=_0x2c255e['allWrites'][_0x355187];if(_0x985b88['writeId']===_0x11d9fd)return _0x985b88;}return null;}function cu(_0xf23662,_0x178ad6){const _0x387345=_0xf23662['allWrites']['findIndex'](_0x582915=>_0x582915['writeId']===_0x178ad6);f(_0x387345>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x595900=_0xf23662['allWrites'][_0x387345];_0xf23662['allWrites']['splice'](_0x387345,0x1);let _0x208ee8=_0x595900['visible'],_0x37c5cb=!0x1,_0x43cce4=_0xf23662['allWrites']['length']-0x1;for(;_0x208ee8&&_0x43cce4>=0x0;){const _0x63e079=_0xf23662['allWrites'][_0x43cce4];_0x63e079['visible']&&(_0x43cce4>=_0x387345&&lu(_0x63e079,_0x595900['path'])?_0x208ee8=!0x1:G(_0x595900['path'],_0x63e079['path'])&&(_0x37c5cb=!0x0)),_0x43cce4--;}if(_0x208ee8){if(_0x37c5cb)return hu(_0xf23662),!0x0;if(_0x595900['snap'])_0xf23662['visibleWrites']=or(_0xf23662['visibleWrites'],_0x595900['path']);else{const _0x14ffc5=_0x595900['children'];x(_0x14ffc5,_0x113bce=>{_0xf23662['visibleWrites']=or(_0xf23662['visibleWrites'],k(_0x595900['path'],_0x113bce));});}return!0x0;}else return!0x1;}function lu(_0x8919e,_0x12a738){if(_0x8919e['snap'])return G(_0x8919e['path'],_0x12a738);for(const _0x3bd449 in _0x8919e['children'])if(_0x8919e['children']['hasOwnProperty'](_0x3bd449)&&G(k(_0x8919e['path'],_0x3bd449),_0x12a738))return!0x0;return!0x1;}function hu(_0x30f6bb){_0x30f6bb['visibleWrites']=Uo(_0x30f6bb['allWrites'],uu,w()),_0x30f6bb['allWrites']['length']>0x0?_0x30f6bb['lastWriteId']=_0x30f6bb['allWrites'][_0x30f6bb['allWrites']['length']-0x1]['writeId']:_0x30f6bb['lastWriteId']=-0x1;}function uu(_0x4bc2ec){return _0x4bc2ec['visible'];}function Uo(_0x21034c,_0xef0070,_0x459833){let _0x5c3023=K['empty']();for(let _0x3b77be=0x0;_0x3b77be<_0x21034c['length'];++_0x3b77be){const _0x504183=_0x21034c[_0x3b77be];if(_0xef0070(_0x504183)){const _0x4df846=_0x504183['path'];let _0x2404b0;if(_0x504183['snap'])G(_0x459833,_0x4df846)?(_0x2404b0=F(_0x459833,_0x4df846),_0x5c3023=Rt(_0x5c3023,_0x2404b0,_0x504183['snap'])):G(_0x4df846,_0x459833)&&(_0x2404b0=F(_0x4df846,_0x459833),_0x5c3023=Rt(_0x5c3023,w(),_0x504183['snap']['getChild'](_0x2404b0)));else{if(_0x504183['children']){if(G(_0x459833,_0x4df846))_0x2404b0=F(_0x459833,_0x4df846),_0x5c3023=Si(_0x5c3023,_0x2404b0,_0x504183['children']);else{if(G(_0x4df846,_0x459833)){if(_0x2404b0=F(_0x4df846,_0x459833),v(_0x2404b0))_0x5c3023=Si(_0x5c3023,w(),_0x504183['children']);else{const _0xe0bb37=Me(_0x504183['children'],y(_0x2404b0));if(_0xe0bb37){const _0x516551=_0xe0bb37['getChild'](S(_0x2404b0));_0x5c3023=Rt(_0x5c3023,w(),_0x516551);}}}}}else throw lt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5c3023;}function Wo(_0x1489de,_0xdda9e9,_0x3ca998,_0x58ba3a,_0xe042a8){if(!_0x58ba3a&&!_0xe042a8){const _0x39723a=qe(_0x1489de['visibleWrites'],_0xdda9e9);if(_0x39723a!=null)return _0x39723a;{const _0x392c9a=ve(_0x1489de['visibleWrites'],_0xdda9e9);if(Ri(_0x392c9a))return _0x3ca998;if(_0x3ca998==null&&!bi(_0x392c9a,w()))return null;{const _0x163818=_0x3ca998||g['EMPTY_NODE'];return ot(_0x392c9a,_0x163818);}}}else{const _0x4cc269=ve(_0x1489de['visibleWrites'],_0xdda9e9);if(!_0xe042a8&&Ri(_0x4cc269))return _0x3ca998;if(!_0xe042a8&&_0x3ca998==null&&!bi(_0x4cc269,w()))return null;{const _0x491c6b=function(_0x2e5222){return(_0x2e5222['visible']||_0xe042a8)&&(!_0x58ba3a||!~_0x58ba3a['indexOf'](_0x2e5222['writeId']))&&(G(_0x2e5222['path'],_0xdda9e9)||G(_0xdda9e9,_0x2e5222['path']));},_0x10d6bb=Uo(_0x1489de['allWrites'],_0x491c6b,_0xdda9e9),_0x12c948=_0x3ca998||g['EMPTY_NODE'];return ot(_0x10d6bb,_0x12c948);}}}function du(_0x40d3a6,_0x4bb9bf,_0x18f131){let _0x5edbab=g['EMPTY_NODE'];const _0x59cc10=qe(_0x40d3a6['visibleWrites'],_0x4bb9bf);if(_0x59cc10)return _0x59cc10['isLeafNode']()||_0x59cc10['forEachChild'](R,(_0x19f320,_0x566921)=>{_0x5edbab=_0x5edbab['updateImmediateChild'](_0x19f320,_0x566921);}),_0x5edbab;if(_0x18f131){const _0x1c3072=ve(_0x40d3a6['visibleWrites'],_0x4bb9bf);return _0x18f131['forEachChild'](R,(_0x50c856,_0x2d2004)=>{const _0x235dc5=ot(ve(_0x1c3072,new C(_0x50c856)),_0x2d2004);_0x5edbab=_0x5edbab['updateImmediateChild'](_0x50c856,_0x235dc5);}),ar(_0x1c3072)['forEach'](_0x4f3c8f=>{_0x5edbab=_0x5edbab['updateImmediateChild'](_0x4f3c8f['name'],_0x4f3c8f['node']);}),_0x5edbab;}else{const _0x3c54b4=ve(_0x40d3a6['visibleWrites'],_0x4bb9bf);return ar(_0x3c54b4)['forEach'](_0x362937=>{_0x5edbab=_0x5edbab['updateImmediateChild'](_0x362937['name'],_0x362937['node']);}),_0x5edbab;}}function fu(_0x40b0fa,_0x4169b8,_0x2d759b,_0x319f9d,_0x17d5ac){f(_0x319f9d||_0x17d5ac,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x11fd63=k(_0x4169b8,_0x2d759b);if(bi(_0x40b0fa['visibleWrites'],_0x11fd63))return null;{const _0x5198e6=ve(_0x40b0fa['visibleWrites'],_0x11fd63);return Ri(_0x5198e6)?_0x17d5ac['getChild'](_0x2d759b):ot(_0x5198e6,_0x17d5ac['getChild'](_0x2d759b));}}function pu(_0x4a8efc,_0x3ea9a8,_0x51f761,_0x30f505){const _0x5d6b82=k(_0x3ea9a8,_0x51f761),_0x1f7e1e=qe(_0x4a8efc['visibleWrites'],_0x5d6b82);if(_0x1f7e1e!=null)return _0x1f7e1e;if(_0x30f505['isCompleteForChild'](_0x51f761)){const _0x173f0e=ve(_0x4a8efc['visibleWrites'],_0x5d6b82);return ot(_0x173f0e,_0x30f505['getNode']()['getImmediateChild'](_0x51f761));}else return null;}function _u(_0xb200fd,_0x40bda9){return qe(_0xb200fd['visibleWrites'],_0x40bda9);}function gu(_0x3a47c7,_0x59e556,_0x206c65,_0x220cc3,_0x5ef206,_0x1507c6,_0x5e98c7){let _0x3d27e7;const _0x7c989c=ve(_0x3a47c7['visibleWrites'],_0x59e556),_0x2b33f9=qe(_0x7c989c,w());if(_0x2b33f9!=null)_0x3d27e7=_0x2b33f9;else{if(_0x206c65!=null)_0x3d27e7=ot(_0x7c989c,_0x206c65);else return[];}if(_0x3d27e7=_0x3d27e7['withIndex'](_0x5e98c7),!_0x3d27e7['isEmpty']()&&!_0x3d27e7['isLeafNode']()){const _0x60c362=[],_0x24a638=_0x5e98c7['getCompare'](),_0x221cab=_0x1507c6?_0x3d27e7['getReverseIteratorFrom'](_0x220cc3,_0x5e98c7):_0x3d27e7['getIteratorFrom'](_0x220cc3,_0x5e98c7);let _0x35d62f=_0x221cab['getNext']();for(;_0x35d62f&&_0x60c362['length']<_0x5ef206;)_0x24a638(_0x35d62f,_0x220cc3)!==0x0&&_0x60c362['push'](_0x35d62f),_0x35d62f=_0x221cab['getNext']();return _0x60c362;}else return[];}function mu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function wn(_0x15bb39,_0x2562e7,_0x2c6f45,_0x488fa4){return Wo(_0x15bb39['writeTree'],_0x15bb39['treePath'],_0x2562e7,_0x2c6f45,_0x488fa4);}function ns(_0x1a2fbf,_0x499970){return du(_0x1a2fbf['writeTree'],_0x1a2fbf['treePath'],_0x499970);}function cr(_0x5afdbb,_0x1b5b3f,_0xf465c2,_0x30be86){return fu(_0x5afdbb['writeTree'],_0x5afdbb['treePath'],_0x1b5b3f,_0xf465c2,_0x30be86);}function Cn(_0x246b24,_0x57b5f8){return _u(_0x246b24['writeTree'],k(_0x246b24['treePath'],_0x57b5f8));}function yu(_0x5d8045,_0x547c1b,_0x4afb5b,_0x52916b,_0x4fa815,_0xe589b4){return gu(_0x5d8045['writeTree'],_0x5d8045['treePath'],_0x547c1b,_0x4afb5b,_0x52916b,_0x4fa815,_0xe589b4);}function is(_0x36cdd6,_0x4e5c00,_0x429fd4){return pu(_0x36cdd6['writeTree'],_0x36cdd6['treePath'],_0x4e5c00,_0x429fd4);}function Bo(_0x8b38a7,_0x2fcde9){return Vo(k(_0x8b38a7['treePath'],_0x2fcde9),_0x8b38a7['writeTree']);}function Vo(_0x1b58ce,_0x58cab5){return{'treePath':_0x1b58ce,'writeTree':_0x58cab5};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4c2762){const _0x3f914d=_0x4c2762['type'],_0x7e04ae=_0x4c2762['childName'];f(_0x3f914d==='child_added'||_0x3f914d==='child_changed'||_0x3f914d==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x7e04ae!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x215e87=this['changeMap']['get'](_0x7e04ae);if(_0x215e87){const _0x3bdc86=_0x215e87['type'];if(_0x3f914d==='child_added'&&_0x3bdc86==='child_removed')this['changeMap']['set'](_0x7e04ae,Lt(_0x7e04ae,_0x4c2762['snapshotNode'],_0x215e87['snapshotNode']));else{if(_0x3f914d==='child_removed'&&_0x3bdc86==='child_added')this['changeMap']['delete'](_0x7e04ae);else{if(_0x3f914d==='child_removed'&&_0x3bdc86==='child_changed')this['changeMap']['set'](_0x7e04ae,Mt(_0x7e04ae,_0x215e87['oldSnap']));else{if(_0x3f914d==='child_changed'&&_0x3bdc86==='child_added')this['changeMap']['set'](_0x7e04ae,st(_0x7e04ae,_0x4c2762['snapshotNode']));else{if(_0x3f914d==='child_changed'&&_0x3bdc86==='child_changed')this['changeMap']['set'](_0x7e04ae,Lt(_0x7e04ae,_0x4c2762['snapshotNode'],_0x215e87['oldSnap']));else throw lt('Illegal\x20combination\x20of\x20changes:\x20'+_0x4c2762+'\x20occurred\x20after\x20'+_0x215e87);}}}}}else this['changeMap']['set'](_0x7e04ae,_0x4c2762);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{['getCompleteChild'](_0x5d8371){return null;}['getChildAfterChild'](_0x4ab409,_0x373417,_0x37df51){return null;}}const Ho=new Eu();class ss{constructor(_0x26dfe,_0xd29526,_0x47519a=null){this['writes_']=_0x26dfe,this['viewCache_']=_0xd29526,this['optCompleteServerCache_']=_0x47519a;}['getCompleteChild'](_0x1805bb){const _0x32dafa=this['viewCache_']['eventCache'];if(_0x32dafa['isCompleteForChild'](_0x1805bb))return _0x32dafa['getNode']()['getImmediateChild'](_0x1805bb);{const _0x13b784=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x1805bb,_0x13b784);}}['getChildAfterChild'](_0x50e83b,_0x4d32d4,_0xd1690){const _0x19e791=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x35a40f=yu(this['writes_'],_0x19e791,_0x4d32d4,0x1,_0xd1690,_0x50e83b);return _0x35a40f['length']===0x0?null:_0x35a40f[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Iu(_0x898564){return{'filter':_0x898564};}function wu(_0x4b641c,_0x3ca2c7){f(_0x3ca2c7['eventCache']['getNode']()['isIndexed'](_0x4b641c['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3ca2c7['serverCache']['getNode']()['isIndexed'](_0x4b641c['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Cu(_0x1ecac1,_0x39916c,_0xdacfbf,_0x1f9242,_0x27ffdb){const _0x2daad6=new vu();let _0x375197,_0x4a23b7;if(_0xdacfbf['type']===z['OVERWRITE']){const _0x3de3ac=_0xdacfbf;_0x3de3ac['source']['fromUser']?_0x375197=Ai(_0x1ecac1,_0x39916c,_0x3de3ac['path'],_0x3de3ac['snap'],_0x1f9242,_0x27ffdb,_0x2daad6):(f(_0x3de3ac['source']['fromServer'],'Unknown\x20source.'),_0x4a23b7=_0x3de3ac['source']['tagged']||_0x39916c['serverCache']['isFiltered']()&&!v(_0x3de3ac['path']),_0x375197=Tn(_0x1ecac1,_0x39916c,_0x3de3ac['path'],_0x3de3ac['snap'],_0x1f9242,_0x27ffdb,_0x4a23b7,_0x2daad6));}else{if(_0xdacfbf['type']===z['MERGE']){const _0x2b731b=_0xdacfbf;_0x2b731b['source']['fromUser']?_0x375197=Su(_0x1ecac1,_0x39916c,_0x2b731b['path'],_0x2b731b['children'],_0x1f9242,_0x27ffdb,_0x2daad6):(f(_0x2b731b['source']['fromServer'],'Unknown\x20source.'),_0x4a23b7=_0x2b731b['source']['tagged']||_0x39916c['serverCache']['isFiltered'](),_0x375197=ki(_0x1ecac1,_0x39916c,_0x2b731b['path'],_0x2b731b['children'],_0x1f9242,_0x27ffdb,_0x4a23b7,_0x2daad6));}else{if(_0xdacfbf['type']===z['ACK_USER_WRITE']){const _0x3d01b9=_0xdacfbf;_0x3d01b9['revert']?_0x375197=Au(_0x1ecac1,_0x39916c,_0x3d01b9['path'],_0x1f9242,_0x27ffdb,_0x2daad6):_0x375197=bu(_0x1ecac1,_0x39916c,_0x3d01b9['path'],_0x3d01b9['affectedTree'],_0x1f9242,_0x27ffdb,_0x2daad6);}else{if(_0xdacfbf['type']===z['LISTEN_COMPLETE'])_0x375197=Ru(_0x1ecac1,_0x39916c,_0xdacfbf['path'],_0x1f9242,_0x2daad6);else throw lt('Unknown\x20operation\x20type:\x20'+_0xdacfbf['type']);}}}const _0xd93d82=_0x2daad6['getChanges']();return Tu(_0x39916c,_0x375197,_0xd93d82),{'viewCache':_0x375197,'changes':_0xd93d82};}function Tu(_0xd3226d,_0xc1b3b3,_0x17e2ae){const _0x25572f=_0xc1b3b3['eventCache'];if(_0x25572f['isFullyInitialized']()){const _0x3bf3e0=_0x25572f['getNode']()['isLeafNode']()||_0x25572f['getNode']()['isEmpty'](),_0x2a94d2=In(_0xd3226d);(_0x17e2ae['length']>0x0||!_0xd3226d['eventCache']['isFullyInitialized']()||_0x3bf3e0&&!_0x25572f['getNode']()['equals'](_0x2a94d2)||!_0x25572f['getNode']()['getPriority']()['equals'](_0x2a94d2['getPriority']()))&&_0x17e2ae['push'](Lo(In(_0xc1b3b3)));}}function $o(_0x4985df,_0x20c494,_0x75b1c3,_0x49b01d,_0x5f3337,_0x417a67){const _0x1dcce2=_0x20c494['eventCache'];if(Cn(_0x49b01d,_0x75b1c3)!=null)return _0x20c494;{let _0x24577e,_0x3b4eb6;if(v(_0x75b1c3)){if(f(_0x20c494['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x20c494['serverCache']['isFiltered']()){const _0x1fce36=Be(_0x20c494),_0x353dd5=_0x1fce36 instanceof g?_0x1fce36:g['EMPTY_NODE'],_0x3c7a09=ns(_0x49b01d,_0x353dd5);_0x24577e=_0x4985df['filter']['updateFullNode'](_0x20c494['eventCache']['getNode'](),_0x3c7a09,_0x417a67);}else{const _0x2df8ab=wn(_0x49b01d,Be(_0x20c494));_0x24577e=_0x4985df['filter']['updateFullNode'](_0x20c494['eventCache']['getNode'](),_0x2df8ab,_0x417a67);}}else{const _0x407735=y(_0x75b1c3);if(_0x407735==='.priority'){f(we(_0x75b1c3)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1e1e43=_0x1dcce2['getNode']();_0x3b4eb6=_0x20c494['serverCache']['getNode']();const _0x375154=cr(_0x49b01d,_0x75b1c3,_0x1e1e43,_0x3b4eb6);_0x375154!=null?_0x24577e=_0x4985df['filter']['updatePriority'](_0x1e1e43,_0x375154):_0x24577e=_0x1dcce2['getNode']();}else{const _0x42e1e6=S(_0x75b1c3);let _0x58ff81;if(_0x1dcce2['isCompleteForChild'](_0x407735)){_0x3b4eb6=_0x20c494['serverCache']['getNode']();const _0xaf23b3=cr(_0x49b01d,_0x75b1c3,_0x1dcce2['getNode'](),_0x3b4eb6);_0xaf23b3!=null?_0x58ff81=_0x1dcce2['getNode']()['getImmediateChild'](_0x407735)['updateChild'](_0x42e1e6,_0xaf23b3):_0x58ff81=_0x1dcce2['getNode']()['getImmediateChild'](_0x407735);}else _0x58ff81=is(_0x49b01d,_0x407735,_0x20c494['serverCache']);_0x58ff81!=null?_0x24577e=_0x4985df['filter']['updateChild'](_0x1dcce2['getNode'](),_0x407735,_0x58ff81,_0x42e1e6,_0x5f3337,_0x417a67):_0x24577e=_0x1dcce2['getNode']();}}return bt(_0x20c494,_0x24577e,_0x1dcce2['isFullyInitialized']()||v(_0x75b1c3),_0x4985df['filter']['filtersNodes']());}}function Tn(_0x4fb15a,_0x27e3b5,_0x240c0f,_0x156e49,_0x331a30,_0x58d0fe,_0x39bc8a,_0x55f32b){const _0x438a80=_0x27e3b5['serverCache'];let _0x3ea77d;const _0x38ba14=_0x39bc8a?_0x4fb15a['filter']:_0x4fb15a['filter']['getIndexedFilter']();if(v(_0x240c0f))_0x3ea77d=_0x38ba14['updateFullNode'](_0x438a80['getNode'](),_0x156e49,null);else{if(_0x38ba14['filtersNodes']()&&!_0x438a80['isFiltered']()){const _0x1c758e=_0x438a80['getNode']()['updateChild'](_0x240c0f,_0x156e49);_0x3ea77d=_0x38ba14['updateFullNode'](_0x438a80['getNode'](),_0x1c758e,null);}else{const _0x143b4f=y(_0x240c0f);if(!_0x438a80['isCompleteForPath'](_0x240c0f)&&we(_0x240c0f)>0x1)return _0x27e3b5;const _0x4ad896=S(_0x240c0f),_0x25cb3e=_0x438a80['getNode']()['getImmediateChild'](_0x143b4f)['updateChild'](_0x4ad896,_0x156e49);_0x143b4f==='.priority'?_0x3ea77d=_0x38ba14['updatePriority'](_0x438a80['getNode'](),_0x25cb3e):_0x3ea77d=_0x38ba14['updateChild'](_0x438a80['getNode'](),_0x143b4f,_0x25cb3e,_0x4ad896,Ho,null);}}const _0x2d7204=xo(_0x27e3b5,_0x3ea77d,_0x438a80['isFullyInitialized']()||v(_0x240c0f),_0x38ba14['filtersNodes']()),_0x44cfcd=new ss(_0x331a30,_0x2d7204,_0x58d0fe);return $o(_0x4fb15a,_0x2d7204,_0x240c0f,_0x331a30,_0x44cfcd,_0x55f32b);}function Ai(_0x591823,_0xe1fb11,_0x494869,_0x1fa81d,_0x460c09,_0x2018f4,_0x23fe03){const _0x45084c=_0xe1fb11['eventCache'];let _0x34ebb0,_0x4c4fcf;const _0x252b5a=new ss(_0x460c09,_0xe1fb11,_0x2018f4);if(v(_0x494869))_0x4c4fcf=_0x591823['filter']['updateFullNode'](_0xe1fb11['eventCache']['getNode'](),_0x1fa81d,_0x23fe03),_0x34ebb0=bt(_0xe1fb11,_0x4c4fcf,!0x0,_0x591823['filter']['filtersNodes']());else{const _0x5fc15e=y(_0x494869);if(_0x5fc15e==='.priority')_0x4c4fcf=_0x591823['filter']['updatePriority'](_0xe1fb11['eventCache']['getNode'](),_0x1fa81d),_0x34ebb0=bt(_0xe1fb11,_0x4c4fcf,_0x45084c['isFullyInitialized'](),_0x45084c['isFiltered']());else{const _0x4a9c73=S(_0x494869),_0x5c4d1a=_0x45084c['getNode']()['getImmediateChild'](_0x5fc15e);let _0x5b5a81;if(v(_0x4a9c73))_0x5b5a81=_0x1fa81d;else{const _0x24a80b=_0x252b5a['getCompleteChild'](_0x5fc15e);_0x24a80b!=null?zi(_0x4a9c73)==='.priority'&&_0x24a80b['getChild'](Ro(_0x4a9c73))['isEmpty']()?_0x5b5a81=_0x24a80b:_0x5b5a81=_0x24a80b['updateChild'](_0x4a9c73,_0x1fa81d):_0x5b5a81=g['EMPTY_NODE'];}if(_0x5c4d1a['equals'](_0x5b5a81))_0x34ebb0=_0xe1fb11;else{const _0x36770e=_0x591823['filter']['updateChild'](_0x45084c['getNode'](),_0x5fc15e,_0x5b5a81,_0x4a9c73,_0x252b5a,_0x23fe03);_0x34ebb0=bt(_0xe1fb11,_0x36770e,_0x45084c['isFullyInitialized'](),_0x591823['filter']['filtersNodes']());}}}return _0x34ebb0;}function lr(_0x5461a3,_0x1b41b5){return _0x5461a3['eventCache']['isCompleteForChild'](_0x1b41b5);}function Su(_0x19a875,_0x20c935,_0x4f0b45,_0x33967,_0x12811a,_0x2fecca,_0x40308d){let _0x22fc4c=_0x20c935;return _0x33967['foreach']((_0x210b3b,_0x576c60)=>{const _0x593448=k(_0x4f0b45,_0x210b3b);lr(_0x20c935,y(_0x593448))&&(_0x22fc4c=Ai(_0x19a875,_0x22fc4c,_0x593448,_0x576c60,_0x12811a,_0x2fecca,_0x40308d));}),_0x33967['foreach']((_0x23cdb8,_0x4afb31)=>{const _0x1fd278=k(_0x4f0b45,_0x23cdb8);lr(_0x20c935,y(_0x1fd278))||(_0x22fc4c=Ai(_0x19a875,_0x22fc4c,_0x1fd278,_0x4afb31,_0x12811a,_0x2fecca,_0x40308d));}),_0x22fc4c;}function hr(_0x4ff1f7,_0x58a41f,_0x1409fa){return _0x1409fa['foreach']((_0x417a3b,_0x4d0c51)=>{_0x58a41f=_0x58a41f['updateChild'](_0x417a3b,_0x4d0c51);}),_0x58a41f;}function ki(_0x1c378d,_0x4bf220,_0x278178,_0x23f0bd,_0x65ff91,_0x58ab40,_0x50ae54,_0x2db24b){if(_0x4bf220['serverCache']['getNode']()['isEmpty']()&&!_0x4bf220['serverCache']['isFullyInitialized']())return _0x4bf220;let _0xd138fd=_0x4bf220,_0x117f94;v(_0x278178)?_0x117f94=_0x23f0bd:_0x117f94=new b(null)['setTree'](_0x278178,_0x23f0bd);const _0xa674f8=_0x4bf220['serverCache']['getNode']();return _0x117f94['children']['inorderTraversal']((_0x3a3008,_0x1cfc05)=>{if(_0xa674f8['hasChild'](_0x3a3008)){const _0xe3ac26=_0x4bf220['serverCache']['getNode']()['getImmediateChild'](_0x3a3008),_0x22ca34=hr(_0x1c378d,_0xe3ac26,_0x1cfc05);_0xd138fd=Tn(_0x1c378d,_0xd138fd,new C(_0x3a3008),_0x22ca34,_0x65ff91,_0x58ab40,_0x50ae54,_0x2db24b);}}),_0x117f94['children']['inorderTraversal']((_0x312356,_0x2aacf7)=>{const _0x13c03a=!_0x4bf220['serverCache']['isCompleteForChild'](_0x312356)&&_0x2aacf7['value']===null;if(!_0xa674f8['hasChild'](_0x312356)&&!_0x13c03a){const _0x317e93=_0x4bf220['serverCache']['getNode']()['getImmediateChild'](_0x312356),_0x1b1492=hr(_0x1c378d,_0x317e93,_0x2aacf7);_0xd138fd=Tn(_0x1c378d,_0xd138fd,new C(_0x312356),_0x1b1492,_0x65ff91,_0x58ab40,_0x50ae54,_0x2db24b);}}),_0xd138fd;}function bu(_0x12f89d,_0x11c0f5,_0x829113,_0x5ce059,_0x251165,_0x2b5996,_0x5c0c74){if(Cn(_0x251165,_0x829113)!=null)return _0x11c0f5;const _0x1747f5=_0x11c0f5['serverCache']['isFiltered'](),_0x27aeb1=_0x11c0f5['serverCache'];if(_0x5ce059['value']!=null){if(v(_0x829113)&&_0x27aeb1['isFullyInitialized']()||_0x27aeb1['isCompleteForPath'](_0x829113))return Tn(_0x12f89d,_0x11c0f5,_0x829113,_0x27aeb1['getNode']()['getChild'](_0x829113),_0x251165,_0x2b5996,_0x1747f5,_0x5c0c74);if(v(_0x829113)){let _0x33c183=new b(null);return _0x27aeb1['getNode']()['forEachChild'](De,(_0x2df871,_0x5a1d19)=>{_0x33c183=_0x33c183['set'](new C(_0x2df871),_0x5a1d19);}),ki(_0x12f89d,_0x11c0f5,_0x829113,_0x33c183,_0x251165,_0x2b5996,_0x1747f5,_0x5c0c74);}else return _0x11c0f5;}else{let _0x5e0fe9=new b(null);return _0x5ce059['foreach']((_0x4ad25d,_0x3f0518)=>{const _0x5a0f7b=k(_0x829113,_0x4ad25d);_0x27aeb1['isCompleteForPath'](_0x5a0f7b)&&(_0x5e0fe9=_0x5e0fe9['set'](_0x4ad25d,_0x27aeb1['getNode']()['getChild'](_0x5a0f7b)));}),ki(_0x12f89d,_0x11c0f5,_0x829113,_0x5e0fe9,_0x251165,_0x2b5996,_0x1747f5,_0x5c0c74);}}function Ru(_0x3851af,_0xc791af,_0x4e413d,_0x534159,_0x14d875){const _0x8a7642=_0xc791af['serverCache'],_0x2f309a=xo(_0xc791af,_0x8a7642['getNode'](),_0x8a7642['isFullyInitialized']()||v(_0x4e413d),_0x8a7642['isFiltered']());return $o(_0x3851af,_0x2f309a,_0x4e413d,_0x534159,Ho,_0x14d875);}function Au(_0x3d48c3,_0x2933cd,_0x296a42,_0x19020b,_0x21b114,_0x13a4ba){let _0x224405;if(Cn(_0x19020b,_0x296a42)!=null)return _0x2933cd;{const _0x2bc297=new ss(_0x19020b,_0x2933cd,_0x21b114),_0x171d2f=_0x2933cd['eventCache']['getNode']();let _0x101fe3;if(v(_0x296a42)||y(_0x296a42)==='.priority'){let _0x14fd4e;if(_0x2933cd['serverCache']['isFullyInitialized']())_0x14fd4e=wn(_0x19020b,Be(_0x2933cd));else{const _0x4076e9=_0x2933cd['serverCache']['getNode']();f(_0x4076e9 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x14fd4e=ns(_0x19020b,_0x4076e9);}_0x14fd4e=_0x14fd4e,_0x101fe3=_0x3d48c3['filter']['updateFullNode'](_0x171d2f,_0x14fd4e,_0x13a4ba);}else{const _0x396bd5=y(_0x296a42);let _0x1842f4=is(_0x19020b,_0x396bd5,_0x2933cd['serverCache']);_0x1842f4==null&&_0x2933cd['serverCache']['isCompleteForChild'](_0x396bd5)&&(_0x1842f4=_0x171d2f['getImmediateChild'](_0x396bd5)),_0x1842f4!=null?_0x101fe3=_0x3d48c3['filter']['updateChild'](_0x171d2f,_0x396bd5,_0x1842f4,S(_0x296a42),_0x2bc297,_0x13a4ba):_0x2933cd['eventCache']['getNode']()['hasChild'](_0x396bd5)?_0x101fe3=_0x3d48c3['filter']['updateChild'](_0x171d2f,_0x396bd5,g['EMPTY_NODE'],S(_0x296a42),_0x2bc297,_0x13a4ba):_0x101fe3=_0x171d2f,_0x101fe3['isEmpty']()&&_0x2933cd['serverCache']['isFullyInitialized']()&&(_0x224405=wn(_0x19020b,Be(_0x2933cd)),_0x224405['isLeafNode']()&&(_0x101fe3=_0x3d48c3['filter']['updateFullNode'](_0x101fe3,_0x224405,_0x13a4ba)));}return _0x224405=_0x2933cd['serverCache']['isFullyInitialized']()||Cn(_0x19020b,w())!=null,bt(_0x2933cd,_0x101fe3,_0x224405,_0x3d48c3['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ku{constructor(_0x42984b,_0x36501b){this['query_']=_0x42984b,this['eventRegistrations_']=[];const _0x43fa21=this['query_']['_queryParams'],_0x51c4c2=new Ji(_0x43fa21['getIndex']()),_0x25189e=Gh(_0x43fa21);this['processor_']=Iu(_0x25189e);const _0x2dfe63=_0x36501b['serverCache'],_0x2b061c=_0x36501b['eventCache'],_0x25fba1=_0x51c4c2['updateFullNode'](g['EMPTY_NODE'],_0x2dfe63['getNode'](),null),_0x28deda=_0x25189e['updateFullNode'](g['EMPTY_NODE'],_0x2b061c['getNode'](),null),_0x340d9d=new Ce(_0x25fba1,_0x2dfe63['isFullyInitialized'](),_0x51c4c2['filtersNodes']()),_0x469a40=new Ce(_0x28deda,_0x2b061c['isFullyInitialized'](),_0x25189e['filtersNodes']());this['viewCache_']=Fn(_0x469a40,_0x340d9d),this['eventGenerator_']=new eu(this['query_']);}get['query'](){return this['query_'];}}function Nu(_0x59b3dd){return _0x59b3dd['viewCache_']['serverCache']['getNode']();}function Pu(_0x4115a8){return In(_0x4115a8['viewCache_']);}function Ou(_0x2dc85d,_0x41c839){const _0x536278=Be(_0x2dc85d['viewCache_']);return _0x536278&&(_0x2dc85d['query']['_queryParams']['loadsAllData']()||!v(_0x41c839)&&!_0x536278['getImmediateChild'](y(_0x41c839))['isEmpty']())?_0x536278['getChild'](_0x41c839):null;}function ur(_0x22b476){return _0x22b476['eventRegistrations_']['length']===0x0;}function Du(_0x236cf5,_0x370259){_0x236cf5['eventRegistrations_']['push'](_0x370259);}function dr(_0x2a11ef,_0x4cbdff,_0x230ce7){const _0x49ea44=[];if(_0x230ce7){f(_0x4cbdff==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0xe7fbbb=_0x2a11ef['query']['_path'];_0x2a11ef['eventRegistrations_']['forEach'](_0xf7769f=>{const _0x499362=_0xf7769f['createCancelEvent'](_0x230ce7,_0xe7fbbb);_0x499362&&_0x49ea44['push'](_0x499362);});}if(_0x4cbdff){let _0x76401c=[];for(let _0x2c74aa=0x0;_0x2c74aa<_0x2a11ef['eventRegistrations_']['length'];++_0x2c74aa){const _0x81fc15=_0x2a11ef['eventRegistrations_'][_0x2c74aa];if(!_0x81fc15['matches'](_0x4cbdff))_0x76401c['push'](_0x81fc15);else{if(_0x4cbdff['hasAnyCallback']()){_0x76401c=_0x76401c['concat'](_0x2a11ef['eventRegistrations_']['slice'](_0x2c74aa+0x1));break;}}}_0x2a11ef['eventRegistrations_']=_0x76401c;}else _0x2a11ef['eventRegistrations_']=[];return _0x49ea44;}function fr(_0x5913bc,_0x15c5a4,_0x39326a,_0x4f4f20){_0x15c5a4['type']===z['MERGE']&&_0x15c5a4['source']['queryId']!==null&&(f(Be(_0x5913bc['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(In(_0x5913bc['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x37d45c=_0x5913bc['viewCache_'],_0x5727e2=Cu(_0x5913bc['processor_'],_0x37d45c,_0x15c5a4,_0x39326a,_0x4f4f20);return wu(_0x5913bc['processor_'],_0x5727e2['viewCache']),f(_0x5727e2['viewCache']['serverCache']['isFullyInitialized']()||!_0x37d45c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5913bc['viewCache_']=_0x5727e2['viewCache'],Go(_0x5913bc,_0x5727e2['changes'],_0x5727e2['viewCache']['eventCache']['getNode'](),null);}function Mu(_0x4c1f67,_0x5460e0){const _0x86b403=_0x4c1f67['viewCache_']['eventCache'],_0x1ca3e3=[];return _0x86b403['getNode']()['isLeafNode']()||_0x86b403['getNode']()['forEachChild'](R,(_0x543596,_0x537852)=>{_0x1ca3e3['push'](st(_0x543596,_0x537852));}),_0x86b403['isFullyInitialized']()&&_0x1ca3e3['push'](Lo(_0x86b403['getNode']())),Go(_0x4c1f67,_0x1ca3e3,_0x86b403['getNode'](),_0x5460e0);}function Go(_0x22e843,_0x41291b,_0x2d6070,_0x1ec4f8){const _0x268133=_0x1ec4f8?[_0x1ec4f8]:_0x22e843['eventRegistrations_'];return tu(_0x22e843['eventGenerator_'],_0x41291b,_0x2d6070,_0x268133);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Sn;class qo{constructor(){this['views']=new Map();}}function Lu(_0x4c1257){f(!Sn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Sn=_0x4c1257;}function xu(){return f(Sn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Sn;}function Fu(_0x26feb1){return _0x26feb1['views']['size']===0x0;}function rs(_0x150591,_0x4865d8,_0x10d632,_0x518658){const _0x4796d3=_0x4865d8['source']['queryId'];if(_0x4796d3!==null){const _0x59ae92=_0x150591['views']['get'](_0x4796d3);return f(_0x59ae92!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x59ae92,_0x4865d8,_0x10d632,_0x518658);}else{let _0x2b4f55=[];for(const _0x41ffca of _0x150591['views']['values']())_0x2b4f55=_0x2b4f55['concat'](fr(_0x41ffca,_0x4865d8,_0x10d632,_0x518658));return _0x2b4f55;}}function zo(_0x25d0bf,_0x4a36f6,_0x29b2d3,_0x3797fd,_0x421756){const _0x3f5898=_0x4a36f6['_queryIdentifier'],_0x1fe00c=_0x25d0bf['views']['get'](_0x3f5898);if(!_0x1fe00c){let _0x502a08=wn(_0x29b2d3,_0x421756?_0x3797fd:null),_0x167a0b=!0x1;_0x502a08?_0x167a0b=!0x0:_0x3797fd instanceof g?(_0x502a08=ns(_0x29b2d3,_0x3797fd),_0x167a0b=!0x1):(_0x502a08=g['EMPTY_NODE'],_0x167a0b=!0x1);const _0x13490e=Fn(new Ce(_0x502a08,_0x167a0b,!0x1),new Ce(_0x3797fd,_0x421756,!0x1));return new ku(_0x4a36f6,_0x13490e);}return _0x1fe00c;}function Uu(_0x27c5e3,_0xddb422,_0xe8e47,_0x23e3bd,_0x2c6410,_0x29d8f){const _0x7e3cfa=zo(_0x27c5e3,_0xddb422,_0x23e3bd,_0x2c6410,_0x29d8f);return _0x27c5e3['views']['has'](_0xddb422['_queryIdentifier'])||_0x27c5e3['views']['set'](_0xddb422['_queryIdentifier'],_0x7e3cfa),Du(_0x7e3cfa,_0xe8e47),Mu(_0x7e3cfa,_0xe8e47);}function Wu(_0x7f15d,_0x580c3b,_0x748c44,_0x20ba9f){const _0x5a5883=_0x580c3b['_queryIdentifier'],_0x49a03a=[];let _0x3df94e=[];const _0x240773=Te(_0x7f15d);if(_0x5a5883==='default'){for(const [_0x190871,_0x1ec2dc]of _0x7f15d['views']['entries']())_0x3df94e=_0x3df94e['concat'](dr(_0x1ec2dc,_0x748c44,_0x20ba9f)),ur(_0x1ec2dc)&&(_0x7f15d['views']['delete'](_0x190871),_0x1ec2dc['query']['_queryParams']['loadsAllData']()||_0x49a03a['push'](_0x1ec2dc['query']));}else{const _0x5cf0ba=_0x7f15d['views']['get'](_0x5a5883);_0x5cf0ba&&(_0x3df94e=_0x3df94e['concat'](dr(_0x5cf0ba,_0x748c44,_0x20ba9f)),ur(_0x5cf0ba)&&(_0x7f15d['views']['delete'](_0x5a5883),_0x5cf0ba['query']['_queryParams']['loadsAllData']()||_0x49a03a['push'](_0x5cf0ba['query'])));}return _0x240773&&!Te(_0x7f15d)&&_0x49a03a['push'](new(xu())(_0x580c3b['_repo'],_0x580c3b['_path'])),{'removed':_0x49a03a,'events':_0x3df94e};}function jo(_0x3ec7ac){const _0x50cd3c=[];for(const _0x16a652 of _0x3ec7ac['views']['values']())_0x16a652['query']['_queryParams']['loadsAllData']()||_0x50cd3c['push'](_0x16a652);return _0x50cd3c;}function Ee(_0x474044,_0x3a00c2){let _0x285277=null;for(const _0x10b5b8 of _0x474044['views']['values']())_0x285277=_0x285277||Ou(_0x10b5b8,_0x3a00c2);return _0x285277;}function Ko(_0x275913,_0x533cba){if(_0x533cba['_queryParams']['loadsAllData']())return Wn(_0x275913);{const _0x12ea25=_0x533cba['_queryIdentifier'];return _0x275913['views']['get'](_0x12ea25);}}function Yo(_0xf7c9b9,_0x3ac6a8){return Ko(_0xf7c9b9,_0x3ac6a8)!=null;}function Te(_0x210edc){return Wn(_0x210edc)!=null;}function Wn(_0x43d0c1){for(const _0x883e16 of _0x43d0c1['views']['values']())if(_0x883e16['query']['_queryParams']['loadsAllData']())return _0x883e16;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;function Bu(_0x454114){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x454114;}function Vu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}let Hu=0x1;class pr{constructor(_0x2f22ff){this['listenProvider_']=_0x2f22ff,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=mu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4d9222,_0x58e0f1,_0xb3b55d,_0x25605a,_0x5cecdf){return ru(_0x4d9222['pendingWriteTree_'],_0x58e0f1,_0xb3b55d,_0x25605a,_0x5cecdf),_0x5cecdf?pt(_0x4d9222,new We(Zi(),_0x58e0f1,_0xb3b55d)):[];}function $u(_0x5a970e,_0x5d1368,_0x53c47d,_0x235ee9){ou(_0x5a970e['pendingWriteTree_'],_0x5d1368,_0x53c47d,_0x235ee9);const _0x51d96f=b['fromObject'](_0x53c47d);return pt(_0x5a970e,new rt(Zi(),_0x5d1368,_0x51d96f));}function _e(_0x479766,_0x389557,_0x3c0f4e=!0x1){const _0x547f3c=au(_0x479766['pendingWriteTree_'],_0x389557);if(cu(_0x479766['pendingWriteTree_'],_0x389557)){let _0x159571=new b(null);return _0x547f3c['snap']!=null?_0x159571=_0x159571['set'](w(),!0x0):x(_0x547f3c['children'],_0x139b58=>{_0x159571=_0x159571['set'](new C(_0x139b58),!0x0);}),pt(_0x479766,new En(_0x547f3c['path'],_0x159571,_0x3c0f4e));}else return[];}function Kt(_0x2f3713,_0x53fb75,_0x908bf2){return pt(_0x2f3713,new We(es(),_0x53fb75,_0x908bf2));}function Gu(_0x32371a,_0x251395,_0x9ff7d6){const _0x111135=b['fromObject'](_0x9ff7d6);return pt(_0x32371a,new rt(es(),_0x251395,_0x111135));}function qu(_0x3de8a9,_0x45e982){return pt(_0x3de8a9,new Ft(es(),_0x45e982));}function zu(_0x5b124e,_0x13c90b,_0x23b563){const _0x11f1dd=as(_0x5b124e,_0x23b563);if(_0x11f1dd){const _0x206c33=cs(_0x11f1dd),_0x199918=_0x206c33['path'],_0x98497c=_0x206c33['queryId'],_0xa39c5c=F(_0x199918,_0x13c90b),_0x5a4294=new Ft(ts(_0x98497c),_0xa39c5c);return ls(_0x5b124e,_0x199918,_0x5a4294);}else return[];}function Rn(_0x1ba160,_0x179761,_0x4c33a8,_0x2f0cfd,_0x4e134e=!0x1){const _0x3f37ac=_0x179761['_path'],_0xfb7243=_0x1ba160['syncPointTree_']['get'](_0x3f37ac);let _0x4623ab=[];if(_0xfb7243&&(_0x179761['_queryIdentifier']==='default'||Yo(_0xfb7243,_0x179761))){const _0x8a2cb9=Wu(_0xfb7243,_0x179761,_0x4c33a8,_0x2f0cfd);Fu(_0xfb7243)&&(_0x1ba160['syncPointTree_']=_0x1ba160['syncPointTree_']['remove'](_0x3f37ac));const _0x26e11a=_0x8a2cb9['removed'];if(_0x4623ab=_0x8a2cb9['events'],!_0x4e134e){const _0x6dcce1=_0x26e11a['findIndex'](_0x20341e=>_0x20341e['_queryParams']['loadsAllData']())!==-0x1,_0x45c2c0=_0x1ba160['syncPointTree_']['findOnPath'](_0x3f37ac,(_0x43206f,_0x190541)=>Te(_0x190541));if(_0x6dcce1&&!_0x45c2c0){const _0x3d4cf5=_0x1ba160['syncPointTree_']['subtree'](_0x3f37ac);if(!_0x3d4cf5['isEmpty']()){const _0x58916b=Yu(_0x3d4cf5);for(let _0x19f837=0x0;_0x19f837<_0x58916b['length'];++_0x19f837){const _0x53d1ce=_0x58916b[_0x19f837],_0xfb8591=_0x53d1ce['query'],_0x2113a3=Zo(_0x1ba160,_0x53d1ce);_0x1ba160['listenProvider_']['startListening'](At(_0xfb8591),Ut(_0x1ba160,_0xfb8591),_0x2113a3['hashFn'],_0x2113a3['onComplete']);}}}!_0x45c2c0&&_0x26e11a['length']>0x0&&!_0x2f0cfd&&(_0x6dcce1?_0x1ba160['listenProvider_']['stopListening'](At(_0x179761),null):_0x26e11a['forEach'](_0x11a712=>{const _0x2fde54=_0x1ba160['queryToTagMap']['get'](Vn(_0x11a712));_0x1ba160['listenProvider_']['stopListening'](At(_0x11a712),_0x2fde54);}));}Qu(_0x1ba160,_0x26e11a);}return _0x4623ab;}function Qo(_0x48bbdc,_0x53147e,_0x40d250,_0x4f511d){const _0x334ec2=as(_0x48bbdc,_0x4f511d);if(_0x334ec2!=null){const _0x2a861d=cs(_0x334ec2),_0x293c07=_0x2a861d['path'],_0xb52efb=_0x2a861d['queryId'],_0x17022f=F(_0x293c07,_0x53147e),_0x6c1979=new We(ts(_0xb52efb),_0x17022f,_0x40d250);return ls(_0x48bbdc,_0x293c07,_0x6c1979);}else return[];}function ju(_0x685109,_0x452f15,_0x430429,_0x1d6c20){const _0x3c879d=as(_0x685109,_0x1d6c20);if(_0x3c879d){const _0x1806ca=cs(_0x3c879d),_0x2ed482=_0x1806ca['path'],_0x5ee770=_0x1806ca['queryId'],_0x33c61=F(_0x2ed482,_0x452f15),_0x55543c=b['fromObject'](_0x430429),_0x2759dd=new rt(ts(_0x5ee770),_0x33c61,_0x55543c);return ls(_0x685109,_0x2ed482,_0x2759dd);}else return[];}function Ni(_0x554a1c,_0x53393d,_0x50f931,_0x249662=!0x1){const _0x46df32=_0x53393d['_path'];let _0x5e7e2e=null,_0x14db25=!0x1;_0x554a1c['syncPointTree_']['foreachOnPath'](_0x46df32,(_0x4ca293,_0x22cee8)=>{const _0x44443f=F(_0x4ca293,_0x46df32);_0x5e7e2e=_0x5e7e2e||Ee(_0x22cee8,_0x44443f),_0x14db25=_0x14db25||Te(_0x22cee8);});let _0x2bb864=_0x554a1c['syncPointTree_']['get'](_0x46df32);_0x2bb864?(_0x14db25=_0x14db25||Te(_0x2bb864),_0x5e7e2e=_0x5e7e2e||Ee(_0x2bb864,w())):(_0x2bb864=new qo(),_0x554a1c['syncPointTree_']=_0x554a1c['syncPointTree_']['set'](_0x46df32,_0x2bb864));let _0x2fdc37;_0x5e7e2e!=null?_0x2fdc37=!0x0:(_0x2fdc37=!0x1,_0x5e7e2e=g['EMPTY_NODE'],_0x554a1c['syncPointTree_']['subtree'](_0x46df32)['foreachChild']((_0xe4eb80,_0x4168d9)=>{const _0x37d788=Ee(_0x4168d9,w());_0x37d788&&(_0x5e7e2e=_0x5e7e2e['updateImmediateChild'](_0xe4eb80,_0x37d788));}));const _0xd11449=Yo(_0x2bb864,_0x53393d);if(!_0xd11449&&!_0x53393d['_queryParams']['loadsAllData']()){const _0x258c0b=Vn(_0x53393d);f(!_0x554a1c['queryToTagMap']['has'](_0x258c0b),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x267c82=Ju();_0x554a1c['queryToTagMap']['set'](_0x258c0b,_0x267c82),_0x554a1c['tagToQueryMap']['set'](_0x267c82,_0x258c0b);}const _0x34130d=Un(_0x554a1c['pendingWriteTree_'],_0x46df32);let _0x15ee39=Uu(_0x2bb864,_0x53393d,_0x50f931,_0x34130d,_0x5e7e2e,_0x2fdc37);if(!_0xd11449&&!_0x14db25&&!_0x249662){const _0xc05dc7=Ko(_0x2bb864,_0x53393d);_0x15ee39=_0x15ee39['concat'](Xu(_0x554a1c,_0x53393d,_0xc05dc7));}return _0x15ee39;}function Bn(_0x50938a,_0x1f19ac,_0x2c041b){const _0x3772ab=_0x50938a['pendingWriteTree_'],_0x9a77d=_0x50938a['syncPointTree_']['findOnPath'](_0x1f19ac,(_0x144231,_0x435a19)=>{const _0x5b4baf=F(_0x144231,_0x1f19ac),_0x397748=Ee(_0x435a19,_0x5b4baf);if(_0x397748)return _0x397748;});return Wo(_0x3772ab,_0x1f19ac,_0x9a77d,_0x2c041b,!0x0);}function Ku(_0x439b15,_0x2687e0){const _0x14c4b9=_0x2687e0['_path'];let _0x5e1cfe=null;_0x439b15['syncPointTree_']['foreachOnPath'](_0x14c4b9,(_0x5cdce1,_0x1ade6a)=>{const _0x21f5af=F(_0x5cdce1,_0x14c4b9);_0x5e1cfe=_0x5e1cfe||Ee(_0x1ade6a,_0x21f5af);});let _0x4edfdf=_0x439b15['syncPointTree_']['get'](_0x14c4b9);_0x4edfdf?_0x5e1cfe=_0x5e1cfe||Ee(_0x4edfdf,w()):(_0x4edfdf=new qo(),_0x439b15['syncPointTree_']=_0x439b15['syncPointTree_']['set'](_0x14c4b9,_0x4edfdf));const _0x13284a=_0x5e1cfe!=null,_0xc1f9a5=_0x13284a?new Ce(_0x5e1cfe,!0x0,!0x1):null,_0x39549c=Un(_0x439b15['pendingWriteTree_'],_0x2687e0['_path']),_0x2127ae=zo(_0x4edfdf,_0x2687e0,_0x39549c,_0x13284a?_0xc1f9a5['getNode']():g['EMPTY_NODE'],_0x13284a);return Pu(_0x2127ae);}function pt(_0x667059,_0x3e6bb5){return Jo(_0x3e6bb5,_0x667059['syncPointTree_'],null,Un(_0x667059['pendingWriteTree_'],w()));}function Jo(_0x168d71,_0xec1480,_0x5034e5,_0x12863e){if(v(_0x168d71['path']))return Xo(_0x168d71,_0xec1480,_0x5034e5,_0x12863e);{const _0xade18e=_0xec1480['get'](w());_0x5034e5==null&&_0xade18e!=null&&(_0x5034e5=Ee(_0xade18e,w()));let _0x1d4f1a=[];const _0x4d0636=y(_0x168d71['path']),_0x370258=_0x168d71['operationForChild'](_0x4d0636),_0x73f04a=_0xec1480['children']['get'](_0x4d0636);if(_0x73f04a&&_0x370258){const _0x412e7b=_0x5034e5?_0x5034e5['getImmediateChild'](_0x4d0636):null,_0x5630e2=Bo(_0x12863e,_0x4d0636);_0x1d4f1a=_0x1d4f1a['concat'](Jo(_0x370258,_0x73f04a,_0x412e7b,_0x5630e2));}return _0xade18e&&(_0x1d4f1a=_0x1d4f1a['concat'](rs(_0xade18e,_0x168d71,_0x12863e,_0x5034e5))),_0x1d4f1a;}}function Xo(_0x5bc8e8,_0x181fb1,_0x5a0ca9,_0x18c70e){const _0x5137a4=_0x181fb1['get'](w());_0x5a0ca9==null&&_0x5137a4!=null&&(_0x5a0ca9=Ee(_0x5137a4,w()));let _0x31973c=[];return _0x181fb1['children']['inorderTraversal']((_0x1b2fdd,_0x197fb7)=>{const _0x453d0d=_0x5a0ca9?_0x5a0ca9['getImmediateChild'](_0x1b2fdd):null,_0x80bf6f=Bo(_0x18c70e,_0x1b2fdd),_0x176517=_0x5bc8e8['operationForChild'](_0x1b2fdd);_0x176517&&(_0x31973c=_0x31973c['concat'](Xo(_0x176517,_0x197fb7,_0x453d0d,_0x80bf6f)));}),_0x5137a4&&(_0x31973c=_0x31973c['concat'](rs(_0x5137a4,_0x5bc8e8,_0x18c70e,_0x5a0ca9))),_0x31973c;}function Zo(_0x471131,_0x4c42d5){const _0x5c66ec=_0x4c42d5['query'],_0x324187=Ut(_0x471131,_0x5c66ec);return{'hashFn':()=>(Nu(_0x4c42d5)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1824dc=>{if(_0x1824dc==='ok')return _0x324187?zu(_0x471131,_0x5c66ec['_path'],_0x324187):qu(_0x471131,_0x5c66ec['_path']);{const _0x215112=Gl(_0x1824dc,_0x5c66ec);return Rn(_0x471131,_0x5c66ec,null,_0x215112);}}};}function Ut(_0xbe7256,_0x28cb27){const _0x32f8b0=Vn(_0x28cb27);return _0xbe7256['queryToTagMap']['get'](_0x32f8b0);}function Vn(_0x499ce4){return _0x499ce4['_path']['toString']()+'$'+_0x499ce4['_queryIdentifier'];}function as(_0x262b26,_0x16a28f){return _0x262b26['tagToQueryMap']['get'](_0x16a28f);}function cs(_0x5e68db){const _0x2ce809=_0x5e68db['indexOf']('$');return f(_0x2ce809!==-0x1&&_0x2ce809<_0x5e68db['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5e68db['substr'](_0x2ce809+0x1),'path':new C(_0x5e68db['substr'](0x0,_0x2ce809))};}function ls(_0x121dda,_0x53bdd0,_0x4ae466){const _0x103b5a=_0x121dda['syncPointTree_']['get'](_0x53bdd0);f(_0x103b5a,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x49f8b8=Un(_0x121dda['pendingWriteTree_'],_0x53bdd0);return rs(_0x103b5a,_0x4ae466,_0x49f8b8,null);}function Yu(_0x49a44c){return _0x49a44c['fold']((_0x4154d6,_0x1bb13d,_0x23638a)=>{if(_0x1bb13d&&Te(_0x1bb13d))return[Wn(_0x1bb13d)];{let _0x40de4f=[];return _0x1bb13d&&(_0x40de4f=jo(_0x1bb13d)),x(_0x23638a,(_0x21f0ca,_0x479b36)=>{_0x40de4f=_0x40de4f['concat'](_0x479b36);}),_0x40de4f;}});}function At(_0x43e55f){return _0x43e55f['_queryParams']['loadsAllData']()&&!_0x43e55f['_queryParams']['isDefault']()?new(Vu())(_0x43e55f['_repo'],_0x43e55f['_path']):_0x43e55f;}function Qu(_0x4d3834,_0x4c19e2){for(let _0x114f6f=0x0;_0x114f6f<_0x4c19e2['length'];++_0x114f6f){const _0x323d9d=_0x4c19e2[_0x114f6f];if(!_0x323d9d['_queryParams']['loadsAllData']()){const _0x552591=Vn(_0x323d9d),_0x56bf19=_0x4d3834['queryToTagMap']['get'](_0x552591);_0x4d3834['queryToTagMap']['delete'](_0x552591),_0x4d3834['tagToQueryMap']['delete'](_0x56bf19);}}}function Ju(){return Hu++;}function Xu(_0x5222a5,_0x123dec,_0x3159c8){const _0x163d4f=_0x123dec['_path'],_0x540cd9=Ut(_0x5222a5,_0x123dec),_0x4454e9=Zo(_0x5222a5,_0x3159c8),_0x9e16fd=_0x5222a5['listenProvider_']['startListening'](At(_0x123dec),_0x540cd9,_0x4454e9['hashFn'],_0x4454e9['onComplete']),_0x405d4a=_0x5222a5['syncPointTree_']['subtree'](_0x163d4f);if(_0x540cd9)f(!Te(_0x405d4a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x746c88=_0x405d4a['fold']((_0x210f71,_0xd6c838,_0xf2af5d)=>{if(!v(_0x210f71)&&_0xd6c838&&Te(_0xd6c838))return[Wn(_0xd6c838)['query']];{let _0xfbc376=[];return _0xd6c838&&(_0xfbc376=_0xfbc376['concat'](jo(_0xd6c838)['map'](_0x58efc3=>_0x58efc3['query']))),x(_0xf2af5d,(_0x1f46a2,_0x1590f8)=>{_0xfbc376=_0xfbc376['concat'](_0x1590f8);}),_0xfbc376;}});for(let _0x5f12df=0x0;_0x5f12df<_0x746c88['length'];++_0x5f12df){const _0x460a1c=_0x746c88[_0x5f12df];_0x5222a5['listenProvider_']['stopListening'](At(_0x460a1c),Ut(_0x5222a5,_0x460a1c));}}return _0x9e16fd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x577c14){this['node_']=_0x577c14;}['getImmediateChild'](_0x44de65){const _0xd035e1=this['node_']['getImmediateChild'](_0x44de65);return new hs(_0xd035e1);}['node'](){return this['node_'];}}class us{constructor(_0x284725,_0x4c04e6){this['syncTree_']=_0x284725,this['path_']=_0x4c04e6;}['getImmediateChild'](_0x3ee5ab){const _0x554c59=k(this['path_'],_0x3ee5ab);return new us(this['syncTree_'],_0x554c59);}['node'](){return Bn(this['syncTree_'],this['path_']);}}const Zu=function(_0x4b62b2){return _0x4b62b2=_0x4b62b2||{},_0x4b62b2['timestamp']=_0x4b62b2['timestamp']||new Date()['getTime'](),_0x4b62b2;},_r=function(_0x1f6aaf,_0x372d28,_0x31664b){if(!_0x1f6aaf||typeof _0x1f6aaf!='object')return _0x1f6aaf;if(f('.sv'in _0x1f6aaf,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1f6aaf['.sv']=='string')return ed(_0x1f6aaf['.sv'],_0x372d28,_0x31664b);if(typeof _0x1f6aaf['.sv']=='object')return td(_0x1f6aaf['.sv'],_0x372d28);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1f6aaf,null,0x2));},ed=function(_0x42447d,_0x1c6760,_0x48a3c0){switch(_0x42447d){case'timestamp':return _0x48a3c0['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x42447d);}},td=function(_0x4c7ea9,_0x57307f,_0x48ac50){_0x4c7ea9['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4c7ea9,null,0x2));const _0x4ba90a=_0x4c7ea9['increment'];typeof _0x4ba90a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4ba90a);const _0x25ec8b=_0x57307f['node']();if(f(_0x25ec8b!==null&&typeof _0x25ec8b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x25ec8b['isLeafNode']())return _0x4ba90a;const _0x51562a=_0x25ec8b['getValue']();return typeof _0x51562a!='number'?_0x4ba90a:_0x51562a+_0x4ba90a;},ea=function(_0x245323,_0x63a7e1,_0x4217c1,_0x2d7912){return fs(_0x63a7e1,new us(_0x4217c1,_0x245323),_0x2d7912);},ds=function(_0x2cd0d2,_0x467d69,_0x5160ed){return fs(_0x2cd0d2,new hs(_0x467d69),_0x5160ed);};function fs(_0xce0cb9,_0x5cf0fc,_0x3ef8a4){const _0x425ccf=_0xce0cb9['getPriority']()['val'](),_0x19729a=_r(_0x425ccf,_0x5cf0fc['getImmediateChild']('.priority'),_0x3ef8a4);let _0x344c7d;if(_0xce0cb9['isLeafNode']()){const _0x290b16=_0xce0cb9,_0x5a9a1d=_r(_0x290b16['getValue'](),_0x5cf0fc,_0x3ef8a4);return _0x5a9a1d!==_0x290b16['getValue']()||_0x19729a!==_0x290b16['getPriority']()['val']()?new D(_0x5a9a1d,A(_0x19729a)):_0xce0cb9;}else{const _0x3a282f=_0xce0cb9;return _0x344c7d=_0x3a282f,_0x19729a!==_0x3a282f['getPriority']()['val']()&&(_0x344c7d=_0x344c7d['updatePriority'](new D(_0x19729a))),_0x3a282f['forEachChild'](R,(_0x347c94,_0x3c8479)=>{const _0x17f7c8=fs(_0x3c8479,_0x5cf0fc['getImmediateChild'](_0x347c94),_0x3ef8a4);_0x17f7c8!==_0x3c8479&&(_0x344c7d=_0x344c7d['updateImmediateChild'](_0x347c94,_0x17f7c8));}),_0x344c7d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x22c683='',_0x2f00a0=null,_0x4cc7e3={'children':{},'childCount':0x0}){this['name']=_0x22c683,this['parent']=_0x2f00a0,this['node']=_0x4cc7e3;}}function Hn(_0x4bf4f0,_0xa7b051){let _0x677a9=_0xa7b051 instanceof C?_0xa7b051:new C(_0xa7b051),_0x677809=_0x4bf4f0,_0x318666=y(_0x677a9);for(;_0x318666!==null;){const _0x5a594a=Me(_0x677809['node']['children'],_0x318666)||{'children':{},'childCount':0x0};_0x677809=new ps(_0x318666,_0x677809,_0x5a594a),_0x677a9=S(_0x677a9),_0x318666=y(_0x677a9);}return _0x677809;}function ze(_0x1e49c3){return _0x1e49c3['node']['value'];}function _s(_0x10a152,_0x51eb7b){_0x10a152['node']['value']=_0x51eb7b,Pi(_0x10a152);}function ta(_0x1988ed){return _0x1988ed['node']['childCount']>0x0;}function nd(_0xd9f28a){return ze(_0xd9f28a)===void 0x0&&!ta(_0xd9f28a);}function $n(_0x47b55c,_0x4938a5){x(_0x47b55c['node']['children'],(_0x3de453,_0x1a7a34)=>{_0x4938a5(new ps(_0x3de453,_0x47b55c,_0x1a7a34));});}function na(_0x2f054a,_0x13bd59,_0x27b72a,_0x13f23a){_0x27b72a&&_0x13bd59(_0x2f054a),$n(_0x2f054a,_0x10b121=>{na(_0x10b121,_0x13bd59,!0x0);});}function id(_0xb3eaf3,_0x18b57a,_0xc5f33d){let _0x1fcebc=_0xb3eaf3['parent'];for(;_0x1fcebc!==null;){if(_0x18b57a(_0x1fcebc))return!0x0;_0x1fcebc=_0x1fcebc['parent'];}return!0x1;}function Yt(_0x3410d7){return new C(_0x3410d7['parent']===null?_0x3410d7['name']:Yt(_0x3410d7['parent'])+'/'+_0x3410d7['name']);}function Pi(_0x33715c){_0x33715c['parent']!==null&&sd(_0x33715c['parent'],_0x33715c['name'],_0x33715c);}function sd(_0x4e68f6,_0x39db42,_0x4f3e6d){const _0x56d1d6=nd(_0x4f3e6d),_0x159fae=Q(_0x4e68f6['node']['children'],_0x39db42);_0x56d1d6&&_0x159fae?(delete _0x4e68f6['node']['children'][_0x39db42],_0x4e68f6['node']['childCount']--,Pi(_0x4e68f6)):!_0x56d1d6&&!_0x159fae&&(_0x4e68f6['node']['children'][_0x39db42]=_0x4f3e6d['node'],_0x4e68f6['node']['childCount']++,Pi(_0x4e68f6));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rd=/[\[\].#$\/\u0000-\u001F\u007F]/,od=/[\[\].#$\u0000-\u001F\u007F]/,hi=0xa*0x400*0x400,gs=function(_0x52d0d2){return typeof _0x52d0d2=='string'&&_0x52d0d2['length']!==0x0&&!rd['test'](_0x52d0d2);},ia=function(_0x1b1f96){return typeof _0x1b1f96=='string'&&_0x1b1f96['length']!==0x0&&!od['test'](_0x1b1f96);},ad=function(_0x214ffe){return _0x214ffe&&(_0x214ffe=_0x214ffe['replace'](/^\/*\.info(\/|$)/,'/')),ia(_0x214ffe);},Wt=function(_0x5b4f21){return _0x5b4f21===null||typeof _0x5b4f21=='string'||typeof _0x5b4f21=='number'&&!Ln(_0x5b4f21)||_0x5b4f21&&typeof _0x5b4f21=='object'&&Q(_0x5b4f21,'.sv');},Ve=function(_0xd1bb7b,_0x3844fa,_0x484807,_0x362cbc){_0x362cbc&&_0x3844fa===void 0x0||Qt(nt(_0xd1bb7b,'value'),_0x3844fa,_0x484807);},Qt=function(_0x2674b4,_0x4975c3,_0xc637f1){const _0x54ee22=_0xc637f1 instanceof C?new Th(_0xc637f1,_0x2674b4):_0xc637f1;if(_0x4975c3===void 0x0)throw new Error(_0x2674b4+'contains\x20undefined\x20'+Ne(_0x54ee22));if(typeof _0x4975c3=='function')throw new Error(_0x2674b4+'contains\x20a\x20function\x20'+Ne(_0x54ee22)+'\x20with\x20contents\x20=\x20'+_0x4975c3['toString']());if(Ln(_0x4975c3))throw new Error(_0x2674b4+'contains\x20'+_0x4975c3['toString']()+'\x20'+Ne(_0x54ee22));if(typeof _0x4975c3=='string'&&_0x4975c3['length']>hi/0x3&&Mn(_0x4975c3)>hi)throw new Error(_0x2674b4+'contains\x20a\x20string\x20greater\x20than\x20'+hi+'\x20utf8\x20bytes\x20'+Ne(_0x54ee22)+'\x20(\x27'+_0x4975c3['substring'](0x0,0x32)+'...\x27)');if(_0x4975c3&&typeof _0x4975c3=='object'){let _0x2523f2=!0x1,_0x4f5427=!0x1;if(x(_0x4975c3,(_0x1a9cf8,_0x4c7586)=>{if(_0x1a9cf8==='.value')_0x2523f2=!0x0;else{if(_0x1a9cf8!=='.priority'&&_0x1a9cf8!=='.sv'&&(_0x4f5427=!0x0,!gs(_0x1a9cf8)))throw new Error(_0x2674b4+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1a9cf8+')\x20'+Ne(_0x54ee22)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}Sh(_0x54ee22,_0x1a9cf8),Qt(_0x2674b4,_0x4c7586,_0x54ee22),bh(_0x54ee22);}),_0x2523f2&&_0x4f5427)throw new Error(_0x2674b4+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x54ee22)+'\x20in\x20addition\x20to\x20actual\x20children.');}},cd=function(_0x5f2635,_0x4aa6d3){let _0x3a780d,_0x443c4b;for(_0x3a780d=0x0;_0x3a780d<_0x4aa6d3['length'];_0x3a780d++){_0x443c4b=_0x4aa6d3[_0x3a780d];const _0x5b2cb7=Dt(_0x443c4b);for(let _0x61d58e=0x0;_0x61d58e<_0x5b2cb7['length'];_0x61d58e++)if(!(_0x5b2cb7[_0x61d58e]==='.priority'&&_0x61d58e===_0x5b2cb7['length']-0x1)){if(!gs(_0x5b2cb7[_0x61d58e]))throw new Error(_0x5f2635+'contains\x20an\x20invalid\x20key\x20('+_0x5b2cb7[_0x61d58e]+')\x20in\x20path\x20'+_0x443c4b['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4aa6d3['sort'](Ch);let _0x1d56de=null;for(_0x3a780d=0x0;_0x3a780d<_0x4aa6d3['length'];_0x3a780d++){if(_0x443c4b=_0x4aa6d3[_0x3a780d],_0x1d56de!==null&&G(_0x1d56de,_0x443c4b))throw new Error(_0x5f2635+'contains\x20a\x20path\x20'+_0x1d56de['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x443c4b['toString']());_0x1d56de=_0x443c4b;}},sa=function(_0x2e765d,_0x42c83e,_0x56627f,_0x40768b){const _0x4a8c0e=nt(_0x2e765d,'values');if(!(_0x42c83e&&typeof _0x42c83e=='object')||Array['isArray'](_0x42c83e))throw new Error(_0x4a8c0e+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2a6307=[];x(_0x42c83e,(_0x2a1707,_0x4ec358)=>{const _0x3b0371=new C(_0x2a1707);if(Qt(_0x4a8c0e,_0x4ec358,k(_0x56627f,_0x3b0371)),zi(_0x3b0371)==='.priority'&&!Wt(_0x4ec358))throw new Error(_0x4a8c0e+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3b0371['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2a6307['push'](_0x3b0371);}),cd(_0x4a8c0e,_0x2a6307);},ld=function(_0x3f92f5,_0x20d4d9,_0x72c640){if(Ln(_0x20d4d9))throw new Error(nt(_0x3f92f5,'priority')+'is\x20'+_0x20d4d9['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x20d4d9))throw new Error(nt(_0x3f92f5,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ms=function(_0x5ccbc7,_0x274e3d,_0x1c13d1,_0x1e99d4){if(!ia(_0x1c13d1))throw new Error(nt(_0x5ccbc7,_0x274e3d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1c13d1+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},hd=function(_0x45aea7,_0x35d646,_0x1c3f8f,_0x2ad19f){_0x1c3f8f&&(_0x1c3f8f=_0x1c3f8f['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x45aea7,_0x35d646,_0x1c3f8f);},Oe=function(_0x1f0c66,_0x23a800){if(y(_0x23a800)==='.info')throw new Error(_0x1f0c66+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},ud=function(_0x37e39f,_0x54008f){const _0x22e1e1=_0x54008f['path']['toString']();if(typeof _0x54008f['repoInfo']['host']!='string'||_0x54008f['repoInfo']['host']['length']===0x0||!gs(_0x54008f['repoInfo']['namespace'])&&_0x54008f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x22e1e1['length']!==0x0&&!ad(_0x22e1e1))throw new Error(nt(_0x37e39f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Gn(_0x3f7194,_0x2113e8){let _0x38a172=null;for(let _0xb5f29d=0x0;_0xb5f29d<_0x2113e8['length'];_0xb5f29d++){const _0x2d830f=_0x2113e8[_0xb5f29d],_0x551751=_0x2d830f['getPath']();_0x38a172!==null&&!ji(_0x551751,_0x38a172['path'])&&(_0x3f7194['eventLists_']['push'](_0x38a172),_0x38a172=null),_0x38a172===null&&(_0x38a172={'events':[],'path':_0x551751}),_0x38a172['events']['push'](_0x2d830f);}_0x38a172&&_0x3f7194['eventLists_']['push'](_0x38a172);}function ra(_0x36b3d4,_0x44c80e,_0x2e4b1f){Gn(_0x36b3d4,_0x2e4b1f),oa(_0x36b3d4,_0x4b40b1=>ji(_0x4b40b1,_0x44c80e));}function V(_0x1ad5ec,_0x2525a7,_0x54b87e){Gn(_0x1ad5ec,_0x54b87e),oa(_0x1ad5ec,_0x22b632=>G(_0x22b632,_0x2525a7)||G(_0x2525a7,_0x22b632));}function oa(_0x18515f,_0xff3b46){_0x18515f['recursionDepth_']++;let _0x19c76a=!0x0;for(let _0x504a0d=0x0;_0x504a0d<_0x18515f['eventLists_']['length'];_0x504a0d++){const _0x40c0ba=_0x18515f['eventLists_'][_0x504a0d];if(_0x40c0ba){const _0x252752=_0x40c0ba['path'];_0xff3b46(_0x252752)?(fd(_0x18515f['eventLists_'][_0x504a0d]),_0x18515f['eventLists_'][_0x504a0d]=null):_0x19c76a=!0x1;}}_0x19c76a&&(_0x18515f['eventLists_']=[]),_0x18515f['recursionDepth_']--;}function fd(_0x8880b1){for(let _0x5404b3=0x0;_0x5404b3<_0x8880b1['events']['length'];_0x5404b3++){const _0x7a3601=_0x8880b1['events'][_0x5404b3];if(_0x7a3601!==null){_0x8880b1['events'][_0x5404b3]=null;const _0x9d0290=_0x7a3601['getEventRunner']();Tt&&L('event:\x20'+_0x7a3601['toString']()),dt(_0x9d0290);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const aa='repo_interrupt',pd=0x19;class _d{constructor(_0x3a999b,_0x3bdf46,_0x38b655,_0x2e7b63){this['repoInfo_']=_0x3a999b,this['forceRestClient_']=_0x3bdf46,this['authTokenProvider_']=_0x38b655,this['appCheckProvider_']=_0x2e7b63,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new dd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=vn(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function gd(_0x4e6a51,_0x53a115,_0x5b520e){if(_0x4e6a51['stats_']=Gi(_0x4e6a51['repoInfo_']),_0x4e6a51['forceRestClient_']||Kl())_0x4e6a51['server_']=new yn(_0x4e6a51['repoInfo_'],(_0x268323,_0x19817e,_0x28edf0,_0x157872)=>{gr(_0x4e6a51,_0x268323,_0x19817e,_0x28edf0,_0x157872);},_0x4e6a51['authTokenProvider_'],_0x4e6a51['appCheckProvider_']),setTimeout(()=>mr(_0x4e6a51,!0x0),0x0);else{if(typeof _0x5b520e<'u'&&_0x5b520e!==null){if(typeof _0x5b520e!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5b520e);}catch(_0x5d46f8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5d46f8);}}_0x4e6a51['persistentConnection_']=new se(_0x4e6a51['repoInfo_'],_0x53a115,(_0x2f1f0a,_0x1fd2a2,_0x464e68,_0x31f910)=>{gr(_0x4e6a51,_0x2f1f0a,_0x1fd2a2,_0x464e68,_0x31f910);},_0x52d4ca=>{mr(_0x4e6a51,_0x52d4ca);},_0x306ed9=>{md(_0x4e6a51,_0x306ed9);},_0x4e6a51['authTokenProvider_'],_0x4e6a51['appCheckProvider_'],_0x5b520e),_0x4e6a51['server_']=_0x4e6a51['persistentConnection_'];}_0x4e6a51['authTokenProvider_']['addTokenChangeListener'](_0x582b56=>{_0x4e6a51['server_']['refreshAuthToken'](_0x582b56);}),_0x4e6a51['appCheckProvider_']['addTokenChangeListener'](_0x284a83=>{_0x4e6a51['server_']['refreshAppCheckToken'](_0x284a83['token']);}),_0x4e6a51['statsReporter_']=Zl(_0x4e6a51['repoInfo_'],()=>new Zh(_0x4e6a51['stats_'],_0x4e6a51['server_'])),_0x4e6a51['infoData_']=new Kh(),_0x4e6a51['infoSyncTree_']=new pr({'startListening':(_0x1abf72,_0x1c72ca,_0x477208,_0x526675)=>{let _0x108476=[];const _0x2f8f57=_0x4e6a51['infoData_']['getNode'](_0x1abf72['_path']);return _0x2f8f57['isEmpty']()||(_0x108476=Kt(_0x4e6a51['infoSyncTree_'],_0x1abf72['_path'],_0x2f8f57),setTimeout(()=>{_0x526675('ok');},0x0)),_0x108476;},'stopListening':()=>{}}),ys(_0x4e6a51,'connected',!0x1),_0x4e6a51['serverSyncTree_']=new pr({'startListening':(_0x3dc484,_0x3d2c7e,_0x300f6c,_0x1c3386)=>(_0x4e6a51['server_']['listen'](_0x3dc484,_0x300f6c,_0x3d2c7e,(_0x535d85,_0x3841e1)=>{const _0xa16afe=_0x1c3386(_0x535d85,_0x3841e1);V(_0x4e6a51['eventQueue_'],_0x3dc484['_path'],_0xa16afe);}),[]),'stopListening':(_0x3cb25f,_0x85aa0e)=>{_0x4e6a51['server_']['unlisten'](_0x3cb25f,_0x85aa0e);}});}function ca(_0x45915c){const _0x25a241=_0x45915c['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x25a241;}function Jt(_0x3a41f6){return Zu({'timestamp':ca(_0x3a41f6)});}function gr(_0x262cd3,_0x242d0c,_0x1f0a4e,_0x2c814e,_0x5ece66){_0x262cd3['dataUpdateCount']++;const _0x3d171a=new C(_0x242d0c);_0x1f0a4e=_0x262cd3['interceptServerDataCallback_']?_0x262cd3['interceptServerDataCallback_'](_0x242d0c,_0x1f0a4e):_0x1f0a4e;let _0x558f10=[];if(_0x5ece66){if(_0x2c814e){const _0x5cc1e6=pn(_0x1f0a4e,_0x116686=>A(_0x116686));_0x558f10=ju(_0x262cd3['serverSyncTree_'],_0x3d171a,_0x5cc1e6,_0x5ece66);}else{const _0x302334=A(_0x1f0a4e);_0x558f10=Qo(_0x262cd3['serverSyncTree_'],_0x3d171a,_0x302334,_0x5ece66);}}else{if(_0x2c814e){const _0x54a459=pn(_0x1f0a4e,_0x352cf1=>A(_0x352cf1));_0x558f10=Gu(_0x262cd3['serverSyncTree_'],_0x3d171a,_0x54a459);}else{const _0x5591cd=A(_0x1f0a4e);_0x558f10=Kt(_0x262cd3['serverSyncTree_'],_0x3d171a,_0x5591cd);}}let _0x38c89c=_0x3d171a;_0x558f10['length']>0x0&&(_0x38c89c=at(_0x262cd3,_0x3d171a)),V(_0x262cd3['eventQueue_'],_0x38c89c,_0x558f10);}function mr(_0x2b6d17,_0x5b1d62){ys(_0x2b6d17,'connected',_0x5b1d62),_0x5b1d62===!0x1&&Id(_0x2b6d17);}function md(_0x18511c,_0x3702d2){x(_0x3702d2,(_0x3363a3,_0x4e5300)=>{ys(_0x18511c,_0x3363a3,_0x4e5300);});}function ys(_0x3323a5,_0x541871,_0x2aa116){const _0x54736f=new C('/.info/'+_0x541871),_0x439c8d=A(_0x2aa116);_0x3323a5['infoData_']['updateSnapshot'](_0x54736f,_0x439c8d);const _0x2d4aa5=Kt(_0x3323a5['infoSyncTree_'],_0x54736f,_0x439c8d);V(_0x3323a5['eventQueue_'],_0x54736f,_0x2d4aa5);}function qn(_0x187653){return _0x187653['nextWriteId_']++;}function yd(_0xf4ebed,_0x1b662c,_0x2991bc){const _0x205880=Ku(_0xf4ebed['serverSyncTree_'],_0x1b662c);return _0x205880!=null?Promise['resolve'](_0x205880):_0xf4ebed['server_']['get'](_0x1b662c)['then'](_0x445e34=>{const _0x251064=A(_0x445e34)['withIndex'](_0x1b662c['_queryParams']['getIndex']());Ni(_0xf4ebed['serverSyncTree_'],_0x1b662c,_0x2991bc,!0x0);let _0x31fbfe;if(_0x1b662c['_queryParams']['loadsAllData']())_0x31fbfe=Kt(_0xf4ebed['serverSyncTree_'],_0x1b662c['_path'],_0x251064);else{const _0x25c60d=Ut(_0xf4ebed['serverSyncTree_'],_0x1b662c);_0x31fbfe=Qo(_0xf4ebed['serverSyncTree_'],_0x1b662c['_path'],_0x251064,_0x25c60d);}return V(_0xf4ebed['eventQueue_'],_0x1b662c['_path'],_0x31fbfe),Rn(_0xf4ebed['serverSyncTree_'],_0x1b662c,_0x2991bc,null,!0x0),_0x251064;},_0x123220=>(_t(_0xf4ebed,'get\x20for\x20query\x20'+O(_0x1b662c)+'\x20failed:\x20'+_0x123220),Promise['reject'](new Error(_0x123220))));}function vd(_0x3f784d,_0x5cd096,_0x38524a,_0x5353c1,_0x1257f3){_t(_0x3f784d,'set',{'path':_0x5cd096['toString'](),'value':_0x38524a,'priority':_0x5353c1});const _0x68ef7f=Jt(_0x3f784d),_0x214ba4=A(_0x38524a,_0x5353c1),_0x2b8d3e=Bn(_0x3f784d['serverSyncTree_'],_0x5cd096),_0x27f7f7=ds(_0x214ba4,_0x2b8d3e,_0x68ef7f),_0x2f4c1f=qn(_0x3f784d),_0x2c0159=os(_0x3f784d['serverSyncTree_'],_0x5cd096,_0x27f7f7,_0x2f4c1f,!0x0);Gn(_0x3f784d['eventQueue_'],_0x2c0159),_0x3f784d['server_']['put'](_0x5cd096['toString'](),_0x214ba4['val'](!0x0),(_0x1c5fd3,_0x52e9bd)=>{const _0x24e8d2=_0x1c5fd3==='ok';_0x24e8d2||U('set\x20at\x20'+_0x5cd096+'\x20failed:\x20'+_0x1c5fd3);const _0x44445b=_e(_0x3f784d['serverSyncTree_'],_0x2f4c1f,!_0x24e8d2);V(_0x3f784d['eventQueue_'],_0x5cd096,_0x44445b),Se(_0x3f784d,_0x1257f3,_0x1c5fd3,_0x52e9bd);});const _0x5ae830=Es(_0x3f784d,_0x5cd096);at(_0x3f784d,_0x5ae830),V(_0x3f784d['eventQueue_'],_0x5ae830,[]);}function Ed(_0xe73329,_0x27cbaa,_0x4b151f,_0x4c8eac){_t(_0xe73329,'update',{'path':_0x27cbaa['toString'](),'value':_0x4b151f});let _0x2afadc=!0x0;const _0x13ffce=Jt(_0xe73329),_0x43ba1e={};if(x(_0x4b151f,(_0xe813c2,_0xe3033a)=>{_0x2afadc=!0x1,_0x43ba1e[_0xe813c2]=ea(k(_0x27cbaa,_0xe813c2),A(_0xe3033a),_0xe73329['serverSyncTree_'],_0x13ffce);}),_0x2afadc)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0xe73329,_0x4c8eac,'ok',void 0x0);else{const _0x2c3c21=qn(_0xe73329),_0x17b2dc=$u(_0xe73329['serverSyncTree_'],_0x27cbaa,_0x43ba1e,_0x2c3c21);Gn(_0xe73329['eventQueue_'],_0x17b2dc),_0xe73329['server_']['merge'](_0x27cbaa['toString'](),_0x4b151f,(_0x17c404,_0x5750fd)=>{const _0x2edcfb=_0x17c404==='ok';_0x2edcfb||U('update\x20at\x20'+_0x27cbaa+'\x20failed:\x20'+_0x17c404);const _0x5d7295=_e(_0xe73329['serverSyncTree_'],_0x2c3c21,!_0x2edcfb),_0x58443f=_0x5d7295['length']>0x0?at(_0xe73329,_0x27cbaa):_0x27cbaa;V(_0xe73329['eventQueue_'],_0x58443f,_0x5d7295),Se(_0xe73329,_0x4c8eac,_0x17c404,_0x5750fd);}),x(_0x4b151f,_0x1921c7=>{const _0x5e72bf=Es(_0xe73329,k(_0x27cbaa,_0x1921c7));at(_0xe73329,_0x5e72bf);}),V(_0xe73329['eventQueue_'],_0x27cbaa,[]);}}function Id(_0x16b509){_t(_0x16b509,'onDisconnectEvents');const _0x4d604b=Jt(_0x16b509),_0xbb1c8f=vn();Ti(_0x16b509['onDisconnect_'],w(),(_0x1c4d4a,_0x5a9b9b)=>{const _0x3792cc=ea(_0x1c4d4a,_0x5a9b9b,_0x16b509['serverSyncTree_'],_0x4d604b);ft(_0xbb1c8f,_0x1c4d4a,_0x3792cc);});let _0x57a2d1=[];Ti(_0xbb1c8f,w(),(_0x4f3eb4,_0x4f7a3b)=>{_0x57a2d1=_0x57a2d1['concat'](Kt(_0x16b509['serverSyncTree_'],_0x4f3eb4,_0x4f7a3b));const _0x464e07=Es(_0x16b509,_0x4f3eb4);at(_0x16b509,_0x464e07);}),_0x16b509['onDisconnect_']=vn(),V(_0x16b509['eventQueue_'],w(),_0x57a2d1);}function wd(_0x4cdc1e,_0x264628,_0x16ce9a){_0x4cdc1e['server_']['onDisconnectCancel'](_0x264628['toString'](),(_0x461270,_0x492d78)=>{_0x461270==='ok'&&Ci(_0x4cdc1e['onDisconnect_'],_0x264628),Se(_0x4cdc1e,_0x16ce9a,_0x461270,_0x492d78);});}function yr(_0x39d73a,_0x4d73b4,_0xd50c18,_0x4ba511){const _0x50d07c=A(_0xd50c18);_0x39d73a['server_']['onDisconnectPut'](_0x4d73b4['toString'](),_0x50d07c['val'](!0x0),(_0x2369eb,_0x59e88b)=>{_0x2369eb==='ok'&&ft(_0x39d73a['onDisconnect_'],_0x4d73b4,_0x50d07c),Se(_0x39d73a,_0x4ba511,_0x2369eb,_0x59e88b);});}function Cd(_0x5a89e0,_0x5e972d,_0x5aa773,_0x5aacae,_0x435c66){const _0x110806=A(_0x5aa773,_0x5aacae);_0x5a89e0['server_']['onDisconnectPut'](_0x5e972d['toString'](),_0x110806['val'](!0x0),(_0x8e8d8d,_0x5882b8)=>{_0x8e8d8d==='ok'&&ft(_0x5a89e0['onDisconnect_'],_0x5e972d,_0x110806),Se(_0x5a89e0,_0x435c66,_0x8e8d8d,_0x5882b8);});}function Td(_0x135427,_0x2b71d8,_0x363566,_0x385dd8){if(fn(_0x363566)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0x135427,_0x385dd8,'ok',void 0x0);return;}_0x135427['server_']['onDisconnectMerge'](_0x2b71d8['toString'](),_0x363566,(_0x4b5744,_0x1f6d99)=>{_0x4b5744==='ok'&&x(_0x363566,(_0x57c22b,_0x56c6c0)=>{const _0x47ddd1=A(_0x56c6c0);ft(_0x135427['onDisconnect_'],k(_0x2b71d8,_0x57c22b),_0x47ddd1);}),Se(_0x135427,_0x385dd8,_0x4b5744,_0x1f6d99);});}function Sd(_0x2e546c,_0x30d356,_0x4b2472){let _0x43c31a;y(_0x30d356['_path'])==='.info'?_0x43c31a=Ni(_0x2e546c['infoSyncTree_'],_0x30d356,_0x4b2472):_0x43c31a=Ni(_0x2e546c['serverSyncTree_'],_0x30d356,_0x4b2472),ra(_0x2e546c['eventQueue_'],_0x30d356['_path'],_0x43c31a);}function bd(_0x585e47,_0x102efb,_0x4d7a5c){let _0x5816be;y(_0x102efb['_path'])==='.info'?_0x5816be=Rn(_0x585e47['infoSyncTree_'],_0x102efb,_0x4d7a5c):_0x5816be=Rn(_0x585e47['serverSyncTree_'],_0x102efb,_0x4d7a5c),ra(_0x585e47['eventQueue_'],_0x102efb['_path'],_0x5816be);}function la(_0x2cd48f){_0x2cd48f['persistentConnection_']&&_0x2cd48f['persistentConnection_']['interrupt'](aa);}function Rd(_0x3c1c2c){_0x3c1c2c['persistentConnection_']&&_0x3c1c2c['persistentConnection_']['resume'](aa);}function _t(_0x3f392b,..._0x22c466){let _0x2fd031='';_0x3f392b['persistentConnection_']&&(_0x2fd031=_0x3f392b['persistentConnection_']['id']+':'),L(_0x2fd031,..._0x22c466);}function Se(_0x2ff36b,_0x5d2b53,_0x5c945a,_0xe0f99e){_0x5d2b53&&dt(()=>{if(_0x5c945a==='ok')_0x5d2b53(null);else{const _0x4d888b=(_0x5c945a||'error')['toUpperCase']();let _0x31942d=_0x4d888b;_0xe0f99e&&(_0x31942d+=':\x20'+_0xe0f99e);const _0x2ffcb5=new Error(_0x31942d);_0x2ffcb5['code']=_0x4d888b,_0x5d2b53(_0x2ffcb5);}});}function Ad(_0xabc16b,_0x25ec86,_0x1e3bfa,_0x23e47a,_0x9c2120,_0x1d53e8){_t(_0xabc16b,'transaction\x20on\x20'+_0x25ec86);const _0x5f1874={'path':_0x25ec86,'update':_0x1e3bfa,'onComplete':_0x23e47a,'status':null,'order':so(),'applyLocally':_0x1d53e8,'retryCount':0x0,'unwatcher':_0x9c2120,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2173cf=vs(_0xabc16b,_0x25ec86,void 0x0);_0x5f1874['currentInputSnapshot']=_0x2173cf;const _0x4bcdae=_0x5f1874['update'](_0x2173cf['val']());if(_0x4bcdae===void 0x0)_0x5f1874['unwatcher'](),_0x5f1874['currentOutputSnapshotRaw']=null,_0x5f1874['currentOutputSnapshotResolved']=null,_0x5f1874['onComplete']&&_0x5f1874['onComplete'](null,!0x1,_0x5f1874['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x4bcdae,_0x5f1874['path']),_0x5f1874['status']=0x0;const _0x2c34b4=Hn(_0xabc16b['transactionQueueTree_'],_0x25ec86),_0x260a4f=ze(_0x2c34b4)||[];_0x260a4f['push'](_0x5f1874),_s(_0x2c34b4,_0x260a4f);let _0x5c96d9;typeof _0x4bcdae=='object'&&_0x4bcdae!==null&&Q(_0x4bcdae,'.priority')?(_0x5c96d9=Me(_0x4bcdae,'.priority'),f(Wt(_0x5c96d9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5c96d9=(Bn(_0xabc16b['serverSyncTree_'],_0x25ec86)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x67d4cc=Jt(_0xabc16b),_0x452148=A(_0x4bcdae,_0x5c96d9),_0x31d607=ds(_0x452148,_0x2173cf,_0x67d4cc);_0x5f1874['currentOutputSnapshotRaw']=_0x452148,_0x5f1874['currentOutputSnapshotResolved']=_0x31d607,_0x5f1874['currentWriteId']=qn(_0xabc16b);const _0x2f4370=os(_0xabc16b['serverSyncTree_'],_0x25ec86,_0x31d607,_0x5f1874['currentWriteId'],_0x5f1874['applyLocally']);V(_0xabc16b['eventQueue_'],_0x25ec86,_0x2f4370),zn(_0xabc16b,_0xabc16b['transactionQueueTree_']);}}function vs(_0x2b5df8,_0x36f3a9,_0x3db5ed){return Bn(_0x2b5df8['serverSyncTree_'],_0x36f3a9,_0x3db5ed)||g['EMPTY_NODE'];}function zn(_0x14890d,_0x321f22=_0x14890d['transactionQueueTree_']){if(_0x321f22||jn(_0x14890d,_0x321f22),ze(_0x321f22)){const _0x4aa332=ua(_0x14890d,_0x321f22);f(_0x4aa332['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4aa332['every'](_0x3738b0=>_0x3738b0['status']===0x0)&&kd(_0x14890d,Yt(_0x321f22),_0x4aa332);}else ta(_0x321f22)&&$n(_0x321f22,_0x2a9217=>{zn(_0x14890d,_0x2a9217);});}function kd(_0x34a465,_0x5b59b1,_0x31cf7a){const _0xea95de=_0x31cf7a['map'](_0x5c20de=>_0x5c20de['currentWriteId']),_0x4e892f=vs(_0x34a465,_0x5b59b1,_0xea95de);let _0xb843a6=_0x4e892f;const _0x2a3354=_0x4e892f['hash']();for(let _0x1b3c7f=0x0;_0x1b3c7f<_0x31cf7a['length'];_0x1b3c7f++){const _0x198ab1=_0x31cf7a[_0x1b3c7f];f(_0x198ab1['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x198ab1['status']=0x1,_0x198ab1['retryCount']++;const _0x4c3ce6=F(_0x5b59b1,_0x198ab1['path']);_0xb843a6=_0xb843a6['updateChild'](_0x4c3ce6,_0x198ab1['currentOutputSnapshotRaw']);}const _0x4cbd66=_0xb843a6['val'](!0x0),_0x37cbe6=_0x5b59b1;_0x34a465['server_']['put'](_0x37cbe6['toString'](),_0x4cbd66,_0x5ea62b=>{_t(_0x34a465,'transaction\x20put\x20response',{'path':_0x37cbe6['toString'](),'status':_0x5ea62b});let _0x4af236=[];if(_0x5ea62b==='ok'){const _0x4085ba=[];for(let _0x458ad7=0x0;_0x458ad7<_0x31cf7a['length'];_0x458ad7++)_0x31cf7a[_0x458ad7]['status']=0x2,_0x4af236=_0x4af236['concat'](_e(_0x34a465['serverSyncTree_'],_0x31cf7a[_0x458ad7]['currentWriteId'])),_0x31cf7a[_0x458ad7]['onComplete']&&_0x4085ba['push'](()=>_0x31cf7a[_0x458ad7]['onComplete'](null,!0x0,_0x31cf7a[_0x458ad7]['currentOutputSnapshotResolved'])),_0x31cf7a[_0x458ad7]['unwatcher']();jn(_0x34a465,Hn(_0x34a465['transactionQueueTree_'],_0x5b59b1)),zn(_0x34a465,_0x34a465['transactionQueueTree_']),V(_0x34a465['eventQueue_'],_0x5b59b1,_0x4af236);for(let _0x39f338=0x0;_0x39f338<_0x4085ba['length'];_0x39f338++)dt(_0x4085ba[_0x39f338]);}else{if(_0x5ea62b==='datastale'){for(let _0x104e87=0x0;_0x104e87<_0x31cf7a['length'];_0x104e87++)_0x31cf7a[_0x104e87]['status']===0x3?_0x31cf7a[_0x104e87]['status']=0x4:_0x31cf7a[_0x104e87]['status']=0x0;}else{U('transaction\x20at\x20'+_0x37cbe6['toString']()+'\x20failed:\x20'+_0x5ea62b);for(let _0xccb9b4=0x0;_0xccb9b4<_0x31cf7a['length'];_0xccb9b4++)_0x31cf7a[_0xccb9b4]['status']=0x4,_0x31cf7a[_0xccb9b4]['abortReason']=_0x5ea62b;}at(_0x34a465,_0x5b59b1);}},_0x2a3354);}function at(_0x2c3552,_0x4073d4){const _0x56fd03=ha(_0x2c3552,_0x4073d4),_0xb3eaa8=Yt(_0x56fd03),_0x174de3=ua(_0x2c3552,_0x56fd03);return Nd(_0x2c3552,_0x174de3,_0xb3eaa8),_0xb3eaa8;}function Nd(_0x179476,_0x5847c4,_0x5c4b8f){if(_0x5847c4['length']===0x0)return;const _0x4becbc=[];let _0x15d7b5=[];const _0x2356bd=_0x5847c4['filter'](_0x2675ee=>_0x2675ee['status']===0x0)['map'](_0x5695f6=>_0x5695f6['currentWriteId']);for(let _0x19e5ac=0x0;_0x19e5ac<_0x5847c4['length'];_0x19e5ac++){const _0x194a4e=_0x5847c4[_0x19e5ac],_0x236114=F(_0x5c4b8f,_0x194a4e['path']);let _0x8e6181=!0x1,_0x17d9c0;if(f(_0x236114!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x194a4e['status']===0x4)_0x8e6181=!0x0,_0x17d9c0=_0x194a4e['abortReason'],_0x15d7b5=_0x15d7b5['concat'](_e(_0x179476['serverSyncTree_'],_0x194a4e['currentWriteId'],!0x0));else{if(_0x194a4e['status']===0x0){if(_0x194a4e['retryCount']>=pd)_0x8e6181=!0x0,_0x17d9c0='maxretry',_0x15d7b5=_0x15d7b5['concat'](_e(_0x179476['serverSyncTree_'],_0x194a4e['currentWriteId'],!0x0));else{const _0x1fcaf2=vs(_0x179476,_0x194a4e['path'],_0x2356bd);_0x194a4e['currentInputSnapshot']=_0x1fcaf2;const _0x53ac9b=_0x5847c4[_0x19e5ac]['update'](_0x1fcaf2['val']());if(_0x53ac9b!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x53ac9b,_0x194a4e['path']);let _0x52a581=A(_0x53ac9b);typeof _0x53ac9b=='object'&&_0x53ac9b!=null&&Q(_0x53ac9b,'.priority')||(_0x52a581=_0x52a581['updatePriority'](_0x1fcaf2['getPriority']()));const _0x1a36da=_0x194a4e['currentWriteId'],_0x4906d4=Jt(_0x179476),_0x333373=ds(_0x52a581,_0x1fcaf2,_0x4906d4);_0x194a4e['currentOutputSnapshotRaw']=_0x52a581,_0x194a4e['currentOutputSnapshotResolved']=_0x333373,_0x194a4e['currentWriteId']=qn(_0x179476),_0x2356bd['splice'](_0x2356bd['indexOf'](_0x1a36da),0x1),_0x15d7b5=_0x15d7b5['concat'](os(_0x179476['serverSyncTree_'],_0x194a4e['path'],_0x333373,_0x194a4e['currentWriteId'],_0x194a4e['applyLocally'])),_0x15d7b5=_0x15d7b5['concat'](_e(_0x179476['serverSyncTree_'],_0x1a36da,!0x0));}else _0x8e6181=!0x0,_0x17d9c0='nodata',_0x15d7b5=_0x15d7b5['concat'](_e(_0x179476['serverSyncTree_'],_0x194a4e['currentWriteId'],!0x0));}}}V(_0x179476['eventQueue_'],_0x5c4b8f,_0x15d7b5),_0x15d7b5=[],_0x8e6181&&(_0x5847c4[_0x19e5ac]['status']=0x2,function(_0x3cb2d2){setTimeout(_0x3cb2d2,Math['floor'](0x0));}(_0x5847c4[_0x19e5ac]['unwatcher']),_0x5847c4[_0x19e5ac]['onComplete']&&(_0x17d9c0==='nodata'?_0x4becbc['push'](()=>_0x5847c4[_0x19e5ac]['onComplete'](null,!0x1,_0x5847c4[_0x19e5ac]['currentInputSnapshot'])):_0x4becbc['push'](()=>_0x5847c4[_0x19e5ac]['onComplete'](new Error(_0x17d9c0),!0x1,null))));}jn(_0x179476,_0x179476['transactionQueueTree_']);for(let _0x40a621=0x0;_0x40a621<_0x4becbc['length'];_0x40a621++)dt(_0x4becbc[_0x40a621]);zn(_0x179476,_0x179476['transactionQueueTree_']);}function ha(_0x53170f,_0x48aa14){let _0x16bb8c,_0x3ac9c8=_0x53170f['transactionQueueTree_'];for(_0x16bb8c=y(_0x48aa14);_0x16bb8c!==null&&ze(_0x3ac9c8)===void 0x0;)_0x3ac9c8=Hn(_0x3ac9c8,_0x16bb8c),_0x48aa14=S(_0x48aa14),_0x16bb8c=y(_0x48aa14);return _0x3ac9c8;}function ua(_0x1a8f0b,_0x101b54){const _0x28a4d2=[];return da(_0x1a8f0b,_0x101b54,_0x28a4d2),_0x28a4d2['sort']((_0x323891,_0x4ab9ac)=>_0x323891['order']-_0x4ab9ac['order']),_0x28a4d2;}function da(_0x5c3b4e,_0x1a609f,_0x36fa9b){const _0x353136=ze(_0x1a609f);if(_0x353136){for(let _0x49a360=0x0;_0x49a360<_0x353136['length'];_0x49a360++)_0x36fa9b['push'](_0x353136[_0x49a360]);}$n(_0x1a609f,_0x54e926=>{da(_0x5c3b4e,_0x54e926,_0x36fa9b);});}function jn(_0x7e882d,_0x1f06e6){const _0x1d8516=ze(_0x1f06e6);if(_0x1d8516){let _0x4470e8=0x0;for(let _0x2f63dc=0x0;_0x2f63dc<_0x1d8516['length'];_0x2f63dc++)_0x1d8516[_0x2f63dc]['status']!==0x2&&(_0x1d8516[_0x4470e8]=_0x1d8516[_0x2f63dc],_0x4470e8++);_0x1d8516['length']=_0x4470e8,_s(_0x1f06e6,_0x1d8516['length']>0x0?_0x1d8516:void 0x0);}$n(_0x1f06e6,_0x2fe030=>{jn(_0x7e882d,_0x2fe030);});}function Es(_0x4efe11,_0xe4b0cd){const _0x4c04e7=Yt(ha(_0x4efe11,_0xe4b0cd)),_0x3c9423=Hn(_0x4efe11['transactionQueueTree_'],_0xe4b0cd);return id(_0x3c9423,_0x15daca=>{ui(_0x4efe11,_0x15daca);}),ui(_0x4efe11,_0x3c9423),na(_0x3c9423,_0x4471e2=>{ui(_0x4efe11,_0x4471e2);}),_0x4c04e7;}function ui(_0x404e0e,_0x2aeb65){const _0x766cb2=ze(_0x2aeb65);if(_0x766cb2){const _0x548598=[];let _0x5ee572=[],_0x185f9c=-0x1;for(let _0x541f8a=0x0;_0x541f8a<_0x766cb2['length'];_0x541f8a++)_0x766cb2[_0x541f8a]['status']===0x3||(_0x766cb2[_0x541f8a]['status']===0x1?(f(_0x185f9c===_0x541f8a-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x185f9c=_0x541f8a,_0x766cb2[_0x541f8a]['status']=0x3,_0x766cb2[_0x541f8a]['abortReason']='set'):(f(_0x766cb2[_0x541f8a]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x766cb2[_0x541f8a]['unwatcher'](),_0x5ee572=_0x5ee572['concat'](_e(_0x404e0e['serverSyncTree_'],_0x766cb2[_0x541f8a]['currentWriteId'],!0x0)),_0x766cb2[_0x541f8a]['onComplete']&&_0x548598['push'](_0x766cb2[_0x541f8a]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x185f9c===-0x1?_s(_0x2aeb65,void 0x0):_0x766cb2['length']=_0x185f9c+0x1,V(_0x404e0e['eventQueue_'],Yt(_0x2aeb65),_0x5ee572);for(let _0x467ee1=0x0;_0x467ee1<_0x548598['length'];_0x467ee1++)dt(_0x548598[_0x467ee1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pd(_0x41ecc4){let _0xc08bcf='';const _0x524f31=_0x41ecc4['split']('/');for(let _0x23915c=0x0;_0x23915c<_0x524f31['length'];_0x23915c++)if(_0x524f31[_0x23915c]['length']>0x0){let _0x11ccb7=_0x524f31[_0x23915c];try{_0x11ccb7=decodeURIComponent(_0x11ccb7['replace'](/\+/g,'\x20'));}catch{}_0xc08bcf+='/'+_0x11ccb7;}return _0xc08bcf;}function Od(_0x14a252){const _0x48e6fa={};_0x14a252['charAt'](0x0)==='?'&&(_0x14a252=_0x14a252['substring'](0x1));for(const _0x5eeea7 of _0x14a252['split']('&')){if(_0x5eeea7['length']===0x0)continue;const _0x591c06=_0x5eeea7['split']('=');_0x591c06['length']===0x2?_0x48e6fa[decodeURIComponent(_0x591c06[0x0])]=decodeURIComponent(_0x591c06[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5eeea7+'\x27\x20in\x20query\x20\x27'+_0x14a252+'\x27');}return _0x48e6fa;}const vr=function(_0x7d7c39,_0x5cec68){const _0x40b422=Dd(_0x7d7c39),_0x184442=_0x40b422['namespace'];_0x40b422['domain']==='firebase.com'&&ae(_0x40b422['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x184442||_0x184442==='undefined')&&_0x40b422['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x40b422['secure']||Wl();const _0x3cf2db=_0x40b422['scheme']==='ws'||_0x40b422['scheme']==='wss';return{'repoInfo':new yo(_0x40b422['host'],_0x40b422['secure'],_0x184442,_0x3cf2db,_0x5cec68,'',_0x184442!==_0x40b422['subdomain']),'path':new C(_0x40b422['pathString'])};},Dd=function(_0x32f8c7){let _0x14fb7e='',_0x10d791='',_0x3c5034='',_0x5eea71='',_0x3917fc='',_0x53ebfa=!0x0,_0x47932d='https',_0x45bb13=0x1bb;if(typeof _0x32f8c7=='string'){let _0x31f1e9=_0x32f8c7['indexOf']('//');_0x31f1e9>=0x0&&(_0x47932d=_0x32f8c7['substring'](0x0,_0x31f1e9-0x1),_0x32f8c7=_0x32f8c7['substring'](_0x31f1e9+0x2));let _0x56bd10=_0x32f8c7['indexOf']('/');_0x56bd10===-0x1&&(_0x56bd10=_0x32f8c7['length']);let _0x318c0f=_0x32f8c7['indexOf']('?');_0x318c0f===-0x1&&(_0x318c0f=_0x32f8c7['length']),_0x14fb7e=_0x32f8c7['substring'](0x0,Math['min'](_0x56bd10,_0x318c0f)),_0x56bd10<_0x318c0f&&(_0x5eea71=Pd(_0x32f8c7['substring'](_0x56bd10,_0x318c0f)));const _0x28eb7d=Od(_0x32f8c7['substring'](Math['min'](_0x32f8c7['length'],_0x318c0f)));_0x31f1e9=_0x14fb7e['indexOf'](':'),_0x31f1e9>=0x0?(_0x53ebfa=_0x47932d==='https'||_0x47932d==='wss',_0x45bb13=parseInt(_0x14fb7e['substring'](_0x31f1e9+0x1),0xa)):_0x31f1e9=_0x14fb7e['length'];const _0x2da326=_0x14fb7e['slice'](0x0,_0x31f1e9);if(_0x2da326['toLowerCase']()==='localhost')_0x10d791='localhost';else{if(_0x2da326['split']('.')['length']<=0x2)_0x10d791=_0x2da326;else{const _0x25fbcf=_0x14fb7e['indexOf']('.');_0x3c5034=_0x14fb7e['substring'](0x0,_0x25fbcf)['toLowerCase'](),_0x10d791=_0x14fb7e['substring'](_0x25fbcf+0x1),_0x3917fc=_0x3c5034;}}'ns'in _0x28eb7d&&(_0x3917fc=_0x28eb7d['ns']);}return{'host':_0x14fb7e,'port':_0x45bb13,'domain':_0x10d791,'subdomain':_0x3c5034,'secure':_0x53ebfa,'scheme':_0x47932d,'pathString':_0x5eea71,'namespace':_0x3917fc};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Md=(function(){let _0x1913aa=0x0;const _0x403db4=[];return function(_0x5153ed){const _0x562e64=_0x5153ed===_0x1913aa;_0x1913aa=_0x5153ed;let _0x22b09d;const _0xce4326=new Array(0x8);for(_0x22b09d=0x7;_0x22b09d>=0x0;_0x22b09d--)_0xce4326[_0x22b09d]=Er['charAt'](_0x5153ed%0x40),_0x5153ed=Math['floor'](_0x5153ed/0x40);f(_0x5153ed===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1ea1c5=_0xce4326['join']('');if(_0x562e64){for(_0x22b09d=0xb;_0x22b09d>=0x0&&_0x403db4[_0x22b09d]===0x3f;_0x22b09d--)_0x403db4[_0x22b09d]=0x0;_0x403db4[_0x22b09d]++;}else{for(_0x22b09d=0x0;_0x22b09d<0xc;_0x22b09d++)_0x403db4[_0x22b09d]=Math['floor'](Math['random']()*0x40);}for(_0x22b09d=0x0;_0x22b09d<0xc;_0x22b09d++)_0x1ea1c5+=Er['charAt'](_0x403db4[_0x22b09d]);return f(_0x1ea1c5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1ea1c5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ld{constructor(_0x296a70,_0x3385b4,_0x2d17be,_0x2e745a){this['eventType']=_0x296a70,this['eventRegistration']=_0x3385b4,this['snapshot']=_0x2d17be,this['prevName']=_0x2e745a;}['getPath'](){const _0x3b2678=this['snapshot']['ref'];return this['eventType']==='value'?_0x3b2678['_path']:_0x3b2678['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class xd{constructor(_0xa2089b,_0xd1fa68,_0x217db5){this['eventRegistration']=_0xa2089b,this['error']=_0xd1fa68,this['path']=_0x217db5;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fa{constructor(_0x589040,_0x3e91c9){this['snapshotCallback']=_0x589040,this['cancelCallback']=_0x3e91c9;}['onValue'](_0x486f3f,_0x1881a7){this['snapshotCallback']['call'](null,_0x486f3f,_0x1881a7);}['onCancel'](_0x6b9885){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x6b9885);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xb7c284){return this['snapshotCallback']===_0xb7c284['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xb7c284['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xb7c284['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fd{constructor(_0x48a0fa,_0x1bc6a3){this['_repo']=_0x48a0fa,this['_path']=_0x1bc6a3;}['cancel'](){const _0x1bb0c2=new H();return wd(this['_repo'],this['_path'],_0x1bb0c2['wrapCallback'](()=>{})),_0x1bb0c2['promise'];}['remove'](){Oe('OnDisconnect.remove',this['_path']);const _0x10a3f7=new H();return yr(this['_repo'],this['_path'],null,_0x10a3f7['wrapCallback'](()=>{})),_0x10a3f7['promise'];}['set'](_0x24dd6c){Oe('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x24dd6c,this['_path'],!0x1);const _0x16ddea=new H();return yr(this['_repo'],this['_path'],_0x24dd6c,_0x16ddea['wrapCallback'](()=>{})),_0x16ddea['promise'];}['setWithPriority'](_0x55fb09,_0x2d9eab){Oe('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x55fb09,this['_path'],!0x1),ld('OnDisconnect.setWithPriority',_0x2d9eab);const _0x292dab=new H();return Cd(this['_repo'],this['_path'],_0x55fb09,_0x2d9eab,_0x292dab['wrapCallback'](()=>{})),_0x292dab['promise'];}['update'](_0x59b32e){Oe('OnDisconnect.update',this['_path']),sa('OnDisconnect.update',_0x59b32e,this['_path']);const _0x5e53ca=new H();return Td(this['_repo'],this['_path'],_0x59b32e,_0x5e53ca['wrapCallback'](()=>{})),_0x5e53ca['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gt{constructor(_0x515c6a,_0x58b22e,_0x578ac0,_0xfd9015){this['_repo']=_0x515c6a,this['_path']=_0x58b22e,this['_queryParams']=_0x578ac0,this['_orderByCalled']=_0xfd9015;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x79ddc8=sr(this['_queryParams']),_0x121bfc=Hi(_0x79ddc8);return _0x121bfc==='{}'?'default':_0x121bfc;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x18eb01){if(_0x18eb01=N(_0x18eb01),!(_0x18eb01 instanceof gt))return!0x1;const _0x39a2b4=this['_repo']===_0x18eb01['_repo'],_0x118981=ji(this['_path'],_0x18eb01['_path']),_0x3fe440=this['_queryIdentifier']===_0x18eb01['_queryIdentifier'];return _0x39a2b4&&_0x118981&&_0x3fe440;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+wh(this['_path']);}}function Ud(_0x380e19,_0xdd91bb){if(_0x380e19['_orderByCalled']===!0x0)throw new Error(_0xdd91bb+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Is(_0x5653f6){let _0x237f1b=null,_0x49722c=null;if(_0x5653f6['hasStart']()&&(_0x237f1b=_0x5653f6['getIndexStartValue']()),_0x5653f6['hasEnd']()&&(_0x49722c=_0x5653f6['getIndexEndValue']()),_0x5653f6['getIndex']()===De){const _0xbf8fd5='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2b4d42='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x5653f6['hasStart']()){if(_0x5653f6['getIndexStartName']()!==Ue)throw new Error(_0xbf8fd5);if(typeof _0x237f1b!='string')throw new Error(_0x2b4d42);}if(_0x5653f6['hasEnd']()){if(_0x5653f6['getIndexEndName']()!==Ie)throw new Error(_0xbf8fd5);if(typeof _0x49722c!='string')throw new Error(_0x2b4d42);}}else{if(_0x5653f6['getIndex']()===R){if(_0x237f1b!=null&&!Wt(_0x237f1b)||_0x49722c!=null&&!Wt(_0x49722c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x5653f6['getIndex']()instanceof Qi||_0x5653f6['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x237f1b!=null&&typeof _0x237f1b=='object'||_0x49722c!=null&&typeof _0x49722c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function pa(_0x301afc){if(_0x301afc['hasStart']()&&_0x301afc['hasEnd']()&&_0x301afc['hasLimit']()&&!_0x301afc['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends gt{constructor(_0x53f470,_0x4218f8){super(_0x53f470,_0x4218f8,new Xi(),!0x1);}get['parent'](){const _0x835194=Ro(this['_path']);return _0x835194===null?null:new ee(this['_repo'],_0x835194);}get['root'](){let _0x1789d9=this;for(;_0x1789d9['parent']!==null;)_0x1789d9=_0x1789d9['parent'];return _0x1789d9;}}class ct{constructor(_0x55f286,_0x262af9,_0x4e087c){this['_node']=_0x55f286,this['ref']=_0x262af9,this['_index']=_0x4e087c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3bcfad){const _0x4a1fbc=new C(_0x3bcfad),_0x5f9116=Bt(this['ref'],_0x3bcfad);return new ct(this['_node']['getChild'](_0x4a1fbc),_0x5f9116,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x527359){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xc08eb4,_0x2d44d6)=>_0x527359(new ct(_0x2d44d6,Bt(this['ref'],_0xc08eb4),R)));}['hasChild'](_0x2f5944){const _0x3baaee=new C(_0x2f5944);return!this['_node']['getChild'](_0x3baaee)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x3c8327,_0x5a88ee){return _0x3c8327=N(_0x3c8327),_0x3c8327['_checkNotDeleted']('ref'),_0x5a88ee!==void 0x0?Bt(_0x3c8327['_root'],_0x5a88ee):_0x3c8327['_root'];}function Bt(_0x7a11c7,_0x5e75a3){return _0x7a11c7=N(_0x7a11c7),y(_0x7a11c7['_path'])===null?hd('child','path',_0x5e75a3):ms('child','path',_0x5e75a3),new ee(_0x7a11c7['_repo'],k(_0x7a11c7['_path'],_0x5e75a3));}function g_(_0x10120){return _0x10120=N(_0x10120),new Fd(_0x10120['_repo'],_0x10120['_path']);}function m_(_0x4800c8,_0x2d5be1){_0x4800c8=N(_0x4800c8),Oe('push',_0x4800c8['_path']),Ve('push',_0x2d5be1,_0x4800c8['_path'],!0x0);const _0x521fbd=ca(_0x4800c8['_repo']),_0x4f5693=Md(_0x521fbd),_0x1ac339=Bt(_0x4800c8,_0x4f5693),_0x1e6064=Bt(_0x4800c8,_0x4f5693);let _0x2c4a10;return _0x2d5be1!=null?_0x2c4a10=Wd(_0x1e6064,_0x2d5be1)['then'](()=>_0x1e6064):_0x2c4a10=Promise['resolve'](_0x1e6064),_0x1ac339['then']=_0x2c4a10['then']['bind'](_0x2c4a10),_0x1ac339['catch']=_0x2c4a10['then']['bind'](_0x2c4a10,void 0x0),_0x1ac339;}function Wd(_0xe1d447,_0x2c482d){_0xe1d447=N(_0xe1d447),Oe('set',_0xe1d447['_path']),Ve('set',_0x2c482d,_0xe1d447['_path'],!0x1);const _0x4aefdb=new H();return vd(_0xe1d447['_repo'],_0xe1d447['_path'],_0x2c482d,null,_0x4aefdb['wrapCallback'](()=>{})),_0x4aefdb['promise'];}function y_(_0x4896a4,_0xaaee91){sa('update',_0xaaee91,_0x4896a4['_path']);const _0x21336a=new H();return Ed(_0x4896a4['_repo'],_0x4896a4['_path'],_0xaaee91,_0x21336a['wrapCallback'](()=>{})),_0x21336a['promise'];}function v_(_0x4a5a45){_0x4a5a45=N(_0x4a5a45);const _0x2bb762=new fa(()=>{}),_0x207fc2=new Kn(_0x2bb762);return yd(_0x4a5a45['_repo'],_0x4a5a45,_0x207fc2)['then'](_0x510183=>new ct(_0x510183,new ee(_0x4a5a45['_repo'],_0x4a5a45['_path']),_0x4a5a45['_queryParams']['getIndex']()));}class Kn{constructor(_0x3875ac){this['callbackContext']=_0x3875ac;}['respondsTo'](_0x59981e){return _0x59981e==='value';}['createEvent'](_0x2d27fb,_0xff827e){const _0x4950fe=_0xff827e['_queryParams']['getIndex']();return new Ld('value',this,new ct(_0x2d27fb['snapshotNode'],new ee(_0xff827e['_repo'],_0xff827e['_path']),_0x4950fe));}['getEventRunner'](_0xcaa3cb){return _0xcaa3cb['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xcaa3cb['error']):()=>this['callbackContext']['onValue'](_0xcaa3cb['snapshot'],null);}['createCancelEvent'](_0x56cc3b,_0x5e6fd7){return this['callbackContext']['hasCancelCallback']?new xd(this,_0x56cc3b,_0x5e6fd7):null;}['matches'](_0x2c4556){return _0x2c4556 instanceof Kn?!_0x2c4556['callbackContext']||!this['callbackContext']?!0x0:_0x2c4556['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Bd(_0x147eeb,_0xbf0b43,_0x43b1e9,_0x2b8814,_0x41dde3){const _0x12239d=new fa(_0x43b1e9,void 0x0),_0x66ed5b=new Kn(_0x12239d);return Sd(_0x147eeb['_repo'],_0x147eeb,_0x66ed5b),()=>bd(_0x147eeb['_repo'],_0x147eeb,_0x66ed5b);}function Vd(_0x2f90e9,_0x459083,_0x46b28f,_0x3f9468){return Bd(_0x2f90e9,'value',_0x459083);}class Yn{}class Hd extends Yn{constructor(_0x2ba306,_0x570156){super(),this['_value']=_0x2ba306,this['_key']=_0x570156,this['type']='endAt';}['_apply'](_0x3d9f67){Ve('endAt',this['_value'],_0x3d9f67['_path'],!0x0);const _0x369942=zh(_0x3d9f67['_queryParams'],this['_value'],this['_key']);if(pa(_0x369942),Is(_0x369942),_0x3d9f67['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new gt(_0x3d9f67['_repo'],_0x3d9f67['_path'],_0x369942,_0x3d9f67['_orderByCalled']);}}class $d extends Yn{constructor(_0x55a285,_0x2f20fa){super(),this['_value']=_0x55a285,this['_key']=_0x2f20fa,this['type']='startAt';}['_apply'](_0x35d44b){Ve('startAt',this['_value'],_0x35d44b['_path'],!0x0);const _0xe7e9c7=qh(_0x35d44b['_queryParams'],this['_value'],this['_key']);if(pa(_0xe7e9c7),Is(_0xe7e9c7),_0x35d44b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new gt(_0x35d44b['_repo'],_0x35d44b['_path'],_0xe7e9c7,_0x35d44b['_orderByCalled']);}}class Gd extends Yn{constructor(_0x3360a5){super(),this['_path']=_0x3360a5,this['type']='orderByChild';}['_apply'](_0x326f2a){Ud(_0x326f2a,'orderByChild');const _0x1c7781=new C(this['_path']);if(v(_0x1c7781))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x44a777=new Qi(_0x1c7781),_0x35fff5=jh(_0x326f2a['_queryParams'],_0x44a777);return Is(_0x35fff5),new gt(_0x326f2a['_repo'],_0x326f2a['_path'],_0x35fff5,!0x0);}}function E_(_0xab4227){if(_0xab4227==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xab4227==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xab4227==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0xab4227),new Gd(_0xab4227);}class qd extends Yn{constructor(_0x31002a,_0xf1baa8){super(),this['_value']=_0x31002a,this['_key']=_0xf1baa8,this['type']='equalTo';}['_apply'](_0x5a7d33){if(Ve('equalTo',this['_value'],_0x5a7d33['_path'],!0x1),_0x5a7d33['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5a7d33['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new Hd(this['_value'],this['_key'])['_apply'](new $d(this['_value'],this['_key'])['_apply'](_0x5a7d33));}}function I_(_0x4daa37,_0xc2b76c){return new qd(_0x4daa37,_0xc2b76c);}function w_(_0x17e114,..._0x1d0be0){let _0x48349b=N(_0x17e114);for(const _0x2453bf of _0x1d0be0)_0x48349b=_0x2453bf['_apply'](_0x48349b);return _0x48349b;}Lu(ee),Bu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zd='FIREBASE_DATABASE_EMULATOR_HOST',Oi={};let jd=!0x1;function Kd(_0x5c414a,_0xc5046b,_0x37b46a,_0x3a23c5){const _0x1c1193=_0xc5046b['lastIndexOf'](':'),_0x643130=_0xc5046b['substring'](0x0,_0x1c1193),_0xe5b831=Gt(_0x643130);_0x5c414a['repoInfo_']=new yo(_0xc5046b,_0xe5b831,_0x5c414a['repoInfo_']['namespace'],_0x5c414a['repoInfo_']['webSocketOnly'],_0x5c414a['repoInfo_']['nodeAdmin'],_0x5c414a['repoInfo_']['persistenceKey'],_0x5c414a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x37b46a),_0x3a23c5&&(_0x5c414a['authTokenProvider_']=_0x3a23c5);}function Yd(_0x30474f,_0x5c6853,_0x3fab0e,_0x5debae,_0x2467c3){let _0x5cf316=_0x5debae||_0x30474f['options']['databaseURL'];_0x5cf316===void 0x0&&(_0x30474f['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x30474f['options']['projectId']),_0x5cf316=_0x30474f['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4ae827=vr(_0x5cf316,_0x2467c3),_0x162444=_0x4ae827['repoInfo'],_0x5bcfa2;typeof process<'u'&&Bs&&(_0x5bcfa2=Bs[zd]),_0x5bcfa2?(_0x5cf316='http://'+_0x5bcfa2+'?ns='+_0x162444['namespace'],_0x4ae827=vr(_0x5cf316,_0x2467c3),_0x162444=_0x4ae827['repoInfo']):_0x4ae827['repoInfo']['secure'];const _0x20e92d=new Ql(_0x30474f['name'],_0x30474f['options'],_0x5c6853);ud('Invalid\x20Firebase\x20Database\x20URL',_0x4ae827),v(_0x4ae827['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x469b11=Jd(_0x162444,_0x30474f,_0x20e92d,new Yl(_0x30474f,_0x3fab0e));return new Xd(_0x469b11,_0x30474f);}function Qd(_0x2a81a1,_0x52ea82){const _0x4109f4=Oi[_0x52ea82];(!_0x4109f4||_0x4109f4[_0x2a81a1['key']]!==_0x2a81a1)&&ae('Database\x20'+_0x52ea82+'('+_0x2a81a1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),la(_0x2a81a1),delete _0x4109f4[_0x2a81a1['key']];}function Jd(_0x587338,_0x58716e,_0x3d058d,_0x3c2975){let _0x40f0c5=Oi[_0x58716e['name']];_0x40f0c5||(_0x40f0c5={},Oi[_0x58716e['name']]=_0x40f0c5);let _0x11ab31=_0x40f0c5[_0x587338['toURLString']()];return _0x11ab31&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x11ab31=new _d(_0x587338,jd,_0x3d058d,_0x3c2975),_0x40f0c5[_0x587338['toURLString']()]=_0x11ab31,_0x11ab31;}class Xd{constructor(_0xe4a91d,_0x5a20cd){this['_repoInternal']=_0xe4a91d,this['app']=_0x5a20cd,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(gd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Qd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x36f27e){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x36f27e+'\x20on\x20a\x20deleted\x20database.');}}function C_(_0xb37078=Zr(),_0x52975a){const _0x30b3e0=Vi(_0xb37078,'database')['getImmediate']({'identifier':_0x52975a});if(!_0x30b3e0['_instanceStarted']){const _0x319163=oc('database');_0x319163&&Zd(_0x30b3e0,..._0x319163);}return _0x30b3e0;}function Zd(_0x1e8ffb,_0x446714,_0x530f83,_0x3afdc1={}){_0x1e8ffb=N(_0x1e8ffb),_0x1e8ffb['_checkNotDeleted']('useEmulator');const _0x2d9bc2=_0x446714+':'+_0x530f83,_0x15bc46=_0x1e8ffb['_repoInternal'];if(_0x1e8ffb['_instanceStarted']){if(_0x2d9bc2===_0x1e8ffb['_repoInternal']['repoInfo_']['host']&&Le(_0x3afdc1,_0x15bc46['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x121a7e;if(_0x15bc46['repoInfo_']['nodeAdmin'])_0x3afdc1['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x121a7e=new on(on['OWNER']);else{if(_0x3afdc1['mockUserToken']){const _0x580d40=typeof _0x3afdc1['mockUserToken']=='string'?_0x3afdc1['mockUserToken']:ac(_0x3afdc1['mockUserToken'],_0x1e8ffb['app']['options']['projectId']);_0x121a7e=new on(_0x580d40);}}Gt(_0x446714)&&Qr(_0x446714),Kd(_0x15bc46,_0x2d9bc2,_0x3afdc1,_0x121a7e);}function T_(_0x9ff5c9){_0x9ff5c9=N(_0x9ff5c9),_0x9ff5c9['_checkNotDeleted']('goOffline'),la(_0x9ff5c9['_repo']);}function S_(_0x553b21){_0x553b21=N(_0x553b21),_0x553b21['_checkNotDeleted']('goOnline'),Rd(_0x553b21['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ef(_0x3a8d07){Ml(ut),it(new xe('database',(_0x9b4dcd,{instanceIdentifier:_0x5de62b})=>{const _0x176bae=_0x9b4dcd['getProvider']('app')['getImmediate'](),_0x1c4e38=_0x9b4dcd['getProvider']('auth-internal'),_0x294651=_0x9b4dcd['getProvider']('app-check-internal');return Yd(_0x176bae,_0x1c4e38,_0x294651,_0x5de62b);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x3a8d07),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const tf={'.sv':'timestamp'};function b_(){return tf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nf{constructor(_0x583325,_0x5abcf8){this['committed']=_0x583325,this['snapshot']=_0x5abcf8;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function R_(_0x41f3e3,_0x37b736,_0x4cfe1e){if(_0x41f3e3=N(_0x41f3e3),Oe('Reference.transaction',_0x41f3e3['_path']),_0x41f3e3['key']==='.length'||_0x41f3e3['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x41f3e3['key']+'\x20is\x20a\x20read-only\x20object.';const _0x194527=!0x0,_0xbdcb72=new H(),_0x20bd3b=(_0x17216a,_0x5206b0,_0x524d3c)=>{let _0x27b7dd=null;_0x17216a?_0xbdcb72['reject'](_0x17216a):(_0x27b7dd=new ct(_0x524d3c,new ee(_0x41f3e3['_repo'],_0x41f3e3['_path']),R),_0xbdcb72['resolve'](new nf(_0x5206b0,_0x27b7dd)));},_0x1afc5c=Vd(_0x41f3e3,()=>{});return Ad(_0x41f3e3['_repo'],_0x41f3e3['_path'],_0x37b736,_0x20bd3b,_0x1afc5c,_0x194527),_0xbdcb72['promise'];}se['prototype']['simpleListen']=function(_0x2ad823,_0x420fcd){this['sendRequest']('q',{'p':_0x2ad823},_0x420fcd);},se['prototype']['echo']=function(_0x178532,_0x234cf2){this['sendRequest']('echo',{'d':_0x178532},_0x234cf2);},ef();function _a(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const sf=_a,ga=new $t('auth','Firebase',_a()),An=new Wi('@firebase/auth');function rf(_0x273da1,..._0x1fc7a6){An['logLevel']<=T['WARN']&&An['warn']('Auth\x20('+ut+'):\x20'+_0x273da1,..._0x1fc7a6);}function an(_0x3f2392,..._0x3cdb55){An['logLevel']<=T['ERROR']&&An['error']('Auth\x20('+ut+'):\x20'+_0x3f2392,..._0x3cdb55);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xf1b69d,..._0x708318){throw ws(_0xf1b69d,..._0x708318);}function X(_0x3a9bdc,..._0x26119f){return ws(_0x3a9bdc,..._0x26119f);}function ma(_0x212669,_0x50c478,_0xc68117){const _0x10d3c0={...sf(),[_0x50c478]:_0xc68117};return new $t('auth','Firebase',_0x10d3c0)['create'](_0x50c478,{'appName':_0x212669['name']});}function re(_0x53985b){return ma(_0x53985b,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x39b40d,..._0x17ffc6){if(typeof _0x39b40d!='string'){const _0x3f5efd=_0x17ffc6[0x0],_0x5a18b6=[..._0x17ffc6['slice'](0x1)];return _0x5a18b6[0x0]&&(_0x5a18b6[0x0]['appName']=_0x39b40d['name']),_0x39b40d['_errorFactory']['create'](_0x3f5efd,..._0x5a18b6);}return ga['create'](_0x39b40d,..._0x17ffc6);}function m(_0x1a4cb7,_0x43f28c,..._0x433db2){if(!_0x1a4cb7)throw ws(_0x43f28c,..._0x433db2);}function ne(_0x20af11){const _0x192fc3='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x20af11;throw an(_0x192fc3),new Error(_0x192fc3);}function ce(_0x30bdf9,_0x1ffe2a){_0x30bdf9||ne(_0x1ffe2a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Di(){var _0x3c7264;return typeof self<'u'&&((_0x3c7264=self['location'])==null?void 0x0:_0x3c7264['href'])||'';}function of(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x34d4f8;return typeof self<'u'&&((_0x34d4f8=self['location'])==null?void 0x0:_0x34d4f8['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function af(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(of()||lc()||'connection'in navigator)?navigator['onLine']:!0x0;}function cf(){if(typeof navigator>'u')return null;const _0x75561=navigator;return _0x75561['languages']&&_0x75561['languages'][0x0]||_0x75561['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xt{constructor(_0x14adc5,_0x5b6488){this['shortDelay']=_0x14adc5,this['longDelay']=_0x5b6488,ce(_0x5b6488>_0x14adc5,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Ui()||Kr();}['get'](){return af()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x5308f,_0x1d95c6){ce(_0x5308f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x465015}=_0x5308f['emulator'];return _0x1d95c6?''+_0x465015+(_0x1d95c6['startsWith']('/')?_0x1d95c6['slice'](0x1):_0x1d95c6):_0x465015;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ya{static['initialize'](_0x257c1f,_0x2c2a3e,_0x378999){this['fetchImpl']=_0x257c1f,_0x2c2a3e&&(this['headersImpl']=_0x2c2a3e),_0x378999&&(this['responseImpl']=_0x378999);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},hf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],uf=new Xt(0x7530,0xea60);function Re(_0x351759,_0x18e7f0){return _0x351759['tenantId']&&!_0x18e7f0['tenantId']?{..._0x18e7f0,'tenantId':_0x351759['tenantId']}:_0x18e7f0;}async function Ae(_0x3d2e3f,_0x462dca,_0x22edcb,_0x47c448,_0x423301={}){return va(_0x3d2e3f,_0x423301,async()=>{let _0x3943c6={},_0x202906={};_0x47c448&&(_0x462dca==='GET'?_0x202906=_0x47c448:_0x3943c6={'body':JSON['stringify'](_0x47c448)});const _0x7187a7=ht({..._0x202906,'key':_0x3d2e3f['config']['apiKey']})['slice'](0x1),_0x372fe8=await _0x3d2e3f['_getAdditionalHeaders']();_0x372fe8['Content-Type']='application/json',_0x3d2e3f['languageCode']&&(_0x372fe8['X-Firebase-Locale']=_0x3d2e3f['languageCode']);const _0x11faf6={'method':_0x462dca,'headers':_0x372fe8,..._0x3943c6};return cc()||(_0x11faf6['referrerPolicy']='strict-origin-when-cross-origin'),_0x3d2e3f['emulatorConfig']&&Gt(_0x3d2e3f['emulatorConfig']['host'])&&(_0x11faf6['credentials']='include'),ya['fetch']()(await Ea(_0x3d2e3f,_0x3d2e3f['config']['apiHost'],_0x22edcb,_0x7187a7),_0x11faf6);});}async function va(_0x4b4ec7,_0x47373c,_0x4d633e){_0x4b4ec7['_canInitEmulator']=!0x1;const _0x32dff8={...lf,..._0x47373c};try{const _0x2384b9=new ff(_0x4b4ec7),_0x47d96c=await Promise['race']([_0x4d633e(),_0x2384b9['promise']]);_0x2384b9['clearNetworkTimeout']();const _0x4dca19=await _0x47d96c['json']();if('needConfirmation'in _0x4dca19)throw rn(_0x4b4ec7,'account-exists-with-different-credential',_0x4dca19);if(_0x47d96c['ok']&&!('errorMessage'in _0x4dca19))return _0x4dca19;{const _0x40b5ce=_0x47d96c['ok']?_0x4dca19['errorMessage']:_0x4dca19['error']['message'],[_0x137ec9,_0x28c642]=_0x40b5ce['split']('\x20:\x20');if(_0x137ec9==='FEDERATED_USER_ID_ALREADY_LINKED')throw rn(_0x4b4ec7,'credential-already-in-use',_0x4dca19);if(_0x137ec9==='EMAIL_EXISTS')throw rn(_0x4b4ec7,'email-already-in-use',_0x4dca19);if(_0x137ec9==='USER_DISABLED')throw rn(_0x4b4ec7,'user-disabled',_0x4dca19);const _0x2b3677=_0x32dff8[_0x137ec9]||_0x137ec9['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x28c642)throw ma(_0x4b4ec7,_0x2b3677,_0x28c642);Y(_0x4b4ec7,_0x2b3677);}}catch(_0x319876){if(_0x319876 instanceof be)throw _0x319876;Y(_0x4b4ec7,'network-request-failed',{'message':String(_0x319876)});}}async function Zt(_0x2fbad7,_0x2b4007,_0x389218,_0x2afda6,_0x402b02={}){const _0x12f1ff=await Ae(_0x2fbad7,_0x2b4007,_0x389218,_0x2afda6,_0x402b02);return'mfaPendingCredential'in _0x12f1ff&&Y(_0x2fbad7,'multi-factor-auth-required',{'_serverResponse':_0x12f1ff}),_0x12f1ff;}async function Ea(_0x2bb6ce,_0x2626ea,_0x36062b,_0x5f1513){const _0x37f849=''+_0x2626ea+_0x36062b+'?'+_0x5f1513,_0x33bfc7=_0x2bb6ce,_0xd7a8a6=_0x33bfc7['config']['emulator']?Cs(_0x2bb6ce['config'],_0x37f849):_0x2bb6ce['config']['apiScheme']+'://'+_0x37f849;return hf['includes'](_0x36062b)&&(await _0x33bfc7['_persistenceManagerAvailable'],_0x33bfc7['_getPersistenceType']()==='COOKIE')?_0x33bfc7['_getPersistence']()['_getFinalTarget'](_0xd7a8a6)['toString']():_0xd7a8a6;}function df(_0x12f921){switch(_0x12f921){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class ff{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x41d94c){this['auth']=_0x41d94c,this['timer']=null,this['promise']=new Promise((_0x635d3b,_0x408736)=>{this['timer']=setTimeout(()=>_0x408736(X(this['auth'],'network-request-failed')),uf['get']());});}}function rn(_0x1e0e45,_0x55953c,_0x1347e1){const _0x4f1b3b={'appName':_0x1e0e45['name']};_0x1347e1['email']&&(_0x4f1b3b['email']=_0x1347e1['email']),_0x1347e1['phoneNumber']&&(_0x4f1b3b['phoneNumber']=_0x1347e1['phoneNumber']);const _0x170147=X(_0x1e0e45,_0x55953c,_0x4f1b3b);return _0x170147['customData']['_tokenResponse']=_0x1347e1,_0x170147;}function wr(_0x121596){return _0x121596!==void 0x0&&_0x121596['enterprise']!==void 0x0;}class pf{constructor(_0x2d0b7c){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2d0b7c['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2d0b7c['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2d0b7c['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3ac311){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x9094a4 of this['recaptchaEnforcementState'])if(_0x9094a4['provider']&&_0x9094a4['provider']===_0x3ac311)return df(_0x9094a4['enforcementState']);return null;}['isProviderEnabled'](_0x47173b){return this['getProviderEnforcementState'](_0x47173b)==='ENFORCE'||this['getProviderEnforcementState'](_0x47173b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function _f(_0x60370b,_0x35fa56){return Ae(_0x60370b,'GET','/v2/recaptchaConfig',Re(_0x60370b,_0x35fa56));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function gf(_0x113acf,_0x2d626e){return Ae(_0x113acf,'POST','/v1/accounts:delete',_0x2d626e);}async function kn(_0x35f3fc,_0x215556){return Ae(_0x35f3fc,'POST','/v1/accounts:lookup',_0x215556);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x32f2e6){if(_0x32f2e6)try{const _0x60be89=new Date(Number(_0x32f2e6));if(!isNaN(_0x60be89['getTime']()))return _0x60be89['toUTCString']();}catch{}}async function mf(_0x3784bf,_0x596d1e=!0x1){const _0x411409=N(_0x3784bf),_0x522353=await _0x411409['getIdToken'](_0x596d1e),_0x20ef6b=Ts(_0x522353);m(_0x20ef6b&&_0x20ef6b['exp']&&_0x20ef6b['auth_time']&&_0x20ef6b['iat'],_0x411409['auth'],'internal-error');const _0xfd991c=typeof _0x20ef6b['firebase']=='object'?_0x20ef6b['firebase']:void 0x0,_0x2390a3=_0xfd991c==null?void 0x0:_0xfd991c['sign_in_provider'];return{'claims':_0x20ef6b,'token':_0x522353,'authTime':kt(di(_0x20ef6b['auth_time'])),'issuedAtTime':kt(di(_0x20ef6b['iat'])),'expirationTime':kt(di(_0x20ef6b['exp'])),'signInProvider':_0x2390a3||null,'signInSecondFactor':(_0xfd991c==null?void 0x0:_0xfd991c['sign_in_second_factor'])||null};}function di(_0x286122){return Number(_0x286122)*0x3e8;}function Ts(_0x410a60){const [_0x1fc6cf,_0xd29db6,_0x5c4bf5]=_0x410a60['split']('.');if(_0x1fc6cf===void 0x0||_0xd29db6===void 0x0||_0x5c4bf5===void 0x0)return an('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x36637a=dn(_0xd29db6);return _0x36637a?JSON['parse'](_0x36637a):(an('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2dd671){return an('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2dd671==null?void 0x0:_0x2dd671['toString']()),null;}}function Cr(_0x53f7da){const _0x41f6c8=Ts(_0x53f7da);return m(_0x41f6c8,'internal-error'),m(typeof _0x41f6c8['exp']<'u','internal-error'),m(typeof _0x41f6c8['iat']<'u','internal-error'),Number(_0x41f6c8['exp'])-Number(_0x41f6c8['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x459741,_0x550764,_0x37f346=!0x1){if(_0x37f346)return _0x550764;try{return await _0x550764;}catch(_0x2bd954){throw _0x2bd954 instanceof be&&yf(_0x2bd954)&&_0x459741['auth']['currentUser']===_0x459741&&await _0x459741['auth']['signOut'](),_0x2bd954;}}function yf({code:_0x485833}){return _0x485833==='auth/user-disabled'||_0x485833==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vf{constructor(_0x528e47){this['user']=_0x528e47,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x226681){if(_0x226681){const _0x16cff9=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x16cff9;}else{this['errorBackoff']=0x7530;const _0x5e74b9=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5e74b9);}}['schedule'](_0x1a4875=!0x1){if(!this['isRunning'])return;const _0x185da0=this['getInterval'](_0x1a4875);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x185da0);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x126f01){(_0x126f01==null?void 0x0:_0x126f01['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mi{constructor(_0x4a4b13,_0x717da3){this['createdAt']=_0x4a4b13,this['lastLoginAt']=_0x717da3,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x3c52ee){this['createdAt']=_0x3c52ee['createdAt'],this['lastLoginAt']=_0x3c52ee['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x190026){var _0x479f2d;const _0x413db0=_0x190026['auth'],_0x504e6e=await _0x190026['getIdToken'](),_0x464c0f=await Vt(_0x190026,kn(_0x413db0,{'idToken':_0x504e6e}));m(_0x464c0f==null?void 0x0:_0x464c0f['users']['length'],_0x413db0,'internal-error');const _0x368a8c=_0x464c0f['users'][0x0];_0x190026['_notifyReloadListener'](_0x368a8c);const _0xced61f=(_0x479f2d=_0x368a8c['providerUserInfo'])!=null&&_0x479f2d['length']?Ia(_0x368a8c['providerUserInfo']):[],_0x4bf6ca=If(_0x190026['providerData'],_0xced61f),_0xf8b7fc=_0x190026['isAnonymous'],_0xae76f7=!(_0x190026['email']&&_0x368a8c['passwordHash'])&&!(_0x4bf6ca!=null&&_0x4bf6ca['length']),_0x472783=_0xf8b7fc?_0xae76f7:!0x1,_0x43fea6={'uid':_0x368a8c['localId'],'displayName':_0x368a8c['displayName']||null,'photoURL':_0x368a8c['photoUrl']||null,'email':_0x368a8c['email']||null,'emailVerified':_0x368a8c['emailVerified']||!0x1,'phoneNumber':_0x368a8c['phoneNumber']||null,'tenantId':_0x368a8c['tenantId']||null,'providerData':_0x4bf6ca,'metadata':new Mi(_0x368a8c['createdAt'],_0x368a8c['lastLoginAt']),'isAnonymous':_0x472783};Object['assign'](_0x190026,_0x43fea6);}async function Ef(_0x4d009f){const _0x515623=N(_0x4d009f);await Nn(_0x515623),await _0x515623['auth']['_persistUserIfCurrent'](_0x515623),_0x515623['auth']['_notifyListenersIfCurrent'](_0x515623);}function If(_0x3f0d42,_0x1a62a4){return[..._0x3f0d42['filter'](_0x17ab12=>!_0x1a62a4['some'](_0x45a9f2=>_0x45a9f2['providerId']===_0x17ab12['providerId'])),..._0x1a62a4];}function Ia(_0x9bc2e8){return _0x9bc2e8['map'](({providerId:_0x34ecec,..._0x581b55})=>({'providerId':_0x34ecec,'uid':_0x581b55['rawId']||'','displayName':_0x581b55['displayName']||null,'email':_0x581b55['email']||null,'phoneNumber':_0x581b55['phoneNumber']||null,'photoURL':_0x581b55['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function wf(_0x36b4d8,_0x227b73){const _0x10db53=await va(_0x36b4d8,{},async()=>{const _0x78058=ht({'grant_type':'refresh_token','refresh_token':_0x227b73})['slice'](0x1),{tokenApiHost:_0xd82097,apiKey:_0x38f59d}=_0x36b4d8['config'],_0x5a2089=await Ea(_0x36b4d8,_0xd82097,'/v1/token','key='+_0x38f59d),_0x288ec0=await _0x36b4d8['_getAdditionalHeaders']();_0x288ec0['Content-Type']='application/x-www-form-urlencoded';const _0x3f08f8={'method':'POST','headers':_0x288ec0,'body':_0x78058};return _0x36b4d8['emulatorConfig']&&Gt(_0x36b4d8['emulatorConfig']['host'])&&(_0x3f08f8['credentials']='include'),ya['fetch']()(_0x5a2089,_0x3f08f8);});return{'accessToken':_0x10db53['access_token'],'expiresIn':_0x10db53['expires_in'],'refreshToken':_0x10db53['refresh_token']};}async function Cf(_0x55386b,_0x3cfc31){return Ae(_0x55386b,'POST','/v2/accounts:revokeToken',Re(_0x55386b,_0x3cfc31));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ze{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5d4211){m(_0x5d4211['idToken'],'internal-error'),m(typeof _0x5d4211['idToken']<'u','internal-error'),m(typeof _0x5d4211['refreshToken']<'u','internal-error');const _0x6cc140='expiresIn'in _0x5d4211&&typeof _0x5d4211['expiresIn']<'u'?Number(_0x5d4211['expiresIn']):Cr(_0x5d4211['idToken']);this['updateTokensAndExpiration'](_0x5d4211['idToken'],_0x5d4211['refreshToken'],_0x6cc140);}['updateFromIdToken'](_0x55b54e){m(_0x55b54e['length']!==0x0,'internal-error');const _0x448769=Cr(_0x55b54e);this['updateTokensAndExpiration'](_0x55b54e,null,_0x448769);}async['getToken'](_0x18084f,_0x290db3=!0x1){return!_0x290db3&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x18084f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x18084f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x41e339,_0x51142b){const {accessToken:_0x14aefe,refreshToken:_0x2dbf64,expiresIn:_0x27cc6a}=await wf(_0x41e339,_0x51142b);this['updateTokensAndExpiration'](_0x14aefe,_0x2dbf64,Number(_0x27cc6a));}['updateTokensAndExpiration'](_0x5bd6e4,_0x468aa1,_0x21e78a){this['refreshToken']=_0x468aa1||null,this['accessToken']=_0x5bd6e4||null,this['expirationTime']=Date['now']()+_0x21e78a*0x3e8;}static['fromJSON'](_0x1bb91c,_0x576af4){const {refreshToken:_0x188ab1,accessToken:_0x4ee328,expirationTime:_0xbf0532}=_0x576af4,_0x255d7a=new Ze();return _0x188ab1&&(m(typeof _0x188ab1=='string','internal-error',{'appName':_0x1bb91c}),_0x255d7a['refreshToken']=_0x188ab1),_0x4ee328&&(m(typeof _0x4ee328=='string','internal-error',{'appName':_0x1bb91c}),_0x255d7a['accessToken']=_0x4ee328),_0xbf0532&&(m(typeof _0xbf0532=='number','internal-error',{'appName':_0x1bb91c}),_0x255d7a['expirationTime']=_0xbf0532),_0x255d7a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3dbbdd){this['accessToken']=_0x3dbbdd['accessToken'],this['refreshToken']=_0x3dbbdd['refreshToken'],this['expirationTime']=_0x3dbbdd['expirationTime'];}['_clone'](){return Object['assign'](new Ze(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3a7f73,_0x61ee22){m(typeof _0x3a7f73=='string'||typeof _0x3a7f73>'u','internal-error',{'appName':_0x61ee22});}class j{constructor({uid:_0x4ac8b2,auth:_0x3bb3b4,stsTokenManager:_0x213ec5,..._0x151ca3}){this['providerId']='firebase',this['proactiveRefresh']=new vf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4ac8b2,this['auth']=_0x3bb3b4,this['stsTokenManager']=_0x213ec5,this['accessToken']=_0x213ec5['accessToken'],this['displayName']=_0x151ca3['displayName']||null,this['email']=_0x151ca3['email']||null,this['emailVerified']=_0x151ca3['emailVerified']||!0x1,this['phoneNumber']=_0x151ca3['phoneNumber']||null,this['photoURL']=_0x151ca3['photoURL']||null,this['isAnonymous']=_0x151ca3['isAnonymous']||!0x1,this['tenantId']=_0x151ca3['tenantId']||null,this['providerData']=_0x151ca3['providerData']?[..._0x151ca3['providerData']]:[],this['metadata']=new Mi(_0x151ca3['createdAt']||void 0x0,_0x151ca3['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1a86e0){const _0x35f94b=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1a86e0));return m(_0x35f94b,this['auth'],'internal-error'),this['accessToken']!==_0x35f94b&&(this['accessToken']=_0x35f94b,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x35f94b;}['getIdTokenResult'](_0x2724a0){return mf(this,_0x2724a0);}['reload'](){return Ef(this);}['_assign'](_0x36825d){this!==_0x36825d&&(m(this['uid']===_0x36825d['uid'],this['auth'],'internal-error'),this['displayName']=_0x36825d['displayName'],this['photoURL']=_0x36825d['photoURL'],this['email']=_0x36825d['email'],this['emailVerified']=_0x36825d['emailVerified'],this['phoneNumber']=_0x36825d['phoneNumber'],this['isAnonymous']=_0x36825d['isAnonymous'],this['tenantId']=_0x36825d['tenantId'],this['providerData']=_0x36825d['providerData']['map'](_0x3a96e7=>({..._0x3a96e7})),this['metadata']['_copy'](_0x36825d['metadata']),this['stsTokenManager']['_assign'](_0x36825d['stsTokenManager']));}['_clone'](_0x2f6239){const _0x1d2ff4=new j({...this,'auth':_0x2f6239,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1d2ff4['metadata']['_copy'](this['metadata']),_0x1d2ff4;}['_onReload'](_0xce1a5d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xce1a5d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3ac62a){this['reloadListener']?this['reloadListener'](_0x3ac62a):this['reloadUserInfo']=_0x3ac62a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2b3c92,_0x3c1e63=!0x1){let _0x4fd108=!0x1;_0x2b3c92['idToken']&&_0x2b3c92['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2b3c92),_0x4fd108=!0x0),_0x3c1e63&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4fd108&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1ba4a9=await this['getIdToken']();return await Vt(this,gf(this['auth'],{'idToken':_0x1ba4a9})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4fef90=>({..._0x4fef90})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1e6243,_0x222fc5){const _0x27f0b9=_0x222fc5['displayName']??void 0x0,_0x577cf0=_0x222fc5['email']??void 0x0,_0x3e105e=_0x222fc5['phoneNumber']??void 0x0,_0x1af76f=_0x222fc5['photoURL']??void 0x0,_0x24d1d7=_0x222fc5['tenantId']??void 0x0,_0x178a6e=_0x222fc5['_redirectEventId']??void 0x0,_0x3fdbf6=_0x222fc5['createdAt']??void 0x0,_0x3b840d=_0x222fc5['lastLoginAt']??void 0x0,{uid:_0x1db0be,emailVerified:_0x96940b,isAnonymous:_0x35a497,providerData:_0x286660,stsTokenManager:_0x359c5a}=_0x222fc5;m(_0x1db0be&&_0x359c5a,_0x1e6243,'internal-error');const _0xffa1f4=Ze['fromJSON'](this['name'],_0x359c5a);m(typeof _0x1db0be=='string',_0x1e6243,'internal-error'),le(_0x27f0b9,_0x1e6243['name']),le(_0x577cf0,_0x1e6243['name']),m(typeof _0x96940b=='boolean',_0x1e6243,'internal-error'),m(typeof _0x35a497=='boolean',_0x1e6243,'internal-error'),le(_0x3e105e,_0x1e6243['name']),le(_0x1af76f,_0x1e6243['name']),le(_0x24d1d7,_0x1e6243['name']),le(_0x178a6e,_0x1e6243['name']),le(_0x3fdbf6,_0x1e6243['name']),le(_0x3b840d,_0x1e6243['name']);const _0x6ed82a=new j({'uid':_0x1db0be,'auth':_0x1e6243,'email':_0x577cf0,'emailVerified':_0x96940b,'displayName':_0x27f0b9,'isAnonymous':_0x35a497,'photoURL':_0x1af76f,'phoneNumber':_0x3e105e,'tenantId':_0x24d1d7,'stsTokenManager':_0xffa1f4,'createdAt':_0x3fdbf6,'lastLoginAt':_0x3b840d});return _0x286660&&Array['isArray'](_0x286660)&&(_0x6ed82a['providerData']=_0x286660['map'](_0x3ef096=>({..._0x3ef096}))),_0x178a6e&&(_0x6ed82a['_redirectEventId']=_0x178a6e),_0x6ed82a;}static async['_fromIdTokenResponse'](_0xc48ad5,_0x2f63e2,_0x866fe2=!0x1){const _0x4e0881=new Ze();_0x4e0881['updateFromServerResponse'](_0x2f63e2);const _0x1205e7=new j({'uid':_0x2f63e2['localId'],'auth':_0xc48ad5,'stsTokenManager':_0x4e0881,'isAnonymous':_0x866fe2});return await Nn(_0x1205e7),_0x1205e7;}static async['_fromGetAccountInfoResponse'](_0x35946b,_0x3d7d57,_0x4b3984){const _0x3751f6=_0x3d7d57['users'][0x0];m(_0x3751f6['localId']!==void 0x0,'internal-error');const _0x3d9ddc=_0x3751f6['providerUserInfo']!==void 0x0?Ia(_0x3751f6['providerUserInfo']):[],_0x218977=!(_0x3751f6['email']&&_0x3751f6['passwordHash'])&&!(_0x3d9ddc!=null&&_0x3d9ddc['length']),_0x294faa=new Ze();_0x294faa['updateFromIdToken'](_0x4b3984);const _0x38f9df=new j({'uid':_0x3751f6['localId'],'auth':_0x35946b,'stsTokenManager':_0x294faa,'isAnonymous':_0x218977}),_0x59a3ef={'uid':_0x3751f6['localId'],'displayName':_0x3751f6['displayName']||null,'photoURL':_0x3751f6['photoUrl']||null,'email':_0x3751f6['email']||null,'emailVerified':_0x3751f6['emailVerified']||!0x1,'phoneNumber':_0x3751f6['phoneNumber']||null,'tenantId':_0x3751f6['tenantId']||null,'providerData':_0x3d9ddc,'metadata':new Mi(_0x3751f6['createdAt'],_0x3751f6['lastLoginAt']),'isAnonymous':!(_0x3751f6['email']&&_0x3751f6['passwordHash'])&&!(_0x3d9ddc!=null&&_0x3d9ddc['length'])};return Object['assign'](_0x38f9df,_0x59a3ef),_0x38f9df;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x55a4e5){ce(_0x55a4e5 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5decc8=Tr['get'](_0x55a4e5);return _0x5decc8?(ce(_0x5decc8 instanceof _0x55a4e5,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5decc8):(_0x5decc8=new _0x55a4e5(),Tr['set'](_0x55a4e5,_0x5decc8),_0x5decc8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x41d492,_0x24d57b){this['storage'][_0x41d492]=_0x24d57b;}async['_get'](_0xe30fb4){const _0x517d3e=this['storage'][_0xe30fb4];return _0x517d3e===void 0x0?null:_0x517d3e;}async['_remove'](_0x265c5d){delete this['storage'][_0x265c5d];}['_addListener'](_0x1817c4,_0x531811){}['_removeListener'](_0x15daf3,_0x2280c1){}}wa['type']='NONE';const Sr=wa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cn(_0x2ea3d9,_0x202ea9,_0x9f6656){return'firebase:'+_0x2ea3d9+':'+_0x202ea9+':'+_0x9f6656;}class et{constructor(_0x5063e6,_0x4a5527,_0x5db18b){this['persistence']=_0x5063e6,this['auth']=_0x4a5527,this['userKey']=_0x5db18b;const {config:_0x202cd7,name:_0x14cc42}=this['auth'];this['fullUserKey']=cn(this['userKey'],_0x202cd7['apiKey'],_0x14cc42),this['fullPersistenceKey']=cn('persistence',_0x202cd7['apiKey'],_0x14cc42),this['boundEventHandler']=_0x4a5527['_onStorageEvent']['bind'](_0x4a5527),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5eec8d){return this['persistence']['_set'](this['fullUserKey'],_0x5eec8d['toJSON']());}async['getCurrentUser'](){const _0xbc5822=await this['persistence']['_get'](this['fullUserKey']);if(!_0xbc5822)return null;if(typeof _0xbc5822=='string'){const _0xc636c7=await kn(this['auth'],{'idToken':_0xbc5822})['catch'](()=>{});return _0xc636c7?j['_fromGetAccountInfoResponse'](this['auth'],_0xc636c7,_0xbc5822):null;}return j['_fromJSON'](this['auth'],_0xbc5822);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x120c23){if(this['persistence']===_0x120c23)return;const _0x2e3dec=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x120c23,_0x2e3dec)return this['setCurrentUser'](_0x2e3dec);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2e28b0,_0x33bf79,_0x107e55='authUser'){if(!_0x33bf79['length'])return new et(ie(Sr),_0x2e28b0,_0x107e55);const _0x25478d=(await Promise['all'](_0x33bf79['map'](async _0x13979d=>{if(await _0x13979d['_isAvailable']())return _0x13979d;})))['filter'](_0x5cac56=>_0x5cac56);let _0x387339=_0x25478d[0x0]||ie(Sr);const _0x4cf9d9=cn(_0x107e55,_0x2e28b0['config']['apiKey'],_0x2e28b0['name']);let _0x2f1f12=null;for(const _0x1caa7a of _0x33bf79)try{const _0x5d7de9=await _0x1caa7a['_get'](_0x4cf9d9);if(_0x5d7de9){let _0x5ceb40;if(typeof _0x5d7de9=='string'){const _0x62227b=await kn(_0x2e28b0,{'idToken':_0x5d7de9})['catch'](()=>{});if(!_0x62227b)break;_0x5ceb40=await j['_fromGetAccountInfoResponse'](_0x2e28b0,_0x62227b,_0x5d7de9);}else _0x5ceb40=j['_fromJSON'](_0x2e28b0,_0x5d7de9);_0x1caa7a!==_0x387339&&(_0x2f1f12=_0x5ceb40),_0x387339=_0x1caa7a;break;}}catch{}const _0x5d1a7e=_0x25478d['filter'](_0x51e1b0=>_0x51e1b0['_shouldAllowMigration']);return!_0x387339['_shouldAllowMigration']||!_0x5d1a7e['length']?new et(_0x387339,_0x2e28b0,_0x107e55):(_0x387339=_0x5d1a7e[0x0],_0x2f1f12&&await _0x387339['_set'](_0x4cf9d9,_0x2f1f12['toJSON']()),await Promise['all'](_0x33bf79['map'](async _0x3de1c1=>{if(_0x3de1c1!==_0x387339)try{await _0x3de1c1['_remove'](_0x4cf9d9);}catch{}})),new et(_0x387339,_0x2e28b0,_0x107e55));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5164b1){const _0x4a06c5=_0x5164b1['toLowerCase']();if(_0x4a06c5['includes']('opera/')||_0x4a06c5['includes']('opr/')||_0x4a06c5['includes']('opios/'))return'Opera';if(ba(_0x4a06c5))return'IEMobile';if(_0x4a06c5['includes']('msie')||_0x4a06c5['includes']('trident/'))return'IE';if(_0x4a06c5['includes']('edge/'))return'Edge';if(Ca(_0x4a06c5))return'Firefox';if(_0x4a06c5['includes']('silk/'))return'Silk';if(Aa(_0x4a06c5))return'Blackberry';if(ka(_0x4a06c5))return'Webos';if(Ta(_0x4a06c5))return'Safari';if((_0x4a06c5['includes']('chrome/')||Sa(_0x4a06c5))&&!_0x4a06c5['includes']('edge/'))return'Chrome';if(Ra(_0x4a06c5))return'Android';{const _0x4f709d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x224dc2=_0x5164b1['match'](_0x4f709d);if((_0x224dc2==null?void 0x0:_0x224dc2['length'])===0x2)return _0x224dc2[0x1];}return'Other';}function Ca(_0x5e099e=W()){return/firefox\//i['test'](_0x5e099e);}function Ta(_0x1e296f=W()){const _0x214327=_0x1e296f['toLowerCase']();return _0x214327['includes']('safari/')&&!_0x214327['includes']('chrome/')&&!_0x214327['includes']('crios/')&&!_0x214327['includes']('android');}function Sa(_0x43a4f3=W()){return/crios\//i['test'](_0x43a4f3);}function ba(_0x4c6b9c=W()){return/iemobile/i['test'](_0x4c6b9c);}function Ra(_0x1e645b=W()){return/android/i['test'](_0x1e645b);}function Aa(_0x3ddfdb=W()){return/blackberry/i['test'](_0x3ddfdb);}function ka(_0x4ab174=W()){return/webos/i['test'](_0x4ab174);}function Ss(_0x458beb=W()){return/iphone|ipad|ipod/i['test'](_0x458beb)||/macintosh/i['test'](_0x458beb)&&/mobile/i['test'](_0x458beb);}function Tf(_0x30fdd8=W()){var _0x424019;return Ss(_0x30fdd8)&&!!((_0x424019=window['navigator'])!=null&&_0x424019['standalone']);}function Sf(){return hc()&&document['documentMode']===0xa;}function Na(_0x110b15=W()){return Ss(_0x110b15)||Ra(_0x110b15)||ka(_0x110b15)||Aa(_0x110b15)||/windows phone/i['test'](_0x110b15)||ba(_0x110b15);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pa(_0x41a172,_0x27b8cd=[]){let _0x1d1011;switch(_0x41a172){case'Browser':_0x1d1011=br(W());break;case'Worker':_0x1d1011=br(W())+'-'+_0x41a172;break;default:_0x1d1011=_0x41a172;}const _0x260508=_0x27b8cd['length']?_0x27b8cd['join'](','):'FirebaseCore-web';return _0x1d1011+'/JsCore/'+ut+'/'+_0x260508;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3a3440){this['auth']=_0x3a3440,this['queue']=[];}['pushCallback'](_0x272fef,_0x372764){const _0x1a28a0=_0x3d091e=>new Promise((_0x35bed4,_0x2463a6)=>{try{const _0x73efca=_0x272fef(_0x3d091e);_0x35bed4(_0x73efca);}catch(_0x1adb5a){_0x2463a6(_0x1adb5a);}});_0x1a28a0['onAbort']=_0x372764,this['queue']['push'](_0x1a28a0);const _0x40d8e0=this['queue']['length']-0x1;return()=>{this['queue'][_0x40d8e0]=()=>Promise['resolve']();};}async['runMiddleware'](_0x55c62f){if(this['auth']['currentUser']===_0x55c62f)return;const _0x5964fe=[];try{for(const _0x567602 of this['queue'])await _0x567602(_0x55c62f),_0x567602['onAbort']&&_0x5964fe['push'](_0x567602['onAbort']);}catch(_0x5edf58){_0x5964fe['reverse']();for(const _0x1cfc38 of _0x5964fe)try{_0x1cfc38();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5edf58==null?void 0x0:_0x5edf58['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rf(_0x4de7f5,_0x500f07={}){return Ae(_0x4de7f5,'GET','/v2/passwordPolicy',Re(_0x4de7f5,_0x500f07));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Af=0x6;class kf{constructor(_0xc0060a){var _0x5a998c;const _0x8b0008=_0xc0060a['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x8b0008['minPasswordLength']??Af,_0x8b0008['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x8b0008['maxPasswordLength']),_0x8b0008['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x8b0008['containsLowercaseCharacter']),_0x8b0008['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x8b0008['containsUppercaseCharacter']),_0x8b0008['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x8b0008['containsNumericCharacter']),_0x8b0008['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x8b0008['containsNonAlphanumericCharacter']),this['enforcementState']=_0xc0060a['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5a998c=_0xc0060a['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5a998c['join'](''))??'',this['forceUpgradeOnSignin']=_0xc0060a['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xc0060a['schemaVersion'];}['validatePassword'](_0x33555f){const _0x10ccd0={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x33555f,_0x10ccd0),this['validatePasswordCharacterOptions'](_0x33555f,_0x10ccd0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['meetsMinPasswordLength']??!0x0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['meetsMaxPasswordLength']??!0x0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['containsLowercaseLetter']??!0x0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['containsUppercaseLetter']??!0x0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['containsNumericCharacter']??!0x0),_0x10ccd0['isValid']&&(_0x10ccd0['isValid']=_0x10ccd0['containsNonAlphanumericCharacter']??!0x0),_0x10ccd0;}['validatePasswordLengthOptions'](_0x6ebcf7,_0x26944d){const _0x2eddaa=this['customStrengthOptions']['minPasswordLength'],_0x3ec74b=this['customStrengthOptions']['maxPasswordLength'];_0x2eddaa&&(_0x26944d['meetsMinPasswordLength']=_0x6ebcf7['length']>=_0x2eddaa),_0x3ec74b&&(_0x26944d['meetsMaxPasswordLength']=_0x6ebcf7['length']<=_0x3ec74b);}['validatePasswordCharacterOptions'](_0xa590bd,_0x5df90c){this['updatePasswordCharacterOptionsStatuses'](_0x5df90c,!0x1,!0x1,!0x1,!0x1);let _0x1d2a3d;for(let _0x332869=0x0;_0x332869<_0xa590bd['length'];_0x332869++)_0x1d2a3d=_0xa590bd['charAt'](_0x332869),this['updatePasswordCharacterOptionsStatuses'](_0x5df90c,_0x1d2a3d>='a'&&_0x1d2a3d<='z',_0x1d2a3d>='A'&&_0x1d2a3d<='Z',_0x1d2a3d>='0'&&_0x1d2a3d<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1d2a3d));}['updatePasswordCharacterOptionsStatuses'](_0x2146af,_0x237a2e,_0x35d617,_0x43927a,_0x37728d){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2146af['containsLowercaseLetter']||(_0x2146af['containsLowercaseLetter']=_0x237a2e)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2146af['containsUppercaseLetter']||(_0x2146af['containsUppercaseLetter']=_0x35d617)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2146af['containsNumericCharacter']||(_0x2146af['containsNumericCharacter']=_0x43927a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2146af['containsNonAlphanumericCharacter']||(_0x2146af['containsNonAlphanumericCharacter']=_0x37728d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nf{constructor(_0xfe8972,_0x501a31,_0x469fdb,_0x257ec7){this['app']=_0xfe8972,this['heartbeatServiceProvider']=_0x501a31,this['appCheckServiceProvider']=_0x469fdb,this['config']=_0x257ec7,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new bf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ga,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xfe8972['name'],this['clientVersion']=_0x257ec7['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x38ea56=>this['_resolvePersistenceManagerAvailable']=_0x38ea56);}['_initializeWithPersistence'](_0x4c7e96,_0x44273a){return _0x44273a&&(this['_popupRedirectResolver']=ie(_0x44273a)),this['_initializationPromise']=this['queue'](async()=>{var _0x189cdf,_0x57f60f,_0x17d15e;if(!this['_deleted']&&(this['persistenceManager']=await et['create'](this,_0x4c7e96),(_0x189cdf=this['_resolvePersistenceManagerAvailable'])==null||_0x189cdf['call'](this),!this['_deleted'])){if((_0x57f60f=this['_popupRedirectResolver'])!=null&&_0x57f60f['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x44273a),this['lastNotifiedUid']=((_0x17d15e=this['currentUser'])==null?void 0x0:_0x17d15e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x11828e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x11828e)){if(this['currentUser']&&_0x11828e&&this['currentUser']['uid']===_0x11828e['uid']){this['_currentUser']['_assign'](_0x11828e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x11828e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x33156b){try{const _0x5c2340=await kn(this,{'idToken':_0x33156b}),_0x39cd84=await j['_fromGetAccountInfoResponse'](this,_0x5c2340,_0x33156b);await this['directlySetCurrentUser'](_0x39cd84);}catch(_0x1ab504){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1ab504),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2898a1){var _0x9f3190;if($(this['app'])){const _0x44e290=this['app']['settings']['authIdToken'];return _0x44e290?new Promise(_0x59f5a4=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x44e290)['then'](_0x59f5a4,_0x59f5a4));}):this['directlySetCurrentUser'](null);}const _0x3645fd=await this['assertedPersistence']['getCurrentUser']();let _0x38b702=_0x3645fd,_0x5a07ff=!0x1;if(_0x2898a1&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x531b79=(_0x9f3190=this['redirectUser'])==null?void 0x0:_0x9f3190['_redirectEventId'],_0x6f4790=_0x38b702==null?void 0x0:_0x38b702['_redirectEventId'],_0x5e7a37=await this['tryRedirectSignIn'](_0x2898a1);(!_0x531b79||_0x531b79===_0x6f4790)&&(_0x5e7a37!=null&&_0x5e7a37['user'])&&(_0x38b702=_0x5e7a37['user'],_0x5a07ff=!0x0);}if(!_0x38b702)return this['directlySetCurrentUser'](null);if(!_0x38b702['_redirectEventId']){if(_0x5a07ff)try{await this['beforeStateQueue']['runMiddleware'](_0x38b702);}catch(_0x269e70){_0x38b702=_0x3645fd,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x269e70));}return _0x38b702?this['reloadAndSetCurrentUserOrClear'](_0x38b702):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x38b702['_redirectEventId']?this['directlySetCurrentUser'](_0x38b702):this['reloadAndSetCurrentUserOrClear'](_0x38b702);}async['tryRedirectSignIn'](_0x12cb11){let _0x5009ea=null;try{_0x5009ea=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x12cb11,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5009ea;}async['reloadAndSetCurrentUserOrClear'](_0x3c4376){try{await Nn(_0x3c4376);}catch(_0x5266e5){if((_0x5266e5==null?void 0x0:_0x5266e5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3c4376);}['useDeviceLanguage'](){this['languageCode']=cf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5826ea){if($(this['app']))return Promise['reject'](re(this));const _0x58d507=_0x5826ea?N(_0x5826ea):null;return _0x58d507&&m(_0x58d507['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x58d507&&_0x58d507['_clone'](this));}async['_updateCurrentUser'](_0x14d572,_0x26b829=!0x1){if(!this['_deleted'])return _0x14d572&&m(this['tenantId']===_0x14d572['tenantId'],this,'tenant-id-mismatch'),_0x26b829||await this['beforeStateQueue']['runMiddleware'](_0x14d572),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x14d572),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3eae0b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3eae0b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2d0518){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2ceafd=this['_getPasswordPolicyInternal']();return _0x2ceafd['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2ceafd['validatePassword'](_0x2d0518);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4a8d11=await Rf(this),_0x5ea0cc=new kf(_0x4a8d11);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5ea0cc:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5ea0cc;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x357cb4){this['_errorFactory']=new $t('auth','Firebase',_0x357cb4());}['onAuthStateChanged'](_0x4f2960,_0x3d1c93,_0x4f3d14){return this['registerStateListener'](this['authStateSubscription'],_0x4f2960,_0x3d1c93,_0x4f3d14);}['beforeAuthStateChanged'](_0x5c24c8,_0x16ad7e){return this['beforeStateQueue']['pushCallback'](_0x5c24c8,_0x16ad7e);}['onIdTokenChanged'](_0x395e25,_0x20bcc7,_0x5a9a56){return this['registerStateListener'](this['idTokenSubscription'],_0x395e25,_0x20bcc7,_0x5a9a56);}['authStateReady'](){return new Promise((_0x1c4de0,_0x43c7f7)=>{if(this['currentUser'])_0x1c4de0();else{const _0x556be1=this['onAuthStateChanged'](()=>{_0x556be1(),_0x1c4de0();},_0x43c7f7);}});}async['revokeAccessToken'](_0x4df89d){if(this['currentUser']){const _0x25fa48=await this['currentUser']['getIdToken'](),_0x11fe16={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4df89d,'idToken':_0x25fa48};this['tenantId']!=null&&(_0x11fe16['tenantId']=this['tenantId']),await Cf(this,_0x11fe16);}}['toJSON'](){var _0x4766a8;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4766a8=this['_currentUser'])==null?void 0x0:_0x4766a8['toJSON']()};}async['_setRedirectUser'](_0x31ac9d,_0x17bae5){const _0x13cd21=await this['getOrInitRedirectPersistenceManager'](_0x17bae5);return _0x31ac9d===null?_0x13cd21['removeCurrentUser']():_0x13cd21['setCurrentUser'](_0x31ac9d);}async['getOrInitRedirectPersistenceManager'](_0x4de9f8){if(!this['redirectPersistenceManager']){const _0x5cce17=_0x4de9f8&&ie(_0x4de9f8)||this['_popupRedirectResolver'];m(_0x5cce17,this,'argument-error'),this['redirectPersistenceManager']=await et['create'](this,[ie(_0x5cce17['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xa03960){var _0x34ce9b,_0x14bcf0;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x34ce9b=this['_currentUser'])==null?void 0x0:_0x34ce9b['_redirectEventId'])===_0xa03960?this['_currentUser']:((_0x14bcf0=this['redirectUser'])==null?void 0x0:_0x14bcf0['_redirectEventId'])===_0xa03960?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x25af67){if(_0x25af67===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x25af67));}['_notifyListenersIfCurrent'](_0x177fad){_0x177fad===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1c5042;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x85201d=((_0x1c5042=this['currentUser'])==null?void 0x0:_0x1c5042['uid'])??null;this['lastNotifiedUid']!==_0x85201d&&(this['lastNotifiedUid']=_0x85201d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3cfe3b,_0x41df95,_0x341cb7,_0xbf3601){if(this['_deleted'])return()=>{};const _0x33cd92=typeof _0x41df95=='function'?_0x41df95:_0x41df95['next']['bind'](_0x41df95);let _0x19b368=!0x1;const _0x330b9a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x330b9a,this,'internal-error'),_0x330b9a['then'](()=>{_0x19b368||_0x33cd92(this['currentUser']);}),typeof _0x41df95=='function'){const _0x46c497=_0x3cfe3b['addObserver'](_0x41df95,_0x341cb7,_0xbf3601);return()=>{_0x19b368=!0x0,_0x46c497();};}else{const _0x4a7e67=_0x3cfe3b['addObserver'](_0x41df95);return()=>{_0x19b368=!0x0,_0x4a7e67();};}}async['directlySetCurrentUser'](_0x4e3927){this['currentUser']&&this['currentUser']!==_0x4e3927&&this['_currentUser']['_stopProactiveRefresh'](),_0x4e3927&&this['isProactiveRefreshEnabled']&&_0x4e3927['_startProactiveRefresh'](),this['currentUser']=_0x4e3927,_0x4e3927?await this['assertedPersistence']['setCurrentUser'](_0x4e3927):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3d3b6a){return this['operations']=this['operations']['then'](_0x3d3b6a,_0x3d3b6a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4e5cef){!_0x4e5cef||this['frameworks']['includes'](_0x4e5cef)||(this['frameworks']['push'](_0x4e5cef),this['frameworks']['sort'](),this['clientVersion']=Pa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2b9d86;const _0x3acdfc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3acdfc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x48bc00=await((_0x2b9d86=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2b9d86['getHeartbeatsHeader']());_0x48bc00&&(_0x3acdfc['X-Firebase-Client']=_0x48bc00);const _0xec7df2=await this['_getAppCheckToken']();return _0xec7df2&&(_0x3acdfc['X-Firebase-AppCheck']=_0xec7df2),_0x3acdfc;}async['_getAppCheckToken'](){var _0x302018;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2c462d=await((_0x302018=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x302018['getToken']());return _0x2c462d!=null&&_0x2c462d['error']&&rf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2c462d['error']),_0x2c462d==null?void 0x0:_0x2c462d['token'];}}function je(_0x1f2413){return N(_0x1f2413);}class Rr{constructor(_0x380620){this['auth']=_0x380620,this['observer']=null,this['addObserver']=Ec(_0x17cfd4=>this['observer']=_0x17cfd4);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Qn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Pf(_0x26fafe){Qn=_0x26fafe;}function Oa(_0x119708){return Qn['loadJS'](_0x119708);}function Of(){return Qn['recaptchaEnterpriseScript'];}function Df(){return Qn['gapiScript'];}function Mf(_0x23abb2){return'__'+_0x23abb2+Math['floor'](Math['random']()*0xf4240);}class Lf{constructor(){this['enterprise']=new xf();}['ready'](_0x41cb2d){_0x41cb2d();}['execute'](_0x1142f7,_0x19dcfb){return Promise['resolve']('token');}['render'](_0x307bfa,_0x557baf){return'';}}class xf{['ready'](_0x205000){_0x205000();}['execute'](_0x18ad27,_0x4bdbb4){return Promise['resolve']('token');}['render'](_0x319507,_0x46faa7){return'';}}const Ff='recaptcha-enterprise',Da='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x1eb509){this['type']=Ff,this['auth']=je(_0x1eb509);}async['verify'](_0x44dc6b='verify',_0x3462e1=!0x1){async function _0x2cc68a(_0x2c328f){if(!_0x3462e1){if(_0x2c328f['tenantId']==null&&_0x2c328f['_agentRecaptchaConfig']!=null)return _0x2c328f['_agentRecaptchaConfig']['siteKey'];if(_0x2c328f['tenantId']!=null&&_0x2c328f['_tenantRecaptchaConfigs'][_0x2c328f['tenantId']]!==void 0x0)return _0x2c328f['_tenantRecaptchaConfigs'][_0x2c328f['tenantId']]['siteKey'];}return new Promise(async(_0x2a6eb1,_0x3bc515)=>{_f(_0x2c328f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3c2202=>{if(_0x3c2202['recaptchaKey']===void 0x0)_0x3bc515(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x85e3ee=new pf(_0x3c2202);return _0x2c328f['tenantId']==null?_0x2c328f['_agentRecaptchaConfig']=_0x85e3ee:_0x2c328f['_tenantRecaptchaConfigs'][_0x2c328f['tenantId']]=_0x85e3ee,_0x2a6eb1(_0x85e3ee['siteKey']);}})['catch'](_0x26bb09=>{_0x3bc515(_0x26bb09);});});}function _0x54697b(_0x4437c9,_0x31a15d,_0x352d97){const _0x1608fb=window['grecaptcha'];wr(_0x1608fb)?_0x1608fb['enterprise']['ready'](()=>{_0x1608fb['enterprise']['execute'](_0x4437c9,{'action':_0x44dc6b})['then'](_0x4b2be1=>{_0x31a15d(_0x4b2be1);})['catch'](()=>{_0x31a15d(Da);});}):_0x352d97(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Lf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3a29c7,_0x3f4250)=>{_0x2cc68a(this['auth'])['then'](async _0xbc63d6=>{if(!_0x3462e1&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x54697b(_0xbc63d6,_0x3a29c7,_0x3f4250);else{if(typeof window>'u'){_0x3f4250(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xbacf4a=Of();_0xbacf4a['length']!==0x0&&(_0xbacf4a+=_0xbc63d6+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x43001b;(_0x43001b=he['scriptInjectionDeferred'])==null||_0x43001b['resolve']();},Oa(_0xbacf4a)['then'](()=>{var _0x45c063;return(_0x45c063=he['scriptInjectionDeferred'])==null?void 0x0:_0x45c063['promise'];})['then'](()=>{_0x54697b(_0xbc63d6,_0x3a29c7,_0x3f4250);})['catch'](_0x51f234=>{_0x3f4250(_0x51f234);});}})['catch'](_0x4921ad=>{_0x3f4250(_0x4921ad);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x586fbe,_0x45b96b,_0x119583,_0x21c295=!0x1,_0x3330df=!0x1){const _0x235428=new he(_0x586fbe);let _0x33af00;if(_0x3330df)_0x33af00=Da;else try{_0x33af00=await _0x235428['verify'](_0x119583);}catch{_0x33af00=await _0x235428['verify'](_0x119583,!0x0);}const _0x4b4a6c={..._0x45b96b};if(_0x119583==='mfaSmsEnrollment'||_0x119583==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4b4a6c){const _0x55b878=_0x4b4a6c['phoneEnrollmentInfo']['phoneNumber'],_0x12f349=_0x4b4a6c['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4b4a6c,{'phoneEnrollmentInfo':{'phoneNumber':_0x55b878,'recaptchaToken':_0x12f349,'captchaResponse':_0x33af00,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4b4a6c){const _0x217659=_0x4b4a6c['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4b4a6c,{'phoneSignInInfo':{'recaptchaToken':_0x217659,'captchaResponse':_0x33af00,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4b4a6c;}return _0x21c295?Object['assign'](_0x4b4a6c,{'captchaResp':_0x33af00}):Object['assign'](_0x4b4a6c,{'captchaResponse':_0x33af00}),Object['assign'](_0x4b4a6c,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4b4a6c,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4b4a6c;}async function Li(_0x14611b,_0x12272c,_0x660b40,_0x24e5c8,_0x53221a){var _0x12ce6d;if((_0x12ce6d=_0x14611b['_getRecaptchaConfig']())!=null&&_0x12ce6d['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5bfed0=await kr(_0x14611b,_0x12272c,_0x660b40,_0x660b40==='getOobCode');return _0x24e5c8(_0x14611b,_0x5bfed0);}else return _0x24e5c8(_0x14611b,_0x12272c)['catch'](async _0x4b9259=>{if(_0x4b9259['code']==='auth/missing-recaptcha-token'){console['log'](_0x660b40+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x40a6ff=await kr(_0x14611b,_0x12272c,_0x660b40,_0x660b40==='getOobCode');return _0x24e5c8(_0x14611b,_0x40a6ff);}else return Promise['reject'](_0x4b9259);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x46d485,_0x4b2a0a){const _0x12fd7e=Vi(_0x46d485,'auth');if(_0x12fd7e['isInitialized']()){const _0x14a041=_0x12fd7e['getImmediate'](),_0x147170=_0x12fd7e['getOptions']();if(Le(_0x147170,_0x4b2a0a??{}))return _0x14a041;Y(_0x14a041,'already-initialized');}return _0x12fd7e['initialize']({'options':_0x4b2a0a});}function Wf(_0x58830d,_0x5e4983){const _0x333182=(_0x5e4983==null?void 0x0:_0x5e4983['persistence'])||[],_0x58f15b=(Array['isArray'](_0x333182)?_0x333182:[_0x333182])['map'](ie);_0x5e4983!=null&&_0x5e4983['errorMap']&&_0x58830d['_updateErrorMap'](_0x5e4983['errorMap']),_0x58830d['_initializeWithPersistence'](_0x58f15b,_0x5e4983==null?void 0x0:_0x5e4983['popupRedirectResolver']);}function Bf(_0x46b3a1,_0x2f6407,_0x55b06a){const _0x5390cf=je(_0x46b3a1);m(/^https?:\/\//['test'](_0x2f6407),_0x5390cf,'invalid-emulator-scheme');const _0x37776c=!0x1,_0xe0681f=Ma(_0x2f6407),{host:_0xa1fe22,port:_0x19c3ce}=Vf(_0x2f6407),_0x4f82b3=_0x19c3ce===null?'':':'+_0x19c3ce,_0x2c3324={'url':_0xe0681f+'//'+_0xa1fe22+_0x4f82b3+'/'},_0x368b5b=Object['freeze']({'host':_0xa1fe22,'port':_0x19c3ce,'protocol':_0xe0681f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x37776c})});if(!_0x5390cf['_canInitEmulator']){m(_0x5390cf['config']['emulator']&&_0x5390cf['emulatorConfig'],_0x5390cf,'emulator-config-failed'),m(Le(_0x2c3324,_0x5390cf['config']['emulator'])&&Le(_0x368b5b,_0x5390cf['emulatorConfig']),_0x5390cf,'emulator-config-failed');return;}_0x5390cf['config']['emulator']=_0x2c3324,_0x5390cf['emulatorConfig']=_0x368b5b,_0x5390cf['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0xa1fe22)?Qr(_0xe0681f+'//'+_0xa1fe22+_0x4f82b3):Hf();}function Ma(_0x2d3322){const _0x32ce48=_0x2d3322['indexOf'](':');return _0x32ce48<0x0?'':_0x2d3322['substr'](0x0,_0x32ce48+0x1);}function Vf(_0x4d058c){const _0x11cadc=Ma(_0x4d058c),_0x33274b=/(\/\/)?([^?#/]+)/['exec'](_0x4d058c['substr'](_0x11cadc['length']));if(!_0x33274b)return{'host':'','port':null};const _0x12ac72=_0x33274b[0x2]['split']('@')['pop']()||'',_0x58f6c3=/^(\[[^\]]+\])(:|$)/['exec'](_0x12ac72);if(_0x58f6c3){const _0x493ad5=_0x58f6c3[0x1];return{'host':_0x493ad5,'port':Nr(_0x12ac72['substr'](_0x493ad5['length']+0x1))};}else{const [_0x49c3c9,_0x48be6f]=_0x12ac72['split'](':');return{'host':_0x49c3c9,'port':Nr(_0x48be6f)};}}function Nr(_0x5e6b4c){if(!_0x5e6b4c)return null;const _0x40db0c=Number(_0x5e6b4c);return isNaN(_0x40db0c)?null:_0x40db0c;}function Hf(){function _0x59c43f(){const _0x3b4975=document['createElement']('p'),_0x9c85ef=_0x3b4975['style'];_0x3b4975['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x9c85ef['position']='fixed',_0x9c85ef['width']='100%',_0x9c85ef['backgroundColor']='#ffffff',_0x9c85ef['border']='.1em\x20solid\x20#000000',_0x9c85ef['color']='#b50000',_0x9c85ef['bottom']='0px',_0x9c85ef['left']='0px',_0x9c85ef['margin']='0px',_0x9c85ef['zIndex']='10000',_0x9c85ef['textAlign']='center',_0x3b4975['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3b4975);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x59c43f):_0x59c43f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x2b23e7,_0x5b7e5d){this['providerId']=_0x2b23e7,this['signInMethod']=_0x5b7e5d;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2f269c){return ne('not\x20implemented');}['_linkToIdToken'](_0x34ad6a,_0x7fabc9){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xc46fb0){return ne('not\x20implemented');}}async function $f(_0x5a7c75,_0x22eb3a){return Ae(_0x5a7c75,'POST','/v1/accounts:signUp',_0x22eb3a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x226a01,_0x29016a){return Zt(_0x226a01,'POST','/v1/accounts:signInWithPassword',Re(_0x226a01,_0x29016a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x3f9c0d,_0x23928d){return Zt(_0x3f9c0d,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3f9c0d,_0x23928d));}async function zf(_0x4791eb,_0x45d42b){return Zt(_0x4791eb,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4791eb,_0x45d42b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x5da6fc,_0x4735eb,_0x5c97dd,_0x4d1b87=null){super('password',_0x5c97dd),this['_email']=_0x5da6fc,this['_password']=_0x4735eb,this['_tenantId']=_0x4d1b87;}static['_fromEmailAndPassword'](_0x3a8f0e,_0x509a55){return new Ht(_0x3a8f0e,_0x509a55,'password');}static['_fromEmailAndCode'](_0x518553,_0x49a2eb,_0x153913=null){return new Ht(_0x518553,_0x49a2eb,'emailLink',_0x153913);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3abdb5){const _0x111d79=typeof _0x3abdb5=='string'?JSON['parse'](_0x3abdb5):_0x3abdb5;if(_0x111d79!=null&&_0x111d79['email']&&(_0x111d79!=null&&_0x111d79['password'])){if(_0x111d79['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x111d79['email'],_0x111d79['password']);if(_0x111d79['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x111d79['email'],_0x111d79['password'],_0x111d79['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5afd71){switch(this['signInMethod']){case'password':const _0x20b926={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Li(_0x5afd71,_0x20b926,'signInWithPassword',Gf);case'emailLink':return qf(_0x5afd71,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5afd71,'internal-error');}}async['_linkToIdToken'](_0x3e600d,_0x32251a){switch(this['signInMethod']){case'password':const _0x33220c={'idToken':_0x32251a,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Li(_0x3e600d,_0x33220c,'signUpPassword',$f);case'emailLink':return zf(_0x3e600d,{'idToken':_0x32251a,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3e600d,'internal-error');}}['_getReauthenticationResolver'](_0x56be0d){return this['_getIdTokenResponse'](_0x56be0d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tt(_0x13828e,_0x3cba96){return Zt(_0x13828e,'POST','/v1/accounts:signInWithIdp',Re(_0x13828e,_0x3cba96));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x229c51){const _0x5d0919=new He(_0x229c51['providerId'],_0x229c51['signInMethod']);return _0x229c51['idToken']||_0x229c51['accessToken']?(_0x229c51['idToken']&&(_0x5d0919['idToken']=_0x229c51['idToken']),_0x229c51['accessToken']&&(_0x5d0919['accessToken']=_0x229c51['accessToken']),_0x229c51['nonce']&&!_0x229c51['pendingToken']&&(_0x5d0919['nonce']=_0x229c51['nonce']),_0x229c51['pendingToken']&&(_0x5d0919['pendingToken']=_0x229c51['pendingToken'])):_0x229c51['oauthToken']&&_0x229c51['oauthTokenSecret']?(_0x5d0919['accessToken']=_0x229c51['oauthToken'],_0x5d0919['secret']=_0x229c51['oauthTokenSecret']):Y('argument-error'),_0x5d0919;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x550018){const _0x533185=typeof _0x550018=='string'?JSON['parse'](_0x550018):_0x550018,{providerId:_0x31c61d,signInMethod:_0x9b34a8,..._0x37529d}=_0x533185;if(!_0x31c61d||!_0x9b34a8)return null;const _0x2c34ac=new He(_0x31c61d,_0x9b34a8);return _0x2c34ac['idToken']=_0x37529d['idToken']||void 0x0,_0x2c34ac['accessToken']=_0x37529d['accessToken']||void 0x0,_0x2c34ac['secret']=_0x37529d['secret'],_0x2c34ac['nonce']=_0x37529d['nonce'],_0x2c34ac['pendingToken']=_0x37529d['pendingToken']||null,_0x2c34ac;}['_getIdTokenResponse'](_0x216024){const _0x232a09=this['buildRequest']();return tt(_0x216024,_0x232a09);}['_linkToIdToken'](_0x23a987,_0x5a1d6d){const _0x492bfa=this['buildRequest']();return _0x492bfa['idToken']=_0x5a1d6d,tt(_0x23a987,_0x492bfa);}['_getReauthenticationResolver'](_0x421d8f){const _0x361cdc=this['buildRequest']();return _0x361cdc['autoCreate']=!0x1,tt(_0x421d8f,_0x361cdc);}['buildRequest'](){const _0x13c18a={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x13c18a['pendingToken']=this['pendingToken'];else{const _0x5554da={};this['idToken']&&(_0x5554da['id_token']=this['idToken']),this['accessToken']&&(_0x5554da['access_token']=this['accessToken']),this['secret']&&(_0x5554da['oauth_token_secret']=this['secret']),_0x5554da['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5554da['nonce']=this['nonce']),_0x13c18a['postBody']=ht(_0x5554da);}return _0x13c18a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x931068){switch(_0x931068){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x27e59d){const _0xb22524=wt(Ct(_0x27e59d))['link'],_0x3a613a=_0xb22524?wt(Ct(_0xb22524))['deep_link_id']:null,_0x56f9a2=wt(Ct(_0x27e59d))['deep_link_id'];return(_0x56f9a2?wt(Ct(_0x56f9a2))['link']:null)||_0x56f9a2||_0x3a613a||_0xb22524||_0x27e59d;}class Rs{constructor(_0x58da43){const _0x59a401=wt(Ct(_0x58da43)),_0x49ff34=_0x59a401['apiKey']??null,_0x144762=_0x59a401['oobCode']??null,_0x9812ee=Kf(_0x59a401['mode']??null);m(_0x49ff34&&_0x144762&&_0x9812ee,'argument-error'),this['apiKey']=_0x49ff34,this['operation']=_0x9812ee,this['code']=_0x144762,this['continueUrl']=_0x59a401['continueUrl']??null,this['languageCode']=_0x59a401['lang']??null,this['tenantId']=_0x59a401['tenantId']??null;}static['parseLink'](_0x197f3c){const _0x3a508a=Yf(_0x197f3c);try{return new Rs(_0x3a508a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x241595,_0x5f418d){return Ht['_fromEmailAndPassword'](_0x241595,_0x5f418d);}static['credentialWithLink'](_0x563e5d,_0xfa66f8){const _0x3a0482=Rs['parseLink'](_0xfa66f8);return m(_0x3a0482,'argument-error'),Ht['_fromEmailAndCode'](_0x563e5d,_0x3a0482['code'],_0x3a0482['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class La{constructor(_0x378c16){this['providerId']=_0x378c16,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1554fd){this['defaultLanguageCode']=_0x1554fd;}['setCustomParameters'](_0x119c76){return this['customParameters']=_0x119c76,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en extends La{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x41ee6d){return this['scopes']['includes'](_0x41ee6d)||this['scopes']['push'](_0x41ee6d),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends en{constructor(){super('facebook.com');}static['credential'](_0x5ad349){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5ad349});}static['credentialFromResult'](_0x10246f){return ue['credentialFromTaggedObject'](_0x10246f);}static['credentialFromError'](_0x28a6f8){return ue['credentialFromTaggedObject'](_0x28a6f8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4e7656}){if(!_0x4e7656||!('oauthAccessToken'in _0x4e7656)||!_0x4e7656['oauthAccessToken'])return null;try{return ue['credential'](_0x4e7656['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends en{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5d3143,_0x250896){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5d3143,'accessToken':_0x250896});}static['credentialFromResult'](_0x5e6da0){return de['credentialFromTaggedObject'](_0x5e6da0);}static['credentialFromError'](_0x21f502){return de['credentialFromTaggedObject'](_0x21f502['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4116a4}){if(!_0x4116a4)return null;const {oauthIdToken:_0x5bdbfd,oauthAccessToken:_0x4fa0fc}=_0x4116a4;if(!_0x5bdbfd&&!_0x4fa0fc)return null;try{return de['credential'](_0x5bdbfd,_0x4fa0fc);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends en{constructor(){super('github.com');}static['credential'](_0x52264e){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x52264e});}static['credentialFromResult'](_0x3009f0){return fe['credentialFromTaggedObject'](_0x3009f0);}static['credentialFromError'](_0x34bb4e){return fe['credentialFromTaggedObject'](_0x34bb4e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e8b83}){if(!_0x5e8b83||!('oauthAccessToken'in _0x5e8b83)||!_0x5e8b83['oauthAccessToken'])return null;try{return fe['credential'](_0x5e8b83['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends en{constructor(){super('twitter.com');}static['credential'](_0x1d5974,_0x1eb4dc){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1d5974,'oauthTokenSecret':_0x1eb4dc});}static['credentialFromResult'](_0x837b92){return pe['credentialFromTaggedObject'](_0x837b92);}static['credentialFromError'](_0x5b3735){return pe['credentialFromTaggedObject'](_0x5b3735['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb5b370}){if(!_0xb5b370)return null;const {oauthAccessToken:_0x4bc95c,oauthTokenSecret:_0x4e7641}=_0xb5b370;if(!_0x4bc95c||!_0x4e7641)return null;try{return pe['credential'](_0x4bc95c,_0x4e7641);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x52e934,_0x473ee8){return Zt(_0x52e934,'POST','/v1/accounts:signUp',Re(_0x52e934,_0x473ee8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x921b1a){this['user']=_0x921b1a['user'],this['providerId']=_0x921b1a['providerId'],this['_tokenResponse']=_0x921b1a['_tokenResponse'],this['operationType']=_0x921b1a['operationType'];}static async['_fromIdTokenResponse'](_0x340c21,_0x26bafb,_0x5b9d72,_0x3acfc0=!0x1){const _0x41a1f8=await j['_fromIdTokenResponse'](_0x340c21,_0x5b9d72,_0x3acfc0),_0x26caa7=Pr(_0x5b9d72);return new $e({'user':_0x41a1f8,'providerId':_0x26caa7,'_tokenResponse':_0x5b9d72,'operationType':_0x26bafb});}static async['_forOperation'](_0x347e3a,_0xd80280,_0x199f17){await _0x347e3a['_updateTokensIfNecessary'](_0x199f17,!0x0);const _0x1c6a31=Pr(_0x199f17);return new $e({'user':_0x347e3a,'providerId':_0x1c6a31,'_tokenResponse':_0x199f17,'operationType':_0xd80280});}}function Pr(_0x15615e){return _0x15615e['providerId']?_0x15615e['providerId']:'phoneNumber'in _0x15615e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pn extends be{constructor(_0xeda712,_0x5879da,_0xa1f5a6,_0x190c90){super(_0x5879da['code'],_0x5879da['message']),this['operationType']=_0xa1f5a6,this['user']=_0x190c90,Object['setPrototypeOf'](this,Pn['prototype']),this['customData']={'appName':_0xeda712['name'],'tenantId':_0xeda712['tenantId']??void 0x0,'_serverResponse':_0x5879da['customData']['_serverResponse'],'operationType':_0xa1f5a6};}static['_fromErrorAndOperation'](_0x3ea0aa,_0x3d636e,_0x378c72,_0x28c6ef){return new Pn(_0x3ea0aa,_0x3d636e,_0x378c72,_0x28c6ef);}}function xa(_0x59b53f,_0x474b84,_0x90cce3,_0x50bc53){return(_0x474b84==='reauthenticate'?_0x90cce3['_getReauthenticationResolver'](_0x59b53f):_0x90cce3['_getIdTokenResponse'](_0x59b53f))['catch'](_0x7dccd6=>{throw _0x7dccd6['code']==='auth/multi-factor-auth-required'?Pn['_fromErrorAndOperation'](_0x59b53f,_0x7dccd6,_0x474b84,_0x50bc53):_0x7dccd6;});}async function Jf(_0x53d61f,_0x39ae7d,_0x2b6d02=!0x1){const _0x24933e=await Vt(_0x53d61f,_0x39ae7d['_linkToIdToken'](_0x53d61f['auth'],await _0x53d61f['getIdToken']()),_0x2b6d02);return $e['_forOperation'](_0x53d61f,'link',_0x24933e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x244f60,_0x16ca93,_0x38c530=!0x1){const {auth:_0x564d89}=_0x244f60;if($(_0x564d89['app']))return Promise['reject'](re(_0x564d89));const _0x296571='reauthenticate';try{const _0x185ff7=await Vt(_0x244f60,xa(_0x564d89,_0x296571,_0x16ca93,_0x244f60),_0x38c530);m(_0x185ff7['idToken'],_0x564d89,'internal-error');const _0x28c4fb=Ts(_0x185ff7['idToken']);m(_0x28c4fb,_0x564d89,'internal-error');const {sub:_0x5d0109}=_0x28c4fb;return m(_0x244f60['uid']===_0x5d0109,_0x564d89,'user-mismatch'),$e['_forOperation'](_0x244f60,_0x296571,_0x185ff7);}catch(_0x37fde1){throw(_0x37fde1==null?void 0x0:_0x37fde1['code'])==='auth/user-not-found'&&Y(_0x564d89,'user-mismatch'),_0x37fde1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Fa(_0x33612a,_0x312f62,_0x104281=!0x1){if($(_0x33612a['app']))return Promise['reject'](re(_0x33612a));const _0x4762a1='signIn',_0x39e06f=await xa(_0x33612a,_0x4762a1,_0x312f62),_0x3a8cab=await $e['_fromIdTokenResponse'](_0x33612a,_0x4762a1,_0x39e06f);return _0x104281||await _0x33612a['_updateCurrentUser'](_0x3a8cab['user']),_0x3a8cab;}async function Zf(_0x10ec07,_0x7b4298){return Fa(je(_0x10ec07),_0x7b4298);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x287be3){const _0x591bf6=je(_0x287be3);_0x591bf6['_getPasswordPolicyInternal']()&&await _0x591bf6['_updatePasswordPolicy']();}async function A_(_0x8d8322,_0x2a1803,_0x100cb7){if($(_0x8d8322['app']))return Promise['reject'](re(_0x8d8322));const _0x258ec3=je(_0x8d8322),_0x3b8002=await Li(_0x258ec3,{'returnSecureToken':!0x0,'email':_0x2a1803,'password':_0x100cb7,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x57d6e8=>{throw _0x57d6e8['code']==='auth/password-does-not-meet-requirements'&&Ua(_0x8d8322),_0x57d6e8;}),_0x43df9c=await $e['_fromIdTokenResponse'](_0x258ec3,'signIn',_0x3b8002);return await _0x258ec3['_updateCurrentUser'](_0x43df9c['user']),_0x43df9c;}function k_(_0x24b5af,_0x9b2bd5,_0x3ba46b){return $(_0x24b5af['app'])?Promise['reject'](re(_0x24b5af)):Zf(N(_0x24b5af),mt['credential'](_0x9b2bd5,_0x3ba46b))['catch'](async _0x3e8592=>{throw _0x3e8592['code']==='auth/password-does-not-meet-requirements'&&Ua(_0x24b5af),_0x3e8592;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N_(_0x3e00c6,_0x2d1272){return N(_0x3e00c6)['setPersistence'](_0x2d1272);}function ep(_0x5a694,_0x33caf0,_0x765177,_0x4e91e5){return N(_0x5a694)['onIdTokenChanged'](_0x33caf0,_0x765177,_0x4e91e5);}function tp(_0x1171cb,_0x203e7b,_0x324e14){return N(_0x1171cb)['beforeAuthStateChanged'](_0x203e7b,_0x324e14);}function P_(_0x279827,_0x3e7500,_0x5f2393,_0x3c820c){return N(_0x279827)['onAuthStateChanged'](_0x3e7500,_0x5f2393,_0x3c820c);}function O_(_0x572684){return N(_0x572684)['signOut']();}const On='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3e9707,_0x1e60e0){this['storageRetriever']=_0x3e9707,this['type']=_0x1e60e0;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](On,'1'),this['storage']['removeItem'](On),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1f89fe,_0x37f15d){return this['storage']['setItem'](_0x1f89fe,JSON['stringify'](_0x37f15d)),Promise['resolve']();}['_get'](_0x42ab7f){const _0x3b7724=this['storage']['getItem'](_0x42ab7f);return Promise['resolve'](_0x3b7724?JSON['parse'](_0x3b7724):null);}['_remove'](_0x5f52e4){return this['storage']['removeItem'](_0x5f52e4),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ba extends Wa{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x325e37,_0x2a6c16)=>this['onStorageEvent'](_0x325e37,_0x2a6c16),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Na(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4e37c0){for(const _0x5b5ad1 of Object['keys'](this['listeners'])){const _0x4f4362=this['storage']['getItem'](_0x5b5ad1),_0x46f2db=this['localCache'][_0x5b5ad1];_0x4f4362!==_0x46f2db&&_0x4e37c0(_0x5b5ad1,_0x46f2db,_0x4f4362);}}['onStorageEvent'](_0x51ac02,_0x65a032=!0x1){if(!_0x51ac02['key']){this['forAllChangedKeys']((_0x18f637,_0x496118,_0xfa5fa)=>{this['notifyListeners'](_0x18f637,_0xfa5fa);});return;}const _0xc94651=_0x51ac02['key'];_0x65a032?this['detachListener']():this['stopPolling']();const _0x1ec1c5=()=>{const _0x19fbfe=this['storage']['getItem'](_0xc94651);!_0x65a032&&this['localCache'][_0xc94651]===_0x19fbfe||this['notifyListeners'](_0xc94651,_0x19fbfe);},_0x5c1fa4=this['storage']['getItem'](_0xc94651);Sf()&&_0x5c1fa4!==_0x51ac02['newValue']&&_0x51ac02['newValue']!==_0x51ac02['oldValue']?setTimeout(_0x1ec1c5,ip):_0x1ec1c5();}['notifyListeners'](_0x56c60a,_0x3d94e9){this['localCache'][_0x56c60a]=_0x3d94e9;const _0x5cd699=this['listeners'][_0x56c60a];if(_0x5cd699){for(const _0x302582 of Array['from'](_0x5cd699))_0x302582(_0x3d94e9&&JSON['parse'](_0x3d94e9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2548d6,_0x22c508,_0x39dcbb)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2548d6,'oldValue':_0x22c508,'newValue':_0x39dcbb}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x231d82,_0x1831da){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x231d82]||(this['listeners'][_0x231d82]=new Set(),this['localCache'][_0x231d82]=this['storage']['getItem'](_0x231d82)),this['listeners'][_0x231d82]['add'](_0x1831da);}['_removeListener'](_0xedb8a9,_0x1ababc){this['listeners'][_0xedb8a9]&&(this['listeners'][_0xedb8a9]['delete'](_0x1ababc),this['listeners'][_0xedb8a9]['size']===0x0&&delete this['listeners'][_0xedb8a9]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x21850b,_0xddca56){await super['_set'](_0x21850b,_0xddca56),this['localCache'][_0x21850b]=JSON['stringify'](_0xddca56);}async['_get'](_0x169cec){const _0x39ef7b=await super['_get'](_0x169cec);return this['localCache'][_0x169cec]=JSON['stringify'](_0x39ef7b),_0x39ef7b;}async['_remove'](_0x1ef782){await super['_remove'](_0x1ef782),delete this['localCache'][_0x1ef782];}}Ba['type']='LOCAL';const sp=Ba;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Va extends Wa{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2977d4,_0x44c310){}['_removeListener'](_0x551336,_0x35b8c3){}}Va['type']='SESSION';const Ha=Va;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1ea547){return Promise['all'](_0x1ea547['map'](async _0x556e9b=>{try{return{'fulfilled':!0x0,'value':await _0x556e9b};}catch(_0x5466a2){return{'fulfilled':!0x1,'reason':_0x5466a2};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jn{constructor(_0x53a024){this['eventTarget']=_0x53a024,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x33f649){const _0x52912a=this['receivers']['find'](_0x5f1009=>_0x5f1009['isListeningto'](_0x33f649));if(_0x52912a)return _0x52912a;const _0x273789=new Jn(_0x33f649);return this['receivers']['push'](_0x273789),_0x273789;}['isListeningto'](_0x3ec1dd){return this['eventTarget']===_0x3ec1dd;}async['handleEvent'](_0x29b597){const _0x126f27=_0x29b597,{eventId:_0x562e39,eventType:_0x27992a,data:_0x31bda8}=_0x126f27['data'],_0x3b18c6=this['handlersMap'][_0x27992a];if(!(_0x3b18c6!=null&&_0x3b18c6['size']))return;_0x126f27['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x562e39,'eventType':_0x27992a});const _0x4ac889=Array['from'](_0x3b18c6)['map'](async _0x268c1a=>_0x268c1a(_0x126f27['origin'],_0x31bda8)),_0xad4262=await rp(_0x4ac889);_0x126f27['ports'][0x0]['postMessage']({'status':'done','eventId':_0x562e39,'eventType':_0x27992a,'response':_0xad4262});}['_subscribe'](_0x3d2053,_0x2e3dd1){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3d2053]||(this['handlersMap'][_0x3d2053]=new Set()),this['handlersMap'][_0x3d2053]['add'](_0x2e3dd1);}['_unsubscribe'](_0x40ee6c,_0x18b998){this['handlersMap'][_0x40ee6c]&&_0x18b998&&this['handlersMap'][_0x40ee6c]['delete'](_0x18b998),(!_0x18b998||this['handlersMap'][_0x40ee6c]['size']===0x0)&&delete this['handlersMap'][_0x40ee6c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x19b192='',_0x41cf19=0xa){let _0x1a0159='';for(let _0x5d09a0=0x0;_0x5d09a0<_0x41cf19;_0x5d09a0++)_0x1a0159+=Math['floor'](Math['random']()*0xa);return _0x19b192+_0x1a0159;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0xf4dc57){this['target']=_0xf4dc57,this['handlers']=new Set();}['removeMessageHandler'](_0x2d3b39){_0x2d3b39['messageChannel']&&(_0x2d3b39['messageChannel']['port1']['removeEventListener']('message',_0x2d3b39['onMessage']),_0x2d3b39['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2d3b39);}async['_send'](_0x453c76,_0x4b2a1f,_0x49e4d2=0x32){const _0x21c3a8=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x21c3a8)throw new Error('connection_unavailable');let _0x26f468,_0x4bb038;return new Promise((_0x28cc5f,_0x16d687)=>{const _0x45e4f8=As('',0x14);_0x21c3a8['port1']['start']();const _0x74ca38=setTimeout(()=>{_0x16d687(new Error('unsupported_event'));},_0x49e4d2);_0x4bb038={'messageChannel':_0x21c3a8,'onMessage'(_0x4f7cda){const _0x3c5107=_0x4f7cda;if(_0x3c5107['data']['eventId']===_0x45e4f8)switch(_0x3c5107['data']['status']){case'ack':clearTimeout(_0x74ca38),_0x26f468=setTimeout(()=>{_0x16d687(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x26f468),_0x28cc5f(_0x3c5107['data']['response']);break;default:clearTimeout(_0x74ca38),clearTimeout(_0x26f468),_0x16d687(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4bb038),_0x21c3a8['port1']['addEventListener']('message',_0x4bb038['onMessage']),this['target']['postMessage']({'eventType':_0x453c76,'eventId':_0x45e4f8,'data':_0x4b2a1f},[_0x21c3a8['port2']]);})['finally'](()=>{_0x4bb038&&this['removeMessageHandler'](_0x4bb038);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x57d965){Z()['location']['href']=_0x57d965;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function $a(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x3f265f;return((_0x3f265f=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3f265f['controller'])||null;}function hp(){return $a()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ga='firebaseLocalStorageDb',up=0x1,Dn='firebaseLocalStorage',qa='fbase_key';class tn{constructor(_0x4c3978){this['request']=_0x4c3978;}['toPromise'](){return new Promise((_0x2e21f2,_0x21e34c)=>{this['request']['addEventListener']('success',()=>{_0x2e21f2(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x21e34c(this['request']['error']);});});}}function Xn(_0x1296ad,_0x52537a){return _0x1296ad['transaction']([Dn],_0x52537a?'readwrite':'readonly')['objectStore'](Dn);}function dp(){const _0x59cef5=indexedDB['deleteDatabase'](Ga);return new tn(_0x59cef5)['toPromise']();}function za(){const _0x1db491=indexedDB['open'](Ga,up);return new Promise((_0x95590e,_0x2381eb)=>{_0x1db491['addEventListener']('error',()=>{_0x2381eb(_0x1db491['error']);}),_0x1db491['addEventListener']('upgradeneeded',()=>{const _0x1ff125=_0x1db491['result'];try{_0x1ff125['createObjectStore'](Dn,{'keyPath':qa});}catch(_0x6219da){_0x2381eb(_0x6219da);}}),_0x1db491['addEventListener']('success',async()=>{const _0x417f5c=_0x1db491['result'];_0x417f5c['objectStoreNames']['contains'](Dn)?_0x95590e(_0x417f5c):(_0x417f5c['close'](),await dp(),_0x95590e(await za()));});});}async function Or(_0x5e8fd1,_0x2c6aae,_0x5280b5){const _0x3cfa75=Xn(_0x5e8fd1,!0x0)['put']({[qa]:_0x2c6aae,'value':_0x5280b5});return new tn(_0x3cfa75)['toPromise']();}async function fp(_0x3032f8,_0x2afec8){const _0x41ff89=Xn(_0x3032f8,!0x1)['get'](_0x2afec8),_0x3eaaf7=await new tn(_0x41ff89)['toPromise']();return _0x3eaaf7===void 0x0?null:_0x3eaaf7['value'];}function Dr(_0x425ec5,_0x36c007){const _0xcccc95=Xn(_0x425ec5,!0x0)['delete'](_0x36c007);return new tn(_0xcccc95)['toPromise']();}const pp=0x320,_p=0x3;class ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=za(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x475359){let _0x1ed6d3=0x0;for(;;)try{const _0x6c29b1=await this['_openDb']();return await _0x475359(_0x6c29b1);}catch(_0x449326){if(_0x1ed6d3++>_p)throw _0x449326;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return $a()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Jn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x916747,_0x5bd6af)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5bd6af['key'])})),this['receiver']['_subscribe']('ping',async(_0x2ba996,_0x5b2291)=>['keyChanged']);}async['initializeSender'](){var _0x4d1c48,_0x4ebd9f;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x2e20bb=await this['sender']['_send']('ping',{},0x320);_0x2e20bb&&(_0x4d1c48=_0x2e20bb[0x0])!=null&&_0x4d1c48['fulfilled']&&(_0x4ebd9f=_0x2e20bb[0x0])!=null&&_0x4ebd9f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x390a3c){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x390a3c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4c9a71=>{await Or(_0x4c9a71,On,'1'),await Dr(_0x4c9a71,On);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0xccb606){this['pendingWrites']++;try{await _0xccb606();}finally{this['pendingWrites']--;}}async['_set'](_0x12892f,_0x321b98){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x366f34=>Or(_0x366f34,_0x12892f,_0x321b98)),this['localCache'][_0x12892f]=_0x321b98,this['notifyServiceWorker'](_0x12892f)));}async['_get'](_0x50336b){const _0x542766=await this['_withRetries'](_0x55f90b=>fp(_0x55f90b,_0x50336b));return this['localCache'][_0x50336b]=_0x542766,_0x542766;}async['_remove'](_0x32346c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x395b0e=>Dr(_0x395b0e,_0x32346c)),delete this['localCache'][_0x32346c],this['notifyServiceWorker'](_0x32346c)));}async['_poll'](){const _0x4a8861=await this['_withRetries'](_0x2cc7b2=>{const _0x344697=Xn(_0x2cc7b2,!0x1)['getAll']();return new tn(_0x344697)['toPromise']();});if(!_0x4a8861)return[];if(this['pendingWrites']!==0x0)return[];const _0x6f37eb=[],_0x31aa7b=new Set();if(_0x4a8861['length']!==0x0){for(const {fbase_key:_0x102014,value:_0x12a61f}of _0x4a8861)_0x31aa7b['add'](_0x102014),JSON['stringify'](this['localCache'][_0x102014])!==JSON['stringify'](_0x12a61f)&&(this['notifyListeners'](_0x102014,_0x12a61f),_0x6f37eb['push'](_0x102014));}for(const _0x23792d of Object['keys'](this['localCache']))this['localCache'][_0x23792d]&&!_0x31aa7b['has'](_0x23792d)&&(this['notifyListeners'](_0x23792d,null),_0x6f37eb['push'](_0x23792d));return _0x6f37eb;}['notifyListeners'](_0x3f58fa,_0x3cd5c1){this['localCache'][_0x3f58fa]=_0x3cd5c1;const _0x42c251=this['listeners'][_0x3f58fa];if(_0x42c251){for(const _0x3eb5c0 of Array['from'](_0x42c251))_0x3eb5c0(_0x3cd5c1);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5115c8,_0x1e149b){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5115c8]||(this['listeners'][_0x5115c8]=new Set(),this['_get'](_0x5115c8)),this['listeners'][_0x5115c8]['add'](_0x1e149b);}['_removeListener'](_0x339a22,_0x19b69b){this['listeners'][_0x339a22]&&(this['listeners'][_0x339a22]['delete'](_0x19b69b),this['listeners'][_0x339a22]['size']===0x0&&delete this['listeners'][_0x339a22]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}ja['type']='LOCAL';const gp=ja;new Xt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x3c6042,_0x156a74){return _0x156a74?ie(_0x156a74):(m(_0x3c6042['_popupRedirectResolver'],_0x3c6042,'argument-error'),_0x3c6042['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2f8dc1){super('custom','custom'),this['params']=_0x2f8dc1;}['_getIdTokenResponse'](_0x45fbc0){return tt(_0x45fbc0,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1268f7,_0x4f210a){return tt(_0x1268f7,this['_buildIdpRequest'](_0x4f210a));}['_getReauthenticationResolver'](_0x57113b){return tt(_0x57113b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x13dd5a){const _0x270021={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x13dd5a&&(_0x270021['idToken']=_0x13dd5a),_0x270021;}}function yp(_0x36ba67){return Fa(_0x36ba67['auth'],new ks(_0x36ba67),_0x36ba67['bypassAuthState']);}function vp(_0x4fc3c3){const {auth:_0x309cc3,user:_0x2bfcba}=_0x4fc3c3;return m(_0x2bfcba,_0x309cc3,'internal-error'),Xf(_0x2bfcba,new ks(_0x4fc3c3),_0x4fc3c3['bypassAuthState']);}async function Ep(_0x4c78b6){const {auth:_0x20fc1f,user:_0x471beb}=_0x4c78b6;return m(_0x471beb,_0x20fc1f,'internal-error'),Jf(_0x471beb,new ks(_0x4c78b6),_0x4c78b6['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ka{constructor(_0x11a16e,_0x3dad27,_0x446395,_0x2dbbfe,_0x4da03d=!0x1){this['auth']=_0x11a16e,this['resolver']=_0x446395,this['user']=_0x2dbbfe,this['bypassAuthState']=_0x4da03d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3dad27)?_0x3dad27:[_0x3dad27];}['execute'](){return new Promise(async(_0x36d2a8,_0x98cd8b)=>{this['pendingPromise']={'resolve':_0x36d2a8,'reject':_0x98cd8b};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3189a7){this['reject'](_0x3189a7);}});}async['onAuthEvent'](_0x5acd9d){const {urlResponse:_0x5352e4,sessionId:_0x13b0fe,postBody:_0x4aa861,tenantId:_0x24a968,error:_0x326454,type:_0x15d864}=_0x5acd9d;if(_0x326454){this['reject'](_0x326454);return;}const _0x17873b={'auth':this['auth'],'requestUri':_0x5352e4,'sessionId':_0x13b0fe,'tenantId':_0x24a968||void 0x0,'postBody':_0x4aa861||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x15d864)(_0x17873b));}catch(_0xa4bdee){this['reject'](_0xa4bdee);}}['onError'](_0x1672bb){this['reject'](_0x1672bb);}['getIdpTask'](_0x13fee8){switch(_0x13fee8){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x7ce3fe){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x7ce3fe),this['unregisterAndCleanUp']();}['reject'](_0x4b9cbe){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4b9cbe),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Xt(0x7d0,0x2710);class Je extends Ka{constructor(_0x44dca1,_0x29178d,_0xec16dd,_0x2eeff1,_0x51ab98){super(_0x44dca1,_0x29178d,_0x2eeff1,_0x51ab98),this['provider']=_0xec16dd,this['authWindow']=null,this['pollId']=null,Je['currentPopupAction']&&Je['currentPopupAction']['cancel'](),Je['currentPopupAction']=this;}async['executeNotNull'](){const _0x4fe24b=await this['execute']();return m(_0x4fe24b,this['auth'],'internal-error'),_0x4fe24b;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x247c26=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x247c26),this['authWindow']['associatedEvent']=_0x247c26,this['resolver']['_originValidation'](this['auth'])['catch'](_0x33716f=>{this['reject'](_0x33716f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x215ae6=>{_0x215ae6||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x37630c;return((_0x37630c=this['authWindow'])==null?void 0x0:_0x37630c['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Je['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2e7796=()=>{var _0x45f0f1,_0xe56a23;if((_0xe56a23=(_0x45f0f1=this['authWindow'])==null?void 0x0:_0x45f0f1['window'])!=null&&_0xe56a23['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2e7796,Ip['get']());};_0x2e7796();}}Je['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',ln=new Map();class Cp extends Ka{constructor(_0x39faec,_0x1be41c,_0x178765=!0x1){super(_0x39faec,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1be41c,void 0x0,_0x178765),this['eventId']=null;}async['execute'](){let _0x1e1a00=ln['get'](this['auth']['_key']());if(!_0x1e1a00){try{const _0x2d74a5=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x1e1a00=()=>Promise['resolve'](_0x2d74a5);}catch(_0x35e61b){_0x1e1a00=()=>Promise['reject'](_0x35e61b);}ln['set'](this['auth']['_key'](),_0x1e1a00);}return this['bypassAuthState']||ln['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1e1a00();}async['onAuthEvent'](_0x41d460){if(_0x41d460['type']==='signInViaRedirect')return super['onAuthEvent'](_0x41d460);if(_0x41d460['type']==='unknown'){this['resolve'](null);return;}if(_0x41d460['eventId']){const _0x1eb972=await this['auth']['_redirectUserForId'](_0x41d460['eventId']);if(_0x1eb972)return this['user']=_0x1eb972,super['onAuthEvent'](_0x41d460);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x21f555,_0x14f5be){const _0x20ab54=Rp(_0x14f5be),_0x3763a9=bp(_0x21f555);if(!await _0x3763a9['_isAvailable']())return!0x1;const _0x175be6=await _0x3763a9['_get'](_0x20ab54)==='true';return await _0x3763a9['_remove'](_0x20ab54),_0x175be6;}function Sp(_0xc84d01,_0x1b4229){ln['set'](_0xc84d01['_key'](),_0x1b4229);}function bp(_0x16d68b){return ie(_0x16d68b['_redirectPersistence']);}function Rp(_0x35efe9){return cn(wp,_0x35efe9['config']['apiKey'],_0x35efe9['name']);}async function Ap(_0x4ae6a7,_0x356fe7,_0x160442=!0x1){if($(_0x4ae6a7['app']))return Promise['reject'](re(_0x4ae6a7));const _0x219e57=je(_0x4ae6a7),_0x3f07ab=mp(_0x219e57,_0x356fe7),_0x4c591b=await new Cp(_0x219e57,_0x3f07ab,_0x160442)['execute']();return _0x4c591b&&!_0x160442&&(delete _0x4c591b['user']['_redirectEventId'],await _0x219e57['_persistUserIfCurrent'](_0x4c591b['user']),await _0x219e57['_setRedirectUser'](null,_0x356fe7)),_0x4c591b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x1bd1e3){this['auth']=_0x1bd1e3,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x45d600){this['consumers']['add'](_0x45d600),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x45d600)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x45d600),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x352929){this['consumers']['delete'](_0x352929);}['onEvent'](_0x45be9e){if(this['hasEventBeenHandled'](_0x45be9e))return!0x1;let _0x48e7d9=!0x1;return this['consumers']['forEach'](_0x51ac85=>{this['isEventForConsumer'](_0x45be9e,_0x51ac85)&&(_0x48e7d9=!0x0,this['sendToConsumer'](_0x45be9e,_0x51ac85),this['saveEventToCache'](_0x45be9e));}),this['hasHandledPotentialRedirect']||!Pp(_0x45be9e)||(this['hasHandledPotentialRedirect']=!0x0,_0x48e7d9||(this['queuedRedirectEvent']=_0x45be9e,_0x48e7d9=!0x0)),_0x48e7d9;}['sendToConsumer'](_0xa1de68,_0x3bb37a){var _0x1c0130;if(_0xa1de68['error']&&!Ya(_0xa1de68)){const _0x904da7=((_0x1c0130=_0xa1de68['error']['code'])==null?void 0x0:_0x1c0130['split']('auth/')[0x1])||'internal-error';_0x3bb37a['onError'](X(this['auth'],_0x904da7));}else _0x3bb37a['onAuthEvent'](_0xa1de68);}['isEventForConsumer'](_0x545c81,_0xdcaa2c){const _0x5e4d49=_0xdcaa2c['eventId']===null||!!_0x545c81['eventId']&&_0x545c81['eventId']===_0xdcaa2c['eventId'];return _0xdcaa2c['filter']['includes'](_0x545c81['type'])&&_0x5e4d49;}['hasEventBeenHandled'](_0x55d691){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x55d691));}['saveEventToCache'](_0x387cba){this['cachedEventUids']['add'](Mr(_0x387cba)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x515cd5){return[_0x515cd5['type'],_0x515cd5['eventId'],_0x515cd5['sessionId'],_0x515cd5['tenantId']]['filter'](_0x21a9ef=>_0x21a9ef)['join']('-');}function Ya({type:_0x50601e,error:_0x11760b}){return _0x50601e==='unknown'&&(_0x11760b==null?void 0x0:_0x11760b['code'])==='auth/no-auth-event';}function Pp(_0x437198){switch(_0x437198['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Ya(_0x437198);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x58cb2f,_0x1b6fce={}){return Ae(_0x58cb2f,'GET','/v1/projects',_0x1b6fce);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x2cecd4){if(_0x2cecd4['config']['emulator'])return;const {authorizedDomains:_0x1589db}=await Op(_0x2cecd4);for(const _0x5b72ca of _0x1589db)try{if(xp(_0x5b72ca))return;}catch{}Y(_0x2cecd4,'unauthorized-domain');}function xp(_0x4e061d){const _0x36428b=Di(),{protocol:_0x33aec1,hostname:_0x26031d}=new URL(_0x36428b);if(_0x4e061d['startsWith']('chrome-extension://')){const _0x15e92e=new URL(_0x4e061d);return _0x15e92e['hostname']===''&&_0x26031d===''?_0x33aec1==='chrome-extension:'&&_0x4e061d['replace']('chrome-extension://','')===_0x36428b['replace']('chrome-extension://',''):_0x33aec1==='chrome-extension:'&&_0x15e92e['hostname']===_0x26031d;}if(!Mp['test'](_0x33aec1))return!0x1;if(Dp['test'](_0x4e061d))return _0x26031d===_0x4e061d;const _0x48d5ff=_0x4e061d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x48d5ff+'|'+_0x48d5ff+')$','i')['test'](_0x26031d);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Xt(0x7530,0xea60);function Lr(){const _0x3575b8=Z()['___jsl'];if(_0x3575b8!=null&&_0x3575b8['H']){for(const _0x39f792 of Object['keys'](_0x3575b8['H']))if(_0x3575b8['H'][_0x39f792]['r']=_0x3575b8['H'][_0x39f792]['r']||[],_0x3575b8['H'][_0x39f792]['L']=_0x3575b8['H'][_0x39f792]['L']||[],_0x3575b8['H'][_0x39f792]['r']=[..._0x3575b8['H'][_0x39f792]['L']],_0x3575b8['CP']){for(let _0x280486=0x0;_0x280486<_0x3575b8['CP']['length'];_0x280486++)_0x3575b8['CP'][_0x280486]=null;}}}function Up(_0x567399){return new Promise((_0x5bb7ae,_0x4c42dc)=>{var _0x3f4cc3,_0xc01b85,_0x29cee7;function _0x57d5d6(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5bb7ae(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4c42dc(X(_0x567399,'network-request-failed'));},'timeout':Fp['get']()});}if((_0xc01b85=(_0x3f4cc3=Z()['gapi'])==null?void 0x0:_0x3f4cc3['iframes'])!=null&&_0xc01b85['Iframe'])_0x5bb7ae(gapi['iframes']['getContext']());else{if((_0x29cee7=Z()['gapi'])!=null&&_0x29cee7['load'])_0x57d5d6();else{const _0x4c8b64=Mf('iframefcb');return Z()[_0x4c8b64]=()=>{gapi['load']?_0x57d5d6():_0x4c42dc(X(_0x567399,'network-request-failed'));},Oa(Df()+'?onload='+_0x4c8b64)['catch'](_0x267e02=>_0x4c42dc(_0x267e02));}}})['catch'](_0x5c4167=>{throw hn=null,_0x5c4167;});}let hn=null;function Wp(_0x4275a4){return hn=hn||Up(_0x4275a4),hn;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Xt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x5748ea){const _0x40399b=_0x5748ea['config'];m(_0x40399b['authDomain'],_0x5748ea,'auth-domain-config-required');const _0x4bfcd4=_0x40399b['emulator']?Cs(_0x40399b,Hp):'https://'+_0x5748ea['config']['authDomain']+'/'+Vp,_0x4f9a3f={'apiKey':_0x40399b['apiKey'],'appName':_0x5748ea['name'],'v':ut},_0x2aa2f3=Gp['get'](_0x5748ea['config']['apiHost']);_0x2aa2f3&&(_0x4f9a3f['eid']=_0x2aa2f3);const _0x21a1db=_0x5748ea['_getFrameworks']();return _0x21a1db['length']&&(_0x4f9a3f['fw']=_0x21a1db['join'](',')),_0x4bfcd4+'?'+ht(_0x4f9a3f)['slice'](0x1);}async function zp(_0x58ee65){const _0x56eb48=await Wp(_0x58ee65),_0x4c9cff=Z()['gapi'];return m(_0x4c9cff,_0x58ee65,'internal-error'),_0x56eb48['open']({'where':document['body'],'url':qp(_0x58ee65),'messageHandlersFilter':_0x4c9cff['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x7f1a1b=>new Promise(async(_0x235783,_0x10a562)=>{await _0x7f1a1b['restyle']({'setHideOnLeave':!0x1});const _0x14074d=X(_0x58ee65,'network-request-failed'),_0xf19cba=Z()['setTimeout'](()=>{_0x10a562(_0x14074d);},Bp['get']());function _0x132bff(){Z()['clearTimeout'](_0xf19cba),_0x235783(_0x7f1a1b);}_0x7f1a1b['ping'](_0x132bff)['then'](_0x132bff,()=>{_0x10a562(_0x14074d);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class xr{constructor(_0x2c9529){this['window']=_0x2c9529,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x19df46,_0x2df751,_0x40f9bd,_0x43ce17=Kp,_0x43f21a=Yp){const _0x1a7574=Math['max']((window['screen']['availHeight']-_0x43f21a)/0x2,0x0)['toString'](),_0x728be0=Math['max']((window['screen']['availWidth']-_0x43ce17)/0x2,0x0)['toString']();let _0x2b197d='';const _0x4e30f5={...jp,'width':_0x43ce17['toString'](),'height':_0x43f21a['toString'](),'top':_0x1a7574,'left':_0x728be0},_0x38823c=W()['toLowerCase']();_0x40f9bd&&(_0x2b197d=Sa(_0x38823c)?Qp:_0x40f9bd),Ca(_0x38823c)&&(_0x2df751=_0x2df751||Jp,_0x4e30f5['scrollbars']='yes');const _0x25f514=Object['entries'](_0x4e30f5)['reduce']((_0x1f3bfb,[_0x59aeb4,_0x353a99])=>''+_0x1f3bfb+_0x59aeb4+'='+_0x353a99+',','');if(Tf(_0x38823c)&&_0x2b197d!=='_self')return Zp(_0x2df751||'',_0x2b197d),new xr(null);const _0x3c05cc=window['open'](_0x2df751||'',_0x2b197d,_0x25f514);m(_0x3c05cc,_0x19df46,'popup-blocked');try{_0x3c05cc['focus']();}catch{}return new xr(_0x3c05cc);}function Zp(_0x1fe30a,_0x44a560){const _0x43e252=document['createElement']('a');_0x43e252['href']=_0x1fe30a,_0x43e252['target']=_0x44a560;const _0x163380=document['createEvent']('MouseEvent');_0x163380['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x43e252['dispatchEvent'](_0x163380);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function Fr(_0x49478e,_0x51fee8,_0x5df8b6,_0x36c375,_0x4436fd,_0x2c572f){m(_0x49478e['config']['authDomain'],_0x49478e,'auth-domain-config-required'),m(_0x49478e['config']['apiKey'],_0x49478e,'invalid-api-key');const _0x1000fb={'apiKey':_0x49478e['config']['apiKey'],'appName':_0x49478e['name'],'authType':_0x5df8b6,'redirectUrl':_0x36c375,'v':ut,'eventId':_0x4436fd};if(_0x51fee8 instanceof La){_0x51fee8['setDefaultLanguage'](_0x49478e['languageCode']),_0x1000fb['providerId']=_0x51fee8['providerId']||'',fn(_0x51fee8['getCustomParameters']())||(_0x1000fb['customParameters']=JSON['stringify'](_0x51fee8['getCustomParameters']()));for(const [_0x470f58,_0x54dfa0]of Object['entries']({}))_0x1000fb[_0x470f58]=_0x54dfa0;}if(_0x51fee8 instanceof en){const _0x1d6064=_0x51fee8['getScopes']()['filter'](_0x539ef2=>_0x539ef2!=='');_0x1d6064['length']>0x0&&(_0x1000fb['scopes']=_0x1d6064['join'](','));}_0x49478e['tenantId']&&(_0x1000fb['tid']=_0x49478e['tenantId']);const _0x180ddc=_0x1000fb;for(const _0x40e22c of Object['keys'](_0x180ddc))_0x180ddc[_0x40e22c]===void 0x0&&delete _0x180ddc[_0x40e22c];const _0x156bf7=await _0x49478e['_getAppCheckToken'](),_0x34fe2d=_0x156bf7?'#'+n_+'='+encodeURIComponent(_0x156bf7):'';return i_(_0x49478e)+'?'+ht(_0x180ddc)['slice'](0x1)+_0x34fe2d;}function i_({config:_0x1bd18f}){return _0x1bd18f['emulator']?Cs(_0x1bd18f,t_):'https://'+_0x1bd18f['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=Ha,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x5ec734,_0x2190a7,_0x5c2eaf,_0x26ed41){var _0x3e8f5a;ce((_0x3e8f5a=this['eventManagers'][_0x5ec734['_key']()])==null?void 0x0:_0x3e8f5a['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x177edd=await Fr(_0x5ec734,_0x2190a7,_0x5c2eaf,Di(),_0x26ed41);return Xp(_0x5ec734,_0x177edd,As());}async['_openRedirect'](_0x4fe625,_0x53a80a,_0x61e705,_0x309df2){await this['_originValidation'](_0x4fe625);const _0x42635b=await Fr(_0x4fe625,_0x53a80a,_0x61e705,Di(),_0x309df2);return ap(_0x42635b),new Promise(()=>{});}['_initialize'](_0x4fb983){const _0x145dc3=_0x4fb983['_key']();if(this['eventManagers'][_0x145dc3]){const {manager:_0x549c7f,promise:_0x39c96c}=this['eventManagers'][_0x145dc3];return _0x549c7f?Promise['resolve'](_0x549c7f):(ce(_0x39c96c,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x39c96c);}const _0x188bcc=this['initAndGetManager'](_0x4fb983);return this['eventManagers'][_0x145dc3]={'promise':_0x188bcc},_0x188bcc['catch'](()=>{delete this['eventManagers'][_0x145dc3];}),_0x188bcc;}async['initAndGetManager'](_0x306e28){const _0x2762e0=await zp(_0x306e28),_0xd2a0f4=new Np(_0x306e28);return _0x2762e0['register']('authEvent',_0xce20cd=>(m(_0xce20cd==null?void 0x0:_0xce20cd['authEvent'],_0x306e28,'invalid-auth-event'),{'status':_0xd2a0f4['onEvent'](_0xce20cd['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x306e28['_key']()]={'manager':_0xd2a0f4},this['iframes'][_0x306e28['_key']()]=_0x2762e0,_0xd2a0f4;}['_isIframeWebStorageSupported'](_0x222dbb,_0x433a48){this['iframes'][_0x222dbb['_key']()]['send'](fi,{'type':fi},_0x1e6214=>{var _0x39612e;const _0x190aeb=(_0x39612e=_0x1e6214==null?void 0x0:_0x1e6214[0x0])==null?void 0x0:_0x39612e[fi];_0x190aeb!==void 0x0&&_0x433a48(!!_0x190aeb),Y(_0x222dbb,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x45db47){const _0x1b9186=_0x45db47['_key']();return this['originValidationPromises'][_0x1b9186]||(this['originValidationPromises'][_0x1b9186]=Lp(_0x45db47)),this['originValidationPromises'][_0x1b9186];}get['_shouldInitProactively'](){return Na()||Ta()||Ss();}}const r_=s_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x39c690){this['auth']=_0x39c690,this['internalListeners']=new Map();}['getUid'](){var _0x308067;return this['assertAuthConfigured'](),((_0x308067=this['auth']['currentUser'])==null?void 0x0:_0x308067['uid'])||null;}async['getToken'](_0x46b09d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x46b09d)}:null;}['addAuthTokenListener'](_0x3d6936){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3d6936))return;const _0xaf6953=this['auth']['onIdTokenChanged'](_0x41caaf=>{_0x3d6936((_0x41caaf==null?void 0x0:_0x41caaf['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3d6936,_0xaf6953),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3723c5){this['assertAuthConfigured']();const _0x21c6b6=this['internalListeners']['get'](_0x3723c5);_0x21c6b6&&(this['internalListeners']['delete'](_0x3723c5),_0x21c6b6(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x4b2665){switch(_0x4b2665){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x3233ea){it(new xe('auth',(_0x3ea2ae,{options:_0x53f9d2})=>{const _0x50a3da=_0x3ea2ae['getProvider']('app')['getImmediate'](),_0x58639d=_0x3ea2ae['getProvider']('heartbeat'),_0xe89240=_0x3ea2ae['getProvider']('app-check-internal'),{apiKey:_0x4254b4,authDomain:_0x579c88}=_0x50a3da['options'];m(_0x4254b4&&!_0x4254b4['includes'](':'),'invalid-api-key',{'appName':_0x50a3da['name']});const _0x5ee762={'apiKey':_0x4254b4,'authDomain':_0x579c88,'clientPlatform':_0x3233ea,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Pa(_0x3233ea)},_0x400a6b=new Nf(_0x50a3da,_0x58639d,_0xe89240,_0x5ee762);return Wf(_0x400a6b,_0x53f9d2),_0x400a6b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2ee989,_0x4432b9,_0x5094fa)=>{_0x2ee989['getProvider']('auth-internal')['initialize']();})),it(new xe('auth-internal',_0x2968ef=>{const _0x52deff=je(_0x2968ef['getProvider']('auth')['getImmediate']());return(_0x35d987=>new o_(_0x35d987))(_0x52deff);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,a_(_0x3233ea)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=jr('authIdTokenMaxAge')||l_;let Br=null;const u_=_0x12760c=>async _0x120f20=>{const _0x12f7f8=_0x120f20&&await _0x120f20['getIdTokenResult'](),_0x4b96f4=_0x12f7f8&&(new Date()['getTime']()-Date['parse'](_0x12f7f8['issuedAtTime']))/0x3e8;if(_0x4b96f4&&_0x4b96f4>h_)return;const _0xe099d4=_0x12f7f8==null?void 0x0:_0x12f7f8['token'];Br!==_0xe099d4&&(Br=_0xe099d4,await fetch(_0x12760c,{'method':_0xe099d4?'POST':'DELETE','headers':_0xe099d4?{'Authorization':'Bearer\x20'+_0xe099d4}:{}}));};function D_(_0x4ceb62=Zr()){const _0x2a1e9d=Vi(_0x4ceb62,'auth');if(_0x2a1e9d['isInitialized']())return _0x2a1e9d['getImmediate']();const _0x52119f=Uf(_0x4ceb62,{'popupRedirectResolver':r_,'persistence':[gp,sp,Ha]}),_0x19a870=jr('authTokenSyncURL');if(_0x19a870&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x9b716f=new URL(_0x19a870,location['origin']);if(location['origin']===_0x9b716f['origin']){const _0x3c4120=u_(_0x9b716f['toString']());tp(_0x52119f,_0x3c4120,()=>_0x3c4120(_0x52119f['currentUser'])),ep(_0x52119f,_0x4dc8e6=>_0x3c4120(_0x4dc8e6));}}const _0xa98da7=qr('auth');return _0xa98da7&&Bf(_0x52119f,'http://'+_0xa98da7),_0x52119f;}function d_(){var _0x255797;return((_0x255797=document['getElementsByTagName']('head'))==null?void 0x0:_0x255797[0x0])??document;}Pf({'loadJS'(_0x45dcda){return new Promise((_0x528d88,_0x1c5a39)=>{const _0x23f9b7=document['createElement']('script');_0x23f9b7['setAttribute']('src',_0x45dcda),_0x23f9b7['onload']=_0x528d88,_0x23f9b7['onerror']=_0x14680e=>{const _0x4c6fec=X('internal-error');_0x4c6fec['customData']=_0x14680e,_0x1c5a39(_0x4c6fec);},_0x23f9b7['type']='text/javascript',_0x23f9b7['charset']='UTF-8',d_()['appendChild'](_0x23f9b7);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{A_ as A,C_ as a,D_ as b,sp as c,Zr as d,v_ as e,k_ as f,f_ as g,O_ as h,Il as i,p_ as j,Wd as k,b_ as l,Vd as m,T_ as n,g_ as o,P_ as p,S_ as q,__ as r,N_ as s,w_ as t,y_ as u,E_ as v,I_ as w,Bt as x,m_ as y,R_ as z};