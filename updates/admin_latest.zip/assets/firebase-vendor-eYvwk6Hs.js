const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x386b68,_0x336d4f){if(!_0x386b68)throw ht(_0x336d4f);},ht=function(_0xc50b92){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xc50b92);},Hr=function(_0x2b701b){const _0x1338f2=[];let _0x584057=0x0;for(let _0x4dd6b6=0x0;_0x4dd6b6<_0x2b701b['length'];_0x4dd6b6++){let _0x41a71d=_0x2b701b['charCodeAt'](_0x4dd6b6);_0x41a71d<0x80?_0x1338f2[_0x584057++]=_0x41a71d:_0x41a71d<0x800?(_0x1338f2[_0x584057++]=_0x41a71d>>0x6|0xc0,_0x1338f2[_0x584057++]=_0x41a71d&0x3f|0x80):(_0x41a71d&0xfc00)===0xd800&&_0x4dd6b6+0x1<_0x2b701b['length']&&(_0x2b701b['charCodeAt'](_0x4dd6b6+0x1)&0xfc00)===0xdc00?(_0x41a71d=0x10000+((_0x41a71d&0x3ff)<<0xa)+(_0x2b701b['charCodeAt'](++_0x4dd6b6)&0x3ff),_0x1338f2[_0x584057++]=_0x41a71d>>0x12|0xf0,_0x1338f2[_0x584057++]=_0x41a71d>>0xc&0x3f|0x80,_0x1338f2[_0x584057++]=_0x41a71d>>0x6&0x3f|0x80,_0x1338f2[_0x584057++]=_0x41a71d&0x3f|0x80):(_0x1338f2[_0x584057++]=_0x41a71d>>0xc|0xe0,_0x1338f2[_0x584057++]=_0x41a71d>>0x6&0x3f|0x80,_0x1338f2[_0x584057++]=_0x41a71d&0x3f|0x80);}return _0x1338f2;},nc=function(_0x4e0fc7){const _0x4b1c8a=[];let _0x99fa92=0x0,_0x3ae419=0x0;for(;_0x99fa92<_0x4e0fc7['length'];){const _0x35b458=_0x4e0fc7[_0x99fa92++];if(_0x35b458<0x80)_0x4b1c8a[_0x3ae419++]=String['fromCharCode'](_0x35b458);else{if(_0x35b458>0xbf&&_0x35b458<0xe0){const _0x1d7621=_0x4e0fc7[_0x99fa92++];_0x4b1c8a[_0x3ae419++]=String['fromCharCode']((_0x35b458&0x1f)<<0x6|_0x1d7621&0x3f);}else{if(_0x35b458>0xef&&_0x35b458<0x16d){const _0x8e33b7=_0x4e0fc7[_0x99fa92++],_0x7487f6=_0x4e0fc7[_0x99fa92++],_0x479a4f=_0x4e0fc7[_0x99fa92++],_0x3fb3ed=((_0x35b458&0x7)<<0x12|(_0x8e33b7&0x3f)<<0xc|(_0x7487f6&0x3f)<<0x6|_0x479a4f&0x3f)-0x10000;_0x4b1c8a[_0x3ae419++]=String['fromCharCode'](0xd800+(_0x3fb3ed>>0xa)),_0x4b1c8a[_0x3ae419++]=String['fromCharCode'](0xdc00+(_0x3fb3ed&0x3ff));}else{const _0x5617a0=_0x4e0fc7[_0x99fa92++],_0xe42515=_0x4e0fc7[_0x99fa92++];_0x4b1c8a[_0x3ae419++]=String['fromCharCode']((_0x35b458&0xf)<<0xc|(_0x5617a0&0x3f)<<0x6|_0xe42515&0x3f);}}}}return _0x4b1c8a['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3d2e54,_0x303c0d){if(!Array['isArray'](_0x3d2e54))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1083f=_0x303c0d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5babb0=[];for(let _0x36adbc=0x0;_0x36adbc<_0x3d2e54['length'];_0x36adbc+=0x3){const _0x15d64f=_0x3d2e54[_0x36adbc],_0x558c3c=_0x36adbc+0x1<_0x3d2e54['length'],_0x9d1cc9=_0x558c3c?_0x3d2e54[_0x36adbc+0x1]:0x0,_0x571d4c=_0x36adbc+0x2<_0x3d2e54['length'],_0x35aa3e=_0x571d4c?_0x3d2e54[_0x36adbc+0x2]:0x0,_0x14bfdf=_0x15d64f>>0x2,_0x25e298=(_0x15d64f&0x3)<<0x4|_0x9d1cc9>>0x4;let _0x3b8fcb=(_0x9d1cc9&0xf)<<0x2|_0x35aa3e>>0x6,_0x25f76d=_0x35aa3e&0x3f;_0x571d4c||(_0x25f76d=0x40,_0x558c3c||(_0x3b8fcb=0x40)),_0x5babb0['push'](_0x1083f[_0x14bfdf],_0x1083f[_0x25e298],_0x1083f[_0x3b8fcb],_0x1083f[_0x25f76d]);}return _0x5babb0['join']('');},'encodeString'(_0x4a7466,_0x1fbfff){return this['HAS_NATIVE_SUPPORT']&&!_0x1fbfff?btoa(_0x4a7466):this['encodeByteArray'](Hr(_0x4a7466),_0x1fbfff);},'decodeString'(_0x23c7be,_0x470a3a){return this['HAS_NATIVE_SUPPORT']&&!_0x470a3a?atob(_0x23c7be):nc(this['decodeStringToByteArray'](_0x23c7be,_0x470a3a));},'decodeStringToByteArray'(_0x9e5d2e,_0x1f1d83){this['init_']();const _0x50f743=_0x1f1d83?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4050c4=[];for(let _0x4507ec=0x0;_0x4507ec<_0x9e5d2e['length'];){const _0x960926=_0x50f743[_0x9e5d2e['charAt'](_0x4507ec++)],_0x292cd8=_0x4507ec<_0x9e5d2e['length']?_0x50f743[_0x9e5d2e['charAt'](_0x4507ec)]:0x0;++_0x4507ec;const _0x23e2e2=_0x4507ec<_0x9e5d2e['length']?_0x50f743[_0x9e5d2e['charAt'](_0x4507ec)]:0x40;++_0x4507ec;const _0x59fade=_0x4507ec<_0x9e5d2e['length']?_0x50f743[_0x9e5d2e['charAt'](_0x4507ec)]:0x40;if(++_0x4507ec,_0x960926==null||_0x292cd8==null||_0x23e2e2==null||_0x59fade==null)throw new ic();const _0x8ad44d=_0x960926<<0x2|_0x292cd8>>0x4;if(_0x4050c4['push'](_0x8ad44d),_0x23e2e2!==0x40){const _0x14e31d=_0x292cd8<<0x4&0xf0|_0x23e2e2>>0x2;if(_0x4050c4['push'](_0x14e31d),_0x59fade!==0x40){const _0x502585=_0x23e2e2<<0x6&0xc0|_0x59fade;_0x4050c4['push'](_0x502585);}}}return _0x4050c4;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x57ad94=0x0;_0x57ad94<this['ENCODED_VALS']['length'];_0x57ad94++)this['byteToCharMap_'][_0x57ad94]=this['ENCODED_VALS']['charAt'](_0x57ad94),this['charToByteMap_'][this['byteToCharMap_'][_0x57ad94]]=_0x57ad94,this['byteToCharMapWebSafe_'][_0x57ad94]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x57ad94),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x57ad94]]=_0x57ad94,_0x57ad94>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x57ad94)]=_0x57ad94,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x57ad94)]=_0x57ad94);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x42fc38){const _0x41583e=Hr(_0x42fc38);return Fi['encodeByteArray'](_0x41583e,!0x0);},dn=function(_0x5e0612){return $r(_0x5e0612)['replace'](/\./g,'');},fn=function(_0x46730f){try{return Fi['decodeString'](_0x46730f,!0x0);}catch(_0x165494){console['error']('base64Decode\x20failed:\x20',_0x165494);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x4c1fa6){return Gr(void 0x0,_0x4c1fa6);}function Gr(_0x4d1d64,_0x597d51){if(!(_0x597d51 instanceof Object))return _0x597d51;switch(_0x597d51['constructor']){case Date:const _0x2f6dc1=_0x597d51;return new Date(_0x2f6dc1['getTime']());case Object:_0x4d1d64===void 0x0&&(_0x4d1d64={});break;case Array:_0x4d1d64=[];break;default:return _0x597d51;}for(const _0x3c74c1 in _0x597d51)!_0x597d51['hasOwnProperty'](_0x3c74c1)||!rc(_0x3c74c1)||(_0x4d1d64[_0x3c74c1]=Gr(_0x4d1d64[_0x3c74c1],_0x597d51[_0x3c74c1]));return _0x4d1d64;}function rc(_0x1259bd){return _0x1259bd!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x12e529=Ps['__FIREBASE_DEFAULTS__'];if(_0x12e529)return JSON['parse'](_0x12e529);},lc=()=>{if(typeof document>'u')return;let _0x3bc16e;try{_0x3bc16e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xceb68d=_0x3bc16e&&fn(_0x3bc16e[0x1]);return _0xceb68d&&JSON['parse'](_0xceb68d);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x29b7e7){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x29b7e7);return;}},qr=_0x4e9d99=>{var _0x1fa294,_0x284ccf;return(_0x284ccf=(_0x1fa294=Ui())==null?void 0x0:_0x1fa294['emulatorHosts'])==null?void 0x0:_0x284ccf[_0x4e9d99];},hc=_0xe59f97=>{const _0x290127=qr(_0xe59f97);if(!_0x290127)return;const _0x2f3691=_0x290127['lastIndexOf'](':');if(_0x2f3691<=0x0||_0x2f3691+0x1===_0x290127['length'])throw new Error('Invalid\x20host\x20'+_0x290127+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0xb19861=parseInt(_0x290127['substring'](_0x2f3691+0x1),0xa);return _0x290127[0x0]==='['?[_0x290127['substring'](0x1,_0x2f3691-0x1),_0xb19861]:[_0x290127['substring'](0x0,_0x2f3691),_0xb19861];},zr=()=>{var _0x121378;return(_0x121378=Ui())==null?void 0x0:_0x121378['config'];},jr=_0x49ff5c=>{var _0x3f71f9;return(_0x3f71f9=Ui())==null?void 0x0:_0x3f71f9['_'+_0x49ff5c];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x8ba94c,_0x11efdf)=>{this['resolve']=_0x8ba94c,this['reject']=_0x11efdf;});}['wrapCallback'](_0x4aea4a){return(_0x33c008,_0x13dc2a)=>{_0x33c008?this['reject'](_0x33c008):this['resolve'](_0x13dc2a),typeof _0x4aea4a=='function'&&(this['promise']['catch'](()=>{}),_0x4aea4a['length']===0x1?_0x4aea4a(_0x33c008):_0x4aea4a(_0x33c008,_0x13dc2a));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x69c873,_0x2f167c){if(_0x69c873['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x273045={'alg':'none','type':'JWT'},_0x5e6b35=_0x2f167c||'demo-project',_0x1770e2=_0x69c873['iat']||0x0,_0x34b620=_0x69c873['sub']||_0x69c873['user_id'];if(!_0x34b620)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x42e1b9={'iss':'https://securetoken.google.com/'+_0x5e6b35,'aud':_0x5e6b35,'iat':_0x1770e2,'exp':_0x1770e2+0xe10,'auth_time':_0x1770e2,'sub':_0x34b620,'user_id':_0x34b620,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x69c873};return[dn(JSON['stringify'](_0x273045)),dn(JSON['stringify'](_0x42e1b9)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x2bc7ef=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2bc7ef=='object'&&_0x2bc7ef['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x18e8d8=W();return _0x18e8d8['indexOf']('MSIE\x20')>=0x0||_0x18e8d8['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2a2b7b,_0x49a7e3)=>{try{let _0x2a9472=!0x0;const _0x1e11b6='validate-browser-context-for-indexeddb-analytics-module',_0x101cad=self['indexedDB']['open'](_0x1e11b6);_0x101cad['onsuccess']=()=>{_0x101cad['result']['close'](),_0x2a9472||self['indexedDB']['deleteDatabase'](_0x1e11b6),_0x2a2b7b(!0x0);},_0x101cad['onupgradeneeded']=()=>{_0x2a9472=!0x1;},_0x101cad['onerror']=()=>{var _0x250458;_0x49a7e3(((_0x250458=_0x101cad['error'])==null?void 0x0:_0x250458['message'])||'');};}catch(_0x100a95){_0x49a7e3(_0x100a95);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x892314,_0x3e795e,_0x4b01ac){super(_0x3e795e),this['code']=_0x892314,this['customData']=_0x4b01ac,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x3c804d,_0xf61cd6,_0x458d59){this['service']=_0x3c804d,this['serviceName']=_0xf61cd6,this['errors']=_0x458d59;}['create'](_0x39f877,..._0x29c9ca){const _0x2432cd=_0x29c9ca[0x0]||{},_0x43c368=this['service']+'/'+_0x39f877,_0x3041f9=this['errors'][_0x39f877],_0x1981b5=_0x3041f9?vc(_0x3041f9,_0x2432cd):'Error',_0x1472e0=this['serviceName']+':\x20'+_0x1981b5+'\x20('+_0x43c368+').';return new Re(_0x43c368,_0x1472e0,_0x2432cd);}}function vc(_0xf5448c,_0x15d2ae){return _0xf5448c['replace'](Ec,(_0x20d70e,_0x551c68)=>{const _0x107fa6=_0x15d2ae[_0x551c68];return _0x107fa6!=null?String(_0x107fa6):'<'+_0x551c68+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x5084b7){return JSON['parse'](_0x5084b7);}function O(_0x5145c2){return JSON['stringify'](_0x5145c2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x450d5d){let _0x2035f8={},_0x587ee7={},_0xfcbc34={},_0x5f0bd9='';try{const _0x130bdf=_0x450d5d['split']('.');_0x2035f8=Nt(fn(_0x130bdf[0x0])||''),_0x587ee7=Nt(fn(_0x130bdf[0x1])||''),_0x5f0bd9=_0x130bdf[0x2],_0xfcbc34=_0x587ee7['d']||{},delete _0x587ee7['d'];}catch{}return{'header':_0x2035f8,'claims':_0x587ee7,'data':_0xfcbc34,'signature':_0x5f0bd9};},Ic=function(_0x4c3341){const _0x2567ce=Yr(_0x4c3341),_0x365c4d=_0x2567ce['claims'];return!!_0x365c4d&&typeof _0x365c4d=='object'&&_0x365c4d['hasOwnProperty']('iat');},wc=function(_0x59dfa9){const _0xe63174=Yr(_0x59dfa9)['claims'];return typeof _0xe63174=='object'&&_0xe63174['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x3da499,_0x50c1c3){return Object['prototype']['hasOwnProperty']['call'](_0x3da499,_0x50c1c3);}function Le(_0x22e923,_0x4e93f4){if(Object['prototype']['hasOwnProperty']['call'](_0x22e923,_0x4e93f4))return _0x22e923[_0x4e93f4];}function pn(_0x2580dc){for(const _0x3705be in _0x2580dc)if(Object['prototype']['hasOwnProperty']['call'](_0x2580dc,_0x3705be))return!0x1;return!0x0;}function _n(_0x53f761,_0x229a59,_0x99c384){const _0x12643c={};for(const _0x458d24 in _0x53f761)Object['prototype']['hasOwnProperty']['call'](_0x53f761,_0x458d24)&&(_0x12643c[_0x458d24]=_0x229a59['call'](_0x99c384,_0x53f761[_0x458d24],_0x458d24,_0x53f761));return _0x12643c;}function xe(_0x5a7699,_0x782f44){if(_0x5a7699===_0x782f44)return!0x0;const _0x2f44ad=Object['keys'](_0x5a7699),_0x4ab198=Object['keys'](_0x782f44);for(const _0x48a26b of _0x2f44ad){if(!_0x4ab198['includes'](_0x48a26b))return!0x1;const _0x3a734e=_0x5a7699[_0x48a26b],_0x1f780d=_0x782f44[_0x48a26b];if(Ns(_0x3a734e)&&Ns(_0x1f780d)){if(!xe(_0x3a734e,_0x1f780d))return!0x1;}else{if(_0x3a734e!==_0x1f780d)return!0x1;}}for(const _0x1c2f8d of _0x4ab198)if(!_0x2f44ad['includes'](_0x1c2f8d))return!0x1;return!0x0;}function Ns(_0x456fdf){return _0x456fdf!==null&&typeof _0x456fdf=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x494c36){const _0x59d4a9=[];for(const [_0x11c410,_0xe4c3a0]of Object['entries'](_0x494c36))Array['isArray'](_0xe4c3a0)?_0xe4c3a0['forEach'](_0x1d149f=>{_0x59d4a9['push'](encodeURIComponent(_0x11c410)+'='+encodeURIComponent(_0x1d149f));}):_0x59d4a9['push'](encodeURIComponent(_0x11c410)+'='+encodeURIComponent(_0xe4c3a0));return _0x59d4a9['length']?'&'+_0x59d4a9['join']('&'):'';}function Ct(_0x1dc7d8){const _0x5cb743={};return _0x1dc7d8['replace'](/^\?/,'')['split']('&')['forEach'](_0x3288b7=>{if(_0x3288b7){const [_0x38d1e5,_0x9c310c]=_0x3288b7['split']('=');_0x5cb743[decodeURIComponent(_0x38d1e5)]=decodeURIComponent(_0x9c310c);}}),_0x5cb743;}function Tt(_0x56003c){const _0x43ab6a=_0x56003c['indexOf']('?');if(!_0x43ab6a)return'';const _0xa7bbe1=_0x56003c['indexOf']('#',_0x43ab6a);return _0x56003c['substring'](_0x43ab6a,_0xa7bbe1>0x0?_0xa7bbe1:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1a8fef=0x1;_0x1a8fef<this['blockSize'];++_0x1a8fef)this['pad_'][_0x1a8fef]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5721d4,_0x47ce2d){_0x47ce2d||(_0x47ce2d=0x0);const _0x36b8bf=this['W_'];if(typeof _0x5721d4=='string'){for(let _0x490da1=0x0;_0x490da1<0x10;_0x490da1++)_0x36b8bf[_0x490da1]=_0x5721d4['charCodeAt'](_0x47ce2d)<<0x18|_0x5721d4['charCodeAt'](_0x47ce2d+0x1)<<0x10|_0x5721d4['charCodeAt'](_0x47ce2d+0x2)<<0x8|_0x5721d4['charCodeAt'](_0x47ce2d+0x3),_0x47ce2d+=0x4;}else{for(let _0x14bdab=0x0;_0x14bdab<0x10;_0x14bdab++)_0x36b8bf[_0x14bdab]=_0x5721d4[_0x47ce2d]<<0x18|_0x5721d4[_0x47ce2d+0x1]<<0x10|_0x5721d4[_0x47ce2d+0x2]<<0x8|_0x5721d4[_0x47ce2d+0x3],_0x47ce2d+=0x4;}for(let _0x12fc10=0x10;_0x12fc10<0x50;_0x12fc10++){const _0x3af972=_0x36b8bf[_0x12fc10-0x3]^_0x36b8bf[_0x12fc10-0x8]^_0x36b8bf[_0x12fc10-0xe]^_0x36b8bf[_0x12fc10-0x10];_0x36b8bf[_0x12fc10]=(_0x3af972<<0x1|_0x3af972>>>0x1f)&0xffffffff;}let _0x583d68=this['chain_'][0x0],_0x42132b=this['chain_'][0x1],_0x8ded1c=this['chain_'][0x2],_0x43aa8f=this['chain_'][0x3],_0x426d48=this['chain_'][0x4],_0x339ceb,_0x160e5f;for(let _0x5a2852=0x0;_0x5a2852<0x50;_0x5a2852++){_0x5a2852<0x28?_0x5a2852<0x14?(_0x339ceb=_0x43aa8f^_0x42132b&(_0x8ded1c^_0x43aa8f),_0x160e5f=0x5a827999):(_0x339ceb=_0x42132b^_0x8ded1c^_0x43aa8f,_0x160e5f=0x6ed9eba1):_0x5a2852<0x3c?(_0x339ceb=_0x42132b&_0x8ded1c|_0x43aa8f&(_0x42132b|_0x8ded1c),_0x160e5f=0x8f1bbcdc):(_0x339ceb=_0x42132b^_0x8ded1c^_0x43aa8f,_0x160e5f=0xca62c1d6);const _0x211ab6=(_0x583d68<<0x5|_0x583d68>>>0x1b)+_0x339ceb+_0x426d48+_0x160e5f+_0x36b8bf[_0x5a2852]&0xffffffff;_0x426d48=_0x43aa8f,_0x43aa8f=_0x8ded1c,_0x8ded1c=(_0x42132b<<0x1e|_0x42132b>>>0x2)&0xffffffff,_0x42132b=_0x583d68,_0x583d68=_0x211ab6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x583d68&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x42132b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x8ded1c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x43aa8f&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x426d48&0xffffffff;}['update'](_0x6f47ed,_0x18fd3f){if(_0x6f47ed==null)return;_0x18fd3f===void 0x0&&(_0x18fd3f=_0x6f47ed['length']);const _0x1b4665=_0x18fd3f-this['blockSize'];let _0x218053=0x0;const _0x4529b5=this['buf_'];let _0x320ef1=this['inbuf_'];for(;_0x218053<_0x18fd3f;){if(_0x320ef1===0x0){for(;_0x218053<=_0x1b4665;)this['compress_'](_0x6f47ed,_0x218053),_0x218053+=this['blockSize'];}if(typeof _0x6f47ed=='string'){for(;_0x218053<_0x18fd3f;)if(_0x4529b5[_0x320ef1]=_0x6f47ed['charCodeAt'](_0x218053),++_0x320ef1,++_0x218053,_0x320ef1===this['blockSize']){this['compress_'](_0x4529b5),_0x320ef1=0x0;break;}}else{for(;_0x218053<_0x18fd3f;)if(_0x4529b5[_0x320ef1]=_0x6f47ed[_0x218053],++_0x320ef1,++_0x218053,_0x320ef1===this['blockSize']){this['compress_'](_0x4529b5),_0x320ef1=0x0;break;}}}this['inbuf_']=_0x320ef1,this['total_']+=_0x18fd3f;}['digest'](){const _0x18fea7=[];let _0x2516e9=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xfe321b=this['blockSize']-0x1;_0xfe321b>=0x38;_0xfe321b--)this['buf_'][_0xfe321b]=_0x2516e9&0xff,_0x2516e9/=0x100;this['compress_'](this['buf_']);let _0x1a4269=0x0;for(let _0xcba1fa=0x0;_0xcba1fa<0x5;_0xcba1fa++)for(let _0x2b1331=0x18;_0x2b1331>=0x0;_0x2b1331-=0x8)_0x18fea7[_0x1a4269]=this['chain_'][_0xcba1fa]>>_0x2b1331&0xff,++_0x1a4269;return _0x18fea7;}}function Tc(_0x22b4b0,_0x4844cb){const _0x207916=new Sc(_0x22b4b0,_0x4844cb);return _0x207916['subscribe']['bind'](_0x207916);}class Sc{constructor(_0x24fe37,_0x423093){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x423093,this['task']['then'](()=>{_0x24fe37(this);})['catch'](_0x5e3f2c=>{this['error'](_0x5e3f2c);});}['next'](_0x19c35c){this['forEachObserver'](_0x158044=>{_0x158044['next'](_0x19c35c);});}['error'](_0x3be004){this['forEachObserver'](_0x3f7b2c=>{_0x3f7b2c['error'](_0x3be004);}),this['close'](_0x3be004);}['complete'](){this['forEachObserver'](_0x40ab49=>{_0x40ab49['complete']();}),this['close']();}['subscribe'](_0xa6da0a,_0x48db52,_0x339583){let _0x4353e8;if(_0xa6da0a===void 0x0&&_0x48db52===void 0x0&&_0x339583===void 0x0)throw new Error('Missing\x20Observer.');bc(_0xa6da0a,['next','error','complete'])?_0x4353e8=_0xa6da0a:_0x4353e8={'next':_0xa6da0a,'error':_0x48db52,'complete':_0x339583},_0x4353e8['next']===void 0x0&&(_0x4353e8['next']=ti),_0x4353e8['error']===void 0x0&&(_0x4353e8['error']=ti),_0x4353e8['complete']===void 0x0&&(_0x4353e8['complete']=ti);const _0x20e58e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4353e8['error'](this['finalError']):_0x4353e8['complete']();}catch{}}),this['observers']['push'](_0x4353e8),_0x20e58e;}['unsubscribeOne'](_0x3ef319){this['observers']===void 0x0||this['observers'][_0x3ef319]===void 0x0||(delete this['observers'][_0x3ef319],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x31bee5){if(!this['finalized']){for(let _0xbdcb4f=0x0;_0xbdcb4f<this['observers']['length'];_0xbdcb4f++)this['sendOne'](_0xbdcb4f,_0x31bee5);}}['sendOne'](_0x3f2b84,_0x4e1609){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3f2b84]!==void 0x0)try{_0x4e1609(this['observers'][_0x3f2b84]);}catch(_0x14f565){typeof console<'u'&&console['error']&&console['error'](_0x14f565);}});}['close'](_0x1ff642){this['finalized']||(this['finalized']=!0x0,_0x1ff642!==void 0x0&&(this['finalError']=_0x1ff642),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x358c08,_0x227260){if(typeof _0x358c08!='object'||_0x358c08===null)return!0x1;for(const _0x2b87fa of _0x227260)if(_0x2b87fa in _0x358c08&&typeof _0x358c08[_0x2b87fa]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x18c893,_0x4d00e1){return _0x18c893+'\x20failed:\x20'+_0x4d00e1+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x390a4b){const _0x3db14d=[];let _0x569ae5=0x0;for(let _0x2725ca=0x0;_0x2725ca<_0x390a4b['length'];_0x2725ca++){let _0x5e6beb=_0x390a4b['charCodeAt'](_0x2725ca);if(_0x5e6beb>=0xd800&&_0x5e6beb<=0xdbff){const _0x49587a=_0x5e6beb-0xd800;_0x2725ca++,f(_0x2725ca<_0x390a4b['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x309783=_0x390a4b['charCodeAt'](_0x2725ca)-0xdc00;_0x5e6beb=0x10000+(_0x49587a<<0xa)+_0x309783;}_0x5e6beb<0x80?_0x3db14d[_0x569ae5++]=_0x5e6beb:_0x5e6beb<0x800?(_0x3db14d[_0x569ae5++]=_0x5e6beb>>0x6|0xc0,_0x3db14d[_0x569ae5++]=_0x5e6beb&0x3f|0x80):_0x5e6beb<0x10000?(_0x3db14d[_0x569ae5++]=_0x5e6beb>>0xc|0xe0,_0x3db14d[_0x569ae5++]=_0x5e6beb>>0x6&0x3f|0x80,_0x3db14d[_0x569ae5++]=_0x5e6beb&0x3f|0x80):(_0x3db14d[_0x569ae5++]=_0x5e6beb>>0x12|0xf0,_0x3db14d[_0x569ae5++]=_0x5e6beb>>0xc&0x3f|0x80,_0x3db14d[_0x569ae5++]=_0x5e6beb>>0x6&0x3f|0x80,_0x3db14d[_0x569ae5++]=_0x5e6beb&0x3f|0x80);}return _0x3db14d;},Ln=function(_0x3efb98){let _0x4c5314=0x0;for(let _0x2f9e82=0x0;_0x2f9e82<_0x3efb98['length'];_0x2f9e82++){const _0x522c69=_0x3efb98['charCodeAt'](_0x2f9e82);_0x522c69<0x80?_0x4c5314++:_0x522c69<0x800?_0x4c5314+=0x2:_0x522c69>=0xd800&&_0x522c69<=0xdbff?(_0x4c5314+=0x4,_0x2f9e82++):_0x4c5314+=0x3;}return _0x4c5314;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x392992){return _0x392992&&_0x392992['_delegate']?_0x392992['_delegate']:_0x392992;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x4b9580){try{return(_0x4b9580['startsWith']('http://')||_0x4b9580['startsWith']('https://')?new URL(_0x4b9580)['hostname']:_0x4b9580)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x5a714d){return(await fetch(_0x5a714d,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x27b5e6,_0x10d850,_0x1b8d2e){this['name']=_0x27b5e6,this['instanceFactory']=_0x10d850,this['type']=_0x1b8d2e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x311526){return this['instantiationMode']=_0x311526,this;}['setMultipleInstances'](_0x3a3622){return this['multipleInstances']=_0x3a3622,this;}['setServiceProps'](_0x12ef94){return this['serviceProps']=_0x12ef94,this;}['setInstanceCreatedCallback'](_0x3786cb){return this['onInstanceCreated']=_0x3786cb,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xcf160e,_0x2ac437){this['name']=_0xcf160e,this['container']=_0x2ac437,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x63a143){const _0x511c18=this['normalizeInstanceIdentifier'](_0x63a143);if(!this['instancesDeferred']['has'](_0x511c18)){const _0x1fc021=new H();if(this['instancesDeferred']['set'](_0x511c18,_0x1fc021),this['isInitialized'](_0x511c18)||this['shouldAutoInitialize']())try{const _0x2dd889=this['getOrInitializeService']({'instanceIdentifier':_0x511c18});_0x2dd889&&_0x1fc021['resolve'](_0x2dd889);}catch{}}return this['instancesDeferred']['get'](_0x511c18)['promise'];}['getImmediate'](_0xb18504){const _0x1fc851=this['normalizeInstanceIdentifier'](_0xb18504==null?void 0x0:_0xb18504['identifier']),_0x4b5075=(_0xb18504==null?void 0x0:_0xb18504['optional'])??!0x1;if(this['isInitialized'](_0x1fc851)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1fc851});}catch(_0x17ef62){if(_0x4b5075)return null;throw _0x17ef62;}else{if(_0x4b5075)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x530e2f){if(_0x530e2f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x530e2f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x530e2f,!!this['shouldAutoInitialize']()){if(Pc(_0x530e2f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x351c17,_0x688dff]of this['instancesDeferred']['entries']()){const _0x3042ec=this['normalizeInstanceIdentifier'](_0x351c17);try{const _0x50a7ca=this['getOrInitializeService']({'instanceIdentifier':_0x3042ec});_0x688dff['resolve'](_0x50a7ca);}catch{}}}}['clearInstance'](_0x4900dd=Ne){this['instancesDeferred']['delete'](_0x4900dd),this['instancesOptions']['delete'](_0x4900dd),this['instances']['delete'](_0x4900dd);}async['delete'](){const _0x4a6f55=Array['from'](this['instances']['values']());await Promise['all']([..._0x4a6f55['filter'](_0x5de244=>'INTERNAL'in _0x5de244)['map'](_0x2ee9cd=>_0x2ee9cd['INTERNAL']['delete']()),..._0x4a6f55['filter'](_0x22084a=>'_delete'in _0x22084a)['map'](_0x33b349=>_0x33b349['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4e502a=Ne){return this['instances']['has'](_0x4e502a);}['getOptions'](_0x4aec12=Ne){return this['instancesOptions']['get'](_0x4aec12)||{};}['initialize'](_0x2eb1b5={}){const {options:_0x3ca0bf={}}=_0x2eb1b5,_0x456be7=this['normalizeInstanceIdentifier'](_0x2eb1b5['instanceIdentifier']);if(this['isInitialized'](_0x456be7))throw Error(this['name']+'('+_0x456be7+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5a863b=this['getOrInitializeService']({'instanceIdentifier':_0x456be7,'options':_0x3ca0bf});for(const [_0x12471c,_0x2f5bd5]of this['instancesDeferred']['entries']()){const _0x165180=this['normalizeInstanceIdentifier'](_0x12471c);_0x456be7===_0x165180&&_0x2f5bd5['resolve'](_0x5a863b);}return _0x5a863b;}['onInit'](_0xb78de8,_0x5bdbc2){const _0x1aba85=this['normalizeInstanceIdentifier'](_0x5bdbc2),_0x1ca7f1=this['onInitCallbacks']['get'](_0x1aba85)??new Set();_0x1ca7f1['add'](_0xb78de8),this['onInitCallbacks']['set'](_0x1aba85,_0x1ca7f1);const _0x3376e6=this['instances']['get'](_0x1aba85);return _0x3376e6&&_0xb78de8(_0x3376e6,_0x1aba85),()=>{_0x1ca7f1['delete'](_0xb78de8);};}['invokeOnInitCallbacks'](_0x4071f4,_0x5714a5){const _0x197a0b=this['onInitCallbacks']['get'](_0x5714a5);if(_0x197a0b){for(const _0x5f7d86 of _0x197a0b)try{_0x5f7d86(_0x4071f4,_0x5714a5);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1faf1c,options:_0x4e455e={}}){let _0x59c020=this['instances']['get'](_0x1faf1c);if(!_0x59c020&&this['component']&&(_0x59c020=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1faf1c),'options':_0x4e455e}),this['instances']['set'](_0x1faf1c,_0x59c020),this['instancesOptions']['set'](_0x1faf1c,_0x4e455e),this['invokeOnInitCallbacks'](_0x59c020,_0x1faf1c),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1faf1c,_0x59c020);}catch{}return _0x59c020||null;}['normalizeInstanceIdentifier'](_0x3cdad8=Ne){return this['component']?this['component']['multipleInstances']?_0x3cdad8:Ne:_0x3cdad8;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x49318c){return _0x49318c===Ne?void 0x0:_0x49318c;}function Pc(_0x35e4ce){return _0x35e4ce['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4edebe){this['name']=_0x4edebe,this['providers']=new Map();}['addComponent'](_0x49e75d){const _0x3aa1c4=this['getProvider'](_0x49e75d['name']);if(_0x3aa1c4['isComponentSet']())throw new Error('Component\x20'+_0x49e75d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3aa1c4['setComponent'](_0x49e75d);}['addOrOverwriteComponent'](_0xc82788){this['getProvider'](_0xc82788['name'])['isComponentSet']()&&this['providers']['delete'](_0xc82788['name']),this['addComponent'](_0xc82788);}['getProvider'](_0x3f53fd){if(this['providers']['has'](_0x3f53fd))return this['providers']['get'](_0x3f53fd);const _0x23dcbb=new Ac(_0x3f53fd,this);return this['providers']['set'](_0x3f53fd,_0x23dcbb),_0x23dcbb;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x24a3aa){_0x24a3aa[_0x24a3aa['DEBUG']=0x0]='DEBUG',_0x24a3aa[_0x24a3aa['VERBOSE']=0x1]='VERBOSE',_0x24a3aa[_0x24a3aa['INFO']=0x2]='INFO',_0x24a3aa[_0x24a3aa['WARN']=0x3]='WARN',_0x24a3aa[_0x24a3aa['ERROR']=0x4]='ERROR',_0x24a3aa[_0x24a3aa['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x1b58b4,_0x5c0708,..._0x1d91c9)=>{if(_0x5c0708<_0x1b58b4['logLevel'])return;const _0xfb633d=new Date()['toISOString'](),_0x3cb943=Mc[_0x5c0708];if(_0x3cb943)console[_0x3cb943]('['+_0xfb633d+']\x20\x20'+_0x1b58b4['name']+':',..._0x1d91c9);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5c0708+')');};class Bi{constructor(_0x1810f6){this['name']=_0x1810f6,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x22c364){if(!(_0x22c364 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x22c364+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x22c364;}['setLogLevel'](_0x12cf5f){this['_logLevel']=typeof _0x12cf5f=='string'?Oc[_0x12cf5f]:_0x12cf5f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xb07661){if(typeof _0xb07661!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xb07661;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x47e922){this['_userLogHandler']=_0x47e922;}['debug'](..._0x3c0536){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3c0536),this['_logHandler'](this,T['DEBUG'],..._0x3c0536);}['log'](..._0x2f0ff2){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2f0ff2),this['_logHandler'](this,T['VERBOSE'],..._0x2f0ff2);}['info'](..._0x1fc3f9){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1fc3f9),this['_logHandler'](this,T['INFO'],..._0x1fc3f9);}['warn'](..._0x26c038){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x26c038),this['_logHandler'](this,T['WARN'],..._0x26c038);}['error'](..._0x5ccc3e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5ccc3e),this['_logHandler'](this,T['ERROR'],..._0x5ccc3e);}}const xc=(_0x544107,_0x373f60)=>_0x373f60['some'](_0x1530a0=>_0x544107 instanceof _0x1530a0);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4a456d){const _0x10531d=new Promise((_0x46b76d,_0x904e80)=>{const _0x12041d=()=>{_0x4a456d['removeEventListener']('success',_0x52c08c),_0x4a456d['removeEventListener']('error',_0x4fd985);},_0x52c08c=()=>{_0x46b76d(ge(_0x4a456d['result'])),_0x12041d();},_0x4fd985=()=>{_0x904e80(_0x4a456d['error']),_0x12041d();};_0x4a456d['addEventListener']('success',_0x52c08c),_0x4a456d['addEventListener']('error',_0x4fd985);});return _0x10531d['then'](_0x2c1a70=>{_0x2c1a70 instanceof IDBCursor&&Jr['set'](_0x2c1a70,_0x4a456d);})['catch'](()=>{}),Vi['set'](_0x10531d,_0x4a456d),_0x10531d;}function Bc(_0x11d55c){if(_i['has'](_0x11d55c))return;const _0xf41c00=new Promise((_0x37f8d5,_0x35a529)=>{const _0x5d02d1=()=>{_0x11d55c['removeEventListener']('complete',_0x4e5ef4),_0x11d55c['removeEventListener']('error',_0x181e3e),_0x11d55c['removeEventListener']('abort',_0x181e3e);},_0x4e5ef4=()=>{_0x37f8d5(),_0x5d02d1();},_0x181e3e=()=>{_0x35a529(_0x11d55c['error']||new DOMException('AbortError','AbortError')),_0x5d02d1();};_0x11d55c['addEventListener']('complete',_0x4e5ef4),_0x11d55c['addEventListener']('error',_0x181e3e),_0x11d55c['addEventListener']('abort',_0x181e3e);});_i['set'](_0x11d55c,_0xf41c00);}let gi={'get'(_0x6e3535,_0x1d1e01,_0x1d9263){if(_0x6e3535 instanceof IDBTransaction){if(_0x1d1e01==='done')return _i['get'](_0x6e3535);if(_0x1d1e01==='objectStoreNames')return _0x6e3535['objectStoreNames']||Xr['get'](_0x6e3535);if(_0x1d1e01==='store')return _0x1d9263['objectStoreNames'][0x1]?void 0x0:_0x1d9263['objectStore'](_0x1d9263['objectStoreNames'][0x0]);}return ge(_0x6e3535[_0x1d1e01]);},'set'(_0x46d02c,_0x159d6c,_0x3ba79a){return _0x46d02c[_0x159d6c]=_0x3ba79a,!0x0;},'has'(_0x36dd0c,_0x5cf16b){return _0x36dd0c instanceof IDBTransaction&&(_0x5cf16b==='done'||_0x5cf16b==='store')?!0x0:_0x5cf16b in _0x36dd0c;}};function Vc(_0x6d0fc5){gi=_0x6d0fc5(gi);}function Hc(_0x162c86){return _0x162c86===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2fb431,..._0x193dcd){const _0x2b29d2=_0x162c86['call'](ii(this),_0x2fb431,..._0x193dcd);return Xr['set'](_0x2b29d2,_0x2fb431['sort']?_0x2fb431['sort']():[_0x2fb431]),ge(_0x2b29d2);}:Uc()['includes'](_0x162c86)?function(..._0x5a80b1){return _0x162c86['apply'](ii(this),_0x5a80b1),ge(Jr['get'](this));}:function(..._0x22b1d8){return ge(_0x162c86['apply'](ii(this),_0x22b1d8));};}function $c(_0x3739b4){return typeof _0x3739b4=='function'?Hc(_0x3739b4):(_0x3739b4 instanceof IDBTransaction&&Bc(_0x3739b4),xc(_0x3739b4,Fc())?new Proxy(_0x3739b4,gi):_0x3739b4);}function ge(_0x54e520){if(_0x54e520 instanceof IDBRequest)return Wc(_0x54e520);if(ni['has'](_0x54e520))return ni['get'](_0x54e520);const _0x3de2c8=$c(_0x54e520);return _0x3de2c8!==_0x54e520&&(ni['set'](_0x54e520,_0x3de2c8),Vi['set'](_0x3de2c8,_0x54e520)),_0x3de2c8;}const ii=_0x3f80ab=>Vi['get'](_0x3f80ab);function Gc(_0x4b9c84,_0x5397c5,{blocked:_0x179f34,upgrade:_0x828c47,blocking:_0x45d5d5,terminated:_0x507cc2}={}){const _0x43789f=indexedDB['open'](_0x4b9c84,_0x5397c5),_0x4ae103=ge(_0x43789f);return _0x828c47&&_0x43789f['addEventListener']('upgradeneeded',_0x5694f1=>{_0x828c47(ge(_0x43789f['result']),_0x5694f1['oldVersion'],_0x5694f1['newVersion'],ge(_0x43789f['transaction']),_0x5694f1);}),_0x179f34&&_0x43789f['addEventListener']('blocked',_0x5dc62b=>_0x179f34(_0x5dc62b['oldVersion'],_0x5dc62b['newVersion'],_0x5dc62b)),_0x4ae103['then'](_0x4a7906=>{_0x507cc2&&_0x4a7906['addEventListener']('close',()=>_0x507cc2()),_0x45d5d5&&_0x4a7906['addEventListener']('versionchange',_0x5f1757=>_0x45d5d5(_0x5f1757['oldVersion'],_0x5f1757['newVersion'],_0x5f1757));})['catch'](()=>{}),_0x4ae103;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x21c73d,_0x24de6a){if(!(_0x21c73d instanceof IDBDatabase&&!(_0x24de6a in _0x21c73d)&&typeof _0x24de6a=='string'))return;if(si['get'](_0x24de6a))return si['get'](_0x24de6a);const _0x9ac20f=_0x24de6a['replace'](/FromIndex$/,''),_0x322285=_0x24de6a!==_0x9ac20f,_0x1c22c0=zc['includes'](_0x9ac20f);if(!(_0x9ac20f in(_0x322285?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1c22c0||qc['includes'](_0x9ac20f)))return;const _0xfba799=async function(_0x5766fd,..._0x253e6a){const _0x1d4b3f=this['transaction'](_0x5766fd,_0x1c22c0?'readwrite':'readonly');let _0xb0904f=_0x1d4b3f['store'];return _0x322285&&(_0xb0904f=_0xb0904f['index'](_0x253e6a['shift']())),(await Promise['all']([_0xb0904f[_0x9ac20f](..._0x253e6a),_0x1c22c0&&_0x1d4b3f['done']]))[0x0];};return si['set'](_0x24de6a,_0xfba799),_0xfba799;}Vc(_0x513a86=>({..._0x513a86,'get':(_0x158292,_0x5a0030,_0x4cbc14)=>Ms(_0x158292,_0x5a0030)||_0x513a86['get'](_0x158292,_0x5a0030,_0x4cbc14),'has':(_0x554553,_0x2b18b3)=>!!Ms(_0x554553,_0x2b18b3)||_0x513a86['has'](_0x554553,_0x2b18b3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5a902c){this['container']=_0x5a902c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x43180b=>{if(Kc(_0x43180b)){const _0x1b9718=_0x43180b['getImmediate']();return _0x1b9718['library']+'/'+_0x1b9718['version'];}else return null;})['filter'](_0x49bd4c=>_0x49bd4c)['join']('\x20');}}function Kc(_0x226a94){const _0x9e9c04=_0x226a94['getComponent']();return(_0x9e9c04==null?void 0x0:_0x9e9c04['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x50d76b,_0x5bd689){try{_0x50d76b['container']['addComponent'](_0x5bd689);}catch(_0x27ec51){oe['debug']('Component\x20'+_0x5bd689['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x50d76b['name'],_0x27ec51);}}function st(_0x939528){const _0x50d4c4=_0x939528['name'];if(Ei['has'](_0x50d4c4))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x50d4c4+'.'),!0x1;Ei['set'](_0x50d4c4,_0x939528);for(const _0xc2de09 of Ue['values']())xs(_0xc2de09,_0x939528);for(const _0x130de1 of vi['values']())xs(_0x130de1,_0x939528);return!0x0;}function Hi(_0x5c9246,_0x180c60){const _0x488dc4=_0x5c9246['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x488dc4&&_0x488dc4['triggerHeartbeat'](),_0x5c9246['container']['getProvider'](_0x180c60);}function $(_0xd9f06c){return _0xd9f06c==null?!0x1:_0xd9f06c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5e5101,_0x1f7119,_0xaa8383){this['_isDeleted']=!0x1,this['_options']={..._0x5e5101},this['_config']={..._0x1f7119},this['_name']=_0x1f7119['name'],this['_automaticDataCollectionEnabled']=_0x1f7119['automaticDataCollectionEnabled'],this['_container']=_0xaa8383,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2cf813){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2cf813;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x52ed20){this['_isDeleted']=_0x52ed20;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x5cd679,_0x5b43ca={}){let _0x5c1141=_0x5cd679;typeof _0x5b43ca!='object'&&(_0x5b43ca={'name':_0x5b43ca});const _0x5614bf={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x5b43ca},_0x59e05f=_0x5614bf['name'];if(typeof _0x59e05f!='string'||!_0x59e05f)throw me['create']('bad-app-name',{'appName':String(_0x59e05f)});if(_0x5c1141||(_0x5c1141=zr()),!_0x5c1141)throw me['create']('no-options');const _0x98e5de=Ue['get'](_0x59e05f);if(_0x98e5de){if(xe(_0x5c1141,_0x98e5de['options'])&&xe(_0x5614bf,_0x98e5de['config']))return _0x98e5de;throw me['create']('duplicate-app',{'appName':_0x59e05f});}const _0x474a82=new Nc(_0x59e05f);for(const _0x4542b2 of Ei['values']())_0x474a82['addComponent'](_0x4542b2);const _0x2357aa=new Tl(_0x5c1141,_0x5614bf,_0x474a82);return Ue['set'](_0x59e05f,_0x2357aa),_0x2357aa;}function Zr(_0x477c7e=yi){const _0x499642=Ue['get'](_0x477c7e);if(!_0x499642&&_0x477c7e===yi&&zr())return Sl();if(!_0x499642)throw me['create']('no-app',{'appName':_0x477c7e});return _0x499642;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x434953){let _0x2d2bde=!0x1;const _0x448d30=_0x434953['name'];Ue['has'](_0x448d30)?(_0x2d2bde=!0x0,Ue['delete'](_0x448d30)):vi['has'](_0x448d30)&&_0x434953['decRefCount']()<=0x0&&(vi['delete'](_0x448d30),_0x2d2bde=!0x0),_0x2d2bde&&(await Promise['all'](_0x434953['container']['getProviders']()['map'](_0x2abac2=>_0x2abac2['delete']())),_0x434953['isDeleted']=!0x0);}function ye(_0x468658,_0x5dd634,_0x2284f2){let _0x284819=wl[_0x468658]??_0x468658;_0x2284f2&&(_0x284819+='-'+_0x2284f2);const _0x402c6f=_0x284819['match'](/\s|\//),_0x138780=_0x5dd634['match'](/\s|\//);if(_0x402c6f||_0x138780){const _0x46c7cc=['Unable\x20to\x20register\x20library\x20\x22'+_0x284819+'\x22\x20with\x20version\x20\x22'+_0x5dd634+'\x22:'];_0x402c6f&&_0x46c7cc['push']('library\x20name\x20\x22'+_0x284819+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x402c6f&&_0x138780&&_0x46c7cc['push']('and'),_0x138780&&_0x46c7cc['push']('version\x20name\x20\x22'+_0x5dd634+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x46c7cc['join']('\x20'));return;}st(new Fe(_0x284819+'-version',()=>({'library':_0x284819,'version':_0x5dd634}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x275f86,_0x47666e)=>{switch(_0x47666e){case 0x0:try{_0x275f86['createObjectStore'](Ot);}catch(_0x52f4bb){console['warn'](_0x52f4bb);}}}})['catch'](_0x4bb8c3=>{throw me['create']('idb-open',{'originalErrorMessage':_0x4bb8c3['message']});})),ri;}async function Al(_0x1f4abf){try{const _0x36d7f0=(await eo())['transaction'](Ot),_0x1016a8=await _0x36d7f0['objectStore'](Ot)['get'](to(_0x1f4abf));return await _0x36d7f0['done'],_0x1016a8;}catch(_0x52766e){if(_0x52766e instanceof Re)oe['warn'](_0x52766e['message']);else{const _0x31c651=me['create']('idb-get',{'originalErrorMessage':_0x52766e==null?void 0x0:_0x52766e['message']});oe['warn'](_0x31c651['message']);}}}async function Fs(_0x46c14f,_0x34aa42){try{const _0x5be259=(await eo())['transaction'](Ot,'readwrite');await _0x5be259['objectStore'](Ot)['put'](_0x34aa42,to(_0x46c14f)),await _0x5be259['done'];}catch(_0x40d11c){if(_0x40d11c instanceof Re)oe['warn'](_0x40d11c['message']);else{const _0x472802=me['create']('idb-set',{'originalErrorMessage':_0x40d11c==null?void 0x0:_0x40d11c['message']});oe['warn'](_0x472802['message']);}}}function to(_0x424eaa){return _0x424eaa['name']+'!'+_0x424eaa['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x384aba){this['container']=_0x384aba,this['_heartbeatsCache']=null;const _0x400a6b=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x400a6b),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x16b31a=>(this['_heartbeatsCache']=_0x16b31a,_0x16b31a));}async['triggerHeartbeat'](){var _0x2a725e,_0x3a6885;try{const _0x12b4a1=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x47d5d0=Us();if(((_0x2a725e=this['_heartbeatsCache'])==null?void 0x0:_0x2a725e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3a6885=this['_heartbeatsCache'])==null?void 0x0:_0x3a6885['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x47d5d0||this['_heartbeatsCache']['heartbeats']['some'](_0x12ffd6=>_0x12ffd6['date']===_0x47d5d0))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x47d5d0,'agent':_0x12b4a1}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x178e7d=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x178e7d,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x21b330){oe['warn'](_0x21b330);}}async['getHeartbeatsHeader'](){var _0x5af3ce;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5af3ce=this['_heartbeatsCache'])==null?void 0x0:_0x5af3ce['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1f9bfc=Us(),{heartbeatsToSend:_0x4404f3,unsentEntries:_0x4a058b}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2504f1=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4404f3}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1f9bfc,_0x4a058b['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4a058b,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2504f1;}catch(_0x918e69){return oe['warn'](_0x918e69),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5ebce7,_0x414d99=kl){const _0x3d58cc=[];let _0x1acb7f=_0x5ebce7['slice']();for(const _0x300b88 of _0x5ebce7){const _0x5c56b1=_0x3d58cc['find'](_0x518658=>_0x518658['agent']===_0x300b88['agent']);if(_0x5c56b1){if(_0x5c56b1['dates']['push'](_0x300b88['date']),Ws(_0x3d58cc)>_0x414d99){_0x5c56b1['dates']['pop']();break;}}else{if(_0x3d58cc['push']({'agent':_0x300b88['agent'],'dates':[_0x300b88['date']]}),Ws(_0x3d58cc)>_0x414d99){_0x3d58cc['pop']();break;}}_0x1acb7f=_0x1acb7f['slice'](0x1);}return{'heartbeatsToSend':_0x3d58cc,'unsentEntries':_0x1acb7f};}class Dl{constructor(_0x3977c5){this['app']=_0x3977c5,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2379df=await Al(this['app']);return _0x2379df!=null&&_0x2379df['heartbeats']?_0x2379df:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1f795c){if(await this['_canUseIndexedDBPromise']){const _0x835971=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1f795c['lastSentHeartbeatDate']??_0x835971['lastSentHeartbeatDate'],'heartbeats':_0x1f795c['heartbeats']});}else return;}async['add'](_0x481519){if(await this['_canUseIndexedDBPromise']){const _0x50081f=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x481519['lastSentHeartbeatDate']??_0x50081f['lastSentHeartbeatDate'],'heartbeats':[..._0x50081f['heartbeats'],..._0x481519['heartbeats']]});}else return;}}function Ws(_0x1720ec){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1720ec}))['length'];}function Ml(_0x3b04f7){if(_0x3b04f7['length']===0x0)return-0x1;let _0x3ad4ef=0x0,_0x4c857c=_0x3b04f7[0x0]['date'];for(let _0x31c262=0x1;_0x31c262<_0x3b04f7['length'];_0x31c262++)_0x3b04f7[_0x31c262]['date']<_0x4c857c&&(_0x4c857c=_0x3b04f7[_0x31c262]['date'],_0x3ad4ef=_0x31c262);return _0x3ad4ef;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x41bb1b){st(new Fe('platform-logger',_0x541270=>new jc(_0x541270),'PRIVATE')),st(new Fe('heartbeat',_0x449d47=>new Nl(_0x449d47),'PRIVATE')),ye(mi,Ls,_0x41bb1b),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x4ec595){no=_0x4ec595;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x16eaa3){this['domStorage_']=_0x16eaa3,this['prefix_']='firebase:';}['set'](_0x59cb29,_0x20de50){_0x20de50==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x59cb29)):this['domStorage_']['setItem'](this['prefixedName_'](_0x59cb29),O(_0x20de50));}['get'](_0x2bf00d){const _0x3651bd=this['domStorage_']['getItem'](this['prefixedName_'](_0x2bf00d));return _0x3651bd==null?null:Nt(_0x3651bd);}['remove'](_0x354f4b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x354f4b));}['prefixedName_'](_0xeb09be){return this['prefix_']+_0xeb09be;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5ef2e6,_0x49ef5d){_0x49ef5d==null?delete this['cache_'][_0x5ef2e6]:this['cache_'][_0x5ef2e6]=_0x49ef5d;}['get'](_0x51095b){return Q(this['cache_'],_0x51095b)?this['cache_'][_0x51095b]:null;}['remove'](_0x1e0a32){delete this['cache_'][_0x1e0a32];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x8390b3){try{if(typeof window<'u'&&typeof window[_0x8390b3]<'u'){const _0x56a032=window[_0x8390b3];return _0x56a032['setItem']('firebase:sentinel','cache'),_0x56a032['removeItem']('firebase:sentinel'),new Wl(_0x56a032);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3c895e=0x1;return function(){return _0x3c895e++;};}()),ro=function(_0x276b2e){const _0x1a6ccb=Rc(_0x276b2e),_0x295bf5=new Cc();_0x295bf5['update'](_0x1a6ccb);const _0x57c045=_0x295bf5['digest']();return Fi['encodeByteArray'](_0x57c045);},zt=function(..._0x4259c2){let _0x4d6034='';for(let _0x571345=0x0;_0x571345<_0x4259c2['length'];_0x571345++){const _0x44828c=_0x4259c2[_0x571345];Array['isArray'](_0x44828c)||_0x44828c&&typeof _0x44828c=='object'&&typeof _0x44828c['length']=='number'?_0x4d6034+=zt['apply'](null,_0x44828c):typeof _0x44828c=='object'?_0x4d6034+=O(_0x44828c):_0x4d6034+=_0x44828c,_0x4d6034+='\x20';}return _0x4d6034;};let St=null,$s=!0x0;const Hl=function(_0x359947,_0x2cb9d5){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x3a2c45){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x94f19d=zt['apply'](null,_0x3a2c45);St(_0x94f19d);}},jt=function(_0x4c8acb){return function(..._0xd563b7){L(_0x4c8acb,..._0xd563b7);};},Ii=function(..._0x20f437){const _0x5dc76d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x20f437);Ze['error'](_0x5dc76d);},ae=function(..._0x147216){const _0x2b9d82='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x147216);throw Ze['error'](_0x2b9d82),new Error(_0x2b9d82);},U=function(..._0x509a7b){const _0x3d89a9='FIREBASE\x20WARNING:\x20'+zt(..._0x509a7b);Ze['warn'](_0x3d89a9);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x49142d){return typeof _0x49142d=='number'&&(_0x49142d!==_0x49142d||_0x49142d===Number['POSITIVE_INFINITY']||_0x49142d===Number['NEGATIVE_INFINITY']);},Gl=function(_0x48fccd){if(document['readyState']==='complete')_0x48fccd();else{let _0x481655=!0x1;const _0x2e940b=function(){if(!document['body']){setTimeout(_0x2e940b,Math['floor'](0xa));return;}_0x481655||(_0x481655=!0x0,_0x48fccd());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2e940b,!0x1),window['addEventListener']('load',_0x2e940b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2e940b();}),window['attachEvent']('onload',_0x2e940b));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x1ff479,_0x5e2e44){if(_0x1ff479===_0x5e2e44)return 0x0;if(_0x1ff479===We||_0x5e2e44===we)return-0x1;if(_0x5e2e44===We||_0x1ff479===we)return 0x1;{const _0x1079c1=Gs(_0x1ff479),_0x26e132=Gs(_0x5e2e44);return _0x1079c1!==null?_0x26e132!==null?_0x1079c1-_0x26e132===0x0?_0x1ff479['length']-_0x5e2e44['length']:_0x1079c1-_0x26e132:-0x1:_0x26e132!==null?0x1:_0x1ff479<_0x5e2e44?-0x1:0x1;}},ql=function(_0x28668c,_0x92cc56){return _0x28668c===_0x92cc56?0x0:_0x28668c<_0x92cc56?-0x1:0x1;},vt=function(_0x65e494,_0x40373f){if(_0x40373f&&_0x65e494 in _0x40373f)return _0x40373f[_0x65e494];throw new Error('Missing\x20required\x20key\x20('+_0x65e494+')\x20in\x20object:\x20'+O(_0x40373f));},$i=function(_0x3a9562){if(typeof _0x3a9562!='object'||_0x3a9562===null)return O(_0x3a9562);const _0x3612be=[];for(const _0x533da2 in _0x3a9562)_0x3612be['push'](_0x533da2);_0x3612be['sort']();let _0x3782b2='{';for(let _0x49e123=0x0;_0x49e123<_0x3612be['length'];_0x49e123++)_0x49e123!==0x0&&(_0x3782b2+=','),_0x3782b2+=O(_0x3612be[_0x49e123]),_0x3782b2+=':',_0x3782b2+=$i(_0x3a9562[_0x3612be[_0x49e123]]);return _0x3782b2+='}',_0x3782b2;},oo=function(_0x29cd31,_0x58b8dc){const _0x507be1=_0x29cd31['length'];if(_0x507be1<=_0x58b8dc)return[_0x29cd31];const _0x28d92a=[];for(let _0x5d101e=0x0;_0x5d101e<_0x507be1;_0x5d101e+=_0x58b8dc)_0x5d101e+_0x58b8dc>_0x507be1?_0x28d92a['push'](_0x29cd31['substring'](_0x5d101e,_0x507be1)):_0x28d92a['push'](_0x29cd31['substring'](_0x5d101e,_0x5d101e+_0x58b8dc));return _0x28d92a;};function x(_0x283c57,_0xc32a8e){for(const _0x53fdc8 in _0x283c57)_0x283c57['hasOwnProperty'](_0x53fdc8)&&_0xc32a8e(_0x53fdc8,_0x283c57[_0x53fdc8]);}const ao=function(_0x1b69e6){f(!xn(_0x1b69e6),'Invalid\x20JSON\x20number');const _0x4407f0=0xb,_0x460c1c=0x34,_0xea815=(0x1<<_0x4407f0-0x1)-0x1;let _0x495cdc,_0x352e22,_0x289774,_0x2e1a33,_0x151003;_0x1b69e6===0x0?(_0x352e22=0x0,_0x289774=0x0,_0x495cdc=0x1/_0x1b69e6===-0x1/0x0?0x1:0x0):(_0x495cdc=_0x1b69e6<0x0,_0x1b69e6=Math['abs'](_0x1b69e6),_0x1b69e6>=Math['pow'](0x2,0x1-_0xea815)?(_0x2e1a33=Math['min'](Math['floor'](Math['log'](_0x1b69e6)/Math['LN2']),_0xea815),_0x352e22=_0x2e1a33+_0xea815,_0x289774=Math['round'](_0x1b69e6*Math['pow'](0x2,_0x460c1c-_0x2e1a33)-Math['pow'](0x2,_0x460c1c))):(_0x352e22=0x0,_0x289774=Math['round'](_0x1b69e6/Math['pow'](0x2,0x1-_0xea815-_0x460c1c))));const _0x3ff827=[];for(_0x151003=_0x460c1c;_0x151003;_0x151003-=0x1)_0x3ff827['push'](_0x289774%0x2?0x1:0x0),_0x289774=Math['floor'](_0x289774/0x2);for(_0x151003=_0x4407f0;_0x151003;_0x151003-=0x1)_0x3ff827['push'](_0x352e22%0x2?0x1:0x0),_0x352e22=Math['floor'](_0x352e22/0x2);_0x3ff827['push'](_0x495cdc?0x1:0x0),_0x3ff827['reverse']();const _0x1df98a=_0x3ff827['join']('');let _0x5e0167='';for(_0x151003=0x0;_0x151003<0x40;_0x151003+=0x8){let _0x19f064=parseInt(_0x1df98a['substr'](_0x151003,0x8),0x2)['toString'](0x10);_0x19f064['length']===0x1&&(_0x19f064='0'+_0x19f064),_0x5e0167=_0x5e0167+_0x19f064;}return _0x5e0167['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0xef13f9,_0x3b1732){let _0x5a00a4='Unknown\x20Error';_0xef13f9==='too_big'?_0x5a00a4='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xef13f9==='permission_denied'?_0x5a00a4='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xef13f9==='unavailable'&&(_0x5a00a4='The\x20service\x20is\x20unavailable');const _0x47fa38=new Error(_0xef13f9+'\x20at\x20'+_0x3b1732['_path']['toString']()+':\x20'+_0x5a00a4);return _0x47fa38['code']=_0xef13f9['toUpperCase'](),_0x47fa38;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x497ab8){if(Yl['test'](_0x497ab8)){const _0x4ed26f=Number(_0x497ab8);if(_0x4ed26f>=Ql&&_0x4ed26f<=Jl)return _0x4ed26f;}return null;},ft=function(_0x2d4300){try{_0x2d4300();}catch(_0x8f4410){setTimeout(()=>{const _0x2d22=_0x8f4410['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2d22),_0x8f4410;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x11d66e,_0xf41036){const _0x13146b=setTimeout(_0x11d66e,_0xf41036);return typeof _0x13146b=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x13146b):typeof _0x13146b=='object'&&_0x13146b['unref']&&_0x13146b['unref'](),_0x13146b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x17ca50,_0x4010bd){this['appCheckProvider']=_0x4010bd,this['appName']=_0x17ca50['name'],$(_0x17ca50)&&_0x17ca50['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x17ca50['settings']['appCheckToken']),this['appCheck']=_0x4010bd==null?void 0x0:_0x4010bd['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4010bd==null||_0x4010bd['get']()['then'](_0xd43ec=>this['appCheck']=_0xd43ec);}['getToken'](_0x21a738){if(this['serverAppAppCheckToken']){if(_0x21a738)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x21a738):new Promise((_0x34c3d3,_0x13ac02)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x21a738)['then'](_0x34c3d3,_0x13ac02):_0x34c3d3(null);},0x0);});}['addTokenChangeListener'](_0xf6a364){var _0x4dc90c;(_0x4dc90c=this['appCheckProvider'])==null||_0x4dc90c['get']()['then'](_0x514fc2=>_0x514fc2['addTokenListener'](_0xf6a364));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x52eef4,_0x278e5e,_0xbed1a8){this['appName_']=_0x52eef4,this['firebaseOptions_']=_0x278e5e,this['authProvider_']=_0xbed1a8,this['auth_']=null,this['auth_']=_0xbed1a8['getImmediate']({'optional':!0x0}),this['auth_']||_0xbed1a8['onInit'](_0x317ced=>this['auth_']=_0x317ced);}['getToken'](_0x1d4951){return this['auth_']?this['auth_']['getToken'](_0x1d4951)['catch'](_0x3689cc=>_0x3689cc&&_0x3689cc['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3689cc)):new Promise((_0x526160,_0x619668)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1d4951)['then'](_0x526160,_0x619668):_0x526160(null);},0x0);});}['addTokenChangeListener'](_0x31fcd5){this['auth_']?this['auth_']['addAuthTokenListener'](_0x31fcd5):this['authProvider_']['get']()['then'](_0x5daa63=>_0x5daa63['addAuthTokenListener'](_0x31fcd5));}['removeTokenChangeListener'](_0x3b2527){this['authProvider_']['get']()['then'](_0x3751da=>_0x3751da['removeAuthTokenListener'](_0x3b2527));}['notifyForInvalidToken'](){let _0x937482='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x937482+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x937482+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x937482+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x937482);}}class an{constructor(_0x375c03){this['accessToken']=_0x375c03;}['getToken'](_0x1ed224){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x320904){_0x320904(this['accessToken']);}['removeTokenChangeListener'](_0x1541b9){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5cb1c0,_0xc3e3c5,_0x4f778d,_0x352244,_0x4bdc31=!0x1,_0x3a9263='',_0xc43893=!0x1,_0x31a1ba=!0x1,_0xcc69b3=null){this['secure']=_0xc3e3c5,this['namespace']=_0x4f778d,this['webSocketOnly']=_0x352244,this['nodeAdmin']=_0x4bdc31,this['persistenceKey']=_0x3a9263,this['includeNamespaceInQueryParams']=_0xc43893,this['isUsingEmulator']=_0x31a1ba,this['emulatorOptions']=_0xcc69b3,this['_host']=_0x5cb1c0['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x5cb1c0)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x14e22d){_0x14e22d!==this['internalHost']&&(this['internalHost']=_0x14e22d,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5c21d4=this['toURLString']();return this['persistenceKey']&&(_0x5c21d4+='<'+this['persistenceKey']+'>'),_0x5c21d4;}['toURLString'](){const _0x25120e=this['secure']?'https://':'http://',_0x392e8c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x25120e+this['host']+'/'+_0x392e8c;}}function th(_0x23db34){return _0x23db34['host']!==_0x23db34['internalHost']||_0x23db34['isCustomHost']()||_0x23db34['includeNamespaceInQueryParams'];}function vo(_0x200cb6,_0x14b2d8,_0x113a13){f(typeof _0x14b2d8=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x113a13=='object','typeof\x20params\x20must\x20==\x20object');let _0xa887ef;if(_0x14b2d8===go)_0xa887ef=(_0x200cb6['secure']?'wss://':'ws://')+_0x200cb6['internalHost']+'/.ws?';else{if(_0x14b2d8===mo)_0xa887ef=(_0x200cb6['secure']?'https://':'http://')+_0x200cb6['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x14b2d8);}th(_0x200cb6)&&(_0x113a13['ns']=_0x200cb6['namespace']);const _0x530043=[];return x(_0x113a13,(_0x539277,_0x14acea)=>{_0x530043['push'](_0x539277+'='+_0x14acea);}),_0xa887ef+_0x530043['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x477f01,_0x1fd8aa=0x1){Q(this['counters_'],_0x477f01)||(this['counters_'][_0x477f01]=0x0),this['counters_'][_0x477f01]+=_0x1fd8aa;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x2fd8d6){const _0x29c261=_0x2fd8d6['toString']();return oi[_0x29c261]||(oi[_0x29c261]=new nh()),oi[_0x29c261];}function ih(_0x4d9040,_0x38e4d2){const _0x507f82=_0x4d9040['toString']();return ai[_0x507f82]||(ai[_0x507f82]=_0x38e4d2()),ai[_0x507f82];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5b8f9a){this['onMessage_']=_0x5b8f9a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x37fda6,_0x243cd4){this['closeAfterResponse']=_0x37fda6,this['onClose']=_0x243cd4,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x170f41,_0x4442fb){for(this['pendingResponses'][_0x170f41]=_0x4442fb;this['pendingResponses'][this['currentResponseNum']];){const _0x26b69a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3b96be=0x0;_0x3b96be<_0x26b69a['length'];++_0x3b96be)_0x26b69a[_0x3b96be]&&ft(()=>{this['onMessage_'](_0x26b69a[_0x3b96be]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2ace1d,_0x4b48fd,_0xd5071e,_0x2caac9,_0x474dda,_0xaf32d4,_0x3e5c95){this['connId']=_0x2ace1d,this['repoInfo']=_0x4b48fd,this['applicationId']=_0xd5071e,this['appCheckToken']=_0x2caac9,this['authToken']=_0x474dda,this['transportSessionId']=_0xaf32d4,this['lastSessionId']=_0x3e5c95,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2ace1d),this['stats_']=qi(_0x4b48fd),this['urlFn']=_0x205c38=>(this['appCheckToken']&&(_0x205c38[wi]=this['appCheckToken']),vo(_0x4b48fd,mo,_0x205c38));}['open'](_0x25a90a,_0x18158b){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x18158b,this['myPacketOrderer']=new sh(_0x25a90a),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x387135)=>{const [_0x54b08e,_0x247672,_0x2b9fe6,_0x166315,_0x57cd7f]=_0x387135;if(this['incrementIncomingBytes_'](_0x387135),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x54b08e===qs)this['id']=_0x247672,this['password']=_0x2b9fe6;else{if(_0x54b08e===rh)_0x247672?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x247672,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x54b08e);}}},(..._0x236d67)=>{const [_0x335b8f,_0x449bea]=_0x236d67;this['incrementIncomingBytes_'](_0x236d67),this['myPacketOrderer']['handleResponse'](_0x335b8f,_0x449bea);},()=>{this['onClosed_']();},this['urlFn']);const _0x301e99={};_0x301e99[qs]='t',_0x301e99[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x301e99[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x301e99[co]=Gi,this['transportSessionId']&&(_0x301e99[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x301e99[po]=this['lastSessionId']),this['applicationId']&&(_0x301e99[_o]=this['applicationId']),this['appCheckToken']&&(_0x301e99[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x301e99[ho]=uo);const _0x12f1d7=this['urlFn'](_0x301e99);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x12f1d7),this['scriptTagHolder']['addTag'](_0x12f1d7,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4136a){const _0x50bb5c=O(_0x4136a);this['bytesSent']+=_0x50bb5c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x50bb5c['length']);const _0x2cccc6=$r(_0x50bb5c),_0x43163d=oo(_0x2cccc6,fh);for(let _0x33895f=0x0;_0x33895f<_0x43163d['length'];_0x33895f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x43163d['length'],_0x43163d[_0x33895f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2ccc06,_0x5cb5ec){this['myDisconnFrame']=document['createElement']('iframe');const _0x369c48={};_0x369c48[dh]='t',_0x369c48[Eo]=_0x2ccc06,_0x369c48[Io]=_0x5cb5ec,this['myDisconnFrame']['src']=this['urlFn'](_0x369c48),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xd3b564){const _0x19764e=O(_0xd3b564)['length'];this['bytesReceived']+=_0x19764e,this['stats_']['incrementCounter']('bytes_received',_0x19764e);}}class zi{constructor(_0x5b517,_0x12d06f,_0x4ac223,_0x584a1a){this['onDisconnect']=_0x4ac223,this['urlFn']=_0x584a1a,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5b517,window[ah+this['uniqueCallbackIdentifier']]=_0x12d06f,this['myIFrame']=zi['createIFrame_']();let _0x2112b6='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2112b6='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2cba1e='<html><body>'+_0x2112b6+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2cba1e),this['myIFrame']['doc']['close']();}catch(_0x414611){L('frame\x20writing\x20exception'),_0x414611['stack']&&L(_0x414611['stack']),L(_0x414611);}}}static['createIFrame_'](){const _0x33b5b9=document['createElement']('iframe');if(_0x33b5b9['style']['display']='none',document['body']){document['body']['appendChild'](_0x33b5b9);try{_0x33b5b9['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x48349b=document['domain'];_0x33b5b9['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x48349b+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x33b5b9['contentDocument']?_0x33b5b9['doc']=_0x33b5b9['contentDocument']:_0x33b5b9['contentWindow']?_0x33b5b9['doc']=_0x33b5b9['contentWindow']['document']:_0x33b5b9['document']&&(_0x33b5b9['doc']=_0x33b5b9['document']),_0x33b5b9;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5d044b=this['onDisconnect'];_0x5d044b&&(this['onDisconnect']=null,_0x5d044b());}['startLongPoll'](_0x407159,_0x810885){for(this['myID']=_0x407159,this['myPW']=_0x810885,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x22668a={};_0x22668a[Eo]=this['myID'],_0x22668a[Io]=this['myPW'],_0x22668a[wo]=this['currentSerial'];let _0x19d214=this['urlFn'](_0x22668a),_0x4b9514='',_0x50e8f5=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4b9514['length']<=Co;){const _0x16ba18=this['pendingSegs']['shift']();_0x4b9514=_0x4b9514+'&'+lh+_0x50e8f5+'='+_0x16ba18['seg']+'&'+hh+_0x50e8f5+'='+_0x16ba18['ts']+'&'+uh+_0x50e8f5+'='+_0x16ba18['d'],_0x50e8f5++;}return _0x19d214=_0x19d214+_0x4b9514,this['addLongPollTag_'](_0x19d214,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x331992,_0x483816,_0x55ba86){this['pendingSegs']['push']({'seg':_0x331992,'ts':_0x483816,'d':_0x55ba86}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x94f2a0,_0x10d3b0){this['outstandingRequests']['add'](_0x10d3b0);const _0x421627=()=>{this['outstandingRequests']['delete'](_0x10d3b0),this['newRequest_']();},_0x35c778=setTimeout(_0x421627,Math['floor'](ph)),_0x49eab4=()=>{clearTimeout(_0x35c778),_0x421627();};this['addTag'](_0x94f2a0,_0x49eab4);}['addTag'](_0x59c55d,_0x44790e){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5b6c06=this['myIFrame']['doc']['createElement']('script');_0x5b6c06['type']='text/javascript',_0x5b6c06['async']=!0x0,_0x5b6c06['src']=_0x59c55d,_0x5b6c06['onload']=_0x5b6c06['onreadystatechange']=function(){const _0x25eef9=_0x5b6c06['readyState'];(!_0x25eef9||_0x25eef9==='loaded'||_0x25eef9==='complete')&&(_0x5b6c06['onload']=_0x5b6c06['onreadystatechange']=null,_0x5b6c06['parentNode']&&_0x5b6c06['parentNode']['removeChild'](_0x5b6c06),_0x44790e());},_0x5b6c06['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x59c55d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5b6c06);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x3c8c0b,_0x463476,_0x3491fe,_0xaaac2d,_0x6fdd56,_0x10ede6,_0x1210d0){this['connId']=_0x3c8c0b,this['applicationId']=_0x3491fe,this['appCheckToken']=_0xaaac2d,this['authToken']=_0x6fdd56,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x463476),this['connURL']=q['connectionURL_'](_0x463476,_0x10ede6,_0x1210d0,_0xaaac2d,_0x3491fe),this['nodeAdmin']=_0x463476['nodeAdmin'];}static['connectionURL_'](_0x549e94,_0x4402f0,_0x7358a5,_0x5472a4,_0x254e9e){const _0x9b2d73={};return _0x9b2d73[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x9b2d73[ho]=uo),_0x4402f0&&(_0x9b2d73[lo]=_0x4402f0),_0x7358a5&&(_0x9b2d73[po]=_0x7358a5),_0x5472a4&&(_0x9b2d73[wi]=_0x5472a4),_0x254e9e&&(_0x9b2d73[_o]=_0x254e9e),vo(_0x549e94,go,_0x9b2d73);}['open'](_0x192073,_0x22ef3c){this['onDisconnect']=_0x22ef3c,this['onMessage']=_0x192073,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x1519f1;_c(),this['mySock']=new gn(this['connURL'],[],_0x1519f1);}catch(_0x1c7279){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x42015e=_0x1c7279['message']||_0x1c7279['data'];_0x42015e&&this['log_'](_0x42015e),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x439621=>{this['handleIncomingFrame'](_0x439621);},this['mySock']['onerror']=_0x516980=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x546b0c=_0x516980['message']||_0x516980['data'];_0x546b0c&&this['log_'](_0x546b0c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x54e7bc=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1ea616=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3abcd6=navigator['userAgent']['match'](_0x1ea616);_0x3abcd6&&_0x3abcd6['length']>0x1&&parseFloat(_0x3abcd6[0x1])<4.4&&(_0x54e7bc=!0x0);}return!_0x54e7bc&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x424297){if(this['frames']['push'](_0x424297),this['frames']['length']===this['totalFrames']){const _0x1c0d32=this['frames']['join']('');this['frames']=null;const _0x297afa=Nt(_0x1c0d32);this['onMessage'](_0x297afa);}}['handleNewFrameCount_'](_0xa65816){this['totalFrames']=_0xa65816,this['frames']=[];}['extractFrameCount_'](_0x2ead4a){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2ead4a['length']<=0x6){const _0x3e250d=Number(_0x2ead4a);if(!isNaN(_0x3e250d))return this['handleNewFrameCount_'](_0x3e250d),null;}return this['handleNewFrameCount_'](0x1),_0x2ead4a;}['handleIncomingFrame'](_0x208876){if(this['mySock']===null)return;const _0x2a59c9=_0x208876['data'];if(this['bytesReceived']+=_0x2a59c9['length'],this['stats_']['incrementCounter']('bytes_received',_0x2a59c9['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2a59c9);else{const _0x38771d=this['extractFrameCount_'](_0x2a59c9);_0x38771d!==null&&this['appendFrame_'](_0x38771d);}}['send'](_0x419b5f){this['resetKeepAlive']();const _0x31d534=O(_0x419b5f);this['bytesSent']+=_0x31d534['length'],this['stats_']['incrementCounter']('bytes_sent',_0x31d534['length']);const _0x5b5b33=oo(_0x31d534,gh);_0x5b5b33['length']>0x1&&this['sendString_'](String(_0x5b5b33['length']));for(let _0x1124b7=0x0;_0x1124b7<_0x5b5b33['length'];_0x1124b7++)this['sendString_'](_0x5b5b33[_0x1124b7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2c3618){try{this['mySock']['send'](_0x2c3618);}catch(_0x47c60c){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x47c60c['message']||_0x47c60c['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2e1775){this['initTransports_'](_0x2e1775);}['initTransports_'](_0x21957b){const _0x1b6ca7=q&&q['isAvailable']();let _0x19c45e=_0x1b6ca7&&!q['previouslyFailed']();if(_0x21957b['webSocketOnly']&&(_0x1b6ca7||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x19c45e=!0x0),_0x19c45e)this['transports_']=[q];else{const _0x469e7c=this['transports_']=[];for(const _0x300091 of Dt['ALL_TRANSPORTS'])_0x300091&&_0x300091['isAvailable']()&&_0x469e7c['push'](_0x300091);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3ae03c,_0x4d6dfe,_0xa32e45,_0x1a0dff,_0x1530f1,_0x558dd3,_0x1f65ee,_0x4395a0,_0x2e0082,_0x5125a5){this['id']=_0x3ae03c,this['repoInfo_']=_0x4d6dfe,this['applicationId_']=_0xa32e45,this['appCheckToken_']=_0x1a0dff,this['authToken_']=_0x1530f1,this['onMessage_']=_0x558dd3,this['onReady_']=_0x1f65ee,this['onDisconnect_']=_0x4395a0,this['onKill_']=_0x2e0082,this['lastSessionId']=_0x5125a5,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x4d6dfe),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3a29a6=this['transportManager_']['initialTransport']();this['conn_']=new _0x3a29a6(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3a29a6['responsesRequiredToBeHealthy']||0x0;const _0x278594=this['connReceiver_'](this['conn_']),_0x3cfa25=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x278594,_0x3cfa25);},Math['floor'](0x0));const _0x54e20f=_0x3a29a6['healthyTimeout']||0x0;_0x54e20f>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x54e20f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x6f98a6){return _0x11b210=>{_0x6f98a6===this['conn_']?this['onConnectionLost_'](_0x11b210):_0x6f98a6===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1fb10b){return _0x1ec61e=>{this['state_']!==0x2&&(_0x1fb10b===this['rx_']?this['onPrimaryMessageReceived_'](_0x1ec61e):_0x1fb10b===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1ec61e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x51cd84){const _0x581089={'t':'d','d':_0x51cd84};this['sendData_'](_0x581089);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x288c57){if(ci in _0x288c57){const _0xd57fe5=_0x288c57[ci];_0xd57fe5===Ys?this['upgradeIfSecondaryHealthy_']():_0xd57fe5===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xd57fe5===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x5e76da){const _0x5834d8=vt('t',_0x5e76da),_0xe1313a=vt('d',_0x5e76da);if(_0x5834d8==='c')this['onSecondaryControl_'](_0xe1313a);else{if(_0x5834d8==='d')this['pendingDataMessages']['push'](_0xe1313a);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5834d8);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x12a407){const _0x38b79f=vt('t',_0x12a407),_0x2a517f=vt('d',_0x12a407);_0x38b79f==='c'?this['onControl_'](_0x2a517f):_0x38b79f==='d'&&this['onDataMessage_'](_0x2a517f);}['onDataMessage_'](_0x1b6ba1){this['onPrimaryResponse_'](),this['onMessage_'](_0x1b6ba1);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4d8903){const _0xc785fb=vt(ci,_0x4d8903);if(zs in _0x4d8903){const _0x39621a=_0x4d8903[zs];if(_0xc785fb===Th){const _0x3f85ea={..._0x39621a};this['repoInfo_']['isUsingEmulator']&&(_0x3f85ea['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3f85ea);}else{if(_0xc785fb===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x7eaa70=0x0;_0x7eaa70<this['pendingDataMessages']['length'];++_0x7eaa70)this['onDataMessage_'](this['pendingDataMessages'][_0x7eaa70]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xc785fb===wh?this['onConnectionShutdown_'](_0x39621a):_0xc785fb===js?this['onReset_'](_0x39621a):_0xc785fb===Ch?Ii('Server\x20Error:\x20'+_0x39621a):_0xc785fb===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xc785fb);}}}['onHandshake_'](_0x30c2f0){const _0x40c86d=_0x30c2f0['ts'],_0x41f893=_0x30c2f0['v'],_0x52aee1=_0x30c2f0['h'];this['sessionId']=_0x30c2f0['s'],this['repoInfo_']['host']=_0x52aee1,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x40c86d),Gi!==_0x41f893&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x321be6=this['transportManager_']['upgradeTransport']();_0x321be6&&this['startUpgrade_'](_0x321be6);}['startUpgrade_'](_0x232a83){this['secondaryConn_']=new _0x232a83(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x232a83['responsesRequiredToBeHealthy']||0x0;const _0x35624a=this['connReceiver_'](this['secondaryConn_']),_0x7f92e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x35624a,_0x7f92e),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x161e7f){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x161e7f),this['repoInfo_']['host']=_0x161e7f,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x11b8da,_0x59fe3b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x11b8da,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x59fe3b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x21ead8=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x21ead8||this['rx_']===_0x21ead8)&&this['close']();}['onConnectionLost_'](_0x54b2fa){this['conn_']=null,!_0x54b2fa&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x13c540){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x13c540),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x999f7a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x999f7a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3b98d0,_0x78d07b,_0x5a4ae8,_0x5f569){}['merge'](_0x33dda4,_0x5a7bd8,_0x4d9398,_0x41ef9c){}['refreshAuthToken'](_0x346ee2){}['refreshAppCheckToken'](_0xbe4bfd){}['onDisconnectPut'](_0x5887e2,_0x197de,_0x1bfb58){}['onDisconnectMerge'](_0x32283d,_0x382bf6,_0x24ebc1){}['onDisconnectCancel'](_0x49a0ce,_0x1eb979){}['reportStats'](_0x26426d){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x5004a5){this['allowedEvents_']=_0x5004a5,this['listeners_']={},f(Array['isArray'](_0x5004a5)&&_0x5004a5['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x9c8193,..._0x544eff){if(Array['isArray'](this['listeners_'][_0x9c8193])){const _0x544c14=[...this['listeners_'][_0x9c8193]];for(let _0x20d3af=0x0;_0x20d3af<_0x544c14['length'];_0x20d3af++)_0x544c14[_0x20d3af]['callback']['apply'](_0x544c14[_0x20d3af]['context'],_0x544eff);}}['on'](_0x1f49e6,_0x998237,_0x566eb9){this['validateEventType_'](_0x1f49e6),this['listeners_'][_0x1f49e6]=this['listeners_'][_0x1f49e6]||[],this['listeners_'][_0x1f49e6]['push']({'callback':_0x998237,'context':_0x566eb9});const _0x27cd7c=this['getInitialEvent'](_0x1f49e6);_0x27cd7c&&_0x998237['apply'](_0x566eb9,_0x27cd7c);}['off'](_0xdcab68,_0x12b110,_0x2fd720){this['validateEventType_'](_0xdcab68);const _0x529420=this['listeners_'][_0xdcab68]||[];for(let _0x3212be=0x0;_0x3212be<_0x529420['length'];_0x3212be++)if(_0x529420[_0x3212be]['callback']===_0x12b110&&(!_0x2fd720||_0x2fd720===_0x529420[_0x3212be]['context'])){_0x529420['splice'](_0x3212be,0x1);return;}}['validateEventType_'](_0x43eb53){f(this['allowedEvents_']['find'](_0xce2b08=>_0xce2b08===_0x43eb53),'Unknown\x20event:\x20'+_0x43eb53);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1cb856){return f(_0x1cb856==='online','Unknown\x20event\x20type:\x20'+_0x1cb856),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x3cecd5,_0x2db3b7){if(_0x2db3b7===void 0x0){this['pieces_']=_0x3cecd5['split']('/');let _0x1eb56b=0x0;for(let _0x52f3c8=0x0;_0x52f3c8<this['pieces_']['length'];_0x52f3c8++)this['pieces_'][_0x52f3c8]['length']>0x0&&(this['pieces_'][_0x1eb56b]=this['pieces_'][_0x52f3c8],_0x1eb56b++);this['pieces_']['length']=_0x1eb56b,this['pieceNum_']=0x0;}else this['pieces_']=_0x3cecd5,this['pieceNum_']=_0x2db3b7;}['toString'](){let _0x281f5b='';for(let _0x130455=this['pieceNum_'];_0x130455<this['pieces_']['length'];_0x130455++)this['pieces_'][_0x130455]!==''&&(_0x281f5b+='/'+this['pieces_'][_0x130455]);return _0x281f5b||'/';}}function w(){return new C('');}function y(_0x267ebe){return _0x267ebe['pieceNum_']>=_0x267ebe['pieces_']['length']?null:_0x267ebe['pieces_'][_0x267ebe['pieceNum_']];}function Ce(_0x1c863a){return _0x1c863a['pieces_']['length']-_0x1c863a['pieceNum_'];}function S(_0x306ab0){let _0x3927f9=_0x306ab0['pieceNum_'];return _0x3927f9<_0x306ab0['pieces_']['length']&&_0x3927f9++,new C(_0x306ab0['pieces_'],_0x3927f9);}function ji(_0x45bf0b){return _0x45bf0b['pieceNum_']<_0x45bf0b['pieces_']['length']?_0x45bf0b['pieces_'][_0x45bf0b['pieces_']['length']-0x1]:null;}function bh(_0x17e530){let _0x604017='';for(let _0x544726=_0x17e530['pieceNum_'];_0x544726<_0x17e530['pieces_']['length'];_0x544726++)_0x17e530['pieces_'][_0x544726]!==''&&(_0x604017+='/'+encodeURIComponent(String(_0x17e530['pieces_'][_0x544726])));return _0x604017||'/';}function Mt(_0x1eedd7,_0x3b6c8f=0x0){return _0x1eedd7['pieces_']['slice'](_0x1eedd7['pieceNum_']+_0x3b6c8f);}function Ro(_0x2c9106){if(_0x2c9106['pieceNum_']>=_0x2c9106['pieces_']['length'])return null;const _0x22878=[];for(let _0x56705e=_0x2c9106['pieceNum_'];_0x56705e<_0x2c9106['pieces_']['length']-0x1;_0x56705e++)_0x22878['push'](_0x2c9106['pieces_'][_0x56705e]);return new C(_0x22878,0x0);}function k(_0x101867,_0x13cacc){const _0x355931=[];for(let _0x4c4a1b=_0x101867['pieceNum_'];_0x4c4a1b<_0x101867['pieces_']['length'];_0x4c4a1b++)_0x355931['push'](_0x101867['pieces_'][_0x4c4a1b]);if(_0x13cacc instanceof C){for(let _0x824a07=_0x13cacc['pieceNum_'];_0x824a07<_0x13cacc['pieces_']['length'];_0x824a07++)_0x355931['push'](_0x13cacc['pieces_'][_0x824a07]);}else{const _0x233e0d=_0x13cacc['split']('/');for(let _0x55ad95=0x0;_0x55ad95<_0x233e0d['length'];_0x55ad95++)_0x233e0d[_0x55ad95]['length']>0x0&&_0x355931['push'](_0x233e0d[_0x55ad95]);}return new C(_0x355931,0x0);}function v(_0x4107d6){return _0x4107d6['pieceNum_']>=_0x4107d6['pieces_']['length'];}function F(_0x3b7975,_0x57e2e8){const _0x4bc0e7=y(_0x3b7975),_0x1f63c9=y(_0x57e2e8);if(_0x4bc0e7===null)return _0x57e2e8;if(_0x4bc0e7===_0x1f63c9)return F(S(_0x3b7975),S(_0x57e2e8));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x57e2e8+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3b7975+')');}function Rh(_0x22c31b,_0x4ce776){const _0xde8c69=Mt(_0x22c31b,0x0),_0x459874=Mt(_0x4ce776,0x0);for(let _0x542bc5=0x0;_0x542bc5<_0xde8c69['length']&&_0x542bc5<_0x459874['length'];_0x542bc5++){const _0x350263=qe(_0xde8c69[_0x542bc5],_0x459874[_0x542bc5]);if(_0x350263!==0x0)return _0x350263;}return _0xde8c69['length']===_0x459874['length']?0x0:_0xde8c69['length']<_0x459874['length']?-0x1:0x1;}function Ki(_0x350295,_0xb18171){if(Ce(_0x350295)!==Ce(_0xb18171))return!0x1;for(let _0x41628c=_0x350295['pieceNum_'],_0x5649bc=_0xb18171['pieceNum_'];_0x41628c<=_0x350295['pieces_']['length'];_0x41628c++,_0x5649bc++)if(_0x350295['pieces_'][_0x41628c]!==_0xb18171['pieces_'][_0x5649bc])return!0x1;return!0x0;}function G(_0x3fe774,_0x4748cc){let _0x14791d=_0x3fe774['pieceNum_'],_0x2b2635=_0x4748cc['pieceNum_'];if(Ce(_0x3fe774)>Ce(_0x4748cc))return!0x1;for(;_0x14791d<_0x3fe774['pieces_']['length'];){if(_0x3fe774['pieces_'][_0x14791d]!==_0x4748cc['pieces_'][_0x2b2635])return!0x1;++_0x14791d,++_0x2b2635;}return!0x0;}class Ah{constructor(_0x173dd8,_0x21453d){this['errorPrefix_']=_0x21453d,this['parts_']=Mt(_0x173dd8,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x19028d=0x0;_0x19028d<this['parts_']['length'];_0x19028d++)this['byteLength_']+=Ln(this['parts_'][_0x19028d]);Ao(this);}}function kh(_0x1fb461,_0x162376){_0x1fb461['parts_']['length']>0x0&&(_0x1fb461['byteLength_']+=0x1),_0x1fb461['parts_']['push'](_0x162376),_0x1fb461['byteLength_']+=Ln(_0x162376),Ao(_0x1fb461);}function Ph(_0x440160){const _0x223279=_0x440160['parts_']['pop']();_0x440160['byteLength_']-=Ln(_0x223279),_0x440160['parts_']['length']>0x0&&(_0x440160['byteLength_']-=0x1);}function Ao(_0x46dc24){if(_0x46dc24['byteLength_']>Zs)throw new Error(_0x46dc24['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x46dc24['byteLength_']+').');if(_0x46dc24['parts_']['length']>Xs)throw new Error(_0x46dc24['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x46dc24));}function Oe(_0x196340){return _0x196340['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x196340['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x44423a,_0x2639f6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2639f6='visibilitychange',_0x44423a='hidden'):typeof document['mozHidden']<'u'?(_0x2639f6='mozvisibilitychange',_0x44423a='mozHidden'):typeof document['msHidden']<'u'?(_0x2639f6='msvisibilitychange',_0x44423a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2639f6='webkitvisibilitychange',_0x44423a='webkitHidden')),this['visible_']=!0x0,_0x2639f6&&document['addEventListener'](_0x2639f6,()=>{const _0x476f4f=!document[_0x44423a];_0x476f4f!==this['visible_']&&(this['visible_']=_0x476f4f,this['trigger']('visible',_0x476f4f));},!0x1);}['getInitialEvent'](_0x4f71b8){return f(_0x4f71b8==='visible','Unknown\x20event\x20type:\x20'+_0x4f71b8),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x1cb834,_0x535101,_0x5f23ff,_0x11546b,_0x29d6b9,_0x31b2a6,_0x10dc29,_0xa6fd70){if(super(),this['repoInfo_']=_0x1cb834,this['applicationId_']=_0x535101,this['onDataUpdate_']=_0x5f23ff,this['onConnectStatus_']=_0x11546b,this['onServerInfoUpdate_']=_0x29d6b9,this['authTokenProvider_']=_0x31b2a6,this['appCheckTokenProvider_']=_0x10dc29,this['authOverride_']=_0xa6fd70,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xa6fd70)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1cb834['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x537188,_0x7189d4,_0x32dc3f){const _0x41a0b9=++this['requestNumber_'],_0x4eca12={'r':_0x41a0b9,'a':_0x537188,'b':_0x7189d4};this['log_'](O(_0x4eca12)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4eca12),_0x32dc3f&&(this['requestCBHash_'][_0x41a0b9]=_0x32dc3f);}['get'](_0x1d69dd){this['initConnection_']();const _0x18dcb2=new H(),_0x2e89a0={'action':'g','request':{'p':_0x1d69dd['_path']['toString'](),'q':_0x1d69dd['_queryObject']},'onComplete':_0x1ac27e=>{const _0x4471b9=_0x1ac27e['d'];_0x1ac27e['s']==='ok'?_0x18dcb2['resolve'](_0x4471b9):_0x18dcb2['reject'](_0x4471b9);}};this['outstandingGets_']['push'](_0x2e89a0),this['outstandingGetCount_']++;const _0x55e7fe=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x55e7fe),_0x18dcb2['promise'];}['listen'](_0x2aa539,_0x4ad507,_0x42f712,_0x572d94){this['initConnection_']();const _0x5c1425=_0x2aa539['_queryIdentifier'],_0x4ce753=_0x2aa539['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4ce753+'\x20'+_0x5c1425),this['listens']['has'](_0x4ce753)||this['listens']['set'](_0x4ce753,new Map()),f(_0x2aa539['_queryParams']['isDefault']()||!_0x2aa539['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4ce753)['has'](_0x5c1425),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x454eac={'onComplete':_0x572d94,'hashFn':_0x4ad507,'query':_0x2aa539,'tag':_0x42f712};this['listens']['get'](_0x4ce753)['set'](_0x5c1425,_0x454eac),this['connected_']&&this['sendListen_'](_0x454eac);}['sendGet_'](_0x505ea6){const _0x387bfa=this['outstandingGets_'][_0x505ea6];this['sendRequest']('g',_0x387bfa['request'],_0x56b4b5=>{delete this['outstandingGets_'][_0x505ea6],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x387bfa['onComplete']&&_0x387bfa['onComplete'](_0x56b4b5);});}['sendListen_'](_0x2cf478){const _0x7de72c=_0x2cf478['query'],_0x4d65c5=_0x7de72c['_path']['toString'](),_0x36514f=_0x7de72c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4d65c5+'\x20for\x20'+_0x36514f);const _0x251a7d={'p':_0x4d65c5},_0x2c51fe='q';_0x2cf478['tag']&&(_0x251a7d['q']=_0x7de72c['_queryObject'],_0x251a7d['t']=_0x2cf478['tag']),_0x251a7d['h']=_0x2cf478['hashFn'](),this['sendRequest'](_0x2c51fe,_0x251a7d,_0xaa58cf=>{const _0x22644f=_0xaa58cf['d'],_0xaa0269=_0xaa58cf['s'];se['warnOnListenWarnings_'](_0x22644f,_0x7de72c),(this['listens']['get'](_0x4d65c5)&&this['listens']['get'](_0x4d65c5)['get'](_0x36514f))===_0x2cf478&&(this['log_']('listen\x20response',_0xaa58cf),_0xaa0269!=='ok'&&this['removeListen_'](_0x4d65c5,_0x36514f),_0x2cf478['onComplete']&&_0x2cf478['onComplete'](_0xaa0269,_0x22644f));});}static['warnOnListenWarnings_'](_0x14e0fa,_0x1d4181){if(_0x14e0fa&&typeof _0x14e0fa=='object'&&Q(_0x14e0fa,'w')){const _0x323208=Le(_0x14e0fa,'w');if(Array['isArray'](_0x323208)&&~_0x323208['indexOf']('no_index')){const _0x3f9d3b='\x22.indexOn\x22:\x20\x22'+_0x1d4181['_queryParams']['getIndex']()['toString']()+'\x22',_0x5da288=_0x1d4181['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3f9d3b+'\x20at\x20'+_0x5da288+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x45aae5){this['authToken_']=_0x45aae5,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x45aae5);}['reduceReconnectDelayIfAdminCredential_'](_0x39ab6e){(_0x39ab6e&&_0x39ab6e['length']===0x28||wc(_0x39ab6e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x431a0f){this['appCheckToken_']=_0x431a0f,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xa577b=this['authToken_'],_0x1f34b4=Ic(_0xa577b)?'auth':'gauth',_0x44dd67={'cred':_0xa577b};this['authOverride_']===null?_0x44dd67['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x44dd67['authvar']=this['authOverride_']),this['sendRequest'](_0x1f34b4,_0x44dd67,_0x274b57=>{const _0x570934=_0x274b57['s'],_0xb94b26=_0x274b57['d']||'error';this['authToken_']===_0xa577b&&(_0x570934==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x570934,_0xb94b26));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1d579e=>{const _0x1073f6=_0x1d579e['s'],_0x3bbb2f=_0x1d579e['d']||'error';_0x1073f6==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1073f6,_0x3bbb2f);});}['unlisten'](_0x3fa84d,_0x36615b){const _0x2f0ee0=_0x3fa84d['_path']['toString'](),_0x370170=_0x3fa84d['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2f0ee0+'\x20'+_0x370170),f(_0x3fa84d['_queryParams']['isDefault']()||!_0x3fa84d['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2f0ee0,_0x370170)&&this['connected_']&&this['sendUnlisten_'](_0x2f0ee0,_0x370170,_0x3fa84d['_queryObject'],_0x36615b);}['sendUnlisten_'](_0x5db886,_0x5e3dbf,_0x3948a9,_0x1429ad){this['log_']('Unlisten\x20on\x20'+_0x5db886+'\x20for\x20'+_0x5e3dbf);const _0xe8504b={'p':_0x5db886},_0x1ed8d0='n';_0x1429ad&&(_0xe8504b['q']=_0x3948a9,_0xe8504b['t']=_0x1429ad),this['sendRequest'](_0x1ed8d0,_0xe8504b);}['onDisconnectPut'](_0x173147,_0x5ddf9d,_0x28e2e0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x173147,_0x5ddf9d,_0x28e2e0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x173147,'action':'o','data':_0x5ddf9d,'onComplete':_0x28e2e0});}['onDisconnectMerge'](_0x21ac32,_0xe8ec93,_0xab1df2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x21ac32,_0xe8ec93,_0xab1df2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x21ac32,'action':'om','data':_0xe8ec93,'onComplete':_0xab1df2});}['onDisconnectCancel'](_0x36f80f,_0x4c89af){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x36f80f,null,_0x4c89af):this['onDisconnectRequestQueue_']['push']({'pathString':_0x36f80f,'action':'oc','data':null,'onComplete':_0x4c89af});}['sendOnDisconnect_'](_0x119823,_0x45c425,_0x2e63c9,_0x2ed1dd){const _0x4b6486={'p':_0x45c425,'d':_0x2e63c9};this['log_']('onDisconnect\x20'+_0x119823,_0x4b6486),this['sendRequest'](_0x119823,_0x4b6486,_0x485e76=>{_0x2ed1dd&&setTimeout(()=>{_0x2ed1dd(_0x485e76['s'],_0x485e76['d']);},Math['floor'](0x0));});}['put'](_0x8fae9c,_0x212277,_0x22c38b,_0x272edf){this['putInternal']('p',_0x8fae9c,_0x212277,_0x22c38b,_0x272edf);}['merge'](_0x349060,_0x25e3dd,_0x115da7,_0x3f4746){this['putInternal']('m',_0x349060,_0x25e3dd,_0x115da7,_0x3f4746);}['putInternal'](_0xc1a442,_0x82a6d7,_0x33d589,_0x59e013,_0x599ce3){this['initConnection_']();const _0x358bc5={'p':_0x82a6d7,'d':_0x33d589};_0x599ce3!==void 0x0&&(_0x358bc5['h']=_0x599ce3),this['outstandingPuts_']['push']({'action':_0xc1a442,'request':_0x358bc5,'onComplete':_0x59e013}),this['outstandingPutCount_']++;const _0x4cb355=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4cb355):this['log_']('Buffering\x20put:\x20'+_0x82a6d7);}['sendPut_'](_0x4238a5){const _0x16dc70=this['outstandingPuts_'][_0x4238a5]['action'],_0x607c53=this['outstandingPuts_'][_0x4238a5]['request'],_0x2bd279=this['outstandingPuts_'][_0x4238a5]['onComplete'];this['outstandingPuts_'][_0x4238a5]['queued']=this['connected_'],this['sendRequest'](_0x16dc70,_0x607c53,_0x4b81cc=>{this['log_'](_0x16dc70+'\x20response',_0x4b81cc),delete this['outstandingPuts_'][_0x4238a5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2bd279&&_0x2bd279(_0x4b81cc['s'],_0x4b81cc['d']);});}['reportStats'](_0x3895c1){if(this['connected_']){const _0xa35eb8={'c':_0x3895c1};this['log_']('reportStats',_0xa35eb8),this['sendRequest']('s',_0xa35eb8,_0x2e3613=>{if(_0x2e3613['s']!=='ok'){const _0x287d21=_0x2e3613['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x287d21);}});}}['onDataMessage_'](_0x140268){if('r'in _0x140268){this['log_']('from\x20server:\x20'+O(_0x140268));const _0x4bc558=_0x140268['r'],_0x5a8598=this['requestCBHash_'][_0x4bc558];_0x5a8598&&(delete this['requestCBHash_'][_0x4bc558],_0x5a8598(_0x140268['b']));}else{if('error'in _0x140268)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x140268['error'];'a'in _0x140268&&this['onDataPush_'](_0x140268['a'],_0x140268['b']);}}['onDataPush_'](_0x3ef0d7,_0x3b14e2){this['log_']('handleServerMessage',_0x3ef0d7,_0x3b14e2),_0x3ef0d7==='d'?this['onDataUpdate_'](_0x3b14e2['p'],_0x3b14e2['d'],!0x1,_0x3b14e2['t']):_0x3ef0d7==='m'?this['onDataUpdate_'](_0x3b14e2['p'],_0x3b14e2['d'],!0x0,_0x3b14e2['t']):_0x3ef0d7==='c'?this['onListenRevoked_'](_0x3b14e2['p'],_0x3b14e2['q']):_0x3ef0d7==='ac'?this['onAuthRevoked_'](_0x3b14e2['s'],_0x3b14e2['d']):_0x3ef0d7==='apc'?this['onAppCheckRevoked_'](_0x3b14e2['s'],_0x3b14e2['d']):_0x3ef0d7==='sd'?this['onSecurityDebugPacket_'](_0x3b14e2):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3ef0d7)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x341e1a,_0x5c2ec8){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x341e1a),this['lastSessionId']=_0x5c2ec8,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2b2f0b){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2b2f0b));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x22ff59){_0x22ff59&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x22ff59;}['onOnline_'](_0x54ae85){_0x54ae85?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x10385c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xbaa271=Math['max'](0x0,this['reconnectDelay_']-_0x10385c);_0xbaa271=Math['random']()*_0xbaa271,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xbaa271+'ms'),this['scheduleConnect_'](_0xbaa271),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x402416=this['onDataMessage_']['bind'](this),_0x3ef854=this['onReady_']['bind'](this),_0x54f250=this['onRealtimeDisconnect_']['bind'](this),_0x10b375=this['id']+':'+se['nextConnectionId_']++,_0x2e2897=this['lastSessionId'];let _0x2ec019=!0x1,_0x4e58c9=null;const _0x35afd9=function(){_0x4e58c9?_0x4e58c9['close']():(_0x2ec019=!0x0,_0x54f250());},_0x4c8dd9=function(_0x59c4b4){f(_0x4e58c9,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4e58c9['sendRequest'](_0x59c4b4);};this['realtime_']={'close':_0x35afd9,'sendRequest':_0x4c8dd9};const _0x4e890a=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5d852b,_0xae0024]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4e890a),this['appCheckTokenProvider_']['getToken'](_0x4e890a)]);_0x2ec019?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5d852b&&_0x5d852b['accessToken'],this['appCheckToken_']=_0xae0024&&_0xae0024['token'],_0x4e58c9=new Sh(_0x10b375,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x402416,_0x3ef854,_0x54f250,_0x2c5c6e=>{U(_0x2c5c6e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2e2897));}catch(_0x2cd1d0){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2cd1d0),_0x2ec019||(this['repoInfo_']['nodeAdmin']&&U(_0x2cd1d0),_0x35afd9());}}}['interrupt'](_0xfea8){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xfea8),this['interruptReasons_'][_0xfea8]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5040d9){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5040d9),delete this['interruptReasons_'][_0x5040d9],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x484906){const _0x185255=_0x484906-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x185255});}['cancelSentTransactions_'](){for(let _0x1bd256=0x0;_0x1bd256<this['outstandingPuts_']['length'];_0x1bd256++){const _0x50cd5c=this['outstandingPuts_'][_0x1bd256];_0x50cd5c&&'h'in _0x50cd5c['request']&&_0x50cd5c['queued']&&(_0x50cd5c['onComplete']&&_0x50cd5c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1bd256],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x320fe5,_0x5e9c3c){let _0x4b4f99;_0x5e9c3c?_0x4b4f99=_0x5e9c3c['map'](_0x749287=>$i(_0x749287))['join']('$'):_0x4b4f99='default';const _0x2615dc=this['removeListen_'](_0x320fe5,_0x4b4f99);_0x2615dc&&_0x2615dc['onComplete']&&_0x2615dc['onComplete']('permission_denied');}['removeListen_'](_0x5f0100,_0x455f78){const _0xf5d7cb=new C(_0x5f0100)['toString']();let _0x410819;if(this['listens']['has'](_0xf5d7cb)){const _0x63ae9c=this['listens']['get'](_0xf5d7cb);_0x410819=_0x63ae9c['get'](_0x455f78),_0x63ae9c['delete'](_0x455f78),_0x63ae9c['size']===0x0&&this['listens']['delete'](_0xf5d7cb);}else _0x410819=void 0x0;return _0x410819;}['onAuthRevoked_'](_0x1eed79,_0x4f7ec1){L('Auth\x20token\x20revoked:\x20'+_0x1eed79+'/'+_0x4f7ec1),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1eed79==='invalid_token'||_0x1eed79==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2f0193,_0x3e3e0b){L('App\x20check\x20token\x20revoked:\x20'+_0x2f0193+'/'+_0x3e3e0b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2f0193==='invalid_token'||_0x2f0193==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x43878e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x43878e):'msg'in _0x43878e&&console['log']('FIREBASE:\x20'+_0x43878e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x35c894 of this['listens']['values']())for(const _0x59d278 of _0x35c894['values']())this['sendListen_'](_0x59d278);for(let _0xfad769=0x0;_0xfad769<this['outstandingPuts_']['length'];_0xfad769++)this['outstandingPuts_'][_0xfad769]&&this['sendPut_'](_0xfad769);for(;this['onDisconnectRequestQueue_']['length'];){const _0x10f5e3=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x10f5e3['action'],_0x10f5e3['pathString'],_0x10f5e3['data'],_0x10f5e3['onComplete']);}for(let _0x2771b4=0x0;_0x2771b4<this['outstandingGets_']['length'];_0x2771b4++)this['outstandingGets_'][_0x2771b4]&&this['sendGet_'](_0x2771b4);}['sendConnectStats_'](){const _0x4c910f={};let _0x2ad31b='js';_0x4c910f['sdk.'+_0x2ad31b+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x4c910f['framework.cordova']=0x1:Kr()&&(_0x4c910f['framework.reactnative']=0x1),this['reportStats'](_0x4c910f);}['shouldReconnect_'](){const _0x10eaaa=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x10eaaa;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x51d1f7,_0x2e56ee){this['name']=_0x51d1f7,this['node']=_0x2e56ee;}static['Wrap'](_0x3edd8f,_0x3c49c8){return new E(_0x3edd8f,_0x3c49c8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xfc09bd,_0x251611){const _0xa17e88=new E(We,_0xfc09bd),_0xbf0c10=new E(We,_0x251611);return this['compare'](_0xa17e88,_0xbf0c10)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x26675b){sn=_0x26675b;}['compare'](_0x2ddf1d,_0x52a39){return qe(_0x2ddf1d['name'],_0x52a39['name']);}['isDefinedOn'](_0x4671b8){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x473a6c,_0x4a878c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x40d28e,_0x4471a3){return f(typeof _0x40d28e=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x40d28e,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x523c6c,_0x2ef305,_0x1b95b0,_0x58e752,_0x12f61a=null){this['isReverse_']=_0x58e752,this['resultGenerator_']=_0x12f61a,this['nodeStack_']=[];let _0x58aaec=0x1;for(;!_0x523c6c['isEmpty']();)if(_0x523c6c=_0x523c6c,_0x58aaec=_0x2ef305?_0x1b95b0(_0x523c6c['key'],_0x2ef305):0x1,_0x58e752&&(_0x58aaec*=-0x1),_0x58aaec<0x0)this['isReverse_']?_0x523c6c=_0x523c6c['left']:_0x523c6c=_0x523c6c['right'];else{if(_0x58aaec===0x0){this['nodeStack_']['push'](_0x523c6c);break;}else this['nodeStack_']['push'](_0x523c6c),this['isReverse_']?_0x523c6c=_0x523c6c['right']:_0x523c6c=_0x523c6c['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x313528=this['nodeStack_']['pop'](),_0x1459a6;if(this['resultGenerator_']?_0x1459a6=this['resultGenerator_'](_0x313528['key'],_0x313528['value']):_0x1459a6={'key':_0x313528['key'],'value':_0x313528['value']},this['isReverse_']){for(_0x313528=_0x313528['left'];!_0x313528['isEmpty']();)this['nodeStack_']['push'](_0x313528),_0x313528=_0x313528['right'];}else{for(_0x313528=_0x313528['right'];!_0x313528['isEmpty']();)this['nodeStack_']['push'](_0x313528),_0x313528=_0x313528['left'];}return _0x1459a6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x429106=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x429106['key'],_0x429106['value']):{'key':_0x429106['key'],'value':_0x429106['value']};}}class M{constructor(_0x508ed6,_0x5416a6,_0x15cd4c,_0x374900,_0x790aad){this['key']=_0x508ed6,this['value']=_0x5416a6,this['color']=_0x15cd4c??M['RED'],this['left']=_0x374900??B['EMPTY_NODE'],this['right']=_0x790aad??B['EMPTY_NODE'];}['copy'](_0x9330a3,_0x1b419b,_0xdf7ca2,_0x5b6048,_0x8a5d93){return new M(_0x9330a3??this['key'],_0x1b419b??this['value'],_0xdf7ca2??this['color'],_0x5b6048??this['left'],_0x8a5d93??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x584359){return this['left']['inorderTraversal'](_0x584359)||!!_0x584359(this['key'],this['value'])||this['right']['inorderTraversal'](_0x584359);}['reverseTraversal'](_0x483f76){return this['right']['reverseTraversal'](_0x483f76)||_0x483f76(this['key'],this['value'])||this['left']['reverseTraversal'](_0x483f76);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x90d576,_0x57ba60,_0xd1e419){let _0x517f88=this;const _0x56d433=_0xd1e419(_0x90d576,_0x517f88['key']);return _0x56d433<0x0?_0x517f88=_0x517f88['copy'](null,null,null,_0x517f88['left']['insert'](_0x90d576,_0x57ba60,_0xd1e419),null):_0x56d433===0x0?_0x517f88=_0x517f88['copy'](null,_0x57ba60,null,null,null):_0x517f88=_0x517f88['copy'](null,null,null,null,_0x517f88['right']['insert'](_0x90d576,_0x57ba60,_0xd1e419)),_0x517f88['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4f8074=this;return!_0x4f8074['left']['isRed_']()&&!_0x4f8074['left']['left']['isRed_']()&&(_0x4f8074=_0x4f8074['moveRedLeft_']()),_0x4f8074=_0x4f8074['copy'](null,null,null,_0x4f8074['left']['removeMin_'](),null),_0x4f8074['fixUp_']();}['remove'](_0x58a4c3,_0x30b6a0){let _0x2a4e80,_0x5af521;if(_0x2a4e80=this,_0x30b6a0(_0x58a4c3,_0x2a4e80['key'])<0x0)!_0x2a4e80['left']['isEmpty']()&&!_0x2a4e80['left']['isRed_']()&&!_0x2a4e80['left']['left']['isRed_']()&&(_0x2a4e80=_0x2a4e80['moveRedLeft_']()),_0x2a4e80=_0x2a4e80['copy'](null,null,null,_0x2a4e80['left']['remove'](_0x58a4c3,_0x30b6a0),null);else{if(_0x2a4e80['left']['isRed_']()&&(_0x2a4e80=_0x2a4e80['rotateRight_']()),!_0x2a4e80['right']['isEmpty']()&&!_0x2a4e80['right']['isRed_']()&&!_0x2a4e80['right']['left']['isRed_']()&&(_0x2a4e80=_0x2a4e80['moveRedRight_']()),_0x30b6a0(_0x58a4c3,_0x2a4e80['key'])===0x0){if(_0x2a4e80['right']['isEmpty']())return B['EMPTY_NODE'];_0x5af521=_0x2a4e80['right']['min_'](),_0x2a4e80=_0x2a4e80['copy'](_0x5af521['key'],_0x5af521['value'],null,null,_0x2a4e80['right']['removeMin_']());}_0x2a4e80=_0x2a4e80['copy'](null,null,null,null,_0x2a4e80['right']['remove'](_0x58a4c3,_0x30b6a0));}return _0x2a4e80['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3f3c74=this;return _0x3f3c74['right']['isRed_']()&&!_0x3f3c74['left']['isRed_']()&&(_0x3f3c74=_0x3f3c74['rotateLeft_']()),_0x3f3c74['left']['isRed_']()&&_0x3f3c74['left']['left']['isRed_']()&&(_0x3f3c74=_0x3f3c74['rotateRight_']()),_0x3f3c74['left']['isRed_']()&&_0x3f3c74['right']['isRed_']()&&(_0x3f3c74=_0x3f3c74['colorFlip_']()),_0x3f3c74;}['moveRedLeft_'](){let _0xc5f91b=this['colorFlip_']();return _0xc5f91b['right']['left']['isRed_']()&&(_0xc5f91b=_0xc5f91b['copy'](null,null,null,null,_0xc5f91b['right']['rotateRight_']()),_0xc5f91b=_0xc5f91b['rotateLeft_'](),_0xc5f91b=_0xc5f91b['colorFlip_']()),_0xc5f91b;}['moveRedRight_'](){let _0x299c7f=this['colorFlip_']();return _0x299c7f['left']['left']['isRed_']()&&(_0x299c7f=_0x299c7f['rotateRight_'](),_0x299c7f=_0x299c7f['colorFlip_']()),_0x299c7f;}['rotateLeft_'](){const _0x1d7b79=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1d7b79,null);}['rotateRight_'](){const _0x4b3405=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4b3405);}['colorFlip_'](){const _0x10d1df=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5da21f=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x10d1df,_0x5da21f);}['checkMaxDepth_'](){const _0x59b6a0=this['check_']();return Math['pow'](0x2,_0x59b6a0)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x204d61=this['left']['check_']();if(_0x204d61!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x204d61+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x472677,_0x513509,_0x1c93fd,_0x3889f6,_0x331a04){return this;}['insert'](_0xa09e35,_0x5a25f6,_0x18708e){return new M(_0xa09e35,_0x5a25f6,null);}['remove'](_0x1826cc,_0x37c715){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2149f0){return!0x1;}['reverseTraversal'](_0x4483ca){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x42c1f0,_0x1d25ce=B['EMPTY_NODE']){this['comparator_']=_0x42c1f0,this['root_']=_0x1d25ce;}['insert'](_0x4c8b83,_0xf449ce){return new B(this['comparator_'],this['root_']['insert'](_0x4c8b83,_0xf449ce,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x534354){return new B(this['comparator_'],this['root_']['remove'](_0x534354,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4a5ae8){let _0x17bdc4,_0xe91d21=this['root_'];for(;!_0xe91d21['isEmpty']();){if(_0x17bdc4=this['comparator_'](_0x4a5ae8,_0xe91d21['key']),_0x17bdc4===0x0)return _0xe91d21['value'];_0x17bdc4<0x0?_0xe91d21=_0xe91d21['left']:_0x17bdc4>0x0&&(_0xe91d21=_0xe91d21['right']);}return null;}['getPredecessorKey'](_0x15b4c7){let _0x74b1f4,_0x1c6869=this['root_'],_0x560f24=null;for(;!_0x1c6869['isEmpty']();)if(_0x74b1f4=this['comparator_'](_0x15b4c7,_0x1c6869['key']),_0x74b1f4===0x0){if(_0x1c6869['left']['isEmpty']())return _0x560f24?_0x560f24['key']:null;for(_0x1c6869=_0x1c6869['left'];!_0x1c6869['right']['isEmpty']();)_0x1c6869=_0x1c6869['right'];return _0x1c6869['key'];}else _0x74b1f4<0x0?_0x1c6869=_0x1c6869['left']:_0x74b1f4>0x0&&(_0x560f24=_0x1c6869,_0x1c6869=_0x1c6869['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x181b40){return this['root_']['inorderTraversal'](_0x181b40);}['reverseTraversal'](_0x33607d){return this['root_']['reverseTraversal'](_0x33607d);}['getIterator'](_0x124dbe){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x124dbe);}['getIteratorFrom'](_0x46f84a,_0xa0d1f4){return new rn(this['root_'],_0x46f84a,this['comparator_'],!0x1,_0xa0d1f4);}['getReverseIteratorFrom'](_0x130d65,_0x548375){return new rn(this['root_'],_0x130d65,this['comparator_'],!0x0,_0x548375);}['getReverseIterator'](_0x196c68){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x196c68);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x4792b8,_0x44757d){return qe(_0x4792b8['name'],_0x44757d['name']);}function Qi(_0x3aa9a5,_0x3b2af2){return qe(_0x3aa9a5,_0x3b2af2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x90ae5c){Ci=_0x90ae5c;}const Po=function(_0x1cca9c){return typeof _0x1cca9c=='number'?'number:'+ao(_0x1cca9c):'string:'+_0x1cca9c;},No=function(_0x59e125){if(_0x59e125['isLeafNode']()){const _0x27444d=_0x59e125['val']();f(typeof _0x27444d=='string'||typeof _0x27444d=='number'||typeof _0x27444d=='object'&&Q(_0x27444d,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x59e125===Ci||_0x59e125['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x59e125===Ci||_0x59e125['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x59e26a){nr=_0x59e26a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x610528,_0x4bd8e2=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x610528,this['priorityNode_']=_0x4bd8e2,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x541093){return new D(this['value_'],_0x541093);}['getImmediateChild'](_0x8d8a75){return _0x8d8a75==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3ef44c){return v(_0x3ef44c)?this:y(_0x3ef44c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3b29ab,_0x5b0010){return null;}['updateImmediateChild'](_0x5747bd,_0x585239){return _0x5747bd==='.priority'?this['updatePriority'](_0x585239):_0x585239['isEmpty']()&&_0x5747bd!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5747bd,_0x585239)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x175f1d,_0x281146){const _0x22d697=y(_0x175f1d);return _0x22d697===null?_0x281146:_0x281146['isEmpty']()&&_0x22d697!=='.priority'?this:(f(_0x22d697!=='.priority'||Ce(_0x175f1d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x22d697,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x175f1d),_0x281146)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4d95c9,_0x3e65ce){return!0x1;}['val'](_0x32be41){return _0x32be41&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x322d51='';this['priorityNode_']['isEmpty']()||(_0x322d51+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1c82ad=typeof this['value_'];_0x322d51+=_0x1c82ad+':',_0x1c82ad==='number'?_0x322d51+=ao(this['value_']):_0x322d51+=this['value_'],this['lazyHash_']=ro(_0x322d51);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x55e5d6){return _0x55e5d6===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x55e5d6 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x55e5d6['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x55e5d6));}['compareToLeafNode_'](_0x1e0043){const _0x43ebf6=typeof _0x1e0043['value_'],_0x7806f5=typeof this['value_'],_0x1ee061=D['VALUE_TYPE_ORDER']['indexOf'](_0x43ebf6),_0x50c730=D['VALUE_TYPE_ORDER']['indexOf'](_0x7806f5);return f(_0x1ee061>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x43ebf6),f(_0x50c730>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x7806f5),_0x1ee061===_0x50c730?_0x7806f5==='object'?0x0:this['value_']<_0x1e0043['value_']?-0x1:this['value_']===_0x1e0043['value_']?0x0:0x1:_0x50c730-_0x1ee061;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x15ba78){if(_0x15ba78===this)return!0x0;if(_0x15ba78['isLeafNode']()){const _0x4a598d=_0x15ba78;return this['value_']===_0x4a598d['value_']&&this['priorityNode_']['equals'](_0x4a598d['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3465d5){Oo=_0x3465d5;}function Wh(_0x28e219){Do=_0x28e219;}class Bh extends Fn{['compare'](_0x2ec3c7,_0x4009bf){const _0x13214b=_0x2ec3c7['node']['getPriority'](),_0x52fc99=_0x4009bf['node']['getPriority'](),_0x1dd1d7=_0x13214b['compareTo'](_0x52fc99);return _0x1dd1d7===0x0?qe(_0x2ec3c7['name'],_0x4009bf['name']):_0x1dd1d7;}['isDefinedOn'](_0x36d0ec){return!_0x36d0ec['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x439a66,_0x4d400b){return!_0x439a66['getPriority']()['equals'](_0x4d400b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x1fc5bb,_0x23f22a){const _0x2847b6=Oo(_0x1fc5bb);return new E(_0x23f22a,new D('[PRIORITY-POST]',_0x2847b6));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x514936){const _0x1a2fe0=_0x25864f=>parseInt(Math['log'](_0x25864f)/Vh,0xa),_0x4b98bf=_0xc92e9d=>parseInt(Array(_0xc92e9d+0x1)['join']('1'),0x2);this['count']=_0x1a2fe0(_0x514936+0x1),this['current_']=this['count']-0x1;const _0x5ad06b=_0x4b98bf(this['count']);this['bits_']=_0x514936+0x1&_0x5ad06b;}['nextBitIsOne'](){const _0x58d674=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x58d674;}}const yn=function(_0x325f5d,_0x439a59,_0x38149f,_0x3c07af){_0x325f5d['sort'](_0x439a59);const _0x164a8d=function(_0xe5a1eb,_0x56b12e){const _0x48973a=_0x56b12e-_0xe5a1eb;let _0x1f1e10,_0x1f421d;if(_0x48973a===0x0)return null;if(_0x48973a===0x1)return _0x1f1e10=_0x325f5d[_0xe5a1eb],_0x1f421d=_0x38149f?_0x38149f(_0x1f1e10):_0x1f1e10,new M(_0x1f421d,_0x1f1e10['node'],M['BLACK'],null,null);{const _0x39225a=parseInt(_0x48973a/0x2,0xa)+_0xe5a1eb,_0x450918=_0x164a8d(_0xe5a1eb,_0x39225a),_0x394d7e=_0x164a8d(_0x39225a+0x1,_0x56b12e);return _0x1f1e10=_0x325f5d[_0x39225a],_0x1f421d=_0x38149f?_0x38149f(_0x1f1e10):_0x1f1e10,new M(_0x1f421d,_0x1f1e10['node'],M['BLACK'],_0x450918,_0x394d7e);}},_0x47923e=function(_0x46f682){let _0x5ce133=null,_0x3e45b5=null,_0x1cb903=_0x325f5d['length'];const _0x45b5fb=function(_0x28bb12,_0x28373c){const _0x7bb9b4=_0x1cb903-_0x28bb12,_0x845133=_0x1cb903;_0x1cb903-=_0x28bb12;const _0x4d8e02=_0x164a8d(_0x7bb9b4+0x1,_0x845133),_0x1d3c20=_0x325f5d[_0x7bb9b4],_0x132046=_0x38149f?_0x38149f(_0x1d3c20):_0x1d3c20;_0x40d5c4(new M(_0x132046,_0x1d3c20['node'],_0x28373c,null,_0x4d8e02));},_0x40d5c4=function(_0x28620f){_0x5ce133?(_0x5ce133['left']=_0x28620f,_0x5ce133=_0x28620f):(_0x3e45b5=_0x28620f,_0x5ce133=_0x28620f);};for(let _0x50b8c1=0x0;_0x50b8c1<_0x46f682['count'];++_0x50b8c1){const _0x94e3e4=_0x46f682['nextBitIsOne'](),_0x559d71=Math['pow'](0x2,_0x46f682['count']-(_0x50b8c1+0x1));_0x94e3e4?_0x45b5fb(_0x559d71,M['BLACK']):(_0x45b5fb(_0x559d71,M['BLACK']),_0x45b5fb(_0x559d71,M['RED']));}return _0x3e45b5;},_0x2037bd=new Hh(_0x325f5d['length']),_0x8f8183=_0x47923e(_0x2037bd);return new B(_0x3c07af||_0x439a59,_0x8f8183);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4971b8,_0x2ed158){this['indexes_']=_0x4971b8,this['indexSet_']=_0x2ed158;}['get'](_0x5d9d3a){const _0x32c88b=Le(this['indexes_'],_0x5d9d3a);if(!_0x32c88b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5d9d3a);return _0x32c88b instanceof B?_0x32c88b:null;}['hasIndex'](_0xb839ef){return Q(this['indexSet_'],_0xb839ef['toString']());}['addIndex'](_0x295044,_0x32b500){f(_0x295044!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x572978=[];let _0x189de2=!0x1;const _0x46d687=_0x32b500['getIterator'](E['Wrap']);let _0x25a221=_0x46d687['getNext']();for(;_0x25a221;)_0x189de2=_0x189de2||_0x295044['isDefinedOn'](_0x25a221['node']),_0x572978['push'](_0x25a221),_0x25a221=_0x46d687['getNext']();let _0x4ba217;_0x189de2?_0x4ba217=yn(_0x572978,_0x295044['getCompare']()):_0x4ba217=Qe;const _0x55bfc3=_0x295044['toString'](),_0x5da006={...this['indexSet_']};_0x5da006[_0x55bfc3]=_0x295044;const _0x247876={...this['indexes_']};return _0x247876[_0x55bfc3]=_0x4ba217,new te(_0x247876,_0x5da006);}['addToIndexes'](_0x4dc98a,_0x9c8033){const _0x275fb9=_n(this['indexes_'],(_0x20ebbc,_0x50ff15)=>{const _0x4ee7f0=Le(this['indexSet_'],_0x50ff15);if(f(_0x4ee7f0,'Missing\x20index\x20implementation\x20for\x20'+_0x50ff15),_0x20ebbc===Qe){if(_0x4ee7f0['isDefinedOn'](_0x4dc98a['node'])){const _0x35f174=[],_0x3e562f=_0x9c8033['getIterator'](E['Wrap']);let _0x1fbdda=_0x3e562f['getNext']();for(;_0x1fbdda;)_0x1fbdda['name']!==_0x4dc98a['name']&&_0x35f174['push'](_0x1fbdda),_0x1fbdda=_0x3e562f['getNext']();return _0x35f174['push'](_0x4dc98a),yn(_0x35f174,_0x4ee7f0['getCompare']());}else return Qe;}else{const _0x311097=_0x9c8033['get'](_0x4dc98a['name']);let _0x4fc8a8=_0x20ebbc;return _0x311097&&(_0x4fc8a8=_0x4fc8a8['remove'](new E(_0x4dc98a['name'],_0x311097))),_0x4fc8a8['insert'](_0x4dc98a,_0x4dc98a['node']);}});return new te(_0x275fb9,this['indexSet_']);}['removeFromIndexes'](_0x182b03,_0x24c9fc){const _0x3f3f12=_n(this['indexes_'],_0x2d8502=>{if(_0x2d8502===Qe)return _0x2d8502;{const _0x30e84a=_0x24c9fc['get'](_0x182b03['name']);return _0x30e84a?_0x2d8502['remove'](new E(_0x182b03['name'],_0x30e84a)):_0x2d8502;}});return new te(_0x3f3f12,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x29e9b3,_0x4b164a,_0x52c626){this['children_']=_0x29e9b3,this['priorityNode_']=_0x4b164a,this['indexMap_']=_0x52c626,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x30ed57){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x30ed57,this['indexMap_']);}['getImmediateChild'](_0x4a44b9){if(_0x4a44b9==='.priority')return this['getPriority']();{const _0x3b28e4=this['children_']['get'](_0x4a44b9);return _0x3b28e4===null?It:_0x3b28e4;}}['getChild'](_0x1e9ce5){const _0x3ab01f=y(_0x1e9ce5);return _0x3ab01f===null?this:this['getImmediateChild'](_0x3ab01f)['getChild'](S(_0x1e9ce5));}['hasChild'](_0x192772){return this['children_']['get'](_0x192772)!==null;}['updateImmediateChild'](_0x4cee53,_0x175492){if(f(_0x175492,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4cee53==='.priority')return this['updatePriority'](_0x175492);{const _0x201295=new E(_0x4cee53,_0x175492);let _0x385392,_0x996d99;_0x175492['isEmpty']()?(_0x385392=this['children_']['remove'](_0x4cee53),_0x996d99=this['indexMap_']['removeFromIndexes'](_0x201295,this['children_'])):(_0x385392=this['children_']['insert'](_0x4cee53,_0x175492),_0x996d99=this['indexMap_']['addToIndexes'](_0x201295,this['children_']));const _0x5904a9=_0x385392['isEmpty']()?It:this['priorityNode_'];return new g(_0x385392,_0x5904a9,_0x996d99);}}['updateChild'](_0x4e859a,_0x2e85f6){const _0x2ea6da=y(_0x4e859a);if(_0x2ea6da===null)return _0x2e85f6;{f(y(_0x4e859a)!=='.priority'||Ce(_0x4e859a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x34fb9b=this['getImmediateChild'](_0x2ea6da)['updateChild'](S(_0x4e859a),_0x2e85f6);return this['updateImmediateChild'](_0x2ea6da,_0x34fb9b);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x29d157){if(this['isEmpty']())return null;const _0x24e3df={};let _0x5d4a5f=0x0,_0x3c27de=0x0,_0x5a3122=!0x0;if(this['forEachChild'](R,(_0x505fc8,_0x13da5e)=>{_0x24e3df[_0x505fc8]=_0x13da5e['val'](_0x29d157),_0x5d4a5f++,_0x5a3122&&g['INTEGER_REGEXP_']['test'](_0x505fc8)?_0x3c27de=Math['max'](_0x3c27de,Number(_0x505fc8)):_0x5a3122=!0x1;}),!_0x29d157&&_0x5a3122&&_0x3c27de<0x2*_0x5d4a5f){const _0x27546c=[];for(const _0x1c22eb in _0x24e3df)_0x27546c[_0x1c22eb]=_0x24e3df[_0x1c22eb];return _0x27546c;}else return _0x29d157&&!this['getPriority']()['isEmpty']()&&(_0x24e3df['.priority']=this['getPriority']()['val']()),_0x24e3df;}['hash'](){if(this['lazyHash_']===null){let _0x451965='';this['getPriority']()['isEmpty']()||(_0x451965+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x144dce,_0x38130e)=>{const _0x54ac30=_0x38130e['hash']();_0x54ac30!==''&&(_0x451965+=':'+_0x144dce+':'+_0x54ac30);}),this['lazyHash_']=_0x451965===''?'':ro(_0x451965);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5eeafa,_0x207bc6,_0x147173){const _0x1cc463=this['resolveIndex_'](_0x147173);if(_0x1cc463){const _0x880ae9=_0x1cc463['getPredecessorKey'](new E(_0x5eeafa,_0x207bc6));return _0x880ae9?_0x880ae9['name']:null;}else return this['children_']['getPredecessorKey'](_0x5eeafa);}['getFirstChildName'](_0x44389b){const _0x1c67a4=this['resolveIndex_'](_0x44389b);if(_0x1c67a4){const _0x32381b=_0x1c67a4['minKey']();return _0x32381b&&_0x32381b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x915cda){const _0x50f58e=this['getFirstChildName'](_0x915cda);return _0x50f58e?new E(_0x50f58e,this['children_']['get'](_0x50f58e)):null;}['getLastChildName'](_0x215acb){const _0x2a041b=this['resolveIndex_'](_0x215acb);if(_0x2a041b){const _0x1b16bb=_0x2a041b['maxKey']();return _0x1b16bb&&_0x1b16bb['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5e8020){const _0x281ef0=this['getLastChildName'](_0x5e8020);return _0x281ef0?new E(_0x281ef0,this['children_']['get'](_0x281ef0)):null;}['forEachChild'](_0x2db4a1,_0xa82396){const _0x264710=this['resolveIndex_'](_0x2db4a1);return _0x264710?_0x264710['inorderTraversal'](_0xdc2555=>_0xa82396(_0xdc2555['name'],_0xdc2555['node'])):this['children_']['inorderTraversal'](_0xa82396);}['getIterator'](_0x422396){return this['getIteratorFrom'](_0x422396['minPost'](),_0x422396);}['getIteratorFrom'](_0x1bb8b0,_0x38fcd6){const _0x14d616=this['resolveIndex_'](_0x38fcd6);if(_0x14d616)return _0x14d616['getIteratorFrom'](_0x1bb8b0,_0x568ec7=>_0x568ec7);{const _0x85ed7c=this['children_']['getIteratorFrom'](_0x1bb8b0['name'],E['Wrap']);let _0x2bef27=_0x85ed7c['peek']();for(;_0x2bef27!=null&&_0x38fcd6['compare'](_0x2bef27,_0x1bb8b0)<0x0;)_0x85ed7c['getNext'](),_0x2bef27=_0x85ed7c['peek']();return _0x85ed7c;}}['getReverseIterator'](_0x217e87){return this['getReverseIteratorFrom'](_0x217e87['maxPost'](),_0x217e87);}['getReverseIteratorFrom'](_0x477e43,_0x4341c0){const _0xfb34ef=this['resolveIndex_'](_0x4341c0);if(_0xfb34ef)return _0xfb34ef['getReverseIteratorFrom'](_0x477e43,_0x1ddd2a=>_0x1ddd2a);{const _0x3e6f34=this['children_']['getReverseIteratorFrom'](_0x477e43['name'],E['Wrap']);let _0x5b8e8c=_0x3e6f34['peek']();for(;_0x5b8e8c!=null&&_0x4341c0['compare'](_0x5b8e8c,_0x477e43)>0x0;)_0x3e6f34['getNext'](),_0x5b8e8c=_0x3e6f34['peek']();return _0x3e6f34;}}['compareTo'](_0x446656){return this['isEmpty']()?_0x446656['isEmpty']()?0x0:-0x1:_0x446656['isLeafNode']()||_0x446656['isEmpty']()?0x1:_0x446656===Kt?-0x1:0x0;}['withIndex'](_0x188434){if(_0x188434===ve||this['indexMap_']['hasIndex'](_0x188434))return this;{const _0x459fa0=this['indexMap_']['addIndex'](_0x188434,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x459fa0);}}['isIndexed'](_0x206ab8){return _0x206ab8===ve||this['indexMap_']['hasIndex'](_0x206ab8);}['equals'](_0x1ba2da){if(_0x1ba2da===this)return!0x0;if(_0x1ba2da['isLeafNode']())return!0x1;{const _0x2c13da=_0x1ba2da;if(this['getPriority']()['equals'](_0x2c13da['getPriority']())){if(this['children_']['count']()===_0x2c13da['children_']['count']()){const _0xc02c38=this['getIterator'](R),_0x491036=_0x2c13da['getIterator'](R);let _0xbb785e=_0xc02c38['getNext'](),_0x10edae=_0x491036['getNext']();for(;_0xbb785e&&_0x10edae;){if(_0xbb785e['name']!==_0x10edae['name']||!_0xbb785e['node']['equals'](_0x10edae['node']))return!0x1;_0xbb785e=_0xc02c38['getNext'](),_0x10edae=_0x491036['getNext']();}return _0xbb785e===null&&_0x10edae===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x15e1f1){return _0x15e1f1===ve?null:this['indexMap_']['get'](_0x15e1f1['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x38aa65){return _0x38aa65===this?0x0:0x1;}['equals'](_0x25ddf1){return _0x25ddf1===this;}['getPriority'](){return this;}['getImmediateChild'](_0x17f952){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xcf9fed,_0x4fd2e4=null){if(_0xcf9fed===null)return g['EMPTY_NODE'];if(typeof _0xcf9fed=='object'&&'.priority'in _0xcf9fed&&(_0x4fd2e4=_0xcf9fed['.priority']),f(_0x4fd2e4===null||typeof _0x4fd2e4=='string'||typeof _0x4fd2e4=='number'||typeof _0x4fd2e4=='object'&&'.sv'in _0x4fd2e4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4fd2e4),typeof _0xcf9fed=='object'&&'.value'in _0xcf9fed&&_0xcf9fed['.value']!==null&&(_0xcf9fed=_0xcf9fed['.value']),typeof _0xcf9fed!='object'||'.sv'in _0xcf9fed){const _0x264eaf=_0xcf9fed;return new D(_0x264eaf,A(_0x4fd2e4));}if(!(_0xcf9fed instanceof Array)&&Gh){const _0x3d31ed=[];let _0x2bdcba=!0x1;if(x(_0xcf9fed,(_0x119b54,_0x29f694)=>{if(_0x119b54['substring'](0x0,0x1)!=='.'){const _0x271e7f=A(_0x29f694);_0x271e7f['isEmpty']()||(_0x2bdcba=_0x2bdcba||!_0x271e7f['getPriority']()['isEmpty'](),_0x3d31ed['push'](new E(_0x119b54,_0x271e7f)));}}),_0x3d31ed['length']===0x0)return g['EMPTY_NODE'];const _0x48c68d=yn(_0x3d31ed,xh,_0x433d73=>_0x433d73['name'],Qi);if(_0x2bdcba){const _0x13fbb3=yn(_0x3d31ed,R['getCompare']());return new g(_0x48c68d,A(_0x4fd2e4),new te({'.priority':_0x13fbb3},{'.priority':R}));}else return new g(_0x48c68d,A(_0x4fd2e4),te['Default']);}else{let _0x46279f=g['EMPTY_NODE'];return x(_0xcf9fed,(_0x9fda25,_0x3ea0e8)=>{if(Q(_0xcf9fed,_0x9fda25)&&_0x9fda25['substring'](0x0,0x1)!=='.'){const _0x5d69cf=A(_0x3ea0e8);(_0x5d69cf['isLeafNode']()||!_0x5d69cf['isEmpty']())&&(_0x46279f=_0x46279f['updateImmediateChild'](_0x9fda25,_0x5d69cf));}}),_0x46279f['updatePriority'](A(_0x4fd2e4));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x561bda){super(),this['indexPath_']=_0x561bda,f(!v(_0x561bda)&&y(_0x561bda)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3617ba){return _0x3617ba['getChild'](this['indexPath_']);}['isDefinedOn'](_0x65abbc){return!_0x65abbc['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x146183,_0x2a2c2a){const _0xb1c0a1=this['extractChild'](_0x146183['node']),_0x56f163=this['extractChild'](_0x2a2c2a['node']),_0x3323cb=_0xb1c0a1['compareTo'](_0x56f163);return _0x3323cb===0x0?qe(_0x146183['name'],_0x2a2c2a['name']):_0x3323cb;}['makePost'](_0x11c237,_0xb9c77d){const _0x7fb9c3=A(_0x11c237),_0x1f68e8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x7fb9c3);return new E(_0xb9c77d,_0x1f68e8);}['maxPost'](){const _0x297f45=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x297f45);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x54e62e,_0x531b74){const _0x422231=_0x54e62e['node']['compareTo'](_0x531b74['node']);return _0x422231===0x0?qe(_0x54e62e['name'],_0x531b74['name']):_0x422231;}['isDefinedOn'](_0x24b1ef){return!0x0;}['indexedValueChanged'](_0x414e72,_0x9fd69d){return!_0x414e72['equals'](_0x9fd69d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x263036,_0x43ba5c){const _0x2daed9=A(_0x263036);return new E(_0x43ba5c,_0x2daed9);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x534949){return{'type':'value','snapshotNode':_0x534949};}function rt(_0xb20ac6,_0x21ce4e){return{'type':'child_added','snapshotNode':_0x21ce4e,'childName':_0xb20ac6};}function Lt(_0x10ed0f,_0x2fcdc8){return{'type':'child_removed','snapshotNode':_0x2fcdc8,'childName':_0x10ed0f};}function xt(_0x31cfd8,_0x20b733,_0x5c3bc3){return{'type':'child_changed','snapshotNode':_0x20b733,'childName':_0x31cfd8,'oldSnap':_0x5c3bc3};}function zh(_0x22a32c,_0x343afa){return{'type':'child_moved','snapshotNode':_0x343afa,'childName':_0x22a32c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1dc2c5){this['index_']=_0x1dc2c5;}['updateChild'](_0x24f85f,_0x370a96,_0x2279e8,_0x1bf9f2,_0x4eb0ba,_0xbb5505){f(_0x24f85f['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x257e94=_0x24f85f['getImmediateChild'](_0x370a96);return _0x257e94['getChild'](_0x1bf9f2)['equals'](_0x2279e8['getChild'](_0x1bf9f2))&&_0x257e94['isEmpty']()===_0x2279e8['isEmpty']()||(_0xbb5505!=null&&(_0x2279e8['isEmpty']()?_0x24f85f['hasChild'](_0x370a96)?_0xbb5505['trackChildChange'](Lt(_0x370a96,_0x257e94)):f(_0x24f85f['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x257e94['isEmpty']()?_0xbb5505['trackChildChange'](rt(_0x370a96,_0x2279e8)):_0xbb5505['trackChildChange'](xt(_0x370a96,_0x2279e8,_0x257e94))),_0x24f85f['isLeafNode']()&&_0x2279e8['isEmpty']())?_0x24f85f:_0x24f85f['updateImmediateChild'](_0x370a96,_0x2279e8)['withIndex'](this['index_']);}['updateFullNode'](_0x2c2046,_0xb5472f,_0x1c4c46){return _0x1c4c46!=null&&(_0x2c2046['isLeafNode']()||_0x2c2046['forEachChild'](R,(_0x16743f,_0xdeb72c)=>{_0xb5472f['hasChild'](_0x16743f)||_0x1c4c46['trackChildChange'](Lt(_0x16743f,_0xdeb72c));}),_0xb5472f['isLeafNode']()||_0xb5472f['forEachChild'](R,(_0x3589e2,_0xeac586)=>{if(_0x2c2046['hasChild'](_0x3589e2)){const _0x530c2c=_0x2c2046['getImmediateChild'](_0x3589e2);_0x530c2c['equals'](_0xeac586)||_0x1c4c46['trackChildChange'](xt(_0x3589e2,_0xeac586,_0x530c2c));}else _0x1c4c46['trackChildChange'](rt(_0x3589e2,_0xeac586));})),_0xb5472f['withIndex'](this['index_']);}['updatePriority'](_0x48829b,_0x1c3fa5){return _0x48829b['isEmpty']()?g['EMPTY_NODE']:_0x48829b['updatePriority'](_0x1c3fa5);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x417c26){this['indexedFilter_']=new Xi(_0x417c26['getIndex']()),this['index_']=_0x417c26['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x417c26),this['endPost_']=Ft['getEndPost_'](_0x417c26),this['startIsInclusive_']=!_0x417c26['startAfterSet_'],this['endIsInclusive_']=!_0x417c26['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x397ac5){const _0x340104=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x397ac5)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x397ac5)<0x0,_0x5a996b=this['endIsInclusive_']?this['index_']['compare'](_0x397ac5,this['getEndPost']())<=0x0:this['index_']['compare'](_0x397ac5,this['getEndPost']())<0x0;return _0x340104&&_0x5a996b;}['updateChild'](_0x45dd84,_0x4fe991,_0x44d44c,_0x5cae67,_0x56561a,_0x4fd0e8){return this['matches'](new E(_0x4fe991,_0x44d44c))||(_0x44d44c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x45dd84,_0x4fe991,_0x44d44c,_0x5cae67,_0x56561a,_0x4fd0e8);}['updateFullNode'](_0x48f7d2,_0x440ab9,_0x32519f){_0x440ab9['isLeafNode']()&&(_0x440ab9=g['EMPTY_NODE']);let _0x2c8f67=_0x440ab9['withIndex'](this['index_']);_0x2c8f67=_0x2c8f67['updatePriority'](g['EMPTY_NODE']);const _0x35494d=this;return _0x440ab9['forEachChild'](R,(_0x476359,_0x14206b)=>{_0x35494d['matches'](new E(_0x476359,_0x14206b))||(_0x2c8f67=_0x2c8f67['updateImmediateChild'](_0x476359,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x48f7d2,_0x2c8f67,_0x32519f);}['updatePriority'](_0x3cb5f8,_0xcd0f9d){return _0x3cb5f8;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x42fe74){if(_0x42fe74['hasStart']()){const _0x14e336=_0x42fe74['getIndexStartName']();return _0x42fe74['getIndex']()['makePost'](_0x42fe74['getIndexStartValue'](),_0x14e336);}else return _0x42fe74['getIndex']()['minPost']();}static['getEndPost_'](_0x177062){if(_0x177062['hasEnd']()){const _0x532c84=_0x177062['getIndexEndName']();return _0x177062['getIndex']()['makePost'](_0x177062['getIndexEndValue'](),_0x532c84);}else return _0x177062['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x391935){this['withinDirectionalStart']=_0x556905=>this['reverse_']?this['withinEndPost'](_0x556905):this['withinStartPost'](_0x556905),this['withinDirectionalEnd']=_0x3658d4=>this['reverse_']?this['withinStartPost'](_0x3658d4):this['withinEndPost'](_0x3658d4),this['withinStartPost']=_0xf5bc64=>{const _0x1197e9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xf5bc64);return this['startIsInclusive_']?_0x1197e9<=0x0:_0x1197e9<0x0;},this['withinEndPost']=_0x3a6e58=>{const _0x510b99=this['index_']['compare'](_0x3a6e58,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x510b99<=0x0:_0x510b99<0x0;},this['rangedFilter_']=new Ft(_0x391935),this['index_']=_0x391935['getIndex'](),this['limit_']=_0x391935['getLimit'](),this['reverse_']=!_0x391935['isViewFromLeft'](),this['startIsInclusive_']=!_0x391935['startAfterSet_'],this['endIsInclusive_']=!_0x391935['endBeforeSet_'];}['updateChild'](_0x403b6f,_0x2a6e54,_0x40990e,_0x585178,_0xd93277,_0x3a8921){return this['rangedFilter_']['matches'](new E(_0x2a6e54,_0x40990e))||(_0x40990e=g['EMPTY_NODE']),_0x403b6f['getImmediateChild'](_0x2a6e54)['equals'](_0x40990e)?_0x403b6f:_0x403b6f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x403b6f,_0x2a6e54,_0x40990e,_0x585178,_0xd93277,_0x3a8921):this['fullLimitUpdateChild_'](_0x403b6f,_0x2a6e54,_0x40990e,_0xd93277,_0x3a8921);}['updateFullNode'](_0x3b2c73,_0x61eb87,_0x52c961){let _0x5b8fa7;if(_0x61eb87['isLeafNode']()||_0x61eb87['isEmpty']())_0x5b8fa7=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x61eb87['numChildren']()&&_0x61eb87['isIndexed'](this['index_'])){_0x5b8fa7=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x46428c;this['reverse_']?_0x46428c=_0x61eb87['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x46428c=_0x61eb87['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x8f87ec=0x0;for(;_0x46428c['hasNext']()&&_0x8f87ec<this['limit_'];){const _0x13521d=_0x46428c['getNext']();if(this['withinDirectionalStart'](_0x13521d)){if(this['withinDirectionalEnd'](_0x13521d))_0x5b8fa7=_0x5b8fa7['updateImmediateChild'](_0x13521d['name'],_0x13521d['node']),_0x8f87ec++;else break;}else continue;}}else{_0x5b8fa7=_0x61eb87['withIndex'](this['index_']),_0x5b8fa7=_0x5b8fa7['updatePriority'](g['EMPTY_NODE']);let _0x340a07;this['reverse_']?_0x340a07=_0x5b8fa7['getReverseIterator'](this['index_']):_0x340a07=_0x5b8fa7['getIterator'](this['index_']);let _0x23e060=0x0;for(;_0x340a07['hasNext']();){const _0x41cf87=_0x340a07['getNext']();_0x23e060<this['limit_']&&this['withinDirectionalStart'](_0x41cf87)&&this['withinDirectionalEnd'](_0x41cf87)?_0x23e060++:_0x5b8fa7=_0x5b8fa7['updateImmediateChild'](_0x41cf87['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3b2c73,_0x5b8fa7,_0x52c961);}['updatePriority'](_0x28d81e,_0x5a7c4f){return _0x28d81e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xeb8986,_0xa051c0,_0x3b663e,_0x905737,_0xcb2ba7){let _0x4b8b71;if(this['reverse_']){const _0xadb47=this['index_']['getCompare']();_0x4b8b71=(_0x1d8985,_0x55ccfb)=>_0xadb47(_0x55ccfb,_0x1d8985);}else _0x4b8b71=this['index_']['getCompare']();const _0x58058f=_0xeb8986;f(_0x58058f['numChildren']()===this['limit_'],'');const _0x3f3aa8=new E(_0xa051c0,_0x3b663e),_0x23f37d=this['reverse_']?_0x58058f['getFirstChild'](this['index_']):_0x58058f['getLastChild'](this['index_']),_0xdae034=this['rangedFilter_']['matches'](_0x3f3aa8);if(_0x58058f['hasChild'](_0xa051c0)){const _0xf22d38=_0x58058f['getImmediateChild'](_0xa051c0);let _0x280803=_0x905737['getChildAfterChild'](this['index_'],_0x23f37d,this['reverse_']);for(;_0x280803!=null&&(_0x280803['name']===_0xa051c0||_0x58058f['hasChild'](_0x280803['name']));)_0x280803=_0x905737['getChildAfterChild'](this['index_'],_0x280803,this['reverse_']);const _0x5906dd=_0x280803==null?0x1:_0x4b8b71(_0x280803,_0x3f3aa8);if(_0xdae034&&!_0x3b663e['isEmpty']()&&_0x5906dd>=0x0)return _0xcb2ba7!=null&&_0xcb2ba7['trackChildChange'](xt(_0xa051c0,_0x3b663e,_0xf22d38)),_0x58058f['updateImmediateChild'](_0xa051c0,_0x3b663e);{_0xcb2ba7!=null&&_0xcb2ba7['trackChildChange'](Lt(_0xa051c0,_0xf22d38));const _0x989758=_0x58058f['updateImmediateChild'](_0xa051c0,g['EMPTY_NODE']);return _0x280803!=null&&this['rangedFilter_']['matches'](_0x280803)?(_0xcb2ba7!=null&&_0xcb2ba7['trackChildChange'](rt(_0x280803['name'],_0x280803['node'])),_0x989758['updateImmediateChild'](_0x280803['name'],_0x280803['node'])):_0x989758;}}else return _0x3b663e['isEmpty']()?_0xeb8986:_0xdae034&&_0x4b8b71(_0x23f37d,_0x3f3aa8)>=0x0?(_0xcb2ba7!=null&&(_0xcb2ba7['trackChildChange'](Lt(_0x23f37d['name'],_0x23f37d['node'])),_0xcb2ba7['trackChildChange'](rt(_0xa051c0,_0x3b663e))),_0x58058f['updateImmediateChild'](_0xa051c0,_0x3b663e)['updateImmediateChild'](_0x23f37d['name'],g['EMPTY_NODE'])):_0xeb8986;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5894ee=new Zi();return _0x5894ee['limitSet_']=this['limitSet_'],_0x5894ee['limit_']=this['limit_'],_0x5894ee['startSet_']=this['startSet_'],_0x5894ee['startAfterSet_']=this['startAfterSet_'],_0x5894ee['indexStartValue_']=this['indexStartValue_'],_0x5894ee['startNameSet_']=this['startNameSet_'],_0x5894ee['indexStartName_']=this['indexStartName_'],_0x5894ee['endSet_']=this['endSet_'],_0x5894ee['endBeforeSet_']=this['endBeforeSet_'],_0x5894ee['indexEndValue_']=this['indexEndValue_'],_0x5894ee['endNameSet_']=this['endNameSet_'],_0x5894ee['indexEndName_']=this['indexEndName_'],_0x5894ee['index_']=this['index_'],_0x5894ee['viewFrom_']=this['viewFrom_'],_0x5894ee;}}function Kh(_0x5abbde){return _0x5abbde['loadsAllData']()?new Xi(_0x5abbde['getIndex']()):_0x5abbde['hasLimit']()?new jh(_0x5abbde):new Ft(_0x5abbde);}function Yh(_0x1676cc,_0x480fbf){const _0x2747f1=_0x1676cc['copy']();return _0x2747f1['limitSet_']=!0x0,_0x2747f1['limit_']=_0x480fbf,_0x2747f1['viewFrom_']='l',_0x2747f1;}function Qh(_0x3b07b5,_0x4c1dbb,_0x3b289a){const _0x41216b=_0x3b07b5['copy']();return _0x41216b['startSet_']=!0x0,_0x4c1dbb===void 0x0&&(_0x4c1dbb=null),_0x41216b['indexStartValue_']=_0x4c1dbb,_0x3b289a!=null?(_0x41216b['startNameSet_']=!0x0,_0x41216b['indexStartName_']=_0x3b289a):(_0x41216b['startNameSet_']=!0x1,_0x41216b['indexStartName_']=''),_0x41216b;}function Jh(_0x2f8ad3,_0x5bf18b,_0x42381a){const _0x12767b=_0x2f8ad3['copy']();return _0x12767b['endSet_']=!0x0,_0x5bf18b===void 0x0&&(_0x5bf18b=null),_0x12767b['indexEndValue_']=_0x5bf18b,_0x42381a!==void 0x0?(_0x12767b['endNameSet_']=!0x0,_0x12767b['indexEndName_']=_0x42381a):(_0x12767b['endNameSet_']=!0x1,_0x12767b['indexEndName_']=''),_0x12767b;}function xo(_0x37b478,_0x27734a){const _0x224520=_0x37b478['copy']();return _0x224520['index_']=_0x27734a,_0x224520;}function ir(_0x4e2a7d){const _0x57603d={};if(_0x4e2a7d['isDefault']())return _0x57603d;let _0x3a5d89;if(_0x4e2a7d['index_']===R?_0x3a5d89='$priority':_0x4e2a7d['index_']===Mo?_0x3a5d89='$value':_0x4e2a7d['index_']===ve?_0x3a5d89='$key':(f(_0x4e2a7d['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x3a5d89=_0x4e2a7d['index_']['toString']()),_0x57603d['orderBy']=O(_0x3a5d89),_0x4e2a7d['startSet_']){const _0x4330ba=_0x4e2a7d['startAfterSet_']?'startAfter':'startAt';_0x57603d[_0x4330ba]=O(_0x4e2a7d['indexStartValue_']),_0x4e2a7d['startNameSet_']&&(_0x57603d[_0x4330ba]+=','+O(_0x4e2a7d['indexStartName_']));}if(_0x4e2a7d['endSet_']){const _0x104e63=_0x4e2a7d['endBeforeSet_']?'endBefore':'endAt';_0x57603d[_0x104e63]=O(_0x4e2a7d['indexEndValue_']),_0x4e2a7d['endNameSet_']&&(_0x57603d[_0x104e63]+=','+O(_0x4e2a7d['indexEndName_']));}return _0x4e2a7d['limitSet_']&&(_0x4e2a7d['isViewFromLeft']()?_0x57603d['limitToFirst']=_0x4e2a7d['limit_']:_0x57603d['limitToLast']=_0x4e2a7d['limit_']),_0x57603d;}function sr(_0x46eeae){const _0x1d5cca={};if(_0x46eeae['startSet_']&&(_0x1d5cca['sp']=_0x46eeae['indexStartValue_'],_0x46eeae['startNameSet_']&&(_0x1d5cca['sn']=_0x46eeae['indexStartName_']),_0x1d5cca['sin']=!_0x46eeae['startAfterSet_']),_0x46eeae['endSet_']&&(_0x1d5cca['ep']=_0x46eeae['indexEndValue_'],_0x46eeae['endNameSet_']&&(_0x1d5cca['en']=_0x46eeae['indexEndName_']),_0x1d5cca['ein']=!_0x46eeae['endBeforeSet_']),_0x46eeae['limitSet_']){_0x1d5cca['l']=_0x46eeae['limit_'];let _0x4a4c58=_0x46eeae['viewFrom_'];_0x4a4c58===''&&(_0x46eeae['isViewFromLeft']()?_0x4a4c58='l':_0x4a4c58='r'),_0x1d5cca['vf']=_0x4a4c58;}return _0x46eeae['index_']!==R&&(_0x1d5cca['i']=_0x46eeae['index_']['toString']()),_0x1d5cca;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x1668a2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2e3ecf,_0x19edd7){return _0x19edd7!==void 0x0?'tag$'+_0x19edd7:(f(_0x2e3ecf['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2e3ecf['_path']['toString']());}constructor(_0x4ef166,_0x408220,_0x274425,_0x40fc69){super(),this['repoInfo_']=_0x4ef166,this['onDataUpdate_']=_0x408220,this['authTokenProvider_']=_0x274425,this['appCheckTokenProvider_']=_0x40fc69,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x31c139,_0xfb68a7,_0x53a047,_0x4a1395){const _0x5d6493=_0x31c139['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5d6493+'\x20'+_0x31c139['_queryIdentifier']);const _0x1a699a=vn['getListenId_'](_0x31c139,_0x53a047),_0x45d152={};this['listens_'][_0x1a699a]=_0x45d152;const _0x1f165d=ir(_0x31c139['_queryParams']);this['restRequest_'](_0x5d6493+'.json',_0x1f165d,(_0x49de6e,_0x728c4f)=>{let _0xadab86=_0x728c4f;if(_0x49de6e===0x194&&(_0xadab86=null,_0x49de6e=null),_0x49de6e===null&&this['onDataUpdate_'](_0x5d6493,_0xadab86,!0x1,_0x53a047),Le(this['listens_'],_0x1a699a)===_0x45d152){let _0x2cfec4;_0x49de6e?_0x49de6e===0x191?_0x2cfec4='permission_denied':_0x2cfec4='rest_error:'+_0x49de6e:_0x2cfec4='ok',_0x4a1395(_0x2cfec4,null);}});}['unlisten'](_0x3af26f,_0x5bd0d4){const _0x4cafd5=vn['getListenId_'](_0x3af26f,_0x5bd0d4);delete this['listens_'][_0x4cafd5];}['get'](_0x15cb5b){const _0x132d39=ir(_0x15cb5b['_queryParams']),_0x117dc5=_0x15cb5b['_path']['toString'](),_0x21a5dc=new H();return this['restRequest_'](_0x117dc5+'.json',_0x132d39,(_0xd7e394,_0x5e1060)=>{let _0x817bbe=_0x5e1060;_0xd7e394===0x194&&(_0x817bbe=null,_0xd7e394=null),_0xd7e394===null?(this['onDataUpdate_'](_0x117dc5,_0x817bbe,!0x1,null),_0x21a5dc['resolve'](_0x817bbe)):_0x21a5dc['reject'](new Error(_0x817bbe));}),_0x21a5dc['promise'];}['refreshAuthToken'](_0x5cec6a){}['restRequest_'](_0x47b6a1,_0x2541df={},_0x95fcdc){return _0x2541df['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xd8a3c4,_0x30d94b])=>{_0xd8a3c4&&_0xd8a3c4['accessToken']&&(_0x2541df['auth']=_0xd8a3c4['accessToken']),_0x30d94b&&_0x30d94b['token']&&(_0x2541df['ac']=_0x30d94b['token']);const _0x4fc5ea=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x47b6a1+'?ns='+this['repoInfo_']['namespace']+ut(_0x2541df);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4fc5ea);const _0x5cb346=new XMLHttpRequest();_0x5cb346['onreadystatechange']=()=>{if(_0x95fcdc&&_0x5cb346['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4fc5ea+'\x20received.\x20status:',_0x5cb346['status'],'response:',_0x5cb346['responseText']);let _0x1d1ee7=null;if(_0x5cb346['status']>=0xc8&&_0x5cb346['status']<0x12c){try{_0x1d1ee7=Nt(_0x5cb346['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4fc5ea+':\x20'+_0x5cb346['responseText']);}_0x95fcdc(null,_0x1d1ee7);}else _0x5cb346['status']!==0x191&&_0x5cb346['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4fc5ea+'\x20Status:\x20'+_0x5cb346['status']),_0x95fcdc(_0x5cb346['status']);_0x95fcdc=null;}},_0x5cb346['open']('GET',_0x4fc5ea,!0x0),_0x5cb346['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4520f3){return this['rootNode_']['getChild'](_0x4520f3);}['updateSnapshot'](_0x24d720,_0x37d907){this['rootNode_']=this['rootNode_']['updateChild'](_0x24d720,_0x37d907);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x8f6dd0,_0x1cc8f9,_0x2d54c0){if(v(_0x1cc8f9))_0x8f6dd0['value']=_0x2d54c0,_0x8f6dd0['children']['clear']();else{if(_0x8f6dd0['value']!==null)_0x8f6dd0['value']=_0x8f6dd0['value']['updateChild'](_0x1cc8f9,_0x2d54c0);else{const _0x187b77=y(_0x1cc8f9);_0x8f6dd0['children']['has'](_0x187b77)||_0x8f6dd0['children']['set'](_0x187b77,En());const _0xd37b0a=_0x8f6dd0['children']['get'](_0x187b77);_0x1cc8f9=S(_0x1cc8f9),pt(_0xd37b0a,_0x1cc8f9,_0x2d54c0);}}}function Ti(_0x33b3af,_0x30eee1){if(v(_0x30eee1))return _0x33b3af['value']=null,_0x33b3af['children']['clear'](),!0x0;if(_0x33b3af['value']!==null){if(_0x33b3af['value']['isLeafNode']())return!0x1;{const _0x565e=_0x33b3af['value'];return _0x33b3af['value']=null,_0x565e['forEachChild'](R,(_0x46bb70,_0x403dec)=>{pt(_0x33b3af,new C(_0x46bb70),_0x403dec);}),Ti(_0x33b3af,_0x30eee1);}}else{if(_0x33b3af['children']['size']>0x0){const _0x291bc4=y(_0x30eee1);return _0x30eee1=S(_0x30eee1),_0x33b3af['children']['has'](_0x291bc4)&&Ti(_0x33b3af['children']['get'](_0x291bc4),_0x30eee1)&&_0x33b3af['children']['delete'](_0x291bc4),_0x33b3af['children']['size']===0x0;}else return!0x0;}}function Si(_0x10ad2d,_0x481491,_0xe7f131){_0x10ad2d['value']!==null?_0xe7f131(_0x481491,_0x10ad2d['value']):Zh(_0x10ad2d,(_0x1cf70c,_0x694b9d)=>{const _0x5644ba=new C(_0x481491['toString']()+'/'+_0x1cf70c);Si(_0x694b9d,_0x5644ba,_0xe7f131);});}function Zh(_0x42b0dd,_0x465b06){_0x42b0dd['children']['forEach']((_0x240d11,_0x861dfa)=>{_0x465b06(_0x861dfa,_0x240d11);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x34d0e6){this['collection_']=_0x34d0e6,this['last_']=null;}['get'](){const _0x80038=this['collection_']['get'](),_0x7c46e5={..._0x80038};return this['last_']&&x(this['last_'],(_0x39522f,_0x235982)=>{_0x7c46e5[_0x39522f]=_0x7c46e5[_0x39522f]-_0x235982;}),this['last_']=_0x80038,_0x7c46e5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3ec7a1,_0x80201c){this['server_']=_0x80201c,this['statsToReport_']={},this['statsListener_']=new eu(_0x3ec7a1);const _0x5257e6=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5257e6));}['reportStats_'](){const _0x5bc445=this['statsListener_']['get'](),_0x5eb309={};let _0x1c04ad=!0x1;x(_0x5bc445,(_0x3af34a,_0x41348f)=>{_0x41348f>0x0&&Q(this['statsToReport_'],_0x3af34a)&&(_0x5eb309[_0x3af34a]=_0x41348f,_0x1c04ad=!0x0);}),_0x1c04ad&&this['server_']['reportStats'](_0x5eb309),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4c056c){_0x4c056c[_0x4c056c['OVERWRITE']=0x0]='OVERWRITE',_0x4c056c[_0x4c056c['MERGE']=0x1]='MERGE',_0x4c056c[_0x4c056c['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4c056c[_0x4c056c['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x580e0e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x580e0e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x16079f,_0x5c0195,_0x25f034){this['path']=_0x16079f,this['affectedTree']=_0x5c0195,this['revert']=_0x25f034,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x443369){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x39f27c=this['affectedTree']['subtree'](new C(_0x443369));return new In(w(),_0x39f27c,this['revert']);}}else return f(y(this['path'])===_0x443369,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x56cf46,_0x10b27a){this['source']=_0x56cf46,this['path']=_0x10b27a,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x18a8af){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x256f95,_0x2183ea,_0x28aa0a){this['source']=_0x256f95,this['path']=_0x2183ea,this['snap']=_0x28aa0a,this['type']=z['OVERWRITE'];}['operationForChild'](_0x19f518){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x19f518)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x18a672,_0x2e4316,_0x54b014){this['source']=_0x18a672,this['path']=_0x2e4316,this['children']=_0x54b014,this['type']=z['MERGE'];}['operationForChild'](_0x3a8ddd){if(v(this['path'])){const _0x66c8d4=this['children']['subtree'](new C(_0x3a8ddd));return _0x66c8d4['isEmpty']()?null:_0x66c8d4['value']?new Be(this['source'],w(),_0x66c8d4['value']):new ot(this['source'],w(),_0x66c8d4);}else return f(y(this['path'])===_0x3a8ddd,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x263143,_0x11f4b0,_0x23d7cc){this['node_']=_0x263143,this['fullyInitialized_']=_0x11f4b0,this['filtered_']=_0x23d7cc;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1750c1){if(v(_0x1750c1))return this['isFullyInitialized']()&&!this['filtered_'];const _0x137e4c=y(_0x1750c1);return this['isCompleteForChild'](_0x137e4c);}['isCompleteForChild'](_0x10951c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x10951c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x552cc5){this['query_']=_0x552cc5,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x232ef3,_0x48bcdd,_0x2a7489,_0x1c78ec){const _0x4a7105=[],_0x401c74=[];return _0x48bcdd['forEach'](_0x22c2ee=>{_0x22c2ee['type']==='child_changed'&&_0x232ef3['index_']['indexedValueChanged'](_0x22c2ee['oldSnap'],_0x22c2ee['snapshotNode'])&&_0x401c74['push'](zh(_0x22c2ee['childName'],_0x22c2ee['snapshotNode']));}),wt(_0x232ef3,_0x4a7105,'child_removed',_0x48bcdd,_0x1c78ec,_0x2a7489),wt(_0x232ef3,_0x4a7105,'child_added',_0x48bcdd,_0x1c78ec,_0x2a7489),wt(_0x232ef3,_0x4a7105,'child_moved',_0x401c74,_0x1c78ec,_0x2a7489),wt(_0x232ef3,_0x4a7105,'child_changed',_0x48bcdd,_0x1c78ec,_0x2a7489),wt(_0x232ef3,_0x4a7105,'value',_0x48bcdd,_0x1c78ec,_0x2a7489),_0x4a7105;}function wt(_0x412393,_0x4a8a05,_0x32c6de,_0x267b6b,_0x58b5de,_0x218481){const _0x7dc855=_0x267b6b['filter'](_0x373bde=>_0x373bde['type']===_0x32c6de);_0x7dc855['sort']((_0x368688,_0x23510a)=>au(_0x412393,_0x368688,_0x23510a)),_0x7dc855['forEach'](_0x1aac15=>{const _0x49be28=ou(_0x412393,_0x1aac15,_0x218481);_0x58b5de['forEach'](_0x5aa38c=>{_0x5aa38c['respondsTo'](_0x1aac15['type'])&&_0x4a8a05['push'](_0x5aa38c['createEvent'](_0x49be28,_0x412393['query_']));});});}function ou(_0x56c0da,_0x4fa745,_0x329878){return _0x4fa745['type']==='value'||_0x4fa745['type']==='child_removed'||(_0x4fa745['prevName']=_0x329878['getPredecessorChildName'](_0x4fa745['childName'],_0x4fa745['snapshotNode'],_0x56c0da['index_'])),_0x4fa745;}function au(_0x2c246a,_0x5c883d,_0x3e8d90){if(_0x5c883d['childName']==null||_0x3e8d90['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0xbd62b7=new E(_0x5c883d['childName'],_0x5c883d['snapshotNode']),_0x51cea0=new E(_0x3e8d90['childName'],_0x3e8d90['snapshotNode']);return _0x2c246a['index_']['compare'](_0xbd62b7,_0x51cea0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x3c669d,_0x10ae9f){return{'eventCache':_0x3c669d,'serverCache':_0x10ae9f};}function Rt(_0xb66b97,_0x2af515,_0x28b718,_0x2a6910){return Un(new Te(_0x2af515,_0x28b718,_0x2a6910),_0xb66b97['serverCache']);}function Fo(_0x261444,_0x4eb84a,_0x5beae8,_0x2070dc){return Un(_0x261444['eventCache'],new Te(_0x4eb84a,_0x5beae8,_0x2070dc));}function wn(_0x3cdea6){return _0x3cdea6['eventCache']['isFullyInitialized']()?_0x3cdea6['eventCache']['getNode']():null;}function Ve(_0x25cc1b){return _0x25cc1b['serverCache']['isFullyInitialized']()?_0x25cc1b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x51dcd5){let _0x1be6a6=new b(null);return x(_0x51dcd5,(_0x4ee118,_0x1db8f6)=>{_0x1be6a6=_0x1be6a6['set'](new C(_0x4ee118),_0x1db8f6);}),_0x1be6a6;}constructor(_0x4df3a3,_0x9bc4c1=cu()){this['value']=_0x4df3a3,this['children']=_0x9bc4c1;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x175648,_0xb652e0){if(this['value']!=null&&_0xb652e0(this['value']))return{'path':w(),'value':this['value']};if(v(_0x175648))return null;{const _0x11c167=y(_0x175648),_0x483920=this['children']['get'](_0x11c167);if(_0x483920!==null){const _0x397dc5=_0x483920['findRootMostMatchingPathAndValue'](S(_0x175648),_0xb652e0);return _0x397dc5!=null?{'path':k(new C(_0x11c167),_0x397dc5['path']),'value':_0x397dc5['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4cccea){return this['findRootMostMatchingPathAndValue'](_0x4cccea,()=>!0x0);}['subtree'](_0x4adb5b){if(v(_0x4adb5b))return this;{const _0x6f3097=y(_0x4adb5b),_0x2ca5ae=this['children']['get'](_0x6f3097);return _0x2ca5ae!==null?_0x2ca5ae['subtree'](S(_0x4adb5b)):new b(null);}}['set'](_0xf9270c,_0x551736){if(v(_0xf9270c))return new b(_0x551736,this['children']);{const _0x48e729=y(_0xf9270c),_0x3fb9a5=(this['children']['get'](_0x48e729)||new b(null))['set'](S(_0xf9270c),_0x551736),_0x42cb22=this['children']['insert'](_0x48e729,_0x3fb9a5);return new b(this['value'],_0x42cb22);}}['remove'](_0x40e936){if(v(_0x40e936))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x441da1=y(_0x40e936),_0x11197d=this['children']['get'](_0x441da1);if(_0x11197d){const _0xd2f3f8=_0x11197d['remove'](S(_0x40e936));let _0x3240f3;return _0xd2f3f8['isEmpty']()?_0x3240f3=this['children']['remove'](_0x441da1):_0x3240f3=this['children']['insert'](_0x441da1,_0xd2f3f8),this['value']===null&&_0x3240f3['isEmpty']()?new b(null):new b(this['value'],_0x3240f3);}else return this;}}['get'](_0x113c86){if(v(_0x113c86))return this['value'];{const _0x1d7530=y(_0x113c86),_0x10494e=this['children']['get'](_0x1d7530);return _0x10494e?_0x10494e['get'](S(_0x113c86)):null;}}['setTree'](_0x40eb54,_0xbd7245){if(v(_0x40eb54))return _0xbd7245;{const _0x545744=y(_0x40eb54),_0x74fd29=(this['children']['get'](_0x545744)||new b(null))['setTree'](S(_0x40eb54),_0xbd7245);let _0x288f5e;return _0x74fd29['isEmpty']()?_0x288f5e=this['children']['remove'](_0x545744):_0x288f5e=this['children']['insert'](_0x545744,_0x74fd29),new b(this['value'],_0x288f5e);}}['fold'](_0x2f8270){return this['fold_'](w(),_0x2f8270);}['fold_'](_0x5cf5f7,_0x40f180){const _0x4ca525={};return this['children']['inorderTraversal']((_0x3c2ebd,_0x1f8b5f)=>{_0x4ca525[_0x3c2ebd]=_0x1f8b5f['fold_'](k(_0x5cf5f7,_0x3c2ebd),_0x40f180);}),_0x40f180(_0x5cf5f7,this['value'],_0x4ca525);}['findOnPath'](_0x1f3d74,_0x1023d3){return this['findOnPath_'](_0x1f3d74,w(),_0x1023d3);}['findOnPath_'](_0x59f2aa,_0x2c77e6,_0x4cfa61){const _0x1ad437=this['value']?_0x4cfa61(_0x2c77e6,this['value']):!0x1;if(_0x1ad437)return _0x1ad437;if(v(_0x59f2aa))return null;{const _0x272706=y(_0x59f2aa),_0x45dd6c=this['children']['get'](_0x272706);return _0x45dd6c?_0x45dd6c['findOnPath_'](S(_0x59f2aa),k(_0x2c77e6,_0x272706),_0x4cfa61):null;}}['foreachOnPath'](_0x5c2746,_0x44e89d){return this['foreachOnPath_'](_0x5c2746,w(),_0x44e89d);}['foreachOnPath_'](_0xd1864f,_0x242677,_0x2d1053){if(v(_0xd1864f))return this;{this['value']&&_0x2d1053(_0x242677,this['value']);const _0x3ac775=y(_0xd1864f),_0x1a5e0a=this['children']['get'](_0x3ac775);return _0x1a5e0a?_0x1a5e0a['foreachOnPath_'](S(_0xd1864f),k(_0x242677,_0x3ac775),_0x2d1053):new b(null);}}['foreach'](_0x17d86f){this['foreach_'](w(),_0x17d86f);}['foreach_'](_0x56ba32,_0x25176f){this['children']['inorderTraversal']((_0xf61bd7,_0x4dc6ba)=>{_0x4dc6ba['foreach_'](k(_0x56ba32,_0xf61bd7),_0x25176f);}),this['value']&&_0x25176f(_0x56ba32,this['value']);}['foreachChild'](_0x383c4b){this['children']['inorderTraversal']((_0x1ed9dc,_0x253f9b)=>{_0x253f9b['value']&&_0x383c4b(_0x1ed9dc,_0x253f9b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x27cb1c){this['writeTree_']=_0x27cb1c;}static['empty'](){return new K(new b(null));}}function At(_0x6f5a8f,_0x4d778e,_0x1303da){if(v(_0x4d778e))return new K(new b(_0x1303da));{const _0x232a17=_0x6f5a8f['writeTree_']['findRootMostValueAndPath'](_0x4d778e);if(_0x232a17!=null){const _0x3b035e=_0x232a17['path'];let _0x44bd25=_0x232a17['value'];const _0xfd1de0=F(_0x3b035e,_0x4d778e);return _0x44bd25=_0x44bd25['updateChild'](_0xfd1de0,_0x1303da),new K(_0x6f5a8f['writeTree_']['set'](_0x3b035e,_0x44bd25));}else{const _0x5123b4=new b(_0x1303da),_0x199ace=_0x6f5a8f['writeTree_']['setTree'](_0x4d778e,_0x5123b4);return new K(_0x199ace);}}}function bi(_0x243e2a,_0x4d3cbc,_0x48293a){let _0x2ee195=_0x243e2a;return x(_0x48293a,(_0x746939,_0x4d8e3c)=>{_0x2ee195=At(_0x2ee195,k(_0x4d3cbc,_0x746939),_0x4d8e3c);}),_0x2ee195;}function or(_0x40f38a,_0x575eaf){if(v(_0x575eaf))return K['empty']();{const _0x5a22b2=_0x40f38a['writeTree_']['setTree'](_0x575eaf,new b(null));return new K(_0x5a22b2);}}function Ri(_0x4adbca,_0x1779b0){return ze(_0x4adbca,_0x1779b0)!=null;}function ze(_0x59affc,_0x3a0e1f){const _0x4e0898=_0x59affc['writeTree_']['findRootMostValueAndPath'](_0x3a0e1f);return _0x4e0898!=null?_0x59affc['writeTree_']['get'](_0x4e0898['path'])['getChild'](F(_0x4e0898['path'],_0x3a0e1f)):null;}function ar(_0x163dff){const _0x161953=[],_0x7283cb=_0x163dff['writeTree_']['value'];return _0x7283cb!=null?_0x7283cb['isLeafNode']()||_0x7283cb['forEachChild'](R,(_0x1a9856,_0x1a7494)=>{_0x161953['push'](new E(_0x1a9856,_0x1a7494));}):_0x163dff['writeTree_']['children']['inorderTraversal']((_0x24131b,_0x2f4e85)=>{_0x2f4e85['value']!=null&&_0x161953['push'](new E(_0x24131b,_0x2f4e85['value']));}),_0x161953;}function Ee(_0x4ac36d,_0x4df35f){if(v(_0x4df35f))return _0x4ac36d;{const _0x61ec79=ze(_0x4ac36d,_0x4df35f);return _0x61ec79!=null?new K(new b(_0x61ec79)):new K(_0x4ac36d['writeTree_']['subtree'](_0x4df35f));}}function Ai(_0x10902d){return _0x10902d['writeTree_']['isEmpty']();}function at(_0x3ad2bd,_0x48ef7d){return Uo(w(),_0x3ad2bd['writeTree_'],_0x48ef7d);}function Uo(_0x1a12fe,_0x4bb281,_0x51b283){if(_0x4bb281['value']!=null)return _0x51b283['updateChild'](_0x1a12fe,_0x4bb281['value']);{let _0x5249d9=null;return _0x4bb281['children']['inorderTraversal']((_0x371ec9,_0x3480f9)=>{_0x371ec9==='.priority'?(f(_0x3480f9['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5249d9=_0x3480f9['value']):_0x51b283=Uo(k(_0x1a12fe,_0x371ec9),_0x3480f9,_0x51b283);}),!_0x51b283['getChild'](_0x1a12fe)['isEmpty']()&&_0x5249d9!==null&&(_0x51b283=_0x51b283['updateChild'](k(_0x1a12fe,'.priority'),_0x5249d9)),_0x51b283;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0xfaa44b,_0x253f36){return Ho(_0x253f36,_0xfaa44b);}function lu(_0x3d7419,_0x4ef5bc,_0x572d49,_0x17c213,_0xee92d5){f(_0x17c213>_0x3d7419['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xee92d5===void 0x0&&(_0xee92d5=!0x0),_0x3d7419['allWrites']['push']({'path':_0x4ef5bc,'snap':_0x572d49,'writeId':_0x17c213,'visible':_0xee92d5}),_0xee92d5&&(_0x3d7419['visibleWrites']=At(_0x3d7419['visibleWrites'],_0x4ef5bc,_0x572d49)),_0x3d7419['lastWriteId']=_0x17c213;}function hu(_0x265791,_0x3d4059,_0x4d1a0a,_0x61ba71){f(_0x61ba71>_0x265791['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x265791['allWrites']['push']({'path':_0x3d4059,'children':_0x4d1a0a,'writeId':_0x61ba71,'visible':!0x0}),_0x265791['visibleWrites']=bi(_0x265791['visibleWrites'],_0x3d4059,_0x4d1a0a),_0x265791['lastWriteId']=_0x61ba71;}function uu(_0x21252a,_0x3642ed){for(let _0x7adf8=0x0;_0x7adf8<_0x21252a['allWrites']['length'];_0x7adf8++){const _0x22b104=_0x21252a['allWrites'][_0x7adf8];if(_0x22b104['writeId']===_0x3642ed)return _0x22b104;}return null;}function du(_0x27a595,_0x31af69){const _0xa954d6=_0x27a595['allWrites']['findIndex'](_0x3c5b5d=>_0x3c5b5d['writeId']===_0x31af69);f(_0xa954d6>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3ff02d=_0x27a595['allWrites'][_0xa954d6];_0x27a595['allWrites']['splice'](_0xa954d6,0x1);let _0x3130da=_0x3ff02d['visible'],_0x32ad14=!0x1,_0x309503=_0x27a595['allWrites']['length']-0x1;for(;_0x3130da&&_0x309503>=0x0;){const _0x29815b=_0x27a595['allWrites'][_0x309503];_0x29815b['visible']&&(_0x309503>=_0xa954d6&&fu(_0x29815b,_0x3ff02d['path'])?_0x3130da=!0x1:G(_0x3ff02d['path'],_0x29815b['path'])&&(_0x32ad14=!0x0)),_0x309503--;}if(_0x3130da){if(_0x32ad14)return pu(_0x27a595),!0x0;if(_0x3ff02d['snap'])_0x27a595['visibleWrites']=or(_0x27a595['visibleWrites'],_0x3ff02d['path']);else{const _0x1d7e6c=_0x3ff02d['children'];x(_0x1d7e6c,_0x517266=>{_0x27a595['visibleWrites']=or(_0x27a595['visibleWrites'],k(_0x3ff02d['path'],_0x517266));});}return!0x0;}else return!0x1;}function fu(_0x128790,_0x13b7e3){if(_0x128790['snap'])return G(_0x128790['path'],_0x13b7e3);for(const _0x41b783 in _0x128790['children'])if(_0x128790['children']['hasOwnProperty'](_0x41b783)&&G(k(_0x128790['path'],_0x41b783),_0x13b7e3))return!0x0;return!0x1;}function pu(_0x50ba5e){_0x50ba5e['visibleWrites']=Wo(_0x50ba5e['allWrites'],_u,w()),_0x50ba5e['allWrites']['length']>0x0?_0x50ba5e['lastWriteId']=_0x50ba5e['allWrites'][_0x50ba5e['allWrites']['length']-0x1]['writeId']:_0x50ba5e['lastWriteId']=-0x1;}function _u(_0x34e84a){return _0x34e84a['visible'];}function Wo(_0x5571bb,_0x9fb7bd,_0xfe8181){let _0xb2733e=K['empty']();for(let _0x2d4b97=0x0;_0x2d4b97<_0x5571bb['length'];++_0x2d4b97){const _0x20faa4=_0x5571bb[_0x2d4b97];if(_0x9fb7bd(_0x20faa4)){const _0x4d95dd=_0x20faa4['path'];let _0x50cb23;if(_0x20faa4['snap'])G(_0xfe8181,_0x4d95dd)?(_0x50cb23=F(_0xfe8181,_0x4d95dd),_0xb2733e=At(_0xb2733e,_0x50cb23,_0x20faa4['snap'])):G(_0x4d95dd,_0xfe8181)&&(_0x50cb23=F(_0x4d95dd,_0xfe8181),_0xb2733e=At(_0xb2733e,w(),_0x20faa4['snap']['getChild'](_0x50cb23)));else{if(_0x20faa4['children']){if(G(_0xfe8181,_0x4d95dd))_0x50cb23=F(_0xfe8181,_0x4d95dd),_0xb2733e=bi(_0xb2733e,_0x50cb23,_0x20faa4['children']);else{if(G(_0x4d95dd,_0xfe8181)){if(_0x50cb23=F(_0x4d95dd,_0xfe8181),v(_0x50cb23))_0xb2733e=bi(_0xb2733e,w(),_0x20faa4['children']);else{const _0x37166c=Le(_0x20faa4['children'],y(_0x50cb23));if(_0x37166c){const _0x3f953f=_0x37166c['getChild'](S(_0x50cb23));_0xb2733e=At(_0xb2733e,w(),_0x3f953f);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xb2733e;}function Bo(_0x5d4d24,_0x54c18d,_0x33c737,_0x48afd4,_0x560332){if(!_0x48afd4&&!_0x560332){const _0x34e427=ze(_0x5d4d24['visibleWrites'],_0x54c18d);if(_0x34e427!=null)return _0x34e427;{const _0xc7dbaa=Ee(_0x5d4d24['visibleWrites'],_0x54c18d);if(Ai(_0xc7dbaa))return _0x33c737;if(_0x33c737==null&&!Ri(_0xc7dbaa,w()))return null;{const _0x129936=_0x33c737||g['EMPTY_NODE'];return at(_0xc7dbaa,_0x129936);}}}else{const _0x5d7159=Ee(_0x5d4d24['visibleWrites'],_0x54c18d);if(!_0x560332&&Ai(_0x5d7159))return _0x33c737;if(!_0x560332&&_0x33c737==null&&!Ri(_0x5d7159,w()))return null;{const _0x3746ad=function(_0x15da41){return(_0x15da41['visible']||_0x560332)&&(!_0x48afd4||!~_0x48afd4['indexOf'](_0x15da41['writeId']))&&(G(_0x15da41['path'],_0x54c18d)||G(_0x54c18d,_0x15da41['path']));},_0x1be0a8=Wo(_0x5d4d24['allWrites'],_0x3746ad,_0x54c18d),_0xc4cb14=_0x33c737||g['EMPTY_NODE'];return at(_0x1be0a8,_0xc4cb14);}}}function gu(_0x42a202,_0xc8d303,_0x26af01){let _0x299667=g['EMPTY_NODE'];const _0x43452e=ze(_0x42a202['visibleWrites'],_0xc8d303);if(_0x43452e)return _0x43452e['isLeafNode']()||_0x43452e['forEachChild'](R,(_0x4ed4dd,_0x3113a3)=>{_0x299667=_0x299667['updateImmediateChild'](_0x4ed4dd,_0x3113a3);}),_0x299667;if(_0x26af01){const _0x13fb8e=Ee(_0x42a202['visibleWrites'],_0xc8d303);return _0x26af01['forEachChild'](R,(_0x43fffe,_0x3fc935)=>{const _0x3fde97=at(Ee(_0x13fb8e,new C(_0x43fffe)),_0x3fc935);_0x299667=_0x299667['updateImmediateChild'](_0x43fffe,_0x3fde97);}),ar(_0x13fb8e)['forEach'](_0x3054ae=>{_0x299667=_0x299667['updateImmediateChild'](_0x3054ae['name'],_0x3054ae['node']);}),_0x299667;}else{const _0xff8590=Ee(_0x42a202['visibleWrites'],_0xc8d303);return ar(_0xff8590)['forEach'](_0x408fc1=>{_0x299667=_0x299667['updateImmediateChild'](_0x408fc1['name'],_0x408fc1['node']);}),_0x299667;}}function mu(_0x1c00e9,_0x34c948,_0x1f11be,_0xbea1a7,_0x27d7c1){f(_0xbea1a7||_0x27d7c1,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3df434=k(_0x34c948,_0x1f11be);if(Ri(_0x1c00e9['visibleWrites'],_0x3df434))return null;{const _0x28756c=Ee(_0x1c00e9['visibleWrites'],_0x3df434);return Ai(_0x28756c)?_0x27d7c1['getChild'](_0x1f11be):at(_0x28756c,_0x27d7c1['getChild'](_0x1f11be));}}function yu(_0x7e26c3,_0x407ac0,_0x35f7d,_0x370692){const _0x4e1e37=k(_0x407ac0,_0x35f7d),_0x292867=ze(_0x7e26c3['visibleWrites'],_0x4e1e37);if(_0x292867!=null)return _0x292867;if(_0x370692['isCompleteForChild'](_0x35f7d)){const _0x4fa452=Ee(_0x7e26c3['visibleWrites'],_0x4e1e37);return at(_0x4fa452,_0x370692['getNode']()['getImmediateChild'](_0x35f7d));}else return null;}function vu(_0x7472e2,_0x151bdf){return ze(_0x7472e2['visibleWrites'],_0x151bdf);}function Eu(_0x370f61,_0x4a1143,_0x3c3653,_0x3cc870,_0x6ed8b7,_0x124b85,_0x20425a){let _0x12c142;const _0x5b27f4=Ee(_0x370f61['visibleWrites'],_0x4a1143),_0x3a69f6=ze(_0x5b27f4,w());if(_0x3a69f6!=null)_0x12c142=_0x3a69f6;else{if(_0x3c3653!=null)_0x12c142=at(_0x5b27f4,_0x3c3653);else return[];}if(_0x12c142=_0x12c142['withIndex'](_0x20425a),!_0x12c142['isEmpty']()&&!_0x12c142['isLeafNode']()){const _0x1a7589=[],_0x13e8a2=_0x20425a['getCompare'](),_0x451b5a=_0x124b85?_0x12c142['getReverseIteratorFrom'](_0x3cc870,_0x20425a):_0x12c142['getIteratorFrom'](_0x3cc870,_0x20425a);let _0xd335c4=_0x451b5a['getNext']();for(;_0xd335c4&&_0x1a7589['length']<_0x6ed8b7;)_0x13e8a2(_0xd335c4,_0x3cc870)!==0x0&&_0x1a7589['push'](_0xd335c4),_0xd335c4=_0x451b5a['getNext']();return _0x1a7589;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x4dd139,_0x598a79,_0x32d5fd,_0x16332b){return Bo(_0x4dd139['writeTree'],_0x4dd139['treePath'],_0x598a79,_0x32d5fd,_0x16332b);}function is(_0x4a42da,_0x2d2064){return gu(_0x4a42da['writeTree'],_0x4a42da['treePath'],_0x2d2064);}function cr(_0x1a2dc7,_0x313043,_0x1d9b55,_0x4ccb0e){return mu(_0x1a2dc7['writeTree'],_0x1a2dc7['treePath'],_0x313043,_0x1d9b55,_0x4ccb0e);}function Tn(_0x2f594a,_0x23b47d){return vu(_0x2f594a['writeTree'],k(_0x2f594a['treePath'],_0x23b47d));}function wu(_0x360077,_0x40f714,_0xe01f5f,_0x3cdd83,_0x3da9b4,_0x405736){return Eu(_0x360077['writeTree'],_0x360077['treePath'],_0x40f714,_0xe01f5f,_0x3cdd83,_0x3da9b4,_0x405736);}function ss(_0x31ea76,_0x480a6b,_0x5c9ea7){return yu(_0x31ea76['writeTree'],_0x31ea76['treePath'],_0x480a6b,_0x5c9ea7);}function Vo(_0x1aea02,_0xdc47a6){return Ho(k(_0x1aea02['treePath'],_0xdc47a6),_0x1aea02['writeTree']);}function Ho(_0x22088c,_0x532f04){return{'treePath':_0x22088c,'writeTree':_0x532f04};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x38e122){const _0x418075=_0x38e122['type'],_0x593e84=_0x38e122['childName'];f(_0x418075==='child_added'||_0x418075==='child_changed'||_0x418075==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x593e84!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x57e3d7=this['changeMap']['get'](_0x593e84);if(_0x57e3d7){const _0x3be9e6=_0x57e3d7['type'];if(_0x418075==='child_added'&&_0x3be9e6==='child_removed')this['changeMap']['set'](_0x593e84,xt(_0x593e84,_0x38e122['snapshotNode'],_0x57e3d7['snapshotNode']));else{if(_0x418075==='child_removed'&&_0x3be9e6==='child_added')this['changeMap']['delete'](_0x593e84);else{if(_0x418075==='child_removed'&&_0x3be9e6==='child_changed')this['changeMap']['set'](_0x593e84,Lt(_0x593e84,_0x57e3d7['oldSnap']));else{if(_0x418075==='child_changed'&&_0x3be9e6==='child_added')this['changeMap']['set'](_0x593e84,rt(_0x593e84,_0x38e122['snapshotNode']));else{if(_0x418075==='child_changed'&&_0x3be9e6==='child_changed')this['changeMap']['set'](_0x593e84,xt(_0x593e84,_0x38e122['snapshotNode'],_0x57e3d7['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x38e122+'\x20occurred\x20after\x20'+_0x57e3d7);}}}}}else this['changeMap']['set'](_0x593e84,_0x38e122);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x2a0123){return null;}['getChildAfterChild'](_0x165767,_0x5e95b3,_0x21fc89){return null;}}const $o=new Tu();class rs{constructor(_0x4d8c70,_0x11191c,_0xbc07c9=null){this['writes_']=_0x4d8c70,this['viewCache_']=_0x11191c,this['optCompleteServerCache_']=_0xbc07c9;}['getCompleteChild'](_0x529d1d){const _0x462ff4=this['viewCache_']['eventCache'];if(_0x462ff4['isCompleteForChild'](_0x529d1d))return _0x462ff4['getNode']()['getImmediateChild'](_0x529d1d);{const _0x1839e3=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x529d1d,_0x1839e3);}}['getChildAfterChild'](_0x5c070a,_0x519cf5,_0x671315){const _0x10212b=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x2e88ee=wu(this['writes_'],_0x10212b,_0x519cf5,0x1,_0x671315,_0x5c070a);return _0x2e88ee['length']===0x0?null:_0x2e88ee[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x468e5b){return{'filter':_0x468e5b};}function bu(_0x452624,_0xfcd49){f(_0xfcd49['eventCache']['getNode']()['isIndexed'](_0x452624['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xfcd49['serverCache']['getNode']()['isIndexed'](_0x452624['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4644c2,_0xf459f1,_0x3a39f4,_0x3151b7,_0x335365){const _0x3f90af=new Cu();let _0x509ee8,_0x3401f8;if(_0x3a39f4['type']===z['OVERWRITE']){const _0x2ef7c3=_0x3a39f4;_0x2ef7c3['source']['fromUser']?_0x509ee8=ki(_0x4644c2,_0xf459f1,_0x2ef7c3['path'],_0x2ef7c3['snap'],_0x3151b7,_0x335365,_0x3f90af):(f(_0x2ef7c3['source']['fromServer'],'Unknown\x20source.'),_0x3401f8=_0x2ef7c3['source']['tagged']||_0xf459f1['serverCache']['isFiltered']()&&!v(_0x2ef7c3['path']),_0x509ee8=Sn(_0x4644c2,_0xf459f1,_0x2ef7c3['path'],_0x2ef7c3['snap'],_0x3151b7,_0x335365,_0x3401f8,_0x3f90af));}else{if(_0x3a39f4['type']===z['MERGE']){const _0x295b4a=_0x3a39f4;_0x295b4a['source']['fromUser']?_0x509ee8=ku(_0x4644c2,_0xf459f1,_0x295b4a['path'],_0x295b4a['children'],_0x3151b7,_0x335365,_0x3f90af):(f(_0x295b4a['source']['fromServer'],'Unknown\x20source.'),_0x3401f8=_0x295b4a['source']['tagged']||_0xf459f1['serverCache']['isFiltered'](),_0x509ee8=Pi(_0x4644c2,_0xf459f1,_0x295b4a['path'],_0x295b4a['children'],_0x3151b7,_0x335365,_0x3401f8,_0x3f90af));}else{if(_0x3a39f4['type']===z['ACK_USER_WRITE']){const _0x5284c8=_0x3a39f4;_0x5284c8['revert']?_0x509ee8=Ou(_0x4644c2,_0xf459f1,_0x5284c8['path'],_0x3151b7,_0x335365,_0x3f90af):_0x509ee8=Pu(_0x4644c2,_0xf459f1,_0x5284c8['path'],_0x5284c8['affectedTree'],_0x3151b7,_0x335365,_0x3f90af);}else{if(_0x3a39f4['type']===z['LISTEN_COMPLETE'])_0x509ee8=Nu(_0x4644c2,_0xf459f1,_0x3a39f4['path'],_0x3151b7,_0x3f90af);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3a39f4['type']);}}}const _0xbbd400=_0x3f90af['getChanges']();return Au(_0xf459f1,_0x509ee8,_0xbbd400),{'viewCache':_0x509ee8,'changes':_0xbbd400};}function Au(_0x20fd9a,_0x53f71f,_0x4dd446){const _0xd69437=_0x53f71f['eventCache'];if(_0xd69437['isFullyInitialized']()){const _0x42995d=_0xd69437['getNode']()['isLeafNode']()||_0xd69437['getNode']()['isEmpty'](),_0x16a3d3=wn(_0x20fd9a);(_0x4dd446['length']>0x0||!_0x20fd9a['eventCache']['isFullyInitialized']()||_0x42995d&&!_0xd69437['getNode']()['equals'](_0x16a3d3)||!_0xd69437['getNode']()['getPriority']()['equals'](_0x16a3d3['getPriority']()))&&_0x4dd446['push'](Lo(wn(_0x53f71f)));}}function Go(_0x17d7f3,_0x87d36a,_0x1b6db2,_0x489a68,_0x573c34,_0x2baca5){const _0x230904=_0x87d36a['eventCache'];if(Tn(_0x489a68,_0x1b6db2)!=null)return _0x87d36a;{let _0x1d454d,_0x3686a2;if(v(_0x1b6db2)){if(f(_0x87d36a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x87d36a['serverCache']['isFiltered']()){const _0x2c0700=Ve(_0x87d36a),_0x2de42d=_0x2c0700 instanceof g?_0x2c0700:g['EMPTY_NODE'],_0x2ad776=is(_0x489a68,_0x2de42d);_0x1d454d=_0x17d7f3['filter']['updateFullNode'](_0x87d36a['eventCache']['getNode'](),_0x2ad776,_0x2baca5);}else{const _0x2d1544=Cn(_0x489a68,Ve(_0x87d36a));_0x1d454d=_0x17d7f3['filter']['updateFullNode'](_0x87d36a['eventCache']['getNode'](),_0x2d1544,_0x2baca5);}}else{const _0x4d50db=y(_0x1b6db2);if(_0x4d50db==='.priority'){f(Ce(_0x1b6db2)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4461dc=_0x230904['getNode']();_0x3686a2=_0x87d36a['serverCache']['getNode']();const _0xb6cf72=cr(_0x489a68,_0x1b6db2,_0x4461dc,_0x3686a2);_0xb6cf72!=null?_0x1d454d=_0x17d7f3['filter']['updatePriority'](_0x4461dc,_0xb6cf72):_0x1d454d=_0x230904['getNode']();}else{const _0x2400c=S(_0x1b6db2);let _0x3741a1;if(_0x230904['isCompleteForChild'](_0x4d50db)){_0x3686a2=_0x87d36a['serverCache']['getNode']();const _0x1825e4=cr(_0x489a68,_0x1b6db2,_0x230904['getNode'](),_0x3686a2);_0x1825e4!=null?_0x3741a1=_0x230904['getNode']()['getImmediateChild'](_0x4d50db)['updateChild'](_0x2400c,_0x1825e4):_0x3741a1=_0x230904['getNode']()['getImmediateChild'](_0x4d50db);}else _0x3741a1=ss(_0x489a68,_0x4d50db,_0x87d36a['serverCache']);_0x3741a1!=null?_0x1d454d=_0x17d7f3['filter']['updateChild'](_0x230904['getNode'](),_0x4d50db,_0x3741a1,_0x2400c,_0x573c34,_0x2baca5):_0x1d454d=_0x230904['getNode']();}}return Rt(_0x87d36a,_0x1d454d,_0x230904['isFullyInitialized']()||v(_0x1b6db2),_0x17d7f3['filter']['filtersNodes']());}}function Sn(_0xee72fa,_0x23e531,_0x49dfae,_0x315f47,_0x1c88fd,_0x2c1eb5,_0x4babf8,_0x305d5d){const _0x495b4b=_0x23e531['serverCache'];let _0x3e3125;const _0x559bf4=_0x4babf8?_0xee72fa['filter']:_0xee72fa['filter']['getIndexedFilter']();if(v(_0x49dfae))_0x3e3125=_0x559bf4['updateFullNode'](_0x495b4b['getNode'](),_0x315f47,null);else{if(_0x559bf4['filtersNodes']()&&!_0x495b4b['isFiltered']()){const _0x3058e7=_0x495b4b['getNode']()['updateChild'](_0x49dfae,_0x315f47);_0x3e3125=_0x559bf4['updateFullNode'](_0x495b4b['getNode'](),_0x3058e7,null);}else{const _0x23029e=y(_0x49dfae);if(!_0x495b4b['isCompleteForPath'](_0x49dfae)&&Ce(_0x49dfae)>0x1)return _0x23e531;const _0x2a51d7=S(_0x49dfae),_0x3bfd50=_0x495b4b['getNode']()['getImmediateChild'](_0x23029e)['updateChild'](_0x2a51d7,_0x315f47);_0x23029e==='.priority'?_0x3e3125=_0x559bf4['updatePriority'](_0x495b4b['getNode'](),_0x3bfd50):_0x3e3125=_0x559bf4['updateChild'](_0x495b4b['getNode'](),_0x23029e,_0x3bfd50,_0x2a51d7,$o,null);}}const _0x2800c0=Fo(_0x23e531,_0x3e3125,_0x495b4b['isFullyInitialized']()||v(_0x49dfae),_0x559bf4['filtersNodes']()),_0x2eedb2=new rs(_0x1c88fd,_0x2800c0,_0x2c1eb5);return Go(_0xee72fa,_0x2800c0,_0x49dfae,_0x1c88fd,_0x2eedb2,_0x305d5d);}function ki(_0x1c16bb,_0x3d9443,_0x105a97,_0x58c72c,_0x299512,_0x516b80,_0x40da87){const _0x369dee=_0x3d9443['eventCache'];let _0x793c8c,_0x150690;const _0x5aa028=new rs(_0x299512,_0x3d9443,_0x516b80);if(v(_0x105a97))_0x150690=_0x1c16bb['filter']['updateFullNode'](_0x3d9443['eventCache']['getNode'](),_0x58c72c,_0x40da87),_0x793c8c=Rt(_0x3d9443,_0x150690,!0x0,_0x1c16bb['filter']['filtersNodes']());else{const _0x43a943=y(_0x105a97);if(_0x43a943==='.priority')_0x150690=_0x1c16bb['filter']['updatePriority'](_0x3d9443['eventCache']['getNode'](),_0x58c72c),_0x793c8c=Rt(_0x3d9443,_0x150690,_0x369dee['isFullyInitialized'](),_0x369dee['isFiltered']());else{const _0x3e1841=S(_0x105a97),_0x46951d=_0x369dee['getNode']()['getImmediateChild'](_0x43a943);let _0x41a290;if(v(_0x3e1841))_0x41a290=_0x58c72c;else{const _0x46c154=_0x5aa028['getCompleteChild'](_0x43a943);_0x46c154!=null?ji(_0x3e1841)==='.priority'&&_0x46c154['getChild'](Ro(_0x3e1841))['isEmpty']()?_0x41a290=_0x46c154:_0x41a290=_0x46c154['updateChild'](_0x3e1841,_0x58c72c):_0x41a290=g['EMPTY_NODE'];}if(_0x46951d['equals'](_0x41a290))_0x793c8c=_0x3d9443;else{const _0x40bb76=_0x1c16bb['filter']['updateChild'](_0x369dee['getNode'](),_0x43a943,_0x41a290,_0x3e1841,_0x5aa028,_0x40da87);_0x793c8c=Rt(_0x3d9443,_0x40bb76,_0x369dee['isFullyInitialized'](),_0x1c16bb['filter']['filtersNodes']());}}}return _0x793c8c;}function lr(_0x4e11f3,_0x3883f9){return _0x4e11f3['eventCache']['isCompleteForChild'](_0x3883f9);}function ku(_0x1ee8af,_0x57a3f1,_0x1f684e,_0x45eb39,_0x587638,_0x1026a5,_0x309986){let _0x3b23ff=_0x57a3f1;return _0x45eb39['foreach']((_0x31307f,_0x6fa861)=>{const _0x2c63d7=k(_0x1f684e,_0x31307f);lr(_0x57a3f1,y(_0x2c63d7))&&(_0x3b23ff=ki(_0x1ee8af,_0x3b23ff,_0x2c63d7,_0x6fa861,_0x587638,_0x1026a5,_0x309986));}),_0x45eb39['foreach']((_0x761a9d,_0x29bbc0)=>{const _0x5881d4=k(_0x1f684e,_0x761a9d);lr(_0x57a3f1,y(_0x5881d4))||(_0x3b23ff=ki(_0x1ee8af,_0x3b23ff,_0x5881d4,_0x29bbc0,_0x587638,_0x1026a5,_0x309986));}),_0x3b23ff;}function hr(_0x1bb825,_0x3fd57d,_0x2a57f7){return _0x2a57f7['foreach']((_0x427b6a,_0x1cb78f)=>{_0x3fd57d=_0x3fd57d['updateChild'](_0x427b6a,_0x1cb78f);}),_0x3fd57d;}function Pi(_0x1e30a6,_0x214f88,_0x27fe71,_0x244e6f,_0x1251c0,_0x3cb571,_0x13bd2f,_0x5019d1){if(_0x214f88['serverCache']['getNode']()['isEmpty']()&&!_0x214f88['serverCache']['isFullyInitialized']())return _0x214f88;let _0x4840bf=_0x214f88,_0x16edc6;v(_0x27fe71)?_0x16edc6=_0x244e6f:_0x16edc6=new b(null)['setTree'](_0x27fe71,_0x244e6f);const _0x2f7244=_0x214f88['serverCache']['getNode']();return _0x16edc6['children']['inorderTraversal']((_0x434031,_0x3088d0)=>{if(_0x2f7244['hasChild'](_0x434031)){const _0x46945c=_0x214f88['serverCache']['getNode']()['getImmediateChild'](_0x434031),_0x535039=hr(_0x1e30a6,_0x46945c,_0x3088d0);_0x4840bf=Sn(_0x1e30a6,_0x4840bf,new C(_0x434031),_0x535039,_0x1251c0,_0x3cb571,_0x13bd2f,_0x5019d1);}}),_0x16edc6['children']['inorderTraversal']((_0x1dabe,_0xf34714)=>{const _0x2fbc2a=!_0x214f88['serverCache']['isCompleteForChild'](_0x1dabe)&&_0xf34714['value']===null;if(!_0x2f7244['hasChild'](_0x1dabe)&&!_0x2fbc2a){const _0x188e5d=_0x214f88['serverCache']['getNode']()['getImmediateChild'](_0x1dabe),_0xb3e9c3=hr(_0x1e30a6,_0x188e5d,_0xf34714);_0x4840bf=Sn(_0x1e30a6,_0x4840bf,new C(_0x1dabe),_0xb3e9c3,_0x1251c0,_0x3cb571,_0x13bd2f,_0x5019d1);}}),_0x4840bf;}function Pu(_0x583b0c,_0x4406a4,_0xdfd02b,_0x5cf824,_0x5ba662,_0x55e625,_0x56207d){if(Tn(_0x5ba662,_0xdfd02b)!=null)return _0x4406a4;const _0x5ca3ad=_0x4406a4['serverCache']['isFiltered'](),_0x3d9b16=_0x4406a4['serverCache'];if(_0x5cf824['value']!=null){if(v(_0xdfd02b)&&_0x3d9b16['isFullyInitialized']()||_0x3d9b16['isCompleteForPath'](_0xdfd02b))return Sn(_0x583b0c,_0x4406a4,_0xdfd02b,_0x3d9b16['getNode']()['getChild'](_0xdfd02b),_0x5ba662,_0x55e625,_0x5ca3ad,_0x56207d);if(v(_0xdfd02b)){let _0x208cdd=new b(null);return _0x3d9b16['getNode']()['forEachChild'](ve,(_0x1bfa97,_0x587a6e)=>{_0x208cdd=_0x208cdd['set'](new C(_0x1bfa97),_0x587a6e);}),Pi(_0x583b0c,_0x4406a4,_0xdfd02b,_0x208cdd,_0x5ba662,_0x55e625,_0x5ca3ad,_0x56207d);}else return _0x4406a4;}else{let _0x2ba35d=new b(null);return _0x5cf824['foreach']((_0x5dc840,_0x3ef08a)=>{const _0x2302f4=k(_0xdfd02b,_0x5dc840);_0x3d9b16['isCompleteForPath'](_0x2302f4)&&(_0x2ba35d=_0x2ba35d['set'](_0x5dc840,_0x3d9b16['getNode']()['getChild'](_0x2302f4)));}),Pi(_0x583b0c,_0x4406a4,_0xdfd02b,_0x2ba35d,_0x5ba662,_0x55e625,_0x5ca3ad,_0x56207d);}}function Nu(_0x2c4789,_0x1c3241,_0x28cdde,_0x41b066,_0x799717){const _0x4030a8=_0x1c3241['serverCache'],_0x360eb1=Fo(_0x1c3241,_0x4030a8['getNode'](),_0x4030a8['isFullyInitialized']()||v(_0x28cdde),_0x4030a8['isFiltered']());return Go(_0x2c4789,_0x360eb1,_0x28cdde,_0x41b066,$o,_0x799717);}function Ou(_0x3ac535,_0xefaffc,_0x2d5636,_0x50d016,_0x484ddc,_0x1bc952){let _0x3b5849;if(Tn(_0x50d016,_0x2d5636)!=null)return _0xefaffc;{const _0x3203f8=new rs(_0x50d016,_0xefaffc,_0x484ddc),_0x31cad6=_0xefaffc['eventCache']['getNode']();let _0x533aca;if(v(_0x2d5636)||y(_0x2d5636)==='.priority'){let _0x384d6e;if(_0xefaffc['serverCache']['isFullyInitialized']())_0x384d6e=Cn(_0x50d016,Ve(_0xefaffc));else{const _0x1be50d=_0xefaffc['serverCache']['getNode']();f(_0x1be50d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x384d6e=is(_0x50d016,_0x1be50d);}_0x384d6e=_0x384d6e,_0x533aca=_0x3ac535['filter']['updateFullNode'](_0x31cad6,_0x384d6e,_0x1bc952);}else{const _0x31a01c=y(_0x2d5636);let _0x5f2436=ss(_0x50d016,_0x31a01c,_0xefaffc['serverCache']);_0x5f2436==null&&_0xefaffc['serverCache']['isCompleteForChild'](_0x31a01c)&&(_0x5f2436=_0x31cad6['getImmediateChild'](_0x31a01c)),_0x5f2436!=null?_0x533aca=_0x3ac535['filter']['updateChild'](_0x31cad6,_0x31a01c,_0x5f2436,S(_0x2d5636),_0x3203f8,_0x1bc952):_0xefaffc['eventCache']['getNode']()['hasChild'](_0x31a01c)?_0x533aca=_0x3ac535['filter']['updateChild'](_0x31cad6,_0x31a01c,g['EMPTY_NODE'],S(_0x2d5636),_0x3203f8,_0x1bc952):_0x533aca=_0x31cad6,_0x533aca['isEmpty']()&&_0xefaffc['serverCache']['isFullyInitialized']()&&(_0x3b5849=Cn(_0x50d016,Ve(_0xefaffc)),_0x3b5849['isLeafNode']()&&(_0x533aca=_0x3ac535['filter']['updateFullNode'](_0x533aca,_0x3b5849,_0x1bc952)));}return _0x3b5849=_0xefaffc['serverCache']['isFullyInitialized']()||Tn(_0x50d016,w())!=null,Rt(_0xefaffc,_0x533aca,_0x3b5849,_0x3ac535['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4c41eb,_0x34be92){this['query_']=_0x4c41eb,this['eventRegistrations_']=[];const _0x44468d=this['query_']['_queryParams'],_0x4d87dc=new Xi(_0x44468d['getIndex']()),_0x95572d=Kh(_0x44468d);this['processor_']=Su(_0x95572d);const _0x2ae0b4=_0x34be92['serverCache'],_0x33d4d6=_0x34be92['eventCache'],_0x295dbe=_0x4d87dc['updateFullNode'](g['EMPTY_NODE'],_0x2ae0b4['getNode'](),null),_0x1d213f=_0x95572d['updateFullNode'](g['EMPTY_NODE'],_0x33d4d6['getNode'](),null),_0x21377f=new Te(_0x295dbe,_0x2ae0b4['isFullyInitialized'](),_0x4d87dc['filtersNodes']()),_0x496358=new Te(_0x1d213f,_0x33d4d6['isFullyInitialized'](),_0x95572d['filtersNodes']());this['viewCache_']=Un(_0x496358,_0x21377f),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x58f38f){return _0x58f38f['viewCache_']['serverCache']['getNode']();}function Lu(_0x5ad1f9){return wn(_0x5ad1f9['viewCache_']);}function xu(_0x4d6273,_0x381cf5){const _0x8d3c70=Ve(_0x4d6273['viewCache_']);return _0x8d3c70&&(_0x4d6273['query']['_queryParams']['loadsAllData']()||!v(_0x381cf5)&&!_0x8d3c70['getImmediateChild'](y(_0x381cf5))['isEmpty']())?_0x8d3c70['getChild'](_0x381cf5):null;}function ur(_0x55d134){return _0x55d134['eventRegistrations_']['length']===0x0;}function Fu(_0x53c52f,_0x5df6a9){_0x53c52f['eventRegistrations_']['push'](_0x5df6a9);}function dr(_0x1c440a,_0x158b6e,_0x3d4a7c){const _0x5d44b5=[];if(_0x3d4a7c){f(_0x158b6e==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1fdd1c=_0x1c440a['query']['_path'];_0x1c440a['eventRegistrations_']['forEach'](_0x8ad8d8=>{const _0x50b1db=_0x8ad8d8['createCancelEvent'](_0x3d4a7c,_0x1fdd1c);_0x50b1db&&_0x5d44b5['push'](_0x50b1db);});}if(_0x158b6e){let _0x57aaf0=[];for(let _0x3e56f2=0x0;_0x3e56f2<_0x1c440a['eventRegistrations_']['length'];++_0x3e56f2){const _0x1de161=_0x1c440a['eventRegistrations_'][_0x3e56f2];if(!_0x1de161['matches'](_0x158b6e))_0x57aaf0['push'](_0x1de161);else{if(_0x158b6e['hasAnyCallback']()){_0x57aaf0=_0x57aaf0['concat'](_0x1c440a['eventRegistrations_']['slice'](_0x3e56f2+0x1));break;}}}_0x1c440a['eventRegistrations_']=_0x57aaf0;}else _0x1c440a['eventRegistrations_']=[];return _0x5d44b5;}function fr(_0x21168e,_0x284d58,_0x231b79,_0x4294b7){_0x284d58['type']===z['MERGE']&&_0x284d58['source']['queryId']!==null&&(f(Ve(_0x21168e['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x21168e['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x152edb=_0x21168e['viewCache_'],_0x7fa660=Ru(_0x21168e['processor_'],_0x152edb,_0x284d58,_0x231b79,_0x4294b7);return bu(_0x21168e['processor_'],_0x7fa660['viewCache']),f(_0x7fa660['viewCache']['serverCache']['isFullyInitialized']()||!_0x152edb['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x21168e['viewCache_']=_0x7fa660['viewCache'],qo(_0x21168e,_0x7fa660['changes'],_0x7fa660['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x1ad9ca,_0x1cf43d){const _0x576064=_0x1ad9ca['viewCache_']['eventCache'],_0x1f0e66=[];return _0x576064['getNode']()['isLeafNode']()||_0x576064['getNode']()['forEachChild'](R,(_0x546b43,_0x39ad8f)=>{_0x1f0e66['push'](rt(_0x546b43,_0x39ad8f));}),_0x576064['isFullyInitialized']()&&_0x1f0e66['push'](Lo(_0x576064['getNode']())),qo(_0x1ad9ca,_0x1f0e66,_0x576064['getNode'](),_0x1cf43d);}function qo(_0x2999d2,_0x3d629c,_0x1ea5bf,_0x2e5dd7){const _0x3e8fa6=_0x2e5dd7?[_0x2e5dd7]:_0x2999d2['eventRegistrations_'];return ru(_0x2999d2['eventGenerator_'],_0x3d629c,_0x1ea5bf,_0x3e8fa6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x4e0fc2){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x4e0fc2;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3ddbce){return _0x3ddbce['views']['size']===0x0;}function os(_0x1cfa26,_0x3da352,_0x5f2880,_0x255544){const _0x3e8e68=_0x3da352['source']['queryId'];if(_0x3e8e68!==null){const _0x5c9e2c=_0x1cfa26['views']['get'](_0x3e8e68);return f(_0x5c9e2c!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x5c9e2c,_0x3da352,_0x5f2880,_0x255544);}else{let _0x5dfe4c=[];for(const _0x5b10bc of _0x1cfa26['views']['values']())_0x5dfe4c=_0x5dfe4c['concat'](fr(_0x5b10bc,_0x3da352,_0x5f2880,_0x255544));return _0x5dfe4c;}}function jo(_0x43f7b1,_0x9d7340,_0x315836,_0x5d02c0,_0x3d6934){const _0x118074=_0x9d7340['_queryIdentifier'],_0x48debe=_0x43f7b1['views']['get'](_0x118074);if(!_0x48debe){let _0x1c7494=Cn(_0x315836,_0x3d6934?_0x5d02c0:null),_0x357fcc=!0x1;_0x1c7494?_0x357fcc=!0x0:_0x5d02c0 instanceof g?(_0x1c7494=is(_0x315836,_0x5d02c0),_0x357fcc=!0x1):(_0x1c7494=g['EMPTY_NODE'],_0x357fcc=!0x1);const _0x5937f3=Un(new Te(_0x1c7494,_0x357fcc,!0x1),new Te(_0x5d02c0,_0x3d6934,!0x1));return new Du(_0x9d7340,_0x5937f3);}return _0x48debe;}function Hu(_0x351b70,_0x47cc3d,_0x3e7657,_0x3c4dbf,_0x12de8d,_0x376957){const _0x417365=jo(_0x351b70,_0x47cc3d,_0x3c4dbf,_0x12de8d,_0x376957);return _0x351b70['views']['has'](_0x47cc3d['_queryIdentifier'])||_0x351b70['views']['set'](_0x47cc3d['_queryIdentifier'],_0x417365),Fu(_0x417365,_0x3e7657),Uu(_0x417365,_0x3e7657);}function $u(_0x1281f5,_0x378dc8,_0x3c4442,_0x1d98fc){const _0xe09141=_0x378dc8['_queryIdentifier'],_0x542a9c=[];let _0x2d6eb4=[];const _0x2c50f4=Se(_0x1281f5);if(_0xe09141==='default'){for(const [_0x24b8fb,_0x24ef04]of _0x1281f5['views']['entries']())_0x2d6eb4=_0x2d6eb4['concat'](dr(_0x24ef04,_0x3c4442,_0x1d98fc)),ur(_0x24ef04)&&(_0x1281f5['views']['delete'](_0x24b8fb),_0x24ef04['query']['_queryParams']['loadsAllData']()||_0x542a9c['push'](_0x24ef04['query']));}else{const _0x2202e1=_0x1281f5['views']['get'](_0xe09141);_0x2202e1&&(_0x2d6eb4=_0x2d6eb4['concat'](dr(_0x2202e1,_0x3c4442,_0x1d98fc)),ur(_0x2202e1)&&(_0x1281f5['views']['delete'](_0xe09141),_0x2202e1['query']['_queryParams']['loadsAllData']()||_0x542a9c['push'](_0x2202e1['query'])));}return _0x2c50f4&&!Se(_0x1281f5)&&_0x542a9c['push'](new(Bu())(_0x378dc8['_repo'],_0x378dc8['_path'])),{'removed':_0x542a9c,'events':_0x2d6eb4};}function Ko(_0x1f3e3d){const _0x3c1a74=[];for(const _0x11244d of _0x1f3e3d['views']['values']())_0x11244d['query']['_queryParams']['loadsAllData']()||_0x3c1a74['push'](_0x11244d);return _0x3c1a74;}function Ie(_0x138358,_0x42e3df){let _0x57d7ad=null;for(const _0x135166 of _0x138358['views']['values']())_0x57d7ad=_0x57d7ad||xu(_0x135166,_0x42e3df);return _0x57d7ad;}function Yo(_0x330476,_0x4caeba){if(_0x4caeba['_queryParams']['loadsAllData']())return Bn(_0x330476);{const _0x441928=_0x4caeba['_queryIdentifier'];return _0x330476['views']['get'](_0x441928);}}function Qo(_0x621f,_0x44881e){return Yo(_0x621f,_0x44881e)!=null;}function Se(_0x18b673){return Bn(_0x18b673)!=null;}function Bn(_0x406bd6){for(const _0x22ebc2 of _0x406bd6['views']['values']())if(_0x22ebc2['query']['_queryParams']['loadsAllData']())return _0x22ebc2;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x78aa00){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x78aa00;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x190c09){this['listenProvider_']=_0x190c09,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x3d9c81,_0x3da0a8,_0x4a296d,_0x59be99,_0x2bfec7){return lu(_0x3d9c81['pendingWriteTree_'],_0x3da0a8,_0x4a296d,_0x59be99,_0x2bfec7),_0x2bfec7?_t(_0x3d9c81,new Be(es(),_0x3da0a8,_0x4a296d)):[];}function ju(_0x42ce15,_0x41ae62,_0x5e2f9a,_0x180a8a){hu(_0x42ce15['pendingWriteTree_'],_0x41ae62,_0x5e2f9a,_0x180a8a);const _0x5195ec=b['fromObject'](_0x5e2f9a);return _t(_0x42ce15,new ot(es(),_0x41ae62,_0x5195ec));}function _e(_0x2ebf97,_0x1e0280,_0x3f99e4=!0x1){const _0x5c8f8d=uu(_0x2ebf97['pendingWriteTree_'],_0x1e0280);if(du(_0x2ebf97['pendingWriteTree_'],_0x1e0280)){let _0x17bec3=new b(null);return _0x5c8f8d['snap']!=null?_0x17bec3=_0x17bec3['set'](w(),!0x0):x(_0x5c8f8d['children'],_0x2901bc=>{_0x17bec3=_0x17bec3['set'](new C(_0x2901bc),!0x0);}),_t(_0x2ebf97,new In(_0x5c8f8d['path'],_0x17bec3,_0x3f99e4));}else return[];}function Yt(_0x47dfd9,_0x463b40,_0x465b8b){return _t(_0x47dfd9,new Be(ts(),_0x463b40,_0x465b8b));}function Ku(_0x25ef96,_0x4d3196,_0x26ca47){const _0xb9d0c5=b['fromObject'](_0x26ca47);return _t(_0x25ef96,new ot(ts(),_0x4d3196,_0xb9d0c5));}function Yu(_0x4ee93b,_0x33124a){return _t(_0x4ee93b,new Ut(ts(),_0x33124a));}function Qu(_0x5b9563,_0x5913dc,_0x3783d0){const _0x3e3ea6=cs(_0x5b9563,_0x3783d0);if(_0x3e3ea6){const _0x372d4b=ls(_0x3e3ea6),_0x407a73=_0x372d4b['path'],_0x40bf1e=_0x372d4b['queryId'],_0x135e77=F(_0x407a73,_0x5913dc),_0x5cc5bd=new Ut(ns(_0x40bf1e),_0x135e77);return hs(_0x5b9563,_0x407a73,_0x5cc5bd);}else return[];}function An(_0xa4cc10,_0x32f306,_0x2b50b4,_0x4da165,_0x16244f=!0x1){const _0xad0e99=_0x32f306['_path'],_0x1b0bb1=_0xa4cc10['syncPointTree_']['get'](_0xad0e99);let _0x511670=[];if(_0x1b0bb1&&(_0x32f306['_queryIdentifier']==='default'||Qo(_0x1b0bb1,_0x32f306))){const _0x3e79ec=$u(_0x1b0bb1,_0x32f306,_0x2b50b4,_0x4da165);Vu(_0x1b0bb1)&&(_0xa4cc10['syncPointTree_']=_0xa4cc10['syncPointTree_']['remove'](_0xad0e99));const _0x45da7f=_0x3e79ec['removed'];if(_0x511670=_0x3e79ec['events'],!_0x16244f){const _0x1d4ac1=_0x45da7f['findIndex'](_0x5d8de4=>_0x5d8de4['_queryParams']['loadsAllData']())!==-0x1,_0x15b1ea=_0xa4cc10['syncPointTree_']['findOnPath'](_0xad0e99,(_0x346e7c,_0x21a491)=>Se(_0x21a491));if(_0x1d4ac1&&!_0x15b1ea){const _0x3a44ee=_0xa4cc10['syncPointTree_']['subtree'](_0xad0e99);if(!_0x3a44ee['isEmpty']()){const _0x34ecca=Zu(_0x3a44ee);for(let _0x85ec0a=0x0;_0x85ec0a<_0x34ecca['length'];++_0x85ec0a){const _0x93ebae=_0x34ecca[_0x85ec0a],_0x5519bd=_0x93ebae['query'],_0x539459=ea(_0xa4cc10,_0x93ebae);_0xa4cc10['listenProvider_']['startListening'](kt(_0x5519bd),Wt(_0xa4cc10,_0x5519bd),_0x539459['hashFn'],_0x539459['onComplete']);}}}!_0x15b1ea&&_0x45da7f['length']>0x0&&!_0x4da165&&(_0x1d4ac1?_0xa4cc10['listenProvider_']['stopListening'](kt(_0x32f306),null):_0x45da7f['forEach'](_0x3196dd=>{const _0x514887=_0xa4cc10['queryToTagMap']['get'](Hn(_0x3196dd));_0xa4cc10['listenProvider_']['stopListening'](kt(_0x3196dd),_0x514887);}));}ed(_0xa4cc10,_0x45da7f);}return _0x511670;}function Jo(_0x5532b9,_0x14d94d,_0x1574c3,_0x474648){const _0xb2f89c=cs(_0x5532b9,_0x474648);if(_0xb2f89c!=null){const _0x484386=ls(_0xb2f89c),_0x5ab6a0=_0x484386['path'],_0x576a8b=_0x484386['queryId'],_0x29bfc6=F(_0x5ab6a0,_0x14d94d),_0xf3c375=new Be(ns(_0x576a8b),_0x29bfc6,_0x1574c3);return hs(_0x5532b9,_0x5ab6a0,_0xf3c375);}else return[];}function Ju(_0xefeb4c,_0x3401b7,_0xe6eb97,_0x220a6b){const _0x585b57=cs(_0xefeb4c,_0x220a6b);if(_0x585b57){const _0x132d11=ls(_0x585b57),_0x4003f3=_0x132d11['path'],_0x8e2256=_0x132d11['queryId'],_0x3835c7=F(_0x4003f3,_0x3401b7),_0x270662=b['fromObject'](_0xe6eb97),_0x92b65f=new ot(ns(_0x8e2256),_0x3835c7,_0x270662);return hs(_0xefeb4c,_0x4003f3,_0x92b65f);}else return[];}function Ni(_0x53cea2,_0xee375b,_0x3319d9,_0x528acd=!0x1){const _0x5b4119=_0xee375b['_path'];let _0x4b5ca6=null,_0x12f574=!0x1;_0x53cea2['syncPointTree_']['foreachOnPath'](_0x5b4119,(_0x34c2a2,_0xa926d0)=>{const _0x57c79=F(_0x34c2a2,_0x5b4119);_0x4b5ca6=_0x4b5ca6||Ie(_0xa926d0,_0x57c79),_0x12f574=_0x12f574||Se(_0xa926d0);});let _0x2378d9=_0x53cea2['syncPointTree_']['get'](_0x5b4119);_0x2378d9?(_0x12f574=_0x12f574||Se(_0x2378d9),_0x4b5ca6=_0x4b5ca6||Ie(_0x2378d9,w())):(_0x2378d9=new zo(),_0x53cea2['syncPointTree_']=_0x53cea2['syncPointTree_']['set'](_0x5b4119,_0x2378d9));let _0x197f3e;_0x4b5ca6!=null?_0x197f3e=!0x0:(_0x197f3e=!0x1,_0x4b5ca6=g['EMPTY_NODE'],_0x53cea2['syncPointTree_']['subtree'](_0x5b4119)['foreachChild']((_0x681af9,_0x18f42e)=>{const _0x5251f9=Ie(_0x18f42e,w());_0x5251f9&&(_0x4b5ca6=_0x4b5ca6['updateImmediateChild'](_0x681af9,_0x5251f9));}));const _0x4bd97a=Qo(_0x2378d9,_0xee375b);if(!_0x4bd97a&&!_0xee375b['_queryParams']['loadsAllData']()){const _0x38d2fb=Hn(_0xee375b);f(!_0x53cea2['queryToTagMap']['has'](_0x38d2fb),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x222d34=td();_0x53cea2['queryToTagMap']['set'](_0x38d2fb,_0x222d34),_0x53cea2['tagToQueryMap']['set'](_0x222d34,_0x38d2fb);}const _0x493947=Wn(_0x53cea2['pendingWriteTree_'],_0x5b4119);let _0x19191c=Hu(_0x2378d9,_0xee375b,_0x3319d9,_0x493947,_0x4b5ca6,_0x197f3e);if(!_0x4bd97a&&!_0x12f574&&!_0x528acd){const _0xec3931=Yo(_0x2378d9,_0xee375b);_0x19191c=_0x19191c['concat'](nd(_0x53cea2,_0xee375b,_0xec3931));}return _0x19191c;}function Vn(_0xae22b5,_0x2065e8,_0x1ed11d){const _0x3ab9e8=_0xae22b5['pendingWriteTree_'],_0x7450d3=_0xae22b5['syncPointTree_']['findOnPath'](_0x2065e8,(_0x3a24a9,_0x62a708)=>{const _0x25eb9a=F(_0x3a24a9,_0x2065e8),_0xf4939e=Ie(_0x62a708,_0x25eb9a);if(_0xf4939e)return _0xf4939e;});return Bo(_0x3ab9e8,_0x2065e8,_0x7450d3,_0x1ed11d,!0x0);}function Xu(_0xc3a53d,_0x2db21e){const _0x328fa5=_0x2db21e['_path'];let _0x7be479=null;_0xc3a53d['syncPointTree_']['foreachOnPath'](_0x328fa5,(_0x41a39d,_0x5dafa9)=>{const _0x38ee6c=F(_0x41a39d,_0x328fa5);_0x7be479=_0x7be479||Ie(_0x5dafa9,_0x38ee6c);});let _0x477774=_0xc3a53d['syncPointTree_']['get'](_0x328fa5);_0x477774?_0x7be479=_0x7be479||Ie(_0x477774,w()):(_0x477774=new zo(),_0xc3a53d['syncPointTree_']=_0xc3a53d['syncPointTree_']['set'](_0x328fa5,_0x477774));const _0x17f6ef=_0x7be479!=null,_0x17cfb8=_0x17f6ef?new Te(_0x7be479,!0x0,!0x1):null,_0x34ea4e=Wn(_0xc3a53d['pendingWriteTree_'],_0x2db21e['_path']),_0x461bba=jo(_0x477774,_0x2db21e,_0x34ea4e,_0x17f6ef?_0x17cfb8['getNode']():g['EMPTY_NODE'],_0x17f6ef);return Lu(_0x461bba);}function _t(_0x5e180a,_0x26b674){return Xo(_0x26b674,_0x5e180a['syncPointTree_'],null,Wn(_0x5e180a['pendingWriteTree_'],w()));}function Xo(_0x2ef19c,_0x2fd57f,_0x4b2a27,_0x5974a5){if(v(_0x2ef19c['path']))return Zo(_0x2ef19c,_0x2fd57f,_0x4b2a27,_0x5974a5);{const _0x375579=_0x2fd57f['get'](w());_0x4b2a27==null&&_0x375579!=null&&(_0x4b2a27=Ie(_0x375579,w()));let _0x978f01=[];const _0x31f240=y(_0x2ef19c['path']),_0x21abb5=_0x2ef19c['operationForChild'](_0x31f240),_0x3356e7=_0x2fd57f['children']['get'](_0x31f240);if(_0x3356e7&&_0x21abb5){const _0x2b9692=_0x4b2a27?_0x4b2a27['getImmediateChild'](_0x31f240):null,_0x59f49e=Vo(_0x5974a5,_0x31f240);_0x978f01=_0x978f01['concat'](Xo(_0x21abb5,_0x3356e7,_0x2b9692,_0x59f49e));}return _0x375579&&(_0x978f01=_0x978f01['concat'](os(_0x375579,_0x2ef19c,_0x5974a5,_0x4b2a27))),_0x978f01;}}function Zo(_0x48018e,_0x5993ee,_0x192fae,_0x5d8e81){const _0x19a7a7=_0x5993ee['get'](w());_0x192fae==null&&_0x19a7a7!=null&&(_0x192fae=Ie(_0x19a7a7,w()));let _0x5c1d65=[];return _0x5993ee['children']['inorderTraversal']((_0x35a719,_0x28906c)=>{const _0x48a248=_0x192fae?_0x192fae['getImmediateChild'](_0x35a719):null,_0x30737f=Vo(_0x5d8e81,_0x35a719),_0x2731f1=_0x48018e['operationForChild'](_0x35a719);_0x2731f1&&(_0x5c1d65=_0x5c1d65['concat'](Zo(_0x2731f1,_0x28906c,_0x48a248,_0x30737f)));}),_0x19a7a7&&(_0x5c1d65=_0x5c1d65['concat'](os(_0x19a7a7,_0x48018e,_0x5d8e81,_0x192fae))),_0x5c1d65;}function ea(_0x477f98,_0x481e69){const _0x3765b6=_0x481e69['query'],_0x2f22d7=Wt(_0x477f98,_0x3765b6);return{'hashFn':()=>(Mu(_0x481e69)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x50af11=>{if(_0x50af11==='ok')return _0x2f22d7?Qu(_0x477f98,_0x3765b6['_path'],_0x2f22d7):Yu(_0x477f98,_0x3765b6['_path']);{const _0x2f7de5=Kl(_0x50af11,_0x3765b6);return An(_0x477f98,_0x3765b6,null,_0x2f7de5);}}};}function Wt(_0x18a620,_0x334876){const _0x49e987=Hn(_0x334876);return _0x18a620['queryToTagMap']['get'](_0x49e987);}function Hn(_0x3ae601){return _0x3ae601['_path']['toString']()+'$'+_0x3ae601['_queryIdentifier'];}function cs(_0x70d329,_0x3ddf5c){return _0x70d329['tagToQueryMap']['get'](_0x3ddf5c);}function ls(_0x22527){const _0x8dae2b=_0x22527['indexOf']('$');return f(_0x8dae2b!==-0x1&&_0x8dae2b<_0x22527['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x22527['substr'](_0x8dae2b+0x1),'path':new C(_0x22527['substr'](0x0,_0x8dae2b))};}function hs(_0x14326e,_0x505392,_0x40eb35){const _0x90d47c=_0x14326e['syncPointTree_']['get'](_0x505392);f(_0x90d47c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x247b8a=Wn(_0x14326e['pendingWriteTree_'],_0x505392);return os(_0x90d47c,_0x40eb35,_0x247b8a,null);}function Zu(_0x2473cb){return _0x2473cb['fold']((_0x4cc4a9,_0xf48514,_0x19c06f)=>{if(_0xf48514&&Se(_0xf48514))return[Bn(_0xf48514)];{let _0x26143a=[];return _0xf48514&&(_0x26143a=Ko(_0xf48514)),x(_0x19c06f,(_0x31918e,_0x1b7708)=>{_0x26143a=_0x26143a['concat'](_0x1b7708);}),_0x26143a;}});}function kt(_0x28bdab){return _0x28bdab['_queryParams']['loadsAllData']()&&!_0x28bdab['_queryParams']['isDefault']()?new(qu())(_0x28bdab['_repo'],_0x28bdab['_path']):_0x28bdab;}function ed(_0x4d6aaf,_0x393e0){for(let _0x19dcd0=0x0;_0x19dcd0<_0x393e0['length'];++_0x19dcd0){const _0x1faeb9=_0x393e0[_0x19dcd0];if(!_0x1faeb9['_queryParams']['loadsAllData']()){const _0x1cb7bd=Hn(_0x1faeb9),_0x6540af=_0x4d6aaf['queryToTagMap']['get'](_0x1cb7bd);_0x4d6aaf['queryToTagMap']['delete'](_0x1cb7bd),_0x4d6aaf['tagToQueryMap']['delete'](_0x6540af);}}}function td(){return zu++;}function nd(_0x30c93a,_0x362ace,_0x17faa6){const _0x1a5b2=_0x362ace['_path'],_0x24b08f=Wt(_0x30c93a,_0x362ace),_0x13ea48=ea(_0x30c93a,_0x17faa6),_0xd6fedd=_0x30c93a['listenProvider_']['startListening'](kt(_0x362ace),_0x24b08f,_0x13ea48['hashFn'],_0x13ea48['onComplete']),_0x1cbbfe=_0x30c93a['syncPointTree_']['subtree'](_0x1a5b2);if(_0x24b08f)f(!Se(_0x1cbbfe['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5111b1=_0x1cbbfe['fold']((_0x30e9b2,_0x54f133,_0xe2ce77)=>{if(!v(_0x30e9b2)&&_0x54f133&&Se(_0x54f133))return[Bn(_0x54f133)['query']];{let _0x40bc6d=[];return _0x54f133&&(_0x40bc6d=_0x40bc6d['concat'](Ko(_0x54f133)['map'](_0x5c099a=>_0x5c099a['query']))),x(_0xe2ce77,(_0xfc58e1,_0x27932e)=>{_0x40bc6d=_0x40bc6d['concat'](_0x27932e);}),_0x40bc6d;}});for(let _0x391064=0x0;_0x391064<_0x5111b1['length'];++_0x391064){const _0x3c6111=_0x5111b1[_0x391064];_0x30c93a['listenProvider_']['stopListening'](kt(_0x3c6111),Wt(_0x30c93a,_0x3c6111));}}return _0xd6fedd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x5027bf){this['node_']=_0x5027bf;}['getImmediateChild'](_0x6f9c8){const _0x57d5ed=this['node_']['getImmediateChild'](_0x6f9c8);return new us(_0x57d5ed);}['node'](){return this['node_'];}}class ds{constructor(_0x2c793f,_0x420f61){this['syncTree_']=_0x2c793f,this['path_']=_0x420f61;}['getImmediateChild'](_0x560664){const _0x1fbddd=k(this['path_'],_0x560664);return new ds(this['syncTree_'],_0x1fbddd);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x5948b6){return _0x5948b6=_0x5948b6||{},_0x5948b6['timestamp']=_0x5948b6['timestamp']||new Date()['getTime'](),_0x5948b6;},_r=function(_0x59ae28,_0x125678,_0x1714f4){if(!_0x59ae28||typeof _0x59ae28!='object')return _0x59ae28;if(f('.sv'in _0x59ae28,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x59ae28['.sv']=='string')return sd(_0x59ae28['.sv'],_0x125678,_0x1714f4);if(typeof _0x59ae28['.sv']=='object')return rd(_0x59ae28['.sv'],_0x125678);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x59ae28,null,0x2));},sd=function(_0x5a4078,_0x55f844,_0x16da49){switch(_0x5a4078){case'timestamp':return _0x16da49['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x5a4078);}},rd=function(_0x1b8f4e,_0x1ed84a,_0x2fff5c){_0x1b8f4e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1b8f4e,null,0x2));const _0x32b03e=_0x1b8f4e['increment'];typeof _0x32b03e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x32b03e);const _0x38dfcd=_0x1ed84a['node']();if(f(_0x38dfcd!==null&&typeof _0x38dfcd<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x38dfcd['isLeafNode']())return _0x32b03e;const _0x1747ea=_0x38dfcd['getValue']();return typeof _0x1747ea!='number'?_0x32b03e:_0x1747ea+_0x32b03e;},ta=function(_0x275464,_0x1f9d45,_0x1b3db4,_0x23eef6){return ps(_0x1f9d45,new ds(_0x1b3db4,_0x275464),_0x23eef6);},fs=function(_0x544d8f,_0x114f21,_0x3ae857){return ps(_0x544d8f,new us(_0x114f21),_0x3ae857);};function ps(_0x483f56,_0x5822f9,_0x57586e){const _0x1bcb38=_0x483f56['getPriority']()['val'](),_0x3f0e68=_r(_0x1bcb38,_0x5822f9['getImmediateChild']('.priority'),_0x57586e);let _0x451853;if(_0x483f56['isLeafNode']()){const _0x37d43c=_0x483f56,_0x1cd25d=_r(_0x37d43c['getValue'](),_0x5822f9,_0x57586e);return _0x1cd25d!==_0x37d43c['getValue']()||_0x3f0e68!==_0x37d43c['getPriority']()['val']()?new D(_0x1cd25d,A(_0x3f0e68)):_0x483f56;}else{const _0x379582=_0x483f56;return _0x451853=_0x379582,_0x3f0e68!==_0x379582['getPriority']()['val']()&&(_0x451853=_0x451853['updatePriority'](new D(_0x3f0e68))),_0x379582['forEachChild'](R,(_0x4a4fbd,_0x3af014)=>{const _0x2d43c4=ps(_0x3af014,_0x5822f9['getImmediateChild'](_0x4a4fbd),_0x57586e);_0x2d43c4!==_0x3af014&&(_0x451853=_0x451853['updateImmediateChild'](_0x4a4fbd,_0x2d43c4));}),_0x451853;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x13f7ef='',_0x390f49=null,_0x949339={'children':{},'childCount':0x0}){this['name']=_0x13f7ef,this['parent']=_0x390f49,this['node']=_0x949339;}}function $n(_0x47ccf,_0x476f8b){let _0x14ea9a=_0x476f8b instanceof C?_0x476f8b:new C(_0x476f8b),_0x2fffc5=_0x47ccf,_0x1ba72b=y(_0x14ea9a);for(;_0x1ba72b!==null;){const _0x2197a8=Le(_0x2fffc5['node']['children'],_0x1ba72b)||{'children':{},'childCount':0x0};_0x2fffc5=new _s(_0x1ba72b,_0x2fffc5,_0x2197a8),_0x14ea9a=S(_0x14ea9a),_0x1ba72b=y(_0x14ea9a);}return _0x2fffc5;}function je(_0x1e7b60){return _0x1e7b60['node']['value'];}function gs(_0x146286,_0x40e65f){_0x146286['node']['value']=_0x40e65f,Oi(_0x146286);}function na(_0x2158ea){return _0x2158ea['node']['childCount']>0x0;}function od(_0x556342){return je(_0x556342)===void 0x0&&!na(_0x556342);}function Gn(_0x290f90,_0x1cbbbb){x(_0x290f90['node']['children'],(_0x4bd570,_0xa65ebd)=>{_0x1cbbbb(new _s(_0x4bd570,_0x290f90,_0xa65ebd));});}function ia(_0x310d5a,_0x3b67ea,_0x548674,_0x2f4256){_0x548674&&_0x3b67ea(_0x310d5a),Gn(_0x310d5a,_0x99ba1b=>{ia(_0x99ba1b,_0x3b67ea,!0x0);});}function ad(_0x30976c,_0x2ae318,_0x2afe62){let _0x379d5e=_0x30976c['parent'];for(;_0x379d5e!==null;){if(_0x2ae318(_0x379d5e))return!0x0;_0x379d5e=_0x379d5e['parent'];}return!0x1;}function Qt(_0x41d963){return new C(_0x41d963['parent']===null?_0x41d963['name']:Qt(_0x41d963['parent'])+'/'+_0x41d963['name']);}function Oi(_0x2fc95f){_0x2fc95f['parent']!==null&&cd(_0x2fc95f['parent'],_0x2fc95f['name'],_0x2fc95f);}function cd(_0x1ee0e0,_0x23fce3,_0x476656){const _0x1746d9=od(_0x476656),_0x3172d3=Q(_0x1ee0e0['node']['children'],_0x23fce3);_0x1746d9&&_0x3172d3?(delete _0x1ee0e0['node']['children'][_0x23fce3],_0x1ee0e0['node']['childCount']--,Oi(_0x1ee0e0)):!_0x1746d9&&!_0x3172d3&&(_0x1ee0e0['node']['children'][_0x23fce3]=_0x476656['node'],_0x1ee0e0['node']['childCount']++,Oi(_0x1ee0e0));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x4bf415){return typeof _0x4bf415=='string'&&_0x4bf415['length']!==0x0&&!ld['test'](_0x4bf415);},sa=function(_0x35fe27){return typeof _0x35fe27=='string'&&_0x35fe27['length']!==0x0&&!hd['test'](_0x35fe27);},ud=function(_0x570b5d){return _0x570b5d&&(_0x570b5d=_0x570b5d['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x570b5d);},Bt=function(_0x3494c9){return _0x3494c9===null||typeof _0x3494c9=='string'||typeof _0x3494c9=='number'&&!xn(_0x3494c9)||_0x3494c9&&typeof _0x3494c9=='object'&&Q(_0x3494c9,'.sv');},He=function(_0x4b1341,_0x27a64d,_0x4cf132,_0x5e3a5c){_0x5e3a5c&&_0x27a64d===void 0x0||Jt(it(_0x4b1341,'value'),_0x27a64d,_0x4cf132);},Jt=function(_0x5b403c,_0x4ae46f,_0x2a25b2){const _0x507625=_0x2a25b2 instanceof C?new Ah(_0x2a25b2,_0x5b403c):_0x2a25b2;if(_0x4ae46f===void 0x0)throw new Error(_0x5b403c+'contains\x20undefined\x20'+Oe(_0x507625));if(typeof _0x4ae46f=='function')throw new Error(_0x5b403c+'contains\x20a\x20function\x20'+Oe(_0x507625)+'\x20with\x20contents\x20=\x20'+_0x4ae46f['toString']());if(xn(_0x4ae46f))throw new Error(_0x5b403c+'contains\x20'+_0x4ae46f['toString']()+'\x20'+Oe(_0x507625));if(typeof _0x4ae46f=='string'&&_0x4ae46f['length']>ui/0x3&&Ln(_0x4ae46f)>ui)throw new Error(_0x5b403c+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x507625)+'\x20(\x27'+_0x4ae46f['substring'](0x0,0x32)+'...\x27)');if(_0x4ae46f&&typeof _0x4ae46f=='object'){let _0x11b7b9=!0x1,_0x5842ac=!0x1;if(x(_0x4ae46f,(_0x4d055a,_0x3498df)=>{if(_0x4d055a==='.value')_0x11b7b9=!0x0;else{if(_0x4d055a!=='.priority'&&_0x4d055a!=='.sv'&&(_0x5842ac=!0x0,!ms(_0x4d055a)))throw new Error(_0x5b403c+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4d055a+')\x20'+Oe(_0x507625)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x507625,_0x4d055a),Jt(_0x5b403c,_0x3498df,_0x507625),Ph(_0x507625);}),_0x11b7b9&&_0x5842ac)throw new Error(_0x5b403c+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x507625)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x494d77,_0x4ff3ca){let _0x46bde1,_0x29cb4;for(_0x46bde1=0x0;_0x46bde1<_0x4ff3ca['length'];_0x46bde1++){_0x29cb4=_0x4ff3ca[_0x46bde1];const _0x4cf175=Mt(_0x29cb4);for(let _0x3794cd=0x0;_0x3794cd<_0x4cf175['length'];_0x3794cd++)if(!(_0x4cf175[_0x3794cd]==='.priority'&&_0x3794cd===_0x4cf175['length']-0x1)){if(!ms(_0x4cf175[_0x3794cd]))throw new Error(_0x494d77+'contains\x20an\x20invalid\x20key\x20('+_0x4cf175[_0x3794cd]+')\x20in\x20path\x20'+_0x29cb4['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4ff3ca['sort'](Rh);let _0x262027=null;for(_0x46bde1=0x0;_0x46bde1<_0x4ff3ca['length'];_0x46bde1++){if(_0x29cb4=_0x4ff3ca[_0x46bde1],_0x262027!==null&&G(_0x262027,_0x29cb4))throw new Error(_0x494d77+'contains\x20a\x20path\x20'+_0x262027['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x29cb4['toString']());_0x262027=_0x29cb4;}},ra=function(_0x422ffb,_0x5e8642,_0x2d580d,_0x56b9d5){const _0x1de4e9=it(_0x422ffb,'values');if(!(_0x5e8642&&typeof _0x5e8642=='object')||Array['isArray'](_0x5e8642))throw new Error(_0x1de4e9+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x263f23=[];x(_0x5e8642,(_0x1d4423,_0x1951be)=>{const _0x28a82e=new C(_0x1d4423);if(Jt(_0x1de4e9,_0x1951be,k(_0x2d580d,_0x28a82e)),ji(_0x28a82e)==='.priority'&&!Bt(_0x1951be))throw new Error(_0x1de4e9+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x28a82e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x263f23['push'](_0x28a82e);}),dd(_0x1de4e9,_0x263f23);},fd=function(_0x18ecda,_0xe6f887,_0x2c6ddb){if(xn(_0xe6f887))throw new Error(it(_0x18ecda,'priority')+'is\x20'+_0xe6f887['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xe6f887))throw new Error(it(_0x18ecda,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xb4ce28,_0x4908d3,_0xbfd729,_0x198d12){if(!sa(_0xbfd729))throw new Error(it(_0xb4ce28,_0x4908d3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0xbfd729+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x10bfd1,_0x279c65,_0x32a2dd,_0x17beb4){_0x32a2dd&&(_0x32a2dd=_0x32a2dd['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x10bfd1,_0x279c65,_0x32a2dd);},Me=function(_0x1dfd30,_0x57d4a3){if(y(_0x57d4a3)==='.info')throw new Error(_0x1dfd30+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x4572fa,_0x404d5c){const _0x38c04d=_0x404d5c['path']['toString']();if(typeof _0x404d5c['repoInfo']['host']!='string'||_0x404d5c['repoInfo']['host']['length']===0x0||!ms(_0x404d5c['repoInfo']['namespace'])&&_0x404d5c['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x38c04d['length']!==0x0&&!ud(_0x38c04d))throw new Error(it(_0x4572fa,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x5a468e,_0xb050d){let _0x472f0d=null;for(let _0x2218ac=0x0;_0x2218ac<_0xb050d['length'];_0x2218ac++){const _0x8289b3=_0xb050d[_0x2218ac],_0x1ba520=_0x8289b3['getPath']();_0x472f0d!==null&&!Ki(_0x1ba520,_0x472f0d['path'])&&(_0x5a468e['eventLists_']['push'](_0x472f0d),_0x472f0d=null),_0x472f0d===null&&(_0x472f0d={'events':[],'path':_0x1ba520}),_0x472f0d['events']['push'](_0x8289b3);}_0x472f0d&&_0x5a468e['eventLists_']['push'](_0x472f0d);}function oa(_0x118984,_0x548669,_0x2d95c8){qn(_0x118984,_0x2d95c8),aa(_0x118984,_0x5878da=>Ki(_0x5878da,_0x548669));}function V(_0x5825ff,_0x419d8a,_0x1f9320){qn(_0x5825ff,_0x1f9320),aa(_0x5825ff,_0x4e4e42=>G(_0x4e4e42,_0x419d8a)||G(_0x419d8a,_0x4e4e42));}function aa(_0x1feb0f,_0x4fe174){_0x1feb0f['recursionDepth_']++;let _0x381c69=!0x0;for(let _0x5bab75=0x0;_0x5bab75<_0x1feb0f['eventLists_']['length'];_0x5bab75++){const _0x41875a=_0x1feb0f['eventLists_'][_0x5bab75];if(_0x41875a){const _0x3d8921=_0x41875a['path'];_0x4fe174(_0x3d8921)?(md(_0x1feb0f['eventLists_'][_0x5bab75]),_0x1feb0f['eventLists_'][_0x5bab75]=null):_0x381c69=!0x1;}}_0x381c69&&(_0x1feb0f['eventLists_']=[]),_0x1feb0f['recursionDepth_']--;}function md(_0x2cc21c){for(let _0x4ef9c1=0x0;_0x4ef9c1<_0x2cc21c['events']['length'];_0x4ef9c1++){const _0x2b85a2=_0x2cc21c['events'][_0x4ef9c1];if(_0x2b85a2!==null){_0x2cc21c['events'][_0x4ef9c1]=null;const _0x3aff7d=_0x2b85a2['getEventRunner']();St&&L('event:\x20'+_0x2b85a2['toString']()),ft(_0x3aff7d);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0xdfd169,_0x3dada9,_0x2ee2c3,_0x39eb68){this['repoInfo_']=_0xdfd169,this['forceRestClient_']=_0x3dada9,this['authTokenProvider_']=_0x2ee2c3,this['appCheckProvider_']=_0x39eb68,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x322ba9,_0x456d88,_0xb03867){if(_0x322ba9['stats_']=qi(_0x322ba9['repoInfo_']),_0x322ba9['forceRestClient_']||Xl())_0x322ba9['server_']=new vn(_0x322ba9['repoInfo_'],(_0x545d13,_0x420176,_0x158713,_0x4c0067)=>{gr(_0x322ba9,_0x545d13,_0x420176,_0x158713,_0x4c0067);},_0x322ba9['authTokenProvider_'],_0x322ba9['appCheckProvider_']),setTimeout(()=>mr(_0x322ba9,!0x0),0x0);else{if(typeof _0xb03867<'u'&&_0xb03867!==null){if(typeof _0xb03867!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xb03867);}catch(_0x4d09ed){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4d09ed);}}_0x322ba9['persistentConnection_']=new se(_0x322ba9['repoInfo_'],_0x456d88,(_0x40fa7e,_0x166833,_0x1d1d47,_0x25e0dc)=>{gr(_0x322ba9,_0x40fa7e,_0x166833,_0x1d1d47,_0x25e0dc);},_0x31ac9e=>{mr(_0x322ba9,_0x31ac9e);},_0x4335df=>{Id(_0x322ba9,_0x4335df);},_0x322ba9['authTokenProvider_'],_0x322ba9['appCheckProvider_'],_0xb03867),_0x322ba9['server_']=_0x322ba9['persistentConnection_'];}_0x322ba9['authTokenProvider_']['addTokenChangeListener'](_0x3827fb=>{_0x322ba9['server_']['refreshAuthToken'](_0x3827fb);}),_0x322ba9['appCheckProvider_']['addTokenChangeListener'](_0xa034c1=>{_0x322ba9['server_']['refreshAppCheckToken'](_0xa034c1['token']);}),_0x322ba9['statsReporter_']=ih(_0x322ba9['repoInfo_'],()=>new iu(_0x322ba9['stats_'],_0x322ba9['server_'])),_0x322ba9['infoData_']=new Xh(),_0x322ba9['infoSyncTree_']=new pr({'startListening':(_0x2ed04c,_0x51debf,_0x3bced7,_0x5b6492)=>{let _0x101741=[];const _0x324cac=_0x322ba9['infoData_']['getNode'](_0x2ed04c['_path']);return _0x324cac['isEmpty']()||(_0x101741=Yt(_0x322ba9['infoSyncTree_'],_0x2ed04c['_path'],_0x324cac),setTimeout(()=>{_0x5b6492('ok');},0x0)),_0x101741;},'stopListening':()=>{}}),vs(_0x322ba9,'connected',!0x1),_0x322ba9['serverSyncTree_']=new pr({'startListening':(_0x1d6339,_0x222f96,_0x55d209,_0x3250c3)=>(_0x322ba9['server_']['listen'](_0x1d6339,_0x55d209,_0x222f96,(_0x4b4caf,_0x4a6442)=>{const _0x422f1d=_0x3250c3(_0x4b4caf,_0x4a6442);V(_0x322ba9['eventQueue_'],_0x1d6339['_path'],_0x422f1d);}),[]),'stopListening':(_0x55a4c6,_0x28f68a)=>{_0x322ba9['server_']['unlisten'](_0x55a4c6,_0x28f68a);}});}function la(_0x48a7b4){const _0x3512d5=_0x48a7b4['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3512d5;}function Xt(_0x431264){return id({'timestamp':la(_0x431264)});}function gr(_0x260e2e,_0x1a23c1,_0x5b448e,_0x5a414d,_0x2ce9c3){_0x260e2e['dataUpdateCount']++;const _0x50745b=new C(_0x1a23c1);_0x5b448e=_0x260e2e['interceptServerDataCallback_']?_0x260e2e['interceptServerDataCallback_'](_0x1a23c1,_0x5b448e):_0x5b448e;let _0x4c352b=[];if(_0x2ce9c3){if(_0x5a414d){const _0x227f6b=_n(_0x5b448e,_0x1916bd=>A(_0x1916bd));_0x4c352b=Ju(_0x260e2e['serverSyncTree_'],_0x50745b,_0x227f6b,_0x2ce9c3);}else{const _0x17e9de=A(_0x5b448e);_0x4c352b=Jo(_0x260e2e['serverSyncTree_'],_0x50745b,_0x17e9de,_0x2ce9c3);}}else{if(_0x5a414d){const _0x1d6edd=_n(_0x5b448e,_0xd0edfd=>A(_0xd0edfd));_0x4c352b=Ku(_0x260e2e['serverSyncTree_'],_0x50745b,_0x1d6edd);}else{const _0x458cf4=A(_0x5b448e);_0x4c352b=Yt(_0x260e2e['serverSyncTree_'],_0x50745b,_0x458cf4);}}let _0x38b665=_0x50745b;_0x4c352b['length']>0x0&&(_0x38b665=ct(_0x260e2e,_0x50745b)),V(_0x260e2e['eventQueue_'],_0x38b665,_0x4c352b);}function mr(_0x467f0c,_0x4b765b){vs(_0x467f0c,'connected',_0x4b765b),_0x4b765b===!0x1&&Sd(_0x467f0c);}function Id(_0x48c1ec,_0x3a2f35){x(_0x3a2f35,(_0xb6e4d8,_0x3fc508)=>{vs(_0x48c1ec,_0xb6e4d8,_0x3fc508);});}function vs(_0x3f445e,_0x4f70a9,_0x51502b){const _0x34ae50=new C('/.info/'+_0x4f70a9),_0x230e57=A(_0x51502b);_0x3f445e['infoData_']['updateSnapshot'](_0x34ae50,_0x230e57);const _0x7056b3=Yt(_0x3f445e['infoSyncTree_'],_0x34ae50,_0x230e57);V(_0x3f445e['eventQueue_'],_0x34ae50,_0x7056b3);}function zn(_0x20097d){return _0x20097d['nextWriteId_']++;}function wd(_0x388728,_0x39f911,_0x50f28f){const _0x18e56d=Xu(_0x388728['serverSyncTree_'],_0x39f911);return _0x18e56d!=null?Promise['resolve'](_0x18e56d):_0x388728['server_']['get'](_0x39f911)['then'](_0x228439=>{const _0x196dcd=A(_0x228439)['withIndex'](_0x39f911['_queryParams']['getIndex']());Ni(_0x388728['serverSyncTree_'],_0x39f911,_0x50f28f,!0x0);let _0x27e193;if(_0x39f911['_queryParams']['loadsAllData']())_0x27e193=Yt(_0x388728['serverSyncTree_'],_0x39f911['_path'],_0x196dcd);else{const _0x4e66b3=Wt(_0x388728['serverSyncTree_'],_0x39f911);_0x27e193=Jo(_0x388728['serverSyncTree_'],_0x39f911['_path'],_0x196dcd,_0x4e66b3);}return V(_0x388728['eventQueue_'],_0x39f911['_path'],_0x27e193),An(_0x388728['serverSyncTree_'],_0x39f911,_0x50f28f,null,!0x0),_0x196dcd;},_0x98297c=>(gt(_0x388728,'get\x20for\x20query\x20'+O(_0x39f911)+'\x20failed:\x20'+_0x98297c),Promise['reject'](new Error(_0x98297c))));}function Cd(_0x1e13fb,_0x55d8d2,_0x77d2a9,_0x5ea347,_0x1bcfb8){gt(_0x1e13fb,'set',{'path':_0x55d8d2['toString'](),'value':_0x77d2a9,'priority':_0x5ea347});const _0x3de22e=Xt(_0x1e13fb),_0x24cf58=A(_0x77d2a9,_0x5ea347),_0x1a9f45=Vn(_0x1e13fb['serverSyncTree_'],_0x55d8d2),_0x5986fa=fs(_0x24cf58,_0x1a9f45,_0x3de22e),_0x368d9d=zn(_0x1e13fb),_0x58d971=as(_0x1e13fb['serverSyncTree_'],_0x55d8d2,_0x5986fa,_0x368d9d,!0x0);qn(_0x1e13fb['eventQueue_'],_0x58d971),_0x1e13fb['server_']['put'](_0x55d8d2['toString'](),_0x24cf58['val'](!0x0),(_0x195cdf,_0x530998)=>{const _0x2950aa=_0x195cdf==='ok';_0x2950aa||U('set\x20at\x20'+_0x55d8d2+'\x20failed:\x20'+_0x195cdf);const _0x1bd26a=_e(_0x1e13fb['serverSyncTree_'],_0x368d9d,!_0x2950aa);V(_0x1e13fb['eventQueue_'],_0x55d8d2,_0x1bd26a),be(_0x1e13fb,_0x1bcfb8,_0x195cdf,_0x530998);});const _0x5ac164=Is(_0x1e13fb,_0x55d8d2);ct(_0x1e13fb,_0x5ac164),V(_0x1e13fb['eventQueue_'],_0x5ac164,[]);}function Td(_0x49ef9f,_0x383495,_0x1b5a45,_0x4dcc7c){gt(_0x49ef9f,'update',{'path':_0x383495['toString'](),'value':_0x1b5a45});let _0xc48450=!0x0;const _0x3e649b=Xt(_0x49ef9f),_0x32f8a4={};if(x(_0x1b5a45,(_0xee7a3d,_0x697af6)=>{_0xc48450=!0x1,_0x32f8a4[_0xee7a3d]=ta(k(_0x383495,_0xee7a3d),A(_0x697af6),_0x49ef9f['serverSyncTree_'],_0x3e649b);}),_0xc48450)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x49ef9f,_0x4dcc7c,'ok',void 0x0);else{const _0x286ba4=zn(_0x49ef9f),_0x18f603=ju(_0x49ef9f['serverSyncTree_'],_0x383495,_0x32f8a4,_0x286ba4);qn(_0x49ef9f['eventQueue_'],_0x18f603),_0x49ef9f['server_']['merge'](_0x383495['toString'](),_0x1b5a45,(_0x5389ce,_0x635f45)=>{const _0x4e45b9=_0x5389ce==='ok';_0x4e45b9||U('update\x20at\x20'+_0x383495+'\x20failed:\x20'+_0x5389ce);const _0xf6d439=_e(_0x49ef9f['serverSyncTree_'],_0x286ba4,!_0x4e45b9),_0x47588f=_0xf6d439['length']>0x0?ct(_0x49ef9f,_0x383495):_0x383495;V(_0x49ef9f['eventQueue_'],_0x47588f,_0xf6d439),be(_0x49ef9f,_0x4dcc7c,_0x5389ce,_0x635f45);}),x(_0x1b5a45,_0xf9fbaf=>{const _0x3a58bd=Is(_0x49ef9f,k(_0x383495,_0xf9fbaf));ct(_0x49ef9f,_0x3a58bd);}),V(_0x49ef9f['eventQueue_'],_0x383495,[]);}}function Sd(_0x5d2586){gt(_0x5d2586,'onDisconnectEvents');const _0x436d30=Xt(_0x5d2586),_0xc4db99=En();Si(_0x5d2586['onDisconnect_'],w(),(_0x2f42fe,_0x3a4b5b)=>{const _0x4d1ddc=ta(_0x2f42fe,_0x3a4b5b,_0x5d2586['serverSyncTree_'],_0x436d30);pt(_0xc4db99,_0x2f42fe,_0x4d1ddc);});let _0x4ba8ea=[];Si(_0xc4db99,w(),(_0xe99483,_0x21db21)=>{_0x4ba8ea=_0x4ba8ea['concat'](Yt(_0x5d2586['serverSyncTree_'],_0xe99483,_0x21db21));const _0xfda00f=Is(_0x5d2586,_0xe99483);ct(_0x5d2586,_0xfda00f);}),_0x5d2586['onDisconnect_']=En(),V(_0x5d2586['eventQueue_'],w(),_0x4ba8ea);}function bd(_0x54a950,_0x521fc1,_0x4296ce){_0x54a950['server_']['onDisconnectCancel'](_0x521fc1['toString'](),(_0x42ff0a,_0x3f789d)=>{_0x42ff0a==='ok'&&Ti(_0x54a950['onDisconnect_'],_0x521fc1),be(_0x54a950,_0x4296ce,_0x42ff0a,_0x3f789d);});}function yr(_0xbf0ba1,_0x44d7a3,_0xcc41c0,_0x354ef7){const _0x5edad7=A(_0xcc41c0);_0xbf0ba1['server_']['onDisconnectPut'](_0x44d7a3['toString'](),_0x5edad7['val'](!0x0),(_0x3e2bef,_0x48c87a)=>{_0x3e2bef==='ok'&&pt(_0xbf0ba1['onDisconnect_'],_0x44d7a3,_0x5edad7),be(_0xbf0ba1,_0x354ef7,_0x3e2bef,_0x48c87a);});}function Rd(_0x287eee,_0x3effe1,_0x251527,_0xff0fc,_0x2227e0){const _0x5a5868=A(_0x251527,_0xff0fc);_0x287eee['server_']['onDisconnectPut'](_0x3effe1['toString'](),_0x5a5868['val'](!0x0),(_0x4103ce,_0x14a3cd)=>{_0x4103ce==='ok'&&pt(_0x287eee['onDisconnect_'],_0x3effe1,_0x5a5868),be(_0x287eee,_0x2227e0,_0x4103ce,_0x14a3cd);});}function Ad(_0x587f47,_0x4ddb66,_0x42e9d1,_0x1de587){if(pn(_0x42e9d1)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x587f47,_0x1de587,'ok',void 0x0);return;}_0x587f47['server_']['onDisconnectMerge'](_0x4ddb66['toString'](),_0x42e9d1,(_0x45ee6b,_0x6d75fc)=>{_0x45ee6b==='ok'&&x(_0x42e9d1,(_0x3e92cf,_0x280a2f)=>{const _0x176fe2=A(_0x280a2f);pt(_0x587f47['onDisconnect_'],k(_0x4ddb66,_0x3e92cf),_0x176fe2);}),be(_0x587f47,_0x1de587,_0x45ee6b,_0x6d75fc);});}function kd(_0x117c27,_0xfb43d,_0x9cb461){let _0x299aa7;y(_0xfb43d['_path'])==='.info'?_0x299aa7=Ni(_0x117c27['infoSyncTree_'],_0xfb43d,_0x9cb461):_0x299aa7=Ni(_0x117c27['serverSyncTree_'],_0xfb43d,_0x9cb461),oa(_0x117c27['eventQueue_'],_0xfb43d['_path'],_0x299aa7);}function Pd(_0x312313,_0x883c37,_0x37ae38){let _0x23d86d;y(_0x883c37['_path'])==='.info'?_0x23d86d=An(_0x312313['infoSyncTree_'],_0x883c37,_0x37ae38):_0x23d86d=An(_0x312313['serverSyncTree_'],_0x883c37,_0x37ae38),oa(_0x312313['eventQueue_'],_0x883c37['_path'],_0x23d86d);}function ha(_0x52706c){_0x52706c['persistentConnection_']&&_0x52706c['persistentConnection_']['interrupt'](ca);}function Nd(_0x1f87a7){_0x1f87a7['persistentConnection_']&&_0x1f87a7['persistentConnection_']['resume'](ca);}function gt(_0x274429,..._0x3da75d){let _0x2adc7b='';_0x274429['persistentConnection_']&&(_0x2adc7b=_0x274429['persistentConnection_']['id']+':'),L(_0x2adc7b,..._0x3da75d);}function be(_0x1e2121,_0x8584ec,_0x4ff26c,_0x7a4659){_0x8584ec&&ft(()=>{if(_0x4ff26c==='ok')_0x8584ec(null);else{const _0x6df894=(_0x4ff26c||'error')['toUpperCase']();let _0x4364fd=_0x6df894;_0x7a4659&&(_0x4364fd+=':\x20'+_0x7a4659);const _0x2d5d44=new Error(_0x4364fd);_0x2d5d44['code']=_0x6df894,_0x8584ec(_0x2d5d44);}});}function Od(_0x294126,_0x48a4c0,_0x3a6415,_0x2eeed9,_0x45a9b6,_0x311e9b){gt(_0x294126,'transaction\x20on\x20'+_0x48a4c0);const _0x4a77fc={'path':_0x48a4c0,'update':_0x3a6415,'onComplete':_0x2eeed9,'status':null,'order':so(),'applyLocally':_0x311e9b,'retryCount':0x0,'unwatcher':_0x45a9b6,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4a7d21=Es(_0x294126,_0x48a4c0,void 0x0);_0x4a77fc['currentInputSnapshot']=_0x4a7d21;const _0x579598=_0x4a77fc['update'](_0x4a7d21['val']());if(_0x579598===void 0x0)_0x4a77fc['unwatcher'](),_0x4a77fc['currentOutputSnapshotRaw']=null,_0x4a77fc['currentOutputSnapshotResolved']=null,_0x4a77fc['onComplete']&&_0x4a77fc['onComplete'](null,!0x1,_0x4a77fc['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x579598,_0x4a77fc['path']),_0x4a77fc['status']=0x0;const _0x151bde=$n(_0x294126['transactionQueueTree_'],_0x48a4c0),_0x2e6dfa=je(_0x151bde)||[];_0x2e6dfa['push'](_0x4a77fc),gs(_0x151bde,_0x2e6dfa);let _0x574c20;typeof _0x579598=='object'&&_0x579598!==null&&Q(_0x579598,'.priority')?(_0x574c20=Le(_0x579598,'.priority'),f(Bt(_0x574c20),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x574c20=(Vn(_0x294126['serverSyncTree_'],_0x48a4c0)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x284268=Xt(_0x294126),_0x39dcae=A(_0x579598,_0x574c20),_0x25898b=fs(_0x39dcae,_0x4a7d21,_0x284268);_0x4a77fc['currentOutputSnapshotRaw']=_0x39dcae,_0x4a77fc['currentOutputSnapshotResolved']=_0x25898b,_0x4a77fc['currentWriteId']=zn(_0x294126);const _0x17c771=as(_0x294126['serverSyncTree_'],_0x48a4c0,_0x25898b,_0x4a77fc['currentWriteId'],_0x4a77fc['applyLocally']);V(_0x294126['eventQueue_'],_0x48a4c0,_0x17c771),jn(_0x294126,_0x294126['transactionQueueTree_']);}}function Es(_0x507f96,_0x8fb636,_0x35c6d4){return Vn(_0x507f96['serverSyncTree_'],_0x8fb636,_0x35c6d4)||g['EMPTY_NODE'];}function jn(_0x453290,_0x445486=_0x453290['transactionQueueTree_']){if(_0x445486||Kn(_0x453290,_0x445486),je(_0x445486)){const _0x1d44ab=da(_0x453290,_0x445486);f(_0x1d44ab['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1d44ab['every'](_0x8d30cc=>_0x8d30cc['status']===0x0)&&Dd(_0x453290,Qt(_0x445486),_0x1d44ab);}else na(_0x445486)&&Gn(_0x445486,_0x5a18d0=>{jn(_0x453290,_0x5a18d0);});}function Dd(_0x4320dc,_0x52b084,_0x4b8684){const _0x32c146=_0x4b8684['map'](_0x5495f1=>_0x5495f1['currentWriteId']),_0x24d53f=Es(_0x4320dc,_0x52b084,_0x32c146);let _0x2358cc=_0x24d53f;const _0xe0ed44=_0x24d53f['hash']();for(let _0xa96679=0x0;_0xa96679<_0x4b8684['length'];_0xa96679++){const _0xba2220=_0x4b8684[_0xa96679];f(_0xba2220['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xba2220['status']=0x1,_0xba2220['retryCount']++;const _0x3b4249=F(_0x52b084,_0xba2220['path']);_0x2358cc=_0x2358cc['updateChild'](_0x3b4249,_0xba2220['currentOutputSnapshotRaw']);}const _0x37bc87=_0x2358cc['val'](!0x0),_0x2a78ba=_0x52b084;_0x4320dc['server_']['put'](_0x2a78ba['toString'](),_0x37bc87,_0x49097a=>{gt(_0x4320dc,'transaction\x20put\x20response',{'path':_0x2a78ba['toString'](),'status':_0x49097a});let _0x13f792=[];if(_0x49097a==='ok'){const _0x74c265=[];for(let _0x2a3230=0x0;_0x2a3230<_0x4b8684['length'];_0x2a3230++)_0x4b8684[_0x2a3230]['status']=0x2,_0x13f792=_0x13f792['concat'](_e(_0x4320dc['serverSyncTree_'],_0x4b8684[_0x2a3230]['currentWriteId'])),_0x4b8684[_0x2a3230]['onComplete']&&_0x74c265['push'](()=>_0x4b8684[_0x2a3230]['onComplete'](null,!0x0,_0x4b8684[_0x2a3230]['currentOutputSnapshotResolved'])),_0x4b8684[_0x2a3230]['unwatcher']();Kn(_0x4320dc,$n(_0x4320dc['transactionQueueTree_'],_0x52b084)),jn(_0x4320dc,_0x4320dc['transactionQueueTree_']),V(_0x4320dc['eventQueue_'],_0x52b084,_0x13f792);for(let _0x19b75f=0x0;_0x19b75f<_0x74c265['length'];_0x19b75f++)ft(_0x74c265[_0x19b75f]);}else{if(_0x49097a==='datastale'){for(let _0x24694c=0x0;_0x24694c<_0x4b8684['length'];_0x24694c++)_0x4b8684[_0x24694c]['status']===0x3?_0x4b8684[_0x24694c]['status']=0x4:_0x4b8684[_0x24694c]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2a78ba['toString']()+'\x20failed:\x20'+_0x49097a);for(let _0x3e3793=0x0;_0x3e3793<_0x4b8684['length'];_0x3e3793++)_0x4b8684[_0x3e3793]['status']=0x4,_0x4b8684[_0x3e3793]['abortReason']=_0x49097a;}ct(_0x4320dc,_0x52b084);}},_0xe0ed44);}function ct(_0x37163b,_0x561282){const _0x240c5f=ua(_0x37163b,_0x561282),_0x1319f9=Qt(_0x240c5f),_0x2406be=da(_0x37163b,_0x240c5f);return Md(_0x37163b,_0x2406be,_0x1319f9),_0x1319f9;}function Md(_0x2df23d,_0x452251,_0x3a6bd9){if(_0x452251['length']===0x0)return;const _0x2b3454=[];let _0x41d16a=[];const _0x49a754=_0x452251['filter'](_0x6a0eb2=>_0x6a0eb2['status']===0x0)['map'](_0x163f66=>_0x163f66['currentWriteId']);for(let _0x5d1fa6=0x0;_0x5d1fa6<_0x452251['length'];_0x5d1fa6++){const _0xcea274=_0x452251[_0x5d1fa6],_0x7070e0=F(_0x3a6bd9,_0xcea274['path']);let _0x45f6b5=!0x1,_0x3df493;if(f(_0x7070e0!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xcea274['status']===0x4)_0x45f6b5=!0x0,_0x3df493=_0xcea274['abortReason'],_0x41d16a=_0x41d16a['concat'](_e(_0x2df23d['serverSyncTree_'],_0xcea274['currentWriteId'],!0x0));else{if(_0xcea274['status']===0x0){if(_0xcea274['retryCount']>=yd)_0x45f6b5=!0x0,_0x3df493='maxretry',_0x41d16a=_0x41d16a['concat'](_e(_0x2df23d['serverSyncTree_'],_0xcea274['currentWriteId'],!0x0));else{const _0x5ebd02=Es(_0x2df23d,_0xcea274['path'],_0x49a754);_0xcea274['currentInputSnapshot']=_0x5ebd02;const _0x1da5a1=_0x452251[_0x5d1fa6]['update'](_0x5ebd02['val']());if(_0x1da5a1!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1da5a1,_0xcea274['path']);let _0x331849=A(_0x1da5a1);typeof _0x1da5a1=='object'&&_0x1da5a1!=null&&Q(_0x1da5a1,'.priority')||(_0x331849=_0x331849['updatePriority'](_0x5ebd02['getPriority']()));const _0x3b6740=_0xcea274['currentWriteId'],_0x541592=Xt(_0x2df23d),_0x206cee=fs(_0x331849,_0x5ebd02,_0x541592);_0xcea274['currentOutputSnapshotRaw']=_0x331849,_0xcea274['currentOutputSnapshotResolved']=_0x206cee,_0xcea274['currentWriteId']=zn(_0x2df23d),_0x49a754['splice'](_0x49a754['indexOf'](_0x3b6740),0x1),_0x41d16a=_0x41d16a['concat'](as(_0x2df23d['serverSyncTree_'],_0xcea274['path'],_0x206cee,_0xcea274['currentWriteId'],_0xcea274['applyLocally'])),_0x41d16a=_0x41d16a['concat'](_e(_0x2df23d['serverSyncTree_'],_0x3b6740,!0x0));}else _0x45f6b5=!0x0,_0x3df493='nodata',_0x41d16a=_0x41d16a['concat'](_e(_0x2df23d['serverSyncTree_'],_0xcea274['currentWriteId'],!0x0));}}}V(_0x2df23d['eventQueue_'],_0x3a6bd9,_0x41d16a),_0x41d16a=[],_0x45f6b5&&(_0x452251[_0x5d1fa6]['status']=0x2,function(_0x3bc461){setTimeout(_0x3bc461,Math['floor'](0x0));}(_0x452251[_0x5d1fa6]['unwatcher']),_0x452251[_0x5d1fa6]['onComplete']&&(_0x3df493==='nodata'?_0x2b3454['push'](()=>_0x452251[_0x5d1fa6]['onComplete'](null,!0x1,_0x452251[_0x5d1fa6]['currentInputSnapshot'])):_0x2b3454['push'](()=>_0x452251[_0x5d1fa6]['onComplete'](new Error(_0x3df493),!0x1,null))));}Kn(_0x2df23d,_0x2df23d['transactionQueueTree_']);for(let _0xe1a78a=0x0;_0xe1a78a<_0x2b3454['length'];_0xe1a78a++)ft(_0x2b3454[_0xe1a78a]);jn(_0x2df23d,_0x2df23d['transactionQueueTree_']);}function ua(_0x3ab875,_0x4ca559){let _0x4978e4,_0x5b832a=_0x3ab875['transactionQueueTree_'];for(_0x4978e4=y(_0x4ca559);_0x4978e4!==null&&je(_0x5b832a)===void 0x0;)_0x5b832a=$n(_0x5b832a,_0x4978e4),_0x4ca559=S(_0x4ca559),_0x4978e4=y(_0x4ca559);return _0x5b832a;}function da(_0x1c55a9,_0x3de7f7){const _0x28b08d=[];return fa(_0x1c55a9,_0x3de7f7,_0x28b08d),_0x28b08d['sort']((_0x4bc707,_0x2c21a9)=>_0x4bc707['order']-_0x2c21a9['order']),_0x28b08d;}function fa(_0x4f1f01,_0x3d0dc9,_0x437f5d){const _0x361b05=je(_0x3d0dc9);if(_0x361b05){for(let _0x3ae841=0x0;_0x3ae841<_0x361b05['length'];_0x3ae841++)_0x437f5d['push'](_0x361b05[_0x3ae841]);}Gn(_0x3d0dc9,_0x2857e6=>{fa(_0x4f1f01,_0x2857e6,_0x437f5d);});}function Kn(_0x111571,_0x15c29d){const _0x1a392e=je(_0x15c29d);if(_0x1a392e){let _0x265a48=0x0;for(let _0x50ac03=0x0;_0x50ac03<_0x1a392e['length'];_0x50ac03++)_0x1a392e[_0x50ac03]['status']!==0x2&&(_0x1a392e[_0x265a48]=_0x1a392e[_0x50ac03],_0x265a48++);_0x1a392e['length']=_0x265a48,gs(_0x15c29d,_0x1a392e['length']>0x0?_0x1a392e:void 0x0);}Gn(_0x15c29d,_0x12b727=>{Kn(_0x111571,_0x12b727);});}function Is(_0x2ad09b,_0x4c09d6){const _0x2512e8=Qt(ua(_0x2ad09b,_0x4c09d6)),_0x30a1e8=$n(_0x2ad09b['transactionQueueTree_'],_0x4c09d6);return ad(_0x30a1e8,_0x4262d6=>{di(_0x2ad09b,_0x4262d6);}),di(_0x2ad09b,_0x30a1e8),ia(_0x30a1e8,_0x1ffb39=>{di(_0x2ad09b,_0x1ffb39);}),_0x2512e8;}function di(_0x5d5001,_0x45b1e4){const _0x24188c=je(_0x45b1e4);if(_0x24188c){const _0xbe58b8=[];let _0x5b5f3a=[],_0x132b03=-0x1;for(let _0x461a7f=0x0;_0x461a7f<_0x24188c['length'];_0x461a7f++)_0x24188c[_0x461a7f]['status']===0x3||(_0x24188c[_0x461a7f]['status']===0x1?(f(_0x132b03===_0x461a7f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x132b03=_0x461a7f,_0x24188c[_0x461a7f]['status']=0x3,_0x24188c[_0x461a7f]['abortReason']='set'):(f(_0x24188c[_0x461a7f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x24188c[_0x461a7f]['unwatcher'](),_0x5b5f3a=_0x5b5f3a['concat'](_e(_0x5d5001['serverSyncTree_'],_0x24188c[_0x461a7f]['currentWriteId'],!0x0)),_0x24188c[_0x461a7f]['onComplete']&&_0xbe58b8['push'](_0x24188c[_0x461a7f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x132b03===-0x1?gs(_0x45b1e4,void 0x0):_0x24188c['length']=_0x132b03+0x1,V(_0x5d5001['eventQueue_'],Qt(_0x45b1e4),_0x5b5f3a);for(let _0x108445=0x0;_0x108445<_0xbe58b8['length'];_0x108445++)ft(_0xbe58b8[_0x108445]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x357c45){let _0x262ca6='';const _0x3afb08=_0x357c45['split']('/');for(let _0x4ca5b3=0x0;_0x4ca5b3<_0x3afb08['length'];_0x4ca5b3++)if(_0x3afb08[_0x4ca5b3]['length']>0x0){let _0x4d3c30=_0x3afb08[_0x4ca5b3];try{_0x4d3c30=decodeURIComponent(_0x4d3c30['replace'](/\+/g,'\x20'));}catch{}_0x262ca6+='/'+_0x4d3c30;}return _0x262ca6;}function xd(_0x3d1a48){const _0x4ae683={};_0x3d1a48['charAt'](0x0)==='?'&&(_0x3d1a48=_0x3d1a48['substring'](0x1));for(const _0x50b512 of _0x3d1a48['split']('&')){if(_0x50b512['length']===0x0)continue;const _0x5c7e29=_0x50b512['split']('=');_0x5c7e29['length']===0x2?_0x4ae683[decodeURIComponent(_0x5c7e29[0x0])]=decodeURIComponent(_0x5c7e29[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x50b512+'\x27\x20in\x20query\x20\x27'+_0x3d1a48+'\x27');}return _0x4ae683;}const vr=function(_0x2f73d1,_0x6a302e){const _0x4d727a=Fd(_0x2f73d1),_0x5a58fc=_0x4d727a['namespace'];_0x4d727a['domain']==='firebase.com'&&ae(_0x4d727a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5a58fc||_0x5a58fc==='undefined')&&_0x4d727a['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4d727a['secure']||$l();const _0x5ba8e1=_0x4d727a['scheme']==='ws'||_0x4d727a['scheme']==='wss';return{'repoInfo':new yo(_0x4d727a['host'],_0x4d727a['secure'],_0x5a58fc,_0x5ba8e1,_0x6a302e,'',_0x5a58fc!==_0x4d727a['subdomain']),'path':new C(_0x4d727a['pathString'])};},Fd=function(_0x177b65){let _0x2b4ab1='',_0x18bf76='',_0x38e7e4='',_0x42bd4d='',_0x16c2c6='',_0x18fb05=!0x0,_0x371015='https',_0x2bc075=0x1bb;if(typeof _0x177b65=='string'){let _0x360ca2=_0x177b65['indexOf']('//');_0x360ca2>=0x0&&(_0x371015=_0x177b65['substring'](0x0,_0x360ca2-0x1),_0x177b65=_0x177b65['substring'](_0x360ca2+0x2));let _0x4c0ea8=_0x177b65['indexOf']('/');_0x4c0ea8===-0x1&&(_0x4c0ea8=_0x177b65['length']);let _0x219bac=_0x177b65['indexOf']('?');_0x219bac===-0x1&&(_0x219bac=_0x177b65['length']),_0x2b4ab1=_0x177b65['substring'](0x0,Math['min'](_0x4c0ea8,_0x219bac)),_0x4c0ea8<_0x219bac&&(_0x42bd4d=Ld(_0x177b65['substring'](_0x4c0ea8,_0x219bac)));const _0x4e7ba7=xd(_0x177b65['substring'](Math['min'](_0x177b65['length'],_0x219bac)));_0x360ca2=_0x2b4ab1['indexOf'](':'),_0x360ca2>=0x0?(_0x18fb05=_0x371015==='https'||_0x371015==='wss',_0x2bc075=parseInt(_0x2b4ab1['substring'](_0x360ca2+0x1),0xa)):_0x360ca2=_0x2b4ab1['length'];const _0x47b068=_0x2b4ab1['slice'](0x0,_0x360ca2);if(_0x47b068['toLowerCase']()==='localhost')_0x18bf76='localhost';else{if(_0x47b068['split']('.')['length']<=0x2)_0x18bf76=_0x47b068;else{const _0x20f8f3=_0x2b4ab1['indexOf']('.');_0x38e7e4=_0x2b4ab1['substring'](0x0,_0x20f8f3)['toLowerCase'](),_0x18bf76=_0x2b4ab1['substring'](_0x20f8f3+0x1),_0x16c2c6=_0x38e7e4;}}'ns'in _0x4e7ba7&&(_0x16c2c6=_0x4e7ba7['ns']);}return{'host':_0x2b4ab1,'port':_0x2bc075,'domain':_0x18bf76,'subdomain':_0x38e7e4,'secure':_0x18fb05,'scheme':_0x371015,'pathString':_0x42bd4d,'namespace':_0x16c2c6};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x17c6c8=0x0;const _0x131b3e=[];return function(_0xa6f867){const _0x87eec3=_0xa6f867===_0x17c6c8;_0x17c6c8=_0xa6f867;let _0xc29f66;const _0x494390=new Array(0x8);for(_0xc29f66=0x7;_0xc29f66>=0x0;_0xc29f66--)_0x494390[_0xc29f66]=Er['charAt'](_0xa6f867%0x40),_0xa6f867=Math['floor'](_0xa6f867/0x40);f(_0xa6f867===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x151df=_0x494390['join']('');if(_0x87eec3){for(_0xc29f66=0xb;_0xc29f66>=0x0&&_0x131b3e[_0xc29f66]===0x3f;_0xc29f66--)_0x131b3e[_0xc29f66]=0x0;_0x131b3e[_0xc29f66]++;}else{for(_0xc29f66=0x0;_0xc29f66<0xc;_0xc29f66++)_0x131b3e[_0xc29f66]=Math['floor'](Math['random']()*0x40);}for(_0xc29f66=0x0;_0xc29f66<0xc;_0xc29f66++)_0x151df+=Er['charAt'](_0x131b3e[_0xc29f66]);return f(_0x151df['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x151df;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x7f69bf,_0x144f8b,_0x3beb37,_0x3b2768){this['eventType']=_0x7f69bf,this['eventRegistration']=_0x144f8b,this['snapshot']=_0x3beb37,this['prevName']=_0x3b2768;}['getPath'](){const _0x2cd53e=this['snapshot']['ref'];return this['eventType']==='value'?_0x2cd53e['_path']:_0x2cd53e['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x1889bc,_0x59619d,_0x20e606){this['eventRegistration']=_0x1889bc,this['error']=_0x59619d,this['path']=_0x20e606;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2ea186,_0x52073e){this['snapshotCallback']=_0x2ea186,this['cancelCallback']=_0x52073e;}['onValue'](_0xaaac6c,_0x4d58ee){this['snapshotCallback']['call'](null,_0xaaac6c,_0x4d58ee);}['onCancel'](_0x58680a){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x58680a);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x14da17){return this['snapshotCallback']===_0x14da17['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x14da17['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x14da17['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3ea2d4,_0x28dd08){this['_repo']=_0x3ea2d4,this['_path']=_0x28dd08;}['cancel'](){const _0x6be6f=new H();return bd(this['_repo'],this['_path'],_0x6be6f['wrapCallback'](()=>{})),_0x6be6f['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x351940=new H();return yr(this['_repo'],this['_path'],null,_0x351940['wrapCallback'](()=>{})),_0x351940['promise'];}['set'](_0x521c7b){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x521c7b,this['_path'],!0x1);const _0xe22d54=new H();return yr(this['_repo'],this['_path'],_0x521c7b,_0xe22d54['wrapCallback'](()=>{})),_0xe22d54['promise'];}['setWithPriority'](_0x3ccc73,_0x4f4c33){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x3ccc73,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4f4c33);const _0x41339f=new H();return Rd(this['_repo'],this['_path'],_0x3ccc73,_0x4f4c33,_0x41339f['wrapCallback'](()=>{})),_0x41339f['promise'];}['update'](_0xa67d37){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0xa67d37,this['_path']);const _0x838194=new H();return Ad(this['_repo'],this['_path'],_0xa67d37,_0x838194['wrapCallback'](()=>{})),_0x838194['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x2500f3,_0x5f22a7,_0x3b99ff,_0x3be81f){this['_repo']=_0x2500f3,this['_path']=_0x5f22a7,this['_queryParams']=_0x3b99ff,this['_orderByCalled']=_0x3be81f;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4fd71b=sr(this['_queryParams']),_0x3eaa29=$i(_0x4fd71b);return _0x3eaa29==='{}'?'default':_0x3eaa29;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2f2cfc){if(_0x2f2cfc=P(_0x2f2cfc),!(_0x2f2cfc instanceof Ae))return!0x1;const _0x37dfa4=this['_repo']===_0x2f2cfc['_repo'],_0x2b503a=Ki(this['_path'],_0x2f2cfc['_path']),_0x5f1092=this['_queryIdentifier']===_0x2f2cfc['_queryIdentifier'];return _0x37dfa4&&_0x2b503a&&_0x5f1092;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x9cfa30,_0x5086c2){if(_0x9cfa30['_orderByCalled']===!0x0)throw new Error(_0x5086c2+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x19e46a){let _0x46ee36=null,_0x4c9b91=null;if(_0x19e46a['hasStart']()&&(_0x46ee36=_0x19e46a['getIndexStartValue']()),_0x19e46a['hasEnd']()&&(_0x4c9b91=_0x19e46a['getIndexEndValue']()),_0x19e46a['getIndex']()===ve){const _0x3f6a22='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x348cce='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x19e46a['hasStart']()){if(_0x19e46a['getIndexStartName']()!==We)throw new Error(_0x3f6a22);if(typeof _0x46ee36!='string')throw new Error(_0x348cce);}if(_0x19e46a['hasEnd']()){if(_0x19e46a['getIndexEndName']()!==we)throw new Error(_0x3f6a22);if(typeof _0x4c9b91!='string')throw new Error(_0x348cce);}}else{if(_0x19e46a['getIndex']()===R){if(_0x46ee36!=null&&!Bt(_0x46ee36)||_0x4c9b91!=null&&!Bt(_0x4c9b91))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x19e46a['getIndex']()instanceof Ji||_0x19e46a['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x46ee36!=null&&typeof _0x46ee36=='object'||_0x4c9b91!=null&&typeof _0x4c9b91=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x559a53){if(_0x559a53['hasStart']()&&_0x559a53['hasEnd']()&&_0x559a53['hasLimit']()&&!_0x559a53['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x348dff,_0xc59249){super(_0x348dff,_0xc59249,new Zi(),!0x1);}get['parent'](){const _0xfc9ca6=Ro(this['_path']);return _0xfc9ca6===null?null:new ee(this['_repo'],_0xfc9ca6);}get['root'](){let _0x416769=this;for(;_0x416769['parent']!==null;)_0x416769=_0x416769['parent'];return _0x416769;}}class lt{constructor(_0xcb65ee,_0x17c0f8,_0x5cc01f){this['_node']=_0xcb65ee,this['ref']=_0x17c0f8,this['_index']=_0x5cc01f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x287c28){const _0x41a6a1=new C(_0x287c28),_0x376325=Vt(this['ref'],_0x287c28);return new lt(this['_node']['getChild'](_0x41a6a1),_0x376325,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x346456){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x47f7b3,_0x4ca3f9)=>_0x346456(new lt(_0x4ca3f9,Vt(this['ref'],_0x47f7b3),R)));}['hasChild'](_0x2a3045){const _0x46206c=new C(_0x2a3045);return!this['_node']['getChild'](_0x46206c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x258696,_0x27564d){return _0x258696=P(_0x258696),_0x258696['_checkNotDeleted']('ref'),_0x27564d!==void 0x0?Vt(_0x258696['_root'],_0x27564d):_0x258696['_root'];}function Vt(_0x45f80f,_0x1e2eeb){return _0x45f80f=P(_0x45f80f),y(_0x45f80f['_path'])===null?pd('child','path',_0x1e2eeb):ys('child','path',_0x1e2eeb),new ee(_0x45f80f['_repo'],k(_0x45f80f['_path'],_0x1e2eeb));}function v_(_0x25ae17){return _0x25ae17=P(_0x25ae17),new Vd(_0x25ae17['_repo'],_0x25ae17['_path']);}function E_(_0x578630,_0x1ec7b2){_0x578630=P(_0x578630),Me('push',_0x578630['_path']),He('push',_0x1ec7b2,_0x578630['_path'],!0x0);const _0x5573bb=la(_0x578630['_repo']),_0x3ec87d=Ud(_0x5573bb),_0x3b69a5=Vt(_0x578630,_0x3ec87d),_0x406ad0=Vt(_0x578630,_0x3ec87d);let _0x36f23b;return _0x1ec7b2!=null?_0x36f23b=Hd(_0x406ad0,_0x1ec7b2)['then'](()=>_0x406ad0):_0x36f23b=Promise['resolve'](_0x406ad0),_0x3b69a5['then']=_0x36f23b['then']['bind'](_0x36f23b),_0x3b69a5['catch']=_0x36f23b['then']['bind'](_0x36f23b,void 0x0),_0x3b69a5;}function Hd(_0x2d99e6,_0x40404d){_0x2d99e6=P(_0x2d99e6),Me('set',_0x2d99e6['_path']),He('set',_0x40404d,_0x2d99e6['_path'],!0x1);const _0x4414ea=new H();return Cd(_0x2d99e6['_repo'],_0x2d99e6['_path'],_0x40404d,null,_0x4414ea['wrapCallback'](()=>{})),_0x4414ea['promise'];}function I_(_0x464afc,_0x5551cf){ra('update',_0x5551cf,_0x464afc['_path']);const _0x49898c=new H();return Td(_0x464afc['_repo'],_0x464afc['_path'],_0x5551cf,_0x49898c['wrapCallback'](()=>{})),_0x49898c['promise'];}function w_(_0x1123d4){_0x1123d4=P(_0x1123d4);const _0x4e39e5=new pa(()=>{}),_0x58a316=new Qn(_0x4e39e5);return wd(_0x1123d4['_repo'],_0x1123d4,_0x58a316)['then'](_0x2eb489=>new lt(_0x2eb489,new ee(_0x1123d4['_repo'],_0x1123d4['_path']),_0x1123d4['_queryParams']['getIndex']()));}class Qn{constructor(_0xc53831){this['callbackContext']=_0xc53831;}['respondsTo'](_0x3d26cc){return _0x3d26cc==='value';}['createEvent'](_0xa672ce,_0xa36d00){const _0x2bb354=_0xa36d00['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0xa672ce['snapshotNode'],new ee(_0xa36d00['_repo'],_0xa36d00['_path']),_0x2bb354));}['getEventRunner'](_0x319f9c){return _0x319f9c['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x319f9c['error']):()=>this['callbackContext']['onValue'](_0x319f9c['snapshot'],null);}['createCancelEvent'](_0x32de9b,_0x1136bd){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x32de9b,_0x1136bd):null;}['matches'](_0x455ee7){return _0x455ee7 instanceof Qn?!_0x455ee7['callbackContext']||!this['callbackContext']?!0x0:_0x455ee7['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x463703,_0x1f40d2,_0x429571,_0x3e7e13,_0x58cf85){const _0x293810=new pa(_0x429571,void 0x0),_0x52d2e4=new Qn(_0x293810);return kd(_0x463703['_repo'],_0x463703,_0x52d2e4),()=>Pd(_0x463703['_repo'],_0x463703,_0x52d2e4);}function Gd(_0x41ac2d,_0x13b818,_0x3e2bfb,_0x893169){return $d(_0x41ac2d,'value',_0x13b818);}class mt{}class ma extends mt{constructor(_0x545021,_0x2d87ca){super(),this['_value']=_0x545021,this['_key']=_0x2d87ca,this['type']='endAt';}['_apply'](_0x179d19){He('endAt',this['_value'],_0x179d19['_path'],!0x0);const _0x2b6da2=Jh(_0x179d19['_queryParams'],this['_value'],this['_key']);if(ga(_0x2b6da2),Yn(_0x2b6da2),_0x179d19['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x179d19['_repo'],_0x179d19['_path'],_0x2b6da2,_0x179d19['_orderByCalled']);}}function C_(_0x1cedc7,_0x56d4e9){return new ma(_0x1cedc7,_0x56d4e9);}class ya extends mt{constructor(_0x238e2d,_0x56ff76){super(),this['_value']=_0x238e2d,this['_key']=_0x56ff76,this['type']='startAt';}['_apply'](_0x4f7c3e){He('startAt',this['_value'],_0x4f7c3e['_path'],!0x0);const _0x881394=Qh(_0x4f7c3e['_queryParams'],this['_value'],this['_key']);if(ga(_0x881394),Yn(_0x881394),_0x4f7c3e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x4f7c3e['_repo'],_0x4f7c3e['_path'],_0x881394,_0x4f7c3e['_orderByCalled']);}}function T_(_0x36a6c2=null,_0x4b2328){return new ya(_0x36a6c2,_0x4b2328);}class qd extends mt{constructor(_0x1c4a5a){super(),this['_limit']=_0x1c4a5a,this['type']='limitToFirst';}['_apply'](_0x106d40){if(_0x106d40['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x106d40['_repo'],_0x106d40['_path'],Yh(_0x106d40['_queryParams'],this['_limit']),_0x106d40['_orderByCalled']);}}function S_(_0x5a6d38){if(Math['floor'](_0x5a6d38)!==_0x5a6d38||_0x5a6d38<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x5a6d38);}class zd extends mt{constructor(_0x2095ed){super(),this['_path']=_0x2095ed,this['type']='orderByChild';}['_apply'](_0x146885){_a(_0x146885,'orderByChild');const _0x51a9ae=new C(this['_path']);if(v(_0x51a9ae))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2f6383=new Ji(_0x51a9ae),_0x3d2439=xo(_0x146885['_queryParams'],_0x2f6383);return Yn(_0x3d2439),new Ae(_0x146885['_repo'],_0x146885['_path'],_0x3d2439,!0x0);}}function b_(_0x43dab1){if(_0x43dab1==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x43dab1==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x43dab1==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x43dab1),new zd(_0x43dab1);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x33953f){_a(_0x33953f,'orderByKey');const _0x5570dd=xo(_0x33953f['_queryParams'],ve);return Yn(_0x5570dd),new Ae(_0x33953f['_repo'],_0x33953f['_path'],_0x5570dd,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x1d28a9,_0xef26a8){super(),this['_value']=_0x1d28a9,this['_key']=_0xef26a8,this['type']='equalTo';}['_apply'](_0x107110){if(He('equalTo',this['_value'],_0x107110['_path'],!0x1),_0x107110['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x107110['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x107110));}}function A_(_0x1a1eac,_0x354b8f){return new Kd(_0x1a1eac,_0x354b8f);}function k_(_0x335ed8,..._0x5e1df0){let _0x4021fb=P(_0x335ed8);for(const _0x522989 of _0x5e1df0)_0x4021fb=_0x522989['_apply'](_0x4021fb);return _0x4021fb;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0xacde43,_0x2e1a18,_0x2d3131,_0x427cb0){const _0x455caa=_0x2e1a18['lastIndexOf'](':'),_0x5cef18=_0x2e1a18['substring'](0x0,_0x455caa),_0x4575d9=qt(_0x5cef18);_0xacde43['repoInfo_']=new yo(_0x2e1a18,_0x4575d9,_0xacde43['repoInfo_']['namespace'],_0xacde43['repoInfo_']['webSocketOnly'],_0xacde43['repoInfo_']['nodeAdmin'],_0xacde43['repoInfo_']['persistenceKey'],_0xacde43['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2d3131),_0x427cb0&&(_0xacde43['authTokenProvider_']=_0x427cb0);}function Xd(_0x3c0192,_0x40aae7,_0x57e11c,_0x211097,_0x46ba8f){let _0x24a613=_0x211097||_0x3c0192['options']['databaseURL'];_0x24a613===void 0x0&&(_0x3c0192['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3c0192['options']['projectId']),_0x24a613=_0x3c0192['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x47710f=vr(_0x24a613,_0x46ba8f),_0x1f306d=_0x47710f['repoInfo'],_0x5a5e3b;typeof process<'u'&&Bs&&(_0x5a5e3b=Bs[Yd]),_0x5a5e3b?(_0x24a613='http://'+_0x5a5e3b+'?ns='+_0x1f306d['namespace'],_0x47710f=vr(_0x24a613,_0x46ba8f),_0x1f306d=_0x47710f['repoInfo']):_0x47710f['repoInfo']['secure'];const _0x5e303d=new eh(_0x3c0192['name'],_0x3c0192['options'],_0x40aae7);_d('Invalid\x20Firebase\x20Database\x20URL',_0x47710f),v(_0x47710f['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x378642=ef(_0x1f306d,_0x3c0192,_0x5e303d,new Zl(_0x3c0192,_0x57e11c));return new tf(_0x378642,_0x3c0192);}function Zd(_0x27ece7,_0x5ef1cd){const _0x41180d=Di[_0x5ef1cd];(!_0x41180d||_0x41180d[_0x27ece7['key']]!==_0x27ece7)&&ae('Database\x20'+_0x5ef1cd+'('+_0x27ece7['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x27ece7),delete _0x41180d[_0x27ece7['key']];}function ef(_0x846048,_0x12e4da,_0x2831fe,_0x2dd585){let _0xc4d748=Di[_0x12e4da['name']];_0xc4d748||(_0xc4d748={},Di[_0x12e4da['name']]=_0xc4d748);let _0x4ad555=_0xc4d748[_0x846048['toURLString']()];return _0x4ad555&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4ad555=new vd(_0x846048,Qd,_0x2831fe,_0x2dd585),_0xc4d748[_0x846048['toURLString']()]=_0x4ad555,_0x4ad555;}class tf{constructor(_0x55ad9f,_0x30e68e){this['_repoInternal']=_0x55ad9f,this['app']=_0x30e68e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x307e02){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x307e02+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x293e92=Zr(),_0x8eecc){const _0x8043c1=Hi(_0x293e92,'database')['getImmediate']({'identifier':_0x8eecc});if(!_0x8043c1['_instanceStarted']){const _0x396a66=hc('database');_0x396a66&&nf(_0x8043c1,..._0x396a66);}return _0x8043c1;}function nf(_0x107f2c,_0x5cf4ec,_0x718d47,_0x48438d={}){_0x107f2c=P(_0x107f2c),_0x107f2c['_checkNotDeleted']('useEmulator');const _0x4cedbe=_0x5cf4ec+':'+_0x718d47,_0x2309dc=_0x107f2c['_repoInternal'];if(_0x107f2c['_instanceStarted']){if(_0x4cedbe===_0x107f2c['_repoInternal']['repoInfo_']['host']&&xe(_0x48438d,_0x2309dc['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x202488;if(_0x2309dc['repoInfo_']['nodeAdmin'])_0x48438d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x202488=new an(an['OWNER']);else{if(_0x48438d['mockUserToken']){const _0x14c17c=typeof _0x48438d['mockUserToken']=='string'?_0x48438d['mockUserToken']:uc(_0x48438d['mockUserToken'],_0x107f2c['app']['options']['projectId']);_0x202488=new an(_0x14c17c);}}qt(_0x5cf4ec)&&Qr(_0x5cf4ec),Jd(_0x2309dc,_0x4cedbe,_0x48438d,_0x202488);}function N_(_0x228759){_0x228759=P(_0x228759),_0x228759['_checkNotDeleted']('goOffline'),ha(_0x228759['_repo']);}function O_(_0x1253d6){_0x1253d6=P(_0x1253d6),_0x1253d6['_checkNotDeleted']('goOnline'),Nd(_0x1253d6['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x30f794){Ul(dt),st(new Fe('database',(_0x2b18a0,{instanceIdentifier:_0x2d5150})=>{const _0x4bae9d=_0x2b18a0['getProvider']('app')['getImmediate'](),_0x91e4a5=_0x2b18a0['getProvider']('auth-internal'),_0x346d57=_0x2b18a0['getProvider']('app-check-internal');return Xd(_0x4bae9d,_0x91e4a5,_0x346d57,_0x2d5150);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x30f794),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x23979a,_0xd5b0ef){this['committed']=_0x23979a,this['snapshot']=_0xd5b0ef;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x1f8ae8,_0x286dce,_0x2e3a7a){if(_0x1f8ae8=P(_0x1f8ae8),Me('Reference.transaction',_0x1f8ae8['_path']),_0x1f8ae8['key']==='.length'||_0x1f8ae8['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x1f8ae8['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3b98e0=!0x0,_0x34f0ad=new H(),_0x3b61c7=(_0x4c74f6,_0x2464b0,_0x10fea3)=>{let _0x547256=null;_0x4c74f6?_0x34f0ad['reject'](_0x4c74f6):(_0x547256=new lt(_0x10fea3,new ee(_0x1f8ae8['_repo'],_0x1f8ae8['_path']),R),_0x34f0ad['resolve'](new of(_0x2464b0,_0x547256)));},_0x5804c9=Gd(_0x1f8ae8,()=>{});return Od(_0x1f8ae8['_repo'],_0x1f8ae8['_path'],_0x286dce,_0x3b61c7,_0x5804c9,_0x3b98e0),_0x34f0ad['promise'];}se['prototype']['simpleListen']=function(_0x332b9b,_0x349e43){this['sendRequest']('q',{'p':_0x332b9b},_0x349e43);},se['prototype']['echo']=function(_0x997a01,_0x4c4ac3){this['sendRequest']('echo',{'d':_0x997a01},_0x4c4ac3);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x35f06f,..._0x348d7a){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x35f06f,..._0x348d7a);}function cn(_0x3119bf,..._0x31bc43){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3119bf,..._0x31bc43);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x34fe06,..._0x1c2301){throw ws(_0x34fe06,..._0x1c2301);}function X(_0x246d2c,..._0x20ed55){return ws(_0x246d2c,..._0x20ed55);}function Ia(_0x2e5c81,_0x10a1c1,_0x5b9688){const _0x3820cc={...af(),[_0x10a1c1]:_0x5b9688};return new Gt('auth','Firebase',_0x3820cc)['create'](_0x10a1c1,{'appName':_0x2e5c81['name']});}function re(_0x4c51fe){return Ia(_0x4c51fe,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1e88ec,..._0x5678ac){if(typeof _0x1e88ec!='string'){const _0xffb9e5=_0x5678ac[0x0],_0x1461ad=[..._0x5678ac['slice'](0x1)];return _0x1461ad[0x0]&&(_0x1461ad[0x0]['appName']=_0x1e88ec['name']),_0x1e88ec['_errorFactory']['create'](_0xffb9e5,..._0x1461ad);}return Ea['create'](_0x1e88ec,..._0x5678ac);}function m(_0x30f6ba,_0x4262da,..._0x2472d8){if(!_0x30f6ba)throw ws(_0x4262da,..._0x2472d8);}function ne(_0x440b4d){const _0x56e7aa='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x440b4d;throw cn(_0x56e7aa),new Error(_0x56e7aa);}function ce(_0x2c2f66,_0x465723){_0x2c2f66||ne(_0x465723);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x40d0a5;return typeof self<'u'&&((_0x40d0a5=self['location'])==null?void 0x0:_0x40d0a5['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x410e3b;return typeof self<'u'&&((_0x410e3b=self['location'])==null?void 0x0:_0x410e3b['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x24cb38=navigator;return _0x24cb38['languages']&&_0x24cb38['languages'][0x0]||_0x24cb38['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x57460b,_0xd29bb1){this['shortDelay']=_0x57460b,this['longDelay']=_0xd29bb1,ce(_0xd29bb1>_0x57460b,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x46b474,_0x20deaa){ce(_0x46b474['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3d1f6c}=_0x46b474['emulator'];return _0x20deaa?''+_0x3d1f6c+(_0x20deaa['startsWith']('/')?_0x20deaa['slice'](0x1):_0x20deaa):_0x3d1f6c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x2892e9,_0x359793,_0xda242d){this['fetchImpl']=_0x2892e9,_0x359793&&(this['headersImpl']=_0x359793),_0xda242d&&(this['responseImpl']=_0xda242d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x176b25,_0x655d09){return _0x176b25['tenantId']&&!_0x655d09['tenantId']?{..._0x655d09,'tenantId':_0x176b25['tenantId']}:_0x655d09;}async function Pe(_0x53b280,_0x1e98b7,_0x27730a,_0x3823f8,_0x528534={}){return Ca(_0x53b280,_0x528534,async()=>{let _0x4a8344={},_0x4f8e57={};_0x3823f8&&(_0x1e98b7==='GET'?_0x4f8e57=_0x3823f8:_0x4a8344={'body':JSON['stringify'](_0x3823f8)});const _0xe40d25=ut({..._0x4f8e57,'key':_0x53b280['config']['apiKey']})['slice'](0x1),_0x5243a5=await _0x53b280['_getAdditionalHeaders']();_0x5243a5['Content-Type']='application/json',_0x53b280['languageCode']&&(_0x5243a5['X-Firebase-Locale']=_0x53b280['languageCode']);const _0x2a8152={'method':_0x1e98b7,'headers':_0x5243a5,..._0x4a8344};return dc()||(_0x2a8152['referrerPolicy']='strict-origin-when-cross-origin'),_0x53b280['emulatorConfig']&&qt(_0x53b280['emulatorConfig']['host'])&&(_0x2a8152['credentials']='include'),wa['fetch']()(await Ta(_0x53b280,_0x53b280['config']['apiHost'],_0x27730a,_0xe40d25),_0x2a8152);});}async function Ca(_0x5ccacc,_0x454a93,_0x20dfa7){_0x5ccacc['_canInitEmulator']=!0x1;const _0x31c00b={...df,..._0x454a93};try{const _0x509940=new gf(_0x5ccacc),_0x462dc2=await Promise['race']([_0x20dfa7(),_0x509940['promise']]);_0x509940['clearNetworkTimeout']();const _0x36d05d=await _0x462dc2['json']();if('needConfirmation'in _0x36d05d)throw on(_0x5ccacc,'account-exists-with-different-credential',_0x36d05d);if(_0x462dc2['ok']&&!('errorMessage'in _0x36d05d))return _0x36d05d;{const _0xd19683=_0x462dc2['ok']?_0x36d05d['errorMessage']:_0x36d05d['error']['message'],[_0x19f4e0,_0xd4f127]=_0xd19683['split']('\x20:\x20');if(_0x19f4e0==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x5ccacc,'credential-already-in-use',_0x36d05d);if(_0x19f4e0==='EMAIL_EXISTS')throw on(_0x5ccacc,'email-already-in-use',_0x36d05d);if(_0x19f4e0==='USER_DISABLED')throw on(_0x5ccacc,'user-disabled',_0x36d05d);const _0x5abdef=_0x31c00b[_0x19f4e0]||_0x19f4e0['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xd4f127)throw Ia(_0x5ccacc,_0x5abdef,_0xd4f127);Y(_0x5ccacc,_0x5abdef);}}catch(_0x3bee2b){if(_0x3bee2b instanceof Re)throw _0x3bee2b;Y(_0x5ccacc,'network-request-failed',{'message':String(_0x3bee2b)});}}async function en(_0x2cc221,_0x7f9fe5,_0x1500bd,_0x1fad1e,_0xcdecea={}){const _0x167406=await Pe(_0x2cc221,_0x7f9fe5,_0x1500bd,_0x1fad1e,_0xcdecea);return'mfaPendingCredential'in _0x167406&&Y(_0x2cc221,'multi-factor-auth-required',{'_serverResponse':_0x167406}),_0x167406;}async function Ta(_0x411c90,_0x8e9b1d,_0x1c830e,_0x36b799){const _0x526eaf=''+_0x8e9b1d+_0x1c830e+'?'+_0x36b799,_0x46b2e1=_0x411c90,_0x4afc55=_0x46b2e1['config']['emulator']?Cs(_0x411c90['config'],_0x526eaf):_0x411c90['config']['apiScheme']+'://'+_0x526eaf;return ff['includes'](_0x1c830e)&&(await _0x46b2e1['_persistenceManagerAvailable'],_0x46b2e1['_getPersistenceType']()==='COOKIE')?_0x46b2e1['_getPersistence']()['_getFinalTarget'](_0x4afc55)['toString']():_0x4afc55;}function _f(_0x50bc07){switch(_0x50bc07){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x44d2fd){this['auth']=_0x44d2fd,this['timer']=null,this['promise']=new Promise((_0x3e719e,_0x10aa8b)=>{this['timer']=setTimeout(()=>_0x10aa8b(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x2d21b8,_0x3a9471,_0x231f5a){const _0x3ea198={'appName':_0x2d21b8['name']};_0x231f5a['email']&&(_0x3ea198['email']=_0x231f5a['email']),_0x231f5a['phoneNumber']&&(_0x3ea198['phoneNumber']=_0x231f5a['phoneNumber']);const _0x47a7b6=X(_0x2d21b8,_0x3a9471,_0x3ea198);return _0x47a7b6['customData']['_tokenResponse']=_0x231f5a,_0x47a7b6;}function wr(_0x4032d4){return _0x4032d4!==void 0x0&&_0x4032d4['enterprise']!==void 0x0;}class mf{constructor(_0x11ae5a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x11ae5a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x11ae5a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x11ae5a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4f7fa5){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x7161b1 of this['recaptchaEnforcementState'])if(_0x7161b1['provider']&&_0x7161b1['provider']===_0x4f7fa5)return _f(_0x7161b1['enforcementState']);return null;}['isProviderEnabled'](_0x23601d){return this['getProviderEnforcementState'](_0x23601d)==='ENFORCE'||this['getProviderEnforcementState'](_0x23601d)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x13e020,_0x3fc2dd){return Pe(_0x13e020,'GET','/v2/recaptchaConfig',ke(_0x13e020,_0x3fc2dd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x593e85,_0x4ce106){return Pe(_0x593e85,'POST','/v1/accounts:delete',_0x4ce106);}async function Pn(_0x5d9b5b,_0x51aa76){return Pe(_0x5d9b5b,'POST','/v1/accounts:lookup',_0x51aa76);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1fbc26){if(_0x1fbc26)try{const _0x2f5061=new Date(Number(_0x1fbc26));if(!isNaN(_0x2f5061['getTime']()))return _0x2f5061['toUTCString']();}catch{}}async function Ef(_0x5bcbdc,_0x12d894=!0x1){const _0x385715=P(_0x5bcbdc),_0x315c3b=await _0x385715['getIdToken'](_0x12d894),_0x3b17d1=Ts(_0x315c3b);m(_0x3b17d1&&_0x3b17d1['exp']&&_0x3b17d1['auth_time']&&_0x3b17d1['iat'],_0x385715['auth'],'internal-error');const _0x44b78b=typeof _0x3b17d1['firebase']=='object'?_0x3b17d1['firebase']:void 0x0,_0x82576a=_0x44b78b==null?void 0x0:_0x44b78b['sign_in_provider'];return{'claims':_0x3b17d1,'token':_0x315c3b,'authTime':Pt(fi(_0x3b17d1['auth_time'])),'issuedAtTime':Pt(fi(_0x3b17d1['iat'])),'expirationTime':Pt(fi(_0x3b17d1['exp'])),'signInProvider':_0x82576a||null,'signInSecondFactor':(_0x44b78b==null?void 0x0:_0x44b78b['sign_in_second_factor'])||null};}function fi(_0xf89e35){return Number(_0xf89e35)*0x3e8;}function Ts(_0x5ee841){const [_0x4ee3ee,_0x32f869,_0x31fff0]=_0x5ee841['split']('.');if(_0x4ee3ee===void 0x0||_0x32f869===void 0x0||_0x31fff0===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x9cf088=fn(_0x32f869);return _0x9cf088?JSON['parse'](_0x9cf088):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2e497e){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2e497e==null?void 0x0:_0x2e497e['toString']()),null;}}function Cr(_0x1dd752){const _0x38be5b=Ts(_0x1dd752);return m(_0x38be5b,'internal-error'),m(typeof _0x38be5b['exp']<'u','internal-error'),m(typeof _0x38be5b['iat']<'u','internal-error'),Number(_0x38be5b['exp'])-Number(_0x38be5b['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x8310d,_0x47c6a4,_0x392717=!0x1){if(_0x392717)return _0x47c6a4;try{return await _0x47c6a4;}catch(_0x1b5c77){throw _0x1b5c77 instanceof Re&&If(_0x1b5c77)&&_0x8310d['auth']['currentUser']===_0x8310d&&await _0x8310d['auth']['signOut'](),_0x1b5c77;}}function If({code:_0x1936db}){return _0x1936db==='auth/user-disabled'||_0x1936db==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x415b28){this['user']=_0x415b28,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x484e38){if(_0x484e38){const _0x1469d6=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1469d6;}else{this['errorBackoff']=0x7530;const _0x49e33c=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x49e33c);}}['schedule'](_0x4b0f96=!0x1){if(!this['isRunning'])return;const _0x27fb0e=this['getInterval'](_0x4b0f96);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x27fb0e);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x24e9a6){(_0x24e9a6==null?void 0x0:_0x24e9a6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x2a9fd6,_0x418471){this['createdAt']=_0x2a9fd6,this['lastLoginAt']=_0x418471,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x3b4f6f){this['createdAt']=_0x3b4f6f['createdAt'],this['lastLoginAt']=_0x3b4f6f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x37e11c){var _0xcec86b;const _0x46be5c=_0x37e11c['auth'],_0x222c94=await _0x37e11c['getIdToken'](),_0x556db8=await Ht(_0x37e11c,Pn(_0x46be5c,{'idToken':_0x222c94}));m(_0x556db8==null?void 0x0:_0x556db8['users']['length'],_0x46be5c,'internal-error');const _0x142a55=_0x556db8['users'][0x0];_0x37e11c['_notifyReloadListener'](_0x142a55);const _0x3f6c5b=(_0xcec86b=_0x142a55['providerUserInfo'])!=null&&_0xcec86b['length']?Sa(_0x142a55['providerUserInfo']):[],_0x27df7e=Tf(_0x37e11c['providerData'],_0x3f6c5b),_0x2d083e=_0x37e11c['isAnonymous'],_0x3c0da6=!(_0x37e11c['email']&&_0x142a55['passwordHash'])&&!(_0x27df7e!=null&&_0x27df7e['length']),_0x1e5b2d=_0x2d083e?_0x3c0da6:!0x1,_0x593bdd={'uid':_0x142a55['localId'],'displayName':_0x142a55['displayName']||null,'photoURL':_0x142a55['photoUrl']||null,'email':_0x142a55['email']||null,'emailVerified':_0x142a55['emailVerified']||!0x1,'phoneNumber':_0x142a55['phoneNumber']||null,'tenantId':_0x142a55['tenantId']||null,'providerData':_0x27df7e,'metadata':new Li(_0x142a55['createdAt'],_0x142a55['lastLoginAt']),'isAnonymous':_0x1e5b2d};Object['assign'](_0x37e11c,_0x593bdd);}async function Cf(_0x13b3f8){const _0x36da09=P(_0x13b3f8);await Nn(_0x36da09),await _0x36da09['auth']['_persistUserIfCurrent'](_0x36da09),_0x36da09['auth']['_notifyListenersIfCurrent'](_0x36da09);}function Tf(_0x3ab403,_0x14cd52){return[..._0x3ab403['filter'](_0x4ee921=>!_0x14cd52['some'](_0xafc4d2=>_0xafc4d2['providerId']===_0x4ee921['providerId'])),..._0x14cd52];}function Sa(_0x232969){return _0x232969['map'](({providerId:_0x398cd3,..._0x53778e})=>({'providerId':_0x398cd3,'uid':_0x53778e['rawId']||'','displayName':_0x53778e['displayName']||null,'email':_0x53778e['email']||null,'phoneNumber':_0x53778e['phoneNumber']||null,'photoURL':_0x53778e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x51d8dc,_0x57ad32){const _0xcef3cf=await Ca(_0x51d8dc,{},async()=>{const _0x1fc7fe=ut({'grant_type':'refresh_token','refresh_token':_0x57ad32})['slice'](0x1),{tokenApiHost:_0x113b40,apiKey:_0xf4cbfd}=_0x51d8dc['config'],_0x3b042d=await Ta(_0x51d8dc,_0x113b40,'/v1/token','key='+_0xf4cbfd),_0x562007=await _0x51d8dc['_getAdditionalHeaders']();_0x562007['Content-Type']='application/x-www-form-urlencoded';const _0x3cd3f1={'method':'POST','headers':_0x562007,'body':_0x1fc7fe};return _0x51d8dc['emulatorConfig']&&qt(_0x51d8dc['emulatorConfig']['host'])&&(_0x3cd3f1['credentials']='include'),wa['fetch']()(_0x3b042d,_0x3cd3f1);});return{'accessToken':_0xcef3cf['access_token'],'expiresIn':_0xcef3cf['expires_in'],'refreshToken':_0xcef3cf['refresh_token']};}async function bf(_0x3e4aea,_0x393e35){return Pe(_0x3e4aea,'POST','/v2/accounts:revokeToken',ke(_0x3e4aea,_0x393e35));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2cf242){m(_0x2cf242['idToken'],'internal-error'),m(typeof _0x2cf242['idToken']<'u','internal-error'),m(typeof _0x2cf242['refreshToken']<'u','internal-error');const _0x1bbe1c='expiresIn'in _0x2cf242&&typeof _0x2cf242['expiresIn']<'u'?Number(_0x2cf242['expiresIn']):Cr(_0x2cf242['idToken']);this['updateTokensAndExpiration'](_0x2cf242['idToken'],_0x2cf242['refreshToken'],_0x1bbe1c);}['updateFromIdToken'](_0x437fcb){m(_0x437fcb['length']!==0x0,'internal-error');const _0x12832b=Cr(_0x437fcb);this['updateTokensAndExpiration'](_0x437fcb,null,_0x12832b);}async['getToken'](_0x2696ca,_0x2c47ef=!0x1){return!_0x2c47ef&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2696ca,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2696ca,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2c0a2a,_0x854f04){const {accessToken:_0x28e68f,refreshToken:_0x42eb87,expiresIn:_0x2f964d}=await Sf(_0x2c0a2a,_0x854f04);this['updateTokensAndExpiration'](_0x28e68f,_0x42eb87,Number(_0x2f964d));}['updateTokensAndExpiration'](_0x5960f9,_0x123b97,_0x1d6c5d){this['refreshToken']=_0x123b97||null,this['accessToken']=_0x5960f9||null,this['expirationTime']=Date['now']()+_0x1d6c5d*0x3e8;}static['fromJSON'](_0x30860d,_0x5163fb){const {refreshToken:_0x15cde8,accessToken:_0x3fdb2a,expirationTime:_0x3d1c41}=_0x5163fb,_0x7e6d17=new et();return _0x15cde8&&(m(typeof _0x15cde8=='string','internal-error',{'appName':_0x30860d}),_0x7e6d17['refreshToken']=_0x15cde8),_0x3fdb2a&&(m(typeof _0x3fdb2a=='string','internal-error',{'appName':_0x30860d}),_0x7e6d17['accessToken']=_0x3fdb2a),_0x3d1c41&&(m(typeof _0x3d1c41=='number','internal-error',{'appName':_0x30860d}),_0x7e6d17['expirationTime']=_0x3d1c41),_0x7e6d17;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5c3b86){this['accessToken']=_0x5c3b86['accessToken'],this['refreshToken']=_0x5c3b86['refreshToken'],this['expirationTime']=_0x5c3b86['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2597e6,_0x2df629){m(typeof _0x2597e6=='string'||typeof _0x2597e6>'u','internal-error',{'appName':_0x2df629});}class j{constructor({uid:_0xd51220,auth:_0x571bbf,stsTokenManager:_0x387f46,..._0x4e15b2}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xd51220,this['auth']=_0x571bbf,this['stsTokenManager']=_0x387f46,this['accessToken']=_0x387f46['accessToken'],this['displayName']=_0x4e15b2['displayName']||null,this['email']=_0x4e15b2['email']||null,this['emailVerified']=_0x4e15b2['emailVerified']||!0x1,this['phoneNumber']=_0x4e15b2['phoneNumber']||null,this['photoURL']=_0x4e15b2['photoURL']||null,this['isAnonymous']=_0x4e15b2['isAnonymous']||!0x1,this['tenantId']=_0x4e15b2['tenantId']||null,this['providerData']=_0x4e15b2['providerData']?[..._0x4e15b2['providerData']]:[],this['metadata']=new Li(_0x4e15b2['createdAt']||void 0x0,_0x4e15b2['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1ea693){const _0x5ac000=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1ea693));return m(_0x5ac000,this['auth'],'internal-error'),this['accessToken']!==_0x5ac000&&(this['accessToken']=_0x5ac000,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5ac000;}['getIdTokenResult'](_0x42a7e0){return Ef(this,_0x42a7e0);}['reload'](){return Cf(this);}['_assign'](_0x10c515){this!==_0x10c515&&(m(this['uid']===_0x10c515['uid'],this['auth'],'internal-error'),this['displayName']=_0x10c515['displayName'],this['photoURL']=_0x10c515['photoURL'],this['email']=_0x10c515['email'],this['emailVerified']=_0x10c515['emailVerified'],this['phoneNumber']=_0x10c515['phoneNumber'],this['isAnonymous']=_0x10c515['isAnonymous'],this['tenantId']=_0x10c515['tenantId'],this['providerData']=_0x10c515['providerData']['map'](_0x4733dd=>({..._0x4733dd})),this['metadata']['_copy'](_0x10c515['metadata']),this['stsTokenManager']['_assign'](_0x10c515['stsTokenManager']));}['_clone'](_0x22c740){const _0x2d0b81=new j({...this,'auth':_0x22c740,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2d0b81['metadata']['_copy'](this['metadata']),_0x2d0b81;}['_onReload'](_0x26c087){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x26c087,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x444f46){this['reloadListener']?this['reloadListener'](_0x444f46):this['reloadUserInfo']=_0x444f46;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4f2aae,_0x5308b3=!0x1){let _0x132d22=!0x1;_0x4f2aae['idToken']&&_0x4f2aae['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4f2aae),_0x132d22=!0x0),_0x5308b3&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x132d22&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x233377=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x233377})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xf79d3d=>({..._0xf79d3d})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x435584,_0x2d582a){const _0x419f36=_0x2d582a['displayName']??void 0x0,_0x3af15c=_0x2d582a['email']??void 0x0,_0x48bd42=_0x2d582a['phoneNumber']??void 0x0,_0x4ac54f=_0x2d582a['photoURL']??void 0x0,_0x559865=_0x2d582a['tenantId']??void 0x0,_0x172798=_0x2d582a['_redirectEventId']??void 0x0,_0xc7c78=_0x2d582a['createdAt']??void 0x0,_0xbed7d9=_0x2d582a['lastLoginAt']??void 0x0,{uid:_0x409b90,emailVerified:_0x335abe,isAnonymous:_0x21ace6,providerData:_0xff0a18,stsTokenManager:_0x23dbfd}=_0x2d582a;m(_0x409b90&&_0x23dbfd,_0x435584,'internal-error');const _0x40d71c=et['fromJSON'](this['name'],_0x23dbfd);m(typeof _0x409b90=='string',_0x435584,'internal-error'),le(_0x419f36,_0x435584['name']),le(_0x3af15c,_0x435584['name']),m(typeof _0x335abe=='boolean',_0x435584,'internal-error'),m(typeof _0x21ace6=='boolean',_0x435584,'internal-error'),le(_0x48bd42,_0x435584['name']),le(_0x4ac54f,_0x435584['name']),le(_0x559865,_0x435584['name']),le(_0x172798,_0x435584['name']),le(_0xc7c78,_0x435584['name']),le(_0xbed7d9,_0x435584['name']);const _0x964fe2=new j({'uid':_0x409b90,'auth':_0x435584,'email':_0x3af15c,'emailVerified':_0x335abe,'displayName':_0x419f36,'isAnonymous':_0x21ace6,'photoURL':_0x4ac54f,'phoneNumber':_0x48bd42,'tenantId':_0x559865,'stsTokenManager':_0x40d71c,'createdAt':_0xc7c78,'lastLoginAt':_0xbed7d9});return _0xff0a18&&Array['isArray'](_0xff0a18)&&(_0x964fe2['providerData']=_0xff0a18['map'](_0x155b3a=>({..._0x155b3a}))),_0x172798&&(_0x964fe2['_redirectEventId']=_0x172798),_0x964fe2;}static async['_fromIdTokenResponse'](_0x1540c0,_0x368b34,_0x59e9cc=!0x1){const _0x29877c=new et();_0x29877c['updateFromServerResponse'](_0x368b34);const _0x417acf=new j({'uid':_0x368b34['localId'],'auth':_0x1540c0,'stsTokenManager':_0x29877c,'isAnonymous':_0x59e9cc});return await Nn(_0x417acf),_0x417acf;}static async['_fromGetAccountInfoResponse'](_0x5b2eba,_0x3135e2,_0x86629a){const _0x4f8f57=_0x3135e2['users'][0x0];m(_0x4f8f57['localId']!==void 0x0,'internal-error');const _0x1c35ab=_0x4f8f57['providerUserInfo']!==void 0x0?Sa(_0x4f8f57['providerUserInfo']):[],_0x2ccc37=!(_0x4f8f57['email']&&_0x4f8f57['passwordHash'])&&!(_0x1c35ab!=null&&_0x1c35ab['length']),_0x2cd13e=new et();_0x2cd13e['updateFromIdToken'](_0x86629a);const _0x17cced=new j({'uid':_0x4f8f57['localId'],'auth':_0x5b2eba,'stsTokenManager':_0x2cd13e,'isAnonymous':_0x2ccc37}),_0x53493e={'uid':_0x4f8f57['localId'],'displayName':_0x4f8f57['displayName']||null,'photoURL':_0x4f8f57['photoUrl']||null,'email':_0x4f8f57['email']||null,'emailVerified':_0x4f8f57['emailVerified']||!0x1,'phoneNumber':_0x4f8f57['phoneNumber']||null,'tenantId':_0x4f8f57['tenantId']||null,'providerData':_0x1c35ab,'metadata':new Li(_0x4f8f57['createdAt'],_0x4f8f57['lastLoginAt']),'isAnonymous':!(_0x4f8f57['email']&&_0x4f8f57['passwordHash'])&&!(_0x1c35ab!=null&&_0x1c35ab['length'])};return Object['assign'](_0x17cced,_0x53493e),_0x17cced;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4eb968){ce(_0x4eb968 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5663c9=Tr['get'](_0x4eb968);return _0x5663c9?(ce(_0x5663c9 instanceof _0x4eb968,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5663c9):(_0x5663c9=new _0x4eb968(),Tr['set'](_0x4eb968,_0x5663c9),_0x5663c9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x596ca9,_0x30d5ac){this['storage'][_0x596ca9]=_0x30d5ac;}async['_get'](_0x213528){const _0x3e1823=this['storage'][_0x213528];return _0x3e1823===void 0x0?null:_0x3e1823;}async['_remove'](_0xcab533){delete this['storage'][_0xcab533];}['_addListener'](_0x41e107,_0x160d20){}['_removeListener'](_0x85a812,_0x20e893){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x2970da,_0x4fb1d7,_0x357c68){return'firebase:'+_0x2970da+':'+_0x4fb1d7+':'+_0x357c68;}class tt{constructor(_0x2505f3,_0x3fc09c,_0x14c352){this['persistence']=_0x2505f3,this['auth']=_0x3fc09c,this['userKey']=_0x14c352;const {config:_0x50ec83,name:_0x565fb7}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x50ec83['apiKey'],_0x565fb7),this['fullPersistenceKey']=ln('persistence',_0x50ec83['apiKey'],_0x565fb7),this['boundEventHandler']=_0x3fc09c['_onStorageEvent']['bind'](_0x3fc09c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1e73b5){return this['persistence']['_set'](this['fullUserKey'],_0x1e73b5['toJSON']());}async['getCurrentUser'](){const _0x17ae3b=await this['persistence']['_get'](this['fullUserKey']);if(!_0x17ae3b)return null;if(typeof _0x17ae3b=='string'){const _0xa5bbdc=await Pn(this['auth'],{'idToken':_0x17ae3b})['catch'](()=>{});return _0xa5bbdc?j['_fromGetAccountInfoResponse'](this['auth'],_0xa5bbdc,_0x17ae3b):null;}return j['_fromJSON'](this['auth'],_0x17ae3b);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x8b9c92){if(this['persistence']===_0x8b9c92)return;const _0x4550b1=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x8b9c92,_0x4550b1)return this['setCurrentUser'](_0x4550b1);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3741d6,_0x4625b5,_0x3cd0c5='authUser'){if(!_0x4625b5['length'])return new tt(ie(Sr),_0x3741d6,_0x3cd0c5);const _0xd06763=(await Promise['all'](_0x4625b5['map'](async _0x28995f=>{if(await _0x28995f['_isAvailable']())return _0x28995f;})))['filter'](_0x41690f=>_0x41690f);let _0x383b98=_0xd06763[0x0]||ie(Sr);const _0x4585f1=ln(_0x3cd0c5,_0x3741d6['config']['apiKey'],_0x3741d6['name']);let _0x458d4f=null;for(const _0x7d10e2 of _0x4625b5)try{const _0x44e363=await _0x7d10e2['_get'](_0x4585f1);if(_0x44e363){let _0x331762;if(typeof _0x44e363=='string'){const _0x1f9778=await Pn(_0x3741d6,{'idToken':_0x44e363})['catch'](()=>{});if(!_0x1f9778)break;_0x331762=await j['_fromGetAccountInfoResponse'](_0x3741d6,_0x1f9778,_0x44e363);}else _0x331762=j['_fromJSON'](_0x3741d6,_0x44e363);_0x7d10e2!==_0x383b98&&(_0x458d4f=_0x331762),_0x383b98=_0x7d10e2;break;}}catch{}const _0x31e1db=_0xd06763['filter'](_0xf3d50d=>_0xf3d50d['_shouldAllowMigration']);return!_0x383b98['_shouldAllowMigration']||!_0x31e1db['length']?new tt(_0x383b98,_0x3741d6,_0x3cd0c5):(_0x383b98=_0x31e1db[0x0],_0x458d4f&&await _0x383b98['_set'](_0x4585f1,_0x458d4f['toJSON']()),await Promise['all'](_0x4625b5['map'](async _0x39cf12=>{if(_0x39cf12!==_0x383b98)try{await _0x39cf12['_remove'](_0x4585f1);}catch{}})),new tt(_0x383b98,_0x3741d6,_0x3cd0c5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x363143){const _0x20f98f=_0x363143['toLowerCase']();if(_0x20f98f['includes']('opera/')||_0x20f98f['includes']('opr/')||_0x20f98f['includes']('opios/'))return'Opera';if(Pa(_0x20f98f))return'IEMobile';if(_0x20f98f['includes']('msie')||_0x20f98f['includes']('trident/'))return'IE';if(_0x20f98f['includes']('edge/'))return'Edge';if(Ra(_0x20f98f))return'Firefox';if(_0x20f98f['includes']('silk/'))return'Silk';if(Oa(_0x20f98f))return'Blackberry';if(Da(_0x20f98f))return'Webos';if(Aa(_0x20f98f))return'Safari';if((_0x20f98f['includes']('chrome/')||ka(_0x20f98f))&&!_0x20f98f['includes']('edge/'))return'Chrome';if(Na(_0x20f98f))return'Android';{const _0x265601=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4c9bf6=_0x363143['match'](_0x265601);if((_0x4c9bf6==null?void 0x0:_0x4c9bf6['length'])===0x2)return _0x4c9bf6[0x1];}return'Other';}function Ra(_0x5c7060=W()){return/firefox\//i['test'](_0x5c7060);}function Aa(_0x2e9e2e=W()){const _0x26ebca=_0x2e9e2e['toLowerCase']();return _0x26ebca['includes']('safari/')&&!_0x26ebca['includes']('chrome/')&&!_0x26ebca['includes']('crios/')&&!_0x26ebca['includes']('android');}function ka(_0x5e2ae1=W()){return/crios\//i['test'](_0x5e2ae1);}function Pa(_0x586be2=W()){return/iemobile/i['test'](_0x586be2);}function Na(_0xbb808b=W()){return/android/i['test'](_0xbb808b);}function Oa(_0x471285=W()){return/blackberry/i['test'](_0x471285);}function Da(_0x358237=W()){return/webos/i['test'](_0x358237);}function Ss(_0x31335a=W()){return/iphone|ipad|ipod/i['test'](_0x31335a)||/macintosh/i['test'](_0x31335a)&&/mobile/i['test'](_0x31335a);}function Rf(_0x3ab509=W()){var _0x48c292;return Ss(_0x3ab509)&&!!((_0x48c292=window['navigator'])!=null&&_0x48c292['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x1ba239=W()){return Ss(_0x1ba239)||Na(_0x1ba239)||Da(_0x1ba239)||Oa(_0x1ba239)||/windows phone/i['test'](_0x1ba239)||Pa(_0x1ba239);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2b845d,_0xb4ebe=[]){let _0xca6540;switch(_0x2b845d){case'Browser':_0xca6540=br(W());break;case'Worker':_0xca6540=br(W())+'-'+_0x2b845d;break;default:_0xca6540=_0x2b845d;}const _0x1ac50b=_0xb4ebe['length']?_0xb4ebe['join'](','):'FirebaseCore-web';return _0xca6540+'/JsCore/'+dt+'/'+_0x1ac50b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x288314){this['auth']=_0x288314,this['queue']=[];}['pushCallback'](_0x3b85bc,_0x4b4f43){const _0x5a6910=_0x31cb08=>new Promise((_0x5c7994,_0xd837e6)=>{try{const _0x745015=_0x3b85bc(_0x31cb08);_0x5c7994(_0x745015);}catch(_0x357ff4){_0xd837e6(_0x357ff4);}});_0x5a6910['onAbort']=_0x4b4f43,this['queue']['push'](_0x5a6910);const _0x46d671=this['queue']['length']-0x1;return()=>{this['queue'][_0x46d671]=()=>Promise['resolve']();};}async['runMiddleware'](_0x379fd4){if(this['auth']['currentUser']===_0x379fd4)return;const _0xc24f9e=[];try{for(const _0x494446 of this['queue'])await _0x494446(_0x379fd4),_0x494446['onAbort']&&_0xc24f9e['push'](_0x494446['onAbort']);}catch(_0x30f68b){_0xc24f9e['reverse']();for(const _0x592baa of _0xc24f9e)try{_0x592baa();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x30f68b==null?void 0x0:_0x30f68b['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1fb63e,_0x411157={}){return Pe(_0x1fb63e,'GET','/v2/passwordPolicy',ke(_0x1fb63e,_0x411157));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3f165c){var _0x28e0a9;const _0x396184=_0x3f165c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x396184['minPasswordLength']??Nf,_0x396184['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x396184['maxPasswordLength']),_0x396184['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x396184['containsLowercaseCharacter']),_0x396184['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x396184['containsUppercaseCharacter']),_0x396184['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x396184['containsNumericCharacter']),_0x396184['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x396184['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3f165c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x28e0a9=_0x3f165c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x28e0a9['join'](''))??'',this['forceUpgradeOnSignin']=_0x3f165c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3f165c['schemaVersion'];}['validatePassword'](_0x2e9d5f){const _0x144d7d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2e9d5f,_0x144d7d),this['validatePasswordCharacterOptions'](_0x2e9d5f,_0x144d7d),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['meetsMinPasswordLength']??!0x0),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['meetsMaxPasswordLength']??!0x0),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['containsLowercaseLetter']??!0x0),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['containsUppercaseLetter']??!0x0),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['containsNumericCharacter']??!0x0),_0x144d7d['isValid']&&(_0x144d7d['isValid']=_0x144d7d['containsNonAlphanumericCharacter']??!0x0),_0x144d7d;}['validatePasswordLengthOptions'](_0x1a8f66,_0x4c3ada){const _0x254511=this['customStrengthOptions']['minPasswordLength'],_0x1d15a5=this['customStrengthOptions']['maxPasswordLength'];_0x254511&&(_0x4c3ada['meetsMinPasswordLength']=_0x1a8f66['length']>=_0x254511),_0x1d15a5&&(_0x4c3ada['meetsMaxPasswordLength']=_0x1a8f66['length']<=_0x1d15a5);}['validatePasswordCharacterOptions'](_0x3f1726,_0x1ce46e){this['updatePasswordCharacterOptionsStatuses'](_0x1ce46e,!0x1,!0x1,!0x1,!0x1);let _0x390fa8;for(let _0x26641b=0x0;_0x26641b<_0x3f1726['length'];_0x26641b++)_0x390fa8=_0x3f1726['charAt'](_0x26641b),this['updatePasswordCharacterOptionsStatuses'](_0x1ce46e,_0x390fa8>='a'&&_0x390fa8<='z',_0x390fa8>='A'&&_0x390fa8<='Z',_0x390fa8>='0'&&_0x390fa8<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x390fa8));}['updatePasswordCharacterOptionsStatuses'](_0x5a1ffc,_0x4a7d61,_0x3c5c03,_0xcdc916,_0x2dceed){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5a1ffc['containsLowercaseLetter']||(_0x5a1ffc['containsLowercaseLetter']=_0x4a7d61)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5a1ffc['containsUppercaseLetter']||(_0x5a1ffc['containsUppercaseLetter']=_0x3c5c03)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5a1ffc['containsNumericCharacter']||(_0x5a1ffc['containsNumericCharacter']=_0xcdc916)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5a1ffc['containsNonAlphanumericCharacter']||(_0x5a1ffc['containsNonAlphanumericCharacter']=_0x2dceed));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x39414b,_0x3e5074,_0x418c75,_0xf714cd){this['app']=_0x39414b,this['heartbeatServiceProvider']=_0x3e5074,this['appCheckServiceProvider']=_0x418c75,this['config']=_0xf714cd,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x39414b['name'],this['clientVersion']=_0xf714cd['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2e709b=>this['_resolvePersistenceManagerAvailable']=_0x2e709b);}['_initializeWithPersistence'](_0x465592,_0x1768eb){return _0x1768eb&&(this['_popupRedirectResolver']=ie(_0x1768eb)),this['_initializationPromise']=this['queue'](async()=>{var _0x1d969c,_0x98652b,_0x23ffd1;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x465592),(_0x1d969c=this['_resolvePersistenceManagerAvailable'])==null||_0x1d969c['call'](this),!this['_deleted'])){if((_0x98652b=this['_popupRedirectResolver'])!=null&&_0x98652b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1768eb),this['lastNotifiedUid']=((_0x23ffd1=this['currentUser'])==null?void 0x0:_0x23ffd1['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x37a64c=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x37a64c)){if(this['currentUser']&&_0x37a64c&&this['currentUser']['uid']===_0x37a64c['uid']){this['_currentUser']['_assign'](_0x37a64c),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x37a64c,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4e5c1c){try{const _0x7f7861=await Pn(this,{'idToken':_0x4e5c1c}),_0x26488c=await j['_fromGetAccountInfoResponse'](this,_0x7f7861,_0x4e5c1c);await this['directlySetCurrentUser'](_0x26488c);}catch(_0x2e9b30){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2e9b30),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1f0f02){var _0x5130da;if($(this['app'])){const _0x1c7c5e=this['app']['settings']['authIdToken'];return _0x1c7c5e?new Promise(_0x5ac5e8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1c7c5e)['then'](_0x5ac5e8,_0x5ac5e8));}):this['directlySetCurrentUser'](null);}const _0x4417a0=await this['assertedPersistence']['getCurrentUser']();let _0x362c50=_0x4417a0,_0x4ea245=!0x1;if(_0x1f0f02&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3a616a=(_0x5130da=this['redirectUser'])==null?void 0x0:_0x5130da['_redirectEventId'],_0x1b45f9=_0x362c50==null?void 0x0:_0x362c50['_redirectEventId'],_0x374c29=await this['tryRedirectSignIn'](_0x1f0f02);(!_0x3a616a||_0x3a616a===_0x1b45f9)&&(_0x374c29!=null&&_0x374c29['user'])&&(_0x362c50=_0x374c29['user'],_0x4ea245=!0x0);}if(!_0x362c50)return this['directlySetCurrentUser'](null);if(!_0x362c50['_redirectEventId']){if(_0x4ea245)try{await this['beforeStateQueue']['runMiddleware'](_0x362c50);}catch(_0x3322f3){_0x362c50=_0x4417a0,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3322f3));}return _0x362c50?this['reloadAndSetCurrentUserOrClear'](_0x362c50):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x362c50['_redirectEventId']?this['directlySetCurrentUser'](_0x362c50):this['reloadAndSetCurrentUserOrClear'](_0x362c50);}async['tryRedirectSignIn'](_0x3eec7d){let _0x4dcc5a=null;try{_0x4dcc5a=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3eec7d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4dcc5a;}async['reloadAndSetCurrentUserOrClear'](_0x4c5e1f){try{await Nn(_0x4c5e1f);}catch(_0x1b6563){if((_0x1b6563==null?void 0x0:_0x1b6563['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4c5e1f);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xe244dc){if($(this['app']))return Promise['reject'](re(this));const _0x24dfa0=_0xe244dc?P(_0xe244dc):null;return _0x24dfa0&&m(_0x24dfa0['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x24dfa0&&_0x24dfa0['_clone'](this));}async['_updateCurrentUser'](_0x563dda,_0x380880=!0x1){if(!this['_deleted'])return _0x563dda&&m(this['tenantId']===_0x563dda['tenantId'],this,'tenant-id-mismatch'),_0x380880||await this['beforeStateQueue']['runMiddleware'](_0x563dda),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x563dda),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x48282d){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x48282d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2f9eb7){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x297583=this['_getPasswordPolicyInternal']();return _0x297583['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x297583['validatePassword'](_0x2f9eb7);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x459cad=await Pf(this),_0x3b86ad=new Of(_0x459cad);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3b86ad:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3b86ad;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x228a00){this['_errorFactory']=new Gt('auth','Firebase',_0x228a00());}['onAuthStateChanged'](_0x56272e,_0x1a8487,_0x24b127){return this['registerStateListener'](this['authStateSubscription'],_0x56272e,_0x1a8487,_0x24b127);}['beforeAuthStateChanged'](_0x225e2f,_0x53657c){return this['beforeStateQueue']['pushCallback'](_0x225e2f,_0x53657c);}['onIdTokenChanged'](_0x64218e,_0x34f300,_0x202a44){return this['registerStateListener'](this['idTokenSubscription'],_0x64218e,_0x34f300,_0x202a44);}['authStateReady'](){return new Promise((_0xd7c8fb,_0x2fe477)=>{if(this['currentUser'])_0xd7c8fb();else{const _0x560fec=this['onAuthStateChanged'](()=>{_0x560fec(),_0xd7c8fb();},_0x2fe477);}});}async['revokeAccessToken'](_0x3ee168){if(this['currentUser']){const _0x1a024b=await this['currentUser']['getIdToken'](),_0x20be30={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3ee168,'idToken':_0x1a024b};this['tenantId']!=null&&(_0x20be30['tenantId']=this['tenantId']),await bf(this,_0x20be30);}}['toJSON'](){var _0x589568;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x589568=this['_currentUser'])==null?void 0x0:_0x589568['toJSON']()};}async['_setRedirectUser'](_0xa9b739,_0x25c2f7){const _0x3388f7=await this['getOrInitRedirectPersistenceManager'](_0x25c2f7);return _0xa9b739===null?_0x3388f7['removeCurrentUser']():_0x3388f7['setCurrentUser'](_0xa9b739);}async['getOrInitRedirectPersistenceManager'](_0x49e860){if(!this['redirectPersistenceManager']){const _0x1ff744=_0x49e860&&ie(_0x49e860)||this['_popupRedirectResolver'];m(_0x1ff744,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1ff744['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x32a360){var _0x17ead2,_0x205c92;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x17ead2=this['_currentUser'])==null?void 0x0:_0x17ead2['_redirectEventId'])===_0x32a360?this['_currentUser']:((_0x205c92=this['redirectUser'])==null?void 0x0:_0x205c92['_redirectEventId'])===_0x32a360?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xa1b7b){if(_0xa1b7b===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xa1b7b));}['_notifyListenersIfCurrent'](_0x43f76b){_0x43f76b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x142036;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x30ec6d=((_0x142036=this['currentUser'])==null?void 0x0:_0x142036['uid'])??null;this['lastNotifiedUid']!==_0x30ec6d&&(this['lastNotifiedUid']=_0x30ec6d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x162529,_0x22a5b4,_0x239497,_0x5dc580){if(this['_deleted'])return()=>{};const _0x973cbb=typeof _0x22a5b4=='function'?_0x22a5b4:_0x22a5b4['next']['bind'](_0x22a5b4);let _0x249cd0=!0x1;const _0x3383c2=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3383c2,this,'internal-error'),_0x3383c2['then'](()=>{_0x249cd0||_0x973cbb(this['currentUser']);}),typeof _0x22a5b4=='function'){const _0x287747=_0x162529['addObserver'](_0x22a5b4,_0x239497,_0x5dc580);return()=>{_0x249cd0=!0x0,_0x287747();};}else{const _0x53f0d9=_0x162529['addObserver'](_0x22a5b4);return()=>{_0x249cd0=!0x0,_0x53f0d9();};}}async['directlySetCurrentUser'](_0x470c8b){this['currentUser']&&this['currentUser']!==_0x470c8b&&this['_currentUser']['_stopProactiveRefresh'](),_0x470c8b&&this['isProactiveRefreshEnabled']&&_0x470c8b['_startProactiveRefresh'](),this['currentUser']=_0x470c8b,_0x470c8b?await this['assertedPersistence']['setCurrentUser'](_0x470c8b):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x32073a){return this['operations']=this['operations']['then'](_0x32073a,_0x32073a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x46c09d){!_0x46c09d||this['frameworks']['includes'](_0x46c09d)||(this['frameworks']['push'](_0x46c09d),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4b39e9;const _0x21f1b4={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x21f1b4['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x35fef1=await((_0x4b39e9=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4b39e9['getHeartbeatsHeader']());_0x35fef1&&(_0x21f1b4['X-Firebase-Client']=_0x35fef1);const _0x5b54a6=await this['_getAppCheckToken']();return _0x5b54a6&&(_0x21f1b4['X-Firebase-AppCheck']=_0x5b54a6),_0x21f1b4;}async['_getAppCheckToken'](){var _0x393e3c;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4499f0=await((_0x393e3c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x393e3c['getToken']());return _0x4499f0!=null&&_0x4499f0['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4499f0['error']),_0x4499f0==null?void 0x0:_0x4499f0['token'];}}function Ke(_0x2f0421){return P(_0x2f0421);}class Rr{constructor(_0x47e7ce){this['auth']=_0x47e7ce,this['observer']=null,this['addObserver']=Tc(_0x151872=>this['observer']=_0x151872);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x4b92fe){Jn=_0x4b92fe;}function xa(_0x436b96){return Jn['loadJS'](_0x436b96);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0xd4f26d){return'__'+_0xd4f26d+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x3a8b9f){_0x3a8b9f();}['execute'](_0x25f55b,_0xed86a8){return Promise['resolve']('token');}['render'](_0x58616c,_0x513be5){return'';}}class Wf{['ready'](_0x30a686){_0x30a686();}['execute'](_0x238266,_0x30ef51){return Promise['resolve']('token');}['render'](_0x14b3d1,_0x2d91fb){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x35bf13){this['type']=Bf,this['auth']=Ke(_0x35bf13);}async['verify'](_0x3025a2='verify',_0x358b5d=!0x1){async function _0x2a2aef(_0x18e6f4){if(!_0x358b5d){if(_0x18e6f4['tenantId']==null&&_0x18e6f4['_agentRecaptchaConfig']!=null)return _0x18e6f4['_agentRecaptchaConfig']['siteKey'];if(_0x18e6f4['tenantId']!=null&&_0x18e6f4['_tenantRecaptchaConfigs'][_0x18e6f4['tenantId']]!==void 0x0)return _0x18e6f4['_tenantRecaptchaConfigs'][_0x18e6f4['tenantId']]['siteKey'];}return new Promise(async(_0x2fed73,_0x403bd2)=>{yf(_0x18e6f4,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x6439aa=>{if(_0x6439aa['recaptchaKey']===void 0x0)_0x403bd2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2c434d=new mf(_0x6439aa);return _0x18e6f4['tenantId']==null?_0x18e6f4['_agentRecaptchaConfig']=_0x2c434d:_0x18e6f4['_tenantRecaptchaConfigs'][_0x18e6f4['tenantId']]=_0x2c434d,_0x2fed73(_0x2c434d['siteKey']);}})['catch'](_0x4f8f3e=>{_0x403bd2(_0x4f8f3e);});});}function _0x247efd(_0x37b8f4,_0xaf7a72,_0x5e6a88){const _0x337452=window['grecaptcha'];wr(_0x337452)?_0x337452['enterprise']['ready'](()=>{_0x337452['enterprise']['execute'](_0x37b8f4,{'action':_0x3025a2})['then'](_0x23f307=>{_0xaf7a72(_0x23f307);})['catch'](()=>{_0xaf7a72(Fa);});}):_0x5e6a88(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x263fe3,_0xc33687)=>{_0x2a2aef(this['auth'])['then'](async _0x4d0b3c=>{if(!_0x358b5d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x247efd(_0x4d0b3c,_0x263fe3,_0xc33687);else{if(typeof window>'u'){_0xc33687(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5df31e=Lf();_0x5df31e['length']!==0x0&&(_0x5df31e+=_0x4d0b3c+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5e9e26;(_0x5e9e26=he['scriptInjectionDeferred'])==null||_0x5e9e26['resolve']();},xa(_0x5df31e)['then'](()=>{var _0x4ac743;return(_0x4ac743=he['scriptInjectionDeferred'])==null?void 0x0:_0x4ac743['promise'];})['then'](()=>{_0x247efd(_0x4d0b3c,_0x263fe3,_0xc33687);})['catch'](_0x357269=>{_0xc33687(_0x357269);});}})['catch'](_0xe65c0c=>{_0xc33687(_0xe65c0c);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x20d2cb,_0xe65927,_0x45a76d,_0x67618e=!0x1,_0x288cdb=!0x1){const _0x453925=new he(_0x20d2cb);let _0x15c2db;if(_0x288cdb)_0x15c2db=Fa;else try{_0x15c2db=await _0x453925['verify'](_0x45a76d);}catch{_0x15c2db=await _0x453925['verify'](_0x45a76d,!0x0);}const _0x126730={..._0xe65927};if(_0x45a76d==='mfaSmsEnrollment'||_0x45a76d==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x126730){const _0x5d193a=_0x126730['phoneEnrollmentInfo']['phoneNumber'],_0x5eb8e8=_0x126730['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x126730,{'phoneEnrollmentInfo':{'phoneNumber':_0x5d193a,'recaptchaToken':_0x5eb8e8,'captchaResponse':_0x15c2db,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x126730){const _0xe5c063=_0x126730['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x126730,{'phoneSignInInfo':{'recaptchaToken':_0xe5c063,'captchaResponse':_0x15c2db,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x126730;}return _0x67618e?Object['assign'](_0x126730,{'captchaResp':_0x15c2db}):Object['assign'](_0x126730,{'captchaResponse':_0x15c2db}),Object['assign'](_0x126730,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x126730,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x126730;}async function xi(_0x608a17,_0xde89b,_0x2c3093,_0x4a65f3,_0x24d0f9){var _0x2de6ee;if((_0x2de6ee=_0x608a17['_getRecaptchaConfig']())!=null&&_0x2de6ee['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x461c4c=await kr(_0x608a17,_0xde89b,_0x2c3093,_0x2c3093==='getOobCode');return _0x4a65f3(_0x608a17,_0x461c4c);}else return _0x4a65f3(_0x608a17,_0xde89b)['catch'](async _0x7489dd=>{if(_0x7489dd['code']==='auth/missing-recaptcha-token'){console['log'](_0x2c3093+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2654b4=await kr(_0x608a17,_0xde89b,_0x2c3093,_0x2c3093==='getOobCode');return _0x4a65f3(_0x608a17,_0x2654b4);}else return Promise['reject'](_0x7489dd);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x3dd0fc,_0x90188c){const _0x3cad05=Hi(_0x3dd0fc,'auth');if(_0x3cad05['isInitialized']()){const _0x41d640=_0x3cad05['getImmediate'](),_0x1976b0=_0x3cad05['getOptions']();if(xe(_0x1976b0,_0x90188c??{}))return _0x41d640;Y(_0x41d640,'already-initialized');}return _0x3cad05['initialize']({'options':_0x90188c});}function Hf(_0x12d144,_0x5c75ea){const _0x2ab923=(_0x5c75ea==null?void 0x0:_0x5c75ea['persistence'])||[],_0x1b90b3=(Array['isArray'](_0x2ab923)?_0x2ab923:[_0x2ab923])['map'](ie);_0x5c75ea!=null&&_0x5c75ea['errorMap']&&_0x12d144['_updateErrorMap'](_0x5c75ea['errorMap']),_0x12d144['_initializeWithPersistence'](_0x1b90b3,_0x5c75ea==null?void 0x0:_0x5c75ea['popupRedirectResolver']);}function $f(_0x3f4b0f,_0x25d11f,_0xa450b4){const _0x3b110f=Ke(_0x3f4b0f);m(/^https?:\/\//['test'](_0x25d11f),_0x3b110f,'invalid-emulator-scheme');const _0x458093=!0x1,_0x28d5ba=Ua(_0x25d11f),{host:_0x35c657,port:_0x42cefe}=Gf(_0x25d11f),_0x22e9d3=_0x42cefe===null?'':':'+_0x42cefe,_0x632f2e={'url':_0x28d5ba+'//'+_0x35c657+_0x22e9d3+'/'},_0x15e0e0=Object['freeze']({'host':_0x35c657,'port':_0x42cefe,'protocol':_0x28d5ba['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x458093})});if(!_0x3b110f['_canInitEmulator']){m(_0x3b110f['config']['emulator']&&_0x3b110f['emulatorConfig'],_0x3b110f,'emulator-config-failed'),m(xe(_0x632f2e,_0x3b110f['config']['emulator'])&&xe(_0x15e0e0,_0x3b110f['emulatorConfig']),_0x3b110f,'emulator-config-failed');return;}_0x3b110f['config']['emulator']=_0x632f2e,_0x3b110f['emulatorConfig']=_0x15e0e0,_0x3b110f['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x35c657)?Qr(_0x28d5ba+'//'+_0x35c657+_0x22e9d3):qf();}function Ua(_0x59b22e){const _0x19e7a5=_0x59b22e['indexOf'](':');return _0x19e7a5<0x0?'':_0x59b22e['substr'](0x0,_0x19e7a5+0x1);}function Gf(_0xffe629){const _0x40bbe1=Ua(_0xffe629),_0x3aed17=/(\/\/)?([^?#/]+)/['exec'](_0xffe629['substr'](_0x40bbe1['length']));if(!_0x3aed17)return{'host':'','port':null};const _0x4dd026=_0x3aed17[0x2]['split']('@')['pop']()||'',_0x1ecedd=/^(\[[^\]]+\])(:|$)/['exec'](_0x4dd026);if(_0x1ecedd){const _0x3312fe=_0x1ecedd[0x1];return{'host':_0x3312fe,'port':Pr(_0x4dd026['substr'](_0x3312fe['length']+0x1))};}else{const [_0x51a1f5,_0x22ecfe]=_0x4dd026['split'](':');return{'host':_0x51a1f5,'port':Pr(_0x22ecfe)};}}function Pr(_0x3e87d3){if(!_0x3e87d3)return null;const _0x307e8d=Number(_0x3e87d3);return isNaN(_0x307e8d)?null:_0x307e8d;}function qf(){function _0x4e4791(){const _0x325d8e=document['createElement']('p'),_0x495fc4=_0x325d8e['style'];_0x325d8e['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x495fc4['position']='fixed',_0x495fc4['width']='100%',_0x495fc4['backgroundColor']='#ffffff',_0x495fc4['border']='.1em\x20solid\x20#000000',_0x495fc4['color']='#b50000',_0x495fc4['bottom']='0px',_0x495fc4['left']='0px',_0x495fc4['margin']='0px',_0x495fc4['zIndex']='10000',_0x495fc4['textAlign']='center',_0x325d8e['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x325d8e);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4e4791):_0x4e4791());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x515ab4,_0x4214cc){this['providerId']=_0x515ab4,this['signInMethod']=_0x4214cc;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3cefb7){return ne('not\x20implemented');}['_linkToIdToken'](_0x39989e,_0x15bd48){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x7b133e){return ne('not\x20implemented');}}async function zf(_0x5650e5,_0x27a9df){return Pe(_0x5650e5,'POST','/v1/accounts:signUp',_0x27a9df);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x99e2f1,_0x2bde0d){return en(_0x99e2f1,'POST','/v1/accounts:signInWithPassword',ke(_0x99e2f1,_0x2bde0d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x221774,_0x28112c){return en(_0x221774,'POST','/v1/accounts:signInWithEmailLink',ke(_0x221774,_0x28112c));}async function Yf(_0x5ddd6f,_0x51fb39){return en(_0x5ddd6f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5ddd6f,_0x51fb39));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x72ba43,_0x28f202,_0xaf8105,_0x5c0ec3=null){super('password',_0xaf8105),this['_email']=_0x72ba43,this['_password']=_0x28f202,this['_tenantId']=_0x5c0ec3;}static['_fromEmailAndPassword'](_0x2babb5,_0x3414a6){return new $t(_0x2babb5,_0x3414a6,'password');}static['_fromEmailAndCode'](_0x42ce5e,_0x23d2ff,_0x443b81=null){return new $t(_0x42ce5e,_0x23d2ff,'emailLink',_0x443b81);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1ff0ef){const _0x2a7560=typeof _0x1ff0ef=='string'?JSON['parse'](_0x1ff0ef):_0x1ff0ef;if(_0x2a7560!=null&&_0x2a7560['email']&&(_0x2a7560!=null&&_0x2a7560['password'])){if(_0x2a7560['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2a7560['email'],_0x2a7560['password']);if(_0x2a7560['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2a7560['email'],_0x2a7560['password'],_0x2a7560['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2631eb){switch(this['signInMethod']){case'password':const _0x1b4971={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2631eb,_0x1b4971,'signInWithPassword',jf);case'emailLink':return Kf(_0x2631eb,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2631eb,'internal-error');}}async['_linkToIdToken'](_0x358a5e,_0x332867){switch(this['signInMethod']){case'password':const _0x208322={'idToken':_0x332867,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x358a5e,_0x208322,'signUpPassword',zf);case'emailLink':return Yf(_0x358a5e,{'idToken':_0x332867,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x358a5e,'internal-error');}}['_getReauthenticationResolver'](_0x3e67b){return this['_getIdTokenResponse'](_0x3e67b);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x3c496b,_0x4c71a0){return en(_0x3c496b,'POST','/v1/accounts:signInWithIdp',ke(_0x3c496b,_0x4c71a0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x46f580){const _0x10e652=new $e(_0x46f580['providerId'],_0x46f580['signInMethod']);return _0x46f580['idToken']||_0x46f580['accessToken']?(_0x46f580['idToken']&&(_0x10e652['idToken']=_0x46f580['idToken']),_0x46f580['accessToken']&&(_0x10e652['accessToken']=_0x46f580['accessToken']),_0x46f580['nonce']&&!_0x46f580['pendingToken']&&(_0x10e652['nonce']=_0x46f580['nonce']),_0x46f580['pendingToken']&&(_0x10e652['pendingToken']=_0x46f580['pendingToken'])):_0x46f580['oauthToken']&&_0x46f580['oauthTokenSecret']?(_0x10e652['accessToken']=_0x46f580['oauthToken'],_0x10e652['secret']=_0x46f580['oauthTokenSecret']):Y('argument-error'),_0x10e652;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xb5647a){const _0x5dc679=typeof _0xb5647a=='string'?JSON['parse'](_0xb5647a):_0xb5647a,{providerId:_0x54f4a4,signInMethod:_0x470dd9,..._0x51d6b3}=_0x5dc679;if(!_0x54f4a4||!_0x470dd9)return null;const _0x1ee80b=new $e(_0x54f4a4,_0x470dd9);return _0x1ee80b['idToken']=_0x51d6b3['idToken']||void 0x0,_0x1ee80b['accessToken']=_0x51d6b3['accessToken']||void 0x0,_0x1ee80b['secret']=_0x51d6b3['secret'],_0x1ee80b['nonce']=_0x51d6b3['nonce'],_0x1ee80b['pendingToken']=_0x51d6b3['pendingToken']||null,_0x1ee80b;}['_getIdTokenResponse'](_0x22391f){const _0x45d082=this['buildRequest']();return nt(_0x22391f,_0x45d082);}['_linkToIdToken'](_0x29bb27,_0x55797b){const _0x457b42=this['buildRequest']();return _0x457b42['idToken']=_0x55797b,nt(_0x29bb27,_0x457b42);}['_getReauthenticationResolver'](_0x2e8750){const _0x12cb1b=this['buildRequest']();return _0x12cb1b['autoCreate']=!0x1,nt(_0x2e8750,_0x12cb1b);}['buildRequest'](){const _0x2c19db={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2c19db['pendingToken']=this['pendingToken'];else{const _0x2ec259={};this['idToken']&&(_0x2ec259['id_token']=this['idToken']),this['accessToken']&&(_0x2ec259['access_token']=this['accessToken']),this['secret']&&(_0x2ec259['oauth_token_secret']=this['secret']),_0x2ec259['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2ec259['nonce']=this['nonce']),_0x2c19db['postBody']=ut(_0x2ec259);}return _0x2c19db;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x46fffe){switch(_0x46fffe){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x3aa992){const _0x3bcef5=Ct(Tt(_0x3aa992))['link'],_0x523995=_0x3bcef5?Ct(Tt(_0x3bcef5))['deep_link_id']:null,_0x32f655=Ct(Tt(_0x3aa992))['deep_link_id'];return(_0x32f655?Ct(Tt(_0x32f655))['link']:null)||_0x32f655||_0x523995||_0x3bcef5||_0x3aa992;}class Rs{constructor(_0x509b6a){const _0x3aba2b=Ct(Tt(_0x509b6a)),_0x2f0bb0=_0x3aba2b['apiKey']??null,_0x144442=_0x3aba2b['oobCode']??null,_0x1595d5=Jf(_0x3aba2b['mode']??null);m(_0x2f0bb0&&_0x144442&&_0x1595d5,'argument-error'),this['apiKey']=_0x2f0bb0,this['operation']=_0x1595d5,this['code']=_0x144442,this['continueUrl']=_0x3aba2b['continueUrl']??null,this['languageCode']=_0x3aba2b['lang']??null,this['tenantId']=_0x3aba2b['tenantId']??null;}static['parseLink'](_0x1fa611){const _0x58876b=Xf(_0x1fa611);try{return new Rs(_0x58876b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x45c6ad,_0x16c853){return $t['_fromEmailAndPassword'](_0x45c6ad,_0x16c853);}static['credentialWithLink'](_0x430d08,_0x5c71e6){const _0x25ba6e=Rs['parseLink'](_0x5c71e6);return m(_0x25ba6e,'argument-error'),$t['_fromEmailAndCode'](_0x430d08,_0x25ba6e['code'],_0x25ba6e['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5b4f4f){this['providerId']=_0x5b4f4f,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3ca44d){this['defaultLanguageCode']=_0x3ca44d;}['setCustomParameters'](_0x9e6f05){return this['customParameters']=_0x9e6f05,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x28b26c){return this['scopes']['includes'](_0x28b26c)||this['scopes']['push'](_0x28b26c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x42fb1f){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x42fb1f});}static['credentialFromResult'](_0x175463){return ue['credentialFromTaggedObject'](_0x175463);}static['credentialFromError'](_0x433556){return ue['credentialFromTaggedObject'](_0x433556['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x125ff2}){if(!_0x125ff2||!('oauthAccessToken'in _0x125ff2)||!_0x125ff2['oauthAccessToken'])return null;try{return ue['credential'](_0x125ff2['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1a92a7,_0x3c5ac4){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1a92a7,'accessToken':_0x3c5ac4});}static['credentialFromResult'](_0x4d02a5){return de['credentialFromTaggedObject'](_0x4d02a5);}static['credentialFromError'](_0x428625){return de['credentialFromTaggedObject'](_0x428625['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x53233f}){if(!_0x53233f)return null;const {oauthIdToken:_0x9aaf0d,oauthAccessToken:_0x49a532}=_0x53233f;if(!_0x9aaf0d&&!_0x49a532)return null;try{return de['credential'](_0x9aaf0d,_0x49a532);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x136103){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x136103});}static['credentialFromResult'](_0x1a1aee){return fe['credentialFromTaggedObject'](_0x1a1aee);}static['credentialFromError'](_0x5bb373){return fe['credentialFromTaggedObject'](_0x5bb373['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c883d}){if(!_0x2c883d||!('oauthAccessToken'in _0x2c883d)||!_0x2c883d['oauthAccessToken'])return null;try{return fe['credential'](_0x2c883d['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x195d9d,_0x1ada47){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x195d9d,'oauthTokenSecret':_0x1ada47});}static['credentialFromResult'](_0x112e65){return pe['credentialFromTaggedObject'](_0x112e65);}static['credentialFromError'](_0x42afc9){return pe['credentialFromTaggedObject'](_0x42afc9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5766d8}){if(!_0x5766d8)return null;const {oauthAccessToken:_0x20822e,oauthTokenSecret:_0x4a5016}=_0x5766d8;if(!_0x20822e||!_0x4a5016)return null;try{return pe['credential'](_0x20822e,_0x4a5016);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x54be14,_0x319203){return en(_0x54be14,'POST','/v1/accounts:signUp',ke(_0x54be14,_0x319203));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5e3f70){this['user']=_0x5e3f70['user'],this['providerId']=_0x5e3f70['providerId'],this['_tokenResponse']=_0x5e3f70['_tokenResponse'],this['operationType']=_0x5e3f70['operationType'];}static async['_fromIdTokenResponse'](_0x5559ee,_0x58e118,_0x443542,_0x1601a2=!0x1){const _0x570edc=await j['_fromIdTokenResponse'](_0x5559ee,_0x443542,_0x1601a2),_0x1b53b4=Nr(_0x443542);return new Ge({'user':_0x570edc,'providerId':_0x1b53b4,'_tokenResponse':_0x443542,'operationType':_0x58e118});}static async['_forOperation'](_0x40e34d,_0x494412,_0x2a8050){await _0x40e34d['_updateTokensIfNecessary'](_0x2a8050,!0x0);const _0x297f42=Nr(_0x2a8050);return new Ge({'user':_0x40e34d,'providerId':_0x297f42,'_tokenResponse':_0x2a8050,'operationType':_0x494412});}}function Nr(_0x5c9434){return _0x5c9434['providerId']?_0x5c9434['providerId']:'phoneNumber'in _0x5c9434?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x54a492,_0x4d5d96,_0x2a7b2b,_0x52b79b){super(_0x4d5d96['code'],_0x4d5d96['message']),this['operationType']=_0x2a7b2b,this['user']=_0x52b79b,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x54a492['name'],'tenantId':_0x54a492['tenantId']??void 0x0,'_serverResponse':_0x4d5d96['customData']['_serverResponse'],'operationType':_0x2a7b2b};}static['_fromErrorAndOperation'](_0x5a745d,_0x2ca185,_0x1e4ad7,_0x5cdcf3){return new On(_0x5a745d,_0x2ca185,_0x1e4ad7,_0x5cdcf3);}}function Ba(_0x47e94d,_0x34983a,_0x16ac5d,_0x4d616f){return(_0x34983a==='reauthenticate'?_0x16ac5d['_getReauthenticationResolver'](_0x47e94d):_0x16ac5d['_getIdTokenResponse'](_0x47e94d))['catch'](_0x548bd8=>{throw _0x548bd8['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x47e94d,_0x548bd8,_0x34983a,_0x4d616f):_0x548bd8;});}async function ep(_0x10b6d0,_0x257627,_0x56d13f=!0x1){const _0x517fe6=await Ht(_0x10b6d0,_0x257627['_linkToIdToken'](_0x10b6d0['auth'],await _0x10b6d0['getIdToken']()),_0x56d13f);return Ge['_forOperation'](_0x10b6d0,'link',_0x517fe6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x4218e2,_0xafe8a9,_0x102756=!0x1){const {auth:_0x42fdd9}=_0x4218e2;if($(_0x42fdd9['app']))return Promise['reject'](re(_0x42fdd9));const _0x4c0c73='reauthenticate';try{const _0x510b93=await Ht(_0x4218e2,Ba(_0x42fdd9,_0x4c0c73,_0xafe8a9,_0x4218e2),_0x102756);m(_0x510b93['idToken'],_0x42fdd9,'internal-error');const _0x25f64b=Ts(_0x510b93['idToken']);m(_0x25f64b,_0x42fdd9,'internal-error');const {sub:_0x2b2865}=_0x25f64b;return m(_0x4218e2['uid']===_0x2b2865,_0x42fdd9,'user-mismatch'),Ge['_forOperation'](_0x4218e2,_0x4c0c73,_0x510b93);}catch(_0x5b798c){throw(_0x5b798c==null?void 0x0:_0x5b798c['code'])==='auth/user-not-found'&&Y(_0x42fdd9,'user-mismatch'),_0x5b798c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4423c6,_0x5cc7e6,_0x3f5b87=!0x1){if($(_0x4423c6['app']))return Promise['reject'](re(_0x4423c6));const _0x18845e='signIn',_0x4a3c81=await Ba(_0x4423c6,_0x18845e,_0x5cc7e6),_0x33d558=await Ge['_fromIdTokenResponse'](_0x4423c6,_0x18845e,_0x4a3c81);return _0x3f5b87||await _0x4423c6['_updateCurrentUser'](_0x33d558['user']),_0x33d558;}async function np(_0x2938d2,_0x30b86d){return Va(Ke(_0x2938d2),_0x30b86d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x262625){const _0x113905=Ke(_0x262625);_0x113905['_getPasswordPolicyInternal']()&&await _0x113905['_updatePasswordPolicy']();}async function L_(_0x154e71,_0x3b888a,_0x32369e){if($(_0x154e71['app']))return Promise['reject'](re(_0x154e71));const _0x69b41d=Ke(_0x154e71),_0x3f6ba8=await xi(_0x69b41d,{'returnSecureToken':!0x0,'email':_0x3b888a,'password':_0x32369e,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x417978=>{throw _0x417978['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x154e71),_0x417978;}),_0x59d044=await Ge['_fromIdTokenResponse'](_0x69b41d,'signIn',_0x3f6ba8);return await _0x69b41d['_updateCurrentUser'](_0x59d044['user']),_0x59d044;}function x_(_0x51f311,_0x4619a9,_0x70ae3b){return $(_0x51f311['app'])?Promise['reject'](re(_0x51f311)):np(P(_0x51f311),yt['credential'](_0x4619a9,_0x70ae3b))['catch'](async _0x459d96=>{throw _0x459d96['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x51f311),_0x459d96;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x1a1983,_0x1aeffc){return P(_0x1a1983)['setPersistence'](_0x1aeffc);}function ip(_0x1b0ede,_0x2cd759,_0x2eb67e,_0x20ea51){return P(_0x1b0ede)['onIdTokenChanged'](_0x2cd759,_0x2eb67e,_0x20ea51);}function sp(_0x90161c,_0x5d4812,_0xc27c50){return P(_0x90161c)['beforeAuthStateChanged'](_0x5d4812,_0xc27c50);}function U_(_0x4568b0,_0x54158a,_0xa67694,_0x463219){return P(_0x4568b0)['onAuthStateChanged'](_0x54158a,_0xa67694,_0x463219);}function W_(_0x2ec5e2){return P(_0x2ec5e2)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5a16b7,_0x233db5){this['storageRetriever']=_0x5a16b7,this['type']=_0x233db5;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x236bb4,_0x2bd65d){return this['storage']['setItem'](_0x236bb4,JSON['stringify'](_0x2bd65d)),Promise['resolve']();}['_get'](_0x395f1d){const _0x1fe9db=this['storage']['getItem'](_0x395f1d);return Promise['resolve'](_0x1fe9db?JSON['parse'](_0x1fe9db):null);}['_remove'](_0x42131e){return this['storage']['removeItem'](_0x42131e),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2c4caa,_0x1148bd)=>this['onStorageEvent'](_0x2c4caa,_0x1148bd),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x23aac2){for(const _0x53ded4 of Object['keys'](this['listeners'])){const _0x58b12c=this['storage']['getItem'](_0x53ded4),_0x3aad2c=this['localCache'][_0x53ded4];_0x58b12c!==_0x3aad2c&&_0x23aac2(_0x53ded4,_0x3aad2c,_0x58b12c);}}['onStorageEvent'](_0x34389d,_0x360b86=!0x1){if(!_0x34389d['key']){this['forAllChangedKeys']((_0x4e61e7,_0x5cbfd8,_0x191ef6)=>{this['notifyListeners'](_0x4e61e7,_0x191ef6);});return;}const _0x1539d8=_0x34389d['key'];_0x360b86?this['detachListener']():this['stopPolling']();const _0x3488e6=()=>{const _0x44786b=this['storage']['getItem'](_0x1539d8);!_0x360b86&&this['localCache'][_0x1539d8]===_0x44786b||this['notifyListeners'](_0x1539d8,_0x44786b);},_0xcd2913=this['storage']['getItem'](_0x1539d8);Af()&&_0xcd2913!==_0x34389d['newValue']&&_0x34389d['newValue']!==_0x34389d['oldValue']?setTimeout(_0x3488e6,op):_0x3488e6();}['notifyListeners'](_0x2378c6,_0x25c768){this['localCache'][_0x2378c6]=_0x25c768;const _0x2a95a5=this['listeners'][_0x2378c6];if(_0x2a95a5){for(const _0x2cf1db of Array['from'](_0x2a95a5))_0x2cf1db(_0x25c768&&JSON['parse'](_0x25c768));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2c2be5,_0x21da80,_0xa543d6)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2c2be5,'oldValue':_0x21da80,'newValue':_0xa543d6}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x254dd5,_0x16f430){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x254dd5]||(this['listeners'][_0x254dd5]=new Set(),this['localCache'][_0x254dd5]=this['storage']['getItem'](_0x254dd5)),this['listeners'][_0x254dd5]['add'](_0x16f430);}['_removeListener'](_0x551d68,_0x1fe132){this['listeners'][_0x551d68]&&(this['listeners'][_0x551d68]['delete'](_0x1fe132),this['listeners'][_0x551d68]['size']===0x0&&delete this['listeners'][_0x551d68]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x53144f,_0xd7585){await super['_set'](_0x53144f,_0xd7585),this['localCache'][_0x53144f]=JSON['stringify'](_0xd7585);}async['_get'](_0xd57cca){const _0x1020fa=await super['_get'](_0xd57cca);return this['localCache'][_0xd57cca]=JSON['stringify'](_0x1020fa),_0x1020fa;}async['_remove'](_0x424852){await super['_remove'](_0x424852),delete this['localCache'][_0x424852];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2cbf0c,_0x5aaf0e){}['_removeListener'](_0x32edd9,_0x39a13b){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5139e5){return Promise['all'](_0x5139e5['map'](async _0xfc469a=>{try{return{'fulfilled':!0x0,'value':await _0xfc469a};}catch(_0xafd225){return{'fulfilled':!0x1,'reason':_0xafd225};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x163a33){this['eventTarget']=_0x163a33,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2eb4e){const _0x5ca9ef=this['receivers']['find'](_0x105798=>_0x105798['isListeningto'](_0x2eb4e));if(_0x5ca9ef)return _0x5ca9ef;const _0x45713c=new Xn(_0x2eb4e);return this['receivers']['push'](_0x45713c),_0x45713c;}['isListeningto'](_0x5b92b4){return this['eventTarget']===_0x5b92b4;}async['handleEvent'](_0x470a4c){const _0xd21e71=_0x470a4c,{eventId:_0x4f5a40,eventType:_0x488f6f,data:_0x2d8578}=_0xd21e71['data'],_0x588ac3=this['handlersMap'][_0x488f6f];if(!(_0x588ac3!=null&&_0x588ac3['size']))return;_0xd21e71['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4f5a40,'eventType':_0x488f6f});const _0x25426e=Array['from'](_0x588ac3)['map'](async _0x4625ba=>_0x4625ba(_0xd21e71['origin'],_0x2d8578)),_0x4b8fc1=await cp(_0x25426e);_0xd21e71['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4f5a40,'eventType':_0x488f6f,'response':_0x4b8fc1});}['_subscribe'](_0xa85a15,_0x4f9a49){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xa85a15]||(this['handlersMap'][_0xa85a15]=new Set()),this['handlersMap'][_0xa85a15]['add'](_0x4f9a49);}['_unsubscribe'](_0x5df35e,_0xcc24d){this['handlersMap'][_0x5df35e]&&_0xcc24d&&this['handlersMap'][_0x5df35e]['delete'](_0xcc24d),(!_0xcc24d||this['handlersMap'][_0x5df35e]['size']===0x0)&&delete this['handlersMap'][_0x5df35e],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x10cbc8='',_0x39abed=0xa){let _0x42900b='';for(let _0xfa16bd=0x0;_0xfa16bd<_0x39abed;_0xfa16bd++)_0x42900b+=Math['floor'](Math['random']()*0xa);return _0x10cbc8+_0x42900b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x560b9b){this['target']=_0x560b9b,this['handlers']=new Set();}['removeMessageHandler'](_0x37fd98){_0x37fd98['messageChannel']&&(_0x37fd98['messageChannel']['port1']['removeEventListener']('message',_0x37fd98['onMessage']),_0x37fd98['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x37fd98);}async['_send'](_0x29d598,_0x50265a,_0x2dc720=0x32){const _0x3bbf2a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3bbf2a)throw new Error('connection_unavailable');let _0x5280e1,_0x494a85;return new Promise((_0x3ab935,_0x4f356a)=>{const _0x31e6fc=As('',0x14);_0x3bbf2a['port1']['start']();const _0x590d4b=setTimeout(()=>{_0x4f356a(new Error('unsupported_event'));},_0x2dc720);_0x494a85={'messageChannel':_0x3bbf2a,'onMessage'(_0x31b9de){const _0x11b0e2=_0x31b9de;if(_0x11b0e2['data']['eventId']===_0x31e6fc)switch(_0x11b0e2['data']['status']){case'ack':clearTimeout(_0x590d4b),_0x5280e1=setTimeout(()=>{_0x4f356a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5280e1),_0x3ab935(_0x11b0e2['data']['response']);break;default:clearTimeout(_0x590d4b),clearTimeout(_0x5280e1),_0x4f356a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x494a85),_0x3bbf2a['port1']['addEventListener']('message',_0x494a85['onMessage']),this['target']['postMessage']({'eventType':_0x29d598,'eventId':_0x31e6fc,'data':_0x50265a},[_0x3bbf2a['port2']]);})['finally'](()=>{_0x494a85&&this['removeMessageHandler'](_0x494a85);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x97d02b){Z()['location']['href']=_0x97d02b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5788b2;return((_0x5788b2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5788b2['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x33f810){this['request']=_0x33f810;}['toPromise'](){return new Promise((_0x21da81,_0x259080)=>{this['request']['addEventListener']('success',()=>{_0x21da81(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x259080(this['request']['error']);});});}}function Zn(_0x56402e,_0xe3bf9b){return _0x56402e['transaction']([Mn],_0xe3bf9b?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x232e0e=indexedDB['deleteDatabase'](Ka);return new nn(_0x232e0e)['toPromise']();}function Qa(){const _0x126581=indexedDB['open'](Ka,pp);return new Promise((_0x3d0dc2,_0x1f6ed5)=>{_0x126581['addEventListener']('error',()=>{_0x1f6ed5(_0x126581['error']);}),_0x126581['addEventListener']('upgradeneeded',()=>{const _0x4c841a=_0x126581['result'];try{_0x4c841a['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x41a974){_0x1f6ed5(_0x41a974);}}),_0x126581['addEventListener']('success',async()=>{const _0x1a2a4b=_0x126581['result'];_0x1a2a4b['objectStoreNames']['contains'](Mn)?_0x3d0dc2(_0x1a2a4b):(_0x1a2a4b['close'](),await _p(),_0x3d0dc2(await Qa()));});});}async function Or(_0x445931,_0x157a35,_0x4dbd4f){const _0x53d26a=Zn(_0x445931,!0x0)['put']({[Ya]:_0x157a35,'value':_0x4dbd4f});return new nn(_0x53d26a)['toPromise']();}async function gp(_0x28f8bf,_0x56402c){const _0x5adcac=Zn(_0x28f8bf,!0x1)['get'](_0x56402c),_0x57774e=await new nn(_0x5adcac)['toPromise']();return _0x57774e===void 0x0?null:_0x57774e['value'];}function Dr(_0x8faa21,_0x37eb0d){const _0x46d063=Zn(_0x8faa21,!0x0)['delete'](_0x37eb0d);return new nn(_0x46d063)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x193edc){let _0x12476f=0x0;for(;;)try{const _0x351ce2=await this['_openDb']();return await _0x193edc(_0x351ce2);}catch(_0x58b6ae){if(_0x12476f++>yp)throw _0x58b6ae;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x339dcc,_0x325d92)=>({'keyProcessed':(await this['_poll']())['includes'](_0x325d92['key'])})),this['receiver']['_subscribe']('ping',async(_0x53e4b2,_0x40a330)=>['keyChanged']);}async['initializeSender'](){var _0xf2fd34,_0x3296f5;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x33ad6f=await this['sender']['_send']('ping',{},0x320);_0x33ad6f&&(_0xf2fd34=_0x33ad6f[0x0])!=null&&_0xf2fd34['fulfilled']&&(_0x3296f5=_0x33ad6f[0x0])!=null&&_0x3296f5['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x523156){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x523156},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2ccae5=>{await Or(_0x2ccae5,Dn,'1'),await Dr(_0x2ccae5,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x47f83f){this['pendingWrites']++;try{await _0x47f83f();}finally{this['pendingWrites']--;}}async['_set'](_0x4ffc65,_0x15fe5d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x20b1f2=>Or(_0x20b1f2,_0x4ffc65,_0x15fe5d)),this['localCache'][_0x4ffc65]=_0x15fe5d,this['notifyServiceWorker'](_0x4ffc65)));}async['_get'](_0x2fa0ca){const _0xb61364=await this['_withRetries'](_0x216c22=>gp(_0x216c22,_0x2fa0ca));return this['localCache'][_0x2fa0ca]=_0xb61364,_0xb61364;}async['_remove'](_0x213b78){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5280ca=>Dr(_0x5280ca,_0x213b78)),delete this['localCache'][_0x213b78],this['notifyServiceWorker'](_0x213b78)));}async['_poll'](){const _0x29ae4b=await this['_withRetries'](_0x3f654d=>{const _0x4243ed=Zn(_0x3f654d,!0x1)['getAll']();return new nn(_0x4243ed)['toPromise']();});if(!_0x29ae4b)return[];if(this['pendingWrites']!==0x0)return[];const _0x22a53f=[],_0x3c3214=new Set();if(_0x29ae4b['length']!==0x0){for(const {fbase_key:_0x254b86,value:_0x5cf37a}of _0x29ae4b)_0x3c3214['add'](_0x254b86),JSON['stringify'](this['localCache'][_0x254b86])!==JSON['stringify'](_0x5cf37a)&&(this['notifyListeners'](_0x254b86,_0x5cf37a),_0x22a53f['push'](_0x254b86));}for(const _0x2b1a1a of Object['keys'](this['localCache']))this['localCache'][_0x2b1a1a]&&!_0x3c3214['has'](_0x2b1a1a)&&(this['notifyListeners'](_0x2b1a1a,null),_0x22a53f['push'](_0x2b1a1a));return _0x22a53f;}['notifyListeners'](_0x12cfaa,_0x5d07b8){this['localCache'][_0x12cfaa]=_0x5d07b8;const _0x11efc2=this['listeners'][_0x12cfaa];if(_0x11efc2){for(const _0x407eca of Array['from'](_0x11efc2))_0x407eca(_0x5d07b8);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x23184c,_0x1ff451){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x23184c]||(this['listeners'][_0x23184c]=new Set(),this['_get'](_0x23184c)),this['listeners'][_0x23184c]['add'](_0x1ff451);}['_removeListener'](_0x445507,_0x4bbfd1){this['listeners'][_0x445507]&&(this['listeners'][_0x445507]['delete'](_0x4bbfd1),this['listeners'][_0x445507]['size']===0x0&&delete this['listeners'][_0x445507]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x255705,_0x3c1627){return _0x3c1627?ie(_0x3c1627):(m(_0x255705['_popupRedirectResolver'],_0x255705,'argument-error'),_0x255705['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3bb058){super('custom','custom'),this['params']=_0x3bb058;}['_getIdTokenResponse'](_0x186819){return nt(_0x186819,this['_buildIdpRequest']());}['_linkToIdToken'](_0x52d672,_0x3e0464){return nt(_0x52d672,this['_buildIdpRequest'](_0x3e0464));}['_getReauthenticationResolver'](_0x12bbd7){return nt(_0x12bbd7,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x673866){const _0x5d8afc={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x673866&&(_0x5d8afc['idToken']=_0x673866),_0x5d8afc;}}function Ip(_0x1bb163){return Va(_0x1bb163['auth'],new ks(_0x1bb163),_0x1bb163['bypassAuthState']);}function wp(_0x22144d){const {auth:_0x339c9e,user:_0x24bcc6}=_0x22144d;return m(_0x24bcc6,_0x339c9e,'internal-error'),tp(_0x24bcc6,new ks(_0x22144d),_0x22144d['bypassAuthState']);}async function Cp(_0x2fb111){const {auth:_0x404882,user:_0x40427c}=_0x2fb111;return m(_0x40427c,_0x404882,'internal-error'),ep(_0x40427c,new ks(_0x2fb111),_0x2fb111['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3476e2,_0x357124,_0x31e481,_0x3407ed,_0x1c1c16=!0x1){this['auth']=_0x3476e2,this['resolver']=_0x31e481,this['user']=_0x3407ed,this['bypassAuthState']=_0x1c1c16,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x357124)?_0x357124:[_0x357124];}['execute'](){return new Promise(async(_0x58a11b,_0x5103f2)=>{this['pendingPromise']={'resolve':_0x58a11b,'reject':_0x5103f2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x6fb30b){this['reject'](_0x6fb30b);}});}async['onAuthEvent'](_0x1a5793){const {urlResponse:_0x44c25c,sessionId:_0x20bdfe,postBody:_0x51210a,tenantId:_0x452e2e,error:_0x47809a,type:_0x18b65e}=_0x1a5793;if(_0x47809a){this['reject'](_0x47809a);return;}const _0x58b561={'auth':this['auth'],'requestUri':_0x44c25c,'sessionId':_0x20bdfe,'tenantId':_0x452e2e||void 0x0,'postBody':_0x51210a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x18b65e)(_0x58b561));}catch(_0x1c4ef8){this['reject'](_0x1c4ef8);}}['onError'](_0x25769d){this['reject'](_0x25769d);}['getIdpTask'](_0xa217ef){switch(_0xa217ef){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x44ecf1){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x44ecf1),this['unregisterAndCleanUp']();}['reject'](_0xb2c37){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xb2c37),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x2d90bb,_0x13e335,_0x383556,_0x21a04a,_0x556331){super(_0x2d90bb,_0x13e335,_0x21a04a,_0x556331),this['provider']=_0x383556,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4e2b92=await this['execute']();return m(_0x4e2b92,this['auth'],'internal-error'),_0x4e2b92;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xa503d8=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xa503d8),this['authWindow']['associatedEvent']=_0xa503d8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x59b42d=>{this['reject'](_0x59b42d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x45e352=>{_0x45e352||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x327d7c;return((_0x327d7c=this['authWindow'])==null?void 0x0:_0x327d7c['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2d8dfa=()=>{var _0x19cb9a,_0x5bd9d5;if((_0x5bd9d5=(_0x19cb9a=this['authWindow'])==null?void 0x0:_0x19cb9a['window'])!=null&&_0x5bd9d5['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2d8dfa,Tp['get']());};_0x2d8dfa();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x37d789,_0x19dc1d,_0x941781=!0x1){super(_0x37d789,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x19dc1d,void 0x0,_0x941781),this['eventId']=null;}async['execute'](){let _0x567ab6=hn['get'](this['auth']['_key']());if(!_0x567ab6){try{const _0x42a293=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x567ab6=()=>Promise['resolve'](_0x42a293);}catch(_0x7c7ead){_0x567ab6=()=>Promise['reject'](_0x7c7ead);}hn['set'](this['auth']['_key'](),_0x567ab6);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x567ab6();}async['onAuthEvent'](_0x2287f4){if(_0x2287f4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2287f4);if(_0x2287f4['type']==='unknown'){this['resolve'](null);return;}if(_0x2287f4['eventId']){const _0x17218b=await this['auth']['_redirectUserForId'](_0x2287f4['eventId']);if(_0x17218b)return this['user']=_0x17218b,super['onAuthEvent'](_0x2287f4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x114938,_0x1ea4a0){const _0xdf99f5=Pp(_0x1ea4a0),_0x47c595=kp(_0x114938);if(!await _0x47c595['_isAvailable']())return!0x1;const _0x1e6617=await _0x47c595['_get'](_0xdf99f5)==='true';return await _0x47c595['_remove'](_0xdf99f5),_0x1e6617;}function Ap(_0x30540f,_0x575120){hn['set'](_0x30540f['_key'](),_0x575120);}function kp(_0x220529){return ie(_0x220529['_redirectPersistence']);}function Pp(_0x5df086){return ln(Sp,_0x5df086['config']['apiKey'],_0x5df086['name']);}async function Np(_0xbd06a4,_0x3d8985,_0x155741=!0x1){if($(_0xbd06a4['app']))return Promise['reject'](re(_0xbd06a4));const _0xecd7d1=Ke(_0xbd06a4),_0x2f2035=Ep(_0xecd7d1,_0x3d8985),_0x41ab57=await new bp(_0xecd7d1,_0x2f2035,_0x155741)['execute']();return _0x41ab57&&!_0x155741&&(delete _0x41ab57['user']['_redirectEventId'],await _0xecd7d1['_persistUserIfCurrent'](_0x41ab57['user']),await _0xecd7d1['_setRedirectUser'](null,_0x3d8985)),_0x41ab57;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0xaaf369){this['auth']=_0xaaf369,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x565959){this['consumers']['add'](_0x565959),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x565959)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x565959),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3c2d31){this['consumers']['delete'](_0x3c2d31);}['onEvent'](_0x172f1e){if(this['hasEventBeenHandled'](_0x172f1e))return!0x1;let _0x34040e=!0x1;return this['consumers']['forEach'](_0x3bdeec=>{this['isEventForConsumer'](_0x172f1e,_0x3bdeec)&&(_0x34040e=!0x0,this['sendToConsumer'](_0x172f1e,_0x3bdeec),this['saveEventToCache'](_0x172f1e));}),this['hasHandledPotentialRedirect']||!Mp(_0x172f1e)||(this['hasHandledPotentialRedirect']=!0x0,_0x34040e||(this['queuedRedirectEvent']=_0x172f1e,_0x34040e=!0x0)),_0x34040e;}['sendToConsumer'](_0x2a2bd3,_0x1471b8){var _0x4193e3;if(_0x2a2bd3['error']&&!Za(_0x2a2bd3)){const _0xd0a9f=((_0x4193e3=_0x2a2bd3['error']['code'])==null?void 0x0:_0x4193e3['split']('auth/')[0x1])||'internal-error';_0x1471b8['onError'](X(this['auth'],_0xd0a9f));}else _0x1471b8['onAuthEvent'](_0x2a2bd3);}['isEventForConsumer'](_0x4a1bf9,_0x3c3b53){const _0x24d6ce=_0x3c3b53['eventId']===null||!!_0x4a1bf9['eventId']&&_0x4a1bf9['eventId']===_0x3c3b53['eventId'];return _0x3c3b53['filter']['includes'](_0x4a1bf9['type'])&&_0x24d6ce;}['hasEventBeenHandled'](_0x36a87d){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x36a87d));}['saveEventToCache'](_0x274242){this['cachedEventUids']['add'](Mr(_0x274242)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1a3c0c){return[_0x1a3c0c['type'],_0x1a3c0c['eventId'],_0x1a3c0c['sessionId'],_0x1a3c0c['tenantId']]['filter'](_0x3fc63b=>_0x3fc63b)['join']('-');}function Za({type:_0x5a0ea2,error:_0x533b43}){return _0x5a0ea2==='unknown'&&(_0x533b43==null?void 0x0:_0x533b43['code'])==='auth/no-auth-event';}function Mp(_0x1f2fc8){switch(_0x1f2fc8['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1f2fc8);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x442d3b,_0x1b1de8={}){return Pe(_0x442d3b,'GET','/v1/projects',_0x1b1de8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x16ba13){if(_0x16ba13['config']['emulator'])return;const {authorizedDomains:_0x3b880d}=await Lp(_0x16ba13);for(const _0x3162d5 of _0x3b880d)try{if(Wp(_0x3162d5))return;}catch{}Y(_0x16ba13,'unauthorized-domain');}function Wp(_0x48bb00){const _0x317b1b=Mi(),{protocol:_0x1def75,hostname:_0x2b87a8}=new URL(_0x317b1b);if(_0x48bb00['startsWith']('chrome-extension://')){const _0x5965a9=new URL(_0x48bb00);return _0x5965a9['hostname']===''&&_0x2b87a8===''?_0x1def75==='chrome-extension:'&&_0x48bb00['replace']('chrome-extension://','')===_0x317b1b['replace']('chrome-extension://',''):_0x1def75==='chrome-extension:'&&_0x5965a9['hostname']===_0x2b87a8;}if(!Fp['test'](_0x1def75))return!0x1;if(xp['test'](_0x48bb00))return _0x2b87a8===_0x48bb00;const _0x2dc299=_0x48bb00['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2dc299+'|'+_0x2dc299+')$','i')['test'](_0x2b87a8);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x339fe1=Z()['___jsl'];if(_0x339fe1!=null&&_0x339fe1['H']){for(const _0x58846d of Object['keys'](_0x339fe1['H']))if(_0x339fe1['H'][_0x58846d]['r']=_0x339fe1['H'][_0x58846d]['r']||[],_0x339fe1['H'][_0x58846d]['L']=_0x339fe1['H'][_0x58846d]['L']||[],_0x339fe1['H'][_0x58846d]['r']=[..._0x339fe1['H'][_0x58846d]['L']],_0x339fe1['CP']){for(let _0x453866=0x0;_0x453866<_0x339fe1['CP']['length'];_0x453866++)_0x339fe1['CP'][_0x453866]=null;}}}function Vp(_0xbc9a0a){return new Promise((_0x9c2197,_0x58c3b8)=>{var _0x1cc765,_0x5d67cc,_0x2385bc;function _0x4dc4bf(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x9c2197(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x58c3b8(X(_0xbc9a0a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5d67cc=(_0x1cc765=Z()['gapi'])==null?void 0x0:_0x1cc765['iframes'])!=null&&_0x5d67cc['Iframe'])_0x9c2197(gapi['iframes']['getContext']());else{if((_0x2385bc=Z()['gapi'])!=null&&_0x2385bc['load'])_0x4dc4bf();else{const _0xbe9fea=Ff('iframefcb');return Z()[_0xbe9fea]=()=>{gapi['load']?_0x4dc4bf():_0x58c3b8(X(_0xbc9a0a,'network-request-failed'));},xa(xf()+'?onload='+_0xbe9fea)['catch'](_0x5aad79=>_0x58c3b8(_0x5aad79));}}})['catch'](_0x25483b=>{throw un=null,_0x25483b;});}let un=null;function Hp(_0x2348f0){return un=un||Vp(_0x2348f0),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x43f824){const _0x12fabe=_0x43f824['config'];m(_0x12fabe['authDomain'],_0x43f824,'auth-domain-config-required');const _0xbf6d73=_0x12fabe['emulator']?Cs(_0x12fabe,qp):'https://'+_0x43f824['config']['authDomain']+'/'+Gp,_0x5180e0={'apiKey':_0x12fabe['apiKey'],'appName':_0x43f824['name'],'v':dt},_0x246af3=jp['get'](_0x43f824['config']['apiHost']);_0x246af3&&(_0x5180e0['eid']=_0x246af3);const _0x4659cd=_0x43f824['_getFrameworks']();return _0x4659cd['length']&&(_0x5180e0['fw']=_0x4659cd['join'](',')),_0xbf6d73+'?'+ut(_0x5180e0)['slice'](0x1);}async function Yp(_0x3984a2){const _0x127c22=await Hp(_0x3984a2),_0x11cf6e=Z()['gapi'];return m(_0x11cf6e,_0x3984a2,'internal-error'),_0x127c22['open']({'where':document['body'],'url':Kp(_0x3984a2),'messageHandlersFilter':_0x11cf6e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x345841=>new Promise(async(_0x2a84b3,_0x1aa3d7)=>{await _0x345841['restyle']({'setHideOnLeave':!0x1});const _0x3014a4=X(_0x3984a2,'network-request-failed'),_0x3c72e2=Z()['setTimeout'](()=>{_0x1aa3d7(_0x3014a4);},$p['get']());function _0x43923f(){Z()['clearTimeout'](_0x3c72e2),_0x2a84b3(_0x345841);}_0x345841['ping'](_0x43923f)['then'](_0x43923f,()=>{_0x1aa3d7(_0x3014a4);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x56b9b0){this['window']=_0x56b9b0,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xfee94b,_0x5b732a,_0x3ed02d,_0x56ea10=Jp,_0x525685=Xp){const _0x37260d=Math['max']((window['screen']['availHeight']-_0x525685)/0x2,0x0)['toString'](),_0x23315f=Math['max']((window['screen']['availWidth']-_0x56ea10)/0x2,0x0)['toString']();let _0x1418f9='';const _0x2a6da5={...Qp,'width':_0x56ea10['toString'](),'height':_0x525685['toString'](),'top':_0x37260d,'left':_0x23315f},_0x31eaec=W()['toLowerCase']();_0x3ed02d&&(_0x1418f9=ka(_0x31eaec)?Zp:_0x3ed02d),Ra(_0x31eaec)&&(_0x5b732a=_0x5b732a||e_,_0x2a6da5['scrollbars']='yes');const _0x495d03=Object['entries'](_0x2a6da5)['reduce']((_0x1c604c,[_0x2e9f43,_0xfd74e0])=>''+_0x1c604c+_0x2e9f43+'='+_0xfd74e0+',','');if(Rf(_0x31eaec)&&_0x1418f9!=='_self')return n_(_0x5b732a||'',_0x1418f9),new xr(null);const _0x5e06b0=window['open'](_0x5b732a||'',_0x1418f9,_0x495d03);m(_0x5e06b0,_0xfee94b,'popup-blocked');try{_0x5e06b0['focus']();}catch{}return new xr(_0x5e06b0);}function n_(_0x35a7ac,_0x2f1d3d){const _0x2eaebb=document['createElement']('a');_0x2eaebb['href']=_0x35a7ac,_0x2eaebb['target']=_0x2f1d3d;const _0x33e221=document['createEvent']('MouseEvent');_0x33e221['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2eaebb['dispatchEvent'](_0x33e221);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x3b2ed4,_0x89620d,_0x4b3a41,_0x75512a,_0x35a7d1,_0x4ef8e5){m(_0x3b2ed4['config']['authDomain'],_0x3b2ed4,'auth-domain-config-required'),m(_0x3b2ed4['config']['apiKey'],_0x3b2ed4,'invalid-api-key');const _0x1b4170={'apiKey':_0x3b2ed4['config']['apiKey'],'appName':_0x3b2ed4['name'],'authType':_0x4b3a41,'redirectUrl':_0x75512a,'v':dt,'eventId':_0x35a7d1};if(_0x89620d instanceof Wa){_0x89620d['setDefaultLanguage'](_0x3b2ed4['languageCode']),_0x1b4170['providerId']=_0x89620d['providerId']||'',pn(_0x89620d['getCustomParameters']())||(_0x1b4170['customParameters']=JSON['stringify'](_0x89620d['getCustomParameters']()));for(const [_0x133bf3,_0x2b6c03]of Object['entries']({}))_0x1b4170[_0x133bf3]=_0x2b6c03;}if(_0x89620d instanceof tn){const _0x3018ed=_0x89620d['getScopes']()['filter'](_0x411bc2=>_0x411bc2!=='');_0x3018ed['length']>0x0&&(_0x1b4170['scopes']=_0x3018ed['join'](','));}_0x3b2ed4['tenantId']&&(_0x1b4170['tid']=_0x3b2ed4['tenantId']);const _0x130acd=_0x1b4170;for(const _0x4da4db of Object['keys'](_0x130acd))_0x130acd[_0x4da4db]===void 0x0&&delete _0x130acd[_0x4da4db];const _0x9adf3=await _0x3b2ed4['_getAppCheckToken'](),_0x4bd91d=_0x9adf3?'#'+r_+'='+encodeURIComponent(_0x9adf3):'';return o_(_0x3b2ed4)+'?'+ut(_0x130acd)['slice'](0x1)+_0x4bd91d;}function o_({config:_0x434885}){return _0x434885['emulator']?Cs(_0x434885,s_):'https://'+_0x434885['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x2e4122,_0x5682fd,_0x4bcf11,_0x8b90b1){var _0x40c051;ce((_0x40c051=this['eventManagers'][_0x2e4122['_key']()])==null?void 0x0:_0x40c051['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2020aa=await Fr(_0x2e4122,_0x5682fd,_0x4bcf11,Mi(),_0x8b90b1);return t_(_0x2e4122,_0x2020aa,As());}async['_openRedirect'](_0x40c45e,_0x3e7fbf,_0x54c075,_0x50f0e3){await this['_originValidation'](_0x40c45e);const _0x48cf4e=await Fr(_0x40c45e,_0x3e7fbf,_0x54c075,Mi(),_0x50f0e3);return hp(_0x48cf4e),new Promise(()=>{});}['_initialize'](_0x8c9780){const _0x3234da=_0x8c9780['_key']();if(this['eventManagers'][_0x3234da]){const {manager:_0x2dd85e,promise:_0x5f4de0}=this['eventManagers'][_0x3234da];return _0x2dd85e?Promise['resolve'](_0x2dd85e):(ce(_0x5f4de0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5f4de0);}const _0xbc8108=this['initAndGetManager'](_0x8c9780);return this['eventManagers'][_0x3234da]={'promise':_0xbc8108},_0xbc8108['catch'](()=>{delete this['eventManagers'][_0x3234da];}),_0xbc8108;}async['initAndGetManager'](_0x5fdf01){const _0xd1027a=await Yp(_0x5fdf01),_0x540459=new Dp(_0x5fdf01);return _0xd1027a['register']('authEvent',_0x52b00c=>(m(_0x52b00c==null?void 0x0:_0x52b00c['authEvent'],_0x5fdf01,'invalid-auth-event'),{'status':_0x540459['onEvent'](_0x52b00c['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5fdf01['_key']()]={'manager':_0x540459},this['iframes'][_0x5fdf01['_key']()]=_0xd1027a,_0x540459;}['_isIframeWebStorageSupported'](_0x2ea8b3,_0x2e5540){this['iframes'][_0x2ea8b3['_key']()]['send'](pi,{'type':pi},_0xc0ca3d=>{var _0x1c3c78;const _0xd0ff84=(_0x1c3c78=_0xc0ca3d==null?void 0x0:_0xc0ca3d[0x0])==null?void 0x0:_0x1c3c78[pi];_0xd0ff84!==void 0x0&&_0x2e5540(!!_0xd0ff84),Y(_0x2ea8b3,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4297ad){const _0x38d14c=_0x4297ad['_key']();return this['originValidationPromises'][_0x38d14c]||(this['originValidationPromises'][_0x38d14c]=Up(_0x4297ad)),this['originValidationPromises'][_0x38d14c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4ee3e4){this['auth']=_0x4ee3e4,this['internalListeners']=new Map();}['getUid'](){var _0x46f8cf;return this['assertAuthConfigured'](),((_0x46f8cf=this['auth']['currentUser'])==null?void 0x0:_0x46f8cf['uid'])||null;}async['getToken'](_0x1af71f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1af71f)}:null;}['addAuthTokenListener'](_0x51fed8){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x51fed8))return;const _0x2c699b=this['auth']['onIdTokenChanged'](_0x1c95df=>{_0x51fed8((_0x1c95df==null?void 0x0:_0x1c95df['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x51fed8,_0x2c699b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3d64dc){this['assertAuthConfigured']();const _0x49492c=this['internalListeners']['get'](_0x3d64dc);_0x49492c&&(this['internalListeners']['delete'](_0x3d64dc),_0x49492c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3716e6){switch(_0x3716e6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x435889){st(new Fe('auth',(_0x4277a6,{options:_0x9ecc7e})=>{const _0x4fa1fa=_0x4277a6['getProvider']('app')['getImmediate'](),_0x17768c=_0x4277a6['getProvider']('heartbeat'),_0x26c19c=_0x4277a6['getProvider']('app-check-internal'),{apiKey:_0x50e788,authDomain:_0x399355}=_0x4fa1fa['options'];m(_0x50e788&&!_0x50e788['includes'](':'),'invalid-api-key',{'appName':_0x4fa1fa['name']});const _0x577224={'apiKey':_0x50e788,'authDomain':_0x399355,'clientPlatform':_0x435889,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x435889)},_0x6b00ec=new Df(_0x4fa1fa,_0x17768c,_0x26c19c,_0x577224);return Hf(_0x6b00ec,_0x9ecc7e),_0x6b00ec;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x59e5f1,_0x2d6c84,_0x30983c)=>{_0x59e5f1['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x378699=>{const _0x5739e3=Ke(_0x378699['getProvider']('auth')['getImmediate']());return(_0x12c05b=>new l_(_0x12c05b))(_0x5739e3);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x435889)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x3bbb48=>async _0x1cd4f5=>{const _0x461deb=_0x1cd4f5&&await _0x1cd4f5['getIdTokenResult'](),_0x595836=_0x461deb&&(new Date()['getTime']()-Date['parse'](_0x461deb['issuedAtTime']))/0x3e8;if(_0x595836&&_0x595836>f_)return;const _0x152df5=_0x461deb==null?void 0x0:_0x461deb['token'];Br!==_0x152df5&&(Br=_0x152df5,await fetch(_0x3bbb48,{'method':_0x152df5?'POST':'DELETE','headers':_0x152df5?{'Authorization':'Bearer\x20'+_0x152df5}:{}}));};function B_(_0x260af4=Zr()){const _0x59a39d=Hi(_0x260af4,'auth');if(_0x59a39d['isInitialized']())return _0x59a39d['getImmediate']();const _0x19b7ea=Vf(_0x260af4,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x285b72=jr('authTokenSyncURL');if(_0x285b72&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x190a56=new URL(_0x285b72,location['origin']);if(location['origin']===_0x190a56['origin']){const _0x2698ca=p_(_0x190a56['toString']());sp(_0x19b7ea,_0x2698ca,()=>_0x2698ca(_0x19b7ea['currentUser'])),ip(_0x19b7ea,_0x321258=>_0x2698ca(_0x321258));}}const _0x592a29=qr('auth');return _0x592a29&&$f(_0x19b7ea,'http://'+_0x592a29),_0x19b7ea;}function __(){var _0x45ffff;return((_0x45ffff=document['getElementsByTagName']('head'))==null?void 0x0:_0x45ffff[0x0])??document;}Mf({'loadJS'(_0x2e65e3){return new Promise((_0x49acb6,_0x198079)=>{const _0x28efcf=document['createElement']('script');_0x28efcf['setAttribute']('src',_0x2e65e3),_0x28efcf['onload']=_0x49acb6,_0x28efcf['onerror']=_0x57f8ad=>{const _0x427d23=X('internal-error');_0x427d23['customData']=_0x57f8ad,_0x198079(_0x427d23);},_0x28efcf['type']='text/javascript',_0x28efcf['charset']='UTF-8',__()['appendChild'](_0x28efcf);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};