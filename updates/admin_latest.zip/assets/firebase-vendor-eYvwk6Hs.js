const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xd9077c,_0x3670f0){if(!_0xd9077c)throw ht(_0x3670f0);},ht=function(_0x99ff){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x99ff);},Hr=function(_0xe8ef62){const _0x178bbb=[];let _0x4a3dc4=0x0;for(let _0x47e322=0x0;_0x47e322<_0xe8ef62['length'];_0x47e322++){let _0x5570ff=_0xe8ef62['charCodeAt'](_0x47e322);_0x5570ff<0x80?_0x178bbb[_0x4a3dc4++]=_0x5570ff:_0x5570ff<0x800?(_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0x6|0xc0,_0x178bbb[_0x4a3dc4++]=_0x5570ff&0x3f|0x80):(_0x5570ff&0xfc00)===0xd800&&_0x47e322+0x1<_0xe8ef62['length']&&(_0xe8ef62['charCodeAt'](_0x47e322+0x1)&0xfc00)===0xdc00?(_0x5570ff=0x10000+((_0x5570ff&0x3ff)<<0xa)+(_0xe8ef62['charCodeAt'](++_0x47e322)&0x3ff),_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0x12|0xf0,_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0xc&0x3f|0x80,_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0x6&0x3f|0x80,_0x178bbb[_0x4a3dc4++]=_0x5570ff&0x3f|0x80):(_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0xc|0xe0,_0x178bbb[_0x4a3dc4++]=_0x5570ff>>0x6&0x3f|0x80,_0x178bbb[_0x4a3dc4++]=_0x5570ff&0x3f|0x80);}return _0x178bbb;},nc=function(_0x22fafd){const _0x2af757=[];let _0x5998d3=0x0,_0x279abe=0x0;for(;_0x5998d3<_0x22fafd['length'];){const _0x1684c8=_0x22fafd[_0x5998d3++];if(_0x1684c8<0x80)_0x2af757[_0x279abe++]=String['fromCharCode'](_0x1684c8);else{if(_0x1684c8>0xbf&&_0x1684c8<0xe0){const _0x2ab7ed=_0x22fafd[_0x5998d3++];_0x2af757[_0x279abe++]=String['fromCharCode']((_0x1684c8&0x1f)<<0x6|_0x2ab7ed&0x3f);}else{if(_0x1684c8>0xef&&_0x1684c8<0x16d){const _0x2492ba=_0x22fafd[_0x5998d3++],_0x45c3d8=_0x22fafd[_0x5998d3++],_0x37c316=_0x22fafd[_0x5998d3++],_0x5a95bb=((_0x1684c8&0x7)<<0x12|(_0x2492ba&0x3f)<<0xc|(_0x45c3d8&0x3f)<<0x6|_0x37c316&0x3f)-0x10000;_0x2af757[_0x279abe++]=String['fromCharCode'](0xd800+(_0x5a95bb>>0xa)),_0x2af757[_0x279abe++]=String['fromCharCode'](0xdc00+(_0x5a95bb&0x3ff));}else{const _0x4cd9de=_0x22fafd[_0x5998d3++],_0x2bd447=_0x22fafd[_0x5998d3++];_0x2af757[_0x279abe++]=String['fromCharCode']((_0x1684c8&0xf)<<0xc|(_0x4cd9de&0x3f)<<0x6|_0x2bd447&0x3f);}}}}return _0x2af757['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x5ea62e,_0xb91492){if(!Array['isArray'](_0x5ea62e))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4607d9=_0xb91492?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4c9955=[];for(let _0x144402=0x0;_0x144402<_0x5ea62e['length'];_0x144402+=0x3){const _0xd2728f=_0x5ea62e[_0x144402],_0x2b137e=_0x144402+0x1<_0x5ea62e['length'],_0x4a7151=_0x2b137e?_0x5ea62e[_0x144402+0x1]:0x0,_0x520a92=_0x144402+0x2<_0x5ea62e['length'],_0x405fa1=_0x520a92?_0x5ea62e[_0x144402+0x2]:0x0,_0x28ffd2=_0xd2728f>>0x2,_0x350f1f=(_0xd2728f&0x3)<<0x4|_0x4a7151>>0x4;let _0x551844=(_0x4a7151&0xf)<<0x2|_0x405fa1>>0x6,_0x54f78b=_0x405fa1&0x3f;_0x520a92||(_0x54f78b=0x40,_0x2b137e||(_0x551844=0x40)),_0x4c9955['push'](_0x4607d9[_0x28ffd2],_0x4607d9[_0x350f1f],_0x4607d9[_0x551844],_0x4607d9[_0x54f78b]);}return _0x4c9955['join']('');},'encodeString'(_0x3f0258,_0xd7f6d4){return this['HAS_NATIVE_SUPPORT']&&!_0xd7f6d4?btoa(_0x3f0258):this['encodeByteArray'](Hr(_0x3f0258),_0xd7f6d4);},'decodeString'(_0x239c6c,_0xeb8d33){return this['HAS_NATIVE_SUPPORT']&&!_0xeb8d33?atob(_0x239c6c):nc(this['decodeStringToByteArray'](_0x239c6c,_0xeb8d33));},'decodeStringToByteArray'(_0x10ef39,_0x37eb8e){this['init_']();const _0x3985a9=_0x37eb8e?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x416270=[];for(let _0x35a6ee=0x0;_0x35a6ee<_0x10ef39['length'];){const _0x49969a=_0x3985a9[_0x10ef39['charAt'](_0x35a6ee++)],_0x43975d=_0x35a6ee<_0x10ef39['length']?_0x3985a9[_0x10ef39['charAt'](_0x35a6ee)]:0x0;++_0x35a6ee;const _0x24759d=_0x35a6ee<_0x10ef39['length']?_0x3985a9[_0x10ef39['charAt'](_0x35a6ee)]:0x40;++_0x35a6ee;const _0x244318=_0x35a6ee<_0x10ef39['length']?_0x3985a9[_0x10ef39['charAt'](_0x35a6ee)]:0x40;if(++_0x35a6ee,_0x49969a==null||_0x43975d==null||_0x24759d==null||_0x244318==null)throw new ic();const _0x1b10a7=_0x49969a<<0x2|_0x43975d>>0x4;if(_0x416270['push'](_0x1b10a7),_0x24759d!==0x40){const _0x289866=_0x43975d<<0x4&0xf0|_0x24759d>>0x2;if(_0x416270['push'](_0x289866),_0x244318!==0x40){const _0x2cbf73=_0x24759d<<0x6&0xc0|_0x244318;_0x416270['push'](_0x2cbf73);}}}return _0x416270;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3d21cb=0x0;_0x3d21cb<this['ENCODED_VALS']['length'];_0x3d21cb++)this['byteToCharMap_'][_0x3d21cb]=this['ENCODED_VALS']['charAt'](_0x3d21cb),this['charToByteMap_'][this['byteToCharMap_'][_0x3d21cb]]=_0x3d21cb,this['byteToCharMapWebSafe_'][_0x3d21cb]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3d21cb),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3d21cb]]=_0x3d21cb,_0x3d21cb>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3d21cb)]=_0x3d21cb,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3d21cb)]=_0x3d21cb);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0xce6f6a){const _0x2a2f8e=Hr(_0xce6f6a);return Fi['encodeByteArray'](_0x2a2f8e,!0x0);},dn=function(_0x2b5083){return $r(_0x2b5083)['replace'](/\./g,'');},fn=function(_0x27889c){try{return Fi['decodeString'](_0x27889c,!0x0);}catch(_0x350298){console['error']('base64Decode\x20failed:\x20',_0x350298);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3a7650){return Gr(void 0x0,_0x3a7650);}function Gr(_0x18fa9a,_0x58b06f){if(!(_0x58b06f instanceof Object))return _0x58b06f;switch(_0x58b06f['constructor']){case Date:const _0x37eb68=_0x58b06f;return new Date(_0x37eb68['getTime']());case Object:_0x18fa9a===void 0x0&&(_0x18fa9a={});break;case Array:_0x18fa9a=[];break;default:return _0x58b06f;}for(const _0x517b11 in _0x58b06f)!_0x58b06f['hasOwnProperty'](_0x517b11)||!rc(_0x517b11)||(_0x18fa9a[_0x517b11]=Gr(_0x18fa9a[_0x517b11],_0x58b06f[_0x517b11]));return _0x18fa9a;}function rc(_0x2d3a24){return _0x2d3a24!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x220c63=Ps['__FIREBASE_DEFAULTS__'];if(_0x220c63)return JSON['parse'](_0x220c63);},lc=()=>{if(typeof document>'u')return;let _0x3ca5d9;try{_0x3ca5d9=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x573eb4=_0x3ca5d9&&fn(_0x3ca5d9[0x1]);return _0x573eb4&&JSON['parse'](_0x573eb4);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x2248a7){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x2248a7);return;}},qr=_0x250ea1=>{var _0x21c79e,_0xb38de2;return(_0xb38de2=(_0x21c79e=Ui())==null?void 0x0:_0x21c79e['emulatorHosts'])==null?void 0x0:_0xb38de2[_0x250ea1];},hc=_0x26c796=>{const _0x46a42f=qr(_0x26c796);if(!_0x46a42f)return;const _0x25b5a0=_0x46a42f['lastIndexOf'](':');if(_0x25b5a0<=0x0||_0x25b5a0+0x1===_0x46a42f['length'])throw new Error('Invalid\x20host\x20'+_0x46a42f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x156edb=parseInt(_0x46a42f['substring'](_0x25b5a0+0x1),0xa);return _0x46a42f[0x0]==='['?[_0x46a42f['substring'](0x1,_0x25b5a0-0x1),_0x156edb]:[_0x46a42f['substring'](0x0,_0x25b5a0),_0x156edb];},zr=()=>{var _0x2ab414;return(_0x2ab414=Ui())==null?void 0x0:_0x2ab414['config'];},jr=_0x16c5dd=>{var _0x1ef083;return(_0x1ef083=Ui())==null?void 0x0:_0x1ef083['_'+_0x16c5dd];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x13b3f1,_0x206752)=>{this['resolve']=_0x13b3f1,this['reject']=_0x206752;});}['wrapCallback'](_0x5c985d){return(_0x5cf36b,_0x456aa8)=>{_0x5cf36b?this['reject'](_0x5cf36b):this['resolve'](_0x456aa8),typeof _0x5c985d=='function'&&(this['promise']['catch'](()=>{}),_0x5c985d['length']===0x1?_0x5c985d(_0x5cf36b):_0x5c985d(_0x5cf36b,_0x456aa8));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x29567a,_0x1ec43c){if(_0x29567a['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3a582f={'alg':'none','type':'JWT'},_0x94f9f2=_0x1ec43c||'demo-project',_0x26020f=_0x29567a['iat']||0x0,_0x906e2b=_0x29567a['sub']||_0x29567a['user_id'];if(!_0x906e2b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5e72f8={'iss':'https://securetoken.google.com/'+_0x94f9f2,'aud':_0x94f9f2,'iat':_0x26020f,'exp':_0x26020f+0xe10,'auth_time':_0x26020f,'sub':_0x906e2b,'user_id':_0x906e2b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x29567a};return[dn(JSON['stringify'](_0x3a582f)),dn(JSON['stringify'](_0x5e72f8)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0xb9de56=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xb9de56=='object'&&_0xb9de56['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x18dfb3=W();return _0x18dfb3['indexOf']('MSIE\x20')>=0x0||_0x18dfb3['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x1339b1,_0x29e603)=>{try{let _0x1f033b=!0x0;const _0x7658b7='validate-browser-context-for-indexeddb-analytics-module',_0x11768a=self['indexedDB']['open'](_0x7658b7);_0x11768a['onsuccess']=()=>{_0x11768a['result']['close'](),_0x1f033b||self['indexedDB']['deleteDatabase'](_0x7658b7),_0x1339b1(!0x0);},_0x11768a['onupgradeneeded']=()=>{_0x1f033b=!0x1;},_0x11768a['onerror']=()=>{var _0x20482d;_0x29e603(((_0x20482d=_0x11768a['error'])==null?void 0x0:_0x20482d['message'])||'');};}catch(_0x1fc3b3){_0x29e603(_0x1fc3b3);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x580806,_0x175dba,_0x58f431){super(_0x175dba),this['code']=_0x580806,this['customData']=_0x58f431,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x3bf422,_0x36229f,_0x557641){this['service']=_0x3bf422,this['serviceName']=_0x36229f,this['errors']=_0x557641;}['create'](_0x43c8b1,..._0x55420b){const _0x17bfe0=_0x55420b[0x0]||{},_0x4a902b=this['service']+'/'+_0x43c8b1,_0x21269c=this['errors'][_0x43c8b1],_0x1d1a2e=_0x21269c?vc(_0x21269c,_0x17bfe0):'Error',_0x2910c2=this['serviceName']+':\x20'+_0x1d1a2e+'\x20('+_0x4a902b+').';return new Re(_0x4a902b,_0x2910c2,_0x17bfe0);}}function vc(_0x40644e,_0x93c6f7){return _0x40644e['replace'](Ec,(_0x60eb6e,_0x4a1f60)=>{const _0x124617=_0x93c6f7[_0x4a1f60];return _0x124617!=null?String(_0x124617):'<'+_0x4a1f60+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x123ebb){return JSON['parse'](_0x123ebb);}function O(_0x2ae649){return JSON['stringify'](_0x2ae649);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x34a2bb){let _0x4ccebe={},_0x4846ba={},_0x258e95={},_0x1f7c0b='';try{const _0x4ead71=_0x34a2bb['split']('.');_0x4ccebe=Nt(fn(_0x4ead71[0x0])||''),_0x4846ba=Nt(fn(_0x4ead71[0x1])||''),_0x1f7c0b=_0x4ead71[0x2],_0x258e95=_0x4846ba['d']||{},delete _0x4846ba['d'];}catch{}return{'header':_0x4ccebe,'claims':_0x4846ba,'data':_0x258e95,'signature':_0x1f7c0b};},Ic=function(_0x370683){const _0x45ac05=Yr(_0x370683),_0x49cf8f=_0x45ac05['claims'];return!!_0x49cf8f&&typeof _0x49cf8f=='object'&&_0x49cf8f['hasOwnProperty']('iat');},wc=function(_0x11c27a){const _0x199eb0=Yr(_0x11c27a)['claims'];return typeof _0x199eb0=='object'&&_0x199eb0['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1d7d49,_0x58afca){return Object['prototype']['hasOwnProperty']['call'](_0x1d7d49,_0x58afca);}function Le(_0x2f3cdf,_0x539838){if(Object['prototype']['hasOwnProperty']['call'](_0x2f3cdf,_0x539838))return _0x2f3cdf[_0x539838];}function pn(_0x1499f4){for(const _0x13f6f9 in _0x1499f4)if(Object['prototype']['hasOwnProperty']['call'](_0x1499f4,_0x13f6f9))return!0x1;return!0x0;}function _n(_0x2c46c4,_0x395504,_0x432d33){const _0x1cf146={};for(const _0x322940 in _0x2c46c4)Object['prototype']['hasOwnProperty']['call'](_0x2c46c4,_0x322940)&&(_0x1cf146[_0x322940]=_0x395504['call'](_0x432d33,_0x2c46c4[_0x322940],_0x322940,_0x2c46c4));return _0x1cf146;}function xe(_0x310b44,_0x29ec75){if(_0x310b44===_0x29ec75)return!0x0;const _0x3f537e=Object['keys'](_0x310b44),_0x5c4190=Object['keys'](_0x29ec75);for(const _0x171cea of _0x3f537e){if(!_0x5c4190['includes'](_0x171cea))return!0x1;const _0x2b92dc=_0x310b44[_0x171cea],_0x55f4ab=_0x29ec75[_0x171cea];if(Ns(_0x2b92dc)&&Ns(_0x55f4ab)){if(!xe(_0x2b92dc,_0x55f4ab))return!0x1;}else{if(_0x2b92dc!==_0x55f4ab)return!0x1;}}for(const _0x48ac02 of _0x5c4190)if(!_0x3f537e['includes'](_0x48ac02))return!0x1;return!0x0;}function Ns(_0x308409){return _0x308409!==null&&typeof _0x308409=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x5a4668){const _0x4fcbc5=[];for(const [_0xc1486f,_0x336436]of Object['entries'](_0x5a4668))Array['isArray'](_0x336436)?_0x336436['forEach'](_0x2f1502=>{_0x4fcbc5['push'](encodeURIComponent(_0xc1486f)+'='+encodeURIComponent(_0x2f1502));}):_0x4fcbc5['push'](encodeURIComponent(_0xc1486f)+'='+encodeURIComponent(_0x336436));return _0x4fcbc5['length']?'&'+_0x4fcbc5['join']('&'):'';}function Ct(_0x774529){const _0x192d2f={};return _0x774529['replace'](/^\?/,'')['split']('&')['forEach'](_0x29c05f=>{if(_0x29c05f){const [_0x49952c,_0x46a68a]=_0x29c05f['split']('=');_0x192d2f[decodeURIComponent(_0x49952c)]=decodeURIComponent(_0x46a68a);}}),_0x192d2f;}function Tt(_0x21a226){const _0xd28eaa=_0x21a226['indexOf']('?');if(!_0xd28eaa)return'';const _0x413b2a=_0x21a226['indexOf']('#',_0xd28eaa);return _0x21a226['substring'](_0xd28eaa,_0x413b2a>0x0?_0x413b2a:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5dd6b8=0x1;_0x5dd6b8<this['blockSize'];++_0x5dd6b8)this['pad_'][_0x5dd6b8]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x437726,_0x52c962){_0x52c962||(_0x52c962=0x0);const _0x4c515a=this['W_'];if(typeof _0x437726=='string'){for(let _0x305a39=0x0;_0x305a39<0x10;_0x305a39++)_0x4c515a[_0x305a39]=_0x437726['charCodeAt'](_0x52c962)<<0x18|_0x437726['charCodeAt'](_0x52c962+0x1)<<0x10|_0x437726['charCodeAt'](_0x52c962+0x2)<<0x8|_0x437726['charCodeAt'](_0x52c962+0x3),_0x52c962+=0x4;}else{for(let _0x4b47e4=0x0;_0x4b47e4<0x10;_0x4b47e4++)_0x4c515a[_0x4b47e4]=_0x437726[_0x52c962]<<0x18|_0x437726[_0x52c962+0x1]<<0x10|_0x437726[_0x52c962+0x2]<<0x8|_0x437726[_0x52c962+0x3],_0x52c962+=0x4;}for(let _0x3c0c77=0x10;_0x3c0c77<0x50;_0x3c0c77++){const _0x35282a=_0x4c515a[_0x3c0c77-0x3]^_0x4c515a[_0x3c0c77-0x8]^_0x4c515a[_0x3c0c77-0xe]^_0x4c515a[_0x3c0c77-0x10];_0x4c515a[_0x3c0c77]=(_0x35282a<<0x1|_0x35282a>>>0x1f)&0xffffffff;}let _0x640de9=this['chain_'][0x0],_0x51e920=this['chain_'][0x1],_0x5063a6=this['chain_'][0x2],_0x207b1e=this['chain_'][0x3],_0x551c2f=this['chain_'][0x4],_0x1c025c,_0x93e3f4;for(let _0x16b9ea=0x0;_0x16b9ea<0x50;_0x16b9ea++){_0x16b9ea<0x28?_0x16b9ea<0x14?(_0x1c025c=_0x207b1e^_0x51e920&(_0x5063a6^_0x207b1e),_0x93e3f4=0x5a827999):(_0x1c025c=_0x51e920^_0x5063a6^_0x207b1e,_0x93e3f4=0x6ed9eba1):_0x16b9ea<0x3c?(_0x1c025c=_0x51e920&_0x5063a6|_0x207b1e&(_0x51e920|_0x5063a6),_0x93e3f4=0x8f1bbcdc):(_0x1c025c=_0x51e920^_0x5063a6^_0x207b1e,_0x93e3f4=0xca62c1d6);const _0x5bf96b=(_0x640de9<<0x5|_0x640de9>>>0x1b)+_0x1c025c+_0x551c2f+_0x93e3f4+_0x4c515a[_0x16b9ea]&0xffffffff;_0x551c2f=_0x207b1e,_0x207b1e=_0x5063a6,_0x5063a6=(_0x51e920<<0x1e|_0x51e920>>>0x2)&0xffffffff,_0x51e920=_0x640de9,_0x640de9=_0x5bf96b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x640de9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x51e920&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5063a6&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x207b1e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x551c2f&0xffffffff;}['update'](_0x289b55,_0x66d7f8){if(_0x289b55==null)return;_0x66d7f8===void 0x0&&(_0x66d7f8=_0x289b55['length']);const _0x42aa40=_0x66d7f8-this['blockSize'];let _0x5d10af=0x0;const _0x19b46a=this['buf_'];let _0x2d27f0=this['inbuf_'];for(;_0x5d10af<_0x66d7f8;){if(_0x2d27f0===0x0){for(;_0x5d10af<=_0x42aa40;)this['compress_'](_0x289b55,_0x5d10af),_0x5d10af+=this['blockSize'];}if(typeof _0x289b55=='string'){for(;_0x5d10af<_0x66d7f8;)if(_0x19b46a[_0x2d27f0]=_0x289b55['charCodeAt'](_0x5d10af),++_0x2d27f0,++_0x5d10af,_0x2d27f0===this['blockSize']){this['compress_'](_0x19b46a),_0x2d27f0=0x0;break;}}else{for(;_0x5d10af<_0x66d7f8;)if(_0x19b46a[_0x2d27f0]=_0x289b55[_0x5d10af],++_0x2d27f0,++_0x5d10af,_0x2d27f0===this['blockSize']){this['compress_'](_0x19b46a),_0x2d27f0=0x0;break;}}}this['inbuf_']=_0x2d27f0,this['total_']+=_0x66d7f8;}['digest'](){const _0x51af9f=[];let _0x342e4e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1a1ade=this['blockSize']-0x1;_0x1a1ade>=0x38;_0x1a1ade--)this['buf_'][_0x1a1ade]=_0x342e4e&0xff,_0x342e4e/=0x100;this['compress_'](this['buf_']);let _0x56deec=0x0;for(let _0xcc03da=0x0;_0xcc03da<0x5;_0xcc03da++)for(let _0x2a5005=0x18;_0x2a5005>=0x0;_0x2a5005-=0x8)_0x51af9f[_0x56deec]=this['chain_'][_0xcc03da]>>_0x2a5005&0xff,++_0x56deec;return _0x51af9f;}}function Tc(_0x3c9967,_0xbb641c){const _0x398d64=new Sc(_0x3c9967,_0xbb641c);return _0x398d64['subscribe']['bind'](_0x398d64);}class Sc{constructor(_0x2624ac,_0x965ff2){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x965ff2,this['task']['then'](()=>{_0x2624ac(this);})['catch'](_0x2fd0ca=>{this['error'](_0x2fd0ca);});}['next'](_0x5e25ab){this['forEachObserver'](_0x543ccd=>{_0x543ccd['next'](_0x5e25ab);});}['error'](_0xcbb221){this['forEachObserver'](_0x267b4d=>{_0x267b4d['error'](_0xcbb221);}),this['close'](_0xcbb221);}['complete'](){this['forEachObserver'](_0x1b5a4e=>{_0x1b5a4e['complete']();}),this['close']();}['subscribe'](_0x267f82,_0x10c01c,_0x376bb5){let _0x2a4888;if(_0x267f82===void 0x0&&_0x10c01c===void 0x0&&_0x376bb5===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x267f82,['next','error','complete'])?_0x2a4888=_0x267f82:_0x2a4888={'next':_0x267f82,'error':_0x10c01c,'complete':_0x376bb5},_0x2a4888['next']===void 0x0&&(_0x2a4888['next']=ti),_0x2a4888['error']===void 0x0&&(_0x2a4888['error']=ti),_0x2a4888['complete']===void 0x0&&(_0x2a4888['complete']=ti);const _0x5301db=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2a4888['error'](this['finalError']):_0x2a4888['complete']();}catch{}}),this['observers']['push'](_0x2a4888),_0x5301db;}['unsubscribeOne'](_0x35a171){this['observers']===void 0x0||this['observers'][_0x35a171]===void 0x0||(delete this['observers'][_0x35a171],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4de5c8){if(!this['finalized']){for(let _0x8ad70f=0x0;_0x8ad70f<this['observers']['length'];_0x8ad70f++)this['sendOne'](_0x8ad70f,_0x4de5c8);}}['sendOne'](_0x5cdd2e,_0xcbcb1b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5cdd2e]!==void 0x0)try{_0xcbcb1b(this['observers'][_0x5cdd2e]);}catch(_0x30eee5){typeof console<'u'&&console['error']&&console['error'](_0x30eee5);}});}['close'](_0x5bbb46){this['finalized']||(this['finalized']=!0x0,_0x5bbb46!==void 0x0&&(this['finalError']=_0x5bbb46),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x129354,_0x2d3911){if(typeof _0x129354!='object'||_0x129354===null)return!0x1;for(const _0x423d24 of _0x2d3911)if(_0x423d24 in _0x129354&&typeof _0x129354[_0x423d24]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x29d982,_0x3457c3){return _0x29d982+'\x20failed:\x20'+_0x3457c3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4663da){const _0xde0c96=[];let _0xcf6b29=0x0;for(let _0xc55fc9=0x0;_0xc55fc9<_0x4663da['length'];_0xc55fc9++){let _0x154c2c=_0x4663da['charCodeAt'](_0xc55fc9);if(_0x154c2c>=0xd800&&_0x154c2c<=0xdbff){const _0x43d2f8=_0x154c2c-0xd800;_0xc55fc9++,f(_0xc55fc9<_0x4663da['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5ef644=_0x4663da['charCodeAt'](_0xc55fc9)-0xdc00;_0x154c2c=0x10000+(_0x43d2f8<<0xa)+_0x5ef644;}_0x154c2c<0x80?_0xde0c96[_0xcf6b29++]=_0x154c2c:_0x154c2c<0x800?(_0xde0c96[_0xcf6b29++]=_0x154c2c>>0x6|0xc0,_0xde0c96[_0xcf6b29++]=_0x154c2c&0x3f|0x80):_0x154c2c<0x10000?(_0xde0c96[_0xcf6b29++]=_0x154c2c>>0xc|0xe0,_0xde0c96[_0xcf6b29++]=_0x154c2c>>0x6&0x3f|0x80,_0xde0c96[_0xcf6b29++]=_0x154c2c&0x3f|0x80):(_0xde0c96[_0xcf6b29++]=_0x154c2c>>0x12|0xf0,_0xde0c96[_0xcf6b29++]=_0x154c2c>>0xc&0x3f|0x80,_0xde0c96[_0xcf6b29++]=_0x154c2c>>0x6&0x3f|0x80,_0xde0c96[_0xcf6b29++]=_0x154c2c&0x3f|0x80);}return _0xde0c96;},Ln=function(_0x47b379){let _0x4fe66f=0x0;for(let _0x2f3e96=0x0;_0x2f3e96<_0x47b379['length'];_0x2f3e96++){const _0x315997=_0x47b379['charCodeAt'](_0x2f3e96);_0x315997<0x80?_0x4fe66f++:_0x315997<0x800?_0x4fe66f+=0x2:_0x315997>=0xd800&&_0x315997<=0xdbff?(_0x4fe66f+=0x4,_0x2f3e96++):_0x4fe66f+=0x3;}return _0x4fe66f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x428975){return _0x428975&&_0x428975['_delegate']?_0x428975['_delegate']:_0x428975;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x449c0f){try{return(_0x449c0f['startsWith']('http://')||_0x449c0f['startsWith']('https://')?new URL(_0x449c0f)['hostname']:_0x449c0f)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x5e06c8){return(await fetch(_0x5e06c8,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x5c4a61,_0x12978d,_0x4a1a79){this['name']=_0x5c4a61,this['instanceFactory']=_0x12978d,this['type']=_0x4a1a79,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x493c4d){return this['instantiationMode']=_0x493c4d,this;}['setMultipleInstances'](_0x1d9ba5){return this['multipleInstances']=_0x1d9ba5,this;}['setServiceProps'](_0x83d4aa){return this['serviceProps']=_0x83d4aa,this;}['setInstanceCreatedCallback'](_0x4c99){return this['onInstanceCreated']=_0x4c99,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2761d3,_0x49d005){this['name']=_0x2761d3,this['container']=_0x49d005,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5244cd){const _0x287071=this['normalizeInstanceIdentifier'](_0x5244cd);if(!this['instancesDeferred']['has'](_0x287071)){const _0x29e7e6=new H();if(this['instancesDeferred']['set'](_0x287071,_0x29e7e6),this['isInitialized'](_0x287071)||this['shouldAutoInitialize']())try{const _0x22f4de=this['getOrInitializeService']({'instanceIdentifier':_0x287071});_0x22f4de&&_0x29e7e6['resolve'](_0x22f4de);}catch{}}return this['instancesDeferred']['get'](_0x287071)['promise'];}['getImmediate'](_0x1e0be1){const _0x2aab5e=this['normalizeInstanceIdentifier'](_0x1e0be1==null?void 0x0:_0x1e0be1['identifier']),_0x9d210e=(_0x1e0be1==null?void 0x0:_0x1e0be1['optional'])??!0x1;if(this['isInitialized'](_0x2aab5e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2aab5e});}catch(_0x50f79f){if(_0x9d210e)return null;throw _0x50f79f;}else{if(_0x9d210e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x215dcb){if(_0x215dcb['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x215dcb['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x215dcb,!!this['shouldAutoInitialize']()){if(Pc(_0x215dcb))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0xbbfb6c,_0x1b0d95]of this['instancesDeferred']['entries']()){const _0x335660=this['normalizeInstanceIdentifier'](_0xbbfb6c);try{const _0x3d6a00=this['getOrInitializeService']({'instanceIdentifier':_0x335660});_0x1b0d95['resolve'](_0x3d6a00);}catch{}}}}['clearInstance'](_0x54205d=Ne){this['instancesDeferred']['delete'](_0x54205d),this['instancesOptions']['delete'](_0x54205d),this['instances']['delete'](_0x54205d);}async['delete'](){const _0x493c35=Array['from'](this['instances']['values']());await Promise['all']([..._0x493c35['filter'](_0xdbd8b6=>'INTERNAL'in _0xdbd8b6)['map'](_0x5e81ab=>_0x5e81ab['INTERNAL']['delete']()),..._0x493c35['filter'](_0xc1efe8=>'_delete'in _0xc1efe8)['map'](_0x4a0cb0=>_0x4a0cb0['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xf23d8e=Ne){return this['instances']['has'](_0xf23d8e);}['getOptions'](_0x58310e=Ne){return this['instancesOptions']['get'](_0x58310e)||{};}['initialize'](_0x47fdd2={}){const {options:_0x3236a4={}}=_0x47fdd2,_0x85a64a=this['normalizeInstanceIdentifier'](_0x47fdd2['instanceIdentifier']);if(this['isInitialized'](_0x85a64a))throw Error(this['name']+'('+_0x85a64a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3edf68=this['getOrInitializeService']({'instanceIdentifier':_0x85a64a,'options':_0x3236a4});for(const [_0x4d9a43,_0x1b286b]of this['instancesDeferred']['entries']()){const _0x24589a=this['normalizeInstanceIdentifier'](_0x4d9a43);_0x85a64a===_0x24589a&&_0x1b286b['resolve'](_0x3edf68);}return _0x3edf68;}['onInit'](_0x1bdab8,_0x264088){const _0x24cc79=this['normalizeInstanceIdentifier'](_0x264088),_0x17ffbd=this['onInitCallbacks']['get'](_0x24cc79)??new Set();_0x17ffbd['add'](_0x1bdab8),this['onInitCallbacks']['set'](_0x24cc79,_0x17ffbd);const _0x43eddf=this['instances']['get'](_0x24cc79);return _0x43eddf&&_0x1bdab8(_0x43eddf,_0x24cc79),()=>{_0x17ffbd['delete'](_0x1bdab8);};}['invokeOnInitCallbacks'](_0x38cee0,_0x4a4957){const _0x391a83=this['onInitCallbacks']['get'](_0x4a4957);if(_0x391a83){for(const _0x52eef9 of _0x391a83)try{_0x52eef9(_0x38cee0,_0x4a4957);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x19a2b2,options:_0x3a520b={}}){let _0x323538=this['instances']['get'](_0x19a2b2);if(!_0x323538&&this['component']&&(_0x323538=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x19a2b2),'options':_0x3a520b}),this['instances']['set'](_0x19a2b2,_0x323538),this['instancesOptions']['set'](_0x19a2b2,_0x3a520b),this['invokeOnInitCallbacks'](_0x323538,_0x19a2b2),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x19a2b2,_0x323538);}catch{}return _0x323538||null;}['normalizeInstanceIdentifier'](_0x365efb=Ne){return this['component']?this['component']['multipleInstances']?_0x365efb:Ne:_0x365efb;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x3522c0){return _0x3522c0===Ne?void 0x0:_0x3522c0;}function Pc(_0x4fdf73){return _0x4fdf73['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x1e868f){this['name']=_0x1e868f,this['providers']=new Map();}['addComponent'](_0x20267e){const _0x30a87d=this['getProvider'](_0x20267e['name']);if(_0x30a87d['isComponentSet']())throw new Error('Component\x20'+_0x20267e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x30a87d['setComponent'](_0x20267e);}['addOrOverwriteComponent'](_0x2502bb){this['getProvider'](_0x2502bb['name'])['isComponentSet']()&&this['providers']['delete'](_0x2502bb['name']),this['addComponent'](_0x2502bb);}['getProvider'](_0x45e34d){if(this['providers']['has'](_0x45e34d))return this['providers']['get'](_0x45e34d);const _0x24d3c1=new Ac(_0x45e34d,this);return this['providers']['set'](_0x45e34d,_0x24d3c1),_0x24d3c1;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xebf97a){_0xebf97a[_0xebf97a['DEBUG']=0x0]='DEBUG',_0xebf97a[_0xebf97a['VERBOSE']=0x1]='VERBOSE',_0xebf97a[_0xebf97a['INFO']=0x2]='INFO',_0xebf97a[_0xebf97a['WARN']=0x3]='WARN',_0xebf97a[_0xebf97a['ERROR']=0x4]='ERROR',_0xebf97a[_0xebf97a['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x331b4e,_0x11045e,..._0x4a842e)=>{if(_0x11045e<_0x331b4e['logLevel'])return;const _0x2e1e3c=new Date()['toISOString'](),_0x5477d3=Mc[_0x11045e];if(_0x5477d3)console[_0x5477d3]('['+_0x2e1e3c+']\x20\x20'+_0x331b4e['name']+':',..._0x4a842e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x11045e+')');};class Bi{constructor(_0x16fa02){this['name']=_0x16fa02,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1b8ea4){if(!(_0x1b8ea4 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1b8ea4+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1b8ea4;}['setLogLevel'](_0x19e8c3){this['_logLevel']=typeof _0x19e8c3=='string'?Oc[_0x19e8c3]:_0x19e8c3;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x15fc7a){if(typeof _0x15fc7a!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x15fc7a;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x524c1d){this['_userLogHandler']=_0x524c1d;}['debug'](..._0x3aa665){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3aa665),this['_logHandler'](this,T['DEBUG'],..._0x3aa665);}['log'](..._0x1dbd5e){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1dbd5e),this['_logHandler'](this,T['VERBOSE'],..._0x1dbd5e);}['info'](..._0x19ef7b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x19ef7b),this['_logHandler'](this,T['INFO'],..._0x19ef7b);}['warn'](..._0x26e968){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x26e968),this['_logHandler'](this,T['WARN'],..._0x26e968);}['error'](..._0x4bbb94){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4bbb94),this['_logHandler'](this,T['ERROR'],..._0x4bbb94);}}const xc=(_0x299a84,_0x4de552)=>_0x4de552['some'](_0x30051f=>_0x299a84 instanceof _0x30051f);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x499cb1){const _0x3df429=new Promise((_0x299a1e,_0x1e6aed)=>{const _0xcd9525=()=>{_0x499cb1['removeEventListener']('success',_0x344267),_0x499cb1['removeEventListener']('error',_0xa6d547);},_0x344267=()=>{_0x299a1e(ge(_0x499cb1['result'])),_0xcd9525();},_0xa6d547=()=>{_0x1e6aed(_0x499cb1['error']),_0xcd9525();};_0x499cb1['addEventListener']('success',_0x344267),_0x499cb1['addEventListener']('error',_0xa6d547);});return _0x3df429['then'](_0x12d9fb=>{_0x12d9fb instanceof IDBCursor&&Jr['set'](_0x12d9fb,_0x499cb1);})['catch'](()=>{}),Vi['set'](_0x3df429,_0x499cb1),_0x3df429;}function Bc(_0x24520a){if(_i['has'](_0x24520a))return;const _0x1c8bda=new Promise((_0x2f78d7,_0x63823e)=>{const _0x30e563=()=>{_0x24520a['removeEventListener']('complete',_0x3cc3d4),_0x24520a['removeEventListener']('error',_0x5050f9),_0x24520a['removeEventListener']('abort',_0x5050f9);},_0x3cc3d4=()=>{_0x2f78d7(),_0x30e563();},_0x5050f9=()=>{_0x63823e(_0x24520a['error']||new DOMException('AbortError','AbortError')),_0x30e563();};_0x24520a['addEventListener']('complete',_0x3cc3d4),_0x24520a['addEventListener']('error',_0x5050f9),_0x24520a['addEventListener']('abort',_0x5050f9);});_i['set'](_0x24520a,_0x1c8bda);}let gi={'get'(_0x3dafc6,_0x44632d,_0x39c265){if(_0x3dafc6 instanceof IDBTransaction){if(_0x44632d==='done')return _i['get'](_0x3dafc6);if(_0x44632d==='objectStoreNames')return _0x3dafc6['objectStoreNames']||Xr['get'](_0x3dafc6);if(_0x44632d==='store')return _0x39c265['objectStoreNames'][0x1]?void 0x0:_0x39c265['objectStore'](_0x39c265['objectStoreNames'][0x0]);}return ge(_0x3dafc6[_0x44632d]);},'set'(_0x5e5ab4,_0x20581e,_0x5b8415){return _0x5e5ab4[_0x20581e]=_0x5b8415,!0x0;},'has'(_0x5f304a,_0x1baf98){return _0x5f304a instanceof IDBTransaction&&(_0x1baf98==='done'||_0x1baf98==='store')?!0x0:_0x1baf98 in _0x5f304a;}};function Vc(_0x5a7561){gi=_0x5a7561(gi);}function Hc(_0x58b07e){return _0x58b07e===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x37a114,..._0x3c595c){const _0x4c00ba=_0x58b07e['call'](ii(this),_0x37a114,..._0x3c595c);return Xr['set'](_0x4c00ba,_0x37a114['sort']?_0x37a114['sort']():[_0x37a114]),ge(_0x4c00ba);}:Uc()['includes'](_0x58b07e)?function(..._0x2344e0){return _0x58b07e['apply'](ii(this),_0x2344e0),ge(Jr['get'](this));}:function(..._0x520b25){return ge(_0x58b07e['apply'](ii(this),_0x520b25));};}function $c(_0x1d35eb){return typeof _0x1d35eb=='function'?Hc(_0x1d35eb):(_0x1d35eb instanceof IDBTransaction&&Bc(_0x1d35eb),xc(_0x1d35eb,Fc())?new Proxy(_0x1d35eb,gi):_0x1d35eb);}function ge(_0xaa62f6){if(_0xaa62f6 instanceof IDBRequest)return Wc(_0xaa62f6);if(ni['has'](_0xaa62f6))return ni['get'](_0xaa62f6);const _0x1b640d=$c(_0xaa62f6);return _0x1b640d!==_0xaa62f6&&(ni['set'](_0xaa62f6,_0x1b640d),Vi['set'](_0x1b640d,_0xaa62f6)),_0x1b640d;}const ii=_0x198a43=>Vi['get'](_0x198a43);function Gc(_0x2b386b,_0x4295a9,{blocked:_0x3878df,upgrade:_0x566d72,blocking:_0x5d050a,terminated:_0x42e9c2}={}){const _0x2bfb51=indexedDB['open'](_0x2b386b,_0x4295a9),_0x40a94c=ge(_0x2bfb51);return _0x566d72&&_0x2bfb51['addEventListener']('upgradeneeded',_0x33ef24=>{_0x566d72(ge(_0x2bfb51['result']),_0x33ef24['oldVersion'],_0x33ef24['newVersion'],ge(_0x2bfb51['transaction']),_0x33ef24);}),_0x3878df&&_0x2bfb51['addEventListener']('blocked',_0x39d311=>_0x3878df(_0x39d311['oldVersion'],_0x39d311['newVersion'],_0x39d311)),_0x40a94c['then'](_0x1aa115=>{_0x42e9c2&&_0x1aa115['addEventListener']('close',()=>_0x42e9c2()),_0x5d050a&&_0x1aa115['addEventListener']('versionchange',_0x1ba956=>_0x5d050a(_0x1ba956['oldVersion'],_0x1ba956['newVersion'],_0x1ba956));})['catch'](()=>{}),_0x40a94c;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x1c0939,_0x5b3caf){if(!(_0x1c0939 instanceof IDBDatabase&&!(_0x5b3caf in _0x1c0939)&&typeof _0x5b3caf=='string'))return;if(si['get'](_0x5b3caf))return si['get'](_0x5b3caf);const _0x4f653e=_0x5b3caf['replace'](/FromIndex$/,''),_0x45426c=_0x5b3caf!==_0x4f653e,_0x10c7d2=zc['includes'](_0x4f653e);if(!(_0x4f653e in(_0x45426c?IDBIndex:IDBObjectStore)['prototype'])||!(_0x10c7d2||qc['includes'](_0x4f653e)))return;const _0x12e96f=async function(_0x1545db,..._0x4c11a5){const _0x2d74f5=this['transaction'](_0x1545db,_0x10c7d2?'readwrite':'readonly');let _0x436959=_0x2d74f5['store'];return _0x45426c&&(_0x436959=_0x436959['index'](_0x4c11a5['shift']())),(await Promise['all']([_0x436959[_0x4f653e](..._0x4c11a5),_0x10c7d2&&_0x2d74f5['done']]))[0x0];};return si['set'](_0x5b3caf,_0x12e96f),_0x12e96f;}Vc(_0x3d1c23=>({..._0x3d1c23,'get':(_0x4ec3d8,_0x1d0d86,_0x5b319d)=>Ms(_0x4ec3d8,_0x1d0d86)||_0x3d1c23['get'](_0x4ec3d8,_0x1d0d86,_0x5b319d),'has':(_0x5e8452,_0x2bd77a)=>!!Ms(_0x5e8452,_0x2bd77a)||_0x3d1c23['has'](_0x5e8452,_0x2bd77a)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5cb0ea){this['container']=_0x5cb0ea;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x13dbb6=>{if(Kc(_0x13dbb6)){const _0x4a86c3=_0x13dbb6['getImmediate']();return _0x4a86c3['library']+'/'+_0x4a86c3['version'];}else return null;})['filter'](_0x4b9c97=>_0x4b9c97)['join']('\x20');}}function Kc(_0x3a81a5){const _0xeaa425=_0x3a81a5['getComponent']();return(_0xeaa425==null?void 0x0:_0xeaa425['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2ad0d3,_0x54fa5a){try{_0x2ad0d3['container']['addComponent'](_0x54fa5a);}catch(_0x159f5c){oe['debug']('Component\x20'+_0x54fa5a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2ad0d3['name'],_0x159f5c);}}function st(_0x3db053){const _0x39bb56=_0x3db053['name'];if(Ei['has'](_0x39bb56))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x39bb56+'.'),!0x1;Ei['set'](_0x39bb56,_0x3db053);for(const _0x1742d9 of Ue['values']())xs(_0x1742d9,_0x3db053);for(const _0x3ebd2e of vi['values']())xs(_0x3ebd2e,_0x3db053);return!0x0;}function Hi(_0x316aaf,_0x603b6e){const _0x22da6c=_0x316aaf['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x22da6c&&_0x22da6c['triggerHeartbeat'](),_0x316aaf['container']['getProvider'](_0x603b6e);}function $(_0x4cd01f){return _0x4cd01f==null?!0x1:_0x4cd01f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x102a26,_0x2790ad,_0x5a18fa){this['_isDeleted']=!0x1,this['_options']={..._0x102a26},this['_config']={..._0x2790ad},this['_name']=_0x2790ad['name'],this['_automaticDataCollectionEnabled']=_0x2790ad['automaticDataCollectionEnabled'],this['_container']=_0x5a18fa,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x277cf6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x277cf6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x337f4b){this['_isDeleted']=_0x337f4b;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x194b1f,_0x16b193={}){let _0xfab552=_0x194b1f;typeof _0x16b193!='object'&&(_0x16b193={'name':_0x16b193});const _0x23bf3a={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x16b193},_0x594266=_0x23bf3a['name'];if(typeof _0x594266!='string'||!_0x594266)throw me['create']('bad-app-name',{'appName':String(_0x594266)});if(_0xfab552||(_0xfab552=zr()),!_0xfab552)throw me['create']('no-options');const _0x4e2b0d=Ue['get'](_0x594266);if(_0x4e2b0d){if(xe(_0xfab552,_0x4e2b0d['options'])&&xe(_0x23bf3a,_0x4e2b0d['config']))return _0x4e2b0d;throw me['create']('duplicate-app',{'appName':_0x594266});}const _0x2f40f4=new Nc(_0x594266);for(const _0x430028 of Ei['values']())_0x2f40f4['addComponent'](_0x430028);const _0x21be39=new Tl(_0xfab552,_0x23bf3a,_0x2f40f4);return Ue['set'](_0x594266,_0x21be39),_0x21be39;}function Zr(_0x37e91e=yi){const _0x52d5e8=Ue['get'](_0x37e91e);if(!_0x52d5e8&&_0x37e91e===yi&&zr())return Sl();if(!_0x52d5e8)throw me['create']('no-app',{'appName':_0x37e91e});return _0x52d5e8;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x25a3db){let _0x32f35a=!0x1;const _0x3d5422=_0x25a3db['name'];Ue['has'](_0x3d5422)?(_0x32f35a=!0x0,Ue['delete'](_0x3d5422)):vi['has'](_0x3d5422)&&_0x25a3db['decRefCount']()<=0x0&&(vi['delete'](_0x3d5422),_0x32f35a=!0x0),_0x32f35a&&(await Promise['all'](_0x25a3db['container']['getProviders']()['map'](_0x282b39=>_0x282b39['delete']())),_0x25a3db['isDeleted']=!0x0);}function ye(_0x49b0c6,_0xc63754,_0x452240){let _0x5d7180=wl[_0x49b0c6]??_0x49b0c6;_0x452240&&(_0x5d7180+='-'+_0x452240);const _0x14ea60=_0x5d7180['match'](/\s|\//),_0x4e14d3=_0xc63754['match'](/\s|\//);if(_0x14ea60||_0x4e14d3){const _0x48121b=['Unable\x20to\x20register\x20library\x20\x22'+_0x5d7180+'\x22\x20with\x20version\x20\x22'+_0xc63754+'\x22:'];_0x14ea60&&_0x48121b['push']('library\x20name\x20\x22'+_0x5d7180+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x14ea60&&_0x4e14d3&&_0x48121b['push']('and'),_0x4e14d3&&_0x48121b['push']('version\x20name\x20\x22'+_0xc63754+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x48121b['join']('\x20'));return;}st(new Fe(_0x5d7180+'-version',()=>({'library':_0x5d7180,'version':_0xc63754}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3eab64,_0x9dc060)=>{switch(_0x9dc060){case 0x0:try{_0x3eab64['createObjectStore'](Ot);}catch(_0x131873){console['warn'](_0x131873);}}}})['catch'](_0x2038da=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2038da['message']});})),ri;}async function Al(_0xbf135e){try{const _0x2ebbfc=(await eo())['transaction'](Ot),_0x1cb40a=await _0x2ebbfc['objectStore'](Ot)['get'](to(_0xbf135e));return await _0x2ebbfc['done'],_0x1cb40a;}catch(_0x2d5919){if(_0x2d5919 instanceof Re)oe['warn'](_0x2d5919['message']);else{const _0x1cd009=me['create']('idb-get',{'originalErrorMessage':_0x2d5919==null?void 0x0:_0x2d5919['message']});oe['warn'](_0x1cd009['message']);}}}async function Fs(_0x1975e1,_0x3c9da2){try{const _0x37ac6c=(await eo())['transaction'](Ot,'readwrite');await _0x37ac6c['objectStore'](Ot)['put'](_0x3c9da2,to(_0x1975e1)),await _0x37ac6c['done'];}catch(_0x20a8fc){if(_0x20a8fc instanceof Re)oe['warn'](_0x20a8fc['message']);else{const _0x517f6d=me['create']('idb-set',{'originalErrorMessage':_0x20a8fc==null?void 0x0:_0x20a8fc['message']});oe['warn'](_0x517f6d['message']);}}}function to(_0x4904b7){return _0x4904b7['name']+'!'+_0x4904b7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x131015){this['container']=_0x131015,this['_heartbeatsCache']=null;const _0xb8648e=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0xb8648e),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4ff4a6=>(this['_heartbeatsCache']=_0x4ff4a6,_0x4ff4a6));}async['triggerHeartbeat'](){var _0x20bb15,_0x2f3311;try{const _0x5ec6f8=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1ca79d=Us();if(((_0x20bb15=this['_heartbeatsCache'])==null?void 0x0:_0x20bb15['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2f3311=this['_heartbeatsCache'])==null?void 0x0:_0x2f3311['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1ca79d||this['_heartbeatsCache']['heartbeats']['some'](_0x581134=>_0x581134['date']===_0x1ca79d))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1ca79d,'agent':_0x5ec6f8}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x5da301=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5da301,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x299112){oe['warn'](_0x299112);}}async['getHeartbeatsHeader'](){var _0x22601c;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x22601c=this['_heartbeatsCache'])==null?void 0x0:_0x22601c['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x321ea4=Us(),{heartbeatsToSend:_0x36ade8,unsentEntries:_0x29c1dc}=Ol(this['_heartbeatsCache']['heartbeats']),_0xc0f96b=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x36ade8}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x321ea4,_0x29c1dc['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x29c1dc,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xc0f96b;}catch(_0x14d4ad){return oe['warn'](_0x14d4ad),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x383ed4,_0x52258f=kl){const _0x50d21a=[];let _0x387b72=_0x383ed4['slice']();for(const _0xf5ab86 of _0x383ed4){const _0x583473=_0x50d21a['find'](_0x319e40=>_0x319e40['agent']===_0xf5ab86['agent']);if(_0x583473){if(_0x583473['dates']['push'](_0xf5ab86['date']),Ws(_0x50d21a)>_0x52258f){_0x583473['dates']['pop']();break;}}else{if(_0x50d21a['push']({'agent':_0xf5ab86['agent'],'dates':[_0xf5ab86['date']]}),Ws(_0x50d21a)>_0x52258f){_0x50d21a['pop']();break;}}_0x387b72=_0x387b72['slice'](0x1);}return{'heartbeatsToSend':_0x50d21a,'unsentEntries':_0x387b72};}class Dl{constructor(_0x2d66e2){this['app']=_0x2d66e2,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2ea162=await Al(this['app']);return _0x2ea162!=null&&_0x2ea162['heartbeats']?_0x2ea162:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x162799){if(await this['_canUseIndexedDBPromise']){const _0x5e9a20=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x162799['lastSentHeartbeatDate']??_0x5e9a20['lastSentHeartbeatDate'],'heartbeats':_0x162799['heartbeats']});}else return;}async['add'](_0x10f442){if(await this['_canUseIndexedDBPromise']){const _0x2500e9=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x10f442['lastSentHeartbeatDate']??_0x2500e9['lastSentHeartbeatDate'],'heartbeats':[..._0x2500e9['heartbeats'],..._0x10f442['heartbeats']]});}else return;}}function Ws(_0x12a277){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x12a277}))['length'];}function Ml(_0x103d63){if(_0x103d63['length']===0x0)return-0x1;let _0x1e3c14=0x0,_0x3560fe=_0x103d63[0x0]['date'];for(let _0x4fd44a=0x1;_0x4fd44a<_0x103d63['length'];_0x4fd44a++)_0x103d63[_0x4fd44a]['date']<_0x3560fe&&(_0x3560fe=_0x103d63[_0x4fd44a]['date'],_0x1e3c14=_0x4fd44a);return _0x1e3c14;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x200225){st(new Fe('platform-logger',_0x105d06=>new jc(_0x105d06),'PRIVATE')),st(new Fe('heartbeat',_0x5c9fcf=>new Nl(_0x5c9fcf),'PRIVATE')),ye(mi,Ls,_0x200225),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x31ed05){no=_0x31ed05;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x286150){this['domStorage_']=_0x286150,this['prefix_']='firebase:';}['set'](_0x499fbe,_0x8ee5e6){_0x8ee5e6==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x499fbe)):this['domStorage_']['setItem'](this['prefixedName_'](_0x499fbe),O(_0x8ee5e6));}['get'](_0x3df31f){const _0x59674d=this['domStorage_']['getItem'](this['prefixedName_'](_0x3df31f));return _0x59674d==null?null:Nt(_0x59674d);}['remove'](_0x5cf4a8){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5cf4a8));}['prefixedName_'](_0x5992ed){return this['prefix_']+_0x5992ed;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4f36bd,_0xb65ef6){_0xb65ef6==null?delete this['cache_'][_0x4f36bd]:this['cache_'][_0x4f36bd]=_0xb65ef6;}['get'](_0x4b3a5d){return Q(this['cache_'],_0x4b3a5d)?this['cache_'][_0x4b3a5d]:null;}['remove'](_0x396fad){delete this['cache_'][_0x396fad];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x5ed53d){try{if(typeof window<'u'&&typeof window[_0x5ed53d]<'u'){const _0x408ed5=window[_0x5ed53d];return _0x408ed5['setItem']('firebase:sentinel','cache'),_0x408ed5['removeItem']('firebase:sentinel'),new Wl(_0x408ed5);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4edfdd=0x1;return function(){return _0x4edfdd++;};}()),ro=function(_0x1fcf2c){const _0x1b72ee=Rc(_0x1fcf2c),_0x29944f=new Cc();_0x29944f['update'](_0x1b72ee);const _0xc83835=_0x29944f['digest']();return Fi['encodeByteArray'](_0xc83835);},zt=function(..._0x1e7bad){let _0x321033='';for(let _0x3046ae=0x0;_0x3046ae<_0x1e7bad['length'];_0x3046ae++){const _0x3e1069=_0x1e7bad[_0x3046ae];Array['isArray'](_0x3e1069)||_0x3e1069&&typeof _0x3e1069=='object'&&typeof _0x3e1069['length']=='number'?_0x321033+=zt['apply'](null,_0x3e1069):typeof _0x3e1069=='object'?_0x321033+=O(_0x3e1069):_0x321033+=_0x3e1069,_0x321033+='\x20';}return _0x321033;};let St=null,$s=!0x0;const Hl=function(_0x3352ee,_0x4c5641){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x1fa958){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x4c27f7=zt['apply'](null,_0x1fa958);St(_0x4c27f7);}},jt=function(_0x33c938){return function(..._0x205344){L(_0x33c938,..._0x205344);};},Ii=function(..._0x5956c0){const _0x50da19='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x5956c0);Ze['error'](_0x50da19);},ae=function(..._0x4ce85f){const _0x4765d2='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x4ce85f);throw Ze['error'](_0x4765d2),new Error(_0x4765d2);},U=function(..._0x53e799){const _0x4cdbf1='FIREBASE\x20WARNING:\x20'+zt(..._0x53e799);Ze['warn'](_0x4cdbf1);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x58f5ad){return typeof _0x58f5ad=='number'&&(_0x58f5ad!==_0x58f5ad||_0x58f5ad===Number['POSITIVE_INFINITY']||_0x58f5ad===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4ea7c8){if(document['readyState']==='complete')_0x4ea7c8();else{let _0x35bf16=!0x1;const _0x2763f6=function(){if(!document['body']){setTimeout(_0x2763f6,Math['floor'](0xa));return;}_0x35bf16||(_0x35bf16=!0x0,_0x4ea7c8());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2763f6,!0x1),window['addEventListener']('load',_0x2763f6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2763f6();}),window['attachEvent']('onload',_0x2763f6));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x568517,_0x1ddc29){if(_0x568517===_0x1ddc29)return 0x0;if(_0x568517===We||_0x1ddc29===we)return-0x1;if(_0x1ddc29===We||_0x568517===we)return 0x1;{const _0x36fbe5=Gs(_0x568517),_0x53b5bb=Gs(_0x1ddc29);return _0x36fbe5!==null?_0x53b5bb!==null?_0x36fbe5-_0x53b5bb===0x0?_0x568517['length']-_0x1ddc29['length']:_0x36fbe5-_0x53b5bb:-0x1:_0x53b5bb!==null?0x1:_0x568517<_0x1ddc29?-0x1:0x1;}},ql=function(_0x1b2cb9,_0x4871ac){return _0x1b2cb9===_0x4871ac?0x0:_0x1b2cb9<_0x4871ac?-0x1:0x1;},vt=function(_0x100d78,_0x113bfe){if(_0x113bfe&&_0x100d78 in _0x113bfe)return _0x113bfe[_0x100d78];throw new Error('Missing\x20required\x20key\x20('+_0x100d78+')\x20in\x20object:\x20'+O(_0x113bfe));},$i=function(_0x3af039){if(typeof _0x3af039!='object'||_0x3af039===null)return O(_0x3af039);const _0x3cd7cd=[];for(const _0x51c53f in _0x3af039)_0x3cd7cd['push'](_0x51c53f);_0x3cd7cd['sort']();let _0x5eb773='{';for(let _0x2bbbab=0x0;_0x2bbbab<_0x3cd7cd['length'];_0x2bbbab++)_0x2bbbab!==0x0&&(_0x5eb773+=','),_0x5eb773+=O(_0x3cd7cd[_0x2bbbab]),_0x5eb773+=':',_0x5eb773+=$i(_0x3af039[_0x3cd7cd[_0x2bbbab]]);return _0x5eb773+='}',_0x5eb773;},oo=function(_0x16b377,_0x575aa1){const _0x2b341c=_0x16b377['length'];if(_0x2b341c<=_0x575aa1)return[_0x16b377];const _0x3b6d1c=[];for(let _0xe8bb9b=0x0;_0xe8bb9b<_0x2b341c;_0xe8bb9b+=_0x575aa1)_0xe8bb9b+_0x575aa1>_0x2b341c?_0x3b6d1c['push'](_0x16b377['substring'](_0xe8bb9b,_0x2b341c)):_0x3b6d1c['push'](_0x16b377['substring'](_0xe8bb9b,_0xe8bb9b+_0x575aa1));return _0x3b6d1c;};function x(_0x38094d,_0x1c82c4){for(const _0x1a01b5 in _0x38094d)_0x38094d['hasOwnProperty'](_0x1a01b5)&&_0x1c82c4(_0x1a01b5,_0x38094d[_0x1a01b5]);}const ao=function(_0x3ff86b){f(!xn(_0x3ff86b),'Invalid\x20JSON\x20number');const _0x124575=0xb,_0x2a4809=0x34,_0xadb4a2=(0x1<<_0x124575-0x1)-0x1;let _0x2114ab,_0x5b507b,_0x108675,_0x2c5bc3,_0x377d3d;_0x3ff86b===0x0?(_0x5b507b=0x0,_0x108675=0x0,_0x2114ab=0x1/_0x3ff86b===-0x1/0x0?0x1:0x0):(_0x2114ab=_0x3ff86b<0x0,_0x3ff86b=Math['abs'](_0x3ff86b),_0x3ff86b>=Math['pow'](0x2,0x1-_0xadb4a2)?(_0x2c5bc3=Math['min'](Math['floor'](Math['log'](_0x3ff86b)/Math['LN2']),_0xadb4a2),_0x5b507b=_0x2c5bc3+_0xadb4a2,_0x108675=Math['round'](_0x3ff86b*Math['pow'](0x2,_0x2a4809-_0x2c5bc3)-Math['pow'](0x2,_0x2a4809))):(_0x5b507b=0x0,_0x108675=Math['round'](_0x3ff86b/Math['pow'](0x2,0x1-_0xadb4a2-_0x2a4809))));const _0x20004a=[];for(_0x377d3d=_0x2a4809;_0x377d3d;_0x377d3d-=0x1)_0x20004a['push'](_0x108675%0x2?0x1:0x0),_0x108675=Math['floor'](_0x108675/0x2);for(_0x377d3d=_0x124575;_0x377d3d;_0x377d3d-=0x1)_0x20004a['push'](_0x5b507b%0x2?0x1:0x0),_0x5b507b=Math['floor'](_0x5b507b/0x2);_0x20004a['push'](_0x2114ab?0x1:0x0),_0x20004a['reverse']();const _0x2c7d92=_0x20004a['join']('');let _0xe46fd2='';for(_0x377d3d=0x0;_0x377d3d<0x40;_0x377d3d+=0x8){let _0x1e6a0e=parseInt(_0x2c7d92['substr'](_0x377d3d,0x8),0x2)['toString'](0x10);_0x1e6a0e['length']===0x1&&(_0x1e6a0e='0'+_0x1e6a0e),_0xe46fd2=_0xe46fd2+_0x1e6a0e;}return _0xe46fd2['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x13659c,_0x205b3b){let _0x37e5b9='Unknown\x20Error';_0x13659c==='too_big'?_0x37e5b9='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x13659c==='permission_denied'?_0x37e5b9='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x13659c==='unavailable'&&(_0x37e5b9='The\x20service\x20is\x20unavailable');const _0x28e199=new Error(_0x13659c+'\x20at\x20'+_0x205b3b['_path']['toString']()+':\x20'+_0x37e5b9);return _0x28e199['code']=_0x13659c['toUpperCase'](),_0x28e199;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x56e31f){if(Yl['test'](_0x56e31f)){const _0x4e8022=Number(_0x56e31f);if(_0x4e8022>=Ql&&_0x4e8022<=Jl)return _0x4e8022;}return null;},ft=function(_0x17edd7){try{_0x17edd7();}catch(_0x48f231){setTimeout(()=>{const _0x154a5a=_0x48f231['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x154a5a),_0x48f231;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x50ba54,_0x34dd43){const _0x596ed3=setTimeout(_0x50ba54,_0x34dd43);return typeof _0x596ed3=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x596ed3):typeof _0x596ed3=='object'&&_0x596ed3['unref']&&_0x596ed3['unref'](),_0x596ed3;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0xd5e461,_0x4aad4e){this['appCheckProvider']=_0x4aad4e,this['appName']=_0xd5e461['name'],$(_0xd5e461)&&_0xd5e461['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xd5e461['settings']['appCheckToken']),this['appCheck']=_0x4aad4e==null?void 0x0:_0x4aad4e['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4aad4e==null||_0x4aad4e['get']()['then'](_0xbbbd3c=>this['appCheck']=_0xbbbd3c);}['getToken'](_0x593109){if(this['serverAppAppCheckToken']){if(_0x593109)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x593109):new Promise((_0x3f7454,_0x5e21bb)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x593109)['then'](_0x3f7454,_0x5e21bb):_0x3f7454(null);},0x0);});}['addTokenChangeListener'](_0x53cba9){var _0x21c864;(_0x21c864=this['appCheckProvider'])==null||_0x21c864['get']()['then'](_0x3b7908=>_0x3b7908['addTokenListener'](_0x53cba9));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x57a517,_0x562859,_0x3668b9){this['appName_']=_0x57a517,this['firebaseOptions_']=_0x562859,this['authProvider_']=_0x3668b9,this['auth_']=null,this['auth_']=_0x3668b9['getImmediate']({'optional':!0x0}),this['auth_']||_0x3668b9['onInit'](_0x16a450=>this['auth_']=_0x16a450);}['getToken'](_0x47d3bb){return this['auth_']?this['auth_']['getToken'](_0x47d3bb)['catch'](_0x33cd6e=>_0x33cd6e&&_0x33cd6e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x33cd6e)):new Promise((_0x57df08,_0xd3b081)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x47d3bb)['then'](_0x57df08,_0xd3b081):_0x57df08(null);},0x0);});}['addTokenChangeListener'](_0x11dcd1){this['auth_']?this['auth_']['addAuthTokenListener'](_0x11dcd1):this['authProvider_']['get']()['then'](_0x288108=>_0x288108['addAuthTokenListener'](_0x11dcd1));}['removeTokenChangeListener'](_0x524f71){this['authProvider_']['get']()['then'](_0x1f1c05=>_0x1f1c05['removeAuthTokenListener'](_0x524f71));}['notifyForInvalidToken'](){let _0x4b3d1f='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4b3d1f+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4b3d1f+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4b3d1f+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4b3d1f);}}class an{constructor(_0x32656d){this['accessToken']=_0x32656d;}['getToken'](_0x5b7aee){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4696a3){_0x4696a3(this['accessToken']);}['removeTokenChangeListener'](_0x32836d){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5b03b3,_0x461821,_0x5f151a,_0x2c2b51,_0x12995c=!0x1,_0x2c96de='',_0x5c2e3d=!0x1,_0xd0e3fd=!0x1,_0x554a9e=null){this['secure']=_0x461821,this['namespace']=_0x5f151a,this['webSocketOnly']=_0x2c2b51,this['nodeAdmin']=_0x12995c,this['persistenceKey']=_0x2c96de,this['includeNamespaceInQueryParams']=_0x5c2e3d,this['isUsingEmulator']=_0xd0e3fd,this['emulatorOptions']=_0x554a9e,this['_host']=_0x5b03b3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x5b03b3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1ac767){_0x1ac767!==this['internalHost']&&(this['internalHost']=_0x1ac767,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x39dd91=this['toURLString']();return this['persistenceKey']&&(_0x39dd91+='<'+this['persistenceKey']+'>'),_0x39dd91;}['toURLString'](){const _0x289c52=this['secure']?'https://':'http://',_0x4a0ee5=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x289c52+this['host']+'/'+_0x4a0ee5;}}function th(_0x140c6c){return _0x140c6c['host']!==_0x140c6c['internalHost']||_0x140c6c['isCustomHost']()||_0x140c6c['includeNamespaceInQueryParams'];}function vo(_0x10f774,_0x2412a4,_0x4e5718){f(typeof _0x2412a4=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4e5718=='object','typeof\x20params\x20must\x20==\x20object');let _0x5d821a;if(_0x2412a4===go)_0x5d821a=(_0x10f774['secure']?'wss://':'ws://')+_0x10f774['internalHost']+'/.ws?';else{if(_0x2412a4===mo)_0x5d821a=(_0x10f774['secure']?'https://':'http://')+_0x10f774['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2412a4);}th(_0x10f774)&&(_0x4e5718['ns']=_0x10f774['namespace']);const _0x47a0f1=[];return x(_0x4e5718,(_0x215b04,_0x5b1a02)=>{_0x47a0f1['push'](_0x215b04+'='+_0x5b1a02);}),_0x5d821a+_0x47a0f1['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x19faf1,_0x4fee58=0x1){Q(this['counters_'],_0x19faf1)||(this['counters_'][_0x19faf1]=0x0),this['counters_'][_0x19faf1]+=_0x4fee58;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x51c3b4){const _0x165a2f=_0x51c3b4['toString']();return oi[_0x165a2f]||(oi[_0x165a2f]=new nh()),oi[_0x165a2f];}function ih(_0x2ec9b2,_0x22a949){const _0xeaeac4=_0x2ec9b2['toString']();return ai[_0xeaeac4]||(ai[_0xeaeac4]=_0x22a949()),ai[_0xeaeac4];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x30b482){this['onMessage_']=_0x30b482,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x37a00d,_0x3b2911){this['closeAfterResponse']=_0x37a00d,this['onClose']=_0x3b2911,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x458462,_0x453086){for(this['pendingResponses'][_0x458462]=_0x453086;this['pendingResponses'][this['currentResponseNum']];){const _0x10e0f7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1ffe15=0x0;_0x1ffe15<_0x10e0f7['length'];++_0x1ffe15)_0x10e0f7[_0x1ffe15]&&ft(()=>{this['onMessage_'](_0x10e0f7[_0x1ffe15]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x74b727,_0x939b7f,_0x40190f,_0x3afba4,_0x19c82c,_0x1dbd83,_0x2ff9dc){this['connId']=_0x74b727,this['repoInfo']=_0x939b7f,this['applicationId']=_0x40190f,this['appCheckToken']=_0x3afba4,this['authToken']=_0x19c82c,this['transportSessionId']=_0x1dbd83,this['lastSessionId']=_0x2ff9dc,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x74b727),this['stats_']=qi(_0x939b7f),this['urlFn']=_0x26ee91=>(this['appCheckToken']&&(_0x26ee91[wi]=this['appCheckToken']),vo(_0x939b7f,mo,_0x26ee91));}['open'](_0x1ad57e,_0x24ffc2){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x24ffc2,this['myPacketOrderer']=new sh(_0x1ad57e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0xba37ba)=>{const [_0x3ebf15,_0x57eb3b,_0x349a1a,_0x3e1f3c,_0x579200]=_0xba37ba;if(this['incrementIncomingBytes_'](_0xba37ba),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3ebf15===qs)this['id']=_0x57eb3b,this['password']=_0x349a1a;else{if(_0x3ebf15===rh)_0x57eb3b?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x57eb3b,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3ebf15);}}},(..._0x4340c2)=>{const [_0x32d79b,_0x43d45b]=_0x4340c2;this['incrementIncomingBytes_'](_0x4340c2),this['myPacketOrderer']['handleResponse'](_0x32d79b,_0x43d45b);},()=>{this['onClosed_']();},this['urlFn']);const _0x52862c={};_0x52862c[qs]='t',_0x52862c[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x52862c[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x52862c[co]=Gi,this['transportSessionId']&&(_0x52862c[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x52862c[po]=this['lastSessionId']),this['applicationId']&&(_0x52862c[_o]=this['applicationId']),this['appCheckToken']&&(_0x52862c[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x52862c[ho]=uo);const _0x481010=this['urlFn'](_0x52862c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x481010),this['scriptTagHolder']['addTag'](_0x481010,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5dac63){const _0x4650cf=O(_0x5dac63);this['bytesSent']+=_0x4650cf['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4650cf['length']);const _0x2fa726=$r(_0x4650cf),_0x3b83dc=oo(_0x2fa726,fh);for(let _0xe516b0=0x0;_0xe516b0<_0x3b83dc['length'];_0xe516b0++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b83dc['length'],_0x3b83dc[_0xe516b0]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x63e1bd,_0xb45994){this['myDisconnFrame']=document['createElement']('iframe');const _0x405e05={};_0x405e05[dh]='t',_0x405e05[Eo]=_0x63e1bd,_0x405e05[Io]=_0xb45994,this['myDisconnFrame']['src']=this['urlFn'](_0x405e05),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x59e4eb){const _0xac44a7=O(_0x59e4eb)['length'];this['bytesReceived']+=_0xac44a7,this['stats_']['incrementCounter']('bytes_received',_0xac44a7);}}class zi{constructor(_0xa4d331,_0x2d9402,_0x27b8e0,_0x3ebbaa){this['onDisconnect']=_0x27b8e0,this['urlFn']=_0x3ebbaa,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xa4d331,window[ah+this['uniqueCallbackIdentifier']]=_0x2d9402,this['myIFrame']=zi['createIFrame_']();let _0x363a6a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x363a6a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x337560='<html><body>'+_0x363a6a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x337560),this['myIFrame']['doc']['close']();}catch(_0x1790a0){L('frame\x20writing\x20exception'),_0x1790a0['stack']&&L(_0x1790a0['stack']),L(_0x1790a0);}}}static['createIFrame_'](){const _0xd3075a=document['createElement']('iframe');if(_0xd3075a['style']['display']='none',document['body']){document['body']['appendChild'](_0xd3075a);try{_0xd3075a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x7b7c20=document['domain'];_0xd3075a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x7b7c20+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xd3075a['contentDocument']?_0xd3075a['doc']=_0xd3075a['contentDocument']:_0xd3075a['contentWindow']?_0xd3075a['doc']=_0xd3075a['contentWindow']['document']:_0xd3075a['document']&&(_0xd3075a['doc']=_0xd3075a['document']),_0xd3075a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2b0196=this['onDisconnect'];_0x2b0196&&(this['onDisconnect']=null,_0x2b0196());}['startLongPoll'](_0xd6dba6,_0x4e693a){for(this['myID']=_0xd6dba6,this['myPW']=_0x4e693a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x551d4c={};_0x551d4c[Eo]=this['myID'],_0x551d4c[Io]=this['myPW'],_0x551d4c[wo]=this['currentSerial'];let _0x85e5f=this['urlFn'](_0x551d4c),_0x4e51cb='',_0x506861=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4e51cb['length']<=Co;){const _0x312978=this['pendingSegs']['shift']();_0x4e51cb=_0x4e51cb+'&'+lh+_0x506861+'='+_0x312978['seg']+'&'+hh+_0x506861+'='+_0x312978['ts']+'&'+uh+_0x506861+'='+_0x312978['d'],_0x506861++;}return _0x85e5f=_0x85e5f+_0x4e51cb,this['addLongPollTag_'](_0x85e5f,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5c6f4e,_0x282eb2,_0x7a9e2f){this['pendingSegs']['push']({'seg':_0x5c6f4e,'ts':_0x282eb2,'d':_0x7a9e2f}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4a9794,_0x1f272f){this['outstandingRequests']['add'](_0x1f272f);const _0xf13c7c=()=>{this['outstandingRequests']['delete'](_0x1f272f),this['newRequest_']();},_0x29a2f1=setTimeout(_0xf13c7c,Math['floor'](ph)),_0x2c9d12=()=>{clearTimeout(_0x29a2f1),_0xf13c7c();};this['addTag'](_0x4a9794,_0x2c9d12);}['addTag'](_0x24baab,_0x7738e5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xb2ef6e=this['myIFrame']['doc']['createElement']('script');_0xb2ef6e['type']='text/javascript',_0xb2ef6e['async']=!0x0,_0xb2ef6e['src']=_0x24baab,_0xb2ef6e['onload']=_0xb2ef6e['onreadystatechange']=function(){const _0x50147c=_0xb2ef6e['readyState'];(!_0x50147c||_0x50147c==='loaded'||_0x50147c==='complete')&&(_0xb2ef6e['onload']=_0xb2ef6e['onreadystatechange']=null,_0xb2ef6e['parentNode']&&_0xb2ef6e['parentNode']['removeChild'](_0xb2ef6e),_0x7738e5());},_0xb2ef6e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x24baab),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xb2ef6e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x758244,_0x2bf6ce,_0x49a098,_0x2d5733,_0xc66139,_0x3ac6df,_0x4c9da0){this['connId']=_0x758244,this['applicationId']=_0x49a098,this['appCheckToken']=_0x2d5733,this['authToken']=_0xc66139,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x2bf6ce),this['connURL']=q['connectionURL_'](_0x2bf6ce,_0x3ac6df,_0x4c9da0,_0x2d5733,_0x49a098),this['nodeAdmin']=_0x2bf6ce['nodeAdmin'];}static['connectionURL_'](_0x4cb55f,_0x5620ca,_0x14bd8b,_0x3da6bd,_0x4806dd){const _0x465561={};return _0x465561[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x465561[ho]=uo),_0x5620ca&&(_0x465561[lo]=_0x5620ca),_0x14bd8b&&(_0x465561[po]=_0x14bd8b),_0x3da6bd&&(_0x465561[wi]=_0x3da6bd),_0x4806dd&&(_0x465561[_o]=_0x4806dd),vo(_0x4cb55f,go,_0x465561);}['open'](_0x47b427,_0xf98e2e){this['onDisconnect']=_0xf98e2e,this['onMessage']=_0x47b427,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x8049c7;_c(),this['mySock']=new gn(this['connURL'],[],_0x8049c7);}catch(_0x6f81d7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x450650=_0x6f81d7['message']||_0x6f81d7['data'];_0x450650&&this['log_'](_0x450650),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x318067=>{this['handleIncomingFrame'](_0x318067);},this['mySock']['onerror']=_0x30e834=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x41579e=_0x30e834['message']||_0x30e834['data'];_0x41579e&&this['log_'](_0x41579e),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x52259f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1d3e5f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2f0a67=navigator['userAgent']['match'](_0x1d3e5f);_0x2f0a67&&_0x2f0a67['length']>0x1&&parseFloat(_0x2f0a67[0x1])<4.4&&(_0x52259f=!0x0);}return!_0x52259f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x275d29){if(this['frames']['push'](_0x275d29),this['frames']['length']===this['totalFrames']){const _0x5b041d=this['frames']['join']('');this['frames']=null;const _0xb341e=Nt(_0x5b041d);this['onMessage'](_0xb341e);}}['handleNewFrameCount_'](_0x1d761f){this['totalFrames']=_0x1d761f,this['frames']=[];}['extractFrameCount_'](_0x5ae049){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5ae049['length']<=0x6){const _0xb633d0=Number(_0x5ae049);if(!isNaN(_0xb633d0))return this['handleNewFrameCount_'](_0xb633d0),null;}return this['handleNewFrameCount_'](0x1),_0x5ae049;}['handleIncomingFrame'](_0x154288){if(this['mySock']===null)return;const _0x1d3c51=_0x154288['data'];if(this['bytesReceived']+=_0x1d3c51['length'],this['stats_']['incrementCounter']('bytes_received',_0x1d3c51['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1d3c51);else{const _0x3a00eb=this['extractFrameCount_'](_0x1d3c51);_0x3a00eb!==null&&this['appendFrame_'](_0x3a00eb);}}['send'](_0x92a804){this['resetKeepAlive']();const _0x125ce1=O(_0x92a804);this['bytesSent']+=_0x125ce1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x125ce1['length']);const _0x22aa6c=oo(_0x125ce1,gh);_0x22aa6c['length']>0x1&&this['sendString_'](String(_0x22aa6c['length']));for(let _0x550917=0x0;_0x550917<_0x22aa6c['length'];_0x550917++)this['sendString_'](_0x22aa6c[_0x550917]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4a1ed5){try{this['mySock']['send'](_0x4a1ed5);}catch(_0x227686){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x227686['message']||_0x227686['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3cfd80){this['initTransports_'](_0x3cfd80);}['initTransports_'](_0x2116d1){const _0x48b375=q&&q['isAvailable']();let _0x238d21=_0x48b375&&!q['previouslyFailed']();if(_0x2116d1['webSocketOnly']&&(_0x48b375||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x238d21=!0x0),_0x238d21)this['transports_']=[q];else{const _0x340ea2=this['transports_']=[];for(const _0x304754 of Dt['ALL_TRANSPORTS'])_0x304754&&_0x304754['isAvailable']()&&_0x340ea2['push'](_0x304754);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4c5ca5,_0x205a42,_0x4dc44d,_0x46ca15,_0x462244,_0x4605ca,_0x237179,_0x3ab5f3,_0xfe3625,_0x3fd52f){this['id']=_0x4c5ca5,this['repoInfo_']=_0x205a42,this['applicationId_']=_0x4dc44d,this['appCheckToken_']=_0x46ca15,this['authToken_']=_0x462244,this['onMessage_']=_0x4605ca,this['onReady_']=_0x237179,this['onDisconnect_']=_0x3ab5f3,this['onKill_']=_0xfe3625,this['lastSessionId']=_0x3fd52f,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x205a42),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x21b681=this['transportManager_']['initialTransport']();this['conn_']=new _0x21b681(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x21b681['responsesRequiredToBeHealthy']||0x0;const _0x340405=this['connReceiver_'](this['conn_']),_0x57a4e5=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x340405,_0x57a4e5);},Math['floor'](0x0));const _0x454af1=_0x21b681['healthyTimeout']||0x0;_0x454af1>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x454af1)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xab392){return _0x4de4d6=>{_0xab392===this['conn_']?this['onConnectionLost_'](_0x4de4d6):_0xab392===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x139c0d){return _0x410554=>{this['state_']!==0x2&&(_0x139c0d===this['rx_']?this['onPrimaryMessageReceived_'](_0x410554):_0x139c0d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x410554):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x104fa4){const _0x4c756c={'t':'d','d':_0x104fa4};this['sendData_'](_0x4c756c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x877e71){if(ci in _0x877e71){const _0x3dc76=_0x877e71[ci];_0x3dc76===Ys?this['upgradeIfSecondaryHealthy_']():_0x3dc76===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3dc76===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3e1726){const _0xb9db44=vt('t',_0x3e1726),_0xac3c55=vt('d',_0x3e1726);if(_0xb9db44==='c')this['onSecondaryControl_'](_0xac3c55);else{if(_0xb9db44==='d')this['pendingDataMessages']['push'](_0xac3c55);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xb9db44);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3301a5){const _0x4465ce=vt('t',_0x3301a5),_0x14b29b=vt('d',_0x3301a5);_0x4465ce==='c'?this['onControl_'](_0x14b29b):_0x4465ce==='d'&&this['onDataMessage_'](_0x14b29b);}['onDataMessage_'](_0x3016f8){this['onPrimaryResponse_'](),this['onMessage_'](_0x3016f8);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x574479){const _0xa93ff0=vt(ci,_0x574479);if(zs in _0x574479){const _0x1967d4=_0x574479[zs];if(_0xa93ff0===Th){const _0xaba992={..._0x1967d4};this['repoInfo_']['isUsingEmulator']&&(_0xaba992['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xaba992);}else{if(_0xa93ff0===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x146ebf=0x0;_0x146ebf<this['pendingDataMessages']['length'];++_0x146ebf)this['onDataMessage_'](this['pendingDataMessages'][_0x146ebf]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xa93ff0===wh?this['onConnectionShutdown_'](_0x1967d4):_0xa93ff0===js?this['onReset_'](_0x1967d4):_0xa93ff0===Ch?Ii('Server\x20Error:\x20'+_0x1967d4):_0xa93ff0===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xa93ff0);}}}['onHandshake_'](_0xd37f82){const _0x13530e=_0xd37f82['ts'],_0x30657b=_0xd37f82['v'],_0x34b10a=_0xd37f82['h'];this['sessionId']=_0xd37f82['s'],this['repoInfo_']['host']=_0x34b10a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x13530e),Gi!==_0x30657b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x38712a=this['transportManager_']['upgradeTransport']();_0x38712a&&this['startUpgrade_'](_0x38712a);}['startUpgrade_'](_0x39470d){this['secondaryConn_']=new _0x39470d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x39470d['responsesRequiredToBeHealthy']||0x0;const _0x17710d=this['connReceiver_'](this['secondaryConn_']),_0x3f635d=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x17710d,_0x3f635d),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x2d4366){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2d4366),this['repoInfo_']['host']=_0x2d4366,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x487bb7,_0x43a946){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x487bb7,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x43a946,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x20aa0a=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x20aa0a||this['rx_']===_0x20aa0a)&&this['close']();}['onConnectionLost_'](_0x583e0c){this['conn_']=null,!_0x583e0c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2f6e33){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2f6e33),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4fb5ea){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4fb5ea);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x500242,_0x2fdd12,_0x8f3b62,_0x1e75ca){}['merge'](_0x2cdcb1,_0x2636af,_0x28f554,_0x264234){}['refreshAuthToken'](_0x4f9191){}['refreshAppCheckToken'](_0x4c2c69){}['onDisconnectPut'](_0x5a1688,_0x120d11,_0x808877){}['onDisconnectMerge'](_0x5ec05e,_0x1662d0,_0x52e5d4){}['onDisconnectCancel'](_0x2e37ff,_0x144748){}['reportStats'](_0x5a9034){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2ac827){this['allowedEvents_']=_0x2ac827,this['listeners_']={},f(Array['isArray'](_0x2ac827)&&_0x2ac827['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x55fd53,..._0x40f6bf){if(Array['isArray'](this['listeners_'][_0x55fd53])){const _0x2b7a64=[...this['listeners_'][_0x55fd53]];for(let _0x2f5433=0x0;_0x2f5433<_0x2b7a64['length'];_0x2f5433++)_0x2b7a64[_0x2f5433]['callback']['apply'](_0x2b7a64[_0x2f5433]['context'],_0x40f6bf);}}['on'](_0xbb2cf4,_0x2057a7,_0x546f4d){this['validateEventType_'](_0xbb2cf4),this['listeners_'][_0xbb2cf4]=this['listeners_'][_0xbb2cf4]||[],this['listeners_'][_0xbb2cf4]['push']({'callback':_0x2057a7,'context':_0x546f4d});const _0x4577da=this['getInitialEvent'](_0xbb2cf4);_0x4577da&&_0x2057a7['apply'](_0x546f4d,_0x4577da);}['off'](_0x560018,_0x466c33,_0x252307){this['validateEventType_'](_0x560018);const _0x15cb09=this['listeners_'][_0x560018]||[];for(let _0x237565=0x0;_0x237565<_0x15cb09['length'];_0x237565++)if(_0x15cb09[_0x237565]['callback']===_0x466c33&&(!_0x252307||_0x252307===_0x15cb09[_0x237565]['context'])){_0x15cb09['splice'](_0x237565,0x1);return;}}['validateEventType_'](_0x477c76){f(this['allowedEvents_']['find'](_0x21ee5b=>_0x21ee5b===_0x477c76),'Unknown\x20event:\x20'+_0x477c76);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x146ce8){return f(_0x146ce8==='online','Unknown\x20event\x20type:\x20'+_0x146ce8),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x531ce7,_0x460ab1){if(_0x460ab1===void 0x0){this['pieces_']=_0x531ce7['split']('/');let _0x53bbd9=0x0;for(let _0x56ae89=0x0;_0x56ae89<this['pieces_']['length'];_0x56ae89++)this['pieces_'][_0x56ae89]['length']>0x0&&(this['pieces_'][_0x53bbd9]=this['pieces_'][_0x56ae89],_0x53bbd9++);this['pieces_']['length']=_0x53bbd9,this['pieceNum_']=0x0;}else this['pieces_']=_0x531ce7,this['pieceNum_']=_0x460ab1;}['toString'](){let _0x401bee='';for(let _0x2f05fd=this['pieceNum_'];_0x2f05fd<this['pieces_']['length'];_0x2f05fd++)this['pieces_'][_0x2f05fd]!==''&&(_0x401bee+='/'+this['pieces_'][_0x2f05fd]);return _0x401bee||'/';}}function w(){return new C('');}function y(_0x2ac686){return _0x2ac686['pieceNum_']>=_0x2ac686['pieces_']['length']?null:_0x2ac686['pieces_'][_0x2ac686['pieceNum_']];}function Ce(_0x384424){return _0x384424['pieces_']['length']-_0x384424['pieceNum_'];}function S(_0x2b2a41){let _0x512e20=_0x2b2a41['pieceNum_'];return _0x512e20<_0x2b2a41['pieces_']['length']&&_0x512e20++,new C(_0x2b2a41['pieces_'],_0x512e20);}function ji(_0xda5b27){return _0xda5b27['pieceNum_']<_0xda5b27['pieces_']['length']?_0xda5b27['pieces_'][_0xda5b27['pieces_']['length']-0x1]:null;}function bh(_0x2e0e38){let _0x3f9474='';for(let _0x5e1a9a=_0x2e0e38['pieceNum_'];_0x5e1a9a<_0x2e0e38['pieces_']['length'];_0x5e1a9a++)_0x2e0e38['pieces_'][_0x5e1a9a]!==''&&(_0x3f9474+='/'+encodeURIComponent(String(_0x2e0e38['pieces_'][_0x5e1a9a])));return _0x3f9474||'/';}function Mt(_0x2df30d,_0x25fbc0=0x0){return _0x2df30d['pieces_']['slice'](_0x2df30d['pieceNum_']+_0x25fbc0);}function Ro(_0x3f7f3c){if(_0x3f7f3c['pieceNum_']>=_0x3f7f3c['pieces_']['length'])return null;const _0x17ebdc=[];for(let _0x96bcb3=_0x3f7f3c['pieceNum_'];_0x96bcb3<_0x3f7f3c['pieces_']['length']-0x1;_0x96bcb3++)_0x17ebdc['push'](_0x3f7f3c['pieces_'][_0x96bcb3]);return new C(_0x17ebdc,0x0);}function k(_0x495daf,_0x4a0432){const _0x1a8a39=[];for(let _0x4ba1fe=_0x495daf['pieceNum_'];_0x4ba1fe<_0x495daf['pieces_']['length'];_0x4ba1fe++)_0x1a8a39['push'](_0x495daf['pieces_'][_0x4ba1fe]);if(_0x4a0432 instanceof C){for(let _0x3d8b6c=_0x4a0432['pieceNum_'];_0x3d8b6c<_0x4a0432['pieces_']['length'];_0x3d8b6c++)_0x1a8a39['push'](_0x4a0432['pieces_'][_0x3d8b6c]);}else{const _0x106915=_0x4a0432['split']('/');for(let _0x19040b=0x0;_0x19040b<_0x106915['length'];_0x19040b++)_0x106915[_0x19040b]['length']>0x0&&_0x1a8a39['push'](_0x106915[_0x19040b]);}return new C(_0x1a8a39,0x0);}function v(_0x5346bc){return _0x5346bc['pieceNum_']>=_0x5346bc['pieces_']['length'];}function F(_0x1959b7,_0x494288){const _0x39d4a2=y(_0x1959b7),_0x553e97=y(_0x494288);if(_0x39d4a2===null)return _0x494288;if(_0x39d4a2===_0x553e97)return F(S(_0x1959b7),S(_0x494288));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x494288+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1959b7+')');}function Rh(_0x5e2b1d,_0x4b6c71){const _0x20f884=Mt(_0x5e2b1d,0x0),_0x376c2a=Mt(_0x4b6c71,0x0);for(let _0x5e07e1=0x0;_0x5e07e1<_0x20f884['length']&&_0x5e07e1<_0x376c2a['length'];_0x5e07e1++){const _0x24d7ef=qe(_0x20f884[_0x5e07e1],_0x376c2a[_0x5e07e1]);if(_0x24d7ef!==0x0)return _0x24d7ef;}return _0x20f884['length']===_0x376c2a['length']?0x0:_0x20f884['length']<_0x376c2a['length']?-0x1:0x1;}function Ki(_0x2c17c0,_0x3f9aaf){if(Ce(_0x2c17c0)!==Ce(_0x3f9aaf))return!0x1;for(let _0x3e3479=_0x2c17c0['pieceNum_'],_0x5ea24c=_0x3f9aaf['pieceNum_'];_0x3e3479<=_0x2c17c0['pieces_']['length'];_0x3e3479++,_0x5ea24c++)if(_0x2c17c0['pieces_'][_0x3e3479]!==_0x3f9aaf['pieces_'][_0x5ea24c])return!0x1;return!0x0;}function G(_0x395c58,_0x485aea){let _0x40d03b=_0x395c58['pieceNum_'],_0x518dfe=_0x485aea['pieceNum_'];if(Ce(_0x395c58)>Ce(_0x485aea))return!0x1;for(;_0x40d03b<_0x395c58['pieces_']['length'];){if(_0x395c58['pieces_'][_0x40d03b]!==_0x485aea['pieces_'][_0x518dfe])return!0x1;++_0x40d03b,++_0x518dfe;}return!0x0;}class Ah{constructor(_0x5cc73f,_0x1c2854){this['errorPrefix_']=_0x1c2854,this['parts_']=Mt(_0x5cc73f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3d1d46=0x0;_0x3d1d46<this['parts_']['length'];_0x3d1d46++)this['byteLength_']+=Ln(this['parts_'][_0x3d1d46]);Ao(this);}}function kh(_0x4e9aec,_0x55fa02){_0x4e9aec['parts_']['length']>0x0&&(_0x4e9aec['byteLength_']+=0x1),_0x4e9aec['parts_']['push'](_0x55fa02),_0x4e9aec['byteLength_']+=Ln(_0x55fa02),Ao(_0x4e9aec);}function Ph(_0x3269fd){const _0xf7f125=_0x3269fd['parts_']['pop']();_0x3269fd['byteLength_']-=Ln(_0xf7f125),_0x3269fd['parts_']['length']>0x0&&(_0x3269fd['byteLength_']-=0x1);}function Ao(_0x1af3c5){if(_0x1af3c5['byteLength_']>Zs)throw new Error(_0x1af3c5['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1af3c5['byteLength_']+').');if(_0x1af3c5['parts_']['length']>Xs)throw new Error(_0x1af3c5['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x1af3c5));}function Oe(_0x39429c){return _0x39429c['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x39429c['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x20a0eb,_0x5b5f20;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5b5f20='visibilitychange',_0x20a0eb='hidden'):typeof document['mozHidden']<'u'?(_0x5b5f20='mozvisibilitychange',_0x20a0eb='mozHidden'):typeof document['msHidden']<'u'?(_0x5b5f20='msvisibilitychange',_0x20a0eb='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5b5f20='webkitvisibilitychange',_0x20a0eb='webkitHidden')),this['visible_']=!0x0,_0x5b5f20&&document['addEventListener'](_0x5b5f20,()=>{const _0x51bbea=!document[_0x20a0eb];_0x51bbea!==this['visible_']&&(this['visible_']=_0x51bbea,this['trigger']('visible',_0x51bbea));},!0x1);}['getInitialEvent'](_0x70d3a0){return f(_0x70d3a0==='visible','Unknown\x20event\x20type:\x20'+_0x70d3a0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x921a19,_0x569bda,_0x44c6de,_0x3e2863,_0x56509e,_0x3972e5,_0x1869b4,_0x496488){if(super(),this['repoInfo_']=_0x921a19,this['applicationId_']=_0x569bda,this['onDataUpdate_']=_0x44c6de,this['onConnectStatus_']=_0x3e2863,this['onServerInfoUpdate_']=_0x56509e,this['authTokenProvider_']=_0x3972e5,this['appCheckTokenProvider_']=_0x1869b4,this['authOverride_']=_0x496488,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x496488)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x921a19['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3a5804,_0x27f603,_0x42861a){const _0x3b2a6f=++this['requestNumber_'],_0x26be67={'r':_0x3b2a6f,'a':_0x3a5804,'b':_0x27f603};this['log_'](O(_0x26be67)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x26be67),_0x42861a&&(this['requestCBHash_'][_0x3b2a6f]=_0x42861a);}['get'](_0x4cfdad){this['initConnection_']();const _0x5b0ea5=new H(),_0x406915={'action':'g','request':{'p':_0x4cfdad['_path']['toString'](),'q':_0x4cfdad['_queryObject']},'onComplete':_0x5bc4d7=>{const _0x46a5a0=_0x5bc4d7['d'];_0x5bc4d7['s']==='ok'?_0x5b0ea5['resolve'](_0x46a5a0):_0x5b0ea5['reject'](_0x46a5a0);}};this['outstandingGets_']['push'](_0x406915),this['outstandingGetCount_']++;const _0x2f444f=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2f444f),_0x5b0ea5['promise'];}['listen'](_0x5ca841,_0x2b6a9c,_0x5eec97,_0x433eed){this['initConnection_']();const _0x321ac8=_0x5ca841['_queryIdentifier'],_0x90b245=_0x5ca841['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x90b245+'\x20'+_0x321ac8),this['listens']['has'](_0x90b245)||this['listens']['set'](_0x90b245,new Map()),f(_0x5ca841['_queryParams']['isDefault']()||!_0x5ca841['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x90b245)['has'](_0x321ac8),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x32c95d={'onComplete':_0x433eed,'hashFn':_0x2b6a9c,'query':_0x5ca841,'tag':_0x5eec97};this['listens']['get'](_0x90b245)['set'](_0x321ac8,_0x32c95d),this['connected_']&&this['sendListen_'](_0x32c95d);}['sendGet_'](_0x404785){const _0x25da54=this['outstandingGets_'][_0x404785];this['sendRequest']('g',_0x25da54['request'],_0x38ae47=>{delete this['outstandingGets_'][_0x404785],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x25da54['onComplete']&&_0x25da54['onComplete'](_0x38ae47);});}['sendListen_'](_0x4eb629){const _0x128463=_0x4eb629['query'],_0x274ce2=_0x128463['_path']['toString'](),_0x34e318=_0x128463['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x274ce2+'\x20for\x20'+_0x34e318);const _0x135618={'p':_0x274ce2},_0x14d0a9='q';_0x4eb629['tag']&&(_0x135618['q']=_0x128463['_queryObject'],_0x135618['t']=_0x4eb629['tag']),_0x135618['h']=_0x4eb629['hashFn'](),this['sendRequest'](_0x14d0a9,_0x135618,_0xd8db8a=>{const _0x4dd9fb=_0xd8db8a['d'],_0x1a22a1=_0xd8db8a['s'];se['warnOnListenWarnings_'](_0x4dd9fb,_0x128463),(this['listens']['get'](_0x274ce2)&&this['listens']['get'](_0x274ce2)['get'](_0x34e318))===_0x4eb629&&(this['log_']('listen\x20response',_0xd8db8a),_0x1a22a1!=='ok'&&this['removeListen_'](_0x274ce2,_0x34e318),_0x4eb629['onComplete']&&_0x4eb629['onComplete'](_0x1a22a1,_0x4dd9fb));});}static['warnOnListenWarnings_'](_0x29748f,_0x527134){if(_0x29748f&&typeof _0x29748f=='object'&&Q(_0x29748f,'w')){const _0x3db4ce=Le(_0x29748f,'w');if(Array['isArray'](_0x3db4ce)&&~_0x3db4ce['indexOf']('no_index')){const _0x4aa65f='\x22.indexOn\x22:\x20\x22'+_0x527134['_queryParams']['getIndex']()['toString']()+'\x22',_0x561e45=_0x527134['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4aa65f+'\x20at\x20'+_0x561e45+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4d60cd){this['authToken_']=_0x4d60cd,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4d60cd);}['reduceReconnectDelayIfAdminCredential_'](_0x168c36){(_0x168c36&&_0x168c36['length']===0x28||wc(_0x168c36))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0xf92ce0){this['appCheckToken_']=_0xf92ce0,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x50b1ca=this['authToken_'],_0x33b815=Ic(_0x50b1ca)?'auth':'gauth',_0x42c917={'cred':_0x50b1ca};this['authOverride_']===null?_0x42c917['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x42c917['authvar']=this['authOverride_']),this['sendRequest'](_0x33b815,_0x42c917,_0x3242bb=>{const _0x17d9c5=_0x3242bb['s'],_0x47d3fb=_0x3242bb['d']||'error';this['authToken_']===_0x50b1ca&&(_0x17d9c5==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x17d9c5,_0x47d3fb));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x380b69=>{const _0x24da4b=_0x380b69['s'],_0x529833=_0x380b69['d']||'error';_0x24da4b==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x24da4b,_0x529833);});}['unlisten'](_0x755c85,_0x1c2db8){const _0x2d4c70=_0x755c85['_path']['toString'](),_0x1c3e6a=_0x755c85['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2d4c70+'\x20'+_0x1c3e6a),f(_0x755c85['_queryParams']['isDefault']()||!_0x755c85['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2d4c70,_0x1c3e6a)&&this['connected_']&&this['sendUnlisten_'](_0x2d4c70,_0x1c3e6a,_0x755c85['_queryObject'],_0x1c2db8);}['sendUnlisten_'](_0x21810f,_0x2df7b0,_0x5be08e,_0x23328a){this['log_']('Unlisten\x20on\x20'+_0x21810f+'\x20for\x20'+_0x2df7b0);const _0x328fbf={'p':_0x21810f},_0x4d998b='n';_0x23328a&&(_0x328fbf['q']=_0x5be08e,_0x328fbf['t']=_0x23328a),this['sendRequest'](_0x4d998b,_0x328fbf);}['onDisconnectPut'](_0x5c1526,_0x50358e,_0xdcf172){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5c1526,_0x50358e,_0xdcf172):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c1526,'action':'o','data':_0x50358e,'onComplete':_0xdcf172});}['onDisconnectMerge'](_0x29d7ae,_0x18c05c,_0x22d2cb){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x29d7ae,_0x18c05c,_0x22d2cb):this['onDisconnectRequestQueue_']['push']({'pathString':_0x29d7ae,'action':'om','data':_0x18c05c,'onComplete':_0x22d2cb});}['onDisconnectCancel'](_0x1f6cad,_0x2be8cd){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1f6cad,null,_0x2be8cd):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1f6cad,'action':'oc','data':null,'onComplete':_0x2be8cd});}['sendOnDisconnect_'](_0x5836a1,_0xef4467,_0x8290eb,_0xb4cd5c){const _0x1aad69={'p':_0xef4467,'d':_0x8290eb};this['log_']('onDisconnect\x20'+_0x5836a1,_0x1aad69),this['sendRequest'](_0x5836a1,_0x1aad69,_0x259f24=>{_0xb4cd5c&&setTimeout(()=>{_0xb4cd5c(_0x259f24['s'],_0x259f24['d']);},Math['floor'](0x0));});}['put'](_0x269466,_0x3691de,_0x2f0a96,_0x4202fb){this['putInternal']('p',_0x269466,_0x3691de,_0x2f0a96,_0x4202fb);}['merge'](_0x79b62f,_0x5656c2,_0x303f4e,_0x455a99){this['putInternal']('m',_0x79b62f,_0x5656c2,_0x303f4e,_0x455a99);}['putInternal'](_0x4b8185,_0x5ce6ff,_0x5e95f8,_0x1fc06b,_0x2ee36b){this['initConnection_']();const _0x5ed0bc={'p':_0x5ce6ff,'d':_0x5e95f8};_0x2ee36b!==void 0x0&&(_0x5ed0bc['h']=_0x2ee36b),this['outstandingPuts_']['push']({'action':_0x4b8185,'request':_0x5ed0bc,'onComplete':_0x1fc06b}),this['outstandingPutCount_']++;const _0x2aa041=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2aa041):this['log_']('Buffering\x20put:\x20'+_0x5ce6ff);}['sendPut_'](_0x2c41cc){const _0x43e0eb=this['outstandingPuts_'][_0x2c41cc]['action'],_0x56702c=this['outstandingPuts_'][_0x2c41cc]['request'],_0x1b8208=this['outstandingPuts_'][_0x2c41cc]['onComplete'];this['outstandingPuts_'][_0x2c41cc]['queued']=this['connected_'],this['sendRequest'](_0x43e0eb,_0x56702c,_0x276998=>{this['log_'](_0x43e0eb+'\x20response',_0x276998),delete this['outstandingPuts_'][_0x2c41cc],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1b8208&&_0x1b8208(_0x276998['s'],_0x276998['d']);});}['reportStats'](_0x22d028){if(this['connected_']){const _0x3532bf={'c':_0x22d028};this['log_']('reportStats',_0x3532bf),this['sendRequest']('s',_0x3532bf,_0x1afec1=>{if(_0x1afec1['s']!=='ok'){const _0x44d2d7=_0x1afec1['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x44d2d7);}});}}['onDataMessage_'](_0x32b813){if('r'in _0x32b813){this['log_']('from\x20server:\x20'+O(_0x32b813));const _0xe09fd0=_0x32b813['r'],_0x14ee10=this['requestCBHash_'][_0xe09fd0];_0x14ee10&&(delete this['requestCBHash_'][_0xe09fd0],_0x14ee10(_0x32b813['b']));}else{if('error'in _0x32b813)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x32b813['error'];'a'in _0x32b813&&this['onDataPush_'](_0x32b813['a'],_0x32b813['b']);}}['onDataPush_'](_0x152431,_0x281c32){this['log_']('handleServerMessage',_0x152431,_0x281c32),_0x152431==='d'?this['onDataUpdate_'](_0x281c32['p'],_0x281c32['d'],!0x1,_0x281c32['t']):_0x152431==='m'?this['onDataUpdate_'](_0x281c32['p'],_0x281c32['d'],!0x0,_0x281c32['t']):_0x152431==='c'?this['onListenRevoked_'](_0x281c32['p'],_0x281c32['q']):_0x152431==='ac'?this['onAuthRevoked_'](_0x281c32['s'],_0x281c32['d']):_0x152431==='apc'?this['onAppCheckRevoked_'](_0x281c32['s'],_0x281c32['d']):_0x152431==='sd'?this['onSecurityDebugPacket_'](_0x281c32):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x152431)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x9f0c39,_0x31e55e){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x9f0c39),this['lastSessionId']=_0x31e55e,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2af18d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2af18d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2ff53a){_0x2ff53a&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2ff53a;}['onOnline_'](_0x433732){_0x433732?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x364847=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x154672=Math['max'](0x0,this['reconnectDelay_']-_0x364847);_0x154672=Math['random']()*_0x154672,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x154672+'ms'),this['scheduleConnect_'](_0x154672),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1c3998=this['onDataMessage_']['bind'](this),_0x41b753=this['onReady_']['bind'](this),_0x3562e9=this['onRealtimeDisconnect_']['bind'](this),_0x4d08c0=this['id']+':'+se['nextConnectionId_']++,_0x5183a0=this['lastSessionId'];let _0x4b360e=!0x1,_0x1d058b=null;const _0x330233=function(){_0x1d058b?_0x1d058b['close']():(_0x4b360e=!0x0,_0x3562e9());},_0x13892b=function(_0x121121){f(_0x1d058b,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1d058b['sendRequest'](_0x121121);};this['realtime_']={'close':_0x330233,'sendRequest':_0x13892b};const _0x3410ce=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2ffc2f,_0x20a36e]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3410ce),this['appCheckTokenProvider_']['getToken'](_0x3410ce)]);_0x4b360e?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2ffc2f&&_0x2ffc2f['accessToken'],this['appCheckToken_']=_0x20a36e&&_0x20a36e['token'],_0x1d058b=new Sh(_0x4d08c0,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1c3998,_0x41b753,_0x3562e9,_0x434ed0=>{U(_0x434ed0+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x5183a0));}catch(_0x31bfa){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x31bfa),_0x4b360e||(this['repoInfo_']['nodeAdmin']&&U(_0x31bfa),_0x330233());}}}['interrupt'](_0x700020){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x700020),this['interruptReasons_'][_0x700020]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5b04c9){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5b04c9),delete this['interruptReasons_'][_0x5b04c9],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4017ff){const _0x3c14ef=_0x4017ff-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3c14ef});}['cancelSentTransactions_'](){for(let _0x273f13=0x0;_0x273f13<this['outstandingPuts_']['length'];_0x273f13++){const _0x165358=this['outstandingPuts_'][_0x273f13];_0x165358&&'h'in _0x165358['request']&&_0x165358['queued']&&(_0x165358['onComplete']&&_0x165358['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x273f13],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x23a116,_0x5630ae){let _0x1665b1;_0x5630ae?_0x1665b1=_0x5630ae['map'](_0x5be087=>$i(_0x5be087))['join']('$'):_0x1665b1='default';const _0x1ec5f0=this['removeListen_'](_0x23a116,_0x1665b1);_0x1ec5f0&&_0x1ec5f0['onComplete']&&_0x1ec5f0['onComplete']('permission_denied');}['removeListen_'](_0x5858ca,_0x2266a6){const _0x5d48e7=new C(_0x5858ca)['toString']();let _0x3b084e;if(this['listens']['has'](_0x5d48e7)){const _0x2685d9=this['listens']['get'](_0x5d48e7);_0x3b084e=_0x2685d9['get'](_0x2266a6),_0x2685d9['delete'](_0x2266a6),_0x2685d9['size']===0x0&&this['listens']['delete'](_0x5d48e7);}else _0x3b084e=void 0x0;return _0x3b084e;}['onAuthRevoked_'](_0x56b0a1,_0x518847){L('Auth\x20token\x20revoked:\x20'+_0x56b0a1+'/'+_0x518847),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x56b0a1==='invalid_token'||_0x56b0a1==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x57451f,_0x53e88a){L('App\x20check\x20token\x20revoked:\x20'+_0x57451f+'/'+_0x53e88a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x57451f==='invalid_token'||_0x57451f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2e3d0f){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2e3d0f):'msg'in _0x2e3d0f&&console['log']('FIREBASE:\x20'+_0x2e3d0f['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x6cc0e0 of this['listens']['values']())for(const _0x22858e of _0x6cc0e0['values']())this['sendListen_'](_0x22858e);for(let _0x9bc862=0x0;_0x9bc862<this['outstandingPuts_']['length'];_0x9bc862++)this['outstandingPuts_'][_0x9bc862]&&this['sendPut_'](_0x9bc862);for(;this['onDisconnectRequestQueue_']['length'];){const _0x538f7a=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x538f7a['action'],_0x538f7a['pathString'],_0x538f7a['data'],_0x538f7a['onComplete']);}for(let _0x19844d=0x0;_0x19844d<this['outstandingGets_']['length'];_0x19844d++)this['outstandingGets_'][_0x19844d]&&this['sendGet_'](_0x19844d);}['sendConnectStats_'](){const _0x277903={};let _0xbd50c1='js';_0x277903['sdk.'+_0xbd50c1+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x277903['framework.cordova']=0x1:Kr()&&(_0x277903['framework.reactnative']=0x1),this['reportStats'](_0x277903);}['shouldReconnect_'](){const _0xa6af7e=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0xa6af7e;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x337f15,_0x415aff){this['name']=_0x337f15,this['node']=_0x415aff;}static['Wrap'](_0x318ff4,_0x1c9902){return new E(_0x318ff4,_0x1c9902);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1f062b,_0x5c1422){const _0xe42375=new E(We,_0x1f062b),_0x1f5c6e=new E(We,_0x5c1422);return this['compare'](_0xe42375,_0x1f5c6e)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x70ee39){sn=_0x70ee39;}['compare'](_0x4d4eff,_0x9d4173){return qe(_0x4d4eff['name'],_0x9d4173['name']);}['isDefinedOn'](_0x3aca6f){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x101cc2,_0x215725){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4320b5,_0x148d8e){return f(typeof _0x4320b5=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4320b5,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x2a4da0,_0x39843e,_0x443f26,_0xe802eb,_0x2e87f1=null){this['isReverse_']=_0xe802eb,this['resultGenerator_']=_0x2e87f1,this['nodeStack_']=[];let _0x52ed5b=0x1;for(;!_0x2a4da0['isEmpty']();)if(_0x2a4da0=_0x2a4da0,_0x52ed5b=_0x39843e?_0x443f26(_0x2a4da0['key'],_0x39843e):0x1,_0xe802eb&&(_0x52ed5b*=-0x1),_0x52ed5b<0x0)this['isReverse_']?_0x2a4da0=_0x2a4da0['left']:_0x2a4da0=_0x2a4da0['right'];else{if(_0x52ed5b===0x0){this['nodeStack_']['push'](_0x2a4da0);break;}else this['nodeStack_']['push'](_0x2a4da0),this['isReverse_']?_0x2a4da0=_0x2a4da0['right']:_0x2a4da0=_0x2a4da0['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5984d1=this['nodeStack_']['pop'](),_0x3ae092;if(this['resultGenerator_']?_0x3ae092=this['resultGenerator_'](_0x5984d1['key'],_0x5984d1['value']):_0x3ae092={'key':_0x5984d1['key'],'value':_0x5984d1['value']},this['isReverse_']){for(_0x5984d1=_0x5984d1['left'];!_0x5984d1['isEmpty']();)this['nodeStack_']['push'](_0x5984d1),_0x5984d1=_0x5984d1['right'];}else{for(_0x5984d1=_0x5984d1['right'];!_0x5984d1['isEmpty']();)this['nodeStack_']['push'](_0x5984d1),_0x5984d1=_0x5984d1['left'];}return _0x3ae092;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x52293f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x52293f['key'],_0x52293f['value']):{'key':_0x52293f['key'],'value':_0x52293f['value']};}}class M{constructor(_0x5282e0,_0x2f03ec,_0x5b8666,_0x1926ff,_0x3ace74){this['key']=_0x5282e0,this['value']=_0x2f03ec,this['color']=_0x5b8666??M['RED'],this['left']=_0x1926ff??B['EMPTY_NODE'],this['right']=_0x3ace74??B['EMPTY_NODE'];}['copy'](_0x5ac606,_0x578a40,_0xaea0c8,_0x4897f3,_0x534af2){return new M(_0x5ac606??this['key'],_0x578a40??this['value'],_0xaea0c8??this['color'],_0x4897f3??this['left'],_0x534af2??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x18e420){return this['left']['inorderTraversal'](_0x18e420)||!!_0x18e420(this['key'],this['value'])||this['right']['inorderTraversal'](_0x18e420);}['reverseTraversal'](_0x277187){return this['right']['reverseTraversal'](_0x277187)||_0x277187(this['key'],this['value'])||this['left']['reverseTraversal'](_0x277187);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xa35f9f,_0x4544a0,_0x3da44d){let _0x2a2975=this;const _0x449fd3=_0x3da44d(_0xa35f9f,_0x2a2975['key']);return _0x449fd3<0x0?_0x2a2975=_0x2a2975['copy'](null,null,null,_0x2a2975['left']['insert'](_0xa35f9f,_0x4544a0,_0x3da44d),null):_0x449fd3===0x0?_0x2a2975=_0x2a2975['copy'](null,_0x4544a0,null,null,null):_0x2a2975=_0x2a2975['copy'](null,null,null,null,_0x2a2975['right']['insert'](_0xa35f9f,_0x4544a0,_0x3da44d)),_0x2a2975['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2a1491=this;return!_0x2a1491['left']['isRed_']()&&!_0x2a1491['left']['left']['isRed_']()&&(_0x2a1491=_0x2a1491['moveRedLeft_']()),_0x2a1491=_0x2a1491['copy'](null,null,null,_0x2a1491['left']['removeMin_'](),null),_0x2a1491['fixUp_']();}['remove'](_0x1efe33,_0x1fcb15){let _0x30405d,_0x89b984;if(_0x30405d=this,_0x1fcb15(_0x1efe33,_0x30405d['key'])<0x0)!_0x30405d['left']['isEmpty']()&&!_0x30405d['left']['isRed_']()&&!_0x30405d['left']['left']['isRed_']()&&(_0x30405d=_0x30405d['moveRedLeft_']()),_0x30405d=_0x30405d['copy'](null,null,null,_0x30405d['left']['remove'](_0x1efe33,_0x1fcb15),null);else{if(_0x30405d['left']['isRed_']()&&(_0x30405d=_0x30405d['rotateRight_']()),!_0x30405d['right']['isEmpty']()&&!_0x30405d['right']['isRed_']()&&!_0x30405d['right']['left']['isRed_']()&&(_0x30405d=_0x30405d['moveRedRight_']()),_0x1fcb15(_0x1efe33,_0x30405d['key'])===0x0){if(_0x30405d['right']['isEmpty']())return B['EMPTY_NODE'];_0x89b984=_0x30405d['right']['min_'](),_0x30405d=_0x30405d['copy'](_0x89b984['key'],_0x89b984['value'],null,null,_0x30405d['right']['removeMin_']());}_0x30405d=_0x30405d['copy'](null,null,null,null,_0x30405d['right']['remove'](_0x1efe33,_0x1fcb15));}return _0x30405d['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4b981c=this;return _0x4b981c['right']['isRed_']()&&!_0x4b981c['left']['isRed_']()&&(_0x4b981c=_0x4b981c['rotateLeft_']()),_0x4b981c['left']['isRed_']()&&_0x4b981c['left']['left']['isRed_']()&&(_0x4b981c=_0x4b981c['rotateRight_']()),_0x4b981c['left']['isRed_']()&&_0x4b981c['right']['isRed_']()&&(_0x4b981c=_0x4b981c['colorFlip_']()),_0x4b981c;}['moveRedLeft_'](){let _0x1dd9c9=this['colorFlip_']();return _0x1dd9c9['right']['left']['isRed_']()&&(_0x1dd9c9=_0x1dd9c9['copy'](null,null,null,null,_0x1dd9c9['right']['rotateRight_']()),_0x1dd9c9=_0x1dd9c9['rotateLeft_'](),_0x1dd9c9=_0x1dd9c9['colorFlip_']()),_0x1dd9c9;}['moveRedRight_'](){let _0x79c0ec=this['colorFlip_']();return _0x79c0ec['left']['left']['isRed_']()&&(_0x79c0ec=_0x79c0ec['rotateRight_'](),_0x79c0ec=_0x79c0ec['colorFlip_']()),_0x79c0ec;}['rotateLeft_'](){const _0x2f8811=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2f8811,null);}['rotateRight_'](){const _0x402828=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x402828);}['colorFlip_'](){const _0x2999e2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x322a05=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2999e2,_0x322a05);}['checkMaxDepth_'](){const _0x2e772a=this['check_']();return Math['pow'](0x2,_0x2e772a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1e51c6=this['left']['check_']();if(_0x1e51c6!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1e51c6+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4dd96a,_0x3b8e6e,_0xe0611c,_0x18acea,_0x323a11){return this;}['insert'](_0x2bc19b,_0x1b72f1,_0x57f76a){return new M(_0x2bc19b,_0x1b72f1,null);}['remove'](_0x1c7bb5,_0x32a48f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4f6926){return!0x1;}['reverseTraversal'](_0x19af36){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2ff41b,_0x199730=B['EMPTY_NODE']){this['comparator_']=_0x2ff41b,this['root_']=_0x199730;}['insert'](_0x257338,_0x496f8b){return new B(this['comparator_'],this['root_']['insert'](_0x257338,_0x496f8b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xc45d50){return new B(this['comparator_'],this['root_']['remove'](_0xc45d50,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x226553){let _0x310b7d,_0x19b6df=this['root_'];for(;!_0x19b6df['isEmpty']();){if(_0x310b7d=this['comparator_'](_0x226553,_0x19b6df['key']),_0x310b7d===0x0)return _0x19b6df['value'];_0x310b7d<0x0?_0x19b6df=_0x19b6df['left']:_0x310b7d>0x0&&(_0x19b6df=_0x19b6df['right']);}return null;}['getPredecessorKey'](_0x7fc4e5){let _0xf71c1c,_0x40fdd0=this['root_'],_0x573946=null;for(;!_0x40fdd0['isEmpty']();)if(_0xf71c1c=this['comparator_'](_0x7fc4e5,_0x40fdd0['key']),_0xf71c1c===0x0){if(_0x40fdd0['left']['isEmpty']())return _0x573946?_0x573946['key']:null;for(_0x40fdd0=_0x40fdd0['left'];!_0x40fdd0['right']['isEmpty']();)_0x40fdd0=_0x40fdd0['right'];return _0x40fdd0['key'];}else _0xf71c1c<0x0?_0x40fdd0=_0x40fdd0['left']:_0xf71c1c>0x0&&(_0x573946=_0x40fdd0,_0x40fdd0=_0x40fdd0['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x63c97){return this['root_']['inorderTraversal'](_0x63c97);}['reverseTraversal'](_0x5bcaff){return this['root_']['reverseTraversal'](_0x5bcaff);}['getIterator'](_0x2dbe51){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2dbe51);}['getIteratorFrom'](_0x47d4ba,_0x442fee){return new rn(this['root_'],_0x47d4ba,this['comparator_'],!0x1,_0x442fee);}['getReverseIteratorFrom'](_0x462ea3,_0x3a5d75){return new rn(this['root_'],_0x462ea3,this['comparator_'],!0x0,_0x3a5d75);}['getReverseIterator'](_0x24e67b){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x24e67b);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0xdfce94,_0x349922){return qe(_0xdfce94['name'],_0x349922['name']);}function Qi(_0x4bc315,_0x55739d){return qe(_0x4bc315,_0x55739d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2a35ad){Ci=_0x2a35ad;}const Po=function(_0x59a7ee){return typeof _0x59a7ee=='number'?'number:'+ao(_0x59a7ee):'string:'+_0x59a7ee;},No=function(_0x48de2a){if(_0x48de2a['isLeafNode']()){const _0x4a19ff=_0x48de2a['val']();f(typeof _0x4a19ff=='string'||typeof _0x4a19ff=='number'||typeof _0x4a19ff=='object'&&Q(_0x4a19ff,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x48de2a===Ci||_0x48de2a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x48de2a===Ci||_0x48de2a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x2c6a54){nr=_0x2c6a54;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0xd85b42,_0x47cbba=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xd85b42,this['priorityNode_']=_0x47cbba,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5ea8e5){return new D(this['value_'],_0x5ea8e5);}['getImmediateChild'](_0x51f689){return _0x51f689==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5b3156){return v(_0x5b3156)?this:y(_0x5b3156)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1b990e,_0x419b88){return null;}['updateImmediateChild'](_0x9764bf,_0x547577){return _0x9764bf==='.priority'?this['updatePriority'](_0x547577):_0x547577['isEmpty']()&&_0x9764bf!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x9764bf,_0x547577)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5d684f,_0xa580ed){const _0x3287b1=y(_0x5d684f);return _0x3287b1===null?_0xa580ed:_0xa580ed['isEmpty']()&&_0x3287b1!=='.priority'?this:(f(_0x3287b1!=='.priority'||Ce(_0x5d684f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3287b1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x5d684f),_0xa580ed)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2c406f,_0x3ea076){return!0x1;}['val'](_0x2f7397){return _0x2f7397&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x113510='';this['priorityNode_']['isEmpty']()||(_0x113510+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x6ea739=typeof this['value_'];_0x113510+=_0x6ea739+':',_0x6ea739==='number'?_0x113510+=ao(this['value_']):_0x113510+=this['value_'],this['lazyHash_']=ro(_0x113510);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3adc07){return _0x3adc07===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3adc07 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3adc07['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3adc07));}['compareToLeafNode_'](_0x2e1d68){const _0x25221c=typeof _0x2e1d68['value_'],_0x5c2633=typeof this['value_'],_0x5d078e=D['VALUE_TYPE_ORDER']['indexOf'](_0x25221c),_0xeb9377=D['VALUE_TYPE_ORDER']['indexOf'](_0x5c2633);return f(_0x5d078e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x25221c),f(_0xeb9377>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5c2633),_0x5d078e===_0xeb9377?_0x5c2633==='object'?0x0:this['value_']<_0x2e1d68['value_']?-0x1:this['value_']===_0x2e1d68['value_']?0x0:0x1:_0xeb9377-_0x5d078e;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x63aaa2){if(_0x63aaa2===this)return!0x0;if(_0x63aaa2['isLeafNode']()){const _0x579c1e=_0x63aaa2;return this['value_']===_0x579c1e['value_']&&this['priorityNode_']['equals'](_0x579c1e['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x447294){Oo=_0x447294;}function Wh(_0x2a936b){Do=_0x2a936b;}class Bh extends Fn{['compare'](_0xf38af2,_0x5e930d){const _0x49ded8=_0xf38af2['node']['getPriority'](),_0xd5b0c8=_0x5e930d['node']['getPriority'](),_0x4cac7f=_0x49ded8['compareTo'](_0xd5b0c8);return _0x4cac7f===0x0?qe(_0xf38af2['name'],_0x5e930d['name']):_0x4cac7f;}['isDefinedOn'](_0x45c79c){return!_0x45c79c['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x560fb3,_0x10cc42){return!_0x560fb3['getPriority']()['equals'](_0x10cc42['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x1e7cfe,_0x2c42e6){const _0x5bd264=Oo(_0x1e7cfe);return new E(_0x2c42e6,new D('[PRIORITY-POST]',_0x5bd264));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x29ab1f){const _0x15e877=_0x11f7d3=>parseInt(Math['log'](_0x11f7d3)/Vh,0xa),_0x459f45=_0x212102=>parseInt(Array(_0x212102+0x1)['join']('1'),0x2);this['count']=_0x15e877(_0x29ab1f+0x1),this['current_']=this['count']-0x1;const _0x2799cb=_0x459f45(this['count']);this['bits_']=_0x29ab1f+0x1&_0x2799cb;}['nextBitIsOne'](){const _0x165eed=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x165eed;}}const yn=function(_0x16fb3a,_0x12d656,_0x34cac5,_0x5e057e){_0x16fb3a['sort'](_0x12d656);const _0x275534=function(_0x35ada3,_0x140063){const _0x48a923=_0x140063-_0x35ada3;let _0x227b94,_0x3b2e79;if(_0x48a923===0x0)return null;if(_0x48a923===0x1)return _0x227b94=_0x16fb3a[_0x35ada3],_0x3b2e79=_0x34cac5?_0x34cac5(_0x227b94):_0x227b94,new M(_0x3b2e79,_0x227b94['node'],M['BLACK'],null,null);{const _0x59a23e=parseInt(_0x48a923/0x2,0xa)+_0x35ada3,_0x431ec5=_0x275534(_0x35ada3,_0x59a23e),_0x185d57=_0x275534(_0x59a23e+0x1,_0x140063);return _0x227b94=_0x16fb3a[_0x59a23e],_0x3b2e79=_0x34cac5?_0x34cac5(_0x227b94):_0x227b94,new M(_0x3b2e79,_0x227b94['node'],M['BLACK'],_0x431ec5,_0x185d57);}},_0x2820e3=function(_0x1550c1){let _0x5ea64f=null,_0x3ef0cd=null,_0x277b8b=_0x16fb3a['length'];const _0x15b8e6=function(_0x1b5c85,_0x2d1e6e){const _0x53db71=_0x277b8b-_0x1b5c85,_0x82c8e8=_0x277b8b;_0x277b8b-=_0x1b5c85;const _0x4226ec=_0x275534(_0x53db71+0x1,_0x82c8e8),_0x47a1db=_0x16fb3a[_0x53db71],_0x24ab60=_0x34cac5?_0x34cac5(_0x47a1db):_0x47a1db;_0x5d6eb1(new M(_0x24ab60,_0x47a1db['node'],_0x2d1e6e,null,_0x4226ec));},_0x5d6eb1=function(_0x26ee20){_0x5ea64f?(_0x5ea64f['left']=_0x26ee20,_0x5ea64f=_0x26ee20):(_0x3ef0cd=_0x26ee20,_0x5ea64f=_0x26ee20);};for(let _0xd1a882=0x0;_0xd1a882<_0x1550c1['count'];++_0xd1a882){const _0x1ca146=_0x1550c1['nextBitIsOne'](),_0x1b63cf=Math['pow'](0x2,_0x1550c1['count']-(_0xd1a882+0x1));_0x1ca146?_0x15b8e6(_0x1b63cf,M['BLACK']):(_0x15b8e6(_0x1b63cf,M['BLACK']),_0x15b8e6(_0x1b63cf,M['RED']));}return _0x3ef0cd;},_0x2f30c1=new Hh(_0x16fb3a['length']),_0x4b8462=_0x2820e3(_0x2f30c1);return new B(_0x5e057e||_0x12d656,_0x4b8462);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x16a16a,_0x1a5134){this['indexes_']=_0x16a16a,this['indexSet_']=_0x1a5134;}['get'](_0x7de6a9){const _0x918004=Le(this['indexes_'],_0x7de6a9);if(!_0x918004)throw new Error('No\x20index\x20defined\x20for\x20'+_0x7de6a9);return _0x918004 instanceof B?_0x918004:null;}['hasIndex'](_0x2e1b1b){return Q(this['indexSet_'],_0x2e1b1b['toString']());}['addIndex'](_0x48a344,_0x57c22e){f(_0x48a344!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x517e12=[];let _0x1686de=!0x1;const _0x241cb4=_0x57c22e['getIterator'](E['Wrap']);let _0x55c05b=_0x241cb4['getNext']();for(;_0x55c05b;)_0x1686de=_0x1686de||_0x48a344['isDefinedOn'](_0x55c05b['node']),_0x517e12['push'](_0x55c05b),_0x55c05b=_0x241cb4['getNext']();let _0x16ece6;_0x1686de?_0x16ece6=yn(_0x517e12,_0x48a344['getCompare']()):_0x16ece6=Qe;const _0xf8927c=_0x48a344['toString'](),_0x35371f={...this['indexSet_']};_0x35371f[_0xf8927c]=_0x48a344;const _0x583f07={...this['indexes_']};return _0x583f07[_0xf8927c]=_0x16ece6,new te(_0x583f07,_0x35371f);}['addToIndexes'](_0x10ca11,_0x34b1fd){const _0x457845=_n(this['indexes_'],(_0x5d9d6a,_0x5279d1)=>{const _0x241d50=Le(this['indexSet_'],_0x5279d1);if(f(_0x241d50,'Missing\x20index\x20implementation\x20for\x20'+_0x5279d1),_0x5d9d6a===Qe){if(_0x241d50['isDefinedOn'](_0x10ca11['node'])){const _0x54e878=[],_0x192efd=_0x34b1fd['getIterator'](E['Wrap']);let _0x448db1=_0x192efd['getNext']();for(;_0x448db1;)_0x448db1['name']!==_0x10ca11['name']&&_0x54e878['push'](_0x448db1),_0x448db1=_0x192efd['getNext']();return _0x54e878['push'](_0x10ca11),yn(_0x54e878,_0x241d50['getCompare']());}else return Qe;}else{const _0x63e528=_0x34b1fd['get'](_0x10ca11['name']);let _0x59c6ae=_0x5d9d6a;return _0x63e528&&(_0x59c6ae=_0x59c6ae['remove'](new E(_0x10ca11['name'],_0x63e528))),_0x59c6ae['insert'](_0x10ca11,_0x10ca11['node']);}});return new te(_0x457845,this['indexSet_']);}['removeFromIndexes'](_0x42853b,_0x26048f){const _0x2ba705=_n(this['indexes_'],_0x244e42=>{if(_0x244e42===Qe)return _0x244e42;{const _0x27bd09=_0x26048f['get'](_0x42853b['name']);return _0x27bd09?_0x244e42['remove'](new E(_0x42853b['name'],_0x27bd09)):_0x244e42;}});return new te(_0x2ba705,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x53c0bd,_0x542a33,_0x3f2f81){this['children_']=_0x53c0bd,this['priorityNode_']=_0x542a33,this['indexMap_']=_0x3f2f81,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x5d41d2){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5d41d2,this['indexMap_']);}['getImmediateChild'](_0x627ba0){if(_0x627ba0==='.priority')return this['getPriority']();{const _0x22914c=this['children_']['get'](_0x627ba0);return _0x22914c===null?It:_0x22914c;}}['getChild'](_0x52c374){const _0x4c2b23=y(_0x52c374);return _0x4c2b23===null?this:this['getImmediateChild'](_0x4c2b23)['getChild'](S(_0x52c374));}['hasChild'](_0x39d8f9){return this['children_']['get'](_0x39d8f9)!==null;}['updateImmediateChild'](_0x215754,_0x5452b2){if(f(_0x5452b2,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x215754==='.priority')return this['updatePriority'](_0x5452b2);{const _0x519f94=new E(_0x215754,_0x5452b2);let _0x438a6c,_0x2485b5;_0x5452b2['isEmpty']()?(_0x438a6c=this['children_']['remove'](_0x215754),_0x2485b5=this['indexMap_']['removeFromIndexes'](_0x519f94,this['children_'])):(_0x438a6c=this['children_']['insert'](_0x215754,_0x5452b2),_0x2485b5=this['indexMap_']['addToIndexes'](_0x519f94,this['children_']));const _0x16bb00=_0x438a6c['isEmpty']()?It:this['priorityNode_'];return new g(_0x438a6c,_0x16bb00,_0x2485b5);}}['updateChild'](_0xc66a98,_0x525c4f){const _0x15e596=y(_0xc66a98);if(_0x15e596===null)return _0x525c4f;{f(y(_0xc66a98)!=='.priority'||Ce(_0xc66a98)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4d141c=this['getImmediateChild'](_0x15e596)['updateChild'](S(_0xc66a98),_0x525c4f);return this['updateImmediateChild'](_0x15e596,_0x4d141c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2521d8){if(this['isEmpty']())return null;const _0x21dd97={};let _0x2c9dc9=0x0,_0x37541b=0x0,_0x18bd02=!0x0;if(this['forEachChild'](R,(_0x3f8e3d,_0x22d181)=>{_0x21dd97[_0x3f8e3d]=_0x22d181['val'](_0x2521d8),_0x2c9dc9++,_0x18bd02&&g['INTEGER_REGEXP_']['test'](_0x3f8e3d)?_0x37541b=Math['max'](_0x37541b,Number(_0x3f8e3d)):_0x18bd02=!0x1;}),!_0x2521d8&&_0x18bd02&&_0x37541b<0x2*_0x2c9dc9){const _0x387143=[];for(const _0x5576c7 in _0x21dd97)_0x387143[_0x5576c7]=_0x21dd97[_0x5576c7];return _0x387143;}else return _0x2521d8&&!this['getPriority']()['isEmpty']()&&(_0x21dd97['.priority']=this['getPriority']()['val']()),_0x21dd97;}['hash'](){if(this['lazyHash_']===null){let _0x524da5='';this['getPriority']()['isEmpty']()||(_0x524da5+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x41ee33,_0x420f92)=>{const _0x2038dd=_0x420f92['hash']();_0x2038dd!==''&&(_0x524da5+=':'+_0x41ee33+':'+_0x2038dd);}),this['lazyHash_']=_0x524da5===''?'':ro(_0x524da5);}return this['lazyHash_'];}['getPredecessorChildName'](_0x401c3f,_0x53a5f0,_0x30042a){const _0x5b93f3=this['resolveIndex_'](_0x30042a);if(_0x5b93f3){const _0x82c802=_0x5b93f3['getPredecessorKey'](new E(_0x401c3f,_0x53a5f0));return _0x82c802?_0x82c802['name']:null;}else return this['children_']['getPredecessorKey'](_0x401c3f);}['getFirstChildName'](_0x388f87){const _0x329f59=this['resolveIndex_'](_0x388f87);if(_0x329f59){const _0x19ab6e=_0x329f59['minKey']();return _0x19ab6e&&_0x19ab6e['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x114873){const _0x20e6cd=this['getFirstChildName'](_0x114873);return _0x20e6cd?new E(_0x20e6cd,this['children_']['get'](_0x20e6cd)):null;}['getLastChildName'](_0x190077){const _0x5f333c=this['resolveIndex_'](_0x190077);if(_0x5f333c){const _0x1a94d1=_0x5f333c['maxKey']();return _0x1a94d1&&_0x1a94d1['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x56de25){const _0x4b2ecb=this['getLastChildName'](_0x56de25);return _0x4b2ecb?new E(_0x4b2ecb,this['children_']['get'](_0x4b2ecb)):null;}['forEachChild'](_0x31861f,_0x224c12){const _0x211a62=this['resolveIndex_'](_0x31861f);return _0x211a62?_0x211a62['inorderTraversal'](_0x1465cb=>_0x224c12(_0x1465cb['name'],_0x1465cb['node'])):this['children_']['inorderTraversal'](_0x224c12);}['getIterator'](_0x117fbb){return this['getIteratorFrom'](_0x117fbb['minPost'](),_0x117fbb);}['getIteratorFrom'](_0x4752fb,_0x14fdbb){const _0x41a892=this['resolveIndex_'](_0x14fdbb);if(_0x41a892)return _0x41a892['getIteratorFrom'](_0x4752fb,_0x183c1a=>_0x183c1a);{const _0xd283a2=this['children_']['getIteratorFrom'](_0x4752fb['name'],E['Wrap']);let _0x524eff=_0xd283a2['peek']();for(;_0x524eff!=null&&_0x14fdbb['compare'](_0x524eff,_0x4752fb)<0x0;)_0xd283a2['getNext'](),_0x524eff=_0xd283a2['peek']();return _0xd283a2;}}['getReverseIterator'](_0x2ea1ad){return this['getReverseIteratorFrom'](_0x2ea1ad['maxPost'](),_0x2ea1ad);}['getReverseIteratorFrom'](_0x19b976,_0x45bfcf){const _0x3486fe=this['resolveIndex_'](_0x45bfcf);if(_0x3486fe)return _0x3486fe['getReverseIteratorFrom'](_0x19b976,_0x2d4728=>_0x2d4728);{const _0x45ca5b=this['children_']['getReverseIteratorFrom'](_0x19b976['name'],E['Wrap']);let _0x1d458f=_0x45ca5b['peek']();for(;_0x1d458f!=null&&_0x45bfcf['compare'](_0x1d458f,_0x19b976)>0x0;)_0x45ca5b['getNext'](),_0x1d458f=_0x45ca5b['peek']();return _0x45ca5b;}}['compareTo'](_0x2aba79){return this['isEmpty']()?_0x2aba79['isEmpty']()?0x0:-0x1:_0x2aba79['isLeafNode']()||_0x2aba79['isEmpty']()?0x1:_0x2aba79===Kt?-0x1:0x0;}['withIndex'](_0x151837){if(_0x151837===ve||this['indexMap_']['hasIndex'](_0x151837))return this;{const _0xef3b52=this['indexMap_']['addIndex'](_0x151837,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xef3b52);}}['isIndexed'](_0x321ce2){return _0x321ce2===ve||this['indexMap_']['hasIndex'](_0x321ce2);}['equals'](_0x5498ec){if(_0x5498ec===this)return!0x0;if(_0x5498ec['isLeafNode']())return!0x1;{const _0x5ce2d3=_0x5498ec;if(this['getPriority']()['equals'](_0x5ce2d3['getPriority']())){if(this['children_']['count']()===_0x5ce2d3['children_']['count']()){const _0x30ebf8=this['getIterator'](R),_0x4fbfeb=_0x5ce2d3['getIterator'](R);let _0x43c832=_0x30ebf8['getNext'](),_0x20d975=_0x4fbfeb['getNext']();for(;_0x43c832&&_0x20d975;){if(_0x43c832['name']!==_0x20d975['name']||!_0x43c832['node']['equals'](_0x20d975['node']))return!0x1;_0x43c832=_0x30ebf8['getNext'](),_0x20d975=_0x4fbfeb['getNext']();}return _0x43c832===null&&_0x20d975===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x284a81){return _0x284a81===ve?null:this['indexMap_']['get'](_0x284a81['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x5d5ed7){return _0x5d5ed7===this?0x0:0x1;}['equals'](_0x5620fd){return _0x5620fd===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3ccd72){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x30a5b9,_0x1a4abc=null){if(_0x30a5b9===null)return g['EMPTY_NODE'];if(typeof _0x30a5b9=='object'&&'.priority'in _0x30a5b9&&(_0x1a4abc=_0x30a5b9['.priority']),f(_0x1a4abc===null||typeof _0x1a4abc=='string'||typeof _0x1a4abc=='number'||typeof _0x1a4abc=='object'&&'.sv'in _0x1a4abc,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1a4abc),typeof _0x30a5b9=='object'&&'.value'in _0x30a5b9&&_0x30a5b9['.value']!==null&&(_0x30a5b9=_0x30a5b9['.value']),typeof _0x30a5b9!='object'||'.sv'in _0x30a5b9){const _0x3c42ea=_0x30a5b9;return new D(_0x3c42ea,A(_0x1a4abc));}if(!(_0x30a5b9 instanceof Array)&&Gh){const _0x8c55de=[];let _0xdc239a=!0x1;if(x(_0x30a5b9,(_0x30bb6b,_0x2ca3f6)=>{if(_0x30bb6b['substring'](0x0,0x1)!=='.'){const _0x5e683c=A(_0x2ca3f6);_0x5e683c['isEmpty']()||(_0xdc239a=_0xdc239a||!_0x5e683c['getPriority']()['isEmpty'](),_0x8c55de['push'](new E(_0x30bb6b,_0x5e683c)));}}),_0x8c55de['length']===0x0)return g['EMPTY_NODE'];const _0x37081f=yn(_0x8c55de,xh,_0x241a93=>_0x241a93['name'],Qi);if(_0xdc239a){const _0x15291e=yn(_0x8c55de,R['getCompare']());return new g(_0x37081f,A(_0x1a4abc),new te({'.priority':_0x15291e},{'.priority':R}));}else return new g(_0x37081f,A(_0x1a4abc),te['Default']);}else{let _0x57cd49=g['EMPTY_NODE'];return x(_0x30a5b9,(_0x4e172e,_0x35b728)=>{if(Q(_0x30a5b9,_0x4e172e)&&_0x4e172e['substring'](0x0,0x1)!=='.'){const _0x582e91=A(_0x35b728);(_0x582e91['isLeafNode']()||!_0x582e91['isEmpty']())&&(_0x57cd49=_0x57cd49['updateImmediateChild'](_0x4e172e,_0x582e91));}}),_0x57cd49['updatePriority'](A(_0x1a4abc));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x3c5d6a){super(),this['indexPath_']=_0x3c5d6a,f(!v(_0x3c5d6a)&&y(_0x3c5d6a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4f440d){return _0x4f440d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1d5c5d){return!_0x1d5c5d['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x53bf02,_0x4843d2){const _0x258038=this['extractChild'](_0x53bf02['node']),_0x7e53be=this['extractChild'](_0x4843d2['node']),_0x182502=_0x258038['compareTo'](_0x7e53be);return _0x182502===0x0?qe(_0x53bf02['name'],_0x4843d2['name']):_0x182502;}['makePost'](_0x3c713c,_0x18553e){const _0x4631f3=A(_0x3c713c),_0x52639a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4631f3);return new E(_0x18553e,_0x52639a);}['maxPost'](){const _0x516e96=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x516e96);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x35b406,_0x969938){const _0x240ebf=_0x35b406['node']['compareTo'](_0x969938['node']);return _0x240ebf===0x0?qe(_0x35b406['name'],_0x969938['name']):_0x240ebf;}['isDefinedOn'](_0x2a7f6){return!0x0;}['indexedValueChanged'](_0x213984,_0x3e92b0){return!_0x213984['equals'](_0x3e92b0);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xbd9891,_0x2369ea){const _0x421dd1=A(_0xbd9891);return new E(_0x2369ea,_0x421dd1);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x2b595a){return{'type':'value','snapshotNode':_0x2b595a};}function rt(_0x568ec2,_0xdea50d){return{'type':'child_added','snapshotNode':_0xdea50d,'childName':_0x568ec2};}function Lt(_0x33fecc,_0xd50958){return{'type':'child_removed','snapshotNode':_0xd50958,'childName':_0x33fecc};}function xt(_0x42a60d,_0x106653,_0x422d1d){return{'type':'child_changed','snapshotNode':_0x106653,'childName':_0x42a60d,'oldSnap':_0x422d1d};}function zh(_0x3f3135,_0x2ed64c){return{'type':'child_moved','snapshotNode':_0x2ed64c,'childName':_0x3f3135};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4e5862){this['index_']=_0x4e5862;}['updateChild'](_0x51ede4,_0x35d431,_0x58b8f2,_0x402e93,_0x13c6be,_0x218f60){f(_0x51ede4['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3ec034=_0x51ede4['getImmediateChild'](_0x35d431);return _0x3ec034['getChild'](_0x402e93)['equals'](_0x58b8f2['getChild'](_0x402e93))&&_0x3ec034['isEmpty']()===_0x58b8f2['isEmpty']()||(_0x218f60!=null&&(_0x58b8f2['isEmpty']()?_0x51ede4['hasChild'](_0x35d431)?_0x218f60['trackChildChange'](Lt(_0x35d431,_0x3ec034)):f(_0x51ede4['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3ec034['isEmpty']()?_0x218f60['trackChildChange'](rt(_0x35d431,_0x58b8f2)):_0x218f60['trackChildChange'](xt(_0x35d431,_0x58b8f2,_0x3ec034))),_0x51ede4['isLeafNode']()&&_0x58b8f2['isEmpty']())?_0x51ede4:_0x51ede4['updateImmediateChild'](_0x35d431,_0x58b8f2)['withIndex'](this['index_']);}['updateFullNode'](_0x5eedd5,_0x35b864,_0x2d3b22){return _0x2d3b22!=null&&(_0x5eedd5['isLeafNode']()||_0x5eedd5['forEachChild'](R,(_0x4d826d,_0x473114)=>{_0x35b864['hasChild'](_0x4d826d)||_0x2d3b22['trackChildChange'](Lt(_0x4d826d,_0x473114));}),_0x35b864['isLeafNode']()||_0x35b864['forEachChild'](R,(_0x4df867,_0x1ca944)=>{if(_0x5eedd5['hasChild'](_0x4df867)){const _0x1d7b94=_0x5eedd5['getImmediateChild'](_0x4df867);_0x1d7b94['equals'](_0x1ca944)||_0x2d3b22['trackChildChange'](xt(_0x4df867,_0x1ca944,_0x1d7b94));}else _0x2d3b22['trackChildChange'](rt(_0x4df867,_0x1ca944));})),_0x35b864['withIndex'](this['index_']);}['updatePriority'](_0x2956fc,_0x54b7a8){return _0x2956fc['isEmpty']()?g['EMPTY_NODE']:_0x2956fc['updatePriority'](_0x54b7a8);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x23142e){this['indexedFilter_']=new Xi(_0x23142e['getIndex']()),this['index_']=_0x23142e['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x23142e),this['endPost_']=Ft['getEndPost_'](_0x23142e),this['startIsInclusive_']=!_0x23142e['startAfterSet_'],this['endIsInclusive_']=!_0x23142e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1e7114){const _0x3c0280=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1e7114)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1e7114)<0x0,_0x3bd3fb=this['endIsInclusive_']?this['index_']['compare'](_0x1e7114,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1e7114,this['getEndPost']())<0x0;return _0x3c0280&&_0x3bd3fb;}['updateChild'](_0x54ed38,_0x2db494,_0x5b62c7,_0x588564,_0x2eb12e,_0x565d89){return this['matches'](new E(_0x2db494,_0x5b62c7))||(_0x5b62c7=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x54ed38,_0x2db494,_0x5b62c7,_0x588564,_0x2eb12e,_0x565d89);}['updateFullNode'](_0x3d2105,_0x243192,_0x487367){_0x243192['isLeafNode']()&&(_0x243192=g['EMPTY_NODE']);let _0xcc4cb5=_0x243192['withIndex'](this['index_']);_0xcc4cb5=_0xcc4cb5['updatePriority'](g['EMPTY_NODE']);const _0x4642c1=this;return _0x243192['forEachChild'](R,(_0x50056d,_0x3e21f2)=>{_0x4642c1['matches'](new E(_0x50056d,_0x3e21f2))||(_0xcc4cb5=_0xcc4cb5['updateImmediateChild'](_0x50056d,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3d2105,_0xcc4cb5,_0x487367);}['updatePriority'](_0x2a3653,_0x5e9e1e){return _0x2a3653;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4a9b49){if(_0x4a9b49['hasStart']()){const _0x41b1e5=_0x4a9b49['getIndexStartName']();return _0x4a9b49['getIndex']()['makePost'](_0x4a9b49['getIndexStartValue'](),_0x41b1e5);}else return _0x4a9b49['getIndex']()['minPost']();}static['getEndPost_'](_0x4e351a){if(_0x4e351a['hasEnd']()){const _0x25fcb5=_0x4e351a['getIndexEndName']();return _0x4e351a['getIndex']()['makePost'](_0x4e351a['getIndexEndValue'](),_0x25fcb5);}else return _0x4e351a['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1bac46){this['withinDirectionalStart']=_0x276087=>this['reverse_']?this['withinEndPost'](_0x276087):this['withinStartPost'](_0x276087),this['withinDirectionalEnd']=_0x2106eb=>this['reverse_']?this['withinStartPost'](_0x2106eb):this['withinEndPost'](_0x2106eb),this['withinStartPost']=_0x233cb0=>{const _0x1e7312=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x233cb0);return this['startIsInclusive_']?_0x1e7312<=0x0:_0x1e7312<0x0;},this['withinEndPost']=_0x3c3622=>{const _0x146065=this['index_']['compare'](_0x3c3622,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x146065<=0x0:_0x146065<0x0;},this['rangedFilter_']=new Ft(_0x1bac46),this['index_']=_0x1bac46['getIndex'](),this['limit_']=_0x1bac46['getLimit'](),this['reverse_']=!_0x1bac46['isViewFromLeft'](),this['startIsInclusive_']=!_0x1bac46['startAfterSet_'],this['endIsInclusive_']=!_0x1bac46['endBeforeSet_'];}['updateChild'](_0x5544e4,_0xefd479,_0x3af68f,_0x723eec,_0x25290f,_0x11efdb){return this['rangedFilter_']['matches'](new E(_0xefd479,_0x3af68f))||(_0x3af68f=g['EMPTY_NODE']),_0x5544e4['getImmediateChild'](_0xefd479)['equals'](_0x3af68f)?_0x5544e4:_0x5544e4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5544e4,_0xefd479,_0x3af68f,_0x723eec,_0x25290f,_0x11efdb):this['fullLimitUpdateChild_'](_0x5544e4,_0xefd479,_0x3af68f,_0x25290f,_0x11efdb);}['updateFullNode'](_0x54f9ce,_0x3dcd43,_0x16a669){let _0x88bb1c;if(_0x3dcd43['isLeafNode']()||_0x3dcd43['isEmpty']())_0x88bb1c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x3dcd43['numChildren']()&&_0x3dcd43['isIndexed'](this['index_'])){_0x88bb1c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3c857a;this['reverse_']?_0x3c857a=_0x3dcd43['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3c857a=_0x3dcd43['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xb9038f=0x0;for(;_0x3c857a['hasNext']()&&_0xb9038f<this['limit_'];){const _0x96951f=_0x3c857a['getNext']();if(this['withinDirectionalStart'](_0x96951f)){if(this['withinDirectionalEnd'](_0x96951f))_0x88bb1c=_0x88bb1c['updateImmediateChild'](_0x96951f['name'],_0x96951f['node']),_0xb9038f++;else break;}else continue;}}else{_0x88bb1c=_0x3dcd43['withIndex'](this['index_']),_0x88bb1c=_0x88bb1c['updatePriority'](g['EMPTY_NODE']);let _0x4eaee4;this['reverse_']?_0x4eaee4=_0x88bb1c['getReverseIterator'](this['index_']):_0x4eaee4=_0x88bb1c['getIterator'](this['index_']);let _0x20a541=0x0;for(;_0x4eaee4['hasNext']();){const _0x34dfcb=_0x4eaee4['getNext']();_0x20a541<this['limit_']&&this['withinDirectionalStart'](_0x34dfcb)&&this['withinDirectionalEnd'](_0x34dfcb)?_0x20a541++:_0x88bb1c=_0x88bb1c['updateImmediateChild'](_0x34dfcb['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x54f9ce,_0x88bb1c,_0x16a669);}['updatePriority'](_0x5c8404,_0x561a6f){return _0x5c8404;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2675dd,_0x330563,_0x20be7a,_0x3d3edf,_0x56c060){let _0x403471;if(this['reverse_']){const _0x20cdc5=this['index_']['getCompare']();_0x403471=(_0x48f644,_0x1fb809)=>_0x20cdc5(_0x1fb809,_0x48f644);}else _0x403471=this['index_']['getCompare']();const _0x2e63ee=_0x2675dd;f(_0x2e63ee['numChildren']()===this['limit_'],'');const _0x2ca2fb=new E(_0x330563,_0x20be7a),_0x3be3b1=this['reverse_']?_0x2e63ee['getFirstChild'](this['index_']):_0x2e63ee['getLastChild'](this['index_']),_0x557d72=this['rangedFilter_']['matches'](_0x2ca2fb);if(_0x2e63ee['hasChild'](_0x330563)){const _0x53776b=_0x2e63ee['getImmediateChild'](_0x330563);let _0x3cf5f3=_0x3d3edf['getChildAfterChild'](this['index_'],_0x3be3b1,this['reverse_']);for(;_0x3cf5f3!=null&&(_0x3cf5f3['name']===_0x330563||_0x2e63ee['hasChild'](_0x3cf5f3['name']));)_0x3cf5f3=_0x3d3edf['getChildAfterChild'](this['index_'],_0x3cf5f3,this['reverse_']);const _0x32ab41=_0x3cf5f3==null?0x1:_0x403471(_0x3cf5f3,_0x2ca2fb);if(_0x557d72&&!_0x20be7a['isEmpty']()&&_0x32ab41>=0x0)return _0x56c060!=null&&_0x56c060['trackChildChange'](xt(_0x330563,_0x20be7a,_0x53776b)),_0x2e63ee['updateImmediateChild'](_0x330563,_0x20be7a);{_0x56c060!=null&&_0x56c060['trackChildChange'](Lt(_0x330563,_0x53776b));const _0x3ccb37=_0x2e63ee['updateImmediateChild'](_0x330563,g['EMPTY_NODE']);return _0x3cf5f3!=null&&this['rangedFilter_']['matches'](_0x3cf5f3)?(_0x56c060!=null&&_0x56c060['trackChildChange'](rt(_0x3cf5f3['name'],_0x3cf5f3['node'])),_0x3ccb37['updateImmediateChild'](_0x3cf5f3['name'],_0x3cf5f3['node'])):_0x3ccb37;}}else return _0x20be7a['isEmpty']()?_0x2675dd:_0x557d72&&_0x403471(_0x3be3b1,_0x2ca2fb)>=0x0?(_0x56c060!=null&&(_0x56c060['trackChildChange'](Lt(_0x3be3b1['name'],_0x3be3b1['node'])),_0x56c060['trackChildChange'](rt(_0x330563,_0x20be7a))),_0x2e63ee['updateImmediateChild'](_0x330563,_0x20be7a)['updateImmediateChild'](_0x3be3b1['name'],g['EMPTY_NODE'])):_0x2675dd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x377aad=new Zi();return _0x377aad['limitSet_']=this['limitSet_'],_0x377aad['limit_']=this['limit_'],_0x377aad['startSet_']=this['startSet_'],_0x377aad['startAfterSet_']=this['startAfterSet_'],_0x377aad['indexStartValue_']=this['indexStartValue_'],_0x377aad['startNameSet_']=this['startNameSet_'],_0x377aad['indexStartName_']=this['indexStartName_'],_0x377aad['endSet_']=this['endSet_'],_0x377aad['endBeforeSet_']=this['endBeforeSet_'],_0x377aad['indexEndValue_']=this['indexEndValue_'],_0x377aad['endNameSet_']=this['endNameSet_'],_0x377aad['indexEndName_']=this['indexEndName_'],_0x377aad['index_']=this['index_'],_0x377aad['viewFrom_']=this['viewFrom_'],_0x377aad;}}function Kh(_0x15555f){return _0x15555f['loadsAllData']()?new Xi(_0x15555f['getIndex']()):_0x15555f['hasLimit']()?new jh(_0x15555f):new Ft(_0x15555f);}function Yh(_0x2247d6,_0x1cc589){const _0x3d62f3=_0x2247d6['copy']();return _0x3d62f3['limitSet_']=!0x0,_0x3d62f3['limit_']=_0x1cc589,_0x3d62f3['viewFrom_']='l',_0x3d62f3;}function Qh(_0x2e964e,_0x1b411b,_0x34863a){const _0x481260=_0x2e964e['copy']();return _0x481260['startSet_']=!0x0,_0x1b411b===void 0x0&&(_0x1b411b=null),_0x481260['indexStartValue_']=_0x1b411b,_0x34863a!=null?(_0x481260['startNameSet_']=!0x0,_0x481260['indexStartName_']=_0x34863a):(_0x481260['startNameSet_']=!0x1,_0x481260['indexStartName_']=''),_0x481260;}function Jh(_0x558cd0,_0x3cdc52,_0x4c1cf8){const _0x249dd4=_0x558cd0['copy']();return _0x249dd4['endSet_']=!0x0,_0x3cdc52===void 0x0&&(_0x3cdc52=null),_0x249dd4['indexEndValue_']=_0x3cdc52,_0x4c1cf8!==void 0x0?(_0x249dd4['endNameSet_']=!0x0,_0x249dd4['indexEndName_']=_0x4c1cf8):(_0x249dd4['endNameSet_']=!0x1,_0x249dd4['indexEndName_']=''),_0x249dd4;}function xo(_0x26152e,_0x40649f){const _0x22f218=_0x26152e['copy']();return _0x22f218['index_']=_0x40649f,_0x22f218;}function ir(_0x5b1e92){const _0x3b0cb3={};if(_0x5b1e92['isDefault']())return _0x3b0cb3;let _0x4454ce;if(_0x5b1e92['index_']===R?_0x4454ce='$priority':_0x5b1e92['index_']===Mo?_0x4454ce='$value':_0x5b1e92['index_']===ve?_0x4454ce='$key':(f(_0x5b1e92['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4454ce=_0x5b1e92['index_']['toString']()),_0x3b0cb3['orderBy']=O(_0x4454ce),_0x5b1e92['startSet_']){const _0xe26c6c=_0x5b1e92['startAfterSet_']?'startAfter':'startAt';_0x3b0cb3[_0xe26c6c]=O(_0x5b1e92['indexStartValue_']),_0x5b1e92['startNameSet_']&&(_0x3b0cb3[_0xe26c6c]+=','+O(_0x5b1e92['indexStartName_']));}if(_0x5b1e92['endSet_']){const _0x1fd079=_0x5b1e92['endBeforeSet_']?'endBefore':'endAt';_0x3b0cb3[_0x1fd079]=O(_0x5b1e92['indexEndValue_']),_0x5b1e92['endNameSet_']&&(_0x3b0cb3[_0x1fd079]+=','+O(_0x5b1e92['indexEndName_']));}return _0x5b1e92['limitSet_']&&(_0x5b1e92['isViewFromLeft']()?_0x3b0cb3['limitToFirst']=_0x5b1e92['limit_']:_0x3b0cb3['limitToLast']=_0x5b1e92['limit_']),_0x3b0cb3;}function sr(_0x37fef4){const _0x17f349={};if(_0x37fef4['startSet_']&&(_0x17f349['sp']=_0x37fef4['indexStartValue_'],_0x37fef4['startNameSet_']&&(_0x17f349['sn']=_0x37fef4['indexStartName_']),_0x17f349['sin']=!_0x37fef4['startAfterSet_']),_0x37fef4['endSet_']&&(_0x17f349['ep']=_0x37fef4['indexEndValue_'],_0x37fef4['endNameSet_']&&(_0x17f349['en']=_0x37fef4['indexEndName_']),_0x17f349['ein']=!_0x37fef4['endBeforeSet_']),_0x37fef4['limitSet_']){_0x17f349['l']=_0x37fef4['limit_'];let _0x1aeb59=_0x37fef4['viewFrom_'];_0x1aeb59===''&&(_0x37fef4['isViewFromLeft']()?_0x1aeb59='l':_0x1aeb59='r'),_0x17f349['vf']=_0x1aeb59;}return _0x37fef4['index_']!==R&&(_0x17f349['i']=_0x37fef4['index_']['toString']()),_0x17f349;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x365730){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x109624,_0x2bb536){return _0x2bb536!==void 0x0?'tag$'+_0x2bb536:(f(_0x109624['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x109624['_path']['toString']());}constructor(_0x3ad1ac,_0xd36550,_0x14098d,_0x35537e){super(),this['repoInfo_']=_0x3ad1ac,this['onDataUpdate_']=_0xd36550,this['authTokenProvider_']=_0x14098d,this['appCheckTokenProvider_']=_0x35537e,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x5220f6,_0x30d0ee,_0x42722a,_0x70543d){const _0xdda21a=_0x5220f6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xdda21a+'\x20'+_0x5220f6['_queryIdentifier']);const _0x32bf71=vn['getListenId_'](_0x5220f6,_0x42722a),_0x10b6fd={};this['listens_'][_0x32bf71]=_0x10b6fd;const _0x1b215e=ir(_0x5220f6['_queryParams']);this['restRequest_'](_0xdda21a+'.json',_0x1b215e,(_0x30dc3f,_0x479f53)=>{let _0x597a03=_0x479f53;if(_0x30dc3f===0x194&&(_0x597a03=null,_0x30dc3f=null),_0x30dc3f===null&&this['onDataUpdate_'](_0xdda21a,_0x597a03,!0x1,_0x42722a),Le(this['listens_'],_0x32bf71)===_0x10b6fd){let _0x4a74c5;_0x30dc3f?_0x30dc3f===0x191?_0x4a74c5='permission_denied':_0x4a74c5='rest_error:'+_0x30dc3f:_0x4a74c5='ok',_0x70543d(_0x4a74c5,null);}});}['unlisten'](_0x4dc188,_0x20ec83){const _0x3d2970=vn['getListenId_'](_0x4dc188,_0x20ec83);delete this['listens_'][_0x3d2970];}['get'](_0x4ddd5e){const _0x49bb1d=ir(_0x4ddd5e['_queryParams']),_0x259f80=_0x4ddd5e['_path']['toString'](),_0xca2e0e=new H();return this['restRequest_'](_0x259f80+'.json',_0x49bb1d,(_0x2a2b64,_0x200f8c)=>{let _0x3700dc=_0x200f8c;_0x2a2b64===0x194&&(_0x3700dc=null,_0x2a2b64=null),_0x2a2b64===null?(this['onDataUpdate_'](_0x259f80,_0x3700dc,!0x1,null),_0xca2e0e['resolve'](_0x3700dc)):_0xca2e0e['reject'](new Error(_0x3700dc));}),_0xca2e0e['promise'];}['refreshAuthToken'](_0x44d7c0){}['restRequest_'](_0x2b4be5,_0x1e6caa={},_0x4ba3c6){return _0x1e6caa['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x488f03,_0x5b6b52])=>{_0x488f03&&_0x488f03['accessToken']&&(_0x1e6caa['auth']=_0x488f03['accessToken']),_0x5b6b52&&_0x5b6b52['token']&&(_0x1e6caa['ac']=_0x5b6b52['token']);const _0x17fa87=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2b4be5+'?ns='+this['repoInfo_']['namespace']+ut(_0x1e6caa);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x17fa87);const _0x25caae=new XMLHttpRequest();_0x25caae['onreadystatechange']=()=>{if(_0x4ba3c6&&_0x25caae['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x17fa87+'\x20received.\x20status:',_0x25caae['status'],'response:',_0x25caae['responseText']);let _0xbec575=null;if(_0x25caae['status']>=0xc8&&_0x25caae['status']<0x12c){try{_0xbec575=Nt(_0x25caae['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x17fa87+':\x20'+_0x25caae['responseText']);}_0x4ba3c6(null,_0xbec575);}else _0x25caae['status']!==0x191&&_0x25caae['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x17fa87+'\x20Status:\x20'+_0x25caae['status']),_0x4ba3c6(_0x25caae['status']);_0x4ba3c6=null;}},_0x25caae['open']('GET',_0x17fa87,!0x0),_0x25caae['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x45d0c3){return this['rootNode_']['getChild'](_0x45d0c3);}['updateSnapshot'](_0xa50d67,_0x32b8b4){this['rootNode_']=this['rootNode_']['updateChild'](_0xa50d67,_0x32b8b4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x1505b1,_0x178c5d,_0x7e5591){if(v(_0x178c5d))_0x1505b1['value']=_0x7e5591,_0x1505b1['children']['clear']();else{if(_0x1505b1['value']!==null)_0x1505b1['value']=_0x1505b1['value']['updateChild'](_0x178c5d,_0x7e5591);else{const _0x16155f=y(_0x178c5d);_0x1505b1['children']['has'](_0x16155f)||_0x1505b1['children']['set'](_0x16155f,En());const _0x1e986c=_0x1505b1['children']['get'](_0x16155f);_0x178c5d=S(_0x178c5d),pt(_0x1e986c,_0x178c5d,_0x7e5591);}}}function Ti(_0x2ab5a9,_0x3fb3e3){if(v(_0x3fb3e3))return _0x2ab5a9['value']=null,_0x2ab5a9['children']['clear'](),!0x0;if(_0x2ab5a9['value']!==null){if(_0x2ab5a9['value']['isLeafNode']())return!0x1;{const _0x238541=_0x2ab5a9['value'];return _0x2ab5a9['value']=null,_0x238541['forEachChild'](R,(_0x2c3576,_0x4a8c1e)=>{pt(_0x2ab5a9,new C(_0x2c3576),_0x4a8c1e);}),Ti(_0x2ab5a9,_0x3fb3e3);}}else{if(_0x2ab5a9['children']['size']>0x0){const _0x47544b=y(_0x3fb3e3);return _0x3fb3e3=S(_0x3fb3e3),_0x2ab5a9['children']['has'](_0x47544b)&&Ti(_0x2ab5a9['children']['get'](_0x47544b),_0x3fb3e3)&&_0x2ab5a9['children']['delete'](_0x47544b),_0x2ab5a9['children']['size']===0x0;}else return!0x0;}}function Si(_0x4e3582,_0x3292e6,_0x20520c){_0x4e3582['value']!==null?_0x20520c(_0x3292e6,_0x4e3582['value']):Zh(_0x4e3582,(_0x17c72e,_0x3ae3cd)=>{const _0x380fbe=new C(_0x3292e6['toString']()+'/'+_0x17c72e);Si(_0x3ae3cd,_0x380fbe,_0x20520c);});}function Zh(_0x378c75,_0x5006f8){_0x378c75['children']['forEach']((_0x40189a,_0x3bf831)=>{_0x5006f8(_0x3bf831,_0x40189a);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x523563){this['collection_']=_0x523563,this['last_']=null;}['get'](){const _0x3a2b89=this['collection_']['get'](),_0x5f5d9a={..._0x3a2b89};return this['last_']&&x(this['last_'],(_0x247857,_0x249d71)=>{_0x5f5d9a[_0x247857]=_0x5f5d9a[_0x247857]-_0x249d71;}),this['last_']=_0x3a2b89,_0x5f5d9a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x124d53,_0x126c77){this['server_']=_0x126c77,this['statsToReport_']={},this['statsListener_']=new eu(_0x124d53);const _0x379ae0=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x379ae0));}['reportStats_'](){const _0x91b82a=this['statsListener_']['get'](),_0x542eab={};let _0x2afda5=!0x1;x(_0x91b82a,(_0x259c2d,_0x233e29)=>{_0x233e29>0x0&&Q(this['statsToReport_'],_0x259c2d)&&(_0x542eab[_0x259c2d]=_0x233e29,_0x2afda5=!0x0);}),_0x2afda5&&this['server_']['reportStats'](_0x542eab),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x205f27){_0x205f27[_0x205f27['OVERWRITE']=0x0]='OVERWRITE',_0x205f27[_0x205f27['MERGE']=0x1]='MERGE',_0x205f27[_0x205f27['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x205f27[_0x205f27['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1224ba){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1224ba,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x52b01b,_0x1cca67,_0x2613e3){this['path']=_0x52b01b,this['affectedTree']=_0x1cca67,this['revert']=_0x2613e3,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x50575a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4d6a20=this['affectedTree']['subtree'](new C(_0x50575a));return new In(w(),_0x4d6a20,this['revert']);}}else return f(y(this['path'])===_0x50575a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x20bcd5,_0x478872){this['source']=_0x20bcd5,this['path']=_0x478872,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x131e86){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x45b37f,_0x43424c,_0x460dd4){this['source']=_0x45b37f,this['path']=_0x43424c,this['snap']=_0x460dd4,this['type']=z['OVERWRITE'];}['operationForChild'](_0xd9f118){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xd9f118)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x36f7d1,_0x43ea88,_0x3c62ef){this['source']=_0x36f7d1,this['path']=_0x43ea88,this['children']=_0x3c62ef,this['type']=z['MERGE'];}['operationForChild'](_0x479ea9){if(v(this['path'])){const _0x5b689a=this['children']['subtree'](new C(_0x479ea9));return _0x5b689a['isEmpty']()?null:_0x5b689a['value']?new Be(this['source'],w(),_0x5b689a['value']):new ot(this['source'],w(),_0x5b689a);}else return f(y(this['path'])===_0x479ea9,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0xe28f2f,_0x324c0a,_0x371c7f){this['node_']=_0xe28f2f,this['fullyInitialized_']=_0x324c0a,this['filtered_']=_0x371c7f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4bef26){if(v(_0x4bef26))return this['isFullyInitialized']()&&!this['filtered_'];const _0x53dff9=y(_0x4bef26);return this['isCompleteForChild'](_0x53dff9);}['isCompleteForChild'](_0x3eda76){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3eda76);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2470c1){this['query_']=_0x2470c1,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x16ecd9,_0x2b0d81,_0xda6aef,_0x10cde8){const _0x9bcf14=[],_0x4afdc1=[];return _0x2b0d81['forEach'](_0x4add23=>{_0x4add23['type']==='child_changed'&&_0x16ecd9['index_']['indexedValueChanged'](_0x4add23['oldSnap'],_0x4add23['snapshotNode'])&&_0x4afdc1['push'](zh(_0x4add23['childName'],_0x4add23['snapshotNode']));}),wt(_0x16ecd9,_0x9bcf14,'child_removed',_0x2b0d81,_0x10cde8,_0xda6aef),wt(_0x16ecd9,_0x9bcf14,'child_added',_0x2b0d81,_0x10cde8,_0xda6aef),wt(_0x16ecd9,_0x9bcf14,'child_moved',_0x4afdc1,_0x10cde8,_0xda6aef),wt(_0x16ecd9,_0x9bcf14,'child_changed',_0x2b0d81,_0x10cde8,_0xda6aef),wt(_0x16ecd9,_0x9bcf14,'value',_0x2b0d81,_0x10cde8,_0xda6aef),_0x9bcf14;}function wt(_0x170ac6,_0x3eadbd,_0x21d5b5,_0x9afaf8,_0x533763,_0x5f186a){const _0x5c0f3a=_0x9afaf8['filter'](_0x407b41=>_0x407b41['type']===_0x21d5b5);_0x5c0f3a['sort']((_0x583963,_0x1eec4a)=>au(_0x170ac6,_0x583963,_0x1eec4a)),_0x5c0f3a['forEach'](_0xd37bfc=>{const _0x575ccb=ou(_0x170ac6,_0xd37bfc,_0x5f186a);_0x533763['forEach'](_0x440c7f=>{_0x440c7f['respondsTo'](_0xd37bfc['type'])&&_0x3eadbd['push'](_0x440c7f['createEvent'](_0x575ccb,_0x170ac6['query_']));});});}function ou(_0x5a8ad7,_0x34bd5e,_0xc98fb0){return _0x34bd5e['type']==='value'||_0x34bd5e['type']==='child_removed'||(_0x34bd5e['prevName']=_0xc98fb0['getPredecessorChildName'](_0x34bd5e['childName'],_0x34bd5e['snapshotNode'],_0x5a8ad7['index_'])),_0x34bd5e;}function au(_0x574af4,_0x7d7c43,_0x272888){if(_0x7d7c43['childName']==null||_0x272888['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1e960e=new E(_0x7d7c43['childName'],_0x7d7c43['snapshotNode']),_0x31da2f=new E(_0x272888['childName'],_0x272888['snapshotNode']);return _0x574af4['index_']['compare'](_0x1e960e,_0x31da2f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2056b1,_0x55e540){return{'eventCache':_0x2056b1,'serverCache':_0x55e540};}function Rt(_0x351891,_0x7341ee,_0x4c5187,_0x2d7943){return Un(new Te(_0x7341ee,_0x4c5187,_0x2d7943),_0x351891['serverCache']);}function Fo(_0x4896d3,_0x533eb5,_0x222e32,_0x1bcb6c){return Un(_0x4896d3['eventCache'],new Te(_0x533eb5,_0x222e32,_0x1bcb6c));}function wn(_0x44a3a8){return _0x44a3a8['eventCache']['isFullyInitialized']()?_0x44a3a8['eventCache']['getNode']():null;}function Ve(_0x343a87){return _0x343a87['serverCache']['isFullyInitialized']()?_0x343a87['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x359935){let _0x59f28c=new b(null);return x(_0x359935,(_0x5e2d8e,_0x5502fc)=>{_0x59f28c=_0x59f28c['set'](new C(_0x5e2d8e),_0x5502fc);}),_0x59f28c;}constructor(_0x1daf10,_0x1f0e65=cu()){this['value']=_0x1daf10,this['children']=_0x1f0e65;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x574016,_0x3a69d7){if(this['value']!=null&&_0x3a69d7(this['value']))return{'path':w(),'value':this['value']};if(v(_0x574016))return null;{const _0x34ae91=y(_0x574016),_0x213158=this['children']['get'](_0x34ae91);if(_0x213158!==null){const _0x4d2930=_0x213158['findRootMostMatchingPathAndValue'](S(_0x574016),_0x3a69d7);return _0x4d2930!=null?{'path':k(new C(_0x34ae91),_0x4d2930['path']),'value':_0x4d2930['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x10c502){return this['findRootMostMatchingPathAndValue'](_0x10c502,()=>!0x0);}['subtree'](_0x33b173){if(v(_0x33b173))return this;{const _0x5f0ab9=y(_0x33b173),_0x38b732=this['children']['get'](_0x5f0ab9);return _0x38b732!==null?_0x38b732['subtree'](S(_0x33b173)):new b(null);}}['set'](_0x1bf067,_0x321ee9){if(v(_0x1bf067))return new b(_0x321ee9,this['children']);{const _0x330417=y(_0x1bf067),_0x12cfda=(this['children']['get'](_0x330417)||new b(null))['set'](S(_0x1bf067),_0x321ee9),_0x2e654a=this['children']['insert'](_0x330417,_0x12cfda);return new b(this['value'],_0x2e654a);}}['remove'](_0x27cedc){if(v(_0x27cedc))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x30afce=y(_0x27cedc),_0x29e1a0=this['children']['get'](_0x30afce);if(_0x29e1a0){const _0x5d9134=_0x29e1a0['remove'](S(_0x27cedc));let _0x3eff0a;return _0x5d9134['isEmpty']()?_0x3eff0a=this['children']['remove'](_0x30afce):_0x3eff0a=this['children']['insert'](_0x30afce,_0x5d9134),this['value']===null&&_0x3eff0a['isEmpty']()?new b(null):new b(this['value'],_0x3eff0a);}else return this;}}['get'](_0x4e07a5){if(v(_0x4e07a5))return this['value'];{const _0xcb4e41=y(_0x4e07a5),_0x15c479=this['children']['get'](_0xcb4e41);return _0x15c479?_0x15c479['get'](S(_0x4e07a5)):null;}}['setTree'](_0x6eeb0b,_0x3b472b){if(v(_0x6eeb0b))return _0x3b472b;{const _0x419e65=y(_0x6eeb0b),_0x2b68ed=(this['children']['get'](_0x419e65)||new b(null))['setTree'](S(_0x6eeb0b),_0x3b472b);let _0x4777ce;return _0x2b68ed['isEmpty']()?_0x4777ce=this['children']['remove'](_0x419e65):_0x4777ce=this['children']['insert'](_0x419e65,_0x2b68ed),new b(this['value'],_0x4777ce);}}['fold'](_0x5adb69){return this['fold_'](w(),_0x5adb69);}['fold_'](_0x4e363a,_0x5e891a){const _0x11a316={};return this['children']['inorderTraversal']((_0x179946,_0x4bf88f)=>{_0x11a316[_0x179946]=_0x4bf88f['fold_'](k(_0x4e363a,_0x179946),_0x5e891a);}),_0x5e891a(_0x4e363a,this['value'],_0x11a316);}['findOnPath'](_0x2fad8b,_0x19a0f6){return this['findOnPath_'](_0x2fad8b,w(),_0x19a0f6);}['findOnPath_'](_0x51eb82,_0x54ef1f,_0x554eb4){const _0x3af9d9=this['value']?_0x554eb4(_0x54ef1f,this['value']):!0x1;if(_0x3af9d9)return _0x3af9d9;if(v(_0x51eb82))return null;{const _0x8f7eec=y(_0x51eb82),_0x400f92=this['children']['get'](_0x8f7eec);return _0x400f92?_0x400f92['findOnPath_'](S(_0x51eb82),k(_0x54ef1f,_0x8f7eec),_0x554eb4):null;}}['foreachOnPath'](_0x4acaf8,_0x58701c){return this['foreachOnPath_'](_0x4acaf8,w(),_0x58701c);}['foreachOnPath_'](_0x1dff54,_0x81abc7,_0x10f34e){if(v(_0x1dff54))return this;{this['value']&&_0x10f34e(_0x81abc7,this['value']);const _0x5caa06=y(_0x1dff54),_0x350005=this['children']['get'](_0x5caa06);return _0x350005?_0x350005['foreachOnPath_'](S(_0x1dff54),k(_0x81abc7,_0x5caa06),_0x10f34e):new b(null);}}['foreach'](_0x1ce363){this['foreach_'](w(),_0x1ce363);}['foreach_'](_0x51bc35,_0xaf0e8){this['children']['inorderTraversal']((_0xfc4653,_0x4808c5)=>{_0x4808c5['foreach_'](k(_0x51bc35,_0xfc4653),_0xaf0e8);}),this['value']&&_0xaf0e8(_0x51bc35,this['value']);}['foreachChild'](_0x58802a){this['children']['inorderTraversal']((_0xaa407f,_0x4bf2b4)=>{_0x4bf2b4['value']&&_0x58802a(_0xaa407f,_0x4bf2b4['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4802d2){this['writeTree_']=_0x4802d2;}static['empty'](){return new K(new b(null));}}function At(_0x3d7db5,_0x43efd8,_0x51d636){if(v(_0x43efd8))return new K(new b(_0x51d636));{const _0x39d1f8=_0x3d7db5['writeTree_']['findRootMostValueAndPath'](_0x43efd8);if(_0x39d1f8!=null){const _0x497f9e=_0x39d1f8['path'];let _0x3de950=_0x39d1f8['value'];const _0x45d5c9=F(_0x497f9e,_0x43efd8);return _0x3de950=_0x3de950['updateChild'](_0x45d5c9,_0x51d636),new K(_0x3d7db5['writeTree_']['set'](_0x497f9e,_0x3de950));}else{const _0x2be39b=new b(_0x51d636),_0x5ae34c=_0x3d7db5['writeTree_']['setTree'](_0x43efd8,_0x2be39b);return new K(_0x5ae34c);}}}function bi(_0x272f85,_0x49f50f,_0x4dcde0){let _0x5c2ceb=_0x272f85;return x(_0x4dcde0,(_0x2f7714,_0x4fe021)=>{_0x5c2ceb=At(_0x5c2ceb,k(_0x49f50f,_0x2f7714),_0x4fe021);}),_0x5c2ceb;}function or(_0x334a0b,_0x5254be){if(v(_0x5254be))return K['empty']();{const _0xa045e=_0x334a0b['writeTree_']['setTree'](_0x5254be,new b(null));return new K(_0xa045e);}}function Ri(_0x443742,_0x3e60bb){return ze(_0x443742,_0x3e60bb)!=null;}function ze(_0x4f94f3,_0x46b7d8){const _0x492020=_0x4f94f3['writeTree_']['findRootMostValueAndPath'](_0x46b7d8);return _0x492020!=null?_0x4f94f3['writeTree_']['get'](_0x492020['path'])['getChild'](F(_0x492020['path'],_0x46b7d8)):null;}function ar(_0x333c3b){const _0x1dd4f2=[],_0x472acc=_0x333c3b['writeTree_']['value'];return _0x472acc!=null?_0x472acc['isLeafNode']()||_0x472acc['forEachChild'](R,(_0x5bacce,_0x103457)=>{_0x1dd4f2['push'](new E(_0x5bacce,_0x103457));}):_0x333c3b['writeTree_']['children']['inorderTraversal']((_0x195381,_0x21bf76)=>{_0x21bf76['value']!=null&&_0x1dd4f2['push'](new E(_0x195381,_0x21bf76['value']));}),_0x1dd4f2;}function Ee(_0x3874de,_0x9e7d40){if(v(_0x9e7d40))return _0x3874de;{const _0x340d81=ze(_0x3874de,_0x9e7d40);return _0x340d81!=null?new K(new b(_0x340d81)):new K(_0x3874de['writeTree_']['subtree'](_0x9e7d40));}}function Ai(_0x4c4d70){return _0x4c4d70['writeTree_']['isEmpty']();}function at(_0x434281,_0x2fea12){return Uo(w(),_0x434281['writeTree_'],_0x2fea12);}function Uo(_0x4fe5de,_0x5d1ca6,_0xe03ae1){if(_0x5d1ca6['value']!=null)return _0xe03ae1['updateChild'](_0x4fe5de,_0x5d1ca6['value']);{let _0x43d7d9=null;return _0x5d1ca6['children']['inorderTraversal']((_0x1df125,_0x375243)=>{_0x1df125==='.priority'?(f(_0x375243['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x43d7d9=_0x375243['value']):_0xe03ae1=Uo(k(_0x4fe5de,_0x1df125),_0x375243,_0xe03ae1);}),!_0xe03ae1['getChild'](_0x4fe5de)['isEmpty']()&&_0x43d7d9!==null&&(_0xe03ae1=_0xe03ae1['updateChild'](k(_0x4fe5de,'.priority'),_0x43d7d9)),_0xe03ae1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x26e658,_0x59d165){return Ho(_0x59d165,_0x26e658);}function lu(_0x4d575f,_0x19a905,_0x3408e9,_0x49da1f,_0x262561){f(_0x49da1f>_0x4d575f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x262561===void 0x0&&(_0x262561=!0x0),_0x4d575f['allWrites']['push']({'path':_0x19a905,'snap':_0x3408e9,'writeId':_0x49da1f,'visible':_0x262561}),_0x262561&&(_0x4d575f['visibleWrites']=At(_0x4d575f['visibleWrites'],_0x19a905,_0x3408e9)),_0x4d575f['lastWriteId']=_0x49da1f;}function hu(_0x44bcf,_0x2cccc8,_0x58de71,_0x1ef33a){f(_0x1ef33a>_0x44bcf['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x44bcf['allWrites']['push']({'path':_0x2cccc8,'children':_0x58de71,'writeId':_0x1ef33a,'visible':!0x0}),_0x44bcf['visibleWrites']=bi(_0x44bcf['visibleWrites'],_0x2cccc8,_0x58de71),_0x44bcf['lastWriteId']=_0x1ef33a;}function uu(_0x2b8ee0,_0x32ef7e){for(let _0x11b931=0x0;_0x11b931<_0x2b8ee0['allWrites']['length'];_0x11b931++){const _0x39a0bf=_0x2b8ee0['allWrites'][_0x11b931];if(_0x39a0bf['writeId']===_0x32ef7e)return _0x39a0bf;}return null;}function du(_0x598936,_0x2dd500){const _0x296cb2=_0x598936['allWrites']['findIndex'](_0x35b751=>_0x35b751['writeId']===_0x2dd500);f(_0x296cb2>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x16987a=_0x598936['allWrites'][_0x296cb2];_0x598936['allWrites']['splice'](_0x296cb2,0x1);let _0x11b559=_0x16987a['visible'],_0x3f6ab5=!0x1,_0x1d6823=_0x598936['allWrites']['length']-0x1;for(;_0x11b559&&_0x1d6823>=0x0;){const _0xdedd58=_0x598936['allWrites'][_0x1d6823];_0xdedd58['visible']&&(_0x1d6823>=_0x296cb2&&fu(_0xdedd58,_0x16987a['path'])?_0x11b559=!0x1:G(_0x16987a['path'],_0xdedd58['path'])&&(_0x3f6ab5=!0x0)),_0x1d6823--;}if(_0x11b559){if(_0x3f6ab5)return pu(_0x598936),!0x0;if(_0x16987a['snap'])_0x598936['visibleWrites']=or(_0x598936['visibleWrites'],_0x16987a['path']);else{const _0x46077d=_0x16987a['children'];x(_0x46077d,_0x5e3119=>{_0x598936['visibleWrites']=or(_0x598936['visibleWrites'],k(_0x16987a['path'],_0x5e3119));});}return!0x0;}else return!0x1;}function fu(_0x13fa3d,_0x4a1748){if(_0x13fa3d['snap'])return G(_0x13fa3d['path'],_0x4a1748);for(const _0x3dfc15 in _0x13fa3d['children'])if(_0x13fa3d['children']['hasOwnProperty'](_0x3dfc15)&&G(k(_0x13fa3d['path'],_0x3dfc15),_0x4a1748))return!0x0;return!0x1;}function pu(_0x29a952){_0x29a952['visibleWrites']=Wo(_0x29a952['allWrites'],_u,w()),_0x29a952['allWrites']['length']>0x0?_0x29a952['lastWriteId']=_0x29a952['allWrites'][_0x29a952['allWrites']['length']-0x1]['writeId']:_0x29a952['lastWriteId']=-0x1;}function _u(_0x26180f){return _0x26180f['visible'];}function Wo(_0x30595e,_0x3b37f7,_0x26a4c4){let _0x4ce19b=K['empty']();for(let _0x30a3cf=0x0;_0x30a3cf<_0x30595e['length'];++_0x30a3cf){const _0x3ed960=_0x30595e[_0x30a3cf];if(_0x3b37f7(_0x3ed960)){const _0x258a92=_0x3ed960['path'];let _0x283b70;if(_0x3ed960['snap'])G(_0x26a4c4,_0x258a92)?(_0x283b70=F(_0x26a4c4,_0x258a92),_0x4ce19b=At(_0x4ce19b,_0x283b70,_0x3ed960['snap'])):G(_0x258a92,_0x26a4c4)&&(_0x283b70=F(_0x258a92,_0x26a4c4),_0x4ce19b=At(_0x4ce19b,w(),_0x3ed960['snap']['getChild'](_0x283b70)));else{if(_0x3ed960['children']){if(G(_0x26a4c4,_0x258a92))_0x283b70=F(_0x26a4c4,_0x258a92),_0x4ce19b=bi(_0x4ce19b,_0x283b70,_0x3ed960['children']);else{if(G(_0x258a92,_0x26a4c4)){if(_0x283b70=F(_0x258a92,_0x26a4c4),v(_0x283b70))_0x4ce19b=bi(_0x4ce19b,w(),_0x3ed960['children']);else{const _0x24c54d=Le(_0x3ed960['children'],y(_0x283b70));if(_0x24c54d){const _0x57b3a2=_0x24c54d['getChild'](S(_0x283b70));_0x4ce19b=At(_0x4ce19b,w(),_0x57b3a2);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4ce19b;}function Bo(_0x287c67,_0x1ed99c,_0x5e952a,_0x460084,_0x424771){if(!_0x460084&&!_0x424771){const _0xdbbc35=ze(_0x287c67['visibleWrites'],_0x1ed99c);if(_0xdbbc35!=null)return _0xdbbc35;{const _0x24d8bb=Ee(_0x287c67['visibleWrites'],_0x1ed99c);if(Ai(_0x24d8bb))return _0x5e952a;if(_0x5e952a==null&&!Ri(_0x24d8bb,w()))return null;{const _0x2e5c9a=_0x5e952a||g['EMPTY_NODE'];return at(_0x24d8bb,_0x2e5c9a);}}}else{const _0x1b948d=Ee(_0x287c67['visibleWrites'],_0x1ed99c);if(!_0x424771&&Ai(_0x1b948d))return _0x5e952a;if(!_0x424771&&_0x5e952a==null&&!Ri(_0x1b948d,w()))return null;{const _0x4d0562=function(_0x4172da){return(_0x4172da['visible']||_0x424771)&&(!_0x460084||!~_0x460084['indexOf'](_0x4172da['writeId']))&&(G(_0x4172da['path'],_0x1ed99c)||G(_0x1ed99c,_0x4172da['path']));},_0xa38bd=Wo(_0x287c67['allWrites'],_0x4d0562,_0x1ed99c),_0x1ad0bb=_0x5e952a||g['EMPTY_NODE'];return at(_0xa38bd,_0x1ad0bb);}}}function gu(_0x1fd280,_0x378eff,_0x2a5e34){let _0x363ce5=g['EMPTY_NODE'];const _0x434d3a=ze(_0x1fd280['visibleWrites'],_0x378eff);if(_0x434d3a)return _0x434d3a['isLeafNode']()||_0x434d3a['forEachChild'](R,(_0x54b67e,_0x20b7d3)=>{_0x363ce5=_0x363ce5['updateImmediateChild'](_0x54b67e,_0x20b7d3);}),_0x363ce5;if(_0x2a5e34){const _0x33e8a5=Ee(_0x1fd280['visibleWrites'],_0x378eff);return _0x2a5e34['forEachChild'](R,(_0x1eb654,_0x2800bc)=>{const _0x197483=at(Ee(_0x33e8a5,new C(_0x1eb654)),_0x2800bc);_0x363ce5=_0x363ce5['updateImmediateChild'](_0x1eb654,_0x197483);}),ar(_0x33e8a5)['forEach'](_0x2a9db0=>{_0x363ce5=_0x363ce5['updateImmediateChild'](_0x2a9db0['name'],_0x2a9db0['node']);}),_0x363ce5;}else{const _0x290253=Ee(_0x1fd280['visibleWrites'],_0x378eff);return ar(_0x290253)['forEach'](_0x4968ae=>{_0x363ce5=_0x363ce5['updateImmediateChild'](_0x4968ae['name'],_0x4968ae['node']);}),_0x363ce5;}}function mu(_0x316670,_0x3c564b,_0x42865b,_0x11556a,_0x3ed950){f(_0x11556a||_0x3ed950,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2610ba=k(_0x3c564b,_0x42865b);if(Ri(_0x316670['visibleWrites'],_0x2610ba))return null;{const _0x278f5b=Ee(_0x316670['visibleWrites'],_0x2610ba);return Ai(_0x278f5b)?_0x3ed950['getChild'](_0x42865b):at(_0x278f5b,_0x3ed950['getChild'](_0x42865b));}}function yu(_0x3a6975,_0x27c3e9,_0x36e499,_0x4d65a8){const _0x50b0db=k(_0x27c3e9,_0x36e499),_0x5536b8=ze(_0x3a6975['visibleWrites'],_0x50b0db);if(_0x5536b8!=null)return _0x5536b8;if(_0x4d65a8['isCompleteForChild'](_0x36e499)){const _0x1bd153=Ee(_0x3a6975['visibleWrites'],_0x50b0db);return at(_0x1bd153,_0x4d65a8['getNode']()['getImmediateChild'](_0x36e499));}else return null;}function vu(_0x4a9623,_0x6df459){return ze(_0x4a9623['visibleWrites'],_0x6df459);}function Eu(_0x4a0795,_0x38f880,_0x393db2,_0x1678f4,_0x2bdcdf,_0xe740b3,_0x14b7b6){let _0x4ff17e;const _0x373672=Ee(_0x4a0795['visibleWrites'],_0x38f880),_0x41f5b8=ze(_0x373672,w());if(_0x41f5b8!=null)_0x4ff17e=_0x41f5b8;else{if(_0x393db2!=null)_0x4ff17e=at(_0x373672,_0x393db2);else return[];}if(_0x4ff17e=_0x4ff17e['withIndex'](_0x14b7b6),!_0x4ff17e['isEmpty']()&&!_0x4ff17e['isLeafNode']()){const _0x11db86=[],_0x1df903=_0x14b7b6['getCompare'](),_0x2be83c=_0xe740b3?_0x4ff17e['getReverseIteratorFrom'](_0x1678f4,_0x14b7b6):_0x4ff17e['getIteratorFrom'](_0x1678f4,_0x14b7b6);let _0x2fee3d=_0x2be83c['getNext']();for(;_0x2fee3d&&_0x11db86['length']<_0x2bdcdf;)_0x1df903(_0x2fee3d,_0x1678f4)!==0x0&&_0x11db86['push'](_0x2fee3d),_0x2fee3d=_0x2be83c['getNext']();return _0x11db86;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x5b2d09,_0x4d91d0,_0x2b82d0,_0x2dcf04){return Bo(_0x5b2d09['writeTree'],_0x5b2d09['treePath'],_0x4d91d0,_0x2b82d0,_0x2dcf04);}function is(_0x2f6561,_0x526745){return gu(_0x2f6561['writeTree'],_0x2f6561['treePath'],_0x526745);}function cr(_0x111a31,_0x6db282,_0x4a9ad2,_0x1d5207){return mu(_0x111a31['writeTree'],_0x111a31['treePath'],_0x6db282,_0x4a9ad2,_0x1d5207);}function Tn(_0x42eb4c,_0x399e33){return vu(_0x42eb4c['writeTree'],k(_0x42eb4c['treePath'],_0x399e33));}function wu(_0x1b619e,_0x3119d6,_0x8d07d2,_0x27e6e8,_0x4779f3,_0xcc45b6){return Eu(_0x1b619e['writeTree'],_0x1b619e['treePath'],_0x3119d6,_0x8d07d2,_0x27e6e8,_0x4779f3,_0xcc45b6);}function ss(_0x151faf,_0x5d3a36,_0x186c0e){return yu(_0x151faf['writeTree'],_0x151faf['treePath'],_0x5d3a36,_0x186c0e);}function Vo(_0x409f1e,_0x27401c){return Ho(k(_0x409f1e['treePath'],_0x27401c),_0x409f1e['writeTree']);}function Ho(_0x465d0f,_0x5ac491){return{'treePath':_0x465d0f,'writeTree':_0x5ac491};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x53a64b){const _0x2782ec=_0x53a64b['type'],_0x44c8b8=_0x53a64b['childName'];f(_0x2782ec==='child_added'||_0x2782ec==='child_changed'||_0x2782ec==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x44c8b8!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1c532c=this['changeMap']['get'](_0x44c8b8);if(_0x1c532c){const _0x5c981e=_0x1c532c['type'];if(_0x2782ec==='child_added'&&_0x5c981e==='child_removed')this['changeMap']['set'](_0x44c8b8,xt(_0x44c8b8,_0x53a64b['snapshotNode'],_0x1c532c['snapshotNode']));else{if(_0x2782ec==='child_removed'&&_0x5c981e==='child_added')this['changeMap']['delete'](_0x44c8b8);else{if(_0x2782ec==='child_removed'&&_0x5c981e==='child_changed')this['changeMap']['set'](_0x44c8b8,Lt(_0x44c8b8,_0x1c532c['oldSnap']));else{if(_0x2782ec==='child_changed'&&_0x5c981e==='child_added')this['changeMap']['set'](_0x44c8b8,rt(_0x44c8b8,_0x53a64b['snapshotNode']));else{if(_0x2782ec==='child_changed'&&_0x5c981e==='child_changed')this['changeMap']['set'](_0x44c8b8,xt(_0x44c8b8,_0x53a64b['snapshotNode'],_0x1c532c['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x53a64b+'\x20occurred\x20after\x20'+_0x1c532c);}}}}}else this['changeMap']['set'](_0x44c8b8,_0x53a64b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3531ca){return null;}['getChildAfterChild'](_0x33a7d3,_0x1925af,_0x284c25){return null;}}const $o=new Tu();class rs{constructor(_0x18ade9,_0x1b122b,_0x27c7f9=null){this['writes_']=_0x18ade9,this['viewCache_']=_0x1b122b,this['optCompleteServerCache_']=_0x27c7f9;}['getCompleteChild'](_0x5ce11d){const _0x3d375d=this['viewCache_']['eventCache'];if(_0x3d375d['isCompleteForChild'](_0x5ce11d))return _0x3d375d['getNode']()['getImmediateChild'](_0x5ce11d);{const _0x29bc80=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x5ce11d,_0x29bc80);}}['getChildAfterChild'](_0xc3f5e5,_0xa7c356,_0x43363c){const _0x438f9f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x356fd5=wu(this['writes_'],_0x438f9f,_0xa7c356,0x1,_0x43363c,_0xc3f5e5);return _0x356fd5['length']===0x0?null:_0x356fd5[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x11adda){return{'filter':_0x11adda};}function bu(_0x51cc66,_0x3cd338){f(_0x3cd338['eventCache']['getNode']()['isIndexed'](_0x51cc66['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3cd338['serverCache']['getNode']()['isIndexed'](_0x51cc66['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2fec92,_0x2c2ff4,_0x32a4f8,_0x5dadd0,_0x315166){const _0x17c844=new Cu();let _0x46a80d,_0x477f4c;if(_0x32a4f8['type']===z['OVERWRITE']){const _0x40e185=_0x32a4f8;_0x40e185['source']['fromUser']?_0x46a80d=ki(_0x2fec92,_0x2c2ff4,_0x40e185['path'],_0x40e185['snap'],_0x5dadd0,_0x315166,_0x17c844):(f(_0x40e185['source']['fromServer'],'Unknown\x20source.'),_0x477f4c=_0x40e185['source']['tagged']||_0x2c2ff4['serverCache']['isFiltered']()&&!v(_0x40e185['path']),_0x46a80d=Sn(_0x2fec92,_0x2c2ff4,_0x40e185['path'],_0x40e185['snap'],_0x5dadd0,_0x315166,_0x477f4c,_0x17c844));}else{if(_0x32a4f8['type']===z['MERGE']){const _0x131fb8=_0x32a4f8;_0x131fb8['source']['fromUser']?_0x46a80d=ku(_0x2fec92,_0x2c2ff4,_0x131fb8['path'],_0x131fb8['children'],_0x5dadd0,_0x315166,_0x17c844):(f(_0x131fb8['source']['fromServer'],'Unknown\x20source.'),_0x477f4c=_0x131fb8['source']['tagged']||_0x2c2ff4['serverCache']['isFiltered'](),_0x46a80d=Pi(_0x2fec92,_0x2c2ff4,_0x131fb8['path'],_0x131fb8['children'],_0x5dadd0,_0x315166,_0x477f4c,_0x17c844));}else{if(_0x32a4f8['type']===z['ACK_USER_WRITE']){const _0x4ace32=_0x32a4f8;_0x4ace32['revert']?_0x46a80d=Ou(_0x2fec92,_0x2c2ff4,_0x4ace32['path'],_0x5dadd0,_0x315166,_0x17c844):_0x46a80d=Pu(_0x2fec92,_0x2c2ff4,_0x4ace32['path'],_0x4ace32['affectedTree'],_0x5dadd0,_0x315166,_0x17c844);}else{if(_0x32a4f8['type']===z['LISTEN_COMPLETE'])_0x46a80d=Nu(_0x2fec92,_0x2c2ff4,_0x32a4f8['path'],_0x5dadd0,_0x17c844);else throw ht('Unknown\x20operation\x20type:\x20'+_0x32a4f8['type']);}}}const _0x22dcd1=_0x17c844['getChanges']();return Au(_0x2c2ff4,_0x46a80d,_0x22dcd1),{'viewCache':_0x46a80d,'changes':_0x22dcd1};}function Au(_0x1e83bc,_0x41fa3e,_0x360f20){const _0xb63e19=_0x41fa3e['eventCache'];if(_0xb63e19['isFullyInitialized']()){const _0x4da045=_0xb63e19['getNode']()['isLeafNode']()||_0xb63e19['getNode']()['isEmpty'](),_0x3580e7=wn(_0x1e83bc);(_0x360f20['length']>0x0||!_0x1e83bc['eventCache']['isFullyInitialized']()||_0x4da045&&!_0xb63e19['getNode']()['equals'](_0x3580e7)||!_0xb63e19['getNode']()['getPriority']()['equals'](_0x3580e7['getPriority']()))&&_0x360f20['push'](Lo(wn(_0x41fa3e)));}}function Go(_0x4fa827,_0x4100fb,_0x180ce4,_0x265615,_0x3a5bd3,_0x36bcf1){const _0x830834=_0x4100fb['eventCache'];if(Tn(_0x265615,_0x180ce4)!=null)return _0x4100fb;{let _0xa8d364,_0x543cf2;if(v(_0x180ce4)){if(f(_0x4100fb['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4100fb['serverCache']['isFiltered']()){const _0xea89fe=Ve(_0x4100fb),_0x5adff5=_0xea89fe instanceof g?_0xea89fe:g['EMPTY_NODE'],_0x95564a=is(_0x265615,_0x5adff5);_0xa8d364=_0x4fa827['filter']['updateFullNode'](_0x4100fb['eventCache']['getNode'](),_0x95564a,_0x36bcf1);}else{const _0x3fdf84=Cn(_0x265615,Ve(_0x4100fb));_0xa8d364=_0x4fa827['filter']['updateFullNode'](_0x4100fb['eventCache']['getNode'](),_0x3fdf84,_0x36bcf1);}}else{const _0x2d57f3=y(_0x180ce4);if(_0x2d57f3==='.priority'){f(Ce(_0x180ce4)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x496d6e=_0x830834['getNode']();_0x543cf2=_0x4100fb['serverCache']['getNode']();const _0x5438dd=cr(_0x265615,_0x180ce4,_0x496d6e,_0x543cf2);_0x5438dd!=null?_0xa8d364=_0x4fa827['filter']['updatePriority'](_0x496d6e,_0x5438dd):_0xa8d364=_0x830834['getNode']();}else{const _0x21b644=S(_0x180ce4);let _0x1f080c;if(_0x830834['isCompleteForChild'](_0x2d57f3)){_0x543cf2=_0x4100fb['serverCache']['getNode']();const _0x455704=cr(_0x265615,_0x180ce4,_0x830834['getNode'](),_0x543cf2);_0x455704!=null?_0x1f080c=_0x830834['getNode']()['getImmediateChild'](_0x2d57f3)['updateChild'](_0x21b644,_0x455704):_0x1f080c=_0x830834['getNode']()['getImmediateChild'](_0x2d57f3);}else _0x1f080c=ss(_0x265615,_0x2d57f3,_0x4100fb['serverCache']);_0x1f080c!=null?_0xa8d364=_0x4fa827['filter']['updateChild'](_0x830834['getNode'](),_0x2d57f3,_0x1f080c,_0x21b644,_0x3a5bd3,_0x36bcf1):_0xa8d364=_0x830834['getNode']();}}return Rt(_0x4100fb,_0xa8d364,_0x830834['isFullyInitialized']()||v(_0x180ce4),_0x4fa827['filter']['filtersNodes']());}}function Sn(_0x1d1f4e,_0x8b1e2,_0x1cea11,_0x3c8b72,_0xb4b346,_0x5638b1,_0x2d475e,_0x233ba2){const _0x50205f=_0x8b1e2['serverCache'];let _0x5adf66;const _0x5a37c6=_0x2d475e?_0x1d1f4e['filter']:_0x1d1f4e['filter']['getIndexedFilter']();if(v(_0x1cea11))_0x5adf66=_0x5a37c6['updateFullNode'](_0x50205f['getNode'](),_0x3c8b72,null);else{if(_0x5a37c6['filtersNodes']()&&!_0x50205f['isFiltered']()){const _0x5380e3=_0x50205f['getNode']()['updateChild'](_0x1cea11,_0x3c8b72);_0x5adf66=_0x5a37c6['updateFullNode'](_0x50205f['getNode'](),_0x5380e3,null);}else{const _0x46bbaa=y(_0x1cea11);if(!_0x50205f['isCompleteForPath'](_0x1cea11)&&Ce(_0x1cea11)>0x1)return _0x8b1e2;const _0x56bb9a=S(_0x1cea11),_0x52704d=_0x50205f['getNode']()['getImmediateChild'](_0x46bbaa)['updateChild'](_0x56bb9a,_0x3c8b72);_0x46bbaa==='.priority'?_0x5adf66=_0x5a37c6['updatePriority'](_0x50205f['getNode'](),_0x52704d):_0x5adf66=_0x5a37c6['updateChild'](_0x50205f['getNode'](),_0x46bbaa,_0x52704d,_0x56bb9a,$o,null);}}const _0x426d48=Fo(_0x8b1e2,_0x5adf66,_0x50205f['isFullyInitialized']()||v(_0x1cea11),_0x5a37c6['filtersNodes']()),_0x5f4421=new rs(_0xb4b346,_0x426d48,_0x5638b1);return Go(_0x1d1f4e,_0x426d48,_0x1cea11,_0xb4b346,_0x5f4421,_0x233ba2);}function ki(_0x15dce9,_0x50f0fb,_0x364bfd,_0x51d910,_0x23dee6,_0x43c2ae,_0x34e5bd){const _0x17cf0e=_0x50f0fb['eventCache'];let _0xa012af,_0x2c5413;const _0x460868=new rs(_0x23dee6,_0x50f0fb,_0x43c2ae);if(v(_0x364bfd))_0x2c5413=_0x15dce9['filter']['updateFullNode'](_0x50f0fb['eventCache']['getNode'](),_0x51d910,_0x34e5bd),_0xa012af=Rt(_0x50f0fb,_0x2c5413,!0x0,_0x15dce9['filter']['filtersNodes']());else{const _0x308523=y(_0x364bfd);if(_0x308523==='.priority')_0x2c5413=_0x15dce9['filter']['updatePriority'](_0x50f0fb['eventCache']['getNode'](),_0x51d910),_0xa012af=Rt(_0x50f0fb,_0x2c5413,_0x17cf0e['isFullyInitialized'](),_0x17cf0e['isFiltered']());else{const _0xa2177c=S(_0x364bfd),_0x4124af=_0x17cf0e['getNode']()['getImmediateChild'](_0x308523);let _0x72cd25;if(v(_0xa2177c))_0x72cd25=_0x51d910;else{const _0x5b8c60=_0x460868['getCompleteChild'](_0x308523);_0x5b8c60!=null?ji(_0xa2177c)==='.priority'&&_0x5b8c60['getChild'](Ro(_0xa2177c))['isEmpty']()?_0x72cd25=_0x5b8c60:_0x72cd25=_0x5b8c60['updateChild'](_0xa2177c,_0x51d910):_0x72cd25=g['EMPTY_NODE'];}if(_0x4124af['equals'](_0x72cd25))_0xa012af=_0x50f0fb;else{const _0x1120a0=_0x15dce9['filter']['updateChild'](_0x17cf0e['getNode'](),_0x308523,_0x72cd25,_0xa2177c,_0x460868,_0x34e5bd);_0xa012af=Rt(_0x50f0fb,_0x1120a0,_0x17cf0e['isFullyInitialized'](),_0x15dce9['filter']['filtersNodes']());}}}return _0xa012af;}function lr(_0x228993,_0x1f21c7){return _0x228993['eventCache']['isCompleteForChild'](_0x1f21c7);}function ku(_0x4d7cf4,_0x5dbb2a,_0x5f4c33,_0x57c196,_0x13380b,_0x2e7f67,_0x3bc55a){let _0x398db3=_0x5dbb2a;return _0x57c196['foreach']((_0x481106,_0x2c48fd)=>{const _0x2149b8=k(_0x5f4c33,_0x481106);lr(_0x5dbb2a,y(_0x2149b8))&&(_0x398db3=ki(_0x4d7cf4,_0x398db3,_0x2149b8,_0x2c48fd,_0x13380b,_0x2e7f67,_0x3bc55a));}),_0x57c196['foreach']((_0x21256e,_0x2cde05)=>{const _0x553638=k(_0x5f4c33,_0x21256e);lr(_0x5dbb2a,y(_0x553638))||(_0x398db3=ki(_0x4d7cf4,_0x398db3,_0x553638,_0x2cde05,_0x13380b,_0x2e7f67,_0x3bc55a));}),_0x398db3;}function hr(_0x429118,_0x3d0c98,_0x182d44){return _0x182d44['foreach']((_0x8b7a93,_0x497155)=>{_0x3d0c98=_0x3d0c98['updateChild'](_0x8b7a93,_0x497155);}),_0x3d0c98;}function Pi(_0xdbd95,_0x8607c9,_0x1c016c,_0x15b45c,_0x183612,_0x11891a,_0x2ab204,_0x5dd272){if(_0x8607c9['serverCache']['getNode']()['isEmpty']()&&!_0x8607c9['serverCache']['isFullyInitialized']())return _0x8607c9;let _0x184dcd=_0x8607c9,_0x14d927;v(_0x1c016c)?_0x14d927=_0x15b45c:_0x14d927=new b(null)['setTree'](_0x1c016c,_0x15b45c);const _0x2f0914=_0x8607c9['serverCache']['getNode']();return _0x14d927['children']['inorderTraversal']((_0xfabff5,_0x1023d2)=>{if(_0x2f0914['hasChild'](_0xfabff5)){const _0x1e6040=_0x8607c9['serverCache']['getNode']()['getImmediateChild'](_0xfabff5),_0x1f52ce=hr(_0xdbd95,_0x1e6040,_0x1023d2);_0x184dcd=Sn(_0xdbd95,_0x184dcd,new C(_0xfabff5),_0x1f52ce,_0x183612,_0x11891a,_0x2ab204,_0x5dd272);}}),_0x14d927['children']['inorderTraversal']((_0x2f1322,_0x33c81b)=>{const _0x1a7a40=!_0x8607c9['serverCache']['isCompleteForChild'](_0x2f1322)&&_0x33c81b['value']===null;if(!_0x2f0914['hasChild'](_0x2f1322)&&!_0x1a7a40){const _0x1ddff7=_0x8607c9['serverCache']['getNode']()['getImmediateChild'](_0x2f1322),_0x24f28d=hr(_0xdbd95,_0x1ddff7,_0x33c81b);_0x184dcd=Sn(_0xdbd95,_0x184dcd,new C(_0x2f1322),_0x24f28d,_0x183612,_0x11891a,_0x2ab204,_0x5dd272);}}),_0x184dcd;}function Pu(_0x55a434,_0x276fb2,_0x358994,_0x4e29d6,_0x48b3f3,_0x473e9a,_0x27b381){if(Tn(_0x48b3f3,_0x358994)!=null)return _0x276fb2;const _0x3f3f0b=_0x276fb2['serverCache']['isFiltered'](),_0x4009ca=_0x276fb2['serverCache'];if(_0x4e29d6['value']!=null){if(v(_0x358994)&&_0x4009ca['isFullyInitialized']()||_0x4009ca['isCompleteForPath'](_0x358994))return Sn(_0x55a434,_0x276fb2,_0x358994,_0x4009ca['getNode']()['getChild'](_0x358994),_0x48b3f3,_0x473e9a,_0x3f3f0b,_0x27b381);if(v(_0x358994)){let _0xa7a618=new b(null);return _0x4009ca['getNode']()['forEachChild'](ve,(_0x1031a4,_0x598b1c)=>{_0xa7a618=_0xa7a618['set'](new C(_0x1031a4),_0x598b1c);}),Pi(_0x55a434,_0x276fb2,_0x358994,_0xa7a618,_0x48b3f3,_0x473e9a,_0x3f3f0b,_0x27b381);}else return _0x276fb2;}else{let _0x348cf0=new b(null);return _0x4e29d6['foreach']((_0x4c29a6,_0x5d61d7)=>{const _0x3a1105=k(_0x358994,_0x4c29a6);_0x4009ca['isCompleteForPath'](_0x3a1105)&&(_0x348cf0=_0x348cf0['set'](_0x4c29a6,_0x4009ca['getNode']()['getChild'](_0x3a1105)));}),Pi(_0x55a434,_0x276fb2,_0x358994,_0x348cf0,_0x48b3f3,_0x473e9a,_0x3f3f0b,_0x27b381);}}function Nu(_0x610c90,_0x483c84,_0x3847ae,_0x35dec3,_0x17236){const _0x2d6ccf=_0x483c84['serverCache'],_0x6f65c9=Fo(_0x483c84,_0x2d6ccf['getNode'](),_0x2d6ccf['isFullyInitialized']()||v(_0x3847ae),_0x2d6ccf['isFiltered']());return Go(_0x610c90,_0x6f65c9,_0x3847ae,_0x35dec3,$o,_0x17236);}function Ou(_0x51467a,_0x297bb7,_0x229814,_0x3c1fcd,_0x583383,_0x49a0c2){let _0x2a9b92;if(Tn(_0x3c1fcd,_0x229814)!=null)return _0x297bb7;{const _0xbd8d2d=new rs(_0x3c1fcd,_0x297bb7,_0x583383),_0x55d266=_0x297bb7['eventCache']['getNode']();let _0x3ea40b;if(v(_0x229814)||y(_0x229814)==='.priority'){let _0x2e495f;if(_0x297bb7['serverCache']['isFullyInitialized']())_0x2e495f=Cn(_0x3c1fcd,Ve(_0x297bb7));else{const _0x3da5f1=_0x297bb7['serverCache']['getNode']();f(_0x3da5f1 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2e495f=is(_0x3c1fcd,_0x3da5f1);}_0x2e495f=_0x2e495f,_0x3ea40b=_0x51467a['filter']['updateFullNode'](_0x55d266,_0x2e495f,_0x49a0c2);}else{const _0x18e714=y(_0x229814);let _0x361af7=ss(_0x3c1fcd,_0x18e714,_0x297bb7['serverCache']);_0x361af7==null&&_0x297bb7['serverCache']['isCompleteForChild'](_0x18e714)&&(_0x361af7=_0x55d266['getImmediateChild'](_0x18e714)),_0x361af7!=null?_0x3ea40b=_0x51467a['filter']['updateChild'](_0x55d266,_0x18e714,_0x361af7,S(_0x229814),_0xbd8d2d,_0x49a0c2):_0x297bb7['eventCache']['getNode']()['hasChild'](_0x18e714)?_0x3ea40b=_0x51467a['filter']['updateChild'](_0x55d266,_0x18e714,g['EMPTY_NODE'],S(_0x229814),_0xbd8d2d,_0x49a0c2):_0x3ea40b=_0x55d266,_0x3ea40b['isEmpty']()&&_0x297bb7['serverCache']['isFullyInitialized']()&&(_0x2a9b92=Cn(_0x3c1fcd,Ve(_0x297bb7)),_0x2a9b92['isLeafNode']()&&(_0x3ea40b=_0x51467a['filter']['updateFullNode'](_0x3ea40b,_0x2a9b92,_0x49a0c2)));}return _0x2a9b92=_0x297bb7['serverCache']['isFullyInitialized']()||Tn(_0x3c1fcd,w())!=null,Rt(_0x297bb7,_0x3ea40b,_0x2a9b92,_0x51467a['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1b8376,_0xf5783){this['query_']=_0x1b8376,this['eventRegistrations_']=[];const _0x549613=this['query_']['_queryParams'],_0x8bb446=new Xi(_0x549613['getIndex']()),_0x392c2f=Kh(_0x549613);this['processor_']=Su(_0x392c2f);const _0x5124bc=_0xf5783['serverCache'],_0x49c806=_0xf5783['eventCache'],_0xb10688=_0x8bb446['updateFullNode'](g['EMPTY_NODE'],_0x5124bc['getNode'](),null),_0x517f8c=_0x392c2f['updateFullNode'](g['EMPTY_NODE'],_0x49c806['getNode'](),null),_0x222e6d=new Te(_0xb10688,_0x5124bc['isFullyInitialized'](),_0x8bb446['filtersNodes']()),_0x58af79=new Te(_0x517f8c,_0x49c806['isFullyInitialized'](),_0x392c2f['filtersNodes']());this['viewCache_']=Un(_0x58af79,_0x222e6d),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1bdb7a){return _0x1bdb7a['viewCache_']['serverCache']['getNode']();}function Lu(_0x4bc9f5){return wn(_0x4bc9f5['viewCache_']);}function xu(_0x54a96a,_0x17c22c){const _0xd0c6f=Ve(_0x54a96a['viewCache_']);return _0xd0c6f&&(_0x54a96a['query']['_queryParams']['loadsAllData']()||!v(_0x17c22c)&&!_0xd0c6f['getImmediateChild'](y(_0x17c22c))['isEmpty']())?_0xd0c6f['getChild'](_0x17c22c):null;}function ur(_0x29f408){return _0x29f408['eventRegistrations_']['length']===0x0;}function Fu(_0x3b24df,_0x364c91){_0x3b24df['eventRegistrations_']['push'](_0x364c91);}function dr(_0x2e5129,_0x3120ab,_0x450b11){const _0x5cedfe=[];if(_0x450b11){f(_0x3120ab==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x243ce9=_0x2e5129['query']['_path'];_0x2e5129['eventRegistrations_']['forEach'](_0x1cee58=>{const _0x29e589=_0x1cee58['createCancelEvent'](_0x450b11,_0x243ce9);_0x29e589&&_0x5cedfe['push'](_0x29e589);});}if(_0x3120ab){let _0x2411be=[];for(let _0x4088a9=0x0;_0x4088a9<_0x2e5129['eventRegistrations_']['length'];++_0x4088a9){const _0x48b9ea=_0x2e5129['eventRegistrations_'][_0x4088a9];if(!_0x48b9ea['matches'](_0x3120ab))_0x2411be['push'](_0x48b9ea);else{if(_0x3120ab['hasAnyCallback']()){_0x2411be=_0x2411be['concat'](_0x2e5129['eventRegistrations_']['slice'](_0x4088a9+0x1));break;}}}_0x2e5129['eventRegistrations_']=_0x2411be;}else _0x2e5129['eventRegistrations_']=[];return _0x5cedfe;}function fr(_0x2fcfea,_0x1e0b69,_0x15a879,_0x2b68d0){_0x1e0b69['type']===z['MERGE']&&_0x1e0b69['source']['queryId']!==null&&(f(Ve(_0x2fcfea['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2fcfea['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2e8309=_0x2fcfea['viewCache_'],_0x205aee=Ru(_0x2fcfea['processor_'],_0x2e8309,_0x1e0b69,_0x15a879,_0x2b68d0);return bu(_0x2fcfea['processor_'],_0x205aee['viewCache']),f(_0x205aee['viewCache']['serverCache']['isFullyInitialized']()||!_0x2e8309['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2fcfea['viewCache_']=_0x205aee['viewCache'],qo(_0x2fcfea,_0x205aee['changes'],_0x205aee['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x51c111,_0x3ba1e5){const _0x5ac460=_0x51c111['viewCache_']['eventCache'],_0xb073bd=[];return _0x5ac460['getNode']()['isLeafNode']()||_0x5ac460['getNode']()['forEachChild'](R,(_0x58ce79,_0x4995b2)=>{_0xb073bd['push'](rt(_0x58ce79,_0x4995b2));}),_0x5ac460['isFullyInitialized']()&&_0xb073bd['push'](Lo(_0x5ac460['getNode']())),qo(_0x51c111,_0xb073bd,_0x5ac460['getNode'](),_0x3ba1e5);}function qo(_0x296e1b,_0x389c9d,_0xac3839,_0xc206a7){const _0x3143cd=_0xc206a7?[_0xc206a7]:_0x296e1b['eventRegistrations_'];return ru(_0x296e1b['eventGenerator_'],_0x389c9d,_0xac3839,_0x3143cd);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x3bf3d7){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x3bf3d7;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x338faf){return _0x338faf['views']['size']===0x0;}function os(_0x325ccd,_0x1cdd50,_0x30bed2,_0x63a9bf){const _0x59f50c=_0x1cdd50['source']['queryId'];if(_0x59f50c!==null){const _0x4bf6a5=_0x325ccd['views']['get'](_0x59f50c);return f(_0x4bf6a5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x4bf6a5,_0x1cdd50,_0x30bed2,_0x63a9bf);}else{let _0x5c1697=[];for(const _0x4b006d of _0x325ccd['views']['values']())_0x5c1697=_0x5c1697['concat'](fr(_0x4b006d,_0x1cdd50,_0x30bed2,_0x63a9bf));return _0x5c1697;}}function jo(_0x265265,_0x102976,_0x268232,_0x23614d,_0x35bc13){const _0x42400b=_0x102976['_queryIdentifier'],_0x47b809=_0x265265['views']['get'](_0x42400b);if(!_0x47b809){let _0xd6573c=Cn(_0x268232,_0x35bc13?_0x23614d:null),_0x1d5bf9=!0x1;_0xd6573c?_0x1d5bf9=!0x0:_0x23614d instanceof g?(_0xd6573c=is(_0x268232,_0x23614d),_0x1d5bf9=!0x1):(_0xd6573c=g['EMPTY_NODE'],_0x1d5bf9=!0x1);const _0x408c9d=Un(new Te(_0xd6573c,_0x1d5bf9,!0x1),new Te(_0x23614d,_0x35bc13,!0x1));return new Du(_0x102976,_0x408c9d);}return _0x47b809;}function Hu(_0x13efc1,_0x59d1f6,_0x19449e,_0x5605c9,_0x473df7,_0x166963){const _0x10603c=jo(_0x13efc1,_0x59d1f6,_0x5605c9,_0x473df7,_0x166963);return _0x13efc1['views']['has'](_0x59d1f6['_queryIdentifier'])||_0x13efc1['views']['set'](_0x59d1f6['_queryIdentifier'],_0x10603c),Fu(_0x10603c,_0x19449e),Uu(_0x10603c,_0x19449e);}function $u(_0x133840,_0xb4d3c5,_0x2a9513,_0x460923){const _0x471ddd=_0xb4d3c5['_queryIdentifier'],_0x55186a=[];let _0x32dece=[];const _0xb13495=Se(_0x133840);if(_0x471ddd==='default'){for(const [_0x24b239,_0x7daf3e]of _0x133840['views']['entries']())_0x32dece=_0x32dece['concat'](dr(_0x7daf3e,_0x2a9513,_0x460923)),ur(_0x7daf3e)&&(_0x133840['views']['delete'](_0x24b239),_0x7daf3e['query']['_queryParams']['loadsAllData']()||_0x55186a['push'](_0x7daf3e['query']));}else{const _0x293eaa=_0x133840['views']['get'](_0x471ddd);_0x293eaa&&(_0x32dece=_0x32dece['concat'](dr(_0x293eaa,_0x2a9513,_0x460923)),ur(_0x293eaa)&&(_0x133840['views']['delete'](_0x471ddd),_0x293eaa['query']['_queryParams']['loadsAllData']()||_0x55186a['push'](_0x293eaa['query'])));}return _0xb13495&&!Se(_0x133840)&&_0x55186a['push'](new(Bu())(_0xb4d3c5['_repo'],_0xb4d3c5['_path'])),{'removed':_0x55186a,'events':_0x32dece};}function Ko(_0x4e2a51){const _0x410780=[];for(const _0xc77316 of _0x4e2a51['views']['values']())_0xc77316['query']['_queryParams']['loadsAllData']()||_0x410780['push'](_0xc77316);return _0x410780;}function Ie(_0x238ecc,_0x104cf6){let _0x3a4ad8=null;for(const _0x1b3804 of _0x238ecc['views']['values']())_0x3a4ad8=_0x3a4ad8||xu(_0x1b3804,_0x104cf6);return _0x3a4ad8;}function Yo(_0x564ac2,_0x204869){if(_0x204869['_queryParams']['loadsAllData']())return Bn(_0x564ac2);{const _0x260ef5=_0x204869['_queryIdentifier'];return _0x564ac2['views']['get'](_0x260ef5);}}function Qo(_0x36b1b2,_0x1ec6d3){return Yo(_0x36b1b2,_0x1ec6d3)!=null;}function Se(_0x2ada2d){return Bn(_0x2ada2d)!=null;}function Bn(_0x50007d){for(const _0x1c3db4 of _0x50007d['views']['values']())if(_0x1c3db4['query']['_queryParams']['loadsAllData']())return _0x1c3db4;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2593cc){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2593cc;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xc28f30){this['listenProvider_']=_0xc28f30,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x259e89,_0x4fc095,_0x469ef4,_0x536898,_0x1e217d){return lu(_0x259e89['pendingWriteTree_'],_0x4fc095,_0x469ef4,_0x536898,_0x1e217d),_0x1e217d?_t(_0x259e89,new Be(es(),_0x4fc095,_0x469ef4)):[];}function ju(_0x2e4586,_0x425152,_0x100165,_0x5478f0){hu(_0x2e4586['pendingWriteTree_'],_0x425152,_0x100165,_0x5478f0);const _0xc78b81=b['fromObject'](_0x100165);return _t(_0x2e4586,new ot(es(),_0x425152,_0xc78b81));}function _e(_0x28eb2d,_0x12f15f,_0x28694e=!0x1){const _0x44388a=uu(_0x28eb2d['pendingWriteTree_'],_0x12f15f);if(du(_0x28eb2d['pendingWriteTree_'],_0x12f15f)){let _0x2e6e4d=new b(null);return _0x44388a['snap']!=null?_0x2e6e4d=_0x2e6e4d['set'](w(),!0x0):x(_0x44388a['children'],_0x186e1f=>{_0x2e6e4d=_0x2e6e4d['set'](new C(_0x186e1f),!0x0);}),_t(_0x28eb2d,new In(_0x44388a['path'],_0x2e6e4d,_0x28694e));}else return[];}function Yt(_0x2cf431,_0x1d968b,_0x4d10aa){return _t(_0x2cf431,new Be(ts(),_0x1d968b,_0x4d10aa));}function Ku(_0x324e32,_0x48e558,_0x1ce92a){const _0x4fdcb3=b['fromObject'](_0x1ce92a);return _t(_0x324e32,new ot(ts(),_0x48e558,_0x4fdcb3));}function Yu(_0x108894,_0x32f9f8){return _t(_0x108894,new Ut(ts(),_0x32f9f8));}function Qu(_0x1b265d,_0x590147,_0x139e2c){const _0x3f1cfb=cs(_0x1b265d,_0x139e2c);if(_0x3f1cfb){const _0x48cfce=ls(_0x3f1cfb),_0x53a325=_0x48cfce['path'],_0xd4fe1a=_0x48cfce['queryId'],_0x2a79e3=F(_0x53a325,_0x590147),_0x2b8657=new Ut(ns(_0xd4fe1a),_0x2a79e3);return hs(_0x1b265d,_0x53a325,_0x2b8657);}else return[];}function An(_0x58ce30,_0x5897e7,_0x1b2f3d,_0x59f684,_0xa0274e=!0x1){const _0x50a27d=_0x5897e7['_path'],_0x11cc03=_0x58ce30['syncPointTree_']['get'](_0x50a27d);let _0x3162f7=[];if(_0x11cc03&&(_0x5897e7['_queryIdentifier']==='default'||Qo(_0x11cc03,_0x5897e7))){const _0xa05379=$u(_0x11cc03,_0x5897e7,_0x1b2f3d,_0x59f684);Vu(_0x11cc03)&&(_0x58ce30['syncPointTree_']=_0x58ce30['syncPointTree_']['remove'](_0x50a27d));const _0x2caeda=_0xa05379['removed'];if(_0x3162f7=_0xa05379['events'],!_0xa0274e){const _0x17d6e3=_0x2caeda['findIndex'](_0x5944fe=>_0x5944fe['_queryParams']['loadsAllData']())!==-0x1,_0x2d2383=_0x58ce30['syncPointTree_']['findOnPath'](_0x50a27d,(_0x1fd4c2,_0x1854a2)=>Se(_0x1854a2));if(_0x17d6e3&&!_0x2d2383){const _0x2f0131=_0x58ce30['syncPointTree_']['subtree'](_0x50a27d);if(!_0x2f0131['isEmpty']()){const _0x4b4d54=Zu(_0x2f0131);for(let _0x4e40bd=0x0;_0x4e40bd<_0x4b4d54['length'];++_0x4e40bd){const _0x35274f=_0x4b4d54[_0x4e40bd],_0x16626c=_0x35274f['query'],_0x48e270=ea(_0x58ce30,_0x35274f);_0x58ce30['listenProvider_']['startListening'](kt(_0x16626c),Wt(_0x58ce30,_0x16626c),_0x48e270['hashFn'],_0x48e270['onComplete']);}}}!_0x2d2383&&_0x2caeda['length']>0x0&&!_0x59f684&&(_0x17d6e3?_0x58ce30['listenProvider_']['stopListening'](kt(_0x5897e7),null):_0x2caeda['forEach'](_0x6927e2=>{const _0x37f6ba=_0x58ce30['queryToTagMap']['get'](Hn(_0x6927e2));_0x58ce30['listenProvider_']['stopListening'](kt(_0x6927e2),_0x37f6ba);}));}ed(_0x58ce30,_0x2caeda);}return _0x3162f7;}function Jo(_0x36fcdd,_0x1c0b4a,_0x2bfaff,_0x50f9fc){const _0x13fb26=cs(_0x36fcdd,_0x50f9fc);if(_0x13fb26!=null){const _0x3df5bb=ls(_0x13fb26),_0x36a3a0=_0x3df5bb['path'],_0x5f1f63=_0x3df5bb['queryId'],_0x32b0f8=F(_0x36a3a0,_0x1c0b4a),_0x1718ab=new Be(ns(_0x5f1f63),_0x32b0f8,_0x2bfaff);return hs(_0x36fcdd,_0x36a3a0,_0x1718ab);}else return[];}function Ju(_0xe47f24,_0x34ddab,_0x5a24cf,_0x35f09f){const _0x16c3d7=cs(_0xe47f24,_0x35f09f);if(_0x16c3d7){const _0x1127da=ls(_0x16c3d7),_0x33f356=_0x1127da['path'],_0x5d8060=_0x1127da['queryId'],_0x4bde5f=F(_0x33f356,_0x34ddab),_0x10f603=b['fromObject'](_0x5a24cf),_0x2e3792=new ot(ns(_0x5d8060),_0x4bde5f,_0x10f603);return hs(_0xe47f24,_0x33f356,_0x2e3792);}else return[];}function Ni(_0x18f70e,_0x2277e7,_0x1dd7ed,_0x569244=!0x1){const _0x5100e9=_0x2277e7['_path'];let _0x239e11=null,_0x2a416b=!0x1;_0x18f70e['syncPointTree_']['foreachOnPath'](_0x5100e9,(_0x49fcd1,_0x2e6f79)=>{const _0x280f5e=F(_0x49fcd1,_0x5100e9);_0x239e11=_0x239e11||Ie(_0x2e6f79,_0x280f5e),_0x2a416b=_0x2a416b||Se(_0x2e6f79);});let _0x18922c=_0x18f70e['syncPointTree_']['get'](_0x5100e9);_0x18922c?(_0x2a416b=_0x2a416b||Se(_0x18922c),_0x239e11=_0x239e11||Ie(_0x18922c,w())):(_0x18922c=new zo(),_0x18f70e['syncPointTree_']=_0x18f70e['syncPointTree_']['set'](_0x5100e9,_0x18922c));let _0x1c8b9e;_0x239e11!=null?_0x1c8b9e=!0x0:(_0x1c8b9e=!0x1,_0x239e11=g['EMPTY_NODE'],_0x18f70e['syncPointTree_']['subtree'](_0x5100e9)['foreachChild']((_0x13ac4d,_0x4f4b05)=>{const _0x3d9c3=Ie(_0x4f4b05,w());_0x3d9c3&&(_0x239e11=_0x239e11['updateImmediateChild'](_0x13ac4d,_0x3d9c3));}));const _0xaad96d=Qo(_0x18922c,_0x2277e7);if(!_0xaad96d&&!_0x2277e7['_queryParams']['loadsAllData']()){const _0x1ff6c0=Hn(_0x2277e7);f(!_0x18f70e['queryToTagMap']['has'](_0x1ff6c0),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x41e4ed=td();_0x18f70e['queryToTagMap']['set'](_0x1ff6c0,_0x41e4ed),_0x18f70e['tagToQueryMap']['set'](_0x41e4ed,_0x1ff6c0);}const _0x34cb41=Wn(_0x18f70e['pendingWriteTree_'],_0x5100e9);let _0x316040=Hu(_0x18922c,_0x2277e7,_0x1dd7ed,_0x34cb41,_0x239e11,_0x1c8b9e);if(!_0xaad96d&&!_0x2a416b&&!_0x569244){const _0xb1eae2=Yo(_0x18922c,_0x2277e7);_0x316040=_0x316040['concat'](nd(_0x18f70e,_0x2277e7,_0xb1eae2));}return _0x316040;}function Vn(_0x39f634,_0x474ce6,_0x370555){const _0x26c6ff=_0x39f634['pendingWriteTree_'],_0x55a767=_0x39f634['syncPointTree_']['findOnPath'](_0x474ce6,(_0x33161f,_0xb83f7)=>{const _0x333654=F(_0x33161f,_0x474ce6),_0x13af01=Ie(_0xb83f7,_0x333654);if(_0x13af01)return _0x13af01;});return Bo(_0x26c6ff,_0x474ce6,_0x55a767,_0x370555,!0x0);}function Xu(_0x3626e9,_0xc3f17c){const _0x6ab8dc=_0xc3f17c['_path'];let _0xbddc80=null;_0x3626e9['syncPointTree_']['foreachOnPath'](_0x6ab8dc,(_0x1bb19e,_0x39b77e)=>{const _0x215f7c=F(_0x1bb19e,_0x6ab8dc);_0xbddc80=_0xbddc80||Ie(_0x39b77e,_0x215f7c);});let _0x2c214c=_0x3626e9['syncPointTree_']['get'](_0x6ab8dc);_0x2c214c?_0xbddc80=_0xbddc80||Ie(_0x2c214c,w()):(_0x2c214c=new zo(),_0x3626e9['syncPointTree_']=_0x3626e9['syncPointTree_']['set'](_0x6ab8dc,_0x2c214c));const _0x2ee976=_0xbddc80!=null,_0x34c729=_0x2ee976?new Te(_0xbddc80,!0x0,!0x1):null,_0x3cb64f=Wn(_0x3626e9['pendingWriteTree_'],_0xc3f17c['_path']),_0x27f7b1=jo(_0x2c214c,_0xc3f17c,_0x3cb64f,_0x2ee976?_0x34c729['getNode']():g['EMPTY_NODE'],_0x2ee976);return Lu(_0x27f7b1);}function _t(_0x39fac9,_0x544e07){return Xo(_0x544e07,_0x39fac9['syncPointTree_'],null,Wn(_0x39fac9['pendingWriteTree_'],w()));}function Xo(_0x4712b3,_0x152c7a,_0x144a03,_0x50eab0){if(v(_0x4712b3['path']))return Zo(_0x4712b3,_0x152c7a,_0x144a03,_0x50eab0);{const _0x341175=_0x152c7a['get'](w());_0x144a03==null&&_0x341175!=null&&(_0x144a03=Ie(_0x341175,w()));let _0x46cbbb=[];const _0x221d02=y(_0x4712b3['path']),_0x1f669e=_0x4712b3['operationForChild'](_0x221d02),_0x52c73c=_0x152c7a['children']['get'](_0x221d02);if(_0x52c73c&&_0x1f669e){const _0x59114d=_0x144a03?_0x144a03['getImmediateChild'](_0x221d02):null,_0x34133a=Vo(_0x50eab0,_0x221d02);_0x46cbbb=_0x46cbbb['concat'](Xo(_0x1f669e,_0x52c73c,_0x59114d,_0x34133a));}return _0x341175&&(_0x46cbbb=_0x46cbbb['concat'](os(_0x341175,_0x4712b3,_0x50eab0,_0x144a03))),_0x46cbbb;}}function Zo(_0x3fcf3f,_0x223ed6,_0x22cb59,_0x1915e7){const _0x2893ab=_0x223ed6['get'](w());_0x22cb59==null&&_0x2893ab!=null&&(_0x22cb59=Ie(_0x2893ab,w()));let _0x133f80=[];return _0x223ed6['children']['inorderTraversal']((_0x1962fd,_0x542b7e)=>{const _0x5ad940=_0x22cb59?_0x22cb59['getImmediateChild'](_0x1962fd):null,_0x3beab6=Vo(_0x1915e7,_0x1962fd),_0x1d3f94=_0x3fcf3f['operationForChild'](_0x1962fd);_0x1d3f94&&(_0x133f80=_0x133f80['concat'](Zo(_0x1d3f94,_0x542b7e,_0x5ad940,_0x3beab6)));}),_0x2893ab&&(_0x133f80=_0x133f80['concat'](os(_0x2893ab,_0x3fcf3f,_0x1915e7,_0x22cb59))),_0x133f80;}function ea(_0x23b5f7,_0x4129dd){const _0x172dc4=_0x4129dd['query'],_0x19c8a1=Wt(_0x23b5f7,_0x172dc4);return{'hashFn':()=>(Mu(_0x4129dd)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3c7d23=>{if(_0x3c7d23==='ok')return _0x19c8a1?Qu(_0x23b5f7,_0x172dc4['_path'],_0x19c8a1):Yu(_0x23b5f7,_0x172dc4['_path']);{const _0x4debc3=Kl(_0x3c7d23,_0x172dc4);return An(_0x23b5f7,_0x172dc4,null,_0x4debc3);}}};}function Wt(_0x2a5bc0,_0x4b5189){const _0x4a0fb6=Hn(_0x4b5189);return _0x2a5bc0['queryToTagMap']['get'](_0x4a0fb6);}function Hn(_0x5d5366){return _0x5d5366['_path']['toString']()+'$'+_0x5d5366['_queryIdentifier'];}function cs(_0x3fafe2,_0x471354){return _0x3fafe2['tagToQueryMap']['get'](_0x471354);}function ls(_0xce223a){const _0x2b4e34=_0xce223a['indexOf']('$');return f(_0x2b4e34!==-0x1&&_0x2b4e34<_0xce223a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xce223a['substr'](_0x2b4e34+0x1),'path':new C(_0xce223a['substr'](0x0,_0x2b4e34))};}function hs(_0x4d7eb6,_0x11b28a,_0x424b85){const _0x29281a=_0x4d7eb6['syncPointTree_']['get'](_0x11b28a);f(_0x29281a,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x21f248=Wn(_0x4d7eb6['pendingWriteTree_'],_0x11b28a);return os(_0x29281a,_0x424b85,_0x21f248,null);}function Zu(_0x159b66){return _0x159b66['fold']((_0xd2381d,_0x5ca8be,_0x1a5819)=>{if(_0x5ca8be&&Se(_0x5ca8be))return[Bn(_0x5ca8be)];{let _0x1d4394=[];return _0x5ca8be&&(_0x1d4394=Ko(_0x5ca8be)),x(_0x1a5819,(_0x5d7e6f,_0x593ede)=>{_0x1d4394=_0x1d4394['concat'](_0x593ede);}),_0x1d4394;}});}function kt(_0x48fe92){return _0x48fe92['_queryParams']['loadsAllData']()&&!_0x48fe92['_queryParams']['isDefault']()?new(qu())(_0x48fe92['_repo'],_0x48fe92['_path']):_0x48fe92;}function ed(_0x57e1ad,_0x494c46){for(let _0x2137f3=0x0;_0x2137f3<_0x494c46['length'];++_0x2137f3){const _0x5c1d4f=_0x494c46[_0x2137f3];if(!_0x5c1d4f['_queryParams']['loadsAllData']()){const _0x1d50be=Hn(_0x5c1d4f),_0x530556=_0x57e1ad['queryToTagMap']['get'](_0x1d50be);_0x57e1ad['queryToTagMap']['delete'](_0x1d50be),_0x57e1ad['tagToQueryMap']['delete'](_0x530556);}}}function td(){return zu++;}function nd(_0x4d414a,_0x42b189,_0x4757c3){const _0x20a040=_0x42b189['_path'],_0x333d47=Wt(_0x4d414a,_0x42b189),_0x1c8356=ea(_0x4d414a,_0x4757c3),_0xf81a80=_0x4d414a['listenProvider_']['startListening'](kt(_0x42b189),_0x333d47,_0x1c8356['hashFn'],_0x1c8356['onComplete']),_0x191423=_0x4d414a['syncPointTree_']['subtree'](_0x20a040);if(_0x333d47)f(!Se(_0x191423['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x14c854=_0x191423['fold']((_0x183898,_0x36e0f7,_0xfb4404)=>{if(!v(_0x183898)&&_0x36e0f7&&Se(_0x36e0f7))return[Bn(_0x36e0f7)['query']];{let _0x16df6d=[];return _0x36e0f7&&(_0x16df6d=_0x16df6d['concat'](Ko(_0x36e0f7)['map'](_0x309ca1=>_0x309ca1['query']))),x(_0xfb4404,(_0x173875,_0x314639)=>{_0x16df6d=_0x16df6d['concat'](_0x314639);}),_0x16df6d;}});for(let _0x191154=0x0;_0x191154<_0x14c854['length'];++_0x191154){const _0x2938c7=_0x14c854[_0x191154];_0x4d414a['listenProvider_']['stopListening'](kt(_0x2938c7),Wt(_0x4d414a,_0x2938c7));}}return _0xf81a80;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x51f57e){this['node_']=_0x51f57e;}['getImmediateChild'](_0x254e49){const _0x22372b=this['node_']['getImmediateChild'](_0x254e49);return new us(_0x22372b);}['node'](){return this['node_'];}}class ds{constructor(_0x495b8e,_0x3523a5){this['syncTree_']=_0x495b8e,this['path_']=_0x3523a5;}['getImmediateChild'](_0xccfd03){const _0x115f38=k(this['path_'],_0xccfd03);return new ds(this['syncTree_'],_0x115f38);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x18300c){return _0x18300c=_0x18300c||{},_0x18300c['timestamp']=_0x18300c['timestamp']||new Date()['getTime'](),_0x18300c;},_r=function(_0x162c75,_0x12e58e,_0x4a573a){if(!_0x162c75||typeof _0x162c75!='object')return _0x162c75;if(f('.sv'in _0x162c75,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x162c75['.sv']=='string')return sd(_0x162c75['.sv'],_0x12e58e,_0x4a573a);if(typeof _0x162c75['.sv']=='object')return rd(_0x162c75['.sv'],_0x12e58e);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x162c75,null,0x2));},sd=function(_0x33b429,_0x1a913a,_0x425a9c){switch(_0x33b429){case'timestamp':return _0x425a9c['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x33b429);}},rd=function(_0xdf3939,_0x2a6898,_0xbb5d8f){_0xdf3939['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xdf3939,null,0x2));const _0x2e840f=_0xdf3939['increment'];typeof _0x2e840f!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2e840f);const _0x2b0642=_0x2a6898['node']();if(f(_0x2b0642!==null&&typeof _0x2b0642<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2b0642['isLeafNode']())return _0x2e840f;const _0x31445f=_0x2b0642['getValue']();return typeof _0x31445f!='number'?_0x2e840f:_0x31445f+_0x2e840f;},ta=function(_0x3e0d1e,_0x22fde9,_0x1c7b95,_0x239561){return ps(_0x22fde9,new ds(_0x1c7b95,_0x3e0d1e),_0x239561);},fs=function(_0x59636f,_0x12d001,_0xfbc883){return ps(_0x59636f,new us(_0x12d001),_0xfbc883);};function ps(_0x20167e,_0x52568d,_0x21b58b){const _0x7cefca=_0x20167e['getPriority']()['val'](),_0x170291=_r(_0x7cefca,_0x52568d['getImmediateChild']('.priority'),_0x21b58b);let _0x196f01;if(_0x20167e['isLeafNode']()){const _0xf6676c=_0x20167e,_0x4a4471=_r(_0xf6676c['getValue'](),_0x52568d,_0x21b58b);return _0x4a4471!==_0xf6676c['getValue']()||_0x170291!==_0xf6676c['getPriority']()['val']()?new D(_0x4a4471,A(_0x170291)):_0x20167e;}else{const _0x58c75c=_0x20167e;return _0x196f01=_0x58c75c,_0x170291!==_0x58c75c['getPriority']()['val']()&&(_0x196f01=_0x196f01['updatePriority'](new D(_0x170291))),_0x58c75c['forEachChild'](R,(_0x4359be,_0x18aa85)=>{const _0x293b86=ps(_0x18aa85,_0x52568d['getImmediateChild'](_0x4359be),_0x21b58b);_0x293b86!==_0x18aa85&&(_0x196f01=_0x196f01['updateImmediateChild'](_0x4359be,_0x293b86));}),_0x196f01;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0xe45477='',_0x3fdc4c=null,_0x15c1b9={'children':{},'childCount':0x0}){this['name']=_0xe45477,this['parent']=_0x3fdc4c,this['node']=_0x15c1b9;}}function $n(_0x3dad42,_0x40f100){let _0x3881f4=_0x40f100 instanceof C?_0x40f100:new C(_0x40f100),_0x4289b4=_0x3dad42,_0x1155e6=y(_0x3881f4);for(;_0x1155e6!==null;){const _0x9a6eb=Le(_0x4289b4['node']['children'],_0x1155e6)||{'children':{},'childCount':0x0};_0x4289b4=new _s(_0x1155e6,_0x4289b4,_0x9a6eb),_0x3881f4=S(_0x3881f4),_0x1155e6=y(_0x3881f4);}return _0x4289b4;}function je(_0x54df73){return _0x54df73['node']['value'];}function gs(_0x18b871,_0x2560f4){_0x18b871['node']['value']=_0x2560f4,Oi(_0x18b871);}function na(_0xeaf159){return _0xeaf159['node']['childCount']>0x0;}function od(_0x2b0b23){return je(_0x2b0b23)===void 0x0&&!na(_0x2b0b23);}function Gn(_0x391cae,_0x5d6967){x(_0x391cae['node']['children'],(_0x25abc5,_0x2665ad)=>{_0x5d6967(new _s(_0x25abc5,_0x391cae,_0x2665ad));});}function ia(_0x18ff07,_0x17b9ae,_0x34311e,_0x3dab70){_0x34311e&&_0x17b9ae(_0x18ff07),Gn(_0x18ff07,_0x2a006b=>{ia(_0x2a006b,_0x17b9ae,!0x0);});}function ad(_0x2170be,_0x259aaa,_0x32184b){let _0x328207=_0x2170be['parent'];for(;_0x328207!==null;){if(_0x259aaa(_0x328207))return!0x0;_0x328207=_0x328207['parent'];}return!0x1;}function Qt(_0x5bdee8){return new C(_0x5bdee8['parent']===null?_0x5bdee8['name']:Qt(_0x5bdee8['parent'])+'/'+_0x5bdee8['name']);}function Oi(_0x42b93a){_0x42b93a['parent']!==null&&cd(_0x42b93a['parent'],_0x42b93a['name'],_0x42b93a);}function cd(_0x5934cc,_0x562f06,_0x2c2dea){const _0x20794e=od(_0x2c2dea),_0x593476=Q(_0x5934cc['node']['children'],_0x562f06);_0x20794e&&_0x593476?(delete _0x5934cc['node']['children'][_0x562f06],_0x5934cc['node']['childCount']--,Oi(_0x5934cc)):!_0x20794e&&!_0x593476&&(_0x5934cc['node']['children'][_0x562f06]=_0x2c2dea['node'],_0x5934cc['node']['childCount']++,Oi(_0x5934cc));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x18fe86){return typeof _0x18fe86=='string'&&_0x18fe86['length']!==0x0&&!ld['test'](_0x18fe86);},sa=function(_0x4ab338){return typeof _0x4ab338=='string'&&_0x4ab338['length']!==0x0&&!hd['test'](_0x4ab338);},ud=function(_0xd10f12){return _0xd10f12&&(_0xd10f12=_0xd10f12['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xd10f12);},Bt=function(_0x654bc3){return _0x654bc3===null||typeof _0x654bc3=='string'||typeof _0x654bc3=='number'&&!xn(_0x654bc3)||_0x654bc3&&typeof _0x654bc3=='object'&&Q(_0x654bc3,'.sv');},He=function(_0x84bc98,_0xdd2713,_0xab1c38,_0x1d9473){_0x1d9473&&_0xdd2713===void 0x0||Jt(it(_0x84bc98,'value'),_0xdd2713,_0xab1c38);},Jt=function(_0x3f0321,_0x5ab075,_0x4bb7a5){const _0x2793aa=_0x4bb7a5 instanceof C?new Ah(_0x4bb7a5,_0x3f0321):_0x4bb7a5;if(_0x5ab075===void 0x0)throw new Error(_0x3f0321+'contains\x20undefined\x20'+Oe(_0x2793aa));if(typeof _0x5ab075=='function')throw new Error(_0x3f0321+'contains\x20a\x20function\x20'+Oe(_0x2793aa)+'\x20with\x20contents\x20=\x20'+_0x5ab075['toString']());if(xn(_0x5ab075))throw new Error(_0x3f0321+'contains\x20'+_0x5ab075['toString']()+'\x20'+Oe(_0x2793aa));if(typeof _0x5ab075=='string'&&_0x5ab075['length']>ui/0x3&&Ln(_0x5ab075)>ui)throw new Error(_0x3f0321+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2793aa)+'\x20(\x27'+_0x5ab075['substring'](0x0,0x32)+'...\x27)');if(_0x5ab075&&typeof _0x5ab075=='object'){let _0x26525f=!0x1,_0x155de3=!0x1;if(x(_0x5ab075,(_0x51dafc,_0x5473bf)=>{if(_0x51dafc==='.value')_0x26525f=!0x0;else{if(_0x51dafc!=='.priority'&&_0x51dafc!=='.sv'&&(_0x155de3=!0x0,!ms(_0x51dafc)))throw new Error(_0x3f0321+'\x20contains\x20an\x20invalid\x20key\x20('+_0x51dafc+')\x20'+Oe(_0x2793aa)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2793aa,_0x51dafc),Jt(_0x3f0321,_0x5473bf,_0x2793aa),Ph(_0x2793aa);}),_0x26525f&&_0x155de3)throw new Error(_0x3f0321+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2793aa)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5be122,_0x33edb5){let _0x356995,_0x2ac874;for(_0x356995=0x0;_0x356995<_0x33edb5['length'];_0x356995++){_0x2ac874=_0x33edb5[_0x356995];const _0x121683=Mt(_0x2ac874);for(let _0x5098a8=0x0;_0x5098a8<_0x121683['length'];_0x5098a8++)if(!(_0x121683[_0x5098a8]==='.priority'&&_0x5098a8===_0x121683['length']-0x1)){if(!ms(_0x121683[_0x5098a8]))throw new Error(_0x5be122+'contains\x20an\x20invalid\x20key\x20('+_0x121683[_0x5098a8]+')\x20in\x20path\x20'+_0x2ac874['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x33edb5['sort'](Rh);let _0xe95391=null;for(_0x356995=0x0;_0x356995<_0x33edb5['length'];_0x356995++){if(_0x2ac874=_0x33edb5[_0x356995],_0xe95391!==null&&G(_0xe95391,_0x2ac874))throw new Error(_0x5be122+'contains\x20a\x20path\x20'+_0xe95391['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2ac874['toString']());_0xe95391=_0x2ac874;}},ra=function(_0x104bc2,_0x2f3671,_0x98bec7,_0x1e74d1){const _0x4b8ba8=it(_0x104bc2,'values');if(!(_0x2f3671&&typeof _0x2f3671=='object')||Array['isArray'](_0x2f3671))throw new Error(_0x4b8ba8+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1513ea=[];x(_0x2f3671,(_0x2857b5,_0x39bcd4)=>{const _0x97a7ce=new C(_0x2857b5);if(Jt(_0x4b8ba8,_0x39bcd4,k(_0x98bec7,_0x97a7ce)),ji(_0x97a7ce)==='.priority'&&!Bt(_0x39bcd4))throw new Error(_0x4b8ba8+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x97a7ce['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1513ea['push'](_0x97a7ce);}),dd(_0x4b8ba8,_0x1513ea);},fd=function(_0x6ee2df,_0x4c12c5,_0x3bfe6b){if(xn(_0x4c12c5))throw new Error(it(_0x6ee2df,'priority')+'is\x20'+_0x4c12c5['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4c12c5))throw new Error(it(_0x6ee2df,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x3188df,_0x2dccb1,_0x2d47e7,_0xe936c9){if(!sa(_0x2d47e7))throw new Error(it(_0x3188df,_0x2dccb1)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2d47e7+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4e4095,_0x21283b,_0x29f740,_0xb974e9){_0x29f740&&(_0x29f740=_0x29f740['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4e4095,_0x21283b,_0x29f740);},Me=function(_0x7b0bb1,_0x414d8d){if(y(_0x414d8d)==='.info')throw new Error(_0x7b0bb1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x253e1c,_0x56cbf1){const _0x38151b=_0x56cbf1['path']['toString']();if(typeof _0x56cbf1['repoInfo']['host']!='string'||_0x56cbf1['repoInfo']['host']['length']===0x0||!ms(_0x56cbf1['repoInfo']['namespace'])&&_0x56cbf1['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x38151b['length']!==0x0&&!ud(_0x38151b))throw new Error(it(_0x253e1c,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3c584c,_0x120b95){let _0x53832b=null;for(let _0x154ab7=0x0;_0x154ab7<_0x120b95['length'];_0x154ab7++){const _0x3ff2d9=_0x120b95[_0x154ab7],_0x29dd52=_0x3ff2d9['getPath']();_0x53832b!==null&&!Ki(_0x29dd52,_0x53832b['path'])&&(_0x3c584c['eventLists_']['push'](_0x53832b),_0x53832b=null),_0x53832b===null&&(_0x53832b={'events':[],'path':_0x29dd52}),_0x53832b['events']['push'](_0x3ff2d9);}_0x53832b&&_0x3c584c['eventLists_']['push'](_0x53832b);}function oa(_0x408d76,_0x51fe0b,_0x27491e){qn(_0x408d76,_0x27491e),aa(_0x408d76,_0x3ae24f=>Ki(_0x3ae24f,_0x51fe0b));}function V(_0x4c7973,_0x40033e,_0x16f1d0){qn(_0x4c7973,_0x16f1d0),aa(_0x4c7973,_0x2925b7=>G(_0x2925b7,_0x40033e)||G(_0x40033e,_0x2925b7));}function aa(_0x576411,_0x42589c){_0x576411['recursionDepth_']++;let _0x16b71c=!0x0;for(let _0x338fe7=0x0;_0x338fe7<_0x576411['eventLists_']['length'];_0x338fe7++){const _0x4c85d6=_0x576411['eventLists_'][_0x338fe7];if(_0x4c85d6){const _0x52c8bb=_0x4c85d6['path'];_0x42589c(_0x52c8bb)?(md(_0x576411['eventLists_'][_0x338fe7]),_0x576411['eventLists_'][_0x338fe7]=null):_0x16b71c=!0x1;}}_0x16b71c&&(_0x576411['eventLists_']=[]),_0x576411['recursionDepth_']--;}function md(_0x2269b4){for(let _0x505feb=0x0;_0x505feb<_0x2269b4['events']['length'];_0x505feb++){const _0x1d8390=_0x2269b4['events'][_0x505feb];if(_0x1d8390!==null){_0x2269b4['events'][_0x505feb]=null;const _0x5ee57b=_0x1d8390['getEventRunner']();St&&L('event:\x20'+_0x1d8390['toString']()),ft(_0x5ee57b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x2a6a44,_0x2d5972,_0x25a26e,_0x2bc70d){this['repoInfo_']=_0x2a6a44,this['forceRestClient_']=_0x2d5972,this['authTokenProvider_']=_0x25a26e,this['appCheckProvider_']=_0x2bc70d,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x32de29,_0x457e35,_0x1f2d4f){if(_0x32de29['stats_']=qi(_0x32de29['repoInfo_']),_0x32de29['forceRestClient_']||Xl())_0x32de29['server_']=new vn(_0x32de29['repoInfo_'],(_0x2531f8,_0x525408,_0x592f4b,_0x21fe10)=>{gr(_0x32de29,_0x2531f8,_0x525408,_0x592f4b,_0x21fe10);},_0x32de29['authTokenProvider_'],_0x32de29['appCheckProvider_']),setTimeout(()=>mr(_0x32de29,!0x0),0x0);else{if(typeof _0x1f2d4f<'u'&&_0x1f2d4f!==null){if(typeof _0x1f2d4f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1f2d4f);}catch(_0xebbebb){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0xebbebb);}}_0x32de29['persistentConnection_']=new se(_0x32de29['repoInfo_'],_0x457e35,(_0x308979,_0x57b8d5,_0x19a48a,_0x1de146)=>{gr(_0x32de29,_0x308979,_0x57b8d5,_0x19a48a,_0x1de146);},_0x4a9477=>{mr(_0x32de29,_0x4a9477);},_0x2a8010=>{Id(_0x32de29,_0x2a8010);},_0x32de29['authTokenProvider_'],_0x32de29['appCheckProvider_'],_0x1f2d4f),_0x32de29['server_']=_0x32de29['persistentConnection_'];}_0x32de29['authTokenProvider_']['addTokenChangeListener'](_0x1d05a2=>{_0x32de29['server_']['refreshAuthToken'](_0x1d05a2);}),_0x32de29['appCheckProvider_']['addTokenChangeListener'](_0x485281=>{_0x32de29['server_']['refreshAppCheckToken'](_0x485281['token']);}),_0x32de29['statsReporter_']=ih(_0x32de29['repoInfo_'],()=>new iu(_0x32de29['stats_'],_0x32de29['server_'])),_0x32de29['infoData_']=new Xh(),_0x32de29['infoSyncTree_']=new pr({'startListening':(_0x42600e,_0x4f15e2,_0x3419ec,_0x3594ca)=>{let _0x35f66f=[];const _0x5989b4=_0x32de29['infoData_']['getNode'](_0x42600e['_path']);return _0x5989b4['isEmpty']()||(_0x35f66f=Yt(_0x32de29['infoSyncTree_'],_0x42600e['_path'],_0x5989b4),setTimeout(()=>{_0x3594ca('ok');},0x0)),_0x35f66f;},'stopListening':()=>{}}),vs(_0x32de29,'connected',!0x1),_0x32de29['serverSyncTree_']=new pr({'startListening':(_0x41d792,_0x43a0b9,_0xa2a6e3,_0x2157c0)=>(_0x32de29['server_']['listen'](_0x41d792,_0xa2a6e3,_0x43a0b9,(_0x3b8365,_0x2f947d)=>{const _0x5ea0d0=_0x2157c0(_0x3b8365,_0x2f947d);V(_0x32de29['eventQueue_'],_0x41d792['_path'],_0x5ea0d0);}),[]),'stopListening':(_0x2b803d,_0x2f209e)=>{_0x32de29['server_']['unlisten'](_0x2b803d,_0x2f209e);}});}function la(_0x2f3396){const _0x46b7fd=_0x2f3396['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x46b7fd;}function Xt(_0xd1fa26){return id({'timestamp':la(_0xd1fa26)});}function gr(_0x53c23a,_0x21e458,_0x31fa4b,_0x51b504,_0x4f8516){_0x53c23a['dataUpdateCount']++;const _0x37f857=new C(_0x21e458);_0x31fa4b=_0x53c23a['interceptServerDataCallback_']?_0x53c23a['interceptServerDataCallback_'](_0x21e458,_0x31fa4b):_0x31fa4b;let _0x5d5fc3=[];if(_0x4f8516){if(_0x51b504){const _0x3136c9=_n(_0x31fa4b,_0x38f841=>A(_0x38f841));_0x5d5fc3=Ju(_0x53c23a['serverSyncTree_'],_0x37f857,_0x3136c9,_0x4f8516);}else{const _0x4e4e3a=A(_0x31fa4b);_0x5d5fc3=Jo(_0x53c23a['serverSyncTree_'],_0x37f857,_0x4e4e3a,_0x4f8516);}}else{if(_0x51b504){const _0x4d1efa=_n(_0x31fa4b,_0x2a9c4e=>A(_0x2a9c4e));_0x5d5fc3=Ku(_0x53c23a['serverSyncTree_'],_0x37f857,_0x4d1efa);}else{const _0x43f403=A(_0x31fa4b);_0x5d5fc3=Yt(_0x53c23a['serverSyncTree_'],_0x37f857,_0x43f403);}}let _0x50ad06=_0x37f857;_0x5d5fc3['length']>0x0&&(_0x50ad06=ct(_0x53c23a,_0x37f857)),V(_0x53c23a['eventQueue_'],_0x50ad06,_0x5d5fc3);}function mr(_0x361160,_0xec6956){vs(_0x361160,'connected',_0xec6956),_0xec6956===!0x1&&Sd(_0x361160);}function Id(_0x2082d6,_0x15223f){x(_0x15223f,(_0x4aae0c,_0x305756)=>{vs(_0x2082d6,_0x4aae0c,_0x305756);});}function vs(_0x4393dc,_0x52af1a,_0x341777){const _0x411721=new C('/.info/'+_0x52af1a),_0x4e56c7=A(_0x341777);_0x4393dc['infoData_']['updateSnapshot'](_0x411721,_0x4e56c7);const _0x4c2b46=Yt(_0x4393dc['infoSyncTree_'],_0x411721,_0x4e56c7);V(_0x4393dc['eventQueue_'],_0x411721,_0x4c2b46);}function zn(_0x4f7e19){return _0x4f7e19['nextWriteId_']++;}function wd(_0x41ef82,_0x12bc13,_0x1046c3){const _0x5a3563=Xu(_0x41ef82['serverSyncTree_'],_0x12bc13);return _0x5a3563!=null?Promise['resolve'](_0x5a3563):_0x41ef82['server_']['get'](_0x12bc13)['then'](_0x1278b2=>{const _0x1f2a07=A(_0x1278b2)['withIndex'](_0x12bc13['_queryParams']['getIndex']());Ni(_0x41ef82['serverSyncTree_'],_0x12bc13,_0x1046c3,!0x0);let _0x6c5ed3;if(_0x12bc13['_queryParams']['loadsAllData']())_0x6c5ed3=Yt(_0x41ef82['serverSyncTree_'],_0x12bc13['_path'],_0x1f2a07);else{const _0x32217c=Wt(_0x41ef82['serverSyncTree_'],_0x12bc13);_0x6c5ed3=Jo(_0x41ef82['serverSyncTree_'],_0x12bc13['_path'],_0x1f2a07,_0x32217c);}return V(_0x41ef82['eventQueue_'],_0x12bc13['_path'],_0x6c5ed3),An(_0x41ef82['serverSyncTree_'],_0x12bc13,_0x1046c3,null,!0x0),_0x1f2a07;},_0x5c226e=>(gt(_0x41ef82,'get\x20for\x20query\x20'+O(_0x12bc13)+'\x20failed:\x20'+_0x5c226e),Promise['reject'](new Error(_0x5c226e))));}function Cd(_0x2cc20a,_0x3a029f,_0x1ee285,_0x51c590,_0x163c3a){gt(_0x2cc20a,'set',{'path':_0x3a029f['toString'](),'value':_0x1ee285,'priority':_0x51c590});const _0x5cdf14=Xt(_0x2cc20a),_0x55dc31=A(_0x1ee285,_0x51c590),_0x2bdee1=Vn(_0x2cc20a['serverSyncTree_'],_0x3a029f),_0x28ed65=fs(_0x55dc31,_0x2bdee1,_0x5cdf14),_0x2e4736=zn(_0x2cc20a),_0x5ec210=as(_0x2cc20a['serverSyncTree_'],_0x3a029f,_0x28ed65,_0x2e4736,!0x0);qn(_0x2cc20a['eventQueue_'],_0x5ec210),_0x2cc20a['server_']['put'](_0x3a029f['toString'](),_0x55dc31['val'](!0x0),(_0x27c90d,_0xa5c73a)=>{const _0x3de55e=_0x27c90d==='ok';_0x3de55e||U('set\x20at\x20'+_0x3a029f+'\x20failed:\x20'+_0x27c90d);const _0x4676fd=_e(_0x2cc20a['serverSyncTree_'],_0x2e4736,!_0x3de55e);V(_0x2cc20a['eventQueue_'],_0x3a029f,_0x4676fd),be(_0x2cc20a,_0x163c3a,_0x27c90d,_0xa5c73a);});const _0x5f460c=Is(_0x2cc20a,_0x3a029f);ct(_0x2cc20a,_0x5f460c),V(_0x2cc20a['eventQueue_'],_0x5f460c,[]);}function Td(_0x541802,_0x2af7ef,_0x9aa67b,_0x45fe3b){gt(_0x541802,'update',{'path':_0x2af7ef['toString'](),'value':_0x9aa67b});let _0x538f0f=!0x0;const _0x41622b=Xt(_0x541802),_0x3f867e={};if(x(_0x9aa67b,(_0x46c633,_0x21db18)=>{_0x538f0f=!0x1,_0x3f867e[_0x46c633]=ta(k(_0x2af7ef,_0x46c633),A(_0x21db18),_0x541802['serverSyncTree_'],_0x41622b);}),_0x538f0f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x541802,_0x45fe3b,'ok',void 0x0);else{const _0x575a6c=zn(_0x541802),_0x1cdc21=ju(_0x541802['serverSyncTree_'],_0x2af7ef,_0x3f867e,_0x575a6c);qn(_0x541802['eventQueue_'],_0x1cdc21),_0x541802['server_']['merge'](_0x2af7ef['toString'](),_0x9aa67b,(_0x1a4e5e,_0xcbe4d9)=>{const _0x27a1c7=_0x1a4e5e==='ok';_0x27a1c7||U('update\x20at\x20'+_0x2af7ef+'\x20failed:\x20'+_0x1a4e5e);const _0x35a51e=_e(_0x541802['serverSyncTree_'],_0x575a6c,!_0x27a1c7),_0x445232=_0x35a51e['length']>0x0?ct(_0x541802,_0x2af7ef):_0x2af7ef;V(_0x541802['eventQueue_'],_0x445232,_0x35a51e),be(_0x541802,_0x45fe3b,_0x1a4e5e,_0xcbe4d9);}),x(_0x9aa67b,_0x42c646=>{const _0x665bd0=Is(_0x541802,k(_0x2af7ef,_0x42c646));ct(_0x541802,_0x665bd0);}),V(_0x541802['eventQueue_'],_0x2af7ef,[]);}}function Sd(_0x165fc7){gt(_0x165fc7,'onDisconnectEvents');const _0x450463=Xt(_0x165fc7),_0x2bfef9=En();Si(_0x165fc7['onDisconnect_'],w(),(_0x5885d6,_0x9fb3ed)=>{const _0x8c4c7e=ta(_0x5885d6,_0x9fb3ed,_0x165fc7['serverSyncTree_'],_0x450463);pt(_0x2bfef9,_0x5885d6,_0x8c4c7e);});let _0x5e2883=[];Si(_0x2bfef9,w(),(_0x14dd4e,_0x5587f3)=>{_0x5e2883=_0x5e2883['concat'](Yt(_0x165fc7['serverSyncTree_'],_0x14dd4e,_0x5587f3));const _0x4d099e=Is(_0x165fc7,_0x14dd4e);ct(_0x165fc7,_0x4d099e);}),_0x165fc7['onDisconnect_']=En(),V(_0x165fc7['eventQueue_'],w(),_0x5e2883);}function bd(_0x11be7e,_0x577951,_0x229d58){_0x11be7e['server_']['onDisconnectCancel'](_0x577951['toString'](),(_0x185709,_0x4da44e)=>{_0x185709==='ok'&&Ti(_0x11be7e['onDisconnect_'],_0x577951),be(_0x11be7e,_0x229d58,_0x185709,_0x4da44e);});}function yr(_0x48ada3,_0x21c760,_0x271b32,_0x1fb192){const _0x26fba7=A(_0x271b32);_0x48ada3['server_']['onDisconnectPut'](_0x21c760['toString'](),_0x26fba7['val'](!0x0),(_0x25f163,_0x3b3ba3)=>{_0x25f163==='ok'&&pt(_0x48ada3['onDisconnect_'],_0x21c760,_0x26fba7),be(_0x48ada3,_0x1fb192,_0x25f163,_0x3b3ba3);});}function Rd(_0x3646da,_0x279bb7,_0x965c79,_0x1ceffb,_0xb4d6e2){const _0x1bc5dc=A(_0x965c79,_0x1ceffb);_0x3646da['server_']['onDisconnectPut'](_0x279bb7['toString'](),_0x1bc5dc['val'](!0x0),(_0x20fc18,_0x7a7d8a)=>{_0x20fc18==='ok'&&pt(_0x3646da['onDisconnect_'],_0x279bb7,_0x1bc5dc),be(_0x3646da,_0xb4d6e2,_0x20fc18,_0x7a7d8a);});}function Ad(_0x3310d6,_0x1cf337,_0x434d23,_0x4849ca){if(pn(_0x434d23)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3310d6,_0x4849ca,'ok',void 0x0);return;}_0x3310d6['server_']['onDisconnectMerge'](_0x1cf337['toString'](),_0x434d23,(_0x33e5f3,_0x30d1ea)=>{_0x33e5f3==='ok'&&x(_0x434d23,(_0x4a3c61,_0x33c136)=>{const _0x4fe2e8=A(_0x33c136);pt(_0x3310d6['onDisconnect_'],k(_0x1cf337,_0x4a3c61),_0x4fe2e8);}),be(_0x3310d6,_0x4849ca,_0x33e5f3,_0x30d1ea);});}function kd(_0x4c2c6b,_0x4c424a,_0x4a86cd){let _0x4e787a;y(_0x4c424a['_path'])==='.info'?_0x4e787a=Ni(_0x4c2c6b['infoSyncTree_'],_0x4c424a,_0x4a86cd):_0x4e787a=Ni(_0x4c2c6b['serverSyncTree_'],_0x4c424a,_0x4a86cd),oa(_0x4c2c6b['eventQueue_'],_0x4c424a['_path'],_0x4e787a);}function Pd(_0x19e8d5,_0x3cd10d,_0x26e72b){let _0x3adc23;y(_0x3cd10d['_path'])==='.info'?_0x3adc23=An(_0x19e8d5['infoSyncTree_'],_0x3cd10d,_0x26e72b):_0x3adc23=An(_0x19e8d5['serverSyncTree_'],_0x3cd10d,_0x26e72b),oa(_0x19e8d5['eventQueue_'],_0x3cd10d['_path'],_0x3adc23);}function ha(_0xf79ef7){_0xf79ef7['persistentConnection_']&&_0xf79ef7['persistentConnection_']['interrupt'](ca);}function Nd(_0x3bcdd1){_0x3bcdd1['persistentConnection_']&&_0x3bcdd1['persistentConnection_']['resume'](ca);}function gt(_0xd6bc61,..._0x5e79bb){let _0x553a7f='';_0xd6bc61['persistentConnection_']&&(_0x553a7f=_0xd6bc61['persistentConnection_']['id']+':'),L(_0x553a7f,..._0x5e79bb);}function be(_0x140b9f,_0x254155,_0xc8844f,_0x57bf64){_0x254155&&ft(()=>{if(_0xc8844f==='ok')_0x254155(null);else{const _0x240d31=(_0xc8844f||'error')['toUpperCase']();let _0x4c28e3=_0x240d31;_0x57bf64&&(_0x4c28e3+=':\x20'+_0x57bf64);const _0x4498ef=new Error(_0x4c28e3);_0x4498ef['code']=_0x240d31,_0x254155(_0x4498ef);}});}function Od(_0x3abee9,_0x14396a,_0x6f77e3,_0x425bac,_0x3ca9fa,_0x15b556){gt(_0x3abee9,'transaction\x20on\x20'+_0x14396a);const _0x4ffbf0={'path':_0x14396a,'update':_0x6f77e3,'onComplete':_0x425bac,'status':null,'order':so(),'applyLocally':_0x15b556,'retryCount':0x0,'unwatcher':_0x3ca9fa,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x52105e=Es(_0x3abee9,_0x14396a,void 0x0);_0x4ffbf0['currentInputSnapshot']=_0x52105e;const _0x5d3aee=_0x4ffbf0['update'](_0x52105e['val']());if(_0x5d3aee===void 0x0)_0x4ffbf0['unwatcher'](),_0x4ffbf0['currentOutputSnapshotRaw']=null,_0x4ffbf0['currentOutputSnapshotResolved']=null,_0x4ffbf0['onComplete']&&_0x4ffbf0['onComplete'](null,!0x1,_0x4ffbf0['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5d3aee,_0x4ffbf0['path']),_0x4ffbf0['status']=0x0;const _0x123ebe=$n(_0x3abee9['transactionQueueTree_'],_0x14396a),_0x567318=je(_0x123ebe)||[];_0x567318['push'](_0x4ffbf0),gs(_0x123ebe,_0x567318);let _0x3f325c;typeof _0x5d3aee=='object'&&_0x5d3aee!==null&&Q(_0x5d3aee,'.priority')?(_0x3f325c=Le(_0x5d3aee,'.priority'),f(Bt(_0x3f325c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3f325c=(Vn(_0x3abee9['serverSyncTree_'],_0x14396a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2a0f79=Xt(_0x3abee9),_0x2de54e=A(_0x5d3aee,_0x3f325c),_0x31921c=fs(_0x2de54e,_0x52105e,_0x2a0f79);_0x4ffbf0['currentOutputSnapshotRaw']=_0x2de54e,_0x4ffbf0['currentOutputSnapshotResolved']=_0x31921c,_0x4ffbf0['currentWriteId']=zn(_0x3abee9);const _0x10a832=as(_0x3abee9['serverSyncTree_'],_0x14396a,_0x31921c,_0x4ffbf0['currentWriteId'],_0x4ffbf0['applyLocally']);V(_0x3abee9['eventQueue_'],_0x14396a,_0x10a832),jn(_0x3abee9,_0x3abee9['transactionQueueTree_']);}}function Es(_0x47b530,_0x433c05,_0x537996){return Vn(_0x47b530['serverSyncTree_'],_0x433c05,_0x537996)||g['EMPTY_NODE'];}function jn(_0x36f5f7,_0x620069=_0x36f5f7['transactionQueueTree_']){if(_0x620069||Kn(_0x36f5f7,_0x620069),je(_0x620069)){const _0x5671d9=da(_0x36f5f7,_0x620069);f(_0x5671d9['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5671d9['every'](_0x316c41=>_0x316c41['status']===0x0)&&Dd(_0x36f5f7,Qt(_0x620069),_0x5671d9);}else na(_0x620069)&&Gn(_0x620069,_0x2da4d6=>{jn(_0x36f5f7,_0x2da4d6);});}function Dd(_0x4f9b2d,_0x52fabd,_0x1e50ba){const _0xdfa598=_0x1e50ba['map'](_0x33f433=>_0x33f433['currentWriteId']),_0x53de19=Es(_0x4f9b2d,_0x52fabd,_0xdfa598);let _0x26ab57=_0x53de19;const _0x1b67b5=_0x53de19['hash']();for(let _0x39708a=0x0;_0x39708a<_0x1e50ba['length'];_0x39708a++){const _0x275667=_0x1e50ba[_0x39708a];f(_0x275667['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x275667['status']=0x1,_0x275667['retryCount']++;const _0x333202=F(_0x52fabd,_0x275667['path']);_0x26ab57=_0x26ab57['updateChild'](_0x333202,_0x275667['currentOutputSnapshotRaw']);}const _0x1d22f5=_0x26ab57['val'](!0x0),_0xfc9382=_0x52fabd;_0x4f9b2d['server_']['put'](_0xfc9382['toString'](),_0x1d22f5,_0x3be82f=>{gt(_0x4f9b2d,'transaction\x20put\x20response',{'path':_0xfc9382['toString'](),'status':_0x3be82f});let _0x4c2a63=[];if(_0x3be82f==='ok'){const _0x522316=[];for(let _0x226983=0x0;_0x226983<_0x1e50ba['length'];_0x226983++)_0x1e50ba[_0x226983]['status']=0x2,_0x4c2a63=_0x4c2a63['concat'](_e(_0x4f9b2d['serverSyncTree_'],_0x1e50ba[_0x226983]['currentWriteId'])),_0x1e50ba[_0x226983]['onComplete']&&_0x522316['push'](()=>_0x1e50ba[_0x226983]['onComplete'](null,!0x0,_0x1e50ba[_0x226983]['currentOutputSnapshotResolved'])),_0x1e50ba[_0x226983]['unwatcher']();Kn(_0x4f9b2d,$n(_0x4f9b2d['transactionQueueTree_'],_0x52fabd)),jn(_0x4f9b2d,_0x4f9b2d['transactionQueueTree_']),V(_0x4f9b2d['eventQueue_'],_0x52fabd,_0x4c2a63);for(let _0x2a214c=0x0;_0x2a214c<_0x522316['length'];_0x2a214c++)ft(_0x522316[_0x2a214c]);}else{if(_0x3be82f==='datastale'){for(let _0x558e3c=0x0;_0x558e3c<_0x1e50ba['length'];_0x558e3c++)_0x1e50ba[_0x558e3c]['status']===0x3?_0x1e50ba[_0x558e3c]['status']=0x4:_0x1e50ba[_0x558e3c]['status']=0x0;}else{U('transaction\x20at\x20'+_0xfc9382['toString']()+'\x20failed:\x20'+_0x3be82f);for(let _0x403b86=0x0;_0x403b86<_0x1e50ba['length'];_0x403b86++)_0x1e50ba[_0x403b86]['status']=0x4,_0x1e50ba[_0x403b86]['abortReason']=_0x3be82f;}ct(_0x4f9b2d,_0x52fabd);}},_0x1b67b5);}function ct(_0x26f2b3,_0x505f58){const _0x3a1e56=ua(_0x26f2b3,_0x505f58),_0x251d78=Qt(_0x3a1e56),_0x565f69=da(_0x26f2b3,_0x3a1e56);return Md(_0x26f2b3,_0x565f69,_0x251d78),_0x251d78;}function Md(_0x43adcd,_0x38716b,_0x3b46a8){if(_0x38716b['length']===0x0)return;const _0x536f32=[];let _0x340800=[];const _0x3e848e=_0x38716b['filter'](_0x4d7a70=>_0x4d7a70['status']===0x0)['map'](_0x3a3337=>_0x3a3337['currentWriteId']);for(let _0x54f437=0x0;_0x54f437<_0x38716b['length'];_0x54f437++){const _0xba4061=_0x38716b[_0x54f437],_0xe7ea76=F(_0x3b46a8,_0xba4061['path']);let _0x1d1a7f=!0x1,_0x224f8a;if(f(_0xe7ea76!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xba4061['status']===0x4)_0x1d1a7f=!0x0,_0x224f8a=_0xba4061['abortReason'],_0x340800=_0x340800['concat'](_e(_0x43adcd['serverSyncTree_'],_0xba4061['currentWriteId'],!0x0));else{if(_0xba4061['status']===0x0){if(_0xba4061['retryCount']>=yd)_0x1d1a7f=!0x0,_0x224f8a='maxretry',_0x340800=_0x340800['concat'](_e(_0x43adcd['serverSyncTree_'],_0xba4061['currentWriteId'],!0x0));else{const _0x244d01=Es(_0x43adcd,_0xba4061['path'],_0x3e848e);_0xba4061['currentInputSnapshot']=_0x244d01;const _0x101d78=_0x38716b[_0x54f437]['update'](_0x244d01['val']());if(_0x101d78!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x101d78,_0xba4061['path']);let _0x43b51e=A(_0x101d78);typeof _0x101d78=='object'&&_0x101d78!=null&&Q(_0x101d78,'.priority')||(_0x43b51e=_0x43b51e['updatePriority'](_0x244d01['getPriority']()));const _0x386787=_0xba4061['currentWriteId'],_0x11d202=Xt(_0x43adcd),_0x12a9c3=fs(_0x43b51e,_0x244d01,_0x11d202);_0xba4061['currentOutputSnapshotRaw']=_0x43b51e,_0xba4061['currentOutputSnapshotResolved']=_0x12a9c3,_0xba4061['currentWriteId']=zn(_0x43adcd),_0x3e848e['splice'](_0x3e848e['indexOf'](_0x386787),0x1),_0x340800=_0x340800['concat'](as(_0x43adcd['serverSyncTree_'],_0xba4061['path'],_0x12a9c3,_0xba4061['currentWriteId'],_0xba4061['applyLocally'])),_0x340800=_0x340800['concat'](_e(_0x43adcd['serverSyncTree_'],_0x386787,!0x0));}else _0x1d1a7f=!0x0,_0x224f8a='nodata',_0x340800=_0x340800['concat'](_e(_0x43adcd['serverSyncTree_'],_0xba4061['currentWriteId'],!0x0));}}}V(_0x43adcd['eventQueue_'],_0x3b46a8,_0x340800),_0x340800=[],_0x1d1a7f&&(_0x38716b[_0x54f437]['status']=0x2,function(_0x3501e7){setTimeout(_0x3501e7,Math['floor'](0x0));}(_0x38716b[_0x54f437]['unwatcher']),_0x38716b[_0x54f437]['onComplete']&&(_0x224f8a==='nodata'?_0x536f32['push'](()=>_0x38716b[_0x54f437]['onComplete'](null,!0x1,_0x38716b[_0x54f437]['currentInputSnapshot'])):_0x536f32['push'](()=>_0x38716b[_0x54f437]['onComplete'](new Error(_0x224f8a),!0x1,null))));}Kn(_0x43adcd,_0x43adcd['transactionQueueTree_']);for(let _0x21e761=0x0;_0x21e761<_0x536f32['length'];_0x21e761++)ft(_0x536f32[_0x21e761]);jn(_0x43adcd,_0x43adcd['transactionQueueTree_']);}function ua(_0xf0e93f,_0x23a46f){let _0x4d711b,_0x3bbb97=_0xf0e93f['transactionQueueTree_'];for(_0x4d711b=y(_0x23a46f);_0x4d711b!==null&&je(_0x3bbb97)===void 0x0;)_0x3bbb97=$n(_0x3bbb97,_0x4d711b),_0x23a46f=S(_0x23a46f),_0x4d711b=y(_0x23a46f);return _0x3bbb97;}function da(_0x13dd27,_0x1a2177){const _0x1d002a=[];return fa(_0x13dd27,_0x1a2177,_0x1d002a),_0x1d002a['sort']((_0x2799f2,_0x41a31c)=>_0x2799f2['order']-_0x41a31c['order']),_0x1d002a;}function fa(_0x25e5a2,_0x2f31f4,_0x28da70){const _0x2c4f7c=je(_0x2f31f4);if(_0x2c4f7c){for(let _0x2e19a4=0x0;_0x2e19a4<_0x2c4f7c['length'];_0x2e19a4++)_0x28da70['push'](_0x2c4f7c[_0x2e19a4]);}Gn(_0x2f31f4,_0x451534=>{fa(_0x25e5a2,_0x451534,_0x28da70);});}function Kn(_0x365317,_0x215220){const _0x1cba4a=je(_0x215220);if(_0x1cba4a){let _0x1e4da2=0x0;for(let _0x672a45=0x0;_0x672a45<_0x1cba4a['length'];_0x672a45++)_0x1cba4a[_0x672a45]['status']!==0x2&&(_0x1cba4a[_0x1e4da2]=_0x1cba4a[_0x672a45],_0x1e4da2++);_0x1cba4a['length']=_0x1e4da2,gs(_0x215220,_0x1cba4a['length']>0x0?_0x1cba4a:void 0x0);}Gn(_0x215220,_0x375628=>{Kn(_0x365317,_0x375628);});}function Is(_0x58dc03,_0x8e8d20){const _0x24032a=Qt(ua(_0x58dc03,_0x8e8d20)),_0x1c8585=$n(_0x58dc03['transactionQueueTree_'],_0x8e8d20);return ad(_0x1c8585,_0x47a9a4=>{di(_0x58dc03,_0x47a9a4);}),di(_0x58dc03,_0x1c8585),ia(_0x1c8585,_0xb65af6=>{di(_0x58dc03,_0xb65af6);}),_0x24032a;}function di(_0x10c8ff,_0xe179ee){const _0x540b7a=je(_0xe179ee);if(_0x540b7a){const _0x37e8b6=[];let _0x5e70f=[],_0x22dfb0=-0x1;for(let _0x46eba1=0x0;_0x46eba1<_0x540b7a['length'];_0x46eba1++)_0x540b7a[_0x46eba1]['status']===0x3||(_0x540b7a[_0x46eba1]['status']===0x1?(f(_0x22dfb0===_0x46eba1-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x22dfb0=_0x46eba1,_0x540b7a[_0x46eba1]['status']=0x3,_0x540b7a[_0x46eba1]['abortReason']='set'):(f(_0x540b7a[_0x46eba1]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x540b7a[_0x46eba1]['unwatcher'](),_0x5e70f=_0x5e70f['concat'](_e(_0x10c8ff['serverSyncTree_'],_0x540b7a[_0x46eba1]['currentWriteId'],!0x0)),_0x540b7a[_0x46eba1]['onComplete']&&_0x37e8b6['push'](_0x540b7a[_0x46eba1]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x22dfb0===-0x1?gs(_0xe179ee,void 0x0):_0x540b7a['length']=_0x22dfb0+0x1,V(_0x10c8ff['eventQueue_'],Qt(_0xe179ee),_0x5e70f);for(let _0x2a77dd=0x0;_0x2a77dd<_0x37e8b6['length'];_0x2a77dd++)ft(_0x37e8b6[_0x2a77dd]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2d2b1b){let _0x425a9a='';const _0x35b7a4=_0x2d2b1b['split']('/');for(let _0x514596=0x0;_0x514596<_0x35b7a4['length'];_0x514596++)if(_0x35b7a4[_0x514596]['length']>0x0){let _0x48000e=_0x35b7a4[_0x514596];try{_0x48000e=decodeURIComponent(_0x48000e['replace'](/\+/g,'\x20'));}catch{}_0x425a9a+='/'+_0x48000e;}return _0x425a9a;}function xd(_0x448ca6){const _0x21f968={};_0x448ca6['charAt'](0x0)==='?'&&(_0x448ca6=_0x448ca6['substring'](0x1));for(const _0xefbc72 of _0x448ca6['split']('&')){if(_0xefbc72['length']===0x0)continue;const _0x2fe838=_0xefbc72['split']('=');_0x2fe838['length']===0x2?_0x21f968[decodeURIComponent(_0x2fe838[0x0])]=decodeURIComponent(_0x2fe838[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xefbc72+'\x27\x20in\x20query\x20\x27'+_0x448ca6+'\x27');}return _0x21f968;}const vr=function(_0x1aff29,_0x9ffb1a){const _0x383635=Fd(_0x1aff29),_0x210513=_0x383635['namespace'];_0x383635['domain']==='firebase.com'&&ae(_0x383635['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x210513||_0x210513==='undefined')&&_0x383635['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x383635['secure']||$l();const _0x312e13=_0x383635['scheme']==='ws'||_0x383635['scheme']==='wss';return{'repoInfo':new yo(_0x383635['host'],_0x383635['secure'],_0x210513,_0x312e13,_0x9ffb1a,'',_0x210513!==_0x383635['subdomain']),'path':new C(_0x383635['pathString'])};},Fd=function(_0x2afcdd){let _0x205a82='',_0x2bbf50='',_0xfdf64f='',_0x2d1833='',_0x4daa94='',_0x2401a1=!0x0,_0x3cdde6='https',_0x4af774=0x1bb;if(typeof _0x2afcdd=='string'){let _0x241800=_0x2afcdd['indexOf']('//');_0x241800>=0x0&&(_0x3cdde6=_0x2afcdd['substring'](0x0,_0x241800-0x1),_0x2afcdd=_0x2afcdd['substring'](_0x241800+0x2));let _0x4102ac=_0x2afcdd['indexOf']('/');_0x4102ac===-0x1&&(_0x4102ac=_0x2afcdd['length']);let _0x41b56b=_0x2afcdd['indexOf']('?');_0x41b56b===-0x1&&(_0x41b56b=_0x2afcdd['length']),_0x205a82=_0x2afcdd['substring'](0x0,Math['min'](_0x4102ac,_0x41b56b)),_0x4102ac<_0x41b56b&&(_0x2d1833=Ld(_0x2afcdd['substring'](_0x4102ac,_0x41b56b)));const _0x124084=xd(_0x2afcdd['substring'](Math['min'](_0x2afcdd['length'],_0x41b56b)));_0x241800=_0x205a82['indexOf'](':'),_0x241800>=0x0?(_0x2401a1=_0x3cdde6==='https'||_0x3cdde6==='wss',_0x4af774=parseInt(_0x205a82['substring'](_0x241800+0x1),0xa)):_0x241800=_0x205a82['length'];const _0x3140ac=_0x205a82['slice'](0x0,_0x241800);if(_0x3140ac['toLowerCase']()==='localhost')_0x2bbf50='localhost';else{if(_0x3140ac['split']('.')['length']<=0x2)_0x2bbf50=_0x3140ac;else{const _0xc43575=_0x205a82['indexOf']('.');_0xfdf64f=_0x205a82['substring'](0x0,_0xc43575)['toLowerCase'](),_0x2bbf50=_0x205a82['substring'](_0xc43575+0x1),_0x4daa94=_0xfdf64f;}}'ns'in _0x124084&&(_0x4daa94=_0x124084['ns']);}return{'host':_0x205a82,'port':_0x4af774,'domain':_0x2bbf50,'subdomain':_0xfdf64f,'secure':_0x2401a1,'scheme':_0x3cdde6,'pathString':_0x2d1833,'namespace':_0x4daa94};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x576623=0x0;const _0x175ac8=[];return function(_0x1ee0b1){const _0x46d56c=_0x1ee0b1===_0x576623;_0x576623=_0x1ee0b1;let _0x29b29e;const _0x3026b1=new Array(0x8);for(_0x29b29e=0x7;_0x29b29e>=0x0;_0x29b29e--)_0x3026b1[_0x29b29e]=Er['charAt'](_0x1ee0b1%0x40),_0x1ee0b1=Math['floor'](_0x1ee0b1/0x40);f(_0x1ee0b1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x23ec7f=_0x3026b1['join']('');if(_0x46d56c){for(_0x29b29e=0xb;_0x29b29e>=0x0&&_0x175ac8[_0x29b29e]===0x3f;_0x29b29e--)_0x175ac8[_0x29b29e]=0x0;_0x175ac8[_0x29b29e]++;}else{for(_0x29b29e=0x0;_0x29b29e<0xc;_0x29b29e++)_0x175ac8[_0x29b29e]=Math['floor'](Math['random']()*0x40);}for(_0x29b29e=0x0;_0x29b29e<0xc;_0x29b29e++)_0x23ec7f+=Er['charAt'](_0x175ac8[_0x29b29e]);return f(_0x23ec7f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x23ec7f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x5c81a2,_0x566c0e,_0x30866d,_0x5e4464){this['eventType']=_0x5c81a2,this['eventRegistration']=_0x566c0e,this['snapshot']=_0x30866d,this['prevName']=_0x5e4464;}['getPath'](){const _0x2d6461=this['snapshot']['ref'];return this['eventType']==='value'?_0x2d6461['_path']:_0x2d6461['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0xfb0cd6,_0x369cc0,_0x348ed9){this['eventRegistration']=_0xfb0cd6,this['error']=_0x369cc0,this['path']=_0x348ed9;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3778d5,_0x12370b){this['snapshotCallback']=_0x3778d5,this['cancelCallback']=_0x12370b;}['onValue'](_0x45b873,_0x6e5544){this['snapshotCallback']['call'](null,_0x45b873,_0x6e5544);}['onCancel'](_0x554a98){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x554a98);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x197b67){return this['snapshotCallback']===_0x197b67['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x197b67['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x197b67['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2ae0d8,_0x2400b5){this['_repo']=_0x2ae0d8,this['_path']=_0x2400b5;}['cancel'](){const _0x54d1da=new H();return bd(this['_repo'],this['_path'],_0x54d1da['wrapCallback'](()=>{})),_0x54d1da['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x40da0d=new H();return yr(this['_repo'],this['_path'],null,_0x40da0d['wrapCallback'](()=>{})),_0x40da0d['promise'];}['set'](_0x1252a6){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x1252a6,this['_path'],!0x1);const _0x1fe61f=new H();return yr(this['_repo'],this['_path'],_0x1252a6,_0x1fe61f['wrapCallback'](()=>{})),_0x1fe61f['promise'];}['setWithPriority'](_0x1772af,_0x542060){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x1772af,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x542060);const _0x1100a6=new H();return Rd(this['_repo'],this['_path'],_0x1772af,_0x542060,_0x1100a6['wrapCallback'](()=>{})),_0x1100a6['promise'];}['update'](_0x1589d2){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1589d2,this['_path']);const _0x5db888=new H();return Ad(this['_repo'],this['_path'],_0x1589d2,_0x5db888['wrapCallback'](()=>{})),_0x5db888['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x295acd,_0x4c1cb7,_0x2f84eb,_0x3fa64c){this['_repo']=_0x295acd,this['_path']=_0x4c1cb7,this['_queryParams']=_0x2f84eb,this['_orderByCalled']=_0x3fa64c;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x238627=sr(this['_queryParams']),_0x897d4c=$i(_0x238627);return _0x897d4c==='{}'?'default':_0x897d4c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x33f7ca){if(_0x33f7ca=P(_0x33f7ca),!(_0x33f7ca instanceof Ae))return!0x1;const _0x40eb12=this['_repo']===_0x33f7ca['_repo'],_0x57eaa7=Ki(this['_path'],_0x33f7ca['_path']),_0x401271=this['_queryIdentifier']===_0x33f7ca['_queryIdentifier'];return _0x40eb12&&_0x57eaa7&&_0x401271;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x5543b0,_0x12db3a){if(_0x5543b0['_orderByCalled']===!0x0)throw new Error(_0x12db3a+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x463193){let _0x32d0f4=null,_0x321bab=null;if(_0x463193['hasStart']()&&(_0x32d0f4=_0x463193['getIndexStartValue']()),_0x463193['hasEnd']()&&(_0x321bab=_0x463193['getIndexEndValue']()),_0x463193['getIndex']()===ve){const _0x829e7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2e4a40='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x463193['hasStart']()){if(_0x463193['getIndexStartName']()!==We)throw new Error(_0x829e7);if(typeof _0x32d0f4!='string')throw new Error(_0x2e4a40);}if(_0x463193['hasEnd']()){if(_0x463193['getIndexEndName']()!==we)throw new Error(_0x829e7);if(typeof _0x321bab!='string')throw new Error(_0x2e4a40);}}else{if(_0x463193['getIndex']()===R){if(_0x32d0f4!=null&&!Bt(_0x32d0f4)||_0x321bab!=null&&!Bt(_0x321bab))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x463193['getIndex']()instanceof Ji||_0x463193['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x32d0f4!=null&&typeof _0x32d0f4=='object'||_0x321bab!=null&&typeof _0x321bab=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1d6cbd){if(_0x1d6cbd['hasStart']()&&_0x1d6cbd['hasEnd']()&&_0x1d6cbd['hasLimit']()&&!_0x1d6cbd['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x99777b,_0xca9daf){super(_0x99777b,_0xca9daf,new Zi(),!0x1);}get['parent'](){const _0x1a8f69=Ro(this['_path']);return _0x1a8f69===null?null:new ee(this['_repo'],_0x1a8f69);}get['root'](){let _0x45cad2=this;for(;_0x45cad2['parent']!==null;)_0x45cad2=_0x45cad2['parent'];return _0x45cad2;}}class lt{constructor(_0x182210,_0xccecc5,_0x4bee7b){this['_node']=_0x182210,this['ref']=_0xccecc5,this['_index']=_0x4bee7b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x47640a){const _0x7376bc=new C(_0x47640a),_0x5f35db=Vt(this['ref'],_0x47640a);return new lt(this['_node']['getChild'](_0x7376bc),_0x5f35db,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x20f728){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4118f0,_0x269d4e)=>_0x20f728(new lt(_0x269d4e,Vt(this['ref'],_0x4118f0),R)));}['hasChild'](_0x3cf79f){const _0x3fe6f3=new C(_0x3cf79f);return!this['_node']['getChild'](_0x3fe6f3)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x58f858,_0x2d2931){return _0x58f858=P(_0x58f858),_0x58f858['_checkNotDeleted']('ref'),_0x2d2931!==void 0x0?Vt(_0x58f858['_root'],_0x2d2931):_0x58f858['_root'];}function Vt(_0x218dad,_0x53eda8){return _0x218dad=P(_0x218dad),y(_0x218dad['_path'])===null?pd('child','path',_0x53eda8):ys('child','path',_0x53eda8),new ee(_0x218dad['_repo'],k(_0x218dad['_path'],_0x53eda8));}function v_(_0x584f0a){return _0x584f0a=P(_0x584f0a),new Vd(_0x584f0a['_repo'],_0x584f0a['_path']);}function E_(_0x1f4cd5,_0x35aeac){_0x1f4cd5=P(_0x1f4cd5),Me('push',_0x1f4cd5['_path']),He('push',_0x35aeac,_0x1f4cd5['_path'],!0x0);const _0x37ca53=la(_0x1f4cd5['_repo']),_0x10ee50=Ud(_0x37ca53),_0x2ab2c0=Vt(_0x1f4cd5,_0x10ee50),_0x570adb=Vt(_0x1f4cd5,_0x10ee50);let _0xb19527;return _0x35aeac!=null?_0xb19527=Hd(_0x570adb,_0x35aeac)['then'](()=>_0x570adb):_0xb19527=Promise['resolve'](_0x570adb),_0x2ab2c0['then']=_0xb19527['then']['bind'](_0xb19527),_0x2ab2c0['catch']=_0xb19527['then']['bind'](_0xb19527,void 0x0),_0x2ab2c0;}function Hd(_0x49677a,_0x300b78){_0x49677a=P(_0x49677a),Me('set',_0x49677a['_path']),He('set',_0x300b78,_0x49677a['_path'],!0x1);const _0x3cffa4=new H();return Cd(_0x49677a['_repo'],_0x49677a['_path'],_0x300b78,null,_0x3cffa4['wrapCallback'](()=>{})),_0x3cffa4['promise'];}function I_(_0x4dad07,_0x5a3f76){ra('update',_0x5a3f76,_0x4dad07['_path']);const _0x37847d=new H();return Td(_0x4dad07['_repo'],_0x4dad07['_path'],_0x5a3f76,_0x37847d['wrapCallback'](()=>{})),_0x37847d['promise'];}function w_(_0x22289c){_0x22289c=P(_0x22289c);const _0x2ce853=new pa(()=>{}),_0x21394d=new Qn(_0x2ce853);return wd(_0x22289c['_repo'],_0x22289c,_0x21394d)['then'](_0x5821d2=>new lt(_0x5821d2,new ee(_0x22289c['_repo'],_0x22289c['_path']),_0x22289c['_queryParams']['getIndex']()));}class Qn{constructor(_0x9b98c6){this['callbackContext']=_0x9b98c6;}['respondsTo'](_0x5df971){return _0x5df971==='value';}['createEvent'](_0x109f12,_0x4dfa47){const _0x5bf09d=_0x4dfa47['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x109f12['snapshotNode'],new ee(_0x4dfa47['_repo'],_0x4dfa47['_path']),_0x5bf09d));}['getEventRunner'](_0x54ab67){return _0x54ab67['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x54ab67['error']):()=>this['callbackContext']['onValue'](_0x54ab67['snapshot'],null);}['createCancelEvent'](_0x1c7f61,_0x46bb4c){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x1c7f61,_0x46bb4c):null;}['matches'](_0x1f88e3){return _0x1f88e3 instanceof Qn?!_0x1f88e3['callbackContext']||!this['callbackContext']?!0x0:_0x1f88e3['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x4399b2,_0x42d68f,_0x20a57d,_0x472545,_0x51d500){const _0x399ebf=new pa(_0x20a57d,void 0x0),_0x1a4324=new Qn(_0x399ebf);return kd(_0x4399b2['_repo'],_0x4399b2,_0x1a4324),()=>Pd(_0x4399b2['_repo'],_0x4399b2,_0x1a4324);}function Gd(_0x57c26f,_0x81650a,_0x4e504e,_0x3e3318){return $d(_0x57c26f,'value',_0x81650a);}class mt{}class ma extends mt{constructor(_0x526b52,_0x3ab1f3){super(),this['_value']=_0x526b52,this['_key']=_0x3ab1f3,this['type']='endAt';}['_apply'](_0x1dfc7b){He('endAt',this['_value'],_0x1dfc7b['_path'],!0x0);const _0x256a44=Jh(_0x1dfc7b['_queryParams'],this['_value'],this['_key']);if(ga(_0x256a44),Yn(_0x256a44),_0x1dfc7b['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x1dfc7b['_repo'],_0x1dfc7b['_path'],_0x256a44,_0x1dfc7b['_orderByCalled']);}}function C_(_0x5e47f2,_0x1ac494){return new ma(_0x5e47f2,_0x1ac494);}class ya extends mt{constructor(_0x2c2ed9,_0x5488f6){super(),this['_value']=_0x2c2ed9,this['_key']=_0x5488f6,this['type']='startAt';}['_apply'](_0x52893d){He('startAt',this['_value'],_0x52893d['_path'],!0x0);const _0x31c413=Qh(_0x52893d['_queryParams'],this['_value'],this['_key']);if(ga(_0x31c413),Yn(_0x31c413),_0x52893d['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x52893d['_repo'],_0x52893d['_path'],_0x31c413,_0x52893d['_orderByCalled']);}}function T_(_0x42e635=null,_0x8a85f1){return new ya(_0x42e635,_0x8a85f1);}class qd extends mt{constructor(_0x272b55){super(),this['_limit']=_0x272b55,this['type']='limitToFirst';}['_apply'](_0x11529b){if(_0x11529b['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x11529b['_repo'],_0x11529b['_path'],Yh(_0x11529b['_queryParams'],this['_limit']),_0x11529b['_orderByCalled']);}}function S_(_0x85d78){if(Math['floor'](_0x85d78)!==_0x85d78||_0x85d78<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x85d78);}class zd extends mt{constructor(_0x1563dd){super(),this['_path']=_0x1563dd,this['type']='orderByChild';}['_apply'](_0x56600e){_a(_0x56600e,'orderByChild');const _0x5a59bc=new C(this['_path']);if(v(_0x5a59bc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4c83ca=new Ji(_0x5a59bc),_0xa1c634=xo(_0x56600e['_queryParams'],_0x4c83ca);return Yn(_0xa1c634),new Ae(_0x56600e['_repo'],_0x56600e['_path'],_0xa1c634,!0x0);}}function b_(_0x192e7a){if(_0x192e7a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x192e7a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x192e7a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x192e7a),new zd(_0x192e7a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x168080){_a(_0x168080,'orderByKey');const _0x5a81ea=xo(_0x168080['_queryParams'],ve);return Yn(_0x5a81ea),new Ae(_0x168080['_repo'],_0x168080['_path'],_0x5a81ea,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x52024a,_0x2cb479){super(),this['_value']=_0x52024a,this['_key']=_0x2cb479,this['type']='equalTo';}['_apply'](_0x2a5e3a){if(He('equalTo',this['_value'],_0x2a5e3a['_path'],!0x1),_0x2a5e3a['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2a5e3a['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2a5e3a));}}function A_(_0x12403b,_0x12a55b){return new Kd(_0x12403b,_0x12a55b);}function k_(_0x999dd5,..._0x10ec60){let _0xac61=P(_0x999dd5);for(const _0x170348 of _0x10ec60)_0xac61=_0x170348['_apply'](_0xac61);return _0xac61;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x2800e8,_0x5ad2d6,_0x1f8f7d,_0x26038f){const _0x13904b=_0x5ad2d6['lastIndexOf'](':'),_0x30f163=_0x5ad2d6['substring'](0x0,_0x13904b),_0x47781f=qt(_0x30f163);_0x2800e8['repoInfo_']=new yo(_0x5ad2d6,_0x47781f,_0x2800e8['repoInfo_']['namespace'],_0x2800e8['repoInfo_']['webSocketOnly'],_0x2800e8['repoInfo_']['nodeAdmin'],_0x2800e8['repoInfo_']['persistenceKey'],_0x2800e8['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1f8f7d),_0x26038f&&(_0x2800e8['authTokenProvider_']=_0x26038f);}function Xd(_0x33f83c,_0x208eab,_0x3965a1,_0x570828,_0x40d4ac){let _0x5d683f=_0x570828||_0x33f83c['options']['databaseURL'];_0x5d683f===void 0x0&&(_0x33f83c['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x33f83c['options']['projectId']),_0x5d683f=_0x33f83c['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x51e342=vr(_0x5d683f,_0x40d4ac),_0x265232=_0x51e342['repoInfo'],_0x4c2252;typeof process<'u'&&Bs&&(_0x4c2252=Bs[Yd]),_0x4c2252?(_0x5d683f='http://'+_0x4c2252+'?ns='+_0x265232['namespace'],_0x51e342=vr(_0x5d683f,_0x40d4ac),_0x265232=_0x51e342['repoInfo']):_0x51e342['repoInfo']['secure'];const _0x1d773b=new eh(_0x33f83c['name'],_0x33f83c['options'],_0x208eab);_d('Invalid\x20Firebase\x20Database\x20URL',_0x51e342),v(_0x51e342['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x576679=ef(_0x265232,_0x33f83c,_0x1d773b,new Zl(_0x33f83c,_0x3965a1));return new tf(_0x576679,_0x33f83c);}function Zd(_0x2eceb0,_0x2c2526){const _0x17a405=Di[_0x2c2526];(!_0x17a405||_0x17a405[_0x2eceb0['key']]!==_0x2eceb0)&&ae('Database\x20'+_0x2c2526+'('+_0x2eceb0['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2eceb0),delete _0x17a405[_0x2eceb0['key']];}function ef(_0x496f06,_0x1f4ae5,_0x5e1344,_0xc020cc){let _0x3fa4ee=Di[_0x1f4ae5['name']];_0x3fa4ee||(_0x3fa4ee={},Di[_0x1f4ae5['name']]=_0x3fa4ee);let _0x4b8560=_0x3fa4ee[_0x496f06['toURLString']()];return _0x4b8560&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4b8560=new vd(_0x496f06,Qd,_0x5e1344,_0xc020cc),_0x3fa4ee[_0x496f06['toURLString']()]=_0x4b8560,_0x4b8560;}class tf{constructor(_0x5e61dd,_0x4d8baa){this['_repoInternal']=_0x5e61dd,this['app']=_0x4d8baa,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x9882f7){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x9882f7+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4ef390=Zr(),_0x2d75cb){const _0x4d5ee9=Hi(_0x4ef390,'database')['getImmediate']({'identifier':_0x2d75cb});if(!_0x4d5ee9['_instanceStarted']){const _0x3d5e2c=hc('database');_0x3d5e2c&&nf(_0x4d5ee9,..._0x3d5e2c);}return _0x4d5ee9;}function nf(_0x34669b,_0xadd5d6,_0x33fc47,_0x4ae36f={}){_0x34669b=P(_0x34669b),_0x34669b['_checkNotDeleted']('useEmulator');const _0x104514=_0xadd5d6+':'+_0x33fc47,_0x2d4da4=_0x34669b['_repoInternal'];if(_0x34669b['_instanceStarted']){if(_0x104514===_0x34669b['_repoInternal']['repoInfo_']['host']&&xe(_0x4ae36f,_0x2d4da4['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4d19fc;if(_0x2d4da4['repoInfo_']['nodeAdmin'])_0x4ae36f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4d19fc=new an(an['OWNER']);else{if(_0x4ae36f['mockUserToken']){const _0x37eac7=typeof _0x4ae36f['mockUserToken']=='string'?_0x4ae36f['mockUserToken']:uc(_0x4ae36f['mockUserToken'],_0x34669b['app']['options']['projectId']);_0x4d19fc=new an(_0x37eac7);}}qt(_0xadd5d6)&&Qr(_0xadd5d6),Jd(_0x2d4da4,_0x104514,_0x4ae36f,_0x4d19fc);}function N_(_0x185a57){_0x185a57=P(_0x185a57),_0x185a57['_checkNotDeleted']('goOffline'),ha(_0x185a57['_repo']);}function O_(_0x48e297){_0x48e297=P(_0x48e297),_0x48e297['_checkNotDeleted']('goOnline'),Nd(_0x48e297['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x3d938a){Ul(dt),st(new Fe('database',(_0x167edc,{instanceIdentifier:_0x4053bd})=>{const _0x367bab=_0x167edc['getProvider']('app')['getImmediate'](),_0x28bd31=_0x167edc['getProvider']('auth-internal'),_0x80016f=_0x167edc['getProvider']('app-check-internal');return Xd(_0x367bab,_0x28bd31,_0x80016f,_0x4053bd);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x3d938a),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x1fba6c,_0x4e59cc){this['committed']=_0x1fba6c,this['snapshot']=_0x4e59cc;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x2015ae,_0x596e52,_0x11340d){if(_0x2015ae=P(_0x2015ae),Me('Reference.transaction',_0x2015ae['_path']),_0x2015ae['key']==='.length'||_0x2015ae['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2015ae['key']+'\x20is\x20a\x20read-only\x20object.';const _0x58af29=!0x0,_0x3eec72=new H(),_0x4a934f=(_0x174f1e,_0x577fe3,_0x1baca0)=>{let _0x111859=null;_0x174f1e?_0x3eec72['reject'](_0x174f1e):(_0x111859=new lt(_0x1baca0,new ee(_0x2015ae['_repo'],_0x2015ae['_path']),R),_0x3eec72['resolve'](new of(_0x577fe3,_0x111859)));},_0x1d5a82=Gd(_0x2015ae,()=>{});return Od(_0x2015ae['_repo'],_0x2015ae['_path'],_0x596e52,_0x4a934f,_0x1d5a82,_0x58af29),_0x3eec72['promise'];}se['prototype']['simpleListen']=function(_0x5290e0,_0x3c95a6){this['sendRequest']('q',{'p':_0x5290e0},_0x3c95a6);},se['prototype']['echo']=function(_0x4e4eb9,_0x563cc8){this['sendRequest']('echo',{'d':_0x4e4eb9},_0x563cc8);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x48abd8,..._0x48e21b){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x48abd8,..._0x48e21b);}function cn(_0x2a041f,..._0x3a9a97){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x2a041f,..._0x3a9a97);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x22d0c8,..._0x41f204){throw ws(_0x22d0c8,..._0x41f204);}function X(_0x184698,..._0x4fd1c8){return ws(_0x184698,..._0x4fd1c8);}function Ia(_0x448ca1,_0x2dec67,_0x46f3f9){const _0x1edde4={...af(),[_0x2dec67]:_0x46f3f9};return new Gt('auth','Firebase',_0x1edde4)['create'](_0x2dec67,{'appName':_0x448ca1['name']});}function re(_0x14cb6a){return Ia(_0x14cb6a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2de64e,..._0x5218d8){if(typeof _0x2de64e!='string'){const _0x13aaf9=_0x5218d8[0x0],_0x5d36b7=[..._0x5218d8['slice'](0x1)];return _0x5d36b7[0x0]&&(_0x5d36b7[0x0]['appName']=_0x2de64e['name']),_0x2de64e['_errorFactory']['create'](_0x13aaf9,..._0x5d36b7);}return Ea['create'](_0x2de64e,..._0x5218d8);}function m(_0x37c041,_0x46518e,..._0x337b40){if(!_0x37c041)throw ws(_0x46518e,..._0x337b40);}function ne(_0x293465){const _0x41311b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x293465;throw cn(_0x41311b),new Error(_0x41311b);}function ce(_0x174c77,_0x24692c){_0x174c77||ne(_0x24692c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3407f4;return typeof self<'u'&&((_0x3407f4=self['location'])==null?void 0x0:_0x3407f4['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x9e260f;return typeof self<'u'&&((_0x9e260f=self['location'])==null?void 0x0:_0x9e260f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x583d2a=navigator;return _0x583d2a['languages']&&_0x583d2a['languages'][0x0]||_0x583d2a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x177666,_0x4bf2af){this['shortDelay']=_0x177666,this['longDelay']=_0x4bf2af,ce(_0x4bf2af>_0x177666,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2af76e,_0x300b51){ce(_0x2af76e['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x11ac20}=_0x2af76e['emulator'];return _0x300b51?''+_0x11ac20+(_0x300b51['startsWith']('/')?_0x300b51['slice'](0x1):_0x300b51):_0x11ac20;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x4350c7,_0x3311df,_0x105aec){this['fetchImpl']=_0x4350c7,_0x3311df&&(this['headersImpl']=_0x3311df),_0x105aec&&(this['responseImpl']=_0x105aec);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0xfbd846,_0x41d26a){return _0xfbd846['tenantId']&&!_0x41d26a['tenantId']?{..._0x41d26a,'tenantId':_0xfbd846['tenantId']}:_0x41d26a;}async function Pe(_0x26d154,_0x4d067e,_0x65d546,_0x5f4215,_0x136a87={}){return Ca(_0x26d154,_0x136a87,async()=>{let _0x4c21af={},_0x4e719={};_0x5f4215&&(_0x4d067e==='GET'?_0x4e719=_0x5f4215:_0x4c21af={'body':JSON['stringify'](_0x5f4215)});const _0x58c503=ut({..._0x4e719,'key':_0x26d154['config']['apiKey']})['slice'](0x1),_0x100227=await _0x26d154['_getAdditionalHeaders']();_0x100227['Content-Type']='application/json',_0x26d154['languageCode']&&(_0x100227['X-Firebase-Locale']=_0x26d154['languageCode']);const _0x5dc488={'method':_0x4d067e,'headers':_0x100227,..._0x4c21af};return dc()||(_0x5dc488['referrerPolicy']='strict-origin-when-cross-origin'),_0x26d154['emulatorConfig']&&qt(_0x26d154['emulatorConfig']['host'])&&(_0x5dc488['credentials']='include'),wa['fetch']()(await Ta(_0x26d154,_0x26d154['config']['apiHost'],_0x65d546,_0x58c503),_0x5dc488);});}async function Ca(_0x2f045b,_0x340b35,_0x12fed5){_0x2f045b['_canInitEmulator']=!0x1;const _0x2d8cbd={...df,..._0x340b35};try{const _0x374500=new gf(_0x2f045b),_0x4f8bca=await Promise['race']([_0x12fed5(),_0x374500['promise']]);_0x374500['clearNetworkTimeout']();const _0x48ffb6=await _0x4f8bca['json']();if('needConfirmation'in _0x48ffb6)throw on(_0x2f045b,'account-exists-with-different-credential',_0x48ffb6);if(_0x4f8bca['ok']&&!('errorMessage'in _0x48ffb6))return _0x48ffb6;{const _0x1a8f09=_0x4f8bca['ok']?_0x48ffb6['errorMessage']:_0x48ffb6['error']['message'],[_0x386449,_0x53e9ef]=_0x1a8f09['split']('\x20:\x20');if(_0x386449==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2f045b,'credential-already-in-use',_0x48ffb6);if(_0x386449==='EMAIL_EXISTS')throw on(_0x2f045b,'email-already-in-use',_0x48ffb6);if(_0x386449==='USER_DISABLED')throw on(_0x2f045b,'user-disabled',_0x48ffb6);const _0x1564dc=_0x2d8cbd[_0x386449]||_0x386449['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x53e9ef)throw Ia(_0x2f045b,_0x1564dc,_0x53e9ef);Y(_0x2f045b,_0x1564dc);}}catch(_0x3e27e3){if(_0x3e27e3 instanceof Re)throw _0x3e27e3;Y(_0x2f045b,'network-request-failed',{'message':String(_0x3e27e3)});}}async function en(_0x47e686,_0x187332,_0x108269,_0x49f826,_0x39b120={}){const _0x1f846f=await Pe(_0x47e686,_0x187332,_0x108269,_0x49f826,_0x39b120);return'mfaPendingCredential'in _0x1f846f&&Y(_0x47e686,'multi-factor-auth-required',{'_serverResponse':_0x1f846f}),_0x1f846f;}async function Ta(_0x5df31a,_0x28a53f,_0x1cd517,_0xab6543){const _0x7768fd=''+_0x28a53f+_0x1cd517+'?'+_0xab6543,_0x233999=_0x5df31a,_0x1792be=_0x233999['config']['emulator']?Cs(_0x5df31a['config'],_0x7768fd):_0x5df31a['config']['apiScheme']+'://'+_0x7768fd;return ff['includes'](_0x1cd517)&&(await _0x233999['_persistenceManagerAvailable'],_0x233999['_getPersistenceType']()==='COOKIE')?_0x233999['_getPersistence']()['_getFinalTarget'](_0x1792be)['toString']():_0x1792be;}function _f(_0xddfedf){switch(_0xddfedf){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x384154){this['auth']=_0x384154,this['timer']=null,this['promise']=new Promise((_0x436613,_0x5b0e00)=>{this['timer']=setTimeout(()=>_0x5b0e00(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x45af1d,_0x22d8d3,_0x52f054){const _0x59cf84={'appName':_0x45af1d['name']};_0x52f054['email']&&(_0x59cf84['email']=_0x52f054['email']),_0x52f054['phoneNumber']&&(_0x59cf84['phoneNumber']=_0x52f054['phoneNumber']);const _0x127bf7=X(_0x45af1d,_0x22d8d3,_0x59cf84);return _0x127bf7['customData']['_tokenResponse']=_0x52f054,_0x127bf7;}function wr(_0x5080c5){return _0x5080c5!==void 0x0&&_0x5080c5['enterprise']!==void 0x0;}class mf{constructor(_0x532c3f){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x532c3f['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x532c3f['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x532c3f['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x47c4cb){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x423d25 of this['recaptchaEnforcementState'])if(_0x423d25['provider']&&_0x423d25['provider']===_0x47c4cb)return _f(_0x423d25['enforcementState']);return null;}['isProviderEnabled'](_0x3d057e){return this['getProviderEnforcementState'](_0x3d057e)==='ENFORCE'||this['getProviderEnforcementState'](_0x3d057e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x253bbf,_0x4095d){return Pe(_0x253bbf,'GET','/v2/recaptchaConfig',ke(_0x253bbf,_0x4095d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3335b2,_0x1dfb9d){return Pe(_0x3335b2,'POST','/v1/accounts:delete',_0x1dfb9d);}async function Pn(_0x2e1b56,_0x581f34){return Pe(_0x2e1b56,'POST','/v1/accounts:lookup',_0x581f34);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x256ba4){if(_0x256ba4)try{const _0x214a53=new Date(Number(_0x256ba4));if(!isNaN(_0x214a53['getTime']()))return _0x214a53['toUTCString']();}catch{}}async function Ef(_0x22654e,_0x5cb533=!0x1){const _0x485578=P(_0x22654e),_0x45da96=await _0x485578['getIdToken'](_0x5cb533),_0xdfbbb5=Ts(_0x45da96);m(_0xdfbbb5&&_0xdfbbb5['exp']&&_0xdfbbb5['auth_time']&&_0xdfbbb5['iat'],_0x485578['auth'],'internal-error');const _0x161cd0=typeof _0xdfbbb5['firebase']=='object'?_0xdfbbb5['firebase']:void 0x0,_0x2e66e2=_0x161cd0==null?void 0x0:_0x161cd0['sign_in_provider'];return{'claims':_0xdfbbb5,'token':_0x45da96,'authTime':Pt(fi(_0xdfbbb5['auth_time'])),'issuedAtTime':Pt(fi(_0xdfbbb5['iat'])),'expirationTime':Pt(fi(_0xdfbbb5['exp'])),'signInProvider':_0x2e66e2||null,'signInSecondFactor':(_0x161cd0==null?void 0x0:_0x161cd0['sign_in_second_factor'])||null};}function fi(_0x38d1ff){return Number(_0x38d1ff)*0x3e8;}function Ts(_0x610c3){const [_0x227a9e,_0xdf6e5f,_0x3d2c02]=_0x610c3['split']('.');if(_0x227a9e===void 0x0||_0xdf6e5f===void 0x0||_0x3d2c02===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x28e38c=fn(_0xdf6e5f);return _0x28e38c?JSON['parse'](_0x28e38c):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x318a01){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x318a01==null?void 0x0:_0x318a01['toString']()),null;}}function Cr(_0x5a52f8){const _0x4d744f=Ts(_0x5a52f8);return m(_0x4d744f,'internal-error'),m(typeof _0x4d744f['exp']<'u','internal-error'),m(typeof _0x4d744f['iat']<'u','internal-error'),Number(_0x4d744f['exp'])-Number(_0x4d744f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x354f64,_0x312879,_0x46f9b1=!0x1){if(_0x46f9b1)return _0x312879;try{return await _0x312879;}catch(_0x3f0310){throw _0x3f0310 instanceof Re&&If(_0x3f0310)&&_0x354f64['auth']['currentUser']===_0x354f64&&await _0x354f64['auth']['signOut'](),_0x3f0310;}}function If({code:_0x6c16c3}){return _0x6c16c3==='auth/user-disabled'||_0x6c16c3==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0xef0ad9){this['user']=_0xef0ad9,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x398fda){if(_0x398fda){const _0x141fe8=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x141fe8;}else{this['errorBackoff']=0x7530;const _0x114b99=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x114b99);}}['schedule'](_0x3156a6=!0x1){if(!this['isRunning'])return;const _0x42a900=this['getInterval'](_0x3156a6);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x42a900);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5c7cdc){(_0x5c7cdc==null?void 0x0:_0x5c7cdc['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x35f9f1,_0x28823c){this['createdAt']=_0x35f9f1,this['lastLoginAt']=_0x28823c,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x11503f){this['createdAt']=_0x11503f['createdAt'],this['lastLoginAt']=_0x11503f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x358cbe){var _0x2314c6;const _0x42e411=_0x358cbe['auth'],_0x2cd4d0=await _0x358cbe['getIdToken'](),_0x5e9e3f=await Ht(_0x358cbe,Pn(_0x42e411,{'idToken':_0x2cd4d0}));m(_0x5e9e3f==null?void 0x0:_0x5e9e3f['users']['length'],_0x42e411,'internal-error');const _0x5b7545=_0x5e9e3f['users'][0x0];_0x358cbe['_notifyReloadListener'](_0x5b7545);const _0x25f377=(_0x2314c6=_0x5b7545['providerUserInfo'])!=null&&_0x2314c6['length']?Sa(_0x5b7545['providerUserInfo']):[],_0x595ed1=Tf(_0x358cbe['providerData'],_0x25f377),_0x1516a0=_0x358cbe['isAnonymous'],_0xd8e2a1=!(_0x358cbe['email']&&_0x5b7545['passwordHash'])&&!(_0x595ed1!=null&&_0x595ed1['length']),_0x53cdc9=_0x1516a0?_0xd8e2a1:!0x1,_0x42478b={'uid':_0x5b7545['localId'],'displayName':_0x5b7545['displayName']||null,'photoURL':_0x5b7545['photoUrl']||null,'email':_0x5b7545['email']||null,'emailVerified':_0x5b7545['emailVerified']||!0x1,'phoneNumber':_0x5b7545['phoneNumber']||null,'tenantId':_0x5b7545['tenantId']||null,'providerData':_0x595ed1,'metadata':new Li(_0x5b7545['createdAt'],_0x5b7545['lastLoginAt']),'isAnonymous':_0x53cdc9};Object['assign'](_0x358cbe,_0x42478b);}async function Cf(_0x55486d){const _0x302dba=P(_0x55486d);await Nn(_0x302dba),await _0x302dba['auth']['_persistUserIfCurrent'](_0x302dba),_0x302dba['auth']['_notifyListenersIfCurrent'](_0x302dba);}function Tf(_0x2f5359,_0xb43aba){return[..._0x2f5359['filter'](_0x3c8400=>!_0xb43aba['some'](_0x5be37b=>_0x5be37b['providerId']===_0x3c8400['providerId'])),..._0xb43aba];}function Sa(_0x2583e2){return _0x2583e2['map'](({providerId:_0x596c4c,..._0x2298df})=>({'providerId':_0x596c4c,'uid':_0x2298df['rawId']||'','displayName':_0x2298df['displayName']||null,'email':_0x2298df['email']||null,'phoneNumber':_0x2298df['phoneNumber']||null,'photoURL':_0x2298df['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x1b14e9,_0xb0a327){const _0x539bf7=await Ca(_0x1b14e9,{},async()=>{const _0x3951d4=ut({'grant_type':'refresh_token','refresh_token':_0xb0a327})['slice'](0x1),{tokenApiHost:_0x3973f9,apiKey:_0x27e561}=_0x1b14e9['config'],_0x58a9f6=await Ta(_0x1b14e9,_0x3973f9,'/v1/token','key='+_0x27e561),_0x3f8092=await _0x1b14e9['_getAdditionalHeaders']();_0x3f8092['Content-Type']='application/x-www-form-urlencoded';const _0x502d00={'method':'POST','headers':_0x3f8092,'body':_0x3951d4};return _0x1b14e9['emulatorConfig']&&qt(_0x1b14e9['emulatorConfig']['host'])&&(_0x502d00['credentials']='include'),wa['fetch']()(_0x58a9f6,_0x502d00);});return{'accessToken':_0x539bf7['access_token'],'expiresIn':_0x539bf7['expires_in'],'refreshToken':_0x539bf7['refresh_token']};}async function bf(_0x4c6a8b,_0x4d5e74){return Pe(_0x4c6a8b,'POST','/v2/accounts:revokeToken',ke(_0x4c6a8b,_0x4d5e74));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4734a8){m(_0x4734a8['idToken'],'internal-error'),m(typeof _0x4734a8['idToken']<'u','internal-error'),m(typeof _0x4734a8['refreshToken']<'u','internal-error');const _0x3df045='expiresIn'in _0x4734a8&&typeof _0x4734a8['expiresIn']<'u'?Number(_0x4734a8['expiresIn']):Cr(_0x4734a8['idToken']);this['updateTokensAndExpiration'](_0x4734a8['idToken'],_0x4734a8['refreshToken'],_0x3df045);}['updateFromIdToken'](_0x50caf1){m(_0x50caf1['length']!==0x0,'internal-error');const _0xab9a14=Cr(_0x50caf1);this['updateTokensAndExpiration'](_0x50caf1,null,_0xab9a14);}async['getToken'](_0x34c768,_0x47e9ad=!0x1){return!_0x47e9ad&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x34c768,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x34c768,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x33acf8,_0x59a9c9){const {accessToken:_0x1ec25b,refreshToken:_0xac1893,expiresIn:_0x2182fa}=await Sf(_0x33acf8,_0x59a9c9);this['updateTokensAndExpiration'](_0x1ec25b,_0xac1893,Number(_0x2182fa));}['updateTokensAndExpiration'](_0x5ec8de,_0x243e6f,_0x3856a5){this['refreshToken']=_0x243e6f||null,this['accessToken']=_0x5ec8de||null,this['expirationTime']=Date['now']()+_0x3856a5*0x3e8;}static['fromJSON'](_0x2c1451,_0x45bd3e){const {refreshToken:_0x578799,accessToken:_0x1520de,expirationTime:_0x826e0d}=_0x45bd3e,_0x4d374c=new et();return _0x578799&&(m(typeof _0x578799=='string','internal-error',{'appName':_0x2c1451}),_0x4d374c['refreshToken']=_0x578799),_0x1520de&&(m(typeof _0x1520de=='string','internal-error',{'appName':_0x2c1451}),_0x4d374c['accessToken']=_0x1520de),_0x826e0d&&(m(typeof _0x826e0d=='number','internal-error',{'appName':_0x2c1451}),_0x4d374c['expirationTime']=_0x826e0d),_0x4d374c;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1dafa3){this['accessToken']=_0x1dafa3['accessToken'],this['refreshToken']=_0x1dafa3['refreshToken'],this['expirationTime']=_0x1dafa3['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3a179b,_0x48980e){m(typeof _0x3a179b=='string'||typeof _0x3a179b>'u','internal-error',{'appName':_0x48980e});}class j{constructor({uid:_0x16f314,auth:_0x463e9e,stsTokenManager:_0x40b398,..._0x502861}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x16f314,this['auth']=_0x463e9e,this['stsTokenManager']=_0x40b398,this['accessToken']=_0x40b398['accessToken'],this['displayName']=_0x502861['displayName']||null,this['email']=_0x502861['email']||null,this['emailVerified']=_0x502861['emailVerified']||!0x1,this['phoneNumber']=_0x502861['phoneNumber']||null,this['photoURL']=_0x502861['photoURL']||null,this['isAnonymous']=_0x502861['isAnonymous']||!0x1,this['tenantId']=_0x502861['tenantId']||null,this['providerData']=_0x502861['providerData']?[..._0x502861['providerData']]:[],this['metadata']=new Li(_0x502861['createdAt']||void 0x0,_0x502861['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1f62b6){const _0x5d2ca8=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1f62b6));return m(_0x5d2ca8,this['auth'],'internal-error'),this['accessToken']!==_0x5d2ca8&&(this['accessToken']=_0x5d2ca8,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5d2ca8;}['getIdTokenResult'](_0x69ca95){return Ef(this,_0x69ca95);}['reload'](){return Cf(this);}['_assign'](_0x4f4adc){this!==_0x4f4adc&&(m(this['uid']===_0x4f4adc['uid'],this['auth'],'internal-error'),this['displayName']=_0x4f4adc['displayName'],this['photoURL']=_0x4f4adc['photoURL'],this['email']=_0x4f4adc['email'],this['emailVerified']=_0x4f4adc['emailVerified'],this['phoneNumber']=_0x4f4adc['phoneNumber'],this['isAnonymous']=_0x4f4adc['isAnonymous'],this['tenantId']=_0x4f4adc['tenantId'],this['providerData']=_0x4f4adc['providerData']['map'](_0x3c00b1=>({..._0x3c00b1})),this['metadata']['_copy'](_0x4f4adc['metadata']),this['stsTokenManager']['_assign'](_0x4f4adc['stsTokenManager']));}['_clone'](_0x549f29){const _0x942e19=new j({...this,'auth':_0x549f29,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x942e19['metadata']['_copy'](this['metadata']),_0x942e19;}['_onReload'](_0x17f63c){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x17f63c,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xf3d2d7){this['reloadListener']?this['reloadListener'](_0xf3d2d7):this['reloadUserInfo']=_0xf3d2d7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x212ef9,_0x356dd7=!0x1){let _0x1aa978=!0x1;_0x212ef9['idToken']&&_0x212ef9['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x212ef9),_0x1aa978=!0x0),_0x356dd7&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1aa978&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1db58f=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x1db58f})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x360fad=>({..._0x360fad})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x19fdbe,_0x32b3d3){const _0x34d938=_0x32b3d3['displayName']??void 0x0,_0x322514=_0x32b3d3['email']??void 0x0,_0x2b106d=_0x32b3d3['phoneNumber']??void 0x0,_0x17cf34=_0x32b3d3['photoURL']??void 0x0,_0x4920de=_0x32b3d3['tenantId']??void 0x0,_0x1d4f57=_0x32b3d3['_redirectEventId']??void 0x0,_0x508cfd=_0x32b3d3['createdAt']??void 0x0,_0x18b380=_0x32b3d3['lastLoginAt']??void 0x0,{uid:_0x237769,emailVerified:_0x11bfdf,isAnonymous:_0x23b80b,providerData:_0x5bc390,stsTokenManager:_0x4d7bf3}=_0x32b3d3;m(_0x237769&&_0x4d7bf3,_0x19fdbe,'internal-error');const _0x5514b3=et['fromJSON'](this['name'],_0x4d7bf3);m(typeof _0x237769=='string',_0x19fdbe,'internal-error'),le(_0x34d938,_0x19fdbe['name']),le(_0x322514,_0x19fdbe['name']),m(typeof _0x11bfdf=='boolean',_0x19fdbe,'internal-error'),m(typeof _0x23b80b=='boolean',_0x19fdbe,'internal-error'),le(_0x2b106d,_0x19fdbe['name']),le(_0x17cf34,_0x19fdbe['name']),le(_0x4920de,_0x19fdbe['name']),le(_0x1d4f57,_0x19fdbe['name']),le(_0x508cfd,_0x19fdbe['name']),le(_0x18b380,_0x19fdbe['name']);const _0x15aa0a=new j({'uid':_0x237769,'auth':_0x19fdbe,'email':_0x322514,'emailVerified':_0x11bfdf,'displayName':_0x34d938,'isAnonymous':_0x23b80b,'photoURL':_0x17cf34,'phoneNumber':_0x2b106d,'tenantId':_0x4920de,'stsTokenManager':_0x5514b3,'createdAt':_0x508cfd,'lastLoginAt':_0x18b380});return _0x5bc390&&Array['isArray'](_0x5bc390)&&(_0x15aa0a['providerData']=_0x5bc390['map'](_0x46c086=>({..._0x46c086}))),_0x1d4f57&&(_0x15aa0a['_redirectEventId']=_0x1d4f57),_0x15aa0a;}static async['_fromIdTokenResponse'](_0x592641,_0xeef2ac,_0x1f1f6e=!0x1){const _0x25e6c1=new et();_0x25e6c1['updateFromServerResponse'](_0xeef2ac);const _0x1be815=new j({'uid':_0xeef2ac['localId'],'auth':_0x592641,'stsTokenManager':_0x25e6c1,'isAnonymous':_0x1f1f6e});return await Nn(_0x1be815),_0x1be815;}static async['_fromGetAccountInfoResponse'](_0x5c8f35,_0x2a3d44,_0x5021d4){const _0x4a3bc6=_0x2a3d44['users'][0x0];m(_0x4a3bc6['localId']!==void 0x0,'internal-error');const _0x522140=_0x4a3bc6['providerUserInfo']!==void 0x0?Sa(_0x4a3bc6['providerUserInfo']):[],_0x53e488=!(_0x4a3bc6['email']&&_0x4a3bc6['passwordHash'])&&!(_0x522140!=null&&_0x522140['length']),_0x27b81d=new et();_0x27b81d['updateFromIdToken'](_0x5021d4);const _0x5e4063=new j({'uid':_0x4a3bc6['localId'],'auth':_0x5c8f35,'stsTokenManager':_0x27b81d,'isAnonymous':_0x53e488}),_0x13da60={'uid':_0x4a3bc6['localId'],'displayName':_0x4a3bc6['displayName']||null,'photoURL':_0x4a3bc6['photoUrl']||null,'email':_0x4a3bc6['email']||null,'emailVerified':_0x4a3bc6['emailVerified']||!0x1,'phoneNumber':_0x4a3bc6['phoneNumber']||null,'tenantId':_0x4a3bc6['tenantId']||null,'providerData':_0x522140,'metadata':new Li(_0x4a3bc6['createdAt'],_0x4a3bc6['lastLoginAt']),'isAnonymous':!(_0x4a3bc6['email']&&_0x4a3bc6['passwordHash'])&&!(_0x522140!=null&&_0x522140['length'])};return Object['assign'](_0x5e4063,_0x13da60),_0x5e4063;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x46d011){ce(_0x46d011 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x565df0=Tr['get'](_0x46d011);return _0x565df0?(ce(_0x565df0 instanceof _0x46d011,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x565df0):(_0x565df0=new _0x46d011(),Tr['set'](_0x46d011,_0x565df0),_0x565df0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2d7fcb,_0x4945ce){this['storage'][_0x2d7fcb]=_0x4945ce;}async['_get'](_0x194d37){const _0x5dfe48=this['storage'][_0x194d37];return _0x5dfe48===void 0x0?null:_0x5dfe48;}async['_remove'](_0x441cd4){delete this['storage'][_0x441cd4];}['_addListener'](_0x429a55,_0x58e7c7){}['_removeListener'](_0x4f16ab,_0x5ce164){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x51fe47,_0x2c74a9,_0x4af2a1){return'firebase:'+_0x51fe47+':'+_0x2c74a9+':'+_0x4af2a1;}class tt{constructor(_0x2a8cdb,_0x5a85d1,_0x1b808c){this['persistence']=_0x2a8cdb,this['auth']=_0x5a85d1,this['userKey']=_0x1b808c;const {config:_0x1dbbc0,name:_0x1a66e9}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x1dbbc0['apiKey'],_0x1a66e9),this['fullPersistenceKey']=ln('persistence',_0x1dbbc0['apiKey'],_0x1a66e9),this['boundEventHandler']=_0x5a85d1['_onStorageEvent']['bind'](_0x5a85d1),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x235fbd){return this['persistence']['_set'](this['fullUserKey'],_0x235fbd['toJSON']());}async['getCurrentUser'](){const _0x2400bf=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2400bf)return null;if(typeof _0x2400bf=='string'){const _0x27346b=await Pn(this['auth'],{'idToken':_0x2400bf})['catch'](()=>{});return _0x27346b?j['_fromGetAccountInfoResponse'](this['auth'],_0x27346b,_0x2400bf):null;}return j['_fromJSON'](this['auth'],_0x2400bf);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x15179a){if(this['persistence']===_0x15179a)return;const _0x193689=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x15179a,_0x193689)return this['setCurrentUser'](_0x193689);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3bafc5,_0x5eb452,_0x2d7c37='authUser'){if(!_0x5eb452['length'])return new tt(ie(Sr),_0x3bafc5,_0x2d7c37);const _0x6e5900=(await Promise['all'](_0x5eb452['map'](async _0x211ce1=>{if(await _0x211ce1['_isAvailable']())return _0x211ce1;})))['filter'](_0x90646f=>_0x90646f);let _0xd756b9=_0x6e5900[0x0]||ie(Sr);const _0x1d3bb2=ln(_0x2d7c37,_0x3bafc5['config']['apiKey'],_0x3bafc5['name']);let _0x3c2996=null;for(const _0x356a82 of _0x5eb452)try{const _0x5a4652=await _0x356a82['_get'](_0x1d3bb2);if(_0x5a4652){let _0x119729;if(typeof _0x5a4652=='string'){const _0x5ace00=await Pn(_0x3bafc5,{'idToken':_0x5a4652})['catch'](()=>{});if(!_0x5ace00)break;_0x119729=await j['_fromGetAccountInfoResponse'](_0x3bafc5,_0x5ace00,_0x5a4652);}else _0x119729=j['_fromJSON'](_0x3bafc5,_0x5a4652);_0x356a82!==_0xd756b9&&(_0x3c2996=_0x119729),_0xd756b9=_0x356a82;break;}}catch{}const _0x508073=_0x6e5900['filter'](_0x4e4439=>_0x4e4439['_shouldAllowMigration']);return!_0xd756b9['_shouldAllowMigration']||!_0x508073['length']?new tt(_0xd756b9,_0x3bafc5,_0x2d7c37):(_0xd756b9=_0x508073[0x0],_0x3c2996&&await _0xd756b9['_set'](_0x1d3bb2,_0x3c2996['toJSON']()),await Promise['all'](_0x5eb452['map'](async _0x4343b7=>{if(_0x4343b7!==_0xd756b9)try{await _0x4343b7['_remove'](_0x1d3bb2);}catch{}})),new tt(_0xd756b9,_0x3bafc5,_0x2d7c37));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x3680f0){const _0x34605f=_0x3680f0['toLowerCase']();if(_0x34605f['includes']('opera/')||_0x34605f['includes']('opr/')||_0x34605f['includes']('opios/'))return'Opera';if(Pa(_0x34605f))return'IEMobile';if(_0x34605f['includes']('msie')||_0x34605f['includes']('trident/'))return'IE';if(_0x34605f['includes']('edge/'))return'Edge';if(Ra(_0x34605f))return'Firefox';if(_0x34605f['includes']('silk/'))return'Silk';if(Oa(_0x34605f))return'Blackberry';if(Da(_0x34605f))return'Webos';if(Aa(_0x34605f))return'Safari';if((_0x34605f['includes']('chrome/')||ka(_0x34605f))&&!_0x34605f['includes']('edge/'))return'Chrome';if(Na(_0x34605f))return'Android';{const _0x1e7466=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x17f65e=_0x3680f0['match'](_0x1e7466);if((_0x17f65e==null?void 0x0:_0x17f65e['length'])===0x2)return _0x17f65e[0x1];}return'Other';}function Ra(_0x289663=W()){return/firefox\//i['test'](_0x289663);}function Aa(_0x3dceb3=W()){const _0x43c8be=_0x3dceb3['toLowerCase']();return _0x43c8be['includes']('safari/')&&!_0x43c8be['includes']('chrome/')&&!_0x43c8be['includes']('crios/')&&!_0x43c8be['includes']('android');}function ka(_0x2c6620=W()){return/crios\//i['test'](_0x2c6620);}function Pa(_0xd8a57=W()){return/iemobile/i['test'](_0xd8a57);}function Na(_0x3ee777=W()){return/android/i['test'](_0x3ee777);}function Oa(_0x3b5e1b=W()){return/blackberry/i['test'](_0x3b5e1b);}function Da(_0x31d295=W()){return/webos/i['test'](_0x31d295);}function Ss(_0x4f439d=W()){return/iphone|ipad|ipod/i['test'](_0x4f439d)||/macintosh/i['test'](_0x4f439d)&&/mobile/i['test'](_0x4f439d);}function Rf(_0x1423cf=W()){var _0x30e010;return Ss(_0x1423cf)&&!!((_0x30e010=window['navigator'])!=null&&_0x30e010['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3c19e7=W()){return Ss(_0x3c19e7)||Na(_0x3c19e7)||Da(_0x3c19e7)||Oa(_0x3c19e7)||/windows phone/i['test'](_0x3c19e7)||Pa(_0x3c19e7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x19adc5,_0x5816e6=[]){let _0x21a184;switch(_0x19adc5){case'Browser':_0x21a184=br(W());break;case'Worker':_0x21a184=br(W())+'-'+_0x19adc5;break;default:_0x21a184=_0x19adc5;}const _0x192acc=_0x5816e6['length']?_0x5816e6['join'](','):'FirebaseCore-web';return _0x21a184+'/JsCore/'+dt+'/'+_0x192acc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1bd251){this['auth']=_0x1bd251,this['queue']=[];}['pushCallback'](_0x39a795,_0x4453f6){const _0x4ae9c8=_0xec7544=>new Promise((_0x267851,_0x334f18)=>{try{const _0x140c2b=_0x39a795(_0xec7544);_0x267851(_0x140c2b);}catch(_0x54c013){_0x334f18(_0x54c013);}});_0x4ae9c8['onAbort']=_0x4453f6,this['queue']['push'](_0x4ae9c8);const _0x106ccc=this['queue']['length']-0x1;return()=>{this['queue'][_0x106ccc]=()=>Promise['resolve']();};}async['runMiddleware'](_0x31152a){if(this['auth']['currentUser']===_0x31152a)return;const _0x8a3c98=[];try{for(const _0xd267b2 of this['queue'])await _0xd267b2(_0x31152a),_0xd267b2['onAbort']&&_0x8a3c98['push'](_0xd267b2['onAbort']);}catch(_0x45f26f){_0x8a3c98['reverse']();for(const _0x438709 of _0x8a3c98)try{_0x438709();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x45f26f==null?void 0x0:_0x45f26f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x231035,_0x18c6ed={}){return Pe(_0x231035,'GET','/v2/passwordPolicy',ke(_0x231035,_0x18c6ed));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x19f6a7){var _0x156eae;const _0x17b186=_0x19f6a7['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x17b186['minPasswordLength']??Nf,_0x17b186['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x17b186['maxPasswordLength']),_0x17b186['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x17b186['containsLowercaseCharacter']),_0x17b186['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x17b186['containsUppercaseCharacter']),_0x17b186['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x17b186['containsNumericCharacter']),_0x17b186['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x17b186['containsNonAlphanumericCharacter']),this['enforcementState']=_0x19f6a7['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x156eae=_0x19f6a7['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x156eae['join'](''))??'',this['forceUpgradeOnSignin']=_0x19f6a7['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x19f6a7['schemaVersion'];}['validatePassword'](_0x278cff){const _0x113542={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x278cff,_0x113542),this['validatePasswordCharacterOptions'](_0x278cff,_0x113542),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['meetsMinPasswordLength']??!0x0),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['meetsMaxPasswordLength']??!0x0),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['containsLowercaseLetter']??!0x0),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['containsUppercaseLetter']??!0x0),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['containsNumericCharacter']??!0x0),_0x113542['isValid']&&(_0x113542['isValid']=_0x113542['containsNonAlphanumericCharacter']??!0x0),_0x113542;}['validatePasswordLengthOptions'](_0x55c694,_0x3e2d36){const _0x363375=this['customStrengthOptions']['minPasswordLength'],_0x1c48d4=this['customStrengthOptions']['maxPasswordLength'];_0x363375&&(_0x3e2d36['meetsMinPasswordLength']=_0x55c694['length']>=_0x363375),_0x1c48d4&&(_0x3e2d36['meetsMaxPasswordLength']=_0x55c694['length']<=_0x1c48d4);}['validatePasswordCharacterOptions'](_0xedf06b,_0x39a4f8){this['updatePasswordCharacterOptionsStatuses'](_0x39a4f8,!0x1,!0x1,!0x1,!0x1);let _0x50a5f0;for(let _0x42a845=0x0;_0x42a845<_0xedf06b['length'];_0x42a845++)_0x50a5f0=_0xedf06b['charAt'](_0x42a845),this['updatePasswordCharacterOptionsStatuses'](_0x39a4f8,_0x50a5f0>='a'&&_0x50a5f0<='z',_0x50a5f0>='A'&&_0x50a5f0<='Z',_0x50a5f0>='0'&&_0x50a5f0<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x50a5f0));}['updatePasswordCharacterOptionsStatuses'](_0x48b289,_0x2a132c,_0xadbf2c,_0x47b92a,_0x2e2f17){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x48b289['containsLowercaseLetter']||(_0x48b289['containsLowercaseLetter']=_0x2a132c)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x48b289['containsUppercaseLetter']||(_0x48b289['containsUppercaseLetter']=_0xadbf2c)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x48b289['containsNumericCharacter']||(_0x48b289['containsNumericCharacter']=_0x47b92a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x48b289['containsNonAlphanumericCharacter']||(_0x48b289['containsNonAlphanumericCharacter']=_0x2e2f17));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x457086,_0x30033a,_0x2d3ba8,_0x517a85){this['app']=_0x457086,this['heartbeatServiceProvider']=_0x30033a,this['appCheckServiceProvider']=_0x2d3ba8,this['config']=_0x517a85,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x457086['name'],this['clientVersion']=_0x517a85['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5730aa=>this['_resolvePersistenceManagerAvailable']=_0x5730aa);}['_initializeWithPersistence'](_0x5d03f5,_0x12d232){return _0x12d232&&(this['_popupRedirectResolver']=ie(_0x12d232)),this['_initializationPromise']=this['queue'](async()=>{var _0x5caa86,_0x24dff7,_0x59323c;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x5d03f5),(_0x5caa86=this['_resolvePersistenceManagerAvailable'])==null||_0x5caa86['call'](this),!this['_deleted'])){if((_0x24dff7=this['_popupRedirectResolver'])!=null&&_0x24dff7['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x12d232),this['lastNotifiedUid']=((_0x59323c=this['currentUser'])==null?void 0x0:_0x59323c['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x289583=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x289583)){if(this['currentUser']&&_0x289583&&this['currentUser']['uid']===_0x289583['uid']){this['_currentUser']['_assign'](_0x289583),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x289583,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x35548d){try{const _0x38e961=await Pn(this,{'idToken':_0x35548d}),_0x52635b=await j['_fromGetAccountInfoResponse'](this,_0x38e961,_0x35548d);await this['directlySetCurrentUser'](_0x52635b);}catch(_0x4cfc83){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4cfc83),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x167ddf){var _0x3ad7f7;if($(this['app'])){const _0x3d4c41=this['app']['settings']['authIdToken'];return _0x3d4c41?new Promise(_0xf7066=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3d4c41)['then'](_0xf7066,_0xf7066));}):this['directlySetCurrentUser'](null);}const _0x47ca6c=await this['assertedPersistence']['getCurrentUser']();let _0x5e834c=_0x47ca6c,_0x511bae=!0x1;if(_0x167ddf&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x4725c5=(_0x3ad7f7=this['redirectUser'])==null?void 0x0:_0x3ad7f7['_redirectEventId'],_0x58d2e7=_0x5e834c==null?void 0x0:_0x5e834c['_redirectEventId'],_0x51a2ec=await this['tryRedirectSignIn'](_0x167ddf);(!_0x4725c5||_0x4725c5===_0x58d2e7)&&(_0x51a2ec!=null&&_0x51a2ec['user'])&&(_0x5e834c=_0x51a2ec['user'],_0x511bae=!0x0);}if(!_0x5e834c)return this['directlySetCurrentUser'](null);if(!_0x5e834c['_redirectEventId']){if(_0x511bae)try{await this['beforeStateQueue']['runMiddleware'](_0x5e834c);}catch(_0x4130e7){_0x5e834c=_0x47ca6c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4130e7));}return _0x5e834c?this['reloadAndSetCurrentUserOrClear'](_0x5e834c):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5e834c['_redirectEventId']?this['directlySetCurrentUser'](_0x5e834c):this['reloadAndSetCurrentUserOrClear'](_0x5e834c);}async['tryRedirectSignIn'](_0x15bfd5){let _0x3d76ed=null;try{_0x3d76ed=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x15bfd5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3d76ed;}async['reloadAndSetCurrentUserOrClear'](_0x2edf72){try{await Nn(_0x2edf72);}catch(_0x145250){if((_0x145250==null?void 0x0:_0x145250['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2edf72);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xa4d9d4){if($(this['app']))return Promise['reject'](re(this));const _0xcd4fbc=_0xa4d9d4?P(_0xa4d9d4):null;return _0xcd4fbc&&m(_0xcd4fbc['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xcd4fbc&&_0xcd4fbc['_clone'](this));}async['_updateCurrentUser'](_0x150ef0,_0x3d7d5f=!0x1){if(!this['_deleted'])return _0x150ef0&&m(this['tenantId']===_0x150ef0['tenantId'],this,'tenant-id-mismatch'),_0x3d7d5f||await this['beforeStateQueue']['runMiddleware'](_0x150ef0),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x150ef0),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x552eea){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x552eea));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xd6992a){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1940e7=this['_getPasswordPolicyInternal']();return _0x1940e7['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1940e7['validatePassword'](_0xd6992a);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x18fa67=await Pf(this),_0x51c4cb=new Of(_0x18fa67);this['tenantId']===null?this['_projectPasswordPolicy']=_0x51c4cb:this['_tenantPasswordPolicies'][this['tenantId']]=_0x51c4cb;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x49dbd0){this['_errorFactory']=new Gt('auth','Firebase',_0x49dbd0());}['onAuthStateChanged'](_0xd32cf2,_0x21f62d,_0xba4220){return this['registerStateListener'](this['authStateSubscription'],_0xd32cf2,_0x21f62d,_0xba4220);}['beforeAuthStateChanged'](_0x4cab6f,_0x372d0d){return this['beforeStateQueue']['pushCallback'](_0x4cab6f,_0x372d0d);}['onIdTokenChanged'](_0x3779bb,_0x132215,_0x5466c5){return this['registerStateListener'](this['idTokenSubscription'],_0x3779bb,_0x132215,_0x5466c5);}['authStateReady'](){return new Promise((_0x164cf7,_0x4b69de)=>{if(this['currentUser'])_0x164cf7();else{const _0x365d4b=this['onAuthStateChanged'](()=>{_0x365d4b(),_0x164cf7();},_0x4b69de);}});}async['revokeAccessToken'](_0x3907f1){if(this['currentUser']){const _0x1c1dd7=await this['currentUser']['getIdToken'](),_0x4cf0f9={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3907f1,'idToken':_0x1c1dd7};this['tenantId']!=null&&(_0x4cf0f9['tenantId']=this['tenantId']),await bf(this,_0x4cf0f9);}}['toJSON'](){var _0x3e9f48;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3e9f48=this['_currentUser'])==null?void 0x0:_0x3e9f48['toJSON']()};}async['_setRedirectUser'](_0x59db77,_0x1ab4ce){const _0x297c93=await this['getOrInitRedirectPersistenceManager'](_0x1ab4ce);return _0x59db77===null?_0x297c93['removeCurrentUser']():_0x297c93['setCurrentUser'](_0x59db77);}async['getOrInitRedirectPersistenceManager'](_0x2c388e){if(!this['redirectPersistenceManager']){const _0x5bfadf=_0x2c388e&&ie(_0x2c388e)||this['_popupRedirectResolver'];m(_0x5bfadf,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x5bfadf['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x179651){var _0x503124,_0x5253aa;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x503124=this['_currentUser'])==null?void 0x0:_0x503124['_redirectEventId'])===_0x179651?this['_currentUser']:((_0x5253aa=this['redirectUser'])==null?void 0x0:_0x5253aa['_redirectEventId'])===_0x179651?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x45d913){if(_0x45d913===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x45d913));}['_notifyListenersIfCurrent'](_0x173d53){_0x173d53===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3c75fa;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x483f16=((_0x3c75fa=this['currentUser'])==null?void 0x0:_0x3c75fa['uid'])??null;this['lastNotifiedUid']!==_0x483f16&&(this['lastNotifiedUid']=_0x483f16,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xe491ea,_0x3a9b98,_0x3aa5f8,_0xec533b){if(this['_deleted'])return()=>{};const _0x35a3a8=typeof _0x3a9b98=='function'?_0x3a9b98:_0x3a9b98['next']['bind'](_0x3a9b98);let _0x1d750d=!0x1;const _0x3d1b74=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3d1b74,this,'internal-error'),_0x3d1b74['then'](()=>{_0x1d750d||_0x35a3a8(this['currentUser']);}),typeof _0x3a9b98=='function'){const _0x5dfd17=_0xe491ea['addObserver'](_0x3a9b98,_0x3aa5f8,_0xec533b);return()=>{_0x1d750d=!0x0,_0x5dfd17();};}else{const _0x2181cd=_0xe491ea['addObserver'](_0x3a9b98);return()=>{_0x1d750d=!0x0,_0x2181cd();};}}async['directlySetCurrentUser'](_0x50d6fb){this['currentUser']&&this['currentUser']!==_0x50d6fb&&this['_currentUser']['_stopProactiveRefresh'](),_0x50d6fb&&this['isProactiveRefreshEnabled']&&_0x50d6fb['_startProactiveRefresh'](),this['currentUser']=_0x50d6fb,_0x50d6fb?await this['assertedPersistence']['setCurrentUser'](_0x50d6fb):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x37e2e7){return this['operations']=this['operations']['then'](_0x37e2e7,_0x37e2e7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5cd66c){!_0x5cd66c||this['frameworks']['includes'](_0x5cd66c)||(this['frameworks']['push'](_0x5cd66c),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x47bce1;const _0x175e09={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x175e09['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x10e482=await((_0x47bce1=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x47bce1['getHeartbeatsHeader']());_0x10e482&&(_0x175e09['X-Firebase-Client']=_0x10e482);const _0x16f9c9=await this['_getAppCheckToken']();return _0x16f9c9&&(_0x175e09['X-Firebase-AppCheck']=_0x16f9c9),_0x175e09;}async['_getAppCheckToken'](){var _0xf0eb8;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x39509a=await((_0xf0eb8=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xf0eb8['getToken']());return _0x39509a!=null&&_0x39509a['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x39509a['error']),_0x39509a==null?void 0x0:_0x39509a['token'];}}function Ke(_0x263149){return P(_0x263149);}class Rr{constructor(_0x155ca4){this['auth']=_0x155ca4,this['observer']=null,this['addObserver']=Tc(_0xd7f538=>this['observer']=_0xd7f538);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x493237){Jn=_0x493237;}function xa(_0x31e78a){return Jn['loadJS'](_0x31e78a);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x1c45e3){return'__'+_0x1c45e3+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x6f435f){_0x6f435f();}['execute'](_0x31d9ed,_0x24ecfb){return Promise['resolve']('token');}['render'](_0x3e79e8,_0x474178){return'';}}class Wf{['ready'](_0x4619cc){_0x4619cc();}['execute'](_0x506353,_0x52680e){return Promise['resolve']('token');}['render'](_0x1405ec,_0x1ca381){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x5624d4){this['type']=Bf,this['auth']=Ke(_0x5624d4);}async['verify'](_0x4e5042='verify',_0x3c871d=!0x1){async function _0x16c6bf(_0xd6b24){if(!_0x3c871d){if(_0xd6b24['tenantId']==null&&_0xd6b24['_agentRecaptchaConfig']!=null)return _0xd6b24['_agentRecaptchaConfig']['siteKey'];if(_0xd6b24['tenantId']!=null&&_0xd6b24['_tenantRecaptchaConfigs'][_0xd6b24['tenantId']]!==void 0x0)return _0xd6b24['_tenantRecaptchaConfigs'][_0xd6b24['tenantId']]['siteKey'];}return new Promise(async(_0x4ef6da,_0x302a31)=>{yf(_0xd6b24,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1b772f=>{if(_0x1b772f['recaptchaKey']===void 0x0)_0x302a31(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x40c2e9=new mf(_0x1b772f);return _0xd6b24['tenantId']==null?_0xd6b24['_agentRecaptchaConfig']=_0x40c2e9:_0xd6b24['_tenantRecaptchaConfigs'][_0xd6b24['tenantId']]=_0x40c2e9,_0x4ef6da(_0x40c2e9['siteKey']);}})['catch'](_0x5bb28f=>{_0x302a31(_0x5bb28f);});});}function _0x5092d1(_0xc8e3a5,_0x4172c3,_0x147922){const _0x1e80ff=window['grecaptcha'];wr(_0x1e80ff)?_0x1e80ff['enterprise']['ready'](()=>{_0x1e80ff['enterprise']['execute'](_0xc8e3a5,{'action':_0x4e5042})['then'](_0xd21ff2=>{_0x4172c3(_0xd21ff2);})['catch'](()=>{_0x4172c3(Fa);});}):_0x147922(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5a371f,_0x194d5c)=>{_0x16c6bf(this['auth'])['then'](async _0x59f473=>{if(!_0x3c871d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x5092d1(_0x59f473,_0x5a371f,_0x194d5c);else{if(typeof window>'u'){_0x194d5c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3cae07=Lf();_0x3cae07['length']!==0x0&&(_0x3cae07+=_0x59f473+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x189e66;(_0x189e66=he['scriptInjectionDeferred'])==null||_0x189e66['resolve']();},xa(_0x3cae07)['then'](()=>{var _0x4ccb1f;return(_0x4ccb1f=he['scriptInjectionDeferred'])==null?void 0x0:_0x4ccb1f['promise'];})['then'](()=>{_0x5092d1(_0x59f473,_0x5a371f,_0x194d5c);})['catch'](_0x36bb26=>{_0x194d5c(_0x36bb26);});}})['catch'](_0x3d03ea=>{_0x194d5c(_0x3d03ea);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x3ea611,_0x5686ac,_0x102600,_0x3f11e2=!0x1,_0x41070f=!0x1){const _0x3a3289=new he(_0x3ea611);let _0x57620d;if(_0x41070f)_0x57620d=Fa;else try{_0x57620d=await _0x3a3289['verify'](_0x102600);}catch{_0x57620d=await _0x3a3289['verify'](_0x102600,!0x0);}const _0x30841e={..._0x5686ac};if(_0x102600==='mfaSmsEnrollment'||_0x102600==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x30841e){const _0x3b14d1=_0x30841e['phoneEnrollmentInfo']['phoneNumber'],_0x291304=_0x30841e['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x30841e,{'phoneEnrollmentInfo':{'phoneNumber':_0x3b14d1,'recaptchaToken':_0x291304,'captchaResponse':_0x57620d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x30841e){const _0x20f0fd=_0x30841e['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x30841e,{'phoneSignInInfo':{'recaptchaToken':_0x20f0fd,'captchaResponse':_0x57620d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x30841e;}return _0x3f11e2?Object['assign'](_0x30841e,{'captchaResp':_0x57620d}):Object['assign'](_0x30841e,{'captchaResponse':_0x57620d}),Object['assign'](_0x30841e,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x30841e,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x30841e;}async function xi(_0x24603,_0x5cf4c9,_0x25754d,_0x360a54,_0x3cb86b){var _0x3b55da;if((_0x3b55da=_0x24603['_getRecaptchaConfig']())!=null&&_0x3b55da['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4c37c9=await kr(_0x24603,_0x5cf4c9,_0x25754d,_0x25754d==='getOobCode');return _0x360a54(_0x24603,_0x4c37c9);}else return _0x360a54(_0x24603,_0x5cf4c9)['catch'](async _0x33685e=>{if(_0x33685e['code']==='auth/missing-recaptcha-token'){console['log'](_0x25754d+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x25f9aa=await kr(_0x24603,_0x5cf4c9,_0x25754d,_0x25754d==='getOobCode');return _0x360a54(_0x24603,_0x25f9aa);}else return Promise['reject'](_0x33685e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1d29a4,_0x2d6bab){const _0x305f15=Hi(_0x1d29a4,'auth');if(_0x305f15['isInitialized']()){const _0x18b068=_0x305f15['getImmediate'](),_0x4bd962=_0x305f15['getOptions']();if(xe(_0x4bd962,_0x2d6bab??{}))return _0x18b068;Y(_0x18b068,'already-initialized');}return _0x305f15['initialize']({'options':_0x2d6bab});}function Hf(_0x38e8fc,_0x49f5b7){const _0x1bc558=(_0x49f5b7==null?void 0x0:_0x49f5b7['persistence'])||[],_0x438c1c=(Array['isArray'](_0x1bc558)?_0x1bc558:[_0x1bc558])['map'](ie);_0x49f5b7!=null&&_0x49f5b7['errorMap']&&_0x38e8fc['_updateErrorMap'](_0x49f5b7['errorMap']),_0x38e8fc['_initializeWithPersistence'](_0x438c1c,_0x49f5b7==null?void 0x0:_0x49f5b7['popupRedirectResolver']);}function $f(_0x145b23,_0x10ae1c,_0x4d30f2){const _0x3f0d73=Ke(_0x145b23);m(/^https?:\/\//['test'](_0x10ae1c),_0x3f0d73,'invalid-emulator-scheme');const _0x41b5ec=!0x1,_0x3ce432=Ua(_0x10ae1c),{host:_0x5c7119,port:_0x147930}=Gf(_0x10ae1c),_0x4f996f=_0x147930===null?'':':'+_0x147930,_0x3fc62f={'url':_0x3ce432+'//'+_0x5c7119+_0x4f996f+'/'},_0x58becd=Object['freeze']({'host':_0x5c7119,'port':_0x147930,'protocol':_0x3ce432['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x41b5ec})});if(!_0x3f0d73['_canInitEmulator']){m(_0x3f0d73['config']['emulator']&&_0x3f0d73['emulatorConfig'],_0x3f0d73,'emulator-config-failed'),m(xe(_0x3fc62f,_0x3f0d73['config']['emulator'])&&xe(_0x58becd,_0x3f0d73['emulatorConfig']),_0x3f0d73,'emulator-config-failed');return;}_0x3f0d73['config']['emulator']=_0x3fc62f,_0x3f0d73['emulatorConfig']=_0x58becd,_0x3f0d73['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x5c7119)?Qr(_0x3ce432+'//'+_0x5c7119+_0x4f996f):qf();}function Ua(_0x4fd883){const _0xda7d8f=_0x4fd883['indexOf'](':');return _0xda7d8f<0x0?'':_0x4fd883['substr'](0x0,_0xda7d8f+0x1);}function Gf(_0x58a529){const _0x26f8bc=Ua(_0x58a529),_0x43567a=/(\/\/)?([^?#/]+)/['exec'](_0x58a529['substr'](_0x26f8bc['length']));if(!_0x43567a)return{'host':'','port':null};const _0x4d0b99=_0x43567a[0x2]['split']('@')['pop']()||'',_0x3bdf2e=/^(\[[^\]]+\])(:|$)/['exec'](_0x4d0b99);if(_0x3bdf2e){const _0x39956a=_0x3bdf2e[0x1];return{'host':_0x39956a,'port':Pr(_0x4d0b99['substr'](_0x39956a['length']+0x1))};}else{const [_0x3d8efa,_0x452a5e]=_0x4d0b99['split'](':');return{'host':_0x3d8efa,'port':Pr(_0x452a5e)};}}function Pr(_0x2d63dc){if(!_0x2d63dc)return null;const _0x27315d=Number(_0x2d63dc);return isNaN(_0x27315d)?null:_0x27315d;}function qf(){function _0x2b6f90(){const _0x4ae556=document['createElement']('p'),_0x1353a1=_0x4ae556['style'];_0x4ae556['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1353a1['position']='fixed',_0x1353a1['width']='100%',_0x1353a1['backgroundColor']='#ffffff',_0x1353a1['border']='.1em\x20solid\x20#000000',_0x1353a1['color']='#b50000',_0x1353a1['bottom']='0px',_0x1353a1['left']='0px',_0x1353a1['margin']='0px',_0x1353a1['zIndex']='10000',_0x1353a1['textAlign']='center',_0x4ae556['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4ae556);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2b6f90):_0x2b6f90());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5185d5,_0xff1bda){this['providerId']=_0x5185d5,this['signInMethod']=_0xff1bda;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x454d0b){return ne('not\x20implemented');}['_linkToIdToken'](_0x1c4a25,_0x4889d2){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x4be679){return ne('not\x20implemented');}}async function zf(_0x320de7,_0x50fa3d){return Pe(_0x320de7,'POST','/v1/accounts:signUp',_0x50fa3d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x553fc8,_0x41ea31){return en(_0x553fc8,'POST','/v1/accounts:signInWithPassword',ke(_0x553fc8,_0x41ea31));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x33e0d8,_0x169559){return en(_0x33e0d8,'POST','/v1/accounts:signInWithEmailLink',ke(_0x33e0d8,_0x169559));}async function Yf(_0x1fd334,_0x26539b){return en(_0x1fd334,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1fd334,_0x26539b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x16e9f6,_0x413341,_0x110048,_0x20965e=null){super('password',_0x110048),this['_email']=_0x16e9f6,this['_password']=_0x413341,this['_tenantId']=_0x20965e;}static['_fromEmailAndPassword'](_0x593026,_0x2570a9){return new $t(_0x593026,_0x2570a9,'password');}static['_fromEmailAndCode'](_0x3774d5,_0x1b4aa8,_0x2f9166=null){return new $t(_0x3774d5,_0x1b4aa8,'emailLink',_0x2f9166);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x172649){const _0x54e7d7=typeof _0x172649=='string'?JSON['parse'](_0x172649):_0x172649;if(_0x54e7d7!=null&&_0x54e7d7['email']&&(_0x54e7d7!=null&&_0x54e7d7['password'])){if(_0x54e7d7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x54e7d7['email'],_0x54e7d7['password']);if(_0x54e7d7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x54e7d7['email'],_0x54e7d7['password'],_0x54e7d7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1bea5b){switch(this['signInMethod']){case'password':const _0x4bf39e={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1bea5b,_0x4bf39e,'signInWithPassword',jf);case'emailLink':return Kf(_0x1bea5b,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1bea5b,'internal-error');}}async['_linkToIdToken'](_0x1c2de1,_0x2cba64){switch(this['signInMethod']){case'password':const _0x5b50df={'idToken':_0x2cba64,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1c2de1,_0x5b50df,'signUpPassword',zf);case'emailLink':return Yf(_0x1c2de1,{'idToken':_0x2cba64,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1c2de1,'internal-error');}}['_getReauthenticationResolver'](_0x225183){return this['_getIdTokenResponse'](_0x225183);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2641f1,_0x66ef7c){return en(_0x2641f1,'POST','/v1/accounts:signInWithIdp',ke(_0x2641f1,_0x66ef7c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5e338b){const _0x3f9d8f=new $e(_0x5e338b['providerId'],_0x5e338b['signInMethod']);return _0x5e338b['idToken']||_0x5e338b['accessToken']?(_0x5e338b['idToken']&&(_0x3f9d8f['idToken']=_0x5e338b['idToken']),_0x5e338b['accessToken']&&(_0x3f9d8f['accessToken']=_0x5e338b['accessToken']),_0x5e338b['nonce']&&!_0x5e338b['pendingToken']&&(_0x3f9d8f['nonce']=_0x5e338b['nonce']),_0x5e338b['pendingToken']&&(_0x3f9d8f['pendingToken']=_0x5e338b['pendingToken'])):_0x5e338b['oauthToken']&&_0x5e338b['oauthTokenSecret']?(_0x3f9d8f['accessToken']=_0x5e338b['oauthToken'],_0x3f9d8f['secret']=_0x5e338b['oauthTokenSecret']):Y('argument-error'),_0x3f9d8f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2871d2){const _0xf0cd75=typeof _0x2871d2=='string'?JSON['parse'](_0x2871d2):_0x2871d2,{providerId:_0x16fefd,signInMethod:_0x1cd8e6,..._0x53be80}=_0xf0cd75;if(!_0x16fefd||!_0x1cd8e6)return null;const _0x2c063a=new $e(_0x16fefd,_0x1cd8e6);return _0x2c063a['idToken']=_0x53be80['idToken']||void 0x0,_0x2c063a['accessToken']=_0x53be80['accessToken']||void 0x0,_0x2c063a['secret']=_0x53be80['secret'],_0x2c063a['nonce']=_0x53be80['nonce'],_0x2c063a['pendingToken']=_0x53be80['pendingToken']||null,_0x2c063a;}['_getIdTokenResponse'](_0x1056c2){const _0x2014b5=this['buildRequest']();return nt(_0x1056c2,_0x2014b5);}['_linkToIdToken'](_0x431c14,_0x5bb42c){const _0x34d5cc=this['buildRequest']();return _0x34d5cc['idToken']=_0x5bb42c,nt(_0x431c14,_0x34d5cc);}['_getReauthenticationResolver'](_0x1e5d67){const _0x32ff2b=this['buildRequest']();return _0x32ff2b['autoCreate']=!0x1,nt(_0x1e5d67,_0x32ff2b);}['buildRequest'](){const _0x36e64b={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x36e64b['pendingToken']=this['pendingToken'];else{const _0x46c37c={};this['idToken']&&(_0x46c37c['id_token']=this['idToken']),this['accessToken']&&(_0x46c37c['access_token']=this['accessToken']),this['secret']&&(_0x46c37c['oauth_token_secret']=this['secret']),_0x46c37c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x46c37c['nonce']=this['nonce']),_0x36e64b['postBody']=ut(_0x46c37c);}return _0x36e64b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x41b8a4){switch(_0x41b8a4){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x506506){const _0x1c6991=Ct(Tt(_0x506506))['link'],_0x3dc2b8=_0x1c6991?Ct(Tt(_0x1c6991))['deep_link_id']:null,_0x330106=Ct(Tt(_0x506506))['deep_link_id'];return(_0x330106?Ct(Tt(_0x330106))['link']:null)||_0x330106||_0x3dc2b8||_0x1c6991||_0x506506;}class Rs{constructor(_0x2466ca){const _0x32183b=Ct(Tt(_0x2466ca)),_0x103586=_0x32183b['apiKey']??null,_0x599ada=_0x32183b['oobCode']??null,_0x293619=Jf(_0x32183b['mode']??null);m(_0x103586&&_0x599ada&&_0x293619,'argument-error'),this['apiKey']=_0x103586,this['operation']=_0x293619,this['code']=_0x599ada,this['continueUrl']=_0x32183b['continueUrl']??null,this['languageCode']=_0x32183b['lang']??null,this['tenantId']=_0x32183b['tenantId']??null;}static['parseLink'](_0xb7077b){const _0x2edb2b=Xf(_0xb7077b);try{return new Rs(_0x2edb2b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x4146c1,_0x5470f4){return $t['_fromEmailAndPassword'](_0x4146c1,_0x5470f4);}static['credentialWithLink'](_0x249f73,_0xb3a8e7){const _0x3ab851=Rs['parseLink'](_0xb3a8e7);return m(_0x3ab851,'argument-error'),$t['_fromEmailAndCode'](_0x249f73,_0x3ab851['code'],_0x3ab851['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2e8455){this['providerId']=_0x2e8455,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1964ac){this['defaultLanguageCode']=_0x1964ac;}['setCustomParameters'](_0xd350c7){return this['customParameters']=_0xd350c7,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x411068){return this['scopes']['includes'](_0x411068)||this['scopes']['push'](_0x411068),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2e09e4){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2e09e4});}static['credentialFromResult'](_0x475091){return ue['credentialFromTaggedObject'](_0x475091);}static['credentialFromError'](_0x58c6d0){return ue['credentialFromTaggedObject'](_0x58c6d0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b9b95}){if(!_0x1b9b95||!('oauthAccessToken'in _0x1b9b95)||!_0x1b9b95['oauthAccessToken'])return null;try{return ue['credential'](_0x1b9b95['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3e40a4,_0x91113a){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3e40a4,'accessToken':_0x91113a});}static['credentialFromResult'](_0x49082a){return de['credentialFromTaggedObject'](_0x49082a);}static['credentialFromError'](_0x40d182){return de['credentialFromTaggedObject'](_0x40d182['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x44c0e1}){if(!_0x44c0e1)return null;const {oauthIdToken:_0x293cad,oauthAccessToken:_0x2b570d}=_0x44c0e1;if(!_0x293cad&&!_0x2b570d)return null;try{return de['credential'](_0x293cad,_0x2b570d);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x561698){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x561698});}static['credentialFromResult'](_0x3bff3b){return fe['credentialFromTaggedObject'](_0x3bff3b);}static['credentialFromError'](_0x597fc2){return fe['credentialFromTaggedObject'](_0x597fc2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x383201}){if(!_0x383201||!('oauthAccessToken'in _0x383201)||!_0x383201['oauthAccessToken'])return null;try{return fe['credential'](_0x383201['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x22d449,_0x138e3b){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x22d449,'oauthTokenSecret':_0x138e3b});}static['credentialFromResult'](_0x19714d){return pe['credentialFromTaggedObject'](_0x19714d);}static['credentialFromError'](_0x436efb){return pe['credentialFromTaggedObject'](_0x436efb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x533c1c}){if(!_0x533c1c)return null;const {oauthAccessToken:_0x9f942e,oauthTokenSecret:_0x43bf62}=_0x533c1c;if(!_0x9f942e||!_0x43bf62)return null;try{return pe['credential'](_0x9f942e,_0x43bf62);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4b3c26,_0x226002){return en(_0x4b3c26,'POST','/v1/accounts:signUp',ke(_0x4b3c26,_0x226002));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x3822b9){this['user']=_0x3822b9['user'],this['providerId']=_0x3822b9['providerId'],this['_tokenResponse']=_0x3822b9['_tokenResponse'],this['operationType']=_0x3822b9['operationType'];}static async['_fromIdTokenResponse'](_0xb694a4,_0x250e66,_0x5630f0,_0x3da1ef=!0x1){const _0x18e093=await j['_fromIdTokenResponse'](_0xb694a4,_0x5630f0,_0x3da1ef),_0x3d98bb=Nr(_0x5630f0);return new Ge({'user':_0x18e093,'providerId':_0x3d98bb,'_tokenResponse':_0x5630f0,'operationType':_0x250e66});}static async['_forOperation'](_0x4d377e,_0x2c7f06,_0x1711d6){await _0x4d377e['_updateTokensIfNecessary'](_0x1711d6,!0x0);const _0x5294f3=Nr(_0x1711d6);return new Ge({'user':_0x4d377e,'providerId':_0x5294f3,'_tokenResponse':_0x1711d6,'operationType':_0x2c7f06});}}function Nr(_0xc80744){return _0xc80744['providerId']?_0xc80744['providerId']:'phoneNumber'in _0xc80744?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xeec696,_0x21e4ac,_0x43dbbc,_0x4542b8){super(_0x21e4ac['code'],_0x21e4ac['message']),this['operationType']=_0x43dbbc,this['user']=_0x4542b8,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xeec696['name'],'tenantId':_0xeec696['tenantId']??void 0x0,'_serverResponse':_0x21e4ac['customData']['_serverResponse'],'operationType':_0x43dbbc};}static['_fromErrorAndOperation'](_0x1f0e88,_0x16d076,_0x93e9ee,_0x4ace3c){return new On(_0x1f0e88,_0x16d076,_0x93e9ee,_0x4ace3c);}}function Ba(_0x51f7f2,_0x7a9f47,_0x13680f,_0x446afd){return(_0x7a9f47==='reauthenticate'?_0x13680f['_getReauthenticationResolver'](_0x51f7f2):_0x13680f['_getIdTokenResponse'](_0x51f7f2))['catch'](_0x190df5=>{throw _0x190df5['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x51f7f2,_0x190df5,_0x7a9f47,_0x446afd):_0x190df5;});}async function ep(_0x160ccd,_0x15eac8,_0x133ab8=!0x1){const _0x32dac3=await Ht(_0x160ccd,_0x15eac8['_linkToIdToken'](_0x160ccd['auth'],await _0x160ccd['getIdToken']()),_0x133ab8);return Ge['_forOperation'](_0x160ccd,'link',_0x32dac3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x1ba892,_0x18a38d,_0x512eaf=!0x1){const {auth:_0x3bb3a9}=_0x1ba892;if($(_0x3bb3a9['app']))return Promise['reject'](re(_0x3bb3a9));const _0xd1b008='reauthenticate';try{const _0x1e79a1=await Ht(_0x1ba892,Ba(_0x3bb3a9,_0xd1b008,_0x18a38d,_0x1ba892),_0x512eaf);m(_0x1e79a1['idToken'],_0x3bb3a9,'internal-error');const _0x4df96b=Ts(_0x1e79a1['idToken']);m(_0x4df96b,_0x3bb3a9,'internal-error');const {sub:_0x2d3faa}=_0x4df96b;return m(_0x1ba892['uid']===_0x2d3faa,_0x3bb3a9,'user-mismatch'),Ge['_forOperation'](_0x1ba892,_0xd1b008,_0x1e79a1);}catch(_0x4ae40a){throw(_0x4ae40a==null?void 0x0:_0x4ae40a['code'])==='auth/user-not-found'&&Y(_0x3bb3a9,'user-mismatch'),_0x4ae40a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x27baef,_0x3e2536,_0x54aca0=!0x1){if($(_0x27baef['app']))return Promise['reject'](re(_0x27baef));const _0x17d280='signIn',_0x17b5ed=await Ba(_0x27baef,_0x17d280,_0x3e2536),_0x1603c4=await Ge['_fromIdTokenResponse'](_0x27baef,_0x17d280,_0x17b5ed);return _0x54aca0||await _0x27baef['_updateCurrentUser'](_0x1603c4['user']),_0x1603c4;}async function np(_0x27a6fb,_0x1796fb){return Va(Ke(_0x27a6fb),_0x1796fb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x57b9b3){const _0x360314=Ke(_0x57b9b3);_0x360314['_getPasswordPolicyInternal']()&&await _0x360314['_updatePasswordPolicy']();}async function L_(_0x2e5f71,_0x24376f,_0x528dc2){if($(_0x2e5f71['app']))return Promise['reject'](re(_0x2e5f71));const _0x18e641=Ke(_0x2e5f71),_0x2315dd=await xi(_0x18e641,{'returnSecureToken':!0x0,'email':_0x24376f,'password':_0x528dc2,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x1d8066=>{throw _0x1d8066['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2e5f71),_0x1d8066;}),_0x385224=await Ge['_fromIdTokenResponse'](_0x18e641,'signIn',_0x2315dd);return await _0x18e641['_updateCurrentUser'](_0x385224['user']),_0x385224;}function x_(_0x4a1c75,_0x1f6aca,_0xd7bea5){return $(_0x4a1c75['app'])?Promise['reject'](re(_0x4a1c75)):np(P(_0x4a1c75),yt['credential'](_0x1f6aca,_0xd7bea5))['catch'](async _0x2af349=>{throw _0x2af349['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4a1c75),_0x2af349;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x475793,_0x50b39a){return P(_0x475793)['setPersistence'](_0x50b39a);}function ip(_0x228911,_0x5a3b21,_0x4b4a79,_0x5201ec){return P(_0x228911)['onIdTokenChanged'](_0x5a3b21,_0x4b4a79,_0x5201ec);}function sp(_0xa0b1eb,_0x3f0382,_0xe2139c){return P(_0xa0b1eb)['beforeAuthStateChanged'](_0x3f0382,_0xe2139c);}function U_(_0x597e5a,_0x59c856,_0x2fc22e,_0x4d7087){return P(_0x597e5a)['onAuthStateChanged'](_0x59c856,_0x2fc22e,_0x4d7087);}function W_(_0x16a931){return P(_0x16a931)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x43e2a2,_0x59611c){this['storageRetriever']=_0x43e2a2,this['type']=_0x59611c;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x322f83,_0x20e986){return this['storage']['setItem'](_0x322f83,JSON['stringify'](_0x20e986)),Promise['resolve']();}['_get'](_0x12f412){const _0x1712bf=this['storage']['getItem'](_0x12f412);return Promise['resolve'](_0x1712bf?JSON['parse'](_0x1712bf):null);}['_remove'](_0x1969f1){return this['storage']['removeItem'](_0x1969f1),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3d898a,_0x14213e)=>this['onStorageEvent'](_0x3d898a,_0x14213e),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5d5b66){for(const _0xae280d of Object['keys'](this['listeners'])){const _0x3c4854=this['storage']['getItem'](_0xae280d),_0x4406a9=this['localCache'][_0xae280d];_0x3c4854!==_0x4406a9&&_0x5d5b66(_0xae280d,_0x4406a9,_0x3c4854);}}['onStorageEvent'](_0x5d30b6,_0x54be4a=!0x1){if(!_0x5d30b6['key']){this['forAllChangedKeys']((_0x1dd7b2,_0x30cc6d,_0x5ac640)=>{this['notifyListeners'](_0x1dd7b2,_0x5ac640);});return;}const _0x5e1244=_0x5d30b6['key'];_0x54be4a?this['detachListener']():this['stopPolling']();const _0x45f557=()=>{const _0x55e305=this['storage']['getItem'](_0x5e1244);!_0x54be4a&&this['localCache'][_0x5e1244]===_0x55e305||this['notifyListeners'](_0x5e1244,_0x55e305);},_0x3b1707=this['storage']['getItem'](_0x5e1244);Af()&&_0x3b1707!==_0x5d30b6['newValue']&&_0x5d30b6['newValue']!==_0x5d30b6['oldValue']?setTimeout(_0x45f557,op):_0x45f557();}['notifyListeners'](_0x17040c,_0x1e1720){this['localCache'][_0x17040c]=_0x1e1720;const _0x822cba=this['listeners'][_0x17040c];if(_0x822cba){for(const _0x3be22b of Array['from'](_0x822cba))_0x3be22b(_0x1e1720&&JSON['parse'](_0x1e1720));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x25d9c4,_0x45c3d7,_0x4a9595)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x25d9c4,'oldValue':_0x45c3d7,'newValue':_0x4a9595}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x24a63a,_0x3a87bc){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x24a63a]||(this['listeners'][_0x24a63a]=new Set(),this['localCache'][_0x24a63a]=this['storage']['getItem'](_0x24a63a)),this['listeners'][_0x24a63a]['add'](_0x3a87bc);}['_removeListener'](_0x48de3f,_0x4e4411){this['listeners'][_0x48de3f]&&(this['listeners'][_0x48de3f]['delete'](_0x4e4411),this['listeners'][_0x48de3f]['size']===0x0&&delete this['listeners'][_0x48de3f]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5c1d3e,_0x47ba04){await super['_set'](_0x5c1d3e,_0x47ba04),this['localCache'][_0x5c1d3e]=JSON['stringify'](_0x47ba04);}async['_get'](_0x2d8ee5){const _0x58e1c2=await super['_get'](_0x2d8ee5);return this['localCache'][_0x2d8ee5]=JSON['stringify'](_0x58e1c2),_0x58e1c2;}async['_remove'](_0x47b95b){await super['_remove'](_0x47b95b),delete this['localCache'][_0x47b95b];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3c77f4,_0x4deb8c){}['_removeListener'](_0xb4851d,_0x42a9f0){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0xa2a23e){return Promise['all'](_0xa2a23e['map'](async _0x4fb40a=>{try{return{'fulfilled':!0x0,'value':await _0x4fb40a};}catch(_0x43fc56){return{'fulfilled':!0x1,'reason':_0x43fc56};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x55be49){this['eventTarget']=_0x55be49,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2b3072){const _0x15d4be=this['receivers']['find'](_0x1e2a2c=>_0x1e2a2c['isListeningto'](_0x2b3072));if(_0x15d4be)return _0x15d4be;const _0x38b288=new Xn(_0x2b3072);return this['receivers']['push'](_0x38b288),_0x38b288;}['isListeningto'](_0x539640){return this['eventTarget']===_0x539640;}async['handleEvent'](_0x9d06fa){const _0x1956b9=_0x9d06fa,{eventId:_0xe67cd8,eventType:_0x2ed9bf,data:_0x362d16}=_0x1956b9['data'],_0x36861d=this['handlersMap'][_0x2ed9bf];if(!(_0x36861d!=null&&_0x36861d['size']))return;_0x1956b9['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xe67cd8,'eventType':_0x2ed9bf});const _0x5aff5f=Array['from'](_0x36861d)['map'](async _0x448cd0=>_0x448cd0(_0x1956b9['origin'],_0x362d16)),_0x124256=await cp(_0x5aff5f);_0x1956b9['ports'][0x0]['postMessage']({'status':'done','eventId':_0xe67cd8,'eventType':_0x2ed9bf,'response':_0x124256});}['_subscribe'](_0x52d2a7,_0x61488a){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x52d2a7]||(this['handlersMap'][_0x52d2a7]=new Set()),this['handlersMap'][_0x52d2a7]['add'](_0x61488a);}['_unsubscribe'](_0x21ec3e,_0x307034){this['handlersMap'][_0x21ec3e]&&_0x307034&&this['handlersMap'][_0x21ec3e]['delete'](_0x307034),(!_0x307034||this['handlersMap'][_0x21ec3e]['size']===0x0)&&delete this['handlersMap'][_0x21ec3e],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5823c6='',_0x13ecf8=0xa){let _0x477c88='';for(let _0x25556a=0x0;_0x25556a<_0x13ecf8;_0x25556a++)_0x477c88+=Math['floor'](Math['random']()*0xa);return _0x5823c6+_0x477c88;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x5f107f){this['target']=_0x5f107f,this['handlers']=new Set();}['removeMessageHandler'](_0x430c7a){_0x430c7a['messageChannel']&&(_0x430c7a['messageChannel']['port1']['removeEventListener']('message',_0x430c7a['onMessage']),_0x430c7a['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x430c7a);}async['_send'](_0x282f4e,_0x3a3fa0,_0xdd0fb8=0x32){const _0x4535e7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4535e7)throw new Error('connection_unavailable');let _0x10875c,_0x31a4de;return new Promise((_0x50a4c6,_0x3f9dcd)=>{const _0x390b85=As('',0x14);_0x4535e7['port1']['start']();const _0x4e69f9=setTimeout(()=>{_0x3f9dcd(new Error('unsupported_event'));},_0xdd0fb8);_0x31a4de={'messageChannel':_0x4535e7,'onMessage'(_0x21ad0c){const _0x51c628=_0x21ad0c;if(_0x51c628['data']['eventId']===_0x390b85)switch(_0x51c628['data']['status']){case'ack':clearTimeout(_0x4e69f9),_0x10875c=setTimeout(()=>{_0x3f9dcd(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x10875c),_0x50a4c6(_0x51c628['data']['response']);break;default:clearTimeout(_0x4e69f9),clearTimeout(_0x10875c),_0x3f9dcd(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x31a4de),_0x4535e7['port1']['addEventListener']('message',_0x31a4de['onMessage']),this['target']['postMessage']({'eventType':_0x282f4e,'eventId':_0x390b85,'data':_0x3a3fa0},[_0x4535e7['port2']]);})['finally'](()=>{_0x31a4de&&this['removeMessageHandler'](_0x31a4de);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4b10cf){Z()['location']['href']=_0x4b10cf;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x57175c;return((_0x57175c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x57175c['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x44b1ca){this['request']=_0x44b1ca;}['toPromise'](){return new Promise((_0x200da7,_0x2e87dc)=>{this['request']['addEventListener']('success',()=>{_0x200da7(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2e87dc(this['request']['error']);});});}}function Zn(_0x5a212d,_0x4a175a){return _0x5a212d['transaction']([Mn],_0x4a175a?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x5e1ce5=indexedDB['deleteDatabase'](Ka);return new nn(_0x5e1ce5)['toPromise']();}function Qa(){const _0xfbe282=indexedDB['open'](Ka,pp);return new Promise((_0x1c169f,_0x4d4ca8)=>{_0xfbe282['addEventListener']('error',()=>{_0x4d4ca8(_0xfbe282['error']);}),_0xfbe282['addEventListener']('upgradeneeded',()=>{const _0x3d5061=_0xfbe282['result'];try{_0x3d5061['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x320a6b){_0x4d4ca8(_0x320a6b);}}),_0xfbe282['addEventListener']('success',async()=>{const _0x582b57=_0xfbe282['result'];_0x582b57['objectStoreNames']['contains'](Mn)?_0x1c169f(_0x582b57):(_0x582b57['close'](),await _p(),_0x1c169f(await Qa()));});});}async function Or(_0x4c0422,_0x3d4fe9,_0x431a2f){const _0x549b40=Zn(_0x4c0422,!0x0)['put']({[Ya]:_0x3d4fe9,'value':_0x431a2f});return new nn(_0x549b40)['toPromise']();}async function gp(_0x13d426,_0x88a7c4){const _0x5015a6=Zn(_0x13d426,!0x1)['get'](_0x88a7c4),_0x33dd6f=await new nn(_0x5015a6)['toPromise']();return _0x33dd6f===void 0x0?null:_0x33dd6f['value'];}function Dr(_0x1af40c,_0x3f5761){const _0x15fe70=Zn(_0x1af40c,!0x0)['delete'](_0x3f5761);return new nn(_0x15fe70)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x487f4a){let _0x22aa43=0x0;for(;;)try{const _0x5f12d8=await this['_openDb']();return await _0x487f4a(_0x5f12d8);}catch(_0x517d12){if(_0x22aa43++>yp)throw _0x517d12;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x7deb70,_0x143809)=>({'keyProcessed':(await this['_poll']())['includes'](_0x143809['key'])})),this['receiver']['_subscribe']('ping',async(_0x82b8b5,_0x3bd382)=>['keyChanged']);}async['initializeSender'](){var _0x5d795a,_0x196f53;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x3907a3=await this['sender']['_send']('ping',{},0x320);_0x3907a3&&(_0x5d795a=_0x3907a3[0x0])!=null&&_0x5d795a['fulfilled']&&(_0x196f53=_0x3907a3[0x0])!=null&&_0x196f53['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x44c16f){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x44c16f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xa6f7e5=>{await Or(_0xa6f7e5,Dn,'1'),await Dr(_0xa6f7e5,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x332017){this['pendingWrites']++;try{await _0x332017();}finally{this['pendingWrites']--;}}async['_set'](_0x544f62,_0x3a7023){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5bf2fa=>Or(_0x5bf2fa,_0x544f62,_0x3a7023)),this['localCache'][_0x544f62]=_0x3a7023,this['notifyServiceWorker'](_0x544f62)));}async['_get'](_0x202b4b){const _0x562989=await this['_withRetries'](_0x4cd2d2=>gp(_0x4cd2d2,_0x202b4b));return this['localCache'][_0x202b4b]=_0x562989,_0x562989;}async['_remove'](_0x4b37f9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1c7f1d=>Dr(_0x1c7f1d,_0x4b37f9)),delete this['localCache'][_0x4b37f9],this['notifyServiceWorker'](_0x4b37f9)));}async['_poll'](){const _0x305de3=await this['_withRetries'](_0x3cf0aa=>{const _0x376c49=Zn(_0x3cf0aa,!0x1)['getAll']();return new nn(_0x376c49)['toPromise']();});if(!_0x305de3)return[];if(this['pendingWrites']!==0x0)return[];const _0x2fb890=[],_0x131680=new Set();if(_0x305de3['length']!==0x0){for(const {fbase_key:_0xfb0975,value:_0x4fce1a}of _0x305de3)_0x131680['add'](_0xfb0975),JSON['stringify'](this['localCache'][_0xfb0975])!==JSON['stringify'](_0x4fce1a)&&(this['notifyListeners'](_0xfb0975,_0x4fce1a),_0x2fb890['push'](_0xfb0975));}for(const _0x57903c of Object['keys'](this['localCache']))this['localCache'][_0x57903c]&&!_0x131680['has'](_0x57903c)&&(this['notifyListeners'](_0x57903c,null),_0x2fb890['push'](_0x57903c));return _0x2fb890;}['notifyListeners'](_0x5e8e66,_0x2cb8d2){this['localCache'][_0x5e8e66]=_0x2cb8d2;const _0x16d59d=this['listeners'][_0x5e8e66];if(_0x16d59d){for(const _0x2dcbc4 of Array['from'](_0x16d59d))_0x2dcbc4(_0x2cb8d2);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x13e09f,_0x32e2aa){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x13e09f]||(this['listeners'][_0x13e09f]=new Set(),this['_get'](_0x13e09f)),this['listeners'][_0x13e09f]['add'](_0x32e2aa);}['_removeListener'](_0x5bfacd,_0x2ca5bf){this['listeners'][_0x5bfacd]&&(this['listeners'][_0x5bfacd]['delete'](_0x2ca5bf),this['listeners'][_0x5bfacd]['size']===0x0&&delete this['listeners'][_0x5bfacd]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x215127,_0x262d88){return _0x262d88?ie(_0x262d88):(m(_0x215127['_popupRedirectResolver'],_0x215127,'argument-error'),_0x215127['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2a68eb){super('custom','custom'),this['params']=_0x2a68eb;}['_getIdTokenResponse'](_0x3f7b14){return nt(_0x3f7b14,this['_buildIdpRequest']());}['_linkToIdToken'](_0x7a3fb8,_0x422410){return nt(_0x7a3fb8,this['_buildIdpRequest'](_0x422410));}['_getReauthenticationResolver'](_0x45f5ec){return nt(_0x45f5ec,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x268071){const _0x3c44e6={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x268071&&(_0x3c44e6['idToken']=_0x268071),_0x3c44e6;}}function Ip(_0x2645e1){return Va(_0x2645e1['auth'],new ks(_0x2645e1),_0x2645e1['bypassAuthState']);}function wp(_0x3228bb){const {auth:_0xb2f4a9,user:_0x57c97a}=_0x3228bb;return m(_0x57c97a,_0xb2f4a9,'internal-error'),tp(_0x57c97a,new ks(_0x3228bb),_0x3228bb['bypassAuthState']);}async function Cp(_0x46d550){const {auth:_0x458fb4,user:_0x1a89a0}=_0x46d550;return m(_0x1a89a0,_0x458fb4,'internal-error'),ep(_0x1a89a0,new ks(_0x46d550),_0x46d550['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x33bd06,_0x1644b3,_0x8cd5cc,_0x510aac,_0x55193b=!0x1){this['auth']=_0x33bd06,this['resolver']=_0x8cd5cc,this['user']=_0x510aac,this['bypassAuthState']=_0x55193b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1644b3)?_0x1644b3:[_0x1644b3];}['execute'](){return new Promise(async(_0x3137f6,_0x552f4d)=>{this['pendingPromise']={'resolve':_0x3137f6,'reject':_0x552f4d};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x17c435){this['reject'](_0x17c435);}});}async['onAuthEvent'](_0x1e424c){const {urlResponse:_0x40b9a1,sessionId:_0x154f04,postBody:_0xfdbe1a,tenantId:_0x47c2b0,error:_0x1a7303,type:_0x4d7a5e}=_0x1e424c;if(_0x1a7303){this['reject'](_0x1a7303);return;}const _0x539d84={'auth':this['auth'],'requestUri':_0x40b9a1,'sessionId':_0x154f04,'tenantId':_0x47c2b0||void 0x0,'postBody':_0xfdbe1a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4d7a5e)(_0x539d84));}catch(_0x12c1c0){this['reject'](_0x12c1c0);}}['onError'](_0x16acdb){this['reject'](_0x16acdb);}['getIdpTask'](_0x2634d3){switch(_0x2634d3){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x1a1164){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1a1164),this['unregisterAndCleanUp']();}['reject'](_0x231a16){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x231a16),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x328e80,_0x13ac22,_0x270872,_0x1687ce,_0x3f673d){super(_0x328e80,_0x13ac22,_0x1687ce,_0x3f673d),this['provider']=_0x270872,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x16d930=await this['execute']();return m(_0x16d930,this['auth'],'internal-error'),_0x16d930;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xe24a2=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xe24a2),this['authWindow']['associatedEvent']=_0xe24a2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x488da4=>{this['reject'](_0x488da4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x38bfe1=>{_0x38bfe1||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x22fe3f;return((_0x22fe3f=this['authWindow'])==null?void 0x0:_0x22fe3f['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x404c32=()=>{var _0x5b0bb2,_0xa629fb;if((_0xa629fb=(_0x5b0bb2=this['authWindow'])==null?void 0x0:_0x5b0bb2['window'])!=null&&_0xa629fb['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x404c32,Tp['get']());};_0x404c32();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x39ec9c,_0x15ab74,_0x2dfb24=!0x1){super(_0x39ec9c,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x15ab74,void 0x0,_0x2dfb24),this['eventId']=null;}async['execute'](){let _0x4a8dbb=hn['get'](this['auth']['_key']());if(!_0x4a8dbb){try{const _0x27379a=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4a8dbb=()=>Promise['resolve'](_0x27379a);}catch(_0x1526e8){_0x4a8dbb=()=>Promise['reject'](_0x1526e8);}hn['set'](this['auth']['_key'](),_0x4a8dbb);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4a8dbb();}async['onAuthEvent'](_0x411078){if(_0x411078['type']==='signInViaRedirect')return super['onAuthEvent'](_0x411078);if(_0x411078['type']==='unknown'){this['resolve'](null);return;}if(_0x411078['eventId']){const _0x5803fb=await this['auth']['_redirectUserForId'](_0x411078['eventId']);if(_0x5803fb)return this['user']=_0x5803fb,super['onAuthEvent'](_0x411078);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x10fbfc,_0x40bc50){const _0x5352c5=Pp(_0x40bc50),_0x5ea054=kp(_0x10fbfc);if(!await _0x5ea054['_isAvailable']())return!0x1;const _0x38483d=await _0x5ea054['_get'](_0x5352c5)==='true';return await _0x5ea054['_remove'](_0x5352c5),_0x38483d;}function Ap(_0x1b7cb0,_0x58ba4f){hn['set'](_0x1b7cb0['_key'](),_0x58ba4f);}function kp(_0x355cd5){return ie(_0x355cd5['_redirectPersistence']);}function Pp(_0xb4afc9){return ln(Sp,_0xb4afc9['config']['apiKey'],_0xb4afc9['name']);}async function Np(_0x32d268,_0x58e597,_0x378596=!0x1){if($(_0x32d268['app']))return Promise['reject'](re(_0x32d268));const _0x1ee5d7=Ke(_0x32d268),_0x7a80cb=Ep(_0x1ee5d7,_0x58e597),_0x39ee24=await new bp(_0x1ee5d7,_0x7a80cb,_0x378596)['execute']();return _0x39ee24&&!_0x378596&&(delete _0x39ee24['user']['_redirectEventId'],await _0x1ee5d7['_persistUserIfCurrent'](_0x39ee24['user']),await _0x1ee5d7['_setRedirectUser'](null,_0x58e597)),_0x39ee24;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3c4c78){this['auth']=_0x3c4c78,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x7e1704){this['consumers']['add'](_0x7e1704),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x7e1704)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x7e1704),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xe1e59b){this['consumers']['delete'](_0xe1e59b);}['onEvent'](_0x561e78){if(this['hasEventBeenHandled'](_0x561e78))return!0x1;let _0x2140b4=!0x1;return this['consumers']['forEach'](_0x5ae12e=>{this['isEventForConsumer'](_0x561e78,_0x5ae12e)&&(_0x2140b4=!0x0,this['sendToConsumer'](_0x561e78,_0x5ae12e),this['saveEventToCache'](_0x561e78));}),this['hasHandledPotentialRedirect']||!Mp(_0x561e78)||(this['hasHandledPotentialRedirect']=!0x0,_0x2140b4||(this['queuedRedirectEvent']=_0x561e78,_0x2140b4=!0x0)),_0x2140b4;}['sendToConsumer'](_0xecf66a,_0x5a1e7d){var _0x384038;if(_0xecf66a['error']&&!Za(_0xecf66a)){const _0x2ed596=((_0x384038=_0xecf66a['error']['code'])==null?void 0x0:_0x384038['split']('auth/')[0x1])||'internal-error';_0x5a1e7d['onError'](X(this['auth'],_0x2ed596));}else _0x5a1e7d['onAuthEvent'](_0xecf66a);}['isEventForConsumer'](_0xce0a71,_0x21209a){const _0x1cca98=_0x21209a['eventId']===null||!!_0xce0a71['eventId']&&_0xce0a71['eventId']===_0x21209a['eventId'];return _0x21209a['filter']['includes'](_0xce0a71['type'])&&_0x1cca98;}['hasEventBeenHandled'](_0x3962e6){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x3962e6));}['saveEventToCache'](_0x543ff6){this['cachedEventUids']['add'](Mr(_0x543ff6)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0xd3c115){return[_0xd3c115['type'],_0xd3c115['eventId'],_0xd3c115['sessionId'],_0xd3c115['tenantId']]['filter'](_0x36d4f5=>_0x36d4f5)['join']('-');}function Za({type:_0x34e8ac,error:_0x394076}){return _0x34e8ac==='unknown'&&(_0x394076==null?void 0x0:_0x394076['code'])==='auth/no-auth-event';}function Mp(_0x3d72ff){switch(_0x3d72ff['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3d72ff);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3bb4d3,_0x5d66df={}){return Pe(_0x3bb4d3,'GET','/v1/projects',_0x5d66df);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x2348fb){if(_0x2348fb['config']['emulator'])return;const {authorizedDomains:_0x2dec92}=await Lp(_0x2348fb);for(const _0x3e16a7 of _0x2dec92)try{if(Wp(_0x3e16a7))return;}catch{}Y(_0x2348fb,'unauthorized-domain');}function Wp(_0x383832){const _0x48508f=Mi(),{protocol:_0x1e0dd9,hostname:_0x4998ee}=new URL(_0x48508f);if(_0x383832['startsWith']('chrome-extension://')){const _0x25f195=new URL(_0x383832);return _0x25f195['hostname']===''&&_0x4998ee===''?_0x1e0dd9==='chrome-extension:'&&_0x383832['replace']('chrome-extension://','')===_0x48508f['replace']('chrome-extension://',''):_0x1e0dd9==='chrome-extension:'&&_0x25f195['hostname']===_0x4998ee;}if(!Fp['test'](_0x1e0dd9))return!0x1;if(xp['test'](_0x383832))return _0x4998ee===_0x383832;const _0x1608a0=_0x383832['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1608a0+'|'+_0x1608a0+')$','i')['test'](_0x4998ee);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x48cebd=Z()['___jsl'];if(_0x48cebd!=null&&_0x48cebd['H']){for(const _0x296105 of Object['keys'](_0x48cebd['H']))if(_0x48cebd['H'][_0x296105]['r']=_0x48cebd['H'][_0x296105]['r']||[],_0x48cebd['H'][_0x296105]['L']=_0x48cebd['H'][_0x296105]['L']||[],_0x48cebd['H'][_0x296105]['r']=[..._0x48cebd['H'][_0x296105]['L']],_0x48cebd['CP']){for(let _0x109d5b=0x0;_0x109d5b<_0x48cebd['CP']['length'];_0x109d5b++)_0x48cebd['CP'][_0x109d5b]=null;}}}function Vp(_0x2f6d34){return new Promise((_0x49aa8c,_0x18051c)=>{var _0x3755e0,_0x859271,_0x1f1efa;function _0x29e812(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x49aa8c(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x18051c(X(_0x2f6d34,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x859271=(_0x3755e0=Z()['gapi'])==null?void 0x0:_0x3755e0['iframes'])!=null&&_0x859271['Iframe'])_0x49aa8c(gapi['iframes']['getContext']());else{if((_0x1f1efa=Z()['gapi'])!=null&&_0x1f1efa['load'])_0x29e812();else{const _0x3cf115=Ff('iframefcb');return Z()[_0x3cf115]=()=>{gapi['load']?_0x29e812():_0x18051c(X(_0x2f6d34,'network-request-failed'));},xa(xf()+'?onload='+_0x3cf115)['catch'](_0x53037c=>_0x18051c(_0x53037c));}}})['catch'](_0x8297e2=>{throw un=null,_0x8297e2;});}let un=null;function Hp(_0x18c426){return un=un||Vp(_0x18c426),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x38db6e){const _0x228cb5=_0x38db6e['config'];m(_0x228cb5['authDomain'],_0x38db6e,'auth-domain-config-required');const _0x504030=_0x228cb5['emulator']?Cs(_0x228cb5,qp):'https://'+_0x38db6e['config']['authDomain']+'/'+Gp,_0x1ad9f0={'apiKey':_0x228cb5['apiKey'],'appName':_0x38db6e['name'],'v':dt},_0x4e35be=jp['get'](_0x38db6e['config']['apiHost']);_0x4e35be&&(_0x1ad9f0['eid']=_0x4e35be);const _0x3863f1=_0x38db6e['_getFrameworks']();return _0x3863f1['length']&&(_0x1ad9f0['fw']=_0x3863f1['join'](',')),_0x504030+'?'+ut(_0x1ad9f0)['slice'](0x1);}async function Yp(_0x3dec5e){const _0x4704b9=await Hp(_0x3dec5e),_0xfb8a97=Z()['gapi'];return m(_0xfb8a97,_0x3dec5e,'internal-error'),_0x4704b9['open']({'where':document['body'],'url':Kp(_0x3dec5e),'messageHandlersFilter':_0xfb8a97['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x251818=>new Promise(async(_0x237092,_0x4f7717)=>{await _0x251818['restyle']({'setHideOnLeave':!0x1});const _0x30efee=X(_0x3dec5e,'network-request-failed'),_0x412c87=Z()['setTimeout'](()=>{_0x4f7717(_0x30efee);},$p['get']());function _0x13e60f(){Z()['clearTimeout'](_0x412c87),_0x237092(_0x251818);}_0x251818['ping'](_0x13e60f)['then'](_0x13e60f,()=>{_0x4f7717(_0x30efee);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x19ead2){this['window']=_0x19ead2,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x1bafe1,_0x67c3f3,_0x47929f,_0x2cb653=Jp,_0x406be8=Xp){const _0x5992e5=Math['max']((window['screen']['availHeight']-_0x406be8)/0x2,0x0)['toString'](),_0x601372=Math['max']((window['screen']['availWidth']-_0x2cb653)/0x2,0x0)['toString']();let _0x10b047='';const _0x20ebf0={...Qp,'width':_0x2cb653['toString'](),'height':_0x406be8['toString'](),'top':_0x5992e5,'left':_0x601372},_0x1407ac=W()['toLowerCase']();_0x47929f&&(_0x10b047=ka(_0x1407ac)?Zp:_0x47929f),Ra(_0x1407ac)&&(_0x67c3f3=_0x67c3f3||e_,_0x20ebf0['scrollbars']='yes');const _0x89a149=Object['entries'](_0x20ebf0)['reduce']((_0x3b2f24,[_0x37acf9,_0x34faa2])=>''+_0x3b2f24+_0x37acf9+'='+_0x34faa2+',','');if(Rf(_0x1407ac)&&_0x10b047!=='_self')return n_(_0x67c3f3||'',_0x10b047),new xr(null);const _0x4bdb98=window['open'](_0x67c3f3||'',_0x10b047,_0x89a149);m(_0x4bdb98,_0x1bafe1,'popup-blocked');try{_0x4bdb98['focus']();}catch{}return new xr(_0x4bdb98);}function n_(_0x684fde,_0x3a7bee){const _0x4b22d3=document['createElement']('a');_0x4b22d3['href']=_0x684fde,_0x4b22d3['target']=_0x3a7bee;const _0x32a6bd=document['createEvent']('MouseEvent');_0x32a6bd['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4b22d3['dispatchEvent'](_0x32a6bd);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x210d36,_0x46803c,_0xc28125,_0x485b8f,_0x192046,_0x208e63){m(_0x210d36['config']['authDomain'],_0x210d36,'auth-domain-config-required'),m(_0x210d36['config']['apiKey'],_0x210d36,'invalid-api-key');const _0x4e75f7={'apiKey':_0x210d36['config']['apiKey'],'appName':_0x210d36['name'],'authType':_0xc28125,'redirectUrl':_0x485b8f,'v':dt,'eventId':_0x192046};if(_0x46803c instanceof Wa){_0x46803c['setDefaultLanguage'](_0x210d36['languageCode']),_0x4e75f7['providerId']=_0x46803c['providerId']||'',pn(_0x46803c['getCustomParameters']())||(_0x4e75f7['customParameters']=JSON['stringify'](_0x46803c['getCustomParameters']()));for(const [_0x9e6343,_0x2d0799]of Object['entries']({}))_0x4e75f7[_0x9e6343]=_0x2d0799;}if(_0x46803c instanceof tn){const _0x2b9e07=_0x46803c['getScopes']()['filter'](_0x132aa6=>_0x132aa6!=='');_0x2b9e07['length']>0x0&&(_0x4e75f7['scopes']=_0x2b9e07['join'](','));}_0x210d36['tenantId']&&(_0x4e75f7['tid']=_0x210d36['tenantId']);const _0x1ebd47=_0x4e75f7;for(const _0x5553e1 of Object['keys'](_0x1ebd47))_0x1ebd47[_0x5553e1]===void 0x0&&delete _0x1ebd47[_0x5553e1];const _0x34700a=await _0x210d36['_getAppCheckToken'](),_0x4f6d13=_0x34700a?'#'+r_+'='+encodeURIComponent(_0x34700a):'';return o_(_0x210d36)+'?'+ut(_0x1ebd47)['slice'](0x1)+_0x4f6d13;}function o_({config:_0x4e81ca}){return _0x4e81ca['emulator']?Cs(_0x4e81ca,s_):'https://'+_0x4e81ca['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x1fa5e3,_0x302154,_0x3f1f48,_0x2916d1){var _0x3e661a;ce((_0x3e661a=this['eventManagers'][_0x1fa5e3['_key']()])==null?void 0x0:_0x3e661a['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3d871b=await Fr(_0x1fa5e3,_0x302154,_0x3f1f48,Mi(),_0x2916d1);return t_(_0x1fa5e3,_0x3d871b,As());}async['_openRedirect'](_0x3f3fc5,_0x4d2a4f,_0x4f1957,_0x2bd79c){await this['_originValidation'](_0x3f3fc5);const _0x5d4576=await Fr(_0x3f3fc5,_0x4d2a4f,_0x4f1957,Mi(),_0x2bd79c);return hp(_0x5d4576),new Promise(()=>{});}['_initialize'](_0x3acb7c){const _0x2bb60f=_0x3acb7c['_key']();if(this['eventManagers'][_0x2bb60f]){const {manager:_0x557203,promise:_0x1bb53b}=this['eventManagers'][_0x2bb60f];return _0x557203?Promise['resolve'](_0x557203):(ce(_0x1bb53b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1bb53b);}const _0x20de16=this['initAndGetManager'](_0x3acb7c);return this['eventManagers'][_0x2bb60f]={'promise':_0x20de16},_0x20de16['catch'](()=>{delete this['eventManagers'][_0x2bb60f];}),_0x20de16;}async['initAndGetManager'](_0x43d585){const _0x2cf63d=await Yp(_0x43d585),_0x53d4ee=new Dp(_0x43d585);return _0x2cf63d['register']('authEvent',_0x20edd8=>(m(_0x20edd8==null?void 0x0:_0x20edd8['authEvent'],_0x43d585,'invalid-auth-event'),{'status':_0x53d4ee['onEvent'](_0x20edd8['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x43d585['_key']()]={'manager':_0x53d4ee},this['iframes'][_0x43d585['_key']()]=_0x2cf63d,_0x53d4ee;}['_isIframeWebStorageSupported'](_0x2e6f51,_0x39bbc3){this['iframes'][_0x2e6f51['_key']()]['send'](pi,{'type':pi},_0x1a878f=>{var _0x1d2980;const _0xfc5d0c=(_0x1d2980=_0x1a878f==null?void 0x0:_0x1a878f[0x0])==null?void 0x0:_0x1d2980[pi];_0xfc5d0c!==void 0x0&&_0x39bbc3(!!_0xfc5d0c),Y(_0x2e6f51,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x531fda){const _0x3d678c=_0x531fda['_key']();return this['originValidationPromises'][_0x3d678c]||(this['originValidationPromises'][_0x3d678c]=Up(_0x531fda)),this['originValidationPromises'][_0x3d678c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x373a2e){this['auth']=_0x373a2e,this['internalListeners']=new Map();}['getUid'](){var _0x4592c7;return this['assertAuthConfigured'](),((_0x4592c7=this['auth']['currentUser'])==null?void 0x0:_0x4592c7['uid'])||null;}async['getToken'](_0x588ae5){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x588ae5)}:null;}['addAuthTokenListener'](_0x4724a3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4724a3))return;const _0xce5c3d=this['auth']['onIdTokenChanged'](_0x4bf5da=>{_0x4724a3((_0x4bf5da==null?void 0x0:_0x4bf5da['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4724a3,_0xce5c3d),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x25c01d){this['assertAuthConfigured']();const _0x5dac7c=this['internalListeners']['get'](_0x25c01d);_0x5dac7c&&(this['internalListeners']['delete'](_0x25c01d),_0x5dac7c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x263f17){switch(_0x263f17){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4218b7){st(new Fe('auth',(_0xea31f6,{options:_0x4161f2})=>{const _0x13e8c7=_0xea31f6['getProvider']('app')['getImmediate'](),_0x278e26=_0xea31f6['getProvider']('heartbeat'),_0x2df85c=_0xea31f6['getProvider']('app-check-internal'),{apiKey:_0x35f346,authDomain:_0x1305c1}=_0x13e8c7['options'];m(_0x35f346&&!_0x35f346['includes'](':'),'invalid-api-key',{'appName':_0x13e8c7['name']});const _0x24dc46={'apiKey':_0x35f346,'authDomain':_0x1305c1,'clientPlatform':_0x4218b7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4218b7)},_0x4e949f=new Df(_0x13e8c7,_0x278e26,_0x2df85c,_0x24dc46);return Hf(_0x4e949f,_0x4161f2),_0x4e949f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x48b3fa,_0x58c835,_0x8a904d)=>{_0x48b3fa['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x2dbcad=>{const _0xcf30f0=Ke(_0x2dbcad['getProvider']('auth')['getImmediate']());return(_0x1382e3=>new l_(_0x1382e3))(_0xcf30f0);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4218b7)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x26c953=>async _0x2e00db=>{const _0x33825f=_0x2e00db&&await _0x2e00db['getIdTokenResult'](),_0x491d8d=_0x33825f&&(new Date()['getTime']()-Date['parse'](_0x33825f['issuedAtTime']))/0x3e8;if(_0x491d8d&&_0x491d8d>f_)return;const _0x26ad2e=_0x33825f==null?void 0x0:_0x33825f['token'];Br!==_0x26ad2e&&(Br=_0x26ad2e,await fetch(_0x26c953,{'method':_0x26ad2e?'POST':'DELETE','headers':_0x26ad2e?{'Authorization':'Bearer\x20'+_0x26ad2e}:{}}));};function B_(_0x46dc68=Zr()){const _0x5c04f8=Hi(_0x46dc68,'auth');if(_0x5c04f8['isInitialized']())return _0x5c04f8['getImmediate']();const _0x32679d=Vf(_0x46dc68,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x2258b3=jr('authTokenSyncURL');if(_0x2258b3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x94aeb8=new URL(_0x2258b3,location['origin']);if(location['origin']===_0x94aeb8['origin']){const _0x4bdbf8=p_(_0x94aeb8['toString']());sp(_0x32679d,_0x4bdbf8,()=>_0x4bdbf8(_0x32679d['currentUser'])),ip(_0x32679d,_0x49a941=>_0x4bdbf8(_0x49a941));}}const _0x15fd47=qr('auth');return _0x15fd47&&$f(_0x32679d,'http://'+_0x15fd47),_0x32679d;}function __(){var _0x292dec;return((_0x292dec=document['getElementsByTagName']('head'))==null?void 0x0:_0x292dec[0x0])??document;}Mf({'loadJS'(_0x273cb2){return new Promise((_0x16d102,_0x4f1550)=>{const _0x5cec80=document['createElement']('script');_0x5cec80['setAttribute']('src',_0x273cb2),_0x5cec80['onload']=_0x16d102,_0x5cec80['onerror']=_0x5cefe8=>{const _0x2c56ae=X('internal-error');_0x2c56ae['customData']=_0x5cefe8,_0x4f1550(_0x2c56ae);},_0x5cec80['type']='text/javascript',_0x5cec80['charset']='UTF-8',__()['appendChild'](_0x5cec80);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};