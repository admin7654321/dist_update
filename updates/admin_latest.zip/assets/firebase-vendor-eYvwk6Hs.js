const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xf9d4d,_0x4eff1){if(!_0xf9d4d)throw ht(_0x4eff1);},ht=function(_0x3ac8ba){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3ac8ba);},Hr=function(_0x3d319c){const _0x2c5696=[];let _0x3cb80a=0x0;for(let _0x248b69=0x0;_0x248b69<_0x3d319c['length'];_0x248b69++){let _0x5c1e95=_0x3d319c['charCodeAt'](_0x248b69);_0x5c1e95<0x80?_0x2c5696[_0x3cb80a++]=_0x5c1e95:_0x5c1e95<0x800?(_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0x6|0xc0,_0x2c5696[_0x3cb80a++]=_0x5c1e95&0x3f|0x80):(_0x5c1e95&0xfc00)===0xd800&&_0x248b69+0x1<_0x3d319c['length']&&(_0x3d319c['charCodeAt'](_0x248b69+0x1)&0xfc00)===0xdc00?(_0x5c1e95=0x10000+((_0x5c1e95&0x3ff)<<0xa)+(_0x3d319c['charCodeAt'](++_0x248b69)&0x3ff),_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0x12|0xf0,_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0xc&0x3f|0x80,_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0x6&0x3f|0x80,_0x2c5696[_0x3cb80a++]=_0x5c1e95&0x3f|0x80):(_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0xc|0xe0,_0x2c5696[_0x3cb80a++]=_0x5c1e95>>0x6&0x3f|0x80,_0x2c5696[_0x3cb80a++]=_0x5c1e95&0x3f|0x80);}return _0x2c5696;},nc=function(_0x49c2a4){const _0x49943f=[];let _0x20c6b1=0x0,_0x32c591=0x0;for(;_0x20c6b1<_0x49c2a4['length'];){const _0x1aa7fe=_0x49c2a4[_0x20c6b1++];if(_0x1aa7fe<0x80)_0x49943f[_0x32c591++]=String['fromCharCode'](_0x1aa7fe);else{if(_0x1aa7fe>0xbf&&_0x1aa7fe<0xe0){const _0x277611=_0x49c2a4[_0x20c6b1++];_0x49943f[_0x32c591++]=String['fromCharCode']((_0x1aa7fe&0x1f)<<0x6|_0x277611&0x3f);}else{if(_0x1aa7fe>0xef&&_0x1aa7fe<0x16d){const _0x48dd17=_0x49c2a4[_0x20c6b1++],_0x3005b6=_0x49c2a4[_0x20c6b1++],_0x5a2ce4=_0x49c2a4[_0x20c6b1++],_0x25c3c6=((_0x1aa7fe&0x7)<<0x12|(_0x48dd17&0x3f)<<0xc|(_0x3005b6&0x3f)<<0x6|_0x5a2ce4&0x3f)-0x10000;_0x49943f[_0x32c591++]=String['fromCharCode'](0xd800+(_0x25c3c6>>0xa)),_0x49943f[_0x32c591++]=String['fromCharCode'](0xdc00+(_0x25c3c6&0x3ff));}else{const _0x28f899=_0x49c2a4[_0x20c6b1++],_0x37fe02=_0x49c2a4[_0x20c6b1++];_0x49943f[_0x32c591++]=String['fromCharCode']((_0x1aa7fe&0xf)<<0xc|(_0x28f899&0x3f)<<0x6|_0x37fe02&0x3f);}}}}return _0x49943f['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x36308c,_0x1de1fb){if(!Array['isArray'](_0x36308c))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x18a1d9=_0x1de1fb?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x132e6e=[];for(let _0x4bf259=0x0;_0x4bf259<_0x36308c['length'];_0x4bf259+=0x3){const _0x11362b=_0x36308c[_0x4bf259],_0x251cea=_0x4bf259+0x1<_0x36308c['length'],_0x3dd1a7=_0x251cea?_0x36308c[_0x4bf259+0x1]:0x0,_0x3aeafc=_0x4bf259+0x2<_0x36308c['length'],_0x525cf6=_0x3aeafc?_0x36308c[_0x4bf259+0x2]:0x0,_0x1b793d=_0x11362b>>0x2,_0x222264=(_0x11362b&0x3)<<0x4|_0x3dd1a7>>0x4;let _0x5a2f12=(_0x3dd1a7&0xf)<<0x2|_0x525cf6>>0x6,_0xec26ca=_0x525cf6&0x3f;_0x3aeafc||(_0xec26ca=0x40,_0x251cea||(_0x5a2f12=0x40)),_0x132e6e['push'](_0x18a1d9[_0x1b793d],_0x18a1d9[_0x222264],_0x18a1d9[_0x5a2f12],_0x18a1d9[_0xec26ca]);}return _0x132e6e['join']('');},'encodeString'(_0x51849a,_0x3490ff){return this['HAS_NATIVE_SUPPORT']&&!_0x3490ff?btoa(_0x51849a):this['encodeByteArray'](Hr(_0x51849a),_0x3490ff);},'decodeString'(_0x1d2cf2,_0x41eaea){return this['HAS_NATIVE_SUPPORT']&&!_0x41eaea?atob(_0x1d2cf2):nc(this['decodeStringToByteArray'](_0x1d2cf2,_0x41eaea));},'decodeStringToByteArray'(_0x24467b,_0x39ec44){this['init_']();const _0x4bd299=_0x39ec44?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x67b276=[];for(let _0x30d8c4=0x0;_0x30d8c4<_0x24467b['length'];){const _0x5b29f8=_0x4bd299[_0x24467b['charAt'](_0x30d8c4++)],_0x17bb2a=_0x30d8c4<_0x24467b['length']?_0x4bd299[_0x24467b['charAt'](_0x30d8c4)]:0x0;++_0x30d8c4;const _0x1f0d2c=_0x30d8c4<_0x24467b['length']?_0x4bd299[_0x24467b['charAt'](_0x30d8c4)]:0x40;++_0x30d8c4;const _0x5b9f60=_0x30d8c4<_0x24467b['length']?_0x4bd299[_0x24467b['charAt'](_0x30d8c4)]:0x40;if(++_0x30d8c4,_0x5b29f8==null||_0x17bb2a==null||_0x1f0d2c==null||_0x5b9f60==null)throw new ic();const _0x17db63=_0x5b29f8<<0x2|_0x17bb2a>>0x4;if(_0x67b276['push'](_0x17db63),_0x1f0d2c!==0x40){const _0xe0d9db=_0x17bb2a<<0x4&0xf0|_0x1f0d2c>>0x2;if(_0x67b276['push'](_0xe0d9db),_0x5b9f60!==0x40){const _0x4c519d=_0x1f0d2c<<0x6&0xc0|_0x5b9f60;_0x67b276['push'](_0x4c519d);}}}return _0x67b276;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xbfdbdd=0x0;_0xbfdbdd<this['ENCODED_VALS']['length'];_0xbfdbdd++)this['byteToCharMap_'][_0xbfdbdd]=this['ENCODED_VALS']['charAt'](_0xbfdbdd),this['charToByteMap_'][this['byteToCharMap_'][_0xbfdbdd]]=_0xbfdbdd,this['byteToCharMapWebSafe_'][_0xbfdbdd]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xbfdbdd),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xbfdbdd]]=_0xbfdbdd,_0xbfdbdd>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xbfdbdd)]=_0xbfdbdd,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xbfdbdd)]=_0xbfdbdd);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x241bdb){const _0x475c6d=Hr(_0x241bdb);return Fi['encodeByteArray'](_0x475c6d,!0x0);},dn=function(_0x17599d){return $r(_0x17599d)['replace'](/\./g,'');},fn=function(_0x3ed9ea){try{return Fi['decodeString'](_0x3ed9ea,!0x0);}catch(_0x542581){console['error']('base64Decode\x20failed:\x20',_0x542581);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x42a9e4){return Gr(void 0x0,_0x42a9e4);}function Gr(_0x3fbde1,_0x4868f0){if(!(_0x4868f0 instanceof Object))return _0x4868f0;switch(_0x4868f0['constructor']){case Date:const _0x5e31ee=_0x4868f0;return new Date(_0x5e31ee['getTime']());case Object:_0x3fbde1===void 0x0&&(_0x3fbde1={});break;case Array:_0x3fbde1=[];break;default:return _0x4868f0;}for(const _0x29e79b in _0x4868f0)!_0x4868f0['hasOwnProperty'](_0x29e79b)||!rc(_0x29e79b)||(_0x3fbde1[_0x29e79b]=Gr(_0x3fbde1[_0x29e79b],_0x4868f0[_0x29e79b]));return _0x3fbde1;}function rc(_0x1922e2){return _0x1922e2!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x5a4889=Ps['__FIREBASE_DEFAULTS__'];if(_0x5a4889)return JSON['parse'](_0x5a4889);},lc=()=>{if(typeof document>'u')return;let _0x15ec49;try{_0x15ec49=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3d6169=_0x15ec49&&fn(_0x15ec49[0x1]);return _0x3d6169&&JSON['parse'](_0x3d6169);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x1d0398){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1d0398);return;}},qr=_0x21a0e6=>{var _0x3e4be8,_0x24f82b;return(_0x24f82b=(_0x3e4be8=Ui())==null?void 0x0:_0x3e4be8['emulatorHosts'])==null?void 0x0:_0x24f82b[_0x21a0e6];},hc=_0x29fc4a=>{const _0x587066=qr(_0x29fc4a);if(!_0x587066)return;const _0x2b1044=_0x587066['lastIndexOf'](':');if(_0x2b1044<=0x0||_0x2b1044+0x1===_0x587066['length'])throw new Error('Invalid\x20host\x20'+_0x587066+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4dc3b4=parseInt(_0x587066['substring'](_0x2b1044+0x1),0xa);return _0x587066[0x0]==='['?[_0x587066['substring'](0x1,_0x2b1044-0x1),_0x4dc3b4]:[_0x587066['substring'](0x0,_0x2b1044),_0x4dc3b4];},zr=()=>{var _0x19aacb;return(_0x19aacb=Ui())==null?void 0x0:_0x19aacb['config'];},jr=_0x5b09bf=>{var _0x4bf245;return(_0x4bf245=Ui())==null?void 0x0:_0x4bf245['_'+_0x5b09bf];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1cd34a,_0x4255ca)=>{this['resolve']=_0x1cd34a,this['reject']=_0x4255ca;});}['wrapCallback'](_0x5851ff){return(_0x1545e8,_0x5a1cb9)=>{_0x1545e8?this['reject'](_0x1545e8):this['resolve'](_0x5a1cb9),typeof _0x5851ff=='function'&&(this['promise']['catch'](()=>{}),_0x5851ff['length']===0x1?_0x5851ff(_0x1545e8):_0x5851ff(_0x1545e8,_0x5a1cb9));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x5531d0,_0x424c63){if(_0x5531d0['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x33b3cb={'alg':'none','type':'JWT'},_0x5969b5=_0x424c63||'demo-project',_0x4b2dc5=_0x5531d0['iat']||0x0,_0x50ed5a=_0x5531d0['sub']||_0x5531d0['user_id'];if(!_0x50ed5a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x20912f={'iss':'https://securetoken.google.com/'+_0x5969b5,'aud':_0x5969b5,'iat':_0x4b2dc5,'exp':_0x4b2dc5+0xe10,'auth_time':_0x4b2dc5,'sub':_0x50ed5a,'user_id':_0x50ed5a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5531d0};return[dn(JSON['stringify'](_0x33b3cb)),dn(JSON['stringify'](_0x20912f)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x39930c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x39930c=='object'&&_0x39930c['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2f586f=W();return _0x2f586f['indexOf']('MSIE\x20')>=0x0||_0x2f586f['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2ffacb,_0x13e1ea)=>{try{let _0x4ac45b=!0x0;const _0x3a089a='validate-browser-context-for-indexeddb-analytics-module',_0x371955=self['indexedDB']['open'](_0x3a089a);_0x371955['onsuccess']=()=>{_0x371955['result']['close'](),_0x4ac45b||self['indexedDB']['deleteDatabase'](_0x3a089a),_0x2ffacb(!0x0);},_0x371955['onupgradeneeded']=()=>{_0x4ac45b=!0x1;},_0x371955['onerror']=()=>{var _0x54bd09;_0x13e1ea(((_0x54bd09=_0x371955['error'])==null?void 0x0:_0x54bd09['message'])||'');};}catch(_0x2cd2d2){_0x13e1ea(_0x2cd2d2);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x51ed80,_0xfccbdd,_0x3e7342){super(_0xfccbdd),this['code']=_0x51ed80,this['customData']=_0x3e7342,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x59694e,_0x281185,_0x214546){this['service']=_0x59694e,this['serviceName']=_0x281185,this['errors']=_0x214546;}['create'](_0x4768d6,..._0x5d9dbb){const _0x3eebf9=_0x5d9dbb[0x0]||{},_0x4400ba=this['service']+'/'+_0x4768d6,_0x5ae284=this['errors'][_0x4768d6],_0x414009=_0x5ae284?vc(_0x5ae284,_0x3eebf9):'Error',_0x2c823b=this['serviceName']+':\x20'+_0x414009+'\x20('+_0x4400ba+').';return new Re(_0x4400ba,_0x2c823b,_0x3eebf9);}}function vc(_0x12d260,_0x120d97){return _0x12d260['replace'](Ec,(_0x1f3dca,_0x2e1264)=>{const _0x379690=_0x120d97[_0x2e1264];return _0x379690!=null?String(_0x379690):'<'+_0x2e1264+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x382140){return JSON['parse'](_0x382140);}function O(_0x56ce5e){return JSON['stringify'](_0x56ce5e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x4e6cdc){let _0x38d436={},_0x45df0c={},_0x436f97={},_0x223ba7='';try{const _0x405ece=_0x4e6cdc['split']('.');_0x38d436=Nt(fn(_0x405ece[0x0])||''),_0x45df0c=Nt(fn(_0x405ece[0x1])||''),_0x223ba7=_0x405ece[0x2],_0x436f97=_0x45df0c['d']||{},delete _0x45df0c['d'];}catch{}return{'header':_0x38d436,'claims':_0x45df0c,'data':_0x436f97,'signature':_0x223ba7};},Ic=function(_0x4bcecd){const _0x4656e8=Yr(_0x4bcecd),_0x155c75=_0x4656e8['claims'];return!!_0x155c75&&typeof _0x155c75=='object'&&_0x155c75['hasOwnProperty']('iat');},wc=function(_0x1fbd25){const _0x43705b=Yr(_0x1fbd25)['claims'];return typeof _0x43705b=='object'&&_0x43705b['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1a826f,_0x28c311){return Object['prototype']['hasOwnProperty']['call'](_0x1a826f,_0x28c311);}function Le(_0x401a8b,_0x2cb45f){if(Object['prototype']['hasOwnProperty']['call'](_0x401a8b,_0x2cb45f))return _0x401a8b[_0x2cb45f];}function pn(_0x208513){for(const _0x7f3c7 in _0x208513)if(Object['prototype']['hasOwnProperty']['call'](_0x208513,_0x7f3c7))return!0x1;return!0x0;}function _n(_0x32e6ab,_0x5a7f2c,_0x21a56c){const _0x4541b2={};for(const _0x374afa in _0x32e6ab)Object['prototype']['hasOwnProperty']['call'](_0x32e6ab,_0x374afa)&&(_0x4541b2[_0x374afa]=_0x5a7f2c['call'](_0x21a56c,_0x32e6ab[_0x374afa],_0x374afa,_0x32e6ab));return _0x4541b2;}function xe(_0x3c151c,_0x1b3459){if(_0x3c151c===_0x1b3459)return!0x0;const _0x5c7eac=Object['keys'](_0x3c151c),_0x45061c=Object['keys'](_0x1b3459);for(const _0x2831c8 of _0x5c7eac){if(!_0x45061c['includes'](_0x2831c8))return!0x1;const _0x1bd33b=_0x3c151c[_0x2831c8],_0x12b0bf=_0x1b3459[_0x2831c8];if(Ns(_0x1bd33b)&&Ns(_0x12b0bf)){if(!xe(_0x1bd33b,_0x12b0bf))return!0x1;}else{if(_0x1bd33b!==_0x12b0bf)return!0x1;}}for(const _0x2b4165 of _0x45061c)if(!_0x5c7eac['includes'](_0x2b4165))return!0x1;return!0x0;}function Ns(_0x50158c){return _0x50158c!==null&&typeof _0x50158c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x2e4b41){const _0x54dd08=[];for(const [_0x1a8f94,_0x657518]of Object['entries'](_0x2e4b41))Array['isArray'](_0x657518)?_0x657518['forEach'](_0x5d5956=>{_0x54dd08['push'](encodeURIComponent(_0x1a8f94)+'='+encodeURIComponent(_0x5d5956));}):_0x54dd08['push'](encodeURIComponent(_0x1a8f94)+'='+encodeURIComponent(_0x657518));return _0x54dd08['length']?'&'+_0x54dd08['join']('&'):'';}function Ct(_0x5c920f){const _0x125f53={};return _0x5c920f['replace'](/^\?/,'')['split']('&')['forEach'](_0x140315=>{if(_0x140315){const [_0x5faf17,_0x18aceb]=_0x140315['split']('=');_0x125f53[decodeURIComponent(_0x5faf17)]=decodeURIComponent(_0x18aceb);}}),_0x125f53;}function Tt(_0x20f36b){const _0x1e71ad=_0x20f36b['indexOf']('?');if(!_0x1e71ad)return'';const _0x1df696=_0x20f36b['indexOf']('#',_0x1e71ad);return _0x20f36b['substring'](_0x1e71ad,_0x1df696>0x0?_0x1df696:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5b97ae=0x1;_0x5b97ae<this['blockSize'];++_0x5b97ae)this['pad_'][_0x5b97ae]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2797ec,_0x366b54){_0x366b54||(_0x366b54=0x0);const _0x42ee3a=this['W_'];if(typeof _0x2797ec=='string'){for(let _0x1f39f0=0x0;_0x1f39f0<0x10;_0x1f39f0++)_0x42ee3a[_0x1f39f0]=_0x2797ec['charCodeAt'](_0x366b54)<<0x18|_0x2797ec['charCodeAt'](_0x366b54+0x1)<<0x10|_0x2797ec['charCodeAt'](_0x366b54+0x2)<<0x8|_0x2797ec['charCodeAt'](_0x366b54+0x3),_0x366b54+=0x4;}else{for(let _0x3cbc9b=0x0;_0x3cbc9b<0x10;_0x3cbc9b++)_0x42ee3a[_0x3cbc9b]=_0x2797ec[_0x366b54]<<0x18|_0x2797ec[_0x366b54+0x1]<<0x10|_0x2797ec[_0x366b54+0x2]<<0x8|_0x2797ec[_0x366b54+0x3],_0x366b54+=0x4;}for(let _0x39ecd1=0x10;_0x39ecd1<0x50;_0x39ecd1++){const _0x15197d=_0x42ee3a[_0x39ecd1-0x3]^_0x42ee3a[_0x39ecd1-0x8]^_0x42ee3a[_0x39ecd1-0xe]^_0x42ee3a[_0x39ecd1-0x10];_0x42ee3a[_0x39ecd1]=(_0x15197d<<0x1|_0x15197d>>>0x1f)&0xffffffff;}let _0x1a9589=this['chain_'][0x0],_0x2a893a=this['chain_'][0x1],_0x33a9a0=this['chain_'][0x2],_0x518c40=this['chain_'][0x3],_0x5522cd=this['chain_'][0x4],_0x8c70f3,_0x1a338e;for(let _0x10c755=0x0;_0x10c755<0x50;_0x10c755++){_0x10c755<0x28?_0x10c755<0x14?(_0x8c70f3=_0x518c40^_0x2a893a&(_0x33a9a0^_0x518c40),_0x1a338e=0x5a827999):(_0x8c70f3=_0x2a893a^_0x33a9a0^_0x518c40,_0x1a338e=0x6ed9eba1):_0x10c755<0x3c?(_0x8c70f3=_0x2a893a&_0x33a9a0|_0x518c40&(_0x2a893a|_0x33a9a0),_0x1a338e=0x8f1bbcdc):(_0x8c70f3=_0x2a893a^_0x33a9a0^_0x518c40,_0x1a338e=0xca62c1d6);const _0x5cd81a=(_0x1a9589<<0x5|_0x1a9589>>>0x1b)+_0x8c70f3+_0x5522cd+_0x1a338e+_0x42ee3a[_0x10c755]&0xffffffff;_0x5522cd=_0x518c40,_0x518c40=_0x33a9a0,_0x33a9a0=(_0x2a893a<<0x1e|_0x2a893a>>>0x2)&0xffffffff,_0x2a893a=_0x1a9589,_0x1a9589=_0x5cd81a;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1a9589&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2a893a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x33a9a0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x518c40&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5522cd&0xffffffff;}['update'](_0x1c78b8,_0x3c34e5){if(_0x1c78b8==null)return;_0x3c34e5===void 0x0&&(_0x3c34e5=_0x1c78b8['length']);const _0x443263=_0x3c34e5-this['blockSize'];let _0x2fd770=0x0;const _0x39c7ba=this['buf_'];let _0x28b646=this['inbuf_'];for(;_0x2fd770<_0x3c34e5;){if(_0x28b646===0x0){for(;_0x2fd770<=_0x443263;)this['compress_'](_0x1c78b8,_0x2fd770),_0x2fd770+=this['blockSize'];}if(typeof _0x1c78b8=='string'){for(;_0x2fd770<_0x3c34e5;)if(_0x39c7ba[_0x28b646]=_0x1c78b8['charCodeAt'](_0x2fd770),++_0x28b646,++_0x2fd770,_0x28b646===this['blockSize']){this['compress_'](_0x39c7ba),_0x28b646=0x0;break;}}else{for(;_0x2fd770<_0x3c34e5;)if(_0x39c7ba[_0x28b646]=_0x1c78b8[_0x2fd770],++_0x28b646,++_0x2fd770,_0x28b646===this['blockSize']){this['compress_'](_0x39c7ba),_0x28b646=0x0;break;}}}this['inbuf_']=_0x28b646,this['total_']+=_0x3c34e5;}['digest'](){const _0x282f9d=[];let _0x3a2c4b=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x7fc3e0=this['blockSize']-0x1;_0x7fc3e0>=0x38;_0x7fc3e0--)this['buf_'][_0x7fc3e0]=_0x3a2c4b&0xff,_0x3a2c4b/=0x100;this['compress_'](this['buf_']);let _0x27e9b9=0x0;for(let _0x4d9715=0x0;_0x4d9715<0x5;_0x4d9715++)for(let _0x1caf49=0x18;_0x1caf49>=0x0;_0x1caf49-=0x8)_0x282f9d[_0x27e9b9]=this['chain_'][_0x4d9715]>>_0x1caf49&0xff,++_0x27e9b9;return _0x282f9d;}}function Tc(_0x133ec0,_0x2b2f3f){const _0xed4566=new Sc(_0x133ec0,_0x2b2f3f);return _0xed4566['subscribe']['bind'](_0xed4566);}class Sc{constructor(_0x11acd2,_0x5ed956){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5ed956,this['task']['then'](()=>{_0x11acd2(this);})['catch'](_0x1c6ef2=>{this['error'](_0x1c6ef2);});}['next'](_0x394165){this['forEachObserver'](_0x6797ea=>{_0x6797ea['next'](_0x394165);});}['error'](_0x46ec37){this['forEachObserver'](_0x1217b3=>{_0x1217b3['error'](_0x46ec37);}),this['close'](_0x46ec37);}['complete'](){this['forEachObserver'](_0x2bc64b=>{_0x2bc64b['complete']();}),this['close']();}['subscribe'](_0x2f5ca6,_0x5b3cee,_0x4f3fa1){let _0x3e8169;if(_0x2f5ca6===void 0x0&&_0x5b3cee===void 0x0&&_0x4f3fa1===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2f5ca6,['next','error','complete'])?_0x3e8169=_0x2f5ca6:_0x3e8169={'next':_0x2f5ca6,'error':_0x5b3cee,'complete':_0x4f3fa1},_0x3e8169['next']===void 0x0&&(_0x3e8169['next']=ti),_0x3e8169['error']===void 0x0&&(_0x3e8169['error']=ti),_0x3e8169['complete']===void 0x0&&(_0x3e8169['complete']=ti);const _0x27342f=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3e8169['error'](this['finalError']):_0x3e8169['complete']();}catch{}}),this['observers']['push'](_0x3e8169),_0x27342f;}['unsubscribeOne'](_0x2e0683){this['observers']===void 0x0||this['observers'][_0x2e0683]===void 0x0||(delete this['observers'][_0x2e0683],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2c3d3b){if(!this['finalized']){for(let _0x36a511=0x0;_0x36a511<this['observers']['length'];_0x36a511++)this['sendOne'](_0x36a511,_0x2c3d3b);}}['sendOne'](_0x2568d1,_0x2a2b1a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2568d1]!==void 0x0)try{_0x2a2b1a(this['observers'][_0x2568d1]);}catch(_0x189707){typeof console<'u'&&console['error']&&console['error'](_0x189707);}});}['close'](_0x401ef1){this['finalized']||(this['finalized']=!0x0,_0x401ef1!==void 0x0&&(this['finalError']=_0x401ef1),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x590c6d,_0x39ee92){if(typeof _0x590c6d!='object'||_0x590c6d===null)return!0x1;for(const _0x542b37 of _0x39ee92)if(_0x542b37 in _0x590c6d&&typeof _0x590c6d[_0x542b37]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x48d83e,_0x5a2e2e){return _0x48d83e+'\x20failed:\x20'+_0x5a2e2e+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x45a7bc){const _0x3f6207=[];let _0x24c1a7=0x0;for(let _0x38cfbb=0x0;_0x38cfbb<_0x45a7bc['length'];_0x38cfbb++){let _0x3e5cf4=_0x45a7bc['charCodeAt'](_0x38cfbb);if(_0x3e5cf4>=0xd800&&_0x3e5cf4<=0xdbff){const _0x186cb4=_0x3e5cf4-0xd800;_0x38cfbb++,f(_0x38cfbb<_0x45a7bc['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x39857b=_0x45a7bc['charCodeAt'](_0x38cfbb)-0xdc00;_0x3e5cf4=0x10000+(_0x186cb4<<0xa)+_0x39857b;}_0x3e5cf4<0x80?_0x3f6207[_0x24c1a7++]=_0x3e5cf4:_0x3e5cf4<0x800?(_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0x6|0xc0,_0x3f6207[_0x24c1a7++]=_0x3e5cf4&0x3f|0x80):_0x3e5cf4<0x10000?(_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0xc|0xe0,_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0x6&0x3f|0x80,_0x3f6207[_0x24c1a7++]=_0x3e5cf4&0x3f|0x80):(_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0x12|0xf0,_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0xc&0x3f|0x80,_0x3f6207[_0x24c1a7++]=_0x3e5cf4>>0x6&0x3f|0x80,_0x3f6207[_0x24c1a7++]=_0x3e5cf4&0x3f|0x80);}return _0x3f6207;},Ln=function(_0x5e50bc){let _0xd7a129=0x0;for(let _0x264811=0x0;_0x264811<_0x5e50bc['length'];_0x264811++){const _0x46276e=_0x5e50bc['charCodeAt'](_0x264811);_0x46276e<0x80?_0xd7a129++:_0x46276e<0x800?_0xd7a129+=0x2:_0x46276e>=0xd800&&_0x46276e<=0xdbff?(_0xd7a129+=0x4,_0x264811++):_0xd7a129+=0x3;}return _0xd7a129;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x11f9f9){return _0x11f9f9&&_0x11f9f9['_delegate']?_0x11f9f9['_delegate']:_0x11f9f9;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x564d33){try{return(_0x564d33['startsWith']('http://')||_0x564d33['startsWith']('https://')?new URL(_0x564d33)['hostname']:_0x564d33)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0xe85d49){return(await fetch(_0xe85d49,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x1223e6,_0x326e8e,_0x1d2d75){this['name']=_0x1223e6,this['instanceFactory']=_0x326e8e,this['type']=_0x1d2d75,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3a8566){return this['instantiationMode']=_0x3a8566,this;}['setMultipleInstances'](_0x483ed0){return this['multipleInstances']=_0x483ed0,this;}['setServiceProps'](_0x3fe627){return this['serviceProps']=_0x3fe627,this;}['setInstanceCreatedCallback'](_0x5dc6a2){return this['onInstanceCreated']=_0x5dc6a2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x256264,_0x8c092c){this['name']=_0x256264,this['container']=_0x8c092c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xf2b280){const _0x48898f=this['normalizeInstanceIdentifier'](_0xf2b280);if(!this['instancesDeferred']['has'](_0x48898f)){const _0x49d9a5=new H();if(this['instancesDeferred']['set'](_0x48898f,_0x49d9a5),this['isInitialized'](_0x48898f)||this['shouldAutoInitialize']())try{const _0x4a9ec3=this['getOrInitializeService']({'instanceIdentifier':_0x48898f});_0x4a9ec3&&_0x49d9a5['resolve'](_0x4a9ec3);}catch{}}return this['instancesDeferred']['get'](_0x48898f)['promise'];}['getImmediate'](_0x52cf9a){const _0x513d44=this['normalizeInstanceIdentifier'](_0x52cf9a==null?void 0x0:_0x52cf9a['identifier']),_0xebb326=(_0x52cf9a==null?void 0x0:_0x52cf9a['optional'])??!0x1;if(this['isInitialized'](_0x513d44)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x513d44});}catch(_0x3f39c2){if(_0xebb326)return null;throw _0x3f39c2;}else{if(_0xebb326)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3ab517){if(_0x3ab517['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3ab517['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3ab517,!!this['shouldAutoInitialize']()){if(Pc(_0x3ab517))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x57b06b,_0x3f657c]of this['instancesDeferred']['entries']()){const _0x5259b6=this['normalizeInstanceIdentifier'](_0x57b06b);try{const _0x1afe91=this['getOrInitializeService']({'instanceIdentifier':_0x5259b6});_0x3f657c['resolve'](_0x1afe91);}catch{}}}}['clearInstance'](_0x1a1c6c=Ne){this['instancesDeferred']['delete'](_0x1a1c6c),this['instancesOptions']['delete'](_0x1a1c6c),this['instances']['delete'](_0x1a1c6c);}async['delete'](){const _0x149037=Array['from'](this['instances']['values']());await Promise['all']([..._0x149037['filter'](_0x17fd7e=>'INTERNAL'in _0x17fd7e)['map'](_0x1457ec=>_0x1457ec['INTERNAL']['delete']()),..._0x149037['filter'](_0x3a1234=>'_delete'in _0x3a1234)['map'](_0x4a1246=>_0x4a1246['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x195c2a=Ne){return this['instances']['has'](_0x195c2a);}['getOptions'](_0x531857=Ne){return this['instancesOptions']['get'](_0x531857)||{};}['initialize'](_0x29f3ba={}){const {options:_0x155013={}}=_0x29f3ba,_0x5235d3=this['normalizeInstanceIdentifier'](_0x29f3ba['instanceIdentifier']);if(this['isInitialized'](_0x5235d3))throw Error(this['name']+'('+_0x5235d3+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x124a31=this['getOrInitializeService']({'instanceIdentifier':_0x5235d3,'options':_0x155013});for(const [_0x22a2d,_0xb97f74]of this['instancesDeferred']['entries']()){const _0x2ef201=this['normalizeInstanceIdentifier'](_0x22a2d);_0x5235d3===_0x2ef201&&_0xb97f74['resolve'](_0x124a31);}return _0x124a31;}['onInit'](_0x15b201,_0x1068d8){const _0x396420=this['normalizeInstanceIdentifier'](_0x1068d8),_0x3a9707=this['onInitCallbacks']['get'](_0x396420)??new Set();_0x3a9707['add'](_0x15b201),this['onInitCallbacks']['set'](_0x396420,_0x3a9707);const _0x2ff938=this['instances']['get'](_0x396420);return _0x2ff938&&_0x15b201(_0x2ff938,_0x396420),()=>{_0x3a9707['delete'](_0x15b201);};}['invokeOnInitCallbacks'](_0x1799b7,_0x5af103){const _0x6eec81=this['onInitCallbacks']['get'](_0x5af103);if(_0x6eec81){for(const _0x493282 of _0x6eec81)try{_0x493282(_0x1799b7,_0x5af103);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x35d6d8,options:_0x46185c={}}){let _0x303305=this['instances']['get'](_0x35d6d8);if(!_0x303305&&this['component']&&(_0x303305=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x35d6d8),'options':_0x46185c}),this['instances']['set'](_0x35d6d8,_0x303305),this['instancesOptions']['set'](_0x35d6d8,_0x46185c),this['invokeOnInitCallbacks'](_0x303305,_0x35d6d8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x35d6d8,_0x303305);}catch{}return _0x303305||null;}['normalizeInstanceIdentifier'](_0x502e19=Ne){return this['component']?this['component']['multipleInstances']?_0x502e19:Ne:_0x502e19;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x52f75e){return _0x52f75e===Ne?void 0x0:_0x52f75e;}function Pc(_0x40ec95){return _0x40ec95['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x299a52){this['name']=_0x299a52,this['providers']=new Map();}['addComponent'](_0x49061e){const _0x554d31=this['getProvider'](_0x49061e['name']);if(_0x554d31['isComponentSet']())throw new Error('Component\x20'+_0x49061e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x554d31['setComponent'](_0x49061e);}['addOrOverwriteComponent'](_0x1b6711){this['getProvider'](_0x1b6711['name'])['isComponentSet']()&&this['providers']['delete'](_0x1b6711['name']),this['addComponent'](_0x1b6711);}['getProvider'](_0x5d262c){if(this['providers']['has'](_0x5d262c))return this['providers']['get'](_0x5d262c);const _0x1687c2=new Ac(_0x5d262c,this);return this['providers']['set'](_0x5d262c,_0x1687c2),_0x1687c2;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xc66846){_0xc66846[_0xc66846['DEBUG']=0x0]='DEBUG',_0xc66846[_0xc66846['VERBOSE']=0x1]='VERBOSE',_0xc66846[_0xc66846['INFO']=0x2]='INFO',_0xc66846[_0xc66846['WARN']=0x3]='WARN',_0xc66846[_0xc66846['ERROR']=0x4]='ERROR',_0xc66846[_0xc66846['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x1e8df3,_0x5787dd,..._0x55bcb6)=>{if(_0x5787dd<_0x1e8df3['logLevel'])return;const _0x16fb09=new Date()['toISOString'](),_0x54bc3b=Mc[_0x5787dd];if(_0x54bc3b)console[_0x54bc3b]('['+_0x16fb09+']\x20\x20'+_0x1e8df3['name']+':',..._0x55bcb6);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5787dd+')');};class Bi{constructor(_0x2f25b1){this['name']=_0x2f25b1,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x25ef05){if(!(_0x25ef05 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x25ef05+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x25ef05;}['setLogLevel'](_0x43ff55){this['_logLevel']=typeof _0x43ff55=='string'?Oc[_0x43ff55]:_0x43ff55;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x36e48f){if(typeof _0x36e48f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x36e48f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x325379){this['_userLogHandler']=_0x325379;}['debug'](..._0x579cca){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x579cca),this['_logHandler'](this,T['DEBUG'],..._0x579cca);}['log'](..._0x25d471){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x25d471),this['_logHandler'](this,T['VERBOSE'],..._0x25d471);}['info'](..._0x1ee1a0){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1ee1a0),this['_logHandler'](this,T['INFO'],..._0x1ee1a0);}['warn'](..._0x3860b7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3860b7),this['_logHandler'](this,T['WARN'],..._0x3860b7);}['error'](..._0x5a243b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5a243b),this['_logHandler'](this,T['ERROR'],..._0x5a243b);}}const xc=(_0x103043,_0x13f134)=>_0x13f134['some'](_0x10bb10=>_0x103043 instanceof _0x10bb10);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x27ef7d){const _0x5263d1=new Promise((_0x597155,_0x17054c)=>{const _0x204efa=()=>{_0x27ef7d['removeEventListener']('success',_0x5b29dc),_0x27ef7d['removeEventListener']('error',_0x42d4cf);},_0x5b29dc=()=>{_0x597155(ge(_0x27ef7d['result'])),_0x204efa();},_0x42d4cf=()=>{_0x17054c(_0x27ef7d['error']),_0x204efa();};_0x27ef7d['addEventListener']('success',_0x5b29dc),_0x27ef7d['addEventListener']('error',_0x42d4cf);});return _0x5263d1['then'](_0xcfd5a8=>{_0xcfd5a8 instanceof IDBCursor&&Jr['set'](_0xcfd5a8,_0x27ef7d);})['catch'](()=>{}),Vi['set'](_0x5263d1,_0x27ef7d),_0x5263d1;}function Bc(_0x13b3bc){if(_i['has'](_0x13b3bc))return;const _0x5ca0c6=new Promise((_0x41a814,_0x153c99)=>{const _0x9fdf24=()=>{_0x13b3bc['removeEventListener']('complete',_0xe90564),_0x13b3bc['removeEventListener']('error',_0x2a891d),_0x13b3bc['removeEventListener']('abort',_0x2a891d);},_0xe90564=()=>{_0x41a814(),_0x9fdf24();},_0x2a891d=()=>{_0x153c99(_0x13b3bc['error']||new DOMException('AbortError','AbortError')),_0x9fdf24();};_0x13b3bc['addEventListener']('complete',_0xe90564),_0x13b3bc['addEventListener']('error',_0x2a891d),_0x13b3bc['addEventListener']('abort',_0x2a891d);});_i['set'](_0x13b3bc,_0x5ca0c6);}let gi={'get'(_0x5b6f2c,_0x4cdcb2,_0x2436fe){if(_0x5b6f2c instanceof IDBTransaction){if(_0x4cdcb2==='done')return _i['get'](_0x5b6f2c);if(_0x4cdcb2==='objectStoreNames')return _0x5b6f2c['objectStoreNames']||Xr['get'](_0x5b6f2c);if(_0x4cdcb2==='store')return _0x2436fe['objectStoreNames'][0x1]?void 0x0:_0x2436fe['objectStore'](_0x2436fe['objectStoreNames'][0x0]);}return ge(_0x5b6f2c[_0x4cdcb2]);},'set'(_0x3b7274,_0x21b89d,_0x29a09b){return _0x3b7274[_0x21b89d]=_0x29a09b,!0x0;},'has'(_0x427d07,_0x2c36b1){return _0x427d07 instanceof IDBTransaction&&(_0x2c36b1==='done'||_0x2c36b1==='store')?!0x0:_0x2c36b1 in _0x427d07;}};function Vc(_0x5027c8){gi=_0x5027c8(gi);}function Hc(_0x6e75f2){return _0x6e75f2===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x57acda,..._0x4c7bc9){const _0x479996=_0x6e75f2['call'](ii(this),_0x57acda,..._0x4c7bc9);return Xr['set'](_0x479996,_0x57acda['sort']?_0x57acda['sort']():[_0x57acda]),ge(_0x479996);}:Uc()['includes'](_0x6e75f2)?function(..._0x493ac2){return _0x6e75f2['apply'](ii(this),_0x493ac2),ge(Jr['get'](this));}:function(..._0x547f95){return ge(_0x6e75f2['apply'](ii(this),_0x547f95));};}function $c(_0x58f0e7){return typeof _0x58f0e7=='function'?Hc(_0x58f0e7):(_0x58f0e7 instanceof IDBTransaction&&Bc(_0x58f0e7),xc(_0x58f0e7,Fc())?new Proxy(_0x58f0e7,gi):_0x58f0e7);}function ge(_0x5b47e4){if(_0x5b47e4 instanceof IDBRequest)return Wc(_0x5b47e4);if(ni['has'](_0x5b47e4))return ni['get'](_0x5b47e4);const _0x21e589=$c(_0x5b47e4);return _0x21e589!==_0x5b47e4&&(ni['set'](_0x5b47e4,_0x21e589),Vi['set'](_0x21e589,_0x5b47e4)),_0x21e589;}const ii=_0x7505d0=>Vi['get'](_0x7505d0);function Gc(_0x23780b,_0x3cb4b6,{blocked:_0x53c87a,upgrade:_0x5e8143,blocking:_0x33ac3e,terminated:_0x466249}={}){const _0x47ef97=indexedDB['open'](_0x23780b,_0x3cb4b6),_0x1e185e=ge(_0x47ef97);return _0x5e8143&&_0x47ef97['addEventListener']('upgradeneeded',_0xb45115=>{_0x5e8143(ge(_0x47ef97['result']),_0xb45115['oldVersion'],_0xb45115['newVersion'],ge(_0x47ef97['transaction']),_0xb45115);}),_0x53c87a&&_0x47ef97['addEventListener']('blocked',_0x14233e=>_0x53c87a(_0x14233e['oldVersion'],_0x14233e['newVersion'],_0x14233e)),_0x1e185e['then'](_0x3d185e=>{_0x466249&&_0x3d185e['addEventListener']('close',()=>_0x466249()),_0x33ac3e&&_0x3d185e['addEventListener']('versionchange',_0x3d37a5=>_0x33ac3e(_0x3d37a5['oldVersion'],_0x3d37a5['newVersion'],_0x3d37a5));})['catch'](()=>{}),_0x1e185e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x43a6a4,_0x2f54c5){if(!(_0x43a6a4 instanceof IDBDatabase&&!(_0x2f54c5 in _0x43a6a4)&&typeof _0x2f54c5=='string'))return;if(si['get'](_0x2f54c5))return si['get'](_0x2f54c5);const _0x56d63b=_0x2f54c5['replace'](/FromIndex$/,''),_0x3a4c42=_0x2f54c5!==_0x56d63b,_0x5a4efa=zc['includes'](_0x56d63b);if(!(_0x56d63b in(_0x3a4c42?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5a4efa||qc['includes'](_0x56d63b)))return;const _0x5db981=async function(_0x244c60,..._0xf54064){const _0x3f7209=this['transaction'](_0x244c60,_0x5a4efa?'readwrite':'readonly');let _0x58afc0=_0x3f7209['store'];return _0x3a4c42&&(_0x58afc0=_0x58afc0['index'](_0xf54064['shift']())),(await Promise['all']([_0x58afc0[_0x56d63b](..._0xf54064),_0x5a4efa&&_0x3f7209['done']]))[0x0];};return si['set'](_0x2f54c5,_0x5db981),_0x5db981;}Vc(_0x4cd8fa=>({..._0x4cd8fa,'get':(_0x303b43,_0xb3ec60,_0x1e89c6)=>Ms(_0x303b43,_0xb3ec60)||_0x4cd8fa['get'](_0x303b43,_0xb3ec60,_0x1e89c6),'has':(_0x10e6de,_0x145d14)=>!!Ms(_0x10e6de,_0x145d14)||_0x4cd8fa['has'](_0x10e6de,_0x145d14)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x174ea9){this['container']=_0x174ea9;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x165010=>{if(Kc(_0x165010)){const _0x71e541=_0x165010['getImmediate']();return _0x71e541['library']+'/'+_0x71e541['version'];}else return null;})['filter'](_0x31465d=>_0x31465d)['join']('\x20');}}function Kc(_0x82c252){const _0x1ce162=_0x82c252['getComponent']();return(_0x1ce162==null?void 0x0:_0x1ce162['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x4dc09d,_0x59484f){try{_0x4dc09d['container']['addComponent'](_0x59484f);}catch(_0x3f1618){oe['debug']('Component\x20'+_0x59484f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4dc09d['name'],_0x3f1618);}}function st(_0x777bf4){const _0x1a77eb=_0x777bf4['name'];if(Ei['has'](_0x1a77eb))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1a77eb+'.'),!0x1;Ei['set'](_0x1a77eb,_0x777bf4);for(const _0x3638df of Ue['values']())xs(_0x3638df,_0x777bf4);for(const _0x2dfe80 of vi['values']())xs(_0x2dfe80,_0x777bf4);return!0x0;}function Hi(_0x9b806,_0x5b0c79){const _0x3059cd=_0x9b806['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3059cd&&_0x3059cd['triggerHeartbeat'](),_0x9b806['container']['getProvider'](_0x5b0c79);}function $(_0x5b0ee9){return _0x5b0ee9==null?!0x1:_0x5b0ee9['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5cee99,_0x4cead2,_0x2a27a6){this['_isDeleted']=!0x1,this['_options']={..._0x5cee99},this['_config']={..._0x4cead2},this['_name']=_0x4cead2['name'],this['_automaticDataCollectionEnabled']=_0x4cead2['automaticDataCollectionEnabled'],this['_container']=_0x2a27a6,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x33f161){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x33f161;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x9832){this['_isDeleted']=_0x9832;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1290dd,_0x57c9f9={}){let _0x486aef=_0x1290dd;typeof _0x57c9f9!='object'&&(_0x57c9f9={'name':_0x57c9f9});const _0x33311d={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x57c9f9},_0x2d22cd=_0x33311d['name'];if(typeof _0x2d22cd!='string'||!_0x2d22cd)throw me['create']('bad-app-name',{'appName':String(_0x2d22cd)});if(_0x486aef||(_0x486aef=zr()),!_0x486aef)throw me['create']('no-options');const _0x1e649f=Ue['get'](_0x2d22cd);if(_0x1e649f){if(xe(_0x486aef,_0x1e649f['options'])&&xe(_0x33311d,_0x1e649f['config']))return _0x1e649f;throw me['create']('duplicate-app',{'appName':_0x2d22cd});}const _0x50395=new Nc(_0x2d22cd);for(const _0x39b4c8 of Ei['values']())_0x50395['addComponent'](_0x39b4c8);const _0x28930e=new Tl(_0x486aef,_0x33311d,_0x50395);return Ue['set'](_0x2d22cd,_0x28930e),_0x28930e;}function Zr(_0x4bba20=yi){const _0x5a4ab3=Ue['get'](_0x4bba20);if(!_0x5a4ab3&&_0x4bba20===yi&&zr())return Sl();if(!_0x5a4ab3)throw me['create']('no-app',{'appName':_0x4bba20});return _0x5a4ab3;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x20839d){let _0x427f58=!0x1;const _0x4e6430=_0x20839d['name'];Ue['has'](_0x4e6430)?(_0x427f58=!0x0,Ue['delete'](_0x4e6430)):vi['has'](_0x4e6430)&&_0x20839d['decRefCount']()<=0x0&&(vi['delete'](_0x4e6430),_0x427f58=!0x0),_0x427f58&&(await Promise['all'](_0x20839d['container']['getProviders']()['map'](_0x5110c9=>_0x5110c9['delete']())),_0x20839d['isDeleted']=!0x0);}function ye(_0x486d65,_0x889474,_0x393549){let _0x5303c6=wl[_0x486d65]??_0x486d65;_0x393549&&(_0x5303c6+='-'+_0x393549);const _0x1cbad9=_0x5303c6['match'](/\s|\//),_0x397e95=_0x889474['match'](/\s|\//);if(_0x1cbad9||_0x397e95){const _0x48cb47=['Unable\x20to\x20register\x20library\x20\x22'+_0x5303c6+'\x22\x20with\x20version\x20\x22'+_0x889474+'\x22:'];_0x1cbad9&&_0x48cb47['push']('library\x20name\x20\x22'+_0x5303c6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1cbad9&&_0x397e95&&_0x48cb47['push']('and'),_0x397e95&&_0x48cb47['push']('version\x20name\x20\x22'+_0x889474+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x48cb47['join']('\x20'));return;}st(new Fe(_0x5303c6+'-version',()=>({'library':_0x5303c6,'version':_0x889474}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x4fc414,_0x4d6e24)=>{switch(_0x4d6e24){case 0x0:try{_0x4fc414['createObjectStore'](Ot);}catch(_0x318a82){console['warn'](_0x318a82);}}}})['catch'](_0x5707c7=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5707c7['message']});})),ri;}async function Al(_0x1590e1){try{const _0x566c8b=(await eo())['transaction'](Ot),_0x4e3e7e=await _0x566c8b['objectStore'](Ot)['get'](to(_0x1590e1));return await _0x566c8b['done'],_0x4e3e7e;}catch(_0x32ccdd){if(_0x32ccdd instanceof Re)oe['warn'](_0x32ccdd['message']);else{const _0x4fa2d2=me['create']('idb-get',{'originalErrorMessage':_0x32ccdd==null?void 0x0:_0x32ccdd['message']});oe['warn'](_0x4fa2d2['message']);}}}async function Fs(_0x47fad8,_0x57939b){try{const _0x1c0151=(await eo())['transaction'](Ot,'readwrite');await _0x1c0151['objectStore'](Ot)['put'](_0x57939b,to(_0x47fad8)),await _0x1c0151['done'];}catch(_0x49d720){if(_0x49d720 instanceof Re)oe['warn'](_0x49d720['message']);else{const _0x48258b=me['create']('idb-set',{'originalErrorMessage':_0x49d720==null?void 0x0:_0x49d720['message']});oe['warn'](_0x48258b['message']);}}}function to(_0x36e084){return _0x36e084['name']+'!'+_0x36e084['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x5ed191){this['container']=_0x5ed191,this['_heartbeatsCache']=null;const _0x2e19cd=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2e19cd),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x44b54d=>(this['_heartbeatsCache']=_0x44b54d,_0x44b54d));}async['triggerHeartbeat'](){var _0x34cb7e,_0x2d96e9;try{const _0x501132=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x44e935=Us();if(((_0x34cb7e=this['_heartbeatsCache'])==null?void 0x0:_0x34cb7e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2d96e9=this['_heartbeatsCache'])==null?void 0x0:_0x2d96e9['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x44e935||this['_heartbeatsCache']['heartbeats']['some'](_0x47b7c2=>_0x47b7c2['date']===_0x44e935))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x44e935,'agent':_0x501132}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x18c1cf=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x18c1cf,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x41c402){oe['warn'](_0x41c402);}}async['getHeartbeatsHeader'](){var _0x126fa8;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x126fa8=this['_heartbeatsCache'])==null?void 0x0:_0x126fa8['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2059fd=Us(),{heartbeatsToSend:_0x43e38d,unsentEntries:_0x206128}=Ol(this['_heartbeatsCache']['heartbeats']),_0x57edd2=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x43e38d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2059fd,_0x206128['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x206128,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x57edd2;}catch(_0xa2a38e){return oe['warn'](_0xa2a38e),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x594505,_0x2fc48e=kl){const _0x5545f8=[];let _0x37c0df=_0x594505['slice']();for(const _0xb9804f of _0x594505){const _0x595147=_0x5545f8['find'](_0x5da996=>_0x5da996['agent']===_0xb9804f['agent']);if(_0x595147){if(_0x595147['dates']['push'](_0xb9804f['date']),Ws(_0x5545f8)>_0x2fc48e){_0x595147['dates']['pop']();break;}}else{if(_0x5545f8['push']({'agent':_0xb9804f['agent'],'dates':[_0xb9804f['date']]}),Ws(_0x5545f8)>_0x2fc48e){_0x5545f8['pop']();break;}}_0x37c0df=_0x37c0df['slice'](0x1);}return{'heartbeatsToSend':_0x5545f8,'unsentEntries':_0x37c0df};}class Dl{constructor(_0x2df61c){this['app']=_0x2df61c,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x519d5b=await Al(this['app']);return _0x519d5b!=null&&_0x519d5b['heartbeats']?_0x519d5b:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x441454){if(await this['_canUseIndexedDBPromise']){const _0x1866e3=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x441454['lastSentHeartbeatDate']??_0x1866e3['lastSentHeartbeatDate'],'heartbeats':_0x441454['heartbeats']});}else return;}async['add'](_0x596516){if(await this['_canUseIndexedDBPromise']){const _0x1a3fb5=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x596516['lastSentHeartbeatDate']??_0x1a3fb5['lastSentHeartbeatDate'],'heartbeats':[..._0x1a3fb5['heartbeats'],..._0x596516['heartbeats']]});}else return;}}function Ws(_0x2d1021){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2d1021}))['length'];}function Ml(_0x431f48){if(_0x431f48['length']===0x0)return-0x1;let _0x5993a2=0x0,_0x4eeb6e=_0x431f48[0x0]['date'];for(let _0x4bf662=0x1;_0x4bf662<_0x431f48['length'];_0x4bf662++)_0x431f48[_0x4bf662]['date']<_0x4eeb6e&&(_0x4eeb6e=_0x431f48[_0x4bf662]['date'],_0x5993a2=_0x4bf662);return _0x5993a2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x510834){st(new Fe('platform-logger',_0x5bc91e=>new jc(_0x5bc91e),'PRIVATE')),st(new Fe('heartbeat',_0x376d49=>new Nl(_0x376d49),'PRIVATE')),ye(mi,Ls,_0x510834),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x3f2cd5){no=_0x3f2cd5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x4c60ca){this['domStorage_']=_0x4c60ca,this['prefix_']='firebase:';}['set'](_0x761939,_0x2b7f32){_0x2b7f32==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x761939)):this['domStorage_']['setItem'](this['prefixedName_'](_0x761939),O(_0x2b7f32));}['get'](_0x56bbd6){const _0xec2a72=this['domStorage_']['getItem'](this['prefixedName_'](_0x56bbd6));return _0xec2a72==null?null:Nt(_0xec2a72);}['remove'](_0x10ff83){this['domStorage_']['removeItem'](this['prefixedName_'](_0x10ff83));}['prefixedName_'](_0x55a4cb){return this['prefix_']+_0x55a4cb;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x55919a,_0x1b1030){_0x1b1030==null?delete this['cache_'][_0x55919a]:this['cache_'][_0x55919a]=_0x1b1030;}['get'](_0x2d9802){return Q(this['cache_'],_0x2d9802)?this['cache_'][_0x2d9802]:null;}['remove'](_0x50b3c6){delete this['cache_'][_0x50b3c6];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4f620f){try{if(typeof window<'u'&&typeof window[_0x4f620f]<'u'){const _0x8b59ad=window[_0x4f620f];return _0x8b59ad['setItem']('firebase:sentinel','cache'),_0x8b59ad['removeItem']('firebase:sentinel'),new Wl(_0x8b59ad);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0xe63c2=0x1;return function(){return _0xe63c2++;};}()),ro=function(_0x4a9a63){const _0x793fa1=Rc(_0x4a9a63),_0x19a089=new Cc();_0x19a089['update'](_0x793fa1);const _0x4f7a28=_0x19a089['digest']();return Fi['encodeByteArray'](_0x4f7a28);},zt=function(..._0x14e618){let _0x1aed2c='';for(let _0x2a7a6e=0x0;_0x2a7a6e<_0x14e618['length'];_0x2a7a6e++){const _0x345c03=_0x14e618[_0x2a7a6e];Array['isArray'](_0x345c03)||_0x345c03&&typeof _0x345c03=='object'&&typeof _0x345c03['length']=='number'?_0x1aed2c+=zt['apply'](null,_0x345c03):typeof _0x345c03=='object'?_0x1aed2c+=O(_0x345c03):_0x1aed2c+=_0x345c03,_0x1aed2c+='\x20';}return _0x1aed2c;};let St=null,$s=!0x0;const Hl=function(_0x338f5c,_0x1d3c75){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x530ce2){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x14eb05=zt['apply'](null,_0x530ce2);St(_0x14eb05);}},jt=function(_0x576ad0){return function(..._0x1b111a){L(_0x576ad0,..._0x1b111a);};},Ii=function(..._0x5dbee9){const _0x5f46ee='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x5dbee9);Ze['error'](_0x5f46ee);},ae=function(..._0x33a043){const _0x3ea09a='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x33a043);throw Ze['error'](_0x3ea09a),new Error(_0x3ea09a);},U=function(..._0x29b889){const _0x4d3f1b='FIREBASE\x20WARNING:\x20'+zt(..._0x29b889);Ze['warn'](_0x4d3f1b);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0xfe9dc8){return typeof _0xfe9dc8=='number'&&(_0xfe9dc8!==_0xfe9dc8||_0xfe9dc8===Number['POSITIVE_INFINITY']||_0xfe9dc8===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3c065b){if(document['readyState']==='complete')_0x3c065b();else{let _0x95511e=!0x1;const _0x1c0e22=function(){if(!document['body']){setTimeout(_0x1c0e22,Math['floor'](0xa));return;}_0x95511e||(_0x95511e=!0x0,_0x3c065b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1c0e22,!0x1),window['addEventListener']('load',_0x1c0e22,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1c0e22();}),window['attachEvent']('onload',_0x1c0e22));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5dc1d1,_0x598a09){if(_0x5dc1d1===_0x598a09)return 0x0;if(_0x5dc1d1===We||_0x598a09===we)return-0x1;if(_0x598a09===We||_0x5dc1d1===we)return 0x1;{const _0x53a684=Gs(_0x5dc1d1),_0x590a28=Gs(_0x598a09);return _0x53a684!==null?_0x590a28!==null?_0x53a684-_0x590a28===0x0?_0x5dc1d1['length']-_0x598a09['length']:_0x53a684-_0x590a28:-0x1:_0x590a28!==null?0x1:_0x5dc1d1<_0x598a09?-0x1:0x1;}},ql=function(_0x4262af,_0x445dcf){return _0x4262af===_0x445dcf?0x0:_0x4262af<_0x445dcf?-0x1:0x1;},vt=function(_0x193562,_0x2ed32e){if(_0x2ed32e&&_0x193562 in _0x2ed32e)return _0x2ed32e[_0x193562];throw new Error('Missing\x20required\x20key\x20('+_0x193562+')\x20in\x20object:\x20'+O(_0x2ed32e));},$i=function(_0xcdb461){if(typeof _0xcdb461!='object'||_0xcdb461===null)return O(_0xcdb461);const _0x225809=[];for(const _0x2d174c in _0xcdb461)_0x225809['push'](_0x2d174c);_0x225809['sort']();let _0x5d4293='{';for(let _0x2a582f=0x0;_0x2a582f<_0x225809['length'];_0x2a582f++)_0x2a582f!==0x0&&(_0x5d4293+=','),_0x5d4293+=O(_0x225809[_0x2a582f]),_0x5d4293+=':',_0x5d4293+=$i(_0xcdb461[_0x225809[_0x2a582f]]);return _0x5d4293+='}',_0x5d4293;},oo=function(_0x33a60f,_0x19ad99){const _0x186c2b=_0x33a60f['length'];if(_0x186c2b<=_0x19ad99)return[_0x33a60f];const _0x1bfde7=[];for(let _0x3cd6be=0x0;_0x3cd6be<_0x186c2b;_0x3cd6be+=_0x19ad99)_0x3cd6be+_0x19ad99>_0x186c2b?_0x1bfde7['push'](_0x33a60f['substring'](_0x3cd6be,_0x186c2b)):_0x1bfde7['push'](_0x33a60f['substring'](_0x3cd6be,_0x3cd6be+_0x19ad99));return _0x1bfde7;};function x(_0x52e4ba,_0x3189fe){for(const _0x346537 in _0x52e4ba)_0x52e4ba['hasOwnProperty'](_0x346537)&&_0x3189fe(_0x346537,_0x52e4ba[_0x346537]);}const ao=function(_0x2184a0){f(!xn(_0x2184a0),'Invalid\x20JSON\x20number');const _0x57615d=0xb,_0x37da48=0x34,_0x2bbb53=(0x1<<_0x57615d-0x1)-0x1;let _0x1935c0,_0x3ab978,_0x5c2c60,_0x1ff045,_0x12502d;_0x2184a0===0x0?(_0x3ab978=0x0,_0x5c2c60=0x0,_0x1935c0=0x1/_0x2184a0===-0x1/0x0?0x1:0x0):(_0x1935c0=_0x2184a0<0x0,_0x2184a0=Math['abs'](_0x2184a0),_0x2184a0>=Math['pow'](0x2,0x1-_0x2bbb53)?(_0x1ff045=Math['min'](Math['floor'](Math['log'](_0x2184a0)/Math['LN2']),_0x2bbb53),_0x3ab978=_0x1ff045+_0x2bbb53,_0x5c2c60=Math['round'](_0x2184a0*Math['pow'](0x2,_0x37da48-_0x1ff045)-Math['pow'](0x2,_0x37da48))):(_0x3ab978=0x0,_0x5c2c60=Math['round'](_0x2184a0/Math['pow'](0x2,0x1-_0x2bbb53-_0x37da48))));const _0x3b6e36=[];for(_0x12502d=_0x37da48;_0x12502d;_0x12502d-=0x1)_0x3b6e36['push'](_0x5c2c60%0x2?0x1:0x0),_0x5c2c60=Math['floor'](_0x5c2c60/0x2);for(_0x12502d=_0x57615d;_0x12502d;_0x12502d-=0x1)_0x3b6e36['push'](_0x3ab978%0x2?0x1:0x0),_0x3ab978=Math['floor'](_0x3ab978/0x2);_0x3b6e36['push'](_0x1935c0?0x1:0x0),_0x3b6e36['reverse']();const _0x362cde=_0x3b6e36['join']('');let _0x509939='';for(_0x12502d=0x0;_0x12502d<0x40;_0x12502d+=0x8){let _0x2d1c03=parseInt(_0x362cde['substr'](_0x12502d,0x8),0x2)['toString'](0x10);_0x2d1c03['length']===0x1&&(_0x2d1c03='0'+_0x2d1c03),_0x509939=_0x509939+_0x2d1c03;}return _0x509939['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x284596,_0x53c3e0){let _0x306a32='Unknown\x20Error';_0x284596==='too_big'?_0x306a32='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x284596==='permission_denied'?_0x306a32='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x284596==='unavailable'&&(_0x306a32='The\x20service\x20is\x20unavailable');const _0x51010c=new Error(_0x284596+'\x20at\x20'+_0x53c3e0['_path']['toString']()+':\x20'+_0x306a32);return _0x51010c['code']=_0x284596['toUpperCase'](),_0x51010c;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x2bf1d4){if(Yl['test'](_0x2bf1d4)){const _0x52eefb=Number(_0x2bf1d4);if(_0x52eefb>=Ql&&_0x52eefb<=Jl)return _0x52eefb;}return null;},ft=function(_0x5b066a){try{_0x5b066a();}catch(_0x2122b8){setTimeout(()=>{const _0x43f323=_0x2122b8['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x43f323),_0x2122b8;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x584a36,_0xc7c01b){const _0x58751a=setTimeout(_0x584a36,_0xc7c01b);return typeof _0x58751a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x58751a):typeof _0x58751a=='object'&&_0x58751a['unref']&&_0x58751a['unref'](),_0x58751a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x39e81a,_0x6908f8){this['appCheckProvider']=_0x6908f8,this['appName']=_0x39e81a['name'],$(_0x39e81a)&&_0x39e81a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x39e81a['settings']['appCheckToken']),this['appCheck']=_0x6908f8==null?void 0x0:_0x6908f8['getImmediate']({'optional':!0x0}),this['appCheck']||_0x6908f8==null||_0x6908f8['get']()['then'](_0x157da2=>this['appCheck']=_0x157da2);}['getToken'](_0xf5dab2){if(this['serverAppAppCheckToken']){if(_0xf5dab2)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xf5dab2):new Promise((_0x5b6ded,_0x55578c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xf5dab2)['then'](_0x5b6ded,_0x55578c):_0x5b6ded(null);},0x0);});}['addTokenChangeListener'](_0x2c0306){var _0x407cf4;(_0x407cf4=this['appCheckProvider'])==null||_0x407cf4['get']()['then'](_0x45f002=>_0x45f002['addTokenListener'](_0x2c0306));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x40d69f,_0x40e61b,_0x3f4205){this['appName_']=_0x40d69f,this['firebaseOptions_']=_0x40e61b,this['authProvider_']=_0x3f4205,this['auth_']=null,this['auth_']=_0x3f4205['getImmediate']({'optional':!0x0}),this['auth_']||_0x3f4205['onInit'](_0x4ed06b=>this['auth_']=_0x4ed06b);}['getToken'](_0x58791c){return this['auth_']?this['auth_']['getToken'](_0x58791c)['catch'](_0x320923=>_0x320923&&_0x320923['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x320923)):new Promise((_0x480277,_0x187d9c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x58791c)['then'](_0x480277,_0x187d9c):_0x480277(null);},0x0);});}['addTokenChangeListener'](_0x2a4987){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2a4987):this['authProvider_']['get']()['then'](_0x1141b1=>_0x1141b1['addAuthTokenListener'](_0x2a4987));}['removeTokenChangeListener'](_0x5af3fd){this['authProvider_']['get']()['then'](_0x10814c=>_0x10814c['removeAuthTokenListener'](_0x5af3fd));}['notifyForInvalidToken'](){let _0x22bdf5='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x22bdf5+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x22bdf5+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x22bdf5+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x22bdf5);}}class an{constructor(_0x402175){this['accessToken']=_0x402175;}['getToken'](_0x5c8b54){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2ae0d6){_0x2ae0d6(this['accessToken']);}['removeTokenChangeListener'](_0x5daa3b){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x497f46,_0x1c58e1,_0x208f38,_0x418596,_0xbeeef3=!0x1,_0x3fd48a='',_0x11a036=!0x1,_0x2508eb=!0x1,_0x12bf43=null){this['secure']=_0x1c58e1,this['namespace']=_0x208f38,this['webSocketOnly']=_0x418596,this['nodeAdmin']=_0xbeeef3,this['persistenceKey']=_0x3fd48a,this['includeNamespaceInQueryParams']=_0x11a036,this['isUsingEmulator']=_0x2508eb,this['emulatorOptions']=_0x12bf43,this['_host']=_0x497f46['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x497f46)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1adbe9){_0x1adbe9!==this['internalHost']&&(this['internalHost']=_0x1adbe9,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5805fe=this['toURLString']();return this['persistenceKey']&&(_0x5805fe+='<'+this['persistenceKey']+'>'),_0x5805fe;}['toURLString'](){const _0x34576a=this['secure']?'https://':'http://',_0x11e3e6=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x34576a+this['host']+'/'+_0x11e3e6;}}function th(_0xa8ef54){return _0xa8ef54['host']!==_0xa8ef54['internalHost']||_0xa8ef54['isCustomHost']()||_0xa8ef54['includeNamespaceInQueryParams'];}function vo(_0x212bf5,_0x3e086e,_0xf4649d){f(typeof _0x3e086e=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xf4649d=='object','typeof\x20params\x20must\x20==\x20object');let _0x486a9d;if(_0x3e086e===go)_0x486a9d=(_0x212bf5['secure']?'wss://':'ws://')+_0x212bf5['internalHost']+'/.ws?';else{if(_0x3e086e===mo)_0x486a9d=(_0x212bf5['secure']?'https://':'http://')+_0x212bf5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3e086e);}th(_0x212bf5)&&(_0xf4649d['ns']=_0x212bf5['namespace']);const _0x4c3612=[];return x(_0xf4649d,(_0x265fd4,_0x4c4b45)=>{_0x4c3612['push'](_0x265fd4+'='+_0x4c4b45);}),_0x486a9d+_0x4c3612['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x552d69,_0x173e46=0x1){Q(this['counters_'],_0x552d69)||(this['counters_'][_0x552d69]=0x0),this['counters_'][_0x552d69]+=_0x173e46;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x566394){const _0x46c93f=_0x566394['toString']();return oi[_0x46c93f]||(oi[_0x46c93f]=new nh()),oi[_0x46c93f];}function ih(_0xe96626,_0x249eed){const _0x4a9b7e=_0xe96626['toString']();return ai[_0x4a9b7e]||(ai[_0x4a9b7e]=_0x249eed()),ai[_0x4a9b7e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x38f19a){this['onMessage_']=_0x38f19a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x570633,_0x1db85a){this['closeAfterResponse']=_0x570633,this['onClose']=_0x1db85a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x47ad23,_0x2f0582){for(this['pendingResponses'][_0x47ad23]=_0x2f0582;this['pendingResponses'][this['currentResponseNum']];){const _0x5b02fe=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x47b60d=0x0;_0x47b60d<_0x5b02fe['length'];++_0x47b60d)_0x5b02fe[_0x47b60d]&&ft(()=>{this['onMessage_'](_0x5b02fe[_0x47b60d]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3c9b66,_0x4de87f,_0x47c5b6,_0x3edd24,_0x194051,_0x34a717,_0x5e0b6d){this['connId']=_0x3c9b66,this['repoInfo']=_0x4de87f,this['applicationId']=_0x47c5b6,this['appCheckToken']=_0x3edd24,this['authToken']=_0x194051,this['transportSessionId']=_0x34a717,this['lastSessionId']=_0x5e0b6d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x3c9b66),this['stats_']=qi(_0x4de87f),this['urlFn']=_0x5bfe46=>(this['appCheckToken']&&(_0x5bfe46[wi]=this['appCheckToken']),vo(_0x4de87f,mo,_0x5bfe46));}['open'](_0x5ba1d3,_0xf8fd1d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xf8fd1d,this['myPacketOrderer']=new sh(_0x5ba1d3),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4c4f3c)=>{const [_0x2c9b25,_0x351766,_0x461133,_0x421029,_0x30c6a7]=_0x4c4f3c;if(this['incrementIncomingBytes_'](_0x4c4f3c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2c9b25===qs)this['id']=_0x351766,this['password']=_0x461133;else{if(_0x2c9b25===rh)_0x351766?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x351766,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2c9b25);}}},(..._0x576c4d)=>{const [_0x575d59,_0x5ceec7]=_0x576c4d;this['incrementIncomingBytes_'](_0x576c4d),this['myPacketOrderer']['handleResponse'](_0x575d59,_0x5ceec7);},()=>{this['onClosed_']();},this['urlFn']);const _0x52bc8c={};_0x52bc8c[qs]='t',_0x52bc8c[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x52bc8c[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x52bc8c[co]=Gi,this['transportSessionId']&&(_0x52bc8c[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x52bc8c[po]=this['lastSessionId']),this['applicationId']&&(_0x52bc8c[_o]=this['applicationId']),this['appCheckToken']&&(_0x52bc8c[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x52bc8c[ho]=uo);const _0x318726=this['urlFn'](_0x52bc8c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x318726),this['scriptTagHolder']['addTag'](_0x318726,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x261100){const _0x5a56af=O(_0x261100);this['bytesSent']+=_0x5a56af['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5a56af['length']);const _0xed85cf=$r(_0x5a56af),_0x12870a=oo(_0xed85cf,fh);for(let _0x3223d0=0x0;_0x3223d0<_0x12870a['length'];_0x3223d0++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x12870a['length'],_0x12870a[_0x3223d0]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x47e630,_0x5cc506){this['myDisconnFrame']=document['createElement']('iframe');const _0x485fbf={};_0x485fbf[dh]='t',_0x485fbf[Eo]=_0x47e630,_0x485fbf[Io]=_0x5cc506,this['myDisconnFrame']['src']=this['urlFn'](_0x485fbf),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x38b570){const _0x200698=O(_0x38b570)['length'];this['bytesReceived']+=_0x200698,this['stats_']['incrementCounter']('bytes_received',_0x200698);}}class zi{constructor(_0xda0160,_0x45f85a,_0x27b709,_0x2530ce){this['onDisconnect']=_0x27b709,this['urlFn']=_0x2530ce,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xda0160,window[ah+this['uniqueCallbackIdentifier']]=_0x45f85a,this['myIFrame']=zi['createIFrame_']();let _0x479de8='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x479de8='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xd73382='<html><body>'+_0x479de8+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xd73382),this['myIFrame']['doc']['close']();}catch(_0x3eb1c6){L('frame\x20writing\x20exception'),_0x3eb1c6['stack']&&L(_0x3eb1c6['stack']),L(_0x3eb1c6);}}}static['createIFrame_'](){const _0x5f0a27=document['createElement']('iframe');if(_0x5f0a27['style']['display']='none',document['body']){document['body']['appendChild'](_0x5f0a27);try{_0x5f0a27['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x511325=document['domain'];_0x5f0a27['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x511325+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x5f0a27['contentDocument']?_0x5f0a27['doc']=_0x5f0a27['contentDocument']:_0x5f0a27['contentWindow']?_0x5f0a27['doc']=_0x5f0a27['contentWindow']['document']:_0x5f0a27['document']&&(_0x5f0a27['doc']=_0x5f0a27['document']),_0x5f0a27;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x31b1ce=this['onDisconnect'];_0x31b1ce&&(this['onDisconnect']=null,_0x31b1ce());}['startLongPoll'](_0x4fdea9,_0x377f55){for(this['myID']=_0x4fdea9,this['myPW']=_0x377f55,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1443d2={};_0x1443d2[Eo]=this['myID'],_0x1443d2[Io]=this['myPW'],_0x1443d2[wo]=this['currentSerial'];let _0x3b43ac=this['urlFn'](_0x1443d2),_0x13a035='',_0x550762=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x13a035['length']<=Co;){const _0x5dc4b7=this['pendingSegs']['shift']();_0x13a035=_0x13a035+'&'+lh+_0x550762+'='+_0x5dc4b7['seg']+'&'+hh+_0x550762+'='+_0x5dc4b7['ts']+'&'+uh+_0x550762+'='+_0x5dc4b7['d'],_0x550762++;}return _0x3b43ac=_0x3b43ac+_0x13a035,this['addLongPollTag_'](_0x3b43ac,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x169467,_0x23b2e3,_0x53b8ee){this['pendingSegs']['push']({'seg':_0x169467,'ts':_0x23b2e3,'d':_0x53b8ee}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x54cc6a,_0x336673){this['outstandingRequests']['add'](_0x336673);const _0x54ca16=()=>{this['outstandingRequests']['delete'](_0x336673),this['newRequest_']();},_0x5d1904=setTimeout(_0x54ca16,Math['floor'](ph)),_0xdc04e6=()=>{clearTimeout(_0x5d1904),_0x54ca16();};this['addTag'](_0x54cc6a,_0xdc04e6);}['addTag'](_0x220c71,_0x1f1282){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4df1a1=this['myIFrame']['doc']['createElement']('script');_0x4df1a1['type']='text/javascript',_0x4df1a1['async']=!0x0,_0x4df1a1['src']=_0x220c71,_0x4df1a1['onload']=_0x4df1a1['onreadystatechange']=function(){const _0x4f6308=_0x4df1a1['readyState'];(!_0x4f6308||_0x4f6308==='loaded'||_0x4f6308==='complete')&&(_0x4df1a1['onload']=_0x4df1a1['onreadystatechange']=null,_0x4df1a1['parentNode']&&_0x4df1a1['parentNode']['removeChild'](_0x4df1a1),_0x1f1282());},_0x4df1a1['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x220c71),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4df1a1);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x23aa98,_0x15a380,_0x1824e0,_0x2efbd9,_0x30d1c1,_0x12ab60,_0x3376c0){this['connId']=_0x23aa98,this['applicationId']=_0x1824e0,this['appCheckToken']=_0x2efbd9,this['authToken']=_0x30d1c1,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x15a380),this['connURL']=q['connectionURL_'](_0x15a380,_0x12ab60,_0x3376c0,_0x2efbd9,_0x1824e0),this['nodeAdmin']=_0x15a380['nodeAdmin'];}static['connectionURL_'](_0xe7eae3,_0x43dd6b,_0x9603a6,_0x20db1f,_0x3b875d){const _0x6b979a={};return _0x6b979a[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x6b979a[ho]=uo),_0x43dd6b&&(_0x6b979a[lo]=_0x43dd6b),_0x9603a6&&(_0x6b979a[po]=_0x9603a6),_0x20db1f&&(_0x6b979a[wi]=_0x20db1f),_0x3b875d&&(_0x6b979a[_o]=_0x3b875d),vo(_0xe7eae3,go,_0x6b979a);}['open'](_0x1e9cfa,_0x55f272){this['onDisconnect']=_0x55f272,this['onMessage']=_0x1e9cfa,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x392e90;_c(),this['mySock']=new gn(this['connURL'],[],_0x392e90);}catch(_0x46edf5){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x41c770=_0x46edf5['message']||_0x46edf5['data'];_0x41c770&&this['log_'](_0x41c770),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x461df4=>{this['handleIncomingFrame'](_0x461df4);},this['mySock']['onerror']=_0x9e7045=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x41396a=_0x9e7045['message']||_0x9e7045['data'];_0x41396a&&this['log_'](_0x41396a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xf7f094=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3219eb=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3a85b5=navigator['userAgent']['match'](_0x3219eb);_0x3a85b5&&_0x3a85b5['length']>0x1&&parseFloat(_0x3a85b5[0x1])<4.4&&(_0xf7f094=!0x0);}return!_0xf7f094&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5d391c){if(this['frames']['push'](_0x5d391c),this['frames']['length']===this['totalFrames']){const _0x584cde=this['frames']['join']('');this['frames']=null;const _0x2c2a23=Nt(_0x584cde);this['onMessage'](_0x2c2a23);}}['handleNewFrameCount_'](_0x2ea31d){this['totalFrames']=_0x2ea31d,this['frames']=[];}['extractFrameCount_'](_0x46deed){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x46deed['length']<=0x6){const _0x40a407=Number(_0x46deed);if(!isNaN(_0x40a407))return this['handleNewFrameCount_'](_0x40a407),null;}return this['handleNewFrameCount_'](0x1),_0x46deed;}['handleIncomingFrame'](_0x24145e){if(this['mySock']===null)return;const _0x23c3de=_0x24145e['data'];if(this['bytesReceived']+=_0x23c3de['length'],this['stats_']['incrementCounter']('bytes_received',_0x23c3de['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x23c3de);else{const _0x2b30b3=this['extractFrameCount_'](_0x23c3de);_0x2b30b3!==null&&this['appendFrame_'](_0x2b30b3);}}['send'](_0x1c36a3){this['resetKeepAlive']();const _0x346a9a=O(_0x1c36a3);this['bytesSent']+=_0x346a9a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x346a9a['length']);const _0x541c85=oo(_0x346a9a,gh);_0x541c85['length']>0x1&&this['sendString_'](String(_0x541c85['length']));for(let _0x45f88e=0x0;_0x45f88e<_0x541c85['length'];_0x45f88e++)this['sendString_'](_0x541c85[_0x45f88e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4ff12c){try{this['mySock']['send'](_0x4ff12c);}catch(_0x175c90){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x175c90['message']||_0x175c90['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x527791){this['initTransports_'](_0x527791);}['initTransports_'](_0x3cc567){const _0x17b5e9=q&&q['isAvailable']();let _0x67eede=_0x17b5e9&&!q['previouslyFailed']();if(_0x3cc567['webSocketOnly']&&(_0x17b5e9||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x67eede=!0x0),_0x67eede)this['transports_']=[q];else{const _0x59274c=this['transports_']=[];for(const _0x21ba33 of Dt['ALL_TRANSPORTS'])_0x21ba33&&_0x21ba33['isAvailable']()&&_0x59274c['push'](_0x21ba33);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4c8eb5,_0x474a92,_0x3ea739,_0x564d72,_0x1446fb,_0x1a4c0e,_0x4eb9a0,_0x1175e1,_0x2cf7cf,_0xa35773){this['id']=_0x4c8eb5,this['repoInfo_']=_0x474a92,this['applicationId_']=_0x3ea739,this['appCheckToken_']=_0x564d72,this['authToken_']=_0x1446fb,this['onMessage_']=_0x1a4c0e,this['onReady_']=_0x4eb9a0,this['onDisconnect_']=_0x1175e1,this['onKill_']=_0x2cf7cf,this['lastSessionId']=_0xa35773,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x474a92),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x29a178=this['transportManager_']['initialTransport']();this['conn_']=new _0x29a178(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x29a178['responsesRequiredToBeHealthy']||0x0;const _0xade5b3=this['connReceiver_'](this['conn_']),_0x40eced=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xade5b3,_0x40eced);},Math['floor'](0x0));const _0x2ff01e=_0x29a178['healthyTimeout']||0x0;_0x2ff01e>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2ff01e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x31f841){return _0x8fc8f=>{_0x31f841===this['conn_']?this['onConnectionLost_'](_0x8fc8f):_0x31f841===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3a3d3d){return _0x10aaba=>{this['state_']!==0x2&&(_0x3a3d3d===this['rx_']?this['onPrimaryMessageReceived_'](_0x10aaba):_0x3a3d3d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x10aaba):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2ef637){const _0x1d01bf={'t':'d','d':_0x2ef637};this['sendData_'](_0x1d01bf);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3137c0){if(ci in _0x3137c0){const _0x1edff9=_0x3137c0[ci];_0x1edff9===Ys?this['upgradeIfSecondaryHealthy_']():_0x1edff9===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1edff9===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x529b0e){const _0x46e80c=vt('t',_0x529b0e),_0xcc3d2f=vt('d',_0x529b0e);if(_0x46e80c==='c')this['onSecondaryControl_'](_0xcc3d2f);else{if(_0x46e80c==='d')this['pendingDataMessages']['push'](_0xcc3d2f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x46e80c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xbeb805){const _0xfc932a=vt('t',_0xbeb805),_0x4cc9dd=vt('d',_0xbeb805);_0xfc932a==='c'?this['onControl_'](_0x4cc9dd):_0xfc932a==='d'&&this['onDataMessage_'](_0x4cc9dd);}['onDataMessage_'](_0x5545d3){this['onPrimaryResponse_'](),this['onMessage_'](_0x5545d3);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4e4b80){const _0x351125=vt(ci,_0x4e4b80);if(zs in _0x4e4b80){const _0x440d4e=_0x4e4b80[zs];if(_0x351125===Th){const _0x5004ee={..._0x440d4e};this['repoInfo_']['isUsingEmulator']&&(_0x5004ee['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5004ee);}else{if(_0x351125===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4bc3c9=0x0;_0x4bc3c9<this['pendingDataMessages']['length'];++_0x4bc3c9)this['onDataMessage_'](this['pendingDataMessages'][_0x4bc3c9]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x351125===wh?this['onConnectionShutdown_'](_0x440d4e):_0x351125===js?this['onReset_'](_0x440d4e):_0x351125===Ch?Ii('Server\x20Error:\x20'+_0x440d4e):_0x351125===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x351125);}}}['onHandshake_'](_0x21a059){const _0x326a45=_0x21a059['ts'],_0x320254=_0x21a059['v'],_0x5076b9=_0x21a059['h'];this['sessionId']=_0x21a059['s'],this['repoInfo_']['host']=_0x5076b9,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x326a45),Gi!==_0x320254&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xda64c4=this['transportManager_']['upgradeTransport']();_0xda64c4&&this['startUpgrade_'](_0xda64c4);}['startUpgrade_'](_0x5ee0b9){this['secondaryConn_']=new _0x5ee0b9(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5ee0b9['responsesRequiredToBeHealthy']||0x0;const _0x47d0b8=this['connReceiver_'](this['secondaryConn_']),_0x2e74c7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x47d0b8,_0x2e74c7),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x31e620){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x31e620),this['repoInfo_']['host']=_0x31e620,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x21390a,_0x4115c1){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x21390a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4115c1,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x215a61=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x215a61||this['rx_']===_0x215a61)&&this['close']();}['onConnectionLost_'](_0x3675f3){this['conn_']=null,!_0x3675f3&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x504a1b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x504a1b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x56f54d){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x56f54d);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x48c3d1,_0xae714c,_0x3aeca4,_0x4a01d8){}['merge'](_0x50021c,_0x675d42,_0x409d59,_0xbd089b){}['refreshAuthToken'](_0x4083bb){}['refreshAppCheckToken'](_0x14facc){}['onDisconnectPut'](_0x3f60fc,_0xcb1d5,_0x18c2f6){}['onDisconnectMerge'](_0x47b87d,_0x3c8fad,_0x5199eb){}['onDisconnectCancel'](_0xddf834,_0x17dcd9){}['reportStats'](_0x1127ee){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2a86f2){this['allowedEvents_']=_0x2a86f2,this['listeners_']={},f(Array['isArray'](_0x2a86f2)&&_0x2a86f2['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5e2453,..._0x2a5d51){if(Array['isArray'](this['listeners_'][_0x5e2453])){const _0x23d160=[...this['listeners_'][_0x5e2453]];for(let _0x262ca2=0x0;_0x262ca2<_0x23d160['length'];_0x262ca2++)_0x23d160[_0x262ca2]['callback']['apply'](_0x23d160[_0x262ca2]['context'],_0x2a5d51);}}['on'](_0x30e2bd,_0x3825de,_0x4dd9d4){this['validateEventType_'](_0x30e2bd),this['listeners_'][_0x30e2bd]=this['listeners_'][_0x30e2bd]||[],this['listeners_'][_0x30e2bd]['push']({'callback':_0x3825de,'context':_0x4dd9d4});const _0x418f1e=this['getInitialEvent'](_0x30e2bd);_0x418f1e&&_0x3825de['apply'](_0x4dd9d4,_0x418f1e);}['off'](_0x4b25e7,_0x33508a,_0x476b3f){this['validateEventType_'](_0x4b25e7);const _0x42c5f2=this['listeners_'][_0x4b25e7]||[];for(let _0x45138c=0x0;_0x45138c<_0x42c5f2['length'];_0x45138c++)if(_0x42c5f2[_0x45138c]['callback']===_0x33508a&&(!_0x476b3f||_0x476b3f===_0x42c5f2[_0x45138c]['context'])){_0x42c5f2['splice'](_0x45138c,0x1);return;}}['validateEventType_'](_0x5e5b93){f(this['allowedEvents_']['find'](_0x406bbe=>_0x406bbe===_0x5e5b93),'Unknown\x20event:\x20'+_0x5e5b93);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2d6d5a){return f(_0x2d6d5a==='online','Unknown\x20event\x20type:\x20'+_0x2d6d5a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x39245a,_0x371ccf){if(_0x371ccf===void 0x0){this['pieces_']=_0x39245a['split']('/');let _0x13630e=0x0;for(let _0x938cfb=0x0;_0x938cfb<this['pieces_']['length'];_0x938cfb++)this['pieces_'][_0x938cfb]['length']>0x0&&(this['pieces_'][_0x13630e]=this['pieces_'][_0x938cfb],_0x13630e++);this['pieces_']['length']=_0x13630e,this['pieceNum_']=0x0;}else this['pieces_']=_0x39245a,this['pieceNum_']=_0x371ccf;}['toString'](){let _0x1affde='';for(let _0x40dd90=this['pieceNum_'];_0x40dd90<this['pieces_']['length'];_0x40dd90++)this['pieces_'][_0x40dd90]!==''&&(_0x1affde+='/'+this['pieces_'][_0x40dd90]);return _0x1affde||'/';}}function w(){return new C('');}function y(_0xc8a581){return _0xc8a581['pieceNum_']>=_0xc8a581['pieces_']['length']?null:_0xc8a581['pieces_'][_0xc8a581['pieceNum_']];}function Ce(_0x20da34){return _0x20da34['pieces_']['length']-_0x20da34['pieceNum_'];}function S(_0x10f27e){let _0x33036c=_0x10f27e['pieceNum_'];return _0x33036c<_0x10f27e['pieces_']['length']&&_0x33036c++,new C(_0x10f27e['pieces_'],_0x33036c);}function ji(_0x1cfc2a){return _0x1cfc2a['pieceNum_']<_0x1cfc2a['pieces_']['length']?_0x1cfc2a['pieces_'][_0x1cfc2a['pieces_']['length']-0x1]:null;}function bh(_0x31f22f){let _0x2b5fea='';for(let _0x21d6ad=_0x31f22f['pieceNum_'];_0x21d6ad<_0x31f22f['pieces_']['length'];_0x21d6ad++)_0x31f22f['pieces_'][_0x21d6ad]!==''&&(_0x2b5fea+='/'+encodeURIComponent(String(_0x31f22f['pieces_'][_0x21d6ad])));return _0x2b5fea||'/';}function Mt(_0x1159ab,_0xb6ff7c=0x0){return _0x1159ab['pieces_']['slice'](_0x1159ab['pieceNum_']+_0xb6ff7c);}function Ro(_0x4cb129){if(_0x4cb129['pieceNum_']>=_0x4cb129['pieces_']['length'])return null;const _0x37ee52=[];for(let _0x1d7a5d=_0x4cb129['pieceNum_'];_0x1d7a5d<_0x4cb129['pieces_']['length']-0x1;_0x1d7a5d++)_0x37ee52['push'](_0x4cb129['pieces_'][_0x1d7a5d]);return new C(_0x37ee52,0x0);}function k(_0x4e08ed,_0x575a54){const _0x4da3d3=[];for(let _0x39a159=_0x4e08ed['pieceNum_'];_0x39a159<_0x4e08ed['pieces_']['length'];_0x39a159++)_0x4da3d3['push'](_0x4e08ed['pieces_'][_0x39a159]);if(_0x575a54 instanceof C){for(let _0x1c2563=_0x575a54['pieceNum_'];_0x1c2563<_0x575a54['pieces_']['length'];_0x1c2563++)_0x4da3d3['push'](_0x575a54['pieces_'][_0x1c2563]);}else{const _0x538253=_0x575a54['split']('/');for(let _0x39a96f=0x0;_0x39a96f<_0x538253['length'];_0x39a96f++)_0x538253[_0x39a96f]['length']>0x0&&_0x4da3d3['push'](_0x538253[_0x39a96f]);}return new C(_0x4da3d3,0x0);}function v(_0x55dc20){return _0x55dc20['pieceNum_']>=_0x55dc20['pieces_']['length'];}function F(_0x4a2f43,_0x585eef){const _0x255ba8=y(_0x4a2f43),_0x2c5005=y(_0x585eef);if(_0x255ba8===null)return _0x585eef;if(_0x255ba8===_0x2c5005)return F(S(_0x4a2f43),S(_0x585eef));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x585eef+')\x20is\x20not\x20within\x20outerPath\x20('+_0x4a2f43+')');}function Rh(_0x287714,_0x1b1234){const _0x3db34a=Mt(_0x287714,0x0),_0x5c8db6=Mt(_0x1b1234,0x0);for(let _0x47523f=0x0;_0x47523f<_0x3db34a['length']&&_0x47523f<_0x5c8db6['length'];_0x47523f++){const _0x519713=qe(_0x3db34a[_0x47523f],_0x5c8db6[_0x47523f]);if(_0x519713!==0x0)return _0x519713;}return _0x3db34a['length']===_0x5c8db6['length']?0x0:_0x3db34a['length']<_0x5c8db6['length']?-0x1:0x1;}function Ki(_0x450a0a,_0x5df119){if(Ce(_0x450a0a)!==Ce(_0x5df119))return!0x1;for(let _0x31d1af=_0x450a0a['pieceNum_'],_0x5f2234=_0x5df119['pieceNum_'];_0x31d1af<=_0x450a0a['pieces_']['length'];_0x31d1af++,_0x5f2234++)if(_0x450a0a['pieces_'][_0x31d1af]!==_0x5df119['pieces_'][_0x5f2234])return!0x1;return!0x0;}function G(_0x375a4c,_0x2cf67e){let _0x1f7da5=_0x375a4c['pieceNum_'],_0x18cd44=_0x2cf67e['pieceNum_'];if(Ce(_0x375a4c)>Ce(_0x2cf67e))return!0x1;for(;_0x1f7da5<_0x375a4c['pieces_']['length'];){if(_0x375a4c['pieces_'][_0x1f7da5]!==_0x2cf67e['pieces_'][_0x18cd44])return!0x1;++_0x1f7da5,++_0x18cd44;}return!0x0;}class Ah{constructor(_0xe93d56,_0x5f55cb){this['errorPrefix_']=_0x5f55cb,this['parts_']=Mt(_0xe93d56,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x59021a=0x0;_0x59021a<this['parts_']['length'];_0x59021a++)this['byteLength_']+=Ln(this['parts_'][_0x59021a]);Ao(this);}}function kh(_0x25d134,_0x594d97){_0x25d134['parts_']['length']>0x0&&(_0x25d134['byteLength_']+=0x1),_0x25d134['parts_']['push'](_0x594d97),_0x25d134['byteLength_']+=Ln(_0x594d97),Ao(_0x25d134);}function Ph(_0x3f7c6a){const _0xcea30e=_0x3f7c6a['parts_']['pop']();_0x3f7c6a['byteLength_']-=Ln(_0xcea30e),_0x3f7c6a['parts_']['length']>0x0&&(_0x3f7c6a['byteLength_']-=0x1);}function Ao(_0x5e362d){if(_0x5e362d['byteLength_']>Zs)throw new Error(_0x5e362d['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x5e362d['byteLength_']+').');if(_0x5e362d['parts_']['length']>Xs)throw new Error(_0x5e362d['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x5e362d));}function Oe(_0x41d0e3){return _0x41d0e3['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x41d0e3['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x26a88b,_0x184c54;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x184c54='visibilitychange',_0x26a88b='hidden'):typeof document['mozHidden']<'u'?(_0x184c54='mozvisibilitychange',_0x26a88b='mozHidden'):typeof document['msHidden']<'u'?(_0x184c54='msvisibilitychange',_0x26a88b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x184c54='webkitvisibilitychange',_0x26a88b='webkitHidden')),this['visible_']=!0x0,_0x184c54&&document['addEventListener'](_0x184c54,()=>{const _0x1d485e=!document[_0x26a88b];_0x1d485e!==this['visible_']&&(this['visible_']=_0x1d485e,this['trigger']('visible',_0x1d485e));},!0x1);}['getInitialEvent'](_0x5ae416){return f(_0x5ae416==='visible','Unknown\x20event\x20type:\x20'+_0x5ae416),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4b7116,_0x25bd3d,_0x57808d,_0xaa343f,_0x555300,_0x56ab9f,_0x456304,_0x4fc744){if(super(),this['repoInfo_']=_0x4b7116,this['applicationId_']=_0x25bd3d,this['onDataUpdate_']=_0x57808d,this['onConnectStatus_']=_0xaa343f,this['onServerInfoUpdate_']=_0x555300,this['authTokenProvider_']=_0x56ab9f,this['appCheckTokenProvider_']=_0x456304,this['authOverride_']=_0x4fc744,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4fc744)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4b7116['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2644cf,_0x2f162f,_0xb67d9f){const _0x55d6fa=++this['requestNumber_'],_0x4700bd={'r':_0x55d6fa,'a':_0x2644cf,'b':_0x2f162f};this['log_'](O(_0x4700bd)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4700bd),_0xb67d9f&&(this['requestCBHash_'][_0x55d6fa]=_0xb67d9f);}['get'](_0x4ac0b9){this['initConnection_']();const _0x2f60e1=new H(),_0x1db0aa={'action':'g','request':{'p':_0x4ac0b9['_path']['toString'](),'q':_0x4ac0b9['_queryObject']},'onComplete':_0x549cbf=>{const _0x41e928=_0x549cbf['d'];_0x549cbf['s']==='ok'?_0x2f60e1['resolve'](_0x41e928):_0x2f60e1['reject'](_0x41e928);}};this['outstandingGets_']['push'](_0x1db0aa),this['outstandingGetCount_']++;const _0x17091b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x17091b),_0x2f60e1['promise'];}['listen'](_0x3a513e,_0x1bf008,_0x33977d,_0x338a79){this['initConnection_']();const _0x532e15=_0x3a513e['_queryIdentifier'],_0x1b6b27=_0x3a513e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1b6b27+'\x20'+_0x532e15),this['listens']['has'](_0x1b6b27)||this['listens']['set'](_0x1b6b27,new Map()),f(_0x3a513e['_queryParams']['isDefault']()||!_0x3a513e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1b6b27)['has'](_0x532e15),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4a2c7c={'onComplete':_0x338a79,'hashFn':_0x1bf008,'query':_0x3a513e,'tag':_0x33977d};this['listens']['get'](_0x1b6b27)['set'](_0x532e15,_0x4a2c7c),this['connected_']&&this['sendListen_'](_0x4a2c7c);}['sendGet_'](_0x54ba0f){const _0x1b12f4=this['outstandingGets_'][_0x54ba0f];this['sendRequest']('g',_0x1b12f4['request'],_0x92c59a=>{delete this['outstandingGets_'][_0x54ba0f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1b12f4['onComplete']&&_0x1b12f4['onComplete'](_0x92c59a);});}['sendListen_'](_0x393834){const _0x17658f=_0x393834['query'],_0x5049e7=_0x17658f['_path']['toString'](),_0x462ecc=_0x17658f['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5049e7+'\x20for\x20'+_0x462ecc);const _0x45e09c={'p':_0x5049e7},_0xc71ba0='q';_0x393834['tag']&&(_0x45e09c['q']=_0x17658f['_queryObject'],_0x45e09c['t']=_0x393834['tag']),_0x45e09c['h']=_0x393834['hashFn'](),this['sendRequest'](_0xc71ba0,_0x45e09c,_0x30d7fc=>{const _0x330f8b=_0x30d7fc['d'],_0x517948=_0x30d7fc['s'];se['warnOnListenWarnings_'](_0x330f8b,_0x17658f),(this['listens']['get'](_0x5049e7)&&this['listens']['get'](_0x5049e7)['get'](_0x462ecc))===_0x393834&&(this['log_']('listen\x20response',_0x30d7fc),_0x517948!=='ok'&&this['removeListen_'](_0x5049e7,_0x462ecc),_0x393834['onComplete']&&_0x393834['onComplete'](_0x517948,_0x330f8b));});}static['warnOnListenWarnings_'](_0x217744,_0x59da0c){if(_0x217744&&typeof _0x217744=='object'&&Q(_0x217744,'w')){const _0x180aa7=Le(_0x217744,'w');if(Array['isArray'](_0x180aa7)&&~_0x180aa7['indexOf']('no_index')){const _0x5a98cb='\x22.indexOn\x22:\x20\x22'+_0x59da0c['_queryParams']['getIndex']()['toString']()+'\x22',_0x465520=_0x59da0c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5a98cb+'\x20at\x20'+_0x465520+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xb059f8){this['authToken_']=_0xb059f8,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xb059f8);}['reduceReconnectDelayIfAdminCredential_'](_0x43ac36){(_0x43ac36&&_0x43ac36['length']===0x28||wc(_0x43ac36))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3d7548){this['appCheckToken_']=_0x3d7548,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5830be=this['authToken_'],_0x50ad96=Ic(_0x5830be)?'auth':'gauth',_0x16c617={'cred':_0x5830be};this['authOverride_']===null?_0x16c617['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x16c617['authvar']=this['authOverride_']),this['sendRequest'](_0x50ad96,_0x16c617,_0x505f81=>{const _0x28d45e=_0x505f81['s'],_0x4d0112=_0x505f81['d']||'error';this['authToken_']===_0x5830be&&(_0x28d45e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x28d45e,_0x4d0112));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4f3a6a=>{const _0x2ea81f=_0x4f3a6a['s'],_0x2587e4=_0x4f3a6a['d']||'error';_0x2ea81f==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2ea81f,_0x2587e4);});}['unlisten'](_0x37dd3a,_0x10470e){const _0x15dc0a=_0x37dd3a['_path']['toString'](),_0x4b344a=_0x37dd3a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x15dc0a+'\x20'+_0x4b344a),f(_0x37dd3a['_queryParams']['isDefault']()||!_0x37dd3a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x15dc0a,_0x4b344a)&&this['connected_']&&this['sendUnlisten_'](_0x15dc0a,_0x4b344a,_0x37dd3a['_queryObject'],_0x10470e);}['sendUnlisten_'](_0x5d0acd,_0x233bfc,_0xa4f152,_0x482129){this['log_']('Unlisten\x20on\x20'+_0x5d0acd+'\x20for\x20'+_0x233bfc);const _0x13ac91={'p':_0x5d0acd},_0x310ebe='n';_0x482129&&(_0x13ac91['q']=_0xa4f152,_0x13ac91['t']=_0x482129),this['sendRequest'](_0x310ebe,_0x13ac91);}['onDisconnectPut'](_0x122792,_0x58e242,_0x478f30){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x122792,_0x58e242,_0x478f30):this['onDisconnectRequestQueue_']['push']({'pathString':_0x122792,'action':'o','data':_0x58e242,'onComplete':_0x478f30});}['onDisconnectMerge'](_0x591349,_0x18ec71,_0x20619d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x591349,_0x18ec71,_0x20619d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x591349,'action':'om','data':_0x18ec71,'onComplete':_0x20619d});}['onDisconnectCancel'](_0x1c95b0,_0x36173b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1c95b0,null,_0x36173b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1c95b0,'action':'oc','data':null,'onComplete':_0x36173b});}['sendOnDisconnect_'](_0x265898,_0x21dd2d,_0x2220a3,_0x14a56e){const _0x4f57b0={'p':_0x21dd2d,'d':_0x2220a3};this['log_']('onDisconnect\x20'+_0x265898,_0x4f57b0),this['sendRequest'](_0x265898,_0x4f57b0,_0x3a6e81=>{_0x14a56e&&setTimeout(()=>{_0x14a56e(_0x3a6e81['s'],_0x3a6e81['d']);},Math['floor'](0x0));});}['put'](_0x4a252a,_0x1e3d70,_0x5d901a,_0x430394){this['putInternal']('p',_0x4a252a,_0x1e3d70,_0x5d901a,_0x430394);}['merge'](_0x2d4cae,_0x4b6392,_0x270fe1,_0xdf34e5){this['putInternal']('m',_0x2d4cae,_0x4b6392,_0x270fe1,_0xdf34e5);}['putInternal'](_0x58c545,_0x299875,_0x17d306,_0x1656ae,_0x64689f){this['initConnection_']();const _0x41205b={'p':_0x299875,'d':_0x17d306};_0x64689f!==void 0x0&&(_0x41205b['h']=_0x64689f),this['outstandingPuts_']['push']({'action':_0x58c545,'request':_0x41205b,'onComplete':_0x1656ae}),this['outstandingPutCount_']++;const _0x14b0be=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x14b0be):this['log_']('Buffering\x20put:\x20'+_0x299875);}['sendPut_'](_0x31d7a4){const _0x56f0fc=this['outstandingPuts_'][_0x31d7a4]['action'],_0x71dc08=this['outstandingPuts_'][_0x31d7a4]['request'],_0x2d34f3=this['outstandingPuts_'][_0x31d7a4]['onComplete'];this['outstandingPuts_'][_0x31d7a4]['queued']=this['connected_'],this['sendRequest'](_0x56f0fc,_0x71dc08,_0x49b567=>{this['log_'](_0x56f0fc+'\x20response',_0x49b567),delete this['outstandingPuts_'][_0x31d7a4],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2d34f3&&_0x2d34f3(_0x49b567['s'],_0x49b567['d']);});}['reportStats'](_0xff4508){if(this['connected_']){const _0x2a6919={'c':_0xff4508};this['log_']('reportStats',_0x2a6919),this['sendRequest']('s',_0x2a6919,_0x5426d7=>{if(_0x5426d7['s']!=='ok'){const _0x3d296d=_0x5426d7['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3d296d);}});}}['onDataMessage_'](_0x31ccea){if('r'in _0x31ccea){this['log_']('from\x20server:\x20'+O(_0x31ccea));const _0x3a04d2=_0x31ccea['r'],_0x37fa31=this['requestCBHash_'][_0x3a04d2];_0x37fa31&&(delete this['requestCBHash_'][_0x3a04d2],_0x37fa31(_0x31ccea['b']));}else{if('error'in _0x31ccea)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x31ccea['error'];'a'in _0x31ccea&&this['onDataPush_'](_0x31ccea['a'],_0x31ccea['b']);}}['onDataPush_'](_0x2ac50f,_0x4ea817){this['log_']('handleServerMessage',_0x2ac50f,_0x4ea817),_0x2ac50f==='d'?this['onDataUpdate_'](_0x4ea817['p'],_0x4ea817['d'],!0x1,_0x4ea817['t']):_0x2ac50f==='m'?this['onDataUpdate_'](_0x4ea817['p'],_0x4ea817['d'],!0x0,_0x4ea817['t']):_0x2ac50f==='c'?this['onListenRevoked_'](_0x4ea817['p'],_0x4ea817['q']):_0x2ac50f==='ac'?this['onAuthRevoked_'](_0x4ea817['s'],_0x4ea817['d']):_0x2ac50f==='apc'?this['onAppCheckRevoked_'](_0x4ea817['s'],_0x4ea817['d']):_0x2ac50f==='sd'?this['onSecurityDebugPacket_'](_0x4ea817):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2ac50f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x17ba27,_0x5592d3){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x17ba27),this['lastSessionId']=_0x5592d3,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x17e376){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x17e376));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4bc2e9){_0x4bc2e9&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4bc2e9;}['onOnline_'](_0x33faab){_0x33faab?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x92532d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x421158=Math['max'](0x0,this['reconnectDelay_']-_0x92532d);_0x421158=Math['random']()*_0x421158,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x421158+'ms'),this['scheduleConnect_'](_0x421158),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xf3ec73=this['onDataMessage_']['bind'](this),_0x58475a=this['onReady_']['bind'](this),_0x55c990=this['onRealtimeDisconnect_']['bind'](this),_0x17dfa5=this['id']+':'+se['nextConnectionId_']++,_0x18315a=this['lastSessionId'];let _0xd7ba44=!0x1,_0x227f07=null;const _0x38c67a=function(){_0x227f07?_0x227f07['close']():(_0xd7ba44=!0x0,_0x55c990());},_0xe702ca=function(_0x27ce99){f(_0x227f07,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x227f07['sendRequest'](_0x27ce99);};this['realtime_']={'close':_0x38c67a,'sendRequest':_0xe702ca};const _0x41c2d5=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4026ee,_0x5ae9f4]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x41c2d5),this['appCheckTokenProvider_']['getToken'](_0x41c2d5)]);_0xd7ba44?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4026ee&&_0x4026ee['accessToken'],this['appCheckToken_']=_0x5ae9f4&&_0x5ae9f4['token'],_0x227f07=new Sh(_0x17dfa5,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xf3ec73,_0x58475a,_0x55c990,_0x5ec412=>{U(_0x5ec412+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x18315a));}catch(_0x437b23){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x437b23),_0xd7ba44||(this['repoInfo_']['nodeAdmin']&&U(_0x437b23),_0x38c67a());}}}['interrupt'](_0x509847){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x509847),this['interruptReasons_'][_0x509847]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x52edb8){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x52edb8),delete this['interruptReasons_'][_0x52edb8],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x455d3c){const _0x5a9bec=_0x455d3c-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5a9bec});}['cancelSentTransactions_'](){for(let _0x15194e=0x0;_0x15194e<this['outstandingPuts_']['length'];_0x15194e++){const _0x4c948a=this['outstandingPuts_'][_0x15194e];_0x4c948a&&'h'in _0x4c948a['request']&&_0x4c948a['queued']&&(_0x4c948a['onComplete']&&_0x4c948a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x15194e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x525625,_0x507fc2){let _0x55dde7;_0x507fc2?_0x55dde7=_0x507fc2['map'](_0x1602d5=>$i(_0x1602d5))['join']('$'):_0x55dde7='default';const _0xcf1a1e=this['removeListen_'](_0x525625,_0x55dde7);_0xcf1a1e&&_0xcf1a1e['onComplete']&&_0xcf1a1e['onComplete']('permission_denied');}['removeListen_'](_0x617a47,_0x40b7a2){const _0x5c4aed=new C(_0x617a47)['toString']();let _0x92081f;if(this['listens']['has'](_0x5c4aed)){const _0x45efe4=this['listens']['get'](_0x5c4aed);_0x92081f=_0x45efe4['get'](_0x40b7a2),_0x45efe4['delete'](_0x40b7a2),_0x45efe4['size']===0x0&&this['listens']['delete'](_0x5c4aed);}else _0x92081f=void 0x0;return _0x92081f;}['onAuthRevoked_'](_0x711f1b,_0x3821e8){L('Auth\x20token\x20revoked:\x20'+_0x711f1b+'/'+_0x3821e8),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x711f1b==='invalid_token'||_0x711f1b==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x578da2,_0x5e1b86){L('App\x20check\x20token\x20revoked:\x20'+_0x578da2+'/'+_0x5e1b86),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x578da2==='invalid_token'||_0x578da2==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0xd429c3){this['securityDebugCallback_']?this['securityDebugCallback_'](_0xd429c3):'msg'in _0xd429c3&&console['log']('FIREBASE:\x20'+_0xd429c3['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2d2a9e of this['listens']['values']())for(const _0x110993 of _0x2d2a9e['values']())this['sendListen_'](_0x110993);for(let _0x3a4e4e=0x0;_0x3a4e4e<this['outstandingPuts_']['length'];_0x3a4e4e++)this['outstandingPuts_'][_0x3a4e4e]&&this['sendPut_'](_0x3a4e4e);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3fe87f=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3fe87f['action'],_0x3fe87f['pathString'],_0x3fe87f['data'],_0x3fe87f['onComplete']);}for(let _0x5a479a=0x0;_0x5a479a<this['outstandingGets_']['length'];_0x5a479a++)this['outstandingGets_'][_0x5a479a]&&this['sendGet_'](_0x5a479a);}['sendConnectStats_'](){const _0x2f0fbd={};let _0x2b464c='js';_0x2f0fbd['sdk.'+_0x2b464c+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x2f0fbd['framework.cordova']=0x1:Kr()&&(_0x2f0fbd['framework.reactnative']=0x1),this['reportStats'](_0x2f0fbd);}['shouldReconnect_'](){const _0x2427f5=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x2427f5;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x24bc5a,_0x2b048f){this['name']=_0x24bc5a,this['node']=_0x2b048f;}static['Wrap'](_0x219d7e,_0x39b08c){return new E(_0x219d7e,_0x39b08c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x59f4db,_0x578149){const _0x482057=new E(We,_0x59f4db),_0x39f0dc=new E(We,_0x578149);return this['compare'](_0x482057,_0x39f0dc)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5d7292){sn=_0x5d7292;}['compare'](_0x2f09e7,_0x563c8b){return qe(_0x2f09e7['name'],_0x563c8b['name']);}['isDefinedOn'](_0x19e37f){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x46d998,_0x37e829){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x8e122f,_0x57a6c5){return f(typeof _0x8e122f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x8e122f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x5bd565,_0x5563a8,_0x5e3709,_0x87f043,_0x589518=null){this['isReverse_']=_0x87f043,this['resultGenerator_']=_0x589518,this['nodeStack_']=[];let _0x5bfd8e=0x1;for(;!_0x5bd565['isEmpty']();)if(_0x5bd565=_0x5bd565,_0x5bfd8e=_0x5563a8?_0x5e3709(_0x5bd565['key'],_0x5563a8):0x1,_0x87f043&&(_0x5bfd8e*=-0x1),_0x5bfd8e<0x0)this['isReverse_']?_0x5bd565=_0x5bd565['left']:_0x5bd565=_0x5bd565['right'];else{if(_0x5bfd8e===0x0){this['nodeStack_']['push'](_0x5bd565);break;}else this['nodeStack_']['push'](_0x5bd565),this['isReverse_']?_0x5bd565=_0x5bd565['right']:_0x5bd565=_0x5bd565['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1e4f43=this['nodeStack_']['pop'](),_0x11fc77;if(this['resultGenerator_']?_0x11fc77=this['resultGenerator_'](_0x1e4f43['key'],_0x1e4f43['value']):_0x11fc77={'key':_0x1e4f43['key'],'value':_0x1e4f43['value']},this['isReverse_']){for(_0x1e4f43=_0x1e4f43['left'];!_0x1e4f43['isEmpty']();)this['nodeStack_']['push'](_0x1e4f43),_0x1e4f43=_0x1e4f43['right'];}else{for(_0x1e4f43=_0x1e4f43['right'];!_0x1e4f43['isEmpty']();)this['nodeStack_']['push'](_0x1e4f43),_0x1e4f43=_0x1e4f43['left'];}return _0x11fc77;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x345cc0=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x345cc0['key'],_0x345cc0['value']):{'key':_0x345cc0['key'],'value':_0x345cc0['value']};}}class M{constructor(_0xdfa79e,_0x5d6a51,_0x3a18b3,_0x374aa6,_0x3e510f){this['key']=_0xdfa79e,this['value']=_0x5d6a51,this['color']=_0x3a18b3??M['RED'],this['left']=_0x374aa6??B['EMPTY_NODE'],this['right']=_0x3e510f??B['EMPTY_NODE'];}['copy'](_0x2e0753,_0x5614f4,_0x53c454,_0x1f6bdd,_0x319a72){return new M(_0x2e0753??this['key'],_0x5614f4??this['value'],_0x53c454??this['color'],_0x1f6bdd??this['left'],_0x319a72??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5d4767){return this['left']['inorderTraversal'](_0x5d4767)||!!_0x5d4767(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5d4767);}['reverseTraversal'](_0x1d1c5f){return this['right']['reverseTraversal'](_0x1d1c5f)||_0x1d1c5f(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1d1c5f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5eafa0,_0x1f464b,_0x519360){let _0xb87142=this;const _0x4bd419=_0x519360(_0x5eafa0,_0xb87142['key']);return _0x4bd419<0x0?_0xb87142=_0xb87142['copy'](null,null,null,_0xb87142['left']['insert'](_0x5eafa0,_0x1f464b,_0x519360),null):_0x4bd419===0x0?_0xb87142=_0xb87142['copy'](null,_0x1f464b,null,null,null):_0xb87142=_0xb87142['copy'](null,null,null,null,_0xb87142['right']['insert'](_0x5eafa0,_0x1f464b,_0x519360)),_0xb87142['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x57764d=this;return!_0x57764d['left']['isRed_']()&&!_0x57764d['left']['left']['isRed_']()&&(_0x57764d=_0x57764d['moveRedLeft_']()),_0x57764d=_0x57764d['copy'](null,null,null,_0x57764d['left']['removeMin_'](),null),_0x57764d['fixUp_']();}['remove'](_0x23a45d,_0x260bad){let _0xfc5c04,_0x5254b7;if(_0xfc5c04=this,_0x260bad(_0x23a45d,_0xfc5c04['key'])<0x0)!_0xfc5c04['left']['isEmpty']()&&!_0xfc5c04['left']['isRed_']()&&!_0xfc5c04['left']['left']['isRed_']()&&(_0xfc5c04=_0xfc5c04['moveRedLeft_']()),_0xfc5c04=_0xfc5c04['copy'](null,null,null,_0xfc5c04['left']['remove'](_0x23a45d,_0x260bad),null);else{if(_0xfc5c04['left']['isRed_']()&&(_0xfc5c04=_0xfc5c04['rotateRight_']()),!_0xfc5c04['right']['isEmpty']()&&!_0xfc5c04['right']['isRed_']()&&!_0xfc5c04['right']['left']['isRed_']()&&(_0xfc5c04=_0xfc5c04['moveRedRight_']()),_0x260bad(_0x23a45d,_0xfc5c04['key'])===0x0){if(_0xfc5c04['right']['isEmpty']())return B['EMPTY_NODE'];_0x5254b7=_0xfc5c04['right']['min_'](),_0xfc5c04=_0xfc5c04['copy'](_0x5254b7['key'],_0x5254b7['value'],null,null,_0xfc5c04['right']['removeMin_']());}_0xfc5c04=_0xfc5c04['copy'](null,null,null,null,_0xfc5c04['right']['remove'](_0x23a45d,_0x260bad));}return _0xfc5c04['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1b2b5e=this;return _0x1b2b5e['right']['isRed_']()&&!_0x1b2b5e['left']['isRed_']()&&(_0x1b2b5e=_0x1b2b5e['rotateLeft_']()),_0x1b2b5e['left']['isRed_']()&&_0x1b2b5e['left']['left']['isRed_']()&&(_0x1b2b5e=_0x1b2b5e['rotateRight_']()),_0x1b2b5e['left']['isRed_']()&&_0x1b2b5e['right']['isRed_']()&&(_0x1b2b5e=_0x1b2b5e['colorFlip_']()),_0x1b2b5e;}['moveRedLeft_'](){let _0x3b05a7=this['colorFlip_']();return _0x3b05a7['right']['left']['isRed_']()&&(_0x3b05a7=_0x3b05a7['copy'](null,null,null,null,_0x3b05a7['right']['rotateRight_']()),_0x3b05a7=_0x3b05a7['rotateLeft_'](),_0x3b05a7=_0x3b05a7['colorFlip_']()),_0x3b05a7;}['moveRedRight_'](){let _0x4100ba=this['colorFlip_']();return _0x4100ba['left']['left']['isRed_']()&&(_0x4100ba=_0x4100ba['rotateRight_'](),_0x4100ba=_0x4100ba['colorFlip_']()),_0x4100ba;}['rotateLeft_'](){const _0x2d7909=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2d7909,null);}['rotateRight_'](){const _0x3215e0=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3215e0);}['colorFlip_'](){const _0x5d8c95=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x280c1c=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5d8c95,_0x280c1c);}['checkMaxDepth_'](){const _0x10d348=this['check_']();return Math['pow'](0x2,_0x10d348)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4ee8ac=this['left']['check_']();if(_0x4ee8ac!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4ee8ac+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4ead2a,_0x1c65f7,_0x32899d,_0x10d133,_0x4dff4d){return this;}['insert'](_0x13da15,_0x8411e3,_0x30b87d){return new M(_0x13da15,_0x8411e3,null);}['remove'](_0x5c718f,_0x40ec26){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x20cedf){return!0x1;}['reverseTraversal'](_0x4c1b8e){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2f8f82,_0x399a27=B['EMPTY_NODE']){this['comparator_']=_0x2f8f82,this['root_']=_0x399a27;}['insert'](_0x3cd94c,_0x2a629a){return new B(this['comparator_'],this['root_']['insert'](_0x3cd94c,_0x2a629a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x9d4b4){return new B(this['comparator_'],this['root_']['remove'](_0x9d4b4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2207fc){let _0x377662,_0x3cbb23=this['root_'];for(;!_0x3cbb23['isEmpty']();){if(_0x377662=this['comparator_'](_0x2207fc,_0x3cbb23['key']),_0x377662===0x0)return _0x3cbb23['value'];_0x377662<0x0?_0x3cbb23=_0x3cbb23['left']:_0x377662>0x0&&(_0x3cbb23=_0x3cbb23['right']);}return null;}['getPredecessorKey'](_0x376cca){let _0x176221,_0x55ec0a=this['root_'],_0x55644d=null;for(;!_0x55ec0a['isEmpty']();)if(_0x176221=this['comparator_'](_0x376cca,_0x55ec0a['key']),_0x176221===0x0){if(_0x55ec0a['left']['isEmpty']())return _0x55644d?_0x55644d['key']:null;for(_0x55ec0a=_0x55ec0a['left'];!_0x55ec0a['right']['isEmpty']();)_0x55ec0a=_0x55ec0a['right'];return _0x55ec0a['key'];}else _0x176221<0x0?_0x55ec0a=_0x55ec0a['left']:_0x176221>0x0&&(_0x55644d=_0x55ec0a,_0x55ec0a=_0x55ec0a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3acfca){return this['root_']['inorderTraversal'](_0x3acfca);}['reverseTraversal'](_0x454cc4){return this['root_']['reverseTraversal'](_0x454cc4);}['getIterator'](_0xe68318){return new rn(this['root_'],null,this['comparator_'],!0x1,_0xe68318);}['getIteratorFrom'](_0x4c6685,_0x4f3b4c){return new rn(this['root_'],_0x4c6685,this['comparator_'],!0x1,_0x4f3b4c);}['getReverseIteratorFrom'](_0x34c51c,_0x223825){return new rn(this['root_'],_0x34c51c,this['comparator_'],!0x0,_0x223825);}['getReverseIterator'](_0x21fa87){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x21fa87);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3a100e,_0x2ea330){return qe(_0x3a100e['name'],_0x2ea330['name']);}function Qi(_0x1eb416,_0x27050c){return qe(_0x1eb416,_0x27050c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x251359){Ci=_0x251359;}const Po=function(_0xd6168b){return typeof _0xd6168b=='number'?'number:'+ao(_0xd6168b):'string:'+_0xd6168b;},No=function(_0xdee487){if(_0xdee487['isLeafNode']()){const _0x39956c=_0xdee487['val']();f(typeof _0x39956c=='string'||typeof _0x39956c=='number'||typeof _0x39956c=='object'&&Q(_0x39956c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xdee487===Ci||_0xdee487['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xdee487===Ci||_0xdee487['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1866f5){nr=_0x1866f5;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x3ab11b,_0x14be3a=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3ab11b,this['priorityNode_']=_0x14be3a,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x308a94){return new D(this['value_'],_0x308a94);}['getImmediateChild'](_0x32b730){return _0x32b730==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0xea848a){return v(_0xea848a)?this:y(_0xea848a)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x33b579,_0x484fc1){return null;}['updateImmediateChild'](_0x139075,_0x3f313d){return _0x139075==='.priority'?this['updatePriority'](_0x3f313d):_0x3f313d['isEmpty']()&&_0x139075!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x139075,_0x3f313d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x210d81,_0x375085){const _0x17a34f=y(_0x210d81);return _0x17a34f===null?_0x375085:_0x375085['isEmpty']()&&_0x17a34f!=='.priority'?this:(f(_0x17a34f!=='.priority'||Ce(_0x210d81)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x17a34f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x210d81),_0x375085)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x59c637,_0x45a5f6){return!0x1;}['val'](_0x2ad4dc){return _0x2ad4dc&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x55f2d1='';this['priorityNode_']['isEmpty']()||(_0x55f2d1+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3728b2=typeof this['value_'];_0x55f2d1+=_0x3728b2+':',_0x3728b2==='number'?_0x55f2d1+=ao(this['value_']):_0x55f2d1+=this['value_'],this['lazyHash_']=ro(_0x55f2d1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x185eac){return _0x185eac===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x185eac instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x185eac['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x185eac));}['compareToLeafNode_'](_0x36f1e8){const _0x5075a9=typeof _0x36f1e8['value_'],_0x242291=typeof this['value_'],_0x28558a=D['VALUE_TYPE_ORDER']['indexOf'](_0x5075a9),_0x4be7db=D['VALUE_TYPE_ORDER']['indexOf'](_0x242291);return f(_0x28558a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5075a9),f(_0x4be7db>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x242291),_0x28558a===_0x4be7db?_0x242291==='object'?0x0:this['value_']<_0x36f1e8['value_']?-0x1:this['value_']===_0x36f1e8['value_']?0x0:0x1:_0x4be7db-_0x28558a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2e5165){if(_0x2e5165===this)return!0x0;if(_0x2e5165['isLeafNode']()){const _0x5d3c02=_0x2e5165;return this['value_']===_0x5d3c02['value_']&&this['priorityNode_']['equals'](_0x5d3c02['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x509bfb){Oo=_0x509bfb;}function Wh(_0x3c8eec){Do=_0x3c8eec;}class Bh extends Fn{['compare'](_0x2112ec,_0x1e8d52){const _0x576bb4=_0x2112ec['node']['getPriority'](),_0x424c43=_0x1e8d52['node']['getPriority'](),_0x253125=_0x576bb4['compareTo'](_0x424c43);return _0x253125===0x0?qe(_0x2112ec['name'],_0x1e8d52['name']):_0x253125;}['isDefinedOn'](_0x166cfb){return!_0x166cfb['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x88f287,_0x4ff045){return!_0x88f287['getPriority']()['equals'](_0x4ff045['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x35aac4,_0x1c3557){const _0x42a630=Oo(_0x35aac4);return new E(_0x1c3557,new D('[PRIORITY-POST]',_0x42a630));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x2c25c5){const _0x26cd19=_0x906d6c=>parseInt(Math['log'](_0x906d6c)/Vh,0xa),_0x569367=_0x21fa27=>parseInt(Array(_0x21fa27+0x1)['join']('1'),0x2);this['count']=_0x26cd19(_0x2c25c5+0x1),this['current_']=this['count']-0x1;const _0x293812=_0x569367(this['count']);this['bits_']=_0x2c25c5+0x1&_0x293812;}['nextBitIsOne'](){const _0x54768d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x54768d;}}const yn=function(_0x4b0cea,_0x30d04b,_0x8bb3a4,_0x36f124){_0x4b0cea['sort'](_0x30d04b);const _0x150c41=function(_0x31aa25,_0x3eef4b){const _0xaae19c=_0x3eef4b-_0x31aa25;let _0x26dbaf,_0x4b4303;if(_0xaae19c===0x0)return null;if(_0xaae19c===0x1)return _0x26dbaf=_0x4b0cea[_0x31aa25],_0x4b4303=_0x8bb3a4?_0x8bb3a4(_0x26dbaf):_0x26dbaf,new M(_0x4b4303,_0x26dbaf['node'],M['BLACK'],null,null);{const _0x29ac3f=parseInt(_0xaae19c/0x2,0xa)+_0x31aa25,_0x40cf09=_0x150c41(_0x31aa25,_0x29ac3f),_0x7cc0a9=_0x150c41(_0x29ac3f+0x1,_0x3eef4b);return _0x26dbaf=_0x4b0cea[_0x29ac3f],_0x4b4303=_0x8bb3a4?_0x8bb3a4(_0x26dbaf):_0x26dbaf,new M(_0x4b4303,_0x26dbaf['node'],M['BLACK'],_0x40cf09,_0x7cc0a9);}},_0x24d79c=function(_0x1026f7){let _0x26dff2=null,_0x16a87a=null,_0x31337e=_0x4b0cea['length'];const _0x4f279f=function(_0x394ea2,_0x4ae8b8){const _0xf5d5e0=_0x31337e-_0x394ea2,_0x251309=_0x31337e;_0x31337e-=_0x394ea2;const _0x412753=_0x150c41(_0xf5d5e0+0x1,_0x251309),_0x44157a=_0x4b0cea[_0xf5d5e0],_0x35d38b=_0x8bb3a4?_0x8bb3a4(_0x44157a):_0x44157a;_0xf8b2b1(new M(_0x35d38b,_0x44157a['node'],_0x4ae8b8,null,_0x412753));},_0xf8b2b1=function(_0x13a32c){_0x26dff2?(_0x26dff2['left']=_0x13a32c,_0x26dff2=_0x13a32c):(_0x16a87a=_0x13a32c,_0x26dff2=_0x13a32c);};for(let _0x245ebf=0x0;_0x245ebf<_0x1026f7['count'];++_0x245ebf){const _0x5e4a7a=_0x1026f7['nextBitIsOne'](),_0x13bdcb=Math['pow'](0x2,_0x1026f7['count']-(_0x245ebf+0x1));_0x5e4a7a?_0x4f279f(_0x13bdcb,M['BLACK']):(_0x4f279f(_0x13bdcb,M['BLACK']),_0x4f279f(_0x13bdcb,M['RED']));}return _0x16a87a;},_0x4f5176=new Hh(_0x4b0cea['length']),_0x5063fd=_0x24d79c(_0x4f5176);return new B(_0x36f124||_0x30d04b,_0x5063fd);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x234ad2,_0x367200){this['indexes_']=_0x234ad2,this['indexSet_']=_0x367200;}['get'](_0x13dec9){const _0x1fb37a=Le(this['indexes_'],_0x13dec9);if(!_0x1fb37a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x13dec9);return _0x1fb37a instanceof B?_0x1fb37a:null;}['hasIndex'](_0x4a42e0){return Q(this['indexSet_'],_0x4a42e0['toString']());}['addIndex'](_0x28182d,_0x144871){f(_0x28182d!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x343196=[];let _0x363d4c=!0x1;const _0x41d50c=_0x144871['getIterator'](E['Wrap']);let _0x49cfe7=_0x41d50c['getNext']();for(;_0x49cfe7;)_0x363d4c=_0x363d4c||_0x28182d['isDefinedOn'](_0x49cfe7['node']),_0x343196['push'](_0x49cfe7),_0x49cfe7=_0x41d50c['getNext']();let _0x4367bb;_0x363d4c?_0x4367bb=yn(_0x343196,_0x28182d['getCompare']()):_0x4367bb=Qe;const _0x2aad07=_0x28182d['toString'](),_0x2dfffd={...this['indexSet_']};_0x2dfffd[_0x2aad07]=_0x28182d;const _0x35ce3f={...this['indexes_']};return _0x35ce3f[_0x2aad07]=_0x4367bb,new te(_0x35ce3f,_0x2dfffd);}['addToIndexes'](_0x24adb5,_0x21b9e0){const _0x22f7f1=_n(this['indexes_'],(_0x773d78,_0x7d5725)=>{const _0x2cf1ea=Le(this['indexSet_'],_0x7d5725);if(f(_0x2cf1ea,'Missing\x20index\x20implementation\x20for\x20'+_0x7d5725),_0x773d78===Qe){if(_0x2cf1ea['isDefinedOn'](_0x24adb5['node'])){const _0x325e20=[],_0x2460f5=_0x21b9e0['getIterator'](E['Wrap']);let _0x42332a=_0x2460f5['getNext']();for(;_0x42332a;)_0x42332a['name']!==_0x24adb5['name']&&_0x325e20['push'](_0x42332a),_0x42332a=_0x2460f5['getNext']();return _0x325e20['push'](_0x24adb5),yn(_0x325e20,_0x2cf1ea['getCompare']());}else return Qe;}else{const _0x52ee99=_0x21b9e0['get'](_0x24adb5['name']);let _0x34bc44=_0x773d78;return _0x52ee99&&(_0x34bc44=_0x34bc44['remove'](new E(_0x24adb5['name'],_0x52ee99))),_0x34bc44['insert'](_0x24adb5,_0x24adb5['node']);}});return new te(_0x22f7f1,this['indexSet_']);}['removeFromIndexes'](_0x3bf5f9,_0x4000ec){const _0x195112=_n(this['indexes_'],_0x35d145=>{if(_0x35d145===Qe)return _0x35d145;{const _0x2f3ccd=_0x4000ec['get'](_0x3bf5f9['name']);return _0x2f3ccd?_0x35d145['remove'](new E(_0x3bf5f9['name'],_0x2f3ccd)):_0x35d145;}});return new te(_0x195112,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x219ed4,_0x22f17a,_0x1fe329){this['children_']=_0x219ed4,this['priorityNode_']=_0x22f17a,this['indexMap_']=_0x1fe329,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x46d006){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x46d006,this['indexMap_']);}['getImmediateChild'](_0x4d2d7a){if(_0x4d2d7a==='.priority')return this['getPriority']();{const _0xa2c488=this['children_']['get'](_0x4d2d7a);return _0xa2c488===null?It:_0xa2c488;}}['getChild'](_0x1f9833){const _0x16a326=y(_0x1f9833);return _0x16a326===null?this:this['getImmediateChild'](_0x16a326)['getChild'](S(_0x1f9833));}['hasChild'](_0xf84d06){return this['children_']['get'](_0xf84d06)!==null;}['updateImmediateChild'](_0x5a48ac,_0x31a155){if(f(_0x31a155,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5a48ac==='.priority')return this['updatePriority'](_0x31a155);{const _0x169e1a=new E(_0x5a48ac,_0x31a155);let _0x41bd15,_0x5c1a9d;_0x31a155['isEmpty']()?(_0x41bd15=this['children_']['remove'](_0x5a48ac),_0x5c1a9d=this['indexMap_']['removeFromIndexes'](_0x169e1a,this['children_'])):(_0x41bd15=this['children_']['insert'](_0x5a48ac,_0x31a155),_0x5c1a9d=this['indexMap_']['addToIndexes'](_0x169e1a,this['children_']));const _0x4d4ff9=_0x41bd15['isEmpty']()?It:this['priorityNode_'];return new g(_0x41bd15,_0x4d4ff9,_0x5c1a9d);}}['updateChild'](_0x12236b,_0x1c17b2){const _0x52c6d1=y(_0x12236b);if(_0x52c6d1===null)return _0x1c17b2;{f(y(_0x12236b)!=='.priority'||Ce(_0x12236b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5ba9ea=this['getImmediateChild'](_0x52c6d1)['updateChild'](S(_0x12236b),_0x1c17b2);return this['updateImmediateChild'](_0x52c6d1,_0x5ba9ea);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x52a8bc){if(this['isEmpty']())return null;const _0x1930fc={};let _0x3c884e=0x0,_0x51b088=0x0,_0x4d2a25=!0x0;if(this['forEachChild'](R,(_0x312bad,_0x22aa41)=>{_0x1930fc[_0x312bad]=_0x22aa41['val'](_0x52a8bc),_0x3c884e++,_0x4d2a25&&g['INTEGER_REGEXP_']['test'](_0x312bad)?_0x51b088=Math['max'](_0x51b088,Number(_0x312bad)):_0x4d2a25=!0x1;}),!_0x52a8bc&&_0x4d2a25&&_0x51b088<0x2*_0x3c884e){const _0x26c682=[];for(const _0x2504b2 in _0x1930fc)_0x26c682[_0x2504b2]=_0x1930fc[_0x2504b2];return _0x26c682;}else return _0x52a8bc&&!this['getPriority']()['isEmpty']()&&(_0x1930fc['.priority']=this['getPriority']()['val']()),_0x1930fc;}['hash'](){if(this['lazyHash_']===null){let _0x4ccd0a='';this['getPriority']()['isEmpty']()||(_0x4ccd0a+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4d0c77,_0x2def27)=>{const _0x56f208=_0x2def27['hash']();_0x56f208!==''&&(_0x4ccd0a+=':'+_0x4d0c77+':'+_0x56f208);}),this['lazyHash_']=_0x4ccd0a===''?'':ro(_0x4ccd0a);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3bc966,_0x3040da,_0x3f6117){const _0x11ac55=this['resolveIndex_'](_0x3f6117);if(_0x11ac55){const _0x16a864=_0x11ac55['getPredecessorKey'](new E(_0x3bc966,_0x3040da));return _0x16a864?_0x16a864['name']:null;}else return this['children_']['getPredecessorKey'](_0x3bc966);}['getFirstChildName'](_0x516013){const _0x1de617=this['resolveIndex_'](_0x516013);if(_0x1de617){const _0x2e8f86=_0x1de617['minKey']();return _0x2e8f86&&_0x2e8f86['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x20e2be){const _0x3d2c62=this['getFirstChildName'](_0x20e2be);return _0x3d2c62?new E(_0x3d2c62,this['children_']['get'](_0x3d2c62)):null;}['getLastChildName'](_0x169085){const _0x9dbfec=this['resolveIndex_'](_0x169085);if(_0x9dbfec){const _0x4916ab=_0x9dbfec['maxKey']();return _0x4916ab&&_0x4916ab['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x459265){const _0x1691e8=this['getLastChildName'](_0x459265);return _0x1691e8?new E(_0x1691e8,this['children_']['get'](_0x1691e8)):null;}['forEachChild'](_0x281944,_0x57c385){const _0x54c7cb=this['resolveIndex_'](_0x281944);return _0x54c7cb?_0x54c7cb['inorderTraversal'](_0x28c4bc=>_0x57c385(_0x28c4bc['name'],_0x28c4bc['node'])):this['children_']['inorderTraversal'](_0x57c385);}['getIterator'](_0x11194d){return this['getIteratorFrom'](_0x11194d['minPost'](),_0x11194d);}['getIteratorFrom'](_0xe3c2e3,_0x4f8c24){const _0xf246c2=this['resolveIndex_'](_0x4f8c24);if(_0xf246c2)return _0xf246c2['getIteratorFrom'](_0xe3c2e3,_0x5e98a5=>_0x5e98a5);{const _0x230c92=this['children_']['getIteratorFrom'](_0xe3c2e3['name'],E['Wrap']);let _0xdfab8e=_0x230c92['peek']();for(;_0xdfab8e!=null&&_0x4f8c24['compare'](_0xdfab8e,_0xe3c2e3)<0x0;)_0x230c92['getNext'](),_0xdfab8e=_0x230c92['peek']();return _0x230c92;}}['getReverseIterator'](_0x1aeac1){return this['getReverseIteratorFrom'](_0x1aeac1['maxPost'](),_0x1aeac1);}['getReverseIteratorFrom'](_0x20ecb2,_0xdca07a){const _0x242a0d=this['resolveIndex_'](_0xdca07a);if(_0x242a0d)return _0x242a0d['getReverseIteratorFrom'](_0x20ecb2,_0x1793c0=>_0x1793c0);{const _0x504928=this['children_']['getReverseIteratorFrom'](_0x20ecb2['name'],E['Wrap']);let _0x4c6b5d=_0x504928['peek']();for(;_0x4c6b5d!=null&&_0xdca07a['compare'](_0x4c6b5d,_0x20ecb2)>0x0;)_0x504928['getNext'](),_0x4c6b5d=_0x504928['peek']();return _0x504928;}}['compareTo'](_0x4a8e37){return this['isEmpty']()?_0x4a8e37['isEmpty']()?0x0:-0x1:_0x4a8e37['isLeafNode']()||_0x4a8e37['isEmpty']()?0x1:_0x4a8e37===Kt?-0x1:0x0;}['withIndex'](_0x34fe10){if(_0x34fe10===ve||this['indexMap_']['hasIndex'](_0x34fe10))return this;{const _0x17e7b8=this['indexMap_']['addIndex'](_0x34fe10,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x17e7b8);}}['isIndexed'](_0x46b8cb){return _0x46b8cb===ve||this['indexMap_']['hasIndex'](_0x46b8cb);}['equals'](_0x5b4764){if(_0x5b4764===this)return!0x0;if(_0x5b4764['isLeafNode']())return!0x1;{const _0x415065=_0x5b4764;if(this['getPriority']()['equals'](_0x415065['getPriority']())){if(this['children_']['count']()===_0x415065['children_']['count']()){const _0x5a0401=this['getIterator'](R),_0x2a3799=_0x415065['getIterator'](R);let _0x54f68a=_0x5a0401['getNext'](),_0x264751=_0x2a3799['getNext']();for(;_0x54f68a&&_0x264751;){if(_0x54f68a['name']!==_0x264751['name']||!_0x54f68a['node']['equals'](_0x264751['node']))return!0x1;_0x54f68a=_0x5a0401['getNext'](),_0x264751=_0x2a3799['getNext']();}return _0x54f68a===null&&_0x264751===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4c6baa){return _0x4c6baa===ve?null:this['indexMap_']['get'](_0x4c6baa['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xe0a169){return _0xe0a169===this?0x0:0x1;}['equals'](_0x48288c){return _0x48288c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4b27b2){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x7fa3f3,_0x3c096c=null){if(_0x7fa3f3===null)return g['EMPTY_NODE'];if(typeof _0x7fa3f3=='object'&&'.priority'in _0x7fa3f3&&(_0x3c096c=_0x7fa3f3['.priority']),f(_0x3c096c===null||typeof _0x3c096c=='string'||typeof _0x3c096c=='number'||typeof _0x3c096c=='object'&&'.sv'in _0x3c096c,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3c096c),typeof _0x7fa3f3=='object'&&'.value'in _0x7fa3f3&&_0x7fa3f3['.value']!==null&&(_0x7fa3f3=_0x7fa3f3['.value']),typeof _0x7fa3f3!='object'||'.sv'in _0x7fa3f3){const _0x222c00=_0x7fa3f3;return new D(_0x222c00,A(_0x3c096c));}if(!(_0x7fa3f3 instanceof Array)&&Gh){const _0xa49a69=[];let _0x31846f=!0x1;if(x(_0x7fa3f3,(_0x25818f,_0x2a87cc)=>{if(_0x25818f['substring'](0x0,0x1)!=='.'){const _0x25e48c=A(_0x2a87cc);_0x25e48c['isEmpty']()||(_0x31846f=_0x31846f||!_0x25e48c['getPriority']()['isEmpty'](),_0xa49a69['push'](new E(_0x25818f,_0x25e48c)));}}),_0xa49a69['length']===0x0)return g['EMPTY_NODE'];const _0x3cd022=yn(_0xa49a69,xh,_0x35fe5a=>_0x35fe5a['name'],Qi);if(_0x31846f){const _0x304eab=yn(_0xa49a69,R['getCompare']());return new g(_0x3cd022,A(_0x3c096c),new te({'.priority':_0x304eab},{'.priority':R}));}else return new g(_0x3cd022,A(_0x3c096c),te['Default']);}else{let _0x532409=g['EMPTY_NODE'];return x(_0x7fa3f3,(_0x12f4e2,_0x3494be)=>{if(Q(_0x7fa3f3,_0x12f4e2)&&_0x12f4e2['substring'](0x0,0x1)!=='.'){const _0x34db52=A(_0x3494be);(_0x34db52['isLeafNode']()||!_0x34db52['isEmpty']())&&(_0x532409=_0x532409['updateImmediateChild'](_0x12f4e2,_0x34db52));}}),_0x532409['updatePriority'](A(_0x3c096c));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x46cdff){super(),this['indexPath_']=_0x46cdff,f(!v(_0x46cdff)&&y(_0x46cdff)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xbe5469){return _0xbe5469['getChild'](this['indexPath_']);}['isDefinedOn'](_0x22fb06){return!_0x22fb06['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1ce25d,_0x561bf7){const _0x3f95a7=this['extractChild'](_0x1ce25d['node']),_0x4beb13=this['extractChild'](_0x561bf7['node']),_0x20bd99=_0x3f95a7['compareTo'](_0x4beb13);return _0x20bd99===0x0?qe(_0x1ce25d['name'],_0x561bf7['name']):_0x20bd99;}['makePost'](_0x2583fb,_0x16a0ee){const _0x323fb9=A(_0x2583fb),_0x18019a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x323fb9);return new E(_0x16a0ee,_0x18019a);}['maxPost'](){const _0x3b2c58=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x3b2c58);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x2b20d4,_0x56bcb8){const _0x5965a9=_0x2b20d4['node']['compareTo'](_0x56bcb8['node']);return _0x5965a9===0x0?qe(_0x2b20d4['name'],_0x56bcb8['name']):_0x5965a9;}['isDefinedOn'](_0x267593){return!0x0;}['indexedValueChanged'](_0x4a622d,_0x2ecab5){return!_0x4a622d['equals'](_0x2ecab5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4855bf,_0x2bcaf4){const _0x421c69=A(_0x4855bf);return new E(_0x2bcaf4,_0x421c69);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x36863e){return{'type':'value','snapshotNode':_0x36863e};}function rt(_0x157a38,_0x517228){return{'type':'child_added','snapshotNode':_0x517228,'childName':_0x157a38};}function Lt(_0x37d916,_0x248c63){return{'type':'child_removed','snapshotNode':_0x248c63,'childName':_0x37d916};}function xt(_0x3ff1ac,_0x572d46,_0xd74b5d){return{'type':'child_changed','snapshotNode':_0x572d46,'childName':_0x3ff1ac,'oldSnap':_0xd74b5d};}function zh(_0x423d34,_0x11e98d){return{'type':'child_moved','snapshotNode':_0x11e98d,'childName':_0x423d34};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x428f5b){this['index_']=_0x428f5b;}['updateChild'](_0x3c3488,_0x5ed6d4,_0x1e994e,_0x30e8f3,_0x2ea2d2,_0x5bde33){f(_0x3c3488['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x368b9d=_0x3c3488['getImmediateChild'](_0x5ed6d4);return _0x368b9d['getChild'](_0x30e8f3)['equals'](_0x1e994e['getChild'](_0x30e8f3))&&_0x368b9d['isEmpty']()===_0x1e994e['isEmpty']()||(_0x5bde33!=null&&(_0x1e994e['isEmpty']()?_0x3c3488['hasChild'](_0x5ed6d4)?_0x5bde33['trackChildChange'](Lt(_0x5ed6d4,_0x368b9d)):f(_0x3c3488['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x368b9d['isEmpty']()?_0x5bde33['trackChildChange'](rt(_0x5ed6d4,_0x1e994e)):_0x5bde33['trackChildChange'](xt(_0x5ed6d4,_0x1e994e,_0x368b9d))),_0x3c3488['isLeafNode']()&&_0x1e994e['isEmpty']())?_0x3c3488:_0x3c3488['updateImmediateChild'](_0x5ed6d4,_0x1e994e)['withIndex'](this['index_']);}['updateFullNode'](_0x3d21b0,_0x2a551f,_0x1e0bac){return _0x1e0bac!=null&&(_0x3d21b0['isLeafNode']()||_0x3d21b0['forEachChild'](R,(_0x2853c6,_0x21a79a)=>{_0x2a551f['hasChild'](_0x2853c6)||_0x1e0bac['trackChildChange'](Lt(_0x2853c6,_0x21a79a));}),_0x2a551f['isLeafNode']()||_0x2a551f['forEachChild'](R,(_0x2b7e41,_0x2695c2)=>{if(_0x3d21b0['hasChild'](_0x2b7e41)){const _0x3fcfce=_0x3d21b0['getImmediateChild'](_0x2b7e41);_0x3fcfce['equals'](_0x2695c2)||_0x1e0bac['trackChildChange'](xt(_0x2b7e41,_0x2695c2,_0x3fcfce));}else _0x1e0bac['trackChildChange'](rt(_0x2b7e41,_0x2695c2));})),_0x2a551f['withIndex'](this['index_']);}['updatePriority'](_0x424a1d,_0x325e3e){return _0x424a1d['isEmpty']()?g['EMPTY_NODE']:_0x424a1d['updatePriority'](_0x325e3e);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x17c14d){this['indexedFilter_']=new Xi(_0x17c14d['getIndex']()),this['index_']=_0x17c14d['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x17c14d),this['endPost_']=Ft['getEndPost_'](_0x17c14d),this['startIsInclusive_']=!_0x17c14d['startAfterSet_'],this['endIsInclusive_']=!_0x17c14d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3e134a){const _0x50989b=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3e134a)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3e134a)<0x0,_0xce5b9=this['endIsInclusive_']?this['index_']['compare'](_0x3e134a,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3e134a,this['getEndPost']())<0x0;return _0x50989b&&_0xce5b9;}['updateChild'](_0x4c3774,_0x3bc965,_0x4ad233,_0x2776aa,_0x32a3b8,_0x161541){return this['matches'](new E(_0x3bc965,_0x4ad233))||(_0x4ad233=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4c3774,_0x3bc965,_0x4ad233,_0x2776aa,_0x32a3b8,_0x161541);}['updateFullNode'](_0x11d5f1,_0x47170c,_0x27341c){_0x47170c['isLeafNode']()&&(_0x47170c=g['EMPTY_NODE']);let _0xb9943c=_0x47170c['withIndex'](this['index_']);_0xb9943c=_0xb9943c['updatePriority'](g['EMPTY_NODE']);const _0x1d4cdb=this;return _0x47170c['forEachChild'](R,(_0xda7dca,_0x56529b)=>{_0x1d4cdb['matches'](new E(_0xda7dca,_0x56529b))||(_0xb9943c=_0xb9943c['updateImmediateChild'](_0xda7dca,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x11d5f1,_0xb9943c,_0x27341c);}['updatePriority'](_0x26ca9f,_0x2a2d4f){return _0x26ca9f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x535e73){if(_0x535e73['hasStart']()){const _0x2de1c2=_0x535e73['getIndexStartName']();return _0x535e73['getIndex']()['makePost'](_0x535e73['getIndexStartValue'](),_0x2de1c2);}else return _0x535e73['getIndex']()['minPost']();}static['getEndPost_'](_0x26cc0f){if(_0x26cc0f['hasEnd']()){const _0x16a68d=_0x26cc0f['getIndexEndName']();return _0x26cc0f['getIndex']()['makePost'](_0x26cc0f['getIndexEndValue'](),_0x16a68d);}else return _0x26cc0f['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x57a2a6){this['withinDirectionalStart']=_0x42a18d=>this['reverse_']?this['withinEndPost'](_0x42a18d):this['withinStartPost'](_0x42a18d),this['withinDirectionalEnd']=_0x3a9dc7=>this['reverse_']?this['withinStartPost'](_0x3a9dc7):this['withinEndPost'](_0x3a9dc7),this['withinStartPost']=_0x2d18d1=>{const _0x4e4193=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2d18d1);return this['startIsInclusive_']?_0x4e4193<=0x0:_0x4e4193<0x0;},this['withinEndPost']=_0x54c710=>{const _0x2e1b6e=this['index_']['compare'](_0x54c710,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2e1b6e<=0x0:_0x2e1b6e<0x0;},this['rangedFilter_']=new Ft(_0x57a2a6),this['index_']=_0x57a2a6['getIndex'](),this['limit_']=_0x57a2a6['getLimit'](),this['reverse_']=!_0x57a2a6['isViewFromLeft'](),this['startIsInclusive_']=!_0x57a2a6['startAfterSet_'],this['endIsInclusive_']=!_0x57a2a6['endBeforeSet_'];}['updateChild'](_0x31ff29,_0x465c1d,_0x4d13b7,_0xa2a431,_0x18c783,_0x572b16){return this['rangedFilter_']['matches'](new E(_0x465c1d,_0x4d13b7))||(_0x4d13b7=g['EMPTY_NODE']),_0x31ff29['getImmediateChild'](_0x465c1d)['equals'](_0x4d13b7)?_0x31ff29:_0x31ff29['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x31ff29,_0x465c1d,_0x4d13b7,_0xa2a431,_0x18c783,_0x572b16):this['fullLimitUpdateChild_'](_0x31ff29,_0x465c1d,_0x4d13b7,_0x18c783,_0x572b16);}['updateFullNode'](_0x574192,_0x46e508,_0x135544){let _0x4a375c;if(_0x46e508['isLeafNode']()||_0x46e508['isEmpty']())_0x4a375c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x46e508['numChildren']()&&_0x46e508['isIndexed'](this['index_'])){_0x4a375c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5714cc;this['reverse_']?_0x5714cc=_0x46e508['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5714cc=_0x46e508['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x29491a=0x0;for(;_0x5714cc['hasNext']()&&_0x29491a<this['limit_'];){const _0xebea99=_0x5714cc['getNext']();if(this['withinDirectionalStart'](_0xebea99)){if(this['withinDirectionalEnd'](_0xebea99))_0x4a375c=_0x4a375c['updateImmediateChild'](_0xebea99['name'],_0xebea99['node']),_0x29491a++;else break;}else continue;}}else{_0x4a375c=_0x46e508['withIndex'](this['index_']),_0x4a375c=_0x4a375c['updatePriority'](g['EMPTY_NODE']);let _0x1ae11a;this['reverse_']?_0x1ae11a=_0x4a375c['getReverseIterator'](this['index_']):_0x1ae11a=_0x4a375c['getIterator'](this['index_']);let _0x2e74c8=0x0;for(;_0x1ae11a['hasNext']();){const _0x1e656a=_0x1ae11a['getNext']();_0x2e74c8<this['limit_']&&this['withinDirectionalStart'](_0x1e656a)&&this['withinDirectionalEnd'](_0x1e656a)?_0x2e74c8++:_0x4a375c=_0x4a375c['updateImmediateChild'](_0x1e656a['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x574192,_0x4a375c,_0x135544);}['updatePriority'](_0x264a28,_0x300fb1){return _0x264a28;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x424e48,_0x28848e,_0x4f9e7d,_0x20cfc5,_0x4a2b18){let _0x28726b;if(this['reverse_']){const _0x5bcd50=this['index_']['getCompare']();_0x28726b=(_0x21b6a1,_0x6c9a44)=>_0x5bcd50(_0x6c9a44,_0x21b6a1);}else _0x28726b=this['index_']['getCompare']();const _0x1beddf=_0x424e48;f(_0x1beddf['numChildren']()===this['limit_'],'');const _0x141fcd=new E(_0x28848e,_0x4f9e7d),_0x541cb3=this['reverse_']?_0x1beddf['getFirstChild'](this['index_']):_0x1beddf['getLastChild'](this['index_']),_0x47f095=this['rangedFilter_']['matches'](_0x141fcd);if(_0x1beddf['hasChild'](_0x28848e)){const _0xf949cb=_0x1beddf['getImmediateChild'](_0x28848e);let _0x7caceb=_0x20cfc5['getChildAfterChild'](this['index_'],_0x541cb3,this['reverse_']);for(;_0x7caceb!=null&&(_0x7caceb['name']===_0x28848e||_0x1beddf['hasChild'](_0x7caceb['name']));)_0x7caceb=_0x20cfc5['getChildAfterChild'](this['index_'],_0x7caceb,this['reverse_']);const _0x569f94=_0x7caceb==null?0x1:_0x28726b(_0x7caceb,_0x141fcd);if(_0x47f095&&!_0x4f9e7d['isEmpty']()&&_0x569f94>=0x0)return _0x4a2b18!=null&&_0x4a2b18['trackChildChange'](xt(_0x28848e,_0x4f9e7d,_0xf949cb)),_0x1beddf['updateImmediateChild'](_0x28848e,_0x4f9e7d);{_0x4a2b18!=null&&_0x4a2b18['trackChildChange'](Lt(_0x28848e,_0xf949cb));const _0x500fb3=_0x1beddf['updateImmediateChild'](_0x28848e,g['EMPTY_NODE']);return _0x7caceb!=null&&this['rangedFilter_']['matches'](_0x7caceb)?(_0x4a2b18!=null&&_0x4a2b18['trackChildChange'](rt(_0x7caceb['name'],_0x7caceb['node'])),_0x500fb3['updateImmediateChild'](_0x7caceb['name'],_0x7caceb['node'])):_0x500fb3;}}else return _0x4f9e7d['isEmpty']()?_0x424e48:_0x47f095&&_0x28726b(_0x541cb3,_0x141fcd)>=0x0?(_0x4a2b18!=null&&(_0x4a2b18['trackChildChange'](Lt(_0x541cb3['name'],_0x541cb3['node'])),_0x4a2b18['trackChildChange'](rt(_0x28848e,_0x4f9e7d))),_0x1beddf['updateImmediateChild'](_0x28848e,_0x4f9e7d)['updateImmediateChild'](_0x541cb3['name'],g['EMPTY_NODE'])):_0x424e48;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x254847=new Zi();return _0x254847['limitSet_']=this['limitSet_'],_0x254847['limit_']=this['limit_'],_0x254847['startSet_']=this['startSet_'],_0x254847['startAfterSet_']=this['startAfterSet_'],_0x254847['indexStartValue_']=this['indexStartValue_'],_0x254847['startNameSet_']=this['startNameSet_'],_0x254847['indexStartName_']=this['indexStartName_'],_0x254847['endSet_']=this['endSet_'],_0x254847['endBeforeSet_']=this['endBeforeSet_'],_0x254847['indexEndValue_']=this['indexEndValue_'],_0x254847['endNameSet_']=this['endNameSet_'],_0x254847['indexEndName_']=this['indexEndName_'],_0x254847['index_']=this['index_'],_0x254847['viewFrom_']=this['viewFrom_'],_0x254847;}}function Kh(_0x415c46){return _0x415c46['loadsAllData']()?new Xi(_0x415c46['getIndex']()):_0x415c46['hasLimit']()?new jh(_0x415c46):new Ft(_0x415c46);}function Yh(_0x5b39c5,_0x4e7c27){const _0x5d01ba=_0x5b39c5['copy']();return _0x5d01ba['limitSet_']=!0x0,_0x5d01ba['limit_']=_0x4e7c27,_0x5d01ba['viewFrom_']='l',_0x5d01ba;}function Qh(_0x811ec5,_0x2d12a7,_0x2ebdfd){const _0x453aee=_0x811ec5['copy']();return _0x453aee['startSet_']=!0x0,_0x2d12a7===void 0x0&&(_0x2d12a7=null),_0x453aee['indexStartValue_']=_0x2d12a7,_0x2ebdfd!=null?(_0x453aee['startNameSet_']=!0x0,_0x453aee['indexStartName_']=_0x2ebdfd):(_0x453aee['startNameSet_']=!0x1,_0x453aee['indexStartName_']=''),_0x453aee;}function Jh(_0x4f6f26,_0x77531a,_0x2e4364){const _0xf4ad79=_0x4f6f26['copy']();return _0xf4ad79['endSet_']=!0x0,_0x77531a===void 0x0&&(_0x77531a=null),_0xf4ad79['indexEndValue_']=_0x77531a,_0x2e4364!==void 0x0?(_0xf4ad79['endNameSet_']=!0x0,_0xf4ad79['indexEndName_']=_0x2e4364):(_0xf4ad79['endNameSet_']=!0x1,_0xf4ad79['indexEndName_']=''),_0xf4ad79;}function xo(_0x5a32d0,_0x46160a){const _0x496171=_0x5a32d0['copy']();return _0x496171['index_']=_0x46160a,_0x496171;}function ir(_0x58b336){const _0x29c0f1={};if(_0x58b336['isDefault']())return _0x29c0f1;let _0x1f5c49;if(_0x58b336['index_']===R?_0x1f5c49='$priority':_0x58b336['index_']===Mo?_0x1f5c49='$value':_0x58b336['index_']===ve?_0x1f5c49='$key':(f(_0x58b336['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1f5c49=_0x58b336['index_']['toString']()),_0x29c0f1['orderBy']=O(_0x1f5c49),_0x58b336['startSet_']){const _0x1f5aee=_0x58b336['startAfterSet_']?'startAfter':'startAt';_0x29c0f1[_0x1f5aee]=O(_0x58b336['indexStartValue_']),_0x58b336['startNameSet_']&&(_0x29c0f1[_0x1f5aee]+=','+O(_0x58b336['indexStartName_']));}if(_0x58b336['endSet_']){const _0x2fdbfd=_0x58b336['endBeforeSet_']?'endBefore':'endAt';_0x29c0f1[_0x2fdbfd]=O(_0x58b336['indexEndValue_']),_0x58b336['endNameSet_']&&(_0x29c0f1[_0x2fdbfd]+=','+O(_0x58b336['indexEndName_']));}return _0x58b336['limitSet_']&&(_0x58b336['isViewFromLeft']()?_0x29c0f1['limitToFirst']=_0x58b336['limit_']:_0x29c0f1['limitToLast']=_0x58b336['limit_']),_0x29c0f1;}function sr(_0x58f708){const _0x53607a={};if(_0x58f708['startSet_']&&(_0x53607a['sp']=_0x58f708['indexStartValue_'],_0x58f708['startNameSet_']&&(_0x53607a['sn']=_0x58f708['indexStartName_']),_0x53607a['sin']=!_0x58f708['startAfterSet_']),_0x58f708['endSet_']&&(_0x53607a['ep']=_0x58f708['indexEndValue_'],_0x58f708['endNameSet_']&&(_0x53607a['en']=_0x58f708['indexEndName_']),_0x53607a['ein']=!_0x58f708['endBeforeSet_']),_0x58f708['limitSet_']){_0x53607a['l']=_0x58f708['limit_'];let _0x5ee42d=_0x58f708['viewFrom_'];_0x5ee42d===''&&(_0x58f708['isViewFromLeft']()?_0x5ee42d='l':_0x5ee42d='r'),_0x53607a['vf']=_0x5ee42d;}return _0x58f708['index_']!==R&&(_0x53607a['i']=_0x58f708['index_']['toString']()),_0x53607a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2764ba){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x15ffb2,_0x3a43ac){return _0x3a43ac!==void 0x0?'tag$'+_0x3a43ac:(f(_0x15ffb2['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x15ffb2['_path']['toString']());}constructor(_0x51e493,_0x277d8c,_0x72c4d9,_0x44164d){super(),this['repoInfo_']=_0x51e493,this['onDataUpdate_']=_0x277d8c,this['authTokenProvider_']=_0x72c4d9,this['appCheckTokenProvider_']=_0x44164d,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1d55ae,_0x300224,_0x2e32fc,_0x46b669){const _0x1499a3=_0x1d55ae['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1499a3+'\x20'+_0x1d55ae['_queryIdentifier']);const _0x30992c=vn['getListenId_'](_0x1d55ae,_0x2e32fc),_0x4f571e={};this['listens_'][_0x30992c]=_0x4f571e;const _0x2b9eac=ir(_0x1d55ae['_queryParams']);this['restRequest_'](_0x1499a3+'.json',_0x2b9eac,(_0x406d7c,_0xcbb2a7)=>{let _0x484186=_0xcbb2a7;if(_0x406d7c===0x194&&(_0x484186=null,_0x406d7c=null),_0x406d7c===null&&this['onDataUpdate_'](_0x1499a3,_0x484186,!0x1,_0x2e32fc),Le(this['listens_'],_0x30992c)===_0x4f571e){let _0x48e1f6;_0x406d7c?_0x406d7c===0x191?_0x48e1f6='permission_denied':_0x48e1f6='rest_error:'+_0x406d7c:_0x48e1f6='ok',_0x46b669(_0x48e1f6,null);}});}['unlisten'](_0x237fce,_0x6e3818){const _0x5cf16d=vn['getListenId_'](_0x237fce,_0x6e3818);delete this['listens_'][_0x5cf16d];}['get'](_0x4421f6){const _0x1589f6=ir(_0x4421f6['_queryParams']),_0x3ee412=_0x4421f6['_path']['toString'](),_0x395978=new H();return this['restRequest_'](_0x3ee412+'.json',_0x1589f6,(_0x2e5808,_0x15f021)=>{let _0x3b6eea=_0x15f021;_0x2e5808===0x194&&(_0x3b6eea=null,_0x2e5808=null),_0x2e5808===null?(this['onDataUpdate_'](_0x3ee412,_0x3b6eea,!0x1,null),_0x395978['resolve'](_0x3b6eea)):_0x395978['reject'](new Error(_0x3b6eea));}),_0x395978['promise'];}['refreshAuthToken'](_0x498b96){}['restRequest_'](_0x237588,_0x21fef7={},_0x5589d2){return _0x21fef7['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x8d0cf2,_0x40ee59])=>{_0x8d0cf2&&_0x8d0cf2['accessToken']&&(_0x21fef7['auth']=_0x8d0cf2['accessToken']),_0x40ee59&&_0x40ee59['token']&&(_0x21fef7['ac']=_0x40ee59['token']);const _0x1a059f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x237588+'?ns='+this['repoInfo_']['namespace']+ut(_0x21fef7);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1a059f);const _0x49ce69=new XMLHttpRequest();_0x49ce69['onreadystatechange']=()=>{if(_0x5589d2&&_0x49ce69['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1a059f+'\x20received.\x20status:',_0x49ce69['status'],'response:',_0x49ce69['responseText']);let _0x361577=null;if(_0x49ce69['status']>=0xc8&&_0x49ce69['status']<0x12c){try{_0x361577=Nt(_0x49ce69['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1a059f+':\x20'+_0x49ce69['responseText']);}_0x5589d2(null,_0x361577);}else _0x49ce69['status']!==0x191&&_0x49ce69['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1a059f+'\x20Status:\x20'+_0x49ce69['status']),_0x5589d2(_0x49ce69['status']);_0x5589d2=null;}},_0x49ce69['open']('GET',_0x1a059f,!0x0),_0x49ce69['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5e0f77){return this['rootNode_']['getChild'](_0x5e0f77);}['updateSnapshot'](_0x31ec53,_0x1a5edc){this['rootNode_']=this['rootNode_']['updateChild'](_0x31ec53,_0x1a5edc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2b9101,_0x4278c1,_0x1d099b){if(v(_0x4278c1))_0x2b9101['value']=_0x1d099b,_0x2b9101['children']['clear']();else{if(_0x2b9101['value']!==null)_0x2b9101['value']=_0x2b9101['value']['updateChild'](_0x4278c1,_0x1d099b);else{const _0x34627c=y(_0x4278c1);_0x2b9101['children']['has'](_0x34627c)||_0x2b9101['children']['set'](_0x34627c,En());const _0x1a7d4d=_0x2b9101['children']['get'](_0x34627c);_0x4278c1=S(_0x4278c1),pt(_0x1a7d4d,_0x4278c1,_0x1d099b);}}}function Ti(_0x32020c,_0x14ae09){if(v(_0x14ae09))return _0x32020c['value']=null,_0x32020c['children']['clear'](),!0x0;if(_0x32020c['value']!==null){if(_0x32020c['value']['isLeafNode']())return!0x1;{const _0x20a95e=_0x32020c['value'];return _0x32020c['value']=null,_0x20a95e['forEachChild'](R,(_0x3a6bb3,_0x4ec573)=>{pt(_0x32020c,new C(_0x3a6bb3),_0x4ec573);}),Ti(_0x32020c,_0x14ae09);}}else{if(_0x32020c['children']['size']>0x0){const _0x114521=y(_0x14ae09);return _0x14ae09=S(_0x14ae09),_0x32020c['children']['has'](_0x114521)&&Ti(_0x32020c['children']['get'](_0x114521),_0x14ae09)&&_0x32020c['children']['delete'](_0x114521),_0x32020c['children']['size']===0x0;}else return!0x0;}}function Si(_0x2be58f,_0xf3160,_0x50368a){_0x2be58f['value']!==null?_0x50368a(_0xf3160,_0x2be58f['value']):Zh(_0x2be58f,(_0x4b26f6,_0x55ec3e)=>{const _0x1fb6b1=new C(_0xf3160['toString']()+'/'+_0x4b26f6);Si(_0x55ec3e,_0x1fb6b1,_0x50368a);});}function Zh(_0x396e05,_0x37a31c){_0x396e05['children']['forEach']((_0x1609a3,_0x1d9d11)=>{_0x37a31c(_0x1d9d11,_0x1609a3);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1974bc){this['collection_']=_0x1974bc,this['last_']=null;}['get'](){const _0x325db1=this['collection_']['get'](),_0x411d1e={..._0x325db1};return this['last_']&&x(this['last_'],(_0x515b1a,_0x18ee46)=>{_0x411d1e[_0x515b1a]=_0x411d1e[_0x515b1a]-_0x18ee46;}),this['last_']=_0x325db1,_0x411d1e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x36f872,_0x1394f7){this['server_']=_0x1394f7,this['statsToReport_']={},this['statsListener_']=new eu(_0x36f872);const _0x31c1f6=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x31c1f6));}['reportStats_'](){const _0x5537f2=this['statsListener_']['get'](),_0x5bac42={};let _0x575fd9=!0x1;x(_0x5537f2,(_0x3cbb5c,_0xce7223)=>{_0xce7223>0x0&&Q(this['statsToReport_'],_0x3cbb5c)&&(_0x5bac42[_0x3cbb5c]=_0xce7223,_0x575fd9=!0x0);}),_0x575fd9&&this['server_']['reportStats'](_0x5bac42),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x3d7741){_0x3d7741[_0x3d7741['OVERWRITE']=0x0]='OVERWRITE',_0x3d7741[_0x3d7741['MERGE']=0x1]='MERGE',_0x3d7741[_0x3d7741['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3d7741[_0x3d7741['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1a72e8){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1a72e8,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xb09c2e,_0x19bdb2,_0x1a9db2){this['path']=_0xb09c2e,this['affectedTree']=_0x19bdb2,this['revert']=_0x1a9db2,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x7e3ef8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x274c73=this['affectedTree']['subtree'](new C(_0x7e3ef8));return new In(w(),_0x274c73,this['revert']);}}else return f(y(this['path'])===_0x7e3ef8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3e8182,_0x236d9c){this['source']=_0x3e8182,this['path']=_0x236d9c,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x2bd275){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x7f6a25,_0x37b508,_0x17fd31){this['source']=_0x7f6a25,this['path']=_0x37b508,this['snap']=_0x17fd31,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3c1d8d){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3c1d8d)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x5007ab,_0xd28bb0,_0x21133e){this['source']=_0x5007ab,this['path']=_0xd28bb0,this['children']=_0x21133e,this['type']=z['MERGE'];}['operationForChild'](_0x3c190d){if(v(this['path'])){const _0x1daebe=this['children']['subtree'](new C(_0x3c190d));return _0x1daebe['isEmpty']()?null:_0x1daebe['value']?new Be(this['source'],w(),_0x1daebe['value']):new ot(this['source'],w(),_0x1daebe);}else return f(y(this['path'])===_0x3c190d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2df531,_0x31ad0f,_0x11bce7){this['node_']=_0x2df531,this['fullyInitialized_']=_0x31ad0f,this['filtered_']=_0x11bce7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1d0a96){if(v(_0x1d0a96))return this['isFullyInitialized']()&&!this['filtered_'];const _0x234f75=y(_0x1d0a96);return this['isCompleteForChild'](_0x234f75);}['isCompleteForChild'](_0x269e48){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x269e48);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x294d97){this['query_']=_0x294d97,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x33d7d7,_0x40e093,_0x4ed0dc,_0x4ec233){const _0x480977=[],_0x3a2ec8=[];return _0x40e093['forEach'](_0x5b23b1=>{_0x5b23b1['type']==='child_changed'&&_0x33d7d7['index_']['indexedValueChanged'](_0x5b23b1['oldSnap'],_0x5b23b1['snapshotNode'])&&_0x3a2ec8['push'](zh(_0x5b23b1['childName'],_0x5b23b1['snapshotNode']));}),wt(_0x33d7d7,_0x480977,'child_removed',_0x40e093,_0x4ec233,_0x4ed0dc),wt(_0x33d7d7,_0x480977,'child_added',_0x40e093,_0x4ec233,_0x4ed0dc),wt(_0x33d7d7,_0x480977,'child_moved',_0x3a2ec8,_0x4ec233,_0x4ed0dc),wt(_0x33d7d7,_0x480977,'child_changed',_0x40e093,_0x4ec233,_0x4ed0dc),wt(_0x33d7d7,_0x480977,'value',_0x40e093,_0x4ec233,_0x4ed0dc),_0x480977;}function wt(_0x52cf81,_0x5a03ac,_0x5ab565,_0x55c589,_0x31a3d4,_0x542f5c){const _0x4604d8=_0x55c589['filter'](_0x3c5f56=>_0x3c5f56['type']===_0x5ab565);_0x4604d8['sort']((_0xdccba4,_0x43f286)=>au(_0x52cf81,_0xdccba4,_0x43f286)),_0x4604d8['forEach'](_0x5f7e8b=>{const _0x409c21=ou(_0x52cf81,_0x5f7e8b,_0x542f5c);_0x31a3d4['forEach'](_0x499056=>{_0x499056['respondsTo'](_0x5f7e8b['type'])&&_0x5a03ac['push'](_0x499056['createEvent'](_0x409c21,_0x52cf81['query_']));});});}function ou(_0xcf9c30,_0x45dd9f,_0x1a7b86){return _0x45dd9f['type']==='value'||_0x45dd9f['type']==='child_removed'||(_0x45dd9f['prevName']=_0x1a7b86['getPredecessorChildName'](_0x45dd9f['childName'],_0x45dd9f['snapshotNode'],_0xcf9c30['index_'])),_0x45dd9f;}function au(_0x5a88d5,_0x5c4adb,_0x185e99){if(_0x5c4adb['childName']==null||_0x185e99['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1ff09a=new E(_0x5c4adb['childName'],_0x5c4adb['snapshotNode']),_0x24308b=new E(_0x185e99['childName'],_0x185e99['snapshotNode']);return _0x5a88d5['index_']['compare'](_0x1ff09a,_0x24308b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x1ba58d,_0x2c404a){return{'eventCache':_0x1ba58d,'serverCache':_0x2c404a};}function Rt(_0x3146da,_0x16ead9,_0x5c8a8a,_0x268038){return Un(new Te(_0x16ead9,_0x5c8a8a,_0x268038),_0x3146da['serverCache']);}function Fo(_0x161c6a,_0x12c43f,_0x1c6c91,_0x10d417){return Un(_0x161c6a['eventCache'],new Te(_0x12c43f,_0x1c6c91,_0x10d417));}function wn(_0x328774){return _0x328774['eventCache']['isFullyInitialized']()?_0x328774['eventCache']['getNode']():null;}function Ve(_0x269238){return _0x269238['serverCache']['isFullyInitialized']()?_0x269238['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x4ece30){let _0x4f96da=new b(null);return x(_0x4ece30,(_0x4cad22,_0x4bbdc5)=>{_0x4f96da=_0x4f96da['set'](new C(_0x4cad22),_0x4bbdc5);}),_0x4f96da;}constructor(_0xdcea49,_0x182485=cu()){this['value']=_0xdcea49,this['children']=_0x182485;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x131600,_0x5139ac){if(this['value']!=null&&_0x5139ac(this['value']))return{'path':w(),'value':this['value']};if(v(_0x131600))return null;{const _0x1b704a=y(_0x131600),_0x32cd96=this['children']['get'](_0x1b704a);if(_0x32cd96!==null){const _0x5dfa73=_0x32cd96['findRootMostMatchingPathAndValue'](S(_0x131600),_0x5139ac);return _0x5dfa73!=null?{'path':k(new C(_0x1b704a),_0x5dfa73['path']),'value':_0x5dfa73['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x2e5c28){return this['findRootMostMatchingPathAndValue'](_0x2e5c28,()=>!0x0);}['subtree'](_0x2590e2){if(v(_0x2590e2))return this;{const _0x5bca25=y(_0x2590e2),_0x59ffc5=this['children']['get'](_0x5bca25);return _0x59ffc5!==null?_0x59ffc5['subtree'](S(_0x2590e2)):new b(null);}}['set'](_0xf5219,_0x2dc847){if(v(_0xf5219))return new b(_0x2dc847,this['children']);{const _0x43a48a=y(_0xf5219),_0x4d777a=(this['children']['get'](_0x43a48a)||new b(null))['set'](S(_0xf5219),_0x2dc847),_0x2cd687=this['children']['insert'](_0x43a48a,_0x4d777a);return new b(this['value'],_0x2cd687);}}['remove'](_0x2212ca){if(v(_0x2212ca))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x40c2b7=y(_0x2212ca),_0x2dbf5a=this['children']['get'](_0x40c2b7);if(_0x2dbf5a){const _0x4504c9=_0x2dbf5a['remove'](S(_0x2212ca));let _0x51eae6;return _0x4504c9['isEmpty']()?_0x51eae6=this['children']['remove'](_0x40c2b7):_0x51eae6=this['children']['insert'](_0x40c2b7,_0x4504c9),this['value']===null&&_0x51eae6['isEmpty']()?new b(null):new b(this['value'],_0x51eae6);}else return this;}}['get'](_0x32e749){if(v(_0x32e749))return this['value'];{const _0x34e75b=y(_0x32e749),_0xcac7ce=this['children']['get'](_0x34e75b);return _0xcac7ce?_0xcac7ce['get'](S(_0x32e749)):null;}}['setTree'](_0x1ca029,_0x1f3e1){if(v(_0x1ca029))return _0x1f3e1;{const _0x554ab2=y(_0x1ca029),_0x158d08=(this['children']['get'](_0x554ab2)||new b(null))['setTree'](S(_0x1ca029),_0x1f3e1);let _0x28f84c;return _0x158d08['isEmpty']()?_0x28f84c=this['children']['remove'](_0x554ab2):_0x28f84c=this['children']['insert'](_0x554ab2,_0x158d08),new b(this['value'],_0x28f84c);}}['fold'](_0x3e03a6){return this['fold_'](w(),_0x3e03a6);}['fold_'](_0x42373b,_0x344cf3){const _0x499d11={};return this['children']['inorderTraversal']((_0x2e9135,_0x2d77b8)=>{_0x499d11[_0x2e9135]=_0x2d77b8['fold_'](k(_0x42373b,_0x2e9135),_0x344cf3);}),_0x344cf3(_0x42373b,this['value'],_0x499d11);}['findOnPath'](_0x11ae6f,_0x11f168){return this['findOnPath_'](_0x11ae6f,w(),_0x11f168);}['findOnPath_'](_0x34a67a,_0x1a027b,_0x1ca1b8){const _0x2a1fde=this['value']?_0x1ca1b8(_0x1a027b,this['value']):!0x1;if(_0x2a1fde)return _0x2a1fde;if(v(_0x34a67a))return null;{const _0x110847=y(_0x34a67a),_0x229add=this['children']['get'](_0x110847);return _0x229add?_0x229add['findOnPath_'](S(_0x34a67a),k(_0x1a027b,_0x110847),_0x1ca1b8):null;}}['foreachOnPath'](_0x4b52ad,_0x1661b8){return this['foreachOnPath_'](_0x4b52ad,w(),_0x1661b8);}['foreachOnPath_'](_0x139697,_0xad3ea5,_0x47cdef){if(v(_0x139697))return this;{this['value']&&_0x47cdef(_0xad3ea5,this['value']);const _0x45c470=y(_0x139697),_0x4a28f6=this['children']['get'](_0x45c470);return _0x4a28f6?_0x4a28f6['foreachOnPath_'](S(_0x139697),k(_0xad3ea5,_0x45c470),_0x47cdef):new b(null);}}['foreach'](_0x82cc09){this['foreach_'](w(),_0x82cc09);}['foreach_'](_0x5926dd,_0x11a5d9){this['children']['inorderTraversal']((_0x1f18f4,_0x52f293)=>{_0x52f293['foreach_'](k(_0x5926dd,_0x1f18f4),_0x11a5d9);}),this['value']&&_0x11a5d9(_0x5926dd,this['value']);}['foreachChild'](_0x804e5a){this['children']['inorderTraversal']((_0x21f273,_0x22b1e6)=>{_0x22b1e6['value']&&_0x804e5a(_0x21f273,_0x22b1e6['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x234ad5){this['writeTree_']=_0x234ad5;}static['empty'](){return new K(new b(null));}}function At(_0x5e5b21,_0x27efc3,_0x112afe){if(v(_0x27efc3))return new K(new b(_0x112afe));{const _0x2f1647=_0x5e5b21['writeTree_']['findRootMostValueAndPath'](_0x27efc3);if(_0x2f1647!=null){const _0x3ebf8e=_0x2f1647['path'];let _0x4eaab0=_0x2f1647['value'];const _0x5aca30=F(_0x3ebf8e,_0x27efc3);return _0x4eaab0=_0x4eaab0['updateChild'](_0x5aca30,_0x112afe),new K(_0x5e5b21['writeTree_']['set'](_0x3ebf8e,_0x4eaab0));}else{const _0x2c93c9=new b(_0x112afe),_0x39c825=_0x5e5b21['writeTree_']['setTree'](_0x27efc3,_0x2c93c9);return new K(_0x39c825);}}}function bi(_0x58aaca,_0x4a483b,_0x51aa0b){let _0x1e6181=_0x58aaca;return x(_0x51aa0b,(_0x33eac8,_0x2c2c44)=>{_0x1e6181=At(_0x1e6181,k(_0x4a483b,_0x33eac8),_0x2c2c44);}),_0x1e6181;}function or(_0x5e7212,_0x2d29b3){if(v(_0x2d29b3))return K['empty']();{const _0x151681=_0x5e7212['writeTree_']['setTree'](_0x2d29b3,new b(null));return new K(_0x151681);}}function Ri(_0x194e62,_0x5d6c2c){return ze(_0x194e62,_0x5d6c2c)!=null;}function ze(_0x2b0dc5,_0x299581){const _0x3fef49=_0x2b0dc5['writeTree_']['findRootMostValueAndPath'](_0x299581);return _0x3fef49!=null?_0x2b0dc5['writeTree_']['get'](_0x3fef49['path'])['getChild'](F(_0x3fef49['path'],_0x299581)):null;}function ar(_0x1dd232){const _0x5c19f5=[],_0x5deeab=_0x1dd232['writeTree_']['value'];return _0x5deeab!=null?_0x5deeab['isLeafNode']()||_0x5deeab['forEachChild'](R,(_0x4139aa,_0x13eee2)=>{_0x5c19f5['push'](new E(_0x4139aa,_0x13eee2));}):_0x1dd232['writeTree_']['children']['inorderTraversal']((_0x5262e3,_0x9f033c)=>{_0x9f033c['value']!=null&&_0x5c19f5['push'](new E(_0x5262e3,_0x9f033c['value']));}),_0x5c19f5;}function Ee(_0x1aacaa,_0x2a7565){if(v(_0x2a7565))return _0x1aacaa;{const _0x916892=ze(_0x1aacaa,_0x2a7565);return _0x916892!=null?new K(new b(_0x916892)):new K(_0x1aacaa['writeTree_']['subtree'](_0x2a7565));}}function Ai(_0x468911){return _0x468911['writeTree_']['isEmpty']();}function at(_0x1f493c,_0x4b68ea){return Uo(w(),_0x1f493c['writeTree_'],_0x4b68ea);}function Uo(_0x2c7fec,_0x3d9d23,_0x37a157){if(_0x3d9d23['value']!=null)return _0x37a157['updateChild'](_0x2c7fec,_0x3d9d23['value']);{let _0x17d8fc=null;return _0x3d9d23['children']['inorderTraversal']((_0x59475b,_0x2bcaf0)=>{_0x59475b==='.priority'?(f(_0x2bcaf0['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x17d8fc=_0x2bcaf0['value']):_0x37a157=Uo(k(_0x2c7fec,_0x59475b),_0x2bcaf0,_0x37a157);}),!_0x37a157['getChild'](_0x2c7fec)['isEmpty']()&&_0x17d8fc!==null&&(_0x37a157=_0x37a157['updateChild'](k(_0x2c7fec,'.priority'),_0x17d8fc)),_0x37a157;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x27aac9,_0x2ad3a9){return Ho(_0x2ad3a9,_0x27aac9);}function lu(_0x2eab9b,_0x5e391a,_0x2c1656,_0x35388d,_0x41d4de){f(_0x35388d>_0x2eab9b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x41d4de===void 0x0&&(_0x41d4de=!0x0),_0x2eab9b['allWrites']['push']({'path':_0x5e391a,'snap':_0x2c1656,'writeId':_0x35388d,'visible':_0x41d4de}),_0x41d4de&&(_0x2eab9b['visibleWrites']=At(_0x2eab9b['visibleWrites'],_0x5e391a,_0x2c1656)),_0x2eab9b['lastWriteId']=_0x35388d;}function hu(_0x468706,_0x7efff8,_0x1c2c09,_0xd4117e){f(_0xd4117e>_0x468706['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x468706['allWrites']['push']({'path':_0x7efff8,'children':_0x1c2c09,'writeId':_0xd4117e,'visible':!0x0}),_0x468706['visibleWrites']=bi(_0x468706['visibleWrites'],_0x7efff8,_0x1c2c09),_0x468706['lastWriteId']=_0xd4117e;}function uu(_0x523c2f,_0x1ceabb){for(let _0x206fc9=0x0;_0x206fc9<_0x523c2f['allWrites']['length'];_0x206fc9++){const _0x5c22f4=_0x523c2f['allWrites'][_0x206fc9];if(_0x5c22f4['writeId']===_0x1ceabb)return _0x5c22f4;}return null;}function du(_0x398dc3,_0x5a0c4b){const _0x342c5a=_0x398dc3['allWrites']['findIndex'](_0x59a7fc=>_0x59a7fc['writeId']===_0x5a0c4b);f(_0x342c5a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x520c80=_0x398dc3['allWrites'][_0x342c5a];_0x398dc3['allWrites']['splice'](_0x342c5a,0x1);let _0x3eeaea=_0x520c80['visible'],_0x56ec77=!0x1,_0x87182b=_0x398dc3['allWrites']['length']-0x1;for(;_0x3eeaea&&_0x87182b>=0x0;){const _0x4f8aa1=_0x398dc3['allWrites'][_0x87182b];_0x4f8aa1['visible']&&(_0x87182b>=_0x342c5a&&fu(_0x4f8aa1,_0x520c80['path'])?_0x3eeaea=!0x1:G(_0x520c80['path'],_0x4f8aa1['path'])&&(_0x56ec77=!0x0)),_0x87182b--;}if(_0x3eeaea){if(_0x56ec77)return pu(_0x398dc3),!0x0;if(_0x520c80['snap'])_0x398dc3['visibleWrites']=or(_0x398dc3['visibleWrites'],_0x520c80['path']);else{const _0x401d4c=_0x520c80['children'];x(_0x401d4c,_0xf0f4cf=>{_0x398dc3['visibleWrites']=or(_0x398dc3['visibleWrites'],k(_0x520c80['path'],_0xf0f4cf));});}return!0x0;}else return!0x1;}function fu(_0x274dcd,_0x45f295){if(_0x274dcd['snap'])return G(_0x274dcd['path'],_0x45f295);for(const _0x4742c2 in _0x274dcd['children'])if(_0x274dcd['children']['hasOwnProperty'](_0x4742c2)&&G(k(_0x274dcd['path'],_0x4742c2),_0x45f295))return!0x0;return!0x1;}function pu(_0x2645f3){_0x2645f3['visibleWrites']=Wo(_0x2645f3['allWrites'],_u,w()),_0x2645f3['allWrites']['length']>0x0?_0x2645f3['lastWriteId']=_0x2645f3['allWrites'][_0x2645f3['allWrites']['length']-0x1]['writeId']:_0x2645f3['lastWriteId']=-0x1;}function _u(_0x175dfe){return _0x175dfe['visible'];}function Wo(_0x5e0363,_0x4c68f2,_0x26f2dc){let _0x490bd9=K['empty']();for(let _0x4a75d5=0x0;_0x4a75d5<_0x5e0363['length'];++_0x4a75d5){const _0x3d18bb=_0x5e0363[_0x4a75d5];if(_0x4c68f2(_0x3d18bb)){const _0x3c99fe=_0x3d18bb['path'];let _0x3e4ff2;if(_0x3d18bb['snap'])G(_0x26f2dc,_0x3c99fe)?(_0x3e4ff2=F(_0x26f2dc,_0x3c99fe),_0x490bd9=At(_0x490bd9,_0x3e4ff2,_0x3d18bb['snap'])):G(_0x3c99fe,_0x26f2dc)&&(_0x3e4ff2=F(_0x3c99fe,_0x26f2dc),_0x490bd9=At(_0x490bd9,w(),_0x3d18bb['snap']['getChild'](_0x3e4ff2)));else{if(_0x3d18bb['children']){if(G(_0x26f2dc,_0x3c99fe))_0x3e4ff2=F(_0x26f2dc,_0x3c99fe),_0x490bd9=bi(_0x490bd9,_0x3e4ff2,_0x3d18bb['children']);else{if(G(_0x3c99fe,_0x26f2dc)){if(_0x3e4ff2=F(_0x3c99fe,_0x26f2dc),v(_0x3e4ff2))_0x490bd9=bi(_0x490bd9,w(),_0x3d18bb['children']);else{const _0x266510=Le(_0x3d18bb['children'],y(_0x3e4ff2));if(_0x266510){const _0x255da8=_0x266510['getChild'](S(_0x3e4ff2));_0x490bd9=At(_0x490bd9,w(),_0x255da8);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x490bd9;}function Bo(_0x4358f3,_0x5afbfe,_0x364a6e,_0xba1dc6,_0x5d2a51){if(!_0xba1dc6&&!_0x5d2a51){const _0x5a8664=ze(_0x4358f3['visibleWrites'],_0x5afbfe);if(_0x5a8664!=null)return _0x5a8664;{const _0x17b8ab=Ee(_0x4358f3['visibleWrites'],_0x5afbfe);if(Ai(_0x17b8ab))return _0x364a6e;if(_0x364a6e==null&&!Ri(_0x17b8ab,w()))return null;{const _0xb41a70=_0x364a6e||g['EMPTY_NODE'];return at(_0x17b8ab,_0xb41a70);}}}else{const _0x1dd09c=Ee(_0x4358f3['visibleWrites'],_0x5afbfe);if(!_0x5d2a51&&Ai(_0x1dd09c))return _0x364a6e;if(!_0x5d2a51&&_0x364a6e==null&&!Ri(_0x1dd09c,w()))return null;{const _0x3b0308=function(_0x2b1eaa){return(_0x2b1eaa['visible']||_0x5d2a51)&&(!_0xba1dc6||!~_0xba1dc6['indexOf'](_0x2b1eaa['writeId']))&&(G(_0x2b1eaa['path'],_0x5afbfe)||G(_0x5afbfe,_0x2b1eaa['path']));},_0x1b9431=Wo(_0x4358f3['allWrites'],_0x3b0308,_0x5afbfe),_0x13aeb2=_0x364a6e||g['EMPTY_NODE'];return at(_0x1b9431,_0x13aeb2);}}}function gu(_0x1345b5,_0x59414f,_0x1df986){let _0x49a7d8=g['EMPTY_NODE'];const _0x1256ea=ze(_0x1345b5['visibleWrites'],_0x59414f);if(_0x1256ea)return _0x1256ea['isLeafNode']()||_0x1256ea['forEachChild'](R,(_0x9c13fe,_0x3b692e)=>{_0x49a7d8=_0x49a7d8['updateImmediateChild'](_0x9c13fe,_0x3b692e);}),_0x49a7d8;if(_0x1df986){const _0x4b62a=Ee(_0x1345b5['visibleWrites'],_0x59414f);return _0x1df986['forEachChild'](R,(_0x266755,_0xdb2367)=>{const _0x5f1214=at(Ee(_0x4b62a,new C(_0x266755)),_0xdb2367);_0x49a7d8=_0x49a7d8['updateImmediateChild'](_0x266755,_0x5f1214);}),ar(_0x4b62a)['forEach'](_0x3497bb=>{_0x49a7d8=_0x49a7d8['updateImmediateChild'](_0x3497bb['name'],_0x3497bb['node']);}),_0x49a7d8;}else{const _0x30f09d=Ee(_0x1345b5['visibleWrites'],_0x59414f);return ar(_0x30f09d)['forEach'](_0x2c99f4=>{_0x49a7d8=_0x49a7d8['updateImmediateChild'](_0x2c99f4['name'],_0x2c99f4['node']);}),_0x49a7d8;}}function mu(_0x7688a9,_0x1a43f4,_0x46431b,_0x35c708,_0x31eaf3){f(_0x35c708||_0x31eaf3,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x31a132=k(_0x1a43f4,_0x46431b);if(Ri(_0x7688a9['visibleWrites'],_0x31a132))return null;{const _0x4addf5=Ee(_0x7688a9['visibleWrites'],_0x31a132);return Ai(_0x4addf5)?_0x31eaf3['getChild'](_0x46431b):at(_0x4addf5,_0x31eaf3['getChild'](_0x46431b));}}function yu(_0x580af4,_0x4a3d0f,_0x66cdab,_0x25de75){const _0x12a6b3=k(_0x4a3d0f,_0x66cdab),_0x4d9f86=ze(_0x580af4['visibleWrites'],_0x12a6b3);if(_0x4d9f86!=null)return _0x4d9f86;if(_0x25de75['isCompleteForChild'](_0x66cdab)){const _0x493aeb=Ee(_0x580af4['visibleWrites'],_0x12a6b3);return at(_0x493aeb,_0x25de75['getNode']()['getImmediateChild'](_0x66cdab));}else return null;}function vu(_0x4dbd9d,_0x270588){return ze(_0x4dbd9d['visibleWrites'],_0x270588);}function Eu(_0x27e2ff,_0x58356a,_0x1d6951,_0x4b216f,_0x5b3f35,_0x2b1fde,_0x1d1905){let _0x599a8a;const _0x514362=Ee(_0x27e2ff['visibleWrites'],_0x58356a),_0x517cfe=ze(_0x514362,w());if(_0x517cfe!=null)_0x599a8a=_0x517cfe;else{if(_0x1d6951!=null)_0x599a8a=at(_0x514362,_0x1d6951);else return[];}if(_0x599a8a=_0x599a8a['withIndex'](_0x1d1905),!_0x599a8a['isEmpty']()&&!_0x599a8a['isLeafNode']()){const _0x3cb7ea=[],_0x1c8cba=_0x1d1905['getCompare'](),_0x27022e=_0x2b1fde?_0x599a8a['getReverseIteratorFrom'](_0x4b216f,_0x1d1905):_0x599a8a['getIteratorFrom'](_0x4b216f,_0x1d1905);let _0x4aad73=_0x27022e['getNext']();for(;_0x4aad73&&_0x3cb7ea['length']<_0x5b3f35;)_0x1c8cba(_0x4aad73,_0x4b216f)!==0x0&&_0x3cb7ea['push'](_0x4aad73),_0x4aad73=_0x27022e['getNext']();return _0x3cb7ea;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x580a7e,_0x27e3b1,_0x5886c7,_0x48cf92){return Bo(_0x580a7e['writeTree'],_0x580a7e['treePath'],_0x27e3b1,_0x5886c7,_0x48cf92);}function is(_0x44076a,_0x45507d){return gu(_0x44076a['writeTree'],_0x44076a['treePath'],_0x45507d);}function cr(_0x962504,_0xccca08,_0x116f49,_0x5dcc83){return mu(_0x962504['writeTree'],_0x962504['treePath'],_0xccca08,_0x116f49,_0x5dcc83);}function Tn(_0x311818,_0x48cbe7){return vu(_0x311818['writeTree'],k(_0x311818['treePath'],_0x48cbe7));}function wu(_0x248748,_0x2e444a,_0x5a8204,_0x566d1e,_0x314a90,_0x48afcc){return Eu(_0x248748['writeTree'],_0x248748['treePath'],_0x2e444a,_0x5a8204,_0x566d1e,_0x314a90,_0x48afcc);}function ss(_0x25691b,_0xf3dfef,_0x453819){return yu(_0x25691b['writeTree'],_0x25691b['treePath'],_0xf3dfef,_0x453819);}function Vo(_0x50c551,_0x1068af){return Ho(k(_0x50c551['treePath'],_0x1068af),_0x50c551['writeTree']);}function Ho(_0x13c80f,_0x3592d7){return{'treePath':_0x13c80f,'writeTree':_0x3592d7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4650bb){const _0x4a6000=_0x4650bb['type'],_0x478ace=_0x4650bb['childName'];f(_0x4a6000==='child_added'||_0x4a6000==='child_changed'||_0x4a6000==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x478ace!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x54f076=this['changeMap']['get'](_0x478ace);if(_0x54f076){const _0x419cfe=_0x54f076['type'];if(_0x4a6000==='child_added'&&_0x419cfe==='child_removed')this['changeMap']['set'](_0x478ace,xt(_0x478ace,_0x4650bb['snapshotNode'],_0x54f076['snapshotNode']));else{if(_0x4a6000==='child_removed'&&_0x419cfe==='child_added')this['changeMap']['delete'](_0x478ace);else{if(_0x4a6000==='child_removed'&&_0x419cfe==='child_changed')this['changeMap']['set'](_0x478ace,Lt(_0x478ace,_0x54f076['oldSnap']));else{if(_0x4a6000==='child_changed'&&_0x419cfe==='child_added')this['changeMap']['set'](_0x478ace,rt(_0x478ace,_0x4650bb['snapshotNode']));else{if(_0x4a6000==='child_changed'&&_0x419cfe==='child_changed')this['changeMap']['set'](_0x478ace,xt(_0x478ace,_0x4650bb['snapshotNode'],_0x54f076['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x4650bb+'\x20occurred\x20after\x20'+_0x54f076);}}}}}else this['changeMap']['set'](_0x478ace,_0x4650bb);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x4b83a5){return null;}['getChildAfterChild'](_0x220565,_0x134c3a,_0x23ffa2){return null;}}const $o=new Tu();class rs{constructor(_0x2d97a2,_0x278bd7,_0x1aa293=null){this['writes_']=_0x2d97a2,this['viewCache_']=_0x278bd7,this['optCompleteServerCache_']=_0x1aa293;}['getCompleteChild'](_0x2dceb7){const _0x3f458a=this['viewCache_']['eventCache'];if(_0x3f458a['isCompleteForChild'](_0x2dceb7))return _0x3f458a['getNode']()['getImmediateChild'](_0x2dceb7);{const _0x4440ac=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2dceb7,_0x4440ac);}}['getChildAfterChild'](_0x51f4f0,_0x13e124,_0x40d183){const _0x7ce05a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x140b58=wu(this['writes_'],_0x7ce05a,_0x13e124,0x1,_0x40d183,_0x51f4f0);return _0x140b58['length']===0x0?null:_0x140b58[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xfcbbab){return{'filter':_0xfcbbab};}function bu(_0x527bfd,_0x123baa){f(_0x123baa['eventCache']['getNode']()['isIndexed'](_0x527bfd['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x123baa['serverCache']['getNode']()['isIndexed'](_0x527bfd['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2a229b,_0x23cf65,_0x3e8b9b,_0x3e05fd,_0x55b2f4){const _0x219c89=new Cu();let _0x84f0b2,_0x3fe94f;if(_0x3e8b9b['type']===z['OVERWRITE']){const _0x4bda63=_0x3e8b9b;_0x4bda63['source']['fromUser']?_0x84f0b2=ki(_0x2a229b,_0x23cf65,_0x4bda63['path'],_0x4bda63['snap'],_0x3e05fd,_0x55b2f4,_0x219c89):(f(_0x4bda63['source']['fromServer'],'Unknown\x20source.'),_0x3fe94f=_0x4bda63['source']['tagged']||_0x23cf65['serverCache']['isFiltered']()&&!v(_0x4bda63['path']),_0x84f0b2=Sn(_0x2a229b,_0x23cf65,_0x4bda63['path'],_0x4bda63['snap'],_0x3e05fd,_0x55b2f4,_0x3fe94f,_0x219c89));}else{if(_0x3e8b9b['type']===z['MERGE']){const _0x160e16=_0x3e8b9b;_0x160e16['source']['fromUser']?_0x84f0b2=ku(_0x2a229b,_0x23cf65,_0x160e16['path'],_0x160e16['children'],_0x3e05fd,_0x55b2f4,_0x219c89):(f(_0x160e16['source']['fromServer'],'Unknown\x20source.'),_0x3fe94f=_0x160e16['source']['tagged']||_0x23cf65['serverCache']['isFiltered'](),_0x84f0b2=Pi(_0x2a229b,_0x23cf65,_0x160e16['path'],_0x160e16['children'],_0x3e05fd,_0x55b2f4,_0x3fe94f,_0x219c89));}else{if(_0x3e8b9b['type']===z['ACK_USER_WRITE']){const _0x579cf5=_0x3e8b9b;_0x579cf5['revert']?_0x84f0b2=Ou(_0x2a229b,_0x23cf65,_0x579cf5['path'],_0x3e05fd,_0x55b2f4,_0x219c89):_0x84f0b2=Pu(_0x2a229b,_0x23cf65,_0x579cf5['path'],_0x579cf5['affectedTree'],_0x3e05fd,_0x55b2f4,_0x219c89);}else{if(_0x3e8b9b['type']===z['LISTEN_COMPLETE'])_0x84f0b2=Nu(_0x2a229b,_0x23cf65,_0x3e8b9b['path'],_0x3e05fd,_0x219c89);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3e8b9b['type']);}}}const _0x2e4490=_0x219c89['getChanges']();return Au(_0x23cf65,_0x84f0b2,_0x2e4490),{'viewCache':_0x84f0b2,'changes':_0x2e4490};}function Au(_0x1cef69,_0x318003,_0x4354d7){const _0x45c4a1=_0x318003['eventCache'];if(_0x45c4a1['isFullyInitialized']()){const _0x45f0c5=_0x45c4a1['getNode']()['isLeafNode']()||_0x45c4a1['getNode']()['isEmpty'](),_0x4b3ac0=wn(_0x1cef69);(_0x4354d7['length']>0x0||!_0x1cef69['eventCache']['isFullyInitialized']()||_0x45f0c5&&!_0x45c4a1['getNode']()['equals'](_0x4b3ac0)||!_0x45c4a1['getNode']()['getPriority']()['equals'](_0x4b3ac0['getPriority']()))&&_0x4354d7['push'](Lo(wn(_0x318003)));}}function Go(_0x55329a,_0x408ae1,_0x489c6f,_0x3a28a9,_0x1d6f20,_0x396a77){const _0x302caf=_0x408ae1['eventCache'];if(Tn(_0x3a28a9,_0x489c6f)!=null)return _0x408ae1;{let _0x1afc03,_0x38f289;if(v(_0x489c6f)){if(f(_0x408ae1['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x408ae1['serverCache']['isFiltered']()){const _0xdf82a3=Ve(_0x408ae1),_0x2cf1d2=_0xdf82a3 instanceof g?_0xdf82a3:g['EMPTY_NODE'],_0x14de80=is(_0x3a28a9,_0x2cf1d2);_0x1afc03=_0x55329a['filter']['updateFullNode'](_0x408ae1['eventCache']['getNode'](),_0x14de80,_0x396a77);}else{const _0x2aa26a=Cn(_0x3a28a9,Ve(_0x408ae1));_0x1afc03=_0x55329a['filter']['updateFullNode'](_0x408ae1['eventCache']['getNode'](),_0x2aa26a,_0x396a77);}}else{const _0x2519a4=y(_0x489c6f);if(_0x2519a4==='.priority'){f(Ce(_0x489c6f)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2888a5=_0x302caf['getNode']();_0x38f289=_0x408ae1['serverCache']['getNode']();const _0x35c887=cr(_0x3a28a9,_0x489c6f,_0x2888a5,_0x38f289);_0x35c887!=null?_0x1afc03=_0x55329a['filter']['updatePriority'](_0x2888a5,_0x35c887):_0x1afc03=_0x302caf['getNode']();}else{const _0x524e27=S(_0x489c6f);let _0x281e85;if(_0x302caf['isCompleteForChild'](_0x2519a4)){_0x38f289=_0x408ae1['serverCache']['getNode']();const _0x5e37eb=cr(_0x3a28a9,_0x489c6f,_0x302caf['getNode'](),_0x38f289);_0x5e37eb!=null?_0x281e85=_0x302caf['getNode']()['getImmediateChild'](_0x2519a4)['updateChild'](_0x524e27,_0x5e37eb):_0x281e85=_0x302caf['getNode']()['getImmediateChild'](_0x2519a4);}else _0x281e85=ss(_0x3a28a9,_0x2519a4,_0x408ae1['serverCache']);_0x281e85!=null?_0x1afc03=_0x55329a['filter']['updateChild'](_0x302caf['getNode'](),_0x2519a4,_0x281e85,_0x524e27,_0x1d6f20,_0x396a77):_0x1afc03=_0x302caf['getNode']();}}return Rt(_0x408ae1,_0x1afc03,_0x302caf['isFullyInitialized']()||v(_0x489c6f),_0x55329a['filter']['filtersNodes']());}}function Sn(_0x510f40,_0x48113f,_0x444330,_0x11f9f5,_0x4a4f30,_0x129bc5,_0x4dc56f,_0x33577d){const _0x36fb3f=_0x48113f['serverCache'];let _0x33b1b2;const _0x4f6c3a=_0x4dc56f?_0x510f40['filter']:_0x510f40['filter']['getIndexedFilter']();if(v(_0x444330))_0x33b1b2=_0x4f6c3a['updateFullNode'](_0x36fb3f['getNode'](),_0x11f9f5,null);else{if(_0x4f6c3a['filtersNodes']()&&!_0x36fb3f['isFiltered']()){const _0x199dd4=_0x36fb3f['getNode']()['updateChild'](_0x444330,_0x11f9f5);_0x33b1b2=_0x4f6c3a['updateFullNode'](_0x36fb3f['getNode'](),_0x199dd4,null);}else{const _0x6f6264=y(_0x444330);if(!_0x36fb3f['isCompleteForPath'](_0x444330)&&Ce(_0x444330)>0x1)return _0x48113f;const _0x3ebb9c=S(_0x444330),_0x30aed7=_0x36fb3f['getNode']()['getImmediateChild'](_0x6f6264)['updateChild'](_0x3ebb9c,_0x11f9f5);_0x6f6264==='.priority'?_0x33b1b2=_0x4f6c3a['updatePriority'](_0x36fb3f['getNode'](),_0x30aed7):_0x33b1b2=_0x4f6c3a['updateChild'](_0x36fb3f['getNode'](),_0x6f6264,_0x30aed7,_0x3ebb9c,$o,null);}}const _0x324b12=Fo(_0x48113f,_0x33b1b2,_0x36fb3f['isFullyInitialized']()||v(_0x444330),_0x4f6c3a['filtersNodes']()),_0x830769=new rs(_0x4a4f30,_0x324b12,_0x129bc5);return Go(_0x510f40,_0x324b12,_0x444330,_0x4a4f30,_0x830769,_0x33577d);}function ki(_0x417d36,_0x4b5ed4,_0x25ec9c,_0x524731,_0x12d37f,_0x13fcd0,_0x32db88){const _0x3742ec=_0x4b5ed4['eventCache'];let _0x12e489,_0x472ddb;const _0x33cc43=new rs(_0x12d37f,_0x4b5ed4,_0x13fcd0);if(v(_0x25ec9c))_0x472ddb=_0x417d36['filter']['updateFullNode'](_0x4b5ed4['eventCache']['getNode'](),_0x524731,_0x32db88),_0x12e489=Rt(_0x4b5ed4,_0x472ddb,!0x0,_0x417d36['filter']['filtersNodes']());else{const _0xce917d=y(_0x25ec9c);if(_0xce917d==='.priority')_0x472ddb=_0x417d36['filter']['updatePriority'](_0x4b5ed4['eventCache']['getNode'](),_0x524731),_0x12e489=Rt(_0x4b5ed4,_0x472ddb,_0x3742ec['isFullyInitialized'](),_0x3742ec['isFiltered']());else{const _0x22e1b2=S(_0x25ec9c),_0x564543=_0x3742ec['getNode']()['getImmediateChild'](_0xce917d);let _0x4641e3;if(v(_0x22e1b2))_0x4641e3=_0x524731;else{const _0x5c85de=_0x33cc43['getCompleteChild'](_0xce917d);_0x5c85de!=null?ji(_0x22e1b2)==='.priority'&&_0x5c85de['getChild'](Ro(_0x22e1b2))['isEmpty']()?_0x4641e3=_0x5c85de:_0x4641e3=_0x5c85de['updateChild'](_0x22e1b2,_0x524731):_0x4641e3=g['EMPTY_NODE'];}if(_0x564543['equals'](_0x4641e3))_0x12e489=_0x4b5ed4;else{const _0x341e4b=_0x417d36['filter']['updateChild'](_0x3742ec['getNode'](),_0xce917d,_0x4641e3,_0x22e1b2,_0x33cc43,_0x32db88);_0x12e489=Rt(_0x4b5ed4,_0x341e4b,_0x3742ec['isFullyInitialized'](),_0x417d36['filter']['filtersNodes']());}}}return _0x12e489;}function lr(_0x2d37ac,_0x322f74){return _0x2d37ac['eventCache']['isCompleteForChild'](_0x322f74);}function ku(_0x3b0eab,_0x4cd957,_0x4ca52f,_0x39f9c6,_0x46d171,_0x54d8b7,_0x497b41){let _0x2be18e=_0x4cd957;return _0x39f9c6['foreach']((_0x3451e8,_0x46ac2b)=>{const _0x290546=k(_0x4ca52f,_0x3451e8);lr(_0x4cd957,y(_0x290546))&&(_0x2be18e=ki(_0x3b0eab,_0x2be18e,_0x290546,_0x46ac2b,_0x46d171,_0x54d8b7,_0x497b41));}),_0x39f9c6['foreach']((_0x4e6637,_0x382cc0)=>{const _0x2855db=k(_0x4ca52f,_0x4e6637);lr(_0x4cd957,y(_0x2855db))||(_0x2be18e=ki(_0x3b0eab,_0x2be18e,_0x2855db,_0x382cc0,_0x46d171,_0x54d8b7,_0x497b41));}),_0x2be18e;}function hr(_0x58dcb8,_0x4d2936,_0x3684d5){return _0x3684d5['foreach']((_0x238a8e,_0x3c0869)=>{_0x4d2936=_0x4d2936['updateChild'](_0x238a8e,_0x3c0869);}),_0x4d2936;}function Pi(_0xf78ee9,_0x3d96a3,_0x32e6b8,_0x14daa9,_0x26688f,_0x449e85,_0x403598,_0x33ebb0){if(_0x3d96a3['serverCache']['getNode']()['isEmpty']()&&!_0x3d96a3['serverCache']['isFullyInitialized']())return _0x3d96a3;let _0x576cbd=_0x3d96a3,_0x429f18;v(_0x32e6b8)?_0x429f18=_0x14daa9:_0x429f18=new b(null)['setTree'](_0x32e6b8,_0x14daa9);const _0x2e9c93=_0x3d96a3['serverCache']['getNode']();return _0x429f18['children']['inorderTraversal']((_0xf55285,_0x1d67d2)=>{if(_0x2e9c93['hasChild'](_0xf55285)){const _0xeaa2ce=_0x3d96a3['serverCache']['getNode']()['getImmediateChild'](_0xf55285),_0x18f512=hr(_0xf78ee9,_0xeaa2ce,_0x1d67d2);_0x576cbd=Sn(_0xf78ee9,_0x576cbd,new C(_0xf55285),_0x18f512,_0x26688f,_0x449e85,_0x403598,_0x33ebb0);}}),_0x429f18['children']['inorderTraversal']((_0x31c717,_0x49d8e9)=>{const _0x1d75b3=!_0x3d96a3['serverCache']['isCompleteForChild'](_0x31c717)&&_0x49d8e9['value']===null;if(!_0x2e9c93['hasChild'](_0x31c717)&&!_0x1d75b3){const _0x2e767c=_0x3d96a3['serverCache']['getNode']()['getImmediateChild'](_0x31c717),_0x46dbd8=hr(_0xf78ee9,_0x2e767c,_0x49d8e9);_0x576cbd=Sn(_0xf78ee9,_0x576cbd,new C(_0x31c717),_0x46dbd8,_0x26688f,_0x449e85,_0x403598,_0x33ebb0);}}),_0x576cbd;}function Pu(_0x109696,_0x452377,_0x969240,_0x147121,_0x510f6a,_0x1da39b,_0x4238df){if(Tn(_0x510f6a,_0x969240)!=null)return _0x452377;const _0x34b99e=_0x452377['serverCache']['isFiltered'](),_0x3d2c9d=_0x452377['serverCache'];if(_0x147121['value']!=null){if(v(_0x969240)&&_0x3d2c9d['isFullyInitialized']()||_0x3d2c9d['isCompleteForPath'](_0x969240))return Sn(_0x109696,_0x452377,_0x969240,_0x3d2c9d['getNode']()['getChild'](_0x969240),_0x510f6a,_0x1da39b,_0x34b99e,_0x4238df);if(v(_0x969240)){let _0x52ae3e=new b(null);return _0x3d2c9d['getNode']()['forEachChild'](ve,(_0x578469,_0x515c59)=>{_0x52ae3e=_0x52ae3e['set'](new C(_0x578469),_0x515c59);}),Pi(_0x109696,_0x452377,_0x969240,_0x52ae3e,_0x510f6a,_0x1da39b,_0x34b99e,_0x4238df);}else return _0x452377;}else{let _0x29fd2f=new b(null);return _0x147121['foreach']((_0x5327bb,_0x1a5c03)=>{const _0x12ce9a=k(_0x969240,_0x5327bb);_0x3d2c9d['isCompleteForPath'](_0x12ce9a)&&(_0x29fd2f=_0x29fd2f['set'](_0x5327bb,_0x3d2c9d['getNode']()['getChild'](_0x12ce9a)));}),Pi(_0x109696,_0x452377,_0x969240,_0x29fd2f,_0x510f6a,_0x1da39b,_0x34b99e,_0x4238df);}}function Nu(_0x277928,_0x43d0b2,_0xa65607,_0x4c34f8,_0x5bb41d){const _0x2a8298=_0x43d0b2['serverCache'],_0x59546f=Fo(_0x43d0b2,_0x2a8298['getNode'](),_0x2a8298['isFullyInitialized']()||v(_0xa65607),_0x2a8298['isFiltered']());return Go(_0x277928,_0x59546f,_0xa65607,_0x4c34f8,$o,_0x5bb41d);}function Ou(_0x55c6fb,_0x19c60a,_0x30ae17,_0x101ebd,_0x24735d,_0x14a10c){let _0x57804a;if(Tn(_0x101ebd,_0x30ae17)!=null)return _0x19c60a;{const _0x577ef0=new rs(_0x101ebd,_0x19c60a,_0x24735d),_0x252e91=_0x19c60a['eventCache']['getNode']();let _0x88544a;if(v(_0x30ae17)||y(_0x30ae17)==='.priority'){let _0x5d1226;if(_0x19c60a['serverCache']['isFullyInitialized']())_0x5d1226=Cn(_0x101ebd,Ve(_0x19c60a));else{const _0x290b68=_0x19c60a['serverCache']['getNode']();f(_0x290b68 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5d1226=is(_0x101ebd,_0x290b68);}_0x5d1226=_0x5d1226,_0x88544a=_0x55c6fb['filter']['updateFullNode'](_0x252e91,_0x5d1226,_0x14a10c);}else{const _0x3be93c=y(_0x30ae17);let _0x270df2=ss(_0x101ebd,_0x3be93c,_0x19c60a['serverCache']);_0x270df2==null&&_0x19c60a['serverCache']['isCompleteForChild'](_0x3be93c)&&(_0x270df2=_0x252e91['getImmediateChild'](_0x3be93c)),_0x270df2!=null?_0x88544a=_0x55c6fb['filter']['updateChild'](_0x252e91,_0x3be93c,_0x270df2,S(_0x30ae17),_0x577ef0,_0x14a10c):_0x19c60a['eventCache']['getNode']()['hasChild'](_0x3be93c)?_0x88544a=_0x55c6fb['filter']['updateChild'](_0x252e91,_0x3be93c,g['EMPTY_NODE'],S(_0x30ae17),_0x577ef0,_0x14a10c):_0x88544a=_0x252e91,_0x88544a['isEmpty']()&&_0x19c60a['serverCache']['isFullyInitialized']()&&(_0x57804a=Cn(_0x101ebd,Ve(_0x19c60a)),_0x57804a['isLeafNode']()&&(_0x88544a=_0x55c6fb['filter']['updateFullNode'](_0x88544a,_0x57804a,_0x14a10c)));}return _0x57804a=_0x19c60a['serverCache']['isFullyInitialized']()||Tn(_0x101ebd,w())!=null,Rt(_0x19c60a,_0x88544a,_0x57804a,_0x55c6fb['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x2fcd94,_0x125978){this['query_']=_0x2fcd94,this['eventRegistrations_']=[];const _0x47987f=this['query_']['_queryParams'],_0x83a4f8=new Xi(_0x47987f['getIndex']()),_0x25e63f=Kh(_0x47987f);this['processor_']=Su(_0x25e63f);const _0x253a2f=_0x125978['serverCache'],_0x45349b=_0x125978['eventCache'],_0x48be16=_0x83a4f8['updateFullNode'](g['EMPTY_NODE'],_0x253a2f['getNode'](),null),_0x1213d7=_0x25e63f['updateFullNode'](g['EMPTY_NODE'],_0x45349b['getNode'](),null),_0x42a94d=new Te(_0x48be16,_0x253a2f['isFullyInitialized'](),_0x83a4f8['filtersNodes']()),_0x475f2e=new Te(_0x1213d7,_0x45349b['isFullyInitialized'](),_0x25e63f['filtersNodes']());this['viewCache_']=Un(_0x475f2e,_0x42a94d),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x58d1f3){return _0x58d1f3['viewCache_']['serverCache']['getNode']();}function Lu(_0x549aea){return wn(_0x549aea['viewCache_']);}function xu(_0x613c4d,_0x2dd908){const _0x48e95f=Ve(_0x613c4d['viewCache_']);return _0x48e95f&&(_0x613c4d['query']['_queryParams']['loadsAllData']()||!v(_0x2dd908)&&!_0x48e95f['getImmediateChild'](y(_0x2dd908))['isEmpty']())?_0x48e95f['getChild'](_0x2dd908):null;}function ur(_0x2d1923){return _0x2d1923['eventRegistrations_']['length']===0x0;}function Fu(_0x57efcc,_0x4ddc2c){_0x57efcc['eventRegistrations_']['push'](_0x4ddc2c);}function dr(_0x16d91e,_0x2b8f99,_0x18624f){const _0x266726=[];if(_0x18624f){f(_0x2b8f99==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1c9754=_0x16d91e['query']['_path'];_0x16d91e['eventRegistrations_']['forEach'](_0x735f3f=>{const _0x5aeeb0=_0x735f3f['createCancelEvent'](_0x18624f,_0x1c9754);_0x5aeeb0&&_0x266726['push'](_0x5aeeb0);});}if(_0x2b8f99){let _0x42d40f=[];for(let _0x472cab=0x0;_0x472cab<_0x16d91e['eventRegistrations_']['length'];++_0x472cab){const _0x51111c=_0x16d91e['eventRegistrations_'][_0x472cab];if(!_0x51111c['matches'](_0x2b8f99))_0x42d40f['push'](_0x51111c);else{if(_0x2b8f99['hasAnyCallback']()){_0x42d40f=_0x42d40f['concat'](_0x16d91e['eventRegistrations_']['slice'](_0x472cab+0x1));break;}}}_0x16d91e['eventRegistrations_']=_0x42d40f;}else _0x16d91e['eventRegistrations_']=[];return _0x266726;}function fr(_0xbcc4a7,_0x48b17d,_0x4fc0ec,_0x52189c){_0x48b17d['type']===z['MERGE']&&_0x48b17d['source']['queryId']!==null&&(f(Ve(_0xbcc4a7['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0xbcc4a7['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5ba0cf=_0xbcc4a7['viewCache_'],_0x3b7d86=Ru(_0xbcc4a7['processor_'],_0x5ba0cf,_0x48b17d,_0x4fc0ec,_0x52189c);return bu(_0xbcc4a7['processor_'],_0x3b7d86['viewCache']),f(_0x3b7d86['viewCache']['serverCache']['isFullyInitialized']()||!_0x5ba0cf['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xbcc4a7['viewCache_']=_0x3b7d86['viewCache'],qo(_0xbcc4a7,_0x3b7d86['changes'],_0x3b7d86['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x354478,_0x3e2b80){const _0x161ffc=_0x354478['viewCache_']['eventCache'],_0x490b9a=[];return _0x161ffc['getNode']()['isLeafNode']()||_0x161ffc['getNode']()['forEachChild'](R,(_0x1011be,_0x2779df)=>{_0x490b9a['push'](rt(_0x1011be,_0x2779df));}),_0x161ffc['isFullyInitialized']()&&_0x490b9a['push'](Lo(_0x161ffc['getNode']())),qo(_0x354478,_0x490b9a,_0x161ffc['getNode'](),_0x3e2b80);}function qo(_0x34a74c,_0x1a9208,_0x1c5f7f,_0x34516d){const _0x59fed6=_0x34516d?[_0x34516d]:_0x34a74c['eventRegistrations_'];return ru(_0x34a74c['eventGenerator_'],_0x1a9208,_0x1c5f7f,_0x59fed6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x541037){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x541037;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x16eefc){return _0x16eefc['views']['size']===0x0;}function os(_0x3ab318,_0xa150ea,_0x545128,_0x1755ac){const _0x49a293=_0xa150ea['source']['queryId'];if(_0x49a293!==null){const _0x47b84d=_0x3ab318['views']['get'](_0x49a293);return f(_0x47b84d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x47b84d,_0xa150ea,_0x545128,_0x1755ac);}else{let _0x39ef2c=[];for(const _0x37e877 of _0x3ab318['views']['values']())_0x39ef2c=_0x39ef2c['concat'](fr(_0x37e877,_0xa150ea,_0x545128,_0x1755ac));return _0x39ef2c;}}function jo(_0x294d83,_0x509c42,_0x4831f2,_0x5b9097,_0x1bf821){const _0x559ea3=_0x509c42['_queryIdentifier'],_0x4602ba=_0x294d83['views']['get'](_0x559ea3);if(!_0x4602ba){let _0x2a0d3b=Cn(_0x4831f2,_0x1bf821?_0x5b9097:null),_0x47cc39=!0x1;_0x2a0d3b?_0x47cc39=!0x0:_0x5b9097 instanceof g?(_0x2a0d3b=is(_0x4831f2,_0x5b9097),_0x47cc39=!0x1):(_0x2a0d3b=g['EMPTY_NODE'],_0x47cc39=!0x1);const _0x5863fe=Un(new Te(_0x2a0d3b,_0x47cc39,!0x1),new Te(_0x5b9097,_0x1bf821,!0x1));return new Du(_0x509c42,_0x5863fe);}return _0x4602ba;}function Hu(_0x290c4c,_0x586155,_0x3bcb31,_0x126e0d,_0x3c6fbd,_0x52d966){const _0x2bb50e=jo(_0x290c4c,_0x586155,_0x126e0d,_0x3c6fbd,_0x52d966);return _0x290c4c['views']['has'](_0x586155['_queryIdentifier'])||_0x290c4c['views']['set'](_0x586155['_queryIdentifier'],_0x2bb50e),Fu(_0x2bb50e,_0x3bcb31),Uu(_0x2bb50e,_0x3bcb31);}function $u(_0x5ed725,_0x1965ce,_0x41342f,_0x41751a){const _0x59c833=_0x1965ce['_queryIdentifier'],_0x4f6e05=[];let _0x12eef9=[];const _0x54b709=Se(_0x5ed725);if(_0x59c833==='default'){for(const [_0x4e2b9f,_0x169a2c]of _0x5ed725['views']['entries']())_0x12eef9=_0x12eef9['concat'](dr(_0x169a2c,_0x41342f,_0x41751a)),ur(_0x169a2c)&&(_0x5ed725['views']['delete'](_0x4e2b9f),_0x169a2c['query']['_queryParams']['loadsAllData']()||_0x4f6e05['push'](_0x169a2c['query']));}else{const _0x5353dd=_0x5ed725['views']['get'](_0x59c833);_0x5353dd&&(_0x12eef9=_0x12eef9['concat'](dr(_0x5353dd,_0x41342f,_0x41751a)),ur(_0x5353dd)&&(_0x5ed725['views']['delete'](_0x59c833),_0x5353dd['query']['_queryParams']['loadsAllData']()||_0x4f6e05['push'](_0x5353dd['query'])));}return _0x54b709&&!Se(_0x5ed725)&&_0x4f6e05['push'](new(Bu())(_0x1965ce['_repo'],_0x1965ce['_path'])),{'removed':_0x4f6e05,'events':_0x12eef9};}function Ko(_0x47c7be){const _0x221232=[];for(const _0x3c72d2 of _0x47c7be['views']['values']())_0x3c72d2['query']['_queryParams']['loadsAllData']()||_0x221232['push'](_0x3c72d2);return _0x221232;}function Ie(_0xf162d8,_0x7c8a81){let _0x158a8a=null;for(const _0x524ac7 of _0xf162d8['views']['values']())_0x158a8a=_0x158a8a||xu(_0x524ac7,_0x7c8a81);return _0x158a8a;}function Yo(_0x1ced72,_0x4665ff){if(_0x4665ff['_queryParams']['loadsAllData']())return Bn(_0x1ced72);{const _0x54393d=_0x4665ff['_queryIdentifier'];return _0x1ced72['views']['get'](_0x54393d);}}function Qo(_0x387b91,_0x39e4ca){return Yo(_0x387b91,_0x39e4ca)!=null;}function Se(_0x269a6d){return Bn(_0x269a6d)!=null;}function Bn(_0x435e19){for(const _0x31e341 of _0x435e19['views']['values']())if(_0x31e341['query']['_queryParams']['loadsAllData']())return _0x31e341;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x29d4bf){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x29d4bf;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3af124){this['listenProvider_']=_0x3af124,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2a9b37,_0x1d80a5,_0xa6870d,_0x142995,_0x2a7f9b){return lu(_0x2a9b37['pendingWriteTree_'],_0x1d80a5,_0xa6870d,_0x142995,_0x2a7f9b),_0x2a7f9b?_t(_0x2a9b37,new Be(es(),_0x1d80a5,_0xa6870d)):[];}function ju(_0x1ddd87,_0x1ec79c,_0x3ac5a7,_0x4f8794){hu(_0x1ddd87['pendingWriteTree_'],_0x1ec79c,_0x3ac5a7,_0x4f8794);const _0x5cbe78=b['fromObject'](_0x3ac5a7);return _t(_0x1ddd87,new ot(es(),_0x1ec79c,_0x5cbe78));}function _e(_0x527889,_0x3b4411,_0x19bd44=!0x1){const _0x2cd52d=uu(_0x527889['pendingWriteTree_'],_0x3b4411);if(du(_0x527889['pendingWriteTree_'],_0x3b4411)){let _0x148145=new b(null);return _0x2cd52d['snap']!=null?_0x148145=_0x148145['set'](w(),!0x0):x(_0x2cd52d['children'],_0x2bd932=>{_0x148145=_0x148145['set'](new C(_0x2bd932),!0x0);}),_t(_0x527889,new In(_0x2cd52d['path'],_0x148145,_0x19bd44));}else return[];}function Yt(_0xc0d2cc,_0x413297,_0x22d759){return _t(_0xc0d2cc,new Be(ts(),_0x413297,_0x22d759));}function Ku(_0xdfaac1,_0x5004b4,_0x1de9a0){const _0x13aae1=b['fromObject'](_0x1de9a0);return _t(_0xdfaac1,new ot(ts(),_0x5004b4,_0x13aae1));}function Yu(_0x4ed2a0,_0x558518){return _t(_0x4ed2a0,new Ut(ts(),_0x558518));}function Qu(_0x408d45,_0x5ceccc,_0x51fbc4){const _0x57c356=cs(_0x408d45,_0x51fbc4);if(_0x57c356){const _0x334443=ls(_0x57c356),_0xf5b181=_0x334443['path'],_0xf59bbf=_0x334443['queryId'],_0x557a68=F(_0xf5b181,_0x5ceccc),_0x24c16c=new Ut(ns(_0xf59bbf),_0x557a68);return hs(_0x408d45,_0xf5b181,_0x24c16c);}else return[];}function An(_0x454093,_0x50db05,_0x11035f,_0x1e1709,_0x32a600=!0x1){const _0x301b64=_0x50db05['_path'],_0x173e16=_0x454093['syncPointTree_']['get'](_0x301b64);let _0xcd98ec=[];if(_0x173e16&&(_0x50db05['_queryIdentifier']==='default'||Qo(_0x173e16,_0x50db05))){const _0x222d02=$u(_0x173e16,_0x50db05,_0x11035f,_0x1e1709);Vu(_0x173e16)&&(_0x454093['syncPointTree_']=_0x454093['syncPointTree_']['remove'](_0x301b64));const _0x278eb5=_0x222d02['removed'];if(_0xcd98ec=_0x222d02['events'],!_0x32a600){const _0x4bf622=_0x278eb5['findIndex'](_0x8ee339=>_0x8ee339['_queryParams']['loadsAllData']())!==-0x1,_0x365e4c=_0x454093['syncPointTree_']['findOnPath'](_0x301b64,(_0x2d4a86,_0x4cc1de)=>Se(_0x4cc1de));if(_0x4bf622&&!_0x365e4c){const _0x59371c=_0x454093['syncPointTree_']['subtree'](_0x301b64);if(!_0x59371c['isEmpty']()){const _0x745f86=Zu(_0x59371c);for(let _0x1cc64e=0x0;_0x1cc64e<_0x745f86['length'];++_0x1cc64e){const _0x4026a1=_0x745f86[_0x1cc64e],_0x373d34=_0x4026a1['query'],_0x3493be=ea(_0x454093,_0x4026a1);_0x454093['listenProvider_']['startListening'](kt(_0x373d34),Wt(_0x454093,_0x373d34),_0x3493be['hashFn'],_0x3493be['onComplete']);}}}!_0x365e4c&&_0x278eb5['length']>0x0&&!_0x1e1709&&(_0x4bf622?_0x454093['listenProvider_']['stopListening'](kt(_0x50db05),null):_0x278eb5['forEach'](_0x5aad9e=>{const _0x226a4f=_0x454093['queryToTagMap']['get'](Hn(_0x5aad9e));_0x454093['listenProvider_']['stopListening'](kt(_0x5aad9e),_0x226a4f);}));}ed(_0x454093,_0x278eb5);}return _0xcd98ec;}function Jo(_0x303545,_0x32ef66,_0x21ce22,_0x2a8ba8){const _0x3e3169=cs(_0x303545,_0x2a8ba8);if(_0x3e3169!=null){const _0x443eb8=ls(_0x3e3169),_0x824011=_0x443eb8['path'],_0x21ae95=_0x443eb8['queryId'],_0x2144ab=F(_0x824011,_0x32ef66),_0xd4b8d3=new Be(ns(_0x21ae95),_0x2144ab,_0x21ce22);return hs(_0x303545,_0x824011,_0xd4b8d3);}else return[];}function Ju(_0x21b5aa,_0x46ad4f,_0x19ad70,_0x464df3){const _0x40ef51=cs(_0x21b5aa,_0x464df3);if(_0x40ef51){const _0x43884c=ls(_0x40ef51),_0x28b25f=_0x43884c['path'],_0x4196e0=_0x43884c['queryId'],_0x4c551b=F(_0x28b25f,_0x46ad4f),_0x2110dd=b['fromObject'](_0x19ad70),_0x45dd26=new ot(ns(_0x4196e0),_0x4c551b,_0x2110dd);return hs(_0x21b5aa,_0x28b25f,_0x45dd26);}else return[];}function Ni(_0x1dc925,_0x397861,_0x35218e,_0xbe83a9=!0x1){const _0x5b44aa=_0x397861['_path'];let _0x53c340=null,_0x40cf86=!0x1;_0x1dc925['syncPointTree_']['foreachOnPath'](_0x5b44aa,(_0x221f7e,_0x19282d)=>{const _0x5957ce=F(_0x221f7e,_0x5b44aa);_0x53c340=_0x53c340||Ie(_0x19282d,_0x5957ce),_0x40cf86=_0x40cf86||Se(_0x19282d);});let _0x4ff420=_0x1dc925['syncPointTree_']['get'](_0x5b44aa);_0x4ff420?(_0x40cf86=_0x40cf86||Se(_0x4ff420),_0x53c340=_0x53c340||Ie(_0x4ff420,w())):(_0x4ff420=new zo(),_0x1dc925['syncPointTree_']=_0x1dc925['syncPointTree_']['set'](_0x5b44aa,_0x4ff420));let _0x4ef6d8;_0x53c340!=null?_0x4ef6d8=!0x0:(_0x4ef6d8=!0x1,_0x53c340=g['EMPTY_NODE'],_0x1dc925['syncPointTree_']['subtree'](_0x5b44aa)['foreachChild']((_0x107e06,_0x207869)=>{const _0x39fd01=Ie(_0x207869,w());_0x39fd01&&(_0x53c340=_0x53c340['updateImmediateChild'](_0x107e06,_0x39fd01));}));const _0x51e2c3=Qo(_0x4ff420,_0x397861);if(!_0x51e2c3&&!_0x397861['_queryParams']['loadsAllData']()){const _0x7abf48=Hn(_0x397861);f(!_0x1dc925['queryToTagMap']['has'](_0x7abf48),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x25a4bf=td();_0x1dc925['queryToTagMap']['set'](_0x7abf48,_0x25a4bf),_0x1dc925['tagToQueryMap']['set'](_0x25a4bf,_0x7abf48);}const _0x44d4aa=Wn(_0x1dc925['pendingWriteTree_'],_0x5b44aa);let _0x258977=Hu(_0x4ff420,_0x397861,_0x35218e,_0x44d4aa,_0x53c340,_0x4ef6d8);if(!_0x51e2c3&&!_0x40cf86&&!_0xbe83a9){const _0x298196=Yo(_0x4ff420,_0x397861);_0x258977=_0x258977['concat'](nd(_0x1dc925,_0x397861,_0x298196));}return _0x258977;}function Vn(_0x222584,_0xa8a616,_0x137c72){const _0x2ac2ad=_0x222584['pendingWriteTree_'],_0x75a7af=_0x222584['syncPointTree_']['findOnPath'](_0xa8a616,(_0x268e73,_0x495b43)=>{const _0x5cbb08=F(_0x268e73,_0xa8a616),_0x48dfc9=Ie(_0x495b43,_0x5cbb08);if(_0x48dfc9)return _0x48dfc9;});return Bo(_0x2ac2ad,_0xa8a616,_0x75a7af,_0x137c72,!0x0);}function Xu(_0x432882,_0x130c61){const _0x117b74=_0x130c61['_path'];let _0x3352df=null;_0x432882['syncPointTree_']['foreachOnPath'](_0x117b74,(_0x32d08c,_0x4b34ca)=>{const _0x35cf0e=F(_0x32d08c,_0x117b74);_0x3352df=_0x3352df||Ie(_0x4b34ca,_0x35cf0e);});let _0x2f7b88=_0x432882['syncPointTree_']['get'](_0x117b74);_0x2f7b88?_0x3352df=_0x3352df||Ie(_0x2f7b88,w()):(_0x2f7b88=new zo(),_0x432882['syncPointTree_']=_0x432882['syncPointTree_']['set'](_0x117b74,_0x2f7b88));const _0x2ad8fe=_0x3352df!=null,_0x4e28e7=_0x2ad8fe?new Te(_0x3352df,!0x0,!0x1):null,_0x486e93=Wn(_0x432882['pendingWriteTree_'],_0x130c61['_path']),_0x268a07=jo(_0x2f7b88,_0x130c61,_0x486e93,_0x2ad8fe?_0x4e28e7['getNode']():g['EMPTY_NODE'],_0x2ad8fe);return Lu(_0x268a07);}function _t(_0x47a122,_0x50575a){return Xo(_0x50575a,_0x47a122['syncPointTree_'],null,Wn(_0x47a122['pendingWriteTree_'],w()));}function Xo(_0x237540,_0x47950a,_0x2a68fa,_0x6c8e05){if(v(_0x237540['path']))return Zo(_0x237540,_0x47950a,_0x2a68fa,_0x6c8e05);{const _0x41776c=_0x47950a['get'](w());_0x2a68fa==null&&_0x41776c!=null&&(_0x2a68fa=Ie(_0x41776c,w()));let _0xb63c55=[];const _0xc357a9=y(_0x237540['path']),_0x4dafcc=_0x237540['operationForChild'](_0xc357a9),_0x312399=_0x47950a['children']['get'](_0xc357a9);if(_0x312399&&_0x4dafcc){const _0x37603e=_0x2a68fa?_0x2a68fa['getImmediateChild'](_0xc357a9):null,_0x16e894=Vo(_0x6c8e05,_0xc357a9);_0xb63c55=_0xb63c55['concat'](Xo(_0x4dafcc,_0x312399,_0x37603e,_0x16e894));}return _0x41776c&&(_0xb63c55=_0xb63c55['concat'](os(_0x41776c,_0x237540,_0x6c8e05,_0x2a68fa))),_0xb63c55;}}function Zo(_0x803f80,_0x98aca1,_0x29e404,_0x17a722){const _0x305be1=_0x98aca1['get'](w());_0x29e404==null&&_0x305be1!=null&&(_0x29e404=Ie(_0x305be1,w()));let _0xe75c7=[];return _0x98aca1['children']['inorderTraversal']((_0x53a5e8,_0x11b86e)=>{const _0x2e8d03=_0x29e404?_0x29e404['getImmediateChild'](_0x53a5e8):null,_0xf57bad=Vo(_0x17a722,_0x53a5e8),_0x4ba4a6=_0x803f80['operationForChild'](_0x53a5e8);_0x4ba4a6&&(_0xe75c7=_0xe75c7['concat'](Zo(_0x4ba4a6,_0x11b86e,_0x2e8d03,_0xf57bad)));}),_0x305be1&&(_0xe75c7=_0xe75c7['concat'](os(_0x305be1,_0x803f80,_0x17a722,_0x29e404))),_0xe75c7;}function ea(_0x1e1991,_0x286768){const _0x2730ec=_0x286768['query'],_0x56d15e=Wt(_0x1e1991,_0x2730ec);return{'hashFn':()=>(Mu(_0x286768)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4c7006=>{if(_0x4c7006==='ok')return _0x56d15e?Qu(_0x1e1991,_0x2730ec['_path'],_0x56d15e):Yu(_0x1e1991,_0x2730ec['_path']);{const _0x5c1863=Kl(_0x4c7006,_0x2730ec);return An(_0x1e1991,_0x2730ec,null,_0x5c1863);}}};}function Wt(_0x2dbe55,_0x3d9dc4){const _0x1f9203=Hn(_0x3d9dc4);return _0x2dbe55['queryToTagMap']['get'](_0x1f9203);}function Hn(_0x9df0f3){return _0x9df0f3['_path']['toString']()+'$'+_0x9df0f3['_queryIdentifier'];}function cs(_0x5036c4,_0xdf8de8){return _0x5036c4['tagToQueryMap']['get'](_0xdf8de8);}function ls(_0x2c55b2){const _0x7ef9=_0x2c55b2['indexOf']('$');return f(_0x7ef9!==-0x1&&_0x7ef9<_0x2c55b2['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2c55b2['substr'](_0x7ef9+0x1),'path':new C(_0x2c55b2['substr'](0x0,_0x7ef9))};}function hs(_0x282cf7,_0x306103,_0x9f66f3){const _0x2d27f2=_0x282cf7['syncPointTree_']['get'](_0x306103);f(_0x2d27f2,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3c4305=Wn(_0x282cf7['pendingWriteTree_'],_0x306103);return os(_0x2d27f2,_0x9f66f3,_0x3c4305,null);}function Zu(_0x5a8a2b){return _0x5a8a2b['fold']((_0xaca3a8,_0x1476bc,_0x469cdd)=>{if(_0x1476bc&&Se(_0x1476bc))return[Bn(_0x1476bc)];{let _0x4bce43=[];return _0x1476bc&&(_0x4bce43=Ko(_0x1476bc)),x(_0x469cdd,(_0x463518,_0x5adbe8)=>{_0x4bce43=_0x4bce43['concat'](_0x5adbe8);}),_0x4bce43;}});}function kt(_0x50ca21){return _0x50ca21['_queryParams']['loadsAllData']()&&!_0x50ca21['_queryParams']['isDefault']()?new(qu())(_0x50ca21['_repo'],_0x50ca21['_path']):_0x50ca21;}function ed(_0x2d07e3,_0x37cf2a){for(let _0x2cbd0a=0x0;_0x2cbd0a<_0x37cf2a['length'];++_0x2cbd0a){const _0x352871=_0x37cf2a[_0x2cbd0a];if(!_0x352871['_queryParams']['loadsAllData']()){const _0x4f09ff=Hn(_0x352871),_0x4f5fea=_0x2d07e3['queryToTagMap']['get'](_0x4f09ff);_0x2d07e3['queryToTagMap']['delete'](_0x4f09ff),_0x2d07e3['tagToQueryMap']['delete'](_0x4f5fea);}}}function td(){return zu++;}function nd(_0x42134d,_0x14dd2a,_0x3c921d){const _0x38983a=_0x14dd2a['_path'],_0x59382f=Wt(_0x42134d,_0x14dd2a),_0x3eebc6=ea(_0x42134d,_0x3c921d),_0x5b2b92=_0x42134d['listenProvider_']['startListening'](kt(_0x14dd2a),_0x59382f,_0x3eebc6['hashFn'],_0x3eebc6['onComplete']),_0x46ff23=_0x42134d['syncPointTree_']['subtree'](_0x38983a);if(_0x59382f)f(!Se(_0x46ff23['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x29ea95=_0x46ff23['fold']((_0x1eae4b,_0x5f4b5f,_0x16ca41)=>{if(!v(_0x1eae4b)&&_0x5f4b5f&&Se(_0x5f4b5f))return[Bn(_0x5f4b5f)['query']];{let _0x5308de=[];return _0x5f4b5f&&(_0x5308de=_0x5308de['concat'](Ko(_0x5f4b5f)['map'](_0x1f2815=>_0x1f2815['query']))),x(_0x16ca41,(_0x4115fc,_0x5be0f1)=>{_0x5308de=_0x5308de['concat'](_0x5be0f1);}),_0x5308de;}});for(let _0x5f35bc=0x0;_0x5f35bc<_0x29ea95['length'];++_0x5f35bc){const _0x50f039=_0x29ea95[_0x5f35bc];_0x42134d['listenProvider_']['stopListening'](kt(_0x50f039),Wt(_0x42134d,_0x50f039));}}return _0x5b2b92;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x46659f){this['node_']=_0x46659f;}['getImmediateChild'](_0x406cf7){const _0x3b5a7a=this['node_']['getImmediateChild'](_0x406cf7);return new us(_0x3b5a7a);}['node'](){return this['node_'];}}class ds{constructor(_0xf00372,_0x1bd572){this['syncTree_']=_0xf00372,this['path_']=_0x1bd572;}['getImmediateChild'](_0x343664){const _0x217ad8=k(this['path_'],_0x343664);return new ds(this['syncTree_'],_0x217ad8);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x5291fc){return _0x5291fc=_0x5291fc||{},_0x5291fc['timestamp']=_0x5291fc['timestamp']||new Date()['getTime'](),_0x5291fc;},_r=function(_0x312f98,_0x36702a,_0x5eeccf){if(!_0x312f98||typeof _0x312f98!='object')return _0x312f98;if(f('.sv'in _0x312f98,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x312f98['.sv']=='string')return sd(_0x312f98['.sv'],_0x36702a,_0x5eeccf);if(typeof _0x312f98['.sv']=='object')return rd(_0x312f98['.sv'],_0x36702a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x312f98,null,0x2));},sd=function(_0x489e09,_0x5e86e6,_0x580421){switch(_0x489e09){case'timestamp':return _0x580421['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x489e09);}},rd=function(_0xc3de74,_0x58abec,_0x1593e1){_0xc3de74['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xc3de74,null,0x2));const _0x2eda61=_0xc3de74['increment'];typeof _0x2eda61!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2eda61);const _0x43f55a=_0x58abec['node']();if(f(_0x43f55a!==null&&typeof _0x43f55a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x43f55a['isLeafNode']())return _0x2eda61;const _0x4fef43=_0x43f55a['getValue']();return typeof _0x4fef43!='number'?_0x2eda61:_0x4fef43+_0x2eda61;},ta=function(_0x3f2502,_0x46d881,_0x377044,_0x1abccf){return ps(_0x46d881,new ds(_0x377044,_0x3f2502),_0x1abccf);},fs=function(_0x137044,_0x224570,_0x46c1f1){return ps(_0x137044,new us(_0x224570),_0x46c1f1);};function ps(_0x51b1b0,_0x4908bf,_0xb300d9){const _0x357cc5=_0x51b1b0['getPriority']()['val'](),_0x4afdc7=_r(_0x357cc5,_0x4908bf['getImmediateChild']('.priority'),_0xb300d9);let _0x430874;if(_0x51b1b0['isLeafNode']()){const _0x136df6=_0x51b1b0,_0x1518ed=_r(_0x136df6['getValue'](),_0x4908bf,_0xb300d9);return _0x1518ed!==_0x136df6['getValue']()||_0x4afdc7!==_0x136df6['getPriority']()['val']()?new D(_0x1518ed,A(_0x4afdc7)):_0x51b1b0;}else{const _0x4c3102=_0x51b1b0;return _0x430874=_0x4c3102,_0x4afdc7!==_0x4c3102['getPriority']()['val']()&&(_0x430874=_0x430874['updatePriority'](new D(_0x4afdc7))),_0x4c3102['forEachChild'](R,(_0x1ed404,_0x3ae2b0)=>{const _0x24a87c=ps(_0x3ae2b0,_0x4908bf['getImmediateChild'](_0x1ed404),_0xb300d9);_0x24a87c!==_0x3ae2b0&&(_0x430874=_0x430874['updateImmediateChild'](_0x1ed404,_0x24a87c));}),_0x430874;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x4d3053='',_0x398a51=null,_0x5b84cf={'children':{},'childCount':0x0}){this['name']=_0x4d3053,this['parent']=_0x398a51,this['node']=_0x5b84cf;}}function $n(_0x46d9d9,_0x45ff41){let _0x205e1e=_0x45ff41 instanceof C?_0x45ff41:new C(_0x45ff41),_0x3486ac=_0x46d9d9,_0x2d3615=y(_0x205e1e);for(;_0x2d3615!==null;){const _0x4e5494=Le(_0x3486ac['node']['children'],_0x2d3615)||{'children':{},'childCount':0x0};_0x3486ac=new _s(_0x2d3615,_0x3486ac,_0x4e5494),_0x205e1e=S(_0x205e1e),_0x2d3615=y(_0x205e1e);}return _0x3486ac;}function je(_0x5a1504){return _0x5a1504['node']['value'];}function gs(_0x299335,_0x51816b){_0x299335['node']['value']=_0x51816b,Oi(_0x299335);}function na(_0x4c3cfe){return _0x4c3cfe['node']['childCount']>0x0;}function od(_0x1cb2e4){return je(_0x1cb2e4)===void 0x0&&!na(_0x1cb2e4);}function Gn(_0x4fd04f,_0x707423){x(_0x4fd04f['node']['children'],(_0x46c957,_0x34642b)=>{_0x707423(new _s(_0x46c957,_0x4fd04f,_0x34642b));});}function ia(_0x48e093,_0x33b31d,_0x27b768,_0x5c4d54){_0x27b768&&_0x33b31d(_0x48e093),Gn(_0x48e093,_0x43a0c6=>{ia(_0x43a0c6,_0x33b31d,!0x0);});}function ad(_0xc8eb3,_0xd8faaa,_0x42d144){let _0x1efe53=_0xc8eb3['parent'];for(;_0x1efe53!==null;){if(_0xd8faaa(_0x1efe53))return!0x0;_0x1efe53=_0x1efe53['parent'];}return!0x1;}function Qt(_0x197c85){return new C(_0x197c85['parent']===null?_0x197c85['name']:Qt(_0x197c85['parent'])+'/'+_0x197c85['name']);}function Oi(_0x5b5113){_0x5b5113['parent']!==null&&cd(_0x5b5113['parent'],_0x5b5113['name'],_0x5b5113);}function cd(_0x304824,_0x2652bc,_0x162fb3){const _0x5d4c0f=od(_0x162fb3),_0x274ad7=Q(_0x304824['node']['children'],_0x2652bc);_0x5d4c0f&&_0x274ad7?(delete _0x304824['node']['children'][_0x2652bc],_0x304824['node']['childCount']--,Oi(_0x304824)):!_0x5d4c0f&&!_0x274ad7&&(_0x304824['node']['children'][_0x2652bc]=_0x162fb3['node'],_0x304824['node']['childCount']++,Oi(_0x304824));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3b3287){return typeof _0x3b3287=='string'&&_0x3b3287['length']!==0x0&&!ld['test'](_0x3b3287);},sa=function(_0x40537d){return typeof _0x40537d=='string'&&_0x40537d['length']!==0x0&&!hd['test'](_0x40537d);},ud=function(_0x2749e5){return _0x2749e5&&(_0x2749e5=_0x2749e5['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x2749e5);},Bt=function(_0x5303b2){return _0x5303b2===null||typeof _0x5303b2=='string'||typeof _0x5303b2=='number'&&!xn(_0x5303b2)||_0x5303b2&&typeof _0x5303b2=='object'&&Q(_0x5303b2,'.sv');},He=function(_0x1d6ec1,_0x6b56fe,_0x20f80a,_0x222551){_0x222551&&_0x6b56fe===void 0x0||Jt(it(_0x1d6ec1,'value'),_0x6b56fe,_0x20f80a);},Jt=function(_0xa6eba0,_0x1a3b7d,_0x518ebb){const _0x1e239c=_0x518ebb instanceof C?new Ah(_0x518ebb,_0xa6eba0):_0x518ebb;if(_0x1a3b7d===void 0x0)throw new Error(_0xa6eba0+'contains\x20undefined\x20'+Oe(_0x1e239c));if(typeof _0x1a3b7d=='function')throw new Error(_0xa6eba0+'contains\x20a\x20function\x20'+Oe(_0x1e239c)+'\x20with\x20contents\x20=\x20'+_0x1a3b7d['toString']());if(xn(_0x1a3b7d))throw new Error(_0xa6eba0+'contains\x20'+_0x1a3b7d['toString']()+'\x20'+Oe(_0x1e239c));if(typeof _0x1a3b7d=='string'&&_0x1a3b7d['length']>ui/0x3&&Ln(_0x1a3b7d)>ui)throw new Error(_0xa6eba0+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x1e239c)+'\x20(\x27'+_0x1a3b7d['substring'](0x0,0x32)+'...\x27)');if(_0x1a3b7d&&typeof _0x1a3b7d=='object'){let _0x4d47e9=!0x1,_0x122bfc=!0x1;if(x(_0x1a3b7d,(_0xf60194,_0x208461)=>{if(_0xf60194==='.value')_0x4d47e9=!0x0;else{if(_0xf60194!=='.priority'&&_0xf60194!=='.sv'&&(_0x122bfc=!0x0,!ms(_0xf60194)))throw new Error(_0xa6eba0+'\x20contains\x20an\x20invalid\x20key\x20('+_0xf60194+')\x20'+Oe(_0x1e239c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x1e239c,_0xf60194),Jt(_0xa6eba0,_0x208461,_0x1e239c),Ph(_0x1e239c);}),_0x4d47e9&&_0x122bfc)throw new Error(_0xa6eba0+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x1e239c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3c69bc,_0x5e3a86){let _0x35f392,_0x56ee4b;for(_0x35f392=0x0;_0x35f392<_0x5e3a86['length'];_0x35f392++){_0x56ee4b=_0x5e3a86[_0x35f392];const _0x234945=Mt(_0x56ee4b);for(let _0x438e6a=0x0;_0x438e6a<_0x234945['length'];_0x438e6a++)if(!(_0x234945[_0x438e6a]==='.priority'&&_0x438e6a===_0x234945['length']-0x1)){if(!ms(_0x234945[_0x438e6a]))throw new Error(_0x3c69bc+'contains\x20an\x20invalid\x20key\x20('+_0x234945[_0x438e6a]+')\x20in\x20path\x20'+_0x56ee4b['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5e3a86['sort'](Rh);let _0xff7a15=null;for(_0x35f392=0x0;_0x35f392<_0x5e3a86['length'];_0x35f392++){if(_0x56ee4b=_0x5e3a86[_0x35f392],_0xff7a15!==null&&G(_0xff7a15,_0x56ee4b))throw new Error(_0x3c69bc+'contains\x20a\x20path\x20'+_0xff7a15['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x56ee4b['toString']());_0xff7a15=_0x56ee4b;}},ra=function(_0x306519,_0x35d56a,_0x2adb14,_0x11e0c7){const _0x22bd16=it(_0x306519,'values');if(!(_0x35d56a&&typeof _0x35d56a=='object')||Array['isArray'](_0x35d56a))throw new Error(_0x22bd16+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xd5aee=[];x(_0x35d56a,(_0x429244,_0x212f3a)=>{const _0x4d3d29=new C(_0x429244);if(Jt(_0x22bd16,_0x212f3a,k(_0x2adb14,_0x4d3d29)),ji(_0x4d3d29)==='.priority'&&!Bt(_0x212f3a))throw new Error(_0x22bd16+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4d3d29['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xd5aee['push'](_0x4d3d29);}),dd(_0x22bd16,_0xd5aee);},fd=function(_0x2ef8f9,_0x2f240d,_0x25c07a){if(xn(_0x2f240d))throw new Error(it(_0x2ef8f9,'priority')+'is\x20'+_0x2f240d['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2f240d))throw new Error(it(_0x2ef8f9,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x23d773,_0x5168c7,_0x2a09bc,_0x2f9c86){if(!sa(_0x2a09bc))throw new Error(it(_0x23d773,_0x5168c7)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2a09bc+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x10d338,_0x435617,_0x5a8eee,_0x3d2497){_0x5a8eee&&(_0x5a8eee=_0x5a8eee['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x10d338,_0x435617,_0x5a8eee);},Me=function(_0xa982d8,_0x159d97){if(y(_0x159d97)==='.info')throw new Error(_0xa982d8+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3065b3,_0x1611fe){const _0xdf2093=_0x1611fe['path']['toString']();if(typeof _0x1611fe['repoInfo']['host']!='string'||_0x1611fe['repoInfo']['host']['length']===0x0||!ms(_0x1611fe['repoInfo']['namespace'])&&_0x1611fe['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xdf2093['length']!==0x0&&!ud(_0xdf2093))throw new Error(it(_0x3065b3,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x35f34b,_0x1613b7){let _0x1926cc=null;for(let _0x357b3e=0x0;_0x357b3e<_0x1613b7['length'];_0x357b3e++){const _0x3956bd=_0x1613b7[_0x357b3e],_0xc12a04=_0x3956bd['getPath']();_0x1926cc!==null&&!Ki(_0xc12a04,_0x1926cc['path'])&&(_0x35f34b['eventLists_']['push'](_0x1926cc),_0x1926cc=null),_0x1926cc===null&&(_0x1926cc={'events':[],'path':_0xc12a04}),_0x1926cc['events']['push'](_0x3956bd);}_0x1926cc&&_0x35f34b['eventLists_']['push'](_0x1926cc);}function oa(_0x24cf45,_0x224ebd,_0x24acfe){qn(_0x24cf45,_0x24acfe),aa(_0x24cf45,_0x3ed68a=>Ki(_0x3ed68a,_0x224ebd));}function V(_0x1210d1,_0x545f66,_0x16d9b9){qn(_0x1210d1,_0x16d9b9),aa(_0x1210d1,_0x12bfa5=>G(_0x12bfa5,_0x545f66)||G(_0x545f66,_0x12bfa5));}function aa(_0x3585e3,_0x2d337e){_0x3585e3['recursionDepth_']++;let _0x49b607=!0x0;for(let _0x365735=0x0;_0x365735<_0x3585e3['eventLists_']['length'];_0x365735++){const _0x595a4c=_0x3585e3['eventLists_'][_0x365735];if(_0x595a4c){const _0x1c8576=_0x595a4c['path'];_0x2d337e(_0x1c8576)?(md(_0x3585e3['eventLists_'][_0x365735]),_0x3585e3['eventLists_'][_0x365735]=null):_0x49b607=!0x1;}}_0x49b607&&(_0x3585e3['eventLists_']=[]),_0x3585e3['recursionDepth_']--;}function md(_0x5d25a3){for(let _0x1853a9=0x0;_0x1853a9<_0x5d25a3['events']['length'];_0x1853a9++){const _0x593379=_0x5d25a3['events'][_0x1853a9];if(_0x593379!==null){_0x5d25a3['events'][_0x1853a9]=null;const _0x40a64b=_0x593379['getEventRunner']();St&&L('event:\x20'+_0x593379['toString']()),ft(_0x40a64b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x487a73,_0x387d79,_0xc172de,_0x934739){this['repoInfo_']=_0x487a73,this['forceRestClient_']=_0x387d79,this['authTokenProvider_']=_0xc172de,this['appCheckProvider_']=_0x934739,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x335f4b,_0x3d6620,_0x33f97c){if(_0x335f4b['stats_']=qi(_0x335f4b['repoInfo_']),_0x335f4b['forceRestClient_']||Xl())_0x335f4b['server_']=new vn(_0x335f4b['repoInfo_'],(_0x21cae9,_0x293c70,_0x27dcc2,_0x2f77c4)=>{gr(_0x335f4b,_0x21cae9,_0x293c70,_0x27dcc2,_0x2f77c4);},_0x335f4b['authTokenProvider_'],_0x335f4b['appCheckProvider_']),setTimeout(()=>mr(_0x335f4b,!0x0),0x0);else{if(typeof _0x33f97c<'u'&&_0x33f97c!==null){if(typeof _0x33f97c!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x33f97c);}catch(_0x97f8c5){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x97f8c5);}}_0x335f4b['persistentConnection_']=new se(_0x335f4b['repoInfo_'],_0x3d6620,(_0x60d7c,_0x294708,_0x4d1e7f,_0x362665)=>{gr(_0x335f4b,_0x60d7c,_0x294708,_0x4d1e7f,_0x362665);},_0xbc3fd4=>{mr(_0x335f4b,_0xbc3fd4);},_0x20a5eb=>{Id(_0x335f4b,_0x20a5eb);},_0x335f4b['authTokenProvider_'],_0x335f4b['appCheckProvider_'],_0x33f97c),_0x335f4b['server_']=_0x335f4b['persistentConnection_'];}_0x335f4b['authTokenProvider_']['addTokenChangeListener'](_0x7be373=>{_0x335f4b['server_']['refreshAuthToken'](_0x7be373);}),_0x335f4b['appCheckProvider_']['addTokenChangeListener'](_0x567d67=>{_0x335f4b['server_']['refreshAppCheckToken'](_0x567d67['token']);}),_0x335f4b['statsReporter_']=ih(_0x335f4b['repoInfo_'],()=>new iu(_0x335f4b['stats_'],_0x335f4b['server_'])),_0x335f4b['infoData_']=new Xh(),_0x335f4b['infoSyncTree_']=new pr({'startListening':(_0x1f0d4a,_0x2bc94b,_0xe739ed,_0x51d443)=>{let _0x41426c=[];const _0xfa8abc=_0x335f4b['infoData_']['getNode'](_0x1f0d4a['_path']);return _0xfa8abc['isEmpty']()||(_0x41426c=Yt(_0x335f4b['infoSyncTree_'],_0x1f0d4a['_path'],_0xfa8abc),setTimeout(()=>{_0x51d443('ok');},0x0)),_0x41426c;},'stopListening':()=>{}}),vs(_0x335f4b,'connected',!0x1),_0x335f4b['serverSyncTree_']=new pr({'startListening':(_0x1c4979,_0x192ce5,_0x3f4b0b,_0x389c70)=>(_0x335f4b['server_']['listen'](_0x1c4979,_0x3f4b0b,_0x192ce5,(_0x5e4cf6,_0x10739c)=>{const _0x3be4b7=_0x389c70(_0x5e4cf6,_0x10739c);V(_0x335f4b['eventQueue_'],_0x1c4979['_path'],_0x3be4b7);}),[]),'stopListening':(_0x24703d,_0x2f84a4)=>{_0x335f4b['server_']['unlisten'](_0x24703d,_0x2f84a4);}});}function la(_0x13e01a){const _0x368a5c=_0x13e01a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x368a5c;}function Xt(_0x34b9f3){return id({'timestamp':la(_0x34b9f3)});}function gr(_0x33a2fc,_0xe6c9c1,_0x5efa5a,_0x277d60,_0x1ca0e3){_0x33a2fc['dataUpdateCount']++;const _0x5615a0=new C(_0xe6c9c1);_0x5efa5a=_0x33a2fc['interceptServerDataCallback_']?_0x33a2fc['interceptServerDataCallback_'](_0xe6c9c1,_0x5efa5a):_0x5efa5a;let _0x22b8e7=[];if(_0x1ca0e3){if(_0x277d60){const _0x58c16b=_n(_0x5efa5a,_0x3623be=>A(_0x3623be));_0x22b8e7=Ju(_0x33a2fc['serverSyncTree_'],_0x5615a0,_0x58c16b,_0x1ca0e3);}else{const _0x354228=A(_0x5efa5a);_0x22b8e7=Jo(_0x33a2fc['serverSyncTree_'],_0x5615a0,_0x354228,_0x1ca0e3);}}else{if(_0x277d60){const _0x4acad4=_n(_0x5efa5a,_0x11d2e5=>A(_0x11d2e5));_0x22b8e7=Ku(_0x33a2fc['serverSyncTree_'],_0x5615a0,_0x4acad4);}else{const _0x6e61b7=A(_0x5efa5a);_0x22b8e7=Yt(_0x33a2fc['serverSyncTree_'],_0x5615a0,_0x6e61b7);}}let _0x2e4790=_0x5615a0;_0x22b8e7['length']>0x0&&(_0x2e4790=ct(_0x33a2fc,_0x5615a0)),V(_0x33a2fc['eventQueue_'],_0x2e4790,_0x22b8e7);}function mr(_0x5cab74,_0x2f572c){vs(_0x5cab74,'connected',_0x2f572c),_0x2f572c===!0x1&&Sd(_0x5cab74);}function Id(_0x783970,_0x4b24ee){x(_0x4b24ee,(_0x4b1eef,_0x514ac6)=>{vs(_0x783970,_0x4b1eef,_0x514ac6);});}function vs(_0x410050,_0x495bd5,_0x3cc1cc){const _0x4be629=new C('/.info/'+_0x495bd5),_0x3e5ed5=A(_0x3cc1cc);_0x410050['infoData_']['updateSnapshot'](_0x4be629,_0x3e5ed5);const _0x2f06d3=Yt(_0x410050['infoSyncTree_'],_0x4be629,_0x3e5ed5);V(_0x410050['eventQueue_'],_0x4be629,_0x2f06d3);}function zn(_0x35e6c8){return _0x35e6c8['nextWriteId_']++;}function wd(_0x12e325,_0x5e3e0e,_0x182195){const _0x23f44a=Xu(_0x12e325['serverSyncTree_'],_0x5e3e0e);return _0x23f44a!=null?Promise['resolve'](_0x23f44a):_0x12e325['server_']['get'](_0x5e3e0e)['then'](_0x545917=>{const _0x5ce9a0=A(_0x545917)['withIndex'](_0x5e3e0e['_queryParams']['getIndex']());Ni(_0x12e325['serverSyncTree_'],_0x5e3e0e,_0x182195,!0x0);let _0x557594;if(_0x5e3e0e['_queryParams']['loadsAllData']())_0x557594=Yt(_0x12e325['serverSyncTree_'],_0x5e3e0e['_path'],_0x5ce9a0);else{const _0x240826=Wt(_0x12e325['serverSyncTree_'],_0x5e3e0e);_0x557594=Jo(_0x12e325['serverSyncTree_'],_0x5e3e0e['_path'],_0x5ce9a0,_0x240826);}return V(_0x12e325['eventQueue_'],_0x5e3e0e['_path'],_0x557594),An(_0x12e325['serverSyncTree_'],_0x5e3e0e,_0x182195,null,!0x0),_0x5ce9a0;},_0x4f73c9=>(gt(_0x12e325,'get\x20for\x20query\x20'+O(_0x5e3e0e)+'\x20failed:\x20'+_0x4f73c9),Promise['reject'](new Error(_0x4f73c9))));}function Cd(_0x3f3021,_0x4bf612,_0x497bd3,_0x3a540a,_0x1debad){gt(_0x3f3021,'set',{'path':_0x4bf612['toString'](),'value':_0x497bd3,'priority':_0x3a540a});const _0x455c70=Xt(_0x3f3021),_0x373d46=A(_0x497bd3,_0x3a540a),_0x58a776=Vn(_0x3f3021['serverSyncTree_'],_0x4bf612),_0x4e5915=fs(_0x373d46,_0x58a776,_0x455c70),_0x21ae28=zn(_0x3f3021),_0x50dae3=as(_0x3f3021['serverSyncTree_'],_0x4bf612,_0x4e5915,_0x21ae28,!0x0);qn(_0x3f3021['eventQueue_'],_0x50dae3),_0x3f3021['server_']['put'](_0x4bf612['toString'](),_0x373d46['val'](!0x0),(_0x3d91ff,_0x3b079a)=>{const _0x30b88b=_0x3d91ff==='ok';_0x30b88b||U('set\x20at\x20'+_0x4bf612+'\x20failed:\x20'+_0x3d91ff);const _0x4c7d4d=_e(_0x3f3021['serverSyncTree_'],_0x21ae28,!_0x30b88b);V(_0x3f3021['eventQueue_'],_0x4bf612,_0x4c7d4d),be(_0x3f3021,_0x1debad,_0x3d91ff,_0x3b079a);});const _0x1338eb=Is(_0x3f3021,_0x4bf612);ct(_0x3f3021,_0x1338eb),V(_0x3f3021['eventQueue_'],_0x1338eb,[]);}function Td(_0x42e082,_0x47b920,_0x4198fb,_0x3b2d86){gt(_0x42e082,'update',{'path':_0x47b920['toString'](),'value':_0x4198fb});let _0x3e356f=!0x0;const _0x39f00e=Xt(_0x42e082),_0x5ad63b={};if(x(_0x4198fb,(_0x451604,_0x27a0b7)=>{_0x3e356f=!0x1,_0x5ad63b[_0x451604]=ta(k(_0x47b920,_0x451604),A(_0x27a0b7),_0x42e082['serverSyncTree_'],_0x39f00e);}),_0x3e356f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x42e082,_0x3b2d86,'ok',void 0x0);else{const _0x24378d=zn(_0x42e082),_0x3f34bb=ju(_0x42e082['serverSyncTree_'],_0x47b920,_0x5ad63b,_0x24378d);qn(_0x42e082['eventQueue_'],_0x3f34bb),_0x42e082['server_']['merge'](_0x47b920['toString'](),_0x4198fb,(_0x4d3c00,_0x1b3d88)=>{const _0x562630=_0x4d3c00==='ok';_0x562630||U('update\x20at\x20'+_0x47b920+'\x20failed:\x20'+_0x4d3c00);const _0x3e9d89=_e(_0x42e082['serverSyncTree_'],_0x24378d,!_0x562630),_0x163f62=_0x3e9d89['length']>0x0?ct(_0x42e082,_0x47b920):_0x47b920;V(_0x42e082['eventQueue_'],_0x163f62,_0x3e9d89),be(_0x42e082,_0x3b2d86,_0x4d3c00,_0x1b3d88);}),x(_0x4198fb,_0x5c714b=>{const _0xb13e8c=Is(_0x42e082,k(_0x47b920,_0x5c714b));ct(_0x42e082,_0xb13e8c);}),V(_0x42e082['eventQueue_'],_0x47b920,[]);}}function Sd(_0x18dcb6){gt(_0x18dcb6,'onDisconnectEvents');const _0x4097b3=Xt(_0x18dcb6),_0x58b9c9=En();Si(_0x18dcb6['onDisconnect_'],w(),(_0x18f12e,_0x8a578c)=>{const _0x377122=ta(_0x18f12e,_0x8a578c,_0x18dcb6['serverSyncTree_'],_0x4097b3);pt(_0x58b9c9,_0x18f12e,_0x377122);});let _0x30b0ba=[];Si(_0x58b9c9,w(),(_0x11de48,_0x39cd5d)=>{_0x30b0ba=_0x30b0ba['concat'](Yt(_0x18dcb6['serverSyncTree_'],_0x11de48,_0x39cd5d));const _0x104945=Is(_0x18dcb6,_0x11de48);ct(_0x18dcb6,_0x104945);}),_0x18dcb6['onDisconnect_']=En(),V(_0x18dcb6['eventQueue_'],w(),_0x30b0ba);}function bd(_0x496464,_0x3d7ab5,_0x39aba8){_0x496464['server_']['onDisconnectCancel'](_0x3d7ab5['toString'](),(_0x398562,_0x8b7f51)=>{_0x398562==='ok'&&Ti(_0x496464['onDisconnect_'],_0x3d7ab5),be(_0x496464,_0x39aba8,_0x398562,_0x8b7f51);});}function yr(_0x54d01e,_0x891b05,_0x515ee8,_0x244347){const _0x382d3b=A(_0x515ee8);_0x54d01e['server_']['onDisconnectPut'](_0x891b05['toString'](),_0x382d3b['val'](!0x0),(_0x11a69c,_0x1f986b)=>{_0x11a69c==='ok'&&pt(_0x54d01e['onDisconnect_'],_0x891b05,_0x382d3b),be(_0x54d01e,_0x244347,_0x11a69c,_0x1f986b);});}function Rd(_0x1f4303,_0xcfe207,_0xa5e2c0,_0x99e58a,_0x496a17){const _0x4a32f9=A(_0xa5e2c0,_0x99e58a);_0x1f4303['server_']['onDisconnectPut'](_0xcfe207['toString'](),_0x4a32f9['val'](!0x0),(_0x16430a,_0x12366f)=>{_0x16430a==='ok'&&pt(_0x1f4303['onDisconnect_'],_0xcfe207,_0x4a32f9),be(_0x1f4303,_0x496a17,_0x16430a,_0x12366f);});}function Ad(_0x7b2ab7,_0x5849c2,_0x230845,_0x392954){if(pn(_0x230845)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x7b2ab7,_0x392954,'ok',void 0x0);return;}_0x7b2ab7['server_']['onDisconnectMerge'](_0x5849c2['toString'](),_0x230845,(_0x506fe3,_0x556add)=>{_0x506fe3==='ok'&&x(_0x230845,(_0x5f4111,_0x2e5e30)=>{const _0x9f5ec1=A(_0x2e5e30);pt(_0x7b2ab7['onDisconnect_'],k(_0x5849c2,_0x5f4111),_0x9f5ec1);}),be(_0x7b2ab7,_0x392954,_0x506fe3,_0x556add);});}function kd(_0x2cbdc2,_0xf60f1e,_0x1e67da){let _0x215d12;y(_0xf60f1e['_path'])==='.info'?_0x215d12=Ni(_0x2cbdc2['infoSyncTree_'],_0xf60f1e,_0x1e67da):_0x215d12=Ni(_0x2cbdc2['serverSyncTree_'],_0xf60f1e,_0x1e67da),oa(_0x2cbdc2['eventQueue_'],_0xf60f1e['_path'],_0x215d12);}function Pd(_0x195e9d,_0x314756,_0x3042f3){let _0xaa0db9;y(_0x314756['_path'])==='.info'?_0xaa0db9=An(_0x195e9d['infoSyncTree_'],_0x314756,_0x3042f3):_0xaa0db9=An(_0x195e9d['serverSyncTree_'],_0x314756,_0x3042f3),oa(_0x195e9d['eventQueue_'],_0x314756['_path'],_0xaa0db9);}function ha(_0x467c8c){_0x467c8c['persistentConnection_']&&_0x467c8c['persistentConnection_']['interrupt'](ca);}function Nd(_0x2fdb24){_0x2fdb24['persistentConnection_']&&_0x2fdb24['persistentConnection_']['resume'](ca);}function gt(_0x482fba,..._0x17dfe2){let _0x49fa57='';_0x482fba['persistentConnection_']&&(_0x49fa57=_0x482fba['persistentConnection_']['id']+':'),L(_0x49fa57,..._0x17dfe2);}function be(_0x2c018e,_0x45301b,_0x1bc930,_0x2dc794){_0x45301b&&ft(()=>{if(_0x1bc930==='ok')_0x45301b(null);else{const _0x4d1115=(_0x1bc930||'error')['toUpperCase']();let _0x6eede3=_0x4d1115;_0x2dc794&&(_0x6eede3+=':\x20'+_0x2dc794);const _0x510a88=new Error(_0x6eede3);_0x510a88['code']=_0x4d1115,_0x45301b(_0x510a88);}});}function Od(_0x179aa8,_0x1ad0a6,_0x4086d2,_0x58c1ab,_0x4c4010,_0x20bb0e){gt(_0x179aa8,'transaction\x20on\x20'+_0x1ad0a6);const _0x2efdbf={'path':_0x1ad0a6,'update':_0x4086d2,'onComplete':_0x58c1ab,'status':null,'order':so(),'applyLocally':_0x20bb0e,'retryCount':0x0,'unwatcher':_0x4c4010,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x157dd2=Es(_0x179aa8,_0x1ad0a6,void 0x0);_0x2efdbf['currentInputSnapshot']=_0x157dd2;const _0x1dc23d=_0x2efdbf['update'](_0x157dd2['val']());if(_0x1dc23d===void 0x0)_0x2efdbf['unwatcher'](),_0x2efdbf['currentOutputSnapshotRaw']=null,_0x2efdbf['currentOutputSnapshotResolved']=null,_0x2efdbf['onComplete']&&_0x2efdbf['onComplete'](null,!0x1,_0x2efdbf['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1dc23d,_0x2efdbf['path']),_0x2efdbf['status']=0x0;const _0x1e5b31=$n(_0x179aa8['transactionQueueTree_'],_0x1ad0a6),_0x44630d=je(_0x1e5b31)||[];_0x44630d['push'](_0x2efdbf),gs(_0x1e5b31,_0x44630d);let _0x83f888;typeof _0x1dc23d=='object'&&_0x1dc23d!==null&&Q(_0x1dc23d,'.priority')?(_0x83f888=Le(_0x1dc23d,'.priority'),f(Bt(_0x83f888),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x83f888=(Vn(_0x179aa8['serverSyncTree_'],_0x1ad0a6)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x48a58c=Xt(_0x179aa8),_0x39f278=A(_0x1dc23d,_0x83f888),_0x20b7a1=fs(_0x39f278,_0x157dd2,_0x48a58c);_0x2efdbf['currentOutputSnapshotRaw']=_0x39f278,_0x2efdbf['currentOutputSnapshotResolved']=_0x20b7a1,_0x2efdbf['currentWriteId']=zn(_0x179aa8);const _0x5a7678=as(_0x179aa8['serverSyncTree_'],_0x1ad0a6,_0x20b7a1,_0x2efdbf['currentWriteId'],_0x2efdbf['applyLocally']);V(_0x179aa8['eventQueue_'],_0x1ad0a6,_0x5a7678),jn(_0x179aa8,_0x179aa8['transactionQueueTree_']);}}function Es(_0x35b573,_0x583a9f,_0x4abcff){return Vn(_0x35b573['serverSyncTree_'],_0x583a9f,_0x4abcff)||g['EMPTY_NODE'];}function jn(_0x4098ba,_0x2cb395=_0x4098ba['transactionQueueTree_']){if(_0x2cb395||Kn(_0x4098ba,_0x2cb395),je(_0x2cb395)){const _0x5a7e62=da(_0x4098ba,_0x2cb395);f(_0x5a7e62['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5a7e62['every'](_0x241380=>_0x241380['status']===0x0)&&Dd(_0x4098ba,Qt(_0x2cb395),_0x5a7e62);}else na(_0x2cb395)&&Gn(_0x2cb395,_0x1983c7=>{jn(_0x4098ba,_0x1983c7);});}function Dd(_0x31f93e,_0x2bd95e,_0x3869f4){const _0x49ad9b=_0x3869f4['map'](_0x5c0347=>_0x5c0347['currentWriteId']),_0x302d90=Es(_0x31f93e,_0x2bd95e,_0x49ad9b);let _0x3432cc=_0x302d90;const _0x4ba827=_0x302d90['hash']();for(let _0x3ed265=0x0;_0x3ed265<_0x3869f4['length'];_0x3ed265++){const _0x181f71=_0x3869f4[_0x3ed265];f(_0x181f71['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x181f71['status']=0x1,_0x181f71['retryCount']++;const _0x2061a4=F(_0x2bd95e,_0x181f71['path']);_0x3432cc=_0x3432cc['updateChild'](_0x2061a4,_0x181f71['currentOutputSnapshotRaw']);}const _0xa19bc6=_0x3432cc['val'](!0x0),_0xd416a4=_0x2bd95e;_0x31f93e['server_']['put'](_0xd416a4['toString'](),_0xa19bc6,_0x2f23ba=>{gt(_0x31f93e,'transaction\x20put\x20response',{'path':_0xd416a4['toString'](),'status':_0x2f23ba});let _0x38680a=[];if(_0x2f23ba==='ok'){const _0x2fbc25=[];for(let _0x5a0475=0x0;_0x5a0475<_0x3869f4['length'];_0x5a0475++)_0x3869f4[_0x5a0475]['status']=0x2,_0x38680a=_0x38680a['concat'](_e(_0x31f93e['serverSyncTree_'],_0x3869f4[_0x5a0475]['currentWriteId'])),_0x3869f4[_0x5a0475]['onComplete']&&_0x2fbc25['push'](()=>_0x3869f4[_0x5a0475]['onComplete'](null,!0x0,_0x3869f4[_0x5a0475]['currentOutputSnapshotResolved'])),_0x3869f4[_0x5a0475]['unwatcher']();Kn(_0x31f93e,$n(_0x31f93e['transactionQueueTree_'],_0x2bd95e)),jn(_0x31f93e,_0x31f93e['transactionQueueTree_']),V(_0x31f93e['eventQueue_'],_0x2bd95e,_0x38680a);for(let _0x5e5578=0x0;_0x5e5578<_0x2fbc25['length'];_0x5e5578++)ft(_0x2fbc25[_0x5e5578]);}else{if(_0x2f23ba==='datastale'){for(let _0x6d8f9d=0x0;_0x6d8f9d<_0x3869f4['length'];_0x6d8f9d++)_0x3869f4[_0x6d8f9d]['status']===0x3?_0x3869f4[_0x6d8f9d]['status']=0x4:_0x3869f4[_0x6d8f9d]['status']=0x0;}else{U('transaction\x20at\x20'+_0xd416a4['toString']()+'\x20failed:\x20'+_0x2f23ba);for(let _0x53d554=0x0;_0x53d554<_0x3869f4['length'];_0x53d554++)_0x3869f4[_0x53d554]['status']=0x4,_0x3869f4[_0x53d554]['abortReason']=_0x2f23ba;}ct(_0x31f93e,_0x2bd95e);}},_0x4ba827);}function ct(_0x320ecd,_0x52d67d){const _0x156be3=ua(_0x320ecd,_0x52d67d),_0x599435=Qt(_0x156be3),_0x45f327=da(_0x320ecd,_0x156be3);return Md(_0x320ecd,_0x45f327,_0x599435),_0x599435;}function Md(_0x582590,_0x2dd0df,_0x3f1d04){if(_0x2dd0df['length']===0x0)return;const _0x512018=[];let _0x27488f=[];const _0x8c48d3=_0x2dd0df['filter'](_0x1acd03=>_0x1acd03['status']===0x0)['map'](_0x2d7f23=>_0x2d7f23['currentWriteId']);for(let _0x4e31c3=0x0;_0x4e31c3<_0x2dd0df['length'];_0x4e31c3++){const _0x217d84=_0x2dd0df[_0x4e31c3],_0x115ec5=F(_0x3f1d04,_0x217d84['path']);let _0x304113=!0x1,_0x42fdec;if(f(_0x115ec5!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x217d84['status']===0x4)_0x304113=!0x0,_0x42fdec=_0x217d84['abortReason'],_0x27488f=_0x27488f['concat'](_e(_0x582590['serverSyncTree_'],_0x217d84['currentWriteId'],!0x0));else{if(_0x217d84['status']===0x0){if(_0x217d84['retryCount']>=yd)_0x304113=!0x0,_0x42fdec='maxretry',_0x27488f=_0x27488f['concat'](_e(_0x582590['serverSyncTree_'],_0x217d84['currentWriteId'],!0x0));else{const _0x20b363=Es(_0x582590,_0x217d84['path'],_0x8c48d3);_0x217d84['currentInputSnapshot']=_0x20b363;const _0x26661e=_0x2dd0df[_0x4e31c3]['update'](_0x20b363['val']());if(_0x26661e!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x26661e,_0x217d84['path']);let _0x33a2c0=A(_0x26661e);typeof _0x26661e=='object'&&_0x26661e!=null&&Q(_0x26661e,'.priority')||(_0x33a2c0=_0x33a2c0['updatePriority'](_0x20b363['getPriority']()));const _0x230f9f=_0x217d84['currentWriteId'],_0x5b9846=Xt(_0x582590),_0x3e30aa=fs(_0x33a2c0,_0x20b363,_0x5b9846);_0x217d84['currentOutputSnapshotRaw']=_0x33a2c0,_0x217d84['currentOutputSnapshotResolved']=_0x3e30aa,_0x217d84['currentWriteId']=zn(_0x582590),_0x8c48d3['splice'](_0x8c48d3['indexOf'](_0x230f9f),0x1),_0x27488f=_0x27488f['concat'](as(_0x582590['serverSyncTree_'],_0x217d84['path'],_0x3e30aa,_0x217d84['currentWriteId'],_0x217d84['applyLocally'])),_0x27488f=_0x27488f['concat'](_e(_0x582590['serverSyncTree_'],_0x230f9f,!0x0));}else _0x304113=!0x0,_0x42fdec='nodata',_0x27488f=_0x27488f['concat'](_e(_0x582590['serverSyncTree_'],_0x217d84['currentWriteId'],!0x0));}}}V(_0x582590['eventQueue_'],_0x3f1d04,_0x27488f),_0x27488f=[],_0x304113&&(_0x2dd0df[_0x4e31c3]['status']=0x2,function(_0x2ff86f){setTimeout(_0x2ff86f,Math['floor'](0x0));}(_0x2dd0df[_0x4e31c3]['unwatcher']),_0x2dd0df[_0x4e31c3]['onComplete']&&(_0x42fdec==='nodata'?_0x512018['push'](()=>_0x2dd0df[_0x4e31c3]['onComplete'](null,!0x1,_0x2dd0df[_0x4e31c3]['currentInputSnapshot'])):_0x512018['push'](()=>_0x2dd0df[_0x4e31c3]['onComplete'](new Error(_0x42fdec),!0x1,null))));}Kn(_0x582590,_0x582590['transactionQueueTree_']);for(let _0x379492=0x0;_0x379492<_0x512018['length'];_0x379492++)ft(_0x512018[_0x379492]);jn(_0x582590,_0x582590['transactionQueueTree_']);}function ua(_0x55af1c,_0x2db8e0){let _0x5a9aa5,_0x47e3c7=_0x55af1c['transactionQueueTree_'];for(_0x5a9aa5=y(_0x2db8e0);_0x5a9aa5!==null&&je(_0x47e3c7)===void 0x0;)_0x47e3c7=$n(_0x47e3c7,_0x5a9aa5),_0x2db8e0=S(_0x2db8e0),_0x5a9aa5=y(_0x2db8e0);return _0x47e3c7;}function da(_0x270457,_0x560d45){const _0xa704a8=[];return fa(_0x270457,_0x560d45,_0xa704a8),_0xa704a8['sort']((_0x5d0d6d,_0x1551e4)=>_0x5d0d6d['order']-_0x1551e4['order']),_0xa704a8;}function fa(_0x54ae86,_0x50d3a8,_0x3c7b8e){const _0x71722c=je(_0x50d3a8);if(_0x71722c){for(let _0x343016=0x0;_0x343016<_0x71722c['length'];_0x343016++)_0x3c7b8e['push'](_0x71722c[_0x343016]);}Gn(_0x50d3a8,_0x4dc459=>{fa(_0x54ae86,_0x4dc459,_0x3c7b8e);});}function Kn(_0x5c45d9,_0x8c216){const _0x1a6d6d=je(_0x8c216);if(_0x1a6d6d){let _0x4aade3=0x0;for(let _0x4fa514=0x0;_0x4fa514<_0x1a6d6d['length'];_0x4fa514++)_0x1a6d6d[_0x4fa514]['status']!==0x2&&(_0x1a6d6d[_0x4aade3]=_0x1a6d6d[_0x4fa514],_0x4aade3++);_0x1a6d6d['length']=_0x4aade3,gs(_0x8c216,_0x1a6d6d['length']>0x0?_0x1a6d6d:void 0x0);}Gn(_0x8c216,_0x2a7bad=>{Kn(_0x5c45d9,_0x2a7bad);});}function Is(_0x2d8a63,_0x3a5925){const _0x1d0ffc=Qt(ua(_0x2d8a63,_0x3a5925)),_0x35757b=$n(_0x2d8a63['transactionQueueTree_'],_0x3a5925);return ad(_0x35757b,_0x12356c=>{di(_0x2d8a63,_0x12356c);}),di(_0x2d8a63,_0x35757b),ia(_0x35757b,_0x1988ad=>{di(_0x2d8a63,_0x1988ad);}),_0x1d0ffc;}function di(_0x254f74,_0x5589b0){const _0x14021b=je(_0x5589b0);if(_0x14021b){const _0x24f0ec=[];let _0x10495d=[],_0x400c8f=-0x1;for(let _0x5c0551=0x0;_0x5c0551<_0x14021b['length'];_0x5c0551++)_0x14021b[_0x5c0551]['status']===0x3||(_0x14021b[_0x5c0551]['status']===0x1?(f(_0x400c8f===_0x5c0551-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x400c8f=_0x5c0551,_0x14021b[_0x5c0551]['status']=0x3,_0x14021b[_0x5c0551]['abortReason']='set'):(f(_0x14021b[_0x5c0551]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x14021b[_0x5c0551]['unwatcher'](),_0x10495d=_0x10495d['concat'](_e(_0x254f74['serverSyncTree_'],_0x14021b[_0x5c0551]['currentWriteId'],!0x0)),_0x14021b[_0x5c0551]['onComplete']&&_0x24f0ec['push'](_0x14021b[_0x5c0551]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x400c8f===-0x1?gs(_0x5589b0,void 0x0):_0x14021b['length']=_0x400c8f+0x1,V(_0x254f74['eventQueue_'],Qt(_0x5589b0),_0x10495d);for(let _0x211a0e=0x0;_0x211a0e<_0x24f0ec['length'];_0x211a0e++)ft(_0x24f0ec[_0x211a0e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3dc8e7){let _0x4438f5='';const _0x495405=_0x3dc8e7['split']('/');for(let _0x6001ee=0x0;_0x6001ee<_0x495405['length'];_0x6001ee++)if(_0x495405[_0x6001ee]['length']>0x0){let _0xb517bd=_0x495405[_0x6001ee];try{_0xb517bd=decodeURIComponent(_0xb517bd['replace'](/\+/g,'\x20'));}catch{}_0x4438f5+='/'+_0xb517bd;}return _0x4438f5;}function xd(_0x3fc84c){const _0x1a5c20={};_0x3fc84c['charAt'](0x0)==='?'&&(_0x3fc84c=_0x3fc84c['substring'](0x1));for(const _0x20a331 of _0x3fc84c['split']('&')){if(_0x20a331['length']===0x0)continue;const _0x3bf272=_0x20a331['split']('=');_0x3bf272['length']===0x2?_0x1a5c20[decodeURIComponent(_0x3bf272[0x0])]=decodeURIComponent(_0x3bf272[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x20a331+'\x27\x20in\x20query\x20\x27'+_0x3fc84c+'\x27');}return _0x1a5c20;}const vr=function(_0x5c84cf,_0x224ee9){const _0x1ab54e=Fd(_0x5c84cf),_0x3af04c=_0x1ab54e['namespace'];_0x1ab54e['domain']==='firebase.com'&&ae(_0x1ab54e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3af04c||_0x3af04c==='undefined')&&_0x1ab54e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1ab54e['secure']||$l();const _0x10c966=_0x1ab54e['scheme']==='ws'||_0x1ab54e['scheme']==='wss';return{'repoInfo':new yo(_0x1ab54e['host'],_0x1ab54e['secure'],_0x3af04c,_0x10c966,_0x224ee9,'',_0x3af04c!==_0x1ab54e['subdomain']),'path':new C(_0x1ab54e['pathString'])};},Fd=function(_0x552783){let _0x12908d='',_0x2c948a='',_0x534c91='',_0x233bcd='',_0x5824c7='',_0x1fd9fd=!0x0,_0x42572e='https',_0x51dbb5=0x1bb;if(typeof _0x552783=='string'){let _0x3fef67=_0x552783['indexOf']('//');_0x3fef67>=0x0&&(_0x42572e=_0x552783['substring'](0x0,_0x3fef67-0x1),_0x552783=_0x552783['substring'](_0x3fef67+0x2));let _0x15995e=_0x552783['indexOf']('/');_0x15995e===-0x1&&(_0x15995e=_0x552783['length']);let _0x1c2fde=_0x552783['indexOf']('?');_0x1c2fde===-0x1&&(_0x1c2fde=_0x552783['length']),_0x12908d=_0x552783['substring'](0x0,Math['min'](_0x15995e,_0x1c2fde)),_0x15995e<_0x1c2fde&&(_0x233bcd=Ld(_0x552783['substring'](_0x15995e,_0x1c2fde)));const _0x517452=xd(_0x552783['substring'](Math['min'](_0x552783['length'],_0x1c2fde)));_0x3fef67=_0x12908d['indexOf'](':'),_0x3fef67>=0x0?(_0x1fd9fd=_0x42572e==='https'||_0x42572e==='wss',_0x51dbb5=parseInt(_0x12908d['substring'](_0x3fef67+0x1),0xa)):_0x3fef67=_0x12908d['length'];const _0x5f28d8=_0x12908d['slice'](0x0,_0x3fef67);if(_0x5f28d8['toLowerCase']()==='localhost')_0x2c948a='localhost';else{if(_0x5f28d8['split']('.')['length']<=0x2)_0x2c948a=_0x5f28d8;else{const _0x5eeb9f=_0x12908d['indexOf']('.');_0x534c91=_0x12908d['substring'](0x0,_0x5eeb9f)['toLowerCase'](),_0x2c948a=_0x12908d['substring'](_0x5eeb9f+0x1),_0x5824c7=_0x534c91;}}'ns'in _0x517452&&(_0x5824c7=_0x517452['ns']);}return{'host':_0x12908d,'port':_0x51dbb5,'domain':_0x2c948a,'subdomain':_0x534c91,'secure':_0x1fd9fd,'scheme':_0x42572e,'pathString':_0x233bcd,'namespace':_0x5824c7};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x50fb70=0x0;const _0x19979a=[];return function(_0x654db3){const _0x350433=_0x654db3===_0x50fb70;_0x50fb70=_0x654db3;let _0x3ea3a2;const _0x30fe40=new Array(0x8);for(_0x3ea3a2=0x7;_0x3ea3a2>=0x0;_0x3ea3a2--)_0x30fe40[_0x3ea3a2]=Er['charAt'](_0x654db3%0x40),_0x654db3=Math['floor'](_0x654db3/0x40);f(_0x654db3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2adcb0=_0x30fe40['join']('');if(_0x350433){for(_0x3ea3a2=0xb;_0x3ea3a2>=0x0&&_0x19979a[_0x3ea3a2]===0x3f;_0x3ea3a2--)_0x19979a[_0x3ea3a2]=0x0;_0x19979a[_0x3ea3a2]++;}else{for(_0x3ea3a2=0x0;_0x3ea3a2<0xc;_0x3ea3a2++)_0x19979a[_0x3ea3a2]=Math['floor'](Math['random']()*0x40);}for(_0x3ea3a2=0x0;_0x3ea3a2<0xc;_0x3ea3a2++)_0x2adcb0+=Er['charAt'](_0x19979a[_0x3ea3a2]);return f(_0x2adcb0['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2adcb0;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1f2f25,_0xce9ef0,_0x326285,_0x5d2502){this['eventType']=_0x1f2f25,this['eventRegistration']=_0xce9ef0,this['snapshot']=_0x326285,this['prevName']=_0x5d2502;}['getPath'](){const _0x5cb57e=this['snapshot']['ref'];return this['eventType']==='value'?_0x5cb57e['_path']:_0x5cb57e['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x58f8ce,_0x448014,_0x262855){this['eventRegistration']=_0x58f8ce,this['error']=_0x448014,this['path']=_0x262855;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x53f397,_0x22c639){this['snapshotCallback']=_0x53f397,this['cancelCallback']=_0x22c639;}['onValue'](_0x982d94,_0x83f476){this['snapshotCallback']['call'](null,_0x982d94,_0x83f476);}['onCancel'](_0xc6caaf){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xc6caaf);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5a7ea3){return this['snapshotCallback']===_0x5a7ea3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5a7ea3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5a7ea3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5a87cf,_0x314c6d){this['_repo']=_0x5a87cf,this['_path']=_0x314c6d;}['cancel'](){const _0x5cb490=new H();return bd(this['_repo'],this['_path'],_0x5cb490['wrapCallback'](()=>{})),_0x5cb490['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x319ef1=new H();return yr(this['_repo'],this['_path'],null,_0x319ef1['wrapCallback'](()=>{})),_0x319ef1['promise'];}['set'](_0x391e02){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x391e02,this['_path'],!0x1);const _0xe8d8ba=new H();return yr(this['_repo'],this['_path'],_0x391e02,_0xe8d8ba['wrapCallback'](()=>{})),_0xe8d8ba['promise'];}['setWithPriority'](_0x4a61b1,_0x2c1d6c){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x4a61b1,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x2c1d6c);const _0x22e4c4=new H();return Rd(this['_repo'],this['_path'],_0x4a61b1,_0x2c1d6c,_0x22e4c4['wrapCallback'](()=>{})),_0x22e4c4['promise'];}['update'](_0x22bd8f){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x22bd8f,this['_path']);const _0x116315=new H();return Ad(this['_repo'],this['_path'],_0x22bd8f,_0x116315['wrapCallback'](()=>{})),_0x116315['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4fd50e,_0x53f0d8,_0x479eae,_0x30a19b){this['_repo']=_0x4fd50e,this['_path']=_0x53f0d8,this['_queryParams']=_0x479eae,this['_orderByCalled']=_0x30a19b;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x20b1db=sr(this['_queryParams']),_0x50e0f6=$i(_0x20b1db);return _0x50e0f6==='{}'?'default':_0x50e0f6;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x306b86){if(_0x306b86=P(_0x306b86),!(_0x306b86 instanceof Ae))return!0x1;const _0x3da267=this['_repo']===_0x306b86['_repo'],_0x11caf8=Ki(this['_path'],_0x306b86['_path']),_0x10c305=this['_queryIdentifier']===_0x306b86['_queryIdentifier'];return _0x3da267&&_0x11caf8&&_0x10c305;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x50c931,_0x20d617){if(_0x50c931['_orderByCalled']===!0x0)throw new Error(_0x20d617+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1750b4){let _0x50d6ec=null,_0x21057f=null;if(_0x1750b4['hasStart']()&&(_0x50d6ec=_0x1750b4['getIndexStartValue']()),_0x1750b4['hasEnd']()&&(_0x21057f=_0x1750b4['getIndexEndValue']()),_0x1750b4['getIndex']()===ve){const _0x380e02='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x12747a='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1750b4['hasStart']()){if(_0x1750b4['getIndexStartName']()!==We)throw new Error(_0x380e02);if(typeof _0x50d6ec!='string')throw new Error(_0x12747a);}if(_0x1750b4['hasEnd']()){if(_0x1750b4['getIndexEndName']()!==we)throw new Error(_0x380e02);if(typeof _0x21057f!='string')throw new Error(_0x12747a);}}else{if(_0x1750b4['getIndex']()===R){if(_0x50d6ec!=null&&!Bt(_0x50d6ec)||_0x21057f!=null&&!Bt(_0x21057f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1750b4['getIndex']()instanceof Ji||_0x1750b4['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x50d6ec!=null&&typeof _0x50d6ec=='object'||_0x21057f!=null&&typeof _0x21057f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x306fe8){if(_0x306fe8['hasStart']()&&_0x306fe8['hasEnd']()&&_0x306fe8['hasLimit']()&&!_0x306fe8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x41caed,_0x2ffbe7){super(_0x41caed,_0x2ffbe7,new Zi(),!0x1);}get['parent'](){const _0x1b1164=Ro(this['_path']);return _0x1b1164===null?null:new ee(this['_repo'],_0x1b1164);}get['root'](){let _0x151fe1=this;for(;_0x151fe1['parent']!==null;)_0x151fe1=_0x151fe1['parent'];return _0x151fe1;}}class lt{constructor(_0x416bad,_0x44f02c,_0x25831f){this['_node']=_0x416bad,this['ref']=_0x44f02c,this['_index']=_0x25831f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x333f0a){const _0x1f0069=new C(_0x333f0a),_0x5d1a24=Vt(this['ref'],_0x333f0a);return new lt(this['_node']['getChild'](_0x1f0069),_0x5d1a24,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x440f3b){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x149ef0,_0x44bb39)=>_0x440f3b(new lt(_0x44bb39,Vt(this['ref'],_0x149ef0),R)));}['hasChild'](_0x4b5791){const _0x1b040c=new C(_0x4b5791);return!this['_node']['getChild'](_0x1b040c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x338c80,_0x1b948e){return _0x338c80=P(_0x338c80),_0x338c80['_checkNotDeleted']('ref'),_0x1b948e!==void 0x0?Vt(_0x338c80['_root'],_0x1b948e):_0x338c80['_root'];}function Vt(_0x4223dd,_0xbc6bb6){return _0x4223dd=P(_0x4223dd),y(_0x4223dd['_path'])===null?pd('child','path',_0xbc6bb6):ys('child','path',_0xbc6bb6),new ee(_0x4223dd['_repo'],k(_0x4223dd['_path'],_0xbc6bb6));}function v_(_0x566630){return _0x566630=P(_0x566630),new Vd(_0x566630['_repo'],_0x566630['_path']);}function E_(_0x56791a,_0x5568ce){_0x56791a=P(_0x56791a),Me('push',_0x56791a['_path']),He('push',_0x5568ce,_0x56791a['_path'],!0x0);const _0x5a14c9=la(_0x56791a['_repo']),_0x3b407f=Ud(_0x5a14c9),_0x27bb52=Vt(_0x56791a,_0x3b407f),_0x29b8bb=Vt(_0x56791a,_0x3b407f);let _0x2fc2df;return _0x5568ce!=null?_0x2fc2df=Hd(_0x29b8bb,_0x5568ce)['then'](()=>_0x29b8bb):_0x2fc2df=Promise['resolve'](_0x29b8bb),_0x27bb52['then']=_0x2fc2df['then']['bind'](_0x2fc2df),_0x27bb52['catch']=_0x2fc2df['then']['bind'](_0x2fc2df,void 0x0),_0x27bb52;}function Hd(_0x2f71ba,_0x1fdda6){_0x2f71ba=P(_0x2f71ba),Me('set',_0x2f71ba['_path']),He('set',_0x1fdda6,_0x2f71ba['_path'],!0x1);const _0x1d412c=new H();return Cd(_0x2f71ba['_repo'],_0x2f71ba['_path'],_0x1fdda6,null,_0x1d412c['wrapCallback'](()=>{})),_0x1d412c['promise'];}function I_(_0x2a5d14,_0xc3e8f5){ra('update',_0xc3e8f5,_0x2a5d14['_path']);const _0x688141=new H();return Td(_0x2a5d14['_repo'],_0x2a5d14['_path'],_0xc3e8f5,_0x688141['wrapCallback'](()=>{})),_0x688141['promise'];}function w_(_0x310777){_0x310777=P(_0x310777);const _0x3ed083=new pa(()=>{}),_0x22e6d6=new Qn(_0x3ed083);return wd(_0x310777['_repo'],_0x310777,_0x22e6d6)['then'](_0x25fb0e=>new lt(_0x25fb0e,new ee(_0x310777['_repo'],_0x310777['_path']),_0x310777['_queryParams']['getIndex']()));}class Qn{constructor(_0x3c047e){this['callbackContext']=_0x3c047e;}['respondsTo'](_0x319bf7){return _0x319bf7==='value';}['createEvent'](_0x19af1d,_0x2e808c){const _0x3fe000=_0x2e808c['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x19af1d['snapshotNode'],new ee(_0x2e808c['_repo'],_0x2e808c['_path']),_0x3fe000));}['getEventRunner'](_0x522d73){return _0x522d73['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x522d73['error']):()=>this['callbackContext']['onValue'](_0x522d73['snapshot'],null);}['createCancelEvent'](_0x232a1f,_0x3fc938){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x232a1f,_0x3fc938):null;}['matches'](_0x5da1be){return _0x5da1be instanceof Qn?!_0x5da1be['callbackContext']||!this['callbackContext']?!0x0:_0x5da1be['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x1cfde3,_0x9703fa,_0x39e6e9,_0x1c5abc,_0x56bc30){const _0x5021e4=new pa(_0x39e6e9,void 0x0),_0x4c70e9=new Qn(_0x5021e4);return kd(_0x1cfde3['_repo'],_0x1cfde3,_0x4c70e9),()=>Pd(_0x1cfde3['_repo'],_0x1cfde3,_0x4c70e9);}function Gd(_0x513de6,_0x418c1a,_0x5ed131,_0x5e6318){return $d(_0x513de6,'value',_0x418c1a);}class mt{}class ma extends mt{constructor(_0x3a2812,_0x515130){super(),this['_value']=_0x3a2812,this['_key']=_0x515130,this['type']='endAt';}['_apply'](_0x2d3c69){He('endAt',this['_value'],_0x2d3c69['_path'],!0x0);const _0x8dd878=Jh(_0x2d3c69['_queryParams'],this['_value'],this['_key']);if(ga(_0x8dd878),Yn(_0x8dd878),_0x2d3c69['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x2d3c69['_repo'],_0x2d3c69['_path'],_0x8dd878,_0x2d3c69['_orderByCalled']);}}function C_(_0x43e18f,_0x203b66){return new ma(_0x43e18f,_0x203b66);}class ya extends mt{constructor(_0x4c8b79,_0x1cb8c1){super(),this['_value']=_0x4c8b79,this['_key']=_0x1cb8c1,this['type']='startAt';}['_apply'](_0x3e7138){He('startAt',this['_value'],_0x3e7138['_path'],!0x0);const _0x397615=Qh(_0x3e7138['_queryParams'],this['_value'],this['_key']);if(ga(_0x397615),Yn(_0x397615),_0x3e7138['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x3e7138['_repo'],_0x3e7138['_path'],_0x397615,_0x3e7138['_orderByCalled']);}}function T_(_0x4a1815=null,_0x4f73ff){return new ya(_0x4a1815,_0x4f73ff);}class qd extends mt{constructor(_0x3e1d01){super(),this['_limit']=_0x3e1d01,this['type']='limitToFirst';}['_apply'](_0x5bfc7a){if(_0x5bfc7a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x5bfc7a['_repo'],_0x5bfc7a['_path'],Yh(_0x5bfc7a['_queryParams'],this['_limit']),_0x5bfc7a['_orderByCalled']);}}function S_(_0x3939b1){if(Math['floor'](_0x3939b1)!==_0x3939b1||_0x3939b1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3939b1);}class zd extends mt{constructor(_0x48a2cf){super(),this['_path']=_0x48a2cf,this['type']='orderByChild';}['_apply'](_0x1ccade){_a(_0x1ccade,'orderByChild');const _0x4fc096=new C(this['_path']);if(v(_0x4fc096))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x114373=new Ji(_0x4fc096),_0x248972=xo(_0x1ccade['_queryParams'],_0x114373);return Yn(_0x248972),new Ae(_0x1ccade['_repo'],_0x1ccade['_path'],_0x248972,!0x0);}}function b_(_0x5288d5){if(_0x5288d5==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5288d5==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5288d5==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5288d5),new zd(_0x5288d5);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1f1170){_a(_0x1f1170,'orderByKey');const _0x1a2422=xo(_0x1f1170['_queryParams'],ve);return Yn(_0x1a2422),new Ae(_0x1f1170['_repo'],_0x1f1170['_path'],_0x1a2422,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x46a37c,_0x226855){super(),this['_value']=_0x46a37c,this['_key']=_0x226855,this['type']='equalTo';}['_apply'](_0x1072c7){if(He('equalTo',this['_value'],_0x1072c7['_path'],!0x1),_0x1072c7['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1072c7['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1072c7));}}function A_(_0x1b450f,_0x59f472){return new Kd(_0x1b450f,_0x59f472);}function k_(_0x691f27,..._0x54f31b){let _0x1d38d7=P(_0x691f27);for(const _0x5c6cdc of _0x54f31b)_0x1d38d7=_0x5c6cdc['_apply'](_0x1d38d7);return _0x1d38d7;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x280e1f,_0x315cb0,_0x3a3a80,_0x2fd205){const _0x3b91fd=_0x315cb0['lastIndexOf'](':'),_0x2b0c34=_0x315cb0['substring'](0x0,_0x3b91fd),_0x532ff1=qt(_0x2b0c34);_0x280e1f['repoInfo_']=new yo(_0x315cb0,_0x532ff1,_0x280e1f['repoInfo_']['namespace'],_0x280e1f['repoInfo_']['webSocketOnly'],_0x280e1f['repoInfo_']['nodeAdmin'],_0x280e1f['repoInfo_']['persistenceKey'],_0x280e1f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3a3a80),_0x2fd205&&(_0x280e1f['authTokenProvider_']=_0x2fd205);}function Xd(_0x57bf22,_0x1c136f,_0x2dd2d3,_0x4313ba,_0x4b6ae7){let _0x29b812=_0x4313ba||_0x57bf22['options']['databaseURL'];_0x29b812===void 0x0&&(_0x57bf22['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x57bf22['options']['projectId']),_0x29b812=_0x57bf22['options']['projectId']+'-default-rtdb.firebaseio.com');let _0xf5bed1=vr(_0x29b812,_0x4b6ae7),_0x198a3d=_0xf5bed1['repoInfo'],_0x282b70;typeof process<'u'&&Bs&&(_0x282b70=Bs[Yd]),_0x282b70?(_0x29b812='http://'+_0x282b70+'?ns='+_0x198a3d['namespace'],_0xf5bed1=vr(_0x29b812,_0x4b6ae7),_0x198a3d=_0xf5bed1['repoInfo']):_0xf5bed1['repoInfo']['secure'];const _0x38075b=new eh(_0x57bf22['name'],_0x57bf22['options'],_0x1c136f);_d('Invalid\x20Firebase\x20Database\x20URL',_0xf5bed1),v(_0xf5bed1['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3ed0a9=ef(_0x198a3d,_0x57bf22,_0x38075b,new Zl(_0x57bf22,_0x2dd2d3));return new tf(_0x3ed0a9,_0x57bf22);}function Zd(_0x35defc,_0x26b715){const _0x4b09a7=Di[_0x26b715];(!_0x4b09a7||_0x4b09a7[_0x35defc['key']]!==_0x35defc)&&ae('Database\x20'+_0x26b715+'('+_0x35defc['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x35defc),delete _0x4b09a7[_0x35defc['key']];}function ef(_0x4504b5,_0x59e86c,_0x3f6c27,_0x3b640b){let _0x53328d=Di[_0x59e86c['name']];_0x53328d||(_0x53328d={},Di[_0x59e86c['name']]=_0x53328d);let _0x3b79b7=_0x53328d[_0x4504b5['toURLString']()];return _0x3b79b7&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3b79b7=new vd(_0x4504b5,Qd,_0x3f6c27,_0x3b640b),_0x53328d[_0x4504b5['toURLString']()]=_0x3b79b7,_0x3b79b7;}class tf{constructor(_0x4ad958,_0x5ac4db){this['_repoInternal']=_0x4ad958,this['app']=_0x5ac4db,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4b2680){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4b2680+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4e7779=Zr(),_0x54d633){const _0x308908=Hi(_0x4e7779,'database')['getImmediate']({'identifier':_0x54d633});if(!_0x308908['_instanceStarted']){const _0x2da6bf=hc('database');_0x2da6bf&&nf(_0x308908,..._0x2da6bf);}return _0x308908;}function nf(_0x48ceae,_0x5989a0,_0x4e3fa0,_0x2d1c68={}){_0x48ceae=P(_0x48ceae),_0x48ceae['_checkNotDeleted']('useEmulator');const _0x272498=_0x5989a0+':'+_0x4e3fa0,_0x51d677=_0x48ceae['_repoInternal'];if(_0x48ceae['_instanceStarted']){if(_0x272498===_0x48ceae['_repoInternal']['repoInfo_']['host']&&xe(_0x2d1c68,_0x51d677['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3cc20c;if(_0x51d677['repoInfo_']['nodeAdmin'])_0x2d1c68['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3cc20c=new an(an['OWNER']);else{if(_0x2d1c68['mockUserToken']){const _0x1214fa=typeof _0x2d1c68['mockUserToken']=='string'?_0x2d1c68['mockUserToken']:uc(_0x2d1c68['mockUserToken'],_0x48ceae['app']['options']['projectId']);_0x3cc20c=new an(_0x1214fa);}}qt(_0x5989a0)&&Qr(_0x5989a0),Jd(_0x51d677,_0x272498,_0x2d1c68,_0x3cc20c);}function N_(_0x23d17c){_0x23d17c=P(_0x23d17c),_0x23d17c['_checkNotDeleted']('goOffline'),ha(_0x23d17c['_repo']);}function O_(_0x2b0139){_0x2b0139=P(_0x2b0139),_0x2b0139['_checkNotDeleted']('goOnline'),Nd(_0x2b0139['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x3b0c50){Ul(dt),st(new Fe('database',(_0x2302f2,{instanceIdentifier:_0x34e2fa})=>{const _0x25122e=_0x2302f2['getProvider']('app')['getImmediate'](),_0x553920=_0x2302f2['getProvider']('auth-internal'),_0x2e1547=_0x2302f2['getProvider']('app-check-internal');return Xd(_0x25122e,_0x553920,_0x2e1547,_0x34e2fa);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x3b0c50),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x48f4c4,_0x262465){this['committed']=_0x48f4c4,this['snapshot']=_0x262465;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x30833d,_0x5ce607,_0x5dda7c){if(_0x30833d=P(_0x30833d),Me('Reference.transaction',_0x30833d['_path']),_0x30833d['key']==='.length'||_0x30833d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x30833d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2f5e63=!0x0,_0x277e4e=new H(),_0x545415=(_0x3632f2,_0x12c9c4,_0x33aede)=>{let _0x1d8f10=null;_0x3632f2?_0x277e4e['reject'](_0x3632f2):(_0x1d8f10=new lt(_0x33aede,new ee(_0x30833d['_repo'],_0x30833d['_path']),R),_0x277e4e['resolve'](new of(_0x12c9c4,_0x1d8f10)));},_0x5171bb=Gd(_0x30833d,()=>{});return Od(_0x30833d['_repo'],_0x30833d['_path'],_0x5ce607,_0x545415,_0x5171bb,_0x2f5e63),_0x277e4e['promise'];}se['prototype']['simpleListen']=function(_0x416626,_0x41b1b5){this['sendRequest']('q',{'p':_0x416626},_0x41b1b5);},se['prototype']['echo']=function(_0xb65617,_0xac8415){this['sendRequest']('echo',{'d':_0xb65617},_0xac8415);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2337a4,..._0xfb3680){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2337a4,..._0xfb3680);}function cn(_0x3c5794,..._0x404148){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3c5794,..._0x404148);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x96d96a,..._0x1c5e71){throw ws(_0x96d96a,..._0x1c5e71);}function X(_0x3abc4e,..._0x416ca6){return ws(_0x3abc4e,..._0x416ca6);}function Ia(_0x1abe19,_0x2a3d72,_0x3c0f4d){const _0x225e42={...af(),[_0x2a3d72]:_0x3c0f4d};return new Gt('auth','Firebase',_0x225e42)['create'](_0x2a3d72,{'appName':_0x1abe19['name']});}function re(_0x20d27c){return Ia(_0x20d27c,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1c9089,..._0x357526){if(typeof _0x1c9089!='string'){const _0x54bdb1=_0x357526[0x0],_0x44dc5f=[..._0x357526['slice'](0x1)];return _0x44dc5f[0x0]&&(_0x44dc5f[0x0]['appName']=_0x1c9089['name']),_0x1c9089['_errorFactory']['create'](_0x54bdb1,..._0x44dc5f);}return Ea['create'](_0x1c9089,..._0x357526);}function m(_0x37c218,_0x2aae2d,..._0x457556){if(!_0x37c218)throw ws(_0x2aae2d,..._0x457556);}function ne(_0x864566){const _0x188c6f='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x864566;throw cn(_0x188c6f),new Error(_0x188c6f);}function ce(_0x52096d,_0x60e305){_0x52096d||ne(_0x60e305);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3b69ed;return typeof self<'u'&&((_0x3b69ed=self['location'])==null?void 0x0:_0x3b69ed['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x57c777;return typeof self<'u'&&((_0x57c777=self['location'])==null?void 0x0:_0x57c777['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x45e261=navigator;return _0x45e261['languages']&&_0x45e261['languages'][0x0]||_0x45e261['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x50d06a,_0x40c82a){this['shortDelay']=_0x50d06a,this['longDelay']=_0x40c82a,ce(_0x40c82a>_0x50d06a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xa06f15,_0x8e3e48){ce(_0xa06f15['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4a3f1e}=_0xa06f15['emulator'];return _0x8e3e48?''+_0x4a3f1e+(_0x8e3e48['startsWith']('/')?_0x8e3e48['slice'](0x1):_0x8e3e48):_0x4a3f1e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x50aeab,_0x391c82,_0x8bdcd4){this['fetchImpl']=_0x50aeab,_0x391c82&&(this['headersImpl']=_0x391c82),_0x8bdcd4&&(this['responseImpl']=_0x8bdcd4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x78ff00,_0x4e8b42){return _0x78ff00['tenantId']&&!_0x4e8b42['tenantId']?{..._0x4e8b42,'tenantId':_0x78ff00['tenantId']}:_0x4e8b42;}async function Pe(_0x19f515,_0x122d96,_0x1fc7a6,_0xf177a2,_0x1c3575={}){return Ca(_0x19f515,_0x1c3575,async()=>{let _0x1de5f9={},_0x1fc6e8={};_0xf177a2&&(_0x122d96==='GET'?_0x1fc6e8=_0xf177a2:_0x1de5f9={'body':JSON['stringify'](_0xf177a2)});const _0x134386=ut({..._0x1fc6e8,'key':_0x19f515['config']['apiKey']})['slice'](0x1),_0xa7c962=await _0x19f515['_getAdditionalHeaders']();_0xa7c962['Content-Type']='application/json',_0x19f515['languageCode']&&(_0xa7c962['X-Firebase-Locale']=_0x19f515['languageCode']);const _0x4f199a={'method':_0x122d96,'headers':_0xa7c962,..._0x1de5f9};return dc()||(_0x4f199a['referrerPolicy']='strict-origin-when-cross-origin'),_0x19f515['emulatorConfig']&&qt(_0x19f515['emulatorConfig']['host'])&&(_0x4f199a['credentials']='include'),wa['fetch']()(await Ta(_0x19f515,_0x19f515['config']['apiHost'],_0x1fc7a6,_0x134386),_0x4f199a);});}async function Ca(_0x599e6c,_0x5a7153,_0x3da681){_0x599e6c['_canInitEmulator']=!0x1;const _0x526ec1={...df,..._0x5a7153};try{const _0xf4296d=new gf(_0x599e6c),_0x535a08=await Promise['race']([_0x3da681(),_0xf4296d['promise']]);_0xf4296d['clearNetworkTimeout']();const _0x4c3b29=await _0x535a08['json']();if('needConfirmation'in _0x4c3b29)throw on(_0x599e6c,'account-exists-with-different-credential',_0x4c3b29);if(_0x535a08['ok']&&!('errorMessage'in _0x4c3b29))return _0x4c3b29;{const _0x21b261=_0x535a08['ok']?_0x4c3b29['errorMessage']:_0x4c3b29['error']['message'],[_0x3e47d7,_0x66579e]=_0x21b261['split']('\x20:\x20');if(_0x3e47d7==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x599e6c,'credential-already-in-use',_0x4c3b29);if(_0x3e47d7==='EMAIL_EXISTS')throw on(_0x599e6c,'email-already-in-use',_0x4c3b29);if(_0x3e47d7==='USER_DISABLED')throw on(_0x599e6c,'user-disabled',_0x4c3b29);const _0x725ae6=_0x526ec1[_0x3e47d7]||_0x3e47d7['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x66579e)throw Ia(_0x599e6c,_0x725ae6,_0x66579e);Y(_0x599e6c,_0x725ae6);}}catch(_0x418704){if(_0x418704 instanceof Re)throw _0x418704;Y(_0x599e6c,'network-request-failed',{'message':String(_0x418704)});}}async function en(_0x168a40,_0x4ac5f4,_0x5e7965,_0x2267b6,_0x22cd87={}){const _0x53caa5=await Pe(_0x168a40,_0x4ac5f4,_0x5e7965,_0x2267b6,_0x22cd87);return'mfaPendingCredential'in _0x53caa5&&Y(_0x168a40,'multi-factor-auth-required',{'_serverResponse':_0x53caa5}),_0x53caa5;}async function Ta(_0x4048a6,_0x280ed6,_0x28e0f5,_0x42069a){const _0x4a610f=''+_0x280ed6+_0x28e0f5+'?'+_0x42069a,_0x3ca8ed=_0x4048a6,_0x5c5f01=_0x3ca8ed['config']['emulator']?Cs(_0x4048a6['config'],_0x4a610f):_0x4048a6['config']['apiScheme']+'://'+_0x4a610f;return ff['includes'](_0x28e0f5)&&(await _0x3ca8ed['_persistenceManagerAvailable'],_0x3ca8ed['_getPersistenceType']()==='COOKIE')?_0x3ca8ed['_getPersistence']()['_getFinalTarget'](_0x5c5f01)['toString']():_0x5c5f01;}function _f(_0x1bf39f){switch(_0x1bf39f){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4e62c3){this['auth']=_0x4e62c3,this['timer']=null,this['promise']=new Promise((_0x24f0e8,_0x4a2531)=>{this['timer']=setTimeout(()=>_0x4a2531(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x5334eb,_0x127fb9,_0x12d403){const _0x2c2315={'appName':_0x5334eb['name']};_0x12d403['email']&&(_0x2c2315['email']=_0x12d403['email']),_0x12d403['phoneNumber']&&(_0x2c2315['phoneNumber']=_0x12d403['phoneNumber']);const _0x2f99b5=X(_0x5334eb,_0x127fb9,_0x2c2315);return _0x2f99b5['customData']['_tokenResponse']=_0x12d403,_0x2f99b5;}function wr(_0x51b61d){return _0x51b61d!==void 0x0&&_0x51b61d['enterprise']!==void 0x0;}class mf{constructor(_0x50a054){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x50a054['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x50a054['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x50a054['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4cf890){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xfda02b of this['recaptchaEnforcementState'])if(_0xfda02b['provider']&&_0xfda02b['provider']===_0x4cf890)return _f(_0xfda02b['enforcementState']);return null;}['isProviderEnabled'](_0x51cf5a){return this['getProviderEnforcementState'](_0x51cf5a)==='ENFORCE'||this['getProviderEnforcementState'](_0x51cf5a)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x500b7d,_0x3f3a32){return Pe(_0x500b7d,'GET','/v2/recaptchaConfig',ke(_0x500b7d,_0x3f3a32));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0xcde5d0,_0x8a4c5f){return Pe(_0xcde5d0,'POST','/v1/accounts:delete',_0x8a4c5f);}async function Pn(_0x57de45,_0x5cb700){return Pe(_0x57de45,'POST','/v1/accounts:lookup',_0x5cb700);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2466ce){if(_0x2466ce)try{const _0x2536e6=new Date(Number(_0x2466ce));if(!isNaN(_0x2536e6['getTime']()))return _0x2536e6['toUTCString']();}catch{}}async function Ef(_0x1f6f72,_0x3833b2=!0x1){const _0x1c3301=P(_0x1f6f72),_0x7645a6=await _0x1c3301['getIdToken'](_0x3833b2),_0x5f2290=Ts(_0x7645a6);m(_0x5f2290&&_0x5f2290['exp']&&_0x5f2290['auth_time']&&_0x5f2290['iat'],_0x1c3301['auth'],'internal-error');const _0x46e186=typeof _0x5f2290['firebase']=='object'?_0x5f2290['firebase']:void 0x0,_0x5e6d50=_0x46e186==null?void 0x0:_0x46e186['sign_in_provider'];return{'claims':_0x5f2290,'token':_0x7645a6,'authTime':Pt(fi(_0x5f2290['auth_time'])),'issuedAtTime':Pt(fi(_0x5f2290['iat'])),'expirationTime':Pt(fi(_0x5f2290['exp'])),'signInProvider':_0x5e6d50||null,'signInSecondFactor':(_0x46e186==null?void 0x0:_0x46e186['sign_in_second_factor'])||null};}function fi(_0x55eb26){return Number(_0x55eb26)*0x3e8;}function Ts(_0x67a1ed){const [_0x4493ff,_0x13f3f2,_0x1f565]=_0x67a1ed['split']('.');if(_0x4493ff===void 0x0||_0x13f3f2===void 0x0||_0x1f565===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3b12b9=fn(_0x13f3f2);return _0x3b12b9?JSON['parse'](_0x3b12b9):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x45dd17){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x45dd17==null?void 0x0:_0x45dd17['toString']()),null;}}function Cr(_0x20f9bd){const _0x49786e=Ts(_0x20f9bd);return m(_0x49786e,'internal-error'),m(typeof _0x49786e['exp']<'u','internal-error'),m(typeof _0x49786e['iat']<'u','internal-error'),Number(_0x49786e['exp'])-Number(_0x49786e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2ce3d6,_0xa9f23,_0x4be873=!0x1){if(_0x4be873)return _0xa9f23;try{return await _0xa9f23;}catch(_0x868738){throw _0x868738 instanceof Re&&If(_0x868738)&&_0x2ce3d6['auth']['currentUser']===_0x2ce3d6&&await _0x2ce3d6['auth']['signOut'](),_0x868738;}}function If({code:_0x439076}){return _0x439076==='auth/user-disabled'||_0x439076==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5220c0){this['user']=_0x5220c0,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x54d0ab){if(_0x54d0ab){const _0x3b636b=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3b636b;}else{this['errorBackoff']=0x7530;const _0x5b8b38=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5b8b38);}}['schedule'](_0x5d5ae1=!0x1){if(!this['isRunning'])return;const _0x58c04d=this['getInterval'](_0x5d5ae1);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x58c04d);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x227d4f){(_0x227d4f==null?void 0x0:_0x227d4f['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x18ca76,_0x33f2fa){this['createdAt']=_0x18ca76,this['lastLoginAt']=_0x33f2fa,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x536e82){this['createdAt']=_0x536e82['createdAt'],this['lastLoginAt']=_0x536e82['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x35e6cf){var _0x4a5dad;const _0x11c38a=_0x35e6cf['auth'],_0x45e4da=await _0x35e6cf['getIdToken'](),_0xf51738=await Ht(_0x35e6cf,Pn(_0x11c38a,{'idToken':_0x45e4da}));m(_0xf51738==null?void 0x0:_0xf51738['users']['length'],_0x11c38a,'internal-error');const _0x3180f5=_0xf51738['users'][0x0];_0x35e6cf['_notifyReloadListener'](_0x3180f5);const _0x5b02f6=(_0x4a5dad=_0x3180f5['providerUserInfo'])!=null&&_0x4a5dad['length']?Sa(_0x3180f5['providerUserInfo']):[],_0x4c1702=Tf(_0x35e6cf['providerData'],_0x5b02f6),_0x37fb1b=_0x35e6cf['isAnonymous'],_0x2e69e1=!(_0x35e6cf['email']&&_0x3180f5['passwordHash'])&&!(_0x4c1702!=null&&_0x4c1702['length']),_0x45cdb4=_0x37fb1b?_0x2e69e1:!0x1,_0x3caf6d={'uid':_0x3180f5['localId'],'displayName':_0x3180f5['displayName']||null,'photoURL':_0x3180f5['photoUrl']||null,'email':_0x3180f5['email']||null,'emailVerified':_0x3180f5['emailVerified']||!0x1,'phoneNumber':_0x3180f5['phoneNumber']||null,'tenantId':_0x3180f5['tenantId']||null,'providerData':_0x4c1702,'metadata':new Li(_0x3180f5['createdAt'],_0x3180f5['lastLoginAt']),'isAnonymous':_0x45cdb4};Object['assign'](_0x35e6cf,_0x3caf6d);}async function Cf(_0x4dd7f8){const _0x12dcd1=P(_0x4dd7f8);await Nn(_0x12dcd1),await _0x12dcd1['auth']['_persistUserIfCurrent'](_0x12dcd1),_0x12dcd1['auth']['_notifyListenersIfCurrent'](_0x12dcd1);}function Tf(_0xa003e0,_0x326a7d){return[..._0xa003e0['filter'](_0x40c3e8=>!_0x326a7d['some'](_0x58c991=>_0x58c991['providerId']===_0x40c3e8['providerId'])),..._0x326a7d];}function Sa(_0x1b0568){return _0x1b0568['map'](({providerId:_0x17231d,..._0x4b6813})=>({'providerId':_0x17231d,'uid':_0x4b6813['rawId']||'','displayName':_0x4b6813['displayName']||null,'email':_0x4b6813['email']||null,'phoneNumber':_0x4b6813['phoneNumber']||null,'photoURL':_0x4b6813['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x58daa0,_0x41b109){const _0x36820a=await Ca(_0x58daa0,{},async()=>{const _0x4b0d90=ut({'grant_type':'refresh_token','refresh_token':_0x41b109})['slice'](0x1),{tokenApiHost:_0x2ac870,apiKey:_0x4523e1}=_0x58daa0['config'],_0x2fa872=await Ta(_0x58daa0,_0x2ac870,'/v1/token','key='+_0x4523e1),_0x20310b=await _0x58daa0['_getAdditionalHeaders']();_0x20310b['Content-Type']='application/x-www-form-urlencoded';const _0x49b8d7={'method':'POST','headers':_0x20310b,'body':_0x4b0d90};return _0x58daa0['emulatorConfig']&&qt(_0x58daa0['emulatorConfig']['host'])&&(_0x49b8d7['credentials']='include'),wa['fetch']()(_0x2fa872,_0x49b8d7);});return{'accessToken':_0x36820a['access_token'],'expiresIn':_0x36820a['expires_in'],'refreshToken':_0x36820a['refresh_token']};}async function bf(_0x5178cd,_0x168684){return Pe(_0x5178cd,'POST','/v2/accounts:revokeToken',ke(_0x5178cd,_0x168684));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x13a3a5){m(_0x13a3a5['idToken'],'internal-error'),m(typeof _0x13a3a5['idToken']<'u','internal-error'),m(typeof _0x13a3a5['refreshToken']<'u','internal-error');const _0x4d3c5a='expiresIn'in _0x13a3a5&&typeof _0x13a3a5['expiresIn']<'u'?Number(_0x13a3a5['expiresIn']):Cr(_0x13a3a5['idToken']);this['updateTokensAndExpiration'](_0x13a3a5['idToken'],_0x13a3a5['refreshToken'],_0x4d3c5a);}['updateFromIdToken'](_0x5072df){m(_0x5072df['length']!==0x0,'internal-error');const _0x266ab3=Cr(_0x5072df);this['updateTokensAndExpiration'](_0x5072df,null,_0x266ab3);}async['getToken'](_0x3cdb13,_0x1228e5=!0x1){return!_0x1228e5&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3cdb13,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3cdb13,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x465559,_0xf939a5){const {accessToken:_0x33a4de,refreshToken:_0x4a1ef9,expiresIn:_0x419146}=await Sf(_0x465559,_0xf939a5);this['updateTokensAndExpiration'](_0x33a4de,_0x4a1ef9,Number(_0x419146));}['updateTokensAndExpiration'](_0x448c0a,_0x24b530,_0x42bda6){this['refreshToken']=_0x24b530||null,this['accessToken']=_0x448c0a||null,this['expirationTime']=Date['now']()+_0x42bda6*0x3e8;}static['fromJSON'](_0x59ca52,_0x380cec){const {refreshToken:_0x1ef06f,accessToken:_0x1b8d8f,expirationTime:_0x1e7532}=_0x380cec,_0x5cdcf3=new et();return _0x1ef06f&&(m(typeof _0x1ef06f=='string','internal-error',{'appName':_0x59ca52}),_0x5cdcf3['refreshToken']=_0x1ef06f),_0x1b8d8f&&(m(typeof _0x1b8d8f=='string','internal-error',{'appName':_0x59ca52}),_0x5cdcf3['accessToken']=_0x1b8d8f),_0x1e7532&&(m(typeof _0x1e7532=='number','internal-error',{'appName':_0x59ca52}),_0x5cdcf3['expirationTime']=_0x1e7532),_0x5cdcf3;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x36f9d5){this['accessToken']=_0x36f9d5['accessToken'],this['refreshToken']=_0x36f9d5['refreshToken'],this['expirationTime']=_0x36f9d5['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1160ab,_0x2eaaab){m(typeof _0x1160ab=='string'||typeof _0x1160ab>'u','internal-error',{'appName':_0x2eaaab});}class j{constructor({uid:_0x370152,auth:_0x293a10,stsTokenManager:_0x56a676,..._0x3ec0e9}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x370152,this['auth']=_0x293a10,this['stsTokenManager']=_0x56a676,this['accessToken']=_0x56a676['accessToken'],this['displayName']=_0x3ec0e9['displayName']||null,this['email']=_0x3ec0e9['email']||null,this['emailVerified']=_0x3ec0e9['emailVerified']||!0x1,this['phoneNumber']=_0x3ec0e9['phoneNumber']||null,this['photoURL']=_0x3ec0e9['photoURL']||null,this['isAnonymous']=_0x3ec0e9['isAnonymous']||!0x1,this['tenantId']=_0x3ec0e9['tenantId']||null,this['providerData']=_0x3ec0e9['providerData']?[..._0x3ec0e9['providerData']]:[],this['metadata']=new Li(_0x3ec0e9['createdAt']||void 0x0,_0x3ec0e9['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1288c6){const _0xddfe37=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1288c6));return m(_0xddfe37,this['auth'],'internal-error'),this['accessToken']!==_0xddfe37&&(this['accessToken']=_0xddfe37,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xddfe37;}['getIdTokenResult'](_0x1192a6){return Ef(this,_0x1192a6);}['reload'](){return Cf(this);}['_assign'](_0x2a7e31){this!==_0x2a7e31&&(m(this['uid']===_0x2a7e31['uid'],this['auth'],'internal-error'),this['displayName']=_0x2a7e31['displayName'],this['photoURL']=_0x2a7e31['photoURL'],this['email']=_0x2a7e31['email'],this['emailVerified']=_0x2a7e31['emailVerified'],this['phoneNumber']=_0x2a7e31['phoneNumber'],this['isAnonymous']=_0x2a7e31['isAnonymous'],this['tenantId']=_0x2a7e31['tenantId'],this['providerData']=_0x2a7e31['providerData']['map'](_0x5ac1df=>({..._0x5ac1df})),this['metadata']['_copy'](_0x2a7e31['metadata']),this['stsTokenManager']['_assign'](_0x2a7e31['stsTokenManager']));}['_clone'](_0x5db71c){const _0x3bf2fa=new j({...this,'auth':_0x5db71c,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3bf2fa['metadata']['_copy'](this['metadata']),_0x3bf2fa;}['_onReload'](_0x242672){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x242672,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xcbd8e9){this['reloadListener']?this['reloadListener'](_0xcbd8e9):this['reloadUserInfo']=_0xcbd8e9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4c6d66,_0x3ea944=!0x1){let _0x4d15d2=!0x1;_0x4c6d66['idToken']&&_0x4c6d66['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4c6d66),_0x4d15d2=!0x0),_0x3ea944&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4d15d2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x22d1ab=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x22d1ab})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1a3320=>({..._0x1a3320})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2e93df,_0x31f58b){const _0x2715a1=_0x31f58b['displayName']??void 0x0,_0x9cb5cc=_0x31f58b['email']??void 0x0,_0x47a366=_0x31f58b['phoneNumber']??void 0x0,_0x260796=_0x31f58b['photoURL']??void 0x0,_0x5b2577=_0x31f58b['tenantId']??void 0x0,_0x510ac5=_0x31f58b['_redirectEventId']??void 0x0,_0x2c6593=_0x31f58b['createdAt']??void 0x0,_0x5044ec=_0x31f58b['lastLoginAt']??void 0x0,{uid:_0x14f92c,emailVerified:_0x17e0c1,isAnonymous:_0x173a05,providerData:_0x2a46f3,stsTokenManager:_0x2e5597}=_0x31f58b;m(_0x14f92c&&_0x2e5597,_0x2e93df,'internal-error');const _0x59de39=et['fromJSON'](this['name'],_0x2e5597);m(typeof _0x14f92c=='string',_0x2e93df,'internal-error'),le(_0x2715a1,_0x2e93df['name']),le(_0x9cb5cc,_0x2e93df['name']),m(typeof _0x17e0c1=='boolean',_0x2e93df,'internal-error'),m(typeof _0x173a05=='boolean',_0x2e93df,'internal-error'),le(_0x47a366,_0x2e93df['name']),le(_0x260796,_0x2e93df['name']),le(_0x5b2577,_0x2e93df['name']),le(_0x510ac5,_0x2e93df['name']),le(_0x2c6593,_0x2e93df['name']),le(_0x5044ec,_0x2e93df['name']);const _0x29cd50=new j({'uid':_0x14f92c,'auth':_0x2e93df,'email':_0x9cb5cc,'emailVerified':_0x17e0c1,'displayName':_0x2715a1,'isAnonymous':_0x173a05,'photoURL':_0x260796,'phoneNumber':_0x47a366,'tenantId':_0x5b2577,'stsTokenManager':_0x59de39,'createdAt':_0x2c6593,'lastLoginAt':_0x5044ec});return _0x2a46f3&&Array['isArray'](_0x2a46f3)&&(_0x29cd50['providerData']=_0x2a46f3['map'](_0x49ff57=>({..._0x49ff57}))),_0x510ac5&&(_0x29cd50['_redirectEventId']=_0x510ac5),_0x29cd50;}static async['_fromIdTokenResponse'](_0x29f632,_0x5be7d1,_0x56c231=!0x1){const _0x3b39e3=new et();_0x3b39e3['updateFromServerResponse'](_0x5be7d1);const _0x208cf3=new j({'uid':_0x5be7d1['localId'],'auth':_0x29f632,'stsTokenManager':_0x3b39e3,'isAnonymous':_0x56c231});return await Nn(_0x208cf3),_0x208cf3;}static async['_fromGetAccountInfoResponse'](_0x37d572,_0x157ec2,_0x5dde96){const _0x308b83=_0x157ec2['users'][0x0];m(_0x308b83['localId']!==void 0x0,'internal-error');const _0x4bae6b=_0x308b83['providerUserInfo']!==void 0x0?Sa(_0x308b83['providerUserInfo']):[],_0x16cd99=!(_0x308b83['email']&&_0x308b83['passwordHash'])&&!(_0x4bae6b!=null&&_0x4bae6b['length']),_0x1d43e9=new et();_0x1d43e9['updateFromIdToken'](_0x5dde96);const _0x296f12=new j({'uid':_0x308b83['localId'],'auth':_0x37d572,'stsTokenManager':_0x1d43e9,'isAnonymous':_0x16cd99}),_0x334665={'uid':_0x308b83['localId'],'displayName':_0x308b83['displayName']||null,'photoURL':_0x308b83['photoUrl']||null,'email':_0x308b83['email']||null,'emailVerified':_0x308b83['emailVerified']||!0x1,'phoneNumber':_0x308b83['phoneNumber']||null,'tenantId':_0x308b83['tenantId']||null,'providerData':_0x4bae6b,'metadata':new Li(_0x308b83['createdAt'],_0x308b83['lastLoginAt']),'isAnonymous':!(_0x308b83['email']&&_0x308b83['passwordHash'])&&!(_0x4bae6b!=null&&_0x4bae6b['length'])};return Object['assign'](_0x296f12,_0x334665),_0x296f12;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1b17aa){ce(_0x1b17aa instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2ec27f=Tr['get'](_0x1b17aa);return _0x2ec27f?(ce(_0x2ec27f instanceof _0x1b17aa,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2ec27f):(_0x2ec27f=new _0x1b17aa(),Tr['set'](_0x1b17aa,_0x2ec27f),_0x2ec27f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x332088,_0x4b7098){this['storage'][_0x332088]=_0x4b7098;}async['_get'](_0x24c8ce){const _0x3a5e4f=this['storage'][_0x24c8ce];return _0x3a5e4f===void 0x0?null:_0x3a5e4f;}async['_remove'](_0x4a9b0f){delete this['storage'][_0x4a9b0f];}['_addListener'](_0x5a755,_0x4719e9){}['_removeListener'](_0x4f3f3f,_0x512910){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x428aad,_0x10d313,_0x263646){return'firebase:'+_0x428aad+':'+_0x10d313+':'+_0x263646;}class tt{constructor(_0x4a3256,_0x5334b4,_0x207204){this['persistence']=_0x4a3256,this['auth']=_0x5334b4,this['userKey']=_0x207204;const {config:_0x39510f,name:_0x11dd98}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x39510f['apiKey'],_0x11dd98),this['fullPersistenceKey']=ln('persistence',_0x39510f['apiKey'],_0x11dd98),this['boundEventHandler']=_0x5334b4['_onStorageEvent']['bind'](_0x5334b4),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4a871d){return this['persistence']['_set'](this['fullUserKey'],_0x4a871d['toJSON']());}async['getCurrentUser'](){const _0x3917f7=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3917f7)return null;if(typeof _0x3917f7=='string'){const _0x556954=await Pn(this['auth'],{'idToken':_0x3917f7})['catch'](()=>{});return _0x556954?j['_fromGetAccountInfoResponse'](this['auth'],_0x556954,_0x3917f7):null;}return j['_fromJSON'](this['auth'],_0x3917f7);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x398e87){if(this['persistence']===_0x398e87)return;const _0x2bfc0d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x398e87,_0x2bfc0d)return this['setCurrentUser'](_0x2bfc0d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x219a1a,_0x1af7c1,_0x52396e='authUser'){if(!_0x1af7c1['length'])return new tt(ie(Sr),_0x219a1a,_0x52396e);const _0x2a14be=(await Promise['all'](_0x1af7c1['map'](async _0x24465c=>{if(await _0x24465c['_isAvailable']())return _0x24465c;})))['filter'](_0x4c30a5=>_0x4c30a5);let _0x204376=_0x2a14be[0x0]||ie(Sr);const _0x4a46a7=ln(_0x52396e,_0x219a1a['config']['apiKey'],_0x219a1a['name']);let _0x5b1100=null;for(const _0x7ae6a9 of _0x1af7c1)try{const _0x24462f=await _0x7ae6a9['_get'](_0x4a46a7);if(_0x24462f){let _0xbe42d5;if(typeof _0x24462f=='string'){const _0x41cdd0=await Pn(_0x219a1a,{'idToken':_0x24462f})['catch'](()=>{});if(!_0x41cdd0)break;_0xbe42d5=await j['_fromGetAccountInfoResponse'](_0x219a1a,_0x41cdd0,_0x24462f);}else _0xbe42d5=j['_fromJSON'](_0x219a1a,_0x24462f);_0x7ae6a9!==_0x204376&&(_0x5b1100=_0xbe42d5),_0x204376=_0x7ae6a9;break;}}catch{}const _0x806d54=_0x2a14be['filter'](_0x270510=>_0x270510['_shouldAllowMigration']);return!_0x204376['_shouldAllowMigration']||!_0x806d54['length']?new tt(_0x204376,_0x219a1a,_0x52396e):(_0x204376=_0x806d54[0x0],_0x5b1100&&await _0x204376['_set'](_0x4a46a7,_0x5b1100['toJSON']()),await Promise['all'](_0x1af7c1['map'](async _0x1dd84f=>{if(_0x1dd84f!==_0x204376)try{await _0x1dd84f['_remove'](_0x4a46a7);}catch{}})),new tt(_0x204376,_0x219a1a,_0x52396e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x278f8d){const _0x17880c=_0x278f8d['toLowerCase']();if(_0x17880c['includes']('opera/')||_0x17880c['includes']('opr/')||_0x17880c['includes']('opios/'))return'Opera';if(Pa(_0x17880c))return'IEMobile';if(_0x17880c['includes']('msie')||_0x17880c['includes']('trident/'))return'IE';if(_0x17880c['includes']('edge/'))return'Edge';if(Ra(_0x17880c))return'Firefox';if(_0x17880c['includes']('silk/'))return'Silk';if(Oa(_0x17880c))return'Blackberry';if(Da(_0x17880c))return'Webos';if(Aa(_0x17880c))return'Safari';if((_0x17880c['includes']('chrome/')||ka(_0x17880c))&&!_0x17880c['includes']('edge/'))return'Chrome';if(Na(_0x17880c))return'Android';{const _0x2105ff=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5d4137=_0x278f8d['match'](_0x2105ff);if((_0x5d4137==null?void 0x0:_0x5d4137['length'])===0x2)return _0x5d4137[0x1];}return'Other';}function Ra(_0x5634ef=W()){return/firefox\//i['test'](_0x5634ef);}function Aa(_0x8fe535=W()){const _0x49cb23=_0x8fe535['toLowerCase']();return _0x49cb23['includes']('safari/')&&!_0x49cb23['includes']('chrome/')&&!_0x49cb23['includes']('crios/')&&!_0x49cb23['includes']('android');}function ka(_0x354526=W()){return/crios\//i['test'](_0x354526);}function Pa(_0x211ecb=W()){return/iemobile/i['test'](_0x211ecb);}function Na(_0x6cc7a6=W()){return/android/i['test'](_0x6cc7a6);}function Oa(_0x5b0e66=W()){return/blackberry/i['test'](_0x5b0e66);}function Da(_0x284486=W()){return/webos/i['test'](_0x284486);}function Ss(_0x344fe9=W()){return/iphone|ipad|ipod/i['test'](_0x344fe9)||/macintosh/i['test'](_0x344fe9)&&/mobile/i['test'](_0x344fe9);}function Rf(_0x3aa31c=W()){var _0x4c5253;return Ss(_0x3aa31c)&&!!((_0x4c5253=window['navigator'])!=null&&_0x4c5253['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3ec345=W()){return Ss(_0x3ec345)||Na(_0x3ec345)||Da(_0x3ec345)||Oa(_0x3ec345)||/windows phone/i['test'](_0x3ec345)||Pa(_0x3ec345);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x53dd40,_0xb297c2=[]){let _0x3b3c3f;switch(_0x53dd40){case'Browser':_0x3b3c3f=br(W());break;case'Worker':_0x3b3c3f=br(W())+'-'+_0x53dd40;break;default:_0x3b3c3f=_0x53dd40;}const _0x3e2601=_0xb297c2['length']?_0xb297c2['join'](','):'FirebaseCore-web';return _0x3b3c3f+'/JsCore/'+dt+'/'+_0x3e2601;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x49ef8d){this['auth']=_0x49ef8d,this['queue']=[];}['pushCallback'](_0x319098,_0x5bd36f){const _0x2de817=_0x3c5297=>new Promise((_0x339b95,_0x4ea89c)=>{try{const _0x4daae5=_0x319098(_0x3c5297);_0x339b95(_0x4daae5);}catch(_0x9b36ae){_0x4ea89c(_0x9b36ae);}});_0x2de817['onAbort']=_0x5bd36f,this['queue']['push'](_0x2de817);const _0x40e195=this['queue']['length']-0x1;return()=>{this['queue'][_0x40e195]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5686a9){if(this['auth']['currentUser']===_0x5686a9)return;const _0x5b9ffb=[];try{for(const _0x5d1a5c of this['queue'])await _0x5d1a5c(_0x5686a9),_0x5d1a5c['onAbort']&&_0x5b9ffb['push'](_0x5d1a5c['onAbort']);}catch(_0x2d07d3){_0x5b9ffb['reverse']();for(const _0x4bdcab of _0x5b9ffb)try{_0x4bdcab();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2d07d3==null?void 0x0:_0x2d07d3['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0xbce638,_0x3b7664={}){return Pe(_0xbce638,'GET','/v2/passwordPolicy',ke(_0xbce638,_0x3b7664));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x5b70cd){var _0x13923d;const _0x433ff5=_0x5b70cd['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x433ff5['minPasswordLength']??Nf,_0x433ff5['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x433ff5['maxPasswordLength']),_0x433ff5['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x433ff5['containsLowercaseCharacter']),_0x433ff5['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x433ff5['containsUppercaseCharacter']),_0x433ff5['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x433ff5['containsNumericCharacter']),_0x433ff5['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x433ff5['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5b70cd['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x13923d=_0x5b70cd['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x13923d['join'](''))??'',this['forceUpgradeOnSignin']=_0x5b70cd['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5b70cd['schemaVersion'];}['validatePassword'](_0x188740){const _0x10b652={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x188740,_0x10b652),this['validatePasswordCharacterOptions'](_0x188740,_0x10b652),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['meetsMinPasswordLength']??!0x0),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['meetsMaxPasswordLength']??!0x0),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['containsLowercaseLetter']??!0x0),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['containsUppercaseLetter']??!0x0),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['containsNumericCharacter']??!0x0),_0x10b652['isValid']&&(_0x10b652['isValid']=_0x10b652['containsNonAlphanumericCharacter']??!0x0),_0x10b652;}['validatePasswordLengthOptions'](_0x3c468a,_0x3540d5){const _0x1393a2=this['customStrengthOptions']['minPasswordLength'],_0x16a024=this['customStrengthOptions']['maxPasswordLength'];_0x1393a2&&(_0x3540d5['meetsMinPasswordLength']=_0x3c468a['length']>=_0x1393a2),_0x16a024&&(_0x3540d5['meetsMaxPasswordLength']=_0x3c468a['length']<=_0x16a024);}['validatePasswordCharacterOptions'](_0x33bb9d,_0x4ce410){this['updatePasswordCharacterOptionsStatuses'](_0x4ce410,!0x1,!0x1,!0x1,!0x1);let _0x5d9bd0;for(let _0x592a24=0x0;_0x592a24<_0x33bb9d['length'];_0x592a24++)_0x5d9bd0=_0x33bb9d['charAt'](_0x592a24),this['updatePasswordCharacterOptionsStatuses'](_0x4ce410,_0x5d9bd0>='a'&&_0x5d9bd0<='z',_0x5d9bd0>='A'&&_0x5d9bd0<='Z',_0x5d9bd0>='0'&&_0x5d9bd0<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5d9bd0));}['updatePasswordCharacterOptionsStatuses'](_0x5c80e7,_0x53b486,_0x2a9ade,_0x14e1c3,_0x5be12f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5c80e7['containsLowercaseLetter']||(_0x5c80e7['containsLowercaseLetter']=_0x53b486)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5c80e7['containsUppercaseLetter']||(_0x5c80e7['containsUppercaseLetter']=_0x2a9ade)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5c80e7['containsNumericCharacter']||(_0x5c80e7['containsNumericCharacter']=_0x14e1c3)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5c80e7['containsNonAlphanumericCharacter']||(_0x5c80e7['containsNonAlphanumericCharacter']=_0x5be12f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x496e1b,_0x56bb32,_0x3f06ea,_0x33a718){this['app']=_0x496e1b,this['heartbeatServiceProvider']=_0x56bb32,this['appCheckServiceProvider']=_0x3f06ea,this['config']=_0x33a718,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x496e1b['name'],this['clientVersion']=_0x33a718['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xedc64d=>this['_resolvePersistenceManagerAvailable']=_0xedc64d);}['_initializeWithPersistence'](_0x3b9ce0,_0x441985){return _0x441985&&(this['_popupRedirectResolver']=ie(_0x441985)),this['_initializationPromise']=this['queue'](async()=>{var _0x582fb6,_0x20af55,_0x5a6eea;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x3b9ce0),(_0x582fb6=this['_resolvePersistenceManagerAvailable'])==null||_0x582fb6['call'](this),!this['_deleted'])){if((_0x20af55=this['_popupRedirectResolver'])!=null&&_0x20af55['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x441985),this['lastNotifiedUid']=((_0x5a6eea=this['currentUser'])==null?void 0x0:_0x5a6eea['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x36d42e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x36d42e)){if(this['currentUser']&&_0x36d42e&&this['currentUser']['uid']===_0x36d42e['uid']){this['_currentUser']['_assign'](_0x36d42e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x36d42e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x13043c){try{const _0x40ca5d=await Pn(this,{'idToken':_0x13043c}),_0x2bf372=await j['_fromGetAccountInfoResponse'](this,_0x40ca5d,_0x13043c);await this['directlySetCurrentUser'](_0x2bf372);}catch(_0x2fad1c){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2fad1c),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xba5d08){var _0x16d3ae;if($(this['app'])){const _0x2c45f6=this['app']['settings']['authIdToken'];return _0x2c45f6?new Promise(_0xd13c20=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2c45f6)['then'](_0xd13c20,_0xd13c20));}):this['directlySetCurrentUser'](null);}const _0x125d47=await this['assertedPersistence']['getCurrentUser']();let _0x6a5a94=_0x125d47,_0x42fa7b=!0x1;if(_0xba5d08&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5f0722=(_0x16d3ae=this['redirectUser'])==null?void 0x0:_0x16d3ae['_redirectEventId'],_0x529278=_0x6a5a94==null?void 0x0:_0x6a5a94['_redirectEventId'],_0x1adc6b=await this['tryRedirectSignIn'](_0xba5d08);(!_0x5f0722||_0x5f0722===_0x529278)&&(_0x1adc6b!=null&&_0x1adc6b['user'])&&(_0x6a5a94=_0x1adc6b['user'],_0x42fa7b=!0x0);}if(!_0x6a5a94)return this['directlySetCurrentUser'](null);if(!_0x6a5a94['_redirectEventId']){if(_0x42fa7b)try{await this['beforeStateQueue']['runMiddleware'](_0x6a5a94);}catch(_0x31ee13){_0x6a5a94=_0x125d47,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x31ee13));}return _0x6a5a94?this['reloadAndSetCurrentUserOrClear'](_0x6a5a94):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x6a5a94['_redirectEventId']?this['directlySetCurrentUser'](_0x6a5a94):this['reloadAndSetCurrentUserOrClear'](_0x6a5a94);}async['tryRedirectSignIn'](_0x186e07){let _0x118d45=null;try{_0x118d45=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x186e07,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x118d45;}async['reloadAndSetCurrentUserOrClear'](_0x5b59d5){try{await Nn(_0x5b59d5);}catch(_0x1bf5b2){if((_0x1bf5b2==null?void 0x0:_0x1bf5b2['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5b59d5);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x23c5da){if($(this['app']))return Promise['reject'](re(this));const _0x141db8=_0x23c5da?P(_0x23c5da):null;return _0x141db8&&m(_0x141db8['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x141db8&&_0x141db8['_clone'](this));}async['_updateCurrentUser'](_0x1e33bf,_0xdf3a6d=!0x1){if(!this['_deleted'])return _0x1e33bf&&m(this['tenantId']===_0x1e33bf['tenantId'],this,'tenant-id-mismatch'),_0xdf3a6d||await this['beforeStateQueue']['runMiddleware'](_0x1e33bf),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1e33bf),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4d21f6){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4d21f6));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4a1384){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1d750a=this['_getPasswordPolicyInternal']();return _0x1d750a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1d750a['validatePassword'](_0x4a1384);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x32f131=await Pf(this),_0x1f0106=new Of(_0x32f131);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1f0106:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1f0106;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x534584){this['_errorFactory']=new Gt('auth','Firebase',_0x534584());}['onAuthStateChanged'](_0x3a96ef,_0x4ac197,_0x266f80){return this['registerStateListener'](this['authStateSubscription'],_0x3a96ef,_0x4ac197,_0x266f80);}['beforeAuthStateChanged'](_0x3c4c0e,_0x289b5a){return this['beforeStateQueue']['pushCallback'](_0x3c4c0e,_0x289b5a);}['onIdTokenChanged'](_0xd8fb09,_0x1e8e2a,_0x45e78d){return this['registerStateListener'](this['idTokenSubscription'],_0xd8fb09,_0x1e8e2a,_0x45e78d);}['authStateReady'](){return new Promise((_0x2194ec,_0x449180)=>{if(this['currentUser'])_0x2194ec();else{const _0x401382=this['onAuthStateChanged'](()=>{_0x401382(),_0x2194ec();},_0x449180);}});}async['revokeAccessToken'](_0x40fdf9){if(this['currentUser']){const _0x2b576e=await this['currentUser']['getIdToken'](),_0x2d0de1={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x40fdf9,'idToken':_0x2b576e};this['tenantId']!=null&&(_0x2d0de1['tenantId']=this['tenantId']),await bf(this,_0x2d0de1);}}['toJSON'](){var _0x5e22c3;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5e22c3=this['_currentUser'])==null?void 0x0:_0x5e22c3['toJSON']()};}async['_setRedirectUser'](_0x61514c,_0x538643){const _0x1a1ca8=await this['getOrInitRedirectPersistenceManager'](_0x538643);return _0x61514c===null?_0x1a1ca8['removeCurrentUser']():_0x1a1ca8['setCurrentUser'](_0x61514c);}async['getOrInitRedirectPersistenceManager'](_0x1fb1d9){if(!this['redirectPersistenceManager']){const _0x2981f6=_0x1fb1d9&&ie(_0x1fb1d9)||this['_popupRedirectResolver'];m(_0x2981f6,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x2981f6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x54e70e){var _0x312715,_0x5583a3;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x312715=this['_currentUser'])==null?void 0x0:_0x312715['_redirectEventId'])===_0x54e70e?this['_currentUser']:((_0x5583a3=this['redirectUser'])==null?void 0x0:_0x5583a3['_redirectEventId'])===_0x54e70e?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2774a6){if(_0x2774a6===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2774a6));}['_notifyListenersIfCurrent'](_0x919485){_0x919485===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2ff2ed;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x42bd2a=((_0x2ff2ed=this['currentUser'])==null?void 0x0:_0x2ff2ed['uid'])??null;this['lastNotifiedUid']!==_0x42bd2a&&(this['lastNotifiedUid']=_0x42bd2a,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x18ada2,_0x4c57b1,_0x1daaac,_0xd5f5f2){if(this['_deleted'])return()=>{};const _0x51c528=typeof _0x4c57b1=='function'?_0x4c57b1:_0x4c57b1['next']['bind'](_0x4c57b1);let _0x6a5558=!0x1;const _0x44ff31=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x44ff31,this,'internal-error'),_0x44ff31['then'](()=>{_0x6a5558||_0x51c528(this['currentUser']);}),typeof _0x4c57b1=='function'){const _0x5b4365=_0x18ada2['addObserver'](_0x4c57b1,_0x1daaac,_0xd5f5f2);return()=>{_0x6a5558=!0x0,_0x5b4365();};}else{const _0x494030=_0x18ada2['addObserver'](_0x4c57b1);return()=>{_0x6a5558=!0x0,_0x494030();};}}async['directlySetCurrentUser'](_0x162967){this['currentUser']&&this['currentUser']!==_0x162967&&this['_currentUser']['_stopProactiveRefresh'](),_0x162967&&this['isProactiveRefreshEnabled']&&_0x162967['_startProactiveRefresh'](),this['currentUser']=_0x162967,_0x162967?await this['assertedPersistence']['setCurrentUser'](_0x162967):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1c7660){return this['operations']=this['operations']['then'](_0x1c7660,_0x1c7660),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3aacf8){!_0x3aacf8||this['frameworks']['includes'](_0x3aacf8)||(this['frameworks']['push'](_0x3aacf8),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x41ad09;const _0x48369a={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x48369a['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3d6422=await((_0x41ad09=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x41ad09['getHeartbeatsHeader']());_0x3d6422&&(_0x48369a['X-Firebase-Client']=_0x3d6422);const _0x36ebcd=await this['_getAppCheckToken']();return _0x36ebcd&&(_0x48369a['X-Firebase-AppCheck']=_0x36ebcd),_0x48369a;}async['_getAppCheckToken'](){var _0x5ef0c4;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xd5eee=await((_0x5ef0c4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5ef0c4['getToken']());return _0xd5eee!=null&&_0xd5eee['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xd5eee['error']),_0xd5eee==null?void 0x0:_0xd5eee['token'];}}function Ke(_0x53f8fe){return P(_0x53f8fe);}class Rr{constructor(_0x19dd2){this['auth']=_0x19dd2,this['observer']=null,this['addObserver']=Tc(_0x44c0d2=>this['observer']=_0x44c0d2);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x24341e){Jn=_0x24341e;}function xa(_0xc7ead8){return Jn['loadJS'](_0xc7ead8);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x5d6c56){return'__'+_0x5d6c56+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x4a25ee){_0x4a25ee();}['execute'](_0x4b4865,_0x1b239f){return Promise['resolve']('token');}['render'](_0x2dd1c9,_0x477134){return'';}}class Wf{['ready'](_0x1347f4){_0x1347f4();}['execute'](_0x131413,_0x4c0dbb){return Promise['resolve']('token');}['render'](_0x5760b6,_0x2ad745){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x448977){this['type']=Bf,this['auth']=Ke(_0x448977);}async['verify'](_0x3acf22='verify',_0x4981be=!0x1){async function _0x39893a(_0x2cb875){if(!_0x4981be){if(_0x2cb875['tenantId']==null&&_0x2cb875['_agentRecaptchaConfig']!=null)return _0x2cb875['_agentRecaptchaConfig']['siteKey'];if(_0x2cb875['tenantId']!=null&&_0x2cb875['_tenantRecaptchaConfigs'][_0x2cb875['tenantId']]!==void 0x0)return _0x2cb875['_tenantRecaptchaConfigs'][_0x2cb875['tenantId']]['siteKey'];}return new Promise(async(_0x555688,_0x113dde)=>{yf(_0x2cb875,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x469b21=>{if(_0x469b21['recaptchaKey']===void 0x0)_0x113dde(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2eb9b6=new mf(_0x469b21);return _0x2cb875['tenantId']==null?_0x2cb875['_agentRecaptchaConfig']=_0x2eb9b6:_0x2cb875['_tenantRecaptchaConfigs'][_0x2cb875['tenantId']]=_0x2eb9b6,_0x555688(_0x2eb9b6['siteKey']);}})['catch'](_0x4a49e2=>{_0x113dde(_0x4a49e2);});});}function _0x200a68(_0x4ccc0e,_0x310797,_0x5f4590){const _0x37e923=window['grecaptcha'];wr(_0x37e923)?_0x37e923['enterprise']['ready'](()=>{_0x37e923['enterprise']['execute'](_0x4ccc0e,{'action':_0x3acf22})['then'](_0x51184f=>{_0x310797(_0x51184f);})['catch'](()=>{_0x310797(Fa);});}):_0x5f4590(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x41c190,_0xa3b5f2)=>{_0x39893a(this['auth'])['then'](async _0x275ef2=>{if(!_0x4981be&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x200a68(_0x275ef2,_0x41c190,_0xa3b5f2);else{if(typeof window>'u'){_0xa3b5f2(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4249d2=Lf();_0x4249d2['length']!==0x0&&(_0x4249d2+=_0x275ef2+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x4cc892;(_0x4cc892=he['scriptInjectionDeferred'])==null||_0x4cc892['resolve']();},xa(_0x4249d2)['then'](()=>{var _0x59cbed;return(_0x59cbed=he['scriptInjectionDeferred'])==null?void 0x0:_0x59cbed['promise'];})['then'](()=>{_0x200a68(_0x275ef2,_0x41c190,_0xa3b5f2);})['catch'](_0xa4e21=>{_0xa3b5f2(_0xa4e21);});}})['catch'](_0x2c272c=>{_0xa3b5f2(_0x2c272c);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x510a6f,_0x6bb46e,_0x308803,_0x39fccd=!0x1,_0x3a0d91=!0x1){const _0x32d134=new he(_0x510a6f);let _0x551b35;if(_0x3a0d91)_0x551b35=Fa;else try{_0x551b35=await _0x32d134['verify'](_0x308803);}catch{_0x551b35=await _0x32d134['verify'](_0x308803,!0x0);}const _0x37b6ac={..._0x6bb46e};if(_0x308803==='mfaSmsEnrollment'||_0x308803==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x37b6ac){const _0x24178c=_0x37b6ac['phoneEnrollmentInfo']['phoneNumber'],_0x164013=_0x37b6ac['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x37b6ac,{'phoneEnrollmentInfo':{'phoneNumber':_0x24178c,'recaptchaToken':_0x164013,'captchaResponse':_0x551b35,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x37b6ac){const _0x167346=_0x37b6ac['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x37b6ac,{'phoneSignInInfo':{'recaptchaToken':_0x167346,'captchaResponse':_0x551b35,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x37b6ac;}return _0x39fccd?Object['assign'](_0x37b6ac,{'captchaResp':_0x551b35}):Object['assign'](_0x37b6ac,{'captchaResponse':_0x551b35}),Object['assign'](_0x37b6ac,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x37b6ac,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x37b6ac;}async function xi(_0x3c4e60,_0x2bfb36,_0x4de4e3,_0x4c531c,_0x2b4e39){var _0x334191;if((_0x334191=_0x3c4e60['_getRecaptchaConfig']())!=null&&_0x334191['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x28b212=await kr(_0x3c4e60,_0x2bfb36,_0x4de4e3,_0x4de4e3==='getOobCode');return _0x4c531c(_0x3c4e60,_0x28b212);}else return _0x4c531c(_0x3c4e60,_0x2bfb36)['catch'](async _0x470edf=>{if(_0x470edf['code']==='auth/missing-recaptcha-token'){console['log'](_0x4de4e3+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x48a976=await kr(_0x3c4e60,_0x2bfb36,_0x4de4e3,_0x4de4e3==='getOobCode');return _0x4c531c(_0x3c4e60,_0x48a976);}else return Promise['reject'](_0x470edf);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1b888f,_0x5ae541){const _0x44efc5=Hi(_0x1b888f,'auth');if(_0x44efc5['isInitialized']()){const _0x6785de=_0x44efc5['getImmediate'](),_0x3ee612=_0x44efc5['getOptions']();if(xe(_0x3ee612,_0x5ae541??{}))return _0x6785de;Y(_0x6785de,'already-initialized');}return _0x44efc5['initialize']({'options':_0x5ae541});}function Hf(_0x26709d,_0x6b3260){const _0x52a04f=(_0x6b3260==null?void 0x0:_0x6b3260['persistence'])||[],_0x4fd60a=(Array['isArray'](_0x52a04f)?_0x52a04f:[_0x52a04f])['map'](ie);_0x6b3260!=null&&_0x6b3260['errorMap']&&_0x26709d['_updateErrorMap'](_0x6b3260['errorMap']),_0x26709d['_initializeWithPersistence'](_0x4fd60a,_0x6b3260==null?void 0x0:_0x6b3260['popupRedirectResolver']);}function $f(_0x587f3d,_0xfb04e2,_0xcf292){const _0x4938b4=Ke(_0x587f3d);m(/^https?:\/\//['test'](_0xfb04e2),_0x4938b4,'invalid-emulator-scheme');const _0x11c343=!0x1,_0xb6d8bf=Ua(_0xfb04e2),{host:_0x3b150c,port:_0x4fc853}=Gf(_0xfb04e2),_0x57c67e=_0x4fc853===null?'':':'+_0x4fc853,_0x423e0a={'url':_0xb6d8bf+'//'+_0x3b150c+_0x57c67e+'/'},_0x6507a9=Object['freeze']({'host':_0x3b150c,'port':_0x4fc853,'protocol':_0xb6d8bf['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x11c343})});if(!_0x4938b4['_canInitEmulator']){m(_0x4938b4['config']['emulator']&&_0x4938b4['emulatorConfig'],_0x4938b4,'emulator-config-failed'),m(xe(_0x423e0a,_0x4938b4['config']['emulator'])&&xe(_0x6507a9,_0x4938b4['emulatorConfig']),_0x4938b4,'emulator-config-failed');return;}_0x4938b4['config']['emulator']=_0x423e0a,_0x4938b4['emulatorConfig']=_0x6507a9,_0x4938b4['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x3b150c)?Qr(_0xb6d8bf+'//'+_0x3b150c+_0x57c67e):qf();}function Ua(_0x4bc97e){const _0x3a2331=_0x4bc97e['indexOf'](':');return _0x3a2331<0x0?'':_0x4bc97e['substr'](0x0,_0x3a2331+0x1);}function Gf(_0x32dc0b){const _0x14e937=Ua(_0x32dc0b),_0x5c58c3=/(\/\/)?([^?#/]+)/['exec'](_0x32dc0b['substr'](_0x14e937['length']));if(!_0x5c58c3)return{'host':'','port':null};const _0x35caac=_0x5c58c3[0x2]['split']('@')['pop']()||'',_0x3e0862=/^(\[[^\]]+\])(:|$)/['exec'](_0x35caac);if(_0x3e0862){const _0xd67b5c=_0x3e0862[0x1];return{'host':_0xd67b5c,'port':Pr(_0x35caac['substr'](_0xd67b5c['length']+0x1))};}else{const [_0x4e8eb0,_0x223052]=_0x35caac['split'](':');return{'host':_0x4e8eb0,'port':Pr(_0x223052)};}}function Pr(_0x25b1ad){if(!_0x25b1ad)return null;const _0x26c617=Number(_0x25b1ad);return isNaN(_0x26c617)?null:_0x26c617;}function qf(){function _0x11f74a(){const _0x433341=document['createElement']('p'),_0x5bc4cd=_0x433341['style'];_0x433341['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5bc4cd['position']='fixed',_0x5bc4cd['width']='100%',_0x5bc4cd['backgroundColor']='#ffffff',_0x5bc4cd['border']='.1em\x20solid\x20#000000',_0x5bc4cd['color']='#b50000',_0x5bc4cd['bottom']='0px',_0x5bc4cd['left']='0px',_0x5bc4cd['margin']='0px',_0x5bc4cd['zIndex']='10000',_0x5bc4cd['textAlign']='center',_0x433341['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x433341);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x11f74a):_0x11f74a());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3e3fab,_0x51ee0e){this['providerId']=_0x3e3fab,this['signInMethod']=_0x51ee0e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3ea10f){return ne('not\x20implemented');}['_linkToIdToken'](_0x59cdc0,_0x523f16){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x52c77e){return ne('not\x20implemented');}}async function zf(_0x3fd8c7,_0x3dcc65){return Pe(_0x3fd8c7,'POST','/v1/accounts:signUp',_0x3dcc65);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x23d1d9,_0x4b9eac){return en(_0x23d1d9,'POST','/v1/accounts:signInWithPassword',ke(_0x23d1d9,_0x4b9eac));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5d3180,_0x112f58){return en(_0x5d3180,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5d3180,_0x112f58));}async function Yf(_0x44bc7e,_0x182cd6){return en(_0x44bc7e,'POST','/v1/accounts:signInWithEmailLink',ke(_0x44bc7e,_0x182cd6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x139a12,_0x43916a,_0x20e1c1,_0x20cd8a=null){super('password',_0x20e1c1),this['_email']=_0x139a12,this['_password']=_0x43916a,this['_tenantId']=_0x20cd8a;}static['_fromEmailAndPassword'](_0x5a4897,_0x282aa0){return new $t(_0x5a4897,_0x282aa0,'password');}static['_fromEmailAndCode'](_0x1019c3,_0x775146,_0x5ef80e=null){return new $t(_0x1019c3,_0x775146,'emailLink',_0x5ef80e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x20e868){const _0x1ebefe=typeof _0x20e868=='string'?JSON['parse'](_0x20e868):_0x20e868;if(_0x1ebefe!=null&&_0x1ebefe['email']&&(_0x1ebefe!=null&&_0x1ebefe['password'])){if(_0x1ebefe['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1ebefe['email'],_0x1ebefe['password']);if(_0x1ebefe['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1ebefe['email'],_0x1ebefe['password'],_0x1ebefe['tenantId']);}return null;}async['_getIdTokenResponse'](_0x533f4b){switch(this['signInMethod']){case'password':const _0x1a4452={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x533f4b,_0x1a4452,'signInWithPassword',jf);case'emailLink':return Kf(_0x533f4b,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x533f4b,'internal-error');}}async['_linkToIdToken'](_0x1a3f07,_0x22e66b){switch(this['signInMethod']){case'password':const _0x145563={'idToken':_0x22e66b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1a3f07,_0x145563,'signUpPassword',zf);case'emailLink':return Yf(_0x1a3f07,{'idToken':_0x22e66b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1a3f07,'internal-error');}}['_getReauthenticationResolver'](_0x3fa034){return this['_getIdTokenResponse'](_0x3fa034);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x22fbcc,_0x51645e){return en(_0x22fbcc,'POST','/v1/accounts:signInWithIdp',ke(_0x22fbcc,_0x51645e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2f66b0){const _0x4ef616=new $e(_0x2f66b0['providerId'],_0x2f66b0['signInMethod']);return _0x2f66b0['idToken']||_0x2f66b0['accessToken']?(_0x2f66b0['idToken']&&(_0x4ef616['idToken']=_0x2f66b0['idToken']),_0x2f66b0['accessToken']&&(_0x4ef616['accessToken']=_0x2f66b0['accessToken']),_0x2f66b0['nonce']&&!_0x2f66b0['pendingToken']&&(_0x4ef616['nonce']=_0x2f66b0['nonce']),_0x2f66b0['pendingToken']&&(_0x4ef616['pendingToken']=_0x2f66b0['pendingToken'])):_0x2f66b0['oauthToken']&&_0x2f66b0['oauthTokenSecret']?(_0x4ef616['accessToken']=_0x2f66b0['oauthToken'],_0x4ef616['secret']=_0x2f66b0['oauthTokenSecret']):Y('argument-error'),_0x4ef616;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2f9e83){const _0xfd9f68=typeof _0x2f9e83=='string'?JSON['parse'](_0x2f9e83):_0x2f9e83,{providerId:_0x2db999,signInMethod:_0x50351e,..._0x54badb}=_0xfd9f68;if(!_0x2db999||!_0x50351e)return null;const _0x673789=new $e(_0x2db999,_0x50351e);return _0x673789['idToken']=_0x54badb['idToken']||void 0x0,_0x673789['accessToken']=_0x54badb['accessToken']||void 0x0,_0x673789['secret']=_0x54badb['secret'],_0x673789['nonce']=_0x54badb['nonce'],_0x673789['pendingToken']=_0x54badb['pendingToken']||null,_0x673789;}['_getIdTokenResponse'](_0x5b757e){const _0xb98a2c=this['buildRequest']();return nt(_0x5b757e,_0xb98a2c);}['_linkToIdToken'](_0x12ba92,_0x2fa1c5){const _0x1d584a=this['buildRequest']();return _0x1d584a['idToken']=_0x2fa1c5,nt(_0x12ba92,_0x1d584a);}['_getReauthenticationResolver'](_0x2c5c8f){const _0x50b4e4=this['buildRequest']();return _0x50b4e4['autoCreate']=!0x1,nt(_0x2c5c8f,_0x50b4e4);}['buildRequest'](){const _0x424197={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x424197['pendingToken']=this['pendingToken'];else{const _0x510b5d={};this['idToken']&&(_0x510b5d['id_token']=this['idToken']),this['accessToken']&&(_0x510b5d['access_token']=this['accessToken']),this['secret']&&(_0x510b5d['oauth_token_secret']=this['secret']),_0x510b5d['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x510b5d['nonce']=this['nonce']),_0x424197['postBody']=ut(_0x510b5d);}return _0x424197;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1596b4){switch(_0x1596b4){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x19a6c2){const _0x2e6e7c=Ct(Tt(_0x19a6c2))['link'],_0x5ebd2e=_0x2e6e7c?Ct(Tt(_0x2e6e7c))['deep_link_id']:null,_0x5737bb=Ct(Tt(_0x19a6c2))['deep_link_id'];return(_0x5737bb?Ct(Tt(_0x5737bb))['link']:null)||_0x5737bb||_0x5ebd2e||_0x2e6e7c||_0x19a6c2;}class Rs{constructor(_0xca7a08){const _0x2ef041=Ct(Tt(_0xca7a08)),_0x21e59d=_0x2ef041['apiKey']??null,_0x4dfcb1=_0x2ef041['oobCode']??null,_0x436c46=Jf(_0x2ef041['mode']??null);m(_0x21e59d&&_0x4dfcb1&&_0x436c46,'argument-error'),this['apiKey']=_0x21e59d,this['operation']=_0x436c46,this['code']=_0x4dfcb1,this['continueUrl']=_0x2ef041['continueUrl']??null,this['languageCode']=_0x2ef041['lang']??null,this['tenantId']=_0x2ef041['tenantId']??null;}static['parseLink'](_0x4d5ea6){const _0x1ec864=Xf(_0x4d5ea6);try{return new Rs(_0x1ec864);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x5b1b85,_0x1d917f){return $t['_fromEmailAndPassword'](_0x5b1b85,_0x1d917f);}static['credentialWithLink'](_0x1be3e1,_0x5a3234){const _0x47fcef=Rs['parseLink'](_0x5a3234);return m(_0x47fcef,'argument-error'),$t['_fromEmailAndCode'](_0x1be3e1,_0x47fcef['code'],_0x47fcef['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x251564){this['providerId']=_0x251564,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1c3991){this['defaultLanguageCode']=_0x1c3991;}['setCustomParameters'](_0x240d40){return this['customParameters']=_0x240d40,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x519ffd){return this['scopes']['includes'](_0x519ffd)||this['scopes']['push'](_0x519ffd),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5a2719){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5a2719});}static['credentialFromResult'](_0xe4c0e3){return ue['credentialFromTaggedObject'](_0xe4c0e3);}static['credentialFromError'](_0x2cfd9d){return ue['credentialFromTaggedObject'](_0x2cfd9d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x17c243}){if(!_0x17c243||!('oauthAccessToken'in _0x17c243)||!_0x17c243['oauthAccessToken'])return null;try{return ue['credential'](_0x17c243['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1058ee,_0x21cb15){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1058ee,'accessToken':_0x21cb15});}static['credentialFromResult'](_0x11b728){return de['credentialFromTaggedObject'](_0x11b728);}static['credentialFromError'](_0x49d9e1){return de['credentialFromTaggedObject'](_0x49d9e1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1904ce}){if(!_0x1904ce)return null;const {oauthIdToken:_0x34b714,oauthAccessToken:_0x519623}=_0x1904ce;if(!_0x34b714&&!_0x519623)return null;try{return de['credential'](_0x34b714,_0x519623);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5eb792){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5eb792});}static['credentialFromResult'](_0x4ca1e8){return fe['credentialFromTaggedObject'](_0x4ca1e8);}static['credentialFromError'](_0x4443fc){return fe['credentialFromTaggedObject'](_0x4443fc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x42b79d}){if(!_0x42b79d||!('oauthAccessToken'in _0x42b79d)||!_0x42b79d['oauthAccessToken'])return null;try{return fe['credential'](_0x42b79d['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x26bb5f,_0x1f13b0){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x26bb5f,'oauthTokenSecret':_0x1f13b0});}static['credentialFromResult'](_0x402748){return pe['credentialFromTaggedObject'](_0x402748);}static['credentialFromError'](_0x5d5b15){return pe['credentialFromTaggedObject'](_0x5d5b15['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4f19d0}){if(!_0x4f19d0)return null;const {oauthAccessToken:_0xc17112,oauthTokenSecret:_0x296ee2}=_0x4f19d0;if(!_0xc17112||!_0x296ee2)return null;try{return pe['credential'](_0xc17112,_0x296ee2);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4303bb,_0xcd86f6){return en(_0x4303bb,'POST','/v1/accounts:signUp',ke(_0x4303bb,_0xcd86f6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x32632e){this['user']=_0x32632e['user'],this['providerId']=_0x32632e['providerId'],this['_tokenResponse']=_0x32632e['_tokenResponse'],this['operationType']=_0x32632e['operationType'];}static async['_fromIdTokenResponse'](_0x1b93c1,_0xa3fe9d,_0x485e52,_0x342ea0=!0x1){const _0x25adec=await j['_fromIdTokenResponse'](_0x1b93c1,_0x485e52,_0x342ea0),_0x24f110=Nr(_0x485e52);return new Ge({'user':_0x25adec,'providerId':_0x24f110,'_tokenResponse':_0x485e52,'operationType':_0xa3fe9d});}static async['_forOperation'](_0x5f2021,_0x460113,_0x44a4b3){await _0x5f2021['_updateTokensIfNecessary'](_0x44a4b3,!0x0);const _0x2a1a2d=Nr(_0x44a4b3);return new Ge({'user':_0x5f2021,'providerId':_0x2a1a2d,'_tokenResponse':_0x44a4b3,'operationType':_0x460113});}}function Nr(_0x583b1f){return _0x583b1f['providerId']?_0x583b1f['providerId']:'phoneNumber'in _0x583b1f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x2851f3,_0x394c65,_0x4cdc8d,_0x3f69ee){super(_0x394c65['code'],_0x394c65['message']),this['operationType']=_0x4cdc8d,this['user']=_0x3f69ee,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x2851f3['name'],'tenantId':_0x2851f3['tenantId']??void 0x0,'_serverResponse':_0x394c65['customData']['_serverResponse'],'operationType':_0x4cdc8d};}static['_fromErrorAndOperation'](_0x432f4f,_0x3f617c,_0x1aa7b8,_0x263e02){return new On(_0x432f4f,_0x3f617c,_0x1aa7b8,_0x263e02);}}function Ba(_0x5ba4d3,_0xb0adcb,_0x2a18a4,_0x2ac448){return(_0xb0adcb==='reauthenticate'?_0x2a18a4['_getReauthenticationResolver'](_0x5ba4d3):_0x2a18a4['_getIdTokenResponse'](_0x5ba4d3))['catch'](_0x2fd961=>{throw _0x2fd961['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x5ba4d3,_0x2fd961,_0xb0adcb,_0x2ac448):_0x2fd961;});}async function ep(_0x359956,_0x38215c,_0x181328=!0x1){const _0x1beaa1=await Ht(_0x359956,_0x38215c['_linkToIdToken'](_0x359956['auth'],await _0x359956['getIdToken']()),_0x181328);return Ge['_forOperation'](_0x359956,'link',_0x1beaa1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3fe6e0,_0x148a0a,_0x2ebeb5=!0x1){const {auth:_0x40a935}=_0x3fe6e0;if($(_0x40a935['app']))return Promise['reject'](re(_0x40a935));const _0x31087a='reauthenticate';try{const _0x200bc3=await Ht(_0x3fe6e0,Ba(_0x40a935,_0x31087a,_0x148a0a,_0x3fe6e0),_0x2ebeb5);m(_0x200bc3['idToken'],_0x40a935,'internal-error');const _0x3cc8ea=Ts(_0x200bc3['idToken']);m(_0x3cc8ea,_0x40a935,'internal-error');const {sub:_0x44ca29}=_0x3cc8ea;return m(_0x3fe6e0['uid']===_0x44ca29,_0x40a935,'user-mismatch'),Ge['_forOperation'](_0x3fe6e0,_0x31087a,_0x200bc3);}catch(_0x5ec73b){throw(_0x5ec73b==null?void 0x0:_0x5ec73b['code'])==='auth/user-not-found'&&Y(_0x40a935,'user-mismatch'),_0x5ec73b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x12fd6b,_0x3a082e,_0x331ed3=!0x1){if($(_0x12fd6b['app']))return Promise['reject'](re(_0x12fd6b));const _0x4bacf5='signIn',_0x4adbe9=await Ba(_0x12fd6b,_0x4bacf5,_0x3a082e),_0x3f19ce=await Ge['_fromIdTokenResponse'](_0x12fd6b,_0x4bacf5,_0x4adbe9);return _0x331ed3||await _0x12fd6b['_updateCurrentUser'](_0x3f19ce['user']),_0x3f19ce;}async function np(_0x1548c9,_0x3de5a7){return Va(Ke(_0x1548c9),_0x3de5a7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5d94ae){const _0x1c9d60=Ke(_0x5d94ae);_0x1c9d60['_getPasswordPolicyInternal']()&&await _0x1c9d60['_updatePasswordPolicy']();}async function L_(_0x5252c9,_0x471b70,_0x2d3ec0){if($(_0x5252c9['app']))return Promise['reject'](re(_0x5252c9));const _0x3da884=Ke(_0x5252c9),_0x1a7b84=await xi(_0x3da884,{'returnSecureToken':!0x0,'email':_0x471b70,'password':_0x2d3ec0,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x577323=>{throw _0x577323['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5252c9),_0x577323;}),_0x2de476=await Ge['_fromIdTokenResponse'](_0x3da884,'signIn',_0x1a7b84);return await _0x3da884['_updateCurrentUser'](_0x2de476['user']),_0x2de476;}function x_(_0x33c874,_0x5194b2,_0x31496b){return $(_0x33c874['app'])?Promise['reject'](re(_0x33c874)):np(P(_0x33c874),yt['credential'](_0x5194b2,_0x31496b))['catch'](async _0x3bd29b=>{throw _0x3bd29b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x33c874),_0x3bd29b;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x16ecd8,_0x432cfa){return P(_0x16ecd8)['setPersistence'](_0x432cfa);}function ip(_0x19c2f6,_0x28e84b,_0x45a476,_0x54d97f){return P(_0x19c2f6)['onIdTokenChanged'](_0x28e84b,_0x45a476,_0x54d97f);}function sp(_0x491d7c,_0x2754e7,_0x4c40d3){return P(_0x491d7c)['beforeAuthStateChanged'](_0x2754e7,_0x4c40d3);}function U_(_0x313394,_0x472548,_0x13554d,_0x3f3e03){return P(_0x313394)['onAuthStateChanged'](_0x472548,_0x13554d,_0x3f3e03);}function W_(_0x37a2db){return P(_0x37a2db)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5dc414,_0x1b115d){this['storageRetriever']=_0x5dc414,this['type']=_0x1b115d;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x58e606,_0x29db41){return this['storage']['setItem'](_0x58e606,JSON['stringify'](_0x29db41)),Promise['resolve']();}['_get'](_0x48e292){const _0xda8600=this['storage']['getItem'](_0x48e292);return Promise['resolve'](_0xda8600?JSON['parse'](_0xda8600):null);}['_remove'](_0xc4c786){return this['storage']['removeItem'](_0xc4c786),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5ea061,_0x5cf0de)=>this['onStorageEvent'](_0x5ea061,_0x5cf0de),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3176fc){for(const _0x2adf51 of Object['keys'](this['listeners'])){const _0x5df930=this['storage']['getItem'](_0x2adf51),_0xe49630=this['localCache'][_0x2adf51];_0x5df930!==_0xe49630&&_0x3176fc(_0x2adf51,_0xe49630,_0x5df930);}}['onStorageEvent'](_0x41283e,_0x44fea3=!0x1){if(!_0x41283e['key']){this['forAllChangedKeys']((_0xe6b0c7,_0x288736,_0xcd295e)=>{this['notifyListeners'](_0xe6b0c7,_0xcd295e);});return;}const _0x2c395f=_0x41283e['key'];_0x44fea3?this['detachListener']():this['stopPolling']();const _0x1f9780=()=>{const _0x2dc384=this['storage']['getItem'](_0x2c395f);!_0x44fea3&&this['localCache'][_0x2c395f]===_0x2dc384||this['notifyListeners'](_0x2c395f,_0x2dc384);},_0x12b786=this['storage']['getItem'](_0x2c395f);Af()&&_0x12b786!==_0x41283e['newValue']&&_0x41283e['newValue']!==_0x41283e['oldValue']?setTimeout(_0x1f9780,op):_0x1f9780();}['notifyListeners'](_0x35b923,_0x5acfa){this['localCache'][_0x35b923]=_0x5acfa;const _0x3f43f5=this['listeners'][_0x35b923];if(_0x3f43f5){for(const _0x445974 of Array['from'](_0x3f43f5))_0x445974(_0x5acfa&&JSON['parse'](_0x5acfa));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5961a1,_0x45d887,_0x5d2214)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5961a1,'oldValue':_0x45d887,'newValue':_0x5d2214}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xd9066d,_0x25348e){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xd9066d]||(this['listeners'][_0xd9066d]=new Set(),this['localCache'][_0xd9066d]=this['storage']['getItem'](_0xd9066d)),this['listeners'][_0xd9066d]['add'](_0x25348e);}['_removeListener'](_0x4fc1f0,_0x4a751a){this['listeners'][_0x4fc1f0]&&(this['listeners'][_0x4fc1f0]['delete'](_0x4a751a),this['listeners'][_0x4fc1f0]['size']===0x0&&delete this['listeners'][_0x4fc1f0]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4f788d,_0x59aa05){await super['_set'](_0x4f788d,_0x59aa05),this['localCache'][_0x4f788d]=JSON['stringify'](_0x59aa05);}async['_get'](_0x4aa493){const _0x58499e=await super['_get'](_0x4aa493);return this['localCache'][_0x4aa493]=JSON['stringify'](_0x58499e),_0x58499e;}async['_remove'](_0x19739e){await super['_remove'](_0x19739e),delete this['localCache'][_0x19739e];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2384d0,_0x15a2dc){}['_removeListener'](_0x49998e,_0x42c964){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x13c28d){return Promise['all'](_0x13c28d['map'](async _0x822e65=>{try{return{'fulfilled':!0x0,'value':await _0x822e65};}catch(_0x429242){return{'fulfilled':!0x1,'reason':_0x429242};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1377fe){this['eventTarget']=_0x1377fe,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x272410){const _0x250914=this['receivers']['find'](_0xc1edc6=>_0xc1edc6['isListeningto'](_0x272410));if(_0x250914)return _0x250914;const _0x27dfdf=new Xn(_0x272410);return this['receivers']['push'](_0x27dfdf),_0x27dfdf;}['isListeningto'](_0x81ceb2){return this['eventTarget']===_0x81ceb2;}async['handleEvent'](_0x5c7515){const _0x4f976d=_0x5c7515,{eventId:_0x17da64,eventType:_0x2bb75b,data:_0x526d6a}=_0x4f976d['data'],_0x2a3393=this['handlersMap'][_0x2bb75b];if(!(_0x2a3393!=null&&_0x2a3393['size']))return;_0x4f976d['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x17da64,'eventType':_0x2bb75b});const _0x53cacb=Array['from'](_0x2a3393)['map'](async _0x10a354=>_0x10a354(_0x4f976d['origin'],_0x526d6a)),_0x382cba=await cp(_0x53cacb);_0x4f976d['ports'][0x0]['postMessage']({'status':'done','eventId':_0x17da64,'eventType':_0x2bb75b,'response':_0x382cba});}['_subscribe'](_0x35d8d7,_0x166f6f){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x35d8d7]||(this['handlersMap'][_0x35d8d7]=new Set()),this['handlersMap'][_0x35d8d7]['add'](_0x166f6f);}['_unsubscribe'](_0x54fadc,_0x546a78){this['handlersMap'][_0x54fadc]&&_0x546a78&&this['handlersMap'][_0x54fadc]['delete'](_0x546a78),(!_0x546a78||this['handlersMap'][_0x54fadc]['size']===0x0)&&delete this['handlersMap'][_0x54fadc],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x345262='',_0x3532cf=0xa){let _0x5dc3f4='';for(let _0xea903e=0x0;_0xea903e<_0x3532cf;_0xea903e++)_0x5dc3f4+=Math['floor'](Math['random']()*0xa);return _0x345262+_0x5dc3f4;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x27f9af){this['target']=_0x27f9af,this['handlers']=new Set();}['removeMessageHandler'](_0x4c96b0){_0x4c96b0['messageChannel']&&(_0x4c96b0['messageChannel']['port1']['removeEventListener']('message',_0x4c96b0['onMessage']),_0x4c96b0['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4c96b0);}async['_send'](_0x27eca8,_0x5c762b,_0x7bf7c4=0x32){const _0x50fd5=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x50fd5)throw new Error('connection_unavailable');let _0xc0ef74,_0x55448e;return new Promise((_0x1fdb1e,_0x21074c)=>{const _0x3dc679=As('',0x14);_0x50fd5['port1']['start']();const _0x30f373=setTimeout(()=>{_0x21074c(new Error('unsupported_event'));},_0x7bf7c4);_0x55448e={'messageChannel':_0x50fd5,'onMessage'(_0x4c321a){const _0x2e2b73=_0x4c321a;if(_0x2e2b73['data']['eventId']===_0x3dc679)switch(_0x2e2b73['data']['status']){case'ack':clearTimeout(_0x30f373),_0xc0ef74=setTimeout(()=>{_0x21074c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xc0ef74),_0x1fdb1e(_0x2e2b73['data']['response']);break;default:clearTimeout(_0x30f373),clearTimeout(_0xc0ef74),_0x21074c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x55448e),_0x50fd5['port1']['addEventListener']('message',_0x55448e['onMessage']),this['target']['postMessage']({'eventType':_0x27eca8,'eventId':_0x3dc679,'data':_0x5c762b},[_0x50fd5['port2']]);})['finally'](()=>{_0x55448e&&this['removeMessageHandler'](_0x55448e);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x43a457){Z()['location']['href']=_0x43a457;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0xc883bb;return((_0xc883bb=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xc883bb['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1084e9){this['request']=_0x1084e9;}['toPromise'](){return new Promise((_0x792109,_0x323275)=>{this['request']['addEventListener']('success',()=>{_0x792109(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x323275(this['request']['error']);});});}}function Zn(_0x4e8a21,_0x335bc3){return _0x4e8a21['transaction']([Mn],_0x335bc3?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x2bef94=indexedDB['deleteDatabase'](Ka);return new nn(_0x2bef94)['toPromise']();}function Qa(){const _0x457780=indexedDB['open'](Ka,pp);return new Promise((_0x20310d,_0x551674)=>{_0x457780['addEventListener']('error',()=>{_0x551674(_0x457780['error']);}),_0x457780['addEventListener']('upgradeneeded',()=>{const _0x40e973=_0x457780['result'];try{_0x40e973['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x8618f9){_0x551674(_0x8618f9);}}),_0x457780['addEventListener']('success',async()=>{const _0x41b724=_0x457780['result'];_0x41b724['objectStoreNames']['contains'](Mn)?_0x20310d(_0x41b724):(_0x41b724['close'](),await _p(),_0x20310d(await Qa()));});});}async function Or(_0x301b52,_0x51c8c7,_0x485f14){const _0x3f197a=Zn(_0x301b52,!0x0)['put']({[Ya]:_0x51c8c7,'value':_0x485f14});return new nn(_0x3f197a)['toPromise']();}async function gp(_0x189369,_0x2ea6b2){const _0x2891be=Zn(_0x189369,!0x1)['get'](_0x2ea6b2),_0x1d422d=await new nn(_0x2891be)['toPromise']();return _0x1d422d===void 0x0?null:_0x1d422d['value'];}function Dr(_0x5092a7,_0x3dbb18){const _0x3ff79c=Zn(_0x5092a7,!0x0)['delete'](_0x3dbb18);return new nn(_0x3ff79c)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x54d4e7){let _0x33920a=0x0;for(;;)try{const _0x54a0c6=await this['_openDb']();return await _0x54d4e7(_0x54a0c6);}catch(_0x396bb2){if(_0x33920a++>yp)throw _0x396bb2;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x3e343b,_0x10c201)=>({'keyProcessed':(await this['_poll']())['includes'](_0x10c201['key'])})),this['receiver']['_subscribe']('ping',async(_0x14f355,_0x39e31c)=>['keyChanged']);}async['initializeSender'](){var _0x4b0bd2,_0x4053b5;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x8b19c=await this['sender']['_send']('ping',{},0x320);_0x8b19c&&(_0x4b0bd2=_0x8b19c[0x0])!=null&&_0x4b0bd2['fulfilled']&&(_0x4053b5=_0x8b19c[0x0])!=null&&_0x4053b5['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x15391d){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x15391d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x57a33b=>{await Or(_0x57a33b,Dn,'1'),await Dr(_0x57a33b,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4b627d){this['pendingWrites']++;try{await _0x4b627d();}finally{this['pendingWrites']--;}}async['_set'](_0x2e8d98,_0x473fb7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x17ddfd=>Or(_0x17ddfd,_0x2e8d98,_0x473fb7)),this['localCache'][_0x2e8d98]=_0x473fb7,this['notifyServiceWorker'](_0x2e8d98)));}async['_get'](_0x20fac3){const _0x146074=await this['_withRetries'](_0x20b273=>gp(_0x20b273,_0x20fac3));return this['localCache'][_0x20fac3]=_0x146074,_0x146074;}async['_remove'](_0x5826bc){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x42329e=>Dr(_0x42329e,_0x5826bc)),delete this['localCache'][_0x5826bc],this['notifyServiceWorker'](_0x5826bc)));}async['_poll'](){const _0x4ec22b=await this['_withRetries'](_0x259300=>{const _0x42c010=Zn(_0x259300,!0x1)['getAll']();return new nn(_0x42c010)['toPromise']();});if(!_0x4ec22b)return[];if(this['pendingWrites']!==0x0)return[];const _0x3ecc95=[],_0x17e3de=new Set();if(_0x4ec22b['length']!==0x0){for(const {fbase_key:_0x143c8f,value:_0x3f2d62}of _0x4ec22b)_0x17e3de['add'](_0x143c8f),JSON['stringify'](this['localCache'][_0x143c8f])!==JSON['stringify'](_0x3f2d62)&&(this['notifyListeners'](_0x143c8f,_0x3f2d62),_0x3ecc95['push'](_0x143c8f));}for(const _0xd5c07f of Object['keys'](this['localCache']))this['localCache'][_0xd5c07f]&&!_0x17e3de['has'](_0xd5c07f)&&(this['notifyListeners'](_0xd5c07f,null),_0x3ecc95['push'](_0xd5c07f));return _0x3ecc95;}['notifyListeners'](_0x312ec2,_0x245ee4){this['localCache'][_0x312ec2]=_0x245ee4;const _0x227481=this['listeners'][_0x312ec2];if(_0x227481){for(const _0x49e3d0 of Array['from'](_0x227481))_0x49e3d0(_0x245ee4);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x305398,_0x25e454){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x305398]||(this['listeners'][_0x305398]=new Set(),this['_get'](_0x305398)),this['listeners'][_0x305398]['add'](_0x25e454);}['_removeListener'](_0x45fd91,_0x20c5cc){this['listeners'][_0x45fd91]&&(this['listeners'][_0x45fd91]['delete'](_0x20c5cc),this['listeners'][_0x45fd91]['size']===0x0&&delete this['listeners'][_0x45fd91]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1d28e7,_0x40df57){return _0x40df57?ie(_0x40df57):(m(_0x1d28e7['_popupRedirectResolver'],_0x1d28e7,'argument-error'),_0x1d28e7['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x230c43){super('custom','custom'),this['params']=_0x230c43;}['_getIdTokenResponse'](_0x402ba1){return nt(_0x402ba1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x451368,_0x10fe62){return nt(_0x451368,this['_buildIdpRequest'](_0x10fe62));}['_getReauthenticationResolver'](_0x63d342){return nt(_0x63d342,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1ced1a){const _0x28b471={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1ced1a&&(_0x28b471['idToken']=_0x1ced1a),_0x28b471;}}function Ip(_0x72022f){return Va(_0x72022f['auth'],new ks(_0x72022f),_0x72022f['bypassAuthState']);}function wp(_0x8f3d9a){const {auth:_0x58288c,user:_0x21ab4c}=_0x8f3d9a;return m(_0x21ab4c,_0x58288c,'internal-error'),tp(_0x21ab4c,new ks(_0x8f3d9a),_0x8f3d9a['bypassAuthState']);}async function Cp(_0x1bcda9){const {auth:_0x26540c,user:_0x1eacda}=_0x1bcda9;return m(_0x1eacda,_0x26540c,'internal-error'),ep(_0x1eacda,new ks(_0x1bcda9),_0x1bcda9['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x5c214d,_0x3c8b3c,_0x8587f5,_0x28fa25,_0x5670cc=!0x1){this['auth']=_0x5c214d,this['resolver']=_0x8587f5,this['user']=_0x28fa25,this['bypassAuthState']=_0x5670cc,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3c8b3c)?_0x3c8b3c:[_0x3c8b3c];}['execute'](){return new Promise(async(_0x43bfcc,_0x4c29fe)=>{this['pendingPromise']={'resolve':_0x43bfcc,'reject':_0x4c29fe};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x39e059){this['reject'](_0x39e059);}});}async['onAuthEvent'](_0x49dda5){const {urlResponse:_0x245630,sessionId:_0x3cd1df,postBody:_0x39229a,tenantId:_0x549c64,error:_0x1291fc,type:_0x4232ef}=_0x49dda5;if(_0x1291fc){this['reject'](_0x1291fc);return;}const _0x9ac833={'auth':this['auth'],'requestUri':_0x245630,'sessionId':_0x3cd1df,'tenantId':_0x549c64||void 0x0,'postBody':_0x39229a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4232ef)(_0x9ac833));}catch(_0x16af41){this['reject'](_0x16af41);}}['onError'](_0x59dd0d){this['reject'](_0x59dd0d);}['getIdpTask'](_0x418bb0){switch(_0x418bb0){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x21e095){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x21e095),this['unregisterAndCleanUp']();}['reject'](_0x57a53c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x57a53c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x483bc6,_0xcb0b6c,_0x460784,_0xa96af0,_0xeaced8){super(_0x483bc6,_0xcb0b6c,_0xa96af0,_0xeaced8),this['provider']=_0x460784,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3b2c05=await this['execute']();return m(_0x3b2c05,this['auth'],'internal-error'),_0x3b2c05;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2a40eb=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2a40eb),this['authWindow']['associatedEvent']=_0x2a40eb,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3979a5=>{this['reject'](_0x3979a5);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x33ca4f=>{_0x33ca4f||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x314b74;return((_0x314b74=this['authWindow'])==null?void 0x0:_0x314b74['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x209022=()=>{var _0x33876e,_0x1cdaaa;if((_0x1cdaaa=(_0x33876e=this['authWindow'])==null?void 0x0:_0x33876e['window'])!=null&&_0x1cdaaa['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x209022,Tp['get']());};_0x209022();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x3c741a,_0x60e9f3,_0x2f8bb0=!0x1){super(_0x3c741a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x60e9f3,void 0x0,_0x2f8bb0),this['eventId']=null;}async['execute'](){let _0xfb218b=hn['get'](this['auth']['_key']());if(!_0xfb218b){try{const _0x439dd4=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0xfb218b=()=>Promise['resolve'](_0x439dd4);}catch(_0x4402a2){_0xfb218b=()=>Promise['reject'](_0x4402a2);}hn['set'](this['auth']['_key'](),_0xfb218b);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xfb218b();}async['onAuthEvent'](_0x53ceaf){if(_0x53ceaf['type']==='signInViaRedirect')return super['onAuthEvent'](_0x53ceaf);if(_0x53ceaf['type']==='unknown'){this['resolve'](null);return;}if(_0x53ceaf['eventId']){const _0x497e7e=await this['auth']['_redirectUserForId'](_0x53ceaf['eventId']);if(_0x497e7e)return this['user']=_0x497e7e,super['onAuthEvent'](_0x53ceaf);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x345e53,_0x45eb23){const _0x5d956f=Pp(_0x45eb23),_0x2e90c9=kp(_0x345e53);if(!await _0x2e90c9['_isAvailable']())return!0x1;const _0x447bf9=await _0x2e90c9['_get'](_0x5d956f)==='true';return await _0x2e90c9['_remove'](_0x5d956f),_0x447bf9;}function Ap(_0x2f57b6,_0x448cda){hn['set'](_0x2f57b6['_key'](),_0x448cda);}function kp(_0x183b06){return ie(_0x183b06['_redirectPersistence']);}function Pp(_0x161b9a){return ln(Sp,_0x161b9a['config']['apiKey'],_0x161b9a['name']);}async function Np(_0x1b8a9b,_0xee10c4,_0x4f2dbe=!0x1){if($(_0x1b8a9b['app']))return Promise['reject'](re(_0x1b8a9b));const _0x236672=Ke(_0x1b8a9b),_0x3f1023=Ep(_0x236672,_0xee10c4),_0x1e6b21=await new bp(_0x236672,_0x3f1023,_0x4f2dbe)['execute']();return _0x1e6b21&&!_0x4f2dbe&&(delete _0x1e6b21['user']['_redirectEventId'],await _0x236672['_persistUserIfCurrent'](_0x1e6b21['user']),await _0x236672['_setRedirectUser'](null,_0xee10c4)),_0x1e6b21;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0xcbb12){this['auth']=_0xcbb12,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3de169){this['consumers']['add'](_0x3de169),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3de169)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3de169),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x13067e){this['consumers']['delete'](_0x13067e);}['onEvent'](_0x52bcf6){if(this['hasEventBeenHandled'](_0x52bcf6))return!0x1;let _0x45f4ce=!0x1;return this['consumers']['forEach'](_0x5268de=>{this['isEventForConsumer'](_0x52bcf6,_0x5268de)&&(_0x45f4ce=!0x0,this['sendToConsumer'](_0x52bcf6,_0x5268de),this['saveEventToCache'](_0x52bcf6));}),this['hasHandledPotentialRedirect']||!Mp(_0x52bcf6)||(this['hasHandledPotentialRedirect']=!0x0,_0x45f4ce||(this['queuedRedirectEvent']=_0x52bcf6,_0x45f4ce=!0x0)),_0x45f4ce;}['sendToConsumer'](_0x549fa5,_0x180f89){var _0x1a65be;if(_0x549fa5['error']&&!Za(_0x549fa5)){const _0xf32a6b=((_0x1a65be=_0x549fa5['error']['code'])==null?void 0x0:_0x1a65be['split']('auth/')[0x1])||'internal-error';_0x180f89['onError'](X(this['auth'],_0xf32a6b));}else _0x180f89['onAuthEvent'](_0x549fa5);}['isEventForConsumer'](_0x3f2df2,_0x1d6d51){const _0x42185b=_0x1d6d51['eventId']===null||!!_0x3f2df2['eventId']&&_0x3f2df2['eventId']===_0x1d6d51['eventId'];return _0x1d6d51['filter']['includes'](_0x3f2df2['type'])&&_0x42185b;}['hasEventBeenHandled'](_0x2d5f9c){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2d5f9c));}['saveEventToCache'](_0x5740eb){this['cachedEventUids']['add'](Mr(_0x5740eb)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x213a69){return[_0x213a69['type'],_0x213a69['eventId'],_0x213a69['sessionId'],_0x213a69['tenantId']]['filter'](_0x241637=>_0x241637)['join']('-');}function Za({type:_0x50bd84,error:_0x571d40}){return _0x50bd84==='unknown'&&(_0x571d40==null?void 0x0:_0x571d40['code'])==='auth/no-auth-event';}function Mp(_0x208b94){switch(_0x208b94['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x208b94);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1ba8e1,_0x57b062={}){return Pe(_0x1ba8e1,'GET','/v1/projects',_0x57b062);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x512b65){if(_0x512b65['config']['emulator'])return;const {authorizedDomains:_0x7280c6}=await Lp(_0x512b65);for(const _0x43695d of _0x7280c6)try{if(Wp(_0x43695d))return;}catch{}Y(_0x512b65,'unauthorized-domain');}function Wp(_0x2565c7){const _0x20a174=Mi(),{protocol:_0x24d6e3,hostname:_0x5b20e4}=new URL(_0x20a174);if(_0x2565c7['startsWith']('chrome-extension://')){const _0x203720=new URL(_0x2565c7);return _0x203720['hostname']===''&&_0x5b20e4===''?_0x24d6e3==='chrome-extension:'&&_0x2565c7['replace']('chrome-extension://','')===_0x20a174['replace']('chrome-extension://',''):_0x24d6e3==='chrome-extension:'&&_0x203720['hostname']===_0x5b20e4;}if(!Fp['test'](_0x24d6e3))return!0x1;if(xp['test'](_0x2565c7))return _0x5b20e4===_0x2565c7;const _0x10c0ac=_0x2565c7['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x10c0ac+'|'+_0x10c0ac+')$','i')['test'](_0x5b20e4);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x226ae0=Z()['___jsl'];if(_0x226ae0!=null&&_0x226ae0['H']){for(const _0x2c3c1b of Object['keys'](_0x226ae0['H']))if(_0x226ae0['H'][_0x2c3c1b]['r']=_0x226ae0['H'][_0x2c3c1b]['r']||[],_0x226ae0['H'][_0x2c3c1b]['L']=_0x226ae0['H'][_0x2c3c1b]['L']||[],_0x226ae0['H'][_0x2c3c1b]['r']=[..._0x226ae0['H'][_0x2c3c1b]['L']],_0x226ae0['CP']){for(let _0x39292f=0x0;_0x39292f<_0x226ae0['CP']['length'];_0x39292f++)_0x226ae0['CP'][_0x39292f]=null;}}}function Vp(_0x51b5cd){return new Promise((_0xaa823f,_0x2c35c9)=>{var _0x3c1e6a,_0x1d2789,_0x3d1452;function _0x401c16(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xaa823f(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x2c35c9(X(_0x51b5cd,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x1d2789=(_0x3c1e6a=Z()['gapi'])==null?void 0x0:_0x3c1e6a['iframes'])!=null&&_0x1d2789['Iframe'])_0xaa823f(gapi['iframes']['getContext']());else{if((_0x3d1452=Z()['gapi'])!=null&&_0x3d1452['load'])_0x401c16();else{const _0x13560e=Ff('iframefcb');return Z()[_0x13560e]=()=>{gapi['load']?_0x401c16():_0x2c35c9(X(_0x51b5cd,'network-request-failed'));},xa(xf()+'?onload='+_0x13560e)['catch'](_0x3fdbf2=>_0x2c35c9(_0x3fdbf2));}}})['catch'](_0x521625=>{throw un=null,_0x521625;});}let un=null;function Hp(_0x5dbaf0){return un=un||Vp(_0x5dbaf0),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x2148dd){const _0x54aefd=_0x2148dd['config'];m(_0x54aefd['authDomain'],_0x2148dd,'auth-domain-config-required');const _0x2000af=_0x54aefd['emulator']?Cs(_0x54aefd,qp):'https://'+_0x2148dd['config']['authDomain']+'/'+Gp,_0x3f2a65={'apiKey':_0x54aefd['apiKey'],'appName':_0x2148dd['name'],'v':dt},_0x1a713c=jp['get'](_0x2148dd['config']['apiHost']);_0x1a713c&&(_0x3f2a65['eid']=_0x1a713c);const _0x5d4c91=_0x2148dd['_getFrameworks']();return _0x5d4c91['length']&&(_0x3f2a65['fw']=_0x5d4c91['join'](',')),_0x2000af+'?'+ut(_0x3f2a65)['slice'](0x1);}async function Yp(_0x390c1b){const _0x2f46fb=await Hp(_0x390c1b),_0x162107=Z()['gapi'];return m(_0x162107,_0x390c1b,'internal-error'),_0x2f46fb['open']({'where':document['body'],'url':Kp(_0x390c1b),'messageHandlersFilter':_0x162107['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x50ac83=>new Promise(async(_0x2e9d58,_0x2fc77c)=>{await _0x50ac83['restyle']({'setHideOnLeave':!0x1});const _0x15e44e=X(_0x390c1b,'network-request-failed'),_0x159467=Z()['setTimeout'](()=>{_0x2fc77c(_0x15e44e);},$p['get']());function _0x2f57dc(){Z()['clearTimeout'](_0x159467),_0x2e9d58(_0x50ac83);}_0x50ac83['ping'](_0x2f57dc)['then'](_0x2f57dc,()=>{_0x2fc77c(_0x15e44e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x40f6e3){this['window']=_0x40f6e3,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x2661e4,_0x57f1de,_0x39ff95,_0x1ac451=Jp,_0xb95a03=Xp){const _0x27303e=Math['max']((window['screen']['availHeight']-_0xb95a03)/0x2,0x0)['toString'](),_0x257071=Math['max']((window['screen']['availWidth']-_0x1ac451)/0x2,0x0)['toString']();let _0x11d2ea='';const _0x5861bc={...Qp,'width':_0x1ac451['toString'](),'height':_0xb95a03['toString'](),'top':_0x27303e,'left':_0x257071},_0x277c35=W()['toLowerCase']();_0x39ff95&&(_0x11d2ea=ka(_0x277c35)?Zp:_0x39ff95),Ra(_0x277c35)&&(_0x57f1de=_0x57f1de||e_,_0x5861bc['scrollbars']='yes');const _0x179445=Object['entries'](_0x5861bc)['reduce']((_0x380b82,[_0x45c906,_0x2dc68e])=>''+_0x380b82+_0x45c906+'='+_0x2dc68e+',','');if(Rf(_0x277c35)&&_0x11d2ea!=='_self')return n_(_0x57f1de||'',_0x11d2ea),new xr(null);const _0x16e37f=window['open'](_0x57f1de||'',_0x11d2ea,_0x179445);m(_0x16e37f,_0x2661e4,'popup-blocked');try{_0x16e37f['focus']();}catch{}return new xr(_0x16e37f);}function n_(_0x2b7b28,_0x893cf9){const _0x3d9fa8=document['createElement']('a');_0x3d9fa8['href']=_0x2b7b28,_0x3d9fa8['target']=_0x893cf9;const _0x296d1d=document['createEvent']('MouseEvent');_0x296d1d['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3d9fa8['dispatchEvent'](_0x296d1d);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x5a8e0c,_0x29dab5,_0x5df660,_0x37ba32,_0x2a4088,_0x7e995){m(_0x5a8e0c['config']['authDomain'],_0x5a8e0c,'auth-domain-config-required'),m(_0x5a8e0c['config']['apiKey'],_0x5a8e0c,'invalid-api-key');const _0x4756cc={'apiKey':_0x5a8e0c['config']['apiKey'],'appName':_0x5a8e0c['name'],'authType':_0x5df660,'redirectUrl':_0x37ba32,'v':dt,'eventId':_0x2a4088};if(_0x29dab5 instanceof Wa){_0x29dab5['setDefaultLanguage'](_0x5a8e0c['languageCode']),_0x4756cc['providerId']=_0x29dab5['providerId']||'',pn(_0x29dab5['getCustomParameters']())||(_0x4756cc['customParameters']=JSON['stringify'](_0x29dab5['getCustomParameters']()));for(const [_0x29ed6d,_0x2e6ce4]of Object['entries']({}))_0x4756cc[_0x29ed6d]=_0x2e6ce4;}if(_0x29dab5 instanceof tn){const _0x55ee7a=_0x29dab5['getScopes']()['filter'](_0x2d0f9=>_0x2d0f9!=='');_0x55ee7a['length']>0x0&&(_0x4756cc['scopes']=_0x55ee7a['join'](','));}_0x5a8e0c['tenantId']&&(_0x4756cc['tid']=_0x5a8e0c['tenantId']);const _0x3398c4=_0x4756cc;for(const _0x914b82 of Object['keys'](_0x3398c4))_0x3398c4[_0x914b82]===void 0x0&&delete _0x3398c4[_0x914b82];const _0x16b7fb=await _0x5a8e0c['_getAppCheckToken'](),_0x9c7648=_0x16b7fb?'#'+r_+'='+encodeURIComponent(_0x16b7fb):'';return o_(_0x5a8e0c)+'?'+ut(_0x3398c4)['slice'](0x1)+_0x9c7648;}function o_({config:_0x2fb3e4}){return _0x2fb3e4['emulator']?Cs(_0x2fb3e4,s_):'https://'+_0x2fb3e4['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x4a023a,_0x448392,_0x15583a,_0x21127b){var _0x2a3cd3;ce((_0x2a3cd3=this['eventManagers'][_0x4a023a['_key']()])==null?void 0x0:_0x2a3cd3['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1f3a54=await Fr(_0x4a023a,_0x448392,_0x15583a,Mi(),_0x21127b);return t_(_0x4a023a,_0x1f3a54,As());}async['_openRedirect'](_0x2b418d,_0xf2d0fd,_0x5a2309,_0x38118b){await this['_originValidation'](_0x2b418d);const _0x4256c9=await Fr(_0x2b418d,_0xf2d0fd,_0x5a2309,Mi(),_0x38118b);return hp(_0x4256c9),new Promise(()=>{});}['_initialize'](_0x11dcef){const _0x41f32e=_0x11dcef['_key']();if(this['eventManagers'][_0x41f32e]){const {manager:_0xb7b573,promise:_0x2e01d4}=this['eventManagers'][_0x41f32e];return _0xb7b573?Promise['resolve'](_0xb7b573):(ce(_0x2e01d4,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2e01d4);}const _0x572973=this['initAndGetManager'](_0x11dcef);return this['eventManagers'][_0x41f32e]={'promise':_0x572973},_0x572973['catch'](()=>{delete this['eventManagers'][_0x41f32e];}),_0x572973;}async['initAndGetManager'](_0x317ff0){const _0xbbd1d9=await Yp(_0x317ff0),_0x2f3898=new Dp(_0x317ff0);return _0xbbd1d9['register']('authEvent',_0x59369d=>(m(_0x59369d==null?void 0x0:_0x59369d['authEvent'],_0x317ff0,'invalid-auth-event'),{'status':_0x2f3898['onEvent'](_0x59369d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x317ff0['_key']()]={'manager':_0x2f3898},this['iframes'][_0x317ff0['_key']()]=_0xbbd1d9,_0x2f3898;}['_isIframeWebStorageSupported'](_0x5590df,_0xdebc8){this['iframes'][_0x5590df['_key']()]['send'](pi,{'type':pi},_0x384fbc=>{var _0x5945e3;const _0x1fe2c9=(_0x5945e3=_0x384fbc==null?void 0x0:_0x384fbc[0x0])==null?void 0x0:_0x5945e3[pi];_0x1fe2c9!==void 0x0&&_0xdebc8(!!_0x1fe2c9),Y(_0x5590df,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xe894b5){const _0x3ddd35=_0xe894b5['_key']();return this['originValidationPromises'][_0x3ddd35]||(this['originValidationPromises'][_0x3ddd35]=Up(_0xe894b5)),this['originValidationPromises'][_0x3ddd35];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x318089){this['auth']=_0x318089,this['internalListeners']=new Map();}['getUid'](){var _0x491165;return this['assertAuthConfigured'](),((_0x491165=this['auth']['currentUser'])==null?void 0x0:_0x491165['uid'])||null;}async['getToken'](_0x494ab6){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x494ab6)}:null;}['addAuthTokenListener'](_0x266692){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x266692))return;const _0x4467b1=this['auth']['onIdTokenChanged'](_0x255b7c=>{_0x266692((_0x255b7c==null?void 0x0:_0x255b7c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x266692,_0x4467b1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xa8e61a){this['assertAuthConfigured']();const _0x392507=this['internalListeners']['get'](_0xa8e61a);_0x392507&&(this['internalListeners']['delete'](_0xa8e61a),_0x392507(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5b7c7b){switch(_0x5b7c7b){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5dab77){st(new Fe('auth',(_0x2640f1,{options:_0x4d48a6})=>{const _0x578da3=_0x2640f1['getProvider']('app')['getImmediate'](),_0x1f7b62=_0x2640f1['getProvider']('heartbeat'),_0x188460=_0x2640f1['getProvider']('app-check-internal'),{apiKey:_0x50a58c,authDomain:_0x11c3c5}=_0x578da3['options'];m(_0x50a58c&&!_0x50a58c['includes'](':'),'invalid-api-key',{'appName':_0x578da3['name']});const _0x2a39cf={'apiKey':_0x50a58c,'authDomain':_0x11c3c5,'clientPlatform':_0x5dab77,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5dab77)},_0x4b23a7=new Df(_0x578da3,_0x1f7b62,_0x188460,_0x2a39cf);return Hf(_0x4b23a7,_0x4d48a6),_0x4b23a7;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x44d801,_0x45ce64,_0x1cf121)=>{_0x44d801['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x4e65b2=>{const _0x9bc4e=Ke(_0x4e65b2['getProvider']('auth')['getImmediate']());return(_0x3bc986=>new l_(_0x3bc986))(_0x9bc4e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5dab77)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0xb1768a=>async _0x545cf9=>{const _0x3aecf2=_0x545cf9&&await _0x545cf9['getIdTokenResult'](),_0x2add95=_0x3aecf2&&(new Date()['getTime']()-Date['parse'](_0x3aecf2['issuedAtTime']))/0x3e8;if(_0x2add95&&_0x2add95>f_)return;const _0x187c75=_0x3aecf2==null?void 0x0:_0x3aecf2['token'];Br!==_0x187c75&&(Br=_0x187c75,await fetch(_0xb1768a,{'method':_0x187c75?'POST':'DELETE','headers':_0x187c75?{'Authorization':'Bearer\x20'+_0x187c75}:{}}));};function B_(_0x5c7789=Zr()){const _0x534f04=Hi(_0x5c7789,'auth');if(_0x534f04['isInitialized']())return _0x534f04['getImmediate']();const _0x526e09=Vf(_0x5c7789,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x29e1b3=jr('authTokenSyncURL');if(_0x29e1b3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x136a6f=new URL(_0x29e1b3,location['origin']);if(location['origin']===_0x136a6f['origin']){const _0x5813ac=p_(_0x136a6f['toString']());sp(_0x526e09,_0x5813ac,()=>_0x5813ac(_0x526e09['currentUser'])),ip(_0x526e09,_0x338ed9=>_0x5813ac(_0x338ed9));}}const _0x2141aa=qr('auth');return _0x2141aa&&$f(_0x526e09,'http://'+_0x2141aa),_0x526e09;}function __(){var _0x3b927a;return((_0x3b927a=document['getElementsByTagName']('head'))==null?void 0x0:_0x3b927a[0x0])??document;}Mf({'loadJS'(_0xa6bdb5){return new Promise((_0x11e0b9,_0x47eaef)=>{const _0x1b10d8=document['createElement']('script');_0x1b10d8['setAttribute']('src',_0xa6bdb5),_0x1b10d8['onload']=_0x11e0b9,_0x1b10d8['onerror']=_0x3e2492=>{const _0xd64dab=X('internal-error');_0xd64dab['customData']=_0x3e2492,_0x47eaef(_0xd64dab);},_0x1b10d8['type']='text/javascript',_0x1b10d8['charset']='UTF-8',__()['appendChild'](_0x1b10d8);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};