const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x37d47b,_0x48a053){if(!_0x37d47b)throw ht(_0x48a053);},ht=function(_0x30cf42){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x30cf42);},Hr=function(_0x39ba54){const _0x4ee0fd=[];let _0x3d257b=0x0;for(let _0x286e9f=0x0;_0x286e9f<_0x39ba54['length'];_0x286e9f++){let _0x4f5ef5=_0x39ba54['charCodeAt'](_0x286e9f);_0x4f5ef5<0x80?_0x4ee0fd[_0x3d257b++]=_0x4f5ef5:_0x4f5ef5<0x800?(_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0x6|0xc0,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5&0x3f|0x80):(_0x4f5ef5&0xfc00)===0xd800&&_0x286e9f+0x1<_0x39ba54['length']&&(_0x39ba54['charCodeAt'](_0x286e9f+0x1)&0xfc00)===0xdc00?(_0x4f5ef5=0x10000+((_0x4f5ef5&0x3ff)<<0xa)+(_0x39ba54['charCodeAt'](++_0x286e9f)&0x3ff),_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0x12|0xf0,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0xc&0x3f|0x80,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0x6&0x3f|0x80,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5&0x3f|0x80):(_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0xc|0xe0,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5>>0x6&0x3f|0x80,_0x4ee0fd[_0x3d257b++]=_0x4f5ef5&0x3f|0x80);}return _0x4ee0fd;},nc=function(_0x5d64d0){const _0x3dec8e=[];let _0x244351=0x0,_0x5957cb=0x0;for(;_0x244351<_0x5d64d0['length'];){const _0x4de044=_0x5d64d0[_0x244351++];if(_0x4de044<0x80)_0x3dec8e[_0x5957cb++]=String['fromCharCode'](_0x4de044);else{if(_0x4de044>0xbf&&_0x4de044<0xe0){const _0x57bf63=_0x5d64d0[_0x244351++];_0x3dec8e[_0x5957cb++]=String['fromCharCode']((_0x4de044&0x1f)<<0x6|_0x57bf63&0x3f);}else{if(_0x4de044>0xef&&_0x4de044<0x16d){const _0x2c9bb7=_0x5d64d0[_0x244351++],_0x30352f=_0x5d64d0[_0x244351++],_0x3c012d=_0x5d64d0[_0x244351++],_0x5e3721=((_0x4de044&0x7)<<0x12|(_0x2c9bb7&0x3f)<<0xc|(_0x30352f&0x3f)<<0x6|_0x3c012d&0x3f)-0x10000;_0x3dec8e[_0x5957cb++]=String['fromCharCode'](0xd800+(_0x5e3721>>0xa)),_0x3dec8e[_0x5957cb++]=String['fromCharCode'](0xdc00+(_0x5e3721&0x3ff));}else{const _0x52f02c=_0x5d64d0[_0x244351++],_0x5a9f45=_0x5d64d0[_0x244351++];_0x3dec8e[_0x5957cb++]=String['fromCharCode']((_0x4de044&0xf)<<0xc|(_0x52f02c&0x3f)<<0x6|_0x5a9f45&0x3f);}}}}return _0x3dec8e['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4af325,_0x88ec4d){if(!Array['isArray'](_0x4af325))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x275f4a=_0x88ec4d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x265891=[];for(let _0x4d8236=0x0;_0x4d8236<_0x4af325['length'];_0x4d8236+=0x3){const _0x2acd5b=_0x4af325[_0x4d8236],_0x11ef1c=_0x4d8236+0x1<_0x4af325['length'],_0x5bdae2=_0x11ef1c?_0x4af325[_0x4d8236+0x1]:0x0,_0x5060bc=_0x4d8236+0x2<_0x4af325['length'],_0x3e3d08=_0x5060bc?_0x4af325[_0x4d8236+0x2]:0x0,_0x12078d=_0x2acd5b>>0x2,_0x3efc43=(_0x2acd5b&0x3)<<0x4|_0x5bdae2>>0x4;let _0x4bd569=(_0x5bdae2&0xf)<<0x2|_0x3e3d08>>0x6,_0x4ada88=_0x3e3d08&0x3f;_0x5060bc||(_0x4ada88=0x40,_0x11ef1c||(_0x4bd569=0x40)),_0x265891['push'](_0x275f4a[_0x12078d],_0x275f4a[_0x3efc43],_0x275f4a[_0x4bd569],_0x275f4a[_0x4ada88]);}return _0x265891['join']('');},'encodeString'(_0x3abff8,_0x5569e8){return this['HAS_NATIVE_SUPPORT']&&!_0x5569e8?btoa(_0x3abff8):this['encodeByteArray'](Hr(_0x3abff8),_0x5569e8);},'decodeString'(_0x49a694,_0x36a25f){return this['HAS_NATIVE_SUPPORT']&&!_0x36a25f?atob(_0x49a694):nc(this['decodeStringToByteArray'](_0x49a694,_0x36a25f));},'decodeStringToByteArray'(_0xc70bf3,_0x517e08){this['init_']();const _0x3cb653=_0x517e08?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x27ca13=[];for(let _0xbc0728=0x0;_0xbc0728<_0xc70bf3['length'];){const _0x3f4454=_0x3cb653[_0xc70bf3['charAt'](_0xbc0728++)],_0x137f1e=_0xbc0728<_0xc70bf3['length']?_0x3cb653[_0xc70bf3['charAt'](_0xbc0728)]:0x0;++_0xbc0728;const _0x463c2c=_0xbc0728<_0xc70bf3['length']?_0x3cb653[_0xc70bf3['charAt'](_0xbc0728)]:0x40;++_0xbc0728;const _0x14bd8b=_0xbc0728<_0xc70bf3['length']?_0x3cb653[_0xc70bf3['charAt'](_0xbc0728)]:0x40;if(++_0xbc0728,_0x3f4454==null||_0x137f1e==null||_0x463c2c==null||_0x14bd8b==null)throw new ic();const _0x1ec70f=_0x3f4454<<0x2|_0x137f1e>>0x4;if(_0x27ca13['push'](_0x1ec70f),_0x463c2c!==0x40){const _0xd60398=_0x137f1e<<0x4&0xf0|_0x463c2c>>0x2;if(_0x27ca13['push'](_0xd60398),_0x14bd8b!==0x40){const _0x481ccf=_0x463c2c<<0x6&0xc0|_0x14bd8b;_0x27ca13['push'](_0x481ccf);}}}return _0x27ca13;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x152319=0x0;_0x152319<this['ENCODED_VALS']['length'];_0x152319++)this['byteToCharMap_'][_0x152319]=this['ENCODED_VALS']['charAt'](_0x152319),this['charToByteMap_'][this['byteToCharMap_'][_0x152319]]=_0x152319,this['byteToCharMapWebSafe_'][_0x152319]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x152319),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x152319]]=_0x152319,_0x152319>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x152319)]=_0x152319,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x152319)]=_0x152319);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3c5c51){const _0x4ce6cb=Hr(_0x3c5c51);return Fi['encodeByteArray'](_0x4ce6cb,!0x0);},dn=function(_0x322fae){return $r(_0x322fae)['replace'](/\./g,'');},fn=function(_0x357570){try{return Fi['decodeString'](_0x357570,!0x0);}catch(_0x89b58d){console['error']('base64Decode\x20failed:\x20',_0x89b58d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x199b85){return Gr(void 0x0,_0x199b85);}function Gr(_0x358bd2,_0x533563){if(!(_0x533563 instanceof Object))return _0x533563;switch(_0x533563['constructor']){case Date:const _0xe942=_0x533563;return new Date(_0xe942['getTime']());case Object:_0x358bd2===void 0x0&&(_0x358bd2={});break;case Array:_0x358bd2=[];break;default:return _0x533563;}for(const _0x1cb333 in _0x533563)!_0x533563['hasOwnProperty'](_0x1cb333)||!rc(_0x1cb333)||(_0x358bd2[_0x1cb333]=Gr(_0x358bd2[_0x1cb333],_0x533563[_0x1cb333]));return _0x358bd2;}function rc(_0x145413){return _0x145413!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x53edd0=Ps['__FIREBASE_DEFAULTS__'];if(_0x53edd0)return JSON['parse'](_0x53edd0);},lc=()=>{if(typeof document>'u')return;let _0x2f39be;try{_0x2f39be=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xf2b5fc=_0x2f39be&&fn(_0x2f39be[0x1]);return _0xf2b5fc&&JSON['parse'](_0xf2b5fc);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xb8da17){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xb8da17);return;}},qr=_0x2c9849=>{var _0x40c399,_0x26a2cc;return(_0x26a2cc=(_0x40c399=Ui())==null?void 0x0:_0x40c399['emulatorHosts'])==null?void 0x0:_0x26a2cc[_0x2c9849];},hc=_0x111128=>{const _0x1d20f9=qr(_0x111128);if(!_0x1d20f9)return;const _0x595ac4=_0x1d20f9['lastIndexOf'](':');if(_0x595ac4<=0x0||_0x595ac4+0x1===_0x1d20f9['length'])throw new Error('Invalid\x20host\x20'+_0x1d20f9+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5ecafe=parseInt(_0x1d20f9['substring'](_0x595ac4+0x1),0xa);return _0x1d20f9[0x0]==='['?[_0x1d20f9['substring'](0x1,_0x595ac4-0x1),_0x5ecafe]:[_0x1d20f9['substring'](0x0,_0x595ac4),_0x5ecafe];},zr=()=>{var _0xdeaab8;return(_0xdeaab8=Ui())==null?void 0x0:_0xdeaab8['config'];},jr=_0x537a9f=>{var _0x2b3f75;return(_0x2b3f75=Ui())==null?void 0x0:_0x2b3f75['_'+_0x537a9f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x53c1fc,_0x5e8c1b)=>{this['resolve']=_0x53c1fc,this['reject']=_0x5e8c1b;});}['wrapCallback'](_0x361eab){return(_0xc6954d,_0x388600)=>{_0xc6954d?this['reject'](_0xc6954d):this['resolve'](_0x388600),typeof _0x361eab=='function'&&(this['promise']['catch'](()=>{}),_0x361eab['length']===0x1?_0x361eab(_0xc6954d):_0x361eab(_0xc6954d,_0x388600));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x46d3b5,_0x39345f){if(_0x46d3b5['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3a7125={'alg':'none','type':'JWT'},_0x4c6f88=_0x39345f||'demo-project',_0x53c516=_0x46d3b5['iat']||0x0,_0x4adacc=_0x46d3b5['sub']||_0x46d3b5['user_id'];if(!_0x4adacc)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x52a0b1={'iss':'https://securetoken.google.com/'+_0x4c6f88,'aud':_0x4c6f88,'iat':_0x53c516,'exp':_0x53c516+0xe10,'auth_time':_0x53c516,'sub':_0x4adacc,'user_id':_0x4adacc,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x46d3b5};return[dn(JSON['stringify'](_0x3a7125)),dn(JSON['stringify'](_0x52a0b1)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x523540=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x523540=='object'&&_0x523540['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x118ce4=W();return _0x118ce4['indexOf']('MSIE\x20')>=0x0||_0x118ce4['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x374560,_0x16a7a7)=>{try{let _0x153731=!0x0;const _0x1dc47a='validate-browser-context-for-indexeddb-analytics-module',_0x25c537=self['indexedDB']['open'](_0x1dc47a);_0x25c537['onsuccess']=()=>{_0x25c537['result']['close'](),_0x153731||self['indexedDB']['deleteDatabase'](_0x1dc47a),_0x374560(!0x0);},_0x25c537['onupgradeneeded']=()=>{_0x153731=!0x1;},_0x25c537['onerror']=()=>{var _0x1dacf0;_0x16a7a7(((_0x1dacf0=_0x25c537['error'])==null?void 0x0:_0x1dacf0['message'])||'');};}catch(_0x253f7f){_0x16a7a7(_0x253f7f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2273fa,_0x34513b,_0x143180){super(_0x34513b),this['code']=_0x2273fa,this['customData']=_0x143180,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x5b0e23,_0x313655,_0x5eefe8){this['service']=_0x5b0e23,this['serviceName']=_0x313655,this['errors']=_0x5eefe8;}['create'](_0x5693f1,..._0x45fbd4){const _0x45b98d=_0x45fbd4[0x0]||{},_0x43b475=this['service']+'/'+_0x5693f1,_0x2d3897=this['errors'][_0x5693f1],_0x40e2e6=_0x2d3897?vc(_0x2d3897,_0x45b98d):'Error',_0x8056ee=this['serviceName']+':\x20'+_0x40e2e6+'\x20('+_0x43b475+').';return new Re(_0x43b475,_0x8056ee,_0x45b98d);}}function vc(_0x3eb216,_0x2c8e4d){return _0x3eb216['replace'](Ec,(_0x443563,_0x162de0)=>{const _0xa6bb5e=_0x2c8e4d[_0x162de0];return _0xa6bb5e!=null?String(_0xa6bb5e):'<'+_0x162de0+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x10eed7){return JSON['parse'](_0x10eed7);}function O(_0x54d641){return JSON['stringify'](_0x54d641);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1a4ad3){let _0x5dd489={},_0x356859={},_0x263713={},_0x231117='';try{const _0x56f1a9=_0x1a4ad3['split']('.');_0x5dd489=Nt(fn(_0x56f1a9[0x0])||''),_0x356859=Nt(fn(_0x56f1a9[0x1])||''),_0x231117=_0x56f1a9[0x2],_0x263713=_0x356859['d']||{},delete _0x356859['d'];}catch{}return{'header':_0x5dd489,'claims':_0x356859,'data':_0x263713,'signature':_0x231117};},Ic=function(_0x2f849a){const _0x52f8a8=Yr(_0x2f849a),_0x55d959=_0x52f8a8['claims'];return!!_0x55d959&&typeof _0x55d959=='object'&&_0x55d959['hasOwnProperty']('iat');},wc=function(_0x21b9dd){const _0x380148=Yr(_0x21b9dd)['claims'];return typeof _0x380148=='object'&&_0x380148['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5d0664,_0x1e8ddb){return Object['prototype']['hasOwnProperty']['call'](_0x5d0664,_0x1e8ddb);}function Le(_0x226c2e,_0x323135){if(Object['prototype']['hasOwnProperty']['call'](_0x226c2e,_0x323135))return _0x226c2e[_0x323135];}function pn(_0x53f487){for(const _0x4eeff1 in _0x53f487)if(Object['prototype']['hasOwnProperty']['call'](_0x53f487,_0x4eeff1))return!0x1;return!0x0;}function _n(_0x2489a9,_0x33f145,_0x1e3eb1){const _0x1bddca={};for(const _0x16d709 in _0x2489a9)Object['prototype']['hasOwnProperty']['call'](_0x2489a9,_0x16d709)&&(_0x1bddca[_0x16d709]=_0x33f145['call'](_0x1e3eb1,_0x2489a9[_0x16d709],_0x16d709,_0x2489a9));return _0x1bddca;}function xe(_0xd33c56,_0x917a16){if(_0xd33c56===_0x917a16)return!0x0;const _0x92969=Object['keys'](_0xd33c56),_0xb654ff=Object['keys'](_0x917a16);for(const _0x488446 of _0x92969){if(!_0xb654ff['includes'](_0x488446))return!0x1;const _0x502075=_0xd33c56[_0x488446],_0x58fda3=_0x917a16[_0x488446];if(Ns(_0x502075)&&Ns(_0x58fda3)){if(!xe(_0x502075,_0x58fda3))return!0x1;}else{if(_0x502075!==_0x58fda3)return!0x1;}}for(const _0x2ecd67 of _0xb654ff)if(!_0x92969['includes'](_0x2ecd67))return!0x1;return!0x0;}function Ns(_0x227d78){return _0x227d78!==null&&typeof _0x227d78=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x225f1e){const _0x15ae6c=[];for(const [_0x4df046,_0x59f506]of Object['entries'](_0x225f1e))Array['isArray'](_0x59f506)?_0x59f506['forEach'](_0x4c578e=>{_0x15ae6c['push'](encodeURIComponent(_0x4df046)+'='+encodeURIComponent(_0x4c578e));}):_0x15ae6c['push'](encodeURIComponent(_0x4df046)+'='+encodeURIComponent(_0x59f506));return _0x15ae6c['length']?'&'+_0x15ae6c['join']('&'):'';}function Ct(_0x2f72c0){const _0x223d33={};return _0x2f72c0['replace'](/^\?/,'')['split']('&')['forEach'](_0xdf8b76=>{if(_0xdf8b76){const [_0x482047,_0x173350]=_0xdf8b76['split']('=');_0x223d33[decodeURIComponent(_0x482047)]=decodeURIComponent(_0x173350);}}),_0x223d33;}function Tt(_0x4ea309){const _0x46a0a5=_0x4ea309['indexOf']('?');if(!_0x46a0a5)return'';const _0x267327=_0x4ea309['indexOf']('#',_0x46a0a5);return _0x4ea309['substring'](_0x46a0a5,_0x267327>0x0?_0x267327:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2befc7=0x1;_0x2befc7<this['blockSize'];++_0x2befc7)this['pad_'][_0x2befc7]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x55244c,_0x28af19){_0x28af19||(_0x28af19=0x0);const _0x21b2b9=this['W_'];if(typeof _0x55244c=='string'){for(let _0x26af08=0x0;_0x26af08<0x10;_0x26af08++)_0x21b2b9[_0x26af08]=_0x55244c['charCodeAt'](_0x28af19)<<0x18|_0x55244c['charCodeAt'](_0x28af19+0x1)<<0x10|_0x55244c['charCodeAt'](_0x28af19+0x2)<<0x8|_0x55244c['charCodeAt'](_0x28af19+0x3),_0x28af19+=0x4;}else{for(let _0x2f64c6=0x0;_0x2f64c6<0x10;_0x2f64c6++)_0x21b2b9[_0x2f64c6]=_0x55244c[_0x28af19]<<0x18|_0x55244c[_0x28af19+0x1]<<0x10|_0x55244c[_0x28af19+0x2]<<0x8|_0x55244c[_0x28af19+0x3],_0x28af19+=0x4;}for(let _0x3f21e4=0x10;_0x3f21e4<0x50;_0x3f21e4++){const _0xdbf78a=_0x21b2b9[_0x3f21e4-0x3]^_0x21b2b9[_0x3f21e4-0x8]^_0x21b2b9[_0x3f21e4-0xe]^_0x21b2b9[_0x3f21e4-0x10];_0x21b2b9[_0x3f21e4]=(_0xdbf78a<<0x1|_0xdbf78a>>>0x1f)&0xffffffff;}let _0x3bbafd=this['chain_'][0x0],_0x1dba2f=this['chain_'][0x1],_0x24ba08=this['chain_'][0x2],_0x4f4abc=this['chain_'][0x3],_0x328652=this['chain_'][0x4],_0x3c3349,_0x120681;for(let _0x5b7c8f=0x0;_0x5b7c8f<0x50;_0x5b7c8f++){_0x5b7c8f<0x28?_0x5b7c8f<0x14?(_0x3c3349=_0x4f4abc^_0x1dba2f&(_0x24ba08^_0x4f4abc),_0x120681=0x5a827999):(_0x3c3349=_0x1dba2f^_0x24ba08^_0x4f4abc,_0x120681=0x6ed9eba1):_0x5b7c8f<0x3c?(_0x3c3349=_0x1dba2f&_0x24ba08|_0x4f4abc&(_0x1dba2f|_0x24ba08),_0x120681=0x8f1bbcdc):(_0x3c3349=_0x1dba2f^_0x24ba08^_0x4f4abc,_0x120681=0xca62c1d6);const _0x3cdb29=(_0x3bbafd<<0x5|_0x3bbafd>>>0x1b)+_0x3c3349+_0x328652+_0x120681+_0x21b2b9[_0x5b7c8f]&0xffffffff;_0x328652=_0x4f4abc,_0x4f4abc=_0x24ba08,_0x24ba08=(_0x1dba2f<<0x1e|_0x1dba2f>>>0x2)&0xffffffff,_0x1dba2f=_0x3bbafd,_0x3bbafd=_0x3cdb29;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3bbafd&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1dba2f&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x24ba08&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4f4abc&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x328652&0xffffffff;}['update'](_0x5ee1b8,_0x2bb5d5){if(_0x5ee1b8==null)return;_0x2bb5d5===void 0x0&&(_0x2bb5d5=_0x5ee1b8['length']);const _0x398c76=_0x2bb5d5-this['blockSize'];let _0x23b8b6=0x0;const _0x5bca5a=this['buf_'];let _0x54f021=this['inbuf_'];for(;_0x23b8b6<_0x2bb5d5;){if(_0x54f021===0x0){for(;_0x23b8b6<=_0x398c76;)this['compress_'](_0x5ee1b8,_0x23b8b6),_0x23b8b6+=this['blockSize'];}if(typeof _0x5ee1b8=='string'){for(;_0x23b8b6<_0x2bb5d5;)if(_0x5bca5a[_0x54f021]=_0x5ee1b8['charCodeAt'](_0x23b8b6),++_0x54f021,++_0x23b8b6,_0x54f021===this['blockSize']){this['compress_'](_0x5bca5a),_0x54f021=0x0;break;}}else{for(;_0x23b8b6<_0x2bb5d5;)if(_0x5bca5a[_0x54f021]=_0x5ee1b8[_0x23b8b6],++_0x54f021,++_0x23b8b6,_0x54f021===this['blockSize']){this['compress_'](_0x5bca5a),_0x54f021=0x0;break;}}}this['inbuf_']=_0x54f021,this['total_']+=_0x2bb5d5;}['digest'](){const _0x3cb24d=[];let _0x5441d4=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5795a3=this['blockSize']-0x1;_0x5795a3>=0x38;_0x5795a3--)this['buf_'][_0x5795a3]=_0x5441d4&0xff,_0x5441d4/=0x100;this['compress_'](this['buf_']);let _0x28297e=0x0;for(let _0x1b3e95=0x0;_0x1b3e95<0x5;_0x1b3e95++)for(let _0x53421b=0x18;_0x53421b>=0x0;_0x53421b-=0x8)_0x3cb24d[_0x28297e]=this['chain_'][_0x1b3e95]>>_0x53421b&0xff,++_0x28297e;return _0x3cb24d;}}function Tc(_0x4d6c0,_0x4292ae){const _0x5bde4e=new Sc(_0x4d6c0,_0x4292ae);return _0x5bde4e['subscribe']['bind'](_0x5bde4e);}class Sc{constructor(_0x30be74,_0x56063c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x56063c,this['task']['then'](()=>{_0x30be74(this);})['catch'](_0x404f04=>{this['error'](_0x404f04);});}['next'](_0x14ce97){this['forEachObserver'](_0x36d141=>{_0x36d141['next'](_0x14ce97);});}['error'](_0x580265){this['forEachObserver'](_0x3b8e95=>{_0x3b8e95['error'](_0x580265);}),this['close'](_0x580265);}['complete'](){this['forEachObserver'](_0x5becaa=>{_0x5becaa['complete']();}),this['close']();}['subscribe'](_0x481909,_0x4f2822,_0x29d3bb){let _0x50b1a3;if(_0x481909===void 0x0&&_0x4f2822===void 0x0&&_0x29d3bb===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x481909,['next','error','complete'])?_0x50b1a3=_0x481909:_0x50b1a3={'next':_0x481909,'error':_0x4f2822,'complete':_0x29d3bb},_0x50b1a3['next']===void 0x0&&(_0x50b1a3['next']=ti),_0x50b1a3['error']===void 0x0&&(_0x50b1a3['error']=ti),_0x50b1a3['complete']===void 0x0&&(_0x50b1a3['complete']=ti);const _0x1f9c5b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x50b1a3['error'](this['finalError']):_0x50b1a3['complete']();}catch{}}),this['observers']['push'](_0x50b1a3),_0x1f9c5b;}['unsubscribeOne'](_0x15d1e1){this['observers']===void 0x0||this['observers'][_0x15d1e1]===void 0x0||(delete this['observers'][_0x15d1e1],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4c4aa4){if(!this['finalized']){for(let _0x46e03d=0x0;_0x46e03d<this['observers']['length'];_0x46e03d++)this['sendOne'](_0x46e03d,_0x4c4aa4);}}['sendOne'](_0x35e122,_0x1905a9){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x35e122]!==void 0x0)try{_0x1905a9(this['observers'][_0x35e122]);}catch(_0x432c1d){typeof console<'u'&&console['error']&&console['error'](_0x432c1d);}});}['close'](_0x3eab71){this['finalized']||(this['finalized']=!0x0,_0x3eab71!==void 0x0&&(this['finalError']=_0x3eab71),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4b4fde,_0x3a31c1){if(typeof _0x4b4fde!='object'||_0x4b4fde===null)return!0x1;for(const _0x16c7d9 of _0x3a31c1)if(_0x16c7d9 in _0x4b4fde&&typeof _0x4b4fde[_0x16c7d9]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1f3895,_0x4fe24a){return _0x1f3895+'\x20failed:\x20'+_0x4fe24a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3d1dfd){const _0x38d3ee=[];let _0x393e1b=0x0;for(let _0x550d37=0x0;_0x550d37<_0x3d1dfd['length'];_0x550d37++){let _0x109671=_0x3d1dfd['charCodeAt'](_0x550d37);if(_0x109671>=0xd800&&_0x109671<=0xdbff){const _0x5b03d5=_0x109671-0xd800;_0x550d37++,f(_0x550d37<_0x3d1dfd['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x544a8f=_0x3d1dfd['charCodeAt'](_0x550d37)-0xdc00;_0x109671=0x10000+(_0x5b03d5<<0xa)+_0x544a8f;}_0x109671<0x80?_0x38d3ee[_0x393e1b++]=_0x109671:_0x109671<0x800?(_0x38d3ee[_0x393e1b++]=_0x109671>>0x6|0xc0,_0x38d3ee[_0x393e1b++]=_0x109671&0x3f|0x80):_0x109671<0x10000?(_0x38d3ee[_0x393e1b++]=_0x109671>>0xc|0xe0,_0x38d3ee[_0x393e1b++]=_0x109671>>0x6&0x3f|0x80,_0x38d3ee[_0x393e1b++]=_0x109671&0x3f|0x80):(_0x38d3ee[_0x393e1b++]=_0x109671>>0x12|0xf0,_0x38d3ee[_0x393e1b++]=_0x109671>>0xc&0x3f|0x80,_0x38d3ee[_0x393e1b++]=_0x109671>>0x6&0x3f|0x80,_0x38d3ee[_0x393e1b++]=_0x109671&0x3f|0x80);}return _0x38d3ee;},Ln=function(_0x449c7d){let _0x2fa5ad=0x0;for(let _0x5d0709=0x0;_0x5d0709<_0x449c7d['length'];_0x5d0709++){const _0xc7e646=_0x449c7d['charCodeAt'](_0x5d0709);_0xc7e646<0x80?_0x2fa5ad++:_0xc7e646<0x800?_0x2fa5ad+=0x2:_0xc7e646>=0xd800&&_0xc7e646<=0xdbff?(_0x2fa5ad+=0x4,_0x5d0709++):_0x2fa5ad+=0x3;}return _0x2fa5ad;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x5186e2){return _0x5186e2&&_0x5186e2['_delegate']?_0x5186e2['_delegate']:_0x5186e2;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x53c490){try{return(_0x53c490['startsWith']('http://')||_0x53c490['startsWith']('https://')?new URL(_0x53c490)['hostname']:_0x53c490)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3e52b8){return(await fetch(_0x3e52b8,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x2cedd8,_0x2480df,_0x3e13ca){this['name']=_0x2cedd8,this['instanceFactory']=_0x2480df,this['type']=_0x3e13ca,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5f1e8b){return this['instantiationMode']=_0x5f1e8b,this;}['setMultipleInstances'](_0x569660){return this['multipleInstances']=_0x569660,this;}['setServiceProps'](_0x5a0711){return this['serviceProps']=_0x5a0711,this;}['setInstanceCreatedCallback'](_0x1315ea){return this['onInstanceCreated']=_0x1315ea,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2d9853,_0x2a170b){this['name']=_0x2d9853,this['container']=_0x2a170b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1dd9e9){const _0x5db0a7=this['normalizeInstanceIdentifier'](_0x1dd9e9);if(!this['instancesDeferred']['has'](_0x5db0a7)){const _0x5792d9=new H();if(this['instancesDeferred']['set'](_0x5db0a7,_0x5792d9),this['isInitialized'](_0x5db0a7)||this['shouldAutoInitialize']())try{const _0x343df8=this['getOrInitializeService']({'instanceIdentifier':_0x5db0a7});_0x343df8&&_0x5792d9['resolve'](_0x343df8);}catch{}}return this['instancesDeferred']['get'](_0x5db0a7)['promise'];}['getImmediate'](_0x4ad24e){const _0x386f23=this['normalizeInstanceIdentifier'](_0x4ad24e==null?void 0x0:_0x4ad24e['identifier']),_0x3d5394=(_0x4ad24e==null?void 0x0:_0x4ad24e['optional'])??!0x1;if(this['isInitialized'](_0x386f23)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x386f23});}catch(_0x1b68f2){if(_0x3d5394)return null;throw _0x1b68f2;}else{if(_0x3d5394)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x40400d){if(_0x40400d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x40400d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x40400d,!!this['shouldAutoInitialize']()){if(Pc(_0x40400d))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x430953,_0x307b5f]of this['instancesDeferred']['entries']()){const _0x2cea45=this['normalizeInstanceIdentifier'](_0x430953);try{const _0x3840bd=this['getOrInitializeService']({'instanceIdentifier':_0x2cea45});_0x307b5f['resolve'](_0x3840bd);}catch{}}}}['clearInstance'](_0x570e44=Ne){this['instancesDeferred']['delete'](_0x570e44),this['instancesOptions']['delete'](_0x570e44),this['instances']['delete'](_0x570e44);}async['delete'](){const _0x4182f3=Array['from'](this['instances']['values']());await Promise['all']([..._0x4182f3['filter'](_0x2f89d3=>'INTERNAL'in _0x2f89d3)['map'](_0x28f8d7=>_0x28f8d7['INTERNAL']['delete']()),..._0x4182f3['filter'](_0x172027=>'_delete'in _0x172027)['map'](_0x16cbdb=>_0x16cbdb['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5b2968=Ne){return this['instances']['has'](_0x5b2968);}['getOptions'](_0xcf1a24=Ne){return this['instancesOptions']['get'](_0xcf1a24)||{};}['initialize'](_0x13315c={}){const {options:_0x1ee9f7={}}=_0x13315c,_0x55e61a=this['normalizeInstanceIdentifier'](_0x13315c['instanceIdentifier']);if(this['isInitialized'](_0x55e61a))throw Error(this['name']+'('+_0x55e61a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x367119=this['getOrInitializeService']({'instanceIdentifier':_0x55e61a,'options':_0x1ee9f7});for(const [_0x432bf1,_0x2589a0]of this['instancesDeferred']['entries']()){const _0x1666a3=this['normalizeInstanceIdentifier'](_0x432bf1);_0x55e61a===_0x1666a3&&_0x2589a0['resolve'](_0x367119);}return _0x367119;}['onInit'](_0x412520,_0x586716){const _0x357f96=this['normalizeInstanceIdentifier'](_0x586716),_0x5453df=this['onInitCallbacks']['get'](_0x357f96)??new Set();_0x5453df['add'](_0x412520),this['onInitCallbacks']['set'](_0x357f96,_0x5453df);const _0x147c1e=this['instances']['get'](_0x357f96);return _0x147c1e&&_0x412520(_0x147c1e,_0x357f96),()=>{_0x5453df['delete'](_0x412520);};}['invokeOnInitCallbacks'](_0x11ed92,_0x16034f){const _0xaa7d98=this['onInitCallbacks']['get'](_0x16034f);if(_0xaa7d98){for(const _0x7e747f of _0xaa7d98)try{_0x7e747f(_0x11ed92,_0x16034f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x16457f,options:_0x224f7f={}}){let _0x2f7966=this['instances']['get'](_0x16457f);if(!_0x2f7966&&this['component']&&(_0x2f7966=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x16457f),'options':_0x224f7f}),this['instances']['set'](_0x16457f,_0x2f7966),this['instancesOptions']['set'](_0x16457f,_0x224f7f),this['invokeOnInitCallbacks'](_0x2f7966,_0x16457f),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x16457f,_0x2f7966);}catch{}return _0x2f7966||null;}['normalizeInstanceIdentifier'](_0x4e476a=Ne){return this['component']?this['component']['multipleInstances']?_0x4e476a:Ne:_0x4e476a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4337b9){return _0x4337b9===Ne?void 0x0:_0x4337b9;}function Pc(_0x224ceb){return _0x224ceb['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x9445c3){this['name']=_0x9445c3,this['providers']=new Map();}['addComponent'](_0x2baa0c){const _0x551fd4=this['getProvider'](_0x2baa0c['name']);if(_0x551fd4['isComponentSet']())throw new Error('Component\x20'+_0x2baa0c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x551fd4['setComponent'](_0x2baa0c);}['addOrOverwriteComponent'](_0x5d6535){this['getProvider'](_0x5d6535['name'])['isComponentSet']()&&this['providers']['delete'](_0x5d6535['name']),this['addComponent'](_0x5d6535);}['getProvider'](_0x193e48){if(this['providers']['has'](_0x193e48))return this['providers']['get'](_0x193e48);const _0x33f572=new Ac(_0x193e48,this);return this['providers']['set'](_0x193e48,_0x33f572),_0x33f572;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x59ad45){_0x59ad45[_0x59ad45['DEBUG']=0x0]='DEBUG',_0x59ad45[_0x59ad45['VERBOSE']=0x1]='VERBOSE',_0x59ad45[_0x59ad45['INFO']=0x2]='INFO',_0x59ad45[_0x59ad45['WARN']=0x3]='WARN',_0x59ad45[_0x59ad45['ERROR']=0x4]='ERROR',_0x59ad45[_0x59ad45['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x49c42f,_0x34adff,..._0xa5f23a)=>{if(_0x34adff<_0x49c42f['logLevel'])return;const _0xc4b52e=new Date()['toISOString'](),_0x287640=Mc[_0x34adff];if(_0x287640)console[_0x287640]('['+_0xc4b52e+']\x20\x20'+_0x49c42f['name']+':',..._0xa5f23a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x34adff+')');};class Bi{constructor(_0x187df8){this['name']=_0x187df8,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x28d2fd){if(!(_0x28d2fd in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x28d2fd+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x28d2fd;}['setLogLevel'](_0x3473c0){this['_logLevel']=typeof _0x3473c0=='string'?Oc[_0x3473c0]:_0x3473c0;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x548462){if(typeof _0x548462!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x548462;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4457cd){this['_userLogHandler']=_0x4457cd;}['debug'](..._0x3d5aed){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3d5aed),this['_logHandler'](this,T['DEBUG'],..._0x3d5aed);}['log'](..._0x2731fc){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2731fc),this['_logHandler'](this,T['VERBOSE'],..._0x2731fc);}['info'](..._0x52f0f5){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x52f0f5),this['_logHandler'](this,T['INFO'],..._0x52f0f5);}['warn'](..._0x493c8f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x493c8f),this['_logHandler'](this,T['WARN'],..._0x493c8f);}['error'](..._0x253b1e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x253b1e),this['_logHandler'](this,T['ERROR'],..._0x253b1e);}}const xc=(_0x676179,_0x3e0ec9)=>_0x3e0ec9['some'](_0x23498d=>_0x676179 instanceof _0x23498d);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0xe0371e){const _0x243cbd=new Promise((_0x2f5128,_0x5f2f71)=>{const _0x307595=()=>{_0xe0371e['removeEventListener']('success',_0x356b22),_0xe0371e['removeEventListener']('error',_0x58f69b);},_0x356b22=()=>{_0x2f5128(ge(_0xe0371e['result'])),_0x307595();},_0x58f69b=()=>{_0x5f2f71(_0xe0371e['error']),_0x307595();};_0xe0371e['addEventListener']('success',_0x356b22),_0xe0371e['addEventListener']('error',_0x58f69b);});return _0x243cbd['then'](_0x2f32ab=>{_0x2f32ab instanceof IDBCursor&&Jr['set'](_0x2f32ab,_0xe0371e);})['catch'](()=>{}),Vi['set'](_0x243cbd,_0xe0371e),_0x243cbd;}function Bc(_0x932d8a){if(_i['has'](_0x932d8a))return;const _0xdd10e4=new Promise((_0x5d5280,_0x35feef)=>{const _0x2430aa=()=>{_0x932d8a['removeEventListener']('complete',_0x2e1e49),_0x932d8a['removeEventListener']('error',_0x1e127d),_0x932d8a['removeEventListener']('abort',_0x1e127d);},_0x2e1e49=()=>{_0x5d5280(),_0x2430aa();},_0x1e127d=()=>{_0x35feef(_0x932d8a['error']||new DOMException('AbortError','AbortError')),_0x2430aa();};_0x932d8a['addEventListener']('complete',_0x2e1e49),_0x932d8a['addEventListener']('error',_0x1e127d),_0x932d8a['addEventListener']('abort',_0x1e127d);});_i['set'](_0x932d8a,_0xdd10e4);}let gi={'get'(_0x729ef9,_0x1e5f1e,_0x26d664){if(_0x729ef9 instanceof IDBTransaction){if(_0x1e5f1e==='done')return _i['get'](_0x729ef9);if(_0x1e5f1e==='objectStoreNames')return _0x729ef9['objectStoreNames']||Xr['get'](_0x729ef9);if(_0x1e5f1e==='store')return _0x26d664['objectStoreNames'][0x1]?void 0x0:_0x26d664['objectStore'](_0x26d664['objectStoreNames'][0x0]);}return ge(_0x729ef9[_0x1e5f1e]);},'set'(_0x201f22,_0x39408f,_0x247303){return _0x201f22[_0x39408f]=_0x247303,!0x0;},'has'(_0x32f471,_0x5e51a7){return _0x32f471 instanceof IDBTransaction&&(_0x5e51a7==='done'||_0x5e51a7==='store')?!0x0:_0x5e51a7 in _0x32f471;}};function Vc(_0x50c6e4){gi=_0x50c6e4(gi);}function Hc(_0x56b905){return _0x56b905===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4237d6,..._0x41cff2){const _0x3716b9=_0x56b905['call'](ii(this),_0x4237d6,..._0x41cff2);return Xr['set'](_0x3716b9,_0x4237d6['sort']?_0x4237d6['sort']():[_0x4237d6]),ge(_0x3716b9);}:Uc()['includes'](_0x56b905)?function(..._0x5b333b){return _0x56b905['apply'](ii(this),_0x5b333b),ge(Jr['get'](this));}:function(..._0x4990f5){return ge(_0x56b905['apply'](ii(this),_0x4990f5));};}function $c(_0x3c69a7){return typeof _0x3c69a7=='function'?Hc(_0x3c69a7):(_0x3c69a7 instanceof IDBTransaction&&Bc(_0x3c69a7),xc(_0x3c69a7,Fc())?new Proxy(_0x3c69a7,gi):_0x3c69a7);}function ge(_0x2b8675){if(_0x2b8675 instanceof IDBRequest)return Wc(_0x2b8675);if(ni['has'](_0x2b8675))return ni['get'](_0x2b8675);const _0x2886d2=$c(_0x2b8675);return _0x2886d2!==_0x2b8675&&(ni['set'](_0x2b8675,_0x2886d2),Vi['set'](_0x2886d2,_0x2b8675)),_0x2886d2;}const ii=_0x2b95b8=>Vi['get'](_0x2b95b8);function Gc(_0x4eee5b,_0x388e98,{blocked:_0x16d03a,upgrade:_0x49d06e,blocking:_0xed148,terminated:_0x32fe79}={}){const _0x4719c6=indexedDB['open'](_0x4eee5b,_0x388e98),_0x299d82=ge(_0x4719c6);return _0x49d06e&&_0x4719c6['addEventListener']('upgradeneeded',_0x1ee5d4=>{_0x49d06e(ge(_0x4719c6['result']),_0x1ee5d4['oldVersion'],_0x1ee5d4['newVersion'],ge(_0x4719c6['transaction']),_0x1ee5d4);}),_0x16d03a&&_0x4719c6['addEventListener']('blocked',_0x2c4790=>_0x16d03a(_0x2c4790['oldVersion'],_0x2c4790['newVersion'],_0x2c4790)),_0x299d82['then'](_0x2ccec6=>{_0x32fe79&&_0x2ccec6['addEventListener']('close',()=>_0x32fe79()),_0xed148&&_0x2ccec6['addEventListener']('versionchange',_0x415889=>_0xed148(_0x415889['oldVersion'],_0x415889['newVersion'],_0x415889));})['catch'](()=>{}),_0x299d82;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x17f284,_0x1af79e){if(!(_0x17f284 instanceof IDBDatabase&&!(_0x1af79e in _0x17f284)&&typeof _0x1af79e=='string'))return;if(si['get'](_0x1af79e))return si['get'](_0x1af79e);const _0x364700=_0x1af79e['replace'](/FromIndex$/,''),_0x11e0a0=_0x1af79e!==_0x364700,_0x54c550=zc['includes'](_0x364700);if(!(_0x364700 in(_0x11e0a0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x54c550||qc['includes'](_0x364700)))return;const _0x11ce26=async function(_0x42569e,..._0xc04bf){const _0x3be5d6=this['transaction'](_0x42569e,_0x54c550?'readwrite':'readonly');let _0x4829c9=_0x3be5d6['store'];return _0x11e0a0&&(_0x4829c9=_0x4829c9['index'](_0xc04bf['shift']())),(await Promise['all']([_0x4829c9[_0x364700](..._0xc04bf),_0x54c550&&_0x3be5d6['done']]))[0x0];};return si['set'](_0x1af79e,_0x11ce26),_0x11ce26;}Vc(_0x5c2602=>({..._0x5c2602,'get':(_0x533366,_0x184352,_0x32209e)=>Ms(_0x533366,_0x184352)||_0x5c2602['get'](_0x533366,_0x184352,_0x32209e),'has':(_0x5643ed,_0x1665d8)=>!!Ms(_0x5643ed,_0x1665d8)||_0x5c2602['has'](_0x5643ed,_0x1665d8)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1353c5){this['container']=_0x1353c5;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x319e52=>{if(Kc(_0x319e52)){const _0x131c55=_0x319e52['getImmediate']();return _0x131c55['library']+'/'+_0x131c55['version'];}else return null;})['filter'](_0x33c960=>_0x33c960)['join']('\x20');}}function Kc(_0xbb2e62){const _0x9caa13=_0xbb2e62['getComponent']();return(_0x9caa13==null?void 0x0:_0x9caa13['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x29daa8,_0x1b7b2b){try{_0x29daa8['container']['addComponent'](_0x1b7b2b);}catch(_0x43b52e){oe['debug']('Component\x20'+_0x1b7b2b['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x29daa8['name'],_0x43b52e);}}function st(_0x3cafca){const _0x417dd5=_0x3cafca['name'];if(Ei['has'](_0x417dd5))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x417dd5+'.'),!0x1;Ei['set'](_0x417dd5,_0x3cafca);for(const _0x302489 of Ue['values']())xs(_0x302489,_0x3cafca);for(const _0xe6be15 of vi['values']())xs(_0xe6be15,_0x3cafca);return!0x0;}function Hi(_0x3094c6,_0xa66e09){const _0x89a9d9=_0x3094c6['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x89a9d9&&_0x89a9d9['triggerHeartbeat'](),_0x3094c6['container']['getProvider'](_0xa66e09);}function $(_0x5480d0){return _0x5480d0==null?!0x1:_0x5480d0['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x3c04d0,_0x13dafa,_0x4a5d49){this['_isDeleted']=!0x1,this['_options']={..._0x3c04d0},this['_config']={..._0x13dafa},this['_name']=_0x13dafa['name'],this['_automaticDataCollectionEnabled']=_0x13dafa['automaticDataCollectionEnabled'],this['_container']=_0x4a5d49,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x32cb76){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x32cb76;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x34486f){this['_isDeleted']=_0x34486f;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x20268b,_0x597386={}){let _0x28230e=_0x20268b;typeof _0x597386!='object'&&(_0x597386={'name':_0x597386});const _0x31fd02={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x597386},_0x179af1=_0x31fd02['name'];if(typeof _0x179af1!='string'||!_0x179af1)throw me['create']('bad-app-name',{'appName':String(_0x179af1)});if(_0x28230e||(_0x28230e=zr()),!_0x28230e)throw me['create']('no-options');const _0x5b5299=Ue['get'](_0x179af1);if(_0x5b5299){if(xe(_0x28230e,_0x5b5299['options'])&&xe(_0x31fd02,_0x5b5299['config']))return _0x5b5299;throw me['create']('duplicate-app',{'appName':_0x179af1});}const _0x6b58eb=new Nc(_0x179af1);for(const _0x18654a of Ei['values']())_0x6b58eb['addComponent'](_0x18654a);const _0x1df5f9=new Tl(_0x28230e,_0x31fd02,_0x6b58eb);return Ue['set'](_0x179af1,_0x1df5f9),_0x1df5f9;}function Zr(_0x254e1e=yi){const _0x338b51=Ue['get'](_0x254e1e);if(!_0x338b51&&_0x254e1e===yi&&zr())return Sl();if(!_0x338b51)throw me['create']('no-app',{'appName':_0x254e1e});return _0x338b51;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x49270e){let _0x5b5770=!0x1;const _0x5b1493=_0x49270e['name'];Ue['has'](_0x5b1493)?(_0x5b5770=!0x0,Ue['delete'](_0x5b1493)):vi['has'](_0x5b1493)&&_0x49270e['decRefCount']()<=0x0&&(vi['delete'](_0x5b1493),_0x5b5770=!0x0),_0x5b5770&&(await Promise['all'](_0x49270e['container']['getProviders']()['map'](_0x3bd4b7=>_0x3bd4b7['delete']())),_0x49270e['isDeleted']=!0x0);}function ye(_0x1c1c44,_0x267215,_0x454a60){let _0x34b22d=wl[_0x1c1c44]??_0x1c1c44;_0x454a60&&(_0x34b22d+='-'+_0x454a60);const _0x744cf7=_0x34b22d['match'](/\s|\//),_0x2b63df=_0x267215['match'](/\s|\//);if(_0x744cf7||_0x2b63df){const _0x24bea0=['Unable\x20to\x20register\x20library\x20\x22'+_0x34b22d+'\x22\x20with\x20version\x20\x22'+_0x267215+'\x22:'];_0x744cf7&&_0x24bea0['push']('library\x20name\x20\x22'+_0x34b22d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x744cf7&&_0x2b63df&&_0x24bea0['push']('and'),_0x2b63df&&_0x24bea0['push']('version\x20name\x20\x22'+_0x267215+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x24bea0['join']('\x20'));return;}st(new Fe(_0x34b22d+'-version',()=>({'library':_0x34b22d,'version':_0x267215}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3ad590,_0x1c1084)=>{switch(_0x1c1084){case 0x0:try{_0x3ad590['createObjectStore'](Ot);}catch(_0xcaf211){console['warn'](_0xcaf211);}}}})['catch'](_0x974a2f=>{throw me['create']('idb-open',{'originalErrorMessage':_0x974a2f['message']});})),ri;}async function Al(_0x54a03c){try{const _0x47e80f=(await eo())['transaction'](Ot),_0x17563d=await _0x47e80f['objectStore'](Ot)['get'](to(_0x54a03c));return await _0x47e80f['done'],_0x17563d;}catch(_0xe54eea){if(_0xe54eea instanceof Re)oe['warn'](_0xe54eea['message']);else{const _0x3c2bac=me['create']('idb-get',{'originalErrorMessage':_0xe54eea==null?void 0x0:_0xe54eea['message']});oe['warn'](_0x3c2bac['message']);}}}async function Fs(_0x399c03,_0x7a9f0){try{const _0x5de229=(await eo())['transaction'](Ot,'readwrite');await _0x5de229['objectStore'](Ot)['put'](_0x7a9f0,to(_0x399c03)),await _0x5de229['done'];}catch(_0x4564f2){if(_0x4564f2 instanceof Re)oe['warn'](_0x4564f2['message']);else{const _0x552ac2=me['create']('idb-set',{'originalErrorMessage':_0x4564f2==null?void 0x0:_0x4564f2['message']});oe['warn'](_0x552ac2['message']);}}}function to(_0x8ac068){return _0x8ac068['name']+'!'+_0x8ac068['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x4ba74a){this['container']=_0x4ba74a,this['_heartbeatsCache']=null;const _0x63f461=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x63f461),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x132970=>(this['_heartbeatsCache']=_0x132970,_0x132970));}async['triggerHeartbeat'](){var _0x5386e7,_0x1494df;try{const _0x14b827=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2d16a1=Us();if(((_0x5386e7=this['_heartbeatsCache'])==null?void 0x0:_0x5386e7['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1494df=this['_heartbeatsCache'])==null?void 0x0:_0x1494df['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2d16a1||this['_heartbeatsCache']['heartbeats']['some'](_0xcf8fb2=>_0xcf8fb2['date']===_0x2d16a1))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2d16a1,'agent':_0x14b827}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x44e682=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x44e682,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x51178c){oe['warn'](_0x51178c);}}async['getHeartbeatsHeader'](){var _0xfa03fa;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xfa03fa=this['_heartbeatsCache'])==null?void 0x0:_0xfa03fa['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x125cf3=Us(),{heartbeatsToSend:_0x1eebf7,unsentEntries:_0x385db9}=Ol(this['_heartbeatsCache']['heartbeats']),_0xf3d43b=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1eebf7}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x125cf3,_0x385db9['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x385db9,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xf3d43b;}catch(_0x324644){return oe['warn'](_0x324644),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x50cc4c,_0x2d8fdc=kl){const _0x54a726=[];let _0x2ec50c=_0x50cc4c['slice']();for(const _0xbe0f62 of _0x50cc4c){const _0x5beb9b=_0x54a726['find'](_0x441711=>_0x441711['agent']===_0xbe0f62['agent']);if(_0x5beb9b){if(_0x5beb9b['dates']['push'](_0xbe0f62['date']),Ws(_0x54a726)>_0x2d8fdc){_0x5beb9b['dates']['pop']();break;}}else{if(_0x54a726['push']({'agent':_0xbe0f62['agent'],'dates':[_0xbe0f62['date']]}),Ws(_0x54a726)>_0x2d8fdc){_0x54a726['pop']();break;}}_0x2ec50c=_0x2ec50c['slice'](0x1);}return{'heartbeatsToSend':_0x54a726,'unsentEntries':_0x2ec50c};}class Dl{constructor(_0x17ecfa){this['app']=_0x17ecfa,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2e0ff4=await Al(this['app']);return _0x2e0ff4!=null&&_0x2e0ff4['heartbeats']?_0x2e0ff4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5ad8ae){if(await this['_canUseIndexedDBPromise']){const _0x49924a=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5ad8ae['lastSentHeartbeatDate']??_0x49924a['lastSentHeartbeatDate'],'heartbeats':_0x5ad8ae['heartbeats']});}else return;}async['add'](_0x1d83f8){if(await this['_canUseIndexedDBPromise']){const _0x6e90ec=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1d83f8['lastSentHeartbeatDate']??_0x6e90ec['lastSentHeartbeatDate'],'heartbeats':[..._0x6e90ec['heartbeats'],..._0x1d83f8['heartbeats']]});}else return;}}function Ws(_0x2be9ab){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2be9ab}))['length'];}function Ml(_0x63728b){if(_0x63728b['length']===0x0)return-0x1;let _0x74a053=0x0,_0x3ce05a=_0x63728b[0x0]['date'];for(let _0x40f3b9=0x1;_0x40f3b9<_0x63728b['length'];_0x40f3b9++)_0x63728b[_0x40f3b9]['date']<_0x3ce05a&&(_0x3ce05a=_0x63728b[_0x40f3b9]['date'],_0x74a053=_0x40f3b9);return _0x74a053;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1847f1){st(new Fe('platform-logger',_0x2f3a0e=>new jc(_0x2f3a0e),'PRIVATE')),st(new Fe('heartbeat',_0x4ce6b8=>new Nl(_0x4ce6b8),'PRIVATE')),ye(mi,Ls,_0x1847f1),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1ee882){no=_0x1ee882;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2eaaa1){this['domStorage_']=_0x2eaaa1,this['prefix_']='firebase:';}['set'](_0x4abea0,_0x5667f4){_0x5667f4==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4abea0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4abea0),O(_0x5667f4));}['get'](_0x34a0e8){const _0x106869=this['domStorage_']['getItem'](this['prefixedName_'](_0x34a0e8));return _0x106869==null?null:Nt(_0x106869);}['remove'](_0x1a94b4){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1a94b4));}['prefixedName_'](_0x445fd1){return this['prefix_']+_0x445fd1;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3c97db,_0x370765){_0x370765==null?delete this['cache_'][_0x3c97db]:this['cache_'][_0x3c97db]=_0x370765;}['get'](_0x58e139){return Q(this['cache_'],_0x58e139)?this['cache_'][_0x58e139]:null;}['remove'](_0x19e936){delete this['cache_'][_0x19e936];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x112147){try{if(typeof window<'u'&&typeof window[_0x112147]<'u'){const _0x339973=window[_0x112147];return _0x339973['setItem']('firebase:sentinel','cache'),_0x339973['removeItem']('firebase:sentinel'),new Wl(_0x339973);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1cf66b=0x1;return function(){return _0x1cf66b++;};}()),ro=function(_0x49e94d){const _0x16fc4e=Rc(_0x49e94d),_0x1a3bc7=new Cc();_0x1a3bc7['update'](_0x16fc4e);const _0x5b8237=_0x1a3bc7['digest']();return Fi['encodeByteArray'](_0x5b8237);},zt=function(..._0x14d68d){let _0x158815='';for(let _0x4bc9cf=0x0;_0x4bc9cf<_0x14d68d['length'];_0x4bc9cf++){const _0x126c44=_0x14d68d[_0x4bc9cf];Array['isArray'](_0x126c44)||_0x126c44&&typeof _0x126c44=='object'&&typeof _0x126c44['length']=='number'?_0x158815+=zt['apply'](null,_0x126c44):typeof _0x126c44=='object'?_0x158815+=O(_0x126c44):_0x158815+=_0x126c44,_0x158815+='\x20';}return _0x158815;};let St=null,$s=!0x0;const Hl=function(_0x49660b,_0x536968){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x2ef05f){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x4bc481=zt['apply'](null,_0x2ef05f);St(_0x4bc481);}},jt=function(_0x2f51fb){return function(..._0x99608c){L(_0x2f51fb,..._0x99608c);};},Ii=function(..._0xfde88){const _0x2f4267='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0xfde88);Ze['error'](_0x2f4267);},ae=function(..._0x4447a0){const _0xfbe35='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x4447a0);throw Ze['error'](_0xfbe35),new Error(_0xfbe35);},U=function(..._0x31a1f0){const _0x22bbd4='FIREBASE\x20WARNING:\x20'+zt(..._0x31a1f0);Ze['warn'](_0x22bbd4);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x1c1146){return typeof _0x1c1146=='number'&&(_0x1c1146!==_0x1c1146||_0x1c1146===Number['POSITIVE_INFINITY']||_0x1c1146===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4028f8){if(document['readyState']==='complete')_0x4028f8();else{let _0x54c9b7=!0x1;const _0x3a81c1=function(){if(!document['body']){setTimeout(_0x3a81c1,Math['floor'](0xa));return;}_0x54c9b7||(_0x54c9b7=!0x0,_0x4028f8());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3a81c1,!0x1),window['addEventListener']('load',_0x3a81c1,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3a81c1();}),window['attachEvent']('onload',_0x3a81c1));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x3bff5c,_0x2cc255){if(_0x3bff5c===_0x2cc255)return 0x0;if(_0x3bff5c===We||_0x2cc255===we)return-0x1;if(_0x2cc255===We||_0x3bff5c===we)return 0x1;{const _0x5b699f=Gs(_0x3bff5c),_0xb2230a=Gs(_0x2cc255);return _0x5b699f!==null?_0xb2230a!==null?_0x5b699f-_0xb2230a===0x0?_0x3bff5c['length']-_0x2cc255['length']:_0x5b699f-_0xb2230a:-0x1:_0xb2230a!==null?0x1:_0x3bff5c<_0x2cc255?-0x1:0x1;}},ql=function(_0x4a4cdf,_0x32dd4a){return _0x4a4cdf===_0x32dd4a?0x0:_0x4a4cdf<_0x32dd4a?-0x1:0x1;},vt=function(_0x4f8efe,_0x3fcf6d){if(_0x3fcf6d&&_0x4f8efe in _0x3fcf6d)return _0x3fcf6d[_0x4f8efe];throw new Error('Missing\x20required\x20key\x20('+_0x4f8efe+')\x20in\x20object:\x20'+O(_0x3fcf6d));},$i=function(_0x179969){if(typeof _0x179969!='object'||_0x179969===null)return O(_0x179969);const _0x526473=[];for(const _0x754a70 in _0x179969)_0x526473['push'](_0x754a70);_0x526473['sort']();let _0x3cb411='{';for(let _0x200ed8=0x0;_0x200ed8<_0x526473['length'];_0x200ed8++)_0x200ed8!==0x0&&(_0x3cb411+=','),_0x3cb411+=O(_0x526473[_0x200ed8]),_0x3cb411+=':',_0x3cb411+=$i(_0x179969[_0x526473[_0x200ed8]]);return _0x3cb411+='}',_0x3cb411;},oo=function(_0x426092,_0x243d77){const _0x5fc7da=_0x426092['length'];if(_0x5fc7da<=_0x243d77)return[_0x426092];const _0x320411=[];for(let _0x237193=0x0;_0x237193<_0x5fc7da;_0x237193+=_0x243d77)_0x237193+_0x243d77>_0x5fc7da?_0x320411['push'](_0x426092['substring'](_0x237193,_0x5fc7da)):_0x320411['push'](_0x426092['substring'](_0x237193,_0x237193+_0x243d77));return _0x320411;};function x(_0x153df2,_0xafcabb){for(const _0x4cfb9a in _0x153df2)_0x153df2['hasOwnProperty'](_0x4cfb9a)&&_0xafcabb(_0x4cfb9a,_0x153df2[_0x4cfb9a]);}const ao=function(_0x553ea0){f(!xn(_0x553ea0),'Invalid\x20JSON\x20number');const _0x38009d=0xb,_0x3ee802=0x34,_0x236f7b=(0x1<<_0x38009d-0x1)-0x1;let _0x346b76,_0x2903c1,_0x39a214,_0xfc785b,_0x2754ac;_0x553ea0===0x0?(_0x2903c1=0x0,_0x39a214=0x0,_0x346b76=0x1/_0x553ea0===-0x1/0x0?0x1:0x0):(_0x346b76=_0x553ea0<0x0,_0x553ea0=Math['abs'](_0x553ea0),_0x553ea0>=Math['pow'](0x2,0x1-_0x236f7b)?(_0xfc785b=Math['min'](Math['floor'](Math['log'](_0x553ea0)/Math['LN2']),_0x236f7b),_0x2903c1=_0xfc785b+_0x236f7b,_0x39a214=Math['round'](_0x553ea0*Math['pow'](0x2,_0x3ee802-_0xfc785b)-Math['pow'](0x2,_0x3ee802))):(_0x2903c1=0x0,_0x39a214=Math['round'](_0x553ea0/Math['pow'](0x2,0x1-_0x236f7b-_0x3ee802))));const _0x37ca97=[];for(_0x2754ac=_0x3ee802;_0x2754ac;_0x2754ac-=0x1)_0x37ca97['push'](_0x39a214%0x2?0x1:0x0),_0x39a214=Math['floor'](_0x39a214/0x2);for(_0x2754ac=_0x38009d;_0x2754ac;_0x2754ac-=0x1)_0x37ca97['push'](_0x2903c1%0x2?0x1:0x0),_0x2903c1=Math['floor'](_0x2903c1/0x2);_0x37ca97['push'](_0x346b76?0x1:0x0),_0x37ca97['reverse']();const _0x51741b=_0x37ca97['join']('');let _0x526dfc='';for(_0x2754ac=0x0;_0x2754ac<0x40;_0x2754ac+=0x8){let _0xc59588=parseInt(_0x51741b['substr'](_0x2754ac,0x8),0x2)['toString'](0x10);_0xc59588['length']===0x1&&(_0xc59588='0'+_0xc59588),_0x526dfc=_0x526dfc+_0xc59588;}return _0x526dfc['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x56823a,_0x32be08){let _0x1984af='Unknown\x20Error';_0x56823a==='too_big'?_0x1984af='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x56823a==='permission_denied'?_0x1984af='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x56823a==='unavailable'&&(_0x1984af='The\x20service\x20is\x20unavailable');const _0x1fa682=new Error(_0x56823a+'\x20at\x20'+_0x32be08['_path']['toString']()+':\x20'+_0x1984af);return _0x1fa682['code']=_0x56823a['toUpperCase'](),_0x1fa682;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x34f004){if(Yl['test'](_0x34f004)){const _0x3365f7=Number(_0x34f004);if(_0x3365f7>=Ql&&_0x3365f7<=Jl)return _0x3365f7;}return null;},ft=function(_0x587270){try{_0x587270();}catch(_0x5c4d00){setTimeout(()=>{const _0x43db6c=_0x5c4d00['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x43db6c),_0x5c4d00;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x5a8b9f,_0x3fc2cc){const _0x51db09=setTimeout(_0x5a8b9f,_0x3fc2cc);return typeof _0x51db09=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x51db09):typeof _0x51db09=='object'&&_0x51db09['unref']&&_0x51db09['unref'](),_0x51db09;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x439d8a,_0x340cf4){this['appCheckProvider']=_0x340cf4,this['appName']=_0x439d8a['name'],$(_0x439d8a)&&_0x439d8a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x439d8a['settings']['appCheckToken']),this['appCheck']=_0x340cf4==null?void 0x0:_0x340cf4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x340cf4==null||_0x340cf4['get']()['then'](_0x11d0bf=>this['appCheck']=_0x11d0bf);}['getToken'](_0x124f54){if(this['serverAppAppCheckToken']){if(_0x124f54)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x124f54):new Promise((_0x132a82,_0x13ae9d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x124f54)['then'](_0x132a82,_0x13ae9d):_0x132a82(null);},0x0);});}['addTokenChangeListener'](_0x298c59){var _0x19ed29;(_0x19ed29=this['appCheckProvider'])==null||_0x19ed29['get']()['then'](_0x2217c5=>_0x2217c5['addTokenListener'](_0x298c59));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x23bd44,_0x671833,_0x48f680){this['appName_']=_0x23bd44,this['firebaseOptions_']=_0x671833,this['authProvider_']=_0x48f680,this['auth_']=null,this['auth_']=_0x48f680['getImmediate']({'optional':!0x0}),this['auth_']||_0x48f680['onInit'](_0x2f5366=>this['auth_']=_0x2f5366);}['getToken'](_0x58fc0a){return this['auth_']?this['auth_']['getToken'](_0x58fc0a)['catch'](_0x1d2b4c=>_0x1d2b4c&&_0x1d2b4c['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1d2b4c)):new Promise((_0x2e90a4,_0x3a2923)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x58fc0a)['then'](_0x2e90a4,_0x3a2923):_0x2e90a4(null);},0x0);});}['addTokenChangeListener'](_0x18ebf9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x18ebf9):this['authProvider_']['get']()['then'](_0x2d9202=>_0x2d9202['addAuthTokenListener'](_0x18ebf9));}['removeTokenChangeListener'](_0x5e1e52){this['authProvider_']['get']()['then'](_0x1d1c1e=>_0x1d1c1e['removeAuthTokenListener'](_0x5e1e52));}['notifyForInvalidToken'](){let _0x33e888='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x33e888+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x33e888+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x33e888+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x33e888);}}class an{constructor(_0x4e7e80){this['accessToken']=_0x4e7e80;}['getToken'](_0x3868a7){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5321fb){_0x5321fb(this['accessToken']);}['removeTokenChangeListener'](_0xd74b9e){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x268856,_0x126af9,_0x1c8418,_0x33a52f,_0x1a84ed=!0x1,_0x2fac92='',_0x1aa625=!0x1,_0x435b3b=!0x1,_0x270d3c=null){this['secure']=_0x126af9,this['namespace']=_0x1c8418,this['webSocketOnly']=_0x33a52f,this['nodeAdmin']=_0x1a84ed,this['persistenceKey']=_0x2fac92,this['includeNamespaceInQueryParams']=_0x1aa625,this['isUsingEmulator']=_0x435b3b,this['emulatorOptions']=_0x270d3c,this['_host']=_0x268856['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x268856)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2ed4d8){_0x2ed4d8!==this['internalHost']&&(this['internalHost']=_0x2ed4d8,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x549b16=this['toURLString']();return this['persistenceKey']&&(_0x549b16+='<'+this['persistenceKey']+'>'),_0x549b16;}['toURLString'](){const _0x450918=this['secure']?'https://':'http://',_0x55492c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x450918+this['host']+'/'+_0x55492c;}}function th(_0x56b9ea){return _0x56b9ea['host']!==_0x56b9ea['internalHost']||_0x56b9ea['isCustomHost']()||_0x56b9ea['includeNamespaceInQueryParams'];}function vo(_0x4b65ed,_0x2862f7,_0x4cb6cc){f(typeof _0x2862f7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4cb6cc=='object','typeof\x20params\x20must\x20==\x20object');let _0x562748;if(_0x2862f7===go)_0x562748=(_0x4b65ed['secure']?'wss://':'ws://')+_0x4b65ed['internalHost']+'/.ws?';else{if(_0x2862f7===mo)_0x562748=(_0x4b65ed['secure']?'https://':'http://')+_0x4b65ed['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2862f7);}th(_0x4b65ed)&&(_0x4cb6cc['ns']=_0x4b65ed['namespace']);const _0x5e30e6=[];return x(_0x4cb6cc,(_0x49f5f9,_0x58d824)=>{_0x5e30e6['push'](_0x49f5f9+'='+_0x58d824);}),_0x562748+_0x5e30e6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x26a9fe,_0x178139=0x1){Q(this['counters_'],_0x26a9fe)||(this['counters_'][_0x26a9fe]=0x0),this['counters_'][_0x26a9fe]+=_0x178139;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x44573c){const _0x20c991=_0x44573c['toString']();return oi[_0x20c991]||(oi[_0x20c991]=new nh()),oi[_0x20c991];}function ih(_0x38760c,_0x5dd84d){const _0x25625d=_0x38760c['toString']();return ai[_0x25625d]||(ai[_0x25625d]=_0x5dd84d()),ai[_0x25625d];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x2a0b52){this['onMessage_']=_0x2a0b52,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x87df8f,_0x23539e){this['closeAfterResponse']=_0x87df8f,this['onClose']=_0x23539e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x504246,_0x47b0f6){for(this['pendingResponses'][_0x504246]=_0x47b0f6;this['pendingResponses'][this['currentResponseNum']];){const _0x1a4098=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xaa1e38=0x0;_0xaa1e38<_0x1a4098['length'];++_0xaa1e38)_0x1a4098[_0xaa1e38]&&ft(()=>{this['onMessage_'](_0x1a4098[_0xaa1e38]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x257ecc,_0x16f0cb,_0x5b1240,_0x34207e,_0x28c973,_0x39d319,_0x3a7809){this['connId']=_0x257ecc,this['repoInfo']=_0x16f0cb,this['applicationId']=_0x5b1240,this['appCheckToken']=_0x34207e,this['authToken']=_0x28c973,this['transportSessionId']=_0x39d319,this['lastSessionId']=_0x3a7809,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x257ecc),this['stats_']=qi(_0x16f0cb),this['urlFn']=_0x11ddcb=>(this['appCheckToken']&&(_0x11ddcb[wi]=this['appCheckToken']),vo(_0x16f0cb,mo,_0x11ddcb));}['open'](_0x29ca33,_0x546014){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x546014,this['myPacketOrderer']=new sh(_0x29ca33),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x27b99)=>{const [_0x4d84f7,_0x5c4b1c,_0x181ee3,_0x1fa599,_0x4960fe]=_0x27b99;if(this['incrementIncomingBytes_'](_0x27b99),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4d84f7===qs)this['id']=_0x5c4b1c,this['password']=_0x181ee3;else{if(_0x4d84f7===rh)_0x5c4b1c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5c4b1c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4d84f7);}}},(..._0x278bb3)=>{const [_0x489865,_0x4d78bb]=_0x278bb3;this['incrementIncomingBytes_'](_0x278bb3),this['myPacketOrderer']['handleResponse'](_0x489865,_0x4d78bb);},()=>{this['onClosed_']();},this['urlFn']);const _0x4cf265={};_0x4cf265[qs]='t',_0x4cf265[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4cf265[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4cf265[co]=Gi,this['transportSessionId']&&(_0x4cf265[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4cf265[po]=this['lastSessionId']),this['applicationId']&&(_0x4cf265[_o]=this['applicationId']),this['appCheckToken']&&(_0x4cf265[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4cf265[ho]=uo);const _0x55525e=this['urlFn'](_0x4cf265);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x55525e),this['scriptTagHolder']['addTag'](_0x55525e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x539cc6){const _0x12891f=O(_0x539cc6);this['bytesSent']+=_0x12891f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x12891f['length']);const _0x2ac5ea=$r(_0x12891f),_0x42da57=oo(_0x2ac5ea,fh);for(let _0x134fb4=0x0;_0x134fb4<_0x42da57['length'];_0x134fb4++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x42da57['length'],_0x42da57[_0x134fb4]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5bfc86,_0x18ee36){this['myDisconnFrame']=document['createElement']('iframe');const _0x5d04f1={};_0x5d04f1[dh]='t',_0x5d04f1[Eo]=_0x5bfc86,_0x5d04f1[Io]=_0x18ee36,this['myDisconnFrame']['src']=this['urlFn'](_0x5d04f1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x216de0){const _0x58bb0d=O(_0x216de0)['length'];this['bytesReceived']+=_0x58bb0d,this['stats_']['incrementCounter']('bytes_received',_0x58bb0d);}}class zi{constructor(_0xf98638,_0x59a0e6,_0x1b5b3e,_0x53780d){this['onDisconnect']=_0x1b5b3e,this['urlFn']=_0x53780d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xf98638,window[ah+this['uniqueCallbackIdentifier']]=_0x59a0e6,this['myIFrame']=zi['createIFrame_']();let _0x328d3a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x328d3a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x40a68a='<html><body>'+_0x328d3a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x40a68a),this['myIFrame']['doc']['close']();}catch(_0x49982a){L('frame\x20writing\x20exception'),_0x49982a['stack']&&L(_0x49982a['stack']),L(_0x49982a);}}}static['createIFrame_'](){const _0x468204=document['createElement']('iframe');if(_0x468204['style']['display']='none',document['body']){document['body']['appendChild'](_0x468204);try{_0x468204['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2c316a=document['domain'];_0x468204['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2c316a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x468204['contentDocument']?_0x468204['doc']=_0x468204['contentDocument']:_0x468204['contentWindow']?_0x468204['doc']=_0x468204['contentWindow']['document']:_0x468204['document']&&(_0x468204['doc']=_0x468204['document']),_0x468204;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5138db=this['onDisconnect'];_0x5138db&&(this['onDisconnect']=null,_0x5138db());}['startLongPoll'](_0x81be79,_0x3f2f73){for(this['myID']=_0x81be79,this['myPW']=_0x3f2f73,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xfa5446={};_0xfa5446[Eo]=this['myID'],_0xfa5446[Io]=this['myPW'],_0xfa5446[wo]=this['currentSerial'];let _0x2aa657=this['urlFn'](_0xfa5446),_0x22b81d='',_0x2032fc=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x22b81d['length']<=Co;){const _0x30cf0e=this['pendingSegs']['shift']();_0x22b81d=_0x22b81d+'&'+lh+_0x2032fc+'='+_0x30cf0e['seg']+'&'+hh+_0x2032fc+'='+_0x30cf0e['ts']+'&'+uh+_0x2032fc+'='+_0x30cf0e['d'],_0x2032fc++;}return _0x2aa657=_0x2aa657+_0x22b81d,this['addLongPollTag_'](_0x2aa657,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x51e47c,_0xd3f5b8,_0x4945cc){this['pendingSegs']['push']({'seg':_0x51e47c,'ts':_0xd3f5b8,'d':_0x4945cc}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4414df,_0x270460){this['outstandingRequests']['add'](_0x270460);const _0x104764=()=>{this['outstandingRequests']['delete'](_0x270460),this['newRequest_']();},_0xe20aa9=setTimeout(_0x104764,Math['floor'](ph)),_0x5dae2a=()=>{clearTimeout(_0xe20aa9),_0x104764();};this['addTag'](_0x4414df,_0x5dae2a);}['addTag'](_0x2b4072,_0x3c27a7){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xc9b652=this['myIFrame']['doc']['createElement']('script');_0xc9b652['type']='text/javascript',_0xc9b652['async']=!0x0,_0xc9b652['src']=_0x2b4072,_0xc9b652['onload']=_0xc9b652['onreadystatechange']=function(){const _0x24ced8=_0xc9b652['readyState'];(!_0x24ced8||_0x24ced8==='loaded'||_0x24ced8==='complete')&&(_0xc9b652['onload']=_0xc9b652['onreadystatechange']=null,_0xc9b652['parentNode']&&_0xc9b652['parentNode']['removeChild'](_0xc9b652),_0x3c27a7());},_0xc9b652['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2b4072),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xc9b652);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x455c37,_0x440554,_0x5b65ca,_0x1deecc,_0x2c8b72,_0x198077,_0x24e194){this['connId']=_0x455c37,this['applicationId']=_0x5b65ca,this['appCheckToken']=_0x1deecc,this['authToken']=_0x2c8b72,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x440554),this['connURL']=q['connectionURL_'](_0x440554,_0x198077,_0x24e194,_0x1deecc,_0x5b65ca),this['nodeAdmin']=_0x440554['nodeAdmin'];}static['connectionURL_'](_0x4dcde2,_0x5c2e0b,_0x30ba23,_0x5e8dbb,_0x3cce51){const _0x31bc64={};return _0x31bc64[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x31bc64[ho]=uo),_0x5c2e0b&&(_0x31bc64[lo]=_0x5c2e0b),_0x30ba23&&(_0x31bc64[po]=_0x30ba23),_0x5e8dbb&&(_0x31bc64[wi]=_0x5e8dbb),_0x3cce51&&(_0x31bc64[_o]=_0x3cce51),vo(_0x4dcde2,go,_0x31bc64);}['open'](_0x1606ab,_0x2f6f7b){this['onDisconnect']=_0x2f6f7b,this['onMessage']=_0x1606ab,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x273785;_c(),this['mySock']=new gn(this['connURL'],[],_0x273785);}catch(_0x5701d0){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x42fd97=_0x5701d0['message']||_0x5701d0['data'];_0x42fd97&&this['log_'](_0x42fd97),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2d68d5=>{this['handleIncomingFrame'](_0x2d68d5);},this['mySock']['onerror']=_0x4beb8d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x353e87=_0x4beb8d['message']||_0x4beb8d['data'];_0x353e87&&this['log_'](_0x353e87),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x54bd4d=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2290a4=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x111b78=navigator['userAgent']['match'](_0x2290a4);_0x111b78&&_0x111b78['length']>0x1&&parseFloat(_0x111b78[0x1])<4.4&&(_0x54bd4d=!0x0);}return!_0x54bd4d&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5d8fdf){if(this['frames']['push'](_0x5d8fdf),this['frames']['length']===this['totalFrames']){const _0x85659f=this['frames']['join']('');this['frames']=null;const _0x16be55=Nt(_0x85659f);this['onMessage'](_0x16be55);}}['handleNewFrameCount_'](_0x7342fe){this['totalFrames']=_0x7342fe,this['frames']=[];}['extractFrameCount_'](_0x563dae){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x563dae['length']<=0x6){const _0x5c53af=Number(_0x563dae);if(!isNaN(_0x5c53af))return this['handleNewFrameCount_'](_0x5c53af),null;}return this['handleNewFrameCount_'](0x1),_0x563dae;}['handleIncomingFrame'](_0x655b1d){if(this['mySock']===null)return;const _0x1c6b07=_0x655b1d['data'];if(this['bytesReceived']+=_0x1c6b07['length'],this['stats_']['incrementCounter']('bytes_received',_0x1c6b07['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1c6b07);else{const _0x370da8=this['extractFrameCount_'](_0x1c6b07);_0x370da8!==null&&this['appendFrame_'](_0x370da8);}}['send'](_0x228f17){this['resetKeepAlive']();const _0x106d57=O(_0x228f17);this['bytesSent']+=_0x106d57['length'],this['stats_']['incrementCounter']('bytes_sent',_0x106d57['length']);const _0x50a53b=oo(_0x106d57,gh);_0x50a53b['length']>0x1&&this['sendString_'](String(_0x50a53b['length']));for(let _0x5c2779=0x0;_0x5c2779<_0x50a53b['length'];_0x5c2779++)this['sendString_'](_0x50a53b[_0x5c2779]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x23ebd1){try{this['mySock']['send'](_0x23ebd1);}catch(_0x124b15){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x124b15['message']||_0x124b15['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x399581){this['initTransports_'](_0x399581);}['initTransports_'](_0x748736){const _0x563c97=q&&q['isAvailable']();let _0xf38b3f=_0x563c97&&!q['previouslyFailed']();if(_0x748736['webSocketOnly']&&(_0x563c97||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xf38b3f=!0x0),_0xf38b3f)this['transports_']=[q];else{const _0x127adf=this['transports_']=[];for(const _0x558c0b of Dt['ALL_TRANSPORTS'])_0x558c0b&&_0x558c0b['isAvailable']()&&_0x127adf['push'](_0x558c0b);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x2a1277,_0x9812d7,_0x582d3e,_0x40867c,_0x64482e,_0x4feb70,_0x9ee934,_0x503ada,_0x16aa67,_0xa1cd3a){this['id']=_0x2a1277,this['repoInfo_']=_0x9812d7,this['applicationId_']=_0x582d3e,this['appCheckToken_']=_0x40867c,this['authToken_']=_0x64482e,this['onMessage_']=_0x4feb70,this['onReady_']=_0x9ee934,this['onDisconnect_']=_0x503ada,this['onKill_']=_0x16aa67,this['lastSessionId']=_0xa1cd3a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x9812d7),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x220be3=this['transportManager_']['initialTransport']();this['conn_']=new _0x220be3(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x220be3['responsesRequiredToBeHealthy']||0x0;const _0x2fe483=this['connReceiver_'](this['conn_']),_0x323a67=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2fe483,_0x323a67);},Math['floor'](0x0));const _0x344171=_0x220be3['healthyTimeout']||0x0;_0x344171>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x344171)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x492a95){return _0x3d2e85=>{_0x492a95===this['conn_']?this['onConnectionLost_'](_0x3d2e85):_0x492a95===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3ad79f){return _0x369b9d=>{this['state_']!==0x2&&(_0x3ad79f===this['rx_']?this['onPrimaryMessageReceived_'](_0x369b9d):_0x3ad79f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x369b9d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2d486e){const _0x41d015={'t':'d','d':_0x2d486e};this['sendData_'](_0x41d015);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x33066e){if(ci in _0x33066e){const _0x461592=_0x33066e[ci];_0x461592===Ys?this['upgradeIfSecondaryHealthy_']():_0x461592===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x461592===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x2dd2cc){const _0x2c5e27=vt('t',_0x2dd2cc),_0x1239be=vt('d',_0x2dd2cc);if(_0x2c5e27==='c')this['onSecondaryControl_'](_0x1239be);else{if(_0x2c5e27==='d')this['pendingDataMessages']['push'](_0x1239be);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x2c5e27);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x446558){const _0x44a05f=vt('t',_0x446558),_0x494332=vt('d',_0x446558);_0x44a05f==='c'?this['onControl_'](_0x494332):_0x44a05f==='d'&&this['onDataMessage_'](_0x494332);}['onDataMessage_'](_0x42ecd4){this['onPrimaryResponse_'](),this['onMessage_'](_0x42ecd4);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5eb78a){const _0x48c7f8=vt(ci,_0x5eb78a);if(zs in _0x5eb78a){const _0x896991=_0x5eb78a[zs];if(_0x48c7f8===Th){const _0x10e4b2={..._0x896991};this['repoInfo_']['isUsingEmulator']&&(_0x10e4b2['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x10e4b2);}else{if(_0x48c7f8===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3d9a8d=0x0;_0x3d9a8d<this['pendingDataMessages']['length'];++_0x3d9a8d)this['onDataMessage_'](this['pendingDataMessages'][_0x3d9a8d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x48c7f8===wh?this['onConnectionShutdown_'](_0x896991):_0x48c7f8===js?this['onReset_'](_0x896991):_0x48c7f8===Ch?Ii('Server\x20Error:\x20'+_0x896991):_0x48c7f8===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x48c7f8);}}}['onHandshake_'](_0x23e5bf){const _0xe655b3=_0x23e5bf['ts'],_0x17c7be=_0x23e5bf['v'],_0x7bcbbf=_0x23e5bf['h'];this['sessionId']=_0x23e5bf['s'],this['repoInfo_']['host']=_0x7bcbbf,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xe655b3),Gi!==_0x17c7be&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x3d0111=this['transportManager_']['upgradeTransport']();_0x3d0111&&this['startUpgrade_'](_0x3d0111);}['startUpgrade_'](_0x323374){this['secondaryConn_']=new _0x323374(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x323374['responsesRequiredToBeHealthy']||0x0;const _0x4c8819=this['connReceiver_'](this['secondaryConn_']),_0x19e555=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4c8819,_0x19e555),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5235db){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5235db),this['repoInfo_']['host']=_0x5235db,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x7c2267,_0x4c52f2){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x7c2267,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4c52f2,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x106f67=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x106f67||this['rx_']===_0x106f67)&&this['close']();}['onConnectionLost_'](_0x58b935){this['conn_']=null,!_0x58b935&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5d96bd){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5d96bd),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x18048e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x18048e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x36c678,_0x42340c,_0x47a072,_0xbfee87){}['merge'](_0x1e8958,_0x38743a,_0x275db5,_0x2f6fb9){}['refreshAuthToken'](_0x59c206){}['refreshAppCheckToken'](_0x4d2472){}['onDisconnectPut'](_0x42c500,_0x3d06a4,_0x38120d){}['onDisconnectMerge'](_0x49ecf5,_0x44cfbd,_0x46f118){}['onDisconnectCancel'](_0x57d139,_0x16617d){}['reportStats'](_0x5443f1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x332756){this['allowedEvents_']=_0x332756,this['listeners_']={},f(Array['isArray'](_0x332756)&&_0x332756['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x467c71,..._0x59bc76){if(Array['isArray'](this['listeners_'][_0x467c71])){const _0xbedd59=[...this['listeners_'][_0x467c71]];for(let _0x5c29da=0x0;_0x5c29da<_0xbedd59['length'];_0x5c29da++)_0xbedd59[_0x5c29da]['callback']['apply'](_0xbedd59[_0x5c29da]['context'],_0x59bc76);}}['on'](_0x3c535c,_0x576a22,_0x466010){this['validateEventType_'](_0x3c535c),this['listeners_'][_0x3c535c]=this['listeners_'][_0x3c535c]||[],this['listeners_'][_0x3c535c]['push']({'callback':_0x576a22,'context':_0x466010});const _0x15f3b0=this['getInitialEvent'](_0x3c535c);_0x15f3b0&&_0x576a22['apply'](_0x466010,_0x15f3b0);}['off'](_0x1aa1d6,_0x5827c1,_0x50a298){this['validateEventType_'](_0x1aa1d6);const _0x5b6da3=this['listeners_'][_0x1aa1d6]||[];for(let _0x5a3536=0x0;_0x5a3536<_0x5b6da3['length'];_0x5a3536++)if(_0x5b6da3[_0x5a3536]['callback']===_0x5827c1&&(!_0x50a298||_0x50a298===_0x5b6da3[_0x5a3536]['context'])){_0x5b6da3['splice'](_0x5a3536,0x1);return;}}['validateEventType_'](_0x5cb859){f(this['allowedEvents_']['find'](_0x567d55=>_0x567d55===_0x5cb859),'Unknown\x20event:\x20'+_0x5cb859);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2e1b4c){return f(_0x2e1b4c==='online','Unknown\x20event\x20type:\x20'+_0x2e1b4c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2e2e06,_0x1033ce){if(_0x1033ce===void 0x0){this['pieces_']=_0x2e2e06['split']('/');let _0x101367=0x0;for(let _0x1fc608=0x0;_0x1fc608<this['pieces_']['length'];_0x1fc608++)this['pieces_'][_0x1fc608]['length']>0x0&&(this['pieces_'][_0x101367]=this['pieces_'][_0x1fc608],_0x101367++);this['pieces_']['length']=_0x101367,this['pieceNum_']=0x0;}else this['pieces_']=_0x2e2e06,this['pieceNum_']=_0x1033ce;}['toString'](){let _0x35596e='';for(let _0x4d2cac=this['pieceNum_'];_0x4d2cac<this['pieces_']['length'];_0x4d2cac++)this['pieces_'][_0x4d2cac]!==''&&(_0x35596e+='/'+this['pieces_'][_0x4d2cac]);return _0x35596e||'/';}}function w(){return new C('');}function y(_0x4668b7){return _0x4668b7['pieceNum_']>=_0x4668b7['pieces_']['length']?null:_0x4668b7['pieces_'][_0x4668b7['pieceNum_']];}function Ce(_0x2f5f2e){return _0x2f5f2e['pieces_']['length']-_0x2f5f2e['pieceNum_'];}function S(_0x34f623){let _0x2fd934=_0x34f623['pieceNum_'];return _0x2fd934<_0x34f623['pieces_']['length']&&_0x2fd934++,new C(_0x34f623['pieces_'],_0x2fd934);}function ji(_0x45d322){return _0x45d322['pieceNum_']<_0x45d322['pieces_']['length']?_0x45d322['pieces_'][_0x45d322['pieces_']['length']-0x1]:null;}function bh(_0x49bd37){let _0x3c7d45='';for(let _0x2091a7=_0x49bd37['pieceNum_'];_0x2091a7<_0x49bd37['pieces_']['length'];_0x2091a7++)_0x49bd37['pieces_'][_0x2091a7]!==''&&(_0x3c7d45+='/'+encodeURIComponent(String(_0x49bd37['pieces_'][_0x2091a7])));return _0x3c7d45||'/';}function Mt(_0x548c8e,_0x279751=0x0){return _0x548c8e['pieces_']['slice'](_0x548c8e['pieceNum_']+_0x279751);}function Ro(_0x5bd166){if(_0x5bd166['pieceNum_']>=_0x5bd166['pieces_']['length'])return null;const _0x79e519=[];for(let _0xbc3e66=_0x5bd166['pieceNum_'];_0xbc3e66<_0x5bd166['pieces_']['length']-0x1;_0xbc3e66++)_0x79e519['push'](_0x5bd166['pieces_'][_0xbc3e66]);return new C(_0x79e519,0x0);}function k(_0x23214c,_0x5a8e5d){const _0x4fecee=[];for(let _0x22be24=_0x23214c['pieceNum_'];_0x22be24<_0x23214c['pieces_']['length'];_0x22be24++)_0x4fecee['push'](_0x23214c['pieces_'][_0x22be24]);if(_0x5a8e5d instanceof C){for(let _0x5c3a91=_0x5a8e5d['pieceNum_'];_0x5c3a91<_0x5a8e5d['pieces_']['length'];_0x5c3a91++)_0x4fecee['push'](_0x5a8e5d['pieces_'][_0x5c3a91]);}else{const _0x59eb29=_0x5a8e5d['split']('/');for(let _0x4b97cd=0x0;_0x4b97cd<_0x59eb29['length'];_0x4b97cd++)_0x59eb29[_0x4b97cd]['length']>0x0&&_0x4fecee['push'](_0x59eb29[_0x4b97cd]);}return new C(_0x4fecee,0x0);}function v(_0xb4ac75){return _0xb4ac75['pieceNum_']>=_0xb4ac75['pieces_']['length'];}function F(_0x438395,_0x470b0a){const _0x354e6f=y(_0x438395),_0x4e736e=y(_0x470b0a);if(_0x354e6f===null)return _0x470b0a;if(_0x354e6f===_0x4e736e)return F(S(_0x438395),S(_0x470b0a));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x470b0a+')\x20is\x20not\x20within\x20outerPath\x20('+_0x438395+')');}function Rh(_0x2531ee,_0x1f08ec){const _0x58d246=Mt(_0x2531ee,0x0),_0x5768d7=Mt(_0x1f08ec,0x0);for(let _0x7dadd5=0x0;_0x7dadd5<_0x58d246['length']&&_0x7dadd5<_0x5768d7['length'];_0x7dadd5++){const _0x5de8f6=qe(_0x58d246[_0x7dadd5],_0x5768d7[_0x7dadd5]);if(_0x5de8f6!==0x0)return _0x5de8f6;}return _0x58d246['length']===_0x5768d7['length']?0x0:_0x58d246['length']<_0x5768d7['length']?-0x1:0x1;}function Ki(_0x105825,_0x1a5f0d){if(Ce(_0x105825)!==Ce(_0x1a5f0d))return!0x1;for(let _0x25dfee=_0x105825['pieceNum_'],_0x26213f=_0x1a5f0d['pieceNum_'];_0x25dfee<=_0x105825['pieces_']['length'];_0x25dfee++,_0x26213f++)if(_0x105825['pieces_'][_0x25dfee]!==_0x1a5f0d['pieces_'][_0x26213f])return!0x1;return!0x0;}function G(_0xf29193,_0x526a7e){let _0x559de0=_0xf29193['pieceNum_'],_0x57b173=_0x526a7e['pieceNum_'];if(Ce(_0xf29193)>Ce(_0x526a7e))return!0x1;for(;_0x559de0<_0xf29193['pieces_']['length'];){if(_0xf29193['pieces_'][_0x559de0]!==_0x526a7e['pieces_'][_0x57b173])return!0x1;++_0x559de0,++_0x57b173;}return!0x0;}class Ah{constructor(_0xc2072d,_0x424ff6){this['errorPrefix_']=_0x424ff6,this['parts_']=Mt(_0xc2072d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x15e116=0x0;_0x15e116<this['parts_']['length'];_0x15e116++)this['byteLength_']+=Ln(this['parts_'][_0x15e116]);Ao(this);}}function kh(_0x24ae71,_0xeec464){_0x24ae71['parts_']['length']>0x0&&(_0x24ae71['byteLength_']+=0x1),_0x24ae71['parts_']['push'](_0xeec464),_0x24ae71['byteLength_']+=Ln(_0xeec464),Ao(_0x24ae71);}function Ph(_0x54f7c4){const _0x367026=_0x54f7c4['parts_']['pop']();_0x54f7c4['byteLength_']-=Ln(_0x367026),_0x54f7c4['parts_']['length']>0x0&&(_0x54f7c4['byteLength_']-=0x1);}function Ao(_0x5d9a05){if(_0x5d9a05['byteLength_']>Zs)throw new Error(_0x5d9a05['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x5d9a05['byteLength_']+').');if(_0x5d9a05['parts_']['length']>Xs)throw new Error(_0x5d9a05['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x5d9a05));}function Oe(_0x33f526){return _0x33f526['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x33f526['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x4671df,_0x154c9f;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x154c9f='visibilitychange',_0x4671df='hidden'):typeof document['mozHidden']<'u'?(_0x154c9f='mozvisibilitychange',_0x4671df='mozHidden'):typeof document['msHidden']<'u'?(_0x154c9f='msvisibilitychange',_0x4671df='msHidden'):typeof document['webkitHidden']<'u'&&(_0x154c9f='webkitvisibilitychange',_0x4671df='webkitHidden')),this['visible_']=!0x0,_0x154c9f&&document['addEventListener'](_0x154c9f,()=>{const _0x461fc4=!document[_0x4671df];_0x461fc4!==this['visible_']&&(this['visible_']=_0x461fc4,this['trigger']('visible',_0x461fc4));},!0x1);}['getInitialEvent'](_0x4caa9f){return f(_0x4caa9f==='visible','Unknown\x20event\x20type:\x20'+_0x4caa9f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x20b0e6,_0x41784a,_0x4abf0a,_0x1d4de3,_0x3adde1,_0x5ca0f3,_0x5bb718,_0x3a7c40){if(super(),this['repoInfo_']=_0x20b0e6,this['applicationId_']=_0x41784a,this['onDataUpdate_']=_0x4abf0a,this['onConnectStatus_']=_0x1d4de3,this['onServerInfoUpdate_']=_0x3adde1,this['authTokenProvider_']=_0x5ca0f3,this['appCheckTokenProvider_']=_0x5bb718,this['authOverride_']=_0x3a7c40,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3a7c40)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x20b0e6['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1ca946,_0x41dae1,_0x344868){const _0x11d112=++this['requestNumber_'],_0x914ca7={'r':_0x11d112,'a':_0x1ca946,'b':_0x41dae1};this['log_'](O(_0x914ca7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x914ca7),_0x344868&&(this['requestCBHash_'][_0x11d112]=_0x344868);}['get'](_0x513195){this['initConnection_']();const _0x403862=new H(),_0x9dad01={'action':'g','request':{'p':_0x513195['_path']['toString'](),'q':_0x513195['_queryObject']},'onComplete':_0x39dc8f=>{const _0xd09041=_0x39dc8f['d'];_0x39dc8f['s']==='ok'?_0x403862['resolve'](_0xd09041):_0x403862['reject'](_0xd09041);}};this['outstandingGets_']['push'](_0x9dad01),this['outstandingGetCount_']++;const _0x5e60e5=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5e60e5),_0x403862['promise'];}['listen'](_0x10fe4c,_0x1aa963,_0x19fb5e,_0x5b96e8){this['initConnection_']();const _0x3af0aa=_0x10fe4c['_queryIdentifier'],_0x245c3a=_0x10fe4c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x245c3a+'\x20'+_0x3af0aa),this['listens']['has'](_0x245c3a)||this['listens']['set'](_0x245c3a,new Map()),f(_0x10fe4c['_queryParams']['isDefault']()||!_0x10fe4c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x245c3a)['has'](_0x3af0aa),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x102918={'onComplete':_0x5b96e8,'hashFn':_0x1aa963,'query':_0x10fe4c,'tag':_0x19fb5e};this['listens']['get'](_0x245c3a)['set'](_0x3af0aa,_0x102918),this['connected_']&&this['sendListen_'](_0x102918);}['sendGet_'](_0x1c24b8){const _0x349494=this['outstandingGets_'][_0x1c24b8];this['sendRequest']('g',_0x349494['request'],_0x40e24f=>{delete this['outstandingGets_'][_0x1c24b8],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x349494['onComplete']&&_0x349494['onComplete'](_0x40e24f);});}['sendListen_'](_0x4d9c66){const _0x1efbf4=_0x4d9c66['query'],_0x4ce6ce=_0x1efbf4['_path']['toString'](),_0x2fae65=_0x1efbf4['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4ce6ce+'\x20for\x20'+_0x2fae65);const _0x370263={'p':_0x4ce6ce},_0x32e6d6='q';_0x4d9c66['tag']&&(_0x370263['q']=_0x1efbf4['_queryObject'],_0x370263['t']=_0x4d9c66['tag']),_0x370263['h']=_0x4d9c66['hashFn'](),this['sendRequest'](_0x32e6d6,_0x370263,_0x3058c7=>{const _0xfdb690=_0x3058c7['d'],_0x566415=_0x3058c7['s'];se['warnOnListenWarnings_'](_0xfdb690,_0x1efbf4),(this['listens']['get'](_0x4ce6ce)&&this['listens']['get'](_0x4ce6ce)['get'](_0x2fae65))===_0x4d9c66&&(this['log_']('listen\x20response',_0x3058c7),_0x566415!=='ok'&&this['removeListen_'](_0x4ce6ce,_0x2fae65),_0x4d9c66['onComplete']&&_0x4d9c66['onComplete'](_0x566415,_0xfdb690));});}static['warnOnListenWarnings_'](_0x445fb8,_0x1a8b58){if(_0x445fb8&&typeof _0x445fb8=='object'&&Q(_0x445fb8,'w')){const _0x4eb4e5=Le(_0x445fb8,'w');if(Array['isArray'](_0x4eb4e5)&&~_0x4eb4e5['indexOf']('no_index')){const _0x64cabd='\x22.indexOn\x22:\x20\x22'+_0x1a8b58['_queryParams']['getIndex']()['toString']()+'\x22',_0x19b3ef=_0x1a8b58['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x64cabd+'\x20at\x20'+_0x19b3ef+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x138c2b){this['authToken_']=_0x138c2b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x138c2b);}['reduceReconnectDelayIfAdminCredential_'](_0xfbebbf){(_0xfbebbf&&_0xfbebbf['length']===0x28||wc(_0xfbebbf))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2c07e9){this['appCheckToken_']=_0x2c07e9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2daf3c=this['authToken_'],_0xd68380=Ic(_0x2daf3c)?'auth':'gauth',_0x61b3cb={'cred':_0x2daf3c};this['authOverride_']===null?_0x61b3cb['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x61b3cb['authvar']=this['authOverride_']),this['sendRequest'](_0xd68380,_0x61b3cb,_0x4b8063=>{const _0x165c70=_0x4b8063['s'],_0x290b26=_0x4b8063['d']||'error';this['authToken_']===_0x2daf3c&&(_0x165c70==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x165c70,_0x290b26));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x15af13=>{const _0x5038fe=_0x15af13['s'],_0x2aedda=_0x15af13['d']||'error';_0x5038fe==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5038fe,_0x2aedda);});}['unlisten'](_0x2eb1b8,_0x4a219e){const _0x20cc03=_0x2eb1b8['_path']['toString'](),_0x24bfd4=_0x2eb1b8['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x20cc03+'\x20'+_0x24bfd4),f(_0x2eb1b8['_queryParams']['isDefault']()||!_0x2eb1b8['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x20cc03,_0x24bfd4)&&this['connected_']&&this['sendUnlisten_'](_0x20cc03,_0x24bfd4,_0x2eb1b8['_queryObject'],_0x4a219e);}['sendUnlisten_'](_0x4ed2e4,_0x30fbe7,_0x3cd2ad,_0x566078){this['log_']('Unlisten\x20on\x20'+_0x4ed2e4+'\x20for\x20'+_0x30fbe7);const _0x15b347={'p':_0x4ed2e4},_0x1a5c2f='n';_0x566078&&(_0x15b347['q']=_0x3cd2ad,_0x15b347['t']=_0x566078),this['sendRequest'](_0x1a5c2f,_0x15b347);}['onDisconnectPut'](_0x4b87d1,_0x4f5bc1,_0xc5bd8e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4b87d1,_0x4f5bc1,_0xc5bd8e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4b87d1,'action':'o','data':_0x4f5bc1,'onComplete':_0xc5bd8e});}['onDisconnectMerge'](_0x4c5bdc,_0x51a492,_0x3cdd65){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4c5bdc,_0x51a492,_0x3cdd65):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4c5bdc,'action':'om','data':_0x51a492,'onComplete':_0x3cdd65});}['onDisconnectCancel'](_0x5aa421,_0x48e646){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5aa421,null,_0x48e646):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5aa421,'action':'oc','data':null,'onComplete':_0x48e646});}['sendOnDisconnect_'](_0x4de0a1,_0x191dd1,_0x454ed6,_0x2f6d90){const _0x1787e5={'p':_0x191dd1,'d':_0x454ed6};this['log_']('onDisconnect\x20'+_0x4de0a1,_0x1787e5),this['sendRequest'](_0x4de0a1,_0x1787e5,_0x5c6fbd=>{_0x2f6d90&&setTimeout(()=>{_0x2f6d90(_0x5c6fbd['s'],_0x5c6fbd['d']);},Math['floor'](0x0));});}['put'](_0x41a29b,_0x43b45e,_0x469be4,_0x40f81c){this['putInternal']('p',_0x41a29b,_0x43b45e,_0x469be4,_0x40f81c);}['merge'](_0x2fe5bf,_0x41ea4c,_0x3ba088,_0x1a8495){this['putInternal']('m',_0x2fe5bf,_0x41ea4c,_0x3ba088,_0x1a8495);}['putInternal'](_0x12cff3,_0x5a04f1,_0xc95738,_0x2c9080,_0xb9a21a){this['initConnection_']();const _0x3fad30={'p':_0x5a04f1,'d':_0xc95738};_0xb9a21a!==void 0x0&&(_0x3fad30['h']=_0xb9a21a),this['outstandingPuts_']['push']({'action':_0x12cff3,'request':_0x3fad30,'onComplete':_0x2c9080}),this['outstandingPutCount_']++;const _0x383fa8=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x383fa8):this['log_']('Buffering\x20put:\x20'+_0x5a04f1);}['sendPut_'](_0x153dc8){const _0x378b1e=this['outstandingPuts_'][_0x153dc8]['action'],_0x10be39=this['outstandingPuts_'][_0x153dc8]['request'],_0x407b24=this['outstandingPuts_'][_0x153dc8]['onComplete'];this['outstandingPuts_'][_0x153dc8]['queued']=this['connected_'],this['sendRequest'](_0x378b1e,_0x10be39,_0x5b7685=>{this['log_'](_0x378b1e+'\x20response',_0x5b7685),delete this['outstandingPuts_'][_0x153dc8],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x407b24&&_0x407b24(_0x5b7685['s'],_0x5b7685['d']);});}['reportStats'](_0x488df3){if(this['connected_']){const _0x42e59d={'c':_0x488df3};this['log_']('reportStats',_0x42e59d),this['sendRequest']('s',_0x42e59d,_0x2ad140=>{if(_0x2ad140['s']!=='ok'){const _0x2b8111=_0x2ad140['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2b8111);}});}}['onDataMessage_'](_0x5b762b){if('r'in _0x5b762b){this['log_']('from\x20server:\x20'+O(_0x5b762b));const _0x3dcb55=_0x5b762b['r'],_0x40e7b4=this['requestCBHash_'][_0x3dcb55];_0x40e7b4&&(delete this['requestCBHash_'][_0x3dcb55],_0x40e7b4(_0x5b762b['b']));}else{if('error'in _0x5b762b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5b762b['error'];'a'in _0x5b762b&&this['onDataPush_'](_0x5b762b['a'],_0x5b762b['b']);}}['onDataPush_'](_0xcf451d,_0x4a7bf5){this['log_']('handleServerMessage',_0xcf451d,_0x4a7bf5),_0xcf451d==='d'?this['onDataUpdate_'](_0x4a7bf5['p'],_0x4a7bf5['d'],!0x1,_0x4a7bf5['t']):_0xcf451d==='m'?this['onDataUpdate_'](_0x4a7bf5['p'],_0x4a7bf5['d'],!0x0,_0x4a7bf5['t']):_0xcf451d==='c'?this['onListenRevoked_'](_0x4a7bf5['p'],_0x4a7bf5['q']):_0xcf451d==='ac'?this['onAuthRevoked_'](_0x4a7bf5['s'],_0x4a7bf5['d']):_0xcf451d==='apc'?this['onAppCheckRevoked_'](_0x4a7bf5['s'],_0x4a7bf5['d']):_0xcf451d==='sd'?this['onSecurityDebugPacket_'](_0x4a7bf5):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xcf451d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4ae61c,_0x16f6c1){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4ae61c),this['lastSessionId']=_0x16f6c1,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4e7aa8){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4e7aa8));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x19e89e){_0x19e89e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x19e89e;}['onOnline_'](_0x363e91){_0x363e91?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x50414c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x513b8d=Math['max'](0x0,this['reconnectDelay_']-_0x50414c);_0x513b8d=Math['random']()*_0x513b8d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x513b8d+'ms'),this['scheduleConnect_'](_0x513b8d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x54f420=this['onDataMessage_']['bind'](this),_0x5a74ce=this['onReady_']['bind'](this),_0x240178=this['onRealtimeDisconnect_']['bind'](this),_0x735417=this['id']+':'+se['nextConnectionId_']++,_0x59dff2=this['lastSessionId'];let _0x3083a5=!0x1,_0x4225fe=null;const _0x11a4a9=function(){_0x4225fe?_0x4225fe['close']():(_0x3083a5=!0x0,_0x240178());},_0x1d8153=function(_0x5d9f69){f(_0x4225fe,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4225fe['sendRequest'](_0x5d9f69);};this['realtime_']={'close':_0x11a4a9,'sendRequest':_0x1d8153};const _0x2ade87=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x29d5b1,_0xe1c62]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2ade87),this['appCheckTokenProvider_']['getToken'](_0x2ade87)]);_0x3083a5?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x29d5b1&&_0x29d5b1['accessToken'],this['appCheckToken_']=_0xe1c62&&_0xe1c62['token'],_0x4225fe=new Sh(_0x735417,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x54f420,_0x5a74ce,_0x240178,_0xefe8d7=>{U(_0xefe8d7+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x59dff2));}catch(_0x44b7f2){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x44b7f2),_0x3083a5||(this['repoInfo_']['nodeAdmin']&&U(_0x44b7f2),_0x11a4a9());}}}['interrupt'](_0x5718fb){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5718fb),this['interruptReasons_'][_0x5718fb]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x128a0b){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x128a0b),delete this['interruptReasons_'][_0x128a0b],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x49bd19){const _0x2290d8=_0x49bd19-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2290d8});}['cancelSentTransactions_'](){for(let _0xdc78e0=0x0;_0xdc78e0<this['outstandingPuts_']['length'];_0xdc78e0++){const _0x4a5ff7=this['outstandingPuts_'][_0xdc78e0];_0x4a5ff7&&'h'in _0x4a5ff7['request']&&_0x4a5ff7['queued']&&(_0x4a5ff7['onComplete']&&_0x4a5ff7['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xdc78e0],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xc35bda,_0x506eea){let _0x35eb39;_0x506eea?_0x35eb39=_0x506eea['map'](_0x49cbfe=>$i(_0x49cbfe))['join']('$'):_0x35eb39='default';const _0x1dbea2=this['removeListen_'](_0xc35bda,_0x35eb39);_0x1dbea2&&_0x1dbea2['onComplete']&&_0x1dbea2['onComplete']('permission_denied');}['removeListen_'](_0x83fa71,_0x3538a9){const _0x11c30a=new C(_0x83fa71)['toString']();let _0x4d73c9;if(this['listens']['has'](_0x11c30a)){const _0x54e7a9=this['listens']['get'](_0x11c30a);_0x4d73c9=_0x54e7a9['get'](_0x3538a9),_0x54e7a9['delete'](_0x3538a9),_0x54e7a9['size']===0x0&&this['listens']['delete'](_0x11c30a);}else _0x4d73c9=void 0x0;return _0x4d73c9;}['onAuthRevoked_'](_0x8c825e,_0x10ceca){L('Auth\x20token\x20revoked:\x20'+_0x8c825e+'/'+_0x10ceca),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x8c825e==='invalid_token'||_0x8c825e==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x200348,_0x514741){L('App\x20check\x20token\x20revoked:\x20'+_0x200348+'/'+_0x514741),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x200348==='invalid_token'||_0x200348==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2a7a4f){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2a7a4f):'msg'in _0x2a7a4f&&console['log']('FIREBASE:\x20'+_0x2a7a4f['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x57b3e8 of this['listens']['values']())for(const _0x44fdb2 of _0x57b3e8['values']())this['sendListen_'](_0x44fdb2);for(let _0x2a51ed=0x0;_0x2a51ed<this['outstandingPuts_']['length'];_0x2a51ed++)this['outstandingPuts_'][_0x2a51ed]&&this['sendPut_'](_0x2a51ed);for(;this['onDisconnectRequestQueue_']['length'];){const _0x54e8fe=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x54e8fe['action'],_0x54e8fe['pathString'],_0x54e8fe['data'],_0x54e8fe['onComplete']);}for(let _0x1009b8=0x0;_0x1009b8<this['outstandingGets_']['length'];_0x1009b8++)this['outstandingGets_'][_0x1009b8]&&this['sendGet_'](_0x1009b8);}['sendConnectStats_'](){const _0x364d3c={};let _0x46e8d6='js';_0x364d3c['sdk.'+_0x46e8d6+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x364d3c['framework.cordova']=0x1:Kr()&&(_0x364d3c['framework.reactnative']=0x1),this['reportStats'](_0x364d3c);}['shouldReconnect_'](){const _0x424bb1=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x424bb1;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3b62ef,_0x5959ce){this['name']=_0x3b62ef,this['node']=_0x5959ce;}static['Wrap'](_0xcb8f6b,_0xd0daec){return new E(_0xcb8f6b,_0xd0daec);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x577ae5,_0x4f25b8){const _0x58a950=new E(We,_0x577ae5),_0x3f5792=new E(We,_0x4f25b8);return this['compare'](_0x58a950,_0x3f5792)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x21f2a2){sn=_0x21f2a2;}['compare'](_0x3aa621,_0x4f9862){return qe(_0x3aa621['name'],_0x4f9862['name']);}['isDefinedOn'](_0x3a8652){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x55032f,_0x371a93){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x173b03,_0x36ecea){return f(typeof _0x173b03=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x173b03,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x5a9b77,_0x201637,_0x4711a3,_0x4f65cc,_0x2606cb=null){this['isReverse_']=_0x4f65cc,this['resultGenerator_']=_0x2606cb,this['nodeStack_']=[];let _0x41894e=0x1;for(;!_0x5a9b77['isEmpty']();)if(_0x5a9b77=_0x5a9b77,_0x41894e=_0x201637?_0x4711a3(_0x5a9b77['key'],_0x201637):0x1,_0x4f65cc&&(_0x41894e*=-0x1),_0x41894e<0x0)this['isReverse_']?_0x5a9b77=_0x5a9b77['left']:_0x5a9b77=_0x5a9b77['right'];else{if(_0x41894e===0x0){this['nodeStack_']['push'](_0x5a9b77);break;}else this['nodeStack_']['push'](_0x5a9b77),this['isReverse_']?_0x5a9b77=_0x5a9b77['right']:_0x5a9b77=_0x5a9b77['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5a06ae=this['nodeStack_']['pop'](),_0x1e0c0a;if(this['resultGenerator_']?_0x1e0c0a=this['resultGenerator_'](_0x5a06ae['key'],_0x5a06ae['value']):_0x1e0c0a={'key':_0x5a06ae['key'],'value':_0x5a06ae['value']},this['isReverse_']){for(_0x5a06ae=_0x5a06ae['left'];!_0x5a06ae['isEmpty']();)this['nodeStack_']['push'](_0x5a06ae),_0x5a06ae=_0x5a06ae['right'];}else{for(_0x5a06ae=_0x5a06ae['right'];!_0x5a06ae['isEmpty']();)this['nodeStack_']['push'](_0x5a06ae),_0x5a06ae=_0x5a06ae['left'];}return _0x1e0c0a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x11299a=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x11299a['key'],_0x11299a['value']):{'key':_0x11299a['key'],'value':_0x11299a['value']};}}class M{constructor(_0x191629,_0x598d34,_0x3b16e4,_0x36cd44,_0x36950e){this['key']=_0x191629,this['value']=_0x598d34,this['color']=_0x3b16e4??M['RED'],this['left']=_0x36cd44??B['EMPTY_NODE'],this['right']=_0x36950e??B['EMPTY_NODE'];}['copy'](_0x34fcc9,_0x1820d1,_0x14ced9,_0x23e8c1,_0x34f014){return new M(_0x34fcc9??this['key'],_0x1820d1??this['value'],_0x14ced9??this['color'],_0x23e8c1??this['left'],_0x34f014??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x556d9c){return this['left']['inorderTraversal'](_0x556d9c)||!!_0x556d9c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x556d9c);}['reverseTraversal'](_0x5a58a3){return this['right']['reverseTraversal'](_0x5a58a3)||_0x5a58a3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5a58a3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x36ae53,_0x3255a8,_0x27e769){let _0x3c48ff=this;const _0x424480=_0x27e769(_0x36ae53,_0x3c48ff['key']);return _0x424480<0x0?_0x3c48ff=_0x3c48ff['copy'](null,null,null,_0x3c48ff['left']['insert'](_0x36ae53,_0x3255a8,_0x27e769),null):_0x424480===0x0?_0x3c48ff=_0x3c48ff['copy'](null,_0x3255a8,null,null,null):_0x3c48ff=_0x3c48ff['copy'](null,null,null,null,_0x3c48ff['right']['insert'](_0x36ae53,_0x3255a8,_0x27e769)),_0x3c48ff['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3bba76=this;return!_0x3bba76['left']['isRed_']()&&!_0x3bba76['left']['left']['isRed_']()&&(_0x3bba76=_0x3bba76['moveRedLeft_']()),_0x3bba76=_0x3bba76['copy'](null,null,null,_0x3bba76['left']['removeMin_'](),null),_0x3bba76['fixUp_']();}['remove'](_0x17aa96,_0x3e6454){let _0x71f7a0,_0x5200a5;if(_0x71f7a0=this,_0x3e6454(_0x17aa96,_0x71f7a0['key'])<0x0)!_0x71f7a0['left']['isEmpty']()&&!_0x71f7a0['left']['isRed_']()&&!_0x71f7a0['left']['left']['isRed_']()&&(_0x71f7a0=_0x71f7a0['moveRedLeft_']()),_0x71f7a0=_0x71f7a0['copy'](null,null,null,_0x71f7a0['left']['remove'](_0x17aa96,_0x3e6454),null);else{if(_0x71f7a0['left']['isRed_']()&&(_0x71f7a0=_0x71f7a0['rotateRight_']()),!_0x71f7a0['right']['isEmpty']()&&!_0x71f7a0['right']['isRed_']()&&!_0x71f7a0['right']['left']['isRed_']()&&(_0x71f7a0=_0x71f7a0['moveRedRight_']()),_0x3e6454(_0x17aa96,_0x71f7a0['key'])===0x0){if(_0x71f7a0['right']['isEmpty']())return B['EMPTY_NODE'];_0x5200a5=_0x71f7a0['right']['min_'](),_0x71f7a0=_0x71f7a0['copy'](_0x5200a5['key'],_0x5200a5['value'],null,null,_0x71f7a0['right']['removeMin_']());}_0x71f7a0=_0x71f7a0['copy'](null,null,null,null,_0x71f7a0['right']['remove'](_0x17aa96,_0x3e6454));}return _0x71f7a0['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x24938d=this;return _0x24938d['right']['isRed_']()&&!_0x24938d['left']['isRed_']()&&(_0x24938d=_0x24938d['rotateLeft_']()),_0x24938d['left']['isRed_']()&&_0x24938d['left']['left']['isRed_']()&&(_0x24938d=_0x24938d['rotateRight_']()),_0x24938d['left']['isRed_']()&&_0x24938d['right']['isRed_']()&&(_0x24938d=_0x24938d['colorFlip_']()),_0x24938d;}['moveRedLeft_'](){let _0x31d781=this['colorFlip_']();return _0x31d781['right']['left']['isRed_']()&&(_0x31d781=_0x31d781['copy'](null,null,null,null,_0x31d781['right']['rotateRight_']()),_0x31d781=_0x31d781['rotateLeft_'](),_0x31d781=_0x31d781['colorFlip_']()),_0x31d781;}['moveRedRight_'](){let _0x4562f5=this['colorFlip_']();return _0x4562f5['left']['left']['isRed_']()&&(_0x4562f5=_0x4562f5['rotateRight_'](),_0x4562f5=_0x4562f5['colorFlip_']()),_0x4562f5;}['rotateLeft_'](){const _0x1701eb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1701eb,null);}['rotateRight_'](){const _0x18d353=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x18d353);}['colorFlip_'](){const _0x14fa12=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4fa11f=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x14fa12,_0x4fa11f);}['checkMaxDepth_'](){const _0x13c73f=this['check_']();return Math['pow'](0x2,_0x13c73f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4aee60=this['left']['check_']();if(_0x4aee60!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4aee60+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x3063b4,_0x46e140,_0x5ac85c,_0x197016,_0x1def60){return this;}['insert'](_0x55044e,_0x48bb5f,_0x2c5dcb){return new M(_0x55044e,_0x48bb5f,null);}['remove'](_0x4ea3a2,_0x5da6b1){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3aaf6a){return!0x1;}['reverseTraversal'](_0x47dd3a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x78880e,_0x504fda=B['EMPTY_NODE']){this['comparator_']=_0x78880e,this['root_']=_0x504fda;}['insert'](_0x5c1a3c,_0x416664){return new B(this['comparator_'],this['root_']['insert'](_0x5c1a3c,_0x416664,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x15a541){return new B(this['comparator_'],this['root_']['remove'](_0x15a541,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4e3da5){let _0x9de1e0,_0x99cb46=this['root_'];for(;!_0x99cb46['isEmpty']();){if(_0x9de1e0=this['comparator_'](_0x4e3da5,_0x99cb46['key']),_0x9de1e0===0x0)return _0x99cb46['value'];_0x9de1e0<0x0?_0x99cb46=_0x99cb46['left']:_0x9de1e0>0x0&&(_0x99cb46=_0x99cb46['right']);}return null;}['getPredecessorKey'](_0x56d4dc){let _0x38f892,_0x23ef78=this['root_'],_0x592806=null;for(;!_0x23ef78['isEmpty']();)if(_0x38f892=this['comparator_'](_0x56d4dc,_0x23ef78['key']),_0x38f892===0x0){if(_0x23ef78['left']['isEmpty']())return _0x592806?_0x592806['key']:null;for(_0x23ef78=_0x23ef78['left'];!_0x23ef78['right']['isEmpty']();)_0x23ef78=_0x23ef78['right'];return _0x23ef78['key'];}else _0x38f892<0x0?_0x23ef78=_0x23ef78['left']:_0x38f892>0x0&&(_0x592806=_0x23ef78,_0x23ef78=_0x23ef78['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xc4fcec){return this['root_']['inorderTraversal'](_0xc4fcec);}['reverseTraversal'](_0x21bac3){return this['root_']['reverseTraversal'](_0x21bac3);}['getIterator'](_0x432869){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x432869);}['getIteratorFrom'](_0x7b7819,_0x53753b){return new rn(this['root_'],_0x7b7819,this['comparator_'],!0x1,_0x53753b);}['getReverseIteratorFrom'](_0x2a41d0,_0x4e13c5){return new rn(this['root_'],_0x2a41d0,this['comparator_'],!0x0,_0x4e13c5);}['getReverseIterator'](_0x58edbf){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x58edbf);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1a8430,_0x84051b){return qe(_0x1a8430['name'],_0x84051b['name']);}function Qi(_0x3e18b9,_0x44c460){return qe(_0x3e18b9,_0x44c460);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x5e53b6){Ci=_0x5e53b6;}const Po=function(_0x2b03be){return typeof _0x2b03be=='number'?'number:'+ao(_0x2b03be):'string:'+_0x2b03be;},No=function(_0x1265bb){if(_0x1265bb['isLeafNode']()){const _0x1ef1e4=_0x1265bb['val']();f(typeof _0x1ef1e4=='string'||typeof _0x1ef1e4=='number'||typeof _0x1ef1e4=='object'&&Q(_0x1ef1e4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1265bb===Ci||_0x1265bb['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1265bb===Ci||_0x1265bb['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x44d9e4){nr=_0x44d9e4;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x119de0,_0x394bd7=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x119de0,this['priorityNode_']=_0x394bd7,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5280f0){return new D(this['value_'],_0x5280f0);}['getImmediateChild'](_0x118639){return _0x118639==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x22c95e){return v(_0x22c95e)?this:y(_0x22c95e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3a84bc,_0x4dfd9c){return null;}['updateImmediateChild'](_0x47694e,_0x47c99b){return _0x47694e==='.priority'?this['updatePriority'](_0x47c99b):_0x47c99b['isEmpty']()&&_0x47694e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x47694e,_0x47c99b)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x53b155,_0x3b5e4d){const _0x47f6f9=y(_0x53b155);return _0x47f6f9===null?_0x3b5e4d:_0x3b5e4d['isEmpty']()&&_0x47f6f9!=='.priority'?this:(f(_0x47f6f9!=='.priority'||Ce(_0x53b155)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x47f6f9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x53b155),_0x3b5e4d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x42a4e0,_0x4645fc){return!0x1;}['val'](_0x287ced){return _0x287ced&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5337cc='';this['priorityNode_']['isEmpty']()||(_0x5337cc+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3249df=typeof this['value_'];_0x5337cc+=_0x3249df+':',_0x3249df==='number'?_0x5337cc+=ao(this['value_']):_0x5337cc+=this['value_'],this['lazyHash_']=ro(_0x5337cc);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x58661a){return _0x58661a===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x58661a instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x58661a['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x58661a));}['compareToLeafNode_'](_0x2e6a80){const _0x32ed99=typeof _0x2e6a80['value_'],_0x1b1e25=typeof this['value_'],_0x12ebaf=D['VALUE_TYPE_ORDER']['indexOf'](_0x32ed99),_0x37fee2=D['VALUE_TYPE_ORDER']['indexOf'](_0x1b1e25);return f(_0x12ebaf>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x32ed99),f(_0x37fee2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1b1e25),_0x12ebaf===_0x37fee2?_0x1b1e25==='object'?0x0:this['value_']<_0x2e6a80['value_']?-0x1:this['value_']===_0x2e6a80['value_']?0x0:0x1:_0x37fee2-_0x12ebaf;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5bc07a){if(_0x5bc07a===this)return!0x0;if(_0x5bc07a['isLeafNode']()){const _0x5d0b1a=_0x5bc07a;return this['value_']===_0x5d0b1a['value_']&&this['priorityNode_']['equals'](_0x5d0b1a['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x313d7c){Oo=_0x313d7c;}function Wh(_0x46eee1){Do=_0x46eee1;}class Bh extends Fn{['compare'](_0x56e8a0,_0x44f000){const _0x3ef558=_0x56e8a0['node']['getPriority'](),_0x3d2644=_0x44f000['node']['getPriority'](),_0x282cb4=_0x3ef558['compareTo'](_0x3d2644);return _0x282cb4===0x0?qe(_0x56e8a0['name'],_0x44f000['name']):_0x282cb4;}['isDefinedOn'](_0x5f4dd6){return!_0x5f4dd6['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x21a81a,_0xa4204d){return!_0x21a81a['getPriority']()['equals'](_0xa4204d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x524efb,_0x13a9e2){const _0x4ce8f5=Oo(_0x524efb);return new E(_0x13a9e2,new D('[PRIORITY-POST]',_0x4ce8f5));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5be1c1){const _0x3b2778=_0xddf3f=>parseInt(Math['log'](_0xddf3f)/Vh,0xa),_0x29891f=_0x4ad0c1=>parseInt(Array(_0x4ad0c1+0x1)['join']('1'),0x2);this['count']=_0x3b2778(_0x5be1c1+0x1),this['current_']=this['count']-0x1;const _0x53f1c7=_0x29891f(this['count']);this['bits_']=_0x5be1c1+0x1&_0x53f1c7;}['nextBitIsOne'](){const _0x3d85ad=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3d85ad;}}const yn=function(_0x5d1506,_0x50edab,_0x5cecbb,_0x1018c9){_0x5d1506['sort'](_0x50edab);const _0x1424b0=function(_0x37ee58,_0x5b5277){const _0x4472c8=_0x5b5277-_0x37ee58;let _0x5718a0,_0x7f8cc1;if(_0x4472c8===0x0)return null;if(_0x4472c8===0x1)return _0x5718a0=_0x5d1506[_0x37ee58],_0x7f8cc1=_0x5cecbb?_0x5cecbb(_0x5718a0):_0x5718a0,new M(_0x7f8cc1,_0x5718a0['node'],M['BLACK'],null,null);{const _0x4545ea=parseInt(_0x4472c8/0x2,0xa)+_0x37ee58,_0x8878e8=_0x1424b0(_0x37ee58,_0x4545ea),_0x1ffc28=_0x1424b0(_0x4545ea+0x1,_0x5b5277);return _0x5718a0=_0x5d1506[_0x4545ea],_0x7f8cc1=_0x5cecbb?_0x5cecbb(_0x5718a0):_0x5718a0,new M(_0x7f8cc1,_0x5718a0['node'],M['BLACK'],_0x8878e8,_0x1ffc28);}},_0x5ec75f=function(_0x562908){let _0x3c5bf9=null,_0x595783=null,_0x23a9ee=_0x5d1506['length'];const _0x445e38=function(_0x47a269,_0x376936){const _0x5343df=_0x23a9ee-_0x47a269,_0x2745dd=_0x23a9ee;_0x23a9ee-=_0x47a269;const _0x110457=_0x1424b0(_0x5343df+0x1,_0x2745dd),_0x37a0f7=_0x5d1506[_0x5343df],_0x24e0d0=_0x5cecbb?_0x5cecbb(_0x37a0f7):_0x37a0f7;_0xdc0caa(new M(_0x24e0d0,_0x37a0f7['node'],_0x376936,null,_0x110457));},_0xdc0caa=function(_0x363c32){_0x3c5bf9?(_0x3c5bf9['left']=_0x363c32,_0x3c5bf9=_0x363c32):(_0x595783=_0x363c32,_0x3c5bf9=_0x363c32);};for(let _0x5a4f53=0x0;_0x5a4f53<_0x562908['count'];++_0x5a4f53){const _0x359826=_0x562908['nextBitIsOne'](),_0x1f4a5f=Math['pow'](0x2,_0x562908['count']-(_0x5a4f53+0x1));_0x359826?_0x445e38(_0x1f4a5f,M['BLACK']):(_0x445e38(_0x1f4a5f,M['BLACK']),_0x445e38(_0x1f4a5f,M['RED']));}return _0x595783;},_0x2c4adb=new Hh(_0x5d1506['length']),_0x568cf4=_0x5ec75f(_0x2c4adb);return new B(_0x1018c9||_0x50edab,_0x568cf4);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x2fca05,_0xd9a058){this['indexes_']=_0x2fca05,this['indexSet_']=_0xd9a058;}['get'](_0x426218){const _0x1dc936=Le(this['indexes_'],_0x426218);if(!_0x1dc936)throw new Error('No\x20index\x20defined\x20for\x20'+_0x426218);return _0x1dc936 instanceof B?_0x1dc936:null;}['hasIndex'](_0x2e0761){return Q(this['indexSet_'],_0x2e0761['toString']());}['addIndex'](_0x4603f2,_0x596672){f(_0x4603f2!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x35378d=[];let _0x30ccef=!0x1;const _0x20d89d=_0x596672['getIterator'](E['Wrap']);let _0xb54675=_0x20d89d['getNext']();for(;_0xb54675;)_0x30ccef=_0x30ccef||_0x4603f2['isDefinedOn'](_0xb54675['node']),_0x35378d['push'](_0xb54675),_0xb54675=_0x20d89d['getNext']();let _0x108720;_0x30ccef?_0x108720=yn(_0x35378d,_0x4603f2['getCompare']()):_0x108720=Qe;const _0x3a27cf=_0x4603f2['toString'](),_0x42203b={...this['indexSet_']};_0x42203b[_0x3a27cf]=_0x4603f2;const _0x483774={...this['indexes_']};return _0x483774[_0x3a27cf]=_0x108720,new te(_0x483774,_0x42203b);}['addToIndexes'](_0x11775d,_0x3a920d){const _0x407e53=_n(this['indexes_'],(_0x52fc50,_0x45c950)=>{const _0x52331a=Le(this['indexSet_'],_0x45c950);if(f(_0x52331a,'Missing\x20index\x20implementation\x20for\x20'+_0x45c950),_0x52fc50===Qe){if(_0x52331a['isDefinedOn'](_0x11775d['node'])){const _0x1dab3f=[],_0x1ef6ab=_0x3a920d['getIterator'](E['Wrap']);let _0x30979d=_0x1ef6ab['getNext']();for(;_0x30979d;)_0x30979d['name']!==_0x11775d['name']&&_0x1dab3f['push'](_0x30979d),_0x30979d=_0x1ef6ab['getNext']();return _0x1dab3f['push'](_0x11775d),yn(_0x1dab3f,_0x52331a['getCompare']());}else return Qe;}else{const _0x1279a3=_0x3a920d['get'](_0x11775d['name']);let _0x433fda=_0x52fc50;return _0x1279a3&&(_0x433fda=_0x433fda['remove'](new E(_0x11775d['name'],_0x1279a3))),_0x433fda['insert'](_0x11775d,_0x11775d['node']);}});return new te(_0x407e53,this['indexSet_']);}['removeFromIndexes'](_0x5cdcdd,_0x17f394){const _0x23902c=_n(this['indexes_'],_0x1d7332=>{if(_0x1d7332===Qe)return _0x1d7332;{const _0x14e086=_0x17f394['get'](_0x5cdcdd['name']);return _0x14e086?_0x1d7332['remove'](new E(_0x5cdcdd['name'],_0x14e086)):_0x1d7332;}});return new te(_0x23902c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0xf0581a,_0x215b8d,_0xacf631){this['children_']=_0xf0581a,this['priorityNode_']=_0x215b8d,this['indexMap_']=_0xacf631,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x29d08e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x29d08e,this['indexMap_']);}['getImmediateChild'](_0x3ef11f){if(_0x3ef11f==='.priority')return this['getPriority']();{const _0x240b8f=this['children_']['get'](_0x3ef11f);return _0x240b8f===null?It:_0x240b8f;}}['getChild'](_0x1abb03){const _0x389823=y(_0x1abb03);return _0x389823===null?this:this['getImmediateChild'](_0x389823)['getChild'](S(_0x1abb03));}['hasChild'](_0x503e30){return this['children_']['get'](_0x503e30)!==null;}['updateImmediateChild'](_0x3feec5,_0x253521){if(f(_0x253521,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3feec5==='.priority')return this['updatePriority'](_0x253521);{const _0x1377fb=new E(_0x3feec5,_0x253521);let _0x4a68d7,_0x3679f8;_0x253521['isEmpty']()?(_0x4a68d7=this['children_']['remove'](_0x3feec5),_0x3679f8=this['indexMap_']['removeFromIndexes'](_0x1377fb,this['children_'])):(_0x4a68d7=this['children_']['insert'](_0x3feec5,_0x253521),_0x3679f8=this['indexMap_']['addToIndexes'](_0x1377fb,this['children_']));const _0x180db4=_0x4a68d7['isEmpty']()?It:this['priorityNode_'];return new g(_0x4a68d7,_0x180db4,_0x3679f8);}}['updateChild'](_0x102850,_0x42d6eb){const _0x2cb0d3=y(_0x102850);if(_0x2cb0d3===null)return _0x42d6eb;{f(y(_0x102850)!=='.priority'||Ce(_0x102850)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5166d5=this['getImmediateChild'](_0x2cb0d3)['updateChild'](S(_0x102850),_0x42d6eb);return this['updateImmediateChild'](_0x2cb0d3,_0x5166d5);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x6953ad){if(this['isEmpty']())return null;const _0x3333dc={};let _0x325e10=0x0,_0x2a7f4f=0x0,_0x5e4ebd=!0x0;if(this['forEachChild'](R,(_0x12d0ff,_0x2ef56b)=>{_0x3333dc[_0x12d0ff]=_0x2ef56b['val'](_0x6953ad),_0x325e10++,_0x5e4ebd&&g['INTEGER_REGEXP_']['test'](_0x12d0ff)?_0x2a7f4f=Math['max'](_0x2a7f4f,Number(_0x12d0ff)):_0x5e4ebd=!0x1;}),!_0x6953ad&&_0x5e4ebd&&_0x2a7f4f<0x2*_0x325e10){const _0xb48731=[];for(const _0x1b75ec in _0x3333dc)_0xb48731[_0x1b75ec]=_0x3333dc[_0x1b75ec];return _0xb48731;}else return _0x6953ad&&!this['getPriority']()['isEmpty']()&&(_0x3333dc['.priority']=this['getPriority']()['val']()),_0x3333dc;}['hash'](){if(this['lazyHash_']===null){let _0x104a71='';this['getPriority']()['isEmpty']()||(_0x104a71+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5df604,_0x5ada89)=>{const _0x224cd7=_0x5ada89['hash']();_0x224cd7!==''&&(_0x104a71+=':'+_0x5df604+':'+_0x224cd7);}),this['lazyHash_']=_0x104a71===''?'':ro(_0x104a71);}return this['lazyHash_'];}['getPredecessorChildName'](_0xf8b2e6,_0x1c741a,_0x232c65){const _0x59271d=this['resolveIndex_'](_0x232c65);if(_0x59271d){const _0x4bab9d=_0x59271d['getPredecessorKey'](new E(_0xf8b2e6,_0x1c741a));return _0x4bab9d?_0x4bab9d['name']:null;}else return this['children_']['getPredecessorKey'](_0xf8b2e6);}['getFirstChildName'](_0x278b4e){const _0x22dbc7=this['resolveIndex_'](_0x278b4e);if(_0x22dbc7){const _0x19ff98=_0x22dbc7['minKey']();return _0x19ff98&&_0x19ff98['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x18b170){const _0x336c1b=this['getFirstChildName'](_0x18b170);return _0x336c1b?new E(_0x336c1b,this['children_']['get'](_0x336c1b)):null;}['getLastChildName'](_0x3ea521){const _0x195ada=this['resolveIndex_'](_0x3ea521);if(_0x195ada){const _0x6dae6e=_0x195ada['maxKey']();return _0x6dae6e&&_0x6dae6e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x10d8d0){const _0x4f739f=this['getLastChildName'](_0x10d8d0);return _0x4f739f?new E(_0x4f739f,this['children_']['get'](_0x4f739f)):null;}['forEachChild'](_0x1ca330,_0x717972){const _0x2b3880=this['resolveIndex_'](_0x1ca330);return _0x2b3880?_0x2b3880['inorderTraversal'](_0xd0442f=>_0x717972(_0xd0442f['name'],_0xd0442f['node'])):this['children_']['inorderTraversal'](_0x717972);}['getIterator'](_0x5cf891){return this['getIteratorFrom'](_0x5cf891['minPost'](),_0x5cf891);}['getIteratorFrom'](_0x3d5909,_0x49296a){const _0x19755d=this['resolveIndex_'](_0x49296a);if(_0x19755d)return _0x19755d['getIteratorFrom'](_0x3d5909,_0x4abc90=>_0x4abc90);{const _0x57c019=this['children_']['getIteratorFrom'](_0x3d5909['name'],E['Wrap']);let _0x423392=_0x57c019['peek']();for(;_0x423392!=null&&_0x49296a['compare'](_0x423392,_0x3d5909)<0x0;)_0x57c019['getNext'](),_0x423392=_0x57c019['peek']();return _0x57c019;}}['getReverseIterator'](_0x5bb50f){return this['getReverseIteratorFrom'](_0x5bb50f['maxPost'](),_0x5bb50f);}['getReverseIteratorFrom'](_0x9ec62a,_0x11b51c){const _0x1fb9f2=this['resolveIndex_'](_0x11b51c);if(_0x1fb9f2)return _0x1fb9f2['getReverseIteratorFrom'](_0x9ec62a,_0x3a220d=>_0x3a220d);{const _0x32715f=this['children_']['getReverseIteratorFrom'](_0x9ec62a['name'],E['Wrap']);let _0x563398=_0x32715f['peek']();for(;_0x563398!=null&&_0x11b51c['compare'](_0x563398,_0x9ec62a)>0x0;)_0x32715f['getNext'](),_0x563398=_0x32715f['peek']();return _0x32715f;}}['compareTo'](_0x5a4c80){return this['isEmpty']()?_0x5a4c80['isEmpty']()?0x0:-0x1:_0x5a4c80['isLeafNode']()||_0x5a4c80['isEmpty']()?0x1:_0x5a4c80===Kt?-0x1:0x0;}['withIndex'](_0x2e8c1f){if(_0x2e8c1f===ve||this['indexMap_']['hasIndex'](_0x2e8c1f))return this;{const _0x36d3db=this['indexMap_']['addIndex'](_0x2e8c1f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x36d3db);}}['isIndexed'](_0x536934){return _0x536934===ve||this['indexMap_']['hasIndex'](_0x536934);}['equals'](_0x3bb55f){if(_0x3bb55f===this)return!0x0;if(_0x3bb55f['isLeafNode']())return!0x1;{const _0x393d5d=_0x3bb55f;if(this['getPriority']()['equals'](_0x393d5d['getPriority']())){if(this['children_']['count']()===_0x393d5d['children_']['count']()){const _0x23aaca=this['getIterator'](R),_0x309c14=_0x393d5d['getIterator'](R);let _0x44825b=_0x23aaca['getNext'](),_0x269734=_0x309c14['getNext']();for(;_0x44825b&&_0x269734;){if(_0x44825b['name']!==_0x269734['name']||!_0x44825b['node']['equals'](_0x269734['node']))return!0x1;_0x44825b=_0x23aaca['getNext'](),_0x269734=_0x309c14['getNext']();}return _0x44825b===null&&_0x269734===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x23e5ae){return _0x23e5ae===ve?null:this['indexMap_']['get'](_0x23e5ae['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x526a94){return _0x526a94===this?0x0:0x1;}['equals'](_0x58d354){return _0x58d354===this;}['getPriority'](){return this;}['getImmediateChild'](_0x340090){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x298be9,_0x561687=null){if(_0x298be9===null)return g['EMPTY_NODE'];if(typeof _0x298be9=='object'&&'.priority'in _0x298be9&&(_0x561687=_0x298be9['.priority']),f(_0x561687===null||typeof _0x561687=='string'||typeof _0x561687=='number'||typeof _0x561687=='object'&&'.sv'in _0x561687,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x561687),typeof _0x298be9=='object'&&'.value'in _0x298be9&&_0x298be9['.value']!==null&&(_0x298be9=_0x298be9['.value']),typeof _0x298be9!='object'||'.sv'in _0x298be9){const _0x4899f4=_0x298be9;return new D(_0x4899f4,A(_0x561687));}if(!(_0x298be9 instanceof Array)&&Gh){const _0x302161=[];let _0x209205=!0x1;if(x(_0x298be9,(_0x35a998,_0x200f0b)=>{if(_0x35a998['substring'](0x0,0x1)!=='.'){const _0x1017fe=A(_0x200f0b);_0x1017fe['isEmpty']()||(_0x209205=_0x209205||!_0x1017fe['getPriority']()['isEmpty'](),_0x302161['push'](new E(_0x35a998,_0x1017fe)));}}),_0x302161['length']===0x0)return g['EMPTY_NODE'];const _0x4b1f62=yn(_0x302161,xh,_0x5b4691=>_0x5b4691['name'],Qi);if(_0x209205){const _0x2046f3=yn(_0x302161,R['getCompare']());return new g(_0x4b1f62,A(_0x561687),new te({'.priority':_0x2046f3},{'.priority':R}));}else return new g(_0x4b1f62,A(_0x561687),te['Default']);}else{let _0x516ca4=g['EMPTY_NODE'];return x(_0x298be9,(_0x3f22e5,_0x1a2e54)=>{if(Q(_0x298be9,_0x3f22e5)&&_0x3f22e5['substring'](0x0,0x1)!=='.'){const _0x1b263f=A(_0x1a2e54);(_0x1b263f['isLeafNode']()||!_0x1b263f['isEmpty']())&&(_0x516ca4=_0x516ca4['updateImmediateChild'](_0x3f22e5,_0x1b263f));}}),_0x516ca4['updatePriority'](A(_0x561687));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x558f3c){super(),this['indexPath_']=_0x558f3c,f(!v(_0x558f3c)&&y(_0x558f3c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5613db){return _0x5613db['getChild'](this['indexPath_']);}['isDefinedOn'](_0x19027c){return!_0x19027c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2158b8,_0xaf12e3){const _0x505b16=this['extractChild'](_0x2158b8['node']),_0x188728=this['extractChild'](_0xaf12e3['node']),_0x30d911=_0x505b16['compareTo'](_0x188728);return _0x30d911===0x0?qe(_0x2158b8['name'],_0xaf12e3['name']):_0x30d911;}['makePost'](_0xdccf35,_0x400b23){const _0x28ac7d=A(_0xdccf35),_0x12fd5e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x28ac7d);return new E(_0x400b23,_0x12fd5e);}['maxPost'](){const _0x4842c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4842c);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x5a0a8b,_0x97cf65){const _0x3dc9ab=_0x5a0a8b['node']['compareTo'](_0x97cf65['node']);return _0x3dc9ab===0x0?qe(_0x5a0a8b['name'],_0x97cf65['name']):_0x3dc9ab;}['isDefinedOn'](_0x1bd406){return!0x0;}['indexedValueChanged'](_0x266183,_0x5e991c){return!_0x266183['equals'](_0x5e991c);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1e998e,_0x123e9e){const _0x50fb0b=A(_0x1e998e);return new E(_0x123e9e,_0x50fb0b);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x5d2db9){return{'type':'value','snapshotNode':_0x5d2db9};}function rt(_0xb18c34,_0x15ac3f){return{'type':'child_added','snapshotNode':_0x15ac3f,'childName':_0xb18c34};}function Lt(_0xbd9315,_0x4e288e){return{'type':'child_removed','snapshotNode':_0x4e288e,'childName':_0xbd9315};}function xt(_0x33c795,_0x542526,_0x158fd9){return{'type':'child_changed','snapshotNode':_0x542526,'childName':_0x33c795,'oldSnap':_0x158fd9};}function zh(_0x384dca,_0x3f43d8){return{'type':'child_moved','snapshotNode':_0x3f43d8,'childName':_0x384dca};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x47d765){this['index_']=_0x47d765;}['updateChild'](_0x19ecc0,_0x469480,_0x2bbd27,_0x3ffd8f,_0x165b06,_0x591472){f(_0x19ecc0['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2dd624=_0x19ecc0['getImmediateChild'](_0x469480);return _0x2dd624['getChild'](_0x3ffd8f)['equals'](_0x2bbd27['getChild'](_0x3ffd8f))&&_0x2dd624['isEmpty']()===_0x2bbd27['isEmpty']()||(_0x591472!=null&&(_0x2bbd27['isEmpty']()?_0x19ecc0['hasChild'](_0x469480)?_0x591472['trackChildChange'](Lt(_0x469480,_0x2dd624)):f(_0x19ecc0['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2dd624['isEmpty']()?_0x591472['trackChildChange'](rt(_0x469480,_0x2bbd27)):_0x591472['trackChildChange'](xt(_0x469480,_0x2bbd27,_0x2dd624))),_0x19ecc0['isLeafNode']()&&_0x2bbd27['isEmpty']())?_0x19ecc0:_0x19ecc0['updateImmediateChild'](_0x469480,_0x2bbd27)['withIndex'](this['index_']);}['updateFullNode'](_0x166720,_0x39f484,_0x3131bd){return _0x3131bd!=null&&(_0x166720['isLeafNode']()||_0x166720['forEachChild'](R,(_0xf24b08,_0x104222)=>{_0x39f484['hasChild'](_0xf24b08)||_0x3131bd['trackChildChange'](Lt(_0xf24b08,_0x104222));}),_0x39f484['isLeafNode']()||_0x39f484['forEachChild'](R,(_0x24683b,_0x20e91a)=>{if(_0x166720['hasChild'](_0x24683b)){const _0x2487b2=_0x166720['getImmediateChild'](_0x24683b);_0x2487b2['equals'](_0x20e91a)||_0x3131bd['trackChildChange'](xt(_0x24683b,_0x20e91a,_0x2487b2));}else _0x3131bd['trackChildChange'](rt(_0x24683b,_0x20e91a));})),_0x39f484['withIndex'](this['index_']);}['updatePriority'](_0x2d3ff6,_0x3063d5){return _0x2d3ff6['isEmpty']()?g['EMPTY_NODE']:_0x2d3ff6['updatePriority'](_0x3063d5);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x11bb36){this['indexedFilter_']=new Xi(_0x11bb36['getIndex']()),this['index_']=_0x11bb36['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x11bb36),this['endPost_']=Ft['getEndPost_'](_0x11bb36),this['startIsInclusive_']=!_0x11bb36['startAfterSet_'],this['endIsInclusive_']=!_0x11bb36['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3df2aa){const _0x224c96=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3df2aa)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3df2aa)<0x0,_0x37a70d=this['endIsInclusive_']?this['index_']['compare'](_0x3df2aa,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3df2aa,this['getEndPost']())<0x0;return _0x224c96&&_0x37a70d;}['updateChild'](_0x1e96f5,_0x5f52ff,_0x33753d,_0xf9f053,_0x493dc5,_0x33d5ea){return this['matches'](new E(_0x5f52ff,_0x33753d))||(_0x33753d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1e96f5,_0x5f52ff,_0x33753d,_0xf9f053,_0x493dc5,_0x33d5ea);}['updateFullNode'](_0x1ffadb,_0x45eefb,_0xd6b9bd){_0x45eefb['isLeafNode']()&&(_0x45eefb=g['EMPTY_NODE']);let _0x5e253f=_0x45eefb['withIndex'](this['index_']);_0x5e253f=_0x5e253f['updatePriority'](g['EMPTY_NODE']);const _0x4e9d2d=this;return _0x45eefb['forEachChild'](R,(_0x2941b1,_0x25f624)=>{_0x4e9d2d['matches'](new E(_0x2941b1,_0x25f624))||(_0x5e253f=_0x5e253f['updateImmediateChild'](_0x2941b1,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1ffadb,_0x5e253f,_0xd6b9bd);}['updatePriority'](_0x1d6e2c,_0x3e8b55){return _0x1d6e2c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x295a7b){if(_0x295a7b['hasStart']()){const _0x1aab43=_0x295a7b['getIndexStartName']();return _0x295a7b['getIndex']()['makePost'](_0x295a7b['getIndexStartValue'](),_0x1aab43);}else return _0x295a7b['getIndex']()['minPost']();}static['getEndPost_'](_0x16dd7e){if(_0x16dd7e['hasEnd']()){const _0x297d13=_0x16dd7e['getIndexEndName']();return _0x16dd7e['getIndex']()['makePost'](_0x16dd7e['getIndexEndValue'](),_0x297d13);}else return _0x16dd7e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x440fb1){this['withinDirectionalStart']=_0xc15f57=>this['reverse_']?this['withinEndPost'](_0xc15f57):this['withinStartPost'](_0xc15f57),this['withinDirectionalEnd']=_0x4515c4=>this['reverse_']?this['withinStartPost'](_0x4515c4):this['withinEndPost'](_0x4515c4),this['withinStartPost']=_0x3cc470=>{const _0x937b94=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3cc470);return this['startIsInclusive_']?_0x937b94<=0x0:_0x937b94<0x0;},this['withinEndPost']=_0x511a37=>{const _0x37ae7f=this['index_']['compare'](_0x511a37,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x37ae7f<=0x0:_0x37ae7f<0x0;},this['rangedFilter_']=new Ft(_0x440fb1),this['index_']=_0x440fb1['getIndex'](),this['limit_']=_0x440fb1['getLimit'](),this['reverse_']=!_0x440fb1['isViewFromLeft'](),this['startIsInclusive_']=!_0x440fb1['startAfterSet_'],this['endIsInclusive_']=!_0x440fb1['endBeforeSet_'];}['updateChild'](_0x269d0d,_0x56ade4,_0x40541f,_0x2f2f69,_0x47f32e,_0x1799a0){return this['rangedFilter_']['matches'](new E(_0x56ade4,_0x40541f))||(_0x40541f=g['EMPTY_NODE']),_0x269d0d['getImmediateChild'](_0x56ade4)['equals'](_0x40541f)?_0x269d0d:_0x269d0d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x269d0d,_0x56ade4,_0x40541f,_0x2f2f69,_0x47f32e,_0x1799a0):this['fullLimitUpdateChild_'](_0x269d0d,_0x56ade4,_0x40541f,_0x47f32e,_0x1799a0);}['updateFullNode'](_0x5d1afb,_0x501d97,_0x110ae3){let _0x254cf6;if(_0x501d97['isLeafNode']()||_0x501d97['isEmpty']())_0x254cf6=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x501d97['numChildren']()&&_0x501d97['isIndexed'](this['index_'])){_0x254cf6=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5f1928;this['reverse_']?_0x5f1928=_0x501d97['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5f1928=_0x501d97['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5d7c2c=0x0;for(;_0x5f1928['hasNext']()&&_0x5d7c2c<this['limit_'];){const _0x2a63b=_0x5f1928['getNext']();if(this['withinDirectionalStart'](_0x2a63b)){if(this['withinDirectionalEnd'](_0x2a63b))_0x254cf6=_0x254cf6['updateImmediateChild'](_0x2a63b['name'],_0x2a63b['node']),_0x5d7c2c++;else break;}else continue;}}else{_0x254cf6=_0x501d97['withIndex'](this['index_']),_0x254cf6=_0x254cf6['updatePriority'](g['EMPTY_NODE']);let _0x284cd2;this['reverse_']?_0x284cd2=_0x254cf6['getReverseIterator'](this['index_']):_0x284cd2=_0x254cf6['getIterator'](this['index_']);let _0x1eb879=0x0;for(;_0x284cd2['hasNext']();){const _0x5cc576=_0x284cd2['getNext']();_0x1eb879<this['limit_']&&this['withinDirectionalStart'](_0x5cc576)&&this['withinDirectionalEnd'](_0x5cc576)?_0x1eb879++:_0x254cf6=_0x254cf6['updateImmediateChild'](_0x5cc576['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5d1afb,_0x254cf6,_0x110ae3);}['updatePriority'](_0x3d1348,_0x3abe13){return _0x3d1348;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2d508d,_0x3565b5,_0xb6459e,_0x5c0d8e,_0x1e28ef){let _0x30b8eb;if(this['reverse_']){const _0x462f6e=this['index_']['getCompare']();_0x30b8eb=(_0x3de0d9,_0x10ade0)=>_0x462f6e(_0x10ade0,_0x3de0d9);}else _0x30b8eb=this['index_']['getCompare']();const _0x2a1636=_0x2d508d;f(_0x2a1636['numChildren']()===this['limit_'],'');const _0x266943=new E(_0x3565b5,_0xb6459e),_0x131116=this['reverse_']?_0x2a1636['getFirstChild'](this['index_']):_0x2a1636['getLastChild'](this['index_']),_0x1256c8=this['rangedFilter_']['matches'](_0x266943);if(_0x2a1636['hasChild'](_0x3565b5)){const _0x3e185a=_0x2a1636['getImmediateChild'](_0x3565b5);let _0x259f6d=_0x5c0d8e['getChildAfterChild'](this['index_'],_0x131116,this['reverse_']);for(;_0x259f6d!=null&&(_0x259f6d['name']===_0x3565b5||_0x2a1636['hasChild'](_0x259f6d['name']));)_0x259f6d=_0x5c0d8e['getChildAfterChild'](this['index_'],_0x259f6d,this['reverse_']);const _0x278874=_0x259f6d==null?0x1:_0x30b8eb(_0x259f6d,_0x266943);if(_0x1256c8&&!_0xb6459e['isEmpty']()&&_0x278874>=0x0)return _0x1e28ef!=null&&_0x1e28ef['trackChildChange'](xt(_0x3565b5,_0xb6459e,_0x3e185a)),_0x2a1636['updateImmediateChild'](_0x3565b5,_0xb6459e);{_0x1e28ef!=null&&_0x1e28ef['trackChildChange'](Lt(_0x3565b5,_0x3e185a));const _0xa04f04=_0x2a1636['updateImmediateChild'](_0x3565b5,g['EMPTY_NODE']);return _0x259f6d!=null&&this['rangedFilter_']['matches'](_0x259f6d)?(_0x1e28ef!=null&&_0x1e28ef['trackChildChange'](rt(_0x259f6d['name'],_0x259f6d['node'])),_0xa04f04['updateImmediateChild'](_0x259f6d['name'],_0x259f6d['node'])):_0xa04f04;}}else return _0xb6459e['isEmpty']()?_0x2d508d:_0x1256c8&&_0x30b8eb(_0x131116,_0x266943)>=0x0?(_0x1e28ef!=null&&(_0x1e28ef['trackChildChange'](Lt(_0x131116['name'],_0x131116['node'])),_0x1e28ef['trackChildChange'](rt(_0x3565b5,_0xb6459e))),_0x2a1636['updateImmediateChild'](_0x3565b5,_0xb6459e)['updateImmediateChild'](_0x131116['name'],g['EMPTY_NODE'])):_0x2d508d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5e2c53=new Zi();return _0x5e2c53['limitSet_']=this['limitSet_'],_0x5e2c53['limit_']=this['limit_'],_0x5e2c53['startSet_']=this['startSet_'],_0x5e2c53['startAfterSet_']=this['startAfterSet_'],_0x5e2c53['indexStartValue_']=this['indexStartValue_'],_0x5e2c53['startNameSet_']=this['startNameSet_'],_0x5e2c53['indexStartName_']=this['indexStartName_'],_0x5e2c53['endSet_']=this['endSet_'],_0x5e2c53['endBeforeSet_']=this['endBeforeSet_'],_0x5e2c53['indexEndValue_']=this['indexEndValue_'],_0x5e2c53['endNameSet_']=this['endNameSet_'],_0x5e2c53['indexEndName_']=this['indexEndName_'],_0x5e2c53['index_']=this['index_'],_0x5e2c53['viewFrom_']=this['viewFrom_'],_0x5e2c53;}}function Kh(_0x50f7fb){return _0x50f7fb['loadsAllData']()?new Xi(_0x50f7fb['getIndex']()):_0x50f7fb['hasLimit']()?new jh(_0x50f7fb):new Ft(_0x50f7fb);}function Yh(_0x20535c,_0x3d1ac8){const _0xe64a8=_0x20535c['copy']();return _0xe64a8['limitSet_']=!0x0,_0xe64a8['limit_']=_0x3d1ac8,_0xe64a8['viewFrom_']='l',_0xe64a8;}function Qh(_0x1e38d8,_0x3a9807,_0x5e99e6){const _0x2969a9=_0x1e38d8['copy']();return _0x2969a9['startSet_']=!0x0,_0x3a9807===void 0x0&&(_0x3a9807=null),_0x2969a9['indexStartValue_']=_0x3a9807,_0x5e99e6!=null?(_0x2969a9['startNameSet_']=!0x0,_0x2969a9['indexStartName_']=_0x5e99e6):(_0x2969a9['startNameSet_']=!0x1,_0x2969a9['indexStartName_']=''),_0x2969a9;}function Jh(_0x582b54,_0x591a51,_0xc22022){const _0x11a4c7=_0x582b54['copy']();return _0x11a4c7['endSet_']=!0x0,_0x591a51===void 0x0&&(_0x591a51=null),_0x11a4c7['indexEndValue_']=_0x591a51,_0xc22022!==void 0x0?(_0x11a4c7['endNameSet_']=!0x0,_0x11a4c7['indexEndName_']=_0xc22022):(_0x11a4c7['endNameSet_']=!0x1,_0x11a4c7['indexEndName_']=''),_0x11a4c7;}function xo(_0x551c3f,_0x535872){const _0x2d38e6=_0x551c3f['copy']();return _0x2d38e6['index_']=_0x535872,_0x2d38e6;}function ir(_0x46c6f3){const _0x4bdf74={};if(_0x46c6f3['isDefault']())return _0x4bdf74;let _0x40806f;if(_0x46c6f3['index_']===R?_0x40806f='$priority':_0x46c6f3['index_']===Mo?_0x40806f='$value':_0x46c6f3['index_']===ve?_0x40806f='$key':(f(_0x46c6f3['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x40806f=_0x46c6f3['index_']['toString']()),_0x4bdf74['orderBy']=O(_0x40806f),_0x46c6f3['startSet_']){const _0x4d5927=_0x46c6f3['startAfterSet_']?'startAfter':'startAt';_0x4bdf74[_0x4d5927]=O(_0x46c6f3['indexStartValue_']),_0x46c6f3['startNameSet_']&&(_0x4bdf74[_0x4d5927]+=','+O(_0x46c6f3['indexStartName_']));}if(_0x46c6f3['endSet_']){const _0x59f5e1=_0x46c6f3['endBeforeSet_']?'endBefore':'endAt';_0x4bdf74[_0x59f5e1]=O(_0x46c6f3['indexEndValue_']),_0x46c6f3['endNameSet_']&&(_0x4bdf74[_0x59f5e1]+=','+O(_0x46c6f3['indexEndName_']));}return _0x46c6f3['limitSet_']&&(_0x46c6f3['isViewFromLeft']()?_0x4bdf74['limitToFirst']=_0x46c6f3['limit_']:_0x4bdf74['limitToLast']=_0x46c6f3['limit_']),_0x4bdf74;}function sr(_0x5cf776){const _0x2f0207={};if(_0x5cf776['startSet_']&&(_0x2f0207['sp']=_0x5cf776['indexStartValue_'],_0x5cf776['startNameSet_']&&(_0x2f0207['sn']=_0x5cf776['indexStartName_']),_0x2f0207['sin']=!_0x5cf776['startAfterSet_']),_0x5cf776['endSet_']&&(_0x2f0207['ep']=_0x5cf776['indexEndValue_'],_0x5cf776['endNameSet_']&&(_0x2f0207['en']=_0x5cf776['indexEndName_']),_0x2f0207['ein']=!_0x5cf776['endBeforeSet_']),_0x5cf776['limitSet_']){_0x2f0207['l']=_0x5cf776['limit_'];let _0x5be4e5=_0x5cf776['viewFrom_'];_0x5be4e5===''&&(_0x5cf776['isViewFromLeft']()?_0x5be4e5='l':_0x5be4e5='r'),_0x2f0207['vf']=_0x5be4e5;}return _0x5cf776['index_']!==R&&(_0x2f0207['i']=_0x5cf776['index_']['toString']()),_0x2f0207;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x17b766){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x416836,_0x527d09){return _0x527d09!==void 0x0?'tag$'+_0x527d09:(f(_0x416836['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x416836['_path']['toString']());}constructor(_0x55454a,_0x94fa3e,_0x261003,_0x3fbc9d){super(),this['repoInfo_']=_0x55454a,this['onDataUpdate_']=_0x94fa3e,this['authTokenProvider_']=_0x261003,this['appCheckTokenProvider_']=_0x3fbc9d,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x122853,_0x4db6c9,_0x407a0b,_0x6e5ad0){const _0x2d92d2=_0x122853['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2d92d2+'\x20'+_0x122853['_queryIdentifier']);const _0x36c5ab=vn['getListenId_'](_0x122853,_0x407a0b),_0x20af42={};this['listens_'][_0x36c5ab]=_0x20af42;const _0x455d97=ir(_0x122853['_queryParams']);this['restRequest_'](_0x2d92d2+'.json',_0x455d97,(_0x4c129b,_0xfe1b90)=>{let _0x379b0b=_0xfe1b90;if(_0x4c129b===0x194&&(_0x379b0b=null,_0x4c129b=null),_0x4c129b===null&&this['onDataUpdate_'](_0x2d92d2,_0x379b0b,!0x1,_0x407a0b),Le(this['listens_'],_0x36c5ab)===_0x20af42){let _0x4d4f94;_0x4c129b?_0x4c129b===0x191?_0x4d4f94='permission_denied':_0x4d4f94='rest_error:'+_0x4c129b:_0x4d4f94='ok',_0x6e5ad0(_0x4d4f94,null);}});}['unlisten'](_0x20291d,_0x76de24){const _0x3dba44=vn['getListenId_'](_0x20291d,_0x76de24);delete this['listens_'][_0x3dba44];}['get'](_0x1ed970){const _0x4a23c8=ir(_0x1ed970['_queryParams']),_0x58029a=_0x1ed970['_path']['toString'](),_0x48a397=new H();return this['restRequest_'](_0x58029a+'.json',_0x4a23c8,(_0x5a8c79,_0x14e9f9)=>{let _0x413ca9=_0x14e9f9;_0x5a8c79===0x194&&(_0x413ca9=null,_0x5a8c79=null),_0x5a8c79===null?(this['onDataUpdate_'](_0x58029a,_0x413ca9,!0x1,null),_0x48a397['resolve'](_0x413ca9)):_0x48a397['reject'](new Error(_0x413ca9));}),_0x48a397['promise'];}['refreshAuthToken'](_0x1b8748){}['restRequest_'](_0x2ee63f,_0x18938a={},_0x2dd715){return _0x18938a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2ffe9f,_0x1e4d2f])=>{_0x2ffe9f&&_0x2ffe9f['accessToken']&&(_0x18938a['auth']=_0x2ffe9f['accessToken']),_0x1e4d2f&&_0x1e4d2f['token']&&(_0x18938a['ac']=_0x1e4d2f['token']);const _0x125c2f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2ee63f+'?ns='+this['repoInfo_']['namespace']+ut(_0x18938a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x125c2f);const _0x3875f8=new XMLHttpRequest();_0x3875f8['onreadystatechange']=()=>{if(_0x2dd715&&_0x3875f8['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x125c2f+'\x20received.\x20status:',_0x3875f8['status'],'response:',_0x3875f8['responseText']);let _0x504220=null;if(_0x3875f8['status']>=0xc8&&_0x3875f8['status']<0x12c){try{_0x504220=Nt(_0x3875f8['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x125c2f+':\x20'+_0x3875f8['responseText']);}_0x2dd715(null,_0x504220);}else _0x3875f8['status']!==0x191&&_0x3875f8['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x125c2f+'\x20Status:\x20'+_0x3875f8['status']),_0x2dd715(_0x3875f8['status']);_0x2dd715=null;}},_0x3875f8['open']('GET',_0x125c2f,!0x0),_0x3875f8['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1ab266){return this['rootNode_']['getChild'](_0x1ab266);}['updateSnapshot'](_0x456a1b,_0x12d8a3){this['rootNode_']=this['rootNode_']['updateChild'](_0x456a1b,_0x12d8a3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x1ea404,_0x311159,_0x3c2cc0){if(v(_0x311159))_0x1ea404['value']=_0x3c2cc0,_0x1ea404['children']['clear']();else{if(_0x1ea404['value']!==null)_0x1ea404['value']=_0x1ea404['value']['updateChild'](_0x311159,_0x3c2cc0);else{const _0x303a72=y(_0x311159);_0x1ea404['children']['has'](_0x303a72)||_0x1ea404['children']['set'](_0x303a72,En());const _0x719cb8=_0x1ea404['children']['get'](_0x303a72);_0x311159=S(_0x311159),pt(_0x719cb8,_0x311159,_0x3c2cc0);}}}function Ti(_0x46ce6f,_0x38e2b0){if(v(_0x38e2b0))return _0x46ce6f['value']=null,_0x46ce6f['children']['clear'](),!0x0;if(_0x46ce6f['value']!==null){if(_0x46ce6f['value']['isLeafNode']())return!0x1;{const _0x1f87a9=_0x46ce6f['value'];return _0x46ce6f['value']=null,_0x1f87a9['forEachChild'](R,(_0x4bea9b,_0x2217f2)=>{pt(_0x46ce6f,new C(_0x4bea9b),_0x2217f2);}),Ti(_0x46ce6f,_0x38e2b0);}}else{if(_0x46ce6f['children']['size']>0x0){const _0x444efc=y(_0x38e2b0);return _0x38e2b0=S(_0x38e2b0),_0x46ce6f['children']['has'](_0x444efc)&&Ti(_0x46ce6f['children']['get'](_0x444efc),_0x38e2b0)&&_0x46ce6f['children']['delete'](_0x444efc),_0x46ce6f['children']['size']===0x0;}else return!0x0;}}function Si(_0x352a17,_0x3a85d7,_0x220c12){_0x352a17['value']!==null?_0x220c12(_0x3a85d7,_0x352a17['value']):Zh(_0x352a17,(_0x13e55e,_0x4e477d)=>{const _0x5f397b=new C(_0x3a85d7['toString']()+'/'+_0x13e55e);Si(_0x4e477d,_0x5f397b,_0x220c12);});}function Zh(_0x36fdc7,_0x1e2367){_0x36fdc7['children']['forEach']((_0x39a491,_0xc62810)=>{_0x1e2367(_0xc62810,_0x39a491);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0xd50d0b){this['collection_']=_0xd50d0b,this['last_']=null;}['get'](){const _0x303543=this['collection_']['get'](),_0x39040c={..._0x303543};return this['last_']&&x(this['last_'],(_0x2f690b,_0x5a52dd)=>{_0x39040c[_0x2f690b]=_0x39040c[_0x2f690b]-_0x5a52dd;}),this['last_']=_0x303543,_0x39040c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x2d4247,_0x48bad1){this['server_']=_0x48bad1,this['statsToReport_']={},this['statsListener_']=new eu(_0x2d4247);const _0x4df97d=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x4df97d));}['reportStats_'](){const _0x36c013=this['statsListener_']['get'](),_0x36167c={};let _0x15afdf=!0x1;x(_0x36c013,(_0x2e0080,_0x462f98)=>{_0x462f98>0x0&&Q(this['statsToReport_'],_0x2e0080)&&(_0x36167c[_0x2e0080]=_0x462f98,_0x15afdf=!0x0);}),_0x15afdf&&this['server_']['reportStats'](_0x36167c),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x5eaeef){_0x5eaeef[_0x5eaeef['OVERWRITE']=0x0]='OVERWRITE',_0x5eaeef[_0x5eaeef['MERGE']=0x1]='MERGE',_0x5eaeef[_0x5eaeef['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5eaeef[_0x5eaeef['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4afc51){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4afc51,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x2a4a6c,_0x7365ee,_0x5638cc){this['path']=_0x2a4a6c,this['affectedTree']=_0x7365ee,this['revert']=_0x5638cc,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1e4458){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1482ce=this['affectedTree']['subtree'](new C(_0x1e4458));return new In(w(),_0x1482ce,this['revert']);}}else return f(y(this['path'])===_0x1e4458,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x596070,_0x275b3c){this['source']=_0x596070,this['path']=_0x275b3c,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3e54f8){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x1ee03a,_0xb16bef,_0x5d02ab){this['source']=_0x1ee03a,this['path']=_0xb16bef,this['snap']=_0x5d02ab,this['type']=z['OVERWRITE'];}['operationForChild'](_0x4f411d){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x4f411d)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x56d07c,_0x13de5d,_0x4e252f){this['source']=_0x56d07c,this['path']=_0x13de5d,this['children']=_0x4e252f,this['type']=z['MERGE'];}['operationForChild'](_0x8a3598){if(v(this['path'])){const _0x499d7a=this['children']['subtree'](new C(_0x8a3598));return _0x499d7a['isEmpty']()?null:_0x499d7a['value']?new Be(this['source'],w(),_0x499d7a['value']):new ot(this['source'],w(),_0x499d7a);}else return f(y(this['path'])===_0x8a3598,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x5b9551,_0x47a445,_0x1f6628){this['node_']=_0x5b9551,this['fullyInitialized_']=_0x47a445,this['filtered_']=_0x1f6628;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x39014b){if(v(_0x39014b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3adba7=y(_0x39014b);return this['isCompleteForChild'](_0x3adba7);}['isCompleteForChild'](_0x49fee5){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x49fee5);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3522d8){this['query_']=_0x3522d8,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xca04bf,_0x3c9f9a,_0x1b08c4,_0x393b89){const _0x4ebdee=[],_0x2720b2=[];return _0x3c9f9a['forEach'](_0x8fbdbc=>{_0x8fbdbc['type']==='child_changed'&&_0xca04bf['index_']['indexedValueChanged'](_0x8fbdbc['oldSnap'],_0x8fbdbc['snapshotNode'])&&_0x2720b2['push'](zh(_0x8fbdbc['childName'],_0x8fbdbc['snapshotNode']));}),wt(_0xca04bf,_0x4ebdee,'child_removed',_0x3c9f9a,_0x393b89,_0x1b08c4),wt(_0xca04bf,_0x4ebdee,'child_added',_0x3c9f9a,_0x393b89,_0x1b08c4),wt(_0xca04bf,_0x4ebdee,'child_moved',_0x2720b2,_0x393b89,_0x1b08c4),wt(_0xca04bf,_0x4ebdee,'child_changed',_0x3c9f9a,_0x393b89,_0x1b08c4),wt(_0xca04bf,_0x4ebdee,'value',_0x3c9f9a,_0x393b89,_0x1b08c4),_0x4ebdee;}function wt(_0x4f16ef,_0x1662f8,_0x45d827,_0x37f354,_0x391841,_0x5bfa1a){const _0x4d3f7c=_0x37f354['filter'](_0x584f68=>_0x584f68['type']===_0x45d827);_0x4d3f7c['sort']((_0x327821,_0x233754)=>au(_0x4f16ef,_0x327821,_0x233754)),_0x4d3f7c['forEach'](_0x15eb20=>{const _0x5816cf=ou(_0x4f16ef,_0x15eb20,_0x5bfa1a);_0x391841['forEach'](_0x5e550b=>{_0x5e550b['respondsTo'](_0x15eb20['type'])&&_0x1662f8['push'](_0x5e550b['createEvent'](_0x5816cf,_0x4f16ef['query_']));});});}function ou(_0x297093,_0x1de04f,_0x12ba42){return _0x1de04f['type']==='value'||_0x1de04f['type']==='child_removed'||(_0x1de04f['prevName']=_0x12ba42['getPredecessorChildName'](_0x1de04f['childName'],_0x1de04f['snapshotNode'],_0x297093['index_'])),_0x1de04f;}function au(_0x59925a,_0x1f7bea,_0x3b2f68){if(_0x1f7bea['childName']==null||_0x3b2f68['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x5e602c=new E(_0x1f7bea['childName'],_0x1f7bea['snapshotNode']),_0x511c1b=new E(_0x3b2f68['childName'],_0x3b2f68['snapshotNode']);return _0x59925a['index_']['compare'](_0x5e602c,_0x511c1b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x510fa9,_0x2ff0d7){return{'eventCache':_0x510fa9,'serverCache':_0x2ff0d7};}function Rt(_0x1268a3,_0x30aef5,_0x4be6e6,_0x500d23){return Un(new Te(_0x30aef5,_0x4be6e6,_0x500d23),_0x1268a3['serverCache']);}function Fo(_0x13b87b,_0x935249,_0x5ed38c,_0x40170d){return Un(_0x13b87b['eventCache'],new Te(_0x935249,_0x5ed38c,_0x40170d));}function wn(_0x34b741){return _0x34b741['eventCache']['isFullyInitialized']()?_0x34b741['eventCache']['getNode']():null;}function Ve(_0x547bfe){return _0x547bfe['serverCache']['isFullyInitialized']()?_0x547bfe['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2ca64f){let _0x123c8f=new b(null);return x(_0x2ca64f,(_0x2b45da,_0x2c044f)=>{_0x123c8f=_0x123c8f['set'](new C(_0x2b45da),_0x2c044f);}),_0x123c8f;}constructor(_0x38104e,_0x27a168=cu()){this['value']=_0x38104e,this['children']=_0x27a168;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5dce97,_0x235d2c){if(this['value']!=null&&_0x235d2c(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5dce97))return null;{const _0x506568=y(_0x5dce97),_0x215da8=this['children']['get'](_0x506568);if(_0x215da8!==null){const _0x34dc96=_0x215da8['findRootMostMatchingPathAndValue'](S(_0x5dce97),_0x235d2c);return _0x34dc96!=null?{'path':k(new C(_0x506568),_0x34dc96['path']),'value':_0x34dc96['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x52f636){return this['findRootMostMatchingPathAndValue'](_0x52f636,()=>!0x0);}['subtree'](_0xda52db){if(v(_0xda52db))return this;{const _0x21e4ba=y(_0xda52db),_0x555f56=this['children']['get'](_0x21e4ba);return _0x555f56!==null?_0x555f56['subtree'](S(_0xda52db)):new b(null);}}['set'](_0x3a0018,_0x5021ba){if(v(_0x3a0018))return new b(_0x5021ba,this['children']);{const _0x31f7b2=y(_0x3a0018),_0x392f7c=(this['children']['get'](_0x31f7b2)||new b(null))['set'](S(_0x3a0018),_0x5021ba),_0x38d22e=this['children']['insert'](_0x31f7b2,_0x392f7c);return new b(this['value'],_0x38d22e);}}['remove'](_0xdcc651){if(v(_0xdcc651))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x351723=y(_0xdcc651),_0xfece86=this['children']['get'](_0x351723);if(_0xfece86){const _0x404fca=_0xfece86['remove'](S(_0xdcc651));let _0x31c13a;return _0x404fca['isEmpty']()?_0x31c13a=this['children']['remove'](_0x351723):_0x31c13a=this['children']['insert'](_0x351723,_0x404fca),this['value']===null&&_0x31c13a['isEmpty']()?new b(null):new b(this['value'],_0x31c13a);}else return this;}}['get'](_0x493039){if(v(_0x493039))return this['value'];{const _0x31cbff=y(_0x493039),_0x155c82=this['children']['get'](_0x31cbff);return _0x155c82?_0x155c82['get'](S(_0x493039)):null;}}['setTree'](_0x4f3b83,_0x5212f5){if(v(_0x4f3b83))return _0x5212f5;{const _0x4f1110=y(_0x4f3b83),_0x38bb3f=(this['children']['get'](_0x4f1110)||new b(null))['setTree'](S(_0x4f3b83),_0x5212f5);let _0x2d40a4;return _0x38bb3f['isEmpty']()?_0x2d40a4=this['children']['remove'](_0x4f1110):_0x2d40a4=this['children']['insert'](_0x4f1110,_0x38bb3f),new b(this['value'],_0x2d40a4);}}['fold'](_0x31080e){return this['fold_'](w(),_0x31080e);}['fold_'](_0x3ada4f,_0x390a44){const _0x6b758a={};return this['children']['inorderTraversal']((_0x200d84,_0xcd4b76)=>{_0x6b758a[_0x200d84]=_0xcd4b76['fold_'](k(_0x3ada4f,_0x200d84),_0x390a44);}),_0x390a44(_0x3ada4f,this['value'],_0x6b758a);}['findOnPath'](_0x44bf60,_0x1b55ff){return this['findOnPath_'](_0x44bf60,w(),_0x1b55ff);}['findOnPath_'](_0x3ec1a4,_0x33d936,_0x4d345f){const _0x2c562c=this['value']?_0x4d345f(_0x33d936,this['value']):!0x1;if(_0x2c562c)return _0x2c562c;if(v(_0x3ec1a4))return null;{const _0x24601b=y(_0x3ec1a4),_0x274eaa=this['children']['get'](_0x24601b);return _0x274eaa?_0x274eaa['findOnPath_'](S(_0x3ec1a4),k(_0x33d936,_0x24601b),_0x4d345f):null;}}['foreachOnPath'](_0xd1bae0,_0x2f9fc4){return this['foreachOnPath_'](_0xd1bae0,w(),_0x2f9fc4);}['foreachOnPath_'](_0x27e83a,_0x1a630a,_0x117537){if(v(_0x27e83a))return this;{this['value']&&_0x117537(_0x1a630a,this['value']);const _0x4b5986=y(_0x27e83a),_0x448303=this['children']['get'](_0x4b5986);return _0x448303?_0x448303['foreachOnPath_'](S(_0x27e83a),k(_0x1a630a,_0x4b5986),_0x117537):new b(null);}}['foreach'](_0x1fa077){this['foreach_'](w(),_0x1fa077);}['foreach_'](_0x243b0a,_0x3aeecf){this['children']['inorderTraversal']((_0x3f61f4,_0x1b9450)=>{_0x1b9450['foreach_'](k(_0x243b0a,_0x3f61f4),_0x3aeecf);}),this['value']&&_0x3aeecf(_0x243b0a,this['value']);}['foreachChild'](_0x3af905){this['children']['inorderTraversal']((_0x54a7a9,_0x4c0a19)=>{_0x4c0a19['value']&&_0x3af905(_0x54a7a9,_0x4c0a19['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x398848){this['writeTree_']=_0x398848;}static['empty'](){return new K(new b(null));}}function At(_0x3b1060,_0x2266af,_0x23d68f){if(v(_0x2266af))return new K(new b(_0x23d68f));{const _0x13423c=_0x3b1060['writeTree_']['findRootMostValueAndPath'](_0x2266af);if(_0x13423c!=null){const _0x3237e5=_0x13423c['path'];let _0x377578=_0x13423c['value'];const _0x18e3ea=F(_0x3237e5,_0x2266af);return _0x377578=_0x377578['updateChild'](_0x18e3ea,_0x23d68f),new K(_0x3b1060['writeTree_']['set'](_0x3237e5,_0x377578));}else{const _0x33aca8=new b(_0x23d68f),_0x479185=_0x3b1060['writeTree_']['setTree'](_0x2266af,_0x33aca8);return new K(_0x479185);}}}function bi(_0x311c66,_0x2d7dff,_0x4764d7){let _0x478e97=_0x311c66;return x(_0x4764d7,(_0x30a12c,_0x58d61a)=>{_0x478e97=At(_0x478e97,k(_0x2d7dff,_0x30a12c),_0x58d61a);}),_0x478e97;}function or(_0x70f9ea,_0x3e80cc){if(v(_0x3e80cc))return K['empty']();{const _0x2ba4b3=_0x70f9ea['writeTree_']['setTree'](_0x3e80cc,new b(null));return new K(_0x2ba4b3);}}function Ri(_0x4ca7f4,_0x56e67d){return ze(_0x4ca7f4,_0x56e67d)!=null;}function ze(_0x169201,_0x34d402){const _0x4b396c=_0x169201['writeTree_']['findRootMostValueAndPath'](_0x34d402);return _0x4b396c!=null?_0x169201['writeTree_']['get'](_0x4b396c['path'])['getChild'](F(_0x4b396c['path'],_0x34d402)):null;}function ar(_0x4b1a98){const _0x391d79=[],_0x1a844d=_0x4b1a98['writeTree_']['value'];return _0x1a844d!=null?_0x1a844d['isLeafNode']()||_0x1a844d['forEachChild'](R,(_0x311a06,_0x2c9421)=>{_0x391d79['push'](new E(_0x311a06,_0x2c9421));}):_0x4b1a98['writeTree_']['children']['inorderTraversal']((_0x4ef64c,_0x4963cb)=>{_0x4963cb['value']!=null&&_0x391d79['push'](new E(_0x4ef64c,_0x4963cb['value']));}),_0x391d79;}function Ee(_0x42fa0e,_0x16bfbb){if(v(_0x16bfbb))return _0x42fa0e;{const _0x187d0f=ze(_0x42fa0e,_0x16bfbb);return _0x187d0f!=null?new K(new b(_0x187d0f)):new K(_0x42fa0e['writeTree_']['subtree'](_0x16bfbb));}}function Ai(_0x338a45){return _0x338a45['writeTree_']['isEmpty']();}function at(_0x428c0b,_0x123c40){return Uo(w(),_0x428c0b['writeTree_'],_0x123c40);}function Uo(_0x1bc421,_0x1f8877,_0x180086){if(_0x1f8877['value']!=null)return _0x180086['updateChild'](_0x1bc421,_0x1f8877['value']);{let _0x59bb8d=null;return _0x1f8877['children']['inorderTraversal']((_0x10bb60,_0x36928c)=>{_0x10bb60==='.priority'?(f(_0x36928c['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x59bb8d=_0x36928c['value']):_0x180086=Uo(k(_0x1bc421,_0x10bb60),_0x36928c,_0x180086);}),!_0x180086['getChild'](_0x1bc421)['isEmpty']()&&_0x59bb8d!==null&&(_0x180086=_0x180086['updateChild'](k(_0x1bc421,'.priority'),_0x59bb8d)),_0x180086;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1c583e,_0x20c6e2){return Ho(_0x20c6e2,_0x1c583e);}function lu(_0x4c4ecd,_0x2f54b3,_0x3b712b,_0x3447ba,_0x455370){f(_0x3447ba>_0x4c4ecd['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x455370===void 0x0&&(_0x455370=!0x0),_0x4c4ecd['allWrites']['push']({'path':_0x2f54b3,'snap':_0x3b712b,'writeId':_0x3447ba,'visible':_0x455370}),_0x455370&&(_0x4c4ecd['visibleWrites']=At(_0x4c4ecd['visibleWrites'],_0x2f54b3,_0x3b712b)),_0x4c4ecd['lastWriteId']=_0x3447ba;}function hu(_0x2a2924,_0x42b1c8,_0x2208b0,_0xb4228a){f(_0xb4228a>_0x2a2924['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2a2924['allWrites']['push']({'path':_0x42b1c8,'children':_0x2208b0,'writeId':_0xb4228a,'visible':!0x0}),_0x2a2924['visibleWrites']=bi(_0x2a2924['visibleWrites'],_0x42b1c8,_0x2208b0),_0x2a2924['lastWriteId']=_0xb4228a;}function uu(_0x40304a,_0x2e8805){for(let _0x2e61de=0x0;_0x2e61de<_0x40304a['allWrites']['length'];_0x2e61de++){const _0x964926=_0x40304a['allWrites'][_0x2e61de];if(_0x964926['writeId']===_0x2e8805)return _0x964926;}return null;}function du(_0x4374d4,_0x4475ce){const _0x469c47=_0x4374d4['allWrites']['findIndex'](_0xb1f50c=>_0xb1f50c['writeId']===_0x4475ce);f(_0x469c47>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5a64b7=_0x4374d4['allWrites'][_0x469c47];_0x4374d4['allWrites']['splice'](_0x469c47,0x1);let _0x3013be=_0x5a64b7['visible'],_0x952e91=!0x1,_0x8baf3f=_0x4374d4['allWrites']['length']-0x1;for(;_0x3013be&&_0x8baf3f>=0x0;){const _0x481ab9=_0x4374d4['allWrites'][_0x8baf3f];_0x481ab9['visible']&&(_0x8baf3f>=_0x469c47&&fu(_0x481ab9,_0x5a64b7['path'])?_0x3013be=!0x1:G(_0x5a64b7['path'],_0x481ab9['path'])&&(_0x952e91=!0x0)),_0x8baf3f--;}if(_0x3013be){if(_0x952e91)return pu(_0x4374d4),!0x0;if(_0x5a64b7['snap'])_0x4374d4['visibleWrites']=or(_0x4374d4['visibleWrites'],_0x5a64b7['path']);else{const _0x124a16=_0x5a64b7['children'];x(_0x124a16,_0xcf681f=>{_0x4374d4['visibleWrites']=or(_0x4374d4['visibleWrites'],k(_0x5a64b7['path'],_0xcf681f));});}return!0x0;}else return!0x1;}function fu(_0x1c535e,_0x5aec89){if(_0x1c535e['snap'])return G(_0x1c535e['path'],_0x5aec89);for(const _0xf6fd76 in _0x1c535e['children'])if(_0x1c535e['children']['hasOwnProperty'](_0xf6fd76)&&G(k(_0x1c535e['path'],_0xf6fd76),_0x5aec89))return!0x0;return!0x1;}function pu(_0x36cf0c){_0x36cf0c['visibleWrites']=Wo(_0x36cf0c['allWrites'],_u,w()),_0x36cf0c['allWrites']['length']>0x0?_0x36cf0c['lastWriteId']=_0x36cf0c['allWrites'][_0x36cf0c['allWrites']['length']-0x1]['writeId']:_0x36cf0c['lastWriteId']=-0x1;}function _u(_0x3afc4c){return _0x3afc4c['visible'];}function Wo(_0x1bde2b,_0x59dc49,_0x105dd5){let _0x5ba983=K['empty']();for(let _0x344906=0x0;_0x344906<_0x1bde2b['length'];++_0x344906){const _0x59600c=_0x1bde2b[_0x344906];if(_0x59dc49(_0x59600c)){const _0x24ba34=_0x59600c['path'];let _0x4a14c5;if(_0x59600c['snap'])G(_0x105dd5,_0x24ba34)?(_0x4a14c5=F(_0x105dd5,_0x24ba34),_0x5ba983=At(_0x5ba983,_0x4a14c5,_0x59600c['snap'])):G(_0x24ba34,_0x105dd5)&&(_0x4a14c5=F(_0x24ba34,_0x105dd5),_0x5ba983=At(_0x5ba983,w(),_0x59600c['snap']['getChild'](_0x4a14c5)));else{if(_0x59600c['children']){if(G(_0x105dd5,_0x24ba34))_0x4a14c5=F(_0x105dd5,_0x24ba34),_0x5ba983=bi(_0x5ba983,_0x4a14c5,_0x59600c['children']);else{if(G(_0x24ba34,_0x105dd5)){if(_0x4a14c5=F(_0x24ba34,_0x105dd5),v(_0x4a14c5))_0x5ba983=bi(_0x5ba983,w(),_0x59600c['children']);else{const _0x47c20f=Le(_0x59600c['children'],y(_0x4a14c5));if(_0x47c20f){const _0xdd87cc=_0x47c20f['getChild'](S(_0x4a14c5));_0x5ba983=At(_0x5ba983,w(),_0xdd87cc);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5ba983;}function Bo(_0x232d5f,_0x4c1e97,_0x29f446,_0x1d2813,_0xc7f95a){if(!_0x1d2813&&!_0xc7f95a){const _0x354e8a=ze(_0x232d5f['visibleWrites'],_0x4c1e97);if(_0x354e8a!=null)return _0x354e8a;{const _0x4a4c55=Ee(_0x232d5f['visibleWrites'],_0x4c1e97);if(Ai(_0x4a4c55))return _0x29f446;if(_0x29f446==null&&!Ri(_0x4a4c55,w()))return null;{const _0x45ebb9=_0x29f446||g['EMPTY_NODE'];return at(_0x4a4c55,_0x45ebb9);}}}else{const _0x568dd7=Ee(_0x232d5f['visibleWrites'],_0x4c1e97);if(!_0xc7f95a&&Ai(_0x568dd7))return _0x29f446;if(!_0xc7f95a&&_0x29f446==null&&!Ri(_0x568dd7,w()))return null;{const _0x2a60ae=function(_0x4358ba){return(_0x4358ba['visible']||_0xc7f95a)&&(!_0x1d2813||!~_0x1d2813['indexOf'](_0x4358ba['writeId']))&&(G(_0x4358ba['path'],_0x4c1e97)||G(_0x4c1e97,_0x4358ba['path']));},_0x2a6748=Wo(_0x232d5f['allWrites'],_0x2a60ae,_0x4c1e97),_0x3cdbd5=_0x29f446||g['EMPTY_NODE'];return at(_0x2a6748,_0x3cdbd5);}}}function gu(_0x554488,_0x2f0626,_0x385ab8){let _0xc345b7=g['EMPTY_NODE'];const _0x4e4957=ze(_0x554488['visibleWrites'],_0x2f0626);if(_0x4e4957)return _0x4e4957['isLeafNode']()||_0x4e4957['forEachChild'](R,(_0x1d2a39,_0x34aff1)=>{_0xc345b7=_0xc345b7['updateImmediateChild'](_0x1d2a39,_0x34aff1);}),_0xc345b7;if(_0x385ab8){const _0x3f5a50=Ee(_0x554488['visibleWrites'],_0x2f0626);return _0x385ab8['forEachChild'](R,(_0x12a1bb,_0x1394e8)=>{const _0x59e148=at(Ee(_0x3f5a50,new C(_0x12a1bb)),_0x1394e8);_0xc345b7=_0xc345b7['updateImmediateChild'](_0x12a1bb,_0x59e148);}),ar(_0x3f5a50)['forEach'](_0x3887f1=>{_0xc345b7=_0xc345b7['updateImmediateChild'](_0x3887f1['name'],_0x3887f1['node']);}),_0xc345b7;}else{const _0x4cc490=Ee(_0x554488['visibleWrites'],_0x2f0626);return ar(_0x4cc490)['forEach'](_0x308af5=>{_0xc345b7=_0xc345b7['updateImmediateChild'](_0x308af5['name'],_0x308af5['node']);}),_0xc345b7;}}function mu(_0xc8ee79,_0x5bb4f8,_0x4c9d50,_0x260867,_0xf5b605){f(_0x260867||_0xf5b605,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2338a6=k(_0x5bb4f8,_0x4c9d50);if(Ri(_0xc8ee79['visibleWrites'],_0x2338a6))return null;{const _0x544fd7=Ee(_0xc8ee79['visibleWrites'],_0x2338a6);return Ai(_0x544fd7)?_0xf5b605['getChild'](_0x4c9d50):at(_0x544fd7,_0xf5b605['getChild'](_0x4c9d50));}}function yu(_0x347b96,_0x400667,_0x1af6a2,_0x11ef13){const _0x94c58e=k(_0x400667,_0x1af6a2),_0x1898dd=ze(_0x347b96['visibleWrites'],_0x94c58e);if(_0x1898dd!=null)return _0x1898dd;if(_0x11ef13['isCompleteForChild'](_0x1af6a2)){const _0x452862=Ee(_0x347b96['visibleWrites'],_0x94c58e);return at(_0x452862,_0x11ef13['getNode']()['getImmediateChild'](_0x1af6a2));}else return null;}function vu(_0x378194,_0x4f3855){return ze(_0x378194['visibleWrites'],_0x4f3855);}function Eu(_0x4903b2,_0x28fd8c,_0x240ee0,_0x264cd9,_0x2b8da2,_0x567203,_0x3ad86e){let _0x242dd8;const _0x3b1ad4=Ee(_0x4903b2['visibleWrites'],_0x28fd8c),_0x258e5c=ze(_0x3b1ad4,w());if(_0x258e5c!=null)_0x242dd8=_0x258e5c;else{if(_0x240ee0!=null)_0x242dd8=at(_0x3b1ad4,_0x240ee0);else return[];}if(_0x242dd8=_0x242dd8['withIndex'](_0x3ad86e),!_0x242dd8['isEmpty']()&&!_0x242dd8['isLeafNode']()){const _0x25cfe3=[],_0x4dc04f=_0x3ad86e['getCompare'](),_0x1ab05f=_0x567203?_0x242dd8['getReverseIteratorFrom'](_0x264cd9,_0x3ad86e):_0x242dd8['getIteratorFrom'](_0x264cd9,_0x3ad86e);let _0x4b5ef9=_0x1ab05f['getNext']();for(;_0x4b5ef9&&_0x25cfe3['length']<_0x2b8da2;)_0x4dc04f(_0x4b5ef9,_0x264cd9)!==0x0&&_0x25cfe3['push'](_0x4b5ef9),_0x4b5ef9=_0x1ab05f['getNext']();return _0x25cfe3;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x29fdb7,_0x15f73c,_0x41a242,_0x5b0f91){return Bo(_0x29fdb7['writeTree'],_0x29fdb7['treePath'],_0x15f73c,_0x41a242,_0x5b0f91);}function is(_0x30a942,_0x463877){return gu(_0x30a942['writeTree'],_0x30a942['treePath'],_0x463877);}function cr(_0x5c3486,_0x598276,_0x4f6101,_0x25a780){return mu(_0x5c3486['writeTree'],_0x5c3486['treePath'],_0x598276,_0x4f6101,_0x25a780);}function Tn(_0xff174,_0x284312){return vu(_0xff174['writeTree'],k(_0xff174['treePath'],_0x284312));}function wu(_0x370758,_0x398f52,_0xf5b9d0,_0x555420,_0x330d20,_0x9e6ec){return Eu(_0x370758['writeTree'],_0x370758['treePath'],_0x398f52,_0xf5b9d0,_0x555420,_0x330d20,_0x9e6ec);}function ss(_0x5a6923,_0x570507,_0x5c4658){return yu(_0x5a6923['writeTree'],_0x5a6923['treePath'],_0x570507,_0x5c4658);}function Vo(_0x18ad6e,_0xc5f83e){return Ho(k(_0x18ad6e['treePath'],_0xc5f83e),_0x18ad6e['writeTree']);}function Ho(_0x86ab7e,_0x510f38){return{'treePath':_0x86ab7e,'writeTree':_0x510f38};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1b113e){const _0x2c40c4=_0x1b113e['type'],_0xa6f8ca=_0x1b113e['childName'];f(_0x2c40c4==='child_added'||_0x2c40c4==='child_changed'||_0x2c40c4==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xa6f8ca!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x19cf99=this['changeMap']['get'](_0xa6f8ca);if(_0x19cf99){const _0xa9db70=_0x19cf99['type'];if(_0x2c40c4==='child_added'&&_0xa9db70==='child_removed')this['changeMap']['set'](_0xa6f8ca,xt(_0xa6f8ca,_0x1b113e['snapshotNode'],_0x19cf99['snapshotNode']));else{if(_0x2c40c4==='child_removed'&&_0xa9db70==='child_added')this['changeMap']['delete'](_0xa6f8ca);else{if(_0x2c40c4==='child_removed'&&_0xa9db70==='child_changed')this['changeMap']['set'](_0xa6f8ca,Lt(_0xa6f8ca,_0x19cf99['oldSnap']));else{if(_0x2c40c4==='child_changed'&&_0xa9db70==='child_added')this['changeMap']['set'](_0xa6f8ca,rt(_0xa6f8ca,_0x1b113e['snapshotNode']));else{if(_0x2c40c4==='child_changed'&&_0xa9db70==='child_changed')this['changeMap']['set'](_0xa6f8ca,xt(_0xa6f8ca,_0x1b113e['snapshotNode'],_0x19cf99['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x1b113e+'\x20occurred\x20after\x20'+_0x19cf99);}}}}}else this['changeMap']['set'](_0xa6f8ca,_0x1b113e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x46da84){return null;}['getChildAfterChild'](_0x547d3c,_0x1d5b8a,_0x5bdeae){return null;}}const $o=new Tu();class rs{constructor(_0x16d3db,_0xbde370,_0x58f2f1=null){this['writes_']=_0x16d3db,this['viewCache_']=_0xbde370,this['optCompleteServerCache_']=_0x58f2f1;}['getCompleteChild'](_0x39667d){const _0x5036f4=this['viewCache_']['eventCache'];if(_0x5036f4['isCompleteForChild'](_0x39667d))return _0x5036f4['getNode']()['getImmediateChild'](_0x39667d);{const _0x96da40=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x39667d,_0x96da40);}}['getChildAfterChild'](_0xc0a487,_0x10e5a6,_0x5ee846){const _0x36e16e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x665952=wu(this['writes_'],_0x36e16e,_0x10e5a6,0x1,_0x5ee846,_0xc0a487);return _0x665952['length']===0x0?null:_0x665952[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2faca0){return{'filter':_0x2faca0};}function bu(_0x4eff89,_0x5b51de){f(_0x5b51de['eventCache']['getNode']()['isIndexed'](_0x4eff89['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5b51de['serverCache']['getNode']()['isIndexed'](_0x4eff89['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x580df0,_0x16f109,_0x457bed,_0x14a44c,_0x186f01){const _0x2d78af=new Cu();let _0x740e18,_0x31be90;if(_0x457bed['type']===z['OVERWRITE']){const _0x4373ba=_0x457bed;_0x4373ba['source']['fromUser']?_0x740e18=ki(_0x580df0,_0x16f109,_0x4373ba['path'],_0x4373ba['snap'],_0x14a44c,_0x186f01,_0x2d78af):(f(_0x4373ba['source']['fromServer'],'Unknown\x20source.'),_0x31be90=_0x4373ba['source']['tagged']||_0x16f109['serverCache']['isFiltered']()&&!v(_0x4373ba['path']),_0x740e18=Sn(_0x580df0,_0x16f109,_0x4373ba['path'],_0x4373ba['snap'],_0x14a44c,_0x186f01,_0x31be90,_0x2d78af));}else{if(_0x457bed['type']===z['MERGE']){const _0x47fae0=_0x457bed;_0x47fae0['source']['fromUser']?_0x740e18=ku(_0x580df0,_0x16f109,_0x47fae0['path'],_0x47fae0['children'],_0x14a44c,_0x186f01,_0x2d78af):(f(_0x47fae0['source']['fromServer'],'Unknown\x20source.'),_0x31be90=_0x47fae0['source']['tagged']||_0x16f109['serverCache']['isFiltered'](),_0x740e18=Pi(_0x580df0,_0x16f109,_0x47fae0['path'],_0x47fae0['children'],_0x14a44c,_0x186f01,_0x31be90,_0x2d78af));}else{if(_0x457bed['type']===z['ACK_USER_WRITE']){const _0x422cdc=_0x457bed;_0x422cdc['revert']?_0x740e18=Ou(_0x580df0,_0x16f109,_0x422cdc['path'],_0x14a44c,_0x186f01,_0x2d78af):_0x740e18=Pu(_0x580df0,_0x16f109,_0x422cdc['path'],_0x422cdc['affectedTree'],_0x14a44c,_0x186f01,_0x2d78af);}else{if(_0x457bed['type']===z['LISTEN_COMPLETE'])_0x740e18=Nu(_0x580df0,_0x16f109,_0x457bed['path'],_0x14a44c,_0x2d78af);else throw ht('Unknown\x20operation\x20type:\x20'+_0x457bed['type']);}}}const _0x54e7c2=_0x2d78af['getChanges']();return Au(_0x16f109,_0x740e18,_0x54e7c2),{'viewCache':_0x740e18,'changes':_0x54e7c2};}function Au(_0x10936f,_0x41b181,_0xcf61da){const _0x3f8947=_0x41b181['eventCache'];if(_0x3f8947['isFullyInitialized']()){const _0x118b95=_0x3f8947['getNode']()['isLeafNode']()||_0x3f8947['getNode']()['isEmpty'](),_0x173396=wn(_0x10936f);(_0xcf61da['length']>0x0||!_0x10936f['eventCache']['isFullyInitialized']()||_0x118b95&&!_0x3f8947['getNode']()['equals'](_0x173396)||!_0x3f8947['getNode']()['getPriority']()['equals'](_0x173396['getPriority']()))&&_0xcf61da['push'](Lo(wn(_0x41b181)));}}function Go(_0x264ee9,_0x723089,_0x1f2fcf,_0x2257ec,_0xd3b04f,_0x4e2a85){const _0x176f89=_0x723089['eventCache'];if(Tn(_0x2257ec,_0x1f2fcf)!=null)return _0x723089;{let _0x40737d,_0x31f78a;if(v(_0x1f2fcf)){if(f(_0x723089['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x723089['serverCache']['isFiltered']()){const _0x250af4=Ve(_0x723089),_0x559349=_0x250af4 instanceof g?_0x250af4:g['EMPTY_NODE'],_0xf547d8=is(_0x2257ec,_0x559349);_0x40737d=_0x264ee9['filter']['updateFullNode'](_0x723089['eventCache']['getNode'](),_0xf547d8,_0x4e2a85);}else{const _0x3130d3=Cn(_0x2257ec,Ve(_0x723089));_0x40737d=_0x264ee9['filter']['updateFullNode'](_0x723089['eventCache']['getNode'](),_0x3130d3,_0x4e2a85);}}else{const _0x1816b3=y(_0x1f2fcf);if(_0x1816b3==='.priority'){f(Ce(_0x1f2fcf)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2f8d77=_0x176f89['getNode']();_0x31f78a=_0x723089['serverCache']['getNode']();const _0x5cc97b=cr(_0x2257ec,_0x1f2fcf,_0x2f8d77,_0x31f78a);_0x5cc97b!=null?_0x40737d=_0x264ee9['filter']['updatePriority'](_0x2f8d77,_0x5cc97b):_0x40737d=_0x176f89['getNode']();}else{const _0x1ca9f6=S(_0x1f2fcf);let _0x15c36d;if(_0x176f89['isCompleteForChild'](_0x1816b3)){_0x31f78a=_0x723089['serverCache']['getNode']();const _0x3de002=cr(_0x2257ec,_0x1f2fcf,_0x176f89['getNode'](),_0x31f78a);_0x3de002!=null?_0x15c36d=_0x176f89['getNode']()['getImmediateChild'](_0x1816b3)['updateChild'](_0x1ca9f6,_0x3de002):_0x15c36d=_0x176f89['getNode']()['getImmediateChild'](_0x1816b3);}else _0x15c36d=ss(_0x2257ec,_0x1816b3,_0x723089['serverCache']);_0x15c36d!=null?_0x40737d=_0x264ee9['filter']['updateChild'](_0x176f89['getNode'](),_0x1816b3,_0x15c36d,_0x1ca9f6,_0xd3b04f,_0x4e2a85):_0x40737d=_0x176f89['getNode']();}}return Rt(_0x723089,_0x40737d,_0x176f89['isFullyInitialized']()||v(_0x1f2fcf),_0x264ee9['filter']['filtersNodes']());}}function Sn(_0x2beff8,_0x277d96,_0x430a14,_0xd90c0c,_0x1301f3,_0x4c62e6,_0x43b214,_0x285fa3){const _0x29646a=_0x277d96['serverCache'];let _0x2f91ae;const _0x21b271=_0x43b214?_0x2beff8['filter']:_0x2beff8['filter']['getIndexedFilter']();if(v(_0x430a14))_0x2f91ae=_0x21b271['updateFullNode'](_0x29646a['getNode'](),_0xd90c0c,null);else{if(_0x21b271['filtersNodes']()&&!_0x29646a['isFiltered']()){const _0x24ecf1=_0x29646a['getNode']()['updateChild'](_0x430a14,_0xd90c0c);_0x2f91ae=_0x21b271['updateFullNode'](_0x29646a['getNode'](),_0x24ecf1,null);}else{const _0xfbef95=y(_0x430a14);if(!_0x29646a['isCompleteForPath'](_0x430a14)&&Ce(_0x430a14)>0x1)return _0x277d96;const _0x106988=S(_0x430a14),_0x5ada4d=_0x29646a['getNode']()['getImmediateChild'](_0xfbef95)['updateChild'](_0x106988,_0xd90c0c);_0xfbef95==='.priority'?_0x2f91ae=_0x21b271['updatePriority'](_0x29646a['getNode'](),_0x5ada4d):_0x2f91ae=_0x21b271['updateChild'](_0x29646a['getNode'](),_0xfbef95,_0x5ada4d,_0x106988,$o,null);}}const _0x47372b=Fo(_0x277d96,_0x2f91ae,_0x29646a['isFullyInitialized']()||v(_0x430a14),_0x21b271['filtersNodes']()),_0x3be7d3=new rs(_0x1301f3,_0x47372b,_0x4c62e6);return Go(_0x2beff8,_0x47372b,_0x430a14,_0x1301f3,_0x3be7d3,_0x285fa3);}function ki(_0x9d50d7,_0x1bdf69,_0x57cbb7,_0x420258,_0x25efbe,_0x52f76f,_0x13f2e6){const _0x5ebbd3=_0x1bdf69['eventCache'];let _0xb1edb2,_0x33d6d7;const _0x207885=new rs(_0x25efbe,_0x1bdf69,_0x52f76f);if(v(_0x57cbb7))_0x33d6d7=_0x9d50d7['filter']['updateFullNode'](_0x1bdf69['eventCache']['getNode'](),_0x420258,_0x13f2e6),_0xb1edb2=Rt(_0x1bdf69,_0x33d6d7,!0x0,_0x9d50d7['filter']['filtersNodes']());else{const _0x4c7d8a=y(_0x57cbb7);if(_0x4c7d8a==='.priority')_0x33d6d7=_0x9d50d7['filter']['updatePriority'](_0x1bdf69['eventCache']['getNode'](),_0x420258),_0xb1edb2=Rt(_0x1bdf69,_0x33d6d7,_0x5ebbd3['isFullyInitialized'](),_0x5ebbd3['isFiltered']());else{const _0x37d5c7=S(_0x57cbb7),_0x5db3f1=_0x5ebbd3['getNode']()['getImmediateChild'](_0x4c7d8a);let _0x5cff71;if(v(_0x37d5c7))_0x5cff71=_0x420258;else{const _0x55cbc5=_0x207885['getCompleteChild'](_0x4c7d8a);_0x55cbc5!=null?ji(_0x37d5c7)==='.priority'&&_0x55cbc5['getChild'](Ro(_0x37d5c7))['isEmpty']()?_0x5cff71=_0x55cbc5:_0x5cff71=_0x55cbc5['updateChild'](_0x37d5c7,_0x420258):_0x5cff71=g['EMPTY_NODE'];}if(_0x5db3f1['equals'](_0x5cff71))_0xb1edb2=_0x1bdf69;else{const _0x2326ec=_0x9d50d7['filter']['updateChild'](_0x5ebbd3['getNode'](),_0x4c7d8a,_0x5cff71,_0x37d5c7,_0x207885,_0x13f2e6);_0xb1edb2=Rt(_0x1bdf69,_0x2326ec,_0x5ebbd3['isFullyInitialized'](),_0x9d50d7['filter']['filtersNodes']());}}}return _0xb1edb2;}function lr(_0x583d2f,_0xf8c51f){return _0x583d2f['eventCache']['isCompleteForChild'](_0xf8c51f);}function ku(_0x3ee867,_0x5955c4,_0x5418d7,_0x1f2434,_0x3b70b7,_0x1b50d7,_0x8daf57){let _0x22a775=_0x5955c4;return _0x1f2434['foreach']((_0xc5bb03,_0x43e3bb)=>{const _0x367ad5=k(_0x5418d7,_0xc5bb03);lr(_0x5955c4,y(_0x367ad5))&&(_0x22a775=ki(_0x3ee867,_0x22a775,_0x367ad5,_0x43e3bb,_0x3b70b7,_0x1b50d7,_0x8daf57));}),_0x1f2434['foreach']((_0x4dc23e,_0x98e4ca)=>{const _0x5c5e48=k(_0x5418d7,_0x4dc23e);lr(_0x5955c4,y(_0x5c5e48))||(_0x22a775=ki(_0x3ee867,_0x22a775,_0x5c5e48,_0x98e4ca,_0x3b70b7,_0x1b50d7,_0x8daf57));}),_0x22a775;}function hr(_0x501f36,_0x37813a,_0x1c0dbe){return _0x1c0dbe['foreach']((_0x222eac,_0x1bee35)=>{_0x37813a=_0x37813a['updateChild'](_0x222eac,_0x1bee35);}),_0x37813a;}function Pi(_0x1752c6,_0x20095d,_0x27fdea,_0x33780b,_0x3b4465,_0x599732,_0x377c1c,_0x1832cb){if(_0x20095d['serverCache']['getNode']()['isEmpty']()&&!_0x20095d['serverCache']['isFullyInitialized']())return _0x20095d;let _0x2f716f=_0x20095d,_0x4cafb5;v(_0x27fdea)?_0x4cafb5=_0x33780b:_0x4cafb5=new b(null)['setTree'](_0x27fdea,_0x33780b);const _0x1059a3=_0x20095d['serverCache']['getNode']();return _0x4cafb5['children']['inorderTraversal']((_0x25c068,_0x379ad2)=>{if(_0x1059a3['hasChild'](_0x25c068)){const _0x14e0ab=_0x20095d['serverCache']['getNode']()['getImmediateChild'](_0x25c068),_0x322811=hr(_0x1752c6,_0x14e0ab,_0x379ad2);_0x2f716f=Sn(_0x1752c6,_0x2f716f,new C(_0x25c068),_0x322811,_0x3b4465,_0x599732,_0x377c1c,_0x1832cb);}}),_0x4cafb5['children']['inorderTraversal']((_0x2b6992,_0x156d57)=>{const _0x52865a=!_0x20095d['serverCache']['isCompleteForChild'](_0x2b6992)&&_0x156d57['value']===null;if(!_0x1059a3['hasChild'](_0x2b6992)&&!_0x52865a){const _0x4e92ad=_0x20095d['serverCache']['getNode']()['getImmediateChild'](_0x2b6992),_0x4b302c=hr(_0x1752c6,_0x4e92ad,_0x156d57);_0x2f716f=Sn(_0x1752c6,_0x2f716f,new C(_0x2b6992),_0x4b302c,_0x3b4465,_0x599732,_0x377c1c,_0x1832cb);}}),_0x2f716f;}function Pu(_0x5d16e6,_0x5712eb,_0x10da77,_0x2dca3b,_0x55510b,_0x3c5cbc,_0x4734b4){if(Tn(_0x55510b,_0x10da77)!=null)return _0x5712eb;const _0x54c3e7=_0x5712eb['serverCache']['isFiltered'](),_0x5c273a=_0x5712eb['serverCache'];if(_0x2dca3b['value']!=null){if(v(_0x10da77)&&_0x5c273a['isFullyInitialized']()||_0x5c273a['isCompleteForPath'](_0x10da77))return Sn(_0x5d16e6,_0x5712eb,_0x10da77,_0x5c273a['getNode']()['getChild'](_0x10da77),_0x55510b,_0x3c5cbc,_0x54c3e7,_0x4734b4);if(v(_0x10da77)){let _0x196bef=new b(null);return _0x5c273a['getNode']()['forEachChild'](ve,(_0x36af3a,_0x1764d9)=>{_0x196bef=_0x196bef['set'](new C(_0x36af3a),_0x1764d9);}),Pi(_0x5d16e6,_0x5712eb,_0x10da77,_0x196bef,_0x55510b,_0x3c5cbc,_0x54c3e7,_0x4734b4);}else return _0x5712eb;}else{let _0x45f387=new b(null);return _0x2dca3b['foreach']((_0xfc7f2d,_0x1dc8ef)=>{const _0x5ea201=k(_0x10da77,_0xfc7f2d);_0x5c273a['isCompleteForPath'](_0x5ea201)&&(_0x45f387=_0x45f387['set'](_0xfc7f2d,_0x5c273a['getNode']()['getChild'](_0x5ea201)));}),Pi(_0x5d16e6,_0x5712eb,_0x10da77,_0x45f387,_0x55510b,_0x3c5cbc,_0x54c3e7,_0x4734b4);}}function Nu(_0x1bb2aa,_0x48247f,_0x5cb967,_0x3cd6a2,_0xe815ae){const _0x19ce8f=_0x48247f['serverCache'],_0x53ffde=Fo(_0x48247f,_0x19ce8f['getNode'](),_0x19ce8f['isFullyInitialized']()||v(_0x5cb967),_0x19ce8f['isFiltered']());return Go(_0x1bb2aa,_0x53ffde,_0x5cb967,_0x3cd6a2,$o,_0xe815ae);}function Ou(_0x18e5e5,_0x2a3626,_0x456138,_0x4c6750,_0x43bfbb,_0x23e6a3){let _0x5cc8f2;if(Tn(_0x4c6750,_0x456138)!=null)return _0x2a3626;{const _0x5f3802=new rs(_0x4c6750,_0x2a3626,_0x43bfbb),_0x5d8948=_0x2a3626['eventCache']['getNode']();let _0x9a7276;if(v(_0x456138)||y(_0x456138)==='.priority'){let _0x1a828d;if(_0x2a3626['serverCache']['isFullyInitialized']())_0x1a828d=Cn(_0x4c6750,Ve(_0x2a3626));else{const _0x59212c=_0x2a3626['serverCache']['getNode']();f(_0x59212c instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1a828d=is(_0x4c6750,_0x59212c);}_0x1a828d=_0x1a828d,_0x9a7276=_0x18e5e5['filter']['updateFullNode'](_0x5d8948,_0x1a828d,_0x23e6a3);}else{const _0x4f2194=y(_0x456138);let _0x28a24b=ss(_0x4c6750,_0x4f2194,_0x2a3626['serverCache']);_0x28a24b==null&&_0x2a3626['serverCache']['isCompleteForChild'](_0x4f2194)&&(_0x28a24b=_0x5d8948['getImmediateChild'](_0x4f2194)),_0x28a24b!=null?_0x9a7276=_0x18e5e5['filter']['updateChild'](_0x5d8948,_0x4f2194,_0x28a24b,S(_0x456138),_0x5f3802,_0x23e6a3):_0x2a3626['eventCache']['getNode']()['hasChild'](_0x4f2194)?_0x9a7276=_0x18e5e5['filter']['updateChild'](_0x5d8948,_0x4f2194,g['EMPTY_NODE'],S(_0x456138),_0x5f3802,_0x23e6a3):_0x9a7276=_0x5d8948,_0x9a7276['isEmpty']()&&_0x2a3626['serverCache']['isFullyInitialized']()&&(_0x5cc8f2=Cn(_0x4c6750,Ve(_0x2a3626)),_0x5cc8f2['isLeafNode']()&&(_0x9a7276=_0x18e5e5['filter']['updateFullNode'](_0x9a7276,_0x5cc8f2,_0x23e6a3)));}return _0x5cc8f2=_0x2a3626['serverCache']['isFullyInitialized']()||Tn(_0x4c6750,w())!=null,Rt(_0x2a3626,_0x9a7276,_0x5cc8f2,_0x18e5e5['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3c0a4c,_0x1d424c){this['query_']=_0x3c0a4c,this['eventRegistrations_']=[];const _0x55b402=this['query_']['_queryParams'],_0x159f60=new Xi(_0x55b402['getIndex']()),_0x59423e=Kh(_0x55b402);this['processor_']=Su(_0x59423e);const _0x1f6a02=_0x1d424c['serverCache'],_0x202e96=_0x1d424c['eventCache'],_0xb77c44=_0x159f60['updateFullNode'](g['EMPTY_NODE'],_0x1f6a02['getNode'](),null),_0x2a0718=_0x59423e['updateFullNode'](g['EMPTY_NODE'],_0x202e96['getNode'](),null),_0x58592c=new Te(_0xb77c44,_0x1f6a02['isFullyInitialized'](),_0x159f60['filtersNodes']()),_0x3ab350=new Te(_0x2a0718,_0x202e96['isFullyInitialized'](),_0x59423e['filtersNodes']());this['viewCache_']=Un(_0x3ab350,_0x58592c),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x204d06){return _0x204d06['viewCache_']['serverCache']['getNode']();}function Lu(_0x4068fb){return wn(_0x4068fb['viewCache_']);}function xu(_0x733269,_0x237d21){const _0x412af9=Ve(_0x733269['viewCache_']);return _0x412af9&&(_0x733269['query']['_queryParams']['loadsAllData']()||!v(_0x237d21)&&!_0x412af9['getImmediateChild'](y(_0x237d21))['isEmpty']())?_0x412af9['getChild'](_0x237d21):null;}function ur(_0x2f07dd){return _0x2f07dd['eventRegistrations_']['length']===0x0;}function Fu(_0x51e660,_0x192184){_0x51e660['eventRegistrations_']['push'](_0x192184);}function dr(_0x258378,_0x3e93a4,_0x4e9f38){const _0x258db0=[];if(_0x4e9f38){f(_0x3e93a4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x29c54a=_0x258378['query']['_path'];_0x258378['eventRegistrations_']['forEach'](_0x35d177=>{const _0x11db2a=_0x35d177['createCancelEvent'](_0x4e9f38,_0x29c54a);_0x11db2a&&_0x258db0['push'](_0x11db2a);});}if(_0x3e93a4){let _0xce1e57=[];for(let _0x1f66dd=0x0;_0x1f66dd<_0x258378['eventRegistrations_']['length'];++_0x1f66dd){const _0x543e4b=_0x258378['eventRegistrations_'][_0x1f66dd];if(!_0x543e4b['matches'](_0x3e93a4))_0xce1e57['push'](_0x543e4b);else{if(_0x3e93a4['hasAnyCallback']()){_0xce1e57=_0xce1e57['concat'](_0x258378['eventRegistrations_']['slice'](_0x1f66dd+0x1));break;}}}_0x258378['eventRegistrations_']=_0xce1e57;}else _0x258378['eventRegistrations_']=[];return _0x258db0;}function fr(_0x167dd3,_0xcb5e46,_0x51184a,_0x4edd18){_0xcb5e46['type']===z['MERGE']&&_0xcb5e46['source']['queryId']!==null&&(f(Ve(_0x167dd3['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x167dd3['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x29da1b=_0x167dd3['viewCache_'],_0x4691dc=Ru(_0x167dd3['processor_'],_0x29da1b,_0xcb5e46,_0x51184a,_0x4edd18);return bu(_0x167dd3['processor_'],_0x4691dc['viewCache']),f(_0x4691dc['viewCache']['serverCache']['isFullyInitialized']()||!_0x29da1b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x167dd3['viewCache_']=_0x4691dc['viewCache'],qo(_0x167dd3,_0x4691dc['changes'],_0x4691dc['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5e21cb,_0x20a0ab){const _0x56ec87=_0x5e21cb['viewCache_']['eventCache'],_0x1ab463=[];return _0x56ec87['getNode']()['isLeafNode']()||_0x56ec87['getNode']()['forEachChild'](R,(_0x315958,_0x384ac7)=>{_0x1ab463['push'](rt(_0x315958,_0x384ac7));}),_0x56ec87['isFullyInitialized']()&&_0x1ab463['push'](Lo(_0x56ec87['getNode']())),qo(_0x5e21cb,_0x1ab463,_0x56ec87['getNode'](),_0x20a0ab);}function qo(_0xc7ff46,_0x332c35,_0x299db3,_0x22b56f){const _0x41903d=_0x22b56f?[_0x22b56f]:_0xc7ff46['eventRegistrations_'];return ru(_0xc7ff46['eventGenerator_'],_0x332c35,_0x299db3,_0x41903d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x535baf){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x535baf;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3d386b){return _0x3d386b['views']['size']===0x0;}function os(_0x1f558b,_0x75b985,_0x11e828,_0x2f6546){const _0x1aa8fc=_0x75b985['source']['queryId'];if(_0x1aa8fc!==null){const _0xcebb8b=_0x1f558b['views']['get'](_0x1aa8fc);return f(_0xcebb8b!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xcebb8b,_0x75b985,_0x11e828,_0x2f6546);}else{let _0x22ac30=[];for(const _0xe322fa of _0x1f558b['views']['values']())_0x22ac30=_0x22ac30['concat'](fr(_0xe322fa,_0x75b985,_0x11e828,_0x2f6546));return _0x22ac30;}}function jo(_0x1630e8,_0x5825af,_0x1aed9e,_0x1dfd17,_0xe64b6e){const _0x5c7cc5=_0x5825af['_queryIdentifier'],_0x55dfe6=_0x1630e8['views']['get'](_0x5c7cc5);if(!_0x55dfe6){let _0x3651a3=Cn(_0x1aed9e,_0xe64b6e?_0x1dfd17:null),_0xb74514=!0x1;_0x3651a3?_0xb74514=!0x0:_0x1dfd17 instanceof g?(_0x3651a3=is(_0x1aed9e,_0x1dfd17),_0xb74514=!0x1):(_0x3651a3=g['EMPTY_NODE'],_0xb74514=!0x1);const _0x271368=Un(new Te(_0x3651a3,_0xb74514,!0x1),new Te(_0x1dfd17,_0xe64b6e,!0x1));return new Du(_0x5825af,_0x271368);}return _0x55dfe6;}function Hu(_0x1f8123,_0x5c1bc9,_0x3b82b6,_0x52022a,_0x12fc1e,_0x39584e){const _0x4efe1a=jo(_0x1f8123,_0x5c1bc9,_0x52022a,_0x12fc1e,_0x39584e);return _0x1f8123['views']['has'](_0x5c1bc9['_queryIdentifier'])||_0x1f8123['views']['set'](_0x5c1bc9['_queryIdentifier'],_0x4efe1a),Fu(_0x4efe1a,_0x3b82b6),Uu(_0x4efe1a,_0x3b82b6);}function $u(_0x5e8e1e,_0x37e0bd,_0x562ed0,_0x5703f1){const _0x20a826=_0x37e0bd['_queryIdentifier'],_0x36fb69=[];let _0xb3dae9=[];const _0x5515f1=Se(_0x5e8e1e);if(_0x20a826==='default'){for(const [_0x419a4c,_0x582e41]of _0x5e8e1e['views']['entries']())_0xb3dae9=_0xb3dae9['concat'](dr(_0x582e41,_0x562ed0,_0x5703f1)),ur(_0x582e41)&&(_0x5e8e1e['views']['delete'](_0x419a4c),_0x582e41['query']['_queryParams']['loadsAllData']()||_0x36fb69['push'](_0x582e41['query']));}else{const _0x283f27=_0x5e8e1e['views']['get'](_0x20a826);_0x283f27&&(_0xb3dae9=_0xb3dae9['concat'](dr(_0x283f27,_0x562ed0,_0x5703f1)),ur(_0x283f27)&&(_0x5e8e1e['views']['delete'](_0x20a826),_0x283f27['query']['_queryParams']['loadsAllData']()||_0x36fb69['push'](_0x283f27['query'])));}return _0x5515f1&&!Se(_0x5e8e1e)&&_0x36fb69['push'](new(Bu())(_0x37e0bd['_repo'],_0x37e0bd['_path'])),{'removed':_0x36fb69,'events':_0xb3dae9};}function Ko(_0xfa277a){const _0x24f7c3=[];for(const _0x5c62e8 of _0xfa277a['views']['values']())_0x5c62e8['query']['_queryParams']['loadsAllData']()||_0x24f7c3['push'](_0x5c62e8);return _0x24f7c3;}function Ie(_0x36901c,_0x3fa39d){let _0x19e310=null;for(const _0x114f79 of _0x36901c['views']['values']())_0x19e310=_0x19e310||xu(_0x114f79,_0x3fa39d);return _0x19e310;}function Yo(_0x121ded,_0x44c2cb){if(_0x44c2cb['_queryParams']['loadsAllData']())return Bn(_0x121ded);{const _0x51ca23=_0x44c2cb['_queryIdentifier'];return _0x121ded['views']['get'](_0x51ca23);}}function Qo(_0x5754d3,_0x43dafd){return Yo(_0x5754d3,_0x43dafd)!=null;}function Se(_0x4383f4){return Bn(_0x4383f4)!=null;}function Bn(_0x4ee08e){for(const _0x275851 of _0x4ee08e['views']['values']())if(_0x275851['query']['_queryParams']['loadsAllData']())return _0x275851;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x33740a){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x33740a;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x48d23b){this['listenProvider_']=_0x48d23b,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x549630,_0x58357c,_0x42b512,_0x4f1cbd,_0xe59a6c){return lu(_0x549630['pendingWriteTree_'],_0x58357c,_0x42b512,_0x4f1cbd,_0xe59a6c),_0xe59a6c?_t(_0x549630,new Be(es(),_0x58357c,_0x42b512)):[];}function ju(_0x351482,_0xe93be4,_0x12562f,_0x4f70b1){hu(_0x351482['pendingWriteTree_'],_0xe93be4,_0x12562f,_0x4f70b1);const _0x1c23d0=b['fromObject'](_0x12562f);return _t(_0x351482,new ot(es(),_0xe93be4,_0x1c23d0));}function _e(_0x5336e4,_0x5a973a,_0x206799=!0x1){const _0x82d9a2=uu(_0x5336e4['pendingWriteTree_'],_0x5a973a);if(du(_0x5336e4['pendingWriteTree_'],_0x5a973a)){let _0x250905=new b(null);return _0x82d9a2['snap']!=null?_0x250905=_0x250905['set'](w(),!0x0):x(_0x82d9a2['children'],_0x4c69a8=>{_0x250905=_0x250905['set'](new C(_0x4c69a8),!0x0);}),_t(_0x5336e4,new In(_0x82d9a2['path'],_0x250905,_0x206799));}else return[];}function Yt(_0x5b3415,_0x18353e,_0x4f39a5){return _t(_0x5b3415,new Be(ts(),_0x18353e,_0x4f39a5));}function Ku(_0x2fbfe4,_0x3216df,_0x11eb8d){const _0x3aceec=b['fromObject'](_0x11eb8d);return _t(_0x2fbfe4,new ot(ts(),_0x3216df,_0x3aceec));}function Yu(_0x595992,_0x4f8bfa){return _t(_0x595992,new Ut(ts(),_0x4f8bfa));}function Qu(_0x2d9634,_0x3cf296,_0x4a71e4){const _0x4192b8=cs(_0x2d9634,_0x4a71e4);if(_0x4192b8){const _0x4b37fc=ls(_0x4192b8),_0x5c0240=_0x4b37fc['path'],_0x5458db=_0x4b37fc['queryId'],_0x58549e=F(_0x5c0240,_0x3cf296),_0x299ecc=new Ut(ns(_0x5458db),_0x58549e);return hs(_0x2d9634,_0x5c0240,_0x299ecc);}else return[];}function An(_0xc574b5,_0x2bbb19,_0x1bc355,_0x3ad7fd,_0x1bf035=!0x1){const _0x4331e0=_0x2bbb19['_path'],_0x70b373=_0xc574b5['syncPointTree_']['get'](_0x4331e0);let _0x38aee6=[];if(_0x70b373&&(_0x2bbb19['_queryIdentifier']==='default'||Qo(_0x70b373,_0x2bbb19))){const _0x5d0b01=$u(_0x70b373,_0x2bbb19,_0x1bc355,_0x3ad7fd);Vu(_0x70b373)&&(_0xc574b5['syncPointTree_']=_0xc574b5['syncPointTree_']['remove'](_0x4331e0));const _0xd322b5=_0x5d0b01['removed'];if(_0x38aee6=_0x5d0b01['events'],!_0x1bf035){const _0x5a018d=_0xd322b5['findIndex'](_0x4199fc=>_0x4199fc['_queryParams']['loadsAllData']())!==-0x1,_0x5713e3=_0xc574b5['syncPointTree_']['findOnPath'](_0x4331e0,(_0x2c2305,_0xe1d06c)=>Se(_0xe1d06c));if(_0x5a018d&&!_0x5713e3){const _0x3b104e=_0xc574b5['syncPointTree_']['subtree'](_0x4331e0);if(!_0x3b104e['isEmpty']()){const _0x2c124e=Zu(_0x3b104e);for(let _0x556f5f=0x0;_0x556f5f<_0x2c124e['length'];++_0x556f5f){const _0x4ff10f=_0x2c124e[_0x556f5f],_0x2a3ec1=_0x4ff10f['query'],_0x21ae6a=ea(_0xc574b5,_0x4ff10f);_0xc574b5['listenProvider_']['startListening'](kt(_0x2a3ec1),Wt(_0xc574b5,_0x2a3ec1),_0x21ae6a['hashFn'],_0x21ae6a['onComplete']);}}}!_0x5713e3&&_0xd322b5['length']>0x0&&!_0x3ad7fd&&(_0x5a018d?_0xc574b5['listenProvider_']['stopListening'](kt(_0x2bbb19),null):_0xd322b5['forEach'](_0x3aaa6f=>{const _0x422faf=_0xc574b5['queryToTagMap']['get'](Hn(_0x3aaa6f));_0xc574b5['listenProvider_']['stopListening'](kt(_0x3aaa6f),_0x422faf);}));}ed(_0xc574b5,_0xd322b5);}return _0x38aee6;}function Jo(_0x2144cc,_0x5b28bf,_0x29af9b,_0x286781){const _0x5ef675=cs(_0x2144cc,_0x286781);if(_0x5ef675!=null){const _0x7a829d=ls(_0x5ef675),_0xd73528=_0x7a829d['path'],_0x3088e3=_0x7a829d['queryId'],_0x561c4e=F(_0xd73528,_0x5b28bf),_0x4c039e=new Be(ns(_0x3088e3),_0x561c4e,_0x29af9b);return hs(_0x2144cc,_0xd73528,_0x4c039e);}else return[];}function Ju(_0x1caa46,_0x3d4e35,_0x7361dc,_0x29343d){const _0x430665=cs(_0x1caa46,_0x29343d);if(_0x430665){const _0x1e6fa2=ls(_0x430665),_0x7d83fe=_0x1e6fa2['path'],_0x32b83e=_0x1e6fa2['queryId'],_0x49b461=F(_0x7d83fe,_0x3d4e35),_0x5ef61b=b['fromObject'](_0x7361dc),_0x466172=new ot(ns(_0x32b83e),_0x49b461,_0x5ef61b);return hs(_0x1caa46,_0x7d83fe,_0x466172);}else return[];}function Ni(_0x3416ec,_0x23c19b,_0x5ac151,_0xb46457=!0x1){const _0x9494f9=_0x23c19b['_path'];let _0x11c801=null,_0x2df6dd=!0x1;_0x3416ec['syncPointTree_']['foreachOnPath'](_0x9494f9,(_0x89fa6e,_0x4f66df)=>{const _0x13ecf1=F(_0x89fa6e,_0x9494f9);_0x11c801=_0x11c801||Ie(_0x4f66df,_0x13ecf1),_0x2df6dd=_0x2df6dd||Se(_0x4f66df);});let _0x204a73=_0x3416ec['syncPointTree_']['get'](_0x9494f9);_0x204a73?(_0x2df6dd=_0x2df6dd||Se(_0x204a73),_0x11c801=_0x11c801||Ie(_0x204a73,w())):(_0x204a73=new zo(),_0x3416ec['syncPointTree_']=_0x3416ec['syncPointTree_']['set'](_0x9494f9,_0x204a73));let _0x1632ba;_0x11c801!=null?_0x1632ba=!0x0:(_0x1632ba=!0x1,_0x11c801=g['EMPTY_NODE'],_0x3416ec['syncPointTree_']['subtree'](_0x9494f9)['foreachChild']((_0x188a76,_0x4a273f)=>{const _0x2ed930=Ie(_0x4a273f,w());_0x2ed930&&(_0x11c801=_0x11c801['updateImmediateChild'](_0x188a76,_0x2ed930));}));const _0x7f64ac=Qo(_0x204a73,_0x23c19b);if(!_0x7f64ac&&!_0x23c19b['_queryParams']['loadsAllData']()){const _0x85742e=Hn(_0x23c19b);f(!_0x3416ec['queryToTagMap']['has'](_0x85742e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1c2283=td();_0x3416ec['queryToTagMap']['set'](_0x85742e,_0x1c2283),_0x3416ec['tagToQueryMap']['set'](_0x1c2283,_0x85742e);}const _0x3c29e8=Wn(_0x3416ec['pendingWriteTree_'],_0x9494f9);let _0x508dcd=Hu(_0x204a73,_0x23c19b,_0x5ac151,_0x3c29e8,_0x11c801,_0x1632ba);if(!_0x7f64ac&&!_0x2df6dd&&!_0xb46457){const _0x1d5d55=Yo(_0x204a73,_0x23c19b);_0x508dcd=_0x508dcd['concat'](nd(_0x3416ec,_0x23c19b,_0x1d5d55));}return _0x508dcd;}function Vn(_0x4b386e,_0x21c64f,_0x4c3977){const _0x257082=_0x4b386e['pendingWriteTree_'],_0x5c3a1b=_0x4b386e['syncPointTree_']['findOnPath'](_0x21c64f,(_0x5019e7,_0x5b8d32)=>{const _0x4be06d=F(_0x5019e7,_0x21c64f),_0x2719fe=Ie(_0x5b8d32,_0x4be06d);if(_0x2719fe)return _0x2719fe;});return Bo(_0x257082,_0x21c64f,_0x5c3a1b,_0x4c3977,!0x0);}function Xu(_0x4b5dff,_0x22bb4f){const _0x47efc3=_0x22bb4f['_path'];let _0x2a2574=null;_0x4b5dff['syncPointTree_']['foreachOnPath'](_0x47efc3,(_0x1d71a8,_0x1b0952)=>{const _0x1b219d=F(_0x1d71a8,_0x47efc3);_0x2a2574=_0x2a2574||Ie(_0x1b0952,_0x1b219d);});let _0x34248e=_0x4b5dff['syncPointTree_']['get'](_0x47efc3);_0x34248e?_0x2a2574=_0x2a2574||Ie(_0x34248e,w()):(_0x34248e=new zo(),_0x4b5dff['syncPointTree_']=_0x4b5dff['syncPointTree_']['set'](_0x47efc3,_0x34248e));const _0x4e6dfa=_0x2a2574!=null,_0x2e5c8d=_0x4e6dfa?new Te(_0x2a2574,!0x0,!0x1):null,_0x5ad3cb=Wn(_0x4b5dff['pendingWriteTree_'],_0x22bb4f['_path']),_0x167854=jo(_0x34248e,_0x22bb4f,_0x5ad3cb,_0x4e6dfa?_0x2e5c8d['getNode']():g['EMPTY_NODE'],_0x4e6dfa);return Lu(_0x167854);}function _t(_0x13cbf7,_0x5ef538){return Xo(_0x5ef538,_0x13cbf7['syncPointTree_'],null,Wn(_0x13cbf7['pendingWriteTree_'],w()));}function Xo(_0x41c5c6,_0x4a6031,_0x1a5963,_0x57c96b){if(v(_0x41c5c6['path']))return Zo(_0x41c5c6,_0x4a6031,_0x1a5963,_0x57c96b);{const _0x1465a4=_0x4a6031['get'](w());_0x1a5963==null&&_0x1465a4!=null&&(_0x1a5963=Ie(_0x1465a4,w()));let _0x2bcbd7=[];const _0x1b6378=y(_0x41c5c6['path']),_0x305e29=_0x41c5c6['operationForChild'](_0x1b6378),_0xe13e00=_0x4a6031['children']['get'](_0x1b6378);if(_0xe13e00&&_0x305e29){const _0x528b95=_0x1a5963?_0x1a5963['getImmediateChild'](_0x1b6378):null,_0x3c0aa6=Vo(_0x57c96b,_0x1b6378);_0x2bcbd7=_0x2bcbd7['concat'](Xo(_0x305e29,_0xe13e00,_0x528b95,_0x3c0aa6));}return _0x1465a4&&(_0x2bcbd7=_0x2bcbd7['concat'](os(_0x1465a4,_0x41c5c6,_0x57c96b,_0x1a5963))),_0x2bcbd7;}}function Zo(_0x226071,_0x4136a3,_0x2e1878,_0x41e511){const _0x245999=_0x4136a3['get'](w());_0x2e1878==null&&_0x245999!=null&&(_0x2e1878=Ie(_0x245999,w()));let _0x3db3a9=[];return _0x4136a3['children']['inorderTraversal']((_0x2546ec,_0x4c378a)=>{const _0x17262f=_0x2e1878?_0x2e1878['getImmediateChild'](_0x2546ec):null,_0x5b43c1=Vo(_0x41e511,_0x2546ec),_0xbc8b4c=_0x226071['operationForChild'](_0x2546ec);_0xbc8b4c&&(_0x3db3a9=_0x3db3a9['concat'](Zo(_0xbc8b4c,_0x4c378a,_0x17262f,_0x5b43c1)));}),_0x245999&&(_0x3db3a9=_0x3db3a9['concat'](os(_0x245999,_0x226071,_0x41e511,_0x2e1878))),_0x3db3a9;}function ea(_0x12af5d,_0x4dd469){const _0x4d06c1=_0x4dd469['query'],_0x4cdd3d=Wt(_0x12af5d,_0x4d06c1);return{'hashFn':()=>(Mu(_0x4dd469)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2bd491=>{if(_0x2bd491==='ok')return _0x4cdd3d?Qu(_0x12af5d,_0x4d06c1['_path'],_0x4cdd3d):Yu(_0x12af5d,_0x4d06c1['_path']);{const _0x4768af=Kl(_0x2bd491,_0x4d06c1);return An(_0x12af5d,_0x4d06c1,null,_0x4768af);}}};}function Wt(_0x204748,_0xeb584f){const _0x3e8c77=Hn(_0xeb584f);return _0x204748['queryToTagMap']['get'](_0x3e8c77);}function Hn(_0x3a80cd){return _0x3a80cd['_path']['toString']()+'$'+_0x3a80cd['_queryIdentifier'];}function cs(_0x2912a9,_0x34d855){return _0x2912a9['tagToQueryMap']['get'](_0x34d855);}function ls(_0x5531b6){const _0x5e5b19=_0x5531b6['indexOf']('$');return f(_0x5e5b19!==-0x1&&_0x5e5b19<_0x5531b6['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5531b6['substr'](_0x5e5b19+0x1),'path':new C(_0x5531b6['substr'](0x0,_0x5e5b19))};}function hs(_0x19d090,_0x3c0947,_0xe709b9){const _0x5b0cf5=_0x19d090['syncPointTree_']['get'](_0x3c0947);f(_0x5b0cf5,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2fa86c=Wn(_0x19d090['pendingWriteTree_'],_0x3c0947);return os(_0x5b0cf5,_0xe709b9,_0x2fa86c,null);}function Zu(_0x5243d5){return _0x5243d5['fold']((_0x51a0cc,_0x53db09,_0x31aecd)=>{if(_0x53db09&&Se(_0x53db09))return[Bn(_0x53db09)];{let _0x11fef8=[];return _0x53db09&&(_0x11fef8=Ko(_0x53db09)),x(_0x31aecd,(_0x3dae0a,_0xac294c)=>{_0x11fef8=_0x11fef8['concat'](_0xac294c);}),_0x11fef8;}});}function kt(_0x1e07c9){return _0x1e07c9['_queryParams']['loadsAllData']()&&!_0x1e07c9['_queryParams']['isDefault']()?new(qu())(_0x1e07c9['_repo'],_0x1e07c9['_path']):_0x1e07c9;}function ed(_0xef3793,_0x3546f){for(let _0x2c14b5=0x0;_0x2c14b5<_0x3546f['length'];++_0x2c14b5){const _0x27e881=_0x3546f[_0x2c14b5];if(!_0x27e881['_queryParams']['loadsAllData']()){const _0x209607=Hn(_0x27e881),_0x24f212=_0xef3793['queryToTagMap']['get'](_0x209607);_0xef3793['queryToTagMap']['delete'](_0x209607),_0xef3793['tagToQueryMap']['delete'](_0x24f212);}}}function td(){return zu++;}function nd(_0x2eb613,_0x37b71a,_0x2eb46a){const _0x2ea9fd=_0x37b71a['_path'],_0x474844=Wt(_0x2eb613,_0x37b71a),_0x440739=ea(_0x2eb613,_0x2eb46a),_0x236cc1=_0x2eb613['listenProvider_']['startListening'](kt(_0x37b71a),_0x474844,_0x440739['hashFn'],_0x440739['onComplete']),_0x4ac14c=_0x2eb613['syncPointTree_']['subtree'](_0x2ea9fd);if(_0x474844)f(!Se(_0x4ac14c['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x103c6f=_0x4ac14c['fold']((_0x215c81,_0x5c531e,_0x3927e3)=>{if(!v(_0x215c81)&&_0x5c531e&&Se(_0x5c531e))return[Bn(_0x5c531e)['query']];{let _0x2c6629=[];return _0x5c531e&&(_0x2c6629=_0x2c6629['concat'](Ko(_0x5c531e)['map'](_0x96a41e=>_0x96a41e['query']))),x(_0x3927e3,(_0x690cb9,_0x44d21e)=>{_0x2c6629=_0x2c6629['concat'](_0x44d21e);}),_0x2c6629;}});for(let _0x4a8e7d=0x0;_0x4a8e7d<_0x103c6f['length'];++_0x4a8e7d){const _0x420642=_0x103c6f[_0x4a8e7d];_0x2eb613['listenProvider_']['stopListening'](kt(_0x420642),Wt(_0x2eb613,_0x420642));}}return _0x236cc1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x9523f2){this['node_']=_0x9523f2;}['getImmediateChild'](_0x4bba16){const _0x2dee1c=this['node_']['getImmediateChild'](_0x4bba16);return new us(_0x2dee1c);}['node'](){return this['node_'];}}class ds{constructor(_0x2c0cb2,_0x3af6e6){this['syncTree_']=_0x2c0cb2,this['path_']=_0x3af6e6;}['getImmediateChild'](_0x219a5b){const _0x5c6ee8=k(this['path_'],_0x219a5b);return new ds(this['syncTree_'],_0x5c6ee8);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x486ae0){return _0x486ae0=_0x486ae0||{},_0x486ae0['timestamp']=_0x486ae0['timestamp']||new Date()['getTime'](),_0x486ae0;},_r=function(_0x3beeac,_0x2a94ca,_0xac0d88){if(!_0x3beeac||typeof _0x3beeac!='object')return _0x3beeac;if(f('.sv'in _0x3beeac,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3beeac['.sv']=='string')return sd(_0x3beeac['.sv'],_0x2a94ca,_0xac0d88);if(typeof _0x3beeac['.sv']=='object')return rd(_0x3beeac['.sv'],_0x2a94ca);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3beeac,null,0x2));},sd=function(_0x532d73,_0x4a56e4,_0x236c45){switch(_0x532d73){case'timestamp':return _0x236c45['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x532d73);}},rd=function(_0x3d15f0,_0x1d3419,_0x1e5136){_0x3d15f0['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3d15f0,null,0x2));const _0x5ecadf=_0x3d15f0['increment'];typeof _0x5ecadf!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5ecadf);const _0xb0637a=_0x1d3419['node']();if(f(_0xb0637a!==null&&typeof _0xb0637a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xb0637a['isLeafNode']())return _0x5ecadf;const _0x135d9c=_0xb0637a['getValue']();return typeof _0x135d9c!='number'?_0x5ecadf:_0x135d9c+_0x5ecadf;},ta=function(_0x19d178,_0x294553,_0x3bad3c,_0xaf0f59){return ps(_0x294553,new ds(_0x3bad3c,_0x19d178),_0xaf0f59);},fs=function(_0x35a726,_0x9256a2,_0x473dc7){return ps(_0x35a726,new us(_0x9256a2),_0x473dc7);};function ps(_0x158918,_0x21b08b,_0x21dcc7){const _0x5403c5=_0x158918['getPriority']()['val'](),_0x580689=_r(_0x5403c5,_0x21b08b['getImmediateChild']('.priority'),_0x21dcc7);let _0x2601d2;if(_0x158918['isLeafNode']()){const _0x36a970=_0x158918,_0x3dd8d6=_r(_0x36a970['getValue'](),_0x21b08b,_0x21dcc7);return _0x3dd8d6!==_0x36a970['getValue']()||_0x580689!==_0x36a970['getPriority']()['val']()?new D(_0x3dd8d6,A(_0x580689)):_0x158918;}else{const _0x3eec8f=_0x158918;return _0x2601d2=_0x3eec8f,_0x580689!==_0x3eec8f['getPriority']()['val']()&&(_0x2601d2=_0x2601d2['updatePriority'](new D(_0x580689))),_0x3eec8f['forEachChild'](R,(_0x5ca46a,_0x33e3df)=>{const _0x247cb8=ps(_0x33e3df,_0x21b08b['getImmediateChild'](_0x5ca46a),_0x21dcc7);_0x247cb8!==_0x33e3df&&(_0x2601d2=_0x2601d2['updateImmediateChild'](_0x5ca46a,_0x247cb8));}),_0x2601d2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x182939='',_0x476db7=null,_0x16cc58={'children':{},'childCount':0x0}){this['name']=_0x182939,this['parent']=_0x476db7,this['node']=_0x16cc58;}}function $n(_0x5752ce,_0x45b8ef){let _0x51c926=_0x45b8ef instanceof C?_0x45b8ef:new C(_0x45b8ef),_0x570ca2=_0x5752ce,_0xc2c08=y(_0x51c926);for(;_0xc2c08!==null;){const _0x25e990=Le(_0x570ca2['node']['children'],_0xc2c08)||{'children':{},'childCount':0x0};_0x570ca2=new _s(_0xc2c08,_0x570ca2,_0x25e990),_0x51c926=S(_0x51c926),_0xc2c08=y(_0x51c926);}return _0x570ca2;}function je(_0xe79d4d){return _0xe79d4d['node']['value'];}function gs(_0xa7f2d4,_0x59709f){_0xa7f2d4['node']['value']=_0x59709f,Oi(_0xa7f2d4);}function na(_0x433faa){return _0x433faa['node']['childCount']>0x0;}function od(_0x125b53){return je(_0x125b53)===void 0x0&&!na(_0x125b53);}function Gn(_0x40d42c,_0x4823d5){x(_0x40d42c['node']['children'],(_0x2c1afd,_0x5e632b)=>{_0x4823d5(new _s(_0x2c1afd,_0x40d42c,_0x5e632b));});}function ia(_0x39f56e,_0x487dd0,_0x2e6f61,_0xa40568){_0x2e6f61&&_0x487dd0(_0x39f56e),Gn(_0x39f56e,_0x39336e=>{ia(_0x39336e,_0x487dd0,!0x0);});}function ad(_0x342985,_0x307fff,_0x5693b4){let _0x16df5a=_0x342985['parent'];for(;_0x16df5a!==null;){if(_0x307fff(_0x16df5a))return!0x0;_0x16df5a=_0x16df5a['parent'];}return!0x1;}function Qt(_0x59e0f1){return new C(_0x59e0f1['parent']===null?_0x59e0f1['name']:Qt(_0x59e0f1['parent'])+'/'+_0x59e0f1['name']);}function Oi(_0x5706c4){_0x5706c4['parent']!==null&&cd(_0x5706c4['parent'],_0x5706c4['name'],_0x5706c4);}function cd(_0x810b1e,_0x1de9bd,_0x3f7175){const _0x27ea6a=od(_0x3f7175),_0xde7e88=Q(_0x810b1e['node']['children'],_0x1de9bd);_0x27ea6a&&_0xde7e88?(delete _0x810b1e['node']['children'][_0x1de9bd],_0x810b1e['node']['childCount']--,Oi(_0x810b1e)):!_0x27ea6a&&!_0xde7e88&&(_0x810b1e['node']['children'][_0x1de9bd]=_0x3f7175['node'],_0x810b1e['node']['childCount']++,Oi(_0x810b1e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x4c9b96){return typeof _0x4c9b96=='string'&&_0x4c9b96['length']!==0x0&&!ld['test'](_0x4c9b96);},sa=function(_0x2f8220){return typeof _0x2f8220=='string'&&_0x2f8220['length']!==0x0&&!hd['test'](_0x2f8220);},ud=function(_0x180ede){return _0x180ede&&(_0x180ede=_0x180ede['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x180ede);},Bt=function(_0x3ded9d){return _0x3ded9d===null||typeof _0x3ded9d=='string'||typeof _0x3ded9d=='number'&&!xn(_0x3ded9d)||_0x3ded9d&&typeof _0x3ded9d=='object'&&Q(_0x3ded9d,'.sv');},He=function(_0x249e78,_0x2122d8,_0x5d54f2,_0x471ec1){_0x471ec1&&_0x2122d8===void 0x0||Jt(it(_0x249e78,'value'),_0x2122d8,_0x5d54f2);},Jt=function(_0x269522,_0x503979,_0x1d52de){const _0x10d7d5=_0x1d52de instanceof C?new Ah(_0x1d52de,_0x269522):_0x1d52de;if(_0x503979===void 0x0)throw new Error(_0x269522+'contains\x20undefined\x20'+Oe(_0x10d7d5));if(typeof _0x503979=='function')throw new Error(_0x269522+'contains\x20a\x20function\x20'+Oe(_0x10d7d5)+'\x20with\x20contents\x20=\x20'+_0x503979['toString']());if(xn(_0x503979))throw new Error(_0x269522+'contains\x20'+_0x503979['toString']()+'\x20'+Oe(_0x10d7d5));if(typeof _0x503979=='string'&&_0x503979['length']>ui/0x3&&Ln(_0x503979)>ui)throw new Error(_0x269522+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x10d7d5)+'\x20(\x27'+_0x503979['substring'](0x0,0x32)+'...\x27)');if(_0x503979&&typeof _0x503979=='object'){let _0xd24b5e=!0x1,_0x126621=!0x1;if(x(_0x503979,(_0x1c34fb,_0x41e142)=>{if(_0x1c34fb==='.value')_0xd24b5e=!0x0;else{if(_0x1c34fb!=='.priority'&&_0x1c34fb!=='.sv'&&(_0x126621=!0x0,!ms(_0x1c34fb)))throw new Error(_0x269522+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1c34fb+')\x20'+Oe(_0x10d7d5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x10d7d5,_0x1c34fb),Jt(_0x269522,_0x41e142,_0x10d7d5),Ph(_0x10d7d5);}),_0xd24b5e&&_0x126621)throw new Error(_0x269522+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x10d7d5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x351a78,_0x4011cf){let _0x4c2bc4,_0x4e937a;for(_0x4c2bc4=0x0;_0x4c2bc4<_0x4011cf['length'];_0x4c2bc4++){_0x4e937a=_0x4011cf[_0x4c2bc4];const _0x1c7448=Mt(_0x4e937a);for(let _0x5e4768=0x0;_0x5e4768<_0x1c7448['length'];_0x5e4768++)if(!(_0x1c7448[_0x5e4768]==='.priority'&&_0x5e4768===_0x1c7448['length']-0x1)){if(!ms(_0x1c7448[_0x5e4768]))throw new Error(_0x351a78+'contains\x20an\x20invalid\x20key\x20('+_0x1c7448[_0x5e4768]+')\x20in\x20path\x20'+_0x4e937a['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4011cf['sort'](Rh);let _0x71a649=null;for(_0x4c2bc4=0x0;_0x4c2bc4<_0x4011cf['length'];_0x4c2bc4++){if(_0x4e937a=_0x4011cf[_0x4c2bc4],_0x71a649!==null&&G(_0x71a649,_0x4e937a))throw new Error(_0x351a78+'contains\x20a\x20path\x20'+_0x71a649['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4e937a['toString']());_0x71a649=_0x4e937a;}},ra=function(_0x536d65,_0x4b48e0,_0x1e7576,_0x57d91c){const _0x3ec1fd=it(_0x536d65,'values');if(!(_0x4b48e0&&typeof _0x4b48e0=='object')||Array['isArray'](_0x4b48e0))throw new Error(_0x3ec1fd+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x384e59=[];x(_0x4b48e0,(_0x3a0a4c,_0x296903)=>{const _0xdedab2=new C(_0x3a0a4c);if(Jt(_0x3ec1fd,_0x296903,k(_0x1e7576,_0xdedab2)),ji(_0xdedab2)==='.priority'&&!Bt(_0x296903))throw new Error(_0x3ec1fd+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xdedab2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x384e59['push'](_0xdedab2);}),dd(_0x3ec1fd,_0x384e59);},fd=function(_0x1bf445,_0x4d23b3,_0x161d4d){if(xn(_0x4d23b3))throw new Error(it(_0x1bf445,'priority')+'is\x20'+_0x4d23b3['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4d23b3))throw new Error(it(_0x1bf445,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x52de81,_0x4a6a7a,_0x5c8c43,_0x4517bd){if(!sa(_0x5c8c43))throw new Error(it(_0x52de81,_0x4a6a7a)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5c8c43+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xdffc6c,_0x20f5bf,_0x4dc01d,_0xfe5ad0){_0x4dc01d&&(_0x4dc01d=_0x4dc01d['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xdffc6c,_0x20f5bf,_0x4dc01d);},Me=function(_0x9011f0,_0x4f4fb2){if(y(_0x4f4fb2)==='.info')throw new Error(_0x9011f0+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x8c3d0e,_0x55bec2){const _0x1bea3e=_0x55bec2['path']['toString']();if(typeof _0x55bec2['repoInfo']['host']!='string'||_0x55bec2['repoInfo']['host']['length']===0x0||!ms(_0x55bec2['repoInfo']['namespace'])&&_0x55bec2['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1bea3e['length']!==0x0&&!ud(_0x1bea3e))throw new Error(it(_0x8c3d0e,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x5e712c,_0x3d6731){let _0x3d8fcf=null;for(let _0x5e2b48=0x0;_0x5e2b48<_0x3d6731['length'];_0x5e2b48++){const _0x13ae10=_0x3d6731[_0x5e2b48],_0x24eec7=_0x13ae10['getPath']();_0x3d8fcf!==null&&!Ki(_0x24eec7,_0x3d8fcf['path'])&&(_0x5e712c['eventLists_']['push'](_0x3d8fcf),_0x3d8fcf=null),_0x3d8fcf===null&&(_0x3d8fcf={'events':[],'path':_0x24eec7}),_0x3d8fcf['events']['push'](_0x13ae10);}_0x3d8fcf&&_0x5e712c['eventLists_']['push'](_0x3d8fcf);}function oa(_0x2c55bb,_0x3ee8cb,_0x35399c){qn(_0x2c55bb,_0x35399c),aa(_0x2c55bb,_0x1a8dc2=>Ki(_0x1a8dc2,_0x3ee8cb));}function V(_0x5ef960,_0x544a54,_0x166def){qn(_0x5ef960,_0x166def),aa(_0x5ef960,_0x587d62=>G(_0x587d62,_0x544a54)||G(_0x544a54,_0x587d62));}function aa(_0x3a07de,_0x4646d3){_0x3a07de['recursionDepth_']++;let _0x53c17e=!0x0;for(let _0x5e4585=0x0;_0x5e4585<_0x3a07de['eventLists_']['length'];_0x5e4585++){const _0x47e4d4=_0x3a07de['eventLists_'][_0x5e4585];if(_0x47e4d4){const _0x1fc947=_0x47e4d4['path'];_0x4646d3(_0x1fc947)?(md(_0x3a07de['eventLists_'][_0x5e4585]),_0x3a07de['eventLists_'][_0x5e4585]=null):_0x53c17e=!0x1;}}_0x53c17e&&(_0x3a07de['eventLists_']=[]),_0x3a07de['recursionDepth_']--;}function md(_0x3054f0){for(let _0x2f3dfa=0x0;_0x2f3dfa<_0x3054f0['events']['length'];_0x2f3dfa++){const _0x1412d2=_0x3054f0['events'][_0x2f3dfa];if(_0x1412d2!==null){_0x3054f0['events'][_0x2f3dfa]=null;const _0x263616=_0x1412d2['getEventRunner']();St&&L('event:\x20'+_0x1412d2['toString']()),ft(_0x263616);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1081ec,_0x4a41f9,_0x1f6b1b,_0x152e1c){this['repoInfo_']=_0x1081ec,this['forceRestClient_']=_0x4a41f9,this['authTokenProvider_']=_0x1f6b1b,this['appCheckProvider_']=_0x152e1c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x11ed82,_0x2528e9,_0x505578){if(_0x11ed82['stats_']=qi(_0x11ed82['repoInfo_']),_0x11ed82['forceRestClient_']||Xl())_0x11ed82['server_']=new vn(_0x11ed82['repoInfo_'],(_0x21aef6,_0x1fccab,_0x4de491,_0x4559ae)=>{gr(_0x11ed82,_0x21aef6,_0x1fccab,_0x4de491,_0x4559ae);},_0x11ed82['authTokenProvider_'],_0x11ed82['appCheckProvider_']),setTimeout(()=>mr(_0x11ed82,!0x0),0x0);else{if(typeof _0x505578<'u'&&_0x505578!==null){if(typeof _0x505578!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x505578);}catch(_0x3560f6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3560f6);}}_0x11ed82['persistentConnection_']=new se(_0x11ed82['repoInfo_'],_0x2528e9,(_0x3e4172,_0xccbba2,_0x1587c5,_0x23bbc2)=>{gr(_0x11ed82,_0x3e4172,_0xccbba2,_0x1587c5,_0x23bbc2);},_0x87b926=>{mr(_0x11ed82,_0x87b926);},_0x32a00d=>{Id(_0x11ed82,_0x32a00d);},_0x11ed82['authTokenProvider_'],_0x11ed82['appCheckProvider_'],_0x505578),_0x11ed82['server_']=_0x11ed82['persistentConnection_'];}_0x11ed82['authTokenProvider_']['addTokenChangeListener'](_0x753f50=>{_0x11ed82['server_']['refreshAuthToken'](_0x753f50);}),_0x11ed82['appCheckProvider_']['addTokenChangeListener'](_0x1e07d0=>{_0x11ed82['server_']['refreshAppCheckToken'](_0x1e07d0['token']);}),_0x11ed82['statsReporter_']=ih(_0x11ed82['repoInfo_'],()=>new iu(_0x11ed82['stats_'],_0x11ed82['server_'])),_0x11ed82['infoData_']=new Xh(),_0x11ed82['infoSyncTree_']=new pr({'startListening':(_0x312331,_0x49a967,_0x230f62,_0x2b0878)=>{let _0x5bd9e0=[];const _0x4e12d3=_0x11ed82['infoData_']['getNode'](_0x312331['_path']);return _0x4e12d3['isEmpty']()||(_0x5bd9e0=Yt(_0x11ed82['infoSyncTree_'],_0x312331['_path'],_0x4e12d3),setTimeout(()=>{_0x2b0878('ok');},0x0)),_0x5bd9e0;},'stopListening':()=>{}}),vs(_0x11ed82,'connected',!0x1),_0x11ed82['serverSyncTree_']=new pr({'startListening':(_0xd048e8,_0x5cb701,_0x410969,_0x1eae2a)=>(_0x11ed82['server_']['listen'](_0xd048e8,_0x410969,_0x5cb701,(_0x3a1a89,_0x2567b2)=>{const _0x903d4=_0x1eae2a(_0x3a1a89,_0x2567b2);V(_0x11ed82['eventQueue_'],_0xd048e8['_path'],_0x903d4);}),[]),'stopListening':(_0x6abea5,_0x4dd81d)=>{_0x11ed82['server_']['unlisten'](_0x6abea5,_0x4dd81d);}});}function la(_0x5daece){const _0x19fc49=_0x5daece['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x19fc49;}function Xt(_0xeb6bc0){return id({'timestamp':la(_0xeb6bc0)});}function gr(_0x57f45c,_0x2b1d89,_0x471cc3,_0x435a2d,_0x5b96e7){_0x57f45c['dataUpdateCount']++;const _0x464582=new C(_0x2b1d89);_0x471cc3=_0x57f45c['interceptServerDataCallback_']?_0x57f45c['interceptServerDataCallback_'](_0x2b1d89,_0x471cc3):_0x471cc3;let _0x4cfc9b=[];if(_0x5b96e7){if(_0x435a2d){const _0xb9a72d=_n(_0x471cc3,_0x3dc18a=>A(_0x3dc18a));_0x4cfc9b=Ju(_0x57f45c['serverSyncTree_'],_0x464582,_0xb9a72d,_0x5b96e7);}else{const _0x4e8989=A(_0x471cc3);_0x4cfc9b=Jo(_0x57f45c['serverSyncTree_'],_0x464582,_0x4e8989,_0x5b96e7);}}else{if(_0x435a2d){const _0x1ac156=_n(_0x471cc3,_0x10c38a=>A(_0x10c38a));_0x4cfc9b=Ku(_0x57f45c['serverSyncTree_'],_0x464582,_0x1ac156);}else{const _0x705c4f=A(_0x471cc3);_0x4cfc9b=Yt(_0x57f45c['serverSyncTree_'],_0x464582,_0x705c4f);}}let _0x163420=_0x464582;_0x4cfc9b['length']>0x0&&(_0x163420=ct(_0x57f45c,_0x464582)),V(_0x57f45c['eventQueue_'],_0x163420,_0x4cfc9b);}function mr(_0x5b76a1,_0xb91e1f){vs(_0x5b76a1,'connected',_0xb91e1f),_0xb91e1f===!0x1&&Sd(_0x5b76a1);}function Id(_0x92fa1d,_0xd1f70f){x(_0xd1f70f,(_0x313504,_0xbfd3e2)=>{vs(_0x92fa1d,_0x313504,_0xbfd3e2);});}function vs(_0x176c75,_0x3b5293,_0x503546){const _0x2c2ff9=new C('/.info/'+_0x3b5293),_0x43e232=A(_0x503546);_0x176c75['infoData_']['updateSnapshot'](_0x2c2ff9,_0x43e232);const _0x2155d5=Yt(_0x176c75['infoSyncTree_'],_0x2c2ff9,_0x43e232);V(_0x176c75['eventQueue_'],_0x2c2ff9,_0x2155d5);}function zn(_0x1cd3a7){return _0x1cd3a7['nextWriteId_']++;}function wd(_0x2be92b,_0x1592ff,_0x54d925){const _0x556ea6=Xu(_0x2be92b['serverSyncTree_'],_0x1592ff);return _0x556ea6!=null?Promise['resolve'](_0x556ea6):_0x2be92b['server_']['get'](_0x1592ff)['then'](_0x246fa4=>{const _0x3682ae=A(_0x246fa4)['withIndex'](_0x1592ff['_queryParams']['getIndex']());Ni(_0x2be92b['serverSyncTree_'],_0x1592ff,_0x54d925,!0x0);let _0x9caa23;if(_0x1592ff['_queryParams']['loadsAllData']())_0x9caa23=Yt(_0x2be92b['serverSyncTree_'],_0x1592ff['_path'],_0x3682ae);else{const _0x15a8d8=Wt(_0x2be92b['serverSyncTree_'],_0x1592ff);_0x9caa23=Jo(_0x2be92b['serverSyncTree_'],_0x1592ff['_path'],_0x3682ae,_0x15a8d8);}return V(_0x2be92b['eventQueue_'],_0x1592ff['_path'],_0x9caa23),An(_0x2be92b['serverSyncTree_'],_0x1592ff,_0x54d925,null,!0x0),_0x3682ae;},_0x58d5b8=>(gt(_0x2be92b,'get\x20for\x20query\x20'+O(_0x1592ff)+'\x20failed:\x20'+_0x58d5b8),Promise['reject'](new Error(_0x58d5b8))));}function Cd(_0x277c7c,_0x3286aa,_0x28bee3,_0x2dd548,_0x19f974){gt(_0x277c7c,'set',{'path':_0x3286aa['toString'](),'value':_0x28bee3,'priority':_0x2dd548});const _0x198ecc=Xt(_0x277c7c),_0x5bd315=A(_0x28bee3,_0x2dd548),_0x260654=Vn(_0x277c7c['serverSyncTree_'],_0x3286aa),_0x4119f3=fs(_0x5bd315,_0x260654,_0x198ecc),_0x50a162=zn(_0x277c7c),_0x365fe5=as(_0x277c7c['serverSyncTree_'],_0x3286aa,_0x4119f3,_0x50a162,!0x0);qn(_0x277c7c['eventQueue_'],_0x365fe5),_0x277c7c['server_']['put'](_0x3286aa['toString'](),_0x5bd315['val'](!0x0),(_0x597fd8,_0x540419)=>{const _0x322c3d=_0x597fd8==='ok';_0x322c3d||U('set\x20at\x20'+_0x3286aa+'\x20failed:\x20'+_0x597fd8);const _0x132b41=_e(_0x277c7c['serverSyncTree_'],_0x50a162,!_0x322c3d);V(_0x277c7c['eventQueue_'],_0x3286aa,_0x132b41),be(_0x277c7c,_0x19f974,_0x597fd8,_0x540419);});const _0x1f5c2d=Is(_0x277c7c,_0x3286aa);ct(_0x277c7c,_0x1f5c2d),V(_0x277c7c['eventQueue_'],_0x1f5c2d,[]);}function Td(_0x2ed395,_0x3aa3c4,_0x48679e,_0x236da7){gt(_0x2ed395,'update',{'path':_0x3aa3c4['toString'](),'value':_0x48679e});let _0x2b4757=!0x0;const _0x292d1b=Xt(_0x2ed395),_0xc8dc91={};if(x(_0x48679e,(_0x1a3c27,_0x1d5bd8)=>{_0x2b4757=!0x1,_0xc8dc91[_0x1a3c27]=ta(k(_0x3aa3c4,_0x1a3c27),A(_0x1d5bd8),_0x2ed395['serverSyncTree_'],_0x292d1b);}),_0x2b4757)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2ed395,_0x236da7,'ok',void 0x0);else{const _0x17dc7d=zn(_0x2ed395),_0x51a76f=ju(_0x2ed395['serverSyncTree_'],_0x3aa3c4,_0xc8dc91,_0x17dc7d);qn(_0x2ed395['eventQueue_'],_0x51a76f),_0x2ed395['server_']['merge'](_0x3aa3c4['toString'](),_0x48679e,(_0x1e76c5,_0x33df76)=>{const _0x3060e7=_0x1e76c5==='ok';_0x3060e7||U('update\x20at\x20'+_0x3aa3c4+'\x20failed:\x20'+_0x1e76c5);const _0xb1fa6c=_e(_0x2ed395['serverSyncTree_'],_0x17dc7d,!_0x3060e7),_0x484408=_0xb1fa6c['length']>0x0?ct(_0x2ed395,_0x3aa3c4):_0x3aa3c4;V(_0x2ed395['eventQueue_'],_0x484408,_0xb1fa6c),be(_0x2ed395,_0x236da7,_0x1e76c5,_0x33df76);}),x(_0x48679e,_0x272146=>{const _0x21778f=Is(_0x2ed395,k(_0x3aa3c4,_0x272146));ct(_0x2ed395,_0x21778f);}),V(_0x2ed395['eventQueue_'],_0x3aa3c4,[]);}}function Sd(_0x53c7ef){gt(_0x53c7ef,'onDisconnectEvents');const _0xcdade=Xt(_0x53c7ef),_0x25cfed=En();Si(_0x53c7ef['onDisconnect_'],w(),(_0xa3c786,_0x6d74a7)=>{const _0x13ba10=ta(_0xa3c786,_0x6d74a7,_0x53c7ef['serverSyncTree_'],_0xcdade);pt(_0x25cfed,_0xa3c786,_0x13ba10);});let _0x128baa=[];Si(_0x25cfed,w(),(_0x41eede,_0x4bd6bf)=>{_0x128baa=_0x128baa['concat'](Yt(_0x53c7ef['serverSyncTree_'],_0x41eede,_0x4bd6bf));const _0x143a6d=Is(_0x53c7ef,_0x41eede);ct(_0x53c7ef,_0x143a6d);}),_0x53c7ef['onDisconnect_']=En(),V(_0x53c7ef['eventQueue_'],w(),_0x128baa);}function bd(_0x2239b9,_0x5991c9,_0x526c33){_0x2239b9['server_']['onDisconnectCancel'](_0x5991c9['toString'](),(_0x21eeab,_0x218aa3)=>{_0x21eeab==='ok'&&Ti(_0x2239b9['onDisconnect_'],_0x5991c9),be(_0x2239b9,_0x526c33,_0x21eeab,_0x218aa3);});}function yr(_0x5a179e,_0x406c9e,_0x58ac95,_0x4df23e){const _0x33de75=A(_0x58ac95);_0x5a179e['server_']['onDisconnectPut'](_0x406c9e['toString'](),_0x33de75['val'](!0x0),(_0x5eb283,_0x488b74)=>{_0x5eb283==='ok'&&pt(_0x5a179e['onDisconnect_'],_0x406c9e,_0x33de75),be(_0x5a179e,_0x4df23e,_0x5eb283,_0x488b74);});}function Rd(_0x1956c2,_0x3b24a7,_0x4fd782,_0x3ab4e4,_0x1a02be){const _0xae788b=A(_0x4fd782,_0x3ab4e4);_0x1956c2['server_']['onDisconnectPut'](_0x3b24a7['toString'](),_0xae788b['val'](!0x0),(_0x2236c7,_0x29fe02)=>{_0x2236c7==='ok'&&pt(_0x1956c2['onDisconnect_'],_0x3b24a7,_0xae788b),be(_0x1956c2,_0x1a02be,_0x2236c7,_0x29fe02);});}function Ad(_0x88c7e6,_0x32d3b9,_0x358f3b,_0x2a9c58){if(pn(_0x358f3b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x88c7e6,_0x2a9c58,'ok',void 0x0);return;}_0x88c7e6['server_']['onDisconnectMerge'](_0x32d3b9['toString'](),_0x358f3b,(_0x2f17e7,_0x40817b)=>{_0x2f17e7==='ok'&&x(_0x358f3b,(_0x43e76f,_0x5d4021)=>{const _0x2652be=A(_0x5d4021);pt(_0x88c7e6['onDisconnect_'],k(_0x32d3b9,_0x43e76f),_0x2652be);}),be(_0x88c7e6,_0x2a9c58,_0x2f17e7,_0x40817b);});}function kd(_0x50a283,_0xb5cc48,_0x234a57){let _0x4b94e7;y(_0xb5cc48['_path'])==='.info'?_0x4b94e7=Ni(_0x50a283['infoSyncTree_'],_0xb5cc48,_0x234a57):_0x4b94e7=Ni(_0x50a283['serverSyncTree_'],_0xb5cc48,_0x234a57),oa(_0x50a283['eventQueue_'],_0xb5cc48['_path'],_0x4b94e7);}function Pd(_0xe4f662,_0x13ed5f,_0x3ee680){let _0x4239c5;y(_0x13ed5f['_path'])==='.info'?_0x4239c5=An(_0xe4f662['infoSyncTree_'],_0x13ed5f,_0x3ee680):_0x4239c5=An(_0xe4f662['serverSyncTree_'],_0x13ed5f,_0x3ee680),oa(_0xe4f662['eventQueue_'],_0x13ed5f['_path'],_0x4239c5);}function ha(_0x46bdac){_0x46bdac['persistentConnection_']&&_0x46bdac['persistentConnection_']['interrupt'](ca);}function Nd(_0x15d8fc){_0x15d8fc['persistentConnection_']&&_0x15d8fc['persistentConnection_']['resume'](ca);}function gt(_0x1b0fab,..._0x34873f){let _0x55d236='';_0x1b0fab['persistentConnection_']&&(_0x55d236=_0x1b0fab['persistentConnection_']['id']+':'),L(_0x55d236,..._0x34873f);}function be(_0x21aa88,_0x731ada,_0x34e419,_0x203b2a){_0x731ada&&ft(()=>{if(_0x34e419==='ok')_0x731ada(null);else{const _0x26c60f=(_0x34e419||'error')['toUpperCase']();let _0x541694=_0x26c60f;_0x203b2a&&(_0x541694+=':\x20'+_0x203b2a);const _0xea7e83=new Error(_0x541694);_0xea7e83['code']=_0x26c60f,_0x731ada(_0xea7e83);}});}function Od(_0x1dc7d2,_0x35b218,_0x2d1732,_0x5a12b7,_0x318c53,_0x39152e){gt(_0x1dc7d2,'transaction\x20on\x20'+_0x35b218);const _0x325e93={'path':_0x35b218,'update':_0x2d1732,'onComplete':_0x5a12b7,'status':null,'order':so(),'applyLocally':_0x39152e,'retryCount':0x0,'unwatcher':_0x318c53,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5231d0=Es(_0x1dc7d2,_0x35b218,void 0x0);_0x325e93['currentInputSnapshot']=_0x5231d0;const _0x16f3d1=_0x325e93['update'](_0x5231d0['val']());if(_0x16f3d1===void 0x0)_0x325e93['unwatcher'](),_0x325e93['currentOutputSnapshotRaw']=null,_0x325e93['currentOutputSnapshotResolved']=null,_0x325e93['onComplete']&&_0x325e93['onComplete'](null,!0x1,_0x325e93['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x16f3d1,_0x325e93['path']),_0x325e93['status']=0x0;const _0x39662c=$n(_0x1dc7d2['transactionQueueTree_'],_0x35b218),_0x5863b5=je(_0x39662c)||[];_0x5863b5['push'](_0x325e93),gs(_0x39662c,_0x5863b5);let _0x5fd05c;typeof _0x16f3d1=='object'&&_0x16f3d1!==null&&Q(_0x16f3d1,'.priority')?(_0x5fd05c=Le(_0x16f3d1,'.priority'),f(Bt(_0x5fd05c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5fd05c=(Vn(_0x1dc7d2['serverSyncTree_'],_0x35b218)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x35d26f=Xt(_0x1dc7d2),_0x5b2a6f=A(_0x16f3d1,_0x5fd05c),_0x370339=fs(_0x5b2a6f,_0x5231d0,_0x35d26f);_0x325e93['currentOutputSnapshotRaw']=_0x5b2a6f,_0x325e93['currentOutputSnapshotResolved']=_0x370339,_0x325e93['currentWriteId']=zn(_0x1dc7d2);const _0x228276=as(_0x1dc7d2['serverSyncTree_'],_0x35b218,_0x370339,_0x325e93['currentWriteId'],_0x325e93['applyLocally']);V(_0x1dc7d2['eventQueue_'],_0x35b218,_0x228276),jn(_0x1dc7d2,_0x1dc7d2['transactionQueueTree_']);}}function Es(_0x3ad375,_0x58832b,_0xaa3dc5){return Vn(_0x3ad375['serverSyncTree_'],_0x58832b,_0xaa3dc5)||g['EMPTY_NODE'];}function jn(_0x54a8c4,_0x466278=_0x54a8c4['transactionQueueTree_']){if(_0x466278||Kn(_0x54a8c4,_0x466278),je(_0x466278)){const _0x223c7d=da(_0x54a8c4,_0x466278);f(_0x223c7d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x223c7d['every'](_0x35fa5a=>_0x35fa5a['status']===0x0)&&Dd(_0x54a8c4,Qt(_0x466278),_0x223c7d);}else na(_0x466278)&&Gn(_0x466278,_0x2cefa4=>{jn(_0x54a8c4,_0x2cefa4);});}function Dd(_0x23aa24,_0x532fa8,_0x1734e2){const _0x56f5fc=_0x1734e2['map'](_0x1c0a6d=>_0x1c0a6d['currentWriteId']),_0x47bf4a=Es(_0x23aa24,_0x532fa8,_0x56f5fc);let _0x458421=_0x47bf4a;const _0x127ca6=_0x47bf4a['hash']();for(let _0x540109=0x0;_0x540109<_0x1734e2['length'];_0x540109++){const _0x24ba13=_0x1734e2[_0x540109];f(_0x24ba13['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x24ba13['status']=0x1,_0x24ba13['retryCount']++;const _0x4eda46=F(_0x532fa8,_0x24ba13['path']);_0x458421=_0x458421['updateChild'](_0x4eda46,_0x24ba13['currentOutputSnapshotRaw']);}const _0x3b065b=_0x458421['val'](!0x0),_0x467895=_0x532fa8;_0x23aa24['server_']['put'](_0x467895['toString'](),_0x3b065b,_0x43bdc7=>{gt(_0x23aa24,'transaction\x20put\x20response',{'path':_0x467895['toString'](),'status':_0x43bdc7});let _0x903535=[];if(_0x43bdc7==='ok'){const _0x2e3af0=[];for(let _0x43fea8=0x0;_0x43fea8<_0x1734e2['length'];_0x43fea8++)_0x1734e2[_0x43fea8]['status']=0x2,_0x903535=_0x903535['concat'](_e(_0x23aa24['serverSyncTree_'],_0x1734e2[_0x43fea8]['currentWriteId'])),_0x1734e2[_0x43fea8]['onComplete']&&_0x2e3af0['push'](()=>_0x1734e2[_0x43fea8]['onComplete'](null,!0x0,_0x1734e2[_0x43fea8]['currentOutputSnapshotResolved'])),_0x1734e2[_0x43fea8]['unwatcher']();Kn(_0x23aa24,$n(_0x23aa24['transactionQueueTree_'],_0x532fa8)),jn(_0x23aa24,_0x23aa24['transactionQueueTree_']),V(_0x23aa24['eventQueue_'],_0x532fa8,_0x903535);for(let _0xa53493=0x0;_0xa53493<_0x2e3af0['length'];_0xa53493++)ft(_0x2e3af0[_0xa53493]);}else{if(_0x43bdc7==='datastale'){for(let _0x3577c6=0x0;_0x3577c6<_0x1734e2['length'];_0x3577c6++)_0x1734e2[_0x3577c6]['status']===0x3?_0x1734e2[_0x3577c6]['status']=0x4:_0x1734e2[_0x3577c6]['status']=0x0;}else{U('transaction\x20at\x20'+_0x467895['toString']()+'\x20failed:\x20'+_0x43bdc7);for(let _0x501a55=0x0;_0x501a55<_0x1734e2['length'];_0x501a55++)_0x1734e2[_0x501a55]['status']=0x4,_0x1734e2[_0x501a55]['abortReason']=_0x43bdc7;}ct(_0x23aa24,_0x532fa8);}},_0x127ca6);}function ct(_0x459596,_0x40b6c7){const _0x396ada=ua(_0x459596,_0x40b6c7),_0xe4faf7=Qt(_0x396ada),_0x49ee55=da(_0x459596,_0x396ada);return Md(_0x459596,_0x49ee55,_0xe4faf7),_0xe4faf7;}function Md(_0x5315f8,_0x1abfea,_0xab3f3e){if(_0x1abfea['length']===0x0)return;const _0x51e2c4=[];let _0x159ae2=[];const _0x446ac3=_0x1abfea['filter'](_0x425031=>_0x425031['status']===0x0)['map'](_0x25ea3a=>_0x25ea3a['currentWriteId']);for(let _0x2a5544=0x0;_0x2a5544<_0x1abfea['length'];_0x2a5544++){const _0x1245ae=_0x1abfea[_0x2a5544],_0x5f21a6=F(_0xab3f3e,_0x1245ae['path']);let _0x20742c=!0x1,_0x537c5f;if(f(_0x5f21a6!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1245ae['status']===0x4)_0x20742c=!0x0,_0x537c5f=_0x1245ae['abortReason'],_0x159ae2=_0x159ae2['concat'](_e(_0x5315f8['serverSyncTree_'],_0x1245ae['currentWriteId'],!0x0));else{if(_0x1245ae['status']===0x0){if(_0x1245ae['retryCount']>=yd)_0x20742c=!0x0,_0x537c5f='maxretry',_0x159ae2=_0x159ae2['concat'](_e(_0x5315f8['serverSyncTree_'],_0x1245ae['currentWriteId'],!0x0));else{const _0x5e4e94=Es(_0x5315f8,_0x1245ae['path'],_0x446ac3);_0x1245ae['currentInputSnapshot']=_0x5e4e94;const _0x293810=_0x1abfea[_0x2a5544]['update'](_0x5e4e94['val']());if(_0x293810!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x293810,_0x1245ae['path']);let _0x32d599=A(_0x293810);typeof _0x293810=='object'&&_0x293810!=null&&Q(_0x293810,'.priority')||(_0x32d599=_0x32d599['updatePriority'](_0x5e4e94['getPriority']()));const _0x568c45=_0x1245ae['currentWriteId'],_0x2a3ae1=Xt(_0x5315f8),_0x5a722b=fs(_0x32d599,_0x5e4e94,_0x2a3ae1);_0x1245ae['currentOutputSnapshotRaw']=_0x32d599,_0x1245ae['currentOutputSnapshotResolved']=_0x5a722b,_0x1245ae['currentWriteId']=zn(_0x5315f8),_0x446ac3['splice'](_0x446ac3['indexOf'](_0x568c45),0x1),_0x159ae2=_0x159ae2['concat'](as(_0x5315f8['serverSyncTree_'],_0x1245ae['path'],_0x5a722b,_0x1245ae['currentWriteId'],_0x1245ae['applyLocally'])),_0x159ae2=_0x159ae2['concat'](_e(_0x5315f8['serverSyncTree_'],_0x568c45,!0x0));}else _0x20742c=!0x0,_0x537c5f='nodata',_0x159ae2=_0x159ae2['concat'](_e(_0x5315f8['serverSyncTree_'],_0x1245ae['currentWriteId'],!0x0));}}}V(_0x5315f8['eventQueue_'],_0xab3f3e,_0x159ae2),_0x159ae2=[],_0x20742c&&(_0x1abfea[_0x2a5544]['status']=0x2,function(_0x32d90f){setTimeout(_0x32d90f,Math['floor'](0x0));}(_0x1abfea[_0x2a5544]['unwatcher']),_0x1abfea[_0x2a5544]['onComplete']&&(_0x537c5f==='nodata'?_0x51e2c4['push'](()=>_0x1abfea[_0x2a5544]['onComplete'](null,!0x1,_0x1abfea[_0x2a5544]['currentInputSnapshot'])):_0x51e2c4['push'](()=>_0x1abfea[_0x2a5544]['onComplete'](new Error(_0x537c5f),!0x1,null))));}Kn(_0x5315f8,_0x5315f8['transactionQueueTree_']);for(let _0x1106eb=0x0;_0x1106eb<_0x51e2c4['length'];_0x1106eb++)ft(_0x51e2c4[_0x1106eb]);jn(_0x5315f8,_0x5315f8['transactionQueueTree_']);}function ua(_0x5edc7b,_0x245dd5){let _0x3bfe11,_0x3ac5ad=_0x5edc7b['transactionQueueTree_'];for(_0x3bfe11=y(_0x245dd5);_0x3bfe11!==null&&je(_0x3ac5ad)===void 0x0;)_0x3ac5ad=$n(_0x3ac5ad,_0x3bfe11),_0x245dd5=S(_0x245dd5),_0x3bfe11=y(_0x245dd5);return _0x3ac5ad;}function da(_0x3b6633,_0x76ebbb){const _0x5cdb57=[];return fa(_0x3b6633,_0x76ebbb,_0x5cdb57),_0x5cdb57['sort']((_0x574256,_0x423982)=>_0x574256['order']-_0x423982['order']),_0x5cdb57;}function fa(_0x7c489f,_0x16538e,_0x34bf7d){const _0x3129c8=je(_0x16538e);if(_0x3129c8){for(let _0x3082f4=0x0;_0x3082f4<_0x3129c8['length'];_0x3082f4++)_0x34bf7d['push'](_0x3129c8[_0x3082f4]);}Gn(_0x16538e,_0x2a3ad2=>{fa(_0x7c489f,_0x2a3ad2,_0x34bf7d);});}function Kn(_0x23c177,_0x5db972){const _0x10e81e=je(_0x5db972);if(_0x10e81e){let _0x4741a9=0x0;for(let _0x10f57f=0x0;_0x10f57f<_0x10e81e['length'];_0x10f57f++)_0x10e81e[_0x10f57f]['status']!==0x2&&(_0x10e81e[_0x4741a9]=_0x10e81e[_0x10f57f],_0x4741a9++);_0x10e81e['length']=_0x4741a9,gs(_0x5db972,_0x10e81e['length']>0x0?_0x10e81e:void 0x0);}Gn(_0x5db972,_0x23cce4=>{Kn(_0x23c177,_0x23cce4);});}function Is(_0x528e02,_0x41799d){const _0x293651=Qt(ua(_0x528e02,_0x41799d)),_0x330f94=$n(_0x528e02['transactionQueueTree_'],_0x41799d);return ad(_0x330f94,_0x3766a4=>{di(_0x528e02,_0x3766a4);}),di(_0x528e02,_0x330f94),ia(_0x330f94,_0x5c2a7d=>{di(_0x528e02,_0x5c2a7d);}),_0x293651;}function di(_0x253c57,_0x29e84a){const _0x305d77=je(_0x29e84a);if(_0x305d77){const _0x3b3183=[];let _0x52d0d6=[],_0x2a5ebd=-0x1;for(let _0x5acf5b=0x0;_0x5acf5b<_0x305d77['length'];_0x5acf5b++)_0x305d77[_0x5acf5b]['status']===0x3||(_0x305d77[_0x5acf5b]['status']===0x1?(f(_0x2a5ebd===_0x5acf5b-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2a5ebd=_0x5acf5b,_0x305d77[_0x5acf5b]['status']=0x3,_0x305d77[_0x5acf5b]['abortReason']='set'):(f(_0x305d77[_0x5acf5b]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x305d77[_0x5acf5b]['unwatcher'](),_0x52d0d6=_0x52d0d6['concat'](_e(_0x253c57['serverSyncTree_'],_0x305d77[_0x5acf5b]['currentWriteId'],!0x0)),_0x305d77[_0x5acf5b]['onComplete']&&_0x3b3183['push'](_0x305d77[_0x5acf5b]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2a5ebd===-0x1?gs(_0x29e84a,void 0x0):_0x305d77['length']=_0x2a5ebd+0x1,V(_0x253c57['eventQueue_'],Qt(_0x29e84a),_0x52d0d6);for(let _0xcf26c8=0x0;_0xcf26c8<_0x3b3183['length'];_0xcf26c8++)ft(_0x3b3183[_0xcf26c8]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4e806d){let _0x456979='';const _0x2f44d7=_0x4e806d['split']('/');for(let _0x2c415d=0x0;_0x2c415d<_0x2f44d7['length'];_0x2c415d++)if(_0x2f44d7[_0x2c415d]['length']>0x0){let _0x354080=_0x2f44d7[_0x2c415d];try{_0x354080=decodeURIComponent(_0x354080['replace'](/\+/g,'\x20'));}catch{}_0x456979+='/'+_0x354080;}return _0x456979;}function xd(_0x4f9e1e){const _0xb45a15={};_0x4f9e1e['charAt'](0x0)==='?'&&(_0x4f9e1e=_0x4f9e1e['substring'](0x1));for(const _0x906dd4 of _0x4f9e1e['split']('&')){if(_0x906dd4['length']===0x0)continue;const _0x1d5bc2=_0x906dd4['split']('=');_0x1d5bc2['length']===0x2?_0xb45a15[decodeURIComponent(_0x1d5bc2[0x0])]=decodeURIComponent(_0x1d5bc2[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x906dd4+'\x27\x20in\x20query\x20\x27'+_0x4f9e1e+'\x27');}return _0xb45a15;}const vr=function(_0x2fd87f,_0x494341){const _0x137e17=Fd(_0x2fd87f),_0x5e03db=_0x137e17['namespace'];_0x137e17['domain']==='firebase.com'&&ae(_0x137e17['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5e03db||_0x5e03db==='undefined')&&_0x137e17['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x137e17['secure']||$l();const _0x22c95f=_0x137e17['scheme']==='ws'||_0x137e17['scheme']==='wss';return{'repoInfo':new yo(_0x137e17['host'],_0x137e17['secure'],_0x5e03db,_0x22c95f,_0x494341,'',_0x5e03db!==_0x137e17['subdomain']),'path':new C(_0x137e17['pathString'])};},Fd=function(_0x84d3c2){let _0xe5d19a='',_0xf5a4d9='',_0x11b136='',_0x54aee4='',_0xdb3889='',_0x3e82ec=!0x0,_0x33adf3='https',_0x147ffb=0x1bb;if(typeof _0x84d3c2=='string'){let _0x1fd82d=_0x84d3c2['indexOf']('//');_0x1fd82d>=0x0&&(_0x33adf3=_0x84d3c2['substring'](0x0,_0x1fd82d-0x1),_0x84d3c2=_0x84d3c2['substring'](_0x1fd82d+0x2));let _0x459752=_0x84d3c2['indexOf']('/');_0x459752===-0x1&&(_0x459752=_0x84d3c2['length']);let _0x1fea92=_0x84d3c2['indexOf']('?');_0x1fea92===-0x1&&(_0x1fea92=_0x84d3c2['length']),_0xe5d19a=_0x84d3c2['substring'](0x0,Math['min'](_0x459752,_0x1fea92)),_0x459752<_0x1fea92&&(_0x54aee4=Ld(_0x84d3c2['substring'](_0x459752,_0x1fea92)));const _0x315269=xd(_0x84d3c2['substring'](Math['min'](_0x84d3c2['length'],_0x1fea92)));_0x1fd82d=_0xe5d19a['indexOf'](':'),_0x1fd82d>=0x0?(_0x3e82ec=_0x33adf3==='https'||_0x33adf3==='wss',_0x147ffb=parseInt(_0xe5d19a['substring'](_0x1fd82d+0x1),0xa)):_0x1fd82d=_0xe5d19a['length'];const _0x40fb36=_0xe5d19a['slice'](0x0,_0x1fd82d);if(_0x40fb36['toLowerCase']()==='localhost')_0xf5a4d9='localhost';else{if(_0x40fb36['split']('.')['length']<=0x2)_0xf5a4d9=_0x40fb36;else{const _0x48f31b=_0xe5d19a['indexOf']('.');_0x11b136=_0xe5d19a['substring'](0x0,_0x48f31b)['toLowerCase'](),_0xf5a4d9=_0xe5d19a['substring'](_0x48f31b+0x1),_0xdb3889=_0x11b136;}}'ns'in _0x315269&&(_0xdb3889=_0x315269['ns']);}return{'host':_0xe5d19a,'port':_0x147ffb,'domain':_0xf5a4d9,'subdomain':_0x11b136,'secure':_0x3e82ec,'scheme':_0x33adf3,'pathString':_0x54aee4,'namespace':_0xdb3889};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x278e4a=0x0;const _0x57b978=[];return function(_0x4e42de){const _0x31735b=_0x4e42de===_0x278e4a;_0x278e4a=_0x4e42de;let _0x22fc0a;const _0x21c2f9=new Array(0x8);for(_0x22fc0a=0x7;_0x22fc0a>=0x0;_0x22fc0a--)_0x21c2f9[_0x22fc0a]=Er['charAt'](_0x4e42de%0x40),_0x4e42de=Math['floor'](_0x4e42de/0x40);f(_0x4e42de===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x451317=_0x21c2f9['join']('');if(_0x31735b){for(_0x22fc0a=0xb;_0x22fc0a>=0x0&&_0x57b978[_0x22fc0a]===0x3f;_0x22fc0a--)_0x57b978[_0x22fc0a]=0x0;_0x57b978[_0x22fc0a]++;}else{for(_0x22fc0a=0x0;_0x22fc0a<0xc;_0x22fc0a++)_0x57b978[_0x22fc0a]=Math['floor'](Math['random']()*0x40);}for(_0x22fc0a=0x0;_0x22fc0a<0xc;_0x22fc0a++)_0x451317+=Er['charAt'](_0x57b978[_0x22fc0a]);return f(_0x451317['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x451317;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x38d3f4,_0x3b7bf2,_0x57146a,_0x5cefe8){this['eventType']=_0x38d3f4,this['eventRegistration']=_0x3b7bf2,this['snapshot']=_0x57146a,this['prevName']=_0x5cefe8;}['getPath'](){const _0xa419cf=this['snapshot']['ref'];return this['eventType']==='value'?_0xa419cf['_path']:_0xa419cf['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2cb537,_0x54a0af,_0x15bfe0){this['eventRegistration']=_0x2cb537,this['error']=_0x54a0af,this['path']=_0x15bfe0;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1f2b1e,_0x457477){this['snapshotCallback']=_0x1f2b1e,this['cancelCallback']=_0x457477;}['onValue'](_0x25629e,_0x56057f){this['snapshotCallback']['call'](null,_0x25629e,_0x56057f);}['onCancel'](_0x523006){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x523006);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x542aa1){return this['snapshotCallback']===_0x542aa1['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x542aa1['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x542aa1['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x561eb0,_0x2e0890){this['_repo']=_0x561eb0,this['_path']=_0x2e0890;}['cancel'](){const _0x20f1dc=new H();return bd(this['_repo'],this['_path'],_0x20f1dc['wrapCallback'](()=>{})),_0x20f1dc['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x44305e=new H();return yr(this['_repo'],this['_path'],null,_0x44305e['wrapCallback'](()=>{})),_0x44305e['promise'];}['set'](_0x14af24){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x14af24,this['_path'],!0x1);const _0x441606=new H();return yr(this['_repo'],this['_path'],_0x14af24,_0x441606['wrapCallback'](()=>{})),_0x441606['promise'];}['setWithPriority'](_0x1ca16c,_0x1502ce){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x1ca16c,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1502ce);const _0x5c26b6=new H();return Rd(this['_repo'],this['_path'],_0x1ca16c,_0x1502ce,_0x5c26b6['wrapCallback'](()=>{})),_0x5c26b6['promise'];}['update'](_0x26b7de){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x26b7de,this['_path']);const _0x1dffcb=new H();return Ad(this['_repo'],this['_path'],_0x26b7de,_0x1dffcb['wrapCallback'](()=>{})),_0x1dffcb['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x228c31,_0x221995,_0x5e07de,_0x2282a9){this['_repo']=_0x228c31,this['_path']=_0x221995,this['_queryParams']=_0x5e07de,this['_orderByCalled']=_0x2282a9;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1e1cf4=sr(this['_queryParams']),_0x269fdd=$i(_0x1e1cf4);return _0x269fdd==='{}'?'default':_0x269fdd;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2dad33){if(_0x2dad33=P(_0x2dad33),!(_0x2dad33 instanceof Ae))return!0x1;const _0x3367d6=this['_repo']===_0x2dad33['_repo'],_0x589c51=Ki(this['_path'],_0x2dad33['_path']),_0x301fb5=this['_queryIdentifier']===_0x2dad33['_queryIdentifier'];return _0x3367d6&&_0x589c51&&_0x301fb5;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x18f7a8,_0x3a4c41){if(_0x18f7a8['_orderByCalled']===!0x0)throw new Error(_0x3a4c41+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x24e8c2){let _0xd6fcb9=null,_0x4e7202=null;if(_0x24e8c2['hasStart']()&&(_0xd6fcb9=_0x24e8c2['getIndexStartValue']()),_0x24e8c2['hasEnd']()&&(_0x4e7202=_0x24e8c2['getIndexEndValue']()),_0x24e8c2['getIndex']()===ve){const _0x4b4683='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1af20d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x24e8c2['hasStart']()){if(_0x24e8c2['getIndexStartName']()!==We)throw new Error(_0x4b4683);if(typeof _0xd6fcb9!='string')throw new Error(_0x1af20d);}if(_0x24e8c2['hasEnd']()){if(_0x24e8c2['getIndexEndName']()!==we)throw new Error(_0x4b4683);if(typeof _0x4e7202!='string')throw new Error(_0x1af20d);}}else{if(_0x24e8c2['getIndex']()===R){if(_0xd6fcb9!=null&&!Bt(_0xd6fcb9)||_0x4e7202!=null&&!Bt(_0x4e7202))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x24e8c2['getIndex']()instanceof Ji||_0x24e8c2['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xd6fcb9!=null&&typeof _0xd6fcb9=='object'||_0x4e7202!=null&&typeof _0x4e7202=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x5a504a){if(_0x5a504a['hasStart']()&&_0x5a504a['hasEnd']()&&_0x5a504a['hasLimit']()&&!_0x5a504a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5a8277,_0xbbdca1){super(_0x5a8277,_0xbbdca1,new Zi(),!0x1);}get['parent'](){const _0x11e8e6=Ro(this['_path']);return _0x11e8e6===null?null:new ee(this['_repo'],_0x11e8e6);}get['root'](){let _0x484f9=this;for(;_0x484f9['parent']!==null;)_0x484f9=_0x484f9['parent'];return _0x484f9;}}class lt{constructor(_0x2dc316,_0x7cded9,_0x289896){this['_node']=_0x2dc316,this['ref']=_0x7cded9,this['_index']=_0x289896;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2fd3d0){const _0x117df2=new C(_0x2fd3d0),_0x2caf10=Vt(this['ref'],_0x2fd3d0);return new lt(this['_node']['getChild'](_0x117df2),_0x2caf10,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x514022){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x565f2d,_0xe5c0e0)=>_0x514022(new lt(_0xe5c0e0,Vt(this['ref'],_0x565f2d),R)));}['hasChild'](_0x4aeff8){const _0x54fe49=new C(_0x4aeff8);return!this['_node']['getChild'](_0x54fe49)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x2fbe2b,_0x31adb5){return _0x2fbe2b=P(_0x2fbe2b),_0x2fbe2b['_checkNotDeleted']('ref'),_0x31adb5!==void 0x0?Vt(_0x2fbe2b['_root'],_0x31adb5):_0x2fbe2b['_root'];}function Vt(_0x31896f,_0x325fae){return _0x31896f=P(_0x31896f),y(_0x31896f['_path'])===null?pd('child','path',_0x325fae):ys('child','path',_0x325fae),new ee(_0x31896f['_repo'],k(_0x31896f['_path'],_0x325fae));}function v_(_0x497675){return _0x497675=P(_0x497675),new Vd(_0x497675['_repo'],_0x497675['_path']);}function E_(_0x526f23,_0x50c153){_0x526f23=P(_0x526f23),Me('push',_0x526f23['_path']),He('push',_0x50c153,_0x526f23['_path'],!0x0);const _0x1cbc29=la(_0x526f23['_repo']),_0x4fdaff=Ud(_0x1cbc29),_0x5868c8=Vt(_0x526f23,_0x4fdaff),_0x1ccc91=Vt(_0x526f23,_0x4fdaff);let _0x4455e8;return _0x50c153!=null?_0x4455e8=Hd(_0x1ccc91,_0x50c153)['then'](()=>_0x1ccc91):_0x4455e8=Promise['resolve'](_0x1ccc91),_0x5868c8['then']=_0x4455e8['then']['bind'](_0x4455e8),_0x5868c8['catch']=_0x4455e8['then']['bind'](_0x4455e8,void 0x0),_0x5868c8;}function Hd(_0x28abe5,_0x9a013f){_0x28abe5=P(_0x28abe5),Me('set',_0x28abe5['_path']),He('set',_0x9a013f,_0x28abe5['_path'],!0x1);const _0xfab9c=new H();return Cd(_0x28abe5['_repo'],_0x28abe5['_path'],_0x9a013f,null,_0xfab9c['wrapCallback'](()=>{})),_0xfab9c['promise'];}function I_(_0x25ca08,_0x192fac){ra('update',_0x192fac,_0x25ca08['_path']);const _0xe8ed26=new H();return Td(_0x25ca08['_repo'],_0x25ca08['_path'],_0x192fac,_0xe8ed26['wrapCallback'](()=>{})),_0xe8ed26['promise'];}function w_(_0x9ab51c){_0x9ab51c=P(_0x9ab51c);const _0x383bfd=new pa(()=>{}),_0x5421f5=new Qn(_0x383bfd);return wd(_0x9ab51c['_repo'],_0x9ab51c,_0x5421f5)['then'](_0x58b3d1=>new lt(_0x58b3d1,new ee(_0x9ab51c['_repo'],_0x9ab51c['_path']),_0x9ab51c['_queryParams']['getIndex']()));}class Qn{constructor(_0x1c4644){this['callbackContext']=_0x1c4644;}['respondsTo'](_0x457ef2){return _0x457ef2==='value';}['createEvent'](_0x370903,_0x187c4d){const _0x4d0e79=_0x187c4d['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x370903['snapshotNode'],new ee(_0x187c4d['_repo'],_0x187c4d['_path']),_0x4d0e79));}['getEventRunner'](_0x494fb7){return _0x494fb7['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x494fb7['error']):()=>this['callbackContext']['onValue'](_0x494fb7['snapshot'],null);}['createCancelEvent'](_0x5ebac4,_0x220e40){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5ebac4,_0x220e40):null;}['matches'](_0x3f188c){return _0x3f188c instanceof Qn?!_0x3f188c['callbackContext']||!this['callbackContext']?!0x0:_0x3f188c['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x9cc801,_0x4ae863,_0x558d71,_0x22d359,_0xf7b8c0){const _0x385a76=new pa(_0x558d71,void 0x0),_0x38c6a5=new Qn(_0x385a76);return kd(_0x9cc801['_repo'],_0x9cc801,_0x38c6a5),()=>Pd(_0x9cc801['_repo'],_0x9cc801,_0x38c6a5);}function Gd(_0x3af803,_0x54206f,_0x4cee0f,_0x26ed7c){return $d(_0x3af803,'value',_0x54206f);}class mt{}class ma extends mt{constructor(_0x4d189d,_0x146435){super(),this['_value']=_0x4d189d,this['_key']=_0x146435,this['type']='endAt';}['_apply'](_0xb4e5cb){He('endAt',this['_value'],_0xb4e5cb['_path'],!0x0);const _0x58dddf=Jh(_0xb4e5cb['_queryParams'],this['_value'],this['_key']);if(ga(_0x58dddf),Yn(_0x58dddf),_0xb4e5cb['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0xb4e5cb['_repo'],_0xb4e5cb['_path'],_0x58dddf,_0xb4e5cb['_orderByCalled']);}}function C_(_0x10c9c2,_0x2d9ae3){return new ma(_0x10c9c2,_0x2d9ae3);}class ya extends mt{constructor(_0x40a6a2,_0xaccbe0){super(),this['_value']=_0x40a6a2,this['_key']=_0xaccbe0,this['type']='startAt';}['_apply'](_0x292067){He('startAt',this['_value'],_0x292067['_path'],!0x0);const _0x3aff25=Qh(_0x292067['_queryParams'],this['_value'],this['_key']);if(ga(_0x3aff25),Yn(_0x3aff25),_0x292067['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x292067['_repo'],_0x292067['_path'],_0x3aff25,_0x292067['_orderByCalled']);}}function T_(_0x5950ae=null,_0x157a87){return new ya(_0x5950ae,_0x157a87);}class qd extends mt{constructor(_0x171580){super(),this['_limit']=_0x171580,this['type']='limitToFirst';}['_apply'](_0x4451e3){if(_0x4451e3['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4451e3['_repo'],_0x4451e3['_path'],Yh(_0x4451e3['_queryParams'],this['_limit']),_0x4451e3['_orderByCalled']);}}function S_(_0x3aa0ae){if(Math['floor'](_0x3aa0ae)!==_0x3aa0ae||_0x3aa0ae<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3aa0ae);}class zd extends mt{constructor(_0x3bdf74){super(),this['_path']=_0x3bdf74,this['type']='orderByChild';}['_apply'](_0x1152a8){_a(_0x1152a8,'orderByChild');const _0x1bd238=new C(this['_path']);if(v(_0x1bd238))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3cdbf=new Ji(_0x1bd238),_0x3b65c6=xo(_0x1152a8['_queryParams'],_0x3cdbf);return Yn(_0x3b65c6),new Ae(_0x1152a8['_repo'],_0x1152a8['_path'],_0x3b65c6,!0x0);}}function b_(_0x56c76a){if(_0x56c76a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x56c76a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x56c76a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x56c76a),new zd(_0x56c76a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x439bc7){_a(_0x439bc7,'orderByKey');const _0x135102=xo(_0x439bc7['_queryParams'],ve);return Yn(_0x135102),new Ae(_0x439bc7['_repo'],_0x439bc7['_path'],_0x135102,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x11e453,_0x3b7af1){super(),this['_value']=_0x11e453,this['_key']=_0x3b7af1,this['type']='equalTo';}['_apply'](_0x18c5aa){if(He('equalTo',this['_value'],_0x18c5aa['_path'],!0x1),_0x18c5aa['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x18c5aa['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x18c5aa));}}function A_(_0x1f8083,_0xc5f59b){return new Kd(_0x1f8083,_0xc5f59b);}function k_(_0x430ffa,..._0x35e339){let _0x33297a=P(_0x430ffa);for(const _0x2ea587 of _0x35e339)_0x33297a=_0x2ea587['_apply'](_0x33297a);return _0x33297a;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1ae668,_0x5ce452,_0x2501e8,_0x3ee421){const _0x31f420=_0x5ce452['lastIndexOf'](':'),_0x25bd74=_0x5ce452['substring'](0x0,_0x31f420),_0x356ddb=qt(_0x25bd74);_0x1ae668['repoInfo_']=new yo(_0x5ce452,_0x356ddb,_0x1ae668['repoInfo_']['namespace'],_0x1ae668['repoInfo_']['webSocketOnly'],_0x1ae668['repoInfo_']['nodeAdmin'],_0x1ae668['repoInfo_']['persistenceKey'],_0x1ae668['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2501e8),_0x3ee421&&(_0x1ae668['authTokenProvider_']=_0x3ee421);}function Xd(_0x1887a7,_0x34cc3b,_0x2f5873,_0x493739,_0x15ebc0){let _0x12c994=_0x493739||_0x1887a7['options']['databaseURL'];_0x12c994===void 0x0&&(_0x1887a7['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1887a7['options']['projectId']),_0x12c994=_0x1887a7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5cacf8=vr(_0x12c994,_0x15ebc0),_0x52d8cf=_0x5cacf8['repoInfo'],_0x343f0f;typeof process<'u'&&Bs&&(_0x343f0f=Bs[Yd]),_0x343f0f?(_0x12c994='http://'+_0x343f0f+'?ns='+_0x52d8cf['namespace'],_0x5cacf8=vr(_0x12c994,_0x15ebc0),_0x52d8cf=_0x5cacf8['repoInfo']):_0x5cacf8['repoInfo']['secure'];const _0x1bac61=new eh(_0x1887a7['name'],_0x1887a7['options'],_0x34cc3b);_d('Invalid\x20Firebase\x20Database\x20URL',_0x5cacf8),v(_0x5cacf8['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x222fd1=ef(_0x52d8cf,_0x1887a7,_0x1bac61,new Zl(_0x1887a7,_0x2f5873));return new tf(_0x222fd1,_0x1887a7);}function Zd(_0x5ba08f,_0x2ebdc3){const _0x1e52fd=Di[_0x2ebdc3];(!_0x1e52fd||_0x1e52fd[_0x5ba08f['key']]!==_0x5ba08f)&&ae('Database\x20'+_0x2ebdc3+'('+_0x5ba08f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x5ba08f),delete _0x1e52fd[_0x5ba08f['key']];}function ef(_0x48a939,_0xb42842,_0x5a8e55,_0x40b758){let _0x2abb97=Di[_0xb42842['name']];_0x2abb97||(_0x2abb97={},Di[_0xb42842['name']]=_0x2abb97);let _0x3a1347=_0x2abb97[_0x48a939['toURLString']()];return _0x3a1347&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3a1347=new vd(_0x48a939,Qd,_0x5a8e55,_0x40b758),_0x2abb97[_0x48a939['toURLString']()]=_0x3a1347,_0x3a1347;}class tf{constructor(_0x3a6674,_0x50ce8a){this['_repoInternal']=_0x3a6674,this['app']=_0x50ce8a,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3a3be0){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3a3be0+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2db6a3=Zr(),_0x48613f){const _0xc8a4c9=Hi(_0x2db6a3,'database')['getImmediate']({'identifier':_0x48613f});if(!_0xc8a4c9['_instanceStarted']){const _0x176e82=hc('database');_0x176e82&&nf(_0xc8a4c9,..._0x176e82);}return _0xc8a4c9;}function nf(_0x3b4494,_0x93a98f,_0x261190,_0x2b2bb8={}){_0x3b4494=P(_0x3b4494),_0x3b4494['_checkNotDeleted']('useEmulator');const _0x230869=_0x93a98f+':'+_0x261190,_0x1b12ce=_0x3b4494['_repoInternal'];if(_0x3b4494['_instanceStarted']){if(_0x230869===_0x3b4494['_repoInternal']['repoInfo_']['host']&&xe(_0x2b2bb8,_0x1b12ce['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xb50c81;if(_0x1b12ce['repoInfo_']['nodeAdmin'])_0x2b2bb8['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xb50c81=new an(an['OWNER']);else{if(_0x2b2bb8['mockUserToken']){const _0x3fafd2=typeof _0x2b2bb8['mockUserToken']=='string'?_0x2b2bb8['mockUserToken']:uc(_0x2b2bb8['mockUserToken'],_0x3b4494['app']['options']['projectId']);_0xb50c81=new an(_0x3fafd2);}}qt(_0x93a98f)&&Qr(_0x93a98f),Jd(_0x1b12ce,_0x230869,_0x2b2bb8,_0xb50c81);}function N_(_0x7a68de){_0x7a68de=P(_0x7a68de),_0x7a68de['_checkNotDeleted']('goOffline'),ha(_0x7a68de['_repo']);}function O_(_0x1b81bb){_0x1b81bb=P(_0x1b81bb),_0x1b81bb['_checkNotDeleted']('goOnline'),Nd(_0x1b81bb['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x337a6d){Ul(dt),st(new Fe('database',(_0xe0840b,{instanceIdentifier:_0x2e010a})=>{const _0x10c88e=_0xe0840b['getProvider']('app')['getImmediate'](),_0x3745a8=_0xe0840b['getProvider']('auth-internal'),_0x5d70aa=_0xe0840b['getProvider']('app-check-internal');return Xd(_0x10c88e,_0x3745a8,_0x5d70aa,_0x2e010a);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x337a6d),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x3080f9,_0x4bd2d1){this['committed']=_0x3080f9,this['snapshot']=_0x4bd2d1;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0xd869fe,_0x1fe65e,_0x30b94a){if(_0xd869fe=P(_0xd869fe),Me('Reference.transaction',_0xd869fe['_path']),_0xd869fe['key']==='.length'||_0xd869fe['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xd869fe['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3d181c=!0x0,_0x49ee1b=new H(),_0x1a5e0f=(_0x58cbc6,_0x3895b2,_0x230173)=>{let _0x49f46a=null;_0x58cbc6?_0x49ee1b['reject'](_0x58cbc6):(_0x49f46a=new lt(_0x230173,new ee(_0xd869fe['_repo'],_0xd869fe['_path']),R),_0x49ee1b['resolve'](new of(_0x3895b2,_0x49f46a)));},_0x34f144=Gd(_0xd869fe,()=>{});return Od(_0xd869fe['_repo'],_0xd869fe['_path'],_0x1fe65e,_0x1a5e0f,_0x34f144,_0x3d181c),_0x49ee1b['promise'];}se['prototype']['simpleListen']=function(_0x3deaab,_0x9c4bd1){this['sendRequest']('q',{'p':_0x3deaab},_0x9c4bd1);},se['prototype']['echo']=function(_0x417f14,_0x1d379a){this['sendRequest']('echo',{'d':_0x417f14},_0x1d379a);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2fe0a8,..._0x4f11d1){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2fe0a8,..._0x4f11d1);}function cn(_0x3ddfb1,..._0x2b66f5){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3ddfb1,..._0x2b66f5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x464399,..._0x4bdf87){throw ws(_0x464399,..._0x4bdf87);}function X(_0x34da12,..._0x35feb1){return ws(_0x34da12,..._0x35feb1);}function Ia(_0x1e4f6c,_0x577b9c,_0x55cd4a){const _0x35e447={...af(),[_0x577b9c]:_0x55cd4a};return new Gt('auth','Firebase',_0x35e447)['create'](_0x577b9c,{'appName':_0x1e4f6c['name']});}function re(_0x34f856){return Ia(_0x34f856,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x145642,..._0x3d3749){if(typeof _0x145642!='string'){const _0x4d34fb=_0x3d3749[0x0],_0x4a038b=[..._0x3d3749['slice'](0x1)];return _0x4a038b[0x0]&&(_0x4a038b[0x0]['appName']=_0x145642['name']),_0x145642['_errorFactory']['create'](_0x4d34fb,..._0x4a038b);}return Ea['create'](_0x145642,..._0x3d3749);}function m(_0x8c84cb,_0x4bb545,..._0x1c3d70){if(!_0x8c84cb)throw ws(_0x4bb545,..._0x1c3d70);}function ne(_0x5d22e0){const _0xa03d5='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5d22e0;throw cn(_0xa03d5),new Error(_0xa03d5);}function ce(_0x3ec698,_0xbe1512){_0x3ec698||ne(_0xbe1512);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x1b2b24;return typeof self<'u'&&((_0x1b2b24=self['location'])==null?void 0x0:_0x1b2b24['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3434de;return typeof self<'u'&&((_0x3434de=self['location'])==null?void 0x0:_0x3434de['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x4fca7d=navigator;return _0x4fca7d['languages']&&_0x4fca7d['languages'][0x0]||_0x4fca7d['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x52c611,_0x215d95){this['shortDelay']=_0x52c611,this['longDelay']=_0x215d95,ce(_0x215d95>_0x52c611,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2585ae,_0x7c2449){ce(_0x2585ae['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x36ee20}=_0x2585ae['emulator'];return _0x7c2449?''+_0x36ee20+(_0x7c2449['startsWith']('/')?_0x7c2449['slice'](0x1):_0x7c2449):_0x36ee20;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x16ea07,_0x1617b8,_0x9c30db){this['fetchImpl']=_0x16ea07,_0x1617b8&&(this['headersImpl']=_0x1617b8),_0x9c30db&&(this['responseImpl']=_0x9c30db);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x5203a1,_0x2b7b52){return _0x5203a1['tenantId']&&!_0x2b7b52['tenantId']?{..._0x2b7b52,'tenantId':_0x5203a1['tenantId']}:_0x2b7b52;}async function Pe(_0x56b527,_0x13f659,_0x227ee8,_0x320873,_0xc2f622={}){return Ca(_0x56b527,_0xc2f622,async()=>{let _0x15c872={},_0x62c469={};_0x320873&&(_0x13f659==='GET'?_0x62c469=_0x320873:_0x15c872={'body':JSON['stringify'](_0x320873)});const _0x241c6c=ut({..._0x62c469,'key':_0x56b527['config']['apiKey']})['slice'](0x1),_0x180236=await _0x56b527['_getAdditionalHeaders']();_0x180236['Content-Type']='application/json',_0x56b527['languageCode']&&(_0x180236['X-Firebase-Locale']=_0x56b527['languageCode']);const _0x1a6929={'method':_0x13f659,'headers':_0x180236,..._0x15c872};return dc()||(_0x1a6929['referrerPolicy']='strict-origin-when-cross-origin'),_0x56b527['emulatorConfig']&&qt(_0x56b527['emulatorConfig']['host'])&&(_0x1a6929['credentials']='include'),wa['fetch']()(await Ta(_0x56b527,_0x56b527['config']['apiHost'],_0x227ee8,_0x241c6c),_0x1a6929);});}async function Ca(_0x3c07dd,_0x99957c,_0x38e9cc){_0x3c07dd['_canInitEmulator']=!0x1;const _0x18fca3={...df,..._0x99957c};try{const _0x1e8ae0=new gf(_0x3c07dd),_0x1fdf39=await Promise['race']([_0x38e9cc(),_0x1e8ae0['promise']]);_0x1e8ae0['clearNetworkTimeout']();const _0x28f82b=await _0x1fdf39['json']();if('needConfirmation'in _0x28f82b)throw on(_0x3c07dd,'account-exists-with-different-credential',_0x28f82b);if(_0x1fdf39['ok']&&!('errorMessage'in _0x28f82b))return _0x28f82b;{const _0xa59307=_0x1fdf39['ok']?_0x28f82b['errorMessage']:_0x28f82b['error']['message'],[_0x199b8d,_0x187fef]=_0xa59307['split']('\x20:\x20');if(_0x199b8d==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x3c07dd,'credential-already-in-use',_0x28f82b);if(_0x199b8d==='EMAIL_EXISTS')throw on(_0x3c07dd,'email-already-in-use',_0x28f82b);if(_0x199b8d==='USER_DISABLED')throw on(_0x3c07dd,'user-disabled',_0x28f82b);const _0x49083a=_0x18fca3[_0x199b8d]||_0x199b8d['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x187fef)throw Ia(_0x3c07dd,_0x49083a,_0x187fef);Y(_0x3c07dd,_0x49083a);}}catch(_0x24da08){if(_0x24da08 instanceof Re)throw _0x24da08;Y(_0x3c07dd,'network-request-failed',{'message':String(_0x24da08)});}}async function en(_0x56f297,_0x47b52d,_0x2679a0,_0x138b22,_0x2e3327={}){const _0x242ceb=await Pe(_0x56f297,_0x47b52d,_0x2679a0,_0x138b22,_0x2e3327);return'mfaPendingCredential'in _0x242ceb&&Y(_0x56f297,'multi-factor-auth-required',{'_serverResponse':_0x242ceb}),_0x242ceb;}async function Ta(_0xea922a,_0x5b4f58,_0x1472df,_0x4c89da){const _0x3ebfb9=''+_0x5b4f58+_0x1472df+'?'+_0x4c89da,_0x5e33ff=_0xea922a,_0xe76117=_0x5e33ff['config']['emulator']?Cs(_0xea922a['config'],_0x3ebfb9):_0xea922a['config']['apiScheme']+'://'+_0x3ebfb9;return ff['includes'](_0x1472df)&&(await _0x5e33ff['_persistenceManagerAvailable'],_0x5e33ff['_getPersistenceType']()==='COOKIE')?_0x5e33ff['_getPersistence']()['_getFinalTarget'](_0xe76117)['toString']():_0xe76117;}function _f(_0x13437f){switch(_0x13437f){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2bc05a){this['auth']=_0x2bc05a,this['timer']=null,this['promise']=new Promise((_0x113e3d,_0x51eb8b)=>{this['timer']=setTimeout(()=>_0x51eb8b(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x4d4cce,_0x42eac9,_0x2f97d3){const _0x14cfec={'appName':_0x4d4cce['name']};_0x2f97d3['email']&&(_0x14cfec['email']=_0x2f97d3['email']),_0x2f97d3['phoneNumber']&&(_0x14cfec['phoneNumber']=_0x2f97d3['phoneNumber']);const _0xe88e1c=X(_0x4d4cce,_0x42eac9,_0x14cfec);return _0xe88e1c['customData']['_tokenResponse']=_0x2f97d3,_0xe88e1c;}function wr(_0x56fb89){return _0x56fb89!==void 0x0&&_0x56fb89['enterprise']!==void 0x0;}class mf{constructor(_0x4484b2){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4484b2['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4484b2['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4484b2['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x177df9){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x18b45e of this['recaptchaEnforcementState'])if(_0x18b45e['provider']&&_0x18b45e['provider']===_0x177df9)return _f(_0x18b45e['enforcementState']);return null;}['isProviderEnabled'](_0x40b6b2){return this['getProviderEnforcementState'](_0x40b6b2)==='ENFORCE'||this['getProviderEnforcementState'](_0x40b6b2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x58960d,_0x1fff3c){return Pe(_0x58960d,'GET','/v2/recaptchaConfig',ke(_0x58960d,_0x1fff3c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3e4f90,_0x55476f){return Pe(_0x3e4f90,'POST','/v1/accounts:delete',_0x55476f);}async function Pn(_0x24cd94,_0x38a6b2){return Pe(_0x24cd94,'POST','/v1/accounts:lookup',_0x38a6b2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x3003dd){if(_0x3003dd)try{const _0x47fecb=new Date(Number(_0x3003dd));if(!isNaN(_0x47fecb['getTime']()))return _0x47fecb['toUTCString']();}catch{}}async function Ef(_0x41ce59,_0x246864=!0x1){const _0x1e40fb=P(_0x41ce59),_0x57f8da=await _0x1e40fb['getIdToken'](_0x246864),_0x4c4d37=Ts(_0x57f8da);m(_0x4c4d37&&_0x4c4d37['exp']&&_0x4c4d37['auth_time']&&_0x4c4d37['iat'],_0x1e40fb['auth'],'internal-error');const _0x33fe03=typeof _0x4c4d37['firebase']=='object'?_0x4c4d37['firebase']:void 0x0,_0x3f3f12=_0x33fe03==null?void 0x0:_0x33fe03['sign_in_provider'];return{'claims':_0x4c4d37,'token':_0x57f8da,'authTime':Pt(fi(_0x4c4d37['auth_time'])),'issuedAtTime':Pt(fi(_0x4c4d37['iat'])),'expirationTime':Pt(fi(_0x4c4d37['exp'])),'signInProvider':_0x3f3f12||null,'signInSecondFactor':(_0x33fe03==null?void 0x0:_0x33fe03['sign_in_second_factor'])||null};}function fi(_0x25219e){return Number(_0x25219e)*0x3e8;}function Ts(_0x43e645){const [_0x488603,_0x335826,_0x251e3d]=_0x43e645['split']('.');if(_0x488603===void 0x0||_0x335826===void 0x0||_0x251e3d===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x387d1b=fn(_0x335826);return _0x387d1b?JSON['parse'](_0x387d1b):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x1206d1){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x1206d1==null?void 0x0:_0x1206d1['toString']()),null;}}function Cr(_0x484b6c){const _0x41f7d5=Ts(_0x484b6c);return m(_0x41f7d5,'internal-error'),m(typeof _0x41f7d5['exp']<'u','internal-error'),m(typeof _0x41f7d5['iat']<'u','internal-error'),Number(_0x41f7d5['exp'])-Number(_0x41f7d5['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4628da,_0x5d9184,_0x4d8518=!0x1){if(_0x4d8518)return _0x5d9184;try{return await _0x5d9184;}catch(_0x1e0719){throw _0x1e0719 instanceof Re&&If(_0x1e0719)&&_0x4628da['auth']['currentUser']===_0x4628da&&await _0x4628da['auth']['signOut'](),_0x1e0719;}}function If({code:_0x5e8730}){return _0x5e8730==='auth/user-disabled'||_0x5e8730==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x567a4c){this['user']=_0x567a4c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5ea2da){if(_0x5ea2da){const _0x517125=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x517125;}else{this['errorBackoff']=0x7530;const _0x36dbe6=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x36dbe6);}}['schedule'](_0x42f4f1=!0x1){if(!this['isRunning'])return;const _0x51016f=this['getInterval'](_0x42f4f1);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x51016f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5255ac){(_0x5255ac==null?void 0x0:_0x5255ac['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x2a1942,_0xc9951c){this['createdAt']=_0x2a1942,this['lastLoginAt']=_0xc9951c,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x42de3b){this['createdAt']=_0x42de3b['createdAt'],this['lastLoginAt']=_0x42de3b['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x1d195c){var _0x2f9f69;const _0x5ef11c=_0x1d195c['auth'],_0xdcdf0f=await _0x1d195c['getIdToken'](),_0x552c4f=await Ht(_0x1d195c,Pn(_0x5ef11c,{'idToken':_0xdcdf0f}));m(_0x552c4f==null?void 0x0:_0x552c4f['users']['length'],_0x5ef11c,'internal-error');const _0x32bf0d=_0x552c4f['users'][0x0];_0x1d195c['_notifyReloadListener'](_0x32bf0d);const _0x686802=(_0x2f9f69=_0x32bf0d['providerUserInfo'])!=null&&_0x2f9f69['length']?Sa(_0x32bf0d['providerUserInfo']):[],_0x1a11f9=Tf(_0x1d195c['providerData'],_0x686802),_0x5c0973=_0x1d195c['isAnonymous'],_0x3ea59a=!(_0x1d195c['email']&&_0x32bf0d['passwordHash'])&&!(_0x1a11f9!=null&&_0x1a11f9['length']),_0x58c5f8=_0x5c0973?_0x3ea59a:!0x1,_0x2a74e2={'uid':_0x32bf0d['localId'],'displayName':_0x32bf0d['displayName']||null,'photoURL':_0x32bf0d['photoUrl']||null,'email':_0x32bf0d['email']||null,'emailVerified':_0x32bf0d['emailVerified']||!0x1,'phoneNumber':_0x32bf0d['phoneNumber']||null,'tenantId':_0x32bf0d['tenantId']||null,'providerData':_0x1a11f9,'metadata':new Li(_0x32bf0d['createdAt'],_0x32bf0d['lastLoginAt']),'isAnonymous':_0x58c5f8};Object['assign'](_0x1d195c,_0x2a74e2);}async function Cf(_0x48e2ac){const _0x35ffc1=P(_0x48e2ac);await Nn(_0x35ffc1),await _0x35ffc1['auth']['_persistUserIfCurrent'](_0x35ffc1),_0x35ffc1['auth']['_notifyListenersIfCurrent'](_0x35ffc1);}function Tf(_0x44cc7,_0x3f17bc){return[..._0x44cc7['filter'](_0x1040c7=>!_0x3f17bc['some'](_0x57ce82=>_0x57ce82['providerId']===_0x1040c7['providerId'])),..._0x3f17bc];}function Sa(_0xbc4ab9){return _0xbc4ab9['map'](({providerId:_0x43e009,..._0x340189})=>({'providerId':_0x43e009,'uid':_0x340189['rawId']||'','displayName':_0x340189['displayName']||null,'email':_0x340189['email']||null,'phoneNumber':_0x340189['phoneNumber']||null,'photoURL':_0x340189['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x23ad93,_0x22b9ba){const _0x36b1c0=await Ca(_0x23ad93,{},async()=>{const _0xa06980=ut({'grant_type':'refresh_token','refresh_token':_0x22b9ba})['slice'](0x1),{tokenApiHost:_0x3bcad1,apiKey:_0x361675}=_0x23ad93['config'],_0x3ebcff=await Ta(_0x23ad93,_0x3bcad1,'/v1/token','key='+_0x361675),_0x56d119=await _0x23ad93['_getAdditionalHeaders']();_0x56d119['Content-Type']='application/x-www-form-urlencoded';const _0x561095={'method':'POST','headers':_0x56d119,'body':_0xa06980};return _0x23ad93['emulatorConfig']&&qt(_0x23ad93['emulatorConfig']['host'])&&(_0x561095['credentials']='include'),wa['fetch']()(_0x3ebcff,_0x561095);});return{'accessToken':_0x36b1c0['access_token'],'expiresIn':_0x36b1c0['expires_in'],'refreshToken':_0x36b1c0['refresh_token']};}async function bf(_0x3a85b8,_0x2054e0){return Pe(_0x3a85b8,'POST','/v2/accounts:revokeToken',ke(_0x3a85b8,_0x2054e0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x187acd){m(_0x187acd['idToken'],'internal-error'),m(typeof _0x187acd['idToken']<'u','internal-error'),m(typeof _0x187acd['refreshToken']<'u','internal-error');const _0x295ca3='expiresIn'in _0x187acd&&typeof _0x187acd['expiresIn']<'u'?Number(_0x187acd['expiresIn']):Cr(_0x187acd['idToken']);this['updateTokensAndExpiration'](_0x187acd['idToken'],_0x187acd['refreshToken'],_0x295ca3);}['updateFromIdToken'](_0x31eaec){m(_0x31eaec['length']!==0x0,'internal-error');const _0x1467de=Cr(_0x31eaec);this['updateTokensAndExpiration'](_0x31eaec,null,_0x1467de);}async['getToken'](_0x55e94b,_0x57f35f=!0x1){return!_0x57f35f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x55e94b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x55e94b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2ff81b,_0x478ddd){const {accessToken:_0x2e7ed0,refreshToken:_0x3c5cf4,expiresIn:_0x4bdfc7}=await Sf(_0x2ff81b,_0x478ddd);this['updateTokensAndExpiration'](_0x2e7ed0,_0x3c5cf4,Number(_0x4bdfc7));}['updateTokensAndExpiration'](_0x4add90,_0x2837eb,_0xe582e7){this['refreshToken']=_0x2837eb||null,this['accessToken']=_0x4add90||null,this['expirationTime']=Date['now']()+_0xe582e7*0x3e8;}static['fromJSON'](_0x10f9cc,_0x273810){const {refreshToken:_0x32d494,accessToken:_0x1d4be2,expirationTime:_0x4a463c}=_0x273810,_0x2c876a=new et();return _0x32d494&&(m(typeof _0x32d494=='string','internal-error',{'appName':_0x10f9cc}),_0x2c876a['refreshToken']=_0x32d494),_0x1d4be2&&(m(typeof _0x1d4be2=='string','internal-error',{'appName':_0x10f9cc}),_0x2c876a['accessToken']=_0x1d4be2),_0x4a463c&&(m(typeof _0x4a463c=='number','internal-error',{'appName':_0x10f9cc}),_0x2c876a['expirationTime']=_0x4a463c),_0x2c876a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x88bfcc){this['accessToken']=_0x88bfcc['accessToken'],this['refreshToken']=_0x88bfcc['refreshToken'],this['expirationTime']=_0x88bfcc['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xf4f27b,_0x5ac267){m(typeof _0xf4f27b=='string'||typeof _0xf4f27b>'u','internal-error',{'appName':_0x5ac267});}class j{constructor({uid:_0x5c54a5,auth:_0x36e6bb,stsTokenManager:_0xad6f91,..._0x581a60}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5c54a5,this['auth']=_0x36e6bb,this['stsTokenManager']=_0xad6f91,this['accessToken']=_0xad6f91['accessToken'],this['displayName']=_0x581a60['displayName']||null,this['email']=_0x581a60['email']||null,this['emailVerified']=_0x581a60['emailVerified']||!0x1,this['phoneNumber']=_0x581a60['phoneNumber']||null,this['photoURL']=_0x581a60['photoURL']||null,this['isAnonymous']=_0x581a60['isAnonymous']||!0x1,this['tenantId']=_0x581a60['tenantId']||null,this['providerData']=_0x581a60['providerData']?[..._0x581a60['providerData']]:[],this['metadata']=new Li(_0x581a60['createdAt']||void 0x0,_0x581a60['lastLoginAt']||void 0x0);}async['getIdToken'](_0x6b97d9){const _0x2eb2cd=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x6b97d9));return m(_0x2eb2cd,this['auth'],'internal-error'),this['accessToken']!==_0x2eb2cd&&(this['accessToken']=_0x2eb2cd,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2eb2cd;}['getIdTokenResult'](_0x4f0dee){return Ef(this,_0x4f0dee);}['reload'](){return Cf(this);}['_assign'](_0x179939){this!==_0x179939&&(m(this['uid']===_0x179939['uid'],this['auth'],'internal-error'),this['displayName']=_0x179939['displayName'],this['photoURL']=_0x179939['photoURL'],this['email']=_0x179939['email'],this['emailVerified']=_0x179939['emailVerified'],this['phoneNumber']=_0x179939['phoneNumber'],this['isAnonymous']=_0x179939['isAnonymous'],this['tenantId']=_0x179939['tenantId'],this['providerData']=_0x179939['providerData']['map'](_0x918e82=>({..._0x918e82})),this['metadata']['_copy'](_0x179939['metadata']),this['stsTokenManager']['_assign'](_0x179939['stsTokenManager']));}['_clone'](_0x4712b1){const _0x5768cf=new j({...this,'auth':_0x4712b1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5768cf['metadata']['_copy'](this['metadata']),_0x5768cf;}['_onReload'](_0x285730){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x285730,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4ffdb5){this['reloadListener']?this['reloadListener'](_0x4ffdb5):this['reloadUserInfo']=_0x4ffdb5;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x211cd1,_0x5d447c=!0x1){let _0x1d2f66=!0x1;_0x211cd1['idToken']&&_0x211cd1['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x211cd1),_0x1d2f66=!0x0),_0x5d447c&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1d2f66&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2c0679=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x2c0679})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x5e9d1b=>({..._0x5e9d1b})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4b56d1,_0x35c9a1){const _0x270b08=_0x35c9a1['displayName']??void 0x0,_0x359044=_0x35c9a1['email']??void 0x0,_0x41be6e=_0x35c9a1['phoneNumber']??void 0x0,_0x288958=_0x35c9a1['photoURL']??void 0x0,_0x3093b4=_0x35c9a1['tenantId']??void 0x0,_0x48058b=_0x35c9a1['_redirectEventId']??void 0x0,_0x33c3af=_0x35c9a1['createdAt']??void 0x0,_0x3a3ff0=_0x35c9a1['lastLoginAt']??void 0x0,{uid:_0x31026b,emailVerified:_0x2fb516,isAnonymous:_0x3b9684,providerData:_0x56a1b0,stsTokenManager:_0x187b3a}=_0x35c9a1;m(_0x31026b&&_0x187b3a,_0x4b56d1,'internal-error');const _0x4dc41e=et['fromJSON'](this['name'],_0x187b3a);m(typeof _0x31026b=='string',_0x4b56d1,'internal-error'),le(_0x270b08,_0x4b56d1['name']),le(_0x359044,_0x4b56d1['name']),m(typeof _0x2fb516=='boolean',_0x4b56d1,'internal-error'),m(typeof _0x3b9684=='boolean',_0x4b56d1,'internal-error'),le(_0x41be6e,_0x4b56d1['name']),le(_0x288958,_0x4b56d1['name']),le(_0x3093b4,_0x4b56d1['name']),le(_0x48058b,_0x4b56d1['name']),le(_0x33c3af,_0x4b56d1['name']),le(_0x3a3ff0,_0x4b56d1['name']);const _0xa2b133=new j({'uid':_0x31026b,'auth':_0x4b56d1,'email':_0x359044,'emailVerified':_0x2fb516,'displayName':_0x270b08,'isAnonymous':_0x3b9684,'photoURL':_0x288958,'phoneNumber':_0x41be6e,'tenantId':_0x3093b4,'stsTokenManager':_0x4dc41e,'createdAt':_0x33c3af,'lastLoginAt':_0x3a3ff0});return _0x56a1b0&&Array['isArray'](_0x56a1b0)&&(_0xa2b133['providerData']=_0x56a1b0['map'](_0x2c3250=>({..._0x2c3250}))),_0x48058b&&(_0xa2b133['_redirectEventId']=_0x48058b),_0xa2b133;}static async['_fromIdTokenResponse'](_0x3431d9,_0x53a156,_0x160135=!0x1){const _0x178def=new et();_0x178def['updateFromServerResponse'](_0x53a156);const _0x578312=new j({'uid':_0x53a156['localId'],'auth':_0x3431d9,'stsTokenManager':_0x178def,'isAnonymous':_0x160135});return await Nn(_0x578312),_0x578312;}static async['_fromGetAccountInfoResponse'](_0x1ef455,_0x3aa6af,_0x593964){const _0x1bdaa6=_0x3aa6af['users'][0x0];m(_0x1bdaa6['localId']!==void 0x0,'internal-error');const _0x18185f=_0x1bdaa6['providerUserInfo']!==void 0x0?Sa(_0x1bdaa6['providerUserInfo']):[],_0x845ad6=!(_0x1bdaa6['email']&&_0x1bdaa6['passwordHash'])&&!(_0x18185f!=null&&_0x18185f['length']),_0x455905=new et();_0x455905['updateFromIdToken'](_0x593964);const _0x46bad0=new j({'uid':_0x1bdaa6['localId'],'auth':_0x1ef455,'stsTokenManager':_0x455905,'isAnonymous':_0x845ad6}),_0x519653={'uid':_0x1bdaa6['localId'],'displayName':_0x1bdaa6['displayName']||null,'photoURL':_0x1bdaa6['photoUrl']||null,'email':_0x1bdaa6['email']||null,'emailVerified':_0x1bdaa6['emailVerified']||!0x1,'phoneNumber':_0x1bdaa6['phoneNumber']||null,'tenantId':_0x1bdaa6['tenantId']||null,'providerData':_0x18185f,'metadata':new Li(_0x1bdaa6['createdAt'],_0x1bdaa6['lastLoginAt']),'isAnonymous':!(_0x1bdaa6['email']&&_0x1bdaa6['passwordHash'])&&!(_0x18185f!=null&&_0x18185f['length'])};return Object['assign'](_0x46bad0,_0x519653),_0x46bad0;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x132bbd){ce(_0x132bbd instanceof Function,'Expected\x20a\x20class\x20definition');let _0xde3baa=Tr['get'](_0x132bbd);return _0xde3baa?(ce(_0xde3baa instanceof _0x132bbd,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xde3baa):(_0xde3baa=new _0x132bbd(),Tr['set'](_0x132bbd,_0xde3baa),_0xde3baa);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x177888,_0x598b82){this['storage'][_0x177888]=_0x598b82;}async['_get'](_0xa94bcc){const _0x28ca04=this['storage'][_0xa94bcc];return _0x28ca04===void 0x0?null:_0x28ca04;}async['_remove'](_0x40929e){delete this['storage'][_0x40929e];}['_addListener'](_0x5cded9,_0x4b4bf4){}['_removeListener'](_0x487ae9,_0x1cbb81){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3b96b6,_0x186a25,_0x5812f6){return'firebase:'+_0x3b96b6+':'+_0x186a25+':'+_0x5812f6;}class tt{constructor(_0x5dc64e,_0x41d581,_0x1ed1b7){this['persistence']=_0x5dc64e,this['auth']=_0x41d581,this['userKey']=_0x1ed1b7;const {config:_0x1ad6c7,name:_0x4e6de4}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x1ad6c7['apiKey'],_0x4e6de4),this['fullPersistenceKey']=ln('persistence',_0x1ad6c7['apiKey'],_0x4e6de4),this['boundEventHandler']=_0x41d581['_onStorageEvent']['bind'](_0x41d581),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x24593c){return this['persistence']['_set'](this['fullUserKey'],_0x24593c['toJSON']());}async['getCurrentUser'](){const _0x350962=await this['persistence']['_get'](this['fullUserKey']);if(!_0x350962)return null;if(typeof _0x350962=='string'){const _0x35fb89=await Pn(this['auth'],{'idToken':_0x350962})['catch'](()=>{});return _0x35fb89?j['_fromGetAccountInfoResponse'](this['auth'],_0x35fb89,_0x350962):null;}return j['_fromJSON'](this['auth'],_0x350962);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x468e86){if(this['persistence']===_0x468e86)return;const _0x2673d0=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x468e86,_0x2673d0)return this['setCurrentUser'](_0x2673d0);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x15f4d7,_0x2b0147,_0x592ca5='authUser'){if(!_0x2b0147['length'])return new tt(ie(Sr),_0x15f4d7,_0x592ca5);const _0x420593=(await Promise['all'](_0x2b0147['map'](async _0x1a0778=>{if(await _0x1a0778['_isAvailable']())return _0x1a0778;})))['filter'](_0x1b74d4=>_0x1b74d4);let _0x3e69d=_0x420593[0x0]||ie(Sr);const _0x23e2e2=ln(_0x592ca5,_0x15f4d7['config']['apiKey'],_0x15f4d7['name']);let _0xac59e3=null;for(const _0xbeac9a of _0x2b0147)try{const _0x2f7e6d=await _0xbeac9a['_get'](_0x23e2e2);if(_0x2f7e6d){let _0x185632;if(typeof _0x2f7e6d=='string'){const _0x34282a=await Pn(_0x15f4d7,{'idToken':_0x2f7e6d})['catch'](()=>{});if(!_0x34282a)break;_0x185632=await j['_fromGetAccountInfoResponse'](_0x15f4d7,_0x34282a,_0x2f7e6d);}else _0x185632=j['_fromJSON'](_0x15f4d7,_0x2f7e6d);_0xbeac9a!==_0x3e69d&&(_0xac59e3=_0x185632),_0x3e69d=_0xbeac9a;break;}}catch{}const _0x14a2d5=_0x420593['filter'](_0x276fd2=>_0x276fd2['_shouldAllowMigration']);return!_0x3e69d['_shouldAllowMigration']||!_0x14a2d5['length']?new tt(_0x3e69d,_0x15f4d7,_0x592ca5):(_0x3e69d=_0x14a2d5[0x0],_0xac59e3&&await _0x3e69d['_set'](_0x23e2e2,_0xac59e3['toJSON']()),await Promise['all'](_0x2b0147['map'](async _0x2efbec=>{if(_0x2efbec!==_0x3e69d)try{await _0x2efbec['_remove'](_0x23e2e2);}catch{}})),new tt(_0x3e69d,_0x15f4d7,_0x592ca5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x22c223){const _0x3d846f=_0x22c223['toLowerCase']();if(_0x3d846f['includes']('opera/')||_0x3d846f['includes']('opr/')||_0x3d846f['includes']('opios/'))return'Opera';if(Pa(_0x3d846f))return'IEMobile';if(_0x3d846f['includes']('msie')||_0x3d846f['includes']('trident/'))return'IE';if(_0x3d846f['includes']('edge/'))return'Edge';if(Ra(_0x3d846f))return'Firefox';if(_0x3d846f['includes']('silk/'))return'Silk';if(Oa(_0x3d846f))return'Blackberry';if(Da(_0x3d846f))return'Webos';if(Aa(_0x3d846f))return'Safari';if((_0x3d846f['includes']('chrome/')||ka(_0x3d846f))&&!_0x3d846f['includes']('edge/'))return'Chrome';if(Na(_0x3d846f))return'Android';{const _0x3e12f6=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1dae8a=_0x22c223['match'](_0x3e12f6);if((_0x1dae8a==null?void 0x0:_0x1dae8a['length'])===0x2)return _0x1dae8a[0x1];}return'Other';}function Ra(_0x2d4b4c=W()){return/firefox\//i['test'](_0x2d4b4c);}function Aa(_0x3ecbf9=W()){const _0x3b9469=_0x3ecbf9['toLowerCase']();return _0x3b9469['includes']('safari/')&&!_0x3b9469['includes']('chrome/')&&!_0x3b9469['includes']('crios/')&&!_0x3b9469['includes']('android');}function ka(_0x2ea35d=W()){return/crios\//i['test'](_0x2ea35d);}function Pa(_0x195651=W()){return/iemobile/i['test'](_0x195651);}function Na(_0x5de648=W()){return/android/i['test'](_0x5de648);}function Oa(_0x2570e6=W()){return/blackberry/i['test'](_0x2570e6);}function Da(_0x28a0ce=W()){return/webos/i['test'](_0x28a0ce);}function Ss(_0x9dc51=W()){return/iphone|ipad|ipod/i['test'](_0x9dc51)||/macintosh/i['test'](_0x9dc51)&&/mobile/i['test'](_0x9dc51);}function Rf(_0x21e045=W()){var _0x1b5b9c;return Ss(_0x21e045)&&!!((_0x1b5b9c=window['navigator'])!=null&&_0x1b5b9c['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x4e06f8=W()){return Ss(_0x4e06f8)||Na(_0x4e06f8)||Da(_0x4e06f8)||Oa(_0x4e06f8)||/windows phone/i['test'](_0x4e06f8)||Pa(_0x4e06f8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x508d17,_0x5452f2=[]){let _0x52607d;switch(_0x508d17){case'Browser':_0x52607d=br(W());break;case'Worker':_0x52607d=br(W())+'-'+_0x508d17;break;default:_0x52607d=_0x508d17;}const _0x3a0042=_0x5452f2['length']?_0x5452f2['join'](','):'FirebaseCore-web';return _0x52607d+'/JsCore/'+dt+'/'+_0x3a0042;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x42c30f){this['auth']=_0x42c30f,this['queue']=[];}['pushCallback'](_0x5cc2a8,_0x429883){const _0x1c952a=_0x50200a=>new Promise((_0x3fc62a,_0x4347aa)=>{try{const _0x16d85d=_0x5cc2a8(_0x50200a);_0x3fc62a(_0x16d85d);}catch(_0x768de5){_0x4347aa(_0x768de5);}});_0x1c952a['onAbort']=_0x429883,this['queue']['push'](_0x1c952a);const _0x36759b=this['queue']['length']-0x1;return()=>{this['queue'][_0x36759b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4a8619){if(this['auth']['currentUser']===_0x4a8619)return;const _0x26b865=[];try{for(const _0x34836a of this['queue'])await _0x34836a(_0x4a8619),_0x34836a['onAbort']&&_0x26b865['push'](_0x34836a['onAbort']);}catch(_0x57ff17){_0x26b865['reverse']();for(const _0x1c12a4 of _0x26b865)try{_0x1c12a4();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x57ff17==null?void 0x0:_0x57ff17['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1c8afe,_0x2ea82e={}){return Pe(_0x1c8afe,'GET','/v2/passwordPolicy',ke(_0x1c8afe,_0x2ea82e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x4801dc){var _0x349ee9;const _0x1f709d=_0x4801dc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1f709d['minPasswordLength']??Nf,_0x1f709d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1f709d['maxPasswordLength']),_0x1f709d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1f709d['containsLowercaseCharacter']),_0x1f709d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1f709d['containsUppercaseCharacter']),_0x1f709d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1f709d['containsNumericCharacter']),_0x1f709d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1f709d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4801dc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x349ee9=_0x4801dc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x349ee9['join'](''))??'',this['forceUpgradeOnSignin']=_0x4801dc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4801dc['schemaVersion'];}['validatePassword'](_0x28c7ff){const _0x1f044c={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x28c7ff,_0x1f044c),this['validatePasswordCharacterOptions'](_0x28c7ff,_0x1f044c),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['meetsMinPasswordLength']??!0x0),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['meetsMaxPasswordLength']??!0x0),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['containsLowercaseLetter']??!0x0),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['containsUppercaseLetter']??!0x0),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['containsNumericCharacter']??!0x0),_0x1f044c['isValid']&&(_0x1f044c['isValid']=_0x1f044c['containsNonAlphanumericCharacter']??!0x0),_0x1f044c;}['validatePasswordLengthOptions'](_0x2df8af,_0x39cde2){const _0xb347f4=this['customStrengthOptions']['minPasswordLength'],_0x2adf5c=this['customStrengthOptions']['maxPasswordLength'];_0xb347f4&&(_0x39cde2['meetsMinPasswordLength']=_0x2df8af['length']>=_0xb347f4),_0x2adf5c&&(_0x39cde2['meetsMaxPasswordLength']=_0x2df8af['length']<=_0x2adf5c);}['validatePasswordCharacterOptions'](_0xe1533d,_0x294df2){this['updatePasswordCharacterOptionsStatuses'](_0x294df2,!0x1,!0x1,!0x1,!0x1);let _0x49a810;for(let _0x591c37=0x0;_0x591c37<_0xe1533d['length'];_0x591c37++)_0x49a810=_0xe1533d['charAt'](_0x591c37),this['updatePasswordCharacterOptionsStatuses'](_0x294df2,_0x49a810>='a'&&_0x49a810<='z',_0x49a810>='A'&&_0x49a810<='Z',_0x49a810>='0'&&_0x49a810<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x49a810));}['updatePasswordCharacterOptionsStatuses'](_0xa4e7fc,_0x98ef96,_0x4acd38,_0x2e0d4b,_0x2cac58){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xa4e7fc['containsLowercaseLetter']||(_0xa4e7fc['containsLowercaseLetter']=_0x98ef96)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xa4e7fc['containsUppercaseLetter']||(_0xa4e7fc['containsUppercaseLetter']=_0x4acd38)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xa4e7fc['containsNumericCharacter']||(_0xa4e7fc['containsNumericCharacter']=_0x2e0d4b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xa4e7fc['containsNonAlphanumericCharacter']||(_0xa4e7fc['containsNonAlphanumericCharacter']=_0x2cac58));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x59a419,_0x3c060b,_0x495d9e,_0xb57a30){this['app']=_0x59a419,this['heartbeatServiceProvider']=_0x3c060b,this['appCheckServiceProvider']=_0x495d9e,this['config']=_0xb57a30,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x59a419['name'],this['clientVersion']=_0xb57a30['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5aecc2=>this['_resolvePersistenceManagerAvailable']=_0x5aecc2);}['_initializeWithPersistence'](_0x38e1df,_0x3f20ae){return _0x3f20ae&&(this['_popupRedirectResolver']=ie(_0x3f20ae)),this['_initializationPromise']=this['queue'](async()=>{var _0x3a0d78,_0x54450a,_0x2613e0;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x38e1df),(_0x3a0d78=this['_resolvePersistenceManagerAvailable'])==null||_0x3a0d78['call'](this),!this['_deleted'])){if((_0x54450a=this['_popupRedirectResolver'])!=null&&_0x54450a['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3f20ae),this['lastNotifiedUid']=((_0x2613e0=this['currentUser'])==null?void 0x0:_0x2613e0['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3472dc=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3472dc)){if(this['currentUser']&&_0x3472dc&&this['currentUser']['uid']===_0x3472dc['uid']){this['_currentUser']['_assign'](_0x3472dc),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3472dc,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3b31b4){try{const _0x143f09=await Pn(this,{'idToken':_0x3b31b4}),_0x3adcbb=await j['_fromGetAccountInfoResponse'](this,_0x143f09,_0x3b31b4);await this['directlySetCurrentUser'](_0x3adcbb);}catch(_0x1dced4){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1dced4),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x15a9a2){var _0x207585;if($(this['app'])){const _0x344a59=this['app']['settings']['authIdToken'];return _0x344a59?new Promise(_0x7eec4=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x344a59)['then'](_0x7eec4,_0x7eec4));}):this['directlySetCurrentUser'](null);}const _0x51b3b1=await this['assertedPersistence']['getCurrentUser']();let _0x150d59=_0x51b3b1,_0x5bed85=!0x1;if(_0x15a9a2&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2db11b=(_0x207585=this['redirectUser'])==null?void 0x0:_0x207585['_redirectEventId'],_0x45d8dc=_0x150d59==null?void 0x0:_0x150d59['_redirectEventId'],_0x273fed=await this['tryRedirectSignIn'](_0x15a9a2);(!_0x2db11b||_0x2db11b===_0x45d8dc)&&(_0x273fed!=null&&_0x273fed['user'])&&(_0x150d59=_0x273fed['user'],_0x5bed85=!0x0);}if(!_0x150d59)return this['directlySetCurrentUser'](null);if(!_0x150d59['_redirectEventId']){if(_0x5bed85)try{await this['beforeStateQueue']['runMiddleware'](_0x150d59);}catch(_0x32e2fb){_0x150d59=_0x51b3b1,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x32e2fb));}return _0x150d59?this['reloadAndSetCurrentUserOrClear'](_0x150d59):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x150d59['_redirectEventId']?this['directlySetCurrentUser'](_0x150d59):this['reloadAndSetCurrentUserOrClear'](_0x150d59);}async['tryRedirectSignIn'](_0x8a5958){let _0x458242=null;try{_0x458242=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x8a5958,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x458242;}async['reloadAndSetCurrentUserOrClear'](_0x585f93){try{await Nn(_0x585f93);}catch(_0x28c591){if((_0x28c591==null?void 0x0:_0x28c591['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x585f93);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x284798){if($(this['app']))return Promise['reject'](re(this));const _0x4a2cca=_0x284798?P(_0x284798):null;return _0x4a2cca&&m(_0x4a2cca['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4a2cca&&_0x4a2cca['_clone'](this));}async['_updateCurrentUser'](_0x141cb4,_0x2a0b42=!0x1){if(!this['_deleted'])return _0x141cb4&&m(this['tenantId']===_0x141cb4['tenantId'],this,'tenant-id-mismatch'),_0x2a0b42||await this['beforeStateQueue']['runMiddleware'](_0x141cb4),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x141cb4),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1ff93c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1ff93c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3d16d6){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x55f307=this['_getPasswordPolicyInternal']();return _0x55f307['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x55f307['validatePassword'](_0x3d16d6);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5f2112=await Pf(this),_0x524803=new Of(_0x5f2112);this['tenantId']===null?this['_projectPasswordPolicy']=_0x524803:this['_tenantPasswordPolicies'][this['tenantId']]=_0x524803;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x22c808){this['_errorFactory']=new Gt('auth','Firebase',_0x22c808());}['onAuthStateChanged'](_0x11aeef,_0x12e9ae,_0x44f4ac){return this['registerStateListener'](this['authStateSubscription'],_0x11aeef,_0x12e9ae,_0x44f4ac);}['beforeAuthStateChanged'](_0x4709c6,_0x29f846){return this['beforeStateQueue']['pushCallback'](_0x4709c6,_0x29f846);}['onIdTokenChanged'](_0x59011c,_0x4895b0,_0x4457e9){return this['registerStateListener'](this['idTokenSubscription'],_0x59011c,_0x4895b0,_0x4457e9);}['authStateReady'](){return new Promise((_0x483f32,_0x5aa621)=>{if(this['currentUser'])_0x483f32();else{const _0x9c804a=this['onAuthStateChanged'](()=>{_0x9c804a(),_0x483f32();},_0x5aa621);}});}async['revokeAccessToken'](_0x4fe656){if(this['currentUser']){const _0x436a66=await this['currentUser']['getIdToken'](),_0x3144c0={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4fe656,'idToken':_0x436a66};this['tenantId']!=null&&(_0x3144c0['tenantId']=this['tenantId']),await bf(this,_0x3144c0);}}['toJSON'](){var _0x4a7822;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4a7822=this['_currentUser'])==null?void 0x0:_0x4a7822['toJSON']()};}async['_setRedirectUser'](_0x384fa2,_0x43be26){const _0x1acd37=await this['getOrInitRedirectPersistenceManager'](_0x43be26);return _0x384fa2===null?_0x1acd37['removeCurrentUser']():_0x1acd37['setCurrentUser'](_0x384fa2);}async['getOrInitRedirectPersistenceManager'](_0x47439a){if(!this['redirectPersistenceManager']){const _0xfd9931=_0x47439a&&ie(_0x47439a)||this['_popupRedirectResolver'];m(_0xfd9931,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0xfd9931['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x319067){var _0x155750,_0x14a5c3;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x155750=this['_currentUser'])==null?void 0x0:_0x155750['_redirectEventId'])===_0x319067?this['_currentUser']:((_0x14a5c3=this['redirectUser'])==null?void 0x0:_0x14a5c3['_redirectEventId'])===_0x319067?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3ccfa2){if(_0x3ccfa2===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3ccfa2));}['_notifyListenersIfCurrent'](_0x1dc24a){_0x1dc24a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x46d649;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x13d56b=((_0x46d649=this['currentUser'])==null?void 0x0:_0x46d649['uid'])??null;this['lastNotifiedUid']!==_0x13d56b&&(this['lastNotifiedUid']=_0x13d56b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x21164c,_0x5c3669,_0x289082,_0xfafe95){if(this['_deleted'])return()=>{};const _0x4573b7=typeof _0x5c3669=='function'?_0x5c3669:_0x5c3669['next']['bind'](_0x5c3669);let _0x4912fa=!0x1;const _0x37283b=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x37283b,this,'internal-error'),_0x37283b['then'](()=>{_0x4912fa||_0x4573b7(this['currentUser']);}),typeof _0x5c3669=='function'){const _0x38282c=_0x21164c['addObserver'](_0x5c3669,_0x289082,_0xfafe95);return()=>{_0x4912fa=!0x0,_0x38282c();};}else{const _0x287b5f=_0x21164c['addObserver'](_0x5c3669);return()=>{_0x4912fa=!0x0,_0x287b5f();};}}async['directlySetCurrentUser'](_0x4db0e5){this['currentUser']&&this['currentUser']!==_0x4db0e5&&this['_currentUser']['_stopProactiveRefresh'](),_0x4db0e5&&this['isProactiveRefreshEnabled']&&_0x4db0e5['_startProactiveRefresh'](),this['currentUser']=_0x4db0e5,_0x4db0e5?await this['assertedPersistence']['setCurrentUser'](_0x4db0e5):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x50972f){return this['operations']=this['operations']['then'](_0x50972f,_0x50972f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4b32ad){!_0x4b32ad||this['frameworks']['includes'](_0x4b32ad)||(this['frameworks']['push'](_0x4b32ad),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xd2152b;const _0x3a40a7={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3a40a7['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1076ea=await((_0xd2152b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xd2152b['getHeartbeatsHeader']());_0x1076ea&&(_0x3a40a7['X-Firebase-Client']=_0x1076ea);const _0x2dad36=await this['_getAppCheckToken']();return _0x2dad36&&(_0x3a40a7['X-Firebase-AppCheck']=_0x2dad36),_0x3a40a7;}async['_getAppCheckToken'](){var _0x13a135;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1ebde2=await((_0x13a135=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x13a135['getToken']());return _0x1ebde2!=null&&_0x1ebde2['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1ebde2['error']),_0x1ebde2==null?void 0x0:_0x1ebde2['token'];}}function Ke(_0x3094f9){return P(_0x3094f9);}class Rr{constructor(_0x18e31c){this['auth']=_0x18e31c,this['observer']=null,this['addObserver']=Tc(_0x37b193=>this['observer']=_0x37b193);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x13f107){Jn=_0x13f107;}function xa(_0x4d0903){return Jn['loadJS'](_0x4d0903);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x31c924){return'__'+_0x31c924+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1e7500){_0x1e7500();}['execute'](_0x4b5892,_0x4093c1){return Promise['resolve']('token');}['render'](_0x1560b8,_0x4b40d9){return'';}}class Wf{['ready'](_0x439fcd){_0x439fcd();}['execute'](_0x4b77c6,_0x12ebe8){return Promise['resolve']('token');}['render'](_0x44df52,_0x92a061){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x40f984){this['type']=Bf,this['auth']=Ke(_0x40f984);}async['verify'](_0x226449='verify',_0x10dbfd=!0x1){async function _0x12b86a(_0x4b03b6){if(!_0x10dbfd){if(_0x4b03b6['tenantId']==null&&_0x4b03b6['_agentRecaptchaConfig']!=null)return _0x4b03b6['_agentRecaptchaConfig']['siteKey'];if(_0x4b03b6['tenantId']!=null&&_0x4b03b6['_tenantRecaptchaConfigs'][_0x4b03b6['tenantId']]!==void 0x0)return _0x4b03b6['_tenantRecaptchaConfigs'][_0x4b03b6['tenantId']]['siteKey'];}return new Promise(async(_0x63c336,_0x5e1f56)=>{yf(_0x4b03b6,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x12bdc1=>{if(_0x12bdc1['recaptchaKey']===void 0x0)_0x5e1f56(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5bf347=new mf(_0x12bdc1);return _0x4b03b6['tenantId']==null?_0x4b03b6['_agentRecaptchaConfig']=_0x5bf347:_0x4b03b6['_tenantRecaptchaConfigs'][_0x4b03b6['tenantId']]=_0x5bf347,_0x63c336(_0x5bf347['siteKey']);}})['catch'](_0x26b521=>{_0x5e1f56(_0x26b521);});});}function _0x42dca6(_0x4c5597,_0x3875e0,_0x3fbab0){const _0x35288b=window['grecaptcha'];wr(_0x35288b)?_0x35288b['enterprise']['ready'](()=>{_0x35288b['enterprise']['execute'](_0x4c5597,{'action':_0x226449})['then'](_0xeb25b=>{_0x3875e0(_0xeb25b);})['catch'](()=>{_0x3875e0(Fa);});}):_0x3fbab0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x501da8,_0x39bca7)=>{_0x12b86a(this['auth'])['then'](async _0xe315d1=>{if(!_0x10dbfd&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x42dca6(_0xe315d1,_0x501da8,_0x39bca7);else{if(typeof window>'u'){_0x39bca7(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2c9af2=Lf();_0x2c9af2['length']!==0x0&&(_0x2c9af2+=_0xe315d1+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x4ccc4a;(_0x4ccc4a=he['scriptInjectionDeferred'])==null||_0x4ccc4a['resolve']();},xa(_0x2c9af2)['then'](()=>{var _0x553ed9;return(_0x553ed9=he['scriptInjectionDeferred'])==null?void 0x0:_0x553ed9['promise'];})['then'](()=>{_0x42dca6(_0xe315d1,_0x501da8,_0x39bca7);})['catch'](_0x3cc10b=>{_0x39bca7(_0x3cc10b);});}})['catch'](_0x8ba213=>{_0x39bca7(_0x8ba213);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5bc4fe,_0x1460a8,_0x50bbaa,_0x291976=!0x1,_0x242fa0=!0x1){const _0x43de66=new he(_0x5bc4fe);let _0x53b515;if(_0x242fa0)_0x53b515=Fa;else try{_0x53b515=await _0x43de66['verify'](_0x50bbaa);}catch{_0x53b515=await _0x43de66['verify'](_0x50bbaa,!0x0);}const _0x3b4fb3={..._0x1460a8};if(_0x50bbaa==='mfaSmsEnrollment'||_0x50bbaa==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3b4fb3){const _0x3b4d12=_0x3b4fb3['phoneEnrollmentInfo']['phoneNumber'],_0x113bab=_0x3b4fb3['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3b4fb3,{'phoneEnrollmentInfo':{'phoneNumber':_0x3b4d12,'recaptchaToken':_0x113bab,'captchaResponse':_0x53b515,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3b4fb3){const _0x4966e8=_0x3b4fb3['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3b4fb3,{'phoneSignInInfo':{'recaptchaToken':_0x4966e8,'captchaResponse':_0x53b515,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3b4fb3;}return _0x291976?Object['assign'](_0x3b4fb3,{'captchaResp':_0x53b515}):Object['assign'](_0x3b4fb3,{'captchaResponse':_0x53b515}),Object['assign'](_0x3b4fb3,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3b4fb3,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3b4fb3;}async function xi(_0x32fbaa,_0x5e8104,_0x2730f7,_0x434d9b,_0x46932d){var _0xcb7ccd;if((_0xcb7ccd=_0x32fbaa['_getRecaptchaConfig']())!=null&&_0xcb7ccd['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x59251e=await kr(_0x32fbaa,_0x5e8104,_0x2730f7,_0x2730f7==='getOobCode');return _0x434d9b(_0x32fbaa,_0x59251e);}else return _0x434d9b(_0x32fbaa,_0x5e8104)['catch'](async _0x885493=>{if(_0x885493['code']==='auth/missing-recaptcha-token'){console['log'](_0x2730f7+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5f542e=await kr(_0x32fbaa,_0x5e8104,_0x2730f7,_0x2730f7==='getOobCode');return _0x434d9b(_0x32fbaa,_0x5f542e);}else return Promise['reject'](_0x885493);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x4992c7,_0x3db547){const _0x546d63=Hi(_0x4992c7,'auth');if(_0x546d63['isInitialized']()){const _0x335670=_0x546d63['getImmediate'](),_0x494be8=_0x546d63['getOptions']();if(xe(_0x494be8,_0x3db547??{}))return _0x335670;Y(_0x335670,'already-initialized');}return _0x546d63['initialize']({'options':_0x3db547});}function Hf(_0x1b9505,_0x9dbf33){const _0x346cf6=(_0x9dbf33==null?void 0x0:_0x9dbf33['persistence'])||[],_0x4d8f23=(Array['isArray'](_0x346cf6)?_0x346cf6:[_0x346cf6])['map'](ie);_0x9dbf33!=null&&_0x9dbf33['errorMap']&&_0x1b9505['_updateErrorMap'](_0x9dbf33['errorMap']),_0x1b9505['_initializeWithPersistence'](_0x4d8f23,_0x9dbf33==null?void 0x0:_0x9dbf33['popupRedirectResolver']);}function $f(_0x271f84,_0x1d246b,_0x52bbe3){const _0x270de2=Ke(_0x271f84);m(/^https?:\/\//['test'](_0x1d246b),_0x270de2,'invalid-emulator-scheme');const _0xcbd043=!0x1,_0x4dc7f7=Ua(_0x1d246b),{host:_0x2964c7,port:_0x3d56c3}=Gf(_0x1d246b),_0x5678ec=_0x3d56c3===null?'':':'+_0x3d56c3,_0x5730c4={'url':_0x4dc7f7+'//'+_0x2964c7+_0x5678ec+'/'},_0x42a27b=Object['freeze']({'host':_0x2964c7,'port':_0x3d56c3,'protocol':_0x4dc7f7['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0xcbd043})});if(!_0x270de2['_canInitEmulator']){m(_0x270de2['config']['emulator']&&_0x270de2['emulatorConfig'],_0x270de2,'emulator-config-failed'),m(xe(_0x5730c4,_0x270de2['config']['emulator'])&&xe(_0x42a27b,_0x270de2['emulatorConfig']),_0x270de2,'emulator-config-failed');return;}_0x270de2['config']['emulator']=_0x5730c4,_0x270de2['emulatorConfig']=_0x42a27b,_0x270de2['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x2964c7)?Qr(_0x4dc7f7+'//'+_0x2964c7+_0x5678ec):qf();}function Ua(_0x1a8c9f){const _0x214ae6=_0x1a8c9f['indexOf'](':');return _0x214ae6<0x0?'':_0x1a8c9f['substr'](0x0,_0x214ae6+0x1);}function Gf(_0x21f632){const _0x34ab74=Ua(_0x21f632),_0x39187b=/(\/\/)?([^?#/]+)/['exec'](_0x21f632['substr'](_0x34ab74['length']));if(!_0x39187b)return{'host':'','port':null};const _0x440cd8=_0x39187b[0x2]['split']('@')['pop']()||'',_0x14bfc6=/^(\[[^\]]+\])(:|$)/['exec'](_0x440cd8);if(_0x14bfc6){const _0x418232=_0x14bfc6[0x1];return{'host':_0x418232,'port':Pr(_0x440cd8['substr'](_0x418232['length']+0x1))};}else{const [_0x258bba,_0x42caaf]=_0x440cd8['split'](':');return{'host':_0x258bba,'port':Pr(_0x42caaf)};}}function Pr(_0x3461d1){if(!_0x3461d1)return null;const _0x4048f2=Number(_0x3461d1);return isNaN(_0x4048f2)?null:_0x4048f2;}function qf(){function _0xc26fbf(){const _0x5d0c0f=document['createElement']('p'),_0x12cda8=_0x5d0c0f['style'];_0x5d0c0f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x12cda8['position']='fixed',_0x12cda8['width']='100%',_0x12cda8['backgroundColor']='#ffffff',_0x12cda8['border']='.1em\x20solid\x20#000000',_0x12cda8['color']='#b50000',_0x12cda8['bottom']='0px',_0x12cda8['left']='0px',_0x12cda8['margin']='0px',_0x12cda8['zIndex']='10000',_0x12cda8['textAlign']='center',_0x5d0c0f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5d0c0f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xc26fbf):_0xc26fbf());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x34b7f1,_0x8e6ae9){this['providerId']=_0x34b7f1,this['signInMethod']=_0x8e6ae9;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2a70de){return ne('not\x20implemented');}['_linkToIdToken'](_0x4a80ad,_0x832f4d){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x510fc0){return ne('not\x20implemented');}}async function zf(_0x2e25f8,_0x308872){return Pe(_0x2e25f8,'POST','/v1/accounts:signUp',_0x308872);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x23c158,_0x2d85bd){return en(_0x23c158,'POST','/v1/accounts:signInWithPassword',ke(_0x23c158,_0x2d85bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5a54f6,_0x50cf91){return en(_0x5a54f6,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5a54f6,_0x50cf91));}async function Yf(_0x45eac7,_0x540cec){return en(_0x45eac7,'POST','/v1/accounts:signInWithEmailLink',ke(_0x45eac7,_0x540cec));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0xed11,_0x331cee,_0x28431e,_0x415086=null){super('password',_0x28431e),this['_email']=_0xed11,this['_password']=_0x331cee,this['_tenantId']=_0x415086;}static['_fromEmailAndPassword'](_0x319fbf,_0x30bdb1){return new $t(_0x319fbf,_0x30bdb1,'password');}static['_fromEmailAndCode'](_0x1432f0,_0x307253,_0x11f3f3=null){return new $t(_0x1432f0,_0x307253,'emailLink',_0x11f3f3);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3b10fb){const _0x819663=typeof _0x3b10fb=='string'?JSON['parse'](_0x3b10fb):_0x3b10fb;if(_0x819663!=null&&_0x819663['email']&&(_0x819663!=null&&_0x819663['password'])){if(_0x819663['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x819663['email'],_0x819663['password']);if(_0x819663['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x819663['email'],_0x819663['password'],_0x819663['tenantId']);}return null;}async['_getIdTokenResponse'](_0x27fc15){switch(this['signInMethod']){case'password':const _0x5024e7={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x27fc15,_0x5024e7,'signInWithPassword',jf);case'emailLink':return Kf(_0x27fc15,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x27fc15,'internal-error');}}async['_linkToIdToken'](_0x34606c,_0xeb0805){switch(this['signInMethod']){case'password':const _0x147650={'idToken':_0xeb0805,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x34606c,_0x147650,'signUpPassword',zf);case'emailLink':return Yf(_0x34606c,{'idToken':_0xeb0805,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x34606c,'internal-error');}}['_getReauthenticationResolver'](_0x1dd0f9){return this['_getIdTokenResponse'](_0x1dd0f9);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x3f27da,_0x488216){return en(_0x3f27da,'POST','/v1/accounts:signInWithIdp',ke(_0x3f27da,_0x488216));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x219eae){const _0x22ed6a=new $e(_0x219eae['providerId'],_0x219eae['signInMethod']);return _0x219eae['idToken']||_0x219eae['accessToken']?(_0x219eae['idToken']&&(_0x22ed6a['idToken']=_0x219eae['idToken']),_0x219eae['accessToken']&&(_0x22ed6a['accessToken']=_0x219eae['accessToken']),_0x219eae['nonce']&&!_0x219eae['pendingToken']&&(_0x22ed6a['nonce']=_0x219eae['nonce']),_0x219eae['pendingToken']&&(_0x22ed6a['pendingToken']=_0x219eae['pendingToken'])):_0x219eae['oauthToken']&&_0x219eae['oauthTokenSecret']?(_0x22ed6a['accessToken']=_0x219eae['oauthToken'],_0x22ed6a['secret']=_0x219eae['oauthTokenSecret']):Y('argument-error'),_0x22ed6a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4c96ed){const _0x15bfac=typeof _0x4c96ed=='string'?JSON['parse'](_0x4c96ed):_0x4c96ed,{providerId:_0x5b023b,signInMethod:_0x5ac895,..._0x1bcb3c}=_0x15bfac;if(!_0x5b023b||!_0x5ac895)return null;const _0x163210=new $e(_0x5b023b,_0x5ac895);return _0x163210['idToken']=_0x1bcb3c['idToken']||void 0x0,_0x163210['accessToken']=_0x1bcb3c['accessToken']||void 0x0,_0x163210['secret']=_0x1bcb3c['secret'],_0x163210['nonce']=_0x1bcb3c['nonce'],_0x163210['pendingToken']=_0x1bcb3c['pendingToken']||null,_0x163210;}['_getIdTokenResponse'](_0x5efa7b){const _0x215cba=this['buildRequest']();return nt(_0x5efa7b,_0x215cba);}['_linkToIdToken'](_0x52e8cd,_0x28c2c7){const _0x6454db=this['buildRequest']();return _0x6454db['idToken']=_0x28c2c7,nt(_0x52e8cd,_0x6454db);}['_getReauthenticationResolver'](_0x48e4f9){const _0x50d3c0=this['buildRequest']();return _0x50d3c0['autoCreate']=!0x1,nt(_0x48e4f9,_0x50d3c0);}['buildRequest'](){const _0x31d5e2={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x31d5e2['pendingToken']=this['pendingToken'];else{const _0x2d9d93={};this['idToken']&&(_0x2d9d93['id_token']=this['idToken']),this['accessToken']&&(_0x2d9d93['access_token']=this['accessToken']),this['secret']&&(_0x2d9d93['oauth_token_secret']=this['secret']),_0x2d9d93['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2d9d93['nonce']=this['nonce']),_0x31d5e2['postBody']=ut(_0x2d9d93);}return _0x31d5e2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x5c48aa){switch(_0x5c48aa){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x5d03ec){const _0xc72406=Ct(Tt(_0x5d03ec))['link'],_0x5e7e69=_0xc72406?Ct(Tt(_0xc72406))['deep_link_id']:null,_0x18bc4b=Ct(Tt(_0x5d03ec))['deep_link_id'];return(_0x18bc4b?Ct(Tt(_0x18bc4b))['link']:null)||_0x18bc4b||_0x5e7e69||_0xc72406||_0x5d03ec;}class Rs{constructor(_0x55fcac){const _0x189164=Ct(Tt(_0x55fcac)),_0x4b6be9=_0x189164['apiKey']??null,_0x465fa3=_0x189164['oobCode']??null,_0x330e95=Jf(_0x189164['mode']??null);m(_0x4b6be9&&_0x465fa3&&_0x330e95,'argument-error'),this['apiKey']=_0x4b6be9,this['operation']=_0x330e95,this['code']=_0x465fa3,this['continueUrl']=_0x189164['continueUrl']??null,this['languageCode']=_0x189164['lang']??null,this['tenantId']=_0x189164['tenantId']??null;}static['parseLink'](_0x27dddb){const _0x4e405b=Xf(_0x27dddb);try{return new Rs(_0x4e405b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x1d5324,_0x2fe0d3){return $t['_fromEmailAndPassword'](_0x1d5324,_0x2fe0d3);}static['credentialWithLink'](_0x415794,_0x1fae0f){const _0x2bfbcb=Rs['parseLink'](_0x1fae0f);return m(_0x2bfbcb,'argument-error'),$t['_fromEmailAndCode'](_0x415794,_0x2bfbcb['code'],_0x2bfbcb['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0xe60ea9){this['providerId']=_0xe60ea9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3352bd){this['defaultLanguageCode']=_0x3352bd;}['setCustomParameters'](_0x2c7c72){return this['customParameters']=_0x2c7c72,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x13d047){return this['scopes']['includes'](_0x13d047)||this['scopes']['push'](_0x13d047),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1cf690){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1cf690});}static['credentialFromResult'](_0x54aa18){return ue['credentialFromTaggedObject'](_0x54aa18);}static['credentialFromError'](_0x30df2f){return ue['credentialFromTaggedObject'](_0x30df2f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3c5707}){if(!_0x3c5707||!('oauthAccessToken'in _0x3c5707)||!_0x3c5707['oauthAccessToken'])return null;try{return ue['credential'](_0x3c5707['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x441339,_0x13d945){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x441339,'accessToken':_0x13d945});}static['credentialFromResult'](_0x115146){return de['credentialFromTaggedObject'](_0x115146);}static['credentialFromError'](_0x2bc820){return de['credentialFromTaggedObject'](_0x2bc820['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3c0d95}){if(!_0x3c0d95)return null;const {oauthIdToken:_0x1d10d9,oauthAccessToken:_0x1d24bc}=_0x3c0d95;if(!_0x1d10d9&&!_0x1d24bc)return null;try{return de['credential'](_0x1d10d9,_0x1d24bc);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5b3bde){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5b3bde});}static['credentialFromResult'](_0x1ee30b){return fe['credentialFromTaggedObject'](_0x1ee30b);}static['credentialFromError'](_0x47ce51){return fe['credentialFromTaggedObject'](_0x47ce51['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x99fa7a}){if(!_0x99fa7a||!('oauthAccessToken'in _0x99fa7a)||!_0x99fa7a['oauthAccessToken'])return null;try{return fe['credential'](_0x99fa7a['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x11ac7e,_0x569de7){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x11ac7e,'oauthTokenSecret':_0x569de7});}static['credentialFromResult'](_0x4bfc2e){return pe['credentialFromTaggedObject'](_0x4bfc2e);}static['credentialFromError'](_0x31b10f){return pe['credentialFromTaggedObject'](_0x31b10f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xc1da66}){if(!_0xc1da66)return null;const {oauthAccessToken:_0xb5928e,oauthTokenSecret:_0x93ca37}=_0xc1da66;if(!_0xb5928e||!_0x93ca37)return null;try{return pe['credential'](_0xb5928e,_0x93ca37);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x1ed095,_0x4ce978){return en(_0x1ed095,'POST','/v1/accounts:signUp',ke(_0x1ed095,_0x4ce978));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0xbfd674){this['user']=_0xbfd674['user'],this['providerId']=_0xbfd674['providerId'],this['_tokenResponse']=_0xbfd674['_tokenResponse'],this['operationType']=_0xbfd674['operationType'];}static async['_fromIdTokenResponse'](_0xfc6c6b,_0x22cceb,_0x1be597,_0x29959f=!0x1){const _0x5da621=await j['_fromIdTokenResponse'](_0xfc6c6b,_0x1be597,_0x29959f),_0x2eca83=Nr(_0x1be597);return new Ge({'user':_0x5da621,'providerId':_0x2eca83,'_tokenResponse':_0x1be597,'operationType':_0x22cceb});}static async['_forOperation'](_0x12018a,_0x13fbb9,_0x35a767){await _0x12018a['_updateTokensIfNecessary'](_0x35a767,!0x0);const _0x56bf8c=Nr(_0x35a767);return new Ge({'user':_0x12018a,'providerId':_0x56bf8c,'_tokenResponse':_0x35a767,'operationType':_0x13fbb9});}}function Nr(_0x18d452){return _0x18d452['providerId']?_0x18d452['providerId']:'phoneNumber'in _0x18d452?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xddbe,_0x4b3ef6,_0xc951ed,_0x4fa7b0){super(_0x4b3ef6['code'],_0x4b3ef6['message']),this['operationType']=_0xc951ed,this['user']=_0x4fa7b0,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xddbe['name'],'tenantId':_0xddbe['tenantId']??void 0x0,'_serverResponse':_0x4b3ef6['customData']['_serverResponse'],'operationType':_0xc951ed};}static['_fromErrorAndOperation'](_0x26b10b,_0x157fa3,_0x241837,_0x25de51){return new On(_0x26b10b,_0x157fa3,_0x241837,_0x25de51);}}function Ba(_0x3d8f0b,_0x536b7d,_0x39ba47,_0x17b1ec){return(_0x536b7d==='reauthenticate'?_0x39ba47['_getReauthenticationResolver'](_0x3d8f0b):_0x39ba47['_getIdTokenResponse'](_0x3d8f0b))['catch'](_0x2c41fd=>{throw _0x2c41fd['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3d8f0b,_0x2c41fd,_0x536b7d,_0x17b1ec):_0x2c41fd;});}async function ep(_0x255caf,_0x936cac,_0x142a08=!0x1){const _0x1eac7c=await Ht(_0x255caf,_0x936cac['_linkToIdToken'](_0x255caf['auth'],await _0x255caf['getIdToken']()),_0x142a08);return Ge['_forOperation'](_0x255caf,'link',_0x1eac7c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x17fed3,_0x2e1e2e,_0x67c4e8=!0x1){const {auth:_0x246b66}=_0x17fed3;if($(_0x246b66['app']))return Promise['reject'](re(_0x246b66));const _0x5025cf='reauthenticate';try{const _0x2040e5=await Ht(_0x17fed3,Ba(_0x246b66,_0x5025cf,_0x2e1e2e,_0x17fed3),_0x67c4e8);m(_0x2040e5['idToken'],_0x246b66,'internal-error');const _0x20003d=Ts(_0x2040e5['idToken']);m(_0x20003d,_0x246b66,'internal-error');const {sub:_0x3d606e}=_0x20003d;return m(_0x17fed3['uid']===_0x3d606e,_0x246b66,'user-mismatch'),Ge['_forOperation'](_0x17fed3,_0x5025cf,_0x2040e5);}catch(_0x2608cf){throw(_0x2608cf==null?void 0x0:_0x2608cf['code'])==='auth/user-not-found'&&Y(_0x246b66,'user-mismatch'),_0x2608cf;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2cac1c,_0x181097,_0x3aa427=!0x1){if($(_0x2cac1c['app']))return Promise['reject'](re(_0x2cac1c));const _0x367984='signIn',_0x491542=await Ba(_0x2cac1c,_0x367984,_0x181097),_0x4137b7=await Ge['_fromIdTokenResponse'](_0x2cac1c,_0x367984,_0x491542);return _0x3aa427||await _0x2cac1c['_updateCurrentUser'](_0x4137b7['user']),_0x4137b7;}async function np(_0x36298e,_0x1928b8){return Va(Ke(_0x36298e),_0x1928b8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x39ca09){const _0x25116b=Ke(_0x39ca09);_0x25116b['_getPasswordPolicyInternal']()&&await _0x25116b['_updatePasswordPolicy']();}async function L_(_0x585584,_0x2f9d4b,_0x41a358){if($(_0x585584['app']))return Promise['reject'](re(_0x585584));const _0x3698a1=Ke(_0x585584),_0x392147=await xi(_0x3698a1,{'returnSecureToken':!0x0,'email':_0x2f9d4b,'password':_0x41a358,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x248125=>{throw _0x248125['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x585584),_0x248125;}),_0x36a3aa=await Ge['_fromIdTokenResponse'](_0x3698a1,'signIn',_0x392147);return await _0x3698a1['_updateCurrentUser'](_0x36a3aa['user']),_0x36a3aa;}function x_(_0x527984,_0x4a0a38,_0x49243d){return $(_0x527984['app'])?Promise['reject'](re(_0x527984)):np(P(_0x527984),yt['credential'](_0x4a0a38,_0x49243d))['catch'](async _0x2cf5f8=>{throw _0x2cf5f8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x527984),_0x2cf5f8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x4c4146,_0x512f86){return P(_0x4c4146)['setPersistence'](_0x512f86);}function ip(_0x6fa8a4,_0x25a54e,_0x5cfa9e,_0x15143d){return P(_0x6fa8a4)['onIdTokenChanged'](_0x25a54e,_0x5cfa9e,_0x15143d);}function sp(_0x3214b2,_0x1ec4ed,_0xaf4e42){return P(_0x3214b2)['beforeAuthStateChanged'](_0x1ec4ed,_0xaf4e42);}function U_(_0x4ca510,_0x1b7afa,_0x781473,_0x1883ae){return P(_0x4ca510)['onAuthStateChanged'](_0x1b7afa,_0x781473,_0x1883ae);}function W_(_0x3ed3d2){return P(_0x3ed3d2)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3e29e4,_0x1f1d93){this['storageRetriever']=_0x3e29e4,this['type']=_0x1f1d93;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4a31d9,_0x3a5c67){return this['storage']['setItem'](_0x4a31d9,JSON['stringify'](_0x3a5c67)),Promise['resolve']();}['_get'](_0x1ee423){const _0x3f15d3=this['storage']['getItem'](_0x1ee423);return Promise['resolve'](_0x3f15d3?JSON['parse'](_0x3f15d3):null);}['_remove'](_0x256f73){return this['storage']['removeItem'](_0x256f73),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xe70482,_0x3d77a2)=>this['onStorageEvent'](_0xe70482,_0x3d77a2),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2a19d1){for(const _0x4a4254 of Object['keys'](this['listeners'])){const _0x2530fb=this['storage']['getItem'](_0x4a4254),_0x5e27e3=this['localCache'][_0x4a4254];_0x2530fb!==_0x5e27e3&&_0x2a19d1(_0x4a4254,_0x5e27e3,_0x2530fb);}}['onStorageEvent'](_0x4cb887,_0x4055a2=!0x1){if(!_0x4cb887['key']){this['forAllChangedKeys']((_0x5b3929,_0x18bf74,_0x42896a)=>{this['notifyListeners'](_0x5b3929,_0x42896a);});return;}const _0x24ad7d=_0x4cb887['key'];_0x4055a2?this['detachListener']():this['stopPolling']();const _0x5ca240=()=>{const _0x3624f8=this['storage']['getItem'](_0x24ad7d);!_0x4055a2&&this['localCache'][_0x24ad7d]===_0x3624f8||this['notifyListeners'](_0x24ad7d,_0x3624f8);},_0x76f95d=this['storage']['getItem'](_0x24ad7d);Af()&&_0x76f95d!==_0x4cb887['newValue']&&_0x4cb887['newValue']!==_0x4cb887['oldValue']?setTimeout(_0x5ca240,op):_0x5ca240();}['notifyListeners'](_0x5581a7,_0x5727c){this['localCache'][_0x5581a7]=_0x5727c;const _0xa018a9=this['listeners'][_0x5581a7];if(_0xa018a9){for(const _0x39b894 of Array['from'](_0xa018a9))_0x39b894(_0x5727c&&JSON['parse'](_0x5727c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4077bb,_0x2ca4ae,_0x3f60cc)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4077bb,'oldValue':_0x2ca4ae,'newValue':_0x3f60cc}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x79c206,_0x20d1fa){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x79c206]||(this['listeners'][_0x79c206]=new Set(),this['localCache'][_0x79c206]=this['storage']['getItem'](_0x79c206)),this['listeners'][_0x79c206]['add'](_0x20d1fa);}['_removeListener'](_0x427334,_0x5af848){this['listeners'][_0x427334]&&(this['listeners'][_0x427334]['delete'](_0x5af848),this['listeners'][_0x427334]['size']===0x0&&delete this['listeners'][_0x427334]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x345f30,_0x333088){await super['_set'](_0x345f30,_0x333088),this['localCache'][_0x345f30]=JSON['stringify'](_0x333088);}async['_get'](_0x18c378){const _0x2c559c=await super['_get'](_0x18c378);return this['localCache'][_0x18c378]=JSON['stringify'](_0x2c559c),_0x2c559c;}async['_remove'](_0x185efc){await super['_remove'](_0x185efc),delete this['localCache'][_0x185efc];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5c5f09,_0x21925b){}['_removeListener'](_0xf52b11,_0x45d352){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x595967){return Promise['all'](_0x595967['map'](async _0x2d3401=>{try{return{'fulfilled':!0x0,'value':await _0x2d3401};}catch(_0x506231){return{'fulfilled':!0x1,'reason':_0x506231};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x5e0799){this['eventTarget']=_0x5e0799,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x56447a){const _0x1c5293=this['receivers']['find'](_0x4635bd=>_0x4635bd['isListeningto'](_0x56447a));if(_0x1c5293)return _0x1c5293;const _0x4aeed6=new Xn(_0x56447a);return this['receivers']['push'](_0x4aeed6),_0x4aeed6;}['isListeningto'](_0x21df4d){return this['eventTarget']===_0x21df4d;}async['handleEvent'](_0x2870d9){const _0x51bb28=_0x2870d9,{eventId:_0x52d7a2,eventType:_0x296fa5,data:_0x432dfc}=_0x51bb28['data'],_0x5f22a3=this['handlersMap'][_0x296fa5];if(!(_0x5f22a3!=null&&_0x5f22a3['size']))return;_0x51bb28['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x52d7a2,'eventType':_0x296fa5});const _0x19e607=Array['from'](_0x5f22a3)['map'](async _0x5365ca=>_0x5365ca(_0x51bb28['origin'],_0x432dfc)),_0x28ef28=await cp(_0x19e607);_0x51bb28['ports'][0x0]['postMessage']({'status':'done','eventId':_0x52d7a2,'eventType':_0x296fa5,'response':_0x28ef28});}['_subscribe'](_0x42ba18,_0x136d37){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x42ba18]||(this['handlersMap'][_0x42ba18]=new Set()),this['handlersMap'][_0x42ba18]['add'](_0x136d37);}['_unsubscribe'](_0x1d1f52,_0x3afa70){this['handlersMap'][_0x1d1f52]&&_0x3afa70&&this['handlersMap'][_0x1d1f52]['delete'](_0x3afa70),(!_0x3afa70||this['handlersMap'][_0x1d1f52]['size']===0x0)&&delete this['handlersMap'][_0x1d1f52],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x147cb9='',_0x1ca333=0xa){let _0x4b8619='';for(let _0x497ddd=0x0;_0x497ddd<_0x1ca333;_0x497ddd++)_0x4b8619+=Math['floor'](Math['random']()*0xa);return _0x147cb9+_0x4b8619;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x4e3b44){this['target']=_0x4e3b44,this['handlers']=new Set();}['removeMessageHandler'](_0xa8797d){_0xa8797d['messageChannel']&&(_0xa8797d['messageChannel']['port1']['removeEventListener']('message',_0xa8797d['onMessage']),_0xa8797d['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xa8797d);}async['_send'](_0x2f8e40,_0xa78969,_0x1902b8=0x32){const _0x11e62c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x11e62c)throw new Error('connection_unavailable');let _0x57cf1c,_0x35cf61;return new Promise((_0x3a85aa,_0x2be58a)=>{const _0x585412=As('',0x14);_0x11e62c['port1']['start']();const _0x2dcf29=setTimeout(()=>{_0x2be58a(new Error('unsupported_event'));},_0x1902b8);_0x35cf61={'messageChannel':_0x11e62c,'onMessage'(_0x39a2c9){const _0x37d1bd=_0x39a2c9;if(_0x37d1bd['data']['eventId']===_0x585412)switch(_0x37d1bd['data']['status']){case'ack':clearTimeout(_0x2dcf29),_0x57cf1c=setTimeout(()=>{_0x2be58a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x57cf1c),_0x3a85aa(_0x37d1bd['data']['response']);break;default:clearTimeout(_0x2dcf29),clearTimeout(_0x57cf1c),_0x2be58a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x35cf61),_0x11e62c['port1']['addEventListener']('message',_0x35cf61['onMessage']),this['target']['postMessage']({'eventType':_0x2f8e40,'eventId':_0x585412,'data':_0xa78969},[_0x11e62c['port2']]);})['finally'](()=>{_0x35cf61&&this['removeMessageHandler'](_0x35cf61);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x1c8b9e){Z()['location']['href']=_0x1c8b9e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x114823;return((_0x114823=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x114823['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x10ad4d){this['request']=_0x10ad4d;}['toPromise'](){return new Promise((_0x279133,_0x37cfd5)=>{this['request']['addEventListener']('success',()=>{_0x279133(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x37cfd5(this['request']['error']);});});}}function Zn(_0x48e6ac,_0x3042d5){return _0x48e6ac['transaction']([Mn],_0x3042d5?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x3f40c7=indexedDB['deleteDatabase'](Ka);return new nn(_0x3f40c7)['toPromise']();}function Qa(){const _0x2fd260=indexedDB['open'](Ka,pp);return new Promise((_0x2f64d9,_0x5636a8)=>{_0x2fd260['addEventListener']('error',()=>{_0x5636a8(_0x2fd260['error']);}),_0x2fd260['addEventListener']('upgradeneeded',()=>{const _0x334015=_0x2fd260['result'];try{_0x334015['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x2492ab){_0x5636a8(_0x2492ab);}}),_0x2fd260['addEventListener']('success',async()=>{const _0x3a8dbf=_0x2fd260['result'];_0x3a8dbf['objectStoreNames']['contains'](Mn)?_0x2f64d9(_0x3a8dbf):(_0x3a8dbf['close'](),await _p(),_0x2f64d9(await Qa()));});});}async function Or(_0x77dcfa,_0x11adf8,_0x1a6ac4){const _0x5857d5=Zn(_0x77dcfa,!0x0)['put']({[Ya]:_0x11adf8,'value':_0x1a6ac4});return new nn(_0x5857d5)['toPromise']();}async function gp(_0x1ff50d,_0x4e33f2){const _0x2da80b=Zn(_0x1ff50d,!0x1)['get'](_0x4e33f2),_0x43e6eb=await new nn(_0x2da80b)['toPromise']();return _0x43e6eb===void 0x0?null:_0x43e6eb['value'];}function Dr(_0x3eea2a,_0xa36b2c){const _0x1da1fa=Zn(_0x3eea2a,!0x0)['delete'](_0xa36b2c);return new nn(_0x1da1fa)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x14e23c){let _0x30de65=0x0;for(;;)try{const _0x18178f=await this['_openDb']();return await _0x14e23c(_0x18178f);}catch(_0x374efa){if(_0x30de65++>yp)throw _0x374efa;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x21fb5e,_0x59b0a5)=>({'keyProcessed':(await this['_poll']())['includes'](_0x59b0a5['key'])})),this['receiver']['_subscribe']('ping',async(_0xe605e5,_0x1d72b8)=>['keyChanged']);}async['initializeSender'](){var _0x3f401a,_0x2458a9;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x34c8e8=await this['sender']['_send']('ping',{},0x320);_0x34c8e8&&(_0x3f401a=_0x34c8e8[0x0])!=null&&_0x3f401a['fulfilled']&&(_0x2458a9=_0x34c8e8[0x0])!=null&&_0x2458a9['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x98d3f5){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x98d3f5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x139f77=>{await Or(_0x139f77,Dn,'1'),await Dr(_0x139f77,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2e8e42){this['pendingWrites']++;try{await _0x2e8e42();}finally{this['pendingWrites']--;}}async['_set'](_0x5f5ba8,_0x35b9c9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3d5114=>Or(_0x3d5114,_0x5f5ba8,_0x35b9c9)),this['localCache'][_0x5f5ba8]=_0x35b9c9,this['notifyServiceWorker'](_0x5f5ba8)));}async['_get'](_0x470d25){const _0x522327=await this['_withRetries'](_0x3d580d=>gp(_0x3d580d,_0x470d25));return this['localCache'][_0x470d25]=_0x522327,_0x522327;}async['_remove'](_0x1d804f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4a0f29=>Dr(_0x4a0f29,_0x1d804f)),delete this['localCache'][_0x1d804f],this['notifyServiceWorker'](_0x1d804f)));}async['_poll'](){const _0x26c61c=await this['_withRetries'](_0x20879a=>{const _0x8337b4=Zn(_0x20879a,!0x1)['getAll']();return new nn(_0x8337b4)['toPromise']();});if(!_0x26c61c)return[];if(this['pendingWrites']!==0x0)return[];const _0x14ffd8=[],_0x1016e6=new Set();if(_0x26c61c['length']!==0x0){for(const {fbase_key:_0x5bf6d4,value:_0x1fff9d}of _0x26c61c)_0x1016e6['add'](_0x5bf6d4),JSON['stringify'](this['localCache'][_0x5bf6d4])!==JSON['stringify'](_0x1fff9d)&&(this['notifyListeners'](_0x5bf6d4,_0x1fff9d),_0x14ffd8['push'](_0x5bf6d4));}for(const _0x2ec807 of Object['keys'](this['localCache']))this['localCache'][_0x2ec807]&&!_0x1016e6['has'](_0x2ec807)&&(this['notifyListeners'](_0x2ec807,null),_0x14ffd8['push'](_0x2ec807));return _0x14ffd8;}['notifyListeners'](_0x408145,_0x56267f){this['localCache'][_0x408145]=_0x56267f;const _0x571ae3=this['listeners'][_0x408145];if(_0x571ae3){for(const _0x112681 of Array['from'](_0x571ae3))_0x112681(_0x56267f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x47b3df,_0xfea83f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x47b3df]||(this['listeners'][_0x47b3df]=new Set(),this['_get'](_0x47b3df)),this['listeners'][_0x47b3df]['add'](_0xfea83f);}['_removeListener'](_0x233792,_0x8d3e1e){this['listeners'][_0x233792]&&(this['listeners'][_0x233792]['delete'](_0x8d3e1e),this['listeners'][_0x233792]['size']===0x0&&delete this['listeners'][_0x233792]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5f8fc3,_0x2d9d35){return _0x2d9d35?ie(_0x2d9d35):(m(_0x5f8fc3['_popupRedirectResolver'],_0x5f8fc3,'argument-error'),_0x5f8fc3['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1dafd8){super('custom','custom'),this['params']=_0x1dafd8;}['_getIdTokenResponse'](_0x462589){return nt(_0x462589,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2c533b,_0x4892f9){return nt(_0x2c533b,this['_buildIdpRequest'](_0x4892f9));}['_getReauthenticationResolver'](_0x32a877){return nt(_0x32a877,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x340c9f){const _0x462987={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x340c9f&&(_0x462987['idToken']=_0x340c9f),_0x462987;}}function Ip(_0xb8b760){return Va(_0xb8b760['auth'],new ks(_0xb8b760),_0xb8b760['bypassAuthState']);}function wp(_0x4f5a9c){const {auth:_0x4a0a4a,user:_0x51c8e8}=_0x4f5a9c;return m(_0x51c8e8,_0x4a0a4a,'internal-error'),tp(_0x51c8e8,new ks(_0x4f5a9c),_0x4f5a9c['bypassAuthState']);}async function Cp(_0x1ffb01){const {auth:_0x181e5a,user:_0x53fbed}=_0x1ffb01;return m(_0x53fbed,_0x181e5a,'internal-error'),ep(_0x53fbed,new ks(_0x1ffb01),_0x1ffb01['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3e4276,_0x4dd600,_0x2656c1,_0x5b6326,_0x651c16=!0x1){this['auth']=_0x3e4276,this['resolver']=_0x2656c1,this['user']=_0x5b6326,this['bypassAuthState']=_0x651c16,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4dd600)?_0x4dd600:[_0x4dd600];}['execute'](){return new Promise(async(_0x290201,_0x53cd52)=>{this['pendingPromise']={'resolve':_0x290201,'reject':_0x53cd52};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x56ed35){this['reject'](_0x56ed35);}});}async['onAuthEvent'](_0x391dde){const {urlResponse:_0x33bb24,sessionId:_0x4a4413,postBody:_0xf1d84,tenantId:_0x363c9e,error:_0x44413c,type:_0x5705fa}=_0x391dde;if(_0x44413c){this['reject'](_0x44413c);return;}const _0x1ff0f5={'auth':this['auth'],'requestUri':_0x33bb24,'sessionId':_0x4a4413,'tenantId':_0x363c9e||void 0x0,'postBody':_0xf1d84||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5705fa)(_0x1ff0f5));}catch(_0x127360){this['reject'](_0x127360);}}['onError'](_0x1a8eaa){this['reject'](_0x1a8eaa);}['getIdpTask'](_0x36f754){switch(_0x36f754){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0xadb993){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xadb993),this['unregisterAndCleanUp']();}['reject'](_0x5b7573){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5b7573),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4b40a6,_0x13d2e6,_0x58766b,_0x3266f0,_0x510c76){super(_0x4b40a6,_0x13d2e6,_0x3266f0,_0x510c76),this['provider']=_0x58766b,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0xd996c5=await this['execute']();return m(_0xd996c5,this['auth'],'internal-error'),_0xd996c5;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x47d026=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x47d026),this['authWindow']['associatedEvent']=_0x47d026,this['resolver']['_originValidation'](this['auth'])['catch'](_0x5b2822=>{this['reject'](_0x5b2822);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3a7e0c=>{_0x3a7e0c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3848b7;return((_0x3848b7=this['authWindow'])==null?void 0x0:_0x3848b7['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x50ddeb=()=>{var _0x23c728,_0x69c429;if((_0x69c429=(_0x23c728=this['authWindow'])==null?void 0x0:_0x23c728['window'])!=null&&_0x69c429['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x50ddeb,Tp['get']());};_0x50ddeb();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2e6706,_0x21317e,_0x5c4866=!0x1){super(_0x2e6706,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x21317e,void 0x0,_0x5c4866),this['eventId']=null;}async['execute'](){let _0x325ac0=hn['get'](this['auth']['_key']());if(!_0x325ac0){try{const _0x349b8a=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x325ac0=()=>Promise['resolve'](_0x349b8a);}catch(_0x4ce9fd){_0x325ac0=()=>Promise['reject'](_0x4ce9fd);}hn['set'](this['auth']['_key'](),_0x325ac0);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x325ac0();}async['onAuthEvent'](_0x2b078b){if(_0x2b078b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2b078b);if(_0x2b078b['type']==='unknown'){this['resolve'](null);return;}if(_0x2b078b['eventId']){const _0x2b38ae=await this['auth']['_redirectUserForId'](_0x2b078b['eventId']);if(_0x2b38ae)return this['user']=_0x2b38ae,super['onAuthEvent'](_0x2b078b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x23fe7f,_0x316222){const _0x4c6a42=Pp(_0x316222),_0x421976=kp(_0x23fe7f);if(!await _0x421976['_isAvailable']())return!0x1;const _0x32a0ac=await _0x421976['_get'](_0x4c6a42)==='true';return await _0x421976['_remove'](_0x4c6a42),_0x32a0ac;}function Ap(_0x1331d3,_0x4a5959){hn['set'](_0x1331d3['_key'](),_0x4a5959);}function kp(_0x5a6394){return ie(_0x5a6394['_redirectPersistence']);}function Pp(_0x2d1d13){return ln(Sp,_0x2d1d13['config']['apiKey'],_0x2d1d13['name']);}async function Np(_0x548e74,_0x2716dd,_0x4e2ec6=!0x1){if($(_0x548e74['app']))return Promise['reject'](re(_0x548e74));const _0x1c4ef9=Ke(_0x548e74),_0x2895f1=Ep(_0x1c4ef9,_0x2716dd),_0x2aeaa7=await new bp(_0x1c4ef9,_0x2895f1,_0x4e2ec6)['execute']();return _0x2aeaa7&&!_0x4e2ec6&&(delete _0x2aeaa7['user']['_redirectEventId'],await _0x1c4ef9['_persistUserIfCurrent'](_0x2aeaa7['user']),await _0x1c4ef9['_setRedirectUser'](null,_0x2716dd)),_0x2aeaa7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x2843b7){this['auth']=_0x2843b7,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x114937){this['consumers']['add'](_0x114937),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x114937)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x114937),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xe1e148){this['consumers']['delete'](_0xe1e148);}['onEvent'](_0x19bda3){if(this['hasEventBeenHandled'](_0x19bda3))return!0x1;let _0xe1800c=!0x1;return this['consumers']['forEach'](_0x1bd9c6=>{this['isEventForConsumer'](_0x19bda3,_0x1bd9c6)&&(_0xe1800c=!0x0,this['sendToConsumer'](_0x19bda3,_0x1bd9c6),this['saveEventToCache'](_0x19bda3));}),this['hasHandledPotentialRedirect']||!Mp(_0x19bda3)||(this['hasHandledPotentialRedirect']=!0x0,_0xe1800c||(this['queuedRedirectEvent']=_0x19bda3,_0xe1800c=!0x0)),_0xe1800c;}['sendToConsumer'](_0x915588,_0x457787){var _0x34a023;if(_0x915588['error']&&!Za(_0x915588)){const _0xa394ee=((_0x34a023=_0x915588['error']['code'])==null?void 0x0:_0x34a023['split']('auth/')[0x1])||'internal-error';_0x457787['onError'](X(this['auth'],_0xa394ee));}else _0x457787['onAuthEvent'](_0x915588);}['isEventForConsumer'](_0x2aaefd,_0x33d560){const _0x4e20cc=_0x33d560['eventId']===null||!!_0x2aaefd['eventId']&&_0x2aaefd['eventId']===_0x33d560['eventId'];return _0x33d560['filter']['includes'](_0x2aaefd['type'])&&_0x4e20cc;}['hasEventBeenHandled'](_0x158158){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x158158));}['saveEventToCache'](_0x4d690c){this['cachedEventUids']['add'](Mr(_0x4d690c)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x394485){return[_0x394485['type'],_0x394485['eventId'],_0x394485['sessionId'],_0x394485['tenantId']]['filter'](_0x495586=>_0x495586)['join']('-');}function Za({type:_0x4d0af0,error:_0x1d644b}){return _0x4d0af0==='unknown'&&(_0x1d644b==null?void 0x0:_0x1d644b['code'])==='auth/no-auth-event';}function Mp(_0x27c88a){switch(_0x27c88a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x27c88a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x57f3d6,_0x5db4fe={}){return Pe(_0x57f3d6,'GET','/v1/projects',_0x5db4fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x50be3f){if(_0x50be3f['config']['emulator'])return;const {authorizedDomains:_0x4061c2}=await Lp(_0x50be3f);for(const _0xba4430 of _0x4061c2)try{if(Wp(_0xba4430))return;}catch{}Y(_0x50be3f,'unauthorized-domain');}function Wp(_0x418d8e){const _0x552c0b=Mi(),{protocol:_0x1ff666,hostname:_0x1626e2}=new URL(_0x552c0b);if(_0x418d8e['startsWith']('chrome-extension://')){const _0x453693=new URL(_0x418d8e);return _0x453693['hostname']===''&&_0x1626e2===''?_0x1ff666==='chrome-extension:'&&_0x418d8e['replace']('chrome-extension://','')===_0x552c0b['replace']('chrome-extension://',''):_0x1ff666==='chrome-extension:'&&_0x453693['hostname']===_0x1626e2;}if(!Fp['test'](_0x1ff666))return!0x1;if(xp['test'](_0x418d8e))return _0x1626e2===_0x418d8e;const _0x1981f4=_0x418d8e['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1981f4+'|'+_0x1981f4+')$','i')['test'](_0x1626e2);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x211464=Z()['___jsl'];if(_0x211464!=null&&_0x211464['H']){for(const _0x345ffd of Object['keys'](_0x211464['H']))if(_0x211464['H'][_0x345ffd]['r']=_0x211464['H'][_0x345ffd]['r']||[],_0x211464['H'][_0x345ffd]['L']=_0x211464['H'][_0x345ffd]['L']||[],_0x211464['H'][_0x345ffd]['r']=[..._0x211464['H'][_0x345ffd]['L']],_0x211464['CP']){for(let _0x28c1c0=0x0;_0x28c1c0<_0x211464['CP']['length'];_0x28c1c0++)_0x211464['CP'][_0x28c1c0]=null;}}}function Vp(_0x17c831){return new Promise((_0x520484,_0x527d16)=>{var _0xbb6140,_0x420c54,_0x41ab08;function _0x118073(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x520484(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x527d16(X(_0x17c831,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x420c54=(_0xbb6140=Z()['gapi'])==null?void 0x0:_0xbb6140['iframes'])!=null&&_0x420c54['Iframe'])_0x520484(gapi['iframes']['getContext']());else{if((_0x41ab08=Z()['gapi'])!=null&&_0x41ab08['load'])_0x118073();else{const _0x365234=Ff('iframefcb');return Z()[_0x365234]=()=>{gapi['load']?_0x118073():_0x527d16(X(_0x17c831,'network-request-failed'));},xa(xf()+'?onload='+_0x365234)['catch'](_0x315a32=>_0x527d16(_0x315a32));}}})['catch'](_0x5e2381=>{throw un=null,_0x5e2381;});}let un=null;function Hp(_0x3444ee){return un=un||Vp(_0x3444ee),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x10b2b7){const _0x173992=_0x10b2b7['config'];m(_0x173992['authDomain'],_0x10b2b7,'auth-domain-config-required');const _0x427ab3=_0x173992['emulator']?Cs(_0x173992,qp):'https://'+_0x10b2b7['config']['authDomain']+'/'+Gp,_0x2cac3f={'apiKey':_0x173992['apiKey'],'appName':_0x10b2b7['name'],'v':dt},_0x36554f=jp['get'](_0x10b2b7['config']['apiHost']);_0x36554f&&(_0x2cac3f['eid']=_0x36554f);const _0x17fc36=_0x10b2b7['_getFrameworks']();return _0x17fc36['length']&&(_0x2cac3f['fw']=_0x17fc36['join'](',')),_0x427ab3+'?'+ut(_0x2cac3f)['slice'](0x1);}async function Yp(_0x148620){const _0x2d07ed=await Hp(_0x148620),_0x545cc1=Z()['gapi'];return m(_0x545cc1,_0x148620,'internal-error'),_0x2d07ed['open']({'where':document['body'],'url':Kp(_0x148620),'messageHandlersFilter':_0x545cc1['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x595eeb=>new Promise(async(_0x166399,_0x3d78fc)=>{await _0x595eeb['restyle']({'setHideOnLeave':!0x1});const _0x4f3e04=X(_0x148620,'network-request-failed'),_0xd56bde=Z()['setTimeout'](()=>{_0x3d78fc(_0x4f3e04);},$p['get']());function _0x350f01(){Z()['clearTimeout'](_0xd56bde),_0x166399(_0x595eeb);}_0x595eeb['ping'](_0x350f01)['then'](_0x350f01,()=>{_0x3d78fc(_0x4f3e04);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x31f6fa){this['window']=_0x31f6fa,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x2be18f,_0x5ef678,_0x29f101,_0x18c73d=Jp,_0x96fdff=Xp){const _0x188b19=Math['max']((window['screen']['availHeight']-_0x96fdff)/0x2,0x0)['toString'](),_0x5be761=Math['max']((window['screen']['availWidth']-_0x18c73d)/0x2,0x0)['toString']();let _0x576e0a='';const _0x309fb2={...Qp,'width':_0x18c73d['toString'](),'height':_0x96fdff['toString'](),'top':_0x188b19,'left':_0x5be761},_0x38e9cf=W()['toLowerCase']();_0x29f101&&(_0x576e0a=ka(_0x38e9cf)?Zp:_0x29f101),Ra(_0x38e9cf)&&(_0x5ef678=_0x5ef678||e_,_0x309fb2['scrollbars']='yes');const _0x544aea=Object['entries'](_0x309fb2)['reduce']((_0x96ce77,[_0x50e461,_0x27f11b])=>''+_0x96ce77+_0x50e461+'='+_0x27f11b+',','');if(Rf(_0x38e9cf)&&_0x576e0a!=='_self')return n_(_0x5ef678||'',_0x576e0a),new xr(null);const _0xd3789a=window['open'](_0x5ef678||'',_0x576e0a,_0x544aea);m(_0xd3789a,_0x2be18f,'popup-blocked');try{_0xd3789a['focus']();}catch{}return new xr(_0xd3789a);}function n_(_0x278c0e,_0x4d7a9c){const _0x2ce057=document['createElement']('a');_0x2ce057['href']=_0x278c0e,_0x2ce057['target']=_0x4d7a9c;const _0x5bc668=document['createEvent']('MouseEvent');_0x5bc668['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2ce057['dispatchEvent'](_0x5bc668);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x3a7adb,_0x46050c,_0x102cd3,_0x76e0b8,_0x1b88c2,_0x404418){m(_0x3a7adb['config']['authDomain'],_0x3a7adb,'auth-domain-config-required'),m(_0x3a7adb['config']['apiKey'],_0x3a7adb,'invalid-api-key');const _0x2e6dd8={'apiKey':_0x3a7adb['config']['apiKey'],'appName':_0x3a7adb['name'],'authType':_0x102cd3,'redirectUrl':_0x76e0b8,'v':dt,'eventId':_0x1b88c2};if(_0x46050c instanceof Wa){_0x46050c['setDefaultLanguage'](_0x3a7adb['languageCode']),_0x2e6dd8['providerId']=_0x46050c['providerId']||'',pn(_0x46050c['getCustomParameters']())||(_0x2e6dd8['customParameters']=JSON['stringify'](_0x46050c['getCustomParameters']()));for(const [_0x1991b7,_0x9c84d2]of Object['entries']({}))_0x2e6dd8[_0x1991b7]=_0x9c84d2;}if(_0x46050c instanceof tn){const _0x4be683=_0x46050c['getScopes']()['filter'](_0x3e264b=>_0x3e264b!=='');_0x4be683['length']>0x0&&(_0x2e6dd8['scopes']=_0x4be683['join'](','));}_0x3a7adb['tenantId']&&(_0x2e6dd8['tid']=_0x3a7adb['tenantId']);const _0x316226=_0x2e6dd8;for(const _0x4fc7ff of Object['keys'](_0x316226))_0x316226[_0x4fc7ff]===void 0x0&&delete _0x316226[_0x4fc7ff];const _0xd5d0fd=await _0x3a7adb['_getAppCheckToken'](),_0x58a575=_0xd5d0fd?'#'+r_+'='+encodeURIComponent(_0xd5d0fd):'';return o_(_0x3a7adb)+'?'+ut(_0x316226)['slice'](0x1)+_0x58a575;}function o_({config:_0x156360}){return _0x156360['emulator']?Cs(_0x156360,s_):'https://'+_0x156360['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x45d59d,_0x56bd62,_0x361824,_0x368992){var _0x199e6c;ce((_0x199e6c=this['eventManagers'][_0x45d59d['_key']()])==null?void 0x0:_0x199e6c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x31ea71=await Fr(_0x45d59d,_0x56bd62,_0x361824,Mi(),_0x368992);return t_(_0x45d59d,_0x31ea71,As());}async['_openRedirect'](_0x519a9d,_0x53182f,_0x3d2303,_0x2ba231){await this['_originValidation'](_0x519a9d);const _0x514f0a=await Fr(_0x519a9d,_0x53182f,_0x3d2303,Mi(),_0x2ba231);return hp(_0x514f0a),new Promise(()=>{});}['_initialize'](_0x4858e5){const _0x1312d3=_0x4858e5['_key']();if(this['eventManagers'][_0x1312d3]){const {manager:_0x41d591,promise:_0x1dca56}=this['eventManagers'][_0x1312d3];return _0x41d591?Promise['resolve'](_0x41d591):(ce(_0x1dca56,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1dca56);}const _0x18550f=this['initAndGetManager'](_0x4858e5);return this['eventManagers'][_0x1312d3]={'promise':_0x18550f},_0x18550f['catch'](()=>{delete this['eventManagers'][_0x1312d3];}),_0x18550f;}async['initAndGetManager'](_0x175218){const _0x469247=await Yp(_0x175218),_0x2eef1b=new Dp(_0x175218);return _0x469247['register']('authEvent',_0x20e1ad=>(m(_0x20e1ad==null?void 0x0:_0x20e1ad['authEvent'],_0x175218,'invalid-auth-event'),{'status':_0x2eef1b['onEvent'](_0x20e1ad['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x175218['_key']()]={'manager':_0x2eef1b},this['iframes'][_0x175218['_key']()]=_0x469247,_0x2eef1b;}['_isIframeWebStorageSupported'](_0x3a306e,_0xd0d744){this['iframes'][_0x3a306e['_key']()]['send'](pi,{'type':pi},_0xa6c38b=>{var _0x5e1997;const _0x384e60=(_0x5e1997=_0xa6c38b==null?void 0x0:_0xa6c38b[0x0])==null?void 0x0:_0x5e1997[pi];_0x384e60!==void 0x0&&_0xd0d744(!!_0x384e60),Y(_0x3a306e,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x8bbd91){const _0x5f0de4=_0x8bbd91['_key']();return this['originValidationPromises'][_0x5f0de4]||(this['originValidationPromises'][_0x5f0de4]=Up(_0x8bbd91)),this['originValidationPromises'][_0x5f0de4];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4c4f9a){this['auth']=_0x4c4f9a,this['internalListeners']=new Map();}['getUid'](){var _0x416985;return this['assertAuthConfigured'](),((_0x416985=this['auth']['currentUser'])==null?void 0x0:_0x416985['uid'])||null;}async['getToken'](_0x5b8d1d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5b8d1d)}:null;}['addAuthTokenListener'](_0x21b94e){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x21b94e))return;const _0x474240=this['auth']['onIdTokenChanged'](_0xe7c60d=>{_0x21b94e((_0xe7c60d==null?void 0x0:_0xe7c60d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x21b94e,_0x474240),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3dfc79){this['assertAuthConfigured']();const _0x2fe3eb=this['internalListeners']['get'](_0x3dfc79);_0x2fe3eb&&(this['internalListeners']['delete'](_0x3dfc79),_0x2fe3eb(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x25042e){switch(_0x25042e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4bcf37){st(new Fe('auth',(_0x17f30c,{options:_0x2205d7})=>{const _0x13ff8e=_0x17f30c['getProvider']('app')['getImmediate'](),_0x3351b3=_0x17f30c['getProvider']('heartbeat'),_0x543a6f=_0x17f30c['getProvider']('app-check-internal'),{apiKey:_0x3adefe,authDomain:_0x3c3102}=_0x13ff8e['options'];m(_0x3adefe&&!_0x3adefe['includes'](':'),'invalid-api-key',{'appName':_0x13ff8e['name']});const _0x9664b5={'apiKey':_0x3adefe,'authDomain':_0x3c3102,'clientPlatform':_0x4bcf37,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4bcf37)},_0x2f9445=new Df(_0x13ff8e,_0x3351b3,_0x543a6f,_0x9664b5);return Hf(_0x2f9445,_0x2205d7),_0x2f9445;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x261d78,_0x224947,_0x43314d)=>{_0x261d78['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x124fe3=>{const _0x153cb5=Ke(_0x124fe3['getProvider']('auth')['getImmediate']());return(_0x5df5f7=>new l_(_0x5df5f7))(_0x153cb5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4bcf37)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1382b6=>async _0x710829=>{const _0x3e7d81=_0x710829&&await _0x710829['getIdTokenResult'](),_0x5940bd=_0x3e7d81&&(new Date()['getTime']()-Date['parse'](_0x3e7d81['issuedAtTime']))/0x3e8;if(_0x5940bd&&_0x5940bd>f_)return;const _0x4ce47b=_0x3e7d81==null?void 0x0:_0x3e7d81['token'];Br!==_0x4ce47b&&(Br=_0x4ce47b,await fetch(_0x1382b6,{'method':_0x4ce47b?'POST':'DELETE','headers':_0x4ce47b?{'Authorization':'Bearer\x20'+_0x4ce47b}:{}}));};function B_(_0x3692e9=Zr()){const _0x1e9ac4=Hi(_0x3692e9,'auth');if(_0x1e9ac4['isInitialized']())return _0x1e9ac4['getImmediate']();const _0x4b6093=Vf(_0x3692e9,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x71978a=jr('authTokenSyncURL');if(_0x71978a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2562d3=new URL(_0x71978a,location['origin']);if(location['origin']===_0x2562d3['origin']){const _0x46234f=p_(_0x2562d3['toString']());sp(_0x4b6093,_0x46234f,()=>_0x46234f(_0x4b6093['currentUser'])),ip(_0x4b6093,_0x596ae5=>_0x46234f(_0x596ae5));}}const _0x4444b4=qr('auth');return _0x4444b4&&$f(_0x4b6093,'http://'+_0x4444b4),_0x4b6093;}function __(){var _0x509293;return((_0x509293=document['getElementsByTagName']('head'))==null?void 0x0:_0x509293[0x0])??document;}Mf({'loadJS'(_0x5379e8){return new Promise((_0x468ab3,_0x4056e9)=>{const _0x445bf3=document['createElement']('script');_0x445bf3['setAttribute']('src',_0x5379e8),_0x445bf3['onload']=_0x468ab3,_0x445bf3['onerror']=_0x5bbcf3=>{const _0x27d80b=X('internal-error');_0x27d80b['customData']=_0x5bbcf3,_0x4056e9(_0x27d80b);},_0x445bf3['type']='text/javascript',_0x445bf3['charset']='UTF-8',__()['appendChild'](_0x445bf3);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};