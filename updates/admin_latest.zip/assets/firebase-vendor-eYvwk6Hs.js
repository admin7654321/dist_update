const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x35464d,_0xdb407f){if(!_0x35464d)throw ht(_0xdb407f);},ht=function(_0x328e1d){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x328e1d);},Hr=function(_0x226117){const _0x36999e=[];let _0x3ac0ae=0x0;for(let _0x47c61c=0x0;_0x47c61c<_0x226117['length'];_0x47c61c++){let _0x1f06c5=_0x226117['charCodeAt'](_0x47c61c);_0x1f06c5<0x80?_0x36999e[_0x3ac0ae++]=_0x1f06c5:_0x1f06c5<0x800?(_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0x6|0xc0,_0x36999e[_0x3ac0ae++]=_0x1f06c5&0x3f|0x80):(_0x1f06c5&0xfc00)===0xd800&&_0x47c61c+0x1<_0x226117['length']&&(_0x226117['charCodeAt'](_0x47c61c+0x1)&0xfc00)===0xdc00?(_0x1f06c5=0x10000+((_0x1f06c5&0x3ff)<<0xa)+(_0x226117['charCodeAt'](++_0x47c61c)&0x3ff),_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0x12|0xf0,_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0xc&0x3f|0x80,_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0x6&0x3f|0x80,_0x36999e[_0x3ac0ae++]=_0x1f06c5&0x3f|0x80):(_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0xc|0xe0,_0x36999e[_0x3ac0ae++]=_0x1f06c5>>0x6&0x3f|0x80,_0x36999e[_0x3ac0ae++]=_0x1f06c5&0x3f|0x80);}return _0x36999e;},nc=function(_0x408c2b){const _0x568f41=[];let _0x6c9671=0x0,_0x145584=0x0;for(;_0x6c9671<_0x408c2b['length'];){const _0x583d4c=_0x408c2b[_0x6c9671++];if(_0x583d4c<0x80)_0x568f41[_0x145584++]=String['fromCharCode'](_0x583d4c);else{if(_0x583d4c>0xbf&&_0x583d4c<0xe0){const _0x87a5af=_0x408c2b[_0x6c9671++];_0x568f41[_0x145584++]=String['fromCharCode']((_0x583d4c&0x1f)<<0x6|_0x87a5af&0x3f);}else{if(_0x583d4c>0xef&&_0x583d4c<0x16d){const _0xf0301f=_0x408c2b[_0x6c9671++],_0x28b648=_0x408c2b[_0x6c9671++],_0x3b5d16=_0x408c2b[_0x6c9671++],_0x3cce3c=((_0x583d4c&0x7)<<0x12|(_0xf0301f&0x3f)<<0xc|(_0x28b648&0x3f)<<0x6|_0x3b5d16&0x3f)-0x10000;_0x568f41[_0x145584++]=String['fromCharCode'](0xd800+(_0x3cce3c>>0xa)),_0x568f41[_0x145584++]=String['fromCharCode'](0xdc00+(_0x3cce3c&0x3ff));}else{const _0x514f3b=_0x408c2b[_0x6c9671++],_0x370da0=_0x408c2b[_0x6c9671++];_0x568f41[_0x145584++]=String['fromCharCode']((_0x583d4c&0xf)<<0xc|(_0x514f3b&0x3f)<<0x6|_0x370da0&0x3f);}}}}return _0x568f41['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4a9b77,_0x59b531){if(!Array['isArray'](_0x4a9b77))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x178afb=_0x59b531?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x509db6=[];for(let _0x2b9c5a=0x0;_0x2b9c5a<_0x4a9b77['length'];_0x2b9c5a+=0x3){const _0x209dea=_0x4a9b77[_0x2b9c5a],_0xde065d=_0x2b9c5a+0x1<_0x4a9b77['length'],_0x140935=_0xde065d?_0x4a9b77[_0x2b9c5a+0x1]:0x0,_0xd7761d=_0x2b9c5a+0x2<_0x4a9b77['length'],_0x3a9069=_0xd7761d?_0x4a9b77[_0x2b9c5a+0x2]:0x0,_0x442332=_0x209dea>>0x2,_0x5d9d76=(_0x209dea&0x3)<<0x4|_0x140935>>0x4;let _0x4468ec=(_0x140935&0xf)<<0x2|_0x3a9069>>0x6,_0x1abe42=_0x3a9069&0x3f;_0xd7761d||(_0x1abe42=0x40,_0xde065d||(_0x4468ec=0x40)),_0x509db6['push'](_0x178afb[_0x442332],_0x178afb[_0x5d9d76],_0x178afb[_0x4468ec],_0x178afb[_0x1abe42]);}return _0x509db6['join']('');},'encodeString'(_0x111f91,_0x4f2d86){return this['HAS_NATIVE_SUPPORT']&&!_0x4f2d86?btoa(_0x111f91):this['encodeByteArray'](Hr(_0x111f91),_0x4f2d86);},'decodeString'(_0x451dc2,_0x21b322){return this['HAS_NATIVE_SUPPORT']&&!_0x21b322?atob(_0x451dc2):nc(this['decodeStringToByteArray'](_0x451dc2,_0x21b322));},'decodeStringToByteArray'(_0x29db62,_0x348237){this['init_']();const _0x4a0699=_0x348237?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2a5080=[];for(let _0x416ced=0x0;_0x416ced<_0x29db62['length'];){const _0x2bbcaa=_0x4a0699[_0x29db62['charAt'](_0x416ced++)],_0x470193=_0x416ced<_0x29db62['length']?_0x4a0699[_0x29db62['charAt'](_0x416ced)]:0x0;++_0x416ced;const _0x5353ce=_0x416ced<_0x29db62['length']?_0x4a0699[_0x29db62['charAt'](_0x416ced)]:0x40;++_0x416ced;const _0x51fa03=_0x416ced<_0x29db62['length']?_0x4a0699[_0x29db62['charAt'](_0x416ced)]:0x40;if(++_0x416ced,_0x2bbcaa==null||_0x470193==null||_0x5353ce==null||_0x51fa03==null)throw new ic();const _0x41d18e=_0x2bbcaa<<0x2|_0x470193>>0x4;if(_0x2a5080['push'](_0x41d18e),_0x5353ce!==0x40){const _0x2521dd=_0x470193<<0x4&0xf0|_0x5353ce>>0x2;if(_0x2a5080['push'](_0x2521dd),_0x51fa03!==0x40){const _0x481392=_0x5353ce<<0x6&0xc0|_0x51fa03;_0x2a5080['push'](_0x481392);}}}return _0x2a5080;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2831e9=0x0;_0x2831e9<this['ENCODED_VALS']['length'];_0x2831e9++)this['byteToCharMap_'][_0x2831e9]=this['ENCODED_VALS']['charAt'](_0x2831e9),this['charToByteMap_'][this['byteToCharMap_'][_0x2831e9]]=_0x2831e9,this['byteToCharMapWebSafe_'][_0x2831e9]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2831e9),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2831e9]]=_0x2831e9,_0x2831e9>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2831e9)]=_0x2831e9,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2831e9)]=_0x2831e9);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3b66a9){const _0x49fce3=Hr(_0x3b66a9);return Fi['encodeByteArray'](_0x49fce3,!0x0);},dn=function(_0x51d4a5){return $r(_0x51d4a5)['replace'](/\./g,'');},fn=function(_0xc525cb){try{return Fi['decodeString'](_0xc525cb,!0x0);}catch(_0x526fa1){console['error']('base64Decode\x20failed:\x20',_0x526fa1);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x28ee03){return Gr(void 0x0,_0x28ee03);}function Gr(_0x50aae1,_0x498df2){if(!(_0x498df2 instanceof Object))return _0x498df2;switch(_0x498df2['constructor']){case Date:const _0x1fb010=_0x498df2;return new Date(_0x1fb010['getTime']());case Object:_0x50aae1===void 0x0&&(_0x50aae1={});break;case Array:_0x50aae1=[];break;default:return _0x498df2;}for(const _0x5b618b in _0x498df2)!_0x498df2['hasOwnProperty'](_0x5b618b)||!rc(_0x5b618b)||(_0x50aae1[_0x5b618b]=Gr(_0x50aae1[_0x5b618b],_0x498df2[_0x5b618b]));return _0x50aae1;}function rc(_0x455441){return _0x455441!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1e3b29=Ps['__FIREBASE_DEFAULTS__'];if(_0x1e3b29)return JSON['parse'](_0x1e3b29);},lc=()=>{if(typeof document>'u')return;let _0x465a89;try{_0x465a89=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x372cec=_0x465a89&&fn(_0x465a89[0x1]);return _0x372cec&&JSON['parse'](_0x372cec);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x15b161){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x15b161);return;}},qr=_0x45a69e=>{var _0x56cda5,_0x15fd58;return(_0x15fd58=(_0x56cda5=Ui())==null?void 0x0:_0x56cda5['emulatorHosts'])==null?void 0x0:_0x15fd58[_0x45a69e];},hc=_0x51c3e8=>{const _0x22af65=qr(_0x51c3e8);if(!_0x22af65)return;const _0x5ee90a=_0x22af65['lastIndexOf'](':');if(_0x5ee90a<=0x0||_0x5ee90a+0x1===_0x22af65['length'])throw new Error('Invalid\x20host\x20'+_0x22af65+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2f4f2c=parseInt(_0x22af65['substring'](_0x5ee90a+0x1),0xa);return _0x22af65[0x0]==='['?[_0x22af65['substring'](0x1,_0x5ee90a-0x1),_0x2f4f2c]:[_0x22af65['substring'](0x0,_0x5ee90a),_0x2f4f2c];},zr=()=>{var _0xb9490a;return(_0xb9490a=Ui())==null?void 0x0:_0xb9490a['config'];},jr=_0x272de6=>{var _0x176e4b;return(_0x176e4b=Ui())==null?void 0x0:_0x176e4b['_'+_0x272de6];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x549a9d,_0x30837a)=>{this['resolve']=_0x549a9d,this['reject']=_0x30837a;});}['wrapCallback'](_0x520226){return(_0x13f98c,_0x22f074)=>{_0x13f98c?this['reject'](_0x13f98c):this['resolve'](_0x22f074),typeof _0x520226=='function'&&(this['promise']['catch'](()=>{}),_0x520226['length']===0x1?_0x520226(_0x13f98c):_0x520226(_0x13f98c,_0x22f074));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x5ae390,_0x3958d0){if(_0x5ae390['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1ff606={'alg':'none','type':'JWT'},_0x25a43a=_0x3958d0||'demo-project',_0x4e83fe=_0x5ae390['iat']||0x0,_0x226110=_0x5ae390['sub']||_0x5ae390['user_id'];if(!_0x226110)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2bc188={'iss':'https://securetoken.google.com/'+_0x25a43a,'aud':_0x25a43a,'iat':_0x4e83fe,'exp':_0x4e83fe+0xe10,'auth_time':_0x4e83fe,'sub':_0x226110,'user_id':_0x226110,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5ae390};return[dn(JSON['stringify'](_0x1ff606)),dn(JSON['stringify'](_0x2bc188)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x310972=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x310972=='object'&&_0x310972['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2bf112=W();return _0x2bf112['indexOf']('MSIE\x20')>=0x0||_0x2bf112['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x5d5ef2,_0x447be2)=>{try{let _0xc6a354=!0x0;const _0x28bead='validate-browser-context-for-indexeddb-analytics-module',_0x4676f3=self['indexedDB']['open'](_0x28bead);_0x4676f3['onsuccess']=()=>{_0x4676f3['result']['close'](),_0xc6a354||self['indexedDB']['deleteDatabase'](_0x28bead),_0x5d5ef2(!0x0);},_0x4676f3['onupgradeneeded']=()=>{_0xc6a354=!0x1;},_0x4676f3['onerror']=()=>{var _0x3ea89f;_0x447be2(((_0x3ea89f=_0x4676f3['error'])==null?void 0x0:_0x3ea89f['message'])||'');};}catch(_0x6fa108){_0x447be2(_0x6fa108);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x1e97d9,_0x504fbd,_0x29e677){super(_0x504fbd),this['code']=_0x1e97d9,this['customData']=_0x29e677,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x46a75e,_0x36e586,_0x4f10bd){this['service']=_0x46a75e,this['serviceName']=_0x36e586,this['errors']=_0x4f10bd;}['create'](_0xb2b84b,..._0x155ad3){const _0x256029=_0x155ad3[0x0]||{},_0x2a3f87=this['service']+'/'+_0xb2b84b,_0x10d7ad=this['errors'][_0xb2b84b],_0xf75a27=_0x10d7ad?vc(_0x10d7ad,_0x256029):'Error',_0x58f907=this['serviceName']+':\x20'+_0xf75a27+'\x20('+_0x2a3f87+').';return new Re(_0x2a3f87,_0x58f907,_0x256029);}}function vc(_0x47b0e2,_0xc0cc5f){return _0x47b0e2['replace'](Ec,(_0x2170e6,_0x441f84)=>{const _0xbc43a1=_0xc0cc5f[_0x441f84];return _0xbc43a1!=null?String(_0xbc43a1):'<'+_0x441f84+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x8064e6){return JSON['parse'](_0x8064e6);}function O(_0x158e80){return JSON['stringify'](_0x158e80);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2362b0){let _0x1e1044={},_0xbe5395={},_0x5c3949={},_0x223839='';try{const _0x471e2b=_0x2362b0['split']('.');_0x1e1044=Nt(fn(_0x471e2b[0x0])||''),_0xbe5395=Nt(fn(_0x471e2b[0x1])||''),_0x223839=_0x471e2b[0x2],_0x5c3949=_0xbe5395['d']||{},delete _0xbe5395['d'];}catch{}return{'header':_0x1e1044,'claims':_0xbe5395,'data':_0x5c3949,'signature':_0x223839};},Ic=function(_0x2f11fa){const _0xc6af7d=Yr(_0x2f11fa),_0x11433c=_0xc6af7d['claims'];return!!_0x11433c&&typeof _0x11433c=='object'&&_0x11433c['hasOwnProperty']('iat');},wc=function(_0x59fbb5){const _0x2bb97e=Yr(_0x59fbb5)['claims'];return typeof _0x2bb97e=='object'&&_0x2bb97e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x17b82a,_0xd20eb){return Object['prototype']['hasOwnProperty']['call'](_0x17b82a,_0xd20eb);}function Le(_0x1f4858,_0x1ca642){if(Object['prototype']['hasOwnProperty']['call'](_0x1f4858,_0x1ca642))return _0x1f4858[_0x1ca642];}function pn(_0x53cfa2){for(const _0x586b67 in _0x53cfa2)if(Object['prototype']['hasOwnProperty']['call'](_0x53cfa2,_0x586b67))return!0x1;return!0x0;}function _n(_0x3fe52d,_0x194848,_0x5eb9cf){const _0x4a1c58={};for(const _0x30844c in _0x3fe52d)Object['prototype']['hasOwnProperty']['call'](_0x3fe52d,_0x30844c)&&(_0x4a1c58[_0x30844c]=_0x194848['call'](_0x5eb9cf,_0x3fe52d[_0x30844c],_0x30844c,_0x3fe52d));return _0x4a1c58;}function xe(_0x50863e,_0x4bc6f0){if(_0x50863e===_0x4bc6f0)return!0x0;const _0x2658f8=Object['keys'](_0x50863e),_0x277104=Object['keys'](_0x4bc6f0);for(const _0x5db74 of _0x2658f8){if(!_0x277104['includes'](_0x5db74))return!0x1;const _0x219fa0=_0x50863e[_0x5db74],_0x1dbfce=_0x4bc6f0[_0x5db74];if(Ns(_0x219fa0)&&Ns(_0x1dbfce)){if(!xe(_0x219fa0,_0x1dbfce))return!0x1;}else{if(_0x219fa0!==_0x1dbfce)return!0x1;}}for(const _0x225c8a of _0x277104)if(!_0x2658f8['includes'](_0x225c8a))return!0x1;return!0x0;}function Ns(_0x258e65){return _0x258e65!==null&&typeof _0x258e65=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x12811f){const _0x17f22b=[];for(const [_0x337988,_0x2f9d6d]of Object['entries'](_0x12811f))Array['isArray'](_0x2f9d6d)?_0x2f9d6d['forEach'](_0x20f57e=>{_0x17f22b['push'](encodeURIComponent(_0x337988)+'='+encodeURIComponent(_0x20f57e));}):_0x17f22b['push'](encodeURIComponent(_0x337988)+'='+encodeURIComponent(_0x2f9d6d));return _0x17f22b['length']?'&'+_0x17f22b['join']('&'):'';}function Ct(_0x2ec37e){const _0x3a421e={};return _0x2ec37e['replace'](/^\?/,'')['split']('&')['forEach'](_0x4600dc=>{if(_0x4600dc){const [_0x24a94b,_0x19de54]=_0x4600dc['split']('=');_0x3a421e[decodeURIComponent(_0x24a94b)]=decodeURIComponent(_0x19de54);}}),_0x3a421e;}function Tt(_0x154e97){const _0x318312=_0x154e97['indexOf']('?');if(!_0x318312)return'';const _0x2356ba=_0x154e97['indexOf']('#',_0x318312);return _0x154e97['substring'](_0x318312,_0x2356ba>0x0?_0x2356ba:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x329435=0x1;_0x329435<this['blockSize'];++_0x329435)this['pad_'][_0x329435]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x47ef76,_0x3fb8e0){_0x3fb8e0||(_0x3fb8e0=0x0);const _0x283b25=this['W_'];if(typeof _0x47ef76=='string'){for(let _0x48726a=0x0;_0x48726a<0x10;_0x48726a++)_0x283b25[_0x48726a]=_0x47ef76['charCodeAt'](_0x3fb8e0)<<0x18|_0x47ef76['charCodeAt'](_0x3fb8e0+0x1)<<0x10|_0x47ef76['charCodeAt'](_0x3fb8e0+0x2)<<0x8|_0x47ef76['charCodeAt'](_0x3fb8e0+0x3),_0x3fb8e0+=0x4;}else{for(let _0x5c3bc8=0x0;_0x5c3bc8<0x10;_0x5c3bc8++)_0x283b25[_0x5c3bc8]=_0x47ef76[_0x3fb8e0]<<0x18|_0x47ef76[_0x3fb8e0+0x1]<<0x10|_0x47ef76[_0x3fb8e0+0x2]<<0x8|_0x47ef76[_0x3fb8e0+0x3],_0x3fb8e0+=0x4;}for(let _0x4bfd85=0x10;_0x4bfd85<0x50;_0x4bfd85++){const _0xa5ec4c=_0x283b25[_0x4bfd85-0x3]^_0x283b25[_0x4bfd85-0x8]^_0x283b25[_0x4bfd85-0xe]^_0x283b25[_0x4bfd85-0x10];_0x283b25[_0x4bfd85]=(_0xa5ec4c<<0x1|_0xa5ec4c>>>0x1f)&0xffffffff;}let _0x259481=this['chain_'][0x0],_0x4e6218=this['chain_'][0x1],_0x303f45=this['chain_'][0x2],_0x19aa34=this['chain_'][0x3],_0x48357c=this['chain_'][0x4],_0x51a939,_0x211f50;for(let _0x31346f=0x0;_0x31346f<0x50;_0x31346f++){_0x31346f<0x28?_0x31346f<0x14?(_0x51a939=_0x19aa34^_0x4e6218&(_0x303f45^_0x19aa34),_0x211f50=0x5a827999):(_0x51a939=_0x4e6218^_0x303f45^_0x19aa34,_0x211f50=0x6ed9eba1):_0x31346f<0x3c?(_0x51a939=_0x4e6218&_0x303f45|_0x19aa34&(_0x4e6218|_0x303f45),_0x211f50=0x8f1bbcdc):(_0x51a939=_0x4e6218^_0x303f45^_0x19aa34,_0x211f50=0xca62c1d6);const _0x1f5532=(_0x259481<<0x5|_0x259481>>>0x1b)+_0x51a939+_0x48357c+_0x211f50+_0x283b25[_0x31346f]&0xffffffff;_0x48357c=_0x19aa34,_0x19aa34=_0x303f45,_0x303f45=(_0x4e6218<<0x1e|_0x4e6218>>>0x2)&0xffffffff,_0x4e6218=_0x259481,_0x259481=_0x1f5532;}this['chain_'][0x0]=this['chain_'][0x0]+_0x259481&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4e6218&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x303f45&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x19aa34&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x48357c&0xffffffff;}['update'](_0x5a9d84,_0x25a1d9){if(_0x5a9d84==null)return;_0x25a1d9===void 0x0&&(_0x25a1d9=_0x5a9d84['length']);const _0x4f1b83=_0x25a1d9-this['blockSize'];let _0xb6220e=0x0;const _0x1e4d33=this['buf_'];let _0xcdcbf7=this['inbuf_'];for(;_0xb6220e<_0x25a1d9;){if(_0xcdcbf7===0x0){for(;_0xb6220e<=_0x4f1b83;)this['compress_'](_0x5a9d84,_0xb6220e),_0xb6220e+=this['blockSize'];}if(typeof _0x5a9d84=='string'){for(;_0xb6220e<_0x25a1d9;)if(_0x1e4d33[_0xcdcbf7]=_0x5a9d84['charCodeAt'](_0xb6220e),++_0xcdcbf7,++_0xb6220e,_0xcdcbf7===this['blockSize']){this['compress_'](_0x1e4d33),_0xcdcbf7=0x0;break;}}else{for(;_0xb6220e<_0x25a1d9;)if(_0x1e4d33[_0xcdcbf7]=_0x5a9d84[_0xb6220e],++_0xcdcbf7,++_0xb6220e,_0xcdcbf7===this['blockSize']){this['compress_'](_0x1e4d33),_0xcdcbf7=0x0;break;}}}this['inbuf_']=_0xcdcbf7,this['total_']+=_0x25a1d9;}['digest'](){const _0x22e490=[];let _0x586552=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x27a6de=this['blockSize']-0x1;_0x27a6de>=0x38;_0x27a6de--)this['buf_'][_0x27a6de]=_0x586552&0xff,_0x586552/=0x100;this['compress_'](this['buf_']);let _0x118afa=0x0;for(let _0x32cb81=0x0;_0x32cb81<0x5;_0x32cb81++)for(let _0x1994d1=0x18;_0x1994d1>=0x0;_0x1994d1-=0x8)_0x22e490[_0x118afa]=this['chain_'][_0x32cb81]>>_0x1994d1&0xff,++_0x118afa;return _0x22e490;}}function Tc(_0x2c03ce,_0x3824f5){const _0x4c46e8=new Sc(_0x2c03ce,_0x3824f5);return _0x4c46e8['subscribe']['bind'](_0x4c46e8);}class Sc{constructor(_0xb0f9b7,_0x5bb892){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5bb892,this['task']['then'](()=>{_0xb0f9b7(this);})['catch'](_0x4679fd=>{this['error'](_0x4679fd);});}['next'](_0x59624b){this['forEachObserver'](_0x7bb456=>{_0x7bb456['next'](_0x59624b);});}['error'](_0x49804d){this['forEachObserver'](_0x4708c9=>{_0x4708c9['error'](_0x49804d);}),this['close'](_0x49804d);}['complete'](){this['forEachObserver'](_0x2ae5fc=>{_0x2ae5fc['complete']();}),this['close']();}['subscribe'](_0x285133,_0x24cd72,_0x2311f9){let _0x3dfae9;if(_0x285133===void 0x0&&_0x24cd72===void 0x0&&_0x2311f9===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x285133,['next','error','complete'])?_0x3dfae9=_0x285133:_0x3dfae9={'next':_0x285133,'error':_0x24cd72,'complete':_0x2311f9},_0x3dfae9['next']===void 0x0&&(_0x3dfae9['next']=ti),_0x3dfae9['error']===void 0x0&&(_0x3dfae9['error']=ti),_0x3dfae9['complete']===void 0x0&&(_0x3dfae9['complete']=ti);const _0x567726=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3dfae9['error'](this['finalError']):_0x3dfae9['complete']();}catch{}}),this['observers']['push'](_0x3dfae9),_0x567726;}['unsubscribeOne'](_0x208452){this['observers']===void 0x0||this['observers'][_0x208452]===void 0x0||(delete this['observers'][_0x208452],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x493794){if(!this['finalized']){for(let _0x440e17=0x0;_0x440e17<this['observers']['length'];_0x440e17++)this['sendOne'](_0x440e17,_0x493794);}}['sendOne'](_0xbca74c,_0x4400ef){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xbca74c]!==void 0x0)try{_0x4400ef(this['observers'][_0xbca74c]);}catch(_0x352701){typeof console<'u'&&console['error']&&console['error'](_0x352701);}});}['close'](_0xd976f9){this['finalized']||(this['finalized']=!0x0,_0xd976f9!==void 0x0&&(this['finalError']=_0xd976f9),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xdd6bb0,_0x5f59e1){if(typeof _0xdd6bb0!='object'||_0xdd6bb0===null)return!0x1;for(const _0x5eb6c3 of _0x5f59e1)if(_0x5eb6c3 in _0xdd6bb0&&typeof _0xdd6bb0[_0x5eb6c3]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1408c9,_0xc87e2b){return _0x1408c9+'\x20failed:\x20'+_0xc87e2b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3d8fd9){const _0x4f2106=[];let _0x5907dc=0x0;for(let _0x418897=0x0;_0x418897<_0x3d8fd9['length'];_0x418897++){let _0x10ade9=_0x3d8fd9['charCodeAt'](_0x418897);if(_0x10ade9>=0xd800&&_0x10ade9<=0xdbff){const _0x2eaa7a=_0x10ade9-0xd800;_0x418897++,f(_0x418897<_0x3d8fd9['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x428346=_0x3d8fd9['charCodeAt'](_0x418897)-0xdc00;_0x10ade9=0x10000+(_0x2eaa7a<<0xa)+_0x428346;}_0x10ade9<0x80?_0x4f2106[_0x5907dc++]=_0x10ade9:_0x10ade9<0x800?(_0x4f2106[_0x5907dc++]=_0x10ade9>>0x6|0xc0,_0x4f2106[_0x5907dc++]=_0x10ade9&0x3f|0x80):_0x10ade9<0x10000?(_0x4f2106[_0x5907dc++]=_0x10ade9>>0xc|0xe0,_0x4f2106[_0x5907dc++]=_0x10ade9>>0x6&0x3f|0x80,_0x4f2106[_0x5907dc++]=_0x10ade9&0x3f|0x80):(_0x4f2106[_0x5907dc++]=_0x10ade9>>0x12|0xf0,_0x4f2106[_0x5907dc++]=_0x10ade9>>0xc&0x3f|0x80,_0x4f2106[_0x5907dc++]=_0x10ade9>>0x6&0x3f|0x80,_0x4f2106[_0x5907dc++]=_0x10ade9&0x3f|0x80);}return _0x4f2106;},Ln=function(_0x3ce653){let _0xc62e96=0x0;for(let _0x4d5369=0x0;_0x4d5369<_0x3ce653['length'];_0x4d5369++){const _0x3a2fe4=_0x3ce653['charCodeAt'](_0x4d5369);_0x3a2fe4<0x80?_0xc62e96++:_0x3a2fe4<0x800?_0xc62e96+=0x2:_0x3a2fe4>=0xd800&&_0x3a2fe4<=0xdbff?(_0xc62e96+=0x4,_0x4d5369++):_0xc62e96+=0x3;}return _0xc62e96;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0xcb0940){return _0xcb0940&&_0xcb0940['_delegate']?_0xcb0940['_delegate']:_0xcb0940;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3f70c1){try{return(_0x3f70c1['startsWith']('http://')||_0x3f70c1['startsWith']('https://')?new URL(_0x3f70c1)['hostname']:_0x3f70c1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x29b753){return(await fetch(_0x29b753,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x504c3a,_0x1e8106,_0x243d60){this['name']=_0x504c3a,this['instanceFactory']=_0x1e8106,this['type']=_0x243d60,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5c163a){return this['instantiationMode']=_0x5c163a,this;}['setMultipleInstances'](_0x11550d){return this['multipleInstances']=_0x11550d,this;}['setServiceProps'](_0x188412){return this['serviceProps']=_0x188412,this;}['setInstanceCreatedCallback'](_0x36acf2){return this['onInstanceCreated']=_0x36acf2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x17b824,_0x3652da){this['name']=_0x17b824,this['container']=_0x3652da,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1327a7){const _0x12f02a=this['normalizeInstanceIdentifier'](_0x1327a7);if(!this['instancesDeferred']['has'](_0x12f02a)){const _0x392c60=new H();if(this['instancesDeferred']['set'](_0x12f02a,_0x392c60),this['isInitialized'](_0x12f02a)||this['shouldAutoInitialize']())try{const _0x530dd7=this['getOrInitializeService']({'instanceIdentifier':_0x12f02a});_0x530dd7&&_0x392c60['resolve'](_0x530dd7);}catch{}}return this['instancesDeferred']['get'](_0x12f02a)['promise'];}['getImmediate'](_0x31bc8a){const _0x4e4822=this['normalizeInstanceIdentifier'](_0x31bc8a==null?void 0x0:_0x31bc8a['identifier']),_0x58674d=(_0x31bc8a==null?void 0x0:_0x31bc8a['optional'])??!0x1;if(this['isInitialized'](_0x4e4822)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4e4822});}catch(_0x54d435){if(_0x58674d)return null;throw _0x54d435;}else{if(_0x58674d)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x451ebf){if(_0x451ebf['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x451ebf['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x451ebf,!!this['shouldAutoInitialize']()){if(Pc(_0x451ebf))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x48c6da,_0x1237f8]of this['instancesDeferred']['entries']()){const _0x21f7d9=this['normalizeInstanceIdentifier'](_0x48c6da);try{const _0xaff64c=this['getOrInitializeService']({'instanceIdentifier':_0x21f7d9});_0x1237f8['resolve'](_0xaff64c);}catch{}}}}['clearInstance'](_0x25af1b=Ne){this['instancesDeferred']['delete'](_0x25af1b),this['instancesOptions']['delete'](_0x25af1b),this['instances']['delete'](_0x25af1b);}async['delete'](){const _0x4479b5=Array['from'](this['instances']['values']());await Promise['all']([..._0x4479b5['filter'](_0x19a1c7=>'INTERNAL'in _0x19a1c7)['map'](_0x52481f=>_0x52481f['INTERNAL']['delete']()),..._0x4479b5['filter'](_0x441248=>'_delete'in _0x441248)['map'](_0x59513c=>_0x59513c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x43a94e=Ne){return this['instances']['has'](_0x43a94e);}['getOptions'](_0x32317a=Ne){return this['instancesOptions']['get'](_0x32317a)||{};}['initialize'](_0x15bc4e={}){const {options:_0x5c8390={}}=_0x15bc4e,_0x3c6a8a=this['normalizeInstanceIdentifier'](_0x15bc4e['instanceIdentifier']);if(this['isInitialized'](_0x3c6a8a))throw Error(this['name']+'('+_0x3c6a8a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1e9848=this['getOrInitializeService']({'instanceIdentifier':_0x3c6a8a,'options':_0x5c8390});for(const [_0xd3b48a,_0x3eed7c]of this['instancesDeferred']['entries']()){const _0x57d623=this['normalizeInstanceIdentifier'](_0xd3b48a);_0x3c6a8a===_0x57d623&&_0x3eed7c['resolve'](_0x1e9848);}return _0x1e9848;}['onInit'](_0x53dce2,_0x24a539){const _0x148b62=this['normalizeInstanceIdentifier'](_0x24a539),_0x1a4a69=this['onInitCallbacks']['get'](_0x148b62)??new Set();_0x1a4a69['add'](_0x53dce2),this['onInitCallbacks']['set'](_0x148b62,_0x1a4a69);const _0x40a39d=this['instances']['get'](_0x148b62);return _0x40a39d&&_0x53dce2(_0x40a39d,_0x148b62),()=>{_0x1a4a69['delete'](_0x53dce2);};}['invokeOnInitCallbacks'](_0x2a7cc8,_0x2503cd){const _0x3276ed=this['onInitCallbacks']['get'](_0x2503cd);if(_0x3276ed){for(const _0x3cf5eb of _0x3276ed)try{_0x3cf5eb(_0x2a7cc8,_0x2503cd);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x40c653,options:_0x3a479f={}}){let _0x1cc700=this['instances']['get'](_0x40c653);if(!_0x1cc700&&this['component']&&(_0x1cc700=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x40c653),'options':_0x3a479f}),this['instances']['set'](_0x40c653,_0x1cc700),this['instancesOptions']['set'](_0x40c653,_0x3a479f),this['invokeOnInitCallbacks'](_0x1cc700,_0x40c653),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x40c653,_0x1cc700);}catch{}return _0x1cc700||null;}['normalizeInstanceIdentifier'](_0x142e4a=Ne){return this['component']?this['component']['multipleInstances']?_0x142e4a:Ne:_0x142e4a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5dbca9){return _0x5dbca9===Ne?void 0x0:_0x5dbca9;}function Pc(_0x20b3f6){return _0x20b3f6['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x49b499){this['name']=_0x49b499,this['providers']=new Map();}['addComponent'](_0x14be93){const _0x4813e4=this['getProvider'](_0x14be93['name']);if(_0x4813e4['isComponentSet']())throw new Error('Component\x20'+_0x14be93['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4813e4['setComponent'](_0x14be93);}['addOrOverwriteComponent'](_0x160cf9){this['getProvider'](_0x160cf9['name'])['isComponentSet']()&&this['providers']['delete'](_0x160cf9['name']),this['addComponent'](_0x160cf9);}['getProvider'](_0x4738a1){if(this['providers']['has'](_0x4738a1))return this['providers']['get'](_0x4738a1);const _0x1a7fb0=new Ac(_0x4738a1,this);return this['providers']['set'](_0x4738a1,_0x1a7fb0),_0x1a7fb0;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4294c5){_0x4294c5[_0x4294c5['DEBUG']=0x0]='DEBUG',_0x4294c5[_0x4294c5['VERBOSE']=0x1]='VERBOSE',_0x4294c5[_0x4294c5['INFO']=0x2]='INFO',_0x4294c5[_0x4294c5['WARN']=0x3]='WARN',_0x4294c5[_0x4294c5['ERROR']=0x4]='ERROR',_0x4294c5[_0x4294c5['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x25d051,_0x5df593,..._0x3c6ebc)=>{if(_0x5df593<_0x25d051['logLevel'])return;const _0x4b46da=new Date()['toISOString'](),_0x25bfc0=Mc[_0x5df593];if(_0x25bfc0)console[_0x25bfc0]('['+_0x4b46da+']\x20\x20'+_0x25d051['name']+':',..._0x3c6ebc);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5df593+')');};class Bi{constructor(_0x448ca2){this['name']=_0x448ca2,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5182d7){if(!(_0x5182d7 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5182d7+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5182d7;}['setLogLevel'](_0x36c08c){this['_logLevel']=typeof _0x36c08c=='string'?Oc[_0x36c08c]:_0x36c08c;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x541037){if(typeof _0x541037!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x541037;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x31c28c){this['_userLogHandler']=_0x31c28c;}['debug'](..._0x58db4e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x58db4e),this['_logHandler'](this,T['DEBUG'],..._0x58db4e);}['log'](..._0x5553fb){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5553fb),this['_logHandler'](this,T['VERBOSE'],..._0x5553fb);}['info'](..._0x5e1afe){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5e1afe),this['_logHandler'](this,T['INFO'],..._0x5e1afe);}['warn'](..._0x1edb8f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1edb8f),this['_logHandler'](this,T['WARN'],..._0x1edb8f);}['error'](..._0x40a0ad){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x40a0ad),this['_logHandler'](this,T['ERROR'],..._0x40a0ad);}}const xc=(_0x30cf86,_0x2313f7)=>_0x2313f7['some'](_0x3ff1f6=>_0x30cf86 instanceof _0x3ff1f6);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x149a17){const _0x2c6ffd=new Promise((_0x5b1dba,_0x53bd31)=>{const _0x51f4c7=()=>{_0x149a17['removeEventListener']('success',_0x26493f),_0x149a17['removeEventListener']('error',_0x579188);},_0x26493f=()=>{_0x5b1dba(ge(_0x149a17['result'])),_0x51f4c7();},_0x579188=()=>{_0x53bd31(_0x149a17['error']),_0x51f4c7();};_0x149a17['addEventListener']('success',_0x26493f),_0x149a17['addEventListener']('error',_0x579188);});return _0x2c6ffd['then'](_0x1dc80b=>{_0x1dc80b instanceof IDBCursor&&Jr['set'](_0x1dc80b,_0x149a17);})['catch'](()=>{}),Vi['set'](_0x2c6ffd,_0x149a17),_0x2c6ffd;}function Bc(_0x3e3e9e){if(_i['has'](_0x3e3e9e))return;const _0x4c448a=new Promise((_0x58bdb6,_0x198891)=>{const _0x44dd81=()=>{_0x3e3e9e['removeEventListener']('complete',_0x31fc89),_0x3e3e9e['removeEventListener']('error',_0x4d9bbe),_0x3e3e9e['removeEventListener']('abort',_0x4d9bbe);},_0x31fc89=()=>{_0x58bdb6(),_0x44dd81();},_0x4d9bbe=()=>{_0x198891(_0x3e3e9e['error']||new DOMException('AbortError','AbortError')),_0x44dd81();};_0x3e3e9e['addEventListener']('complete',_0x31fc89),_0x3e3e9e['addEventListener']('error',_0x4d9bbe),_0x3e3e9e['addEventListener']('abort',_0x4d9bbe);});_i['set'](_0x3e3e9e,_0x4c448a);}let gi={'get'(_0x36de9a,_0x571997,_0x5659fe){if(_0x36de9a instanceof IDBTransaction){if(_0x571997==='done')return _i['get'](_0x36de9a);if(_0x571997==='objectStoreNames')return _0x36de9a['objectStoreNames']||Xr['get'](_0x36de9a);if(_0x571997==='store')return _0x5659fe['objectStoreNames'][0x1]?void 0x0:_0x5659fe['objectStore'](_0x5659fe['objectStoreNames'][0x0]);}return ge(_0x36de9a[_0x571997]);},'set'(_0x54a01d,_0x30350c,_0x5d4139){return _0x54a01d[_0x30350c]=_0x5d4139,!0x0;},'has'(_0x2737c0,_0x384cb4){return _0x2737c0 instanceof IDBTransaction&&(_0x384cb4==='done'||_0x384cb4==='store')?!0x0:_0x384cb4 in _0x2737c0;}};function Vc(_0x192a11){gi=_0x192a11(gi);}function Hc(_0x2110cf){return _0x2110cf===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2e3620,..._0x3bffe2){const _0x357beb=_0x2110cf['call'](ii(this),_0x2e3620,..._0x3bffe2);return Xr['set'](_0x357beb,_0x2e3620['sort']?_0x2e3620['sort']():[_0x2e3620]),ge(_0x357beb);}:Uc()['includes'](_0x2110cf)?function(..._0x4d6112){return _0x2110cf['apply'](ii(this),_0x4d6112),ge(Jr['get'](this));}:function(..._0x1d92a7){return ge(_0x2110cf['apply'](ii(this),_0x1d92a7));};}function $c(_0x40b8c6){return typeof _0x40b8c6=='function'?Hc(_0x40b8c6):(_0x40b8c6 instanceof IDBTransaction&&Bc(_0x40b8c6),xc(_0x40b8c6,Fc())?new Proxy(_0x40b8c6,gi):_0x40b8c6);}function ge(_0x3c717e){if(_0x3c717e instanceof IDBRequest)return Wc(_0x3c717e);if(ni['has'](_0x3c717e))return ni['get'](_0x3c717e);const _0x4b20d0=$c(_0x3c717e);return _0x4b20d0!==_0x3c717e&&(ni['set'](_0x3c717e,_0x4b20d0),Vi['set'](_0x4b20d0,_0x3c717e)),_0x4b20d0;}const ii=_0x3c4bfd=>Vi['get'](_0x3c4bfd);function Gc(_0x21523d,_0x3f8440,{blocked:_0x276ecc,upgrade:_0x2bbc9f,blocking:_0x56e068,terminated:_0x1584c5}={}){const _0x244ffb=indexedDB['open'](_0x21523d,_0x3f8440),_0x333cf2=ge(_0x244ffb);return _0x2bbc9f&&_0x244ffb['addEventListener']('upgradeneeded',_0x36ef1b=>{_0x2bbc9f(ge(_0x244ffb['result']),_0x36ef1b['oldVersion'],_0x36ef1b['newVersion'],ge(_0x244ffb['transaction']),_0x36ef1b);}),_0x276ecc&&_0x244ffb['addEventListener']('blocked',_0x15e5eb=>_0x276ecc(_0x15e5eb['oldVersion'],_0x15e5eb['newVersion'],_0x15e5eb)),_0x333cf2['then'](_0x4b98b2=>{_0x1584c5&&_0x4b98b2['addEventListener']('close',()=>_0x1584c5()),_0x56e068&&_0x4b98b2['addEventListener']('versionchange',_0x439c31=>_0x56e068(_0x439c31['oldVersion'],_0x439c31['newVersion'],_0x439c31));})['catch'](()=>{}),_0x333cf2;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x4eff04,_0x5e81b3){if(!(_0x4eff04 instanceof IDBDatabase&&!(_0x5e81b3 in _0x4eff04)&&typeof _0x5e81b3=='string'))return;if(si['get'](_0x5e81b3))return si['get'](_0x5e81b3);const _0x49a5e3=_0x5e81b3['replace'](/FromIndex$/,''),_0x535268=_0x5e81b3!==_0x49a5e3,_0x149a8d=zc['includes'](_0x49a5e3);if(!(_0x49a5e3 in(_0x535268?IDBIndex:IDBObjectStore)['prototype'])||!(_0x149a8d||qc['includes'](_0x49a5e3)))return;const _0x1be91d=async function(_0x4988b3,..._0x288842){const _0x4b9de7=this['transaction'](_0x4988b3,_0x149a8d?'readwrite':'readonly');let _0xeff235=_0x4b9de7['store'];return _0x535268&&(_0xeff235=_0xeff235['index'](_0x288842['shift']())),(await Promise['all']([_0xeff235[_0x49a5e3](..._0x288842),_0x149a8d&&_0x4b9de7['done']]))[0x0];};return si['set'](_0x5e81b3,_0x1be91d),_0x1be91d;}Vc(_0x53dcc4=>({..._0x53dcc4,'get':(_0x1ba3de,_0x292249,_0x9393a1)=>Ms(_0x1ba3de,_0x292249)||_0x53dcc4['get'](_0x1ba3de,_0x292249,_0x9393a1),'has':(_0x1e9fbb,_0x48a4d4)=>!!Ms(_0x1e9fbb,_0x48a4d4)||_0x53dcc4['has'](_0x1e9fbb,_0x48a4d4)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x2371c0){this['container']=_0x2371c0;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1ad841=>{if(Kc(_0x1ad841)){const _0x4fc29b=_0x1ad841['getImmediate']();return _0x4fc29b['library']+'/'+_0x4fc29b['version'];}else return null;})['filter'](_0x1cdb71=>_0x1cdb71)['join']('\x20');}}function Kc(_0x54508d){const _0x4d2f62=_0x54508d['getComponent']();return(_0x4d2f62==null?void 0x0:_0x4d2f62['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x20be24,_0x5148d2){try{_0x20be24['container']['addComponent'](_0x5148d2);}catch(_0x233208){oe['debug']('Component\x20'+_0x5148d2['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x20be24['name'],_0x233208);}}function st(_0x2d9539){const _0x3098ab=_0x2d9539['name'];if(Ei['has'](_0x3098ab))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3098ab+'.'),!0x1;Ei['set'](_0x3098ab,_0x2d9539);for(const _0x2793f2 of Ue['values']())xs(_0x2793f2,_0x2d9539);for(const _0x427aa4 of vi['values']())xs(_0x427aa4,_0x2d9539);return!0x0;}function Hi(_0x4e919e,_0x4b1bd4){const _0x26bd9d=_0x4e919e['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x26bd9d&&_0x26bd9d['triggerHeartbeat'](),_0x4e919e['container']['getProvider'](_0x4b1bd4);}function $(_0x24e793){return _0x24e793==null?!0x1:_0x24e793['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5d6818,_0x3865b1,_0x2f1118){this['_isDeleted']=!0x1,this['_options']={..._0x5d6818},this['_config']={..._0x3865b1},this['_name']=_0x3865b1['name'],this['_automaticDataCollectionEnabled']=_0x3865b1['automaticDataCollectionEnabled'],this['_container']=_0x2f1118,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x41db37){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x41db37;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4e2294){this['_isDeleted']=_0x4e2294;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x52d6c8,_0x2d5676={}){let _0xfe2732=_0x52d6c8;typeof _0x2d5676!='object'&&(_0x2d5676={'name':_0x2d5676});const _0x284670={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x2d5676},_0x1c6996=_0x284670['name'];if(typeof _0x1c6996!='string'||!_0x1c6996)throw me['create']('bad-app-name',{'appName':String(_0x1c6996)});if(_0xfe2732||(_0xfe2732=zr()),!_0xfe2732)throw me['create']('no-options');const _0x21b460=Ue['get'](_0x1c6996);if(_0x21b460){if(xe(_0xfe2732,_0x21b460['options'])&&xe(_0x284670,_0x21b460['config']))return _0x21b460;throw me['create']('duplicate-app',{'appName':_0x1c6996});}const _0x4aae03=new Nc(_0x1c6996);for(const _0x1f7347 of Ei['values']())_0x4aae03['addComponent'](_0x1f7347);const _0x21df91=new Tl(_0xfe2732,_0x284670,_0x4aae03);return Ue['set'](_0x1c6996,_0x21df91),_0x21df91;}function Zr(_0x55abcf=yi){const _0x3a30f4=Ue['get'](_0x55abcf);if(!_0x3a30f4&&_0x55abcf===yi&&zr())return Sl();if(!_0x3a30f4)throw me['create']('no-app',{'appName':_0x55abcf});return _0x3a30f4;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x1ec073){let _0x2891fb=!0x1;const _0x4ff5bf=_0x1ec073['name'];Ue['has'](_0x4ff5bf)?(_0x2891fb=!0x0,Ue['delete'](_0x4ff5bf)):vi['has'](_0x4ff5bf)&&_0x1ec073['decRefCount']()<=0x0&&(vi['delete'](_0x4ff5bf),_0x2891fb=!0x0),_0x2891fb&&(await Promise['all'](_0x1ec073['container']['getProviders']()['map'](_0x11c9ca=>_0x11c9ca['delete']())),_0x1ec073['isDeleted']=!0x0);}function ye(_0x4fce42,_0x3d3ecc,_0x34423d){let _0x1025d3=wl[_0x4fce42]??_0x4fce42;_0x34423d&&(_0x1025d3+='-'+_0x34423d);const _0x2e39dd=_0x1025d3['match'](/\s|\//),_0x95c1d6=_0x3d3ecc['match'](/\s|\//);if(_0x2e39dd||_0x95c1d6){const _0x55631f=['Unable\x20to\x20register\x20library\x20\x22'+_0x1025d3+'\x22\x20with\x20version\x20\x22'+_0x3d3ecc+'\x22:'];_0x2e39dd&&_0x55631f['push']('library\x20name\x20\x22'+_0x1025d3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2e39dd&&_0x95c1d6&&_0x55631f['push']('and'),_0x95c1d6&&_0x55631f['push']('version\x20name\x20\x22'+_0x3d3ecc+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x55631f['join']('\x20'));return;}st(new Fe(_0x1025d3+'-version',()=>({'library':_0x1025d3,'version':_0x3d3ecc}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x37bddb,_0xd05483)=>{switch(_0xd05483){case 0x0:try{_0x37bddb['createObjectStore'](Ot);}catch(_0x4c7bdf){console['warn'](_0x4c7bdf);}}}})['catch'](_0x4f6beb=>{throw me['create']('idb-open',{'originalErrorMessage':_0x4f6beb['message']});})),ri;}async function Al(_0x12af6d){try{const _0x5e3e49=(await eo())['transaction'](Ot),_0x449a81=await _0x5e3e49['objectStore'](Ot)['get'](to(_0x12af6d));return await _0x5e3e49['done'],_0x449a81;}catch(_0x431da5){if(_0x431da5 instanceof Re)oe['warn'](_0x431da5['message']);else{const _0x1d95a1=me['create']('idb-get',{'originalErrorMessage':_0x431da5==null?void 0x0:_0x431da5['message']});oe['warn'](_0x1d95a1['message']);}}}async function Fs(_0x174730,_0x383a33){try{const _0x544534=(await eo())['transaction'](Ot,'readwrite');await _0x544534['objectStore'](Ot)['put'](_0x383a33,to(_0x174730)),await _0x544534['done'];}catch(_0x354beb){if(_0x354beb instanceof Re)oe['warn'](_0x354beb['message']);else{const _0x348802=me['create']('idb-set',{'originalErrorMessage':_0x354beb==null?void 0x0:_0x354beb['message']});oe['warn'](_0x348802['message']);}}}function to(_0x238ada){return _0x238ada['name']+'!'+_0x238ada['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x561993){this['container']=_0x561993,this['_heartbeatsCache']=null;const _0x451722=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x451722),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x47a455=>(this['_heartbeatsCache']=_0x47a455,_0x47a455));}async['triggerHeartbeat'](){var _0xf5f97f,_0x453f6a;try{const _0x49efbf=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2fb2cc=Us();if(((_0xf5f97f=this['_heartbeatsCache'])==null?void 0x0:_0xf5f97f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x453f6a=this['_heartbeatsCache'])==null?void 0x0:_0x453f6a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2fb2cc||this['_heartbeatsCache']['heartbeats']['some'](_0x500dd1=>_0x500dd1['date']===_0x2fb2cc))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2fb2cc,'agent':_0x49efbf}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x37f8f9=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x37f8f9,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4bfbf1){oe['warn'](_0x4bfbf1);}}async['getHeartbeatsHeader'](){var _0x1ff0d6;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1ff0d6=this['_heartbeatsCache'])==null?void 0x0:_0x1ff0d6['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x42893f=Us(),{heartbeatsToSend:_0x41dd51,unsentEntries:_0xf440da}=Ol(this['_heartbeatsCache']['heartbeats']),_0x596fae=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x41dd51}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x42893f,_0xf440da['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xf440da,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x596fae;}catch(_0x1d4a10){return oe['warn'](_0x1d4a10),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5debac,_0x59fc64=kl){const _0x3fc9be=[];let _0x54baf9=_0x5debac['slice']();for(const _0x59ce0c of _0x5debac){const _0x13816c=_0x3fc9be['find'](_0x1333e8=>_0x1333e8['agent']===_0x59ce0c['agent']);if(_0x13816c){if(_0x13816c['dates']['push'](_0x59ce0c['date']),Ws(_0x3fc9be)>_0x59fc64){_0x13816c['dates']['pop']();break;}}else{if(_0x3fc9be['push']({'agent':_0x59ce0c['agent'],'dates':[_0x59ce0c['date']]}),Ws(_0x3fc9be)>_0x59fc64){_0x3fc9be['pop']();break;}}_0x54baf9=_0x54baf9['slice'](0x1);}return{'heartbeatsToSend':_0x3fc9be,'unsentEntries':_0x54baf9};}class Dl{constructor(_0x5905c5){this['app']=_0x5905c5,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5d6a2e=await Al(this['app']);return _0x5d6a2e!=null&&_0x5d6a2e['heartbeats']?_0x5d6a2e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0xc9478f){if(await this['_canUseIndexedDBPromise']){const _0x52e2dd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xc9478f['lastSentHeartbeatDate']??_0x52e2dd['lastSentHeartbeatDate'],'heartbeats':_0xc9478f['heartbeats']});}else return;}async['add'](_0xa89673){if(await this['_canUseIndexedDBPromise']){const _0x46d3ff=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xa89673['lastSentHeartbeatDate']??_0x46d3ff['lastSentHeartbeatDate'],'heartbeats':[..._0x46d3ff['heartbeats'],..._0xa89673['heartbeats']]});}else return;}}function Ws(_0x1da791){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1da791}))['length'];}function Ml(_0x397de7){if(_0x397de7['length']===0x0)return-0x1;let _0x31ad54=0x0,_0x4af425=_0x397de7[0x0]['date'];for(let _0x5d2c00=0x1;_0x5d2c00<_0x397de7['length'];_0x5d2c00++)_0x397de7[_0x5d2c00]['date']<_0x4af425&&(_0x4af425=_0x397de7[_0x5d2c00]['date'],_0x31ad54=_0x5d2c00);return _0x31ad54;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0xce8d87){st(new Fe('platform-logger',_0x1029f0=>new jc(_0x1029f0),'PRIVATE')),st(new Fe('heartbeat',_0x7b462a=>new Nl(_0x7b462a),'PRIVATE')),ye(mi,Ls,_0xce8d87),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x387b3){no=_0x387b3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x36aa83){this['domStorage_']=_0x36aa83,this['prefix_']='firebase:';}['set'](_0xffd1ab,_0x1e3907){_0x1e3907==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xffd1ab)):this['domStorage_']['setItem'](this['prefixedName_'](_0xffd1ab),O(_0x1e3907));}['get'](_0x5c5b0f){const _0x27f75c=this['domStorage_']['getItem'](this['prefixedName_'](_0x5c5b0f));return _0x27f75c==null?null:Nt(_0x27f75c);}['remove'](_0x3ee7ab){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3ee7ab));}['prefixedName_'](_0x3991d5){return this['prefix_']+_0x3991d5;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x349907,_0x12adee){_0x12adee==null?delete this['cache_'][_0x349907]:this['cache_'][_0x349907]=_0x12adee;}['get'](_0x21c0b7){return Q(this['cache_'],_0x21c0b7)?this['cache_'][_0x21c0b7]:null;}['remove'](_0x23a344){delete this['cache_'][_0x23a344];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x5c30f8){try{if(typeof window<'u'&&typeof window[_0x5c30f8]<'u'){const _0x2c7fc9=window[_0x5c30f8];return _0x2c7fc9['setItem']('firebase:sentinel','cache'),_0x2c7fc9['removeItem']('firebase:sentinel'),new Wl(_0x2c7fc9);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x38207f=0x1;return function(){return _0x38207f++;};}()),ro=function(_0x539479){const _0x48c5ff=Rc(_0x539479),_0x36e378=new Cc();_0x36e378['update'](_0x48c5ff);const _0x483f84=_0x36e378['digest']();return Fi['encodeByteArray'](_0x483f84);},zt=function(..._0x3809f5){let _0x42608c='';for(let _0x109e4e=0x0;_0x109e4e<_0x3809f5['length'];_0x109e4e++){const _0xd294ac=_0x3809f5[_0x109e4e];Array['isArray'](_0xd294ac)||_0xd294ac&&typeof _0xd294ac=='object'&&typeof _0xd294ac['length']=='number'?_0x42608c+=zt['apply'](null,_0xd294ac):typeof _0xd294ac=='object'?_0x42608c+=O(_0xd294ac):_0x42608c+=_0xd294ac,_0x42608c+='\x20';}return _0x42608c;};let St=null,$s=!0x0;const Hl=function(_0xa3eab4,_0x5698c0){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x15836b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x22b5dc=zt['apply'](null,_0x15836b);St(_0x22b5dc);}},jt=function(_0x53dcb9){return function(..._0x40d151){L(_0x53dcb9,..._0x40d151);};},Ii=function(..._0x597d1d){const _0x177e8f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x597d1d);Ze['error'](_0x177e8f);},ae=function(..._0x136675){const _0xf7ed65='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x136675);throw Ze['error'](_0xf7ed65),new Error(_0xf7ed65);},U=function(..._0x4ad5b5){const _0x23a5b9='FIREBASE\x20WARNING:\x20'+zt(..._0x4ad5b5);Ze['warn'](_0x23a5b9);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2ef0e0){return typeof _0x2ef0e0=='number'&&(_0x2ef0e0!==_0x2ef0e0||_0x2ef0e0===Number['POSITIVE_INFINITY']||_0x2ef0e0===Number['NEGATIVE_INFINITY']);},Gl=function(_0x51c8cc){if(document['readyState']==='complete')_0x51c8cc();else{let _0x453831=!0x1;const _0x159c99=function(){if(!document['body']){setTimeout(_0x159c99,Math['floor'](0xa));return;}_0x453831||(_0x453831=!0x0,_0x51c8cc());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x159c99,!0x1),window['addEventListener']('load',_0x159c99,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x159c99();}),window['attachEvent']('onload',_0x159c99));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4bd9c3,_0x27e78e){if(_0x4bd9c3===_0x27e78e)return 0x0;if(_0x4bd9c3===We||_0x27e78e===we)return-0x1;if(_0x27e78e===We||_0x4bd9c3===we)return 0x1;{const _0x470a68=Gs(_0x4bd9c3),_0x5b2a9d=Gs(_0x27e78e);return _0x470a68!==null?_0x5b2a9d!==null?_0x470a68-_0x5b2a9d===0x0?_0x4bd9c3['length']-_0x27e78e['length']:_0x470a68-_0x5b2a9d:-0x1:_0x5b2a9d!==null?0x1:_0x4bd9c3<_0x27e78e?-0x1:0x1;}},ql=function(_0x2c8093,_0x4f1381){return _0x2c8093===_0x4f1381?0x0:_0x2c8093<_0x4f1381?-0x1:0x1;},vt=function(_0x26e809,_0x388eda){if(_0x388eda&&_0x26e809 in _0x388eda)return _0x388eda[_0x26e809];throw new Error('Missing\x20required\x20key\x20('+_0x26e809+')\x20in\x20object:\x20'+O(_0x388eda));},$i=function(_0x432cdd){if(typeof _0x432cdd!='object'||_0x432cdd===null)return O(_0x432cdd);const _0x25ccea=[];for(const _0x39da2e in _0x432cdd)_0x25ccea['push'](_0x39da2e);_0x25ccea['sort']();let _0x40ee96='{';for(let _0x453c3f=0x0;_0x453c3f<_0x25ccea['length'];_0x453c3f++)_0x453c3f!==0x0&&(_0x40ee96+=','),_0x40ee96+=O(_0x25ccea[_0x453c3f]),_0x40ee96+=':',_0x40ee96+=$i(_0x432cdd[_0x25ccea[_0x453c3f]]);return _0x40ee96+='}',_0x40ee96;},oo=function(_0x469d67,_0x203c63){const _0x13a9b0=_0x469d67['length'];if(_0x13a9b0<=_0x203c63)return[_0x469d67];const _0x21fdde=[];for(let _0x40af86=0x0;_0x40af86<_0x13a9b0;_0x40af86+=_0x203c63)_0x40af86+_0x203c63>_0x13a9b0?_0x21fdde['push'](_0x469d67['substring'](_0x40af86,_0x13a9b0)):_0x21fdde['push'](_0x469d67['substring'](_0x40af86,_0x40af86+_0x203c63));return _0x21fdde;};function x(_0x20e459,_0x438aeb){for(const _0x4386f8 in _0x20e459)_0x20e459['hasOwnProperty'](_0x4386f8)&&_0x438aeb(_0x4386f8,_0x20e459[_0x4386f8]);}const ao=function(_0x22c11c){f(!xn(_0x22c11c),'Invalid\x20JSON\x20number');const _0xa2703=0xb,_0x46f0cf=0x34,_0x131ec5=(0x1<<_0xa2703-0x1)-0x1;let _0x1d2233,_0x1c096e,_0x5e2d20,_0x4e5453,_0x541f8f;_0x22c11c===0x0?(_0x1c096e=0x0,_0x5e2d20=0x0,_0x1d2233=0x1/_0x22c11c===-0x1/0x0?0x1:0x0):(_0x1d2233=_0x22c11c<0x0,_0x22c11c=Math['abs'](_0x22c11c),_0x22c11c>=Math['pow'](0x2,0x1-_0x131ec5)?(_0x4e5453=Math['min'](Math['floor'](Math['log'](_0x22c11c)/Math['LN2']),_0x131ec5),_0x1c096e=_0x4e5453+_0x131ec5,_0x5e2d20=Math['round'](_0x22c11c*Math['pow'](0x2,_0x46f0cf-_0x4e5453)-Math['pow'](0x2,_0x46f0cf))):(_0x1c096e=0x0,_0x5e2d20=Math['round'](_0x22c11c/Math['pow'](0x2,0x1-_0x131ec5-_0x46f0cf))));const _0x591115=[];for(_0x541f8f=_0x46f0cf;_0x541f8f;_0x541f8f-=0x1)_0x591115['push'](_0x5e2d20%0x2?0x1:0x0),_0x5e2d20=Math['floor'](_0x5e2d20/0x2);for(_0x541f8f=_0xa2703;_0x541f8f;_0x541f8f-=0x1)_0x591115['push'](_0x1c096e%0x2?0x1:0x0),_0x1c096e=Math['floor'](_0x1c096e/0x2);_0x591115['push'](_0x1d2233?0x1:0x0),_0x591115['reverse']();const _0x1dee1b=_0x591115['join']('');let _0x1d891f='';for(_0x541f8f=0x0;_0x541f8f<0x40;_0x541f8f+=0x8){let _0xf97f72=parseInt(_0x1dee1b['substr'](_0x541f8f,0x8),0x2)['toString'](0x10);_0xf97f72['length']===0x1&&(_0xf97f72='0'+_0xf97f72),_0x1d891f=_0x1d891f+_0xf97f72;}return _0x1d891f['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x371790,_0x271fcc){let _0x3eeeb0='Unknown\x20Error';_0x371790==='too_big'?_0x3eeeb0='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x371790==='permission_denied'?_0x3eeeb0='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x371790==='unavailable'&&(_0x3eeeb0='The\x20service\x20is\x20unavailable');const _0x417e06=new Error(_0x371790+'\x20at\x20'+_0x271fcc['_path']['toString']()+':\x20'+_0x3eeeb0);return _0x417e06['code']=_0x371790['toUpperCase'](),_0x417e06;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x1800ef){if(Yl['test'](_0x1800ef)){const _0x59f43a=Number(_0x1800ef);if(_0x59f43a>=Ql&&_0x59f43a<=Jl)return _0x59f43a;}return null;},ft=function(_0x1951fe){try{_0x1951fe();}catch(_0x92267c){setTimeout(()=>{const _0x147be6=_0x92267c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x147be6),_0x92267c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x320082,_0x50085f){const _0x3a9f72=setTimeout(_0x320082,_0x50085f);return typeof _0x3a9f72=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3a9f72):typeof _0x3a9f72=='object'&&_0x3a9f72['unref']&&_0x3a9f72['unref'](),_0x3a9f72;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x25719b,_0x15e590){this['appCheckProvider']=_0x15e590,this['appName']=_0x25719b['name'],$(_0x25719b)&&_0x25719b['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x25719b['settings']['appCheckToken']),this['appCheck']=_0x15e590==null?void 0x0:_0x15e590['getImmediate']({'optional':!0x0}),this['appCheck']||_0x15e590==null||_0x15e590['get']()['then'](_0x553353=>this['appCheck']=_0x553353);}['getToken'](_0x2fa4b2){if(this['serverAppAppCheckToken']){if(_0x2fa4b2)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2fa4b2):new Promise((_0x184809,_0x3dd3d4)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2fa4b2)['then'](_0x184809,_0x3dd3d4):_0x184809(null);},0x0);});}['addTokenChangeListener'](_0xe6fef5){var _0x341148;(_0x341148=this['appCheckProvider'])==null||_0x341148['get']()['then'](_0x4c9b2a=>_0x4c9b2a['addTokenListener'](_0xe6fef5));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x48abb0,_0x2a5879,_0x2f7ac7){this['appName_']=_0x48abb0,this['firebaseOptions_']=_0x2a5879,this['authProvider_']=_0x2f7ac7,this['auth_']=null,this['auth_']=_0x2f7ac7['getImmediate']({'optional':!0x0}),this['auth_']||_0x2f7ac7['onInit'](_0x1ce596=>this['auth_']=_0x1ce596);}['getToken'](_0x4daf0a){return this['auth_']?this['auth_']['getToken'](_0x4daf0a)['catch'](_0x2413d6=>_0x2413d6&&_0x2413d6['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2413d6)):new Promise((_0x3759e5,_0x2f8a9f)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4daf0a)['then'](_0x3759e5,_0x2f8a9f):_0x3759e5(null);},0x0);});}['addTokenChangeListener'](_0x3cbee5){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3cbee5):this['authProvider_']['get']()['then'](_0x444685=>_0x444685['addAuthTokenListener'](_0x3cbee5));}['removeTokenChangeListener'](_0x9425b7){this['authProvider_']['get']()['then'](_0x1f5395=>_0x1f5395['removeAuthTokenListener'](_0x9425b7));}['notifyForInvalidToken'](){let _0x140339='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x140339+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x140339+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x140339+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x140339);}}class an{constructor(_0x3ad34f){this['accessToken']=_0x3ad34f;}['getToken'](_0x374d0e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2af458){_0x2af458(this['accessToken']);}['removeTokenChangeListener'](_0x3ac24e){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x14aaea,_0x34a3db,_0x38fb05,_0x2ee02d,_0xd15082=!0x1,_0x20048e='',_0x1976d7=!0x1,_0x37be43=!0x1,_0x17cae4=null){this['secure']=_0x34a3db,this['namespace']=_0x38fb05,this['webSocketOnly']=_0x2ee02d,this['nodeAdmin']=_0xd15082,this['persistenceKey']=_0x20048e,this['includeNamespaceInQueryParams']=_0x1976d7,this['isUsingEmulator']=_0x37be43,this['emulatorOptions']=_0x17cae4,this['_host']=_0x14aaea['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x14aaea)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x48ceeb){_0x48ceeb!==this['internalHost']&&(this['internalHost']=_0x48ceeb,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x22dc26=this['toURLString']();return this['persistenceKey']&&(_0x22dc26+='<'+this['persistenceKey']+'>'),_0x22dc26;}['toURLString'](){const _0x37ef75=this['secure']?'https://':'http://',_0x3d401b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x37ef75+this['host']+'/'+_0x3d401b;}}function th(_0x159268){return _0x159268['host']!==_0x159268['internalHost']||_0x159268['isCustomHost']()||_0x159268['includeNamespaceInQueryParams'];}function vo(_0xc76a08,_0x1a58f9,_0x252d20){f(typeof _0x1a58f9=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x252d20=='object','typeof\x20params\x20must\x20==\x20object');let _0x80cb9f;if(_0x1a58f9===go)_0x80cb9f=(_0xc76a08['secure']?'wss://':'ws://')+_0xc76a08['internalHost']+'/.ws?';else{if(_0x1a58f9===mo)_0x80cb9f=(_0xc76a08['secure']?'https://':'http://')+_0xc76a08['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1a58f9);}th(_0xc76a08)&&(_0x252d20['ns']=_0xc76a08['namespace']);const _0x49eaf6=[];return x(_0x252d20,(_0x1d697a,_0x2f91db)=>{_0x49eaf6['push'](_0x1d697a+'='+_0x2f91db);}),_0x80cb9f+_0x49eaf6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4fdb42,_0x146fa0=0x1){Q(this['counters_'],_0x4fdb42)||(this['counters_'][_0x4fdb42]=0x0),this['counters_'][_0x4fdb42]+=_0x146fa0;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x53efca){const _0x267206=_0x53efca['toString']();return oi[_0x267206]||(oi[_0x267206]=new nh()),oi[_0x267206];}function ih(_0x5f18c0,_0x2c7690){const _0x4c38be=_0x5f18c0['toString']();return ai[_0x4c38be]||(ai[_0x4c38be]=_0x2c7690()),ai[_0x4c38be];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x1e0d27){this['onMessage_']=_0x1e0d27,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4ebb55,_0x4edfeb){this['closeAfterResponse']=_0x4ebb55,this['onClose']=_0x4edfeb,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4cf323,_0xb75fbf){for(this['pendingResponses'][_0x4cf323]=_0xb75fbf;this['pendingResponses'][this['currentResponseNum']];){const _0x7c3d98=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x474837=0x0;_0x474837<_0x7c3d98['length'];++_0x474837)_0x7c3d98[_0x474837]&&ft(()=>{this['onMessage_'](_0x7c3d98[_0x474837]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x55c7df,_0xacd136,_0x28422f,_0x32a4b6,_0x582e63,_0x12b09c,_0x1dd7d5){this['connId']=_0x55c7df,this['repoInfo']=_0xacd136,this['applicationId']=_0x28422f,this['appCheckToken']=_0x32a4b6,this['authToken']=_0x582e63,this['transportSessionId']=_0x12b09c,this['lastSessionId']=_0x1dd7d5,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x55c7df),this['stats_']=qi(_0xacd136),this['urlFn']=_0x5d2454=>(this['appCheckToken']&&(_0x5d2454[wi]=this['appCheckToken']),vo(_0xacd136,mo,_0x5d2454));}['open'](_0x2bf790,_0x387955){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x387955,this['myPacketOrderer']=new sh(_0x2bf790),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4c409a)=>{const [_0xb13cf,_0x5d0c24,_0x5d8789,_0x5201e8,_0x3ec71c]=_0x4c409a;if(this['incrementIncomingBytes_'](_0x4c409a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0xb13cf===qs)this['id']=_0x5d0c24,this['password']=_0x5d8789;else{if(_0xb13cf===rh)_0x5d0c24?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5d0c24,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0xb13cf);}}},(..._0x499ccd)=>{const [_0x46d89b,_0x350a19]=_0x499ccd;this['incrementIncomingBytes_'](_0x499ccd),this['myPacketOrderer']['handleResponse'](_0x46d89b,_0x350a19);},()=>{this['onClosed_']();},this['urlFn']);const _0x1b5dc7={};_0x1b5dc7[qs]='t',_0x1b5dc7[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1b5dc7[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1b5dc7[co]=Gi,this['transportSessionId']&&(_0x1b5dc7[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1b5dc7[po]=this['lastSessionId']),this['applicationId']&&(_0x1b5dc7[_o]=this['applicationId']),this['appCheckToken']&&(_0x1b5dc7[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1b5dc7[ho]=uo);const _0xb1e07a=this['urlFn'](_0x1b5dc7);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xb1e07a),this['scriptTagHolder']['addTag'](_0xb1e07a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x249d4f){const _0x1e2b56=O(_0x249d4f);this['bytesSent']+=_0x1e2b56['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1e2b56['length']);const _0x26349d=$r(_0x1e2b56),_0x1bcb03=oo(_0x26349d,fh);for(let _0x48f401=0x0;_0x48f401<_0x1bcb03['length'];_0x48f401++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1bcb03['length'],_0x1bcb03[_0x48f401]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x78afb,_0x560aa8){this['myDisconnFrame']=document['createElement']('iframe');const _0x419658={};_0x419658[dh]='t',_0x419658[Eo]=_0x78afb,_0x419658[Io]=_0x560aa8,this['myDisconnFrame']['src']=this['urlFn'](_0x419658),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x542844){const _0x228773=O(_0x542844)['length'];this['bytesReceived']+=_0x228773,this['stats_']['incrementCounter']('bytes_received',_0x228773);}}class zi{constructor(_0x2b361d,_0x581d5b,_0x3aecf9,_0x263e22){this['onDisconnect']=_0x3aecf9,this['urlFn']=_0x263e22,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2b361d,window[ah+this['uniqueCallbackIdentifier']]=_0x581d5b,this['myIFrame']=zi['createIFrame_']();let _0x144fbf='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x144fbf='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x136f7b='<html><body>'+_0x144fbf+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x136f7b),this['myIFrame']['doc']['close']();}catch(_0x4306e0){L('frame\x20writing\x20exception'),_0x4306e0['stack']&&L(_0x4306e0['stack']),L(_0x4306e0);}}}static['createIFrame_'](){const _0x3e3625=document['createElement']('iframe');if(_0x3e3625['style']['display']='none',document['body']){document['body']['appendChild'](_0x3e3625);try{_0x3e3625['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x590f84=document['domain'];_0x3e3625['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x590f84+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3e3625['contentDocument']?_0x3e3625['doc']=_0x3e3625['contentDocument']:_0x3e3625['contentWindow']?_0x3e3625['doc']=_0x3e3625['contentWindow']['document']:_0x3e3625['document']&&(_0x3e3625['doc']=_0x3e3625['document']),_0x3e3625;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2e6466=this['onDisconnect'];_0x2e6466&&(this['onDisconnect']=null,_0x2e6466());}['startLongPoll'](_0x3c1ec5,_0x418d8f){for(this['myID']=_0x3c1ec5,this['myPW']=_0x418d8f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3a8924={};_0x3a8924[Eo]=this['myID'],_0x3a8924[Io]=this['myPW'],_0x3a8924[wo]=this['currentSerial'];let _0x27b825=this['urlFn'](_0x3a8924),_0x59c3e1='',_0x467d5b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x59c3e1['length']<=Co;){const _0x19f63e=this['pendingSegs']['shift']();_0x59c3e1=_0x59c3e1+'&'+lh+_0x467d5b+'='+_0x19f63e['seg']+'&'+hh+_0x467d5b+'='+_0x19f63e['ts']+'&'+uh+_0x467d5b+'='+_0x19f63e['d'],_0x467d5b++;}return _0x27b825=_0x27b825+_0x59c3e1,this['addLongPollTag_'](_0x27b825,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3408ce,_0x1e6389,_0x5c4e2a){this['pendingSegs']['push']({'seg':_0x3408ce,'ts':_0x1e6389,'d':_0x5c4e2a}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1a4eb0,_0x3abebb){this['outstandingRequests']['add'](_0x3abebb);const _0x6bfbe9=()=>{this['outstandingRequests']['delete'](_0x3abebb),this['newRequest_']();},_0x1548c3=setTimeout(_0x6bfbe9,Math['floor'](ph)),_0x926e6c=()=>{clearTimeout(_0x1548c3),_0x6bfbe9();};this['addTag'](_0x1a4eb0,_0x926e6c);}['addTag'](_0x548628,_0x3cac65){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x327135=this['myIFrame']['doc']['createElement']('script');_0x327135['type']='text/javascript',_0x327135['async']=!0x0,_0x327135['src']=_0x548628,_0x327135['onload']=_0x327135['onreadystatechange']=function(){const _0x3aa56d=_0x327135['readyState'];(!_0x3aa56d||_0x3aa56d==='loaded'||_0x3aa56d==='complete')&&(_0x327135['onload']=_0x327135['onreadystatechange']=null,_0x327135['parentNode']&&_0x327135['parentNode']['removeChild'](_0x327135),_0x3cac65());},_0x327135['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x548628),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x327135);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x5915d7,_0x299ccd,_0x501440,_0x4ef21f,_0x561ff8,_0x21eebc,_0x311efa){this['connId']=_0x5915d7,this['applicationId']=_0x501440,this['appCheckToken']=_0x4ef21f,this['authToken']=_0x561ff8,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x299ccd),this['connURL']=q['connectionURL_'](_0x299ccd,_0x21eebc,_0x311efa,_0x4ef21f,_0x501440),this['nodeAdmin']=_0x299ccd['nodeAdmin'];}static['connectionURL_'](_0x18266a,_0x1a05c8,_0x2980ef,_0x570456,_0x318da0){const _0xd604a={};return _0xd604a[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xd604a[ho]=uo),_0x1a05c8&&(_0xd604a[lo]=_0x1a05c8),_0x2980ef&&(_0xd604a[po]=_0x2980ef),_0x570456&&(_0xd604a[wi]=_0x570456),_0x318da0&&(_0xd604a[_o]=_0x318da0),vo(_0x18266a,go,_0xd604a);}['open'](_0x27c9fe,_0x14b0ca){this['onDisconnect']=_0x14b0ca,this['onMessage']=_0x27c9fe,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x804db3;_c(),this['mySock']=new gn(this['connURL'],[],_0x804db3);}catch(_0x533857){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3eefdf=_0x533857['message']||_0x533857['data'];_0x3eefdf&&this['log_'](_0x3eefdf),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2d765c=>{this['handleIncomingFrame'](_0x2d765c);},this['mySock']['onerror']=_0x5de155=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x49d4dc=_0x5de155['message']||_0x5de155['data'];_0x49d4dc&&this['log_'](_0x49d4dc),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3813df=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5160c5=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5d2ad3=navigator['userAgent']['match'](_0x5160c5);_0x5d2ad3&&_0x5d2ad3['length']>0x1&&parseFloat(_0x5d2ad3[0x1])<4.4&&(_0x3813df=!0x0);}return!_0x3813df&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x1ad904){if(this['frames']['push'](_0x1ad904),this['frames']['length']===this['totalFrames']){const _0x4741da=this['frames']['join']('');this['frames']=null;const _0x34a2fc=Nt(_0x4741da);this['onMessage'](_0x34a2fc);}}['handleNewFrameCount_'](_0x2587be){this['totalFrames']=_0x2587be,this['frames']=[];}['extractFrameCount_'](_0x1d20bc){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1d20bc['length']<=0x6){const _0x590c8f=Number(_0x1d20bc);if(!isNaN(_0x590c8f))return this['handleNewFrameCount_'](_0x590c8f),null;}return this['handleNewFrameCount_'](0x1),_0x1d20bc;}['handleIncomingFrame'](_0x2379ad){if(this['mySock']===null)return;const _0x339cd4=_0x2379ad['data'];if(this['bytesReceived']+=_0x339cd4['length'],this['stats_']['incrementCounter']('bytes_received',_0x339cd4['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x339cd4);else{const _0x2a532e=this['extractFrameCount_'](_0x339cd4);_0x2a532e!==null&&this['appendFrame_'](_0x2a532e);}}['send'](_0x59588c){this['resetKeepAlive']();const _0x4506cc=O(_0x59588c);this['bytesSent']+=_0x4506cc['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4506cc['length']);const _0x458e0a=oo(_0x4506cc,gh);_0x458e0a['length']>0x1&&this['sendString_'](String(_0x458e0a['length']));for(let _0x1f72c4=0x0;_0x1f72c4<_0x458e0a['length'];_0x1f72c4++)this['sendString_'](_0x458e0a[_0x1f72c4]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xfdebe2){try{this['mySock']['send'](_0xfdebe2);}catch(_0x4da588){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4da588['message']||_0x4da588['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5478b2){this['initTransports_'](_0x5478b2);}['initTransports_'](_0x4ae637){const _0x335aef=q&&q['isAvailable']();let _0x47c6ad=_0x335aef&&!q['previouslyFailed']();if(_0x4ae637['webSocketOnly']&&(_0x335aef||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x47c6ad=!0x0),_0x47c6ad)this['transports_']=[q];else{const _0x1d4a14=this['transports_']=[];for(const _0x33aa39 of Dt['ALL_TRANSPORTS'])_0x33aa39&&_0x33aa39['isAvailable']()&&_0x1d4a14['push'](_0x33aa39);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0xf5ee25,_0x10812e,_0xa67ae7,_0x12d730,_0x598b6a,_0x59e6c8,_0x45d943,_0x15a7e9,_0x426cfa,_0x425ce6){this['id']=_0xf5ee25,this['repoInfo_']=_0x10812e,this['applicationId_']=_0xa67ae7,this['appCheckToken_']=_0x12d730,this['authToken_']=_0x598b6a,this['onMessage_']=_0x59e6c8,this['onReady_']=_0x45d943,this['onDisconnect_']=_0x15a7e9,this['onKill_']=_0x426cfa,this['lastSessionId']=_0x425ce6,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x10812e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x24ccb7=this['transportManager_']['initialTransport']();this['conn_']=new _0x24ccb7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x24ccb7['responsesRequiredToBeHealthy']||0x0;const _0xfd2fee=this['connReceiver_'](this['conn_']),_0x47d74b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xfd2fee,_0x47d74b);},Math['floor'](0x0));const _0xfa87b=_0x24ccb7['healthyTimeout']||0x0;_0xfa87b>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xfa87b)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1e5e69){return _0x38aba4=>{_0x1e5e69===this['conn_']?this['onConnectionLost_'](_0x38aba4):_0x1e5e69===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2ca271){return _0xd8b8b7=>{this['state_']!==0x2&&(_0x2ca271===this['rx_']?this['onPrimaryMessageReceived_'](_0xd8b8b7):_0x2ca271===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xd8b8b7):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1a2ae2){const _0x5d1d1b={'t':'d','d':_0x1a2ae2};this['sendData_'](_0x5d1d1b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4f385a){if(ci in _0x4f385a){const _0xc4c2ac=_0x4f385a[ci];_0xc4c2ac===Ys?this['upgradeIfSecondaryHealthy_']():_0xc4c2ac===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xc4c2ac===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1c1eac){const _0x1268e8=vt('t',_0x1c1eac),_0x5df147=vt('d',_0x1c1eac);if(_0x1268e8==='c')this['onSecondaryControl_'](_0x5df147);else{if(_0x1268e8==='d')this['pendingDataMessages']['push'](_0x5df147);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1268e8);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x21b45e){const _0x3cd9a8=vt('t',_0x21b45e),_0x1dde08=vt('d',_0x21b45e);_0x3cd9a8==='c'?this['onControl_'](_0x1dde08):_0x3cd9a8==='d'&&this['onDataMessage_'](_0x1dde08);}['onDataMessage_'](_0x534a90){this['onPrimaryResponse_'](),this['onMessage_'](_0x534a90);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1e753d){const _0x27bb4a=vt(ci,_0x1e753d);if(zs in _0x1e753d){const _0xa1d6a4=_0x1e753d[zs];if(_0x27bb4a===Th){const _0x1bbda5={..._0xa1d6a4};this['repoInfo_']['isUsingEmulator']&&(_0x1bbda5['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1bbda5);}else{if(_0x27bb4a===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x41eeb2=0x0;_0x41eeb2<this['pendingDataMessages']['length'];++_0x41eeb2)this['onDataMessage_'](this['pendingDataMessages'][_0x41eeb2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x27bb4a===wh?this['onConnectionShutdown_'](_0xa1d6a4):_0x27bb4a===js?this['onReset_'](_0xa1d6a4):_0x27bb4a===Ch?Ii('Server\x20Error:\x20'+_0xa1d6a4):_0x27bb4a===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x27bb4a);}}}['onHandshake_'](_0x4138a2){const _0x537b7e=_0x4138a2['ts'],_0x205d2c=_0x4138a2['v'],_0x4e6239=_0x4138a2['h'];this['sessionId']=_0x4138a2['s'],this['repoInfo_']['host']=_0x4e6239,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x537b7e),Gi!==_0x205d2c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5cac51=this['transportManager_']['upgradeTransport']();_0x5cac51&&this['startUpgrade_'](_0x5cac51);}['startUpgrade_'](_0x5d4553){this['secondaryConn_']=new _0x5d4553(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5d4553['responsesRequiredToBeHealthy']||0x0;const _0x3eda86=this['connReceiver_'](this['secondaryConn_']),_0x345d67=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3eda86,_0x345d67),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x18366b){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x18366b),this['repoInfo_']['host']=_0x18366b,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x7c03c1,_0xe1f28a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x7c03c1,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xe1f28a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5841e3=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5841e3||this['rx_']===_0x5841e3)&&this['close']();}['onConnectionLost_'](_0xe5cb0e){this['conn_']=null,!_0xe5cb0e&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x31a7db){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x31a7db),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1d58d1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1d58d1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4c039d,_0x178c37,_0x5410c8,_0x4ddd74){}['merge'](_0x5cf206,_0x2b5f54,_0x2e1439,_0x23a50c){}['refreshAuthToken'](_0x2ad865){}['refreshAppCheckToken'](_0x1691df){}['onDisconnectPut'](_0x14688e,_0x298fec,_0x345aeb){}['onDisconnectMerge'](_0x8f718b,_0x162760,_0x250dfe){}['onDisconnectCancel'](_0x117fc7,_0x26cffc){}['reportStats'](_0x2e151e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x26cdbf){this['allowedEvents_']=_0x26cdbf,this['listeners_']={},f(Array['isArray'](_0x26cdbf)&&_0x26cdbf['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x59e391,..._0x58f273){if(Array['isArray'](this['listeners_'][_0x59e391])){const _0x55806f=[...this['listeners_'][_0x59e391]];for(let _0x3aa67f=0x0;_0x3aa67f<_0x55806f['length'];_0x3aa67f++)_0x55806f[_0x3aa67f]['callback']['apply'](_0x55806f[_0x3aa67f]['context'],_0x58f273);}}['on'](_0x138ced,_0x8c434,_0x31ae44){this['validateEventType_'](_0x138ced),this['listeners_'][_0x138ced]=this['listeners_'][_0x138ced]||[],this['listeners_'][_0x138ced]['push']({'callback':_0x8c434,'context':_0x31ae44});const _0x314dc2=this['getInitialEvent'](_0x138ced);_0x314dc2&&_0x8c434['apply'](_0x31ae44,_0x314dc2);}['off'](_0x9ebb85,_0x5985c0,_0x1c882a){this['validateEventType_'](_0x9ebb85);const _0x148ddc=this['listeners_'][_0x9ebb85]||[];for(let _0x403395=0x0;_0x403395<_0x148ddc['length'];_0x403395++)if(_0x148ddc[_0x403395]['callback']===_0x5985c0&&(!_0x1c882a||_0x1c882a===_0x148ddc[_0x403395]['context'])){_0x148ddc['splice'](_0x403395,0x1);return;}}['validateEventType_'](_0x4c1773){f(this['allowedEvents_']['find'](_0x1a2f1e=>_0x1a2f1e===_0x4c1773),'Unknown\x20event:\x20'+_0x4c1773);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4b328c){return f(_0x4b328c==='online','Unknown\x20event\x20type:\x20'+_0x4b328c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2db375,_0x448733){if(_0x448733===void 0x0){this['pieces_']=_0x2db375['split']('/');let _0x4a35a1=0x0;for(let _0x2c0ff9=0x0;_0x2c0ff9<this['pieces_']['length'];_0x2c0ff9++)this['pieces_'][_0x2c0ff9]['length']>0x0&&(this['pieces_'][_0x4a35a1]=this['pieces_'][_0x2c0ff9],_0x4a35a1++);this['pieces_']['length']=_0x4a35a1,this['pieceNum_']=0x0;}else this['pieces_']=_0x2db375,this['pieceNum_']=_0x448733;}['toString'](){let _0x4af69c='';for(let _0x1da889=this['pieceNum_'];_0x1da889<this['pieces_']['length'];_0x1da889++)this['pieces_'][_0x1da889]!==''&&(_0x4af69c+='/'+this['pieces_'][_0x1da889]);return _0x4af69c||'/';}}function w(){return new C('');}function y(_0x53c598){return _0x53c598['pieceNum_']>=_0x53c598['pieces_']['length']?null:_0x53c598['pieces_'][_0x53c598['pieceNum_']];}function Ce(_0x5a2f32){return _0x5a2f32['pieces_']['length']-_0x5a2f32['pieceNum_'];}function S(_0xe630c6){let _0x15d64b=_0xe630c6['pieceNum_'];return _0x15d64b<_0xe630c6['pieces_']['length']&&_0x15d64b++,new C(_0xe630c6['pieces_'],_0x15d64b);}function ji(_0x53bec2){return _0x53bec2['pieceNum_']<_0x53bec2['pieces_']['length']?_0x53bec2['pieces_'][_0x53bec2['pieces_']['length']-0x1]:null;}function bh(_0xc98e95){let _0x4c8348='';for(let _0x5791bf=_0xc98e95['pieceNum_'];_0x5791bf<_0xc98e95['pieces_']['length'];_0x5791bf++)_0xc98e95['pieces_'][_0x5791bf]!==''&&(_0x4c8348+='/'+encodeURIComponent(String(_0xc98e95['pieces_'][_0x5791bf])));return _0x4c8348||'/';}function Mt(_0x301102,_0x38b3d3=0x0){return _0x301102['pieces_']['slice'](_0x301102['pieceNum_']+_0x38b3d3);}function Ro(_0x3038e7){if(_0x3038e7['pieceNum_']>=_0x3038e7['pieces_']['length'])return null;const _0x2c00aa=[];for(let _0x259a66=_0x3038e7['pieceNum_'];_0x259a66<_0x3038e7['pieces_']['length']-0x1;_0x259a66++)_0x2c00aa['push'](_0x3038e7['pieces_'][_0x259a66]);return new C(_0x2c00aa,0x0);}function k(_0x46eca8,_0x1df072){const _0x4c2890=[];for(let _0x49092e=_0x46eca8['pieceNum_'];_0x49092e<_0x46eca8['pieces_']['length'];_0x49092e++)_0x4c2890['push'](_0x46eca8['pieces_'][_0x49092e]);if(_0x1df072 instanceof C){for(let _0x625317=_0x1df072['pieceNum_'];_0x625317<_0x1df072['pieces_']['length'];_0x625317++)_0x4c2890['push'](_0x1df072['pieces_'][_0x625317]);}else{const _0x4c81d7=_0x1df072['split']('/');for(let _0x155eee=0x0;_0x155eee<_0x4c81d7['length'];_0x155eee++)_0x4c81d7[_0x155eee]['length']>0x0&&_0x4c2890['push'](_0x4c81d7[_0x155eee]);}return new C(_0x4c2890,0x0);}function v(_0x3ddd05){return _0x3ddd05['pieceNum_']>=_0x3ddd05['pieces_']['length'];}function F(_0x2b1f07,_0x11c71c){const _0x421898=y(_0x2b1f07),_0x217800=y(_0x11c71c);if(_0x421898===null)return _0x11c71c;if(_0x421898===_0x217800)return F(S(_0x2b1f07),S(_0x11c71c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x11c71c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2b1f07+')');}function Rh(_0x2313d9,_0x195c02){const _0x1180de=Mt(_0x2313d9,0x0),_0x9399f7=Mt(_0x195c02,0x0);for(let _0x3be2d3=0x0;_0x3be2d3<_0x1180de['length']&&_0x3be2d3<_0x9399f7['length'];_0x3be2d3++){const _0x2b9193=qe(_0x1180de[_0x3be2d3],_0x9399f7[_0x3be2d3]);if(_0x2b9193!==0x0)return _0x2b9193;}return _0x1180de['length']===_0x9399f7['length']?0x0:_0x1180de['length']<_0x9399f7['length']?-0x1:0x1;}function Ki(_0x48d49a,_0x57668e){if(Ce(_0x48d49a)!==Ce(_0x57668e))return!0x1;for(let _0x4c6ec3=_0x48d49a['pieceNum_'],_0x275712=_0x57668e['pieceNum_'];_0x4c6ec3<=_0x48d49a['pieces_']['length'];_0x4c6ec3++,_0x275712++)if(_0x48d49a['pieces_'][_0x4c6ec3]!==_0x57668e['pieces_'][_0x275712])return!0x1;return!0x0;}function G(_0x25338d,_0x515eb5){let _0x5be139=_0x25338d['pieceNum_'],_0x1ce35a=_0x515eb5['pieceNum_'];if(Ce(_0x25338d)>Ce(_0x515eb5))return!0x1;for(;_0x5be139<_0x25338d['pieces_']['length'];){if(_0x25338d['pieces_'][_0x5be139]!==_0x515eb5['pieces_'][_0x1ce35a])return!0x1;++_0x5be139,++_0x1ce35a;}return!0x0;}class Ah{constructor(_0x16f987,_0x5e279c){this['errorPrefix_']=_0x5e279c,this['parts_']=Mt(_0x16f987,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x25ece3=0x0;_0x25ece3<this['parts_']['length'];_0x25ece3++)this['byteLength_']+=Ln(this['parts_'][_0x25ece3]);Ao(this);}}function kh(_0x38d498,_0x36a70d){_0x38d498['parts_']['length']>0x0&&(_0x38d498['byteLength_']+=0x1),_0x38d498['parts_']['push'](_0x36a70d),_0x38d498['byteLength_']+=Ln(_0x36a70d),Ao(_0x38d498);}function Ph(_0x427769){const _0x45498b=_0x427769['parts_']['pop']();_0x427769['byteLength_']-=Ln(_0x45498b),_0x427769['parts_']['length']>0x0&&(_0x427769['byteLength_']-=0x1);}function Ao(_0x114c6e){if(_0x114c6e['byteLength_']>Zs)throw new Error(_0x114c6e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x114c6e['byteLength_']+').');if(_0x114c6e['parts_']['length']>Xs)throw new Error(_0x114c6e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x114c6e));}function Oe(_0x3b601c){return _0x3b601c['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3b601c['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x6acb26,_0x41a6ab;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x41a6ab='visibilitychange',_0x6acb26='hidden'):typeof document['mozHidden']<'u'?(_0x41a6ab='mozvisibilitychange',_0x6acb26='mozHidden'):typeof document['msHidden']<'u'?(_0x41a6ab='msvisibilitychange',_0x6acb26='msHidden'):typeof document['webkitHidden']<'u'&&(_0x41a6ab='webkitvisibilitychange',_0x6acb26='webkitHidden')),this['visible_']=!0x0,_0x41a6ab&&document['addEventListener'](_0x41a6ab,()=>{const _0x3bd82b=!document[_0x6acb26];_0x3bd82b!==this['visible_']&&(this['visible_']=_0x3bd82b,this['trigger']('visible',_0x3bd82b));},!0x1);}['getInitialEvent'](_0x3945a0){return f(_0x3945a0==='visible','Unknown\x20event\x20type:\x20'+_0x3945a0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4ec5aa,_0x435ff8,_0x18b398,_0x4bd90e,_0x39700d,_0x5a95d2,_0x4f56b1,_0x5bd8c7){if(super(),this['repoInfo_']=_0x4ec5aa,this['applicationId_']=_0x435ff8,this['onDataUpdate_']=_0x18b398,this['onConnectStatus_']=_0x4bd90e,this['onServerInfoUpdate_']=_0x39700d,this['authTokenProvider_']=_0x5a95d2,this['appCheckTokenProvider_']=_0x4f56b1,this['authOverride_']=_0x5bd8c7,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5bd8c7)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4ec5aa['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x360d11,_0x5c82c8,_0x39266f){const _0x4179b5=++this['requestNumber_'],_0x434f6b={'r':_0x4179b5,'a':_0x360d11,'b':_0x5c82c8};this['log_'](O(_0x434f6b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x434f6b),_0x39266f&&(this['requestCBHash_'][_0x4179b5]=_0x39266f);}['get'](_0x4b2925){this['initConnection_']();const _0x550742=new H(),_0x217db8={'action':'g','request':{'p':_0x4b2925['_path']['toString'](),'q':_0x4b2925['_queryObject']},'onComplete':_0x18613b=>{const _0x3a73ce=_0x18613b['d'];_0x18613b['s']==='ok'?_0x550742['resolve'](_0x3a73ce):_0x550742['reject'](_0x3a73ce);}};this['outstandingGets_']['push'](_0x217db8),this['outstandingGetCount_']++;const _0x5eac00=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5eac00),_0x550742['promise'];}['listen'](_0x89fb4c,_0x49a3b7,_0x5b957b,_0x2a97b9){this['initConnection_']();const _0x2ebee8=_0x89fb4c['_queryIdentifier'],_0x3c5515=_0x89fb4c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3c5515+'\x20'+_0x2ebee8),this['listens']['has'](_0x3c5515)||this['listens']['set'](_0x3c5515,new Map()),f(_0x89fb4c['_queryParams']['isDefault']()||!_0x89fb4c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3c5515)['has'](_0x2ebee8),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x358657={'onComplete':_0x2a97b9,'hashFn':_0x49a3b7,'query':_0x89fb4c,'tag':_0x5b957b};this['listens']['get'](_0x3c5515)['set'](_0x2ebee8,_0x358657),this['connected_']&&this['sendListen_'](_0x358657);}['sendGet_'](_0x7f063b){const _0x28f6e4=this['outstandingGets_'][_0x7f063b];this['sendRequest']('g',_0x28f6e4['request'],_0x38fcea=>{delete this['outstandingGets_'][_0x7f063b],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x28f6e4['onComplete']&&_0x28f6e4['onComplete'](_0x38fcea);});}['sendListen_'](_0x11814a){const _0x2cc253=_0x11814a['query'],_0x648231=_0x2cc253['_path']['toString'](),_0x3af066=_0x2cc253['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x648231+'\x20for\x20'+_0x3af066);const _0x4e3a34={'p':_0x648231},_0x3ae1e3='q';_0x11814a['tag']&&(_0x4e3a34['q']=_0x2cc253['_queryObject'],_0x4e3a34['t']=_0x11814a['tag']),_0x4e3a34['h']=_0x11814a['hashFn'](),this['sendRequest'](_0x3ae1e3,_0x4e3a34,_0x49f631=>{const _0x25d594=_0x49f631['d'],_0x16d676=_0x49f631['s'];se['warnOnListenWarnings_'](_0x25d594,_0x2cc253),(this['listens']['get'](_0x648231)&&this['listens']['get'](_0x648231)['get'](_0x3af066))===_0x11814a&&(this['log_']('listen\x20response',_0x49f631),_0x16d676!=='ok'&&this['removeListen_'](_0x648231,_0x3af066),_0x11814a['onComplete']&&_0x11814a['onComplete'](_0x16d676,_0x25d594));});}static['warnOnListenWarnings_'](_0x53f0a2,_0x5df4fb){if(_0x53f0a2&&typeof _0x53f0a2=='object'&&Q(_0x53f0a2,'w')){const _0x2f26ec=Le(_0x53f0a2,'w');if(Array['isArray'](_0x2f26ec)&&~_0x2f26ec['indexOf']('no_index')){const _0x4eeda4='\x22.indexOn\x22:\x20\x22'+_0x5df4fb['_queryParams']['getIndex']()['toString']()+'\x22',_0x634830=_0x5df4fb['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4eeda4+'\x20at\x20'+_0x634830+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2be44){this['authToken_']=_0x2be44,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2be44);}['reduceReconnectDelayIfAdminCredential_'](_0x4913ce){(_0x4913ce&&_0x4913ce['length']===0x28||wc(_0x4913ce))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x5c9496){this['appCheckToken_']=_0x5c9496,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x40a07e=this['authToken_'],_0x2c5910=Ic(_0x40a07e)?'auth':'gauth',_0x3c57ba={'cred':_0x40a07e};this['authOverride_']===null?_0x3c57ba['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3c57ba['authvar']=this['authOverride_']),this['sendRequest'](_0x2c5910,_0x3c57ba,_0x1ed1ea=>{const _0x5eb191=_0x1ed1ea['s'],_0x1704ea=_0x1ed1ea['d']||'error';this['authToken_']===_0x40a07e&&(_0x5eb191==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5eb191,_0x1704ea));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x517d81=>{const _0x28130a=_0x517d81['s'],_0x230ecf=_0x517d81['d']||'error';_0x28130a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x28130a,_0x230ecf);});}['unlisten'](_0xed786d,_0x36c6d2){const _0x274076=_0xed786d['_path']['toString'](),_0x524087=_0xed786d['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x274076+'\x20'+_0x524087),f(_0xed786d['_queryParams']['isDefault']()||!_0xed786d['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x274076,_0x524087)&&this['connected_']&&this['sendUnlisten_'](_0x274076,_0x524087,_0xed786d['_queryObject'],_0x36c6d2);}['sendUnlisten_'](_0x19171d,_0x3c008c,_0x315dba,_0x59b6c5){this['log_']('Unlisten\x20on\x20'+_0x19171d+'\x20for\x20'+_0x3c008c);const _0x59a5f0={'p':_0x19171d},_0x744e7e='n';_0x59b6c5&&(_0x59a5f0['q']=_0x315dba,_0x59a5f0['t']=_0x59b6c5),this['sendRequest'](_0x744e7e,_0x59a5f0);}['onDisconnectPut'](_0x2de3cc,_0x2232e0,_0xae0d25){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2de3cc,_0x2232e0,_0xae0d25):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2de3cc,'action':'o','data':_0x2232e0,'onComplete':_0xae0d25});}['onDisconnectMerge'](_0x97d56a,_0x2207eb,_0x375742){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x97d56a,_0x2207eb,_0x375742):this['onDisconnectRequestQueue_']['push']({'pathString':_0x97d56a,'action':'om','data':_0x2207eb,'onComplete':_0x375742});}['onDisconnectCancel'](_0x5c5c48,_0x3fb056){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5c5c48,null,_0x3fb056):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c5c48,'action':'oc','data':null,'onComplete':_0x3fb056});}['sendOnDisconnect_'](_0x29fa76,_0xd488b5,_0x11806f,_0x395fb5){const _0x524387={'p':_0xd488b5,'d':_0x11806f};this['log_']('onDisconnect\x20'+_0x29fa76,_0x524387),this['sendRequest'](_0x29fa76,_0x524387,_0x3165c1=>{_0x395fb5&&setTimeout(()=>{_0x395fb5(_0x3165c1['s'],_0x3165c1['d']);},Math['floor'](0x0));});}['put'](_0x3d0671,_0x5107da,_0x5d8c6d,_0x33c9db){this['putInternal']('p',_0x3d0671,_0x5107da,_0x5d8c6d,_0x33c9db);}['merge'](_0x56ea1e,_0x49f2b9,_0x334563,_0x500317){this['putInternal']('m',_0x56ea1e,_0x49f2b9,_0x334563,_0x500317);}['putInternal'](_0x43079a,_0x51b8d2,_0x277c63,_0x692bcf,_0x3586df){this['initConnection_']();const _0x25701e={'p':_0x51b8d2,'d':_0x277c63};_0x3586df!==void 0x0&&(_0x25701e['h']=_0x3586df),this['outstandingPuts_']['push']({'action':_0x43079a,'request':_0x25701e,'onComplete':_0x692bcf}),this['outstandingPutCount_']++;const _0x215f38=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x215f38):this['log_']('Buffering\x20put:\x20'+_0x51b8d2);}['sendPut_'](_0x12e4bb){const _0x43f04c=this['outstandingPuts_'][_0x12e4bb]['action'],_0x139ba1=this['outstandingPuts_'][_0x12e4bb]['request'],_0x4fc1c8=this['outstandingPuts_'][_0x12e4bb]['onComplete'];this['outstandingPuts_'][_0x12e4bb]['queued']=this['connected_'],this['sendRequest'](_0x43f04c,_0x139ba1,_0x28a12e=>{this['log_'](_0x43f04c+'\x20response',_0x28a12e),delete this['outstandingPuts_'][_0x12e4bb],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4fc1c8&&_0x4fc1c8(_0x28a12e['s'],_0x28a12e['d']);});}['reportStats'](_0x4ec1e0){if(this['connected_']){const _0x472416={'c':_0x4ec1e0};this['log_']('reportStats',_0x472416),this['sendRequest']('s',_0x472416,_0x47d282=>{if(_0x47d282['s']!=='ok'){const _0x3b0daa=_0x47d282['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3b0daa);}});}}['onDataMessage_'](_0xa0d60){if('r'in _0xa0d60){this['log_']('from\x20server:\x20'+O(_0xa0d60));const _0x54b19c=_0xa0d60['r'],_0x34c04f=this['requestCBHash_'][_0x54b19c];_0x34c04f&&(delete this['requestCBHash_'][_0x54b19c],_0x34c04f(_0xa0d60['b']));}else{if('error'in _0xa0d60)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xa0d60['error'];'a'in _0xa0d60&&this['onDataPush_'](_0xa0d60['a'],_0xa0d60['b']);}}['onDataPush_'](_0x2e8a7f,_0x17d7e0){this['log_']('handleServerMessage',_0x2e8a7f,_0x17d7e0),_0x2e8a7f==='d'?this['onDataUpdate_'](_0x17d7e0['p'],_0x17d7e0['d'],!0x1,_0x17d7e0['t']):_0x2e8a7f==='m'?this['onDataUpdate_'](_0x17d7e0['p'],_0x17d7e0['d'],!0x0,_0x17d7e0['t']):_0x2e8a7f==='c'?this['onListenRevoked_'](_0x17d7e0['p'],_0x17d7e0['q']):_0x2e8a7f==='ac'?this['onAuthRevoked_'](_0x17d7e0['s'],_0x17d7e0['d']):_0x2e8a7f==='apc'?this['onAppCheckRevoked_'](_0x17d7e0['s'],_0x17d7e0['d']):_0x2e8a7f==='sd'?this['onSecurityDebugPacket_'](_0x17d7e0):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2e8a7f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x52a3be,_0x5c5874){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x52a3be),this['lastSessionId']=_0x5c5874,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3de048){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3de048));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x236e0b){_0x236e0b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x236e0b;}['onOnline_'](_0x14c80){_0x14c80?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3be136=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xe3132c=Math['max'](0x0,this['reconnectDelay_']-_0x3be136);_0xe3132c=Math['random']()*_0xe3132c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xe3132c+'ms'),this['scheduleConnect_'](_0xe3132c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4e02b9=this['onDataMessage_']['bind'](this),_0x1064fc=this['onReady_']['bind'](this),_0x498c10=this['onRealtimeDisconnect_']['bind'](this),_0x3f0ba5=this['id']+':'+se['nextConnectionId_']++,_0x56febf=this['lastSessionId'];let _0x37b879=!0x1,_0x1a00bd=null;const _0x4e0766=function(){_0x1a00bd?_0x1a00bd['close']():(_0x37b879=!0x0,_0x498c10());},_0x34df6d=function(_0x2c2170){f(_0x1a00bd,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1a00bd['sendRequest'](_0x2c2170);};this['realtime_']={'close':_0x4e0766,'sendRequest':_0x34df6d};const _0x14293d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x397ea4,_0x788c55]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x14293d),this['appCheckTokenProvider_']['getToken'](_0x14293d)]);_0x37b879?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x397ea4&&_0x397ea4['accessToken'],this['appCheckToken_']=_0x788c55&&_0x788c55['token'],_0x1a00bd=new Sh(_0x3f0ba5,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4e02b9,_0x1064fc,_0x498c10,_0x2c3c5c=>{U(_0x2c3c5c+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x56febf));}catch(_0x4212cc){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4212cc),_0x37b879||(this['repoInfo_']['nodeAdmin']&&U(_0x4212cc),_0x4e0766());}}}['interrupt'](_0x36acd6){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x36acd6),this['interruptReasons_'][_0x36acd6]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2405bb){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2405bb),delete this['interruptReasons_'][_0x2405bb],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x350011){const _0xa7e3d3=_0x350011-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xa7e3d3});}['cancelSentTransactions_'](){for(let _0x3662b0=0x0;_0x3662b0<this['outstandingPuts_']['length'];_0x3662b0++){const _0xa73113=this['outstandingPuts_'][_0x3662b0];_0xa73113&&'h'in _0xa73113['request']&&_0xa73113['queued']&&(_0xa73113['onComplete']&&_0xa73113['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3662b0],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x439862,_0xaf45e3){let _0x278137;_0xaf45e3?_0x278137=_0xaf45e3['map'](_0x509dfe=>$i(_0x509dfe))['join']('$'):_0x278137='default';const _0x4a5197=this['removeListen_'](_0x439862,_0x278137);_0x4a5197&&_0x4a5197['onComplete']&&_0x4a5197['onComplete']('permission_denied');}['removeListen_'](_0x1e8bbe,_0x2d6ff0){const _0x4627be=new C(_0x1e8bbe)['toString']();let _0x3d36c4;if(this['listens']['has'](_0x4627be)){const _0x4d30f9=this['listens']['get'](_0x4627be);_0x3d36c4=_0x4d30f9['get'](_0x2d6ff0),_0x4d30f9['delete'](_0x2d6ff0),_0x4d30f9['size']===0x0&&this['listens']['delete'](_0x4627be);}else _0x3d36c4=void 0x0;return _0x3d36c4;}['onAuthRevoked_'](_0x2d620e,_0x4e239c){L('Auth\x20token\x20revoked:\x20'+_0x2d620e+'/'+_0x4e239c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2d620e==='invalid_token'||_0x2d620e==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x472cf8,_0x46a52f){L('App\x20check\x20token\x20revoked:\x20'+_0x472cf8+'/'+_0x46a52f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x472cf8==='invalid_token'||_0x472cf8==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5516ff){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5516ff):'msg'in _0x5516ff&&console['log']('FIREBASE:\x20'+_0x5516ff['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x453e81 of this['listens']['values']())for(const _0x55c4ae of _0x453e81['values']())this['sendListen_'](_0x55c4ae);for(let _0x4ddc4d=0x0;_0x4ddc4d<this['outstandingPuts_']['length'];_0x4ddc4d++)this['outstandingPuts_'][_0x4ddc4d]&&this['sendPut_'](_0x4ddc4d);for(;this['onDisconnectRequestQueue_']['length'];){const _0x19af97=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x19af97['action'],_0x19af97['pathString'],_0x19af97['data'],_0x19af97['onComplete']);}for(let _0x1274e7=0x0;_0x1274e7<this['outstandingGets_']['length'];_0x1274e7++)this['outstandingGets_'][_0x1274e7]&&this['sendGet_'](_0x1274e7);}['sendConnectStats_'](){const _0x3ea822={};let _0x34b562='js';_0x3ea822['sdk.'+_0x34b562+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x3ea822['framework.cordova']=0x1:Kr()&&(_0x3ea822['framework.reactnative']=0x1),this['reportStats'](_0x3ea822);}['shouldReconnect_'](){const _0x241d08=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x241d08;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x539a7a,_0x30204b){this['name']=_0x539a7a,this['node']=_0x30204b;}static['Wrap'](_0xd90170,_0x597a94){return new E(_0xd90170,_0x597a94);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5afeaf,_0x20a4e0){const _0x55c59e=new E(We,_0x5afeaf),_0x10fd50=new E(We,_0x20a4e0);return this['compare'](_0x55c59e,_0x10fd50)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x1854ee){sn=_0x1854ee;}['compare'](_0x15038f,_0x2f4c2e){return qe(_0x15038f['name'],_0x2f4c2e['name']);}['isDefinedOn'](_0x319a53){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4d7c81,_0x37a80b){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xc65807,_0x5b3e93){return f(typeof _0xc65807=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xc65807,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x501928,_0x56f35b,_0x2f7f74,_0x164f29,_0x249596=null){this['isReverse_']=_0x164f29,this['resultGenerator_']=_0x249596,this['nodeStack_']=[];let _0x2e498e=0x1;for(;!_0x501928['isEmpty']();)if(_0x501928=_0x501928,_0x2e498e=_0x56f35b?_0x2f7f74(_0x501928['key'],_0x56f35b):0x1,_0x164f29&&(_0x2e498e*=-0x1),_0x2e498e<0x0)this['isReverse_']?_0x501928=_0x501928['left']:_0x501928=_0x501928['right'];else{if(_0x2e498e===0x0){this['nodeStack_']['push'](_0x501928);break;}else this['nodeStack_']['push'](_0x501928),this['isReverse_']?_0x501928=_0x501928['right']:_0x501928=_0x501928['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x250ba9=this['nodeStack_']['pop'](),_0x30be8c;if(this['resultGenerator_']?_0x30be8c=this['resultGenerator_'](_0x250ba9['key'],_0x250ba9['value']):_0x30be8c={'key':_0x250ba9['key'],'value':_0x250ba9['value']},this['isReverse_']){for(_0x250ba9=_0x250ba9['left'];!_0x250ba9['isEmpty']();)this['nodeStack_']['push'](_0x250ba9),_0x250ba9=_0x250ba9['right'];}else{for(_0x250ba9=_0x250ba9['right'];!_0x250ba9['isEmpty']();)this['nodeStack_']['push'](_0x250ba9),_0x250ba9=_0x250ba9['left'];}return _0x30be8c;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1fb1f2=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1fb1f2['key'],_0x1fb1f2['value']):{'key':_0x1fb1f2['key'],'value':_0x1fb1f2['value']};}}class M{constructor(_0x4c5111,_0x5b4d90,_0x19fcae,_0x462aec,_0x1335f1){this['key']=_0x4c5111,this['value']=_0x5b4d90,this['color']=_0x19fcae??M['RED'],this['left']=_0x462aec??B['EMPTY_NODE'],this['right']=_0x1335f1??B['EMPTY_NODE'];}['copy'](_0xa35366,_0x3f1c22,_0xde92d8,_0x1a0656,_0x69e0fd){return new M(_0xa35366??this['key'],_0x3f1c22??this['value'],_0xde92d8??this['color'],_0x1a0656??this['left'],_0x69e0fd??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3437da){return this['left']['inorderTraversal'](_0x3437da)||!!_0x3437da(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3437da);}['reverseTraversal'](_0x5f3e57){return this['right']['reverseTraversal'](_0x5f3e57)||_0x5f3e57(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5f3e57);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xd9e9d2,_0x411199,_0x2a3cf2){let _0x13f560=this;const _0x4d7f49=_0x2a3cf2(_0xd9e9d2,_0x13f560['key']);return _0x4d7f49<0x0?_0x13f560=_0x13f560['copy'](null,null,null,_0x13f560['left']['insert'](_0xd9e9d2,_0x411199,_0x2a3cf2),null):_0x4d7f49===0x0?_0x13f560=_0x13f560['copy'](null,_0x411199,null,null,null):_0x13f560=_0x13f560['copy'](null,null,null,null,_0x13f560['right']['insert'](_0xd9e9d2,_0x411199,_0x2a3cf2)),_0x13f560['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x56a13e=this;return!_0x56a13e['left']['isRed_']()&&!_0x56a13e['left']['left']['isRed_']()&&(_0x56a13e=_0x56a13e['moveRedLeft_']()),_0x56a13e=_0x56a13e['copy'](null,null,null,_0x56a13e['left']['removeMin_'](),null),_0x56a13e['fixUp_']();}['remove'](_0x2e76db,_0x200e0f){let _0x47af20,_0x471710;if(_0x47af20=this,_0x200e0f(_0x2e76db,_0x47af20['key'])<0x0)!_0x47af20['left']['isEmpty']()&&!_0x47af20['left']['isRed_']()&&!_0x47af20['left']['left']['isRed_']()&&(_0x47af20=_0x47af20['moveRedLeft_']()),_0x47af20=_0x47af20['copy'](null,null,null,_0x47af20['left']['remove'](_0x2e76db,_0x200e0f),null);else{if(_0x47af20['left']['isRed_']()&&(_0x47af20=_0x47af20['rotateRight_']()),!_0x47af20['right']['isEmpty']()&&!_0x47af20['right']['isRed_']()&&!_0x47af20['right']['left']['isRed_']()&&(_0x47af20=_0x47af20['moveRedRight_']()),_0x200e0f(_0x2e76db,_0x47af20['key'])===0x0){if(_0x47af20['right']['isEmpty']())return B['EMPTY_NODE'];_0x471710=_0x47af20['right']['min_'](),_0x47af20=_0x47af20['copy'](_0x471710['key'],_0x471710['value'],null,null,_0x47af20['right']['removeMin_']());}_0x47af20=_0x47af20['copy'](null,null,null,null,_0x47af20['right']['remove'](_0x2e76db,_0x200e0f));}return _0x47af20['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x22921d=this;return _0x22921d['right']['isRed_']()&&!_0x22921d['left']['isRed_']()&&(_0x22921d=_0x22921d['rotateLeft_']()),_0x22921d['left']['isRed_']()&&_0x22921d['left']['left']['isRed_']()&&(_0x22921d=_0x22921d['rotateRight_']()),_0x22921d['left']['isRed_']()&&_0x22921d['right']['isRed_']()&&(_0x22921d=_0x22921d['colorFlip_']()),_0x22921d;}['moveRedLeft_'](){let _0x2ccd12=this['colorFlip_']();return _0x2ccd12['right']['left']['isRed_']()&&(_0x2ccd12=_0x2ccd12['copy'](null,null,null,null,_0x2ccd12['right']['rotateRight_']()),_0x2ccd12=_0x2ccd12['rotateLeft_'](),_0x2ccd12=_0x2ccd12['colorFlip_']()),_0x2ccd12;}['moveRedRight_'](){let _0x3ae3db=this['colorFlip_']();return _0x3ae3db['left']['left']['isRed_']()&&(_0x3ae3db=_0x3ae3db['rotateRight_'](),_0x3ae3db=_0x3ae3db['colorFlip_']()),_0x3ae3db;}['rotateLeft_'](){const _0x96079c=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x96079c,null);}['rotateRight_'](){const _0x38eaa1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x38eaa1);}['colorFlip_'](){const _0x3d62db=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x57fb41=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3d62db,_0x57fb41);}['checkMaxDepth_'](){const _0x3d8fac=this['check_']();return Math['pow'](0x2,_0x3d8fac)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5f23f8=this['left']['check_']();if(_0x5f23f8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5f23f8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x337574,_0x1540fe,_0x55992b,_0x4cd9e9,_0x44ca48){return this;}['insert'](_0x34bd45,_0x4be667,_0x57fddd){return new M(_0x34bd45,_0x4be667,null);}['remove'](_0x2b801f,_0x5bbaac){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xecbc50){return!0x1;}['reverseTraversal'](_0x294b84){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x87bded,_0x4c3ade=B['EMPTY_NODE']){this['comparator_']=_0x87bded,this['root_']=_0x4c3ade;}['insert'](_0x4b7bb5,_0x5b6299){return new B(this['comparator_'],this['root_']['insert'](_0x4b7bb5,_0x5b6299,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2f5430){return new B(this['comparator_'],this['root_']['remove'](_0x2f5430,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x59f37c){let _0xa7cb37,_0x2ec236=this['root_'];for(;!_0x2ec236['isEmpty']();){if(_0xa7cb37=this['comparator_'](_0x59f37c,_0x2ec236['key']),_0xa7cb37===0x0)return _0x2ec236['value'];_0xa7cb37<0x0?_0x2ec236=_0x2ec236['left']:_0xa7cb37>0x0&&(_0x2ec236=_0x2ec236['right']);}return null;}['getPredecessorKey'](_0x395795){let _0x7a20cc,_0x148739=this['root_'],_0x37e16a=null;for(;!_0x148739['isEmpty']();)if(_0x7a20cc=this['comparator_'](_0x395795,_0x148739['key']),_0x7a20cc===0x0){if(_0x148739['left']['isEmpty']())return _0x37e16a?_0x37e16a['key']:null;for(_0x148739=_0x148739['left'];!_0x148739['right']['isEmpty']();)_0x148739=_0x148739['right'];return _0x148739['key'];}else _0x7a20cc<0x0?_0x148739=_0x148739['left']:_0x7a20cc>0x0&&(_0x37e16a=_0x148739,_0x148739=_0x148739['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x16cb35){return this['root_']['inorderTraversal'](_0x16cb35);}['reverseTraversal'](_0x426232){return this['root_']['reverseTraversal'](_0x426232);}['getIterator'](_0x9b8384){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x9b8384);}['getIteratorFrom'](_0x563faa,_0x13f278){return new rn(this['root_'],_0x563faa,this['comparator_'],!0x1,_0x13f278);}['getReverseIteratorFrom'](_0x96c9fc,_0x15429f){return new rn(this['root_'],_0x96c9fc,this['comparator_'],!0x0,_0x15429f);}['getReverseIterator'](_0x2c2153){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x2c2153);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1c8d58,_0x3388d7){return qe(_0x1c8d58['name'],_0x3388d7['name']);}function Qi(_0x5e1c06,_0x4d2d73){return qe(_0x5e1c06,_0x4d2d73);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x17288c){Ci=_0x17288c;}const Po=function(_0x9845f){return typeof _0x9845f=='number'?'number:'+ao(_0x9845f):'string:'+_0x9845f;},No=function(_0xdea941){if(_0xdea941['isLeafNode']()){const _0x5a8163=_0xdea941['val']();f(typeof _0x5a8163=='string'||typeof _0x5a8163=='number'||typeof _0x5a8163=='object'&&Q(_0x5a8163,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xdea941===Ci||_0xdea941['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xdea941===Ci||_0xdea941['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x26706c){nr=_0x26706c;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x410ea4,_0x451b92=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x410ea4,this['priorityNode_']=_0x451b92,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4cbf4b){return new D(this['value_'],_0x4cbf4b);}['getImmediateChild'](_0xa6a8ff){return _0xa6a8ff==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x14cc92){return v(_0x14cc92)?this:y(_0x14cc92)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2a0d6b,_0x37afe5){return null;}['updateImmediateChild'](_0x32e319,_0x4534ae){return _0x32e319==='.priority'?this['updatePriority'](_0x4534ae):_0x4534ae['isEmpty']()&&_0x32e319!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x32e319,_0x4534ae)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x18e777,_0x197b49){const _0x47c717=y(_0x18e777);return _0x47c717===null?_0x197b49:_0x197b49['isEmpty']()&&_0x47c717!=='.priority'?this:(f(_0x47c717!=='.priority'||Ce(_0x18e777)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x47c717,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x18e777),_0x197b49)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1f75fa,_0x24d4cb){return!0x1;}['val'](_0x16d2ee){return _0x16d2ee&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x138c2a='';this['priorityNode_']['isEmpty']()||(_0x138c2a+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x5c6321=typeof this['value_'];_0x138c2a+=_0x5c6321+':',_0x5c6321==='number'?_0x138c2a+=ao(this['value_']):_0x138c2a+=this['value_'],this['lazyHash_']=ro(_0x138c2a);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x13cc34){return _0x13cc34===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x13cc34 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x13cc34['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x13cc34));}['compareToLeafNode_'](_0x1a5f7c){const _0x353188=typeof _0x1a5f7c['value_'],_0x2b3190=typeof this['value_'],_0x11dd3b=D['VALUE_TYPE_ORDER']['indexOf'](_0x353188),_0xe4d57f=D['VALUE_TYPE_ORDER']['indexOf'](_0x2b3190);return f(_0x11dd3b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x353188),f(_0xe4d57f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2b3190),_0x11dd3b===_0xe4d57f?_0x2b3190==='object'?0x0:this['value_']<_0x1a5f7c['value_']?-0x1:this['value_']===_0x1a5f7c['value_']?0x0:0x1:_0xe4d57f-_0x11dd3b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3747ec){if(_0x3747ec===this)return!0x0;if(_0x3747ec['isLeafNode']()){const _0x467a4b=_0x3747ec;return this['value_']===_0x467a4b['value_']&&this['priorityNode_']['equals'](_0x467a4b['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3be280){Oo=_0x3be280;}function Wh(_0x110bcb){Do=_0x110bcb;}class Bh extends Fn{['compare'](_0x2e2779,_0x7b8ad8){const _0x26e8fa=_0x2e2779['node']['getPriority'](),_0x19669d=_0x7b8ad8['node']['getPriority'](),_0x539467=_0x26e8fa['compareTo'](_0x19669d);return _0x539467===0x0?qe(_0x2e2779['name'],_0x7b8ad8['name']):_0x539467;}['isDefinedOn'](_0x280a71){return!_0x280a71['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x38f316,_0x495d3b){return!_0x38f316['getPriority']()['equals'](_0x495d3b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4b59db,_0x19ec8e){const _0x55e1fe=Oo(_0x4b59db);return new E(_0x19ec8e,new D('[PRIORITY-POST]',_0x55e1fe));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x18419b){const _0x228867=_0x33ed2e=>parseInt(Math['log'](_0x33ed2e)/Vh,0xa),_0x2530f8=_0x187644=>parseInt(Array(_0x187644+0x1)['join']('1'),0x2);this['count']=_0x228867(_0x18419b+0x1),this['current_']=this['count']-0x1;const _0x18e348=_0x2530f8(this['count']);this['bits_']=_0x18419b+0x1&_0x18e348;}['nextBitIsOne'](){const _0x1049a6=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1049a6;}}const yn=function(_0x453366,_0x5195de,_0xfc2c3c,_0xe7ec84){_0x453366['sort'](_0x5195de);const _0x60d4f6=function(_0x2d1d22,_0x4c3060){const _0x697a31=_0x4c3060-_0x2d1d22;let _0xf70005,_0xd2c2c4;if(_0x697a31===0x0)return null;if(_0x697a31===0x1)return _0xf70005=_0x453366[_0x2d1d22],_0xd2c2c4=_0xfc2c3c?_0xfc2c3c(_0xf70005):_0xf70005,new M(_0xd2c2c4,_0xf70005['node'],M['BLACK'],null,null);{const _0x39a696=parseInt(_0x697a31/0x2,0xa)+_0x2d1d22,_0x4f2c8b=_0x60d4f6(_0x2d1d22,_0x39a696),_0x2b6637=_0x60d4f6(_0x39a696+0x1,_0x4c3060);return _0xf70005=_0x453366[_0x39a696],_0xd2c2c4=_0xfc2c3c?_0xfc2c3c(_0xf70005):_0xf70005,new M(_0xd2c2c4,_0xf70005['node'],M['BLACK'],_0x4f2c8b,_0x2b6637);}},_0x43672f=function(_0x2335df){let _0x3e2280=null,_0x20c21b=null,_0x3a8460=_0x453366['length'];const _0x249a31=function(_0x556bec,_0x59a4d3){const _0xe40274=_0x3a8460-_0x556bec,_0x3f6f75=_0x3a8460;_0x3a8460-=_0x556bec;const _0x1fcbb3=_0x60d4f6(_0xe40274+0x1,_0x3f6f75),_0x5434a6=_0x453366[_0xe40274],_0x1f1c2c=_0xfc2c3c?_0xfc2c3c(_0x5434a6):_0x5434a6;_0x911a1e(new M(_0x1f1c2c,_0x5434a6['node'],_0x59a4d3,null,_0x1fcbb3));},_0x911a1e=function(_0x77006a){_0x3e2280?(_0x3e2280['left']=_0x77006a,_0x3e2280=_0x77006a):(_0x20c21b=_0x77006a,_0x3e2280=_0x77006a);};for(let _0x43d392=0x0;_0x43d392<_0x2335df['count'];++_0x43d392){const _0x1e1bff=_0x2335df['nextBitIsOne'](),_0x45a170=Math['pow'](0x2,_0x2335df['count']-(_0x43d392+0x1));_0x1e1bff?_0x249a31(_0x45a170,M['BLACK']):(_0x249a31(_0x45a170,M['BLACK']),_0x249a31(_0x45a170,M['RED']));}return _0x20c21b;},_0x2ac12c=new Hh(_0x453366['length']),_0x52d121=_0x43672f(_0x2ac12c);return new B(_0xe7ec84||_0x5195de,_0x52d121);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4961c1,_0x5b9dc6){this['indexes_']=_0x4961c1,this['indexSet_']=_0x5b9dc6;}['get'](_0x4b5c19){const _0x268f28=Le(this['indexes_'],_0x4b5c19);if(!_0x268f28)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4b5c19);return _0x268f28 instanceof B?_0x268f28:null;}['hasIndex'](_0x5c3657){return Q(this['indexSet_'],_0x5c3657['toString']());}['addIndex'](_0x36b8e3,_0x2c5f1b){f(_0x36b8e3!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1f8659=[];let _0x34cd48=!0x1;const _0x3f63d9=_0x2c5f1b['getIterator'](E['Wrap']);let _0x5bd95f=_0x3f63d9['getNext']();for(;_0x5bd95f;)_0x34cd48=_0x34cd48||_0x36b8e3['isDefinedOn'](_0x5bd95f['node']),_0x1f8659['push'](_0x5bd95f),_0x5bd95f=_0x3f63d9['getNext']();let _0x230758;_0x34cd48?_0x230758=yn(_0x1f8659,_0x36b8e3['getCompare']()):_0x230758=Qe;const _0xe84879=_0x36b8e3['toString'](),_0x17ff74={...this['indexSet_']};_0x17ff74[_0xe84879]=_0x36b8e3;const _0xa75fde={...this['indexes_']};return _0xa75fde[_0xe84879]=_0x230758,new te(_0xa75fde,_0x17ff74);}['addToIndexes'](_0x40555a,_0x481b7a){const _0x4cd630=_n(this['indexes_'],(_0x3927a4,_0x5a4ce8)=>{const _0x56d9b7=Le(this['indexSet_'],_0x5a4ce8);if(f(_0x56d9b7,'Missing\x20index\x20implementation\x20for\x20'+_0x5a4ce8),_0x3927a4===Qe){if(_0x56d9b7['isDefinedOn'](_0x40555a['node'])){const _0x418277=[],_0x415a32=_0x481b7a['getIterator'](E['Wrap']);let _0x473b2d=_0x415a32['getNext']();for(;_0x473b2d;)_0x473b2d['name']!==_0x40555a['name']&&_0x418277['push'](_0x473b2d),_0x473b2d=_0x415a32['getNext']();return _0x418277['push'](_0x40555a),yn(_0x418277,_0x56d9b7['getCompare']());}else return Qe;}else{const _0x4900d0=_0x481b7a['get'](_0x40555a['name']);let _0x4695ab=_0x3927a4;return _0x4900d0&&(_0x4695ab=_0x4695ab['remove'](new E(_0x40555a['name'],_0x4900d0))),_0x4695ab['insert'](_0x40555a,_0x40555a['node']);}});return new te(_0x4cd630,this['indexSet_']);}['removeFromIndexes'](_0x444399,_0x5f15ea){const _0x29f2f8=_n(this['indexes_'],_0x426431=>{if(_0x426431===Qe)return _0x426431;{const _0xfc3c2c=_0x5f15ea['get'](_0x444399['name']);return _0xfc3c2c?_0x426431['remove'](new E(_0x444399['name'],_0xfc3c2c)):_0x426431;}});return new te(_0x29f2f8,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4f81da,_0x2d3197,_0xfa915b){this['children_']=_0x4f81da,this['priorityNode_']=_0x2d3197,this['indexMap_']=_0xfa915b,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x16401c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x16401c,this['indexMap_']);}['getImmediateChild'](_0x46e130){if(_0x46e130==='.priority')return this['getPriority']();{const _0x556b4c=this['children_']['get'](_0x46e130);return _0x556b4c===null?It:_0x556b4c;}}['getChild'](_0x78fb1c){const _0x2b15=y(_0x78fb1c);return _0x2b15===null?this:this['getImmediateChild'](_0x2b15)['getChild'](S(_0x78fb1c));}['hasChild'](_0x856363){return this['children_']['get'](_0x856363)!==null;}['updateImmediateChild'](_0x2f1eec,_0x5841c7){if(f(_0x5841c7,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2f1eec==='.priority')return this['updatePriority'](_0x5841c7);{const _0x4d2310=new E(_0x2f1eec,_0x5841c7);let _0x5f17ab,_0x44b5d4;_0x5841c7['isEmpty']()?(_0x5f17ab=this['children_']['remove'](_0x2f1eec),_0x44b5d4=this['indexMap_']['removeFromIndexes'](_0x4d2310,this['children_'])):(_0x5f17ab=this['children_']['insert'](_0x2f1eec,_0x5841c7),_0x44b5d4=this['indexMap_']['addToIndexes'](_0x4d2310,this['children_']));const _0xc0926b=_0x5f17ab['isEmpty']()?It:this['priorityNode_'];return new g(_0x5f17ab,_0xc0926b,_0x44b5d4);}}['updateChild'](_0xb2e7c2,_0x57a3f3){const _0x10a153=y(_0xb2e7c2);if(_0x10a153===null)return _0x57a3f3;{f(y(_0xb2e7c2)!=='.priority'||Ce(_0xb2e7c2)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x39a2a5=this['getImmediateChild'](_0x10a153)['updateChild'](S(_0xb2e7c2),_0x57a3f3);return this['updateImmediateChild'](_0x10a153,_0x39a2a5);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x144c7e){if(this['isEmpty']())return null;const _0x5630c5={};let _0x5431de=0x0,_0x3928ec=0x0,_0x3057a2=!0x0;if(this['forEachChild'](R,(_0x1ea67d,_0x420afa)=>{_0x5630c5[_0x1ea67d]=_0x420afa['val'](_0x144c7e),_0x5431de++,_0x3057a2&&g['INTEGER_REGEXP_']['test'](_0x1ea67d)?_0x3928ec=Math['max'](_0x3928ec,Number(_0x1ea67d)):_0x3057a2=!0x1;}),!_0x144c7e&&_0x3057a2&&_0x3928ec<0x2*_0x5431de){const _0x152011=[];for(const _0x4c0900 in _0x5630c5)_0x152011[_0x4c0900]=_0x5630c5[_0x4c0900];return _0x152011;}else return _0x144c7e&&!this['getPriority']()['isEmpty']()&&(_0x5630c5['.priority']=this['getPriority']()['val']()),_0x5630c5;}['hash'](){if(this['lazyHash_']===null){let _0x3a83e8='';this['getPriority']()['isEmpty']()||(_0x3a83e8+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x378d1f,_0xfbb5da)=>{const _0x320528=_0xfbb5da['hash']();_0x320528!==''&&(_0x3a83e8+=':'+_0x378d1f+':'+_0x320528);}),this['lazyHash_']=_0x3a83e8===''?'':ro(_0x3a83e8);}return this['lazyHash_'];}['getPredecessorChildName'](_0x55244e,_0x4c47e2,_0x5d6daa){const _0x27a88d=this['resolveIndex_'](_0x5d6daa);if(_0x27a88d){const _0x6582b8=_0x27a88d['getPredecessorKey'](new E(_0x55244e,_0x4c47e2));return _0x6582b8?_0x6582b8['name']:null;}else return this['children_']['getPredecessorKey'](_0x55244e);}['getFirstChildName'](_0x21fa77){const _0x144f6c=this['resolveIndex_'](_0x21fa77);if(_0x144f6c){const _0xcf0657=_0x144f6c['minKey']();return _0xcf0657&&_0xcf0657['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x567618){const _0x2ff746=this['getFirstChildName'](_0x567618);return _0x2ff746?new E(_0x2ff746,this['children_']['get'](_0x2ff746)):null;}['getLastChildName'](_0x41b015){const _0x129e4f=this['resolveIndex_'](_0x41b015);if(_0x129e4f){const _0x13ff2c=_0x129e4f['maxKey']();return _0x13ff2c&&_0x13ff2c['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x11468a){const _0x346899=this['getLastChildName'](_0x11468a);return _0x346899?new E(_0x346899,this['children_']['get'](_0x346899)):null;}['forEachChild'](_0x40defe,_0x2b9b0e){const _0x1c7356=this['resolveIndex_'](_0x40defe);return _0x1c7356?_0x1c7356['inorderTraversal'](_0x25088d=>_0x2b9b0e(_0x25088d['name'],_0x25088d['node'])):this['children_']['inorderTraversal'](_0x2b9b0e);}['getIterator'](_0x3e8095){return this['getIteratorFrom'](_0x3e8095['minPost'](),_0x3e8095);}['getIteratorFrom'](_0x4e84b1,_0x3d7aef){const _0x123b41=this['resolveIndex_'](_0x3d7aef);if(_0x123b41)return _0x123b41['getIteratorFrom'](_0x4e84b1,_0x3f3ab0=>_0x3f3ab0);{const _0x2eaae5=this['children_']['getIteratorFrom'](_0x4e84b1['name'],E['Wrap']);let _0x5a6e96=_0x2eaae5['peek']();for(;_0x5a6e96!=null&&_0x3d7aef['compare'](_0x5a6e96,_0x4e84b1)<0x0;)_0x2eaae5['getNext'](),_0x5a6e96=_0x2eaae5['peek']();return _0x2eaae5;}}['getReverseIterator'](_0x464e2f){return this['getReverseIteratorFrom'](_0x464e2f['maxPost'](),_0x464e2f);}['getReverseIteratorFrom'](_0x34bb70,_0x6f65ad){const _0x443709=this['resolveIndex_'](_0x6f65ad);if(_0x443709)return _0x443709['getReverseIteratorFrom'](_0x34bb70,_0x12a45f=>_0x12a45f);{const _0x39cebe=this['children_']['getReverseIteratorFrom'](_0x34bb70['name'],E['Wrap']);let _0x19d534=_0x39cebe['peek']();for(;_0x19d534!=null&&_0x6f65ad['compare'](_0x19d534,_0x34bb70)>0x0;)_0x39cebe['getNext'](),_0x19d534=_0x39cebe['peek']();return _0x39cebe;}}['compareTo'](_0x58d70e){return this['isEmpty']()?_0x58d70e['isEmpty']()?0x0:-0x1:_0x58d70e['isLeafNode']()||_0x58d70e['isEmpty']()?0x1:_0x58d70e===Kt?-0x1:0x0;}['withIndex'](_0x342a80){if(_0x342a80===ve||this['indexMap_']['hasIndex'](_0x342a80))return this;{const _0x237088=this['indexMap_']['addIndex'](_0x342a80,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x237088);}}['isIndexed'](_0x1d0b9c){return _0x1d0b9c===ve||this['indexMap_']['hasIndex'](_0x1d0b9c);}['equals'](_0x54e8b7){if(_0x54e8b7===this)return!0x0;if(_0x54e8b7['isLeafNode']())return!0x1;{const _0x4c362a=_0x54e8b7;if(this['getPriority']()['equals'](_0x4c362a['getPriority']())){if(this['children_']['count']()===_0x4c362a['children_']['count']()){const _0x130f96=this['getIterator'](R),_0x5608a2=_0x4c362a['getIterator'](R);let _0x13df40=_0x130f96['getNext'](),_0x293b6a=_0x5608a2['getNext']();for(;_0x13df40&&_0x293b6a;){if(_0x13df40['name']!==_0x293b6a['name']||!_0x13df40['node']['equals'](_0x293b6a['node']))return!0x1;_0x13df40=_0x130f96['getNext'](),_0x293b6a=_0x5608a2['getNext']();}return _0x13df40===null&&_0x293b6a===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x85636a){return _0x85636a===ve?null:this['indexMap_']['get'](_0x85636a['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x12ef47){return _0x12ef47===this?0x0:0x1;}['equals'](_0x274ea7){return _0x274ea7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x497dbc){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x26d8f1,_0x5c79b8=null){if(_0x26d8f1===null)return g['EMPTY_NODE'];if(typeof _0x26d8f1=='object'&&'.priority'in _0x26d8f1&&(_0x5c79b8=_0x26d8f1['.priority']),f(_0x5c79b8===null||typeof _0x5c79b8=='string'||typeof _0x5c79b8=='number'||typeof _0x5c79b8=='object'&&'.sv'in _0x5c79b8,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5c79b8),typeof _0x26d8f1=='object'&&'.value'in _0x26d8f1&&_0x26d8f1['.value']!==null&&(_0x26d8f1=_0x26d8f1['.value']),typeof _0x26d8f1!='object'||'.sv'in _0x26d8f1){const _0x16fabc=_0x26d8f1;return new D(_0x16fabc,A(_0x5c79b8));}if(!(_0x26d8f1 instanceof Array)&&Gh){const _0x177534=[];let _0xaab62f=!0x1;if(x(_0x26d8f1,(_0x2e574f,_0x2a15ab)=>{if(_0x2e574f['substring'](0x0,0x1)!=='.'){const _0x3711e7=A(_0x2a15ab);_0x3711e7['isEmpty']()||(_0xaab62f=_0xaab62f||!_0x3711e7['getPriority']()['isEmpty'](),_0x177534['push'](new E(_0x2e574f,_0x3711e7)));}}),_0x177534['length']===0x0)return g['EMPTY_NODE'];const _0xdc5995=yn(_0x177534,xh,_0x5b2943=>_0x5b2943['name'],Qi);if(_0xaab62f){const _0x57b0e5=yn(_0x177534,R['getCompare']());return new g(_0xdc5995,A(_0x5c79b8),new te({'.priority':_0x57b0e5},{'.priority':R}));}else return new g(_0xdc5995,A(_0x5c79b8),te['Default']);}else{let _0x32e061=g['EMPTY_NODE'];return x(_0x26d8f1,(_0x1ab45c,_0x40af0a)=>{if(Q(_0x26d8f1,_0x1ab45c)&&_0x1ab45c['substring'](0x0,0x1)!=='.'){const _0x430d1b=A(_0x40af0a);(_0x430d1b['isLeafNode']()||!_0x430d1b['isEmpty']())&&(_0x32e061=_0x32e061['updateImmediateChild'](_0x1ab45c,_0x430d1b));}}),_0x32e061['updatePriority'](A(_0x5c79b8));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x16231d){super(),this['indexPath_']=_0x16231d,f(!v(_0x16231d)&&y(_0x16231d)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xfae755){return _0xfae755['getChild'](this['indexPath_']);}['isDefinedOn'](_0x35f631){return!_0x35f631['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x421ee7,_0x35e3ce){const _0xfaec05=this['extractChild'](_0x421ee7['node']),_0x2c4905=this['extractChild'](_0x35e3ce['node']),_0x57546f=_0xfaec05['compareTo'](_0x2c4905);return _0x57546f===0x0?qe(_0x421ee7['name'],_0x35e3ce['name']):_0x57546f;}['makePost'](_0x66c711,_0x374d3f){const _0x48552d=A(_0x66c711),_0x127968=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x48552d);return new E(_0x374d3f,_0x127968);}['maxPost'](){const _0x2c2c8e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x2c2c8e);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x48f083,_0x3c2709){const _0x481c4a=_0x48f083['node']['compareTo'](_0x3c2709['node']);return _0x481c4a===0x0?qe(_0x48f083['name'],_0x3c2709['name']):_0x481c4a;}['isDefinedOn'](_0x1d6e7c){return!0x0;}['indexedValueChanged'](_0x49d4d0,_0x31a0d4){return!_0x49d4d0['equals'](_0x31a0d4);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x351fe8,_0x161eb5){const _0x129689=A(_0x351fe8);return new E(_0x161eb5,_0x129689);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x4689ea){return{'type':'value','snapshotNode':_0x4689ea};}function rt(_0x3da0b1,_0x4485b1){return{'type':'child_added','snapshotNode':_0x4485b1,'childName':_0x3da0b1};}function Lt(_0x4c1299,_0xaa87b1){return{'type':'child_removed','snapshotNode':_0xaa87b1,'childName':_0x4c1299};}function xt(_0x5d432f,_0xf90ff1,_0x2eff81){return{'type':'child_changed','snapshotNode':_0xf90ff1,'childName':_0x5d432f,'oldSnap':_0x2eff81};}function zh(_0x222ff1,_0x5bada8){return{'type':'child_moved','snapshotNode':_0x5bada8,'childName':_0x222ff1};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1245f3){this['index_']=_0x1245f3;}['updateChild'](_0x3d9450,_0x254893,_0x3bcfd7,_0x219661,_0xd3b41c,_0x51f46c){f(_0x3d9450['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4c4af7=_0x3d9450['getImmediateChild'](_0x254893);return _0x4c4af7['getChild'](_0x219661)['equals'](_0x3bcfd7['getChild'](_0x219661))&&_0x4c4af7['isEmpty']()===_0x3bcfd7['isEmpty']()||(_0x51f46c!=null&&(_0x3bcfd7['isEmpty']()?_0x3d9450['hasChild'](_0x254893)?_0x51f46c['trackChildChange'](Lt(_0x254893,_0x4c4af7)):f(_0x3d9450['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4c4af7['isEmpty']()?_0x51f46c['trackChildChange'](rt(_0x254893,_0x3bcfd7)):_0x51f46c['trackChildChange'](xt(_0x254893,_0x3bcfd7,_0x4c4af7))),_0x3d9450['isLeafNode']()&&_0x3bcfd7['isEmpty']())?_0x3d9450:_0x3d9450['updateImmediateChild'](_0x254893,_0x3bcfd7)['withIndex'](this['index_']);}['updateFullNode'](_0x334808,_0x403dbc,_0x42655b){return _0x42655b!=null&&(_0x334808['isLeafNode']()||_0x334808['forEachChild'](R,(_0x43c8ba,_0x2d8e3f)=>{_0x403dbc['hasChild'](_0x43c8ba)||_0x42655b['trackChildChange'](Lt(_0x43c8ba,_0x2d8e3f));}),_0x403dbc['isLeafNode']()||_0x403dbc['forEachChild'](R,(_0xec67c7,_0x462b41)=>{if(_0x334808['hasChild'](_0xec67c7)){const _0x3c21da=_0x334808['getImmediateChild'](_0xec67c7);_0x3c21da['equals'](_0x462b41)||_0x42655b['trackChildChange'](xt(_0xec67c7,_0x462b41,_0x3c21da));}else _0x42655b['trackChildChange'](rt(_0xec67c7,_0x462b41));})),_0x403dbc['withIndex'](this['index_']);}['updatePriority'](_0x6e902b,_0x5a998a){return _0x6e902b['isEmpty']()?g['EMPTY_NODE']:_0x6e902b['updatePriority'](_0x5a998a);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x39ede6){this['indexedFilter_']=new Xi(_0x39ede6['getIndex']()),this['index_']=_0x39ede6['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x39ede6),this['endPost_']=Ft['getEndPost_'](_0x39ede6),this['startIsInclusive_']=!_0x39ede6['startAfterSet_'],this['endIsInclusive_']=!_0x39ede6['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x26fbd2){const _0x4e6ac1=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x26fbd2)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x26fbd2)<0x0,_0x429503=this['endIsInclusive_']?this['index_']['compare'](_0x26fbd2,this['getEndPost']())<=0x0:this['index_']['compare'](_0x26fbd2,this['getEndPost']())<0x0;return _0x4e6ac1&&_0x429503;}['updateChild'](_0x8ac52,_0x5f412b,_0xdfe569,_0x5e6558,_0x48852b,_0x4222ff){return this['matches'](new E(_0x5f412b,_0xdfe569))||(_0xdfe569=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x8ac52,_0x5f412b,_0xdfe569,_0x5e6558,_0x48852b,_0x4222ff);}['updateFullNode'](_0xdfe7de,_0x1a381b,_0x5b5d7){_0x1a381b['isLeafNode']()&&(_0x1a381b=g['EMPTY_NODE']);let _0x4effc6=_0x1a381b['withIndex'](this['index_']);_0x4effc6=_0x4effc6['updatePriority'](g['EMPTY_NODE']);const _0x5bc846=this;return _0x1a381b['forEachChild'](R,(_0xf2e004,_0x16c6ea)=>{_0x5bc846['matches'](new E(_0xf2e004,_0x16c6ea))||(_0x4effc6=_0x4effc6['updateImmediateChild'](_0xf2e004,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xdfe7de,_0x4effc6,_0x5b5d7);}['updatePriority'](_0x1353c5,_0x213564){return _0x1353c5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4582e9){if(_0x4582e9['hasStart']()){const _0x3a900b=_0x4582e9['getIndexStartName']();return _0x4582e9['getIndex']()['makePost'](_0x4582e9['getIndexStartValue'](),_0x3a900b);}else return _0x4582e9['getIndex']()['minPost']();}static['getEndPost_'](_0x97a307){if(_0x97a307['hasEnd']()){const _0x244b5f=_0x97a307['getIndexEndName']();return _0x97a307['getIndex']()['makePost'](_0x97a307['getIndexEndValue'](),_0x244b5f);}else return _0x97a307['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x55bc46){this['withinDirectionalStart']=_0x12c4b2=>this['reverse_']?this['withinEndPost'](_0x12c4b2):this['withinStartPost'](_0x12c4b2),this['withinDirectionalEnd']=_0x49492b=>this['reverse_']?this['withinStartPost'](_0x49492b):this['withinEndPost'](_0x49492b),this['withinStartPost']=_0x24f28e=>{const _0x279441=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x24f28e);return this['startIsInclusive_']?_0x279441<=0x0:_0x279441<0x0;},this['withinEndPost']=_0x418604=>{const _0x5d7263=this['index_']['compare'](_0x418604,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5d7263<=0x0:_0x5d7263<0x0;},this['rangedFilter_']=new Ft(_0x55bc46),this['index_']=_0x55bc46['getIndex'](),this['limit_']=_0x55bc46['getLimit'](),this['reverse_']=!_0x55bc46['isViewFromLeft'](),this['startIsInclusive_']=!_0x55bc46['startAfterSet_'],this['endIsInclusive_']=!_0x55bc46['endBeforeSet_'];}['updateChild'](_0x187733,_0x90e477,_0x1b4c96,_0x1a5663,_0x47fc2c,_0x352fd8){return this['rangedFilter_']['matches'](new E(_0x90e477,_0x1b4c96))||(_0x1b4c96=g['EMPTY_NODE']),_0x187733['getImmediateChild'](_0x90e477)['equals'](_0x1b4c96)?_0x187733:_0x187733['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x187733,_0x90e477,_0x1b4c96,_0x1a5663,_0x47fc2c,_0x352fd8):this['fullLimitUpdateChild_'](_0x187733,_0x90e477,_0x1b4c96,_0x47fc2c,_0x352fd8);}['updateFullNode'](_0x44ec9e,_0x546858,_0x7876a8){let _0x4f2172;if(_0x546858['isLeafNode']()||_0x546858['isEmpty']())_0x4f2172=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x546858['numChildren']()&&_0x546858['isIndexed'](this['index_'])){_0x4f2172=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x21eca2;this['reverse_']?_0x21eca2=_0x546858['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x21eca2=_0x546858['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2c34f3=0x0;for(;_0x21eca2['hasNext']()&&_0x2c34f3<this['limit_'];){const _0x4435af=_0x21eca2['getNext']();if(this['withinDirectionalStart'](_0x4435af)){if(this['withinDirectionalEnd'](_0x4435af))_0x4f2172=_0x4f2172['updateImmediateChild'](_0x4435af['name'],_0x4435af['node']),_0x2c34f3++;else break;}else continue;}}else{_0x4f2172=_0x546858['withIndex'](this['index_']),_0x4f2172=_0x4f2172['updatePriority'](g['EMPTY_NODE']);let _0x190f02;this['reverse_']?_0x190f02=_0x4f2172['getReverseIterator'](this['index_']):_0x190f02=_0x4f2172['getIterator'](this['index_']);let _0x535911=0x0;for(;_0x190f02['hasNext']();){const _0xbb856d=_0x190f02['getNext']();_0x535911<this['limit_']&&this['withinDirectionalStart'](_0xbb856d)&&this['withinDirectionalEnd'](_0xbb856d)?_0x535911++:_0x4f2172=_0x4f2172['updateImmediateChild'](_0xbb856d['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x44ec9e,_0x4f2172,_0x7876a8);}['updatePriority'](_0x1dbf22,_0x4f1b5b){return _0x1dbf22;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x39e00a,_0x2cd4df,_0x514e3b,_0x40f8d8,_0x22b292){let _0x4d269f;if(this['reverse_']){const _0x4d2eb6=this['index_']['getCompare']();_0x4d269f=(_0x3f98bd,_0x11e2c4)=>_0x4d2eb6(_0x11e2c4,_0x3f98bd);}else _0x4d269f=this['index_']['getCompare']();const _0x20a31b=_0x39e00a;f(_0x20a31b['numChildren']()===this['limit_'],'');const _0x300772=new E(_0x2cd4df,_0x514e3b),_0x39c75c=this['reverse_']?_0x20a31b['getFirstChild'](this['index_']):_0x20a31b['getLastChild'](this['index_']),_0x2db44b=this['rangedFilter_']['matches'](_0x300772);if(_0x20a31b['hasChild'](_0x2cd4df)){const _0x3e64db=_0x20a31b['getImmediateChild'](_0x2cd4df);let _0x154c4d=_0x40f8d8['getChildAfterChild'](this['index_'],_0x39c75c,this['reverse_']);for(;_0x154c4d!=null&&(_0x154c4d['name']===_0x2cd4df||_0x20a31b['hasChild'](_0x154c4d['name']));)_0x154c4d=_0x40f8d8['getChildAfterChild'](this['index_'],_0x154c4d,this['reverse_']);const _0x427d7c=_0x154c4d==null?0x1:_0x4d269f(_0x154c4d,_0x300772);if(_0x2db44b&&!_0x514e3b['isEmpty']()&&_0x427d7c>=0x0)return _0x22b292!=null&&_0x22b292['trackChildChange'](xt(_0x2cd4df,_0x514e3b,_0x3e64db)),_0x20a31b['updateImmediateChild'](_0x2cd4df,_0x514e3b);{_0x22b292!=null&&_0x22b292['trackChildChange'](Lt(_0x2cd4df,_0x3e64db));const _0x551e96=_0x20a31b['updateImmediateChild'](_0x2cd4df,g['EMPTY_NODE']);return _0x154c4d!=null&&this['rangedFilter_']['matches'](_0x154c4d)?(_0x22b292!=null&&_0x22b292['trackChildChange'](rt(_0x154c4d['name'],_0x154c4d['node'])),_0x551e96['updateImmediateChild'](_0x154c4d['name'],_0x154c4d['node'])):_0x551e96;}}else return _0x514e3b['isEmpty']()?_0x39e00a:_0x2db44b&&_0x4d269f(_0x39c75c,_0x300772)>=0x0?(_0x22b292!=null&&(_0x22b292['trackChildChange'](Lt(_0x39c75c['name'],_0x39c75c['node'])),_0x22b292['trackChildChange'](rt(_0x2cd4df,_0x514e3b))),_0x20a31b['updateImmediateChild'](_0x2cd4df,_0x514e3b)['updateImmediateChild'](_0x39c75c['name'],g['EMPTY_NODE'])):_0x39e00a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x48bd01=new Zi();return _0x48bd01['limitSet_']=this['limitSet_'],_0x48bd01['limit_']=this['limit_'],_0x48bd01['startSet_']=this['startSet_'],_0x48bd01['startAfterSet_']=this['startAfterSet_'],_0x48bd01['indexStartValue_']=this['indexStartValue_'],_0x48bd01['startNameSet_']=this['startNameSet_'],_0x48bd01['indexStartName_']=this['indexStartName_'],_0x48bd01['endSet_']=this['endSet_'],_0x48bd01['endBeforeSet_']=this['endBeforeSet_'],_0x48bd01['indexEndValue_']=this['indexEndValue_'],_0x48bd01['endNameSet_']=this['endNameSet_'],_0x48bd01['indexEndName_']=this['indexEndName_'],_0x48bd01['index_']=this['index_'],_0x48bd01['viewFrom_']=this['viewFrom_'],_0x48bd01;}}function Kh(_0x2e95d3){return _0x2e95d3['loadsAllData']()?new Xi(_0x2e95d3['getIndex']()):_0x2e95d3['hasLimit']()?new jh(_0x2e95d3):new Ft(_0x2e95d3);}function Yh(_0x3d514c,_0x3eb030){const _0x3ec1e8=_0x3d514c['copy']();return _0x3ec1e8['limitSet_']=!0x0,_0x3ec1e8['limit_']=_0x3eb030,_0x3ec1e8['viewFrom_']='l',_0x3ec1e8;}function Qh(_0x5fc6f,_0x5eb876,_0x37c3a6){const _0x26aea1=_0x5fc6f['copy']();return _0x26aea1['startSet_']=!0x0,_0x5eb876===void 0x0&&(_0x5eb876=null),_0x26aea1['indexStartValue_']=_0x5eb876,_0x37c3a6!=null?(_0x26aea1['startNameSet_']=!0x0,_0x26aea1['indexStartName_']=_0x37c3a6):(_0x26aea1['startNameSet_']=!0x1,_0x26aea1['indexStartName_']=''),_0x26aea1;}function Jh(_0x372087,_0x2ee2d4,_0x160ca5){const _0x2a4b5f=_0x372087['copy']();return _0x2a4b5f['endSet_']=!0x0,_0x2ee2d4===void 0x0&&(_0x2ee2d4=null),_0x2a4b5f['indexEndValue_']=_0x2ee2d4,_0x160ca5!==void 0x0?(_0x2a4b5f['endNameSet_']=!0x0,_0x2a4b5f['indexEndName_']=_0x160ca5):(_0x2a4b5f['endNameSet_']=!0x1,_0x2a4b5f['indexEndName_']=''),_0x2a4b5f;}function xo(_0xce1390,_0x3585e9){const _0x1672c8=_0xce1390['copy']();return _0x1672c8['index_']=_0x3585e9,_0x1672c8;}function ir(_0x16030c){const _0x2558fd={};if(_0x16030c['isDefault']())return _0x2558fd;let _0x3aedf8;if(_0x16030c['index_']===R?_0x3aedf8='$priority':_0x16030c['index_']===Mo?_0x3aedf8='$value':_0x16030c['index_']===ve?_0x3aedf8='$key':(f(_0x16030c['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x3aedf8=_0x16030c['index_']['toString']()),_0x2558fd['orderBy']=O(_0x3aedf8),_0x16030c['startSet_']){const _0x2af2f8=_0x16030c['startAfterSet_']?'startAfter':'startAt';_0x2558fd[_0x2af2f8]=O(_0x16030c['indexStartValue_']),_0x16030c['startNameSet_']&&(_0x2558fd[_0x2af2f8]+=','+O(_0x16030c['indexStartName_']));}if(_0x16030c['endSet_']){const _0x37dd9a=_0x16030c['endBeforeSet_']?'endBefore':'endAt';_0x2558fd[_0x37dd9a]=O(_0x16030c['indexEndValue_']),_0x16030c['endNameSet_']&&(_0x2558fd[_0x37dd9a]+=','+O(_0x16030c['indexEndName_']));}return _0x16030c['limitSet_']&&(_0x16030c['isViewFromLeft']()?_0x2558fd['limitToFirst']=_0x16030c['limit_']:_0x2558fd['limitToLast']=_0x16030c['limit_']),_0x2558fd;}function sr(_0x55eea6){const _0x2b306d={};if(_0x55eea6['startSet_']&&(_0x2b306d['sp']=_0x55eea6['indexStartValue_'],_0x55eea6['startNameSet_']&&(_0x2b306d['sn']=_0x55eea6['indexStartName_']),_0x2b306d['sin']=!_0x55eea6['startAfterSet_']),_0x55eea6['endSet_']&&(_0x2b306d['ep']=_0x55eea6['indexEndValue_'],_0x55eea6['endNameSet_']&&(_0x2b306d['en']=_0x55eea6['indexEndName_']),_0x2b306d['ein']=!_0x55eea6['endBeforeSet_']),_0x55eea6['limitSet_']){_0x2b306d['l']=_0x55eea6['limit_'];let _0x53a933=_0x55eea6['viewFrom_'];_0x53a933===''&&(_0x55eea6['isViewFromLeft']()?_0x53a933='l':_0x53a933='r'),_0x2b306d['vf']=_0x53a933;}return _0x55eea6['index_']!==R&&(_0x2b306d['i']=_0x55eea6['index_']['toString']()),_0x2b306d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x22265e){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xd7fe75,_0x5d4511){return _0x5d4511!==void 0x0?'tag$'+_0x5d4511:(f(_0xd7fe75['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xd7fe75['_path']['toString']());}constructor(_0x118c14,_0x58a5e1,_0x49b0fa,_0x4193bb){super(),this['repoInfo_']=_0x118c14,this['onDataUpdate_']=_0x58a5e1,this['authTokenProvider_']=_0x49b0fa,this['appCheckTokenProvider_']=_0x4193bb,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x2bef30,_0xc7e1de,_0xb708b5,_0x3e9bb3){const _0x26e401=_0x2bef30['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x26e401+'\x20'+_0x2bef30['_queryIdentifier']);const _0x1536fe=vn['getListenId_'](_0x2bef30,_0xb708b5),_0x46e3dc={};this['listens_'][_0x1536fe]=_0x46e3dc;const _0x4d6fbd=ir(_0x2bef30['_queryParams']);this['restRequest_'](_0x26e401+'.json',_0x4d6fbd,(_0x4250bb,_0x53e4d5)=>{let _0xc1b58b=_0x53e4d5;if(_0x4250bb===0x194&&(_0xc1b58b=null,_0x4250bb=null),_0x4250bb===null&&this['onDataUpdate_'](_0x26e401,_0xc1b58b,!0x1,_0xb708b5),Le(this['listens_'],_0x1536fe)===_0x46e3dc){let _0x58c02e;_0x4250bb?_0x4250bb===0x191?_0x58c02e='permission_denied':_0x58c02e='rest_error:'+_0x4250bb:_0x58c02e='ok',_0x3e9bb3(_0x58c02e,null);}});}['unlisten'](_0x8710c7,_0x6e59e4){const _0x5b6b87=vn['getListenId_'](_0x8710c7,_0x6e59e4);delete this['listens_'][_0x5b6b87];}['get'](_0x2ff695){const _0xfad183=ir(_0x2ff695['_queryParams']),_0x433c14=_0x2ff695['_path']['toString'](),_0x1da9c7=new H();return this['restRequest_'](_0x433c14+'.json',_0xfad183,(_0x19e59f,_0x507a28)=>{let _0x4b7465=_0x507a28;_0x19e59f===0x194&&(_0x4b7465=null,_0x19e59f=null),_0x19e59f===null?(this['onDataUpdate_'](_0x433c14,_0x4b7465,!0x1,null),_0x1da9c7['resolve'](_0x4b7465)):_0x1da9c7['reject'](new Error(_0x4b7465));}),_0x1da9c7['promise'];}['refreshAuthToken'](_0x2d2413){}['restRequest_'](_0x3cbc95,_0x4e4da9={},_0x2c14b4){return _0x4e4da9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x41f69d,_0x1ff05e])=>{_0x41f69d&&_0x41f69d['accessToken']&&(_0x4e4da9['auth']=_0x41f69d['accessToken']),_0x1ff05e&&_0x1ff05e['token']&&(_0x4e4da9['ac']=_0x1ff05e['token']);const _0x4f02b0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3cbc95+'?ns='+this['repoInfo_']['namespace']+ut(_0x4e4da9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4f02b0);const _0x1c903b=new XMLHttpRequest();_0x1c903b['onreadystatechange']=()=>{if(_0x2c14b4&&_0x1c903b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4f02b0+'\x20received.\x20status:',_0x1c903b['status'],'response:',_0x1c903b['responseText']);let _0x483b22=null;if(_0x1c903b['status']>=0xc8&&_0x1c903b['status']<0x12c){try{_0x483b22=Nt(_0x1c903b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4f02b0+':\x20'+_0x1c903b['responseText']);}_0x2c14b4(null,_0x483b22);}else _0x1c903b['status']!==0x191&&_0x1c903b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4f02b0+'\x20Status:\x20'+_0x1c903b['status']),_0x2c14b4(_0x1c903b['status']);_0x2c14b4=null;}},_0x1c903b['open']('GET',_0x4f02b0,!0x0),_0x1c903b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2083d8){return this['rootNode_']['getChild'](_0x2083d8);}['updateSnapshot'](_0x1b598d,_0x360a5d){this['rootNode_']=this['rootNode_']['updateChild'](_0x1b598d,_0x360a5d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x322a81,_0x25241e,_0x541b87){if(v(_0x25241e))_0x322a81['value']=_0x541b87,_0x322a81['children']['clear']();else{if(_0x322a81['value']!==null)_0x322a81['value']=_0x322a81['value']['updateChild'](_0x25241e,_0x541b87);else{const _0x2e8d04=y(_0x25241e);_0x322a81['children']['has'](_0x2e8d04)||_0x322a81['children']['set'](_0x2e8d04,En());const _0x3457c4=_0x322a81['children']['get'](_0x2e8d04);_0x25241e=S(_0x25241e),pt(_0x3457c4,_0x25241e,_0x541b87);}}}function Ti(_0x32b479,_0x4c5159){if(v(_0x4c5159))return _0x32b479['value']=null,_0x32b479['children']['clear'](),!0x0;if(_0x32b479['value']!==null){if(_0x32b479['value']['isLeafNode']())return!0x1;{const _0x2a24b1=_0x32b479['value'];return _0x32b479['value']=null,_0x2a24b1['forEachChild'](R,(_0x115d85,_0x50522c)=>{pt(_0x32b479,new C(_0x115d85),_0x50522c);}),Ti(_0x32b479,_0x4c5159);}}else{if(_0x32b479['children']['size']>0x0){const _0xa61454=y(_0x4c5159);return _0x4c5159=S(_0x4c5159),_0x32b479['children']['has'](_0xa61454)&&Ti(_0x32b479['children']['get'](_0xa61454),_0x4c5159)&&_0x32b479['children']['delete'](_0xa61454),_0x32b479['children']['size']===0x0;}else return!0x0;}}function Si(_0x8c8d33,_0x447a12,_0x208f9f){_0x8c8d33['value']!==null?_0x208f9f(_0x447a12,_0x8c8d33['value']):Zh(_0x8c8d33,(_0x34697c,_0x26b010)=>{const _0x3dce10=new C(_0x447a12['toString']()+'/'+_0x34697c);Si(_0x26b010,_0x3dce10,_0x208f9f);});}function Zh(_0x59b436,_0x269109){_0x59b436['children']['forEach']((_0x59eb22,_0x41077e)=>{_0x269109(_0x41077e,_0x59eb22);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x5a1573){this['collection_']=_0x5a1573,this['last_']=null;}['get'](){const _0x3b6adb=this['collection_']['get'](),_0x3893fc={..._0x3b6adb};return this['last_']&&x(this['last_'],(_0x43141f,_0x46498c)=>{_0x3893fc[_0x43141f]=_0x3893fc[_0x43141f]-_0x46498c;}),this['last_']=_0x3b6adb,_0x3893fc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x29ed19,_0x4526d0){this['server_']=_0x4526d0,this['statsToReport_']={},this['statsListener_']=new eu(_0x29ed19);const _0x4f1239=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x4f1239));}['reportStats_'](){const _0x39d2cc=this['statsListener_']['get'](),_0x422183={};let _0x5ed920=!0x1;x(_0x39d2cc,(_0x3c1594,_0x3f2063)=>{_0x3f2063>0x0&&Q(this['statsToReport_'],_0x3c1594)&&(_0x422183[_0x3c1594]=_0x3f2063,_0x5ed920=!0x0);}),_0x5ed920&&this['server_']['reportStats'](_0x422183),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2c8692){_0x2c8692[_0x2c8692['OVERWRITE']=0x0]='OVERWRITE',_0x2c8692[_0x2c8692['MERGE']=0x1]='MERGE',_0x2c8692[_0x2c8692['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2c8692[_0x2c8692['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4264ec){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4264ec,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5b1d8f,_0x2ad62d,_0x5887ba){this['path']=_0x5b1d8f,this['affectedTree']=_0x2ad62d,this['revert']=_0x5887ba,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x484ac3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x35546a=this['affectedTree']['subtree'](new C(_0x484ac3));return new In(w(),_0x35546a,this['revert']);}}else return f(y(this['path'])===_0x484ac3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4a56fa,_0x3b5c4b){this['source']=_0x4a56fa,this['path']=_0x3b5c4b,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x17a73a){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5c02c0,_0x1dc5c6,_0x189ff3){this['source']=_0x5c02c0,this['path']=_0x1dc5c6,this['snap']=_0x189ff3,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1deac8){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1deac8)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x56025e,_0x3a1cc5,_0x417ce6){this['source']=_0x56025e,this['path']=_0x3a1cc5,this['children']=_0x417ce6,this['type']=z['MERGE'];}['operationForChild'](_0x1c2ca5){if(v(this['path'])){const _0x7f7bf3=this['children']['subtree'](new C(_0x1c2ca5));return _0x7f7bf3['isEmpty']()?null:_0x7f7bf3['value']?new Be(this['source'],w(),_0x7f7bf3['value']):new ot(this['source'],w(),_0x7f7bf3);}else return f(y(this['path'])===_0x1c2ca5,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x3d5b78,_0x418790,_0x563665){this['node_']=_0x3d5b78,this['fullyInitialized_']=_0x418790,this['filtered_']=_0x563665;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xfea038){if(v(_0xfea038))return this['isFullyInitialized']()&&!this['filtered_'];const _0x58c370=y(_0xfea038);return this['isCompleteForChild'](_0x58c370);}['isCompleteForChild'](_0x429dbe){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x429dbe);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x39db05){this['query_']=_0x39db05,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1fba98,_0x370cda,_0x12e727,_0xbc1267){const _0x2c364e=[],_0x276cd7=[];return _0x370cda['forEach'](_0x3e594f=>{_0x3e594f['type']==='child_changed'&&_0x1fba98['index_']['indexedValueChanged'](_0x3e594f['oldSnap'],_0x3e594f['snapshotNode'])&&_0x276cd7['push'](zh(_0x3e594f['childName'],_0x3e594f['snapshotNode']));}),wt(_0x1fba98,_0x2c364e,'child_removed',_0x370cda,_0xbc1267,_0x12e727),wt(_0x1fba98,_0x2c364e,'child_added',_0x370cda,_0xbc1267,_0x12e727),wt(_0x1fba98,_0x2c364e,'child_moved',_0x276cd7,_0xbc1267,_0x12e727),wt(_0x1fba98,_0x2c364e,'child_changed',_0x370cda,_0xbc1267,_0x12e727),wt(_0x1fba98,_0x2c364e,'value',_0x370cda,_0xbc1267,_0x12e727),_0x2c364e;}function wt(_0x4554e6,_0x303098,_0x17147f,_0x122fee,_0x527f1f,_0x1b694a){const _0x1e6318=_0x122fee['filter'](_0xacb2e=>_0xacb2e['type']===_0x17147f);_0x1e6318['sort']((_0x386351,_0x28e0b7)=>au(_0x4554e6,_0x386351,_0x28e0b7)),_0x1e6318['forEach'](_0x1872a7=>{const _0x8ebde5=ou(_0x4554e6,_0x1872a7,_0x1b694a);_0x527f1f['forEach'](_0xfab5d1=>{_0xfab5d1['respondsTo'](_0x1872a7['type'])&&_0x303098['push'](_0xfab5d1['createEvent'](_0x8ebde5,_0x4554e6['query_']));});});}function ou(_0x19be7c,_0x402466,_0x49bdc6){return _0x402466['type']==='value'||_0x402466['type']==='child_removed'||(_0x402466['prevName']=_0x49bdc6['getPredecessorChildName'](_0x402466['childName'],_0x402466['snapshotNode'],_0x19be7c['index_'])),_0x402466;}function au(_0x308c90,_0x4a12e9,_0x596b3d){if(_0x4a12e9['childName']==null||_0x596b3d['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x717c51=new E(_0x4a12e9['childName'],_0x4a12e9['snapshotNode']),_0x27b121=new E(_0x596b3d['childName'],_0x596b3d['snapshotNode']);return _0x308c90['index_']['compare'](_0x717c51,_0x27b121);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x36eb03,_0x33afe9){return{'eventCache':_0x36eb03,'serverCache':_0x33afe9};}function Rt(_0x357c5b,_0xbe574d,_0x219e15,_0x528a2d){return Un(new Te(_0xbe574d,_0x219e15,_0x528a2d),_0x357c5b['serverCache']);}function Fo(_0x1353cd,_0x346b5c,_0x42c336,_0x486e61){return Un(_0x1353cd['eventCache'],new Te(_0x346b5c,_0x42c336,_0x486e61));}function wn(_0x5727f4){return _0x5727f4['eventCache']['isFullyInitialized']()?_0x5727f4['eventCache']['getNode']():null;}function Ve(_0xe400f4){return _0xe400f4['serverCache']['isFullyInitialized']()?_0xe400f4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x56f6c2){let _0x29efac=new b(null);return x(_0x56f6c2,(_0x220780,_0x5cb51f)=>{_0x29efac=_0x29efac['set'](new C(_0x220780),_0x5cb51f);}),_0x29efac;}constructor(_0x5e83f4,_0x2bcc12=cu()){this['value']=_0x5e83f4,this['children']=_0x2bcc12;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5db598,_0x1c26e0){if(this['value']!=null&&_0x1c26e0(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5db598))return null;{const _0x50fc84=y(_0x5db598),_0x8c040b=this['children']['get'](_0x50fc84);if(_0x8c040b!==null){const _0x42ed7e=_0x8c040b['findRootMostMatchingPathAndValue'](S(_0x5db598),_0x1c26e0);return _0x42ed7e!=null?{'path':k(new C(_0x50fc84),_0x42ed7e['path']),'value':_0x42ed7e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5e0f48){return this['findRootMostMatchingPathAndValue'](_0x5e0f48,()=>!0x0);}['subtree'](_0x2e0ad7){if(v(_0x2e0ad7))return this;{const _0x3ec461=y(_0x2e0ad7),_0x476d58=this['children']['get'](_0x3ec461);return _0x476d58!==null?_0x476d58['subtree'](S(_0x2e0ad7)):new b(null);}}['set'](_0x478624,_0x3eaf54){if(v(_0x478624))return new b(_0x3eaf54,this['children']);{const _0xb64512=y(_0x478624),_0x3c4cc3=(this['children']['get'](_0xb64512)||new b(null))['set'](S(_0x478624),_0x3eaf54),_0x364e7f=this['children']['insert'](_0xb64512,_0x3c4cc3);return new b(this['value'],_0x364e7f);}}['remove'](_0x54255b){if(v(_0x54255b))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2d159f=y(_0x54255b),_0x3cdf0b=this['children']['get'](_0x2d159f);if(_0x3cdf0b){const _0x2ddfc3=_0x3cdf0b['remove'](S(_0x54255b));let _0x5b3c09;return _0x2ddfc3['isEmpty']()?_0x5b3c09=this['children']['remove'](_0x2d159f):_0x5b3c09=this['children']['insert'](_0x2d159f,_0x2ddfc3),this['value']===null&&_0x5b3c09['isEmpty']()?new b(null):new b(this['value'],_0x5b3c09);}else return this;}}['get'](_0x5d7882){if(v(_0x5d7882))return this['value'];{const _0x5c3dc8=y(_0x5d7882),_0x53c270=this['children']['get'](_0x5c3dc8);return _0x53c270?_0x53c270['get'](S(_0x5d7882)):null;}}['setTree'](_0x211b74,_0x24b18c){if(v(_0x211b74))return _0x24b18c;{const _0x33397d=y(_0x211b74),_0x4e8c83=(this['children']['get'](_0x33397d)||new b(null))['setTree'](S(_0x211b74),_0x24b18c);let _0x1fc7de;return _0x4e8c83['isEmpty']()?_0x1fc7de=this['children']['remove'](_0x33397d):_0x1fc7de=this['children']['insert'](_0x33397d,_0x4e8c83),new b(this['value'],_0x1fc7de);}}['fold'](_0x22b779){return this['fold_'](w(),_0x22b779);}['fold_'](_0x1d2204,_0x3c53bc){const _0x500277={};return this['children']['inorderTraversal']((_0x5135e,_0x48cd2c)=>{_0x500277[_0x5135e]=_0x48cd2c['fold_'](k(_0x1d2204,_0x5135e),_0x3c53bc);}),_0x3c53bc(_0x1d2204,this['value'],_0x500277);}['findOnPath'](_0x8bb3a0,_0x53ba67){return this['findOnPath_'](_0x8bb3a0,w(),_0x53ba67);}['findOnPath_'](_0x37e682,_0x50bd97,_0x1928b0){const _0x2df984=this['value']?_0x1928b0(_0x50bd97,this['value']):!0x1;if(_0x2df984)return _0x2df984;if(v(_0x37e682))return null;{const _0x299b2f=y(_0x37e682),_0x207425=this['children']['get'](_0x299b2f);return _0x207425?_0x207425['findOnPath_'](S(_0x37e682),k(_0x50bd97,_0x299b2f),_0x1928b0):null;}}['foreachOnPath'](_0x35f131,_0x264d73){return this['foreachOnPath_'](_0x35f131,w(),_0x264d73);}['foreachOnPath_'](_0x562020,_0x59e3cc,_0xa43af){if(v(_0x562020))return this;{this['value']&&_0xa43af(_0x59e3cc,this['value']);const _0x10adcb=y(_0x562020),_0x27f92b=this['children']['get'](_0x10adcb);return _0x27f92b?_0x27f92b['foreachOnPath_'](S(_0x562020),k(_0x59e3cc,_0x10adcb),_0xa43af):new b(null);}}['foreach'](_0x4260ff){this['foreach_'](w(),_0x4260ff);}['foreach_'](_0x5a0822,_0x3687e3){this['children']['inorderTraversal']((_0xbc42b0,_0x4fca97)=>{_0x4fca97['foreach_'](k(_0x5a0822,_0xbc42b0),_0x3687e3);}),this['value']&&_0x3687e3(_0x5a0822,this['value']);}['foreachChild'](_0x43f433){this['children']['inorderTraversal']((_0x1267f9,_0x4bed78)=>{_0x4bed78['value']&&_0x43f433(_0x1267f9,_0x4bed78['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x405ccb){this['writeTree_']=_0x405ccb;}static['empty'](){return new K(new b(null));}}function At(_0x395535,_0x235241,_0x37eaf8){if(v(_0x235241))return new K(new b(_0x37eaf8));{const _0x1db2b2=_0x395535['writeTree_']['findRootMostValueAndPath'](_0x235241);if(_0x1db2b2!=null){const _0x3eeeef=_0x1db2b2['path'];let _0x1bf38e=_0x1db2b2['value'];const _0x1f1001=F(_0x3eeeef,_0x235241);return _0x1bf38e=_0x1bf38e['updateChild'](_0x1f1001,_0x37eaf8),new K(_0x395535['writeTree_']['set'](_0x3eeeef,_0x1bf38e));}else{const _0x3e6f89=new b(_0x37eaf8),_0x484dd6=_0x395535['writeTree_']['setTree'](_0x235241,_0x3e6f89);return new K(_0x484dd6);}}}function bi(_0x1eb868,_0x3f7eed,_0x2f2c34){let _0x296bea=_0x1eb868;return x(_0x2f2c34,(_0x3ec727,_0x43ff09)=>{_0x296bea=At(_0x296bea,k(_0x3f7eed,_0x3ec727),_0x43ff09);}),_0x296bea;}function or(_0x23faf7,_0xdbf09e){if(v(_0xdbf09e))return K['empty']();{const _0x5afd52=_0x23faf7['writeTree_']['setTree'](_0xdbf09e,new b(null));return new K(_0x5afd52);}}function Ri(_0x11265a,_0x43a7df){return ze(_0x11265a,_0x43a7df)!=null;}function ze(_0x4b0caf,_0x1e2b34){const _0x440994=_0x4b0caf['writeTree_']['findRootMostValueAndPath'](_0x1e2b34);return _0x440994!=null?_0x4b0caf['writeTree_']['get'](_0x440994['path'])['getChild'](F(_0x440994['path'],_0x1e2b34)):null;}function ar(_0x2a8648){const _0x44f086=[],_0x5ca6e2=_0x2a8648['writeTree_']['value'];return _0x5ca6e2!=null?_0x5ca6e2['isLeafNode']()||_0x5ca6e2['forEachChild'](R,(_0x29ce30,_0x28b355)=>{_0x44f086['push'](new E(_0x29ce30,_0x28b355));}):_0x2a8648['writeTree_']['children']['inorderTraversal']((_0x1fce6f,_0x16db21)=>{_0x16db21['value']!=null&&_0x44f086['push'](new E(_0x1fce6f,_0x16db21['value']));}),_0x44f086;}function Ee(_0x2ef136,_0x4cfa80){if(v(_0x4cfa80))return _0x2ef136;{const _0x4afe80=ze(_0x2ef136,_0x4cfa80);return _0x4afe80!=null?new K(new b(_0x4afe80)):new K(_0x2ef136['writeTree_']['subtree'](_0x4cfa80));}}function Ai(_0x25a9b1){return _0x25a9b1['writeTree_']['isEmpty']();}function at(_0x3d14b4,_0x520984){return Uo(w(),_0x3d14b4['writeTree_'],_0x520984);}function Uo(_0x502689,_0x52a501,_0x12d077){if(_0x52a501['value']!=null)return _0x12d077['updateChild'](_0x502689,_0x52a501['value']);{let _0x4d65a4=null;return _0x52a501['children']['inorderTraversal']((_0x549d9f,_0x57ec1b)=>{_0x549d9f==='.priority'?(f(_0x57ec1b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4d65a4=_0x57ec1b['value']):_0x12d077=Uo(k(_0x502689,_0x549d9f),_0x57ec1b,_0x12d077);}),!_0x12d077['getChild'](_0x502689)['isEmpty']()&&_0x4d65a4!==null&&(_0x12d077=_0x12d077['updateChild'](k(_0x502689,'.priority'),_0x4d65a4)),_0x12d077;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x44610a,_0x4e49b8){return Ho(_0x4e49b8,_0x44610a);}function lu(_0x597954,_0x357c94,_0x3462f9,_0x42d041,_0x14863a){f(_0x42d041>_0x597954['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x14863a===void 0x0&&(_0x14863a=!0x0),_0x597954['allWrites']['push']({'path':_0x357c94,'snap':_0x3462f9,'writeId':_0x42d041,'visible':_0x14863a}),_0x14863a&&(_0x597954['visibleWrites']=At(_0x597954['visibleWrites'],_0x357c94,_0x3462f9)),_0x597954['lastWriteId']=_0x42d041;}function hu(_0x16c67c,_0x49e308,_0x20d92c,_0x1ffe4c){f(_0x1ffe4c>_0x16c67c['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x16c67c['allWrites']['push']({'path':_0x49e308,'children':_0x20d92c,'writeId':_0x1ffe4c,'visible':!0x0}),_0x16c67c['visibleWrites']=bi(_0x16c67c['visibleWrites'],_0x49e308,_0x20d92c),_0x16c67c['lastWriteId']=_0x1ffe4c;}function uu(_0x146e19,_0x589dda){for(let _0x59ffd1=0x0;_0x59ffd1<_0x146e19['allWrites']['length'];_0x59ffd1++){const _0x52c905=_0x146e19['allWrites'][_0x59ffd1];if(_0x52c905['writeId']===_0x589dda)return _0x52c905;}return null;}function du(_0x373fd0,_0x37f81c){const _0x31f705=_0x373fd0['allWrites']['findIndex'](_0x1b2a75=>_0x1b2a75['writeId']===_0x37f81c);f(_0x31f705>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x17af6f=_0x373fd0['allWrites'][_0x31f705];_0x373fd0['allWrites']['splice'](_0x31f705,0x1);let _0x3a7d5b=_0x17af6f['visible'],_0x8bddf2=!0x1,_0x34fecc=_0x373fd0['allWrites']['length']-0x1;for(;_0x3a7d5b&&_0x34fecc>=0x0;){const _0x2fc6e6=_0x373fd0['allWrites'][_0x34fecc];_0x2fc6e6['visible']&&(_0x34fecc>=_0x31f705&&fu(_0x2fc6e6,_0x17af6f['path'])?_0x3a7d5b=!0x1:G(_0x17af6f['path'],_0x2fc6e6['path'])&&(_0x8bddf2=!0x0)),_0x34fecc--;}if(_0x3a7d5b){if(_0x8bddf2)return pu(_0x373fd0),!0x0;if(_0x17af6f['snap'])_0x373fd0['visibleWrites']=or(_0x373fd0['visibleWrites'],_0x17af6f['path']);else{const _0x1a3c2f=_0x17af6f['children'];x(_0x1a3c2f,_0xdcdc14=>{_0x373fd0['visibleWrites']=or(_0x373fd0['visibleWrites'],k(_0x17af6f['path'],_0xdcdc14));});}return!0x0;}else return!0x1;}function fu(_0x49671f,_0x35fc9d){if(_0x49671f['snap'])return G(_0x49671f['path'],_0x35fc9d);for(const _0xe921f9 in _0x49671f['children'])if(_0x49671f['children']['hasOwnProperty'](_0xe921f9)&&G(k(_0x49671f['path'],_0xe921f9),_0x35fc9d))return!0x0;return!0x1;}function pu(_0x4e06cf){_0x4e06cf['visibleWrites']=Wo(_0x4e06cf['allWrites'],_u,w()),_0x4e06cf['allWrites']['length']>0x0?_0x4e06cf['lastWriteId']=_0x4e06cf['allWrites'][_0x4e06cf['allWrites']['length']-0x1]['writeId']:_0x4e06cf['lastWriteId']=-0x1;}function _u(_0x14d8a8){return _0x14d8a8['visible'];}function Wo(_0x404499,_0x13e40a,_0x56615c){let _0x3df870=K['empty']();for(let _0x29a770=0x0;_0x29a770<_0x404499['length'];++_0x29a770){const _0x171a9b=_0x404499[_0x29a770];if(_0x13e40a(_0x171a9b)){const _0x53f436=_0x171a9b['path'];let _0x4b7063;if(_0x171a9b['snap'])G(_0x56615c,_0x53f436)?(_0x4b7063=F(_0x56615c,_0x53f436),_0x3df870=At(_0x3df870,_0x4b7063,_0x171a9b['snap'])):G(_0x53f436,_0x56615c)&&(_0x4b7063=F(_0x53f436,_0x56615c),_0x3df870=At(_0x3df870,w(),_0x171a9b['snap']['getChild'](_0x4b7063)));else{if(_0x171a9b['children']){if(G(_0x56615c,_0x53f436))_0x4b7063=F(_0x56615c,_0x53f436),_0x3df870=bi(_0x3df870,_0x4b7063,_0x171a9b['children']);else{if(G(_0x53f436,_0x56615c)){if(_0x4b7063=F(_0x53f436,_0x56615c),v(_0x4b7063))_0x3df870=bi(_0x3df870,w(),_0x171a9b['children']);else{const _0x4a3099=Le(_0x171a9b['children'],y(_0x4b7063));if(_0x4a3099){const _0x622846=_0x4a3099['getChild'](S(_0x4b7063));_0x3df870=At(_0x3df870,w(),_0x622846);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3df870;}function Bo(_0x1974b4,_0x4f39c6,_0x23134f,_0x52a47c,_0x1cbea1){if(!_0x52a47c&&!_0x1cbea1){const _0x577799=ze(_0x1974b4['visibleWrites'],_0x4f39c6);if(_0x577799!=null)return _0x577799;{const _0x8da91e=Ee(_0x1974b4['visibleWrites'],_0x4f39c6);if(Ai(_0x8da91e))return _0x23134f;if(_0x23134f==null&&!Ri(_0x8da91e,w()))return null;{const _0x537636=_0x23134f||g['EMPTY_NODE'];return at(_0x8da91e,_0x537636);}}}else{const _0x4523f7=Ee(_0x1974b4['visibleWrites'],_0x4f39c6);if(!_0x1cbea1&&Ai(_0x4523f7))return _0x23134f;if(!_0x1cbea1&&_0x23134f==null&&!Ri(_0x4523f7,w()))return null;{const _0x199318=function(_0x1c0d9a){return(_0x1c0d9a['visible']||_0x1cbea1)&&(!_0x52a47c||!~_0x52a47c['indexOf'](_0x1c0d9a['writeId']))&&(G(_0x1c0d9a['path'],_0x4f39c6)||G(_0x4f39c6,_0x1c0d9a['path']));},_0x1e88b5=Wo(_0x1974b4['allWrites'],_0x199318,_0x4f39c6),_0x24416a=_0x23134f||g['EMPTY_NODE'];return at(_0x1e88b5,_0x24416a);}}}function gu(_0x5cebf2,_0x319633,_0x5b4f07){let _0x4053f3=g['EMPTY_NODE'];const _0x492c4a=ze(_0x5cebf2['visibleWrites'],_0x319633);if(_0x492c4a)return _0x492c4a['isLeafNode']()||_0x492c4a['forEachChild'](R,(_0x33e9c5,_0x259829)=>{_0x4053f3=_0x4053f3['updateImmediateChild'](_0x33e9c5,_0x259829);}),_0x4053f3;if(_0x5b4f07){const _0x2ef2e0=Ee(_0x5cebf2['visibleWrites'],_0x319633);return _0x5b4f07['forEachChild'](R,(_0x5aae65,_0x3142db)=>{const _0x397c63=at(Ee(_0x2ef2e0,new C(_0x5aae65)),_0x3142db);_0x4053f3=_0x4053f3['updateImmediateChild'](_0x5aae65,_0x397c63);}),ar(_0x2ef2e0)['forEach'](_0x2835ca=>{_0x4053f3=_0x4053f3['updateImmediateChild'](_0x2835ca['name'],_0x2835ca['node']);}),_0x4053f3;}else{const _0x324f42=Ee(_0x5cebf2['visibleWrites'],_0x319633);return ar(_0x324f42)['forEach'](_0x580bbc=>{_0x4053f3=_0x4053f3['updateImmediateChild'](_0x580bbc['name'],_0x580bbc['node']);}),_0x4053f3;}}function mu(_0x21372c,_0x2dcc16,_0x35ff3e,_0x5b9abe,_0x3fe775){f(_0x5b9abe||_0x3fe775,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2e6965=k(_0x2dcc16,_0x35ff3e);if(Ri(_0x21372c['visibleWrites'],_0x2e6965))return null;{const _0x337e99=Ee(_0x21372c['visibleWrites'],_0x2e6965);return Ai(_0x337e99)?_0x3fe775['getChild'](_0x35ff3e):at(_0x337e99,_0x3fe775['getChild'](_0x35ff3e));}}function yu(_0x50f06d,_0x9c6ef0,_0x41f242,_0x4e7230){const _0x1d8ee3=k(_0x9c6ef0,_0x41f242),_0x498adb=ze(_0x50f06d['visibleWrites'],_0x1d8ee3);if(_0x498adb!=null)return _0x498adb;if(_0x4e7230['isCompleteForChild'](_0x41f242)){const _0x31a9f0=Ee(_0x50f06d['visibleWrites'],_0x1d8ee3);return at(_0x31a9f0,_0x4e7230['getNode']()['getImmediateChild'](_0x41f242));}else return null;}function vu(_0x1a9612,_0x4f7be5){return ze(_0x1a9612['visibleWrites'],_0x4f7be5);}function Eu(_0x5156a9,_0x42ccc1,_0x537d47,_0x46a9e9,_0x35ef1b,_0x69c821,_0x147e52){let _0x5e7614;const _0x510ed1=Ee(_0x5156a9['visibleWrites'],_0x42ccc1),_0x529f0a=ze(_0x510ed1,w());if(_0x529f0a!=null)_0x5e7614=_0x529f0a;else{if(_0x537d47!=null)_0x5e7614=at(_0x510ed1,_0x537d47);else return[];}if(_0x5e7614=_0x5e7614['withIndex'](_0x147e52),!_0x5e7614['isEmpty']()&&!_0x5e7614['isLeafNode']()){const _0x884982=[],_0x59743b=_0x147e52['getCompare'](),_0x5d0f5b=_0x69c821?_0x5e7614['getReverseIteratorFrom'](_0x46a9e9,_0x147e52):_0x5e7614['getIteratorFrom'](_0x46a9e9,_0x147e52);let _0x53e52b=_0x5d0f5b['getNext']();for(;_0x53e52b&&_0x884982['length']<_0x35ef1b;)_0x59743b(_0x53e52b,_0x46a9e9)!==0x0&&_0x884982['push'](_0x53e52b),_0x53e52b=_0x5d0f5b['getNext']();return _0x884982;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x118d1e,_0x16ba73,_0x326ede,_0xf5ecc2){return Bo(_0x118d1e['writeTree'],_0x118d1e['treePath'],_0x16ba73,_0x326ede,_0xf5ecc2);}function is(_0x54dc02,_0x2fc21d){return gu(_0x54dc02['writeTree'],_0x54dc02['treePath'],_0x2fc21d);}function cr(_0x3ea91a,_0x904ed,_0x4c8f9a,_0x19d7dd){return mu(_0x3ea91a['writeTree'],_0x3ea91a['treePath'],_0x904ed,_0x4c8f9a,_0x19d7dd);}function Tn(_0x19827c,_0xfa189c){return vu(_0x19827c['writeTree'],k(_0x19827c['treePath'],_0xfa189c));}function wu(_0x2ae118,_0x6c5171,_0x4a5e30,_0x30c8ee,_0x5c1483,_0x3400a1){return Eu(_0x2ae118['writeTree'],_0x2ae118['treePath'],_0x6c5171,_0x4a5e30,_0x30c8ee,_0x5c1483,_0x3400a1);}function ss(_0x53d305,_0x1ae4e4,_0x52578f){return yu(_0x53d305['writeTree'],_0x53d305['treePath'],_0x1ae4e4,_0x52578f);}function Vo(_0x1881f7,_0x41bc6e){return Ho(k(_0x1881f7['treePath'],_0x41bc6e),_0x1881f7['writeTree']);}function Ho(_0x35037a,_0x7d837f){return{'treePath':_0x35037a,'writeTree':_0x7d837f};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x720a59){const _0x36c9fe=_0x720a59['type'],_0x482599=_0x720a59['childName'];f(_0x36c9fe==='child_added'||_0x36c9fe==='child_changed'||_0x36c9fe==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x482599!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4dc3a0=this['changeMap']['get'](_0x482599);if(_0x4dc3a0){const _0x481068=_0x4dc3a0['type'];if(_0x36c9fe==='child_added'&&_0x481068==='child_removed')this['changeMap']['set'](_0x482599,xt(_0x482599,_0x720a59['snapshotNode'],_0x4dc3a0['snapshotNode']));else{if(_0x36c9fe==='child_removed'&&_0x481068==='child_added')this['changeMap']['delete'](_0x482599);else{if(_0x36c9fe==='child_removed'&&_0x481068==='child_changed')this['changeMap']['set'](_0x482599,Lt(_0x482599,_0x4dc3a0['oldSnap']));else{if(_0x36c9fe==='child_changed'&&_0x481068==='child_added')this['changeMap']['set'](_0x482599,rt(_0x482599,_0x720a59['snapshotNode']));else{if(_0x36c9fe==='child_changed'&&_0x481068==='child_changed')this['changeMap']['set'](_0x482599,xt(_0x482599,_0x720a59['snapshotNode'],_0x4dc3a0['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x720a59+'\x20occurred\x20after\x20'+_0x4dc3a0);}}}}}else this['changeMap']['set'](_0x482599,_0x720a59);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3f0c9b){return null;}['getChildAfterChild'](_0x5191e4,_0x245a79,_0x5d26a4){return null;}}const $o=new Tu();class rs{constructor(_0x4ef558,_0x4e09cc,_0x835acf=null){this['writes_']=_0x4ef558,this['viewCache_']=_0x4e09cc,this['optCompleteServerCache_']=_0x835acf;}['getCompleteChild'](_0x409a2d){const _0x48149f=this['viewCache_']['eventCache'];if(_0x48149f['isCompleteForChild'](_0x409a2d))return _0x48149f['getNode']()['getImmediateChild'](_0x409a2d);{const _0x1ad206=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x409a2d,_0x1ad206);}}['getChildAfterChild'](_0x2e2106,_0x1f3b22,_0x1441e7){const _0x3cd71f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x2d5e97=wu(this['writes_'],_0x3cd71f,_0x1f3b22,0x1,_0x1441e7,_0x2e2106);return _0x2d5e97['length']===0x0?null:_0x2d5e97[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3b39a9){return{'filter':_0x3b39a9};}function bu(_0x428bc9,_0x35c4f8){f(_0x35c4f8['eventCache']['getNode']()['isIndexed'](_0x428bc9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x35c4f8['serverCache']['getNode']()['isIndexed'](_0x428bc9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0xbfd2d8,_0x151324,_0x1a8118,_0x5dfef6,_0x1e124c){const _0x5ec542=new Cu();let _0x322cf7,_0x8ea4f0;if(_0x1a8118['type']===z['OVERWRITE']){const _0x50c386=_0x1a8118;_0x50c386['source']['fromUser']?_0x322cf7=ki(_0xbfd2d8,_0x151324,_0x50c386['path'],_0x50c386['snap'],_0x5dfef6,_0x1e124c,_0x5ec542):(f(_0x50c386['source']['fromServer'],'Unknown\x20source.'),_0x8ea4f0=_0x50c386['source']['tagged']||_0x151324['serverCache']['isFiltered']()&&!v(_0x50c386['path']),_0x322cf7=Sn(_0xbfd2d8,_0x151324,_0x50c386['path'],_0x50c386['snap'],_0x5dfef6,_0x1e124c,_0x8ea4f0,_0x5ec542));}else{if(_0x1a8118['type']===z['MERGE']){const _0x32094c=_0x1a8118;_0x32094c['source']['fromUser']?_0x322cf7=ku(_0xbfd2d8,_0x151324,_0x32094c['path'],_0x32094c['children'],_0x5dfef6,_0x1e124c,_0x5ec542):(f(_0x32094c['source']['fromServer'],'Unknown\x20source.'),_0x8ea4f0=_0x32094c['source']['tagged']||_0x151324['serverCache']['isFiltered'](),_0x322cf7=Pi(_0xbfd2d8,_0x151324,_0x32094c['path'],_0x32094c['children'],_0x5dfef6,_0x1e124c,_0x8ea4f0,_0x5ec542));}else{if(_0x1a8118['type']===z['ACK_USER_WRITE']){const _0x46cfd1=_0x1a8118;_0x46cfd1['revert']?_0x322cf7=Ou(_0xbfd2d8,_0x151324,_0x46cfd1['path'],_0x5dfef6,_0x1e124c,_0x5ec542):_0x322cf7=Pu(_0xbfd2d8,_0x151324,_0x46cfd1['path'],_0x46cfd1['affectedTree'],_0x5dfef6,_0x1e124c,_0x5ec542);}else{if(_0x1a8118['type']===z['LISTEN_COMPLETE'])_0x322cf7=Nu(_0xbfd2d8,_0x151324,_0x1a8118['path'],_0x5dfef6,_0x5ec542);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1a8118['type']);}}}const _0x13ad7e=_0x5ec542['getChanges']();return Au(_0x151324,_0x322cf7,_0x13ad7e),{'viewCache':_0x322cf7,'changes':_0x13ad7e};}function Au(_0x187370,_0x41601d,_0x364e99){const _0x5c11e2=_0x41601d['eventCache'];if(_0x5c11e2['isFullyInitialized']()){const _0x181780=_0x5c11e2['getNode']()['isLeafNode']()||_0x5c11e2['getNode']()['isEmpty'](),_0x350a30=wn(_0x187370);(_0x364e99['length']>0x0||!_0x187370['eventCache']['isFullyInitialized']()||_0x181780&&!_0x5c11e2['getNode']()['equals'](_0x350a30)||!_0x5c11e2['getNode']()['getPriority']()['equals'](_0x350a30['getPriority']()))&&_0x364e99['push'](Lo(wn(_0x41601d)));}}function Go(_0x76ca10,_0x3bccdf,_0x139b6d,_0x57e789,_0x5ac82b,_0x22338e){const _0x4570f0=_0x3bccdf['eventCache'];if(Tn(_0x57e789,_0x139b6d)!=null)return _0x3bccdf;{let _0x4db537,_0x5976ad;if(v(_0x139b6d)){if(f(_0x3bccdf['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3bccdf['serverCache']['isFiltered']()){const _0x1b78af=Ve(_0x3bccdf),_0x5ce303=_0x1b78af instanceof g?_0x1b78af:g['EMPTY_NODE'],_0x5f24c0=is(_0x57e789,_0x5ce303);_0x4db537=_0x76ca10['filter']['updateFullNode'](_0x3bccdf['eventCache']['getNode'](),_0x5f24c0,_0x22338e);}else{const _0x36f187=Cn(_0x57e789,Ve(_0x3bccdf));_0x4db537=_0x76ca10['filter']['updateFullNode'](_0x3bccdf['eventCache']['getNode'](),_0x36f187,_0x22338e);}}else{const _0x2aba84=y(_0x139b6d);if(_0x2aba84==='.priority'){f(Ce(_0x139b6d)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3b8e30=_0x4570f0['getNode']();_0x5976ad=_0x3bccdf['serverCache']['getNode']();const _0x43e616=cr(_0x57e789,_0x139b6d,_0x3b8e30,_0x5976ad);_0x43e616!=null?_0x4db537=_0x76ca10['filter']['updatePriority'](_0x3b8e30,_0x43e616):_0x4db537=_0x4570f0['getNode']();}else{const _0x4901ed=S(_0x139b6d);let _0x489c6a;if(_0x4570f0['isCompleteForChild'](_0x2aba84)){_0x5976ad=_0x3bccdf['serverCache']['getNode']();const _0x1f78b1=cr(_0x57e789,_0x139b6d,_0x4570f0['getNode'](),_0x5976ad);_0x1f78b1!=null?_0x489c6a=_0x4570f0['getNode']()['getImmediateChild'](_0x2aba84)['updateChild'](_0x4901ed,_0x1f78b1):_0x489c6a=_0x4570f0['getNode']()['getImmediateChild'](_0x2aba84);}else _0x489c6a=ss(_0x57e789,_0x2aba84,_0x3bccdf['serverCache']);_0x489c6a!=null?_0x4db537=_0x76ca10['filter']['updateChild'](_0x4570f0['getNode'](),_0x2aba84,_0x489c6a,_0x4901ed,_0x5ac82b,_0x22338e):_0x4db537=_0x4570f0['getNode']();}}return Rt(_0x3bccdf,_0x4db537,_0x4570f0['isFullyInitialized']()||v(_0x139b6d),_0x76ca10['filter']['filtersNodes']());}}function Sn(_0x4357e9,_0xc64fc4,_0x3e830f,_0xe86b4,_0x2df9c4,_0x40fe9e,_0x1417d1,_0x2c7107){const _0x5121b7=_0xc64fc4['serverCache'];let _0x1bda13;const _0x2e824a=_0x1417d1?_0x4357e9['filter']:_0x4357e9['filter']['getIndexedFilter']();if(v(_0x3e830f))_0x1bda13=_0x2e824a['updateFullNode'](_0x5121b7['getNode'](),_0xe86b4,null);else{if(_0x2e824a['filtersNodes']()&&!_0x5121b7['isFiltered']()){const _0x20379c=_0x5121b7['getNode']()['updateChild'](_0x3e830f,_0xe86b4);_0x1bda13=_0x2e824a['updateFullNode'](_0x5121b7['getNode'](),_0x20379c,null);}else{const _0x30426f=y(_0x3e830f);if(!_0x5121b7['isCompleteForPath'](_0x3e830f)&&Ce(_0x3e830f)>0x1)return _0xc64fc4;const _0x1879eb=S(_0x3e830f),_0x5ba254=_0x5121b7['getNode']()['getImmediateChild'](_0x30426f)['updateChild'](_0x1879eb,_0xe86b4);_0x30426f==='.priority'?_0x1bda13=_0x2e824a['updatePriority'](_0x5121b7['getNode'](),_0x5ba254):_0x1bda13=_0x2e824a['updateChild'](_0x5121b7['getNode'](),_0x30426f,_0x5ba254,_0x1879eb,$o,null);}}const _0x219eb6=Fo(_0xc64fc4,_0x1bda13,_0x5121b7['isFullyInitialized']()||v(_0x3e830f),_0x2e824a['filtersNodes']()),_0x480b2c=new rs(_0x2df9c4,_0x219eb6,_0x40fe9e);return Go(_0x4357e9,_0x219eb6,_0x3e830f,_0x2df9c4,_0x480b2c,_0x2c7107);}function ki(_0x122a15,_0x36be56,_0xe319a,_0x206b30,_0xae2a4b,_0x5125df,_0x371c48){const _0x55b67b=_0x36be56['eventCache'];let _0x5a03c2,_0x195d79;const _0x5ce9ed=new rs(_0xae2a4b,_0x36be56,_0x5125df);if(v(_0xe319a))_0x195d79=_0x122a15['filter']['updateFullNode'](_0x36be56['eventCache']['getNode'](),_0x206b30,_0x371c48),_0x5a03c2=Rt(_0x36be56,_0x195d79,!0x0,_0x122a15['filter']['filtersNodes']());else{const _0x33fe1b=y(_0xe319a);if(_0x33fe1b==='.priority')_0x195d79=_0x122a15['filter']['updatePriority'](_0x36be56['eventCache']['getNode'](),_0x206b30),_0x5a03c2=Rt(_0x36be56,_0x195d79,_0x55b67b['isFullyInitialized'](),_0x55b67b['isFiltered']());else{const _0x6db5c5=S(_0xe319a),_0x5e3043=_0x55b67b['getNode']()['getImmediateChild'](_0x33fe1b);let _0x52fb9c;if(v(_0x6db5c5))_0x52fb9c=_0x206b30;else{const _0x2f069c=_0x5ce9ed['getCompleteChild'](_0x33fe1b);_0x2f069c!=null?ji(_0x6db5c5)==='.priority'&&_0x2f069c['getChild'](Ro(_0x6db5c5))['isEmpty']()?_0x52fb9c=_0x2f069c:_0x52fb9c=_0x2f069c['updateChild'](_0x6db5c5,_0x206b30):_0x52fb9c=g['EMPTY_NODE'];}if(_0x5e3043['equals'](_0x52fb9c))_0x5a03c2=_0x36be56;else{const _0x1d0c4b=_0x122a15['filter']['updateChild'](_0x55b67b['getNode'](),_0x33fe1b,_0x52fb9c,_0x6db5c5,_0x5ce9ed,_0x371c48);_0x5a03c2=Rt(_0x36be56,_0x1d0c4b,_0x55b67b['isFullyInitialized'](),_0x122a15['filter']['filtersNodes']());}}}return _0x5a03c2;}function lr(_0x2e0f56,_0x1451fd){return _0x2e0f56['eventCache']['isCompleteForChild'](_0x1451fd);}function ku(_0x415a91,_0x3dc39d,_0x5f5382,_0xbae2d9,_0x1a1bb2,_0x3e69e4,_0x59ac83){let _0x121744=_0x3dc39d;return _0xbae2d9['foreach']((_0x3e6abe,_0x27f1f1)=>{const _0x4f3812=k(_0x5f5382,_0x3e6abe);lr(_0x3dc39d,y(_0x4f3812))&&(_0x121744=ki(_0x415a91,_0x121744,_0x4f3812,_0x27f1f1,_0x1a1bb2,_0x3e69e4,_0x59ac83));}),_0xbae2d9['foreach']((_0x7b8955,_0x306895)=>{const _0x44db82=k(_0x5f5382,_0x7b8955);lr(_0x3dc39d,y(_0x44db82))||(_0x121744=ki(_0x415a91,_0x121744,_0x44db82,_0x306895,_0x1a1bb2,_0x3e69e4,_0x59ac83));}),_0x121744;}function hr(_0x13d474,_0x328f9e,_0x3fcc21){return _0x3fcc21['foreach']((_0x42434e,_0x483bcf)=>{_0x328f9e=_0x328f9e['updateChild'](_0x42434e,_0x483bcf);}),_0x328f9e;}function Pi(_0x3a61f5,_0x580861,_0x916ed9,_0x51300c,_0x1407b0,_0x1fabd7,_0x5b89ee,_0x3a79bb){if(_0x580861['serverCache']['getNode']()['isEmpty']()&&!_0x580861['serverCache']['isFullyInitialized']())return _0x580861;let _0x1b984c=_0x580861,_0xb6d5b2;v(_0x916ed9)?_0xb6d5b2=_0x51300c:_0xb6d5b2=new b(null)['setTree'](_0x916ed9,_0x51300c);const _0x23b90b=_0x580861['serverCache']['getNode']();return _0xb6d5b2['children']['inorderTraversal']((_0x1cc057,_0x3e6ac5)=>{if(_0x23b90b['hasChild'](_0x1cc057)){const _0x14fc04=_0x580861['serverCache']['getNode']()['getImmediateChild'](_0x1cc057),_0x16329f=hr(_0x3a61f5,_0x14fc04,_0x3e6ac5);_0x1b984c=Sn(_0x3a61f5,_0x1b984c,new C(_0x1cc057),_0x16329f,_0x1407b0,_0x1fabd7,_0x5b89ee,_0x3a79bb);}}),_0xb6d5b2['children']['inorderTraversal']((_0x28b454,_0x2a2652)=>{const _0x31bedf=!_0x580861['serverCache']['isCompleteForChild'](_0x28b454)&&_0x2a2652['value']===null;if(!_0x23b90b['hasChild'](_0x28b454)&&!_0x31bedf){const _0x4eb93e=_0x580861['serverCache']['getNode']()['getImmediateChild'](_0x28b454),_0x478452=hr(_0x3a61f5,_0x4eb93e,_0x2a2652);_0x1b984c=Sn(_0x3a61f5,_0x1b984c,new C(_0x28b454),_0x478452,_0x1407b0,_0x1fabd7,_0x5b89ee,_0x3a79bb);}}),_0x1b984c;}function Pu(_0x44d34c,_0x345b0d,_0x19ee3f,_0x29f986,_0x48df37,_0x13b97f,_0x308a9e){if(Tn(_0x48df37,_0x19ee3f)!=null)return _0x345b0d;const _0x10df51=_0x345b0d['serverCache']['isFiltered'](),_0x531cc6=_0x345b0d['serverCache'];if(_0x29f986['value']!=null){if(v(_0x19ee3f)&&_0x531cc6['isFullyInitialized']()||_0x531cc6['isCompleteForPath'](_0x19ee3f))return Sn(_0x44d34c,_0x345b0d,_0x19ee3f,_0x531cc6['getNode']()['getChild'](_0x19ee3f),_0x48df37,_0x13b97f,_0x10df51,_0x308a9e);if(v(_0x19ee3f)){let _0x427a07=new b(null);return _0x531cc6['getNode']()['forEachChild'](ve,(_0x29ae8a,_0x5b09bc)=>{_0x427a07=_0x427a07['set'](new C(_0x29ae8a),_0x5b09bc);}),Pi(_0x44d34c,_0x345b0d,_0x19ee3f,_0x427a07,_0x48df37,_0x13b97f,_0x10df51,_0x308a9e);}else return _0x345b0d;}else{let _0x3feba6=new b(null);return _0x29f986['foreach']((_0x907b23,_0x409019)=>{const _0x1efb08=k(_0x19ee3f,_0x907b23);_0x531cc6['isCompleteForPath'](_0x1efb08)&&(_0x3feba6=_0x3feba6['set'](_0x907b23,_0x531cc6['getNode']()['getChild'](_0x1efb08)));}),Pi(_0x44d34c,_0x345b0d,_0x19ee3f,_0x3feba6,_0x48df37,_0x13b97f,_0x10df51,_0x308a9e);}}function Nu(_0x5e5b62,_0xbe437c,_0x254873,_0x1995d4,_0x507491){const _0x541c87=_0xbe437c['serverCache'],_0x205068=Fo(_0xbe437c,_0x541c87['getNode'](),_0x541c87['isFullyInitialized']()||v(_0x254873),_0x541c87['isFiltered']());return Go(_0x5e5b62,_0x205068,_0x254873,_0x1995d4,$o,_0x507491);}function Ou(_0x153892,_0x43a70c,_0x3bf9dc,_0x275ecd,_0x167af6,_0x189519){let _0x2ea34c;if(Tn(_0x275ecd,_0x3bf9dc)!=null)return _0x43a70c;{const _0x5b9963=new rs(_0x275ecd,_0x43a70c,_0x167af6),_0x324c5c=_0x43a70c['eventCache']['getNode']();let _0x208ade;if(v(_0x3bf9dc)||y(_0x3bf9dc)==='.priority'){let _0xbdf437;if(_0x43a70c['serverCache']['isFullyInitialized']())_0xbdf437=Cn(_0x275ecd,Ve(_0x43a70c));else{const _0x361f00=_0x43a70c['serverCache']['getNode']();f(_0x361f00 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xbdf437=is(_0x275ecd,_0x361f00);}_0xbdf437=_0xbdf437,_0x208ade=_0x153892['filter']['updateFullNode'](_0x324c5c,_0xbdf437,_0x189519);}else{const _0x59f875=y(_0x3bf9dc);let _0x11e044=ss(_0x275ecd,_0x59f875,_0x43a70c['serverCache']);_0x11e044==null&&_0x43a70c['serverCache']['isCompleteForChild'](_0x59f875)&&(_0x11e044=_0x324c5c['getImmediateChild'](_0x59f875)),_0x11e044!=null?_0x208ade=_0x153892['filter']['updateChild'](_0x324c5c,_0x59f875,_0x11e044,S(_0x3bf9dc),_0x5b9963,_0x189519):_0x43a70c['eventCache']['getNode']()['hasChild'](_0x59f875)?_0x208ade=_0x153892['filter']['updateChild'](_0x324c5c,_0x59f875,g['EMPTY_NODE'],S(_0x3bf9dc),_0x5b9963,_0x189519):_0x208ade=_0x324c5c,_0x208ade['isEmpty']()&&_0x43a70c['serverCache']['isFullyInitialized']()&&(_0x2ea34c=Cn(_0x275ecd,Ve(_0x43a70c)),_0x2ea34c['isLeafNode']()&&(_0x208ade=_0x153892['filter']['updateFullNode'](_0x208ade,_0x2ea34c,_0x189519)));}return _0x2ea34c=_0x43a70c['serverCache']['isFullyInitialized']()||Tn(_0x275ecd,w())!=null,Rt(_0x43a70c,_0x208ade,_0x2ea34c,_0x153892['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3c6e7c,_0x973477){this['query_']=_0x3c6e7c,this['eventRegistrations_']=[];const _0x2d6fae=this['query_']['_queryParams'],_0x1456a0=new Xi(_0x2d6fae['getIndex']()),_0x2e3eae=Kh(_0x2d6fae);this['processor_']=Su(_0x2e3eae);const _0x392360=_0x973477['serverCache'],_0xac850e=_0x973477['eventCache'],_0x1ee0ed=_0x1456a0['updateFullNode'](g['EMPTY_NODE'],_0x392360['getNode'](),null),_0x2ab6fd=_0x2e3eae['updateFullNode'](g['EMPTY_NODE'],_0xac850e['getNode'](),null),_0x38dca7=new Te(_0x1ee0ed,_0x392360['isFullyInitialized'](),_0x1456a0['filtersNodes']()),_0x4a70f9=new Te(_0x2ab6fd,_0xac850e['isFullyInitialized'](),_0x2e3eae['filtersNodes']());this['viewCache_']=Un(_0x4a70f9,_0x38dca7),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x4090de){return _0x4090de['viewCache_']['serverCache']['getNode']();}function Lu(_0x42736d){return wn(_0x42736d['viewCache_']);}function xu(_0x2e039d,_0x38186d){const _0x5bdbb9=Ve(_0x2e039d['viewCache_']);return _0x5bdbb9&&(_0x2e039d['query']['_queryParams']['loadsAllData']()||!v(_0x38186d)&&!_0x5bdbb9['getImmediateChild'](y(_0x38186d))['isEmpty']())?_0x5bdbb9['getChild'](_0x38186d):null;}function ur(_0x171ee8){return _0x171ee8['eventRegistrations_']['length']===0x0;}function Fu(_0x4b7afa,_0x3e20c4){_0x4b7afa['eventRegistrations_']['push'](_0x3e20c4);}function dr(_0x4a2db6,_0x199249,_0x330c86){const _0x3265fd=[];if(_0x330c86){f(_0x199249==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x81fc5a=_0x4a2db6['query']['_path'];_0x4a2db6['eventRegistrations_']['forEach'](_0xf6588e=>{const _0x54d219=_0xf6588e['createCancelEvent'](_0x330c86,_0x81fc5a);_0x54d219&&_0x3265fd['push'](_0x54d219);});}if(_0x199249){let _0x3d4bad=[];for(let _0x40f77b=0x0;_0x40f77b<_0x4a2db6['eventRegistrations_']['length'];++_0x40f77b){const _0x13094c=_0x4a2db6['eventRegistrations_'][_0x40f77b];if(!_0x13094c['matches'](_0x199249))_0x3d4bad['push'](_0x13094c);else{if(_0x199249['hasAnyCallback']()){_0x3d4bad=_0x3d4bad['concat'](_0x4a2db6['eventRegistrations_']['slice'](_0x40f77b+0x1));break;}}}_0x4a2db6['eventRegistrations_']=_0x3d4bad;}else _0x4a2db6['eventRegistrations_']=[];return _0x3265fd;}function fr(_0x288c87,_0x4ace08,_0x5377e7,_0x28ff88){_0x4ace08['type']===z['MERGE']&&_0x4ace08['source']['queryId']!==null&&(f(Ve(_0x288c87['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x288c87['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1794d0=_0x288c87['viewCache_'],_0x5a6195=Ru(_0x288c87['processor_'],_0x1794d0,_0x4ace08,_0x5377e7,_0x28ff88);return bu(_0x288c87['processor_'],_0x5a6195['viewCache']),f(_0x5a6195['viewCache']['serverCache']['isFullyInitialized']()||!_0x1794d0['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x288c87['viewCache_']=_0x5a6195['viewCache'],qo(_0x288c87,_0x5a6195['changes'],_0x5a6195['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5a3184,_0x24069a){const _0x926551=_0x5a3184['viewCache_']['eventCache'],_0x55a995=[];return _0x926551['getNode']()['isLeafNode']()||_0x926551['getNode']()['forEachChild'](R,(_0x269483,_0x2b0996)=>{_0x55a995['push'](rt(_0x269483,_0x2b0996));}),_0x926551['isFullyInitialized']()&&_0x55a995['push'](Lo(_0x926551['getNode']())),qo(_0x5a3184,_0x55a995,_0x926551['getNode'](),_0x24069a);}function qo(_0x29a4db,_0x3863a2,_0x13556f,_0x10696a){const _0x1b76b3=_0x10696a?[_0x10696a]:_0x29a4db['eventRegistrations_'];return ru(_0x29a4db['eventGenerator_'],_0x3863a2,_0x13556f,_0x1b76b3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x2b5bbd){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x2b5bbd;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1282b4){return _0x1282b4['views']['size']===0x0;}function os(_0x358f85,_0x4f0f5f,_0x2eee61,_0x18165f){const _0x11ce88=_0x4f0f5f['source']['queryId'];if(_0x11ce88!==null){const _0x366b4d=_0x358f85['views']['get'](_0x11ce88);return f(_0x366b4d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x366b4d,_0x4f0f5f,_0x2eee61,_0x18165f);}else{let _0x35fa99=[];for(const _0x51ddcc of _0x358f85['views']['values']())_0x35fa99=_0x35fa99['concat'](fr(_0x51ddcc,_0x4f0f5f,_0x2eee61,_0x18165f));return _0x35fa99;}}function jo(_0x11aa70,_0x34d414,_0x551e77,_0x694f6d,_0x3f66d6){const _0x241f0e=_0x34d414['_queryIdentifier'],_0x384bbc=_0x11aa70['views']['get'](_0x241f0e);if(!_0x384bbc){let _0x22027f=Cn(_0x551e77,_0x3f66d6?_0x694f6d:null),_0x10a803=!0x1;_0x22027f?_0x10a803=!0x0:_0x694f6d instanceof g?(_0x22027f=is(_0x551e77,_0x694f6d),_0x10a803=!0x1):(_0x22027f=g['EMPTY_NODE'],_0x10a803=!0x1);const _0xc66a14=Un(new Te(_0x22027f,_0x10a803,!0x1),new Te(_0x694f6d,_0x3f66d6,!0x1));return new Du(_0x34d414,_0xc66a14);}return _0x384bbc;}function Hu(_0x26bf59,_0x5bae60,_0x24e2b4,_0x5e0420,_0x3a2ff3,_0x4872b5){const _0x178b6d=jo(_0x26bf59,_0x5bae60,_0x5e0420,_0x3a2ff3,_0x4872b5);return _0x26bf59['views']['has'](_0x5bae60['_queryIdentifier'])||_0x26bf59['views']['set'](_0x5bae60['_queryIdentifier'],_0x178b6d),Fu(_0x178b6d,_0x24e2b4),Uu(_0x178b6d,_0x24e2b4);}function $u(_0x1b49a6,_0x564544,_0x257f16,_0x34914b){const _0x36ee36=_0x564544['_queryIdentifier'],_0x10b12a=[];let _0x103880=[];const _0x138ad0=Se(_0x1b49a6);if(_0x36ee36==='default'){for(const [_0x1378d8,_0x4bddc4]of _0x1b49a6['views']['entries']())_0x103880=_0x103880['concat'](dr(_0x4bddc4,_0x257f16,_0x34914b)),ur(_0x4bddc4)&&(_0x1b49a6['views']['delete'](_0x1378d8),_0x4bddc4['query']['_queryParams']['loadsAllData']()||_0x10b12a['push'](_0x4bddc4['query']));}else{const _0x86c9f1=_0x1b49a6['views']['get'](_0x36ee36);_0x86c9f1&&(_0x103880=_0x103880['concat'](dr(_0x86c9f1,_0x257f16,_0x34914b)),ur(_0x86c9f1)&&(_0x1b49a6['views']['delete'](_0x36ee36),_0x86c9f1['query']['_queryParams']['loadsAllData']()||_0x10b12a['push'](_0x86c9f1['query'])));}return _0x138ad0&&!Se(_0x1b49a6)&&_0x10b12a['push'](new(Bu())(_0x564544['_repo'],_0x564544['_path'])),{'removed':_0x10b12a,'events':_0x103880};}function Ko(_0x102be2){const _0x50833d=[];for(const _0x5c3621 of _0x102be2['views']['values']())_0x5c3621['query']['_queryParams']['loadsAllData']()||_0x50833d['push'](_0x5c3621);return _0x50833d;}function Ie(_0xd075c,_0x590b00){let _0x2594cb=null;for(const _0x5b7b40 of _0xd075c['views']['values']())_0x2594cb=_0x2594cb||xu(_0x5b7b40,_0x590b00);return _0x2594cb;}function Yo(_0x16fc22,_0x13e043){if(_0x13e043['_queryParams']['loadsAllData']())return Bn(_0x16fc22);{const _0x3acbcb=_0x13e043['_queryIdentifier'];return _0x16fc22['views']['get'](_0x3acbcb);}}function Qo(_0x32c5d5,_0x4cd60f){return Yo(_0x32c5d5,_0x4cd60f)!=null;}function Se(_0x3adfe6){return Bn(_0x3adfe6)!=null;}function Bn(_0x38e75f){for(const _0x846bf7 of _0x38e75f['views']['values']())if(_0x846bf7['query']['_queryParams']['loadsAllData']())return _0x846bf7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x35cd5d){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x35cd5d;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x52768c){this['listenProvider_']=_0x52768c,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x511841,_0x1bbdd7,_0xbc227d,_0x50ff9c,_0x27b804){return lu(_0x511841['pendingWriteTree_'],_0x1bbdd7,_0xbc227d,_0x50ff9c,_0x27b804),_0x27b804?_t(_0x511841,new Be(es(),_0x1bbdd7,_0xbc227d)):[];}function ju(_0xcbf226,_0x238ba4,_0x4a10e4,_0x4d0090){hu(_0xcbf226['pendingWriteTree_'],_0x238ba4,_0x4a10e4,_0x4d0090);const _0x189408=b['fromObject'](_0x4a10e4);return _t(_0xcbf226,new ot(es(),_0x238ba4,_0x189408));}function _e(_0x5c6844,_0x2f3b05,_0xf5b3e9=!0x1){const _0x3fb70b=uu(_0x5c6844['pendingWriteTree_'],_0x2f3b05);if(du(_0x5c6844['pendingWriteTree_'],_0x2f3b05)){let _0x2a80f0=new b(null);return _0x3fb70b['snap']!=null?_0x2a80f0=_0x2a80f0['set'](w(),!0x0):x(_0x3fb70b['children'],_0x373df5=>{_0x2a80f0=_0x2a80f0['set'](new C(_0x373df5),!0x0);}),_t(_0x5c6844,new In(_0x3fb70b['path'],_0x2a80f0,_0xf5b3e9));}else return[];}function Yt(_0x4c5598,_0x54c22c,_0x1adda6){return _t(_0x4c5598,new Be(ts(),_0x54c22c,_0x1adda6));}function Ku(_0x2d1fb9,_0x124fa9,_0x4622d3){const _0x3c545e=b['fromObject'](_0x4622d3);return _t(_0x2d1fb9,new ot(ts(),_0x124fa9,_0x3c545e));}function Yu(_0x28aaa9,_0x2067be){return _t(_0x28aaa9,new Ut(ts(),_0x2067be));}function Qu(_0x4ceb90,_0x426372,_0x12b5b3){const _0x5e300e=cs(_0x4ceb90,_0x12b5b3);if(_0x5e300e){const _0x1c4c2c=ls(_0x5e300e),_0x587dd0=_0x1c4c2c['path'],_0x27bb0f=_0x1c4c2c['queryId'],_0x30f434=F(_0x587dd0,_0x426372),_0x5707e4=new Ut(ns(_0x27bb0f),_0x30f434);return hs(_0x4ceb90,_0x587dd0,_0x5707e4);}else return[];}function An(_0x51be0f,_0x58f5cf,_0x1a59f4,_0x195ea8,_0x32fc5b=!0x1){const _0x2b4590=_0x58f5cf['_path'],_0xd382b5=_0x51be0f['syncPointTree_']['get'](_0x2b4590);let _0x2fe5b5=[];if(_0xd382b5&&(_0x58f5cf['_queryIdentifier']==='default'||Qo(_0xd382b5,_0x58f5cf))){const _0x3512f8=$u(_0xd382b5,_0x58f5cf,_0x1a59f4,_0x195ea8);Vu(_0xd382b5)&&(_0x51be0f['syncPointTree_']=_0x51be0f['syncPointTree_']['remove'](_0x2b4590));const _0x2b10ae=_0x3512f8['removed'];if(_0x2fe5b5=_0x3512f8['events'],!_0x32fc5b){const _0x178202=_0x2b10ae['findIndex'](_0x301787=>_0x301787['_queryParams']['loadsAllData']())!==-0x1,_0x193b90=_0x51be0f['syncPointTree_']['findOnPath'](_0x2b4590,(_0x57d7a6,_0x5ca321)=>Se(_0x5ca321));if(_0x178202&&!_0x193b90){const _0x52960e=_0x51be0f['syncPointTree_']['subtree'](_0x2b4590);if(!_0x52960e['isEmpty']()){const _0x5587cb=Zu(_0x52960e);for(let _0x4acbc3=0x0;_0x4acbc3<_0x5587cb['length'];++_0x4acbc3){const _0x5ece14=_0x5587cb[_0x4acbc3],_0x3bd2f6=_0x5ece14['query'],_0x218eb0=ea(_0x51be0f,_0x5ece14);_0x51be0f['listenProvider_']['startListening'](kt(_0x3bd2f6),Wt(_0x51be0f,_0x3bd2f6),_0x218eb0['hashFn'],_0x218eb0['onComplete']);}}}!_0x193b90&&_0x2b10ae['length']>0x0&&!_0x195ea8&&(_0x178202?_0x51be0f['listenProvider_']['stopListening'](kt(_0x58f5cf),null):_0x2b10ae['forEach'](_0x115603=>{const _0x25798a=_0x51be0f['queryToTagMap']['get'](Hn(_0x115603));_0x51be0f['listenProvider_']['stopListening'](kt(_0x115603),_0x25798a);}));}ed(_0x51be0f,_0x2b10ae);}return _0x2fe5b5;}function Jo(_0x640b49,_0x5d4e59,_0x28d15a,_0x4dbcc8){const _0x4dbede=cs(_0x640b49,_0x4dbcc8);if(_0x4dbede!=null){const _0x129b29=ls(_0x4dbede),_0x599199=_0x129b29['path'],_0x2cb50b=_0x129b29['queryId'],_0x5237ee=F(_0x599199,_0x5d4e59),_0x8b86b4=new Be(ns(_0x2cb50b),_0x5237ee,_0x28d15a);return hs(_0x640b49,_0x599199,_0x8b86b4);}else return[];}function Ju(_0x9d8555,_0x590798,_0x5898e2,_0x20fc0a){const _0x1d8b89=cs(_0x9d8555,_0x20fc0a);if(_0x1d8b89){const _0x3ac4cc=ls(_0x1d8b89),_0x5bf843=_0x3ac4cc['path'],_0x4a50f2=_0x3ac4cc['queryId'],_0x4b325c=F(_0x5bf843,_0x590798),_0x4c9e7c=b['fromObject'](_0x5898e2),_0xa608c=new ot(ns(_0x4a50f2),_0x4b325c,_0x4c9e7c);return hs(_0x9d8555,_0x5bf843,_0xa608c);}else return[];}function Ni(_0x4393d5,_0x544707,_0xf1f23d,_0x527a30=!0x1){const _0xe06c43=_0x544707['_path'];let _0x351d38=null,_0x3a2868=!0x1;_0x4393d5['syncPointTree_']['foreachOnPath'](_0xe06c43,(_0x460b70,_0x830532)=>{const _0x5e1422=F(_0x460b70,_0xe06c43);_0x351d38=_0x351d38||Ie(_0x830532,_0x5e1422),_0x3a2868=_0x3a2868||Se(_0x830532);});let _0x5c3012=_0x4393d5['syncPointTree_']['get'](_0xe06c43);_0x5c3012?(_0x3a2868=_0x3a2868||Se(_0x5c3012),_0x351d38=_0x351d38||Ie(_0x5c3012,w())):(_0x5c3012=new zo(),_0x4393d5['syncPointTree_']=_0x4393d5['syncPointTree_']['set'](_0xe06c43,_0x5c3012));let _0x2051b8;_0x351d38!=null?_0x2051b8=!0x0:(_0x2051b8=!0x1,_0x351d38=g['EMPTY_NODE'],_0x4393d5['syncPointTree_']['subtree'](_0xe06c43)['foreachChild']((_0x6370a,_0x5cf191)=>{const _0x471afe=Ie(_0x5cf191,w());_0x471afe&&(_0x351d38=_0x351d38['updateImmediateChild'](_0x6370a,_0x471afe));}));const _0x5ce633=Qo(_0x5c3012,_0x544707);if(!_0x5ce633&&!_0x544707['_queryParams']['loadsAllData']()){const _0x46d3a7=Hn(_0x544707);f(!_0x4393d5['queryToTagMap']['has'](_0x46d3a7),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x222dc7=td();_0x4393d5['queryToTagMap']['set'](_0x46d3a7,_0x222dc7),_0x4393d5['tagToQueryMap']['set'](_0x222dc7,_0x46d3a7);}const _0x512add=Wn(_0x4393d5['pendingWriteTree_'],_0xe06c43);let _0x5cef34=Hu(_0x5c3012,_0x544707,_0xf1f23d,_0x512add,_0x351d38,_0x2051b8);if(!_0x5ce633&&!_0x3a2868&&!_0x527a30){const _0x47e04f=Yo(_0x5c3012,_0x544707);_0x5cef34=_0x5cef34['concat'](nd(_0x4393d5,_0x544707,_0x47e04f));}return _0x5cef34;}function Vn(_0x31f292,_0x4c9f70,_0x4d3bae){const _0x1313f5=_0x31f292['pendingWriteTree_'],_0x5892e2=_0x31f292['syncPointTree_']['findOnPath'](_0x4c9f70,(_0x1238ea,_0x34f860)=>{const _0x4985e8=F(_0x1238ea,_0x4c9f70),_0x434a88=Ie(_0x34f860,_0x4985e8);if(_0x434a88)return _0x434a88;});return Bo(_0x1313f5,_0x4c9f70,_0x5892e2,_0x4d3bae,!0x0);}function Xu(_0x39211a,_0x3891a3){const _0x4d852b=_0x3891a3['_path'];let _0x350b7c=null;_0x39211a['syncPointTree_']['foreachOnPath'](_0x4d852b,(_0x562707,_0x528dd1)=>{const _0x56e480=F(_0x562707,_0x4d852b);_0x350b7c=_0x350b7c||Ie(_0x528dd1,_0x56e480);});let _0xafaa44=_0x39211a['syncPointTree_']['get'](_0x4d852b);_0xafaa44?_0x350b7c=_0x350b7c||Ie(_0xafaa44,w()):(_0xafaa44=new zo(),_0x39211a['syncPointTree_']=_0x39211a['syncPointTree_']['set'](_0x4d852b,_0xafaa44));const _0x21c200=_0x350b7c!=null,_0x383f56=_0x21c200?new Te(_0x350b7c,!0x0,!0x1):null,_0x129833=Wn(_0x39211a['pendingWriteTree_'],_0x3891a3['_path']),_0x19b02e=jo(_0xafaa44,_0x3891a3,_0x129833,_0x21c200?_0x383f56['getNode']():g['EMPTY_NODE'],_0x21c200);return Lu(_0x19b02e);}function _t(_0x44341e,_0x360e5e){return Xo(_0x360e5e,_0x44341e['syncPointTree_'],null,Wn(_0x44341e['pendingWriteTree_'],w()));}function Xo(_0x1640e8,_0x3a0783,_0x392851,_0x5bf42b){if(v(_0x1640e8['path']))return Zo(_0x1640e8,_0x3a0783,_0x392851,_0x5bf42b);{const _0x58f253=_0x3a0783['get'](w());_0x392851==null&&_0x58f253!=null&&(_0x392851=Ie(_0x58f253,w()));let _0x226fae=[];const _0x764cda=y(_0x1640e8['path']),_0x4cd538=_0x1640e8['operationForChild'](_0x764cda),_0x332101=_0x3a0783['children']['get'](_0x764cda);if(_0x332101&&_0x4cd538){const _0x579916=_0x392851?_0x392851['getImmediateChild'](_0x764cda):null,_0x870a37=Vo(_0x5bf42b,_0x764cda);_0x226fae=_0x226fae['concat'](Xo(_0x4cd538,_0x332101,_0x579916,_0x870a37));}return _0x58f253&&(_0x226fae=_0x226fae['concat'](os(_0x58f253,_0x1640e8,_0x5bf42b,_0x392851))),_0x226fae;}}function Zo(_0x2bdc69,_0x4536a4,_0x8da8b6,_0x2c5ecb){const _0x5d021a=_0x4536a4['get'](w());_0x8da8b6==null&&_0x5d021a!=null&&(_0x8da8b6=Ie(_0x5d021a,w()));let _0x2e009d=[];return _0x4536a4['children']['inorderTraversal']((_0x4523c6,_0xb7aec3)=>{const _0x51834c=_0x8da8b6?_0x8da8b6['getImmediateChild'](_0x4523c6):null,_0x54ed38=Vo(_0x2c5ecb,_0x4523c6),_0x378416=_0x2bdc69['operationForChild'](_0x4523c6);_0x378416&&(_0x2e009d=_0x2e009d['concat'](Zo(_0x378416,_0xb7aec3,_0x51834c,_0x54ed38)));}),_0x5d021a&&(_0x2e009d=_0x2e009d['concat'](os(_0x5d021a,_0x2bdc69,_0x2c5ecb,_0x8da8b6))),_0x2e009d;}function ea(_0x256ab4,_0x42c616){const _0x104ad9=_0x42c616['query'],_0x3bdff0=Wt(_0x256ab4,_0x104ad9);return{'hashFn':()=>(Mu(_0x42c616)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5486a3=>{if(_0x5486a3==='ok')return _0x3bdff0?Qu(_0x256ab4,_0x104ad9['_path'],_0x3bdff0):Yu(_0x256ab4,_0x104ad9['_path']);{const _0x35b0e9=Kl(_0x5486a3,_0x104ad9);return An(_0x256ab4,_0x104ad9,null,_0x35b0e9);}}};}function Wt(_0x389fa0,_0x4f0244){const _0x33de8a=Hn(_0x4f0244);return _0x389fa0['queryToTagMap']['get'](_0x33de8a);}function Hn(_0x5e7e22){return _0x5e7e22['_path']['toString']()+'$'+_0x5e7e22['_queryIdentifier'];}function cs(_0x1c1d1a,_0x4fd88f){return _0x1c1d1a['tagToQueryMap']['get'](_0x4fd88f);}function ls(_0x201185){const _0x3977e6=_0x201185['indexOf']('$');return f(_0x3977e6!==-0x1&&_0x3977e6<_0x201185['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x201185['substr'](_0x3977e6+0x1),'path':new C(_0x201185['substr'](0x0,_0x3977e6))};}function hs(_0x5e0ffe,_0x4f8deb,_0x2e91a6){const _0xa4ff8e=_0x5e0ffe['syncPointTree_']['get'](_0x4f8deb);f(_0xa4ff8e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x515f93=Wn(_0x5e0ffe['pendingWriteTree_'],_0x4f8deb);return os(_0xa4ff8e,_0x2e91a6,_0x515f93,null);}function Zu(_0x48b7a3){return _0x48b7a3['fold']((_0x3c7398,_0x5dec5a,_0x575da7)=>{if(_0x5dec5a&&Se(_0x5dec5a))return[Bn(_0x5dec5a)];{let _0x2337b4=[];return _0x5dec5a&&(_0x2337b4=Ko(_0x5dec5a)),x(_0x575da7,(_0x5989d0,_0x29c115)=>{_0x2337b4=_0x2337b4['concat'](_0x29c115);}),_0x2337b4;}});}function kt(_0x3c042a){return _0x3c042a['_queryParams']['loadsAllData']()&&!_0x3c042a['_queryParams']['isDefault']()?new(qu())(_0x3c042a['_repo'],_0x3c042a['_path']):_0x3c042a;}function ed(_0x10424b,_0x6efe51){for(let _0x53d70f=0x0;_0x53d70f<_0x6efe51['length'];++_0x53d70f){const _0x30189b=_0x6efe51[_0x53d70f];if(!_0x30189b['_queryParams']['loadsAllData']()){const _0x568357=Hn(_0x30189b),_0x57821c=_0x10424b['queryToTagMap']['get'](_0x568357);_0x10424b['queryToTagMap']['delete'](_0x568357),_0x10424b['tagToQueryMap']['delete'](_0x57821c);}}}function td(){return zu++;}function nd(_0x4ad7e0,_0x1f0bb7,_0x116005){const _0x5a545b=_0x1f0bb7['_path'],_0x3824e7=Wt(_0x4ad7e0,_0x1f0bb7),_0x391846=ea(_0x4ad7e0,_0x116005),_0x3f322b=_0x4ad7e0['listenProvider_']['startListening'](kt(_0x1f0bb7),_0x3824e7,_0x391846['hashFn'],_0x391846['onComplete']),_0x580d05=_0x4ad7e0['syncPointTree_']['subtree'](_0x5a545b);if(_0x3824e7)f(!Se(_0x580d05['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x39763a=_0x580d05['fold']((_0x59cf1e,_0x102485,_0xec2b8b)=>{if(!v(_0x59cf1e)&&_0x102485&&Se(_0x102485))return[Bn(_0x102485)['query']];{let _0x463f25=[];return _0x102485&&(_0x463f25=_0x463f25['concat'](Ko(_0x102485)['map'](_0x30fcc4=>_0x30fcc4['query']))),x(_0xec2b8b,(_0x21d90b,_0x437ba5)=>{_0x463f25=_0x463f25['concat'](_0x437ba5);}),_0x463f25;}});for(let _0x5431da=0x0;_0x5431da<_0x39763a['length'];++_0x5431da){const _0x3564a6=_0x39763a[_0x5431da];_0x4ad7e0['listenProvider_']['stopListening'](kt(_0x3564a6),Wt(_0x4ad7e0,_0x3564a6));}}return _0x3f322b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x4c0e1f){this['node_']=_0x4c0e1f;}['getImmediateChild'](_0x14cca1){const _0x2c4c0d=this['node_']['getImmediateChild'](_0x14cca1);return new us(_0x2c4c0d);}['node'](){return this['node_'];}}class ds{constructor(_0x587118,_0x459c7b){this['syncTree_']=_0x587118,this['path_']=_0x459c7b;}['getImmediateChild'](_0x593093){const _0xfa0c67=k(this['path_'],_0x593093);return new ds(this['syncTree_'],_0xfa0c67);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x463dbf){return _0x463dbf=_0x463dbf||{},_0x463dbf['timestamp']=_0x463dbf['timestamp']||new Date()['getTime'](),_0x463dbf;},_r=function(_0x565585,_0x40b442,_0x3b47b0){if(!_0x565585||typeof _0x565585!='object')return _0x565585;if(f('.sv'in _0x565585,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x565585['.sv']=='string')return sd(_0x565585['.sv'],_0x40b442,_0x3b47b0);if(typeof _0x565585['.sv']=='object')return rd(_0x565585['.sv'],_0x40b442);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x565585,null,0x2));},sd=function(_0xe6b278,_0x251e0d,_0x3d1a50){switch(_0xe6b278){case'timestamp':return _0x3d1a50['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xe6b278);}},rd=function(_0x5da79e,_0x5a1fb6,_0x381104){_0x5da79e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5da79e,null,0x2));const _0x78f882=_0x5da79e['increment'];typeof _0x78f882!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x78f882);const _0x1a8ff1=_0x5a1fb6['node']();if(f(_0x1a8ff1!==null&&typeof _0x1a8ff1<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1a8ff1['isLeafNode']())return _0x78f882;const _0x148170=_0x1a8ff1['getValue']();return typeof _0x148170!='number'?_0x78f882:_0x148170+_0x78f882;},ta=function(_0x24e3ee,_0x2e0915,_0x57f8ac,_0x5c229c){return ps(_0x2e0915,new ds(_0x57f8ac,_0x24e3ee),_0x5c229c);},fs=function(_0x37f514,_0x18b1c9,_0x5c86b3){return ps(_0x37f514,new us(_0x18b1c9),_0x5c86b3);};function ps(_0x4c9d9d,_0x11cf9b,_0x35f780){const _0x56d505=_0x4c9d9d['getPriority']()['val'](),_0x441509=_r(_0x56d505,_0x11cf9b['getImmediateChild']('.priority'),_0x35f780);let _0x2efef1;if(_0x4c9d9d['isLeafNode']()){const _0xab30c=_0x4c9d9d,_0x1c74e9=_r(_0xab30c['getValue'](),_0x11cf9b,_0x35f780);return _0x1c74e9!==_0xab30c['getValue']()||_0x441509!==_0xab30c['getPriority']()['val']()?new D(_0x1c74e9,A(_0x441509)):_0x4c9d9d;}else{const _0x222982=_0x4c9d9d;return _0x2efef1=_0x222982,_0x441509!==_0x222982['getPriority']()['val']()&&(_0x2efef1=_0x2efef1['updatePriority'](new D(_0x441509))),_0x222982['forEachChild'](R,(_0x10a737,_0x3634a5)=>{const _0x1bb6cf=ps(_0x3634a5,_0x11cf9b['getImmediateChild'](_0x10a737),_0x35f780);_0x1bb6cf!==_0x3634a5&&(_0x2efef1=_0x2efef1['updateImmediateChild'](_0x10a737,_0x1bb6cf));}),_0x2efef1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x36d6a1='',_0x398c57=null,_0x68d93e={'children':{},'childCount':0x0}){this['name']=_0x36d6a1,this['parent']=_0x398c57,this['node']=_0x68d93e;}}function $n(_0x3cf46a,_0x5626f6){let _0x122f3e=_0x5626f6 instanceof C?_0x5626f6:new C(_0x5626f6),_0x42d2cf=_0x3cf46a,_0x52148e=y(_0x122f3e);for(;_0x52148e!==null;){const _0x4cd622=Le(_0x42d2cf['node']['children'],_0x52148e)||{'children':{},'childCount':0x0};_0x42d2cf=new _s(_0x52148e,_0x42d2cf,_0x4cd622),_0x122f3e=S(_0x122f3e),_0x52148e=y(_0x122f3e);}return _0x42d2cf;}function je(_0x314519){return _0x314519['node']['value'];}function gs(_0x40656c,_0x44d9b1){_0x40656c['node']['value']=_0x44d9b1,Oi(_0x40656c);}function na(_0x52aa6a){return _0x52aa6a['node']['childCount']>0x0;}function od(_0x59b06a){return je(_0x59b06a)===void 0x0&&!na(_0x59b06a);}function Gn(_0x10a5db,_0x9de256){x(_0x10a5db['node']['children'],(_0xf22106,_0x2039bd)=>{_0x9de256(new _s(_0xf22106,_0x10a5db,_0x2039bd));});}function ia(_0xa41d8c,_0x22169b,_0x5a0947,_0x47e2f9){_0x5a0947&&_0x22169b(_0xa41d8c),Gn(_0xa41d8c,_0x5e24e8=>{ia(_0x5e24e8,_0x22169b,!0x0);});}function ad(_0x4c65f6,_0x2fe8e0,_0x119a52){let _0x175c5b=_0x4c65f6['parent'];for(;_0x175c5b!==null;){if(_0x2fe8e0(_0x175c5b))return!0x0;_0x175c5b=_0x175c5b['parent'];}return!0x1;}function Qt(_0x3ffeb2){return new C(_0x3ffeb2['parent']===null?_0x3ffeb2['name']:Qt(_0x3ffeb2['parent'])+'/'+_0x3ffeb2['name']);}function Oi(_0x41215a){_0x41215a['parent']!==null&&cd(_0x41215a['parent'],_0x41215a['name'],_0x41215a);}function cd(_0xba7c49,_0x693916,_0x55d221){const _0x26a258=od(_0x55d221),_0x39e971=Q(_0xba7c49['node']['children'],_0x693916);_0x26a258&&_0x39e971?(delete _0xba7c49['node']['children'][_0x693916],_0xba7c49['node']['childCount']--,Oi(_0xba7c49)):!_0x26a258&&!_0x39e971&&(_0xba7c49['node']['children'][_0x693916]=_0x55d221['node'],_0xba7c49['node']['childCount']++,Oi(_0xba7c49));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x18330d){return typeof _0x18330d=='string'&&_0x18330d['length']!==0x0&&!ld['test'](_0x18330d);},sa=function(_0x288589){return typeof _0x288589=='string'&&_0x288589['length']!==0x0&&!hd['test'](_0x288589);},ud=function(_0x4b97d0){return _0x4b97d0&&(_0x4b97d0=_0x4b97d0['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x4b97d0);},Bt=function(_0x4e60c8){return _0x4e60c8===null||typeof _0x4e60c8=='string'||typeof _0x4e60c8=='number'&&!xn(_0x4e60c8)||_0x4e60c8&&typeof _0x4e60c8=='object'&&Q(_0x4e60c8,'.sv');},He=function(_0x242b12,_0x42e483,_0x6e8d73,_0xc5cc20){_0xc5cc20&&_0x42e483===void 0x0||Jt(it(_0x242b12,'value'),_0x42e483,_0x6e8d73);},Jt=function(_0x3a2e96,_0x4efc8e,_0xf3d4d7){const _0x55b2f6=_0xf3d4d7 instanceof C?new Ah(_0xf3d4d7,_0x3a2e96):_0xf3d4d7;if(_0x4efc8e===void 0x0)throw new Error(_0x3a2e96+'contains\x20undefined\x20'+Oe(_0x55b2f6));if(typeof _0x4efc8e=='function')throw new Error(_0x3a2e96+'contains\x20a\x20function\x20'+Oe(_0x55b2f6)+'\x20with\x20contents\x20=\x20'+_0x4efc8e['toString']());if(xn(_0x4efc8e))throw new Error(_0x3a2e96+'contains\x20'+_0x4efc8e['toString']()+'\x20'+Oe(_0x55b2f6));if(typeof _0x4efc8e=='string'&&_0x4efc8e['length']>ui/0x3&&Ln(_0x4efc8e)>ui)throw new Error(_0x3a2e96+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x55b2f6)+'\x20(\x27'+_0x4efc8e['substring'](0x0,0x32)+'...\x27)');if(_0x4efc8e&&typeof _0x4efc8e=='object'){let _0x1a3ec2=!0x1,_0x36fbab=!0x1;if(x(_0x4efc8e,(_0x1cf8ab,_0x489308)=>{if(_0x1cf8ab==='.value')_0x1a3ec2=!0x0;else{if(_0x1cf8ab!=='.priority'&&_0x1cf8ab!=='.sv'&&(_0x36fbab=!0x0,!ms(_0x1cf8ab)))throw new Error(_0x3a2e96+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1cf8ab+')\x20'+Oe(_0x55b2f6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x55b2f6,_0x1cf8ab),Jt(_0x3a2e96,_0x489308,_0x55b2f6),Ph(_0x55b2f6);}),_0x1a3ec2&&_0x36fbab)throw new Error(_0x3a2e96+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x55b2f6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x153f55,_0x5f2a32){let _0x708cd5,_0xc6da53;for(_0x708cd5=0x0;_0x708cd5<_0x5f2a32['length'];_0x708cd5++){_0xc6da53=_0x5f2a32[_0x708cd5];const _0x18ade1=Mt(_0xc6da53);for(let _0x10c0b7=0x0;_0x10c0b7<_0x18ade1['length'];_0x10c0b7++)if(!(_0x18ade1[_0x10c0b7]==='.priority'&&_0x10c0b7===_0x18ade1['length']-0x1)){if(!ms(_0x18ade1[_0x10c0b7]))throw new Error(_0x153f55+'contains\x20an\x20invalid\x20key\x20('+_0x18ade1[_0x10c0b7]+')\x20in\x20path\x20'+_0xc6da53['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5f2a32['sort'](Rh);let _0x35a2ab=null;for(_0x708cd5=0x0;_0x708cd5<_0x5f2a32['length'];_0x708cd5++){if(_0xc6da53=_0x5f2a32[_0x708cd5],_0x35a2ab!==null&&G(_0x35a2ab,_0xc6da53))throw new Error(_0x153f55+'contains\x20a\x20path\x20'+_0x35a2ab['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xc6da53['toString']());_0x35a2ab=_0xc6da53;}},ra=function(_0xeef845,_0x197759,_0xa716d,_0x4830c2){const _0xb7e4b8=it(_0xeef845,'values');if(!(_0x197759&&typeof _0x197759=='object')||Array['isArray'](_0x197759))throw new Error(_0xb7e4b8+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x48e676=[];x(_0x197759,(_0x71241f,_0x254b1b)=>{const _0xd27a4e=new C(_0x71241f);if(Jt(_0xb7e4b8,_0x254b1b,k(_0xa716d,_0xd27a4e)),ji(_0xd27a4e)==='.priority'&&!Bt(_0x254b1b))throw new Error(_0xb7e4b8+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xd27a4e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x48e676['push'](_0xd27a4e);}),dd(_0xb7e4b8,_0x48e676);},fd=function(_0x13a741,_0x48a0a3,_0x127ff8){if(xn(_0x48a0a3))throw new Error(it(_0x13a741,'priority')+'is\x20'+_0x48a0a3['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x48a0a3))throw new Error(it(_0x13a741,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x4d88e0,_0x36cfc5,_0x548c2a,_0x86591a){if(!sa(_0x548c2a))throw new Error(it(_0x4d88e0,_0x36cfc5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x548c2a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x20c35d,_0x1d6e2b,_0xc14766,_0x277619){_0xc14766&&(_0xc14766=_0xc14766['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x20c35d,_0x1d6e2b,_0xc14766);},Me=function(_0x20e889,_0x42fd79){if(y(_0x42fd79)==='.info')throw new Error(_0x20e889+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x15dbd5,_0xf41de6){const _0x11795b=_0xf41de6['path']['toString']();if(typeof _0xf41de6['repoInfo']['host']!='string'||_0xf41de6['repoInfo']['host']['length']===0x0||!ms(_0xf41de6['repoInfo']['namespace'])&&_0xf41de6['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x11795b['length']!==0x0&&!ud(_0x11795b))throw new Error(it(_0x15dbd5,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x76c5b0,_0x3b1271){let _0x5635e5=null;for(let _0x34eace=0x0;_0x34eace<_0x3b1271['length'];_0x34eace++){const _0x49d622=_0x3b1271[_0x34eace],_0x12b392=_0x49d622['getPath']();_0x5635e5!==null&&!Ki(_0x12b392,_0x5635e5['path'])&&(_0x76c5b0['eventLists_']['push'](_0x5635e5),_0x5635e5=null),_0x5635e5===null&&(_0x5635e5={'events':[],'path':_0x12b392}),_0x5635e5['events']['push'](_0x49d622);}_0x5635e5&&_0x76c5b0['eventLists_']['push'](_0x5635e5);}function oa(_0x12f420,_0x4171ae,_0xbab037){qn(_0x12f420,_0xbab037),aa(_0x12f420,_0x5e221b=>Ki(_0x5e221b,_0x4171ae));}function V(_0x5b1701,_0x5ea0fd,_0x4fec4c){qn(_0x5b1701,_0x4fec4c),aa(_0x5b1701,_0x151f9d=>G(_0x151f9d,_0x5ea0fd)||G(_0x5ea0fd,_0x151f9d));}function aa(_0x59fa39,_0x149436){_0x59fa39['recursionDepth_']++;let _0x5b7879=!0x0;for(let _0x209924=0x0;_0x209924<_0x59fa39['eventLists_']['length'];_0x209924++){const _0x116f35=_0x59fa39['eventLists_'][_0x209924];if(_0x116f35){const _0x2a49af=_0x116f35['path'];_0x149436(_0x2a49af)?(md(_0x59fa39['eventLists_'][_0x209924]),_0x59fa39['eventLists_'][_0x209924]=null):_0x5b7879=!0x1;}}_0x5b7879&&(_0x59fa39['eventLists_']=[]),_0x59fa39['recursionDepth_']--;}function md(_0x2d253e){for(let _0x14aa16=0x0;_0x14aa16<_0x2d253e['events']['length'];_0x14aa16++){const _0xe1193b=_0x2d253e['events'][_0x14aa16];if(_0xe1193b!==null){_0x2d253e['events'][_0x14aa16]=null;const _0x1399dd=_0xe1193b['getEventRunner']();St&&L('event:\x20'+_0xe1193b['toString']()),ft(_0x1399dd);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x36cafa,_0x3c2432,_0x59dc67,_0x59d14d){this['repoInfo_']=_0x36cafa,this['forceRestClient_']=_0x3c2432,this['authTokenProvider_']=_0x59dc67,this['appCheckProvider_']=_0x59d14d,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x363010,_0x23463d,_0x325713){if(_0x363010['stats_']=qi(_0x363010['repoInfo_']),_0x363010['forceRestClient_']||Xl())_0x363010['server_']=new vn(_0x363010['repoInfo_'],(_0x27db72,_0x332c74,_0x99a40c,_0x1d15d2)=>{gr(_0x363010,_0x27db72,_0x332c74,_0x99a40c,_0x1d15d2);},_0x363010['authTokenProvider_'],_0x363010['appCheckProvider_']),setTimeout(()=>mr(_0x363010,!0x0),0x0);else{if(typeof _0x325713<'u'&&_0x325713!==null){if(typeof _0x325713!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x325713);}catch(_0x153042){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x153042);}}_0x363010['persistentConnection_']=new se(_0x363010['repoInfo_'],_0x23463d,(_0x15c337,_0xe55b24,_0x2e22e3,_0x4e10da)=>{gr(_0x363010,_0x15c337,_0xe55b24,_0x2e22e3,_0x4e10da);},_0x414ace=>{mr(_0x363010,_0x414ace);},_0x56beee=>{Id(_0x363010,_0x56beee);},_0x363010['authTokenProvider_'],_0x363010['appCheckProvider_'],_0x325713),_0x363010['server_']=_0x363010['persistentConnection_'];}_0x363010['authTokenProvider_']['addTokenChangeListener'](_0xfc95b3=>{_0x363010['server_']['refreshAuthToken'](_0xfc95b3);}),_0x363010['appCheckProvider_']['addTokenChangeListener'](_0x5e9163=>{_0x363010['server_']['refreshAppCheckToken'](_0x5e9163['token']);}),_0x363010['statsReporter_']=ih(_0x363010['repoInfo_'],()=>new iu(_0x363010['stats_'],_0x363010['server_'])),_0x363010['infoData_']=new Xh(),_0x363010['infoSyncTree_']=new pr({'startListening':(_0x27fd7e,_0x26c1c9,_0x611f6e,_0xb8cf49)=>{let _0xa89d7f=[];const _0x5a965d=_0x363010['infoData_']['getNode'](_0x27fd7e['_path']);return _0x5a965d['isEmpty']()||(_0xa89d7f=Yt(_0x363010['infoSyncTree_'],_0x27fd7e['_path'],_0x5a965d),setTimeout(()=>{_0xb8cf49('ok');},0x0)),_0xa89d7f;},'stopListening':()=>{}}),vs(_0x363010,'connected',!0x1),_0x363010['serverSyncTree_']=new pr({'startListening':(_0x3c5c60,_0x377800,_0x249421,_0x1e6b52)=>(_0x363010['server_']['listen'](_0x3c5c60,_0x249421,_0x377800,(_0x39c417,_0x118dda)=>{const _0x27a20=_0x1e6b52(_0x39c417,_0x118dda);V(_0x363010['eventQueue_'],_0x3c5c60['_path'],_0x27a20);}),[]),'stopListening':(_0x1603d9,_0x2c2815)=>{_0x363010['server_']['unlisten'](_0x1603d9,_0x2c2815);}});}function la(_0x43540a){const _0x136a54=_0x43540a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x136a54;}function Xt(_0x1c0f7f){return id({'timestamp':la(_0x1c0f7f)});}function gr(_0x19927c,_0x3bb53a,_0x1ece08,_0x29ba04,_0x2a49e5){_0x19927c['dataUpdateCount']++;const _0x49308b=new C(_0x3bb53a);_0x1ece08=_0x19927c['interceptServerDataCallback_']?_0x19927c['interceptServerDataCallback_'](_0x3bb53a,_0x1ece08):_0x1ece08;let _0x54d03a=[];if(_0x2a49e5){if(_0x29ba04){const _0x574400=_n(_0x1ece08,_0x371002=>A(_0x371002));_0x54d03a=Ju(_0x19927c['serverSyncTree_'],_0x49308b,_0x574400,_0x2a49e5);}else{const _0x2473f0=A(_0x1ece08);_0x54d03a=Jo(_0x19927c['serverSyncTree_'],_0x49308b,_0x2473f0,_0x2a49e5);}}else{if(_0x29ba04){const _0x34c0ea=_n(_0x1ece08,_0xda7443=>A(_0xda7443));_0x54d03a=Ku(_0x19927c['serverSyncTree_'],_0x49308b,_0x34c0ea);}else{const _0x518c72=A(_0x1ece08);_0x54d03a=Yt(_0x19927c['serverSyncTree_'],_0x49308b,_0x518c72);}}let _0x49a1a8=_0x49308b;_0x54d03a['length']>0x0&&(_0x49a1a8=ct(_0x19927c,_0x49308b)),V(_0x19927c['eventQueue_'],_0x49a1a8,_0x54d03a);}function mr(_0x5cc158,_0x3f9cf1){vs(_0x5cc158,'connected',_0x3f9cf1),_0x3f9cf1===!0x1&&Sd(_0x5cc158);}function Id(_0x59b0db,_0x31b71c){x(_0x31b71c,(_0xefb461,_0xcc8a71)=>{vs(_0x59b0db,_0xefb461,_0xcc8a71);});}function vs(_0x410162,_0x4e0e41,_0x40297a){const _0x2713e6=new C('/.info/'+_0x4e0e41),_0x3c1ee1=A(_0x40297a);_0x410162['infoData_']['updateSnapshot'](_0x2713e6,_0x3c1ee1);const _0x2ebdad=Yt(_0x410162['infoSyncTree_'],_0x2713e6,_0x3c1ee1);V(_0x410162['eventQueue_'],_0x2713e6,_0x2ebdad);}function zn(_0x667e67){return _0x667e67['nextWriteId_']++;}function wd(_0x473cfd,_0x52ba14,_0x4ad993){const _0x82ce60=Xu(_0x473cfd['serverSyncTree_'],_0x52ba14);return _0x82ce60!=null?Promise['resolve'](_0x82ce60):_0x473cfd['server_']['get'](_0x52ba14)['then'](_0x17bf86=>{const _0x39ede9=A(_0x17bf86)['withIndex'](_0x52ba14['_queryParams']['getIndex']());Ni(_0x473cfd['serverSyncTree_'],_0x52ba14,_0x4ad993,!0x0);let _0x1123b8;if(_0x52ba14['_queryParams']['loadsAllData']())_0x1123b8=Yt(_0x473cfd['serverSyncTree_'],_0x52ba14['_path'],_0x39ede9);else{const _0x2af954=Wt(_0x473cfd['serverSyncTree_'],_0x52ba14);_0x1123b8=Jo(_0x473cfd['serverSyncTree_'],_0x52ba14['_path'],_0x39ede9,_0x2af954);}return V(_0x473cfd['eventQueue_'],_0x52ba14['_path'],_0x1123b8),An(_0x473cfd['serverSyncTree_'],_0x52ba14,_0x4ad993,null,!0x0),_0x39ede9;},_0x356bd4=>(gt(_0x473cfd,'get\x20for\x20query\x20'+O(_0x52ba14)+'\x20failed:\x20'+_0x356bd4),Promise['reject'](new Error(_0x356bd4))));}function Cd(_0x55c9d8,_0x3070c9,_0x5e2e60,_0x2d45a8,_0x32bd75){gt(_0x55c9d8,'set',{'path':_0x3070c9['toString'](),'value':_0x5e2e60,'priority':_0x2d45a8});const _0x169082=Xt(_0x55c9d8),_0xb8b493=A(_0x5e2e60,_0x2d45a8),_0x211267=Vn(_0x55c9d8['serverSyncTree_'],_0x3070c9),_0x454cd9=fs(_0xb8b493,_0x211267,_0x169082),_0x9b9b32=zn(_0x55c9d8),_0x17d668=as(_0x55c9d8['serverSyncTree_'],_0x3070c9,_0x454cd9,_0x9b9b32,!0x0);qn(_0x55c9d8['eventQueue_'],_0x17d668),_0x55c9d8['server_']['put'](_0x3070c9['toString'](),_0xb8b493['val'](!0x0),(_0x5db023,_0x366d74)=>{const _0x5dbe37=_0x5db023==='ok';_0x5dbe37||U('set\x20at\x20'+_0x3070c9+'\x20failed:\x20'+_0x5db023);const _0x1e4421=_e(_0x55c9d8['serverSyncTree_'],_0x9b9b32,!_0x5dbe37);V(_0x55c9d8['eventQueue_'],_0x3070c9,_0x1e4421),be(_0x55c9d8,_0x32bd75,_0x5db023,_0x366d74);});const _0x1dbcc9=Is(_0x55c9d8,_0x3070c9);ct(_0x55c9d8,_0x1dbcc9),V(_0x55c9d8['eventQueue_'],_0x1dbcc9,[]);}function Td(_0x5d9a95,_0x20dd24,_0x1a48a1,_0x13a2f9){gt(_0x5d9a95,'update',{'path':_0x20dd24['toString'](),'value':_0x1a48a1});let _0x55ddcc=!0x0;const _0x2ae4fc=Xt(_0x5d9a95),_0x2501ca={};if(x(_0x1a48a1,(_0x44b883,_0x2c71ad)=>{_0x55ddcc=!0x1,_0x2501ca[_0x44b883]=ta(k(_0x20dd24,_0x44b883),A(_0x2c71ad),_0x5d9a95['serverSyncTree_'],_0x2ae4fc);}),_0x55ddcc)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x5d9a95,_0x13a2f9,'ok',void 0x0);else{const _0x1da17d=zn(_0x5d9a95),_0xc2fd27=ju(_0x5d9a95['serverSyncTree_'],_0x20dd24,_0x2501ca,_0x1da17d);qn(_0x5d9a95['eventQueue_'],_0xc2fd27),_0x5d9a95['server_']['merge'](_0x20dd24['toString'](),_0x1a48a1,(_0x5c27e2,_0x14017c)=>{const _0x22f761=_0x5c27e2==='ok';_0x22f761||U('update\x20at\x20'+_0x20dd24+'\x20failed:\x20'+_0x5c27e2);const _0x28d4ae=_e(_0x5d9a95['serverSyncTree_'],_0x1da17d,!_0x22f761),_0x19dbd7=_0x28d4ae['length']>0x0?ct(_0x5d9a95,_0x20dd24):_0x20dd24;V(_0x5d9a95['eventQueue_'],_0x19dbd7,_0x28d4ae),be(_0x5d9a95,_0x13a2f9,_0x5c27e2,_0x14017c);}),x(_0x1a48a1,_0xfdd5b0=>{const _0x517b62=Is(_0x5d9a95,k(_0x20dd24,_0xfdd5b0));ct(_0x5d9a95,_0x517b62);}),V(_0x5d9a95['eventQueue_'],_0x20dd24,[]);}}function Sd(_0x2d91c7){gt(_0x2d91c7,'onDisconnectEvents');const _0x4656fe=Xt(_0x2d91c7),_0x5d124f=En();Si(_0x2d91c7['onDisconnect_'],w(),(_0x46fdbd,_0x1a9695)=>{const _0x1fbe7b=ta(_0x46fdbd,_0x1a9695,_0x2d91c7['serverSyncTree_'],_0x4656fe);pt(_0x5d124f,_0x46fdbd,_0x1fbe7b);});let _0x185a8d=[];Si(_0x5d124f,w(),(_0x43ded1,_0x5029ec)=>{_0x185a8d=_0x185a8d['concat'](Yt(_0x2d91c7['serverSyncTree_'],_0x43ded1,_0x5029ec));const _0x2a9f00=Is(_0x2d91c7,_0x43ded1);ct(_0x2d91c7,_0x2a9f00);}),_0x2d91c7['onDisconnect_']=En(),V(_0x2d91c7['eventQueue_'],w(),_0x185a8d);}function bd(_0x50626f,_0x333871,_0x1295ac){_0x50626f['server_']['onDisconnectCancel'](_0x333871['toString'](),(_0x42b50f,_0x148563)=>{_0x42b50f==='ok'&&Ti(_0x50626f['onDisconnect_'],_0x333871),be(_0x50626f,_0x1295ac,_0x42b50f,_0x148563);});}function yr(_0x3fbab9,_0x44e9b3,_0x578436,_0x53f195){const _0xbed5e9=A(_0x578436);_0x3fbab9['server_']['onDisconnectPut'](_0x44e9b3['toString'](),_0xbed5e9['val'](!0x0),(_0x136e47,_0x562a54)=>{_0x136e47==='ok'&&pt(_0x3fbab9['onDisconnect_'],_0x44e9b3,_0xbed5e9),be(_0x3fbab9,_0x53f195,_0x136e47,_0x562a54);});}function Rd(_0x823bcf,_0x16b25f,_0x6b8573,_0x1718e7,_0x5a5ea1){const _0x27af6e=A(_0x6b8573,_0x1718e7);_0x823bcf['server_']['onDisconnectPut'](_0x16b25f['toString'](),_0x27af6e['val'](!0x0),(_0x3a96ab,_0x300014)=>{_0x3a96ab==='ok'&&pt(_0x823bcf['onDisconnect_'],_0x16b25f,_0x27af6e),be(_0x823bcf,_0x5a5ea1,_0x3a96ab,_0x300014);});}function Ad(_0x31f27c,_0x17658e,_0x9f9458,_0x4a477a){if(pn(_0x9f9458)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x31f27c,_0x4a477a,'ok',void 0x0);return;}_0x31f27c['server_']['onDisconnectMerge'](_0x17658e['toString'](),_0x9f9458,(_0x374012,_0x190a42)=>{_0x374012==='ok'&&x(_0x9f9458,(_0x18eda6,_0x16fd33)=>{const _0x5414c4=A(_0x16fd33);pt(_0x31f27c['onDisconnect_'],k(_0x17658e,_0x18eda6),_0x5414c4);}),be(_0x31f27c,_0x4a477a,_0x374012,_0x190a42);});}function kd(_0x3816d4,_0x250060,_0x32bb31){let _0x1c0af6;y(_0x250060['_path'])==='.info'?_0x1c0af6=Ni(_0x3816d4['infoSyncTree_'],_0x250060,_0x32bb31):_0x1c0af6=Ni(_0x3816d4['serverSyncTree_'],_0x250060,_0x32bb31),oa(_0x3816d4['eventQueue_'],_0x250060['_path'],_0x1c0af6);}function Pd(_0xb432ef,_0x239ccc,_0x54f452){let _0x1aa80c;y(_0x239ccc['_path'])==='.info'?_0x1aa80c=An(_0xb432ef['infoSyncTree_'],_0x239ccc,_0x54f452):_0x1aa80c=An(_0xb432ef['serverSyncTree_'],_0x239ccc,_0x54f452),oa(_0xb432ef['eventQueue_'],_0x239ccc['_path'],_0x1aa80c);}function ha(_0x1b650c){_0x1b650c['persistentConnection_']&&_0x1b650c['persistentConnection_']['interrupt'](ca);}function Nd(_0x5a1431){_0x5a1431['persistentConnection_']&&_0x5a1431['persistentConnection_']['resume'](ca);}function gt(_0x751a74,..._0x1f972b){let _0x17f17a='';_0x751a74['persistentConnection_']&&(_0x17f17a=_0x751a74['persistentConnection_']['id']+':'),L(_0x17f17a,..._0x1f972b);}function be(_0x487bf7,_0x18cadf,_0x4c6e1b,_0x2396c6){_0x18cadf&&ft(()=>{if(_0x4c6e1b==='ok')_0x18cadf(null);else{const _0x282784=(_0x4c6e1b||'error')['toUpperCase']();let _0x324b30=_0x282784;_0x2396c6&&(_0x324b30+=':\x20'+_0x2396c6);const _0x37b506=new Error(_0x324b30);_0x37b506['code']=_0x282784,_0x18cadf(_0x37b506);}});}function Od(_0x3ebb38,_0x29ee39,_0x3df470,_0x42a1d7,_0x3c4a85,_0x5810cf){gt(_0x3ebb38,'transaction\x20on\x20'+_0x29ee39);const _0x3f9f14={'path':_0x29ee39,'update':_0x3df470,'onComplete':_0x42a1d7,'status':null,'order':so(),'applyLocally':_0x5810cf,'retryCount':0x0,'unwatcher':_0x3c4a85,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1b420a=Es(_0x3ebb38,_0x29ee39,void 0x0);_0x3f9f14['currentInputSnapshot']=_0x1b420a;const _0x12a07e=_0x3f9f14['update'](_0x1b420a['val']());if(_0x12a07e===void 0x0)_0x3f9f14['unwatcher'](),_0x3f9f14['currentOutputSnapshotRaw']=null,_0x3f9f14['currentOutputSnapshotResolved']=null,_0x3f9f14['onComplete']&&_0x3f9f14['onComplete'](null,!0x1,_0x3f9f14['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x12a07e,_0x3f9f14['path']),_0x3f9f14['status']=0x0;const _0x19883f=$n(_0x3ebb38['transactionQueueTree_'],_0x29ee39),_0x39f96e=je(_0x19883f)||[];_0x39f96e['push'](_0x3f9f14),gs(_0x19883f,_0x39f96e);let _0x1716b2;typeof _0x12a07e=='object'&&_0x12a07e!==null&&Q(_0x12a07e,'.priority')?(_0x1716b2=Le(_0x12a07e,'.priority'),f(Bt(_0x1716b2),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1716b2=(Vn(_0x3ebb38['serverSyncTree_'],_0x29ee39)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x57778e=Xt(_0x3ebb38),_0x16f412=A(_0x12a07e,_0x1716b2),_0x76bd7=fs(_0x16f412,_0x1b420a,_0x57778e);_0x3f9f14['currentOutputSnapshotRaw']=_0x16f412,_0x3f9f14['currentOutputSnapshotResolved']=_0x76bd7,_0x3f9f14['currentWriteId']=zn(_0x3ebb38);const _0x37bf58=as(_0x3ebb38['serverSyncTree_'],_0x29ee39,_0x76bd7,_0x3f9f14['currentWriteId'],_0x3f9f14['applyLocally']);V(_0x3ebb38['eventQueue_'],_0x29ee39,_0x37bf58),jn(_0x3ebb38,_0x3ebb38['transactionQueueTree_']);}}function Es(_0x42617c,_0x3966d3,_0x1edab6){return Vn(_0x42617c['serverSyncTree_'],_0x3966d3,_0x1edab6)||g['EMPTY_NODE'];}function jn(_0x52ea4d,_0x1d3392=_0x52ea4d['transactionQueueTree_']){if(_0x1d3392||Kn(_0x52ea4d,_0x1d3392),je(_0x1d3392)){const _0x59f196=da(_0x52ea4d,_0x1d3392);f(_0x59f196['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x59f196['every'](_0x589bf7=>_0x589bf7['status']===0x0)&&Dd(_0x52ea4d,Qt(_0x1d3392),_0x59f196);}else na(_0x1d3392)&&Gn(_0x1d3392,_0xc8c8d0=>{jn(_0x52ea4d,_0xc8c8d0);});}function Dd(_0xdba6,_0x31bba4,_0x30d7ab){const _0x2b1cc3=_0x30d7ab['map'](_0xe473b=>_0xe473b['currentWriteId']),_0x5b3eb3=Es(_0xdba6,_0x31bba4,_0x2b1cc3);let _0x57f898=_0x5b3eb3;const _0x2314d4=_0x5b3eb3['hash']();for(let _0x20d180=0x0;_0x20d180<_0x30d7ab['length'];_0x20d180++){const _0x3fc242=_0x30d7ab[_0x20d180];f(_0x3fc242['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3fc242['status']=0x1,_0x3fc242['retryCount']++;const _0x5875f9=F(_0x31bba4,_0x3fc242['path']);_0x57f898=_0x57f898['updateChild'](_0x5875f9,_0x3fc242['currentOutputSnapshotRaw']);}const _0xa94263=_0x57f898['val'](!0x0),_0x23e2e2=_0x31bba4;_0xdba6['server_']['put'](_0x23e2e2['toString'](),_0xa94263,_0x209538=>{gt(_0xdba6,'transaction\x20put\x20response',{'path':_0x23e2e2['toString'](),'status':_0x209538});let _0x47456c=[];if(_0x209538==='ok'){const _0x19679b=[];for(let _0x4f1305=0x0;_0x4f1305<_0x30d7ab['length'];_0x4f1305++)_0x30d7ab[_0x4f1305]['status']=0x2,_0x47456c=_0x47456c['concat'](_e(_0xdba6['serverSyncTree_'],_0x30d7ab[_0x4f1305]['currentWriteId'])),_0x30d7ab[_0x4f1305]['onComplete']&&_0x19679b['push'](()=>_0x30d7ab[_0x4f1305]['onComplete'](null,!0x0,_0x30d7ab[_0x4f1305]['currentOutputSnapshotResolved'])),_0x30d7ab[_0x4f1305]['unwatcher']();Kn(_0xdba6,$n(_0xdba6['transactionQueueTree_'],_0x31bba4)),jn(_0xdba6,_0xdba6['transactionQueueTree_']),V(_0xdba6['eventQueue_'],_0x31bba4,_0x47456c);for(let _0x1fa298=0x0;_0x1fa298<_0x19679b['length'];_0x1fa298++)ft(_0x19679b[_0x1fa298]);}else{if(_0x209538==='datastale'){for(let _0x4d32a3=0x0;_0x4d32a3<_0x30d7ab['length'];_0x4d32a3++)_0x30d7ab[_0x4d32a3]['status']===0x3?_0x30d7ab[_0x4d32a3]['status']=0x4:_0x30d7ab[_0x4d32a3]['status']=0x0;}else{U('transaction\x20at\x20'+_0x23e2e2['toString']()+'\x20failed:\x20'+_0x209538);for(let _0x4dda69=0x0;_0x4dda69<_0x30d7ab['length'];_0x4dda69++)_0x30d7ab[_0x4dda69]['status']=0x4,_0x30d7ab[_0x4dda69]['abortReason']=_0x209538;}ct(_0xdba6,_0x31bba4);}},_0x2314d4);}function ct(_0x4ffcd2,_0x827ddc){const _0x24a387=ua(_0x4ffcd2,_0x827ddc),_0x25163f=Qt(_0x24a387),_0x8591d2=da(_0x4ffcd2,_0x24a387);return Md(_0x4ffcd2,_0x8591d2,_0x25163f),_0x25163f;}function Md(_0x199e86,_0x16e953,_0x32854e){if(_0x16e953['length']===0x0)return;const _0x500025=[];let _0x1f751c=[];const _0x55bbbe=_0x16e953['filter'](_0x447f8d=>_0x447f8d['status']===0x0)['map'](_0x4df81f=>_0x4df81f['currentWriteId']);for(let _0x320f24=0x0;_0x320f24<_0x16e953['length'];_0x320f24++){const _0x24ecba=_0x16e953[_0x320f24],_0x2164d4=F(_0x32854e,_0x24ecba['path']);let _0x5cf57d=!0x1,_0x2305b1;if(f(_0x2164d4!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x24ecba['status']===0x4)_0x5cf57d=!0x0,_0x2305b1=_0x24ecba['abortReason'],_0x1f751c=_0x1f751c['concat'](_e(_0x199e86['serverSyncTree_'],_0x24ecba['currentWriteId'],!0x0));else{if(_0x24ecba['status']===0x0){if(_0x24ecba['retryCount']>=yd)_0x5cf57d=!0x0,_0x2305b1='maxretry',_0x1f751c=_0x1f751c['concat'](_e(_0x199e86['serverSyncTree_'],_0x24ecba['currentWriteId'],!0x0));else{const _0x532433=Es(_0x199e86,_0x24ecba['path'],_0x55bbbe);_0x24ecba['currentInputSnapshot']=_0x532433;const _0x315d62=_0x16e953[_0x320f24]['update'](_0x532433['val']());if(_0x315d62!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x315d62,_0x24ecba['path']);let _0x102b20=A(_0x315d62);typeof _0x315d62=='object'&&_0x315d62!=null&&Q(_0x315d62,'.priority')||(_0x102b20=_0x102b20['updatePriority'](_0x532433['getPriority']()));const _0xf23def=_0x24ecba['currentWriteId'],_0x203c71=Xt(_0x199e86),_0x483363=fs(_0x102b20,_0x532433,_0x203c71);_0x24ecba['currentOutputSnapshotRaw']=_0x102b20,_0x24ecba['currentOutputSnapshotResolved']=_0x483363,_0x24ecba['currentWriteId']=zn(_0x199e86),_0x55bbbe['splice'](_0x55bbbe['indexOf'](_0xf23def),0x1),_0x1f751c=_0x1f751c['concat'](as(_0x199e86['serverSyncTree_'],_0x24ecba['path'],_0x483363,_0x24ecba['currentWriteId'],_0x24ecba['applyLocally'])),_0x1f751c=_0x1f751c['concat'](_e(_0x199e86['serverSyncTree_'],_0xf23def,!0x0));}else _0x5cf57d=!0x0,_0x2305b1='nodata',_0x1f751c=_0x1f751c['concat'](_e(_0x199e86['serverSyncTree_'],_0x24ecba['currentWriteId'],!0x0));}}}V(_0x199e86['eventQueue_'],_0x32854e,_0x1f751c),_0x1f751c=[],_0x5cf57d&&(_0x16e953[_0x320f24]['status']=0x2,function(_0x12863c){setTimeout(_0x12863c,Math['floor'](0x0));}(_0x16e953[_0x320f24]['unwatcher']),_0x16e953[_0x320f24]['onComplete']&&(_0x2305b1==='nodata'?_0x500025['push'](()=>_0x16e953[_0x320f24]['onComplete'](null,!0x1,_0x16e953[_0x320f24]['currentInputSnapshot'])):_0x500025['push'](()=>_0x16e953[_0x320f24]['onComplete'](new Error(_0x2305b1),!0x1,null))));}Kn(_0x199e86,_0x199e86['transactionQueueTree_']);for(let _0x2cf4a5=0x0;_0x2cf4a5<_0x500025['length'];_0x2cf4a5++)ft(_0x500025[_0x2cf4a5]);jn(_0x199e86,_0x199e86['transactionQueueTree_']);}function ua(_0x425fd3,_0x110cc0){let _0x59313e,_0x119702=_0x425fd3['transactionQueueTree_'];for(_0x59313e=y(_0x110cc0);_0x59313e!==null&&je(_0x119702)===void 0x0;)_0x119702=$n(_0x119702,_0x59313e),_0x110cc0=S(_0x110cc0),_0x59313e=y(_0x110cc0);return _0x119702;}function da(_0x2ac24b,_0x2c770c){const _0xbc9684=[];return fa(_0x2ac24b,_0x2c770c,_0xbc9684),_0xbc9684['sort']((_0x3c5931,_0x3cc3f0)=>_0x3c5931['order']-_0x3cc3f0['order']),_0xbc9684;}function fa(_0x48a3d4,_0x1f7fc9,_0x3a664e){const _0x3dd5df=je(_0x1f7fc9);if(_0x3dd5df){for(let _0x3c3a98=0x0;_0x3c3a98<_0x3dd5df['length'];_0x3c3a98++)_0x3a664e['push'](_0x3dd5df[_0x3c3a98]);}Gn(_0x1f7fc9,_0xab85df=>{fa(_0x48a3d4,_0xab85df,_0x3a664e);});}function Kn(_0x5dfb24,_0x5c56f2){const _0x2f40d9=je(_0x5c56f2);if(_0x2f40d9){let _0x21f330=0x0;for(let _0x2bc15d=0x0;_0x2bc15d<_0x2f40d9['length'];_0x2bc15d++)_0x2f40d9[_0x2bc15d]['status']!==0x2&&(_0x2f40d9[_0x21f330]=_0x2f40d9[_0x2bc15d],_0x21f330++);_0x2f40d9['length']=_0x21f330,gs(_0x5c56f2,_0x2f40d9['length']>0x0?_0x2f40d9:void 0x0);}Gn(_0x5c56f2,_0x26d27c=>{Kn(_0x5dfb24,_0x26d27c);});}function Is(_0x27fe01,_0x9519ff){const _0x56fcba=Qt(ua(_0x27fe01,_0x9519ff)),_0x42c40e=$n(_0x27fe01['transactionQueueTree_'],_0x9519ff);return ad(_0x42c40e,_0x1e344f=>{di(_0x27fe01,_0x1e344f);}),di(_0x27fe01,_0x42c40e),ia(_0x42c40e,_0x3c1e24=>{di(_0x27fe01,_0x3c1e24);}),_0x56fcba;}function di(_0xad91cc,_0x42c4bf){const _0x483c86=je(_0x42c4bf);if(_0x483c86){const _0x218e18=[];let _0xe42154=[],_0x2db76c=-0x1;for(let _0x25dbcb=0x0;_0x25dbcb<_0x483c86['length'];_0x25dbcb++)_0x483c86[_0x25dbcb]['status']===0x3||(_0x483c86[_0x25dbcb]['status']===0x1?(f(_0x2db76c===_0x25dbcb-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2db76c=_0x25dbcb,_0x483c86[_0x25dbcb]['status']=0x3,_0x483c86[_0x25dbcb]['abortReason']='set'):(f(_0x483c86[_0x25dbcb]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x483c86[_0x25dbcb]['unwatcher'](),_0xe42154=_0xe42154['concat'](_e(_0xad91cc['serverSyncTree_'],_0x483c86[_0x25dbcb]['currentWriteId'],!0x0)),_0x483c86[_0x25dbcb]['onComplete']&&_0x218e18['push'](_0x483c86[_0x25dbcb]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2db76c===-0x1?gs(_0x42c4bf,void 0x0):_0x483c86['length']=_0x2db76c+0x1,V(_0xad91cc['eventQueue_'],Qt(_0x42c4bf),_0xe42154);for(let _0x2a258c=0x0;_0x2a258c<_0x218e18['length'];_0x2a258c++)ft(_0x218e18[_0x2a258c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x288396){let _0x4f6ed3='';const _0x455589=_0x288396['split']('/');for(let _0xe19c8e=0x0;_0xe19c8e<_0x455589['length'];_0xe19c8e++)if(_0x455589[_0xe19c8e]['length']>0x0){let _0x11fc7a=_0x455589[_0xe19c8e];try{_0x11fc7a=decodeURIComponent(_0x11fc7a['replace'](/\+/g,'\x20'));}catch{}_0x4f6ed3+='/'+_0x11fc7a;}return _0x4f6ed3;}function xd(_0x2e398f){const _0x1fe563={};_0x2e398f['charAt'](0x0)==='?'&&(_0x2e398f=_0x2e398f['substring'](0x1));for(const _0x363ac1 of _0x2e398f['split']('&')){if(_0x363ac1['length']===0x0)continue;const _0xb5aec5=_0x363ac1['split']('=');_0xb5aec5['length']===0x2?_0x1fe563[decodeURIComponent(_0xb5aec5[0x0])]=decodeURIComponent(_0xb5aec5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x363ac1+'\x27\x20in\x20query\x20\x27'+_0x2e398f+'\x27');}return _0x1fe563;}const vr=function(_0x4e3cb2,_0x38a311){const _0x2c8f27=Fd(_0x4e3cb2),_0x3dabc1=_0x2c8f27['namespace'];_0x2c8f27['domain']==='firebase.com'&&ae(_0x2c8f27['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3dabc1||_0x3dabc1==='undefined')&&_0x2c8f27['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2c8f27['secure']||$l();const _0x1b6647=_0x2c8f27['scheme']==='ws'||_0x2c8f27['scheme']==='wss';return{'repoInfo':new yo(_0x2c8f27['host'],_0x2c8f27['secure'],_0x3dabc1,_0x1b6647,_0x38a311,'',_0x3dabc1!==_0x2c8f27['subdomain']),'path':new C(_0x2c8f27['pathString'])};},Fd=function(_0x1c6511){let _0x18a8d4='',_0x2ea7d8='',_0x2b9536='',_0xd2c605='',_0xba7bf2='',_0x4dcf6e=!0x0,_0x51ef98='https',_0x21bac5=0x1bb;if(typeof _0x1c6511=='string'){let _0xf0d97d=_0x1c6511['indexOf']('//');_0xf0d97d>=0x0&&(_0x51ef98=_0x1c6511['substring'](0x0,_0xf0d97d-0x1),_0x1c6511=_0x1c6511['substring'](_0xf0d97d+0x2));let _0x5e842f=_0x1c6511['indexOf']('/');_0x5e842f===-0x1&&(_0x5e842f=_0x1c6511['length']);let _0x39f949=_0x1c6511['indexOf']('?');_0x39f949===-0x1&&(_0x39f949=_0x1c6511['length']),_0x18a8d4=_0x1c6511['substring'](0x0,Math['min'](_0x5e842f,_0x39f949)),_0x5e842f<_0x39f949&&(_0xd2c605=Ld(_0x1c6511['substring'](_0x5e842f,_0x39f949)));const _0x3123eb=xd(_0x1c6511['substring'](Math['min'](_0x1c6511['length'],_0x39f949)));_0xf0d97d=_0x18a8d4['indexOf'](':'),_0xf0d97d>=0x0?(_0x4dcf6e=_0x51ef98==='https'||_0x51ef98==='wss',_0x21bac5=parseInt(_0x18a8d4['substring'](_0xf0d97d+0x1),0xa)):_0xf0d97d=_0x18a8d4['length'];const _0x3e20b2=_0x18a8d4['slice'](0x0,_0xf0d97d);if(_0x3e20b2['toLowerCase']()==='localhost')_0x2ea7d8='localhost';else{if(_0x3e20b2['split']('.')['length']<=0x2)_0x2ea7d8=_0x3e20b2;else{const _0x50c396=_0x18a8d4['indexOf']('.');_0x2b9536=_0x18a8d4['substring'](0x0,_0x50c396)['toLowerCase'](),_0x2ea7d8=_0x18a8d4['substring'](_0x50c396+0x1),_0xba7bf2=_0x2b9536;}}'ns'in _0x3123eb&&(_0xba7bf2=_0x3123eb['ns']);}return{'host':_0x18a8d4,'port':_0x21bac5,'domain':_0x2ea7d8,'subdomain':_0x2b9536,'secure':_0x4dcf6e,'scheme':_0x51ef98,'pathString':_0xd2c605,'namespace':_0xba7bf2};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x36879d=0x0;const _0x10ff02=[];return function(_0x32f7d6){const _0x3bcdcf=_0x32f7d6===_0x36879d;_0x36879d=_0x32f7d6;let _0x4e4f16;const _0x2075f5=new Array(0x8);for(_0x4e4f16=0x7;_0x4e4f16>=0x0;_0x4e4f16--)_0x2075f5[_0x4e4f16]=Er['charAt'](_0x32f7d6%0x40),_0x32f7d6=Math['floor'](_0x32f7d6/0x40);f(_0x32f7d6===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4e895d=_0x2075f5['join']('');if(_0x3bcdcf){for(_0x4e4f16=0xb;_0x4e4f16>=0x0&&_0x10ff02[_0x4e4f16]===0x3f;_0x4e4f16--)_0x10ff02[_0x4e4f16]=0x0;_0x10ff02[_0x4e4f16]++;}else{for(_0x4e4f16=0x0;_0x4e4f16<0xc;_0x4e4f16++)_0x10ff02[_0x4e4f16]=Math['floor'](Math['random']()*0x40);}for(_0x4e4f16=0x0;_0x4e4f16<0xc;_0x4e4f16++)_0x4e895d+=Er['charAt'](_0x10ff02[_0x4e4f16]);return f(_0x4e895d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4e895d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x35f95a,_0x3a99e9,_0x25dec7,_0x8d06fb){this['eventType']=_0x35f95a,this['eventRegistration']=_0x3a99e9,this['snapshot']=_0x25dec7,this['prevName']=_0x8d06fb;}['getPath'](){const _0x2aba0d=this['snapshot']['ref'];return this['eventType']==='value'?_0x2aba0d['_path']:_0x2aba0d['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x34a4a2,_0x383ea8,_0x298cf8){this['eventRegistration']=_0x34a4a2,this['error']=_0x383ea8,this['path']=_0x298cf8;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x107980,_0xe1ae78){this['snapshotCallback']=_0x107980,this['cancelCallback']=_0xe1ae78;}['onValue'](_0x2b78e1,_0xc605f2){this['snapshotCallback']['call'](null,_0x2b78e1,_0xc605f2);}['onCancel'](_0x572b3c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x572b3c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x58e109){return this['snapshotCallback']===_0x58e109['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x58e109['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x58e109['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x267bec,_0x2c9036){this['_repo']=_0x267bec,this['_path']=_0x2c9036;}['cancel'](){const _0x3101ad=new H();return bd(this['_repo'],this['_path'],_0x3101ad['wrapCallback'](()=>{})),_0x3101ad['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x33f184=new H();return yr(this['_repo'],this['_path'],null,_0x33f184['wrapCallback'](()=>{})),_0x33f184['promise'];}['set'](_0xc4e62f){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0xc4e62f,this['_path'],!0x1);const _0x118c3d=new H();return yr(this['_repo'],this['_path'],_0xc4e62f,_0x118c3d['wrapCallback'](()=>{})),_0x118c3d['promise'];}['setWithPriority'](_0x560d87,_0x36eb65){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x560d87,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x36eb65);const _0x5e024a=new H();return Rd(this['_repo'],this['_path'],_0x560d87,_0x36eb65,_0x5e024a['wrapCallback'](()=>{})),_0x5e024a['promise'];}['update'](_0x577ea6){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x577ea6,this['_path']);const _0x4bea60=new H();return Ad(this['_repo'],this['_path'],_0x577ea6,_0x4bea60['wrapCallback'](()=>{})),_0x4bea60['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x151ce9,_0x5ac835,_0x2f951e,_0x328cb9){this['_repo']=_0x151ce9,this['_path']=_0x5ac835,this['_queryParams']=_0x2f951e,this['_orderByCalled']=_0x328cb9;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5cb314=sr(this['_queryParams']),_0x463a54=$i(_0x5cb314);return _0x463a54==='{}'?'default':_0x463a54;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x316aab){if(_0x316aab=P(_0x316aab),!(_0x316aab instanceof Ae))return!0x1;const _0x53bd92=this['_repo']===_0x316aab['_repo'],_0x518b09=Ki(this['_path'],_0x316aab['_path']),_0x2cc537=this['_queryIdentifier']===_0x316aab['_queryIdentifier'];return _0x53bd92&&_0x518b09&&_0x2cc537;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x47cabc,_0x33ed49){if(_0x47cabc['_orderByCalled']===!0x0)throw new Error(_0x33ed49+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x58875f){let _0x3488f2=null,_0x372941=null;if(_0x58875f['hasStart']()&&(_0x3488f2=_0x58875f['getIndexStartValue']()),_0x58875f['hasEnd']()&&(_0x372941=_0x58875f['getIndexEndValue']()),_0x58875f['getIndex']()===ve){const _0x281c5a='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3f9ff0='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x58875f['hasStart']()){if(_0x58875f['getIndexStartName']()!==We)throw new Error(_0x281c5a);if(typeof _0x3488f2!='string')throw new Error(_0x3f9ff0);}if(_0x58875f['hasEnd']()){if(_0x58875f['getIndexEndName']()!==we)throw new Error(_0x281c5a);if(typeof _0x372941!='string')throw new Error(_0x3f9ff0);}}else{if(_0x58875f['getIndex']()===R){if(_0x3488f2!=null&&!Bt(_0x3488f2)||_0x372941!=null&&!Bt(_0x372941))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x58875f['getIndex']()instanceof Ji||_0x58875f['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3488f2!=null&&typeof _0x3488f2=='object'||_0x372941!=null&&typeof _0x372941=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x11c191){if(_0x11c191['hasStart']()&&_0x11c191['hasEnd']()&&_0x11c191['hasLimit']()&&!_0x11c191['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5927c8,_0x40b2a5){super(_0x5927c8,_0x40b2a5,new Zi(),!0x1);}get['parent'](){const _0x40496d=Ro(this['_path']);return _0x40496d===null?null:new ee(this['_repo'],_0x40496d);}get['root'](){let _0x350bf4=this;for(;_0x350bf4['parent']!==null;)_0x350bf4=_0x350bf4['parent'];return _0x350bf4;}}class lt{constructor(_0x202d68,_0xcb5570,_0x1e7aed){this['_node']=_0x202d68,this['ref']=_0xcb5570,this['_index']=_0x1e7aed;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4f1819){const _0x3293f1=new C(_0x4f1819),_0x15b80a=Vt(this['ref'],_0x4f1819);return new lt(this['_node']['getChild'](_0x3293f1),_0x15b80a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x153c93){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x427d83,_0x3c5b9e)=>_0x153c93(new lt(_0x3c5b9e,Vt(this['ref'],_0x427d83),R)));}['hasChild'](_0x14370c){const _0x49a91c=new C(_0x14370c);return!this['_node']['getChild'](_0x49a91c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x48765c,_0xa1f18f){return _0x48765c=P(_0x48765c),_0x48765c['_checkNotDeleted']('ref'),_0xa1f18f!==void 0x0?Vt(_0x48765c['_root'],_0xa1f18f):_0x48765c['_root'];}function Vt(_0x58b0e4,_0x16d79f){return _0x58b0e4=P(_0x58b0e4),y(_0x58b0e4['_path'])===null?pd('child','path',_0x16d79f):ys('child','path',_0x16d79f),new ee(_0x58b0e4['_repo'],k(_0x58b0e4['_path'],_0x16d79f));}function v_(_0x5a18cf){return _0x5a18cf=P(_0x5a18cf),new Vd(_0x5a18cf['_repo'],_0x5a18cf['_path']);}function E_(_0x35985f,_0x3ae792){_0x35985f=P(_0x35985f),Me('push',_0x35985f['_path']),He('push',_0x3ae792,_0x35985f['_path'],!0x0);const _0x597fc3=la(_0x35985f['_repo']),_0x260dbb=Ud(_0x597fc3),_0x2f1f3a=Vt(_0x35985f,_0x260dbb),_0x4e2edd=Vt(_0x35985f,_0x260dbb);let _0x4175e6;return _0x3ae792!=null?_0x4175e6=Hd(_0x4e2edd,_0x3ae792)['then'](()=>_0x4e2edd):_0x4175e6=Promise['resolve'](_0x4e2edd),_0x2f1f3a['then']=_0x4175e6['then']['bind'](_0x4175e6),_0x2f1f3a['catch']=_0x4175e6['then']['bind'](_0x4175e6,void 0x0),_0x2f1f3a;}function Hd(_0x3e582a,_0x2fa914){_0x3e582a=P(_0x3e582a),Me('set',_0x3e582a['_path']),He('set',_0x2fa914,_0x3e582a['_path'],!0x1);const _0x2d3885=new H();return Cd(_0x3e582a['_repo'],_0x3e582a['_path'],_0x2fa914,null,_0x2d3885['wrapCallback'](()=>{})),_0x2d3885['promise'];}function I_(_0x1d66d5,_0x3140d9){ra('update',_0x3140d9,_0x1d66d5['_path']);const _0x7d97e5=new H();return Td(_0x1d66d5['_repo'],_0x1d66d5['_path'],_0x3140d9,_0x7d97e5['wrapCallback'](()=>{})),_0x7d97e5['promise'];}function w_(_0x2aff3b){_0x2aff3b=P(_0x2aff3b);const _0x14aefe=new pa(()=>{}),_0x27b8a3=new Qn(_0x14aefe);return wd(_0x2aff3b['_repo'],_0x2aff3b,_0x27b8a3)['then'](_0x9b8332=>new lt(_0x9b8332,new ee(_0x2aff3b['_repo'],_0x2aff3b['_path']),_0x2aff3b['_queryParams']['getIndex']()));}class Qn{constructor(_0x8abead){this['callbackContext']=_0x8abead;}['respondsTo'](_0x3dd8c1){return _0x3dd8c1==='value';}['createEvent'](_0x49c549,_0x53f73f){const _0x35f9ac=_0x53f73f['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x49c549['snapshotNode'],new ee(_0x53f73f['_repo'],_0x53f73f['_path']),_0x35f9ac));}['getEventRunner'](_0x9a1d92){return _0x9a1d92['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x9a1d92['error']):()=>this['callbackContext']['onValue'](_0x9a1d92['snapshot'],null);}['createCancelEvent'](_0x2a3a52,_0x49c118){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x2a3a52,_0x49c118):null;}['matches'](_0xfd4411){return _0xfd4411 instanceof Qn?!_0xfd4411['callbackContext']||!this['callbackContext']?!0x0:_0xfd4411['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x215be1,_0xe57c30,_0x48416e,_0x34fd7d,_0xada5bb){const _0xe77690=new pa(_0x48416e,void 0x0),_0x499a80=new Qn(_0xe77690);return kd(_0x215be1['_repo'],_0x215be1,_0x499a80),()=>Pd(_0x215be1['_repo'],_0x215be1,_0x499a80);}function Gd(_0x68fffb,_0x2f14c6,_0x39cf6b,_0x48594d){return $d(_0x68fffb,'value',_0x2f14c6);}class mt{}class ma extends mt{constructor(_0x52b6a3,_0x67bc21){super(),this['_value']=_0x52b6a3,this['_key']=_0x67bc21,this['type']='endAt';}['_apply'](_0x2ebc97){He('endAt',this['_value'],_0x2ebc97['_path'],!0x0);const _0x29dbca=Jh(_0x2ebc97['_queryParams'],this['_value'],this['_key']);if(ga(_0x29dbca),Yn(_0x29dbca),_0x2ebc97['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x2ebc97['_repo'],_0x2ebc97['_path'],_0x29dbca,_0x2ebc97['_orderByCalled']);}}function C_(_0x586aa5,_0x4f5e3a){return new ma(_0x586aa5,_0x4f5e3a);}class ya extends mt{constructor(_0x3965c3,_0xda68b7){super(),this['_value']=_0x3965c3,this['_key']=_0xda68b7,this['type']='startAt';}['_apply'](_0x1b882c){He('startAt',this['_value'],_0x1b882c['_path'],!0x0);const _0x206f7a=Qh(_0x1b882c['_queryParams'],this['_value'],this['_key']);if(ga(_0x206f7a),Yn(_0x206f7a),_0x1b882c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x1b882c['_repo'],_0x1b882c['_path'],_0x206f7a,_0x1b882c['_orderByCalled']);}}function T_(_0x25382c=null,_0x5e401a){return new ya(_0x25382c,_0x5e401a);}class qd extends mt{constructor(_0x2d8364){super(),this['_limit']=_0x2d8364,this['type']='limitToFirst';}['_apply'](_0x4167e7){if(_0x4167e7['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4167e7['_repo'],_0x4167e7['_path'],Yh(_0x4167e7['_queryParams'],this['_limit']),_0x4167e7['_orderByCalled']);}}function S_(_0x31a1f6){if(Math['floor'](_0x31a1f6)!==_0x31a1f6||_0x31a1f6<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x31a1f6);}class zd extends mt{constructor(_0x9fea85){super(),this['_path']=_0x9fea85,this['type']='orderByChild';}['_apply'](_0x5ee368){_a(_0x5ee368,'orderByChild');const _0x12c641=new C(this['_path']);if(v(_0x12c641))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x45c221=new Ji(_0x12c641),_0x4d0cfd=xo(_0x5ee368['_queryParams'],_0x45c221);return Yn(_0x4d0cfd),new Ae(_0x5ee368['_repo'],_0x5ee368['_path'],_0x4d0cfd,!0x0);}}function b_(_0x3cc815){if(_0x3cc815==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3cc815==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3cc815==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x3cc815),new zd(_0x3cc815);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x241498){_a(_0x241498,'orderByKey');const _0x1d17bf=xo(_0x241498['_queryParams'],ve);return Yn(_0x1d17bf),new Ae(_0x241498['_repo'],_0x241498['_path'],_0x1d17bf,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0xa18865,_0x556471){super(),this['_value']=_0xa18865,this['_key']=_0x556471,this['type']='equalTo';}['_apply'](_0x36f979){if(He('equalTo',this['_value'],_0x36f979['_path'],!0x1),_0x36f979['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x36f979['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x36f979));}}function A_(_0x5538f2,_0x59926b){return new Kd(_0x5538f2,_0x59926b);}function k_(_0x405cc5,..._0x4bd004){let _0x3d8c44=P(_0x405cc5);for(const _0x8f6fbf of _0x4bd004)_0x3d8c44=_0x8f6fbf['_apply'](_0x3d8c44);return _0x3d8c44;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4616a3,_0x5c6d23,_0x18d336,_0x24d815){const _0x480c91=_0x5c6d23['lastIndexOf'](':'),_0x3c0934=_0x5c6d23['substring'](0x0,_0x480c91),_0x381a3a=qt(_0x3c0934);_0x4616a3['repoInfo_']=new yo(_0x5c6d23,_0x381a3a,_0x4616a3['repoInfo_']['namespace'],_0x4616a3['repoInfo_']['webSocketOnly'],_0x4616a3['repoInfo_']['nodeAdmin'],_0x4616a3['repoInfo_']['persistenceKey'],_0x4616a3['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x18d336),_0x24d815&&(_0x4616a3['authTokenProvider_']=_0x24d815);}function Xd(_0x5a7c40,_0x399e5f,_0x57e5bb,_0x3488c1,_0x374d71){let _0x1c6476=_0x3488c1||_0x5a7c40['options']['databaseURL'];_0x1c6476===void 0x0&&(_0x5a7c40['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5a7c40['options']['projectId']),_0x1c6476=_0x5a7c40['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2b6d03=vr(_0x1c6476,_0x374d71),_0x3bbb9b=_0x2b6d03['repoInfo'],_0x23e307;typeof process<'u'&&Bs&&(_0x23e307=Bs[Yd]),_0x23e307?(_0x1c6476='http://'+_0x23e307+'?ns='+_0x3bbb9b['namespace'],_0x2b6d03=vr(_0x1c6476,_0x374d71),_0x3bbb9b=_0x2b6d03['repoInfo']):_0x2b6d03['repoInfo']['secure'];const _0x1a6991=new eh(_0x5a7c40['name'],_0x5a7c40['options'],_0x399e5f);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2b6d03),v(_0x2b6d03['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x36ec60=ef(_0x3bbb9b,_0x5a7c40,_0x1a6991,new Zl(_0x5a7c40,_0x57e5bb));return new tf(_0x36ec60,_0x5a7c40);}function Zd(_0x4a1c2d,_0x40aa9b){const _0x20ffab=Di[_0x40aa9b];(!_0x20ffab||_0x20ffab[_0x4a1c2d['key']]!==_0x4a1c2d)&&ae('Database\x20'+_0x40aa9b+'('+_0x4a1c2d['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4a1c2d),delete _0x20ffab[_0x4a1c2d['key']];}function ef(_0x4638c2,_0x56f12e,_0x190581,_0x8cd0ae){let _0x26e664=Di[_0x56f12e['name']];_0x26e664||(_0x26e664={},Di[_0x56f12e['name']]=_0x26e664);let _0x25804f=_0x26e664[_0x4638c2['toURLString']()];return _0x25804f&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x25804f=new vd(_0x4638c2,Qd,_0x190581,_0x8cd0ae),_0x26e664[_0x4638c2['toURLString']()]=_0x25804f,_0x25804f;}class tf{constructor(_0x2c93bc,_0x1c72e8){this['_repoInternal']=_0x2c93bc,this['app']=_0x1c72e8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x48ba7b){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x48ba7b+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x17b0cd=Zr(),_0x33f12b){const _0x18175b=Hi(_0x17b0cd,'database')['getImmediate']({'identifier':_0x33f12b});if(!_0x18175b['_instanceStarted']){const _0x3b3ade=hc('database');_0x3b3ade&&nf(_0x18175b,..._0x3b3ade);}return _0x18175b;}function nf(_0x2e4745,_0x481d2e,_0x45bc93,_0x30e933={}){_0x2e4745=P(_0x2e4745),_0x2e4745['_checkNotDeleted']('useEmulator');const _0x2d9a94=_0x481d2e+':'+_0x45bc93,_0x301693=_0x2e4745['_repoInternal'];if(_0x2e4745['_instanceStarted']){if(_0x2d9a94===_0x2e4745['_repoInternal']['repoInfo_']['host']&&xe(_0x30e933,_0x301693['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1b8384;if(_0x301693['repoInfo_']['nodeAdmin'])_0x30e933['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1b8384=new an(an['OWNER']);else{if(_0x30e933['mockUserToken']){const _0x569e4a=typeof _0x30e933['mockUserToken']=='string'?_0x30e933['mockUserToken']:uc(_0x30e933['mockUserToken'],_0x2e4745['app']['options']['projectId']);_0x1b8384=new an(_0x569e4a);}}qt(_0x481d2e)&&Qr(_0x481d2e),Jd(_0x301693,_0x2d9a94,_0x30e933,_0x1b8384);}function N_(_0x4c32c8){_0x4c32c8=P(_0x4c32c8),_0x4c32c8['_checkNotDeleted']('goOffline'),ha(_0x4c32c8['_repo']);}function O_(_0x25c908){_0x25c908=P(_0x25c908),_0x25c908['_checkNotDeleted']('goOnline'),Nd(_0x25c908['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x594513){Ul(dt),st(new Fe('database',(_0x3e32f0,{instanceIdentifier:_0x411125})=>{const _0xc5c6e=_0x3e32f0['getProvider']('app')['getImmediate'](),_0x30d723=_0x3e32f0['getProvider']('auth-internal'),_0x5b8e81=_0x3e32f0['getProvider']('app-check-internal');return Xd(_0xc5c6e,_0x30d723,_0x5b8e81,_0x411125);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x594513),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x4577bd,_0x4440f3){this['committed']=_0x4577bd,this['snapshot']=_0x4440f3;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x101783,_0x88528a,_0x1be82f){if(_0x101783=P(_0x101783),Me('Reference.transaction',_0x101783['_path']),_0x101783['key']==='.length'||_0x101783['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x101783['key']+'\x20is\x20a\x20read-only\x20object.';const _0x20b7fd=!0x0,_0x352632=new H(),_0x8dd224=(_0xf07706,_0x5828bd,_0xbea5b)=>{let _0x89100a=null;_0xf07706?_0x352632['reject'](_0xf07706):(_0x89100a=new lt(_0xbea5b,new ee(_0x101783['_repo'],_0x101783['_path']),R),_0x352632['resolve'](new of(_0x5828bd,_0x89100a)));},_0x407dc5=Gd(_0x101783,()=>{});return Od(_0x101783['_repo'],_0x101783['_path'],_0x88528a,_0x8dd224,_0x407dc5,_0x20b7fd),_0x352632['promise'];}se['prototype']['simpleListen']=function(_0x4be6eb,_0x3946b5){this['sendRequest']('q',{'p':_0x4be6eb},_0x3946b5);},se['prototype']['echo']=function(_0x316ccb,_0x2df1cd){this['sendRequest']('echo',{'d':_0x316ccb},_0x2df1cd);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0xd0efee,..._0x3ac05b){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0xd0efee,..._0x3ac05b);}function cn(_0x182164,..._0x446910){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x182164,..._0x446910);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x55ff9a,..._0x50f79a){throw ws(_0x55ff9a,..._0x50f79a);}function X(_0x34771c,..._0x33f2be){return ws(_0x34771c,..._0x33f2be);}function Ia(_0x501b07,_0x458294,_0x2b6094){const _0x393a66={...af(),[_0x458294]:_0x2b6094};return new Gt('auth','Firebase',_0x393a66)['create'](_0x458294,{'appName':_0x501b07['name']});}function re(_0x20862f){return Ia(_0x20862f,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xb4ead5,..._0x48266a){if(typeof _0xb4ead5!='string'){const _0x3758d3=_0x48266a[0x0],_0x4629c0=[..._0x48266a['slice'](0x1)];return _0x4629c0[0x0]&&(_0x4629c0[0x0]['appName']=_0xb4ead5['name']),_0xb4ead5['_errorFactory']['create'](_0x3758d3,..._0x4629c0);}return Ea['create'](_0xb4ead5,..._0x48266a);}function m(_0x3d29f7,_0x1da7f6,..._0xbd949){if(!_0x3d29f7)throw ws(_0x1da7f6,..._0xbd949);}function ne(_0x3aea88){const _0x431ff4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3aea88;throw cn(_0x431ff4),new Error(_0x431ff4);}function ce(_0x1cc6b3,_0x13a0db){_0x1cc6b3||ne(_0x13a0db);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0xb03ee3;return typeof self<'u'&&((_0xb03ee3=self['location'])==null?void 0x0:_0xb03ee3['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x41ea2e;return typeof self<'u'&&((_0x41ea2e=self['location'])==null?void 0x0:_0x41ea2e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x56a0fc=navigator;return _0x56a0fc['languages']&&_0x56a0fc['languages'][0x0]||_0x56a0fc['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5996b5,_0x5f0464){this['shortDelay']=_0x5996b5,this['longDelay']=_0x5f0464,ce(_0x5f0464>_0x5996b5,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x217d5a,_0x598a5f){ce(_0x217d5a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x43dcbc}=_0x217d5a['emulator'];return _0x598a5f?''+_0x43dcbc+(_0x598a5f['startsWith']('/')?_0x598a5f['slice'](0x1):_0x598a5f):_0x43dcbc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3be39b,_0x247d88,_0x5b9042){this['fetchImpl']=_0x3be39b,_0x247d88&&(this['headersImpl']=_0x247d88),_0x5b9042&&(this['responseImpl']=_0x5b9042);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x1b2322,_0x48867b){return _0x1b2322['tenantId']&&!_0x48867b['tenantId']?{..._0x48867b,'tenantId':_0x1b2322['tenantId']}:_0x48867b;}async function Pe(_0x4fd34b,_0x5da748,_0x32c4d7,_0x50aa4c,_0xe85ed4={}){return Ca(_0x4fd34b,_0xe85ed4,async()=>{let _0x5c7873={},_0xf854a8={};_0x50aa4c&&(_0x5da748==='GET'?_0xf854a8=_0x50aa4c:_0x5c7873={'body':JSON['stringify'](_0x50aa4c)});const _0x118f63=ut({..._0xf854a8,'key':_0x4fd34b['config']['apiKey']})['slice'](0x1),_0x535738=await _0x4fd34b['_getAdditionalHeaders']();_0x535738['Content-Type']='application/json',_0x4fd34b['languageCode']&&(_0x535738['X-Firebase-Locale']=_0x4fd34b['languageCode']);const _0x540089={'method':_0x5da748,'headers':_0x535738,..._0x5c7873};return dc()||(_0x540089['referrerPolicy']='strict-origin-when-cross-origin'),_0x4fd34b['emulatorConfig']&&qt(_0x4fd34b['emulatorConfig']['host'])&&(_0x540089['credentials']='include'),wa['fetch']()(await Ta(_0x4fd34b,_0x4fd34b['config']['apiHost'],_0x32c4d7,_0x118f63),_0x540089);});}async function Ca(_0x2e5ad0,_0x1e9da7,_0x1cdd62){_0x2e5ad0['_canInitEmulator']=!0x1;const _0xe33bd={...df,..._0x1e9da7};try{const _0x21d52f=new gf(_0x2e5ad0),_0x6c2d8f=await Promise['race']([_0x1cdd62(),_0x21d52f['promise']]);_0x21d52f['clearNetworkTimeout']();const _0x5f41b1=await _0x6c2d8f['json']();if('needConfirmation'in _0x5f41b1)throw on(_0x2e5ad0,'account-exists-with-different-credential',_0x5f41b1);if(_0x6c2d8f['ok']&&!('errorMessage'in _0x5f41b1))return _0x5f41b1;{const _0x16a8f2=_0x6c2d8f['ok']?_0x5f41b1['errorMessage']:_0x5f41b1['error']['message'],[_0x246a77,_0x55c7f5]=_0x16a8f2['split']('\x20:\x20');if(_0x246a77==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2e5ad0,'credential-already-in-use',_0x5f41b1);if(_0x246a77==='EMAIL_EXISTS')throw on(_0x2e5ad0,'email-already-in-use',_0x5f41b1);if(_0x246a77==='USER_DISABLED')throw on(_0x2e5ad0,'user-disabled',_0x5f41b1);const _0x54e818=_0xe33bd[_0x246a77]||_0x246a77['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x55c7f5)throw Ia(_0x2e5ad0,_0x54e818,_0x55c7f5);Y(_0x2e5ad0,_0x54e818);}}catch(_0x155c49){if(_0x155c49 instanceof Re)throw _0x155c49;Y(_0x2e5ad0,'network-request-failed',{'message':String(_0x155c49)});}}async function en(_0x40b517,_0x3fc20e,_0x47ce69,_0x432ef9,_0x358766={}){const _0x47bd81=await Pe(_0x40b517,_0x3fc20e,_0x47ce69,_0x432ef9,_0x358766);return'mfaPendingCredential'in _0x47bd81&&Y(_0x40b517,'multi-factor-auth-required',{'_serverResponse':_0x47bd81}),_0x47bd81;}async function Ta(_0x522cd6,_0x5847ea,_0x3a86e6,_0x58a837){const _0x28b7b8=''+_0x5847ea+_0x3a86e6+'?'+_0x58a837,_0x24485a=_0x522cd6,_0x2fd1ce=_0x24485a['config']['emulator']?Cs(_0x522cd6['config'],_0x28b7b8):_0x522cd6['config']['apiScheme']+'://'+_0x28b7b8;return ff['includes'](_0x3a86e6)&&(await _0x24485a['_persistenceManagerAvailable'],_0x24485a['_getPersistenceType']()==='COOKIE')?_0x24485a['_getPersistence']()['_getFinalTarget'](_0x2fd1ce)['toString']():_0x2fd1ce;}function _f(_0x3863b5){switch(_0x3863b5){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x559881){this['auth']=_0x559881,this['timer']=null,this['promise']=new Promise((_0x9a7b2c,_0x315288)=>{this['timer']=setTimeout(()=>_0x315288(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x552d6e,_0x28d83f,_0x8304b8){const _0xdc8ddf={'appName':_0x552d6e['name']};_0x8304b8['email']&&(_0xdc8ddf['email']=_0x8304b8['email']),_0x8304b8['phoneNumber']&&(_0xdc8ddf['phoneNumber']=_0x8304b8['phoneNumber']);const _0x1c6471=X(_0x552d6e,_0x28d83f,_0xdc8ddf);return _0x1c6471['customData']['_tokenResponse']=_0x8304b8,_0x1c6471;}function wr(_0x1a4064){return _0x1a4064!==void 0x0&&_0x1a4064['enterprise']!==void 0x0;}class mf{constructor(_0x4a5987){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4a5987['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4a5987['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4a5987['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x15dc65){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xebf310 of this['recaptchaEnforcementState'])if(_0xebf310['provider']&&_0xebf310['provider']===_0x15dc65)return _f(_0xebf310['enforcementState']);return null;}['isProviderEnabled'](_0x14f8a6){return this['getProviderEnforcementState'](_0x14f8a6)==='ENFORCE'||this['getProviderEnforcementState'](_0x14f8a6)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x46a8e9,_0x27116c){return Pe(_0x46a8e9,'GET','/v2/recaptchaConfig',ke(_0x46a8e9,_0x27116c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x2b7f27,_0x567b51){return Pe(_0x2b7f27,'POST','/v1/accounts:delete',_0x567b51);}async function Pn(_0x2b37e7,_0x24599d){return Pe(_0x2b37e7,'POST','/v1/accounts:lookup',_0x24599d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2327ea){if(_0x2327ea)try{const _0x388198=new Date(Number(_0x2327ea));if(!isNaN(_0x388198['getTime']()))return _0x388198['toUTCString']();}catch{}}async function Ef(_0x41c597,_0x4a8dae=!0x1){const _0x10d395=P(_0x41c597),_0xf9b4ad=await _0x10d395['getIdToken'](_0x4a8dae),_0x2e8b5b=Ts(_0xf9b4ad);m(_0x2e8b5b&&_0x2e8b5b['exp']&&_0x2e8b5b['auth_time']&&_0x2e8b5b['iat'],_0x10d395['auth'],'internal-error');const _0x4dd259=typeof _0x2e8b5b['firebase']=='object'?_0x2e8b5b['firebase']:void 0x0,_0x2f99cd=_0x4dd259==null?void 0x0:_0x4dd259['sign_in_provider'];return{'claims':_0x2e8b5b,'token':_0xf9b4ad,'authTime':Pt(fi(_0x2e8b5b['auth_time'])),'issuedAtTime':Pt(fi(_0x2e8b5b['iat'])),'expirationTime':Pt(fi(_0x2e8b5b['exp'])),'signInProvider':_0x2f99cd||null,'signInSecondFactor':(_0x4dd259==null?void 0x0:_0x4dd259['sign_in_second_factor'])||null};}function fi(_0x3d9fdd){return Number(_0x3d9fdd)*0x3e8;}function Ts(_0x2d52e1){const [_0x3b2a27,_0x3d7e38,_0x50bd07]=_0x2d52e1['split']('.');if(_0x3b2a27===void 0x0||_0x3d7e38===void 0x0||_0x50bd07===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2f751d=fn(_0x3d7e38);return _0x2f751d?JSON['parse'](_0x2f751d):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5d75f1){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5d75f1==null?void 0x0:_0x5d75f1['toString']()),null;}}function Cr(_0x538efd){const _0x560bb0=Ts(_0x538efd);return m(_0x560bb0,'internal-error'),m(typeof _0x560bb0['exp']<'u','internal-error'),m(typeof _0x560bb0['iat']<'u','internal-error'),Number(_0x560bb0['exp'])-Number(_0x560bb0['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x523666,_0x423b16,_0x38990e=!0x1){if(_0x38990e)return _0x423b16;try{return await _0x423b16;}catch(_0x55468b){throw _0x55468b instanceof Re&&If(_0x55468b)&&_0x523666['auth']['currentUser']===_0x523666&&await _0x523666['auth']['signOut'](),_0x55468b;}}function If({code:_0x1132d4}){return _0x1132d4==='auth/user-disabled'||_0x1132d4==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x577f4b){this['user']=_0x577f4b,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x16bf71){if(_0x16bf71){const _0x300d2b=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x300d2b;}else{this['errorBackoff']=0x7530;const _0x3d0396=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3d0396);}}['schedule'](_0x4fb33a=!0x1){if(!this['isRunning'])return;const _0x2a20d8=this['getInterval'](_0x4fb33a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2a20d8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3a691c){(_0x3a691c==null?void 0x0:_0x3a691c['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x34aae0,_0x3f7fc7){this['createdAt']=_0x34aae0,this['lastLoginAt']=_0x3f7fc7,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x1f8ad6){this['createdAt']=_0x1f8ad6['createdAt'],this['lastLoginAt']=_0x1f8ad6['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x1ef1b8){var _0x25d786;const _0x5d6929=_0x1ef1b8['auth'],_0x8c9d1d=await _0x1ef1b8['getIdToken'](),_0x56eace=await Ht(_0x1ef1b8,Pn(_0x5d6929,{'idToken':_0x8c9d1d}));m(_0x56eace==null?void 0x0:_0x56eace['users']['length'],_0x5d6929,'internal-error');const _0x343712=_0x56eace['users'][0x0];_0x1ef1b8['_notifyReloadListener'](_0x343712);const _0x131ad4=(_0x25d786=_0x343712['providerUserInfo'])!=null&&_0x25d786['length']?Sa(_0x343712['providerUserInfo']):[],_0x4b155e=Tf(_0x1ef1b8['providerData'],_0x131ad4),_0x23cd08=_0x1ef1b8['isAnonymous'],_0x147cab=!(_0x1ef1b8['email']&&_0x343712['passwordHash'])&&!(_0x4b155e!=null&&_0x4b155e['length']),_0x27e1de=_0x23cd08?_0x147cab:!0x1,_0x596375={'uid':_0x343712['localId'],'displayName':_0x343712['displayName']||null,'photoURL':_0x343712['photoUrl']||null,'email':_0x343712['email']||null,'emailVerified':_0x343712['emailVerified']||!0x1,'phoneNumber':_0x343712['phoneNumber']||null,'tenantId':_0x343712['tenantId']||null,'providerData':_0x4b155e,'metadata':new Li(_0x343712['createdAt'],_0x343712['lastLoginAt']),'isAnonymous':_0x27e1de};Object['assign'](_0x1ef1b8,_0x596375);}async function Cf(_0x4677ec){const _0x383c4a=P(_0x4677ec);await Nn(_0x383c4a),await _0x383c4a['auth']['_persistUserIfCurrent'](_0x383c4a),_0x383c4a['auth']['_notifyListenersIfCurrent'](_0x383c4a);}function Tf(_0x2fe977,_0x41684a){return[..._0x2fe977['filter'](_0x245cd6=>!_0x41684a['some'](_0x2f3d15=>_0x2f3d15['providerId']===_0x245cd6['providerId'])),..._0x41684a];}function Sa(_0x3cc235){return _0x3cc235['map'](({providerId:_0x375504,..._0x2807ea})=>({'providerId':_0x375504,'uid':_0x2807ea['rawId']||'','displayName':_0x2807ea['displayName']||null,'email':_0x2807ea['email']||null,'phoneNumber':_0x2807ea['phoneNumber']||null,'photoURL':_0x2807ea['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4d331c,_0x19c0ae){const _0x42abdd=await Ca(_0x4d331c,{},async()=>{const _0x1a3cf1=ut({'grant_type':'refresh_token','refresh_token':_0x19c0ae})['slice'](0x1),{tokenApiHost:_0x39f88d,apiKey:_0x4d2828}=_0x4d331c['config'],_0x1c0aa7=await Ta(_0x4d331c,_0x39f88d,'/v1/token','key='+_0x4d2828),_0x13bf03=await _0x4d331c['_getAdditionalHeaders']();_0x13bf03['Content-Type']='application/x-www-form-urlencoded';const _0x12cdf2={'method':'POST','headers':_0x13bf03,'body':_0x1a3cf1};return _0x4d331c['emulatorConfig']&&qt(_0x4d331c['emulatorConfig']['host'])&&(_0x12cdf2['credentials']='include'),wa['fetch']()(_0x1c0aa7,_0x12cdf2);});return{'accessToken':_0x42abdd['access_token'],'expiresIn':_0x42abdd['expires_in'],'refreshToken':_0x42abdd['refresh_token']};}async function bf(_0xe3988b,_0x9ef6ca){return Pe(_0xe3988b,'POST','/v2/accounts:revokeToken',ke(_0xe3988b,_0x9ef6ca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2439ed){m(_0x2439ed['idToken'],'internal-error'),m(typeof _0x2439ed['idToken']<'u','internal-error'),m(typeof _0x2439ed['refreshToken']<'u','internal-error');const _0x435308='expiresIn'in _0x2439ed&&typeof _0x2439ed['expiresIn']<'u'?Number(_0x2439ed['expiresIn']):Cr(_0x2439ed['idToken']);this['updateTokensAndExpiration'](_0x2439ed['idToken'],_0x2439ed['refreshToken'],_0x435308);}['updateFromIdToken'](_0x564bce){m(_0x564bce['length']!==0x0,'internal-error');const _0x4ad95a=Cr(_0x564bce);this['updateTokensAndExpiration'](_0x564bce,null,_0x4ad95a);}async['getToken'](_0x47f923,_0x21a81f=!0x1){return!_0x21a81f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x47f923,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x47f923,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2ca73b,_0x8b1360){const {accessToken:_0x311524,refreshToken:_0x544631,expiresIn:_0x86b9c8}=await Sf(_0x2ca73b,_0x8b1360);this['updateTokensAndExpiration'](_0x311524,_0x544631,Number(_0x86b9c8));}['updateTokensAndExpiration'](_0x21e06d,_0x265465,_0x4c557f){this['refreshToken']=_0x265465||null,this['accessToken']=_0x21e06d||null,this['expirationTime']=Date['now']()+_0x4c557f*0x3e8;}static['fromJSON'](_0x57b039,_0x395ab3){const {refreshToken:_0x638a2a,accessToken:_0x4dace1,expirationTime:_0xd916d2}=_0x395ab3,_0x34020f=new et();return _0x638a2a&&(m(typeof _0x638a2a=='string','internal-error',{'appName':_0x57b039}),_0x34020f['refreshToken']=_0x638a2a),_0x4dace1&&(m(typeof _0x4dace1=='string','internal-error',{'appName':_0x57b039}),_0x34020f['accessToken']=_0x4dace1),_0xd916d2&&(m(typeof _0xd916d2=='number','internal-error',{'appName':_0x57b039}),_0x34020f['expirationTime']=_0xd916d2),_0x34020f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4348b5){this['accessToken']=_0x4348b5['accessToken'],this['refreshToken']=_0x4348b5['refreshToken'],this['expirationTime']=_0x4348b5['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x57b18b,_0x558a8c){m(typeof _0x57b18b=='string'||typeof _0x57b18b>'u','internal-error',{'appName':_0x558a8c});}class j{constructor({uid:_0x1c585f,auth:_0x4b39c0,stsTokenManager:_0x224980,..._0x1c5ad2}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1c585f,this['auth']=_0x4b39c0,this['stsTokenManager']=_0x224980,this['accessToken']=_0x224980['accessToken'],this['displayName']=_0x1c5ad2['displayName']||null,this['email']=_0x1c5ad2['email']||null,this['emailVerified']=_0x1c5ad2['emailVerified']||!0x1,this['phoneNumber']=_0x1c5ad2['phoneNumber']||null,this['photoURL']=_0x1c5ad2['photoURL']||null,this['isAnonymous']=_0x1c5ad2['isAnonymous']||!0x1,this['tenantId']=_0x1c5ad2['tenantId']||null,this['providerData']=_0x1c5ad2['providerData']?[..._0x1c5ad2['providerData']]:[],this['metadata']=new Li(_0x1c5ad2['createdAt']||void 0x0,_0x1c5ad2['lastLoginAt']||void 0x0);}async['getIdToken'](_0x15bf9f){const _0x4f1e05=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x15bf9f));return m(_0x4f1e05,this['auth'],'internal-error'),this['accessToken']!==_0x4f1e05&&(this['accessToken']=_0x4f1e05,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4f1e05;}['getIdTokenResult'](_0x533e9f){return Ef(this,_0x533e9f);}['reload'](){return Cf(this);}['_assign'](_0x5e17ed){this!==_0x5e17ed&&(m(this['uid']===_0x5e17ed['uid'],this['auth'],'internal-error'),this['displayName']=_0x5e17ed['displayName'],this['photoURL']=_0x5e17ed['photoURL'],this['email']=_0x5e17ed['email'],this['emailVerified']=_0x5e17ed['emailVerified'],this['phoneNumber']=_0x5e17ed['phoneNumber'],this['isAnonymous']=_0x5e17ed['isAnonymous'],this['tenantId']=_0x5e17ed['tenantId'],this['providerData']=_0x5e17ed['providerData']['map'](_0x22663a=>({..._0x22663a})),this['metadata']['_copy'](_0x5e17ed['metadata']),this['stsTokenManager']['_assign'](_0x5e17ed['stsTokenManager']));}['_clone'](_0xe5bfbe){const _0x5d47c1=new j({...this,'auth':_0xe5bfbe,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5d47c1['metadata']['_copy'](this['metadata']),_0x5d47c1;}['_onReload'](_0x51f4a3){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x51f4a3,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3eb60e){this['reloadListener']?this['reloadListener'](_0x3eb60e):this['reloadUserInfo']=_0x3eb60e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x56e4b4,_0x176e0f=!0x1){let _0x1fa2f6=!0x1;_0x56e4b4['idToken']&&_0x56e4b4['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x56e4b4),_0x1fa2f6=!0x0),_0x176e0f&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1fa2f6&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x39d802=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x39d802})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3dd9a7=>({..._0x3dd9a7})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2d8e97,_0x2b9e85){const _0x2c3861=_0x2b9e85['displayName']??void 0x0,_0x12c0c1=_0x2b9e85['email']??void 0x0,_0x5f187c=_0x2b9e85['phoneNumber']??void 0x0,_0x28ad0c=_0x2b9e85['photoURL']??void 0x0,_0x56d6a7=_0x2b9e85['tenantId']??void 0x0,_0x9aef62=_0x2b9e85['_redirectEventId']??void 0x0,_0x22a263=_0x2b9e85['createdAt']??void 0x0,_0x1b78d5=_0x2b9e85['lastLoginAt']??void 0x0,{uid:_0x1f34a6,emailVerified:_0x119325,isAnonymous:_0x539897,providerData:_0x2e63ab,stsTokenManager:_0x2afca3}=_0x2b9e85;m(_0x1f34a6&&_0x2afca3,_0x2d8e97,'internal-error');const _0xe4e32e=et['fromJSON'](this['name'],_0x2afca3);m(typeof _0x1f34a6=='string',_0x2d8e97,'internal-error'),le(_0x2c3861,_0x2d8e97['name']),le(_0x12c0c1,_0x2d8e97['name']),m(typeof _0x119325=='boolean',_0x2d8e97,'internal-error'),m(typeof _0x539897=='boolean',_0x2d8e97,'internal-error'),le(_0x5f187c,_0x2d8e97['name']),le(_0x28ad0c,_0x2d8e97['name']),le(_0x56d6a7,_0x2d8e97['name']),le(_0x9aef62,_0x2d8e97['name']),le(_0x22a263,_0x2d8e97['name']),le(_0x1b78d5,_0x2d8e97['name']);const _0x28e6f2=new j({'uid':_0x1f34a6,'auth':_0x2d8e97,'email':_0x12c0c1,'emailVerified':_0x119325,'displayName':_0x2c3861,'isAnonymous':_0x539897,'photoURL':_0x28ad0c,'phoneNumber':_0x5f187c,'tenantId':_0x56d6a7,'stsTokenManager':_0xe4e32e,'createdAt':_0x22a263,'lastLoginAt':_0x1b78d5});return _0x2e63ab&&Array['isArray'](_0x2e63ab)&&(_0x28e6f2['providerData']=_0x2e63ab['map'](_0x2c09c0=>({..._0x2c09c0}))),_0x9aef62&&(_0x28e6f2['_redirectEventId']=_0x9aef62),_0x28e6f2;}static async['_fromIdTokenResponse'](_0x1a3b86,_0xec6d33,_0x4a0565=!0x1){const _0x5cd0b4=new et();_0x5cd0b4['updateFromServerResponse'](_0xec6d33);const _0x59cb4f=new j({'uid':_0xec6d33['localId'],'auth':_0x1a3b86,'stsTokenManager':_0x5cd0b4,'isAnonymous':_0x4a0565});return await Nn(_0x59cb4f),_0x59cb4f;}static async['_fromGetAccountInfoResponse'](_0x2d16e8,_0x123ca5,_0xb62e1c){const _0x3e184e=_0x123ca5['users'][0x0];m(_0x3e184e['localId']!==void 0x0,'internal-error');const _0x443278=_0x3e184e['providerUserInfo']!==void 0x0?Sa(_0x3e184e['providerUserInfo']):[],_0x11f04d=!(_0x3e184e['email']&&_0x3e184e['passwordHash'])&&!(_0x443278!=null&&_0x443278['length']),_0x3c3cd2=new et();_0x3c3cd2['updateFromIdToken'](_0xb62e1c);const _0x5a9176=new j({'uid':_0x3e184e['localId'],'auth':_0x2d16e8,'stsTokenManager':_0x3c3cd2,'isAnonymous':_0x11f04d}),_0x49c81b={'uid':_0x3e184e['localId'],'displayName':_0x3e184e['displayName']||null,'photoURL':_0x3e184e['photoUrl']||null,'email':_0x3e184e['email']||null,'emailVerified':_0x3e184e['emailVerified']||!0x1,'phoneNumber':_0x3e184e['phoneNumber']||null,'tenantId':_0x3e184e['tenantId']||null,'providerData':_0x443278,'metadata':new Li(_0x3e184e['createdAt'],_0x3e184e['lastLoginAt']),'isAnonymous':!(_0x3e184e['email']&&_0x3e184e['passwordHash'])&&!(_0x443278!=null&&_0x443278['length'])};return Object['assign'](_0x5a9176,_0x49c81b),_0x5a9176;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xa9b1f1){ce(_0xa9b1f1 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x54345e=Tr['get'](_0xa9b1f1);return _0x54345e?(ce(_0x54345e instanceof _0xa9b1f1,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x54345e):(_0x54345e=new _0xa9b1f1(),Tr['set'](_0xa9b1f1,_0x54345e),_0x54345e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x448e6d,_0x2d15d4){this['storage'][_0x448e6d]=_0x2d15d4;}async['_get'](_0x317b92){const _0x38d409=this['storage'][_0x317b92];return _0x38d409===void 0x0?null:_0x38d409;}async['_remove'](_0x2a15d1){delete this['storage'][_0x2a15d1];}['_addListener'](_0x40aadb,_0x2b7fe4){}['_removeListener'](_0x453535,_0x2928e8){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4c825e,_0x4339b5,_0x1d6d3e){return'firebase:'+_0x4c825e+':'+_0x4339b5+':'+_0x1d6d3e;}class tt{constructor(_0x44fab4,_0x23d431,_0x5bbd71){this['persistence']=_0x44fab4,this['auth']=_0x23d431,this['userKey']=_0x5bbd71;const {config:_0x2e3636,name:_0x52350a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2e3636['apiKey'],_0x52350a),this['fullPersistenceKey']=ln('persistence',_0x2e3636['apiKey'],_0x52350a),this['boundEventHandler']=_0x23d431['_onStorageEvent']['bind'](_0x23d431),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4d473c){return this['persistence']['_set'](this['fullUserKey'],_0x4d473c['toJSON']());}async['getCurrentUser'](){const _0x3dfa95=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3dfa95)return null;if(typeof _0x3dfa95=='string'){const _0x204459=await Pn(this['auth'],{'idToken':_0x3dfa95})['catch'](()=>{});return _0x204459?j['_fromGetAccountInfoResponse'](this['auth'],_0x204459,_0x3dfa95):null;}return j['_fromJSON'](this['auth'],_0x3dfa95);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x13b4d9){if(this['persistence']===_0x13b4d9)return;const _0x573f55=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x13b4d9,_0x573f55)return this['setCurrentUser'](_0x573f55);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x27b457,_0x3c5f35,_0x3abfcf='authUser'){if(!_0x3c5f35['length'])return new tt(ie(Sr),_0x27b457,_0x3abfcf);const _0x5b273c=(await Promise['all'](_0x3c5f35['map'](async _0x52b6be=>{if(await _0x52b6be['_isAvailable']())return _0x52b6be;})))['filter'](_0xa69af5=>_0xa69af5);let _0x504cf3=_0x5b273c[0x0]||ie(Sr);const _0x3819bd=ln(_0x3abfcf,_0x27b457['config']['apiKey'],_0x27b457['name']);let _0x1db4b3=null;for(const _0xb9b5c1 of _0x3c5f35)try{const _0x52f2cf=await _0xb9b5c1['_get'](_0x3819bd);if(_0x52f2cf){let _0x27134a;if(typeof _0x52f2cf=='string'){const _0x2a18cb=await Pn(_0x27b457,{'idToken':_0x52f2cf})['catch'](()=>{});if(!_0x2a18cb)break;_0x27134a=await j['_fromGetAccountInfoResponse'](_0x27b457,_0x2a18cb,_0x52f2cf);}else _0x27134a=j['_fromJSON'](_0x27b457,_0x52f2cf);_0xb9b5c1!==_0x504cf3&&(_0x1db4b3=_0x27134a),_0x504cf3=_0xb9b5c1;break;}}catch{}const _0xadbfbc=_0x5b273c['filter'](_0x1caf3e=>_0x1caf3e['_shouldAllowMigration']);return!_0x504cf3['_shouldAllowMigration']||!_0xadbfbc['length']?new tt(_0x504cf3,_0x27b457,_0x3abfcf):(_0x504cf3=_0xadbfbc[0x0],_0x1db4b3&&await _0x504cf3['_set'](_0x3819bd,_0x1db4b3['toJSON']()),await Promise['all'](_0x3c5f35['map'](async _0x101881=>{if(_0x101881!==_0x504cf3)try{await _0x101881['_remove'](_0x3819bd);}catch{}})),new tt(_0x504cf3,_0x27b457,_0x3abfcf));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x473d02){const _0x205f98=_0x473d02['toLowerCase']();if(_0x205f98['includes']('opera/')||_0x205f98['includes']('opr/')||_0x205f98['includes']('opios/'))return'Opera';if(Pa(_0x205f98))return'IEMobile';if(_0x205f98['includes']('msie')||_0x205f98['includes']('trident/'))return'IE';if(_0x205f98['includes']('edge/'))return'Edge';if(Ra(_0x205f98))return'Firefox';if(_0x205f98['includes']('silk/'))return'Silk';if(Oa(_0x205f98))return'Blackberry';if(Da(_0x205f98))return'Webos';if(Aa(_0x205f98))return'Safari';if((_0x205f98['includes']('chrome/')||ka(_0x205f98))&&!_0x205f98['includes']('edge/'))return'Chrome';if(Na(_0x205f98))return'Android';{const _0x2846b3=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3edd6b=_0x473d02['match'](_0x2846b3);if((_0x3edd6b==null?void 0x0:_0x3edd6b['length'])===0x2)return _0x3edd6b[0x1];}return'Other';}function Ra(_0x57d3a4=W()){return/firefox\//i['test'](_0x57d3a4);}function Aa(_0x4db6dd=W()){const _0x350ebc=_0x4db6dd['toLowerCase']();return _0x350ebc['includes']('safari/')&&!_0x350ebc['includes']('chrome/')&&!_0x350ebc['includes']('crios/')&&!_0x350ebc['includes']('android');}function ka(_0x974b77=W()){return/crios\//i['test'](_0x974b77);}function Pa(_0x2f1488=W()){return/iemobile/i['test'](_0x2f1488);}function Na(_0x2a4550=W()){return/android/i['test'](_0x2a4550);}function Oa(_0x5100fd=W()){return/blackberry/i['test'](_0x5100fd);}function Da(_0x42df59=W()){return/webos/i['test'](_0x42df59);}function Ss(_0x1cbab7=W()){return/iphone|ipad|ipod/i['test'](_0x1cbab7)||/macintosh/i['test'](_0x1cbab7)&&/mobile/i['test'](_0x1cbab7);}function Rf(_0x411d6b=W()){var _0x537ce1;return Ss(_0x411d6b)&&!!((_0x537ce1=window['navigator'])!=null&&_0x537ce1['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x541b1a=W()){return Ss(_0x541b1a)||Na(_0x541b1a)||Da(_0x541b1a)||Oa(_0x541b1a)||/windows phone/i['test'](_0x541b1a)||Pa(_0x541b1a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x56b01f,_0x2467c8=[]){let _0x5971a6;switch(_0x56b01f){case'Browser':_0x5971a6=br(W());break;case'Worker':_0x5971a6=br(W())+'-'+_0x56b01f;break;default:_0x5971a6=_0x56b01f;}const _0x34482e=_0x2467c8['length']?_0x2467c8['join'](','):'FirebaseCore-web';return _0x5971a6+'/JsCore/'+dt+'/'+_0x34482e;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x110bc7){this['auth']=_0x110bc7,this['queue']=[];}['pushCallback'](_0x29b1f9,_0x432627){const _0x4f02ad=_0x208690=>new Promise((_0x52d31c,_0x233ee1)=>{try{const _0x1a6001=_0x29b1f9(_0x208690);_0x52d31c(_0x1a6001);}catch(_0x422a0e){_0x233ee1(_0x422a0e);}});_0x4f02ad['onAbort']=_0x432627,this['queue']['push'](_0x4f02ad);const _0x590662=this['queue']['length']-0x1;return()=>{this['queue'][_0x590662]=()=>Promise['resolve']();};}async['runMiddleware'](_0x12e208){if(this['auth']['currentUser']===_0x12e208)return;const _0x4d6e97=[];try{for(const _0x78cba9 of this['queue'])await _0x78cba9(_0x12e208),_0x78cba9['onAbort']&&_0x4d6e97['push'](_0x78cba9['onAbort']);}catch(_0x1c271a){_0x4d6e97['reverse']();for(const _0x13017e of _0x4d6e97)try{_0x13017e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1c271a==null?void 0x0:_0x1c271a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1a4bd8,_0x471670={}){return Pe(_0x1a4bd8,'GET','/v2/passwordPolicy',ke(_0x1a4bd8,_0x471670));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3157c3){var _0x57c9b0;const _0x33ef4f=_0x3157c3['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x33ef4f['minPasswordLength']??Nf,_0x33ef4f['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x33ef4f['maxPasswordLength']),_0x33ef4f['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x33ef4f['containsLowercaseCharacter']),_0x33ef4f['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x33ef4f['containsUppercaseCharacter']),_0x33ef4f['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x33ef4f['containsNumericCharacter']),_0x33ef4f['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x33ef4f['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3157c3['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x57c9b0=_0x3157c3['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x57c9b0['join'](''))??'',this['forceUpgradeOnSignin']=_0x3157c3['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3157c3['schemaVersion'];}['validatePassword'](_0x2ec44c){const _0x20c559={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2ec44c,_0x20c559),this['validatePasswordCharacterOptions'](_0x2ec44c,_0x20c559),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['meetsMinPasswordLength']??!0x0),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['meetsMaxPasswordLength']??!0x0),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['containsLowercaseLetter']??!0x0),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['containsUppercaseLetter']??!0x0),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['containsNumericCharacter']??!0x0),_0x20c559['isValid']&&(_0x20c559['isValid']=_0x20c559['containsNonAlphanumericCharacter']??!0x0),_0x20c559;}['validatePasswordLengthOptions'](_0x28a347,_0x15bc6e){const _0x3547b9=this['customStrengthOptions']['minPasswordLength'],_0x2ec6ba=this['customStrengthOptions']['maxPasswordLength'];_0x3547b9&&(_0x15bc6e['meetsMinPasswordLength']=_0x28a347['length']>=_0x3547b9),_0x2ec6ba&&(_0x15bc6e['meetsMaxPasswordLength']=_0x28a347['length']<=_0x2ec6ba);}['validatePasswordCharacterOptions'](_0x238ccb,_0x24a4fa){this['updatePasswordCharacterOptionsStatuses'](_0x24a4fa,!0x1,!0x1,!0x1,!0x1);let _0x53ee33;for(let _0x8bae0d=0x0;_0x8bae0d<_0x238ccb['length'];_0x8bae0d++)_0x53ee33=_0x238ccb['charAt'](_0x8bae0d),this['updatePasswordCharacterOptionsStatuses'](_0x24a4fa,_0x53ee33>='a'&&_0x53ee33<='z',_0x53ee33>='A'&&_0x53ee33<='Z',_0x53ee33>='0'&&_0x53ee33<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x53ee33));}['updatePasswordCharacterOptionsStatuses'](_0x1502e4,_0x2dc075,_0x550eef,_0x3273ac,_0x1e64ef){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1502e4['containsLowercaseLetter']||(_0x1502e4['containsLowercaseLetter']=_0x2dc075)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1502e4['containsUppercaseLetter']||(_0x1502e4['containsUppercaseLetter']=_0x550eef)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1502e4['containsNumericCharacter']||(_0x1502e4['containsNumericCharacter']=_0x3273ac)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1502e4['containsNonAlphanumericCharacter']||(_0x1502e4['containsNonAlphanumericCharacter']=_0x1e64ef));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x3e45a0,_0x3b7678,_0x5512f1,_0x392e3a){this['app']=_0x3e45a0,this['heartbeatServiceProvider']=_0x3b7678,this['appCheckServiceProvider']=_0x5512f1,this['config']=_0x392e3a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3e45a0['name'],this['clientVersion']=_0x392e3a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1b31c3=>this['_resolvePersistenceManagerAvailable']=_0x1b31c3);}['_initializeWithPersistence'](_0x574ce7,_0x754ed7){return _0x754ed7&&(this['_popupRedirectResolver']=ie(_0x754ed7)),this['_initializationPromise']=this['queue'](async()=>{var _0x16d20c,_0x4e8989,_0x5426b6;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x574ce7),(_0x16d20c=this['_resolvePersistenceManagerAvailable'])==null||_0x16d20c['call'](this),!this['_deleted'])){if((_0x4e8989=this['_popupRedirectResolver'])!=null&&_0x4e8989['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x754ed7),this['lastNotifiedUid']=((_0x5426b6=this['currentUser'])==null?void 0x0:_0x5426b6['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x323d07=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x323d07)){if(this['currentUser']&&_0x323d07&&this['currentUser']['uid']===_0x323d07['uid']){this['_currentUser']['_assign'](_0x323d07),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x323d07,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x537d18){try{const _0xae83cd=await Pn(this,{'idToken':_0x537d18}),_0x1d2d56=await j['_fromGetAccountInfoResponse'](this,_0xae83cd,_0x537d18);await this['directlySetCurrentUser'](_0x1d2d56);}catch(_0x32d74b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x32d74b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x39d9da){var _0x208530;if($(this['app'])){const _0x4d8433=this['app']['settings']['authIdToken'];return _0x4d8433?new Promise(_0x3a9926=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4d8433)['then'](_0x3a9926,_0x3a9926));}):this['directlySetCurrentUser'](null);}const _0x3f7d2b=await this['assertedPersistence']['getCurrentUser']();let _0x1764cf=_0x3f7d2b,_0x53b088=!0x1;if(_0x39d9da&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x597fa7=(_0x208530=this['redirectUser'])==null?void 0x0:_0x208530['_redirectEventId'],_0x3b46fc=_0x1764cf==null?void 0x0:_0x1764cf['_redirectEventId'],_0x53cf1f=await this['tryRedirectSignIn'](_0x39d9da);(!_0x597fa7||_0x597fa7===_0x3b46fc)&&(_0x53cf1f!=null&&_0x53cf1f['user'])&&(_0x1764cf=_0x53cf1f['user'],_0x53b088=!0x0);}if(!_0x1764cf)return this['directlySetCurrentUser'](null);if(!_0x1764cf['_redirectEventId']){if(_0x53b088)try{await this['beforeStateQueue']['runMiddleware'](_0x1764cf);}catch(_0x2b63b4){_0x1764cf=_0x3f7d2b,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2b63b4));}return _0x1764cf?this['reloadAndSetCurrentUserOrClear'](_0x1764cf):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1764cf['_redirectEventId']?this['directlySetCurrentUser'](_0x1764cf):this['reloadAndSetCurrentUserOrClear'](_0x1764cf);}async['tryRedirectSignIn'](_0x1433a4){let _0x2ab6b9=null;try{_0x2ab6b9=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1433a4,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2ab6b9;}async['reloadAndSetCurrentUserOrClear'](_0x36a2e7){try{await Nn(_0x36a2e7);}catch(_0x3bfc92){if((_0x3bfc92==null?void 0x0:_0x3bfc92['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x36a2e7);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x10c2db){if($(this['app']))return Promise['reject'](re(this));const _0x4dc7f4=_0x10c2db?P(_0x10c2db):null;return _0x4dc7f4&&m(_0x4dc7f4['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4dc7f4&&_0x4dc7f4['_clone'](this));}async['_updateCurrentUser'](_0x219c47,_0xd860d9=!0x1){if(!this['_deleted'])return _0x219c47&&m(this['tenantId']===_0x219c47['tenantId'],this,'tenant-id-mismatch'),_0xd860d9||await this['beforeStateQueue']['runMiddleware'](_0x219c47),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x219c47),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5deb8a){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5deb8a));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x581ff4){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5b9f93=this['_getPasswordPolicyInternal']();return _0x5b9f93['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5b9f93['validatePassword'](_0x581ff4);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x576f8c=await Pf(this),_0x108df5=new Of(_0x576f8c);this['tenantId']===null?this['_projectPasswordPolicy']=_0x108df5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x108df5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2f2f50){this['_errorFactory']=new Gt('auth','Firebase',_0x2f2f50());}['onAuthStateChanged'](_0x23452e,_0x5be4be,_0x3157bb){return this['registerStateListener'](this['authStateSubscription'],_0x23452e,_0x5be4be,_0x3157bb);}['beforeAuthStateChanged'](_0x2c356f,_0x3fa448){return this['beforeStateQueue']['pushCallback'](_0x2c356f,_0x3fa448);}['onIdTokenChanged'](_0x3106b0,_0x4c40d1,_0x1a2c93){return this['registerStateListener'](this['idTokenSubscription'],_0x3106b0,_0x4c40d1,_0x1a2c93);}['authStateReady'](){return new Promise((_0x3e39d9,_0xa61865)=>{if(this['currentUser'])_0x3e39d9();else{const _0x3f88ac=this['onAuthStateChanged'](()=>{_0x3f88ac(),_0x3e39d9();},_0xa61865);}});}async['revokeAccessToken'](_0x537216){if(this['currentUser']){const _0x575c09=await this['currentUser']['getIdToken'](),_0x1eddb5={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x537216,'idToken':_0x575c09};this['tenantId']!=null&&(_0x1eddb5['tenantId']=this['tenantId']),await bf(this,_0x1eddb5);}}['toJSON'](){var _0x5a24ac;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5a24ac=this['_currentUser'])==null?void 0x0:_0x5a24ac['toJSON']()};}async['_setRedirectUser'](_0x4280d7,_0x22ff9c){const _0x3e8696=await this['getOrInitRedirectPersistenceManager'](_0x22ff9c);return _0x4280d7===null?_0x3e8696['removeCurrentUser']():_0x3e8696['setCurrentUser'](_0x4280d7);}async['getOrInitRedirectPersistenceManager'](_0x355c0e){if(!this['redirectPersistenceManager']){const _0x3497b6=_0x355c0e&&ie(_0x355c0e)||this['_popupRedirectResolver'];m(_0x3497b6,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3497b6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2b3093){var _0x2a7b15,_0x3f5f21;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2a7b15=this['_currentUser'])==null?void 0x0:_0x2a7b15['_redirectEventId'])===_0x2b3093?this['_currentUser']:((_0x3f5f21=this['redirectUser'])==null?void 0x0:_0x3f5f21['_redirectEventId'])===_0x2b3093?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x138c5b){if(_0x138c5b===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x138c5b));}['_notifyListenersIfCurrent'](_0x3756ea){_0x3756ea===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5ef199;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x27c254=((_0x5ef199=this['currentUser'])==null?void 0x0:_0x5ef199['uid'])??null;this['lastNotifiedUid']!==_0x27c254&&(this['lastNotifiedUid']=_0x27c254,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xe518a7,_0x3b7bbf,_0x3779e2,_0x474dc0){if(this['_deleted'])return()=>{};const _0x3b825e=typeof _0x3b7bbf=='function'?_0x3b7bbf:_0x3b7bbf['next']['bind'](_0x3b7bbf);let _0x38056c=!0x1;const _0x4a4042=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4a4042,this,'internal-error'),_0x4a4042['then'](()=>{_0x38056c||_0x3b825e(this['currentUser']);}),typeof _0x3b7bbf=='function'){const _0x47c5fd=_0xe518a7['addObserver'](_0x3b7bbf,_0x3779e2,_0x474dc0);return()=>{_0x38056c=!0x0,_0x47c5fd();};}else{const _0x79e261=_0xe518a7['addObserver'](_0x3b7bbf);return()=>{_0x38056c=!0x0,_0x79e261();};}}async['directlySetCurrentUser'](_0x520d99){this['currentUser']&&this['currentUser']!==_0x520d99&&this['_currentUser']['_stopProactiveRefresh'](),_0x520d99&&this['isProactiveRefreshEnabled']&&_0x520d99['_startProactiveRefresh'](),this['currentUser']=_0x520d99,_0x520d99?await this['assertedPersistence']['setCurrentUser'](_0x520d99):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1da43c){return this['operations']=this['operations']['then'](_0x1da43c,_0x1da43c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1593e4){!_0x1593e4||this['frameworks']['includes'](_0x1593e4)||(this['frameworks']['push'](_0x1593e4),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xc20448;const _0x15197b={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x15197b['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x518696=await((_0xc20448=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xc20448['getHeartbeatsHeader']());_0x518696&&(_0x15197b['X-Firebase-Client']=_0x518696);const _0x58165d=await this['_getAppCheckToken']();return _0x58165d&&(_0x15197b['X-Firebase-AppCheck']=_0x58165d),_0x15197b;}async['_getAppCheckToken'](){var _0x51f678;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xd71278=await((_0x51f678=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x51f678['getToken']());return _0xd71278!=null&&_0xd71278['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xd71278['error']),_0xd71278==null?void 0x0:_0xd71278['token'];}}function Ke(_0x5e13a8){return P(_0x5e13a8);}class Rr{constructor(_0x3a7d6a){this['auth']=_0x3a7d6a,this['observer']=null,this['addObserver']=Tc(_0x43bf5b=>this['observer']=_0x43bf5b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1cb73a){Jn=_0x1cb73a;}function xa(_0xc45e2b){return Jn['loadJS'](_0xc45e2b);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x5549a2){return'__'+_0x5549a2+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xb6c0fb){_0xb6c0fb();}['execute'](_0x28abdf,_0x36bd8b){return Promise['resolve']('token');}['render'](_0x7a49ae,_0x24238a){return'';}}class Wf{['ready'](_0x366ffc){_0x366ffc();}['execute'](_0x52e317,_0x30655b){return Promise['resolve']('token');}['render'](_0xb6c0ee,_0x585dec){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x64386e){this['type']=Bf,this['auth']=Ke(_0x64386e);}async['verify'](_0x3117e9='verify',_0x1d553f=!0x1){async function _0x166f49(_0x48c974){if(!_0x1d553f){if(_0x48c974['tenantId']==null&&_0x48c974['_agentRecaptchaConfig']!=null)return _0x48c974['_agentRecaptchaConfig']['siteKey'];if(_0x48c974['tenantId']!=null&&_0x48c974['_tenantRecaptchaConfigs'][_0x48c974['tenantId']]!==void 0x0)return _0x48c974['_tenantRecaptchaConfigs'][_0x48c974['tenantId']]['siteKey'];}return new Promise(async(_0x557dfb,_0x2ed98c)=>{yf(_0x48c974,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x462d7a=>{if(_0x462d7a['recaptchaKey']===void 0x0)_0x2ed98c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4022c9=new mf(_0x462d7a);return _0x48c974['tenantId']==null?_0x48c974['_agentRecaptchaConfig']=_0x4022c9:_0x48c974['_tenantRecaptchaConfigs'][_0x48c974['tenantId']]=_0x4022c9,_0x557dfb(_0x4022c9['siteKey']);}})['catch'](_0x1fbb81=>{_0x2ed98c(_0x1fbb81);});});}function _0x1e1b2a(_0x10e0ae,_0x5a9527,_0xecfaa9){const _0x3caa37=window['grecaptcha'];wr(_0x3caa37)?_0x3caa37['enterprise']['ready'](()=>{_0x3caa37['enterprise']['execute'](_0x10e0ae,{'action':_0x3117e9})['then'](_0x33ffa1=>{_0x5a9527(_0x33ffa1);})['catch'](()=>{_0x5a9527(Fa);});}):_0xecfaa9(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4ea4f1,_0x3e7a8d)=>{_0x166f49(this['auth'])['then'](async _0x338021=>{if(!_0x1d553f&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x1e1b2a(_0x338021,_0x4ea4f1,_0x3e7a8d);else{if(typeof window>'u'){_0x3e7a8d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x16cb9b=Lf();_0x16cb9b['length']!==0x0&&(_0x16cb9b+=_0x338021+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x474545;(_0x474545=he['scriptInjectionDeferred'])==null||_0x474545['resolve']();},xa(_0x16cb9b)['then'](()=>{var _0xce81fc;return(_0xce81fc=he['scriptInjectionDeferred'])==null?void 0x0:_0xce81fc['promise'];})['then'](()=>{_0x1e1b2a(_0x338021,_0x4ea4f1,_0x3e7a8d);})['catch'](_0x2e6cc0=>{_0x3e7a8d(_0x2e6cc0);});}})['catch'](_0x8ede2d=>{_0x3e7a8d(_0x8ede2d);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x1b7c4e,_0x245dda,_0x91fa34,_0x43ed9b=!0x1,_0x210676=!0x1){const _0x2506ee=new he(_0x1b7c4e);let _0xcc0289;if(_0x210676)_0xcc0289=Fa;else try{_0xcc0289=await _0x2506ee['verify'](_0x91fa34);}catch{_0xcc0289=await _0x2506ee['verify'](_0x91fa34,!0x0);}const _0x17109a={..._0x245dda};if(_0x91fa34==='mfaSmsEnrollment'||_0x91fa34==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x17109a){const _0x551d74=_0x17109a['phoneEnrollmentInfo']['phoneNumber'],_0x1626c8=_0x17109a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x17109a,{'phoneEnrollmentInfo':{'phoneNumber':_0x551d74,'recaptchaToken':_0x1626c8,'captchaResponse':_0xcc0289,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x17109a){const _0x32c3d6=_0x17109a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x17109a,{'phoneSignInInfo':{'recaptchaToken':_0x32c3d6,'captchaResponse':_0xcc0289,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x17109a;}return _0x43ed9b?Object['assign'](_0x17109a,{'captchaResp':_0xcc0289}):Object['assign'](_0x17109a,{'captchaResponse':_0xcc0289}),Object['assign'](_0x17109a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x17109a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x17109a;}async function xi(_0x5bfca4,_0x2e9e6e,_0xa2fd87,_0x4f38a5,_0x1e5287){var _0x34718b;if((_0x34718b=_0x5bfca4['_getRecaptchaConfig']())!=null&&_0x34718b['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3c129c=await kr(_0x5bfca4,_0x2e9e6e,_0xa2fd87,_0xa2fd87==='getOobCode');return _0x4f38a5(_0x5bfca4,_0x3c129c);}else return _0x4f38a5(_0x5bfca4,_0x2e9e6e)['catch'](async _0x5d4dad=>{if(_0x5d4dad['code']==='auth/missing-recaptcha-token'){console['log'](_0xa2fd87+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x23d1ec=await kr(_0x5bfca4,_0x2e9e6e,_0xa2fd87,_0xa2fd87==='getOobCode');return _0x4f38a5(_0x5bfca4,_0x23d1ec);}else return Promise['reject'](_0x5d4dad);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x5cfb2c,_0x15a7e5){const _0x5c918b=Hi(_0x5cfb2c,'auth');if(_0x5c918b['isInitialized']()){const _0x4bbb51=_0x5c918b['getImmediate'](),_0x2ec7a5=_0x5c918b['getOptions']();if(xe(_0x2ec7a5,_0x15a7e5??{}))return _0x4bbb51;Y(_0x4bbb51,'already-initialized');}return _0x5c918b['initialize']({'options':_0x15a7e5});}function Hf(_0x33084d,_0x1f6452){const _0x553251=(_0x1f6452==null?void 0x0:_0x1f6452['persistence'])||[],_0xa48a29=(Array['isArray'](_0x553251)?_0x553251:[_0x553251])['map'](ie);_0x1f6452!=null&&_0x1f6452['errorMap']&&_0x33084d['_updateErrorMap'](_0x1f6452['errorMap']),_0x33084d['_initializeWithPersistence'](_0xa48a29,_0x1f6452==null?void 0x0:_0x1f6452['popupRedirectResolver']);}function $f(_0x3f2f34,_0x112438,_0xe05824){const _0x3e3fce=Ke(_0x3f2f34);m(/^https?:\/\//['test'](_0x112438),_0x3e3fce,'invalid-emulator-scheme');const _0x8af559=!0x1,_0x3d229f=Ua(_0x112438),{host:_0x1352df,port:_0x5a4f27}=Gf(_0x112438),_0x2cf387=_0x5a4f27===null?'':':'+_0x5a4f27,_0x4d4655={'url':_0x3d229f+'//'+_0x1352df+_0x2cf387+'/'},_0x5d4157=Object['freeze']({'host':_0x1352df,'port':_0x5a4f27,'protocol':_0x3d229f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x8af559})});if(!_0x3e3fce['_canInitEmulator']){m(_0x3e3fce['config']['emulator']&&_0x3e3fce['emulatorConfig'],_0x3e3fce,'emulator-config-failed'),m(xe(_0x4d4655,_0x3e3fce['config']['emulator'])&&xe(_0x5d4157,_0x3e3fce['emulatorConfig']),_0x3e3fce,'emulator-config-failed');return;}_0x3e3fce['config']['emulator']=_0x4d4655,_0x3e3fce['emulatorConfig']=_0x5d4157,_0x3e3fce['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x1352df)?Qr(_0x3d229f+'//'+_0x1352df+_0x2cf387):qf();}function Ua(_0x8569f){const _0x5b5f0e=_0x8569f['indexOf'](':');return _0x5b5f0e<0x0?'':_0x8569f['substr'](0x0,_0x5b5f0e+0x1);}function Gf(_0x4f8b81){const _0x557759=Ua(_0x4f8b81),_0x2ec062=/(\/\/)?([^?#/]+)/['exec'](_0x4f8b81['substr'](_0x557759['length']));if(!_0x2ec062)return{'host':'','port':null};const _0x3e0379=_0x2ec062[0x2]['split']('@')['pop']()||'',_0x438827=/^(\[[^\]]+\])(:|$)/['exec'](_0x3e0379);if(_0x438827){const _0x9db0ac=_0x438827[0x1];return{'host':_0x9db0ac,'port':Pr(_0x3e0379['substr'](_0x9db0ac['length']+0x1))};}else{const [_0x145d8e,_0x145c1b]=_0x3e0379['split'](':');return{'host':_0x145d8e,'port':Pr(_0x145c1b)};}}function Pr(_0x2076a7){if(!_0x2076a7)return null;const _0x5103d0=Number(_0x2076a7);return isNaN(_0x5103d0)?null:_0x5103d0;}function qf(){function _0x385704(){const _0x22f542=document['createElement']('p'),_0x4b5952=_0x22f542['style'];_0x22f542['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4b5952['position']='fixed',_0x4b5952['width']='100%',_0x4b5952['backgroundColor']='#ffffff',_0x4b5952['border']='.1em\x20solid\x20#000000',_0x4b5952['color']='#b50000',_0x4b5952['bottom']='0px',_0x4b5952['left']='0px',_0x4b5952['margin']='0px',_0x4b5952['zIndex']='10000',_0x4b5952['textAlign']='center',_0x22f542['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x22f542);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x385704):_0x385704());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xdcef5b,_0x1f2ad1){this['providerId']=_0xdcef5b,this['signInMethod']=_0x1f2ad1;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x598d83){return ne('not\x20implemented');}['_linkToIdToken'](_0x36611e,_0x1a38f3){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x4419a9){return ne('not\x20implemented');}}async function zf(_0x3486d5,_0x380bac){return Pe(_0x3486d5,'POST','/v1/accounts:signUp',_0x380bac);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x581102,_0x3da287){return en(_0x581102,'POST','/v1/accounts:signInWithPassword',ke(_0x581102,_0x3da287));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x45e0fa,_0x26bdf4){return en(_0x45e0fa,'POST','/v1/accounts:signInWithEmailLink',ke(_0x45e0fa,_0x26bdf4));}async function Yf(_0x584510,_0xacaa63){return en(_0x584510,'POST','/v1/accounts:signInWithEmailLink',ke(_0x584510,_0xacaa63));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x11fdfa,_0x293ae5,_0x1400bd,_0x243486=null){super('password',_0x1400bd),this['_email']=_0x11fdfa,this['_password']=_0x293ae5,this['_tenantId']=_0x243486;}static['_fromEmailAndPassword'](_0x2d33f5,_0x4a2d52){return new $t(_0x2d33f5,_0x4a2d52,'password');}static['_fromEmailAndCode'](_0x4e236c,_0xabd8bf,_0x430705=null){return new $t(_0x4e236c,_0xabd8bf,'emailLink',_0x430705);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3010fd){const _0x5e017c=typeof _0x3010fd=='string'?JSON['parse'](_0x3010fd):_0x3010fd;if(_0x5e017c!=null&&_0x5e017c['email']&&(_0x5e017c!=null&&_0x5e017c['password'])){if(_0x5e017c['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5e017c['email'],_0x5e017c['password']);if(_0x5e017c['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5e017c['email'],_0x5e017c['password'],_0x5e017c['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5c8d15){switch(this['signInMethod']){case'password':const _0x287974={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5c8d15,_0x287974,'signInWithPassword',jf);case'emailLink':return Kf(_0x5c8d15,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5c8d15,'internal-error');}}async['_linkToIdToken'](_0x2cbcd6,_0x535496){switch(this['signInMethod']){case'password':const _0xf7c5fa={'idToken':_0x535496,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2cbcd6,_0xf7c5fa,'signUpPassword',zf);case'emailLink':return Yf(_0x2cbcd6,{'idToken':_0x535496,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2cbcd6,'internal-error');}}['_getReauthenticationResolver'](_0x2cd482){return this['_getIdTokenResponse'](_0x2cd482);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x262899,_0x528583){return en(_0x262899,'POST','/v1/accounts:signInWithIdp',ke(_0x262899,_0x528583));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2ff413){const _0x475d31=new $e(_0x2ff413['providerId'],_0x2ff413['signInMethod']);return _0x2ff413['idToken']||_0x2ff413['accessToken']?(_0x2ff413['idToken']&&(_0x475d31['idToken']=_0x2ff413['idToken']),_0x2ff413['accessToken']&&(_0x475d31['accessToken']=_0x2ff413['accessToken']),_0x2ff413['nonce']&&!_0x2ff413['pendingToken']&&(_0x475d31['nonce']=_0x2ff413['nonce']),_0x2ff413['pendingToken']&&(_0x475d31['pendingToken']=_0x2ff413['pendingToken'])):_0x2ff413['oauthToken']&&_0x2ff413['oauthTokenSecret']?(_0x475d31['accessToken']=_0x2ff413['oauthToken'],_0x475d31['secret']=_0x2ff413['oauthTokenSecret']):Y('argument-error'),_0x475d31;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3699c8){const _0x32cd5b=typeof _0x3699c8=='string'?JSON['parse'](_0x3699c8):_0x3699c8,{providerId:_0x50322b,signInMethod:_0x18191f,..._0x4752f1}=_0x32cd5b;if(!_0x50322b||!_0x18191f)return null;const _0x1f2315=new $e(_0x50322b,_0x18191f);return _0x1f2315['idToken']=_0x4752f1['idToken']||void 0x0,_0x1f2315['accessToken']=_0x4752f1['accessToken']||void 0x0,_0x1f2315['secret']=_0x4752f1['secret'],_0x1f2315['nonce']=_0x4752f1['nonce'],_0x1f2315['pendingToken']=_0x4752f1['pendingToken']||null,_0x1f2315;}['_getIdTokenResponse'](_0x5ebf72){const _0xdea76=this['buildRequest']();return nt(_0x5ebf72,_0xdea76);}['_linkToIdToken'](_0x4a306a,_0x1b697a){const _0x488a45=this['buildRequest']();return _0x488a45['idToken']=_0x1b697a,nt(_0x4a306a,_0x488a45);}['_getReauthenticationResolver'](_0x57b106){const _0x1caa6d=this['buildRequest']();return _0x1caa6d['autoCreate']=!0x1,nt(_0x57b106,_0x1caa6d);}['buildRequest'](){const _0x3209e8={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3209e8['pendingToken']=this['pendingToken'];else{const _0x551059={};this['idToken']&&(_0x551059['id_token']=this['idToken']),this['accessToken']&&(_0x551059['access_token']=this['accessToken']),this['secret']&&(_0x551059['oauth_token_secret']=this['secret']),_0x551059['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x551059['nonce']=this['nonce']),_0x3209e8['postBody']=ut(_0x551059);}return _0x3209e8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2ac0f3){switch(_0x2ac0f3){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x14736c){const _0x4f1a0c=Ct(Tt(_0x14736c))['link'],_0x2fdcd7=_0x4f1a0c?Ct(Tt(_0x4f1a0c))['deep_link_id']:null,_0x473c65=Ct(Tt(_0x14736c))['deep_link_id'];return(_0x473c65?Ct(Tt(_0x473c65))['link']:null)||_0x473c65||_0x2fdcd7||_0x4f1a0c||_0x14736c;}class Rs{constructor(_0x5763e8){const _0x556e0b=Ct(Tt(_0x5763e8)),_0x286578=_0x556e0b['apiKey']??null,_0x2f293d=_0x556e0b['oobCode']??null,_0x467e34=Jf(_0x556e0b['mode']??null);m(_0x286578&&_0x2f293d&&_0x467e34,'argument-error'),this['apiKey']=_0x286578,this['operation']=_0x467e34,this['code']=_0x2f293d,this['continueUrl']=_0x556e0b['continueUrl']??null,this['languageCode']=_0x556e0b['lang']??null,this['tenantId']=_0x556e0b['tenantId']??null;}static['parseLink'](_0x1e6fa3){const _0x1dedd4=Xf(_0x1e6fa3);try{return new Rs(_0x1dedd4);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x19cb6c,_0x40c1f9){return $t['_fromEmailAndPassword'](_0x19cb6c,_0x40c1f9);}static['credentialWithLink'](_0x238aaf,_0x2e1f11){const _0x4e5494=Rs['parseLink'](_0x2e1f11);return m(_0x4e5494,'argument-error'),$t['_fromEmailAndCode'](_0x238aaf,_0x4e5494['code'],_0x4e5494['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x41c2af){this['providerId']=_0x41c2af,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x35c440){this['defaultLanguageCode']=_0x35c440;}['setCustomParameters'](_0x152706){return this['customParameters']=_0x152706,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x314fa7){return this['scopes']['includes'](_0x314fa7)||this['scopes']['push'](_0x314fa7),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x35e21d){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x35e21d});}static['credentialFromResult'](_0x383b99){return ue['credentialFromTaggedObject'](_0x383b99);}static['credentialFromError'](_0x286403){return ue['credentialFromTaggedObject'](_0x286403['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x12ee5d}){if(!_0x12ee5d||!('oauthAccessToken'in _0x12ee5d)||!_0x12ee5d['oauthAccessToken'])return null;try{return ue['credential'](_0x12ee5d['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xb258cc,_0x3e31f3){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xb258cc,'accessToken':_0x3e31f3});}static['credentialFromResult'](_0xd3d502){return de['credentialFromTaggedObject'](_0xd3d502);}static['credentialFromError'](_0x5f0a5d){return de['credentialFromTaggedObject'](_0x5f0a5d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3fc458}){if(!_0x3fc458)return null;const {oauthIdToken:_0x38be43,oauthAccessToken:_0x597852}=_0x3fc458;if(!_0x38be43&&!_0x597852)return null;try{return de['credential'](_0x38be43,_0x597852);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x57e902){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x57e902});}static['credentialFromResult'](_0x33b183){return fe['credentialFromTaggedObject'](_0x33b183);}static['credentialFromError'](_0x334ac5){return fe['credentialFromTaggedObject'](_0x334ac5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x31dbdf}){if(!_0x31dbdf||!('oauthAccessToken'in _0x31dbdf)||!_0x31dbdf['oauthAccessToken'])return null;try{return fe['credential'](_0x31dbdf['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x31c9fb,_0x364ba0){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x31c9fb,'oauthTokenSecret':_0x364ba0});}static['credentialFromResult'](_0x5591b5){return pe['credentialFromTaggedObject'](_0x5591b5);}static['credentialFromError'](_0x3f0e0f){return pe['credentialFromTaggedObject'](_0x3f0e0f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5c4d3f}){if(!_0x5c4d3f)return null;const {oauthAccessToken:_0x122c43,oauthTokenSecret:_0x4e4281}=_0x5c4d3f;if(!_0x122c43||!_0x4e4281)return null;try{return pe['credential'](_0x122c43,_0x4e4281);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4be088,_0x1f6c85){return en(_0x4be088,'POST','/v1/accounts:signUp',ke(_0x4be088,_0x1f6c85));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x333137){this['user']=_0x333137['user'],this['providerId']=_0x333137['providerId'],this['_tokenResponse']=_0x333137['_tokenResponse'],this['operationType']=_0x333137['operationType'];}static async['_fromIdTokenResponse'](_0x533e1c,_0x5df4d0,_0x1329b9,_0x2c9063=!0x1){const _0x1eb8c2=await j['_fromIdTokenResponse'](_0x533e1c,_0x1329b9,_0x2c9063),_0x542954=Nr(_0x1329b9);return new Ge({'user':_0x1eb8c2,'providerId':_0x542954,'_tokenResponse':_0x1329b9,'operationType':_0x5df4d0});}static async['_forOperation'](_0x17d7d6,_0x579aa9,_0x2830a9){await _0x17d7d6['_updateTokensIfNecessary'](_0x2830a9,!0x0);const _0x177b10=Nr(_0x2830a9);return new Ge({'user':_0x17d7d6,'providerId':_0x177b10,'_tokenResponse':_0x2830a9,'operationType':_0x579aa9});}}function Nr(_0x4a8fc8){return _0x4a8fc8['providerId']?_0x4a8fc8['providerId']:'phoneNumber'in _0x4a8fc8?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x4e54c0,_0x328fa1,_0x57676c,_0x1cdf0c){super(_0x328fa1['code'],_0x328fa1['message']),this['operationType']=_0x57676c,this['user']=_0x1cdf0c,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x4e54c0['name'],'tenantId':_0x4e54c0['tenantId']??void 0x0,'_serverResponse':_0x328fa1['customData']['_serverResponse'],'operationType':_0x57676c};}static['_fromErrorAndOperation'](_0x47ee04,_0x3ff44e,_0x41311b,_0x4c99da){return new On(_0x47ee04,_0x3ff44e,_0x41311b,_0x4c99da);}}function Ba(_0x437727,_0x455ee3,_0x23f216,_0x473fdb){return(_0x455ee3==='reauthenticate'?_0x23f216['_getReauthenticationResolver'](_0x437727):_0x23f216['_getIdTokenResponse'](_0x437727))['catch'](_0x18a4de=>{throw _0x18a4de['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x437727,_0x18a4de,_0x455ee3,_0x473fdb):_0x18a4de;});}async function ep(_0x5cefbb,_0x695f0e,_0x2cbd63=!0x1){const _0x3761f8=await Ht(_0x5cefbb,_0x695f0e['_linkToIdToken'](_0x5cefbb['auth'],await _0x5cefbb['getIdToken']()),_0x2cbd63);return Ge['_forOperation'](_0x5cefbb,'link',_0x3761f8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x496ac8,_0x6dfe30,_0x1db8f7=!0x1){const {auth:_0x1eb132}=_0x496ac8;if($(_0x1eb132['app']))return Promise['reject'](re(_0x1eb132));const _0x5a32a4='reauthenticate';try{const _0x19b8d6=await Ht(_0x496ac8,Ba(_0x1eb132,_0x5a32a4,_0x6dfe30,_0x496ac8),_0x1db8f7);m(_0x19b8d6['idToken'],_0x1eb132,'internal-error');const _0x135b11=Ts(_0x19b8d6['idToken']);m(_0x135b11,_0x1eb132,'internal-error');const {sub:_0x1ba563}=_0x135b11;return m(_0x496ac8['uid']===_0x1ba563,_0x1eb132,'user-mismatch'),Ge['_forOperation'](_0x496ac8,_0x5a32a4,_0x19b8d6);}catch(_0x1c9b7c){throw(_0x1c9b7c==null?void 0x0:_0x1c9b7c['code'])==='auth/user-not-found'&&Y(_0x1eb132,'user-mismatch'),_0x1c9b7c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x518b2a,_0x5ae215,_0x1f8d27=!0x1){if($(_0x518b2a['app']))return Promise['reject'](re(_0x518b2a));const _0x4c76ba='signIn',_0x3a7796=await Ba(_0x518b2a,_0x4c76ba,_0x5ae215),_0x707231=await Ge['_fromIdTokenResponse'](_0x518b2a,_0x4c76ba,_0x3a7796);return _0x1f8d27||await _0x518b2a['_updateCurrentUser'](_0x707231['user']),_0x707231;}async function np(_0x8cea6e,_0x22dc4b){return Va(Ke(_0x8cea6e),_0x22dc4b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x253347){const _0x4364e9=Ke(_0x253347);_0x4364e9['_getPasswordPolicyInternal']()&&await _0x4364e9['_updatePasswordPolicy']();}async function L_(_0x23b58e,_0x5b9df7,_0x7a0c89){if($(_0x23b58e['app']))return Promise['reject'](re(_0x23b58e));const _0x2caa8b=Ke(_0x23b58e),_0x14248a=await xi(_0x2caa8b,{'returnSecureToken':!0x0,'email':_0x5b9df7,'password':_0x7a0c89,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xdee879=>{throw _0xdee879['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x23b58e),_0xdee879;}),_0x59c29f=await Ge['_fromIdTokenResponse'](_0x2caa8b,'signIn',_0x14248a);return await _0x2caa8b['_updateCurrentUser'](_0x59c29f['user']),_0x59c29f;}function x_(_0x5527ee,_0x1733c6,_0x30e02d){return $(_0x5527ee['app'])?Promise['reject'](re(_0x5527ee)):np(P(_0x5527ee),yt['credential'](_0x1733c6,_0x30e02d))['catch'](async _0x3b6e26=>{throw _0x3b6e26['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5527ee),_0x3b6e26;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x181fcc,_0x103c24){return P(_0x181fcc)['setPersistence'](_0x103c24);}function ip(_0x16aeff,_0x29db65,_0x59d855,_0x212968){return P(_0x16aeff)['onIdTokenChanged'](_0x29db65,_0x59d855,_0x212968);}function sp(_0x5e7fbd,_0x59ef63,_0x4104c6){return P(_0x5e7fbd)['beforeAuthStateChanged'](_0x59ef63,_0x4104c6);}function U_(_0x380ec8,_0x1cbe98,_0x955e71,_0x4812f3){return P(_0x380ec8)['onAuthStateChanged'](_0x1cbe98,_0x955e71,_0x4812f3);}function W_(_0x2a819b){return P(_0x2a819b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x56801e,_0x5a453e){this['storageRetriever']=_0x56801e,this['type']=_0x5a453e;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1fd969,_0x2f5f87){return this['storage']['setItem'](_0x1fd969,JSON['stringify'](_0x2f5f87)),Promise['resolve']();}['_get'](_0x41f0f5){const _0x4f45a0=this['storage']['getItem'](_0x41f0f5);return Promise['resolve'](_0x4f45a0?JSON['parse'](_0x4f45a0):null);}['_remove'](_0x515083){return this['storage']['removeItem'](_0x515083),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3b38ac,_0x13b327)=>this['onStorageEvent'](_0x3b38ac,_0x13b327),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xbc903d){for(const _0x314560 of Object['keys'](this['listeners'])){const _0x5cbdd2=this['storage']['getItem'](_0x314560),_0x2bb788=this['localCache'][_0x314560];_0x5cbdd2!==_0x2bb788&&_0xbc903d(_0x314560,_0x2bb788,_0x5cbdd2);}}['onStorageEvent'](_0x40bffa,_0x4f287f=!0x1){if(!_0x40bffa['key']){this['forAllChangedKeys']((_0x3d9cc7,_0x41b825,_0x46a863)=>{this['notifyListeners'](_0x3d9cc7,_0x46a863);});return;}const _0x1fbda2=_0x40bffa['key'];_0x4f287f?this['detachListener']():this['stopPolling']();const _0x330647=()=>{const _0x2a2a79=this['storage']['getItem'](_0x1fbda2);!_0x4f287f&&this['localCache'][_0x1fbda2]===_0x2a2a79||this['notifyListeners'](_0x1fbda2,_0x2a2a79);},_0x5c70a9=this['storage']['getItem'](_0x1fbda2);Af()&&_0x5c70a9!==_0x40bffa['newValue']&&_0x40bffa['newValue']!==_0x40bffa['oldValue']?setTimeout(_0x330647,op):_0x330647();}['notifyListeners'](_0x1a5711,_0x589132){this['localCache'][_0x1a5711]=_0x589132;const _0x1ee824=this['listeners'][_0x1a5711];if(_0x1ee824){for(const _0x5b9e86 of Array['from'](_0x1ee824))_0x5b9e86(_0x589132&&JSON['parse'](_0x589132));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x30b76f,_0x5352aa,_0x517628)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x30b76f,'oldValue':_0x5352aa,'newValue':_0x517628}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3e92a6,_0x2479ce){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3e92a6]||(this['listeners'][_0x3e92a6]=new Set(),this['localCache'][_0x3e92a6]=this['storage']['getItem'](_0x3e92a6)),this['listeners'][_0x3e92a6]['add'](_0x2479ce);}['_removeListener'](_0x57b022,_0x5e45f5){this['listeners'][_0x57b022]&&(this['listeners'][_0x57b022]['delete'](_0x5e45f5),this['listeners'][_0x57b022]['size']===0x0&&delete this['listeners'][_0x57b022]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4d9635,_0x50ef52){await super['_set'](_0x4d9635,_0x50ef52),this['localCache'][_0x4d9635]=JSON['stringify'](_0x50ef52);}async['_get'](_0x37cb71){const _0x50a584=await super['_get'](_0x37cb71);return this['localCache'][_0x37cb71]=JSON['stringify'](_0x50a584),_0x50a584;}async['_remove'](_0x2dc005){await super['_remove'](_0x2dc005),delete this['localCache'][_0x2dc005];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5bdab5,_0x33b530){}['_removeListener'](_0x4c9487,_0x294a33){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x3360e3){return Promise['all'](_0x3360e3['map'](async _0x1bb4b0=>{try{return{'fulfilled':!0x0,'value':await _0x1bb4b0};}catch(_0x28ce12){return{'fulfilled':!0x1,'reason':_0x28ce12};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x34acae){this['eventTarget']=_0x34acae,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5d37f1){const _0x387f69=this['receivers']['find'](_0x7beffc=>_0x7beffc['isListeningto'](_0x5d37f1));if(_0x387f69)return _0x387f69;const _0x8223dc=new Xn(_0x5d37f1);return this['receivers']['push'](_0x8223dc),_0x8223dc;}['isListeningto'](_0x5da39b){return this['eventTarget']===_0x5da39b;}async['handleEvent'](_0x18ea0a){const _0x11c2c2=_0x18ea0a,{eventId:_0x4f1f9a,eventType:_0x2b11a8,data:_0x49a298}=_0x11c2c2['data'],_0x4a8a6e=this['handlersMap'][_0x2b11a8];if(!(_0x4a8a6e!=null&&_0x4a8a6e['size']))return;_0x11c2c2['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4f1f9a,'eventType':_0x2b11a8});const _0x143186=Array['from'](_0x4a8a6e)['map'](async _0xa86c7c=>_0xa86c7c(_0x11c2c2['origin'],_0x49a298)),_0x2fd659=await cp(_0x143186);_0x11c2c2['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4f1f9a,'eventType':_0x2b11a8,'response':_0x2fd659});}['_subscribe'](_0x25dfa1,_0x47a922){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x25dfa1]||(this['handlersMap'][_0x25dfa1]=new Set()),this['handlersMap'][_0x25dfa1]['add'](_0x47a922);}['_unsubscribe'](_0x5e1f79,_0x59709d){this['handlersMap'][_0x5e1f79]&&_0x59709d&&this['handlersMap'][_0x5e1f79]['delete'](_0x59709d),(!_0x59709d||this['handlersMap'][_0x5e1f79]['size']===0x0)&&delete this['handlersMap'][_0x5e1f79],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x2f2094='',_0x2ea205=0xa){let _0x54475='';for(let _0x57adbe=0x0;_0x57adbe<_0x2ea205;_0x57adbe++)_0x54475+=Math['floor'](Math['random']()*0xa);return _0x2f2094+_0x54475;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x51bfc3){this['target']=_0x51bfc3,this['handlers']=new Set();}['removeMessageHandler'](_0x365564){_0x365564['messageChannel']&&(_0x365564['messageChannel']['port1']['removeEventListener']('message',_0x365564['onMessage']),_0x365564['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x365564);}async['_send'](_0x1a541b,_0x182fc7,_0xafcd33=0x32){const _0x32769c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x32769c)throw new Error('connection_unavailable');let _0x11fea8,_0x13b557;return new Promise((_0x1e88cb,_0x5eaed5)=>{const _0x47cb56=As('',0x14);_0x32769c['port1']['start']();const _0x2ac6ef=setTimeout(()=>{_0x5eaed5(new Error('unsupported_event'));},_0xafcd33);_0x13b557={'messageChannel':_0x32769c,'onMessage'(_0xc84d94){const _0x2ee851=_0xc84d94;if(_0x2ee851['data']['eventId']===_0x47cb56)switch(_0x2ee851['data']['status']){case'ack':clearTimeout(_0x2ac6ef),_0x11fea8=setTimeout(()=>{_0x5eaed5(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x11fea8),_0x1e88cb(_0x2ee851['data']['response']);break;default:clearTimeout(_0x2ac6ef),clearTimeout(_0x11fea8),_0x5eaed5(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x13b557),_0x32769c['port1']['addEventListener']('message',_0x13b557['onMessage']),this['target']['postMessage']({'eventType':_0x1a541b,'eventId':_0x47cb56,'data':_0x182fc7},[_0x32769c['port2']]);})['finally'](()=>{_0x13b557&&this['removeMessageHandler'](_0x13b557);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x3b7cd0){Z()['location']['href']=_0x3b7cd0;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5eaa14;return((_0x5eaa14=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5eaa14['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4a5f0a){this['request']=_0x4a5f0a;}['toPromise'](){return new Promise((_0x188e70,_0x52ddde)=>{this['request']['addEventListener']('success',()=>{_0x188e70(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x52ddde(this['request']['error']);});});}}function Zn(_0xda26a,_0x446756){return _0xda26a['transaction']([Mn],_0x446756?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x580750=indexedDB['deleteDatabase'](Ka);return new nn(_0x580750)['toPromise']();}function Qa(){const _0xa59b7b=indexedDB['open'](Ka,pp);return new Promise((_0x27f359,_0x5eec5f)=>{_0xa59b7b['addEventListener']('error',()=>{_0x5eec5f(_0xa59b7b['error']);}),_0xa59b7b['addEventListener']('upgradeneeded',()=>{const _0x3c638f=_0xa59b7b['result'];try{_0x3c638f['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4e1725){_0x5eec5f(_0x4e1725);}}),_0xa59b7b['addEventListener']('success',async()=>{const _0x47c9da=_0xa59b7b['result'];_0x47c9da['objectStoreNames']['contains'](Mn)?_0x27f359(_0x47c9da):(_0x47c9da['close'](),await _p(),_0x27f359(await Qa()));});});}async function Or(_0x5a705d,_0x463e86,_0x44a260){const _0x36d64a=Zn(_0x5a705d,!0x0)['put']({[Ya]:_0x463e86,'value':_0x44a260});return new nn(_0x36d64a)['toPromise']();}async function gp(_0x51a4c2,_0x358dd4){const _0xe1c6ca=Zn(_0x51a4c2,!0x1)['get'](_0x358dd4),_0x4edfc5=await new nn(_0xe1c6ca)['toPromise']();return _0x4edfc5===void 0x0?null:_0x4edfc5['value'];}function Dr(_0x25f326,_0x45653a){const _0x4519d0=Zn(_0x25f326,!0x0)['delete'](_0x45653a);return new nn(_0x4519d0)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2c843a){let _0x233e80=0x0;for(;;)try{const _0x39426c=await this['_openDb']();return await _0x2c843a(_0x39426c);}catch(_0x36ca48){if(_0x233e80++>yp)throw _0x36ca48;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x423ae3,_0x1a2aca)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1a2aca['key'])})),this['receiver']['_subscribe']('ping',async(_0x150bad,_0x111411)=>['keyChanged']);}async['initializeSender'](){var _0x5dcf11,_0x2b7fc0;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2cf559=await this['sender']['_send']('ping',{},0x320);_0x2cf559&&(_0x5dcf11=_0x2cf559[0x0])!=null&&_0x5dcf11['fulfilled']&&(_0x2b7fc0=_0x2cf559[0x0])!=null&&_0x2b7fc0['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3a5465){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3a5465},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5b0ea0=>{await Or(_0x5b0ea0,Dn,'1'),await Dr(_0x5b0ea0,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x284fe0){this['pendingWrites']++;try{await _0x284fe0();}finally{this['pendingWrites']--;}}async['_set'](_0x399f98,_0x27448d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x59d53d=>Or(_0x59d53d,_0x399f98,_0x27448d)),this['localCache'][_0x399f98]=_0x27448d,this['notifyServiceWorker'](_0x399f98)));}async['_get'](_0x8c5763){const _0x2ea990=await this['_withRetries'](_0x156bce=>gp(_0x156bce,_0x8c5763));return this['localCache'][_0x8c5763]=_0x2ea990,_0x2ea990;}async['_remove'](_0x2403f2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1f4785=>Dr(_0x1f4785,_0x2403f2)),delete this['localCache'][_0x2403f2],this['notifyServiceWorker'](_0x2403f2)));}async['_poll'](){const _0x459fe7=await this['_withRetries'](_0x3d1582=>{const _0x489084=Zn(_0x3d1582,!0x1)['getAll']();return new nn(_0x489084)['toPromise']();});if(!_0x459fe7)return[];if(this['pendingWrites']!==0x0)return[];const _0x348ccb=[],_0x1f65c0=new Set();if(_0x459fe7['length']!==0x0){for(const {fbase_key:_0x2b2c38,value:_0x12babb}of _0x459fe7)_0x1f65c0['add'](_0x2b2c38),JSON['stringify'](this['localCache'][_0x2b2c38])!==JSON['stringify'](_0x12babb)&&(this['notifyListeners'](_0x2b2c38,_0x12babb),_0x348ccb['push'](_0x2b2c38));}for(const _0x50188e of Object['keys'](this['localCache']))this['localCache'][_0x50188e]&&!_0x1f65c0['has'](_0x50188e)&&(this['notifyListeners'](_0x50188e,null),_0x348ccb['push'](_0x50188e));return _0x348ccb;}['notifyListeners'](_0x3a831c,_0x143712){this['localCache'][_0x3a831c]=_0x143712;const _0x32fe7d=this['listeners'][_0x3a831c];if(_0x32fe7d){for(const _0x66ba82 of Array['from'](_0x32fe7d))_0x66ba82(_0x143712);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x474198,_0x167edf){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x474198]||(this['listeners'][_0x474198]=new Set(),this['_get'](_0x474198)),this['listeners'][_0x474198]['add'](_0x167edf);}['_removeListener'](_0x5c95de,_0x4f0248){this['listeners'][_0x5c95de]&&(this['listeners'][_0x5c95de]['delete'](_0x4f0248),this['listeners'][_0x5c95de]['size']===0x0&&delete this['listeners'][_0x5c95de]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5c90b6,_0x46cb89){return _0x46cb89?ie(_0x46cb89):(m(_0x5c90b6['_popupRedirectResolver'],_0x5c90b6,'argument-error'),_0x5c90b6['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x5ccbdc){super('custom','custom'),this['params']=_0x5ccbdc;}['_getIdTokenResponse'](_0x5ece1b){return nt(_0x5ece1b,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5e0e36,_0x1842a0){return nt(_0x5e0e36,this['_buildIdpRequest'](_0x1842a0));}['_getReauthenticationResolver'](_0x2d30b3){return nt(_0x2d30b3,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x205837){const _0x34a344={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x205837&&(_0x34a344['idToken']=_0x205837),_0x34a344;}}function Ip(_0x990253){return Va(_0x990253['auth'],new ks(_0x990253),_0x990253['bypassAuthState']);}function wp(_0x1b3b5a){const {auth:_0x1c68d3,user:_0x5b2271}=_0x1b3b5a;return m(_0x5b2271,_0x1c68d3,'internal-error'),tp(_0x5b2271,new ks(_0x1b3b5a),_0x1b3b5a['bypassAuthState']);}async function Cp(_0x4889d5){const {auth:_0x5adb76,user:_0x1bcd94}=_0x4889d5;return m(_0x1bcd94,_0x5adb76,'internal-error'),ep(_0x1bcd94,new ks(_0x4889d5),_0x4889d5['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x133848,_0x37267c,_0x4f8184,_0x2f6057,_0x245258=!0x1){this['auth']=_0x133848,this['resolver']=_0x4f8184,this['user']=_0x2f6057,this['bypassAuthState']=_0x245258,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x37267c)?_0x37267c:[_0x37267c];}['execute'](){return new Promise(async(_0x19750d,_0x4d1ff0)=>{this['pendingPromise']={'resolve':_0x19750d,'reject':_0x4d1ff0};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x38ed6e){this['reject'](_0x38ed6e);}});}async['onAuthEvent'](_0xdf87d3){const {urlResponse:_0x1e94de,sessionId:_0x2ccc44,postBody:_0x58866e,tenantId:_0xb7d81f,error:_0x5a5c3e,type:_0x597c87}=_0xdf87d3;if(_0x5a5c3e){this['reject'](_0x5a5c3e);return;}const _0x129881={'auth':this['auth'],'requestUri':_0x1e94de,'sessionId':_0x2ccc44,'tenantId':_0xb7d81f||void 0x0,'postBody':_0x58866e||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x597c87)(_0x129881));}catch(_0x3a6ef2){this['reject'](_0x3a6ef2);}}['onError'](_0x4aa2a6){this['reject'](_0x4aa2a6);}['getIdpTask'](_0x453852){switch(_0x453852){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x360adc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x360adc),this['unregisterAndCleanUp']();}['reject'](_0x366c67){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x366c67),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x1c6362,_0x16fe22,_0x1cf068,_0x2eccc8,_0x4bf3ab){super(_0x1c6362,_0x16fe22,_0x2eccc8,_0x4bf3ab),this['provider']=_0x1cf068,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x276882=await this['execute']();return m(_0x276882,this['auth'],'internal-error'),_0x276882;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x9d0ef7=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x9d0ef7),this['authWindow']['associatedEvent']=_0x9d0ef7,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2379f3=>{this['reject'](_0x2379f3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1c6bd9=>{_0x1c6bd9||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x17df08;return((_0x17df08=this['authWindow'])==null?void 0x0:_0x17df08['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4eddbe=()=>{var _0x121b6c,_0x28f0be;if((_0x28f0be=(_0x121b6c=this['authWindow'])==null?void 0x0:_0x121b6c['window'])!=null&&_0x28f0be['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4eddbe,Tp['get']());};_0x4eddbe();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x30d566,_0x2d8f12,_0x46c569=!0x1){super(_0x30d566,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2d8f12,void 0x0,_0x46c569),this['eventId']=null;}async['execute'](){let _0x553640=hn['get'](this['auth']['_key']());if(!_0x553640){try{const _0x29b0e4=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x553640=()=>Promise['resolve'](_0x29b0e4);}catch(_0x37100d){_0x553640=()=>Promise['reject'](_0x37100d);}hn['set'](this['auth']['_key'](),_0x553640);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x553640();}async['onAuthEvent'](_0x33ba08){if(_0x33ba08['type']==='signInViaRedirect')return super['onAuthEvent'](_0x33ba08);if(_0x33ba08['type']==='unknown'){this['resolve'](null);return;}if(_0x33ba08['eventId']){const _0x37814e=await this['auth']['_redirectUserForId'](_0x33ba08['eventId']);if(_0x37814e)return this['user']=_0x37814e,super['onAuthEvent'](_0x33ba08);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x23400b,_0xbe8cc0){const _0x52e178=Pp(_0xbe8cc0),_0x31bd91=kp(_0x23400b);if(!await _0x31bd91['_isAvailable']())return!0x1;const _0x202581=await _0x31bd91['_get'](_0x52e178)==='true';return await _0x31bd91['_remove'](_0x52e178),_0x202581;}function Ap(_0x1c97dd,_0x2393b9){hn['set'](_0x1c97dd['_key'](),_0x2393b9);}function kp(_0x21fea1){return ie(_0x21fea1['_redirectPersistence']);}function Pp(_0x5c239b){return ln(Sp,_0x5c239b['config']['apiKey'],_0x5c239b['name']);}async function Np(_0x57eecc,_0x37dee0,_0xee74a8=!0x1){if($(_0x57eecc['app']))return Promise['reject'](re(_0x57eecc));const _0x2a0273=Ke(_0x57eecc),_0x16f894=Ep(_0x2a0273,_0x37dee0),_0x1d2597=await new bp(_0x2a0273,_0x16f894,_0xee74a8)['execute']();return _0x1d2597&&!_0xee74a8&&(delete _0x1d2597['user']['_redirectEventId'],await _0x2a0273['_persistUserIfCurrent'](_0x1d2597['user']),await _0x2a0273['_setRedirectUser'](null,_0x37dee0)),_0x1d2597;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x1c160e){this['auth']=_0x1c160e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x278bc7){this['consumers']['add'](_0x278bc7),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x278bc7)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x278bc7),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x205acd){this['consumers']['delete'](_0x205acd);}['onEvent'](_0x474c66){if(this['hasEventBeenHandled'](_0x474c66))return!0x1;let _0x357b83=!0x1;return this['consumers']['forEach'](_0x58dc94=>{this['isEventForConsumer'](_0x474c66,_0x58dc94)&&(_0x357b83=!0x0,this['sendToConsumer'](_0x474c66,_0x58dc94),this['saveEventToCache'](_0x474c66));}),this['hasHandledPotentialRedirect']||!Mp(_0x474c66)||(this['hasHandledPotentialRedirect']=!0x0,_0x357b83||(this['queuedRedirectEvent']=_0x474c66,_0x357b83=!0x0)),_0x357b83;}['sendToConsumer'](_0x7ec971,_0x47178f){var _0x29f407;if(_0x7ec971['error']&&!Za(_0x7ec971)){const _0x13fb57=((_0x29f407=_0x7ec971['error']['code'])==null?void 0x0:_0x29f407['split']('auth/')[0x1])||'internal-error';_0x47178f['onError'](X(this['auth'],_0x13fb57));}else _0x47178f['onAuthEvent'](_0x7ec971);}['isEventForConsumer'](_0x27a462,_0x58d8c9){const _0x37f466=_0x58d8c9['eventId']===null||!!_0x27a462['eventId']&&_0x27a462['eventId']===_0x58d8c9['eventId'];return _0x58d8c9['filter']['includes'](_0x27a462['type'])&&_0x37f466;}['hasEventBeenHandled'](_0x353d04){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x353d04));}['saveEventToCache'](_0x2f9ab1){this['cachedEventUids']['add'](Mr(_0x2f9ab1)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x44106e){return[_0x44106e['type'],_0x44106e['eventId'],_0x44106e['sessionId'],_0x44106e['tenantId']]['filter'](_0x3d792f=>_0x3d792f)['join']('-');}function Za({type:_0x1598f4,error:_0x291682}){return _0x1598f4==='unknown'&&(_0x291682==null?void 0x0:_0x291682['code'])==='auth/no-auth-event';}function Mp(_0x4a0244){switch(_0x4a0244['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x4a0244);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3cd560,_0x4aa9a5={}){return Pe(_0x3cd560,'GET','/v1/projects',_0x4aa9a5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x4bf97e){if(_0x4bf97e['config']['emulator'])return;const {authorizedDomains:_0x533453}=await Lp(_0x4bf97e);for(const _0x275965 of _0x533453)try{if(Wp(_0x275965))return;}catch{}Y(_0x4bf97e,'unauthorized-domain');}function Wp(_0x11883c){const _0x5d7b15=Mi(),{protocol:_0x12c1e4,hostname:_0x54e13d}=new URL(_0x5d7b15);if(_0x11883c['startsWith']('chrome-extension://')){const _0x533c7c=new URL(_0x11883c);return _0x533c7c['hostname']===''&&_0x54e13d===''?_0x12c1e4==='chrome-extension:'&&_0x11883c['replace']('chrome-extension://','')===_0x5d7b15['replace']('chrome-extension://',''):_0x12c1e4==='chrome-extension:'&&_0x533c7c['hostname']===_0x54e13d;}if(!Fp['test'](_0x12c1e4))return!0x1;if(xp['test'](_0x11883c))return _0x54e13d===_0x11883c;const _0x5721a8=_0x11883c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5721a8+'|'+_0x5721a8+')$','i')['test'](_0x54e13d);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x4031bc=Z()['___jsl'];if(_0x4031bc!=null&&_0x4031bc['H']){for(const _0x2f9fa0 of Object['keys'](_0x4031bc['H']))if(_0x4031bc['H'][_0x2f9fa0]['r']=_0x4031bc['H'][_0x2f9fa0]['r']||[],_0x4031bc['H'][_0x2f9fa0]['L']=_0x4031bc['H'][_0x2f9fa0]['L']||[],_0x4031bc['H'][_0x2f9fa0]['r']=[..._0x4031bc['H'][_0x2f9fa0]['L']],_0x4031bc['CP']){for(let _0x501c28=0x0;_0x501c28<_0x4031bc['CP']['length'];_0x501c28++)_0x4031bc['CP'][_0x501c28]=null;}}}function Vp(_0x269690){return new Promise((_0xbf0a56,_0x4da674)=>{var _0x5a7c67,_0x4bde22,_0x2e9e87;function _0x5c1803(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xbf0a56(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4da674(X(_0x269690,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4bde22=(_0x5a7c67=Z()['gapi'])==null?void 0x0:_0x5a7c67['iframes'])!=null&&_0x4bde22['Iframe'])_0xbf0a56(gapi['iframes']['getContext']());else{if((_0x2e9e87=Z()['gapi'])!=null&&_0x2e9e87['load'])_0x5c1803();else{const _0x15af7f=Ff('iframefcb');return Z()[_0x15af7f]=()=>{gapi['load']?_0x5c1803():_0x4da674(X(_0x269690,'network-request-failed'));},xa(xf()+'?onload='+_0x15af7f)['catch'](_0x2cb899=>_0x4da674(_0x2cb899));}}})['catch'](_0x496c20=>{throw un=null,_0x496c20;});}let un=null;function Hp(_0x5c13b9){return un=un||Vp(_0x5c13b9),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x299b6f){const _0x17b281=_0x299b6f['config'];m(_0x17b281['authDomain'],_0x299b6f,'auth-domain-config-required');const _0x2404d3=_0x17b281['emulator']?Cs(_0x17b281,qp):'https://'+_0x299b6f['config']['authDomain']+'/'+Gp,_0x385f32={'apiKey':_0x17b281['apiKey'],'appName':_0x299b6f['name'],'v':dt},_0x2b5c33=jp['get'](_0x299b6f['config']['apiHost']);_0x2b5c33&&(_0x385f32['eid']=_0x2b5c33);const _0x4d7cb9=_0x299b6f['_getFrameworks']();return _0x4d7cb9['length']&&(_0x385f32['fw']=_0x4d7cb9['join'](',')),_0x2404d3+'?'+ut(_0x385f32)['slice'](0x1);}async function Yp(_0x4be256){const _0x38f373=await Hp(_0x4be256),_0x3f37f7=Z()['gapi'];return m(_0x3f37f7,_0x4be256,'internal-error'),_0x38f373['open']({'where':document['body'],'url':Kp(_0x4be256),'messageHandlersFilter':_0x3f37f7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x52f8a3=>new Promise(async(_0x1fad99,_0x11cb85)=>{await _0x52f8a3['restyle']({'setHideOnLeave':!0x1});const _0x53ee92=X(_0x4be256,'network-request-failed'),_0x42b893=Z()['setTimeout'](()=>{_0x11cb85(_0x53ee92);},$p['get']());function _0x4d4913(){Z()['clearTimeout'](_0x42b893),_0x1fad99(_0x52f8a3);}_0x52f8a3['ping'](_0x4d4913)['then'](_0x4d4913,()=>{_0x11cb85(_0x53ee92);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x53b5da){this['window']=_0x53b5da,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x1e4e2f,_0x17a1ed,_0x134e3e,_0x4e278f=Jp,_0x4bff6a=Xp){const _0x341052=Math['max']((window['screen']['availHeight']-_0x4bff6a)/0x2,0x0)['toString'](),_0x342173=Math['max']((window['screen']['availWidth']-_0x4e278f)/0x2,0x0)['toString']();let _0x3235d1='';const _0x597945={...Qp,'width':_0x4e278f['toString'](),'height':_0x4bff6a['toString'](),'top':_0x341052,'left':_0x342173},_0x2ce824=W()['toLowerCase']();_0x134e3e&&(_0x3235d1=ka(_0x2ce824)?Zp:_0x134e3e),Ra(_0x2ce824)&&(_0x17a1ed=_0x17a1ed||e_,_0x597945['scrollbars']='yes');const _0x2ee1e9=Object['entries'](_0x597945)['reduce']((_0xa128e1,[_0x151724,_0x5b27ad])=>''+_0xa128e1+_0x151724+'='+_0x5b27ad+',','');if(Rf(_0x2ce824)&&_0x3235d1!=='_self')return n_(_0x17a1ed||'',_0x3235d1),new xr(null);const _0x1eac4a=window['open'](_0x17a1ed||'',_0x3235d1,_0x2ee1e9);m(_0x1eac4a,_0x1e4e2f,'popup-blocked');try{_0x1eac4a['focus']();}catch{}return new xr(_0x1eac4a);}function n_(_0x27fb29,_0x5a7923){const _0x38c14e=document['createElement']('a');_0x38c14e['href']=_0x27fb29,_0x38c14e['target']=_0x5a7923;const _0x27b7bc=document['createEvent']('MouseEvent');_0x27b7bc['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x38c14e['dispatchEvent'](_0x27b7bc);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x5a7885,_0x254468,_0x2d97b3,_0x5c8f90,_0x508d78,_0x5f47a7){m(_0x5a7885['config']['authDomain'],_0x5a7885,'auth-domain-config-required'),m(_0x5a7885['config']['apiKey'],_0x5a7885,'invalid-api-key');const _0x890a13={'apiKey':_0x5a7885['config']['apiKey'],'appName':_0x5a7885['name'],'authType':_0x2d97b3,'redirectUrl':_0x5c8f90,'v':dt,'eventId':_0x508d78};if(_0x254468 instanceof Wa){_0x254468['setDefaultLanguage'](_0x5a7885['languageCode']),_0x890a13['providerId']=_0x254468['providerId']||'',pn(_0x254468['getCustomParameters']())||(_0x890a13['customParameters']=JSON['stringify'](_0x254468['getCustomParameters']()));for(const [_0x602910,_0x329bd6]of Object['entries']({}))_0x890a13[_0x602910]=_0x329bd6;}if(_0x254468 instanceof tn){const _0x45b945=_0x254468['getScopes']()['filter'](_0x4b2ad4=>_0x4b2ad4!=='');_0x45b945['length']>0x0&&(_0x890a13['scopes']=_0x45b945['join'](','));}_0x5a7885['tenantId']&&(_0x890a13['tid']=_0x5a7885['tenantId']);const _0x45b5bc=_0x890a13;for(const _0x2876a2 of Object['keys'](_0x45b5bc))_0x45b5bc[_0x2876a2]===void 0x0&&delete _0x45b5bc[_0x2876a2];const _0x51fe6d=await _0x5a7885['_getAppCheckToken'](),_0x196f3c=_0x51fe6d?'#'+r_+'='+encodeURIComponent(_0x51fe6d):'';return o_(_0x5a7885)+'?'+ut(_0x45b5bc)['slice'](0x1)+_0x196f3c;}function o_({config:_0x219f20}){return _0x219f20['emulator']?Cs(_0x219f20,s_):'https://'+_0x219f20['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x169a3f,_0x5aec07,_0x21d5a7,_0x157791){var _0xc3f075;ce((_0xc3f075=this['eventManagers'][_0x169a3f['_key']()])==null?void 0x0:_0xc3f075['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3c4814=await Fr(_0x169a3f,_0x5aec07,_0x21d5a7,Mi(),_0x157791);return t_(_0x169a3f,_0x3c4814,As());}async['_openRedirect'](_0x2a07d,_0xe1e343,_0x254a92,_0x1f6d30){await this['_originValidation'](_0x2a07d);const _0x3b0d76=await Fr(_0x2a07d,_0xe1e343,_0x254a92,Mi(),_0x1f6d30);return hp(_0x3b0d76),new Promise(()=>{});}['_initialize'](_0x3a033a){const _0x5e19fa=_0x3a033a['_key']();if(this['eventManagers'][_0x5e19fa]){const {manager:_0x118fef,promise:_0xc1192a}=this['eventManagers'][_0x5e19fa];return _0x118fef?Promise['resolve'](_0x118fef):(ce(_0xc1192a,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xc1192a);}const _0x2da5de=this['initAndGetManager'](_0x3a033a);return this['eventManagers'][_0x5e19fa]={'promise':_0x2da5de},_0x2da5de['catch'](()=>{delete this['eventManagers'][_0x5e19fa];}),_0x2da5de;}async['initAndGetManager'](_0x49dadc){const _0x369732=await Yp(_0x49dadc),_0x31453d=new Dp(_0x49dadc);return _0x369732['register']('authEvent',_0x380243=>(m(_0x380243==null?void 0x0:_0x380243['authEvent'],_0x49dadc,'invalid-auth-event'),{'status':_0x31453d['onEvent'](_0x380243['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x49dadc['_key']()]={'manager':_0x31453d},this['iframes'][_0x49dadc['_key']()]=_0x369732,_0x31453d;}['_isIframeWebStorageSupported'](_0x2cad2b,_0x5d5bf0){this['iframes'][_0x2cad2b['_key']()]['send'](pi,{'type':pi},_0x3bbaac=>{var _0x363c5a;const _0x582c66=(_0x363c5a=_0x3bbaac==null?void 0x0:_0x3bbaac[0x0])==null?void 0x0:_0x363c5a[pi];_0x582c66!==void 0x0&&_0x5d5bf0(!!_0x582c66),Y(_0x2cad2b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4c867f){const _0x3f1b47=_0x4c867f['_key']();return this['originValidationPromises'][_0x3f1b47]||(this['originValidationPromises'][_0x3f1b47]=Up(_0x4c867f)),this['originValidationPromises'][_0x3f1b47];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x46b829){this['auth']=_0x46b829,this['internalListeners']=new Map();}['getUid'](){var _0x9dd251;return this['assertAuthConfigured'](),((_0x9dd251=this['auth']['currentUser'])==null?void 0x0:_0x9dd251['uid'])||null;}async['getToken'](_0x35a4c8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x35a4c8)}:null;}['addAuthTokenListener'](_0x161b22){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x161b22))return;const _0xf69371=this['auth']['onIdTokenChanged'](_0x398e8d=>{_0x161b22((_0x398e8d==null?void 0x0:_0x398e8d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x161b22,_0xf69371),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1235a7){this['assertAuthConfigured']();const _0x4325f2=this['internalListeners']['get'](_0x1235a7);_0x4325f2&&(this['internalListeners']['delete'](_0x1235a7),_0x4325f2(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x2ea109){switch(_0x2ea109){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x3dcfe2){st(new Fe('auth',(_0x4060d4,{options:_0x313a56})=>{const _0x2acccf=_0x4060d4['getProvider']('app')['getImmediate'](),_0x1ab542=_0x4060d4['getProvider']('heartbeat'),_0x350ad6=_0x4060d4['getProvider']('app-check-internal'),{apiKey:_0xc0af7d,authDomain:_0x12c702}=_0x2acccf['options'];m(_0xc0af7d&&!_0xc0af7d['includes'](':'),'invalid-api-key',{'appName':_0x2acccf['name']});const _0x5d3ca7={'apiKey':_0xc0af7d,'authDomain':_0x12c702,'clientPlatform':_0x3dcfe2,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3dcfe2)},_0x931c7b=new Df(_0x2acccf,_0x1ab542,_0x350ad6,_0x5d3ca7);return Hf(_0x931c7b,_0x313a56),_0x931c7b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1b2e20,_0x1ef055,_0x3b2303)=>{_0x1b2e20['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x10f452=>{const _0x43a22=Ke(_0x10f452['getProvider']('auth')['getImmediate']());return(_0x3fb7e4=>new l_(_0x3fb7e4))(_0x43a22);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x3dcfe2)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1ba594=>async _0x2b3aa6=>{const _0x4c8e73=_0x2b3aa6&&await _0x2b3aa6['getIdTokenResult'](),_0x3d1914=_0x4c8e73&&(new Date()['getTime']()-Date['parse'](_0x4c8e73['issuedAtTime']))/0x3e8;if(_0x3d1914&&_0x3d1914>f_)return;const _0x3a1d0f=_0x4c8e73==null?void 0x0:_0x4c8e73['token'];Br!==_0x3a1d0f&&(Br=_0x3a1d0f,await fetch(_0x1ba594,{'method':_0x3a1d0f?'POST':'DELETE','headers':_0x3a1d0f?{'Authorization':'Bearer\x20'+_0x3a1d0f}:{}}));};function B_(_0x22a87e=Zr()){const _0x58cbcb=Hi(_0x22a87e,'auth');if(_0x58cbcb['isInitialized']())return _0x58cbcb['getImmediate']();const _0x23a32c=Vf(_0x22a87e,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x444bd2=jr('authTokenSyncURL');if(_0x444bd2&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x46f03c=new URL(_0x444bd2,location['origin']);if(location['origin']===_0x46f03c['origin']){const _0x50a52c=p_(_0x46f03c['toString']());sp(_0x23a32c,_0x50a52c,()=>_0x50a52c(_0x23a32c['currentUser'])),ip(_0x23a32c,_0x559a87=>_0x50a52c(_0x559a87));}}const _0xca9172=qr('auth');return _0xca9172&&$f(_0x23a32c,'http://'+_0xca9172),_0x23a32c;}function __(){var _0x1037eb;return((_0x1037eb=document['getElementsByTagName']('head'))==null?void 0x0:_0x1037eb[0x0])??document;}Mf({'loadJS'(_0x29da56){return new Promise((_0x22723a,_0x3dbaf5)=>{const _0x4b1357=document['createElement']('script');_0x4b1357['setAttribute']('src',_0x29da56),_0x4b1357['onload']=_0x22723a,_0x4b1357['onerror']=_0x27088d=>{const _0x2eb10e=X('internal-error');_0x2eb10e['customData']=_0x27088d,_0x3dbaf5(_0x2eb10e);},_0x4b1357['type']='text/javascript',_0x4b1357['charset']='UTF-8',__()['appendChild'](_0x4b1357);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};