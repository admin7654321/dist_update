const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1ede6b,_0x1c668b){if(!_0x1ede6b)throw ht(_0x1c668b);},ht=function(_0x3f5290){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3f5290);},Hr=function(_0x1b510b){const _0x14bd6a=[];let _0x4ec07a=0x0;for(let _0x340bbf=0x0;_0x340bbf<_0x1b510b['length'];_0x340bbf++){let _0x1ecc35=_0x1b510b['charCodeAt'](_0x340bbf);_0x1ecc35<0x80?_0x14bd6a[_0x4ec07a++]=_0x1ecc35:_0x1ecc35<0x800?(_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0x6|0xc0,_0x14bd6a[_0x4ec07a++]=_0x1ecc35&0x3f|0x80):(_0x1ecc35&0xfc00)===0xd800&&_0x340bbf+0x1<_0x1b510b['length']&&(_0x1b510b['charCodeAt'](_0x340bbf+0x1)&0xfc00)===0xdc00?(_0x1ecc35=0x10000+((_0x1ecc35&0x3ff)<<0xa)+(_0x1b510b['charCodeAt'](++_0x340bbf)&0x3ff),_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0x12|0xf0,_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0xc&0x3f|0x80,_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0x6&0x3f|0x80,_0x14bd6a[_0x4ec07a++]=_0x1ecc35&0x3f|0x80):(_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0xc|0xe0,_0x14bd6a[_0x4ec07a++]=_0x1ecc35>>0x6&0x3f|0x80,_0x14bd6a[_0x4ec07a++]=_0x1ecc35&0x3f|0x80);}return _0x14bd6a;},nc=function(_0x9bf8bd){const _0x4888de=[];let _0x7941e6=0x0,_0x25ddb8=0x0;for(;_0x7941e6<_0x9bf8bd['length'];){const _0x4c8b8e=_0x9bf8bd[_0x7941e6++];if(_0x4c8b8e<0x80)_0x4888de[_0x25ddb8++]=String['fromCharCode'](_0x4c8b8e);else{if(_0x4c8b8e>0xbf&&_0x4c8b8e<0xe0){const _0x2a481e=_0x9bf8bd[_0x7941e6++];_0x4888de[_0x25ddb8++]=String['fromCharCode']((_0x4c8b8e&0x1f)<<0x6|_0x2a481e&0x3f);}else{if(_0x4c8b8e>0xef&&_0x4c8b8e<0x16d){const _0x3192d4=_0x9bf8bd[_0x7941e6++],_0x5c28a4=_0x9bf8bd[_0x7941e6++],_0x2f186f=_0x9bf8bd[_0x7941e6++],_0xc9f107=((_0x4c8b8e&0x7)<<0x12|(_0x3192d4&0x3f)<<0xc|(_0x5c28a4&0x3f)<<0x6|_0x2f186f&0x3f)-0x10000;_0x4888de[_0x25ddb8++]=String['fromCharCode'](0xd800+(_0xc9f107>>0xa)),_0x4888de[_0x25ddb8++]=String['fromCharCode'](0xdc00+(_0xc9f107&0x3ff));}else{const _0xc3b8ba=_0x9bf8bd[_0x7941e6++],_0x4ebc69=_0x9bf8bd[_0x7941e6++];_0x4888de[_0x25ddb8++]=String['fromCharCode']((_0x4c8b8e&0xf)<<0xc|(_0xc3b8ba&0x3f)<<0x6|_0x4ebc69&0x3f);}}}}return _0x4888de['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x233984,_0x2439e6){if(!Array['isArray'](_0x233984))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x586720=_0x2439e6?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3a10f5=[];for(let _0x30dfd3=0x0;_0x30dfd3<_0x233984['length'];_0x30dfd3+=0x3){const _0x3be7b1=_0x233984[_0x30dfd3],_0x1fd34a=_0x30dfd3+0x1<_0x233984['length'],_0x95025c=_0x1fd34a?_0x233984[_0x30dfd3+0x1]:0x0,_0x144eb1=_0x30dfd3+0x2<_0x233984['length'],_0x56d85f=_0x144eb1?_0x233984[_0x30dfd3+0x2]:0x0,_0x44be46=_0x3be7b1>>0x2,_0x5efe54=(_0x3be7b1&0x3)<<0x4|_0x95025c>>0x4;let _0x163f5b=(_0x95025c&0xf)<<0x2|_0x56d85f>>0x6,_0x387e5d=_0x56d85f&0x3f;_0x144eb1||(_0x387e5d=0x40,_0x1fd34a||(_0x163f5b=0x40)),_0x3a10f5['push'](_0x586720[_0x44be46],_0x586720[_0x5efe54],_0x586720[_0x163f5b],_0x586720[_0x387e5d]);}return _0x3a10f5['join']('');},'encodeString'(_0x2f3fed,_0xd07514){return this['HAS_NATIVE_SUPPORT']&&!_0xd07514?btoa(_0x2f3fed):this['encodeByteArray'](Hr(_0x2f3fed),_0xd07514);},'decodeString'(_0xf05c83,_0x5efd14){return this['HAS_NATIVE_SUPPORT']&&!_0x5efd14?atob(_0xf05c83):nc(this['decodeStringToByteArray'](_0xf05c83,_0x5efd14));},'decodeStringToByteArray'(_0x43bb24,_0x5651d9){this['init_']();const _0x316bb4=_0x5651d9?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x491dc2=[];for(let _0x2fd08c=0x0;_0x2fd08c<_0x43bb24['length'];){const _0x34cb3d=_0x316bb4[_0x43bb24['charAt'](_0x2fd08c++)],_0x14d610=_0x2fd08c<_0x43bb24['length']?_0x316bb4[_0x43bb24['charAt'](_0x2fd08c)]:0x0;++_0x2fd08c;const _0x3d0873=_0x2fd08c<_0x43bb24['length']?_0x316bb4[_0x43bb24['charAt'](_0x2fd08c)]:0x40;++_0x2fd08c;const _0x5dc342=_0x2fd08c<_0x43bb24['length']?_0x316bb4[_0x43bb24['charAt'](_0x2fd08c)]:0x40;if(++_0x2fd08c,_0x34cb3d==null||_0x14d610==null||_0x3d0873==null||_0x5dc342==null)throw new ic();const _0x42529d=_0x34cb3d<<0x2|_0x14d610>>0x4;if(_0x491dc2['push'](_0x42529d),_0x3d0873!==0x40){const _0x18d5ee=_0x14d610<<0x4&0xf0|_0x3d0873>>0x2;if(_0x491dc2['push'](_0x18d5ee),_0x5dc342!==0x40){const _0x3a227a=_0x3d0873<<0x6&0xc0|_0x5dc342;_0x491dc2['push'](_0x3a227a);}}}return _0x491dc2;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x237d86=0x0;_0x237d86<this['ENCODED_VALS']['length'];_0x237d86++)this['byteToCharMap_'][_0x237d86]=this['ENCODED_VALS']['charAt'](_0x237d86),this['charToByteMap_'][this['byteToCharMap_'][_0x237d86]]=_0x237d86,this['byteToCharMapWebSafe_'][_0x237d86]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x237d86),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x237d86]]=_0x237d86,_0x237d86>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x237d86)]=_0x237d86,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x237d86)]=_0x237d86);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3f5428){const _0x1c2488=Hr(_0x3f5428);return Fi['encodeByteArray'](_0x1c2488,!0x0);},dn=function(_0xb77067){return $r(_0xb77067)['replace'](/\./g,'');},fn=function(_0x797f23){try{return Fi['decodeString'](_0x797f23,!0x0);}catch(_0x3e3efb){console['error']('base64Decode\x20failed:\x20',_0x3e3efb);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2506db){return Gr(void 0x0,_0x2506db);}function Gr(_0x23f928,_0x1a8d5b){if(!(_0x1a8d5b instanceof Object))return _0x1a8d5b;switch(_0x1a8d5b['constructor']){case Date:const _0x39ada5=_0x1a8d5b;return new Date(_0x39ada5['getTime']());case Object:_0x23f928===void 0x0&&(_0x23f928={});break;case Array:_0x23f928=[];break;default:return _0x1a8d5b;}for(const _0x569a6b in _0x1a8d5b)!_0x1a8d5b['hasOwnProperty'](_0x569a6b)||!rc(_0x569a6b)||(_0x23f928[_0x569a6b]=Gr(_0x23f928[_0x569a6b],_0x1a8d5b[_0x569a6b]));return _0x23f928;}function rc(_0x22617a){return _0x22617a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x29e5ed=Ps['__FIREBASE_DEFAULTS__'];if(_0x29e5ed)return JSON['parse'](_0x29e5ed);},lc=()=>{if(typeof document>'u')return;let _0x490e9c;try{_0x490e9c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3a4cdb=_0x490e9c&&fn(_0x490e9c[0x1]);return _0x3a4cdb&&JSON['parse'](_0x3a4cdb);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x5c92f0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5c92f0);return;}},qr=_0x37bb0b=>{var _0x31fd45,_0x14f938;return(_0x14f938=(_0x31fd45=Ui())==null?void 0x0:_0x31fd45['emulatorHosts'])==null?void 0x0:_0x14f938[_0x37bb0b];},hc=_0x57dc36=>{const _0x3de5eb=qr(_0x57dc36);if(!_0x3de5eb)return;const _0x226627=_0x3de5eb['lastIndexOf'](':');if(_0x226627<=0x0||_0x226627+0x1===_0x3de5eb['length'])throw new Error('Invalid\x20host\x20'+_0x3de5eb+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x43af12=parseInt(_0x3de5eb['substring'](_0x226627+0x1),0xa);return _0x3de5eb[0x0]==='['?[_0x3de5eb['substring'](0x1,_0x226627-0x1),_0x43af12]:[_0x3de5eb['substring'](0x0,_0x226627),_0x43af12];},zr=()=>{var _0x4bf1ef;return(_0x4bf1ef=Ui())==null?void 0x0:_0x4bf1ef['config'];},jr=_0x5a6a50=>{var _0x552e3e;return(_0x552e3e=Ui())==null?void 0x0:_0x552e3e['_'+_0x5a6a50];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x31ff6e,_0x5f2478)=>{this['resolve']=_0x31ff6e,this['reject']=_0x5f2478;});}['wrapCallback'](_0x32fd15){return(_0x44fbdb,_0x14defb)=>{_0x44fbdb?this['reject'](_0x44fbdb):this['resolve'](_0x14defb),typeof _0x32fd15=='function'&&(this['promise']['catch'](()=>{}),_0x32fd15['length']===0x1?_0x32fd15(_0x44fbdb):_0x32fd15(_0x44fbdb,_0x14defb));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x2f95f8,_0xd2dfa8){if(_0x2f95f8['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4f4858={'alg':'none','type':'JWT'},_0x18092d=_0xd2dfa8||'demo-project',_0x47165f=_0x2f95f8['iat']||0x0,_0x61e5d7=_0x2f95f8['sub']||_0x2f95f8['user_id'];if(!_0x61e5d7)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2b4ef8={'iss':'https://securetoken.google.com/'+_0x18092d,'aud':_0x18092d,'iat':_0x47165f,'exp':_0x47165f+0xe10,'auth_time':_0x47165f,'sub':_0x61e5d7,'user_id':_0x61e5d7,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2f95f8};return[dn(JSON['stringify'](_0x4f4858)),dn(JSON['stringify'](_0x2b4ef8)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x14d274=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x14d274=='object'&&_0x14d274['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3f4ec9=W();return _0x3f4ec9['indexOf']('MSIE\x20')>=0x0||_0x3f4ec9['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x19ab27,_0x47bf19)=>{try{let _0x261d85=!0x0;const _0x255c51='validate-browser-context-for-indexeddb-analytics-module',_0x474b40=self['indexedDB']['open'](_0x255c51);_0x474b40['onsuccess']=()=>{_0x474b40['result']['close'](),_0x261d85||self['indexedDB']['deleteDatabase'](_0x255c51),_0x19ab27(!0x0);},_0x474b40['onupgradeneeded']=()=>{_0x261d85=!0x1;},_0x474b40['onerror']=()=>{var _0x36bf73;_0x47bf19(((_0x36bf73=_0x474b40['error'])==null?void 0x0:_0x36bf73['message'])||'');};}catch(_0x5357a0){_0x47bf19(_0x5357a0);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x204e32,_0x41ec75,_0x9a8332){super(_0x41ec75),this['code']=_0x204e32,this['customData']=_0x9a8332,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x5ae9d1,_0x8e110b,_0x3da0d9){this['service']=_0x5ae9d1,this['serviceName']=_0x8e110b,this['errors']=_0x3da0d9;}['create'](_0x293313,..._0x4c84fe){const _0xe2ab18=_0x4c84fe[0x0]||{},_0xd547b8=this['service']+'/'+_0x293313,_0x471149=this['errors'][_0x293313],_0x43471d=_0x471149?vc(_0x471149,_0xe2ab18):'Error',_0x1d9705=this['serviceName']+':\x20'+_0x43471d+'\x20('+_0xd547b8+').';return new Re(_0xd547b8,_0x1d9705,_0xe2ab18);}}function vc(_0x1200de,_0x39d881){return _0x1200de['replace'](Ec,(_0x53f851,_0x52466c)=>{const _0x1384bf=_0x39d881[_0x52466c];return _0x1384bf!=null?String(_0x1384bf):'<'+_0x52466c+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x160622){return JSON['parse'](_0x160622);}function O(_0x53ed4f){return JSON['stringify'](_0x53ed4f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x13e747){let _0x13fcf3={},_0x5a070e={},_0x5e4ea4={},_0x1352c1='';try{const _0x2a37d1=_0x13e747['split']('.');_0x13fcf3=Nt(fn(_0x2a37d1[0x0])||''),_0x5a070e=Nt(fn(_0x2a37d1[0x1])||''),_0x1352c1=_0x2a37d1[0x2],_0x5e4ea4=_0x5a070e['d']||{},delete _0x5a070e['d'];}catch{}return{'header':_0x13fcf3,'claims':_0x5a070e,'data':_0x5e4ea4,'signature':_0x1352c1};},Ic=function(_0x20caeb){const _0xf982ff=Yr(_0x20caeb),_0x1e1fe8=_0xf982ff['claims'];return!!_0x1e1fe8&&typeof _0x1e1fe8=='object'&&_0x1e1fe8['hasOwnProperty']('iat');},wc=function(_0x38836b){const _0x2fab06=Yr(_0x38836b)['claims'];return typeof _0x2fab06=='object'&&_0x2fab06['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xdc9991,_0x575eef){return Object['prototype']['hasOwnProperty']['call'](_0xdc9991,_0x575eef);}function Le(_0x235d03,_0x16a26a){if(Object['prototype']['hasOwnProperty']['call'](_0x235d03,_0x16a26a))return _0x235d03[_0x16a26a];}function pn(_0xb49c14){for(const _0x2abd89 in _0xb49c14)if(Object['prototype']['hasOwnProperty']['call'](_0xb49c14,_0x2abd89))return!0x1;return!0x0;}function _n(_0x589023,_0x264421,_0x2aa80e){const _0x435f43={};for(const _0x383c7b in _0x589023)Object['prototype']['hasOwnProperty']['call'](_0x589023,_0x383c7b)&&(_0x435f43[_0x383c7b]=_0x264421['call'](_0x2aa80e,_0x589023[_0x383c7b],_0x383c7b,_0x589023));return _0x435f43;}function xe(_0x55a81c,_0x4ec883){if(_0x55a81c===_0x4ec883)return!0x0;const _0x5dbc29=Object['keys'](_0x55a81c),_0x5b1b48=Object['keys'](_0x4ec883);for(const _0x199467 of _0x5dbc29){if(!_0x5b1b48['includes'](_0x199467))return!0x1;const _0x416408=_0x55a81c[_0x199467],_0x1de63c=_0x4ec883[_0x199467];if(Ns(_0x416408)&&Ns(_0x1de63c)){if(!xe(_0x416408,_0x1de63c))return!0x1;}else{if(_0x416408!==_0x1de63c)return!0x1;}}for(const _0x55bd49 of _0x5b1b48)if(!_0x5dbc29['includes'](_0x55bd49))return!0x1;return!0x0;}function Ns(_0x33909c){return _0x33909c!==null&&typeof _0x33909c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x14b485){const _0x547dfd=[];for(const [_0x3a1bcd,_0x53bf7f]of Object['entries'](_0x14b485))Array['isArray'](_0x53bf7f)?_0x53bf7f['forEach'](_0x2d1fcb=>{_0x547dfd['push'](encodeURIComponent(_0x3a1bcd)+'='+encodeURIComponent(_0x2d1fcb));}):_0x547dfd['push'](encodeURIComponent(_0x3a1bcd)+'='+encodeURIComponent(_0x53bf7f));return _0x547dfd['length']?'&'+_0x547dfd['join']('&'):'';}function Ct(_0x27834f){const _0x31c3fe={};return _0x27834f['replace'](/^\?/,'')['split']('&')['forEach'](_0x295699=>{if(_0x295699){const [_0x3b367f,_0x39644f]=_0x295699['split']('=');_0x31c3fe[decodeURIComponent(_0x3b367f)]=decodeURIComponent(_0x39644f);}}),_0x31c3fe;}function Tt(_0x3a0c1a){const _0x78f857=_0x3a0c1a['indexOf']('?');if(!_0x78f857)return'';const _0x42e7ca=_0x3a0c1a['indexOf']('#',_0x78f857);return _0x3a0c1a['substring'](_0x78f857,_0x42e7ca>0x0?_0x42e7ca:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x225b7c=0x1;_0x225b7c<this['blockSize'];++_0x225b7c)this['pad_'][_0x225b7c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xa70a37,_0x133285){_0x133285||(_0x133285=0x0);const _0x2ba6e3=this['W_'];if(typeof _0xa70a37=='string'){for(let _0x31af2f=0x0;_0x31af2f<0x10;_0x31af2f++)_0x2ba6e3[_0x31af2f]=_0xa70a37['charCodeAt'](_0x133285)<<0x18|_0xa70a37['charCodeAt'](_0x133285+0x1)<<0x10|_0xa70a37['charCodeAt'](_0x133285+0x2)<<0x8|_0xa70a37['charCodeAt'](_0x133285+0x3),_0x133285+=0x4;}else{for(let _0x281ad8=0x0;_0x281ad8<0x10;_0x281ad8++)_0x2ba6e3[_0x281ad8]=_0xa70a37[_0x133285]<<0x18|_0xa70a37[_0x133285+0x1]<<0x10|_0xa70a37[_0x133285+0x2]<<0x8|_0xa70a37[_0x133285+0x3],_0x133285+=0x4;}for(let _0x2f9ee6=0x10;_0x2f9ee6<0x50;_0x2f9ee6++){const _0x4e435b=_0x2ba6e3[_0x2f9ee6-0x3]^_0x2ba6e3[_0x2f9ee6-0x8]^_0x2ba6e3[_0x2f9ee6-0xe]^_0x2ba6e3[_0x2f9ee6-0x10];_0x2ba6e3[_0x2f9ee6]=(_0x4e435b<<0x1|_0x4e435b>>>0x1f)&0xffffffff;}let _0xb0bf72=this['chain_'][0x0],_0xe2f9a6=this['chain_'][0x1],_0x1e9dd6=this['chain_'][0x2],_0xbcf999=this['chain_'][0x3],_0x4ed18d=this['chain_'][0x4],_0x5d4ce2,_0xd6ce4e;for(let _0x4252d1=0x0;_0x4252d1<0x50;_0x4252d1++){_0x4252d1<0x28?_0x4252d1<0x14?(_0x5d4ce2=_0xbcf999^_0xe2f9a6&(_0x1e9dd6^_0xbcf999),_0xd6ce4e=0x5a827999):(_0x5d4ce2=_0xe2f9a6^_0x1e9dd6^_0xbcf999,_0xd6ce4e=0x6ed9eba1):_0x4252d1<0x3c?(_0x5d4ce2=_0xe2f9a6&_0x1e9dd6|_0xbcf999&(_0xe2f9a6|_0x1e9dd6),_0xd6ce4e=0x8f1bbcdc):(_0x5d4ce2=_0xe2f9a6^_0x1e9dd6^_0xbcf999,_0xd6ce4e=0xca62c1d6);const _0x57c9f2=(_0xb0bf72<<0x5|_0xb0bf72>>>0x1b)+_0x5d4ce2+_0x4ed18d+_0xd6ce4e+_0x2ba6e3[_0x4252d1]&0xffffffff;_0x4ed18d=_0xbcf999,_0xbcf999=_0x1e9dd6,_0x1e9dd6=(_0xe2f9a6<<0x1e|_0xe2f9a6>>>0x2)&0xffffffff,_0xe2f9a6=_0xb0bf72,_0xb0bf72=_0x57c9f2;}this['chain_'][0x0]=this['chain_'][0x0]+_0xb0bf72&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xe2f9a6&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1e9dd6&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0xbcf999&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4ed18d&0xffffffff;}['update'](_0x4f7b37,_0x11861a){if(_0x4f7b37==null)return;_0x11861a===void 0x0&&(_0x11861a=_0x4f7b37['length']);const _0x1e0695=_0x11861a-this['blockSize'];let _0x3918d1=0x0;const _0x1c45e6=this['buf_'];let _0x1db05d=this['inbuf_'];for(;_0x3918d1<_0x11861a;){if(_0x1db05d===0x0){for(;_0x3918d1<=_0x1e0695;)this['compress_'](_0x4f7b37,_0x3918d1),_0x3918d1+=this['blockSize'];}if(typeof _0x4f7b37=='string'){for(;_0x3918d1<_0x11861a;)if(_0x1c45e6[_0x1db05d]=_0x4f7b37['charCodeAt'](_0x3918d1),++_0x1db05d,++_0x3918d1,_0x1db05d===this['blockSize']){this['compress_'](_0x1c45e6),_0x1db05d=0x0;break;}}else{for(;_0x3918d1<_0x11861a;)if(_0x1c45e6[_0x1db05d]=_0x4f7b37[_0x3918d1],++_0x1db05d,++_0x3918d1,_0x1db05d===this['blockSize']){this['compress_'](_0x1c45e6),_0x1db05d=0x0;break;}}}this['inbuf_']=_0x1db05d,this['total_']+=_0x11861a;}['digest'](){const _0x2a5e6d=[];let _0x2efe06=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1fab67=this['blockSize']-0x1;_0x1fab67>=0x38;_0x1fab67--)this['buf_'][_0x1fab67]=_0x2efe06&0xff,_0x2efe06/=0x100;this['compress_'](this['buf_']);let _0xe80325=0x0;for(let _0x8ce57b=0x0;_0x8ce57b<0x5;_0x8ce57b++)for(let _0x354827=0x18;_0x354827>=0x0;_0x354827-=0x8)_0x2a5e6d[_0xe80325]=this['chain_'][_0x8ce57b]>>_0x354827&0xff,++_0xe80325;return _0x2a5e6d;}}function Tc(_0xdec7cc,_0x3f9408){const _0x1f2669=new Sc(_0xdec7cc,_0x3f9408);return _0x1f2669['subscribe']['bind'](_0x1f2669);}class Sc{constructor(_0x365618,_0x25390c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x25390c,this['task']['then'](()=>{_0x365618(this);})['catch'](_0x4430f2=>{this['error'](_0x4430f2);});}['next'](_0x191456){this['forEachObserver'](_0x572e53=>{_0x572e53['next'](_0x191456);});}['error'](_0x1024f2){this['forEachObserver'](_0x5a8ebe=>{_0x5a8ebe['error'](_0x1024f2);}),this['close'](_0x1024f2);}['complete'](){this['forEachObserver'](_0x25e0bf=>{_0x25e0bf['complete']();}),this['close']();}['subscribe'](_0x2c1f98,_0x2f048e,_0x574bff){let _0x3b0f16;if(_0x2c1f98===void 0x0&&_0x2f048e===void 0x0&&_0x574bff===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2c1f98,['next','error','complete'])?_0x3b0f16=_0x2c1f98:_0x3b0f16={'next':_0x2c1f98,'error':_0x2f048e,'complete':_0x574bff},_0x3b0f16['next']===void 0x0&&(_0x3b0f16['next']=ti),_0x3b0f16['error']===void 0x0&&(_0x3b0f16['error']=ti),_0x3b0f16['complete']===void 0x0&&(_0x3b0f16['complete']=ti);const _0x56a5fd=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3b0f16['error'](this['finalError']):_0x3b0f16['complete']();}catch{}}),this['observers']['push'](_0x3b0f16),_0x56a5fd;}['unsubscribeOne'](_0x522757){this['observers']===void 0x0||this['observers'][_0x522757]===void 0x0||(delete this['observers'][_0x522757],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2d2b46){if(!this['finalized']){for(let _0x4d7505=0x0;_0x4d7505<this['observers']['length'];_0x4d7505++)this['sendOne'](_0x4d7505,_0x2d2b46);}}['sendOne'](_0x689427,_0x166004){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x689427]!==void 0x0)try{_0x166004(this['observers'][_0x689427]);}catch(_0x4d8045){typeof console<'u'&&console['error']&&console['error'](_0x4d8045);}});}['close'](_0x5c4a6a){this['finalized']||(this['finalized']=!0x0,_0x5c4a6a!==void 0x0&&(this['finalError']=_0x5c4a6a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1f8f5f,_0x5606b9){if(typeof _0x1f8f5f!='object'||_0x1f8f5f===null)return!0x1;for(const _0x2e3643 of _0x5606b9)if(_0x2e3643 in _0x1f8f5f&&typeof _0x1f8f5f[_0x2e3643]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x2e871f,_0x49be67){return _0x2e871f+'\x20failed:\x20'+_0x49be67+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4e274a){const _0x5bd86d=[];let _0x7fa942=0x0;for(let _0xdf0d8a=0x0;_0xdf0d8a<_0x4e274a['length'];_0xdf0d8a++){let _0x5839dd=_0x4e274a['charCodeAt'](_0xdf0d8a);if(_0x5839dd>=0xd800&&_0x5839dd<=0xdbff){const _0x1f04da=_0x5839dd-0xd800;_0xdf0d8a++,f(_0xdf0d8a<_0x4e274a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3b589c=_0x4e274a['charCodeAt'](_0xdf0d8a)-0xdc00;_0x5839dd=0x10000+(_0x1f04da<<0xa)+_0x3b589c;}_0x5839dd<0x80?_0x5bd86d[_0x7fa942++]=_0x5839dd:_0x5839dd<0x800?(_0x5bd86d[_0x7fa942++]=_0x5839dd>>0x6|0xc0,_0x5bd86d[_0x7fa942++]=_0x5839dd&0x3f|0x80):_0x5839dd<0x10000?(_0x5bd86d[_0x7fa942++]=_0x5839dd>>0xc|0xe0,_0x5bd86d[_0x7fa942++]=_0x5839dd>>0x6&0x3f|0x80,_0x5bd86d[_0x7fa942++]=_0x5839dd&0x3f|0x80):(_0x5bd86d[_0x7fa942++]=_0x5839dd>>0x12|0xf0,_0x5bd86d[_0x7fa942++]=_0x5839dd>>0xc&0x3f|0x80,_0x5bd86d[_0x7fa942++]=_0x5839dd>>0x6&0x3f|0x80,_0x5bd86d[_0x7fa942++]=_0x5839dd&0x3f|0x80);}return _0x5bd86d;},Ln=function(_0x48ce66){let _0x2d158e=0x0;for(let _0x29df08=0x0;_0x29df08<_0x48ce66['length'];_0x29df08++){const _0x1508ca=_0x48ce66['charCodeAt'](_0x29df08);_0x1508ca<0x80?_0x2d158e++:_0x1508ca<0x800?_0x2d158e+=0x2:_0x1508ca>=0xd800&&_0x1508ca<=0xdbff?(_0x2d158e+=0x4,_0x29df08++):_0x2d158e+=0x3;}return _0x2d158e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x2c2284){return _0x2c2284&&_0x2c2284['_delegate']?_0x2c2284['_delegate']:_0x2c2284;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x41fb59){try{return(_0x41fb59['startsWith']('http://')||_0x41fb59['startsWith']('https://')?new URL(_0x41fb59)['hostname']:_0x41fb59)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3d4792){return(await fetch(_0x3d4792,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x9903be,_0x2fb2b8,_0x1b6bce){this['name']=_0x9903be,this['instanceFactory']=_0x2fb2b8,this['type']=_0x1b6bce,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x91451f){return this['instantiationMode']=_0x91451f,this;}['setMultipleInstances'](_0x4bb70d){return this['multipleInstances']=_0x4bb70d,this;}['setServiceProps'](_0x17decd){return this['serviceProps']=_0x17decd,this;}['setInstanceCreatedCallback'](_0x9d718d){return this['onInstanceCreated']=_0x9d718d,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x433b79,_0xd611a6){this['name']=_0x433b79,this['container']=_0xd611a6,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x22af85){const _0x3887b2=this['normalizeInstanceIdentifier'](_0x22af85);if(!this['instancesDeferred']['has'](_0x3887b2)){const _0x5a96c0=new H();if(this['instancesDeferred']['set'](_0x3887b2,_0x5a96c0),this['isInitialized'](_0x3887b2)||this['shouldAutoInitialize']())try{const _0x4b6ca4=this['getOrInitializeService']({'instanceIdentifier':_0x3887b2});_0x4b6ca4&&_0x5a96c0['resolve'](_0x4b6ca4);}catch{}}return this['instancesDeferred']['get'](_0x3887b2)['promise'];}['getImmediate'](_0x10fff6){const _0x5606e5=this['normalizeInstanceIdentifier'](_0x10fff6==null?void 0x0:_0x10fff6['identifier']),_0x11daed=(_0x10fff6==null?void 0x0:_0x10fff6['optional'])??!0x1;if(this['isInitialized'](_0x5606e5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5606e5});}catch(_0x476a15){if(_0x11daed)return null;throw _0x476a15;}else{if(_0x11daed)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x20b951){if(_0x20b951['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x20b951['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x20b951,!!this['shouldAutoInitialize']()){if(Pc(_0x20b951))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4b5d99,_0x52690b]of this['instancesDeferred']['entries']()){const _0x5f0b9e=this['normalizeInstanceIdentifier'](_0x4b5d99);try{const _0x40e05f=this['getOrInitializeService']({'instanceIdentifier':_0x5f0b9e});_0x52690b['resolve'](_0x40e05f);}catch{}}}}['clearInstance'](_0x4bc4b5=Ne){this['instancesDeferred']['delete'](_0x4bc4b5),this['instancesOptions']['delete'](_0x4bc4b5),this['instances']['delete'](_0x4bc4b5);}async['delete'](){const _0x2a2728=Array['from'](this['instances']['values']());await Promise['all']([..._0x2a2728['filter'](_0x479846=>'INTERNAL'in _0x479846)['map'](_0xb8079b=>_0xb8079b['INTERNAL']['delete']()),..._0x2a2728['filter'](_0x56d5a5=>'_delete'in _0x56d5a5)['map'](_0x479c8a=>_0x479c8a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x339a34=Ne){return this['instances']['has'](_0x339a34);}['getOptions'](_0x18e9fe=Ne){return this['instancesOptions']['get'](_0x18e9fe)||{};}['initialize'](_0x408136={}){const {options:_0x2886aa={}}=_0x408136,_0x26b6a0=this['normalizeInstanceIdentifier'](_0x408136['instanceIdentifier']);if(this['isInitialized'](_0x26b6a0))throw Error(this['name']+'('+_0x26b6a0+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4f9e62=this['getOrInitializeService']({'instanceIdentifier':_0x26b6a0,'options':_0x2886aa});for(const [_0x27b630,_0x40a477]of this['instancesDeferred']['entries']()){const _0x2d7ca9=this['normalizeInstanceIdentifier'](_0x27b630);_0x26b6a0===_0x2d7ca9&&_0x40a477['resolve'](_0x4f9e62);}return _0x4f9e62;}['onInit'](_0x1c0a02,_0x2ed7ec){const _0x438cbf=this['normalizeInstanceIdentifier'](_0x2ed7ec),_0x4d5ace=this['onInitCallbacks']['get'](_0x438cbf)??new Set();_0x4d5ace['add'](_0x1c0a02),this['onInitCallbacks']['set'](_0x438cbf,_0x4d5ace);const _0x39e2da=this['instances']['get'](_0x438cbf);return _0x39e2da&&_0x1c0a02(_0x39e2da,_0x438cbf),()=>{_0x4d5ace['delete'](_0x1c0a02);};}['invokeOnInitCallbacks'](_0x48d6c7,_0x23ea43){const _0x3d73ea=this['onInitCallbacks']['get'](_0x23ea43);if(_0x3d73ea){for(const _0x462a66 of _0x3d73ea)try{_0x462a66(_0x48d6c7,_0x23ea43);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1c2fc8,options:_0x13cade={}}){let _0x7f3dc5=this['instances']['get'](_0x1c2fc8);if(!_0x7f3dc5&&this['component']&&(_0x7f3dc5=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1c2fc8),'options':_0x13cade}),this['instances']['set'](_0x1c2fc8,_0x7f3dc5),this['instancesOptions']['set'](_0x1c2fc8,_0x13cade),this['invokeOnInitCallbacks'](_0x7f3dc5,_0x1c2fc8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1c2fc8,_0x7f3dc5);}catch{}return _0x7f3dc5||null;}['normalizeInstanceIdentifier'](_0x3c8ef5=Ne){return this['component']?this['component']['multipleInstances']?_0x3c8ef5:Ne:_0x3c8ef5;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x3a6dd4){return _0x3a6dd4===Ne?void 0x0:_0x3a6dd4;}function Pc(_0x1afb0a){return _0x1afb0a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x5cba5a){this['name']=_0x5cba5a,this['providers']=new Map();}['addComponent'](_0x377ea7){const _0x1fa030=this['getProvider'](_0x377ea7['name']);if(_0x1fa030['isComponentSet']())throw new Error('Component\x20'+_0x377ea7['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1fa030['setComponent'](_0x377ea7);}['addOrOverwriteComponent'](_0x1fce8e){this['getProvider'](_0x1fce8e['name'])['isComponentSet']()&&this['providers']['delete'](_0x1fce8e['name']),this['addComponent'](_0x1fce8e);}['getProvider'](_0x816fbd){if(this['providers']['has'](_0x816fbd))return this['providers']['get'](_0x816fbd);const _0x21193d=new Ac(_0x816fbd,this);return this['providers']['set'](_0x816fbd,_0x21193d),_0x21193d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2352f0){_0x2352f0[_0x2352f0['DEBUG']=0x0]='DEBUG',_0x2352f0[_0x2352f0['VERBOSE']=0x1]='VERBOSE',_0x2352f0[_0x2352f0['INFO']=0x2]='INFO',_0x2352f0[_0x2352f0['WARN']=0x3]='WARN',_0x2352f0[_0x2352f0['ERROR']=0x4]='ERROR',_0x2352f0[_0x2352f0['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x42669f,_0x735139,..._0xbd1458)=>{if(_0x735139<_0x42669f['logLevel'])return;const _0x4d0501=new Date()['toISOString'](),_0x4dad88=Mc[_0x735139];if(_0x4dad88)console[_0x4dad88]('['+_0x4d0501+']\x20\x20'+_0x42669f['name']+':',..._0xbd1458);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x735139+')');};class Bi{constructor(_0x570ff8){this['name']=_0x570ff8,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x37eda4){if(!(_0x37eda4 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x37eda4+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x37eda4;}['setLogLevel'](_0x568eb7){this['_logLevel']=typeof _0x568eb7=='string'?Oc[_0x568eb7]:_0x568eb7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1198fa){if(typeof _0x1198fa!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1198fa;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2f6fa3){this['_userLogHandler']=_0x2f6fa3;}['debug'](..._0x2fde82){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2fde82),this['_logHandler'](this,T['DEBUG'],..._0x2fde82);}['log'](..._0x4b4bb2){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4b4bb2),this['_logHandler'](this,T['VERBOSE'],..._0x4b4bb2);}['info'](..._0x57e666){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x57e666),this['_logHandler'](this,T['INFO'],..._0x57e666);}['warn'](..._0x190a61){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x190a61),this['_logHandler'](this,T['WARN'],..._0x190a61);}['error'](..._0x4584e8){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4584e8),this['_logHandler'](this,T['ERROR'],..._0x4584e8);}}const xc=(_0x560ae5,_0x517261)=>_0x517261['some'](_0xa262ba=>_0x560ae5 instanceof _0xa262ba);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x22d04f){const _0x3a89e4=new Promise((_0xa9043d,_0x334a2d)=>{const _0x558d02=()=>{_0x22d04f['removeEventListener']('success',_0x17c05c),_0x22d04f['removeEventListener']('error',_0x397e00);},_0x17c05c=()=>{_0xa9043d(ge(_0x22d04f['result'])),_0x558d02();},_0x397e00=()=>{_0x334a2d(_0x22d04f['error']),_0x558d02();};_0x22d04f['addEventListener']('success',_0x17c05c),_0x22d04f['addEventListener']('error',_0x397e00);});return _0x3a89e4['then'](_0x499575=>{_0x499575 instanceof IDBCursor&&Jr['set'](_0x499575,_0x22d04f);})['catch'](()=>{}),Vi['set'](_0x3a89e4,_0x22d04f),_0x3a89e4;}function Bc(_0x5b274a){if(_i['has'](_0x5b274a))return;const _0x2f3d3d=new Promise((_0x43e683,_0x5dd34c)=>{const _0x14564d=()=>{_0x5b274a['removeEventListener']('complete',_0x1363ae),_0x5b274a['removeEventListener']('error',_0x5e65cd),_0x5b274a['removeEventListener']('abort',_0x5e65cd);},_0x1363ae=()=>{_0x43e683(),_0x14564d();},_0x5e65cd=()=>{_0x5dd34c(_0x5b274a['error']||new DOMException('AbortError','AbortError')),_0x14564d();};_0x5b274a['addEventListener']('complete',_0x1363ae),_0x5b274a['addEventListener']('error',_0x5e65cd),_0x5b274a['addEventListener']('abort',_0x5e65cd);});_i['set'](_0x5b274a,_0x2f3d3d);}let gi={'get'(_0x373837,_0x477eca,_0x35f9cd){if(_0x373837 instanceof IDBTransaction){if(_0x477eca==='done')return _i['get'](_0x373837);if(_0x477eca==='objectStoreNames')return _0x373837['objectStoreNames']||Xr['get'](_0x373837);if(_0x477eca==='store')return _0x35f9cd['objectStoreNames'][0x1]?void 0x0:_0x35f9cd['objectStore'](_0x35f9cd['objectStoreNames'][0x0]);}return ge(_0x373837[_0x477eca]);},'set'(_0x3b6cab,_0x18053d,_0x4cab68){return _0x3b6cab[_0x18053d]=_0x4cab68,!0x0;},'has'(_0x2e74bf,_0x2d3ba1){return _0x2e74bf instanceof IDBTransaction&&(_0x2d3ba1==='done'||_0x2d3ba1==='store')?!0x0:_0x2d3ba1 in _0x2e74bf;}};function Vc(_0x3f3c60){gi=_0x3f3c60(gi);}function Hc(_0x114248){return _0x114248===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x182405,..._0x56f392){const _0x199648=_0x114248['call'](ii(this),_0x182405,..._0x56f392);return Xr['set'](_0x199648,_0x182405['sort']?_0x182405['sort']():[_0x182405]),ge(_0x199648);}:Uc()['includes'](_0x114248)?function(..._0x200946){return _0x114248['apply'](ii(this),_0x200946),ge(Jr['get'](this));}:function(..._0x2e5f53){return ge(_0x114248['apply'](ii(this),_0x2e5f53));};}function $c(_0x3892bc){return typeof _0x3892bc=='function'?Hc(_0x3892bc):(_0x3892bc instanceof IDBTransaction&&Bc(_0x3892bc),xc(_0x3892bc,Fc())?new Proxy(_0x3892bc,gi):_0x3892bc);}function ge(_0x555d8d){if(_0x555d8d instanceof IDBRequest)return Wc(_0x555d8d);if(ni['has'](_0x555d8d))return ni['get'](_0x555d8d);const _0x13f042=$c(_0x555d8d);return _0x13f042!==_0x555d8d&&(ni['set'](_0x555d8d,_0x13f042),Vi['set'](_0x13f042,_0x555d8d)),_0x13f042;}const ii=_0x211baa=>Vi['get'](_0x211baa);function Gc(_0x2a3867,_0x267b19,{blocked:_0x2334fc,upgrade:_0x331abf,blocking:_0x438b5f,terminated:_0x3a304a}={}){const _0x1b350c=indexedDB['open'](_0x2a3867,_0x267b19),_0x2378f1=ge(_0x1b350c);return _0x331abf&&_0x1b350c['addEventListener']('upgradeneeded',_0x37eca9=>{_0x331abf(ge(_0x1b350c['result']),_0x37eca9['oldVersion'],_0x37eca9['newVersion'],ge(_0x1b350c['transaction']),_0x37eca9);}),_0x2334fc&&_0x1b350c['addEventListener']('blocked',_0x10bbf4=>_0x2334fc(_0x10bbf4['oldVersion'],_0x10bbf4['newVersion'],_0x10bbf4)),_0x2378f1['then'](_0x12a626=>{_0x3a304a&&_0x12a626['addEventListener']('close',()=>_0x3a304a()),_0x438b5f&&_0x12a626['addEventListener']('versionchange',_0x105f00=>_0x438b5f(_0x105f00['oldVersion'],_0x105f00['newVersion'],_0x105f00));})['catch'](()=>{}),_0x2378f1;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x50d037,_0x30ee5a){if(!(_0x50d037 instanceof IDBDatabase&&!(_0x30ee5a in _0x50d037)&&typeof _0x30ee5a=='string'))return;if(si['get'](_0x30ee5a))return si['get'](_0x30ee5a);const _0xdf9e21=_0x30ee5a['replace'](/FromIndex$/,''),_0x8ab8df=_0x30ee5a!==_0xdf9e21,_0x3a6b99=zc['includes'](_0xdf9e21);if(!(_0xdf9e21 in(_0x8ab8df?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3a6b99||qc['includes'](_0xdf9e21)))return;const _0xf4ccf0=async function(_0x28f428,..._0x386a65){const _0x29654e=this['transaction'](_0x28f428,_0x3a6b99?'readwrite':'readonly');let _0x4ed36b=_0x29654e['store'];return _0x8ab8df&&(_0x4ed36b=_0x4ed36b['index'](_0x386a65['shift']())),(await Promise['all']([_0x4ed36b[_0xdf9e21](..._0x386a65),_0x3a6b99&&_0x29654e['done']]))[0x0];};return si['set'](_0x30ee5a,_0xf4ccf0),_0xf4ccf0;}Vc(_0x1ee79e=>({..._0x1ee79e,'get':(_0x4e0045,_0x5aa64a,_0x2dba3e)=>Ms(_0x4e0045,_0x5aa64a)||_0x1ee79e['get'](_0x4e0045,_0x5aa64a,_0x2dba3e),'has':(_0x32cb77,_0x10c258)=>!!Ms(_0x32cb77,_0x10c258)||_0x1ee79e['has'](_0x32cb77,_0x10c258)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x556a39){this['container']=_0x556a39;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x48bc8a=>{if(Kc(_0x48bc8a)){const _0x405a49=_0x48bc8a['getImmediate']();return _0x405a49['library']+'/'+_0x405a49['version'];}else return null;})['filter'](_0x3ad824=>_0x3ad824)['join']('\x20');}}function Kc(_0x5d9a02){const _0x40b0b5=_0x5d9a02['getComponent']();return(_0x40b0b5==null?void 0x0:_0x40b0b5['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x5f1dd7,_0xb87d2a){try{_0x5f1dd7['container']['addComponent'](_0xb87d2a);}catch(_0x1a65eb){oe['debug']('Component\x20'+_0xb87d2a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5f1dd7['name'],_0x1a65eb);}}function st(_0x30d269){const _0x336eb3=_0x30d269['name'];if(Ei['has'](_0x336eb3))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x336eb3+'.'),!0x1;Ei['set'](_0x336eb3,_0x30d269);for(const _0x5cab65 of Ue['values']())xs(_0x5cab65,_0x30d269);for(const _0xb37aa6 of vi['values']())xs(_0xb37aa6,_0x30d269);return!0x0;}function Hi(_0x49fbf6,_0x5905d3){const _0x290208=_0x49fbf6['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x290208&&_0x290208['triggerHeartbeat'](),_0x49fbf6['container']['getProvider'](_0x5905d3);}function $(_0xc96bdd){return _0xc96bdd==null?!0x1:_0xc96bdd['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1a8e19,_0x4d7137,_0x2fb505){this['_isDeleted']=!0x1,this['_options']={..._0x1a8e19},this['_config']={..._0x4d7137},this['_name']=_0x4d7137['name'],this['_automaticDataCollectionEnabled']=_0x4d7137['automaticDataCollectionEnabled'],this['_container']=_0x2fb505,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x125c9e){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x125c9e;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x38ccbc){this['_isDeleted']=_0x38ccbc;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x2f2e4b,_0x4c743a={}){let _0x4ef383=_0x2f2e4b;typeof _0x4c743a!='object'&&(_0x4c743a={'name':_0x4c743a});const _0x4d03b5={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4c743a},_0x550e38=_0x4d03b5['name'];if(typeof _0x550e38!='string'||!_0x550e38)throw me['create']('bad-app-name',{'appName':String(_0x550e38)});if(_0x4ef383||(_0x4ef383=zr()),!_0x4ef383)throw me['create']('no-options');const _0x4e2726=Ue['get'](_0x550e38);if(_0x4e2726){if(xe(_0x4ef383,_0x4e2726['options'])&&xe(_0x4d03b5,_0x4e2726['config']))return _0x4e2726;throw me['create']('duplicate-app',{'appName':_0x550e38});}const _0x2dd4c6=new Nc(_0x550e38);for(const _0x378c11 of Ei['values']())_0x2dd4c6['addComponent'](_0x378c11);const _0x3fafba=new Tl(_0x4ef383,_0x4d03b5,_0x2dd4c6);return Ue['set'](_0x550e38,_0x3fafba),_0x3fafba;}function Zr(_0x2ab87f=yi){const _0x233cae=Ue['get'](_0x2ab87f);if(!_0x233cae&&_0x2ab87f===yi&&zr())return Sl();if(!_0x233cae)throw me['create']('no-app',{'appName':_0x2ab87f});return _0x233cae;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x3cf321){let _0xc57701=!0x1;const _0x15f52b=_0x3cf321['name'];Ue['has'](_0x15f52b)?(_0xc57701=!0x0,Ue['delete'](_0x15f52b)):vi['has'](_0x15f52b)&&_0x3cf321['decRefCount']()<=0x0&&(vi['delete'](_0x15f52b),_0xc57701=!0x0),_0xc57701&&(await Promise['all'](_0x3cf321['container']['getProviders']()['map'](_0x4eac76=>_0x4eac76['delete']())),_0x3cf321['isDeleted']=!0x0);}function ye(_0x102ec5,_0x2d295a,_0x2940b1){let _0x3dc82f=wl[_0x102ec5]??_0x102ec5;_0x2940b1&&(_0x3dc82f+='-'+_0x2940b1);const _0x3eb619=_0x3dc82f['match'](/\s|\//),_0x2e6887=_0x2d295a['match'](/\s|\//);if(_0x3eb619||_0x2e6887){const _0x2963de=['Unable\x20to\x20register\x20library\x20\x22'+_0x3dc82f+'\x22\x20with\x20version\x20\x22'+_0x2d295a+'\x22:'];_0x3eb619&&_0x2963de['push']('library\x20name\x20\x22'+_0x3dc82f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3eb619&&_0x2e6887&&_0x2963de['push']('and'),_0x2e6887&&_0x2963de['push']('version\x20name\x20\x22'+_0x2d295a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2963de['join']('\x20'));return;}st(new Fe(_0x3dc82f+'-version',()=>({'library':_0x3dc82f,'version':_0x2d295a}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x37827b,_0x186855)=>{switch(_0x186855){case 0x0:try{_0x37827b['createObjectStore'](Ot);}catch(_0x44a2c8){console['warn'](_0x44a2c8);}}}})['catch'](_0x6ef70d=>{throw me['create']('idb-open',{'originalErrorMessage':_0x6ef70d['message']});})),ri;}async function Al(_0x102cb6){try{const _0x5e5dcc=(await eo())['transaction'](Ot),_0x5f2740=await _0x5e5dcc['objectStore'](Ot)['get'](to(_0x102cb6));return await _0x5e5dcc['done'],_0x5f2740;}catch(_0x4a2430){if(_0x4a2430 instanceof Re)oe['warn'](_0x4a2430['message']);else{const _0xa1c582=me['create']('idb-get',{'originalErrorMessage':_0x4a2430==null?void 0x0:_0x4a2430['message']});oe['warn'](_0xa1c582['message']);}}}async function Fs(_0x334413,_0x1fe553){try{const _0x49bf51=(await eo())['transaction'](Ot,'readwrite');await _0x49bf51['objectStore'](Ot)['put'](_0x1fe553,to(_0x334413)),await _0x49bf51['done'];}catch(_0x269d2d){if(_0x269d2d instanceof Re)oe['warn'](_0x269d2d['message']);else{const _0x58b2d3=me['create']('idb-set',{'originalErrorMessage':_0x269d2d==null?void 0x0:_0x269d2d['message']});oe['warn'](_0x58b2d3['message']);}}}function to(_0x193067){return _0x193067['name']+'!'+_0x193067['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x77fcd){this['container']=_0x77fcd,this['_heartbeatsCache']=null;const _0x364b80=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x364b80),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x351f5f=>(this['_heartbeatsCache']=_0x351f5f,_0x351f5f));}async['triggerHeartbeat'](){var _0xde8fe3,_0x306578;try{const _0x21b767=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3f5fef=Us();if(((_0xde8fe3=this['_heartbeatsCache'])==null?void 0x0:_0xde8fe3['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x306578=this['_heartbeatsCache'])==null?void 0x0:_0x306578['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3f5fef||this['_heartbeatsCache']['heartbeats']['some'](_0x23c37a=>_0x23c37a['date']===_0x3f5fef))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3f5fef,'agent':_0x21b767}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x8d0282=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x8d0282,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x26cbf){oe['warn'](_0x26cbf);}}async['getHeartbeatsHeader'](){var _0xdd8b49;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xdd8b49=this['_heartbeatsCache'])==null?void 0x0:_0xdd8b49['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x49f206=Us(),{heartbeatsToSend:_0x4c2bae,unsentEntries:_0x2821a3}=Ol(this['_heartbeatsCache']['heartbeats']),_0x1e0215=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4c2bae}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x49f206,_0x2821a3['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2821a3,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1e0215;}catch(_0x1d7107){return oe['warn'](_0x1d7107),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5c9af4,_0x19aa99=kl){const _0x37fff4=[];let _0x848957=_0x5c9af4['slice']();for(const _0xf2e8cd of _0x5c9af4){const _0x550031=_0x37fff4['find'](_0x2e9b88=>_0x2e9b88['agent']===_0xf2e8cd['agent']);if(_0x550031){if(_0x550031['dates']['push'](_0xf2e8cd['date']),Ws(_0x37fff4)>_0x19aa99){_0x550031['dates']['pop']();break;}}else{if(_0x37fff4['push']({'agent':_0xf2e8cd['agent'],'dates':[_0xf2e8cd['date']]}),Ws(_0x37fff4)>_0x19aa99){_0x37fff4['pop']();break;}}_0x848957=_0x848957['slice'](0x1);}return{'heartbeatsToSend':_0x37fff4,'unsentEntries':_0x848957};}class Dl{constructor(_0x4374ea){this['app']=_0x4374ea,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x11ea7f=await Al(this['app']);return _0x11ea7f!=null&&_0x11ea7f['heartbeats']?_0x11ea7f:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5a04a5){if(await this['_canUseIndexedDBPromise']){const _0x38fffd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5a04a5['lastSentHeartbeatDate']??_0x38fffd['lastSentHeartbeatDate'],'heartbeats':_0x5a04a5['heartbeats']});}else return;}async['add'](_0x374edc){if(await this['_canUseIndexedDBPromise']){const _0x2a1a61=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x374edc['lastSentHeartbeatDate']??_0x2a1a61['lastSentHeartbeatDate'],'heartbeats':[..._0x2a1a61['heartbeats'],..._0x374edc['heartbeats']]});}else return;}}function Ws(_0x557d66){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x557d66}))['length'];}function Ml(_0x10a9d9){if(_0x10a9d9['length']===0x0)return-0x1;let _0x243845=0x0,_0x53ea05=_0x10a9d9[0x0]['date'];for(let _0x1b8ca3=0x1;_0x1b8ca3<_0x10a9d9['length'];_0x1b8ca3++)_0x10a9d9[_0x1b8ca3]['date']<_0x53ea05&&(_0x53ea05=_0x10a9d9[_0x1b8ca3]['date'],_0x243845=_0x1b8ca3);return _0x243845;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1b3d1a){st(new Fe('platform-logger',_0x36ab71=>new jc(_0x36ab71),'PRIVATE')),st(new Fe('heartbeat',_0x405012=>new Nl(_0x405012),'PRIVATE')),ye(mi,Ls,_0x1b3d1a),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2e6f9c){no=_0x2e6f9c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x4cf35a){this['domStorage_']=_0x4cf35a,this['prefix_']='firebase:';}['set'](_0x454bd6,_0xa2cab6){_0xa2cab6==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x454bd6)):this['domStorage_']['setItem'](this['prefixedName_'](_0x454bd6),O(_0xa2cab6));}['get'](_0x1de8e7){const _0x5aef14=this['domStorage_']['getItem'](this['prefixedName_'](_0x1de8e7));return _0x5aef14==null?null:Nt(_0x5aef14);}['remove'](_0x1cb617){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1cb617));}['prefixedName_'](_0x11350d){return this['prefix_']+_0x11350d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x585813,_0x272cd8){_0x272cd8==null?delete this['cache_'][_0x585813]:this['cache_'][_0x585813]=_0x272cd8;}['get'](_0x5e597c){return Q(this['cache_'],_0x5e597c)?this['cache_'][_0x5e597c]:null;}['remove'](_0x504008){delete this['cache_'][_0x504008];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3fce55){try{if(typeof window<'u'&&typeof window[_0x3fce55]<'u'){const _0x936272=window[_0x3fce55];return _0x936272['setItem']('firebase:sentinel','cache'),_0x936272['removeItem']('firebase:sentinel'),new Wl(_0x936272);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3399f8=0x1;return function(){return _0x3399f8++;};}()),ro=function(_0x23b9e2){const _0x2848d8=Rc(_0x23b9e2),_0x2bd23c=new Cc();_0x2bd23c['update'](_0x2848d8);const _0x3c8596=_0x2bd23c['digest']();return Fi['encodeByteArray'](_0x3c8596);},zt=function(..._0x3745db){let _0x3a3a4d='';for(let _0x303e32=0x0;_0x303e32<_0x3745db['length'];_0x303e32++){const _0x454b25=_0x3745db[_0x303e32];Array['isArray'](_0x454b25)||_0x454b25&&typeof _0x454b25=='object'&&typeof _0x454b25['length']=='number'?_0x3a3a4d+=zt['apply'](null,_0x454b25):typeof _0x454b25=='object'?_0x3a3a4d+=O(_0x454b25):_0x3a3a4d+=_0x454b25,_0x3a3a4d+='\x20';}return _0x3a3a4d;};let St=null,$s=!0x0;const Hl=function(_0x40c7cd,_0x5303f8){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x33123b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x59affe=zt['apply'](null,_0x33123b);St(_0x59affe);}},jt=function(_0x2fc068){return function(..._0x14232f){L(_0x2fc068,..._0x14232f);};},Ii=function(..._0x15bcae){const _0x56d2ad='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x15bcae);Ze['error'](_0x56d2ad);},ae=function(..._0x3249a3){const _0x4fcc06='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x3249a3);throw Ze['error'](_0x4fcc06),new Error(_0x4fcc06);},U=function(..._0x4767ab){const _0x2d504a='FIREBASE\x20WARNING:\x20'+zt(..._0x4767ab);Ze['warn'](_0x2d504a);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x59baba){return typeof _0x59baba=='number'&&(_0x59baba!==_0x59baba||_0x59baba===Number['POSITIVE_INFINITY']||_0x59baba===Number['NEGATIVE_INFINITY']);},Gl=function(_0xfb453d){if(document['readyState']==='complete')_0xfb453d();else{let _0x36b090=!0x1;const _0x51ea81=function(){if(!document['body']){setTimeout(_0x51ea81,Math['floor'](0xa));return;}_0x36b090||(_0x36b090=!0x0,_0xfb453d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x51ea81,!0x1),window['addEventListener']('load',_0x51ea81,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x51ea81();}),window['attachEvent']('onload',_0x51ea81));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0xeaa01c,_0x3fd71a){if(_0xeaa01c===_0x3fd71a)return 0x0;if(_0xeaa01c===We||_0x3fd71a===we)return-0x1;if(_0x3fd71a===We||_0xeaa01c===we)return 0x1;{const _0x278edf=Gs(_0xeaa01c),_0xa2fd7d=Gs(_0x3fd71a);return _0x278edf!==null?_0xa2fd7d!==null?_0x278edf-_0xa2fd7d===0x0?_0xeaa01c['length']-_0x3fd71a['length']:_0x278edf-_0xa2fd7d:-0x1:_0xa2fd7d!==null?0x1:_0xeaa01c<_0x3fd71a?-0x1:0x1;}},ql=function(_0x2bdf31,_0x26e12d){return _0x2bdf31===_0x26e12d?0x0:_0x2bdf31<_0x26e12d?-0x1:0x1;},vt=function(_0x4117e7,_0x427dbd){if(_0x427dbd&&_0x4117e7 in _0x427dbd)return _0x427dbd[_0x4117e7];throw new Error('Missing\x20required\x20key\x20('+_0x4117e7+')\x20in\x20object:\x20'+O(_0x427dbd));},$i=function(_0x5ea903){if(typeof _0x5ea903!='object'||_0x5ea903===null)return O(_0x5ea903);const _0x12ea46=[];for(const _0x595872 in _0x5ea903)_0x12ea46['push'](_0x595872);_0x12ea46['sort']();let _0x3f505c='{';for(let _0x238844=0x0;_0x238844<_0x12ea46['length'];_0x238844++)_0x238844!==0x0&&(_0x3f505c+=','),_0x3f505c+=O(_0x12ea46[_0x238844]),_0x3f505c+=':',_0x3f505c+=$i(_0x5ea903[_0x12ea46[_0x238844]]);return _0x3f505c+='}',_0x3f505c;},oo=function(_0x542aa5,_0x50f57c){const _0x5d99d6=_0x542aa5['length'];if(_0x5d99d6<=_0x50f57c)return[_0x542aa5];const _0x5b6bfb=[];for(let _0x59b87a=0x0;_0x59b87a<_0x5d99d6;_0x59b87a+=_0x50f57c)_0x59b87a+_0x50f57c>_0x5d99d6?_0x5b6bfb['push'](_0x542aa5['substring'](_0x59b87a,_0x5d99d6)):_0x5b6bfb['push'](_0x542aa5['substring'](_0x59b87a,_0x59b87a+_0x50f57c));return _0x5b6bfb;};function x(_0x847ba8,_0x377313){for(const _0x871f90 in _0x847ba8)_0x847ba8['hasOwnProperty'](_0x871f90)&&_0x377313(_0x871f90,_0x847ba8[_0x871f90]);}const ao=function(_0x1a7324){f(!xn(_0x1a7324),'Invalid\x20JSON\x20number');const _0x90dc75=0xb,_0x5e8edf=0x34,_0x1dc30e=(0x1<<_0x90dc75-0x1)-0x1;let _0x3ae5f3,_0x319a89,_0x22b15d,_0x524258,_0x5e30d0;_0x1a7324===0x0?(_0x319a89=0x0,_0x22b15d=0x0,_0x3ae5f3=0x1/_0x1a7324===-0x1/0x0?0x1:0x0):(_0x3ae5f3=_0x1a7324<0x0,_0x1a7324=Math['abs'](_0x1a7324),_0x1a7324>=Math['pow'](0x2,0x1-_0x1dc30e)?(_0x524258=Math['min'](Math['floor'](Math['log'](_0x1a7324)/Math['LN2']),_0x1dc30e),_0x319a89=_0x524258+_0x1dc30e,_0x22b15d=Math['round'](_0x1a7324*Math['pow'](0x2,_0x5e8edf-_0x524258)-Math['pow'](0x2,_0x5e8edf))):(_0x319a89=0x0,_0x22b15d=Math['round'](_0x1a7324/Math['pow'](0x2,0x1-_0x1dc30e-_0x5e8edf))));const _0x1d3343=[];for(_0x5e30d0=_0x5e8edf;_0x5e30d0;_0x5e30d0-=0x1)_0x1d3343['push'](_0x22b15d%0x2?0x1:0x0),_0x22b15d=Math['floor'](_0x22b15d/0x2);for(_0x5e30d0=_0x90dc75;_0x5e30d0;_0x5e30d0-=0x1)_0x1d3343['push'](_0x319a89%0x2?0x1:0x0),_0x319a89=Math['floor'](_0x319a89/0x2);_0x1d3343['push'](_0x3ae5f3?0x1:0x0),_0x1d3343['reverse']();const _0x5aa24a=_0x1d3343['join']('');let _0x29ddc4='';for(_0x5e30d0=0x0;_0x5e30d0<0x40;_0x5e30d0+=0x8){let _0x56500d=parseInt(_0x5aa24a['substr'](_0x5e30d0,0x8),0x2)['toString'](0x10);_0x56500d['length']===0x1&&(_0x56500d='0'+_0x56500d),_0x29ddc4=_0x29ddc4+_0x56500d;}return _0x29ddc4['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x8edd1e,_0x194a1b){let _0x537421='Unknown\x20Error';_0x8edd1e==='too_big'?_0x537421='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x8edd1e==='permission_denied'?_0x537421='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x8edd1e==='unavailable'&&(_0x537421='The\x20service\x20is\x20unavailable');const _0x13f0a3=new Error(_0x8edd1e+'\x20at\x20'+_0x194a1b['_path']['toString']()+':\x20'+_0x537421);return _0x13f0a3['code']=_0x8edd1e['toUpperCase'](),_0x13f0a3;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x290d83){if(Yl['test'](_0x290d83)){const _0x518a9a=Number(_0x290d83);if(_0x518a9a>=Ql&&_0x518a9a<=Jl)return _0x518a9a;}return null;},ft=function(_0x2b7c05){try{_0x2b7c05();}catch(_0xf4d54){setTimeout(()=>{const _0x1b1a1f=_0xf4d54['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1b1a1f),_0xf4d54;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x48659,_0x1a69e1){const _0x197624=setTimeout(_0x48659,_0x1a69e1);return typeof _0x197624=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x197624):typeof _0x197624=='object'&&_0x197624['unref']&&_0x197624['unref'](),_0x197624;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x365ab9,_0x4118d2){this['appCheckProvider']=_0x4118d2,this['appName']=_0x365ab9['name'],$(_0x365ab9)&&_0x365ab9['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x365ab9['settings']['appCheckToken']),this['appCheck']=_0x4118d2==null?void 0x0:_0x4118d2['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4118d2==null||_0x4118d2['get']()['then'](_0x17d439=>this['appCheck']=_0x17d439);}['getToken'](_0x1e60bb){if(this['serverAppAppCheckToken']){if(_0x1e60bb)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1e60bb):new Promise((_0xc70566,_0x2888bb)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1e60bb)['then'](_0xc70566,_0x2888bb):_0xc70566(null);},0x0);});}['addTokenChangeListener'](_0x4d9d32){var _0x233192;(_0x233192=this['appCheckProvider'])==null||_0x233192['get']()['then'](_0x5a6129=>_0x5a6129['addTokenListener'](_0x4d9d32));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x36d93f,_0x2bac39,_0x2b7e6f){this['appName_']=_0x36d93f,this['firebaseOptions_']=_0x2bac39,this['authProvider_']=_0x2b7e6f,this['auth_']=null,this['auth_']=_0x2b7e6f['getImmediate']({'optional':!0x0}),this['auth_']||_0x2b7e6f['onInit'](_0x579c27=>this['auth_']=_0x579c27);}['getToken'](_0x3476c5){return this['auth_']?this['auth_']['getToken'](_0x3476c5)['catch'](_0x449d5b=>_0x449d5b&&_0x449d5b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x449d5b)):new Promise((_0x435eec,_0x532fab)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3476c5)['then'](_0x435eec,_0x532fab):_0x435eec(null);},0x0);});}['addTokenChangeListener'](_0x236ed9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x236ed9):this['authProvider_']['get']()['then'](_0x465fbf=>_0x465fbf['addAuthTokenListener'](_0x236ed9));}['removeTokenChangeListener'](_0x2a4674){this['authProvider_']['get']()['then'](_0x39c891=>_0x39c891['removeAuthTokenListener'](_0x2a4674));}['notifyForInvalidToken'](){let _0x421a1e='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x421a1e+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x421a1e+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x421a1e+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x421a1e);}}class an{constructor(_0x12b509){this['accessToken']=_0x12b509;}['getToken'](_0x364f96){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2446cb){_0x2446cb(this['accessToken']);}['removeTokenChangeListener'](_0xa60c47){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x330e66,_0x2f6787,_0x2aca95,_0xe03975,_0x121f6e=!0x1,_0x411e18='',_0x5d58e0=!0x1,_0x1566d5=!0x1,_0x162368=null){this['secure']=_0x2f6787,this['namespace']=_0x2aca95,this['webSocketOnly']=_0xe03975,this['nodeAdmin']=_0x121f6e,this['persistenceKey']=_0x411e18,this['includeNamespaceInQueryParams']=_0x5d58e0,this['isUsingEmulator']=_0x1566d5,this['emulatorOptions']=_0x162368,this['_host']=_0x330e66['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x330e66)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1f8da8){_0x1f8da8!==this['internalHost']&&(this['internalHost']=_0x1f8da8,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5b0268=this['toURLString']();return this['persistenceKey']&&(_0x5b0268+='<'+this['persistenceKey']+'>'),_0x5b0268;}['toURLString'](){const _0x3774a9=this['secure']?'https://':'http://',_0x5617d1=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3774a9+this['host']+'/'+_0x5617d1;}}function th(_0x5349ae){return _0x5349ae['host']!==_0x5349ae['internalHost']||_0x5349ae['isCustomHost']()||_0x5349ae['includeNamespaceInQueryParams'];}function vo(_0x4ce2a5,_0x30a9b7,_0x3c1c91){f(typeof _0x30a9b7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3c1c91=='object','typeof\x20params\x20must\x20==\x20object');let _0x5e40bb;if(_0x30a9b7===go)_0x5e40bb=(_0x4ce2a5['secure']?'wss://':'ws://')+_0x4ce2a5['internalHost']+'/.ws?';else{if(_0x30a9b7===mo)_0x5e40bb=(_0x4ce2a5['secure']?'https://':'http://')+_0x4ce2a5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x30a9b7);}th(_0x4ce2a5)&&(_0x3c1c91['ns']=_0x4ce2a5['namespace']);const _0x568103=[];return x(_0x3c1c91,(_0x59d437,_0x1b4e07)=>{_0x568103['push'](_0x59d437+'='+_0x1b4e07);}),_0x5e40bb+_0x568103['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x52b9ad,_0x3fa2ae=0x1){Q(this['counters_'],_0x52b9ad)||(this['counters_'][_0x52b9ad]=0x0),this['counters_'][_0x52b9ad]+=_0x3fa2ae;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3990c3){const _0x3ca0b6=_0x3990c3['toString']();return oi[_0x3ca0b6]||(oi[_0x3ca0b6]=new nh()),oi[_0x3ca0b6];}function ih(_0x291622,_0x3bd22c){const _0x408f3c=_0x291622['toString']();return ai[_0x408f3c]||(ai[_0x408f3c]=_0x3bd22c()),ai[_0x408f3c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5166d5){this['onMessage_']=_0x5166d5,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4d12d1,_0x466a9c){this['closeAfterResponse']=_0x4d12d1,this['onClose']=_0x466a9c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4f02d8,_0x2c0a36){for(this['pendingResponses'][_0x4f02d8]=_0x2c0a36;this['pendingResponses'][this['currentResponseNum']];){const _0x2fe78b=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2c5f9a=0x0;_0x2c5f9a<_0x2fe78b['length'];++_0x2c5f9a)_0x2fe78b[_0x2c5f9a]&&ft(()=>{this['onMessage_'](_0x2fe78b[_0x2c5f9a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x322e1a,_0x3d372c,_0x5c32ca,_0x3908af,_0x210e8b,_0x4c7190,_0x24ab87){this['connId']=_0x322e1a,this['repoInfo']=_0x3d372c,this['applicationId']=_0x5c32ca,this['appCheckToken']=_0x3908af,this['authToken']=_0x210e8b,this['transportSessionId']=_0x4c7190,this['lastSessionId']=_0x24ab87,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x322e1a),this['stats_']=qi(_0x3d372c),this['urlFn']=_0x51ebf0=>(this['appCheckToken']&&(_0x51ebf0[wi]=this['appCheckToken']),vo(_0x3d372c,mo,_0x51ebf0));}['open'](_0x24a885,_0x18e3ed){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x18e3ed,this['myPacketOrderer']=new sh(_0x24a885),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x1ddacb)=>{const [_0x5a8f78,_0x3d4a70,_0x404571,_0x4f1068,_0x59b2c7]=_0x1ddacb;if(this['incrementIncomingBytes_'](_0x1ddacb),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5a8f78===qs)this['id']=_0x3d4a70,this['password']=_0x404571;else{if(_0x5a8f78===rh)_0x3d4a70?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3d4a70,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5a8f78);}}},(..._0x46d45a)=>{const [_0x39c307,_0x5f598f]=_0x46d45a;this['incrementIncomingBytes_'](_0x46d45a),this['myPacketOrderer']['handleResponse'](_0x39c307,_0x5f598f);},()=>{this['onClosed_']();},this['urlFn']);const _0x2eb301={};_0x2eb301[qs]='t',_0x2eb301[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2eb301[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2eb301[co]=Gi,this['transportSessionId']&&(_0x2eb301[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x2eb301[po]=this['lastSessionId']),this['applicationId']&&(_0x2eb301[_o]=this['applicationId']),this['appCheckToken']&&(_0x2eb301[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2eb301[ho]=uo);const _0x68e8c=this['urlFn'](_0x2eb301);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x68e8c),this['scriptTagHolder']['addTag'](_0x68e8c,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x457dc6){const _0x5e5355=O(_0x457dc6);this['bytesSent']+=_0x5e5355['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5e5355['length']);const _0x26c164=$r(_0x5e5355),_0x21c8d2=oo(_0x26c164,fh);for(let _0x146a8f=0x0;_0x146a8f<_0x21c8d2['length'];_0x146a8f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x21c8d2['length'],_0x21c8d2[_0x146a8f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x377b61,_0x201d1a){this['myDisconnFrame']=document['createElement']('iframe');const _0xf40366={};_0xf40366[dh]='t',_0xf40366[Eo]=_0x377b61,_0xf40366[Io]=_0x201d1a,this['myDisconnFrame']['src']=this['urlFn'](_0xf40366),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1bd786){const _0x4eea9f=O(_0x1bd786)['length'];this['bytesReceived']+=_0x4eea9f,this['stats_']['incrementCounter']('bytes_received',_0x4eea9f);}}class zi{constructor(_0xbdd1da,_0x5f5b03,_0x12a5bc,_0x40c1f0){this['onDisconnect']=_0x12a5bc,this['urlFn']=_0x40c1f0,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xbdd1da,window[ah+this['uniqueCallbackIdentifier']]=_0x5f5b03,this['myIFrame']=zi['createIFrame_']();let _0x23f5b3='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x23f5b3='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x10d1a0='<html><body>'+_0x23f5b3+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x10d1a0),this['myIFrame']['doc']['close']();}catch(_0x1f4ace){L('frame\x20writing\x20exception'),_0x1f4ace['stack']&&L(_0x1f4ace['stack']),L(_0x1f4ace);}}}static['createIFrame_'](){const _0x2d8460=document['createElement']('iframe');if(_0x2d8460['style']['display']='none',document['body']){document['body']['appendChild'](_0x2d8460);try{_0x2d8460['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x56f496=document['domain'];_0x2d8460['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x56f496+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2d8460['contentDocument']?_0x2d8460['doc']=_0x2d8460['contentDocument']:_0x2d8460['contentWindow']?_0x2d8460['doc']=_0x2d8460['contentWindow']['document']:_0x2d8460['document']&&(_0x2d8460['doc']=_0x2d8460['document']),_0x2d8460;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0xe449d6=this['onDisconnect'];_0xe449d6&&(this['onDisconnect']=null,_0xe449d6());}['startLongPoll'](_0x498226,_0x266113){for(this['myID']=_0x498226,this['myPW']=_0x266113,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1ad33d={};_0x1ad33d[Eo]=this['myID'],_0x1ad33d[Io]=this['myPW'],_0x1ad33d[wo]=this['currentSerial'];let _0x985c80=this['urlFn'](_0x1ad33d),_0x453354='',_0x66ae12=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x453354['length']<=Co;){const _0x5a4081=this['pendingSegs']['shift']();_0x453354=_0x453354+'&'+lh+_0x66ae12+'='+_0x5a4081['seg']+'&'+hh+_0x66ae12+'='+_0x5a4081['ts']+'&'+uh+_0x66ae12+'='+_0x5a4081['d'],_0x66ae12++;}return _0x985c80=_0x985c80+_0x453354,this['addLongPollTag_'](_0x985c80,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x19cf93,_0x5f0b26,_0x3b2871){this['pendingSegs']['push']({'seg':_0x19cf93,'ts':_0x5f0b26,'d':_0x3b2871}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1ae072,_0x45479a){this['outstandingRequests']['add'](_0x45479a);const _0x4475ca=()=>{this['outstandingRequests']['delete'](_0x45479a),this['newRequest_']();},_0x47f8ad=setTimeout(_0x4475ca,Math['floor'](ph)),_0x24fc00=()=>{clearTimeout(_0x47f8ad),_0x4475ca();};this['addTag'](_0x1ae072,_0x24fc00);}['addTag'](_0x4689c1,_0x230b77){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x282806=this['myIFrame']['doc']['createElement']('script');_0x282806['type']='text/javascript',_0x282806['async']=!0x0,_0x282806['src']=_0x4689c1,_0x282806['onload']=_0x282806['onreadystatechange']=function(){const _0x33fea2=_0x282806['readyState'];(!_0x33fea2||_0x33fea2==='loaded'||_0x33fea2==='complete')&&(_0x282806['onload']=_0x282806['onreadystatechange']=null,_0x282806['parentNode']&&_0x282806['parentNode']['removeChild'](_0x282806),_0x230b77());},_0x282806['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4689c1),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x282806);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x3f932e,_0x32ce45,_0x1fc4d7,_0x39d4ea,_0x1ad58d,_0x491c5d,_0x7ae646){this['connId']=_0x3f932e,this['applicationId']=_0x1fc4d7,this['appCheckToken']=_0x39d4ea,this['authToken']=_0x1ad58d,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x32ce45),this['connURL']=q['connectionURL_'](_0x32ce45,_0x491c5d,_0x7ae646,_0x39d4ea,_0x1fc4d7),this['nodeAdmin']=_0x32ce45['nodeAdmin'];}static['connectionURL_'](_0x5bc7d6,_0x308c0c,_0x41a6fd,_0x1dbf99,_0xe3fb85){const _0x430e6d={};return _0x430e6d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x430e6d[ho]=uo),_0x308c0c&&(_0x430e6d[lo]=_0x308c0c),_0x41a6fd&&(_0x430e6d[po]=_0x41a6fd),_0x1dbf99&&(_0x430e6d[wi]=_0x1dbf99),_0xe3fb85&&(_0x430e6d[_o]=_0xe3fb85),vo(_0x5bc7d6,go,_0x430e6d);}['open'](_0x594e0b,_0x5265ff){this['onDisconnect']=_0x5265ff,this['onMessage']=_0x594e0b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x3056ec;_c(),this['mySock']=new gn(this['connURL'],[],_0x3056ec);}catch(_0x2cfef7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x39798a=_0x2cfef7['message']||_0x2cfef7['data'];_0x39798a&&this['log_'](_0x39798a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5db273=>{this['handleIncomingFrame'](_0x5db273);},this['mySock']['onerror']=_0x4942f6=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x105967=_0x4942f6['message']||_0x4942f6['data'];_0x105967&&this['log_'](_0x105967),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x245d6c=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x56b11d=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x527f4c=navigator['userAgent']['match'](_0x56b11d);_0x527f4c&&_0x527f4c['length']>0x1&&parseFloat(_0x527f4c[0x1])<4.4&&(_0x245d6c=!0x0);}return!_0x245d6c&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x36a0e7){if(this['frames']['push'](_0x36a0e7),this['frames']['length']===this['totalFrames']){const _0x415973=this['frames']['join']('');this['frames']=null;const _0xaf8e86=Nt(_0x415973);this['onMessage'](_0xaf8e86);}}['handleNewFrameCount_'](_0x34982a){this['totalFrames']=_0x34982a,this['frames']=[];}['extractFrameCount_'](_0x4f1657){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4f1657['length']<=0x6){const _0x31d48f=Number(_0x4f1657);if(!isNaN(_0x31d48f))return this['handleNewFrameCount_'](_0x31d48f),null;}return this['handleNewFrameCount_'](0x1),_0x4f1657;}['handleIncomingFrame'](_0x276b71){if(this['mySock']===null)return;const _0x178f4e=_0x276b71['data'];if(this['bytesReceived']+=_0x178f4e['length'],this['stats_']['incrementCounter']('bytes_received',_0x178f4e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x178f4e);else{const _0x599983=this['extractFrameCount_'](_0x178f4e);_0x599983!==null&&this['appendFrame_'](_0x599983);}}['send'](_0xcfec60){this['resetKeepAlive']();const _0x5a36ed=O(_0xcfec60);this['bytesSent']+=_0x5a36ed['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5a36ed['length']);const _0x548b66=oo(_0x5a36ed,gh);_0x548b66['length']>0x1&&this['sendString_'](String(_0x548b66['length']));for(let _0x444bb0=0x0;_0x444bb0<_0x548b66['length'];_0x444bb0++)this['sendString_'](_0x548b66[_0x444bb0]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x15f788){try{this['mySock']['send'](_0x15f788);}catch(_0x5e2f25){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5e2f25['message']||_0x5e2f25['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xa3418d){this['initTransports_'](_0xa3418d);}['initTransports_'](_0x5bc81a){const _0x1c6d8c=q&&q['isAvailable']();let _0x52ba43=_0x1c6d8c&&!q['previouslyFailed']();if(_0x5bc81a['webSocketOnly']&&(_0x1c6d8c||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x52ba43=!0x0),_0x52ba43)this['transports_']=[q];else{const _0x3be4d6=this['transports_']=[];for(const _0x45ce02 of Dt['ALL_TRANSPORTS'])_0x45ce02&&_0x45ce02['isAvailable']()&&_0x3be4d6['push'](_0x45ce02);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x25ffc7,_0x4d2ff4,_0x48f61e,_0x5dd95f,_0x87d4f7,_0x53f9e9,_0x306f04,_0x1cde8f,_0x1a17a2,_0x51dbaa){this['id']=_0x25ffc7,this['repoInfo_']=_0x4d2ff4,this['applicationId_']=_0x48f61e,this['appCheckToken_']=_0x5dd95f,this['authToken_']=_0x87d4f7,this['onMessage_']=_0x53f9e9,this['onReady_']=_0x306f04,this['onDisconnect_']=_0x1cde8f,this['onKill_']=_0x1a17a2,this['lastSessionId']=_0x51dbaa,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x4d2ff4),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x124e6a=this['transportManager_']['initialTransport']();this['conn_']=new _0x124e6a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x124e6a['responsesRequiredToBeHealthy']||0x0;const _0x1648b8=this['connReceiver_'](this['conn_']),_0x2ac97d=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1648b8,_0x2ac97d);},Math['floor'](0x0));const _0x2ec9a1=_0x124e6a['healthyTimeout']||0x0;_0x2ec9a1>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2ec9a1)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x36dedc){return _0x556108=>{_0x36dedc===this['conn_']?this['onConnectionLost_'](_0x556108):_0x36dedc===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x328b50){return _0x140c52=>{this['state_']!==0x2&&(_0x328b50===this['rx_']?this['onPrimaryMessageReceived_'](_0x140c52):_0x328b50===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x140c52):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1d1bad){const _0xb06e9b={'t':'d','d':_0x1d1bad};this['sendData_'](_0xb06e9b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2a92d7){if(ci in _0x2a92d7){const _0x41ae8e=_0x2a92d7[ci];_0x41ae8e===Ys?this['upgradeIfSecondaryHealthy_']():_0x41ae8e===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x41ae8e===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x40f89e){const _0x3f6448=vt('t',_0x40f89e),_0x45ef60=vt('d',_0x40f89e);if(_0x3f6448==='c')this['onSecondaryControl_'](_0x45ef60);else{if(_0x3f6448==='d')this['pendingDataMessages']['push'](_0x45ef60);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3f6448);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1184d9){const _0x1646c3=vt('t',_0x1184d9),_0x2daebc=vt('d',_0x1184d9);_0x1646c3==='c'?this['onControl_'](_0x2daebc):_0x1646c3==='d'&&this['onDataMessage_'](_0x2daebc);}['onDataMessage_'](_0x467623){this['onPrimaryResponse_'](),this['onMessage_'](_0x467623);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x25e2dc){const _0x10829d=vt(ci,_0x25e2dc);if(zs in _0x25e2dc){const _0x1581a0=_0x25e2dc[zs];if(_0x10829d===Th){const _0x37d422={..._0x1581a0};this['repoInfo_']['isUsingEmulator']&&(_0x37d422['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x37d422);}else{if(_0x10829d===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1475fe=0x0;_0x1475fe<this['pendingDataMessages']['length'];++_0x1475fe)this['onDataMessage_'](this['pendingDataMessages'][_0x1475fe]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x10829d===wh?this['onConnectionShutdown_'](_0x1581a0):_0x10829d===js?this['onReset_'](_0x1581a0):_0x10829d===Ch?Ii('Server\x20Error:\x20'+_0x1581a0):_0x10829d===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x10829d);}}}['onHandshake_'](_0x4e8246){const _0x2a0459=_0x4e8246['ts'],_0x3ddede=_0x4e8246['v'],_0x136c0e=_0x4e8246['h'];this['sessionId']=_0x4e8246['s'],this['repoInfo_']['host']=_0x136c0e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2a0459),Gi!==_0x3ddede&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x18c362=this['transportManager_']['upgradeTransport']();_0x18c362&&this['startUpgrade_'](_0x18c362);}['startUpgrade_'](_0x23d940){this['secondaryConn_']=new _0x23d940(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x23d940['responsesRequiredToBeHealthy']||0x0;const _0x1aa2c3=this['connReceiver_'](this['secondaryConn_']),_0x292225=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1aa2c3,_0x292225),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x69bcc5){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x69bcc5),this['repoInfo_']['host']=_0x69bcc5,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x38af77,_0x179a4a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x38af77,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x179a4a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x63e59e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x63e59e||this['rx_']===_0x63e59e)&&this['close']();}['onConnectionLost_'](_0x3b2f6c){this['conn_']=null,!_0x3b2f6c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x54fb69){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x54fb69),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2bfe44){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2bfe44);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x413af5,_0x261b5a,_0x1209c5,_0x2443ba){}['merge'](_0x34d676,_0x387738,_0x479da8,_0x5b7777){}['refreshAuthToken'](_0xbd5872){}['refreshAppCheckToken'](_0x243781){}['onDisconnectPut'](_0x25d746,_0x348793,_0x2c075f){}['onDisconnectMerge'](_0x3e9866,_0x44eadf,_0x16eb15){}['onDisconnectCancel'](_0x2f12ec,_0x297d8c){}['reportStats'](_0x18aa4a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x59321a){this['allowedEvents_']=_0x59321a,this['listeners_']={},f(Array['isArray'](_0x59321a)&&_0x59321a['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x37974c,..._0x5d34cd){if(Array['isArray'](this['listeners_'][_0x37974c])){const _0x2e4390=[...this['listeners_'][_0x37974c]];for(let _0x8a2d8a=0x0;_0x8a2d8a<_0x2e4390['length'];_0x8a2d8a++)_0x2e4390[_0x8a2d8a]['callback']['apply'](_0x2e4390[_0x8a2d8a]['context'],_0x5d34cd);}}['on'](_0x8c783e,_0x4b37bd,_0x44705e){this['validateEventType_'](_0x8c783e),this['listeners_'][_0x8c783e]=this['listeners_'][_0x8c783e]||[],this['listeners_'][_0x8c783e]['push']({'callback':_0x4b37bd,'context':_0x44705e});const _0x5ae7cb=this['getInitialEvent'](_0x8c783e);_0x5ae7cb&&_0x4b37bd['apply'](_0x44705e,_0x5ae7cb);}['off'](_0x5f27f9,_0x3a972d,_0x332631){this['validateEventType_'](_0x5f27f9);const _0x42e170=this['listeners_'][_0x5f27f9]||[];for(let _0x49b3d6=0x0;_0x49b3d6<_0x42e170['length'];_0x49b3d6++)if(_0x42e170[_0x49b3d6]['callback']===_0x3a972d&&(!_0x332631||_0x332631===_0x42e170[_0x49b3d6]['context'])){_0x42e170['splice'](_0x49b3d6,0x1);return;}}['validateEventType_'](_0x4cfa09){f(this['allowedEvents_']['find'](_0x520771=>_0x520771===_0x4cfa09),'Unknown\x20event:\x20'+_0x4cfa09);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x265e90){return f(_0x265e90==='online','Unknown\x20event\x20type:\x20'+_0x265e90),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x12922b,_0x3d805b){if(_0x3d805b===void 0x0){this['pieces_']=_0x12922b['split']('/');let _0x478c79=0x0;for(let _0x19b040=0x0;_0x19b040<this['pieces_']['length'];_0x19b040++)this['pieces_'][_0x19b040]['length']>0x0&&(this['pieces_'][_0x478c79]=this['pieces_'][_0x19b040],_0x478c79++);this['pieces_']['length']=_0x478c79,this['pieceNum_']=0x0;}else this['pieces_']=_0x12922b,this['pieceNum_']=_0x3d805b;}['toString'](){let _0x2906a0='';for(let _0x47b11d=this['pieceNum_'];_0x47b11d<this['pieces_']['length'];_0x47b11d++)this['pieces_'][_0x47b11d]!==''&&(_0x2906a0+='/'+this['pieces_'][_0x47b11d]);return _0x2906a0||'/';}}function w(){return new C('');}function y(_0x2da374){return _0x2da374['pieceNum_']>=_0x2da374['pieces_']['length']?null:_0x2da374['pieces_'][_0x2da374['pieceNum_']];}function Ce(_0x3d33c6){return _0x3d33c6['pieces_']['length']-_0x3d33c6['pieceNum_'];}function S(_0xd71781){let _0x59ae6d=_0xd71781['pieceNum_'];return _0x59ae6d<_0xd71781['pieces_']['length']&&_0x59ae6d++,new C(_0xd71781['pieces_'],_0x59ae6d);}function ji(_0x1982e5){return _0x1982e5['pieceNum_']<_0x1982e5['pieces_']['length']?_0x1982e5['pieces_'][_0x1982e5['pieces_']['length']-0x1]:null;}function bh(_0x4a4da6){let _0x1bbeb4='';for(let _0x5574a6=_0x4a4da6['pieceNum_'];_0x5574a6<_0x4a4da6['pieces_']['length'];_0x5574a6++)_0x4a4da6['pieces_'][_0x5574a6]!==''&&(_0x1bbeb4+='/'+encodeURIComponent(String(_0x4a4da6['pieces_'][_0x5574a6])));return _0x1bbeb4||'/';}function Mt(_0x1125f5,_0x142826=0x0){return _0x1125f5['pieces_']['slice'](_0x1125f5['pieceNum_']+_0x142826);}function Ro(_0x47d57f){if(_0x47d57f['pieceNum_']>=_0x47d57f['pieces_']['length'])return null;const _0xd73175=[];for(let _0x108529=_0x47d57f['pieceNum_'];_0x108529<_0x47d57f['pieces_']['length']-0x1;_0x108529++)_0xd73175['push'](_0x47d57f['pieces_'][_0x108529]);return new C(_0xd73175,0x0);}function k(_0x577b39,_0x5e74e1){const _0x20d48a=[];for(let _0x39f600=_0x577b39['pieceNum_'];_0x39f600<_0x577b39['pieces_']['length'];_0x39f600++)_0x20d48a['push'](_0x577b39['pieces_'][_0x39f600]);if(_0x5e74e1 instanceof C){for(let _0x2a39f1=_0x5e74e1['pieceNum_'];_0x2a39f1<_0x5e74e1['pieces_']['length'];_0x2a39f1++)_0x20d48a['push'](_0x5e74e1['pieces_'][_0x2a39f1]);}else{const _0x3956b4=_0x5e74e1['split']('/');for(let _0x5f85f0=0x0;_0x5f85f0<_0x3956b4['length'];_0x5f85f0++)_0x3956b4[_0x5f85f0]['length']>0x0&&_0x20d48a['push'](_0x3956b4[_0x5f85f0]);}return new C(_0x20d48a,0x0);}function v(_0xf609a5){return _0xf609a5['pieceNum_']>=_0xf609a5['pieces_']['length'];}function F(_0x19db11,_0x5b9144){const _0xdc233d=y(_0x19db11),_0x4b63e7=y(_0x5b9144);if(_0xdc233d===null)return _0x5b9144;if(_0xdc233d===_0x4b63e7)return F(S(_0x19db11),S(_0x5b9144));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5b9144+')\x20is\x20not\x20within\x20outerPath\x20('+_0x19db11+')');}function Rh(_0x300682,_0x2e0286){const _0x5f3e73=Mt(_0x300682,0x0),_0x252cd9=Mt(_0x2e0286,0x0);for(let _0x149b4f=0x0;_0x149b4f<_0x5f3e73['length']&&_0x149b4f<_0x252cd9['length'];_0x149b4f++){const _0x43bd2c=qe(_0x5f3e73[_0x149b4f],_0x252cd9[_0x149b4f]);if(_0x43bd2c!==0x0)return _0x43bd2c;}return _0x5f3e73['length']===_0x252cd9['length']?0x0:_0x5f3e73['length']<_0x252cd9['length']?-0x1:0x1;}function Ki(_0x4a87e6,_0x435c1b){if(Ce(_0x4a87e6)!==Ce(_0x435c1b))return!0x1;for(let _0x4bb5bf=_0x4a87e6['pieceNum_'],_0x51e78c=_0x435c1b['pieceNum_'];_0x4bb5bf<=_0x4a87e6['pieces_']['length'];_0x4bb5bf++,_0x51e78c++)if(_0x4a87e6['pieces_'][_0x4bb5bf]!==_0x435c1b['pieces_'][_0x51e78c])return!0x1;return!0x0;}function G(_0x7d205d,_0x55c232){let _0x3f3d41=_0x7d205d['pieceNum_'],_0x2fa547=_0x55c232['pieceNum_'];if(Ce(_0x7d205d)>Ce(_0x55c232))return!0x1;for(;_0x3f3d41<_0x7d205d['pieces_']['length'];){if(_0x7d205d['pieces_'][_0x3f3d41]!==_0x55c232['pieces_'][_0x2fa547])return!0x1;++_0x3f3d41,++_0x2fa547;}return!0x0;}class Ah{constructor(_0x38ae48,_0xe8e43c){this['errorPrefix_']=_0xe8e43c,this['parts_']=Mt(_0x38ae48,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4a92ad=0x0;_0x4a92ad<this['parts_']['length'];_0x4a92ad++)this['byteLength_']+=Ln(this['parts_'][_0x4a92ad]);Ao(this);}}function kh(_0x32ae72,_0x4fd544){_0x32ae72['parts_']['length']>0x0&&(_0x32ae72['byteLength_']+=0x1),_0x32ae72['parts_']['push'](_0x4fd544),_0x32ae72['byteLength_']+=Ln(_0x4fd544),Ao(_0x32ae72);}function Ph(_0x3f4c1f){const _0x7cbc76=_0x3f4c1f['parts_']['pop']();_0x3f4c1f['byteLength_']-=Ln(_0x7cbc76),_0x3f4c1f['parts_']['length']>0x0&&(_0x3f4c1f['byteLength_']-=0x1);}function Ao(_0x1079ff){if(_0x1079ff['byteLength_']>Zs)throw new Error(_0x1079ff['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1079ff['byteLength_']+').');if(_0x1079ff['parts_']['length']>Xs)throw new Error(_0x1079ff['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x1079ff));}function Oe(_0x123140){return _0x123140['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x123140['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x57e1ee,_0x4a6416;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4a6416='visibilitychange',_0x57e1ee='hidden'):typeof document['mozHidden']<'u'?(_0x4a6416='mozvisibilitychange',_0x57e1ee='mozHidden'):typeof document['msHidden']<'u'?(_0x4a6416='msvisibilitychange',_0x57e1ee='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4a6416='webkitvisibilitychange',_0x57e1ee='webkitHidden')),this['visible_']=!0x0,_0x4a6416&&document['addEventListener'](_0x4a6416,()=>{const _0x71ed53=!document[_0x57e1ee];_0x71ed53!==this['visible_']&&(this['visible_']=_0x71ed53,this['trigger']('visible',_0x71ed53));},!0x1);}['getInitialEvent'](_0x4c8bc1){return f(_0x4c8bc1==='visible','Unknown\x20event\x20type:\x20'+_0x4c8bc1),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x5816d3,_0x28f82b,_0x16fc64,_0x393af6,_0x2d2bc7,_0x39579d,_0x25a2fe,_0x5c9763){if(super(),this['repoInfo_']=_0x5816d3,this['applicationId_']=_0x28f82b,this['onDataUpdate_']=_0x16fc64,this['onConnectStatus_']=_0x393af6,this['onServerInfoUpdate_']=_0x2d2bc7,this['authTokenProvider_']=_0x39579d,this['appCheckTokenProvider_']=_0x25a2fe,this['authOverride_']=_0x5c9763,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5c9763)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5816d3['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xd69343,_0x561923,_0x486115){const _0xfe9d9d=++this['requestNumber_'],_0x375b5a={'r':_0xfe9d9d,'a':_0xd69343,'b':_0x561923};this['log_'](O(_0x375b5a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x375b5a),_0x486115&&(this['requestCBHash_'][_0xfe9d9d]=_0x486115);}['get'](_0x4bcea4){this['initConnection_']();const _0x359c8a=new H(),_0x499ce9={'action':'g','request':{'p':_0x4bcea4['_path']['toString'](),'q':_0x4bcea4['_queryObject']},'onComplete':_0x1549c3=>{const _0x2165f1=_0x1549c3['d'];_0x1549c3['s']==='ok'?_0x359c8a['resolve'](_0x2165f1):_0x359c8a['reject'](_0x2165f1);}};this['outstandingGets_']['push'](_0x499ce9),this['outstandingGetCount_']++;const _0x453c47=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x453c47),_0x359c8a['promise'];}['listen'](_0x13cd0a,_0x8012aa,_0x2fe17b,_0x11e217){this['initConnection_']();const _0x672e08=_0x13cd0a['_queryIdentifier'],_0xf02ccd=_0x13cd0a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xf02ccd+'\x20'+_0x672e08),this['listens']['has'](_0xf02ccd)||this['listens']['set'](_0xf02ccd,new Map()),f(_0x13cd0a['_queryParams']['isDefault']()||!_0x13cd0a['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0xf02ccd)['has'](_0x672e08),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x3a9532={'onComplete':_0x11e217,'hashFn':_0x8012aa,'query':_0x13cd0a,'tag':_0x2fe17b};this['listens']['get'](_0xf02ccd)['set'](_0x672e08,_0x3a9532),this['connected_']&&this['sendListen_'](_0x3a9532);}['sendGet_'](_0x2ee624){const _0x4f7ed4=this['outstandingGets_'][_0x2ee624];this['sendRequest']('g',_0x4f7ed4['request'],_0x344fed=>{delete this['outstandingGets_'][_0x2ee624],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x4f7ed4['onComplete']&&_0x4f7ed4['onComplete'](_0x344fed);});}['sendListen_'](_0x3515c1){const _0x250f9c=_0x3515c1['query'],_0xb3f0a2=_0x250f9c['_path']['toString'](),_0x4065b3=_0x250f9c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0xb3f0a2+'\x20for\x20'+_0x4065b3);const _0xd72018={'p':_0xb3f0a2},_0x5c9be9='q';_0x3515c1['tag']&&(_0xd72018['q']=_0x250f9c['_queryObject'],_0xd72018['t']=_0x3515c1['tag']),_0xd72018['h']=_0x3515c1['hashFn'](),this['sendRequest'](_0x5c9be9,_0xd72018,_0x184cee=>{const _0x26da3c=_0x184cee['d'],_0x793971=_0x184cee['s'];se['warnOnListenWarnings_'](_0x26da3c,_0x250f9c),(this['listens']['get'](_0xb3f0a2)&&this['listens']['get'](_0xb3f0a2)['get'](_0x4065b3))===_0x3515c1&&(this['log_']('listen\x20response',_0x184cee),_0x793971!=='ok'&&this['removeListen_'](_0xb3f0a2,_0x4065b3),_0x3515c1['onComplete']&&_0x3515c1['onComplete'](_0x793971,_0x26da3c));});}static['warnOnListenWarnings_'](_0x19a9d4,_0x383711){if(_0x19a9d4&&typeof _0x19a9d4=='object'&&Q(_0x19a9d4,'w')){const _0x22afb6=Le(_0x19a9d4,'w');if(Array['isArray'](_0x22afb6)&&~_0x22afb6['indexOf']('no_index')){const _0x40cc07='\x22.indexOn\x22:\x20\x22'+_0x383711['_queryParams']['getIndex']()['toString']()+'\x22',_0x205bfd=_0x383711['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x40cc07+'\x20at\x20'+_0x205bfd+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x37fbea){this['authToken_']=_0x37fbea,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x37fbea);}['reduceReconnectDelayIfAdminCredential_'](_0x45c6cd){(_0x45c6cd&&_0x45c6cd['length']===0x28||wc(_0x45c6cd))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x287b79){this['appCheckToken_']=_0x287b79,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5339ab=this['authToken_'],_0x2043ca=Ic(_0x5339ab)?'auth':'gauth',_0x1543b5={'cred':_0x5339ab};this['authOverride_']===null?_0x1543b5['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1543b5['authvar']=this['authOverride_']),this['sendRequest'](_0x2043ca,_0x1543b5,_0x134bf8=>{const _0x2328e1=_0x134bf8['s'],_0x10fbea=_0x134bf8['d']||'error';this['authToken_']===_0x5339ab&&(_0x2328e1==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2328e1,_0x10fbea));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2a7c2b=>{const _0x112bce=_0x2a7c2b['s'],_0x10617a=_0x2a7c2b['d']||'error';_0x112bce==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x112bce,_0x10617a);});}['unlisten'](_0xa5e5be,_0x2d0210){const _0x55f083=_0xa5e5be['_path']['toString'](),_0x381baf=_0xa5e5be['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x55f083+'\x20'+_0x381baf),f(_0xa5e5be['_queryParams']['isDefault']()||!_0xa5e5be['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x55f083,_0x381baf)&&this['connected_']&&this['sendUnlisten_'](_0x55f083,_0x381baf,_0xa5e5be['_queryObject'],_0x2d0210);}['sendUnlisten_'](_0x74092d,_0x146a5e,_0x20fbeb,_0x1ad89d){this['log_']('Unlisten\x20on\x20'+_0x74092d+'\x20for\x20'+_0x146a5e);const _0x3853b1={'p':_0x74092d},_0x1c0ed3='n';_0x1ad89d&&(_0x3853b1['q']=_0x20fbeb,_0x3853b1['t']=_0x1ad89d),this['sendRequest'](_0x1c0ed3,_0x3853b1);}['onDisconnectPut'](_0x24be0f,_0x1a818a,_0x19fc0b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x24be0f,_0x1a818a,_0x19fc0b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x24be0f,'action':'o','data':_0x1a818a,'onComplete':_0x19fc0b});}['onDisconnectMerge'](_0x17c95b,_0x3e664b,_0x768f95){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x17c95b,_0x3e664b,_0x768f95):this['onDisconnectRequestQueue_']['push']({'pathString':_0x17c95b,'action':'om','data':_0x3e664b,'onComplete':_0x768f95});}['onDisconnectCancel'](_0x499972,_0x399240){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x499972,null,_0x399240):this['onDisconnectRequestQueue_']['push']({'pathString':_0x499972,'action':'oc','data':null,'onComplete':_0x399240});}['sendOnDisconnect_'](_0x175a26,_0x467910,_0x1d7172,_0x1488c8){const _0x46b5b3={'p':_0x467910,'d':_0x1d7172};this['log_']('onDisconnect\x20'+_0x175a26,_0x46b5b3),this['sendRequest'](_0x175a26,_0x46b5b3,_0x5bcf66=>{_0x1488c8&&setTimeout(()=>{_0x1488c8(_0x5bcf66['s'],_0x5bcf66['d']);},Math['floor'](0x0));});}['put'](_0x56bf6c,_0x1e66b2,_0xdfe170,_0x124485){this['putInternal']('p',_0x56bf6c,_0x1e66b2,_0xdfe170,_0x124485);}['merge'](_0x2b11d1,_0x11dd94,_0x50a823,_0x5cb7df){this['putInternal']('m',_0x2b11d1,_0x11dd94,_0x50a823,_0x5cb7df);}['putInternal'](_0x35ce4c,_0x1d2f31,_0x1172b8,_0x2e0db6,_0x730690){this['initConnection_']();const _0x595a0c={'p':_0x1d2f31,'d':_0x1172b8};_0x730690!==void 0x0&&(_0x595a0c['h']=_0x730690),this['outstandingPuts_']['push']({'action':_0x35ce4c,'request':_0x595a0c,'onComplete':_0x2e0db6}),this['outstandingPutCount_']++;const _0x407121=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x407121):this['log_']('Buffering\x20put:\x20'+_0x1d2f31);}['sendPut_'](_0x539fe2){const _0x4c4039=this['outstandingPuts_'][_0x539fe2]['action'],_0x1e83d9=this['outstandingPuts_'][_0x539fe2]['request'],_0x182cf2=this['outstandingPuts_'][_0x539fe2]['onComplete'];this['outstandingPuts_'][_0x539fe2]['queued']=this['connected_'],this['sendRequest'](_0x4c4039,_0x1e83d9,_0x18055d=>{this['log_'](_0x4c4039+'\x20response',_0x18055d),delete this['outstandingPuts_'][_0x539fe2],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x182cf2&&_0x182cf2(_0x18055d['s'],_0x18055d['d']);});}['reportStats'](_0x3e5f9b){if(this['connected_']){const _0x1dd6a1={'c':_0x3e5f9b};this['log_']('reportStats',_0x1dd6a1),this['sendRequest']('s',_0x1dd6a1,_0x1f9cd5=>{if(_0x1f9cd5['s']!=='ok'){const _0x2c47bb=_0x1f9cd5['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2c47bb);}});}}['onDataMessage_'](_0x103da1){if('r'in _0x103da1){this['log_']('from\x20server:\x20'+O(_0x103da1));const _0x351db4=_0x103da1['r'],_0x343791=this['requestCBHash_'][_0x351db4];_0x343791&&(delete this['requestCBHash_'][_0x351db4],_0x343791(_0x103da1['b']));}else{if('error'in _0x103da1)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x103da1['error'];'a'in _0x103da1&&this['onDataPush_'](_0x103da1['a'],_0x103da1['b']);}}['onDataPush_'](_0x3409dd,_0x50178e){this['log_']('handleServerMessage',_0x3409dd,_0x50178e),_0x3409dd==='d'?this['onDataUpdate_'](_0x50178e['p'],_0x50178e['d'],!0x1,_0x50178e['t']):_0x3409dd==='m'?this['onDataUpdate_'](_0x50178e['p'],_0x50178e['d'],!0x0,_0x50178e['t']):_0x3409dd==='c'?this['onListenRevoked_'](_0x50178e['p'],_0x50178e['q']):_0x3409dd==='ac'?this['onAuthRevoked_'](_0x50178e['s'],_0x50178e['d']):_0x3409dd==='apc'?this['onAppCheckRevoked_'](_0x50178e['s'],_0x50178e['d']):_0x3409dd==='sd'?this['onSecurityDebugPacket_'](_0x50178e):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3409dd)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1dabae,_0x4ba957){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1dabae),this['lastSessionId']=_0x4ba957,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x35120f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x35120f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5a3a81){_0x5a3a81&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5a3a81;}['onOnline_'](_0x1519e3){_0x1519e3?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2b982d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xa053f1=Math['max'](0x0,this['reconnectDelay_']-_0x2b982d);_0xa053f1=Math['random']()*_0xa053f1,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xa053f1+'ms'),this['scheduleConnect_'](_0xa053f1),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x33829d=this['onDataMessage_']['bind'](this),_0x53e1c7=this['onReady_']['bind'](this),_0x483f12=this['onRealtimeDisconnect_']['bind'](this),_0x38507c=this['id']+':'+se['nextConnectionId_']++,_0x2e22f3=this['lastSessionId'];let _0xc03984=!0x1,_0xfd241c=null;const _0x20dd91=function(){_0xfd241c?_0xfd241c['close']():(_0xc03984=!0x0,_0x483f12());},_0x2df4a9=function(_0x1b14ee){f(_0xfd241c,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xfd241c['sendRequest'](_0x1b14ee);};this['realtime_']={'close':_0x20dd91,'sendRequest':_0x2df4a9};const _0x596199=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x29e50e,_0x5dbca5]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x596199),this['appCheckTokenProvider_']['getToken'](_0x596199)]);_0xc03984?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x29e50e&&_0x29e50e['accessToken'],this['appCheckToken_']=_0x5dbca5&&_0x5dbca5['token'],_0xfd241c=new Sh(_0x38507c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x33829d,_0x53e1c7,_0x483f12,_0x15f5b7=>{U(_0x15f5b7+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2e22f3));}catch(_0x554a40){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x554a40),_0xc03984||(this['repoInfo_']['nodeAdmin']&&U(_0x554a40),_0x20dd91());}}}['interrupt'](_0x58b456){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x58b456),this['interruptReasons_'][_0x58b456]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5dfa15){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5dfa15),delete this['interruptReasons_'][_0x5dfa15],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x52030d){const _0x64a734=_0x52030d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x64a734});}['cancelSentTransactions_'](){for(let _0x1aa04f=0x0;_0x1aa04f<this['outstandingPuts_']['length'];_0x1aa04f++){const _0x263cce=this['outstandingPuts_'][_0x1aa04f];_0x263cce&&'h'in _0x263cce['request']&&_0x263cce['queued']&&(_0x263cce['onComplete']&&_0x263cce['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1aa04f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x72dad0,_0x505c2d){let _0x1f0b5d;_0x505c2d?_0x1f0b5d=_0x505c2d['map'](_0x4d5ee9=>$i(_0x4d5ee9))['join']('$'):_0x1f0b5d='default';const _0x440cf4=this['removeListen_'](_0x72dad0,_0x1f0b5d);_0x440cf4&&_0x440cf4['onComplete']&&_0x440cf4['onComplete']('permission_denied');}['removeListen_'](_0x36d238,_0x464f75){const _0x368724=new C(_0x36d238)['toString']();let _0x49143e;if(this['listens']['has'](_0x368724)){const _0x5d0046=this['listens']['get'](_0x368724);_0x49143e=_0x5d0046['get'](_0x464f75),_0x5d0046['delete'](_0x464f75),_0x5d0046['size']===0x0&&this['listens']['delete'](_0x368724);}else _0x49143e=void 0x0;return _0x49143e;}['onAuthRevoked_'](_0x4bfa0c,_0x47a1af){L('Auth\x20token\x20revoked:\x20'+_0x4bfa0c+'/'+_0x47a1af),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4bfa0c==='invalid_token'||_0x4bfa0c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1fa15d,_0x319650){L('App\x20check\x20token\x20revoked:\x20'+_0x1fa15d+'/'+_0x319650),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1fa15d==='invalid_token'||_0x1fa15d==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x47ed1e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x47ed1e):'msg'in _0x47ed1e&&console['log']('FIREBASE:\x20'+_0x47ed1e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x111cf8 of this['listens']['values']())for(const _0x58b833 of _0x111cf8['values']())this['sendListen_'](_0x58b833);for(let _0x1119c3=0x0;_0x1119c3<this['outstandingPuts_']['length'];_0x1119c3++)this['outstandingPuts_'][_0x1119c3]&&this['sendPut_'](_0x1119c3);for(;this['onDisconnectRequestQueue_']['length'];){const _0x247913=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x247913['action'],_0x247913['pathString'],_0x247913['data'],_0x247913['onComplete']);}for(let _0x44c376=0x0;_0x44c376<this['outstandingGets_']['length'];_0x44c376++)this['outstandingGets_'][_0x44c376]&&this['sendGet_'](_0x44c376);}['sendConnectStats_'](){const _0x51d318={};let _0x4d3e27='js';_0x51d318['sdk.'+_0x4d3e27+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x51d318['framework.cordova']=0x1:Kr()&&(_0x51d318['framework.reactnative']=0x1),this['reportStats'](_0x51d318);}['shouldReconnect_'](){const _0xd2ca42=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0xd2ca42;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x22ddb9,_0x590900){this['name']=_0x22ddb9,this['node']=_0x590900;}static['Wrap'](_0x580abc,_0x334019){return new E(_0x580abc,_0x334019);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2d6cc0,_0x3d394b){const _0x5ae35c=new E(We,_0x2d6cc0),_0x3757e0=new E(We,_0x3d394b);return this['compare'](_0x5ae35c,_0x3757e0)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x21f899){sn=_0x21f899;}['compare'](_0x28f825,_0x36dc89){return qe(_0x28f825['name'],_0x36dc89['name']);}['isDefinedOn'](_0x497a9f){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x44bbec,_0x1bc21b){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x3d6cdb,_0x5b6506){return f(typeof _0x3d6cdb=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3d6cdb,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x16d348,_0x4cc5af,_0x2bb482,_0xc182b9,_0x3ce6e8=null){this['isReverse_']=_0xc182b9,this['resultGenerator_']=_0x3ce6e8,this['nodeStack_']=[];let _0x46fce8=0x1;for(;!_0x16d348['isEmpty']();)if(_0x16d348=_0x16d348,_0x46fce8=_0x4cc5af?_0x2bb482(_0x16d348['key'],_0x4cc5af):0x1,_0xc182b9&&(_0x46fce8*=-0x1),_0x46fce8<0x0)this['isReverse_']?_0x16d348=_0x16d348['left']:_0x16d348=_0x16d348['right'];else{if(_0x46fce8===0x0){this['nodeStack_']['push'](_0x16d348);break;}else this['nodeStack_']['push'](_0x16d348),this['isReverse_']?_0x16d348=_0x16d348['right']:_0x16d348=_0x16d348['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x27bc5e=this['nodeStack_']['pop'](),_0x1be465;if(this['resultGenerator_']?_0x1be465=this['resultGenerator_'](_0x27bc5e['key'],_0x27bc5e['value']):_0x1be465={'key':_0x27bc5e['key'],'value':_0x27bc5e['value']},this['isReverse_']){for(_0x27bc5e=_0x27bc5e['left'];!_0x27bc5e['isEmpty']();)this['nodeStack_']['push'](_0x27bc5e),_0x27bc5e=_0x27bc5e['right'];}else{for(_0x27bc5e=_0x27bc5e['right'];!_0x27bc5e['isEmpty']();)this['nodeStack_']['push'](_0x27bc5e),_0x27bc5e=_0x27bc5e['left'];}return _0x1be465;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x546e01=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x546e01['key'],_0x546e01['value']):{'key':_0x546e01['key'],'value':_0x546e01['value']};}}class M{constructor(_0x20178c,_0x2c5645,_0x4ab090,_0x176feb,_0x4f7c6f){this['key']=_0x20178c,this['value']=_0x2c5645,this['color']=_0x4ab090??M['RED'],this['left']=_0x176feb??B['EMPTY_NODE'],this['right']=_0x4f7c6f??B['EMPTY_NODE'];}['copy'](_0x14a731,_0xb82f41,_0x5af399,_0x2832d1,_0x585f49){return new M(_0x14a731??this['key'],_0xb82f41??this['value'],_0x5af399??this['color'],_0x2832d1??this['left'],_0x585f49??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4b151d){return this['left']['inorderTraversal'](_0x4b151d)||!!_0x4b151d(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4b151d);}['reverseTraversal'](_0x2fe365){return this['right']['reverseTraversal'](_0x2fe365)||_0x2fe365(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2fe365);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2a4de8,_0x3b55c4,_0x3502b4){let _0x5262ea=this;const _0x2248ed=_0x3502b4(_0x2a4de8,_0x5262ea['key']);return _0x2248ed<0x0?_0x5262ea=_0x5262ea['copy'](null,null,null,_0x5262ea['left']['insert'](_0x2a4de8,_0x3b55c4,_0x3502b4),null):_0x2248ed===0x0?_0x5262ea=_0x5262ea['copy'](null,_0x3b55c4,null,null,null):_0x5262ea=_0x5262ea['copy'](null,null,null,null,_0x5262ea['right']['insert'](_0x2a4de8,_0x3b55c4,_0x3502b4)),_0x5262ea['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3ca790=this;return!_0x3ca790['left']['isRed_']()&&!_0x3ca790['left']['left']['isRed_']()&&(_0x3ca790=_0x3ca790['moveRedLeft_']()),_0x3ca790=_0x3ca790['copy'](null,null,null,_0x3ca790['left']['removeMin_'](),null),_0x3ca790['fixUp_']();}['remove'](_0x41724f,_0x509f1a){let _0x51b426,_0x45f986;if(_0x51b426=this,_0x509f1a(_0x41724f,_0x51b426['key'])<0x0)!_0x51b426['left']['isEmpty']()&&!_0x51b426['left']['isRed_']()&&!_0x51b426['left']['left']['isRed_']()&&(_0x51b426=_0x51b426['moveRedLeft_']()),_0x51b426=_0x51b426['copy'](null,null,null,_0x51b426['left']['remove'](_0x41724f,_0x509f1a),null);else{if(_0x51b426['left']['isRed_']()&&(_0x51b426=_0x51b426['rotateRight_']()),!_0x51b426['right']['isEmpty']()&&!_0x51b426['right']['isRed_']()&&!_0x51b426['right']['left']['isRed_']()&&(_0x51b426=_0x51b426['moveRedRight_']()),_0x509f1a(_0x41724f,_0x51b426['key'])===0x0){if(_0x51b426['right']['isEmpty']())return B['EMPTY_NODE'];_0x45f986=_0x51b426['right']['min_'](),_0x51b426=_0x51b426['copy'](_0x45f986['key'],_0x45f986['value'],null,null,_0x51b426['right']['removeMin_']());}_0x51b426=_0x51b426['copy'](null,null,null,null,_0x51b426['right']['remove'](_0x41724f,_0x509f1a));}return _0x51b426['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x326c25=this;return _0x326c25['right']['isRed_']()&&!_0x326c25['left']['isRed_']()&&(_0x326c25=_0x326c25['rotateLeft_']()),_0x326c25['left']['isRed_']()&&_0x326c25['left']['left']['isRed_']()&&(_0x326c25=_0x326c25['rotateRight_']()),_0x326c25['left']['isRed_']()&&_0x326c25['right']['isRed_']()&&(_0x326c25=_0x326c25['colorFlip_']()),_0x326c25;}['moveRedLeft_'](){let _0x580f38=this['colorFlip_']();return _0x580f38['right']['left']['isRed_']()&&(_0x580f38=_0x580f38['copy'](null,null,null,null,_0x580f38['right']['rotateRight_']()),_0x580f38=_0x580f38['rotateLeft_'](),_0x580f38=_0x580f38['colorFlip_']()),_0x580f38;}['moveRedRight_'](){let _0xc1b454=this['colorFlip_']();return _0xc1b454['left']['left']['isRed_']()&&(_0xc1b454=_0xc1b454['rotateRight_'](),_0xc1b454=_0xc1b454['colorFlip_']()),_0xc1b454;}['rotateLeft_'](){const _0x2917fb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2917fb,null);}['rotateRight_'](){const _0x50db11=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x50db11);}['colorFlip_'](){const _0x47bb78=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xf74cda=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x47bb78,_0xf74cda);}['checkMaxDepth_'](){const _0x423ba1=this['check_']();return Math['pow'](0x2,_0x423ba1)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1213f3=this['left']['check_']();if(_0x1213f3!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1213f3+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4e2bc5,_0x330ef8,_0x804f0c,_0x2b8c2f,_0x397a5e){return this;}['insert'](_0x502909,_0x5b3ef0,_0x5c7753){return new M(_0x502909,_0x5b3ef0,null);}['remove'](_0x822450,_0x412dfa){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5e5938){return!0x1;}['reverseTraversal'](_0x4c6f70){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x135801,_0x1ad572=B['EMPTY_NODE']){this['comparator_']=_0x135801,this['root_']=_0x1ad572;}['insert'](_0x1f8984,_0x34dac1){return new B(this['comparator_'],this['root_']['insert'](_0x1f8984,_0x34dac1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5a6005){return new B(this['comparator_'],this['root_']['remove'](_0x5a6005,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3840f1){let _0x1722e6,_0x4109d2=this['root_'];for(;!_0x4109d2['isEmpty']();){if(_0x1722e6=this['comparator_'](_0x3840f1,_0x4109d2['key']),_0x1722e6===0x0)return _0x4109d2['value'];_0x1722e6<0x0?_0x4109d2=_0x4109d2['left']:_0x1722e6>0x0&&(_0x4109d2=_0x4109d2['right']);}return null;}['getPredecessorKey'](_0x43da87){let _0x3d25d4,_0x4277ac=this['root_'],_0x158815=null;for(;!_0x4277ac['isEmpty']();)if(_0x3d25d4=this['comparator_'](_0x43da87,_0x4277ac['key']),_0x3d25d4===0x0){if(_0x4277ac['left']['isEmpty']())return _0x158815?_0x158815['key']:null;for(_0x4277ac=_0x4277ac['left'];!_0x4277ac['right']['isEmpty']();)_0x4277ac=_0x4277ac['right'];return _0x4277ac['key'];}else _0x3d25d4<0x0?_0x4277ac=_0x4277ac['left']:_0x3d25d4>0x0&&(_0x158815=_0x4277ac,_0x4277ac=_0x4277ac['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4ab3e6){return this['root_']['inorderTraversal'](_0x4ab3e6);}['reverseTraversal'](_0x5911d5){return this['root_']['reverseTraversal'](_0x5911d5);}['getIterator'](_0x2eb625){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2eb625);}['getIteratorFrom'](_0x26ce9d,_0x1efaf8){return new rn(this['root_'],_0x26ce9d,this['comparator_'],!0x1,_0x1efaf8);}['getReverseIteratorFrom'](_0x20642f,_0x3fb7ae){return new rn(this['root_'],_0x20642f,this['comparator_'],!0x0,_0x3fb7ae);}['getReverseIterator'](_0x5cbb31){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5cbb31);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x580b82,_0x4e6b28){return qe(_0x580b82['name'],_0x4e6b28['name']);}function Qi(_0x29c583,_0x2833f9){return qe(_0x29c583,_0x2833f9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4c8e6d){Ci=_0x4c8e6d;}const Po=function(_0x5dca44){return typeof _0x5dca44=='number'?'number:'+ao(_0x5dca44):'string:'+_0x5dca44;},No=function(_0x401b9c){if(_0x401b9c['isLeafNode']()){const _0x7488a=_0x401b9c['val']();f(typeof _0x7488a=='string'||typeof _0x7488a=='number'||typeof _0x7488a=='object'&&Q(_0x7488a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x401b9c===Ci||_0x401b9c['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x401b9c===Ci||_0x401b9c['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x6bbab6){nr=_0x6bbab6;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x5c7d24,_0x2e47e7=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x5c7d24,this['priorityNode_']=_0x2e47e7,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x457499){return new D(this['value_'],_0x457499);}['getImmediateChild'](_0x435065){return _0x435065==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5a771f){return v(_0x5a771f)?this:y(_0x5a771f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3ebe87,_0x16634a){return null;}['updateImmediateChild'](_0x2f5a29,_0x34ed62){return _0x2f5a29==='.priority'?this['updatePriority'](_0x34ed62):_0x34ed62['isEmpty']()&&_0x2f5a29!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2f5a29,_0x34ed62)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4464e9,_0x1455e6){const _0xbcc8c=y(_0x4464e9);return _0xbcc8c===null?_0x1455e6:_0x1455e6['isEmpty']()&&_0xbcc8c!=='.priority'?this:(f(_0xbcc8c!=='.priority'||Ce(_0x4464e9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xbcc8c,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x4464e9),_0x1455e6)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3716a1,_0x4c8c20){return!0x1;}['val'](_0x2dc99e){return _0x2dc99e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xdbe94f='';this['priorityNode_']['isEmpty']()||(_0xdbe94f+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3d2239=typeof this['value_'];_0xdbe94f+=_0x3d2239+':',_0x3d2239==='number'?_0xdbe94f+=ao(this['value_']):_0xdbe94f+=this['value_'],this['lazyHash_']=ro(_0xdbe94f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x16f70d){return _0x16f70d===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x16f70d instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x16f70d['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x16f70d));}['compareToLeafNode_'](_0xb4807f){const _0x449983=typeof _0xb4807f['value_'],_0x539745=typeof this['value_'],_0x168b79=D['VALUE_TYPE_ORDER']['indexOf'](_0x449983),_0x4a22a9=D['VALUE_TYPE_ORDER']['indexOf'](_0x539745);return f(_0x168b79>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x449983),f(_0x4a22a9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x539745),_0x168b79===_0x4a22a9?_0x539745==='object'?0x0:this['value_']<_0xb4807f['value_']?-0x1:this['value_']===_0xb4807f['value_']?0x0:0x1:_0x4a22a9-_0x168b79;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4b1a44){if(_0x4b1a44===this)return!0x0;if(_0x4b1a44['isLeafNode']()){const _0x552e00=_0x4b1a44;return this['value_']===_0x552e00['value_']&&this['priorityNode_']['equals'](_0x552e00['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2e6ad7){Oo=_0x2e6ad7;}function Wh(_0xa22380){Do=_0xa22380;}class Bh extends Fn{['compare'](_0x57b99f,_0x4a3048){const _0x2b8781=_0x57b99f['node']['getPriority'](),_0x769033=_0x4a3048['node']['getPriority'](),_0x58a9a9=_0x2b8781['compareTo'](_0x769033);return _0x58a9a9===0x0?qe(_0x57b99f['name'],_0x4a3048['name']):_0x58a9a9;}['isDefinedOn'](_0x19ee02){return!_0x19ee02['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x390d7d,_0x4252bc){return!_0x390d7d['getPriority']()['equals'](_0x4252bc['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5ae34d,_0x1c722b){const _0x23624d=Oo(_0x5ae34d);return new E(_0x1c722b,new D('[PRIORITY-POST]',_0x23624d));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x31b945){const _0x3e42d6=_0x1515c0=>parseInt(Math['log'](_0x1515c0)/Vh,0xa),_0x5abf92=_0x2c4d9c=>parseInt(Array(_0x2c4d9c+0x1)['join']('1'),0x2);this['count']=_0x3e42d6(_0x31b945+0x1),this['current_']=this['count']-0x1;const _0x4156cc=_0x5abf92(this['count']);this['bits_']=_0x31b945+0x1&_0x4156cc;}['nextBitIsOne'](){const _0x3a932b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3a932b;}}const yn=function(_0x279c06,_0x34456a,_0x3df590,_0x5e6327){_0x279c06['sort'](_0x34456a);const _0x587f5e=function(_0x59ea45,_0x3bb517){const _0x2e1788=_0x3bb517-_0x59ea45;let _0x5c9ab3,_0x2ae10c;if(_0x2e1788===0x0)return null;if(_0x2e1788===0x1)return _0x5c9ab3=_0x279c06[_0x59ea45],_0x2ae10c=_0x3df590?_0x3df590(_0x5c9ab3):_0x5c9ab3,new M(_0x2ae10c,_0x5c9ab3['node'],M['BLACK'],null,null);{const _0x14631c=parseInt(_0x2e1788/0x2,0xa)+_0x59ea45,_0x231197=_0x587f5e(_0x59ea45,_0x14631c),_0x3a19b4=_0x587f5e(_0x14631c+0x1,_0x3bb517);return _0x5c9ab3=_0x279c06[_0x14631c],_0x2ae10c=_0x3df590?_0x3df590(_0x5c9ab3):_0x5c9ab3,new M(_0x2ae10c,_0x5c9ab3['node'],M['BLACK'],_0x231197,_0x3a19b4);}},_0x498691=function(_0x39e801){let _0x2a9dc6=null,_0x9f511f=null,_0x7342e5=_0x279c06['length'];const _0x483adf=function(_0x1d67bd,_0x10c846){const _0x446470=_0x7342e5-_0x1d67bd,_0x239a0b=_0x7342e5;_0x7342e5-=_0x1d67bd;const _0x2dbec4=_0x587f5e(_0x446470+0x1,_0x239a0b),_0x509991=_0x279c06[_0x446470],_0xe709f8=_0x3df590?_0x3df590(_0x509991):_0x509991;_0x4fb669(new M(_0xe709f8,_0x509991['node'],_0x10c846,null,_0x2dbec4));},_0x4fb669=function(_0x28b29e){_0x2a9dc6?(_0x2a9dc6['left']=_0x28b29e,_0x2a9dc6=_0x28b29e):(_0x9f511f=_0x28b29e,_0x2a9dc6=_0x28b29e);};for(let _0x1dbab0=0x0;_0x1dbab0<_0x39e801['count'];++_0x1dbab0){const _0x2944ef=_0x39e801['nextBitIsOne'](),_0x43e3d8=Math['pow'](0x2,_0x39e801['count']-(_0x1dbab0+0x1));_0x2944ef?_0x483adf(_0x43e3d8,M['BLACK']):(_0x483adf(_0x43e3d8,M['BLACK']),_0x483adf(_0x43e3d8,M['RED']));}return _0x9f511f;},_0x3bb3a8=new Hh(_0x279c06['length']),_0x207e6a=_0x498691(_0x3bb3a8);return new B(_0x5e6327||_0x34456a,_0x207e6a);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x5d123a,_0xd9176a){this['indexes_']=_0x5d123a,this['indexSet_']=_0xd9176a;}['get'](_0x9c5ab8){const _0x3c3bf6=Le(this['indexes_'],_0x9c5ab8);if(!_0x3c3bf6)throw new Error('No\x20index\x20defined\x20for\x20'+_0x9c5ab8);return _0x3c3bf6 instanceof B?_0x3c3bf6:null;}['hasIndex'](_0x26ba96){return Q(this['indexSet_'],_0x26ba96['toString']());}['addIndex'](_0x16f9e6,_0x43253b){f(_0x16f9e6!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x59cfa7=[];let _0x1ec006=!0x1;const _0x9a8ee1=_0x43253b['getIterator'](E['Wrap']);let _0x1623ac=_0x9a8ee1['getNext']();for(;_0x1623ac;)_0x1ec006=_0x1ec006||_0x16f9e6['isDefinedOn'](_0x1623ac['node']),_0x59cfa7['push'](_0x1623ac),_0x1623ac=_0x9a8ee1['getNext']();let _0x5b60f5;_0x1ec006?_0x5b60f5=yn(_0x59cfa7,_0x16f9e6['getCompare']()):_0x5b60f5=Qe;const _0x51f123=_0x16f9e6['toString'](),_0x2213ae={...this['indexSet_']};_0x2213ae[_0x51f123]=_0x16f9e6;const _0x35d6ab={...this['indexes_']};return _0x35d6ab[_0x51f123]=_0x5b60f5,new te(_0x35d6ab,_0x2213ae);}['addToIndexes'](_0x10ea8f,_0x47341f){const _0x3343e6=_n(this['indexes_'],(_0x43a2fb,_0x23e19c)=>{const _0x58a5d0=Le(this['indexSet_'],_0x23e19c);if(f(_0x58a5d0,'Missing\x20index\x20implementation\x20for\x20'+_0x23e19c),_0x43a2fb===Qe){if(_0x58a5d0['isDefinedOn'](_0x10ea8f['node'])){const _0x48f96c=[],_0x4fa3dd=_0x47341f['getIterator'](E['Wrap']);let _0x7e6bc8=_0x4fa3dd['getNext']();for(;_0x7e6bc8;)_0x7e6bc8['name']!==_0x10ea8f['name']&&_0x48f96c['push'](_0x7e6bc8),_0x7e6bc8=_0x4fa3dd['getNext']();return _0x48f96c['push'](_0x10ea8f),yn(_0x48f96c,_0x58a5d0['getCompare']());}else return Qe;}else{const _0x444f9d=_0x47341f['get'](_0x10ea8f['name']);let _0x53dcfa=_0x43a2fb;return _0x444f9d&&(_0x53dcfa=_0x53dcfa['remove'](new E(_0x10ea8f['name'],_0x444f9d))),_0x53dcfa['insert'](_0x10ea8f,_0x10ea8f['node']);}});return new te(_0x3343e6,this['indexSet_']);}['removeFromIndexes'](_0x52086d,_0x34c2cd){const _0x495cc5=_n(this['indexes_'],_0x32cc43=>{if(_0x32cc43===Qe)return _0x32cc43;{const _0xbb14d6=_0x34c2cd['get'](_0x52086d['name']);return _0xbb14d6?_0x32cc43['remove'](new E(_0x52086d['name'],_0xbb14d6)):_0x32cc43;}});return new te(_0x495cc5,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0xd27740,_0x494f64,_0x1eed48){this['children_']=_0xd27740,this['priorityNode_']=_0x494f64,this['indexMap_']=_0x1eed48,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x36d1b1){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x36d1b1,this['indexMap_']);}['getImmediateChild'](_0x596973){if(_0x596973==='.priority')return this['getPriority']();{const _0x2e5259=this['children_']['get'](_0x596973);return _0x2e5259===null?It:_0x2e5259;}}['getChild'](_0x1f8705){const _0x4af700=y(_0x1f8705);return _0x4af700===null?this:this['getImmediateChild'](_0x4af700)['getChild'](S(_0x1f8705));}['hasChild'](_0x5d09bc){return this['children_']['get'](_0x5d09bc)!==null;}['updateImmediateChild'](_0x42955d,_0x27f771){if(f(_0x27f771,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x42955d==='.priority')return this['updatePriority'](_0x27f771);{const _0x1edb58=new E(_0x42955d,_0x27f771);let _0x27f21f,_0xdc4b79;_0x27f771['isEmpty']()?(_0x27f21f=this['children_']['remove'](_0x42955d),_0xdc4b79=this['indexMap_']['removeFromIndexes'](_0x1edb58,this['children_'])):(_0x27f21f=this['children_']['insert'](_0x42955d,_0x27f771),_0xdc4b79=this['indexMap_']['addToIndexes'](_0x1edb58,this['children_']));const _0x501f24=_0x27f21f['isEmpty']()?It:this['priorityNode_'];return new g(_0x27f21f,_0x501f24,_0xdc4b79);}}['updateChild'](_0x1642b5,_0x3fef05){const _0x48074f=y(_0x1642b5);if(_0x48074f===null)return _0x3fef05;{f(y(_0x1642b5)!=='.priority'||Ce(_0x1642b5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x51f879=this['getImmediateChild'](_0x48074f)['updateChild'](S(_0x1642b5),_0x3fef05);return this['updateImmediateChild'](_0x48074f,_0x51f879);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x38041b){if(this['isEmpty']())return null;const _0x1edb8a={};let _0x1939cf=0x0,_0x4f288c=0x0,_0x49f0b3=!0x0;if(this['forEachChild'](R,(_0x11004a,_0x218adb)=>{_0x1edb8a[_0x11004a]=_0x218adb['val'](_0x38041b),_0x1939cf++,_0x49f0b3&&g['INTEGER_REGEXP_']['test'](_0x11004a)?_0x4f288c=Math['max'](_0x4f288c,Number(_0x11004a)):_0x49f0b3=!0x1;}),!_0x38041b&&_0x49f0b3&&_0x4f288c<0x2*_0x1939cf){const _0x161ef2=[];for(const _0x6be1a9 in _0x1edb8a)_0x161ef2[_0x6be1a9]=_0x1edb8a[_0x6be1a9];return _0x161ef2;}else return _0x38041b&&!this['getPriority']()['isEmpty']()&&(_0x1edb8a['.priority']=this['getPriority']()['val']()),_0x1edb8a;}['hash'](){if(this['lazyHash_']===null){let _0x549791='';this['getPriority']()['isEmpty']()||(_0x549791+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x270187,_0x50a91b)=>{const _0x1c2baa=_0x50a91b['hash']();_0x1c2baa!==''&&(_0x549791+=':'+_0x270187+':'+_0x1c2baa);}),this['lazyHash_']=_0x549791===''?'':ro(_0x549791);}return this['lazyHash_'];}['getPredecessorChildName'](_0x363221,_0x39d2ea,_0x2aef82){const _0xb6b7d6=this['resolveIndex_'](_0x2aef82);if(_0xb6b7d6){const _0x51f336=_0xb6b7d6['getPredecessorKey'](new E(_0x363221,_0x39d2ea));return _0x51f336?_0x51f336['name']:null;}else return this['children_']['getPredecessorKey'](_0x363221);}['getFirstChildName'](_0x2ba052){const _0x5cd264=this['resolveIndex_'](_0x2ba052);if(_0x5cd264){const _0x3f88f6=_0x5cd264['minKey']();return _0x3f88f6&&_0x3f88f6['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x55619b){const _0x2e775a=this['getFirstChildName'](_0x55619b);return _0x2e775a?new E(_0x2e775a,this['children_']['get'](_0x2e775a)):null;}['getLastChildName'](_0x9658e){const _0x3e0c46=this['resolveIndex_'](_0x9658e);if(_0x3e0c46){const _0x50486a=_0x3e0c46['maxKey']();return _0x50486a&&_0x50486a['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x38b6f8){const _0x1592f3=this['getLastChildName'](_0x38b6f8);return _0x1592f3?new E(_0x1592f3,this['children_']['get'](_0x1592f3)):null;}['forEachChild'](_0x4f3154,_0x197134){const _0x357b66=this['resolveIndex_'](_0x4f3154);return _0x357b66?_0x357b66['inorderTraversal'](_0x209d8d=>_0x197134(_0x209d8d['name'],_0x209d8d['node'])):this['children_']['inorderTraversal'](_0x197134);}['getIterator'](_0x476a95){return this['getIteratorFrom'](_0x476a95['minPost'](),_0x476a95);}['getIteratorFrom'](_0x4923e3,_0xbe16f5){const _0x1caddf=this['resolveIndex_'](_0xbe16f5);if(_0x1caddf)return _0x1caddf['getIteratorFrom'](_0x4923e3,_0x1c7249=>_0x1c7249);{const _0x45a244=this['children_']['getIteratorFrom'](_0x4923e3['name'],E['Wrap']);let _0x38e277=_0x45a244['peek']();for(;_0x38e277!=null&&_0xbe16f5['compare'](_0x38e277,_0x4923e3)<0x0;)_0x45a244['getNext'](),_0x38e277=_0x45a244['peek']();return _0x45a244;}}['getReverseIterator'](_0x266aa7){return this['getReverseIteratorFrom'](_0x266aa7['maxPost'](),_0x266aa7);}['getReverseIteratorFrom'](_0x31aa46,_0x38cbdc){const _0x3eb7a6=this['resolveIndex_'](_0x38cbdc);if(_0x3eb7a6)return _0x3eb7a6['getReverseIteratorFrom'](_0x31aa46,_0x164a39=>_0x164a39);{const _0x4f391f=this['children_']['getReverseIteratorFrom'](_0x31aa46['name'],E['Wrap']);let _0x59f181=_0x4f391f['peek']();for(;_0x59f181!=null&&_0x38cbdc['compare'](_0x59f181,_0x31aa46)>0x0;)_0x4f391f['getNext'](),_0x59f181=_0x4f391f['peek']();return _0x4f391f;}}['compareTo'](_0xe10eae){return this['isEmpty']()?_0xe10eae['isEmpty']()?0x0:-0x1:_0xe10eae['isLeafNode']()||_0xe10eae['isEmpty']()?0x1:_0xe10eae===Kt?-0x1:0x0;}['withIndex'](_0x194732){if(_0x194732===ve||this['indexMap_']['hasIndex'](_0x194732))return this;{const _0x3d104c=this['indexMap_']['addIndex'](_0x194732,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3d104c);}}['isIndexed'](_0x26bca8){return _0x26bca8===ve||this['indexMap_']['hasIndex'](_0x26bca8);}['equals'](_0x843cef){if(_0x843cef===this)return!0x0;if(_0x843cef['isLeafNode']())return!0x1;{const _0x4250a7=_0x843cef;if(this['getPriority']()['equals'](_0x4250a7['getPriority']())){if(this['children_']['count']()===_0x4250a7['children_']['count']()){const _0x5f3014=this['getIterator'](R),_0x5d794c=_0x4250a7['getIterator'](R);let _0x10aeb1=_0x5f3014['getNext'](),_0x310109=_0x5d794c['getNext']();for(;_0x10aeb1&&_0x310109;){if(_0x10aeb1['name']!==_0x310109['name']||!_0x10aeb1['node']['equals'](_0x310109['node']))return!0x1;_0x10aeb1=_0x5f3014['getNext'](),_0x310109=_0x5d794c['getNext']();}return _0x10aeb1===null&&_0x310109===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1ef150){return _0x1ef150===ve?null:this['indexMap_']['get'](_0x1ef150['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x464d0c){return _0x464d0c===this?0x0:0x1;}['equals'](_0x1a9820){return _0x1a9820===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1df020){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x29c2b5,_0x281de8=null){if(_0x29c2b5===null)return g['EMPTY_NODE'];if(typeof _0x29c2b5=='object'&&'.priority'in _0x29c2b5&&(_0x281de8=_0x29c2b5['.priority']),f(_0x281de8===null||typeof _0x281de8=='string'||typeof _0x281de8=='number'||typeof _0x281de8=='object'&&'.sv'in _0x281de8,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x281de8),typeof _0x29c2b5=='object'&&'.value'in _0x29c2b5&&_0x29c2b5['.value']!==null&&(_0x29c2b5=_0x29c2b5['.value']),typeof _0x29c2b5!='object'||'.sv'in _0x29c2b5){const _0x415829=_0x29c2b5;return new D(_0x415829,A(_0x281de8));}if(!(_0x29c2b5 instanceof Array)&&Gh){const _0xb905ae=[];let _0x4e6ec8=!0x1;if(x(_0x29c2b5,(_0x126050,_0x35f010)=>{if(_0x126050['substring'](0x0,0x1)!=='.'){const _0x4ae666=A(_0x35f010);_0x4ae666['isEmpty']()||(_0x4e6ec8=_0x4e6ec8||!_0x4ae666['getPriority']()['isEmpty'](),_0xb905ae['push'](new E(_0x126050,_0x4ae666)));}}),_0xb905ae['length']===0x0)return g['EMPTY_NODE'];const _0x29f422=yn(_0xb905ae,xh,_0x41d393=>_0x41d393['name'],Qi);if(_0x4e6ec8){const _0x511409=yn(_0xb905ae,R['getCompare']());return new g(_0x29f422,A(_0x281de8),new te({'.priority':_0x511409},{'.priority':R}));}else return new g(_0x29f422,A(_0x281de8),te['Default']);}else{let _0x37a2e3=g['EMPTY_NODE'];return x(_0x29c2b5,(_0x168ed0,_0x193121)=>{if(Q(_0x29c2b5,_0x168ed0)&&_0x168ed0['substring'](0x0,0x1)!=='.'){const _0x271d82=A(_0x193121);(_0x271d82['isLeafNode']()||!_0x271d82['isEmpty']())&&(_0x37a2e3=_0x37a2e3['updateImmediateChild'](_0x168ed0,_0x271d82));}}),_0x37a2e3['updatePriority'](A(_0x281de8));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x48e38a){super(),this['indexPath_']=_0x48e38a,f(!v(_0x48e38a)&&y(_0x48e38a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5c1758){return _0x5c1758['getChild'](this['indexPath_']);}['isDefinedOn'](_0x5a78ed){return!_0x5a78ed['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x6d7f60,_0x43491c){const _0x264f8b=this['extractChild'](_0x6d7f60['node']),_0x3de27b=this['extractChild'](_0x43491c['node']),_0x296d74=_0x264f8b['compareTo'](_0x3de27b);return _0x296d74===0x0?qe(_0x6d7f60['name'],_0x43491c['name']):_0x296d74;}['makePost'](_0x34954a,_0x2859b8){const _0x788eb7=A(_0x34954a),_0x3217db=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x788eb7);return new E(_0x2859b8,_0x3217db);}['maxPost'](){const _0x251e6d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x251e6d);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x569a75,_0x108e72){const _0x3fcc72=_0x569a75['node']['compareTo'](_0x108e72['node']);return _0x3fcc72===0x0?qe(_0x569a75['name'],_0x108e72['name']):_0x3fcc72;}['isDefinedOn'](_0x56fa33){return!0x0;}['indexedValueChanged'](_0x2c642e,_0x43f9e5){return!_0x2c642e['equals'](_0x43f9e5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x23f4e8,_0x4e715f){const _0x17c258=A(_0x23f4e8);return new E(_0x4e715f,_0x17c258);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x59e069){return{'type':'value','snapshotNode':_0x59e069};}function rt(_0x252497,_0x7ec3c5){return{'type':'child_added','snapshotNode':_0x7ec3c5,'childName':_0x252497};}function Lt(_0x69c72e,_0x36dcab){return{'type':'child_removed','snapshotNode':_0x36dcab,'childName':_0x69c72e};}function xt(_0x829b6f,_0x34f9d1,_0x2c48c4){return{'type':'child_changed','snapshotNode':_0x34f9d1,'childName':_0x829b6f,'oldSnap':_0x2c48c4};}function zh(_0x475c45,_0x20a88f){return{'type':'child_moved','snapshotNode':_0x20a88f,'childName':_0x475c45};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1bc055){this['index_']=_0x1bc055;}['updateChild'](_0x4d80f3,_0x366be1,_0x1f9741,_0x3b2626,_0x57c964,_0x2f7a96){f(_0x4d80f3['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x58b5d6=_0x4d80f3['getImmediateChild'](_0x366be1);return _0x58b5d6['getChild'](_0x3b2626)['equals'](_0x1f9741['getChild'](_0x3b2626))&&_0x58b5d6['isEmpty']()===_0x1f9741['isEmpty']()||(_0x2f7a96!=null&&(_0x1f9741['isEmpty']()?_0x4d80f3['hasChild'](_0x366be1)?_0x2f7a96['trackChildChange'](Lt(_0x366be1,_0x58b5d6)):f(_0x4d80f3['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x58b5d6['isEmpty']()?_0x2f7a96['trackChildChange'](rt(_0x366be1,_0x1f9741)):_0x2f7a96['trackChildChange'](xt(_0x366be1,_0x1f9741,_0x58b5d6))),_0x4d80f3['isLeafNode']()&&_0x1f9741['isEmpty']())?_0x4d80f3:_0x4d80f3['updateImmediateChild'](_0x366be1,_0x1f9741)['withIndex'](this['index_']);}['updateFullNode'](_0x5a1a1,_0x51b8ad,_0x1e9127){return _0x1e9127!=null&&(_0x5a1a1['isLeafNode']()||_0x5a1a1['forEachChild'](R,(_0x55214c,_0x1cc9fc)=>{_0x51b8ad['hasChild'](_0x55214c)||_0x1e9127['trackChildChange'](Lt(_0x55214c,_0x1cc9fc));}),_0x51b8ad['isLeafNode']()||_0x51b8ad['forEachChild'](R,(_0x103994,_0x5ea26b)=>{if(_0x5a1a1['hasChild'](_0x103994)){const _0x4f4418=_0x5a1a1['getImmediateChild'](_0x103994);_0x4f4418['equals'](_0x5ea26b)||_0x1e9127['trackChildChange'](xt(_0x103994,_0x5ea26b,_0x4f4418));}else _0x1e9127['trackChildChange'](rt(_0x103994,_0x5ea26b));})),_0x51b8ad['withIndex'](this['index_']);}['updatePriority'](_0x3d86e3,_0x112ae9){return _0x3d86e3['isEmpty']()?g['EMPTY_NODE']:_0x3d86e3['updatePriority'](_0x112ae9);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x1b0ee1){this['indexedFilter_']=new Xi(_0x1b0ee1['getIndex']()),this['index_']=_0x1b0ee1['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x1b0ee1),this['endPost_']=Ft['getEndPost_'](_0x1b0ee1),this['startIsInclusive_']=!_0x1b0ee1['startAfterSet_'],this['endIsInclusive_']=!_0x1b0ee1['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x324729){const _0x278d8a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x324729)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x324729)<0x0,_0x200d35=this['endIsInclusive_']?this['index_']['compare'](_0x324729,this['getEndPost']())<=0x0:this['index_']['compare'](_0x324729,this['getEndPost']())<0x0;return _0x278d8a&&_0x200d35;}['updateChild'](_0x1eef49,_0xba82ee,_0x56b81a,_0x166d1a,_0x58b5f8,_0x2fbfc8){return this['matches'](new E(_0xba82ee,_0x56b81a))||(_0x56b81a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1eef49,_0xba82ee,_0x56b81a,_0x166d1a,_0x58b5f8,_0x2fbfc8);}['updateFullNode'](_0x1e0115,_0x353bf7,_0x1a45bc){_0x353bf7['isLeafNode']()&&(_0x353bf7=g['EMPTY_NODE']);let _0x3f867e=_0x353bf7['withIndex'](this['index_']);_0x3f867e=_0x3f867e['updatePriority'](g['EMPTY_NODE']);const _0x3f193a=this;return _0x353bf7['forEachChild'](R,(_0x31d67f,_0x313d90)=>{_0x3f193a['matches'](new E(_0x31d67f,_0x313d90))||(_0x3f867e=_0x3f867e['updateImmediateChild'](_0x31d67f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1e0115,_0x3f867e,_0x1a45bc);}['updatePriority'](_0x20dca1,_0x35a851){return _0x20dca1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x57a94e){if(_0x57a94e['hasStart']()){const _0x383d53=_0x57a94e['getIndexStartName']();return _0x57a94e['getIndex']()['makePost'](_0x57a94e['getIndexStartValue'](),_0x383d53);}else return _0x57a94e['getIndex']()['minPost']();}static['getEndPost_'](_0xc104e8){if(_0xc104e8['hasEnd']()){const _0x5bec24=_0xc104e8['getIndexEndName']();return _0xc104e8['getIndex']()['makePost'](_0xc104e8['getIndexEndValue'](),_0x5bec24);}else return _0xc104e8['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x25556d){this['withinDirectionalStart']=_0xee5303=>this['reverse_']?this['withinEndPost'](_0xee5303):this['withinStartPost'](_0xee5303),this['withinDirectionalEnd']=_0x20f982=>this['reverse_']?this['withinStartPost'](_0x20f982):this['withinEndPost'](_0x20f982),this['withinStartPost']=_0x2dcf51=>{const _0x4b375b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2dcf51);return this['startIsInclusive_']?_0x4b375b<=0x0:_0x4b375b<0x0;},this['withinEndPost']=_0xf7e188=>{const _0x255b03=this['index_']['compare'](_0xf7e188,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x255b03<=0x0:_0x255b03<0x0;},this['rangedFilter_']=new Ft(_0x25556d),this['index_']=_0x25556d['getIndex'](),this['limit_']=_0x25556d['getLimit'](),this['reverse_']=!_0x25556d['isViewFromLeft'](),this['startIsInclusive_']=!_0x25556d['startAfterSet_'],this['endIsInclusive_']=!_0x25556d['endBeforeSet_'];}['updateChild'](_0x105d9d,_0x58e8fd,_0x21e675,_0x506587,_0xdf1dc8,_0x2670c9){return this['rangedFilter_']['matches'](new E(_0x58e8fd,_0x21e675))||(_0x21e675=g['EMPTY_NODE']),_0x105d9d['getImmediateChild'](_0x58e8fd)['equals'](_0x21e675)?_0x105d9d:_0x105d9d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x105d9d,_0x58e8fd,_0x21e675,_0x506587,_0xdf1dc8,_0x2670c9):this['fullLimitUpdateChild_'](_0x105d9d,_0x58e8fd,_0x21e675,_0xdf1dc8,_0x2670c9);}['updateFullNode'](_0x26d7b6,_0x10486a,_0x11b2a1){let _0x428526;if(_0x10486a['isLeafNode']()||_0x10486a['isEmpty']())_0x428526=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x10486a['numChildren']()&&_0x10486a['isIndexed'](this['index_'])){_0x428526=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x17ca2a;this['reverse_']?_0x17ca2a=_0x10486a['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x17ca2a=_0x10486a['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x24b76b=0x0;for(;_0x17ca2a['hasNext']()&&_0x24b76b<this['limit_'];){const _0x303d84=_0x17ca2a['getNext']();if(this['withinDirectionalStart'](_0x303d84)){if(this['withinDirectionalEnd'](_0x303d84))_0x428526=_0x428526['updateImmediateChild'](_0x303d84['name'],_0x303d84['node']),_0x24b76b++;else break;}else continue;}}else{_0x428526=_0x10486a['withIndex'](this['index_']),_0x428526=_0x428526['updatePriority'](g['EMPTY_NODE']);let _0x599fbe;this['reverse_']?_0x599fbe=_0x428526['getReverseIterator'](this['index_']):_0x599fbe=_0x428526['getIterator'](this['index_']);let _0x457539=0x0;for(;_0x599fbe['hasNext']();){const _0x32af36=_0x599fbe['getNext']();_0x457539<this['limit_']&&this['withinDirectionalStart'](_0x32af36)&&this['withinDirectionalEnd'](_0x32af36)?_0x457539++:_0x428526=_0x428526['updateImmediateChild'](_0x32af36['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x26d7b6,_0x428526,_0x11b2a1);}['updatePriority'](_0x5e037d,_0x4252fb){return _0x5e037d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x28bf40,_0x499cce,_0x1b2e71,_0x3863f7,_0x30416e){let _0x380a6a;if(this['reverse_']){const _0x4417d8=this['index_']['getCompare']();_0x380a6a=(_0x19c9a3,_0xf18efd)=>_0x4417d8(_0xf18efd,_0x19c9a3);}else _0x380a6a=this['index_']['getCompare']();const _0x2ec979=_0x28bf40;f(_0x2ec979['numChildren']()===this['limit_'],'');const _0x3af566=new E(_0x499cce,_0x1b2e71),_0x2c95ed=this['reverse_']?_0x2ec979['getFirstChild'](this['index_']):_0x2ec979['getLastChild'](this['index_']),_0x27ad5=this['rangedFilter_']['matches'](_0x3af566);if(_0x2ec979['hasChild'](_0x499cce)){const _0x52e587=_0x2ec979['getImmediateChild'](_0x499cce);let _0x22b721=_0x3863f7['getChildAfterChild'](this['index_'],_0x2c95ed,this['reverse_']);for(;_0x22b721!=null&&(_0x22b721['name']===_0x499cce||_0x2ec979['hasChild'](_0x22b721['name']));)_0x22b721=_0x3863f7['getChildAfterChild'](this['index_'],_0x22b721,this['reverse_']);const _0x41c6da=_0x22b721==null?0x1:_0x380a6a(_0x22b721,_0x3af566);if(_0x27ad5&&!_0x1b2e71['isEmpty']()&&_0x41c6da>=0x0)return _0x30416e!=null&&_0x30416e['trackChildChange'](xt(_0x499cce,_0x1b2e71,_0x52e587)),_0x2ec979['updateImmediateChild'](_0x499cce,_0x1b2e71);{_0x30416e!=null&&_0x30416e['trackChildChange'](Lt(_0x499cce,_0x52e587));const _0x4aefc4=_0x2ec979['updateImmediateChild'](_0x499cce,g['EMPTY_NODE']);return _0x22b721!=null&&this['rangedFilter_']['matches'](_0x22b721)?(_0x30416e!=null&&_0x30416e['trackChildChange'](rt(_0x22b721['name'],_0x22b721['node'])),_0x4aefc4['updateImmediateChild'](_0x22b721['name'],_0x22b721['node'])):_0x4aefc4;}}else return _0x1b2e71['isEmpty']()?_0x28bf40:_0x27ad5&&_0x380a6a(_0x2c95ed,_0x3af566)>=0x0?(_0x30416e!=null&&(_0x30416e['trackChildChange'](Lt(_0x2c95ed['name'],_0x2c95ed['node'])),_0x30416e['trackChildChange'](rt(_0x499cce,_0x1b2e71))),_0x2ec979['updateImmediateChild'](_0x499cce,_0x1b2e71)['updateImmediateChild'](_0x2c95ed['name'],g['EMPTY_NODE'])):_0x28bf40;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x28cc51=new Zi();return _0x28cc51['limitSet_']=this['limitSet_'],_0x28cc51['limit_']=this['limit_'],_0x28cc51['startSet_']=this['startSet_'],_0x28cc51['startAfterSet_']=this['startAfterSet_'],_0x28cc51['indexStartValue_']=this['indexStartValue_'],_0x28cc51['startNameSet_']=this['startNameSet_'],_0x28cc51['indexStartName_']=this['indexStartName_'],_0x28cc51['endSet_']=this['endSet_'],_0x28cc51['endBeforeSet_']=this['endBeforeSet_'],_0x28cc51['indexEndValue_']=this['indexEndValue_'],_0x28cc51['endNameSet_']=this['endNameSet_'],_0x28cc51['indexEndName_']=this['indexEndName_'],_0x28cc51['index_']=this['index_'],_0x28cc51['viewFrom_']=this['viewFrom_'],_0x28cc51;}}function Kh(_0x3ef73e){return _0x3ef73e['loadsAllData']()?new Xi(_0x3ef73e['getIndex']()):_0x3ef73e['hasLimit']()?new jh(_0x3ef73e):new Ft(_0x3ef73e);}function Yh(_0x285826,_0x10a505){const _0x393d96=_0x285826['copy']();return _0x393d96['limitSet_']=!0x0,_0x393d96['limit_']=_0x10a505,_0x393d96['viewFrom_']='l',_0x393d96;}function Qh(_0x5ba57d,_0x51a158,_0x278614){const _0x18c61=_0x5ba57d['copy']();return _0x18c61['startSet_']=!0x0,_0x51a158===void 0x0&&(_0x51a158=null),_0x18c61['indexStartValue_']=_0x51a158,_0x278614!=null?(_0x18c61['startNameSet_']=!0x0,_0x18c61['indexStartName_']=_0x278614):(_0x18c61['startNameSet_']=!0x1,_0x18c61['indexStartName_']=''),_0x18c61;}function Jh(_0x19938e,_0x1e72bf,_0x59bd26){const _0x38a01d=_0x19938e['copy']();return _0x38a01d['endSet_']=!0x0,_0x1e72bf===void 0x0&&(_0x1e72bf=null),_0x38a01d['indexEndValue_']=_0x1e72bf,_0x59bd26!==void 0x0?(_0x38a01d['endNameSet_']=!0x0,_0x38a01d['indexEndName_']=_0x59bd26):(_0x38a01d['endNameSet_']=!0x1,_0x38a01d['indexEndName_']=''),_0x38a01d;}function xo(_0x249c29,_0x17b06c){const _0x15386a=_0x249c29['copy']();return _0x15386a['index_']=_0x17b06c,_0x15386a;}function ir(_0x91836){const _0x37915c={};if(_0x91836['isDefault']())return _0x37915c;let _0x42fb5c;if(_0x91836['index_']===R?_0x42fb5c='$priority':_0x91836['index_']===Mo?_0x42fb5c='$value':_0x91836['index_']===ve?_0x42fb5c='$key':(f(_0x91836['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x42fb5c=_0x91836['index_']['toString']()),_0x37915c['orderBy']=O(_0x42fb5c),_0x91836['startSet_']){const _0x1e33bf=_0x91836['startAfterSet_']?'startAfter':'startAt';_0x37915c[_0x1e33bf]=O(_0x91836['indexStartValue_']),_0x91836['startNameSet_']&&(_0x37915c[_0x1e33bf]+=','+O(_0x91836['indexStartName_']));}if(_0x91836['endSet_']){const _0x1047ac=_0x91836['endBeforeSet_']?'endBefore':'endAt';_0x37915c[_0x1047ac]=O(_0x91836['indexEndValue_']),_0x91836['endNameSet_']&&(_0x37915c[_0x1047ac]+=','+O(_0x91836['indexEndName_']));}return _0x91836['limitSet_']&&(_0x91836['isViewFromLeft']()?_0x37915c['limitToFirst']=_0x91836['limit_']:_0x37915c['limitToLast']=_0x91836['limit_']),_0x37915c;}function sr(_0x3c7ada){const _0x48575d={};if(_0x3c7ada['startSet_']&&(_0x48575d['sp']=_0x3c7ada['indexStartValue_'],_0x3c7ada['startNameSet_']&&(_0x48575d['sn']=_0x3c7ada['indexStartName_']),_0x48575d['sin']=!_0x3c7ada['startAfterSet_']),_0x3c7ada['endSet_']&&(_0x48575d['ep']=_0x3c7ada['indexEndValue_'],_0x3c7ada['endNameSet_']&&(_0x48575d['en']=_0x3c7ada['indexEndName_']),_0x48575d['ein']=!_0x3c7ada['endBeforeSet_']),_0x3c7ada['limitSet_']){_0x48575d['l']=_0x3c7ada['limit_'];let _0x7b13a4=_0x3c7ada['viewFrom_'];_0x7b13a4===''&&(_0x3c7ada['isViewFromLeft']()?_0x7b13a4='l':_0x7b13a4='r'),_0x48575d['vf']=_0x7b13a4;}return _0x3c7ada['index_']!==R&&(_0x48575d['i']=_0x3c7ada['index_']['toString']()),_0x48575d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x32d7f6){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3e46a4,_0x57d780){return _0x57d780!==void 0x0?'tag$'+_0x57d780:(f(_0x3e46a4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3e46a4['_path']['toString']());}constructor(_0x535f03,_0x30968d,_0x140219,_0x3c8bc5){super(),this['repoInfo_']=_0x535f03,this['onDataUpdate_']=_0x30968d,this['authTokenProvider_']=_0x140219,this['appCheckTokenProvider_']=_0x3c8bc5,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1a4515,_0x19200c,_0x5aaac0,_0x1197db){const _0x58535b=_0x1a4515['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x58535b+'\x20'+_0x1a4515['_queryIdentifier']);const _0x476de8=vn['getListenId_'](_0x1a4515,_0x5aaac0),_0x254b23={};this['listens_'][_0x476de8]=_0x254b23;const _0x18e272=ir(_0x1a4515['_queryParams']);this['restRequest_'](_0x58535b+'.json',_0x18e272,(_0x1d0548,_0x154236)=>{let _0x598639=_0x154236;if(_0x1d0548===0x194&&(_0x598639=null,_0x1d0548=null),_0x1d0548===null&&this['onDataUpdate_'](_0x58535b,_0x598639,!0x1,_0x5aaac0),Le(this['listens_'],_0x476de8)===_0x254b23){let _0x46c4ec;_0x1d0548?_0x1d0548===0x191?_0x46c4ec='permission_denied':_0x46c4ec='rest_error:'+_0x1d0548:_0x46c4ec='ok',_0x1197db(_0x46c4ec,null);}});}['unlisten'](_0x447c86,_0x1173d6){const _0x5c8a7f=vn['getListenId_'](_0x447c86,_0x1173d6);delete this['listens_'][_0x5c8a7f];}['get'](_0x152db9){const _0x8c09d6=ir(_0x152db9['_queryParams']),_0x4e11f4=_0x152db9['_path']['toString'](),_0x6e9bbb=new H();return this['restRequest_'](_0x4e11f4+'.json',_0x8c09d6,(_0x1116bc,_0x4198c9)=>{let _0x185fad=_0x4198c9;_0x1116bc===0x194&&(_0x185fad=null,_0x1116bc=null),_0x1116bc===null?(this['onDataUpdate_'](_0x4e11f4,_0x185fad,!0x1,null),_0x6e9bbb['resolve'](_0x185fad)):_0x6e9bbb['reject'](new Error(_0x185fad));}),_0x6e9bbb['promise'];}['refreshAuthToken'](_0x51b6b5){}['restRequest_'](_0x3072cf,_0x1ab860={},_0xf6db57){return _0x1ab860['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3da531,_0x597853])=>{_0x3da531&&_0x3da531['accessToken']&&(_0x1ab860['auth']=_0x3da531['accessToken']),_0x597853&&_0x597853['token']&&(_0x1ab860['ac']=_0x597853['token']);const _0x5251b0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3072cf+'?ns='+this['repoInfo_']['namespace']+ut(_0x1ab860);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5251b0);const _0x284ce7=new XMLHttpRequest();_0x284ce7['onreadystatechange']=()=>{if(_0xf6db57&&_0x284ce7['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5251b0+'\x20received.\x20status:',_0x284ce7['status'],'response:',_0x284ce7['responseText']);let _0x196fae=null;if(_0x284ce7['status']>=0xc8&&_0x284ce7['status']<0x12c){try{_0x196fae=Nt(_0x284ce7['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5251b0+':\x20'+_0x284ce7['responseText']);}_0xf6db57(null,_0x196fae);}else _0x284ce7['status']!==0x191&&_0x284ce7['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5251b0+'\x20Status:\x20'+_0x284ce7['status']),_0xf6db57(_0x284ce7['status']);_0xf6db57=null;}},_0x284ce7['open']('GET',_0x5251b0,!0x0),_0x284ce7['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5ca7c6){return this['rootNode_']['getChild'](_0x5ca7c6);}['updateSnapshot'](_0x4d2bc1,_0x35ddbc){this['rootNode_']=this['rootNode_']['updateChild'](_0x4d2bc1,_0x35ddbc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x717ff9,_0x918118,_0x50f440){if(v(_0x918118))_0x717ff9['value']=_0x50f440,_0x717ff9['children']['clear']();else{if(_0x717ff9['value']!==null)_0x717ff9['value']=_0x717ff9['value']['updateChild'](_0x918118,_0x50f440);else{const _0x3a420b=y(_0x918118);_0x717ff9['children']['has'](_0x3a420b)||_0x717ff9['children']['set'](_0x3a420b,En());const _0x3fa9dc=_0x717ff9['children']['get'](_0x3a420b);_0x918118=S(_0x918118),pt(_0x3fa9dc,_0x918118,_0x50f440);}}}function Ti(_0x3a6b35,_0x11be6f){if(v(_0x11be6f))return _0x3a6b35['value']=null,_0x3a6b35['children']['clear'](),!0x0;if(_0x3a6b35['value']!==null){if(_0x3a6b35['value']['isLeafNode']())return!0x1;{const _0x19a63f=_0x3a6b35['value'];return _0x3a6b35['value']=null,_0x19a63f['forEachChild'](R,(_0xec1d7a,_0x7e6842)=>{pt(_0x3a6b35,new C(_0xec1d7a),_0x7e6842);}),Ti(_0x3a6b35,_0x11be6f);}}else{if(_0x3a6b35['children']['size']>0x0){const _0x2e406b=y(_0x11be6f);return _0x11be6f=S(_0x11be6f),_0x3a6b35['children']['has'](_0x2e406b)&&Ti(_0x3a6b35['children']['get'](_0x2e406b),_0x11be6f)&&_0x3a6b35['children']['delete'](_0x2e406b),_0x3a6b35['children']['size']===0x0;}else return!0x0;}}function Si(_0xda0eb8,_0x4bf2d2,_0x35db13){_0xda0eb8['value']!==null?_0x35db13(_0x4bf2d2,_0xda0eb8['value']):Zh(_0xda0eb8,(_0x335138,_0x515bf5)=>{const _0x3be264=new C(_0x4bf2d2['toString']()+'/'+_0x335138);Si(_0x515bf5,_0x3be264,_0x35db13);});}function Zh(_0x325aab,_0x1f1a46){_0x325aab['children']['forEach']((_0x7fddd2,_0x10581b)=>{_0x1f1a46(_0x10581b,_0x7fddd2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x6b886a){this['collection_']=_0x6b886a,this['last_']=null;}['get'](){const _0x57bfaf=this['collection_']['get'](),_0x57ba36={..._0x57bfaf};return this['last_']&&x(this['last_'],(_0x2c9b18,_0x289ec4)=>{_0x57ba36[_0x2c9b18]=_0x57ba36[_0x2c9b18]-_0x289ec4;}),this['last_']=_0x57bfaf,_0x57ba36;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x4a54e2,_0x356e7e){this['server_']=_0x356e7e,this['statsToReport_']={},this['statsListener_']=new eu(_0x4a54e2);const _0x1adeca=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1adeca));}['reportStats_'](){const _0x1f9686=this['statsListener_']['get'](),_0x34f059={};let _0x2c21ca=!0x1;x(_0x1f9686,(_0x59eee8,_0x568daf)=>{_0x568daf>0x0&&Q(this['statsToReport_'],_0x59eee8)&&(_0x34f059[_0x59eee8]=_0x568daf,_0x2c21ca=!0x0);}),_0x2c21ca&&this['server_']['reportStats'](_0x34f059),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x300b38){_0x300b38[_0x300b38['OVERWRITE']=0x0]='OVERWRITE',_0x300b38[_0x300b38['MERGE']=0x1]='MERGE',_0x300b38[_0x300b38['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x300b38[_0x300b38['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x5a7cd4){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5a7cd4,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x257782,_0x77fecd,_0x39a453){this['path']=_0x257782,this['affectedTree']=_0x77fecd,this['revert']=_0x39a453,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x2a1f58){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5e67d5=this['affectedTree']['subtree'](new C(_0x2a1f58));return new In(w(),_0x5e67d5,this['revert']);}}else return f(y(this['path'])===_0x2a1f58,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x5e1f6e,_0x1afae9){this['source']=_0x5e1f6e,this['path']=_0x1afae9,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5b8b01){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x253d99,_0x25623f,_0x1e6da0){this['source']=_0x253d99,this['path']=_0x25623f,this['snap']=_0x1e6da0,this['type']=z['OVERWRITE'];}['operationForChild'](_0x224b18){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x224b18)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x19af9a,_0x3c901a,_0x1fc44d){this['source']=_0x19af9a,this['path']=_0x3c901a,this['children']=_0x1fc44d,this['type']=z['MERGE'];}['operationForChild'](_0x1f2aed){if(v(this['path'])){const _0x6f8f46=this['children']['subtree'](new C(_0x1f2aed));return _0x6f8f46['isEmpty']()?null:_0x6f8f46['value']?new Be(this['source'],w(),_0x6f8f46['value']):new ot(this['source'],w(),_0x6f8f46);}else return f(y(this['path'])===_0x1f2aed,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2329e7,_0x14642a,_0x312e38){this['node_']=_0x2329e7,this['fullyInitialized_']=_0x14642a,this['filtered_']=_0x312e38;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3e3e96){if(v(_0x3e3e96))return this['isFullyInitialized']()&&!this['filtered_'];const _0x192d54=y(_0x3e3e96);return this['isCompleteForChild'](_0x192d54);}['isCompleteForChild'](_0x29c93f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x29c93f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x42c755){this['query_']=_0x42c755,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x24efc6,_0x57495e,_0x4c1386,_0x1070e0){const _0x479367=[],_0x59689f=[];return _0x57495e['forEach'](_0x59afb4=>{_0x59afb4['type']==='child_changed'&&_0x24efc6['index_']['indexedValueChanged'](_0x59afb4['oldSnap'],_0x59afb4['snapshotNode'])&&_0x59689f['push'](zh(_0x59afb4['childName'],_0x59afb4['snapshotNode']));}),wt(_0x24efc6,_0x479367,'child_removed',_0x57495e,_0x1070e0,_0x4c1386),wt(_0x24efc6,_0x479367,'child_added',_0x57495e,_0x1070e0,_0x4c1386),wt(_0x24efc6,_0x479367,'child_moved',_0x59689f,_0x1070e0,_0x4c1386),wt(_0x24efc6,_0x479367,'child_changed',_0x57495e,_0x1070e0,_0x4c1386),wt(_0x24efc6,_0x479367,'value',_0x57495e,_0x1070e0,_0x4c1386),_0x479367;}function wt(_0x4783dd,_0x1e8880,_0x26758,_0x45c930,_0x29c746,_0x168622){const _0x3926ab=_0x45c930['filter'](_0x4e0c07=>_0x4e0c07['type']===_0x26758);_0x3926ab['sort']((_0x31d302,_0x4dc05f)=>au(_0x4783dd,_0x31d302,_0x4dc05f)),_0x3926ab['forEach'](_0x5c3d03=>{const _0x519a69=ou(_0x4783dd,_0x5c3d03,_0x168622);_0x29c746['forEach'](_0x12421d=>{_0x12421d['respondsTo'](_0x5c3d03['type'])&&_0x1e8880['push'](_0x12421d['createEvent'](_0x519a69,_0x4783dd['query_']));});});}function ou(_0xc0555f,_0x3dbe14,_0x2c98b8){return _0x3dbe14['type']==='value'||_0x3dbe14['type']==='child_removed'||(_0x3dbe14['prevName']=_0x2c98b8['getPredecessorChildName'](_0x3dbe14['childName'],_0x3dbe14['snapshotNode'],_0xc0555f['index_'])),_0x3dbe14;}function au(_0x155919,_0x1cd4f8,_0x3cfcfd){if(_0x1cd4f8['childName']==null||_0x3cfcfd['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0xa0c235=new E(_0x1cd4f8['childName'],_0x1cd4f8['snapshotNode']),_0x48f0d2=new E(_0x3cfcfd['childName'],_0x3cfcfd['snapshotNode']);return _0x155919['index_']['compare'](_0xa0c235,_0x48f0d2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x50e60a,_0xe07b40){return{'eventCache':_0x50e60a,'serverCache':_0xe07b40};}function Rt(_0x277120,_0x33adab,_0x3b65dd,_0x471af0){return Un(new Te(_0x33adab,_0x3b65dd,_0x471af0),_0x277120['serverCache']);}function Fo(_0x23bf83,_0xb524d1,_0x364202,_0x3db3fc){return Un(_0x23bf83['eventCache'],new Te(_0xb524d1,_0x364202,_0x3db3fc));}function wn(_0x4abe42){return _0x4abe42['eventCache']['isFullyInitialized']()?_0x4abe42['eventCache']['getNode']():null;}function Ve(_0x21128e){return _0x21128e['serverCache']['isFullyInitialized']()?_0x21128e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x416805){let _0x202b7c=new b(null);return x(_0x416805,(_0x27ec4d,_0x4303d1)=>{_0x202b7c=_0x202b7c['set'](new C(_0x27ec4d),_0x4303d1);}),_0x202b7c;}constructor(_0x3158e1,_0x27f40c=cu()){this['value']=_0x3158e1,this['children']=_0x27f40c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1e0e91,_0xca7200){if(this['value']!=null&&_0xca7200(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1e0e91))return null;{const _0x3a3f88=y(_0x1e0e91),_0x8ad9ae=this['children']['get'](_0x3a3f88);if(_0x8ad9ae!==null){const _0x32dbb9=_0x8ad9ae['findRootMostMatchingPathAndValue'](S(_0x1e0e91),_0xca7200);return _0x32dbb9!=null?{'path':k(new C(_0x3a3f88),_0x32dbb9['path']),'value':_0x32dbb9['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5abfaa){return this['findRootMostMatchingPathAndValue'](_0x5abfaa,()=>!0x0);}['subtree'](_0x2471d9){if(v(_0x2471d9))return this;{const _0x440c30=y(_0x2471d9),_0x124cd2=this['children']['get'](_0x440c30);return _0x124cd2!==null?_0x124cd2['subtree'](S(_0x2471d9)):new b(null);}}['set'](_0x42fdf7,_0x3db7b9){if(v(_0x42fdf7))return new b(_0x3db7b9,this['children']);{const _0x27cd4c=y(_0x42fdf7),_0x649a5=(this['children']['get'](_0x27cd4c)||new b(null))['set'](S(_0x42fdf7),_0x3db7b9),_0x289352=this['children']['insert'](_0x27cd4c,_0x649a5);return new b(this['value'],_0x289352);}}['remove'](_0x3a3b99){if(v(_0x3a3b99))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x12fa57=y(_0x3a3b99),_0xeb40fd=this['children']['get'](_0x12fa57);if(_0xeb40fd){const _0x392073=_0xeb40fd['remove'](S(_0x3a3b99));let _0x218092;return _0x392073['isEmpty']()?_0x218092=this['children']['remove'](_0x12fa57):_0x218092=this['children']['insert'](_0x12fa57,_0x392073),this['value']===null&&_0x218092['isEmpty']()?new b(null):new b(this['value'],_0x218092);}else return this;}}['get'](_0x415d08){if(v(_0x415d08))return this['value'];{const _0x5a4dac=y(_0x415d08),_0x396abf=this['children']['get'](_0x5a4dac);return _0x396abf?_0x396abf['get'](S(_0x415d08)):null;}}['setTree'](_0xa0fcd3,_0x5bf9fe){if(v(_0xa0fcd3))return _0x5bf9fe;{const _0x3c529c=y(_0xa0fcd3),_0x1fd160=(this['children']['get'](_0x3c529c)||new b(null))['setTree'](S(_0xa0fcd3),_0x5bf9fe);let _0x2d0682;return _0x1fd160['isEmpty']()?_0x2d0682=this['children']['remove'](_0x3c529c):_0x2d0682=this['children']['insert'](_0x3c529c,_0x1fd160),new b(this['value'],_0x2d0682);}}['fold'](_0x2b56fb){return this['fold_'](w(),_0x2b56fb);}['fold_'](_0x4400a8,_0x5f3de7){const _0x488198={};return this['children']['inorderTraversal']((_0x3840e5,_0x3dddea)=>{_0x488198[_0x3840e5]=_0x3dddea['fold_'](k(_0x4400a8,_0x3840e5),_0x5f3de7);}),_0x5f3de7(_0x4400a8,this['value'],_0x488198);}['findOnPath'](_0x5eb2dd,_0x406e51){return this['findOnPath_'](_0x5eb2dd,w(),_0x406e51);}['findOnPath_'](_0x34ad0d,_0x4b94bb,_0x35d4a4){const _0x44bf16=this['value']?_0x35d4a4(_0x4b94bb,this['value']):!0x1;if(_0x44bf16)return _0x44bf16;if(v(_0x34ad0d))return null;{const _0x16a4a2=y(_0x34ad0d),_0x4f97fd=this['children']['get'](_0x16a4a2);return _0x4f97fd?_0x4f97fd['findOnPath_'](S(_0x34ad0d),k(_0x4b94bb,_0x16a4a2),_0x35d4a4):null;}}['foreachOnPath'](_0x14c2c9,_0x2243ac){return this['foreachOnPath_'](_0x14c2c9,w(),_0x2243ac);}['foreachOnPath_'](_0xec8feb,_0x2d8488,_0x7b0b35){if(v(_0xec8feb))return this;{this['value']&&_0x7b0b35(_0x2d8488,this['value']);const _0x2e6eb9=y(_0xec8feb),_0x4c7bca=this['children']['get'](_0x2e6eb9);return _0x4c7bca?_0x4c7bca['foreachOnPath_'](S(_0xec8feb),k(_0x2d8488,_0x2e6eb9),_0x7b0b35):new b(null);}}['foreach'](_0x3731af){this['foreach_'](w(),_0x3731af);}['foreach_'](_0x46ff36,_0x1989ef){this['children']['inorderTraversal']((_0x5228b0,_0x4d8203)=>{_0x4d8203['foreach_'](k(_0x46ff36,_0x5228b0),_0x1989ef);}),this['value']&&_0x1989ef(_0x46ff36,this['value']);}['foreachChild'](_0x1c075c){this['children']['inorderTraversal']((_0x2aa7a8,_0x3c816b)=>{_0x3c816b['value']&&_0x1c075c(_0x2aa7a8,_0x3c816b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x103fdc){this['writeTree_']=_0x103fdc;}static['empty'](){return new K(new b(null));}}function At(_0x2aa565,_0xda1265,_0x8c78d0){if(v(_0xda1265))return new K(new b(_0x8c78d0));{const _0xffa9a7=_0x2aa565['writeTree_']['findRootMostValueAndPath'](_0xda1265);if(_0xffa9a7!=null){const _0x27a61b=_0xffa9a7['path'];let _0x4ce044=_0xffa9a7['value'];const _0x201038=F(_0x27a61b,_0xda1265);return _0x4ce044=_0x4ce044['updateChild'](_0x201038,_0x8c78d0),new K(_0x2aa565['writeTree_']['set'](_0x27a61b,_0x4ce044));}else{const _0x14609f=new b(_0x8c78d0),_0x456b50=_0x2aa565['writeTree_']['setTree'](_0xda1265,_0x14609f);return new K(_0x456b50);}}}function bi(_0x1c1dbd,_0xf5e10d,_0x2ab597){let _0x3de658=_0x1c1dbd;return x(_0x2ab597,(_0x4dd14d,_0x310d41)=>{_0x3de658=At(_0x3de658,k(_0xf5e10d,_0x4dd14d),_0x310d41);}),_0x3de658;}function or(_0x2faf4d,_0x218db0){if(v(_0x218db0))return K['empty']();{const _0x324d8d=_0x2faf4d['writeTree_']['setTree'](_0x218db0,new b(null));return new K(_0x324d8d);}}function Ri(_0x250a1b,_0xfb7499){return ze(_0x250a1b,_0xfb7499)!=null;}function ze(_0x23bf8f,_0x5297a9){const _0x5ca4f0=_0x23bf8f['writeTree_']['findRootMostValueAndPath'](_0x5297a9);return _0x5ca4f0!=null?_0x23bf8f['writeTree_']['get'](_0x5ca4f0['path'])['getChild'](F(_0x5ca4f0['path'],_0x5297a9)):null;}function ar(_0x4f0bbc){const _0x51c508=[],_0x21ce9c=_0x4f0bbc['writeTree_']['value'];return _0x21ce9c!=null?_0x21ce9c['isLeafNode']()||_0x21ce9c['forEachChild'](R,(_0x5a06ef,_0x2247c9)=>{_0x51c508['push'](new E(_0x5a06ef,_0x2247c9));}):_0x4f0bbc['writeTree_']['children']['inorderTraversal']((_0x56b49f,_0x2dfc1a)=>{_0x2dfc1a['value']!=null&&_0x51c508['push'](new E(_0x56b49f,_0x2dfc1a['value']));}),_0x51c508;}function Ee(_0x3a4967,_0xeec385){if(v(_0xeec385))return _0x3a4967;{const _0x9bd224=ze(_0x3a4967,_0xeec385);return _0x9bd224!=null?new K(new b(_0x9bd224)):new K(_0x3a4967['writeTree_']['subtree'](_0xeec385));}}function Ai(_0x57ec2d){return _0x57ec2d['writeTree_']['isEmpty']();}function at(_0x3fd361,_0x4c717a){return Uo(w(),_0x3fd361['writeTree_'],_0x4c717a);}function Uo(_0x34ed13,_0x538c40,_0x28ec1c){if(_0x538c40['value']!=null)return _0x28ec1c['updateChild'](_0x34ed13,_0x538c40['value']);{let _0x22ac49=null;return _0x538c40['children']['inorderTraversal']((_0x414c4d,_0x21e8bb)=>{_0x414c4d==='.priority'?(f(_0x21e8bb['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x22ac49=_0x21e8bb['value']):_0x28ec1c=Uo(k(_0x34ed13,_0x414c4d),_0x21e8bb,_0x28ec1c);}),!_0x28ec1c['getChild'](_0x34ed13)['isEmpty']()&&_0x22ac49!==null&&(_0x28ec1c=_0x28ec1c['updateChild'](k(_0x34ed13,'.priority'),_0x22ac49)),_0x28ec1c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x3afe25,_0xaeb030){return Ho(_0xaeb030,_0x3afe25);}function lu(_0x4423fe,_0x5053d8,_0x374c19,_0x113f1b,_0x58b386){f(_0x113f1b>_0x4423fe['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x58b386===void 0x0&&(_0x58b386=!0x0),_0x4423fe['allWrites']['push']({'path':_0x5053d8,'snap':_0x374c19,'writeId':_0x113f1b,'visible':_0x58b386}),_0x58b386&&(_0x4423fe['visibleWrites']=At(_0x4423fe['visibleWrites'],_0x5053d8,_0x374c19)),_0x4423fe['lastWriteId']=_0x113f1b;}function hu(_0x310203,_0x14a73a,_0x4456ef,_0xaff496){f(_0xaff496>_0x310203['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x310203['allWrites']['push']({'path':_0x14a73a,'children':_0x4456ef,'writeId':_0xaff496,'visible':!0x0}),_0x310203['visibleWrites']=bi(_0x310203['visibleWrites'],_0x14a73a,_0x4456ef),_0x310203['lastWriteId']=_0xaff496;}function uu(_0x22bbce,_0x4cda93){for(let _0x42a8d8=0x0;_0x42a8d8<_0x22bbce['allWrites']['length'];_0x42a8d8++){const _0x57778e=_0x22bbce['allWrites'][_0x42a8d8];if(_0x57778e['writeId']===_0x4cda93)return _0x57778e;}return null;}function du(_0x44d0e5,_0x3c3383){const _0x142b99=_0x44d0e5['allWrites']['findIndex'](_0x1c492e=>_0x1c492e['writeId']===_0x3c3383);f(_0x142b99>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x467631=_0x44d0e5['allWrites'][_0x142b99];_0x44d0e5['allWrites']['splice'](_0x142b99,0x1);let _0x1d786b=_0x467631['visible'],_0x55719b=!0x1,_0x536c90=_0x44d0e5['allWrites']['length']-0x1;for(;_0x1d786b&&_0x536c90>=0x0;){const _0x337eac=_0x44d0e5['allWrites'][_0x536c90];_0x337eac['visible']&&(_0x536c90>=_0x142b99&&fu(_0x337eac,_0x467631['path'])?_0x1d786b=!0x1:G(_0x467631['path'],_0x337eac['path'])&&(_0x55719b=!0x0)),_0x536c90--;}if(_0x1d786b){if(_0x55719b)return pu(_0x44d0e5),!0x0;if(_0x467631['snap'])_0x44d0e5['visibleWrites']=or(_0x44d0e5['visibleWrites'],_0x467631['path']);else{const _0x549ec3=_0x467631['children'];x(_0x549ec3,_0x165fac=>{_0x44d0e5['visibleWrites']=or(_0x44d0e5['visibleWrites'],k(_0x467631['path'],_0x165fac));});}return!0x0;}else return!0x1;}function fu(_0x2fa634,_0xc2c9){if(_0x2fa634['snap'])return G(_0x2fa634['path'],_0xc2c9);for(const _0x4f50a1 in _0x2fa634['children'])if(_0x2fa634['children']['hasOwnProperty'](_0x4f50a1)&&G(k(_0x2fa634['path'],_0x4f50a1),_0xc2c9))return!0x0;return!0x1;}function pu(_0x198844){_0x198844['visibleWrites']=Wo(_0x198844['allWrites'],_u,w()),_0x198844['allWrites']['length']>0x0?_0x198844['lastWriteId']=_0x198844['allWrites'][_0x198844['allWrites']['length']-0x1]['writeId']:_0x198844['lastWriteId']=-0x1;}function _u(_0x446a76){return _0x446a76['visible'];}function Wo(_0x3d112f,_0x44b9f4,_0x1fe51e){let _0x35adc3=K['empty']();for(let _0x4f6a4e=0x0;_0x4f6a4e<_0x3d112f['length'];++_0x4f6a4e){const _0x15c3a4=_0x3d112f[_0x4f6a4e];if(_0x44b9f4(_0x15c3a4)){const _0xc00c6d=_0x15c3a4['path'];let _0x35d3f8;if(_0x15c3a4['snap'])G(_0x1fe51e,_0xc00c6d)?(_0x35d3f8=F(_0x1fe51e,_0xc00c6d),_0x35adc3=At(_0x35adc3,_0x35d3f8,_0x15c3a4['snap'])):G(_0xc00c6d,_0x1fe51e)&&(_0x35d3f8=F(_0xc00c6d,_0x1fe51e),_0x35adc3=At(_0x35adc3,w(),_0x15c3a4['snap']['getChild'](_0x35d3f8)));else{if(_0x15c3a4['children']){if(G(_0x1fe51e,_0xc00c6d))_0x35d3f8=F(_0x1fe51e,_0xc00c6d),_0x35adc3=bi(_0x35adc3,_0x35d3f8,_0x15c3a4['children']);else{if(G(_0xc00c6d,_0x1fe51e)){if(_0x35d3f8=F(_0xc00c6d,_0x1fe51e),v(_0x35d3f8))_0x35adc3=bi(_0x35adc3,w(),_0x15c3a4['children']);else{const _0x50d60e=Le(_0x15c3a4['children'],y(_0x35d3f8));if(_0x50d60e){const _0x405d4c=_0x50d60e['getChild'](S(_0x35d3f8));_0x35adc3=At(_0x35adc3,w(),_0x405d4c);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x35adc3;}function Bo(_0xe4bcc,_0x3d0a21,_0x258ceb,_0x2d7620,_0x31616c){if(!_0x2d7620&&!_0x31616c){const _0xfcf7ca=ze(_0xe4bcc['visibleWrites'],_0x3d0a21);if(_0xfcf7ca!=null)return _0xfcf7ca;{const _0x106209=Ee(_0xe4bcc['visibleWrites'],_0x3d0a21);if(Ai(_0x106209))return _0x258ceb;if(_0x258ceb==null&&!Ri(_0x106209,w()))return null;{const _0x5e7b64=_0x258ceb||g['EMPTY_NODE'];return at(_0x106209,_0x5e7b64);}}}else{const _0x39968=Ee(_0xe4bcc['visibleWrites'],_0x3d0a21);if(!_0x31616c&&Ai(_0x39968))return _0x258ceb;if(!_0x31616c&&_0x258ceb==null&&!Ri(_0x39968,w()))return null;{const _0x4ecbed=function(_0xbc9558){return(_0xbc9558['visible']||_0x31616c)&&(!_0x2d7620||!~_0x2d7620['indexOf'](_0xbc9558['writeId']))&&(G(_0xbc9558['path'],_0x3d0a21)||G(_0x3d0a21,_0xbc9558['path']));},_0xfe54a2=Wo(_0xe4bcc['allWrites'],_0x4ecbed,_0x3d0a21),_0x58601e=_0x258ceb||g['EMPTY_NODE'];return at(_0xfe54a2,_0x58601e);}}}function gu(_0x51fc5a,_0x5455aa,_0x1c433a){let _0xdd523=g['EMPTY_NODE'];const _0x12a22d=ze(_0x51fc5a['visibleWrites'],_0x5455aa);if(_0x12a22d)return _0x12a22d['isLeafNode']()||_0x12a22d['forEachChild'](R,(_0x512486,_0x137575)=>{_0xdd523=_0xdd523['updateImmediateChild'](_0x512486,_0x137575);}),_0xdd523;if(_0x1c433a){const _0x3710=Ee(_0x51fc5a['visibleWrites'],_0x5455aa);return _0x1c433a['forEachChild'](R,(_0x1cdef3,_0x1cdd4e)=>{const _0x2d11a7=at(Ee(_0x3710,new C(_0x1cdef3)),_0x1cdd4e);_0xdd523=_0xdd523['updateImmediateChild'](_0x1cdef3,_0x2d11a7);}),ar(_0x3710)['forEach'](_0x357820=>{_0xdd523=_0xdd523['updateImmediateChild'](_0x357820['name'],_0x357820['node']);}),_0xdd523;}else{const _0x4a59ac=Ee(_0x51fc5a['visibleWrites'],_0x5455aa);return ar(_0x4a59ac)['forEach'](_0x433117=>{_0xdd523=_0xdd523['updateImmediateChild'](_0x433117['name'],_0x433117['node']);}),_0xdd523;}}function mu(_0x55c84d,_0x41d137,_0x48b63e,_0x3bd482,_0x50d8dd){f(_0x3bd482||_0x50d8dd,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x28ff3e=k(_0x41d137,_0x48b63e);if(Ri(_0x55c84d['visibleWrites'],_0x28ff3e))return null;{const _0xdaf5c1=Ee(_0x55c84d['visibleWrites'],_0x28ff3e);return Ai(_0xdaf5c1)?_0x50d8dd['getChild'](_0x48b63e):at(_0xdaf5c1,_0x50d8dd['getChild'](_0x48b63e));}}function yu(_0x3316a2,_0x1d7cc5,_0x3b8668,_0x51e756){const _0x11204e=k(_0x1d7cc5,_0x3b8668),_0x173c59=ze(_0x3316a2['visibleWrites'],_0x11204e);if(_0x173c59!=null)return _0x173c59;if(_0x51e756['isCompleteForChild'](_0x3b8668)){const _0x4af242=Ee(_0x3316a2['visibleWrites'],_0x11204e);return at(_0x4af242,_0x51e756['getNode']()['getImmediateChild'](_0x3b8668));}else return null;}function vu(_0x287399,_0x4b4798){return ze(_0x287399['visibleWrites'],_0x4b4798);}function Eu(_0xbcb030,_0x13dfb7,_0x921542,_0x200bf6,_0x3cc833,_0x515d2d,_0x15a044){let _0x3aa905;const _0x329d73=Ee(_0xbcb030['visibleWrites'],_0x13dfb7),_0x34167f=ze(_0x329d73,w());if(_0x34167f!=null)_0x3aa905=_0x34167f;else{if(_0x921542!=null)_0x3aa905=at(_0x329d73,_0x921542);else return[];}if(_0x3aa905=_0x3aa905['withIndex'](_0x15a044),!_0x3aa905['isEmpty']()&&!_0x3aa905['isLeafNode']()){const _0x4fbb24=[],_0x2c194f=_0x15a044['getCompare'](),_0x5c3fe5=_0x515d2d?_0x3aa905['getReverseIteratorFrom'](_0x200bf6,_0x15a044):_0x3aa905['getIteratorFrom'](_0x200bf6,_0x15a044);let _0x2196ac=_0x5c3fe5['getNext']();for(;_0x2196ac&&_0x4fbb24['length']<_0x3cc833;)_0x2c194f(_0x2196ac,_0x200bf6)!==0x0&&_0x4fbb24['push'](_0x2196ac),_0x2196ac=_0x5c3fe5['getNext']();return _0x4fbb24;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2222a1,_0xe90f73,_0x4da46a,_0x52cca1){return Bo(_0x2222a1['writeTree'],_0x2222a1['treePath'],_0xe90f73,_0x4da46a,_0x52cca1);}function is(_0x3ae4d8,_0x221ed1){return gu(_0x3ae4d8['writeTree'],_0x3ae4d8['treePath'],_0x221ed1);}function cr(_0x2cb83b,_0x4bbea3,_0x1f8faf,_0x25133f){return mu(_0x2cb83b['writeTree'],_0x2cb83b['treePath'],_0x4bbea3,_0x1f8faf,_0x25133f);}function Tn(_0x27b89b,_0x45007a){return vu(_0x27b89b['writeTree'],k(_0x27b89b['treePath'],_0x45007a));}function wu(_0x81eb40,_0x2044ec,_0x384d89,_0xaa32e2,_0x2246bc,_0x385d16){return Eu(_0x81eb40['writeTree'],_0x81eb40['treePath'],_0x2044ec,_0x384d89,_0xaa32e2,_0x2246bc,_0x385d16);}function ss(_0x3615d6,_0x4bba9,_0x21143a){return yu(_0x3615d6['writeTree'],_0x3615d6['treePath'],_0x4bba9,_0x21143a);}function Vo(_0x491daf,_0x4bce06){return Ho(k(_0x491daf['treePath'],_0x4bce06),_0x491daf['writeTree']);}function Ho(_0x53e351,_0x5ebbf8){return{'treePath':_0x53e351,'writeTree':_0x5ebbf8};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3ecb3e){const _0x28ed18=_0x3ecb3e['type'],_0x463504=_0x3ecb3e['childName'];f(_0x28ed18==='child_added'||_0x28ed18==='child_changed'||_0x28ed18==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x463504!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x24230e=this['changeMap']['get'](_0x463504);if(_0x24230e){const _0x3e8257=_0x24230e['type'];if(_0x28ed18==='child_added'&&_0x3e8257==='child_removed')this['changeMap']['set'](_0x463504,xt(_0x463504,_0x3ecb3e['snapshotNode'],_0x24230e['snapshotNode']));else{if(_0x28ed18==='child_removed'&&_0x3e8257==='child_added')this['changeMap']['delete'](_0x463504);else{if(_0x28ed18==='child_removed'&&_0x3e8257==='child_changed')this['changeMap']['set'](_0x463504,Lt(_0x463504,_0x24230e['oldSnap']));else{if(_0x28ed18==='child_changed'&&_0x3e8257==='child_added')this['changeMap']['set'](_0x463504,rt(_0x463504,_0x3ecb3e['snapshotNode']));else{if(_0x28ed18==='child_changed'&&_0x3e8257==='child_changed')this['changeMap']['set'](_0x463504,xt(_0x463504,_0x3ecb3e['snapshotNode'],_0x24230e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x3ecb3e+'\x20occurred\x20after\x20'+_0x24230e);}}}}}else this['changeMap']['set'](_0x463504,_0x3ecb3e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x11eb74){return null;}['getChildAfterChild'](_0x5bbc3e,_0x5d4e43,_0x342f9b){return null;}}const $o=new Tu();class rs{constructor(_0x4ab64c,_0x15ed81,_0x5f40ef=null){this['writes_']=_0x4ab64c,this['viewCache_']=_0x15ed81,this['optCompleteServerCache_']=_0x5f40ef;}['getCompleteChild'](_0x2f3106){const _0x48af3e=this['viewCache_']['eventCache'];if(_0x48af3e['isCompleteForChild'](_0x2f3106))return _0x48af3e['getNode']()['getImmediateChild'](_0x2f3106);{const _0x16b196=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2f3106,_0x16b196);}}['getChildAfterChild'](_0x28cfc1,_0x371fea,_0x5bf400){const _0x2a164d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x49b2b5=wu(this['writes_'],_0x2a164d,_0x371fea,0x1,_0x5bf400,_0x28cfc1);return _0x49b2b5['length']===0x0?null:_0x49b2b5[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5a4474){return{'filter':_0x5a4474};}function bu(_0x366400,_0x5a8399){f(_0x5a8399['eventCache']['getNode']()['isIndexed'](_0x366400['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5a8399['serverCache']['getNode']()['isIndexed'](_0x366400['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x24ac41,_0x394720,_0x45c124,_0x52bf11,_0x3ca915){const _0x29818a=new Cu();let _0x137913,_0x575bf2;if(_0x45c124['type']===z['OVERWRITE']){const _0x59e3ab=_0x45c124;_0x59e3ab['source']['fromUser']?_0x137913=ki(_0x24ac41,_0x394720,_0x59e3ab['path'],_0x59e3ab['snap'],_0x52bf11,_0x3ca915,_0x29818a):(f(_0x59e3ab['source']['fromServer'],'Unknown\x20source.'),_0x575bf2=_0x59e3ab['source']['tagged']||_0x394720['serverCache']['isFiltered']()&&!v(_0x59e3ab['path']),_0x137913=Sn(_0x24ac41,_0x394720,_0x59e3ab['path'],_0x59e3ab['snap'],_0x52bf11,_0x3ca915,_0x575bf2,_0x29818a));}else{if(_0x45c124['type']===z['MERGE']){const _0x547533=_0x45c124;_0x547533['source']['fromUser']?_0x137913=ku(_0x24ac41,_0x394720,_0x547533['path'],_0x547533['children'],_0x52bf11,_0x3ca915,_0x29818a):(f(_0x547533['source']['fromServer'],'Unknown\x20source.'),_0x575bf2=_0x547533['source']['tagged']||_0x394720['serverCache']['isFiltered'](),_0x137913=Pi(_0x24ac41,_0x394720,_0x547533['path'],_0x547533['children'],_0x52bf11,_0x3ca915,_0x575bf2,_0x29818a));}else{if(_0x45c124['type']===z['ACK_USER_WRITE']){const _0xf17d13=_0x45c124;_0xf17d13['revert']?_0x137913=Ou(_0x24ac41,_0x394720,_0xf17d13['path'],_0x52bf11,_0x3ca915,_0x29818a):_0x137913=Pu(_0x24ac41,_0x394720,_0xf17d13['path'],_0xf17d13['affectedTree'],_0x52bf11,_0x3ca915,_0x29818a);}else{if(_0x45c124['type']===z['LISTEN_COMPLETE'])_0x137913=Nu(_0x24ac41,_0x394720,_0x45c124['path'],_0x52bf11,_0x29818a);else throw ht('Unknown\x20operation\x20type:\x20'+_0x45c124['type']);}}}const _0x5e524e=_0x29818a['getChanges']();return Au(_0x394720,_0x137913,_0x5e524e),{'viewCache':_0x137913,'changes':_0x5e524e};}function Au(_0x3182a6,_0x19f50f,_0x3800a0){const _0x4e810c=_0x19f50f['eventCache'];if(_0x4e810c['isFullyInitialized']()){const _0x13c23a=_0x4e810c['getNode']()['isLeafNode']()||_0x4e810c['getNode']()['isEmpty'](),_0x2b8827=wn(_0x3182a6);(_0x3800a0['length']>0x0||!_0x3182a6['eventCache']['isFullyInitialized']()||_0x13c23a&&!_0x4e810c['getNode']()['equals'](_0x2b8827)||!_0x4e810c['getNode']()['getPriority']()['equals'](_0x2b8827['getPriority']()))&&_0x3800a0['push'](Lo(wn(_0x19f50f)));}}function Go(_0x436fe6,_0x56ca21,_0x2f6719,_0x41caa5,_0x342f80,_0x30e14d){const _0x9621ba=_0x56ca21['eventCache'];if(Tn(_0x41caa5,_0x2f6719)!=null)return _0x56ca21;{let _0x3cc561,_0x743088;if(v(_0x2f6719)){if(f(_0x56ca21['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x56ca21['serverCache']['isFiltered']()){const _0xc96974=Ve(_0x56ca21),_0x47dbfc=_0xc96974 instanceof g?_0xc96974:g['EMPTY_NODE'],_0x24d432=is(_0x41caa5,_0x47dbfc);_0x3cc561=_0x436fe6['filter']['updateFullNode'](_0x56ca21['eventCache']['getNode'](),_0x24d432,_0x30e14d);}else{const _0x4d90fb=Cn(_0x41caa5,Ve(_0x56ca21));_0x3cc561=_0x436fe6['filter']['updateFullNode'](_0x56ca21['eventCache']['getNode'](),_0x4d90fb,_0x30e14d);}}else{const _0x5eb8e2=y(_0x2f6719);if(_0x5eb8e2==='.priority'){f(Ce(_0x2f6719)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x15289e=_0x9621ba['getNode']();_0x743088=_0x56ca21['serverCache']['getNode']();const _0x5e2e6f=cr(_0x41caa5,_0x2f6719,_0x15289e,_0x743088);_0x5e2e6f!=null?_0x3cc561=_0x436fe6['filter']['updatePriority'](_0x15289e,_0x5e2e6f):_0x3cc561=_0x9621ba['getNode']();}else{const _0x24c51d=S(_0x2f6719);let _0xda2a5a;if(_0x9621ba['isCompleteForChild'](_0x5eb8e2)){_0x743088=_0x56ca21['serverCache']['getNode']();const _0x490d14=cr(_0x41caa5,_0x2f6719,_0x9621ba['getNode'](),_0x743088);_0x490d14!=null?_0xda2a5a=_0x9621ba['getNode']()['getImmediateChild'](_0x5eb8e2)['updateChild'](_0x24c51d,_0x490d14):_0xda2a5a=_0x9621ba['getNode']()['getImmediateChild'](_0x5eb8e2);}else _0xda2a5a=ss(_0x41caa5,_0x5eb8e2,_0x56ca21['serverCache']);_0xda2a5a!=null?_0x3cc561=_0x436fe6['filter']['updateChild'](_0x9621ba['getNode'](),_0x5eb8e2,_0xda2a5a,_0x24c51d,_0x342f80,_0x30e14d):_0x3cc561=_0x9621ba['getNode']();}}return Rt(_0x56ca21,_0x3cc561,_0x9621ba['isFullyInitialized']()||v(_0x2f6719),_0x436fe6['filter']['filtersNodes']());}}function Sn(_0x398d46,_0x284a26,_0x683c2c,_0x2179c8,_0x4afa28,_0x44db25,_0x4812cd,_0x473886){const _0x1aa95a=_0x284a26['serverCache'];let _0x668093;const _0x43b04b=_0x4812cd?_0x398d46['filter']:_0x398d46['filter']['getIndexedFilter']();if(v(_0x683c2c))_0x668093=_0x43b04b['updateFullNode'](_0x1aa95a['getNode'](),_0x2179c8,null);else{if(_0x43b04b['filtersNodes']()&&!_0x1aa95a['isFiltered']()){const _0x39053d=_0x1aa95a['getNode']()['updateChild'](_0x683c2c,_0x2179c8);_0x668093=_0x43b04b['updateFullNode'](_0x1aa95a['getNode'](),_0x39053d,null);}else{const _0x382ba4=y(_0x683c2c);if(!_0x1aa95a['isCompleteForPath'](_0x683c2c)&&Ce(_0x683c2c)>0x1)return _0x284a26;const _0x3cf828=S(_0x683c2c),_0x2bc64c=_0x1aa95a['getNode']()['getImmediateChild'](_0x382ba4)['updateChild'](_0x3cf828,_0x2179c8);_0x382ba4==='.priority'?_0x668093=_0x43b04b['updatePriority'](_0x1aa95a['getNode'](),_0x2bc64c):_0x668093=_0x43b04b['updateChild'](_0x1aa95a['getNode'](),_0x382ba4,_0x2bc64c,_0x3cf828,$o,null);}}const _0x158de4=Fo(_0x284a26,_0x668093,_0x1aa95a['isFullyInitialized']()||v(_0x683c2c),_0x43b04b['filtersNodes']()),_0xf5c5cd=new rs(_0x4afa28,_0x158de4,_0x44db25);return Go(_0x398d46,_0x158de4,_0x683c2c,_0x4afa28,_0xf5c5cd,_0x473886);}function ki(_0x453af1,_0x464c48,_0x2851fb,_0x197684,_0x2e9493,_0x19d636,_0x54ea4d){const _0x5bdf76=_0x464c48['eventCache'];let _0x541cc2,_0x56ae82;const _0x28091d=new rs(_0x2e9493,_0x464c48,_0x19d636);if(v(_0x2851fb))_0x56ae82=_0x453af1['filter']['updateFullNode'](_0x464c48['eventCache']['getNode'](),_0x197684,_0x54ea4d),_0x541cc2=Rt(_0x464c48,_0x56ae82,!0x0,_0x453af1['filter']['filtersNodes']());else{const _0x232ace=y(_0x2851fb);if(_0x232ace==='.priority')_0x56ae82=_0x453af1['filter']['updatePriority'](_0x464c48['eventCache']['getNode'](),_0x197684),_0x541cc2=Rt(_0x464c48,_0x56ae82,_0x5bdf76['isFullyInitialized'](),_0x5bdf76['isFiltered']());else{const _0x41bdaf=S(_0x2851fb),_0x3443a1=_0x5bdf76['getNode']()['getImmediateChild'](_0x232ace);let _0x4953a;if(v(_0x41bdaf))_0x4953a=_0x197684;else{const _0x485a27=_0x28091d['getCompleteChild'](_0x232ace);_0x485a27!=null?ji(_0x41bdaf)==='.priority'&&_0x485a27['getChild'](Ro(_0x41bdaf))['isEmpty']()?_0x4953a=_0x485a27:_0x4953a=_0x485a27['updateChild'](_0x41bdaf,_0x197684):_0x4953a=g['EMPTY_NODE'];}if(_0x3443a1['equals'](_0x4953a))_0x541cc2=_0x464c48;else{const _0x4196fb=_0x453af1['filter']['updateChild'](_0x5bdf76['getNode'](),_0x232ace,_0x4953a,_0x41bdaf,_0x28091d,_0x54ea4d);_0x541cc2=Rt(_0x464c48,_0x4196fb,_0x5bdf76['isFullyInitialized'](),_0x453af1['filter']['filtersNodes']());}}}return _0x541cc2;}function lr(_0x213ded,_0x6d0d42){return _0x213ded['eventCache']['isCompleteForChild'](_0x6d0d42);}function ku(_0x22d31c,_0x553b8f,_0x1c7bec,_0x5bbeda,_0x532791,_0x34a7a6,_0x874392){let _0x2ab1c5=_0x553b8f;return _0x5bbeda['foreach']((_0x243ba5,_0x724e7e)=>{const _0x6a96d7=k(_0x1c7bec,_0x243ba5);lr(_0x553b8f,y(_0x6a96d7))&&(_0x2ab1c5=ki(_0x22d31c,_0x2ab1c5,_0x6a96d7,_0x724e7e,_0x532791,_0x34a7a6,_0x874392));}),_0x5bbeda['foreach']((_0x26b187,_0x588ac9)=>{const _0xc2d9f8=k(_0x1c7bec,_0x26b187);lr(_0x553b8f,y(_0xc2d9f8))||(_0x2ab1c5=ki(_0x22d31c,_0x2ab1c5,_0xc2d9f8,_0x588ac9,_0x532791,_0x34a7a6,_0x874392));}),_0x2ab1c5;}function hr(_0x30a0da,_0x3a971d,_0x45e556){return _0x45e556['foreach']((_0x3bbd87,_0x3fb06a)=>{_0x3a971d=_0x3a971d['updateChild'](_0x3bbd87,_0x3fb06a);}),_0x3a971d;}function Pi(_0x11fbdd,_0x42cb05,_0x1c00c5,_0x890cd7,_0x1f08a5,_0x2f73b2,_0x28d5e0,_0x5b7edb){if(_0x42cb05['serverCache']['getNode']()['isEmpty']()&&!_0x42cb05['serverCache']['isFullyInitialized']())return _0x42cb05;let _0x2d49d0=_0x42cb05,_0x45b282;v(_0x1c00c5)?_0x45b282=_0x890cd7:_0x45b282=new b(null)['setTree'](_0x1c00c5,_0x890cd7);const _0x50cb12=_0x42cb05['serverCache']['getNode']();return _0x45b282['children']['inorderTraversal']((_0x129c79,_0x34a69e)=>{if(_0x50cb12['hasChild'](_0x129c79)){const _0x1a09ff=_0x42cb05['serverCache']['getNode']()['getImmediateChild'](_0x129c79),_0x5104b2=hr(_0x11fbdd,_0x1a09ff,_0x34a69e);_0x2d49d0=Sn(_0x11fbdd,_0x2d49d0,new C(_0x129c79),_0x5104b2,_0x1f08a5,_0x2f73b2,_0x28d5e0,_0x5b7edb);}}),_0x45b282['children']['inorderTraversal']((_0x100872,_0x362925)=>{const _0x133ebb=!_0x42cb05['serverCache']['isCompleteForChild'](_0x100872)&&_0x362925['value']===null;if(!_0x50cb12['hasChild'](_0x100872)&&!_0x133ebb){const _0x2a23db=_0x42cb05['serverCache']['getNode']()['getImmediateChild'](_0x100872),_0x3ea12b=hr(_0x11fbdd,_0x2a23db,_0x362925);_0x2d49d0=Sn(_0x11fbdd,_0x2d49d0,new C(_0x100872),_0x3ea12b,_0x1f08a5,_0x2f73b2,_0x28d5e0,_0x5b7edb);}}),_0x2d49d0;}function Pu(_0x373839,_0x306865,_0x34e1f4,_0x2e0b4c,_0x3d8ab3,_0x373dfa,_0x5b0198){if(Tn(_0x3d8ab3,_0x34e1f4)!=null)return _0x306865;const _0x4d50f0=_0x306865['serverCache']['isFiltered'](),_0x8e7491=_0x306865['serverCache'];if(_0x2e0b4c['value']!=null){if(v(_0x34e1f4)&&_0x8e7491['isFullyInitialized']()||_0x8e7491['isCompleteForPath'](_0x34e1f4))return Sn(_0x373839,_0x306865,_0x34e1f4,_0x8e7491['getNode']()['getChild'](_0x34e1f4),_0x3d8ab3,_0x373dfa,_0x4d50f0,_0x5b0198);if(v(_0x34e1f4)){let _0x447397=new b(null);return _0x8e7491['getNode']()['forEachChild'](ve,(_0x5c4ee9,_0x1fc063)=>{_0x447397=_0x447397['set'](new C(_0x5c4ee9),_0x1fc063);}),Pi(_0x373839,_0x306865,_0x34e1f4,_0x447397,_0x3d8ab3,_0x373dfa,_0x4d50f0,_0x5b0198);}else return _0x306865;}else{let _0x1c3223=new b(null);return _0x2e0b4c['foreach']((_0xd6d7ed,_0x1afc93)=>{const _0x50c03e=k(_0x34e1f4,_0xd6d7ed);_0x8e7491['isCompleteForPath'](_0x50c03e)&&(_0x1c3223=_0x1c3223['set'](_0xd6d7ed,_0x8e7491['getNode']()['getChild'](_0x50c03e)));}),Pi(_0x373839,_0x306865,_0x34e1f4,_0x1c3223,_0x3d8ab3,_0x373dfa,_0x4d50f0,_0x5b0198);}}function Nu(_0x304459,_0x599bb9,_0x304db3,_0x4753df,_0x2839a7){const _0x28e46d=_0x599bb9['serverCache'],_0x12540e=Fo(_0x599bb9,_0x28e46d['getNode'](),_0x28e46d['isFullyInitialized']()||v(_0x304db3),_0x28e46d['isFiltered']());return Go(_0x304459,_0x12540e,_0x304db3,_0x4753df,$o,_0x2839a7);}function Ou(_0x23993f,_0x160779,_0x115201,_0x9177aa,_0x5f4a7b,_0x3dad3a){let _0x27ed58;if(Tn(_0x9177aa,_0x115201)!=null)return _0x160779;{const _0x593032=new rs(_0x9177aa,_0x160779,_0x5f4a7b),_0x1356ef=_0x160779['eventCache']['getNode']();let _0x2eb1b2;if(v(_0x115201)||y(_0x115201)==='.priority'){let _0x9c3270;if(_0x160779['serverCache']['isFullyInitialized']())_0x9c3270=Cn(_0x9177aa,Ve(_0x160779));else{const _0x1b028d=_0x160779['serverCache']['getNode']();f(_0x1b028d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x9c3270=is(_0x9177aa,_0x1b028d);}_0x9c3270=_0x9c3270,_0x2eb1b2=_0x23993f['filter']['updateFullNode'](_0x1356ef,_0x9c3270,_0x3dad3a);}else{const _0x5e698d=y(_0x115201);let _0x3abfb1=ss(_0x9177aa,_0x5e698d,_0x160779['serverCache']);_0x3abfb1==null&&_0x160779['serverCache']['isCompleteForChild'](_0x5e698d)&&(_0x3abfb1=_0x1356ef['getImmediateChild'](_0x5e698d)),_0x3abfb1!=null?_0x2eb1b2=_0x23993f['filter']['updateChild'](_0x1356ef,_0x5e698d,_0x3abfb1,S(_0x115201),_0x593032,_0x3dad3a):_0x160779['eventCache']['getNode']()['hasChild'](_0x5e698d)?_0x2eb1b2=_0x23993f['filter']['updateChild'](_0x1356ef,_0x5e698d,g['EMPTY_NODE'],S(_0x115201),_0x593032,_0x3dad3a):_0x2eb1b2=_0x1356ef,_0x2eb1b2['isEmpty']()&&_0x160779['serverCache']['isFullyInitialized']()&&(_0x27ed58=Cn(_0x9177aa,Ve(_0x160779)),_0x27ed58['isLeafNode']()&&(_0x2eb1b2=_0x23993f['filter']['updateFullNode'](_0x2eb1b2,_0x27ed58,_0x3dad3a)));}return _0x27ed58=_0x160779['serverCache']['isFullyInitialized']()||Tn(_0x9177aa,w())!=null,Rt(_0x160779,_0x2eb1b2,_0x27ed58,_0x23993f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0xb197f3,_0x26b417){this['query_']=_0xb197f3,this['eventRegistrations_']=[];const _0x1b4586=this['query_']['_queryParams'],_0x1fa4bb=new Xi(_0x1b4586['getIndex']()),_0x336500=Kh(_0x1b4586);this['processor_']=Su(_0x336500);const _0x3dc432=_0x26b417['serverCache'],_0x4f4109=_0x26b417['eventCache'],_0x32539a=_0x1fa4bb['updateFullNode'](g['EMPTY_NODE'],_0x3dc432['getNode'](),null),_0x58b255=_0x336500['updateFullNode'](g['EMPTY_NODE'],_0x4f4109['getNode'](),null),_0x5d57b6=new Te(_0x32539a,_0x3dc432['isFullyInitialized'](),_0x1fa4bb['filtersNodes']()),_0x1360d5=new Te(_0x58b255,_0x4f4109['isFullyInitialized'](),_0x336500['filtersNodes']());this['viewCache_']=Un(_0x1360d5,_0x5d57b6),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x85d373){return _0x85d373['viewCache_']['serverCache']['getNode']();}function Lu(_0x475c91){return wn(_0x475c91['viewCache_']);}function xu(_0x2efd3e,_0x3a39b8){const _0x2b9384=Ve(_0x2efd3e['viewCache_']);return _0x2b9384&&(_0x2efd3e['query']['_queryParams']['loadsAllData']()||!v(_0x3a39b8)&&!_0x2b9384['getImmediateChild'](y(_0x3a39b8))['isEmpty']())?_0x2b9384['getChild'](_0x3a39b8):null;}function ur(_0x14b4d2){return _0x14b4d2['eventRegistrations_']['length']===0x0;}function Fu(_0x5aa38c,_0x1c4cc6){_0x5aa38c['eventRegistrations_']['push'](_0x1c4cc6);}function dr(_0x3329ac,_0x23c19f,_0x44c4d1){const _0x3972e0=[];if(_0x44c4d1){f(_0x23c19f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2e5b06=_0x3329ac['query']['_path'];_0x3329ac['eventRegistrations_']['forEach'](_0x488e04=>{const _0x57b43c=_0x488e04['createCancelEvent'](_0x44c4d1,_0x2e5b06);_0x57b43c&&_0x3972e0['push'](_0x57b43c);});}if(_0x23c19f){let _0x3bafd2=[];for(let _0x546a1f=0x0;_0x546a1f<_0x3329ac['eventRegistrations_']['length'];++_0x546a1f){const _0x5f2891=_0x3329ac['eventRegistrations_'][_0x546a1f];if(!_0x5f2891['matches'](_0x23c19f))_0x3bafd2['push'](_0x5f2891);else{if(_0x23c19f['hasAnyCallback']()){_0x3bafd2=_0x3bafd2['concat'](_0x3329ac['eventRegistrations_']['slice'](_0x546a1f+0x1));break;}}}_0x3329ac['eventRegistrations_']=_0x3bafd2;}else _0x3329ac['eventRegistrations_']=[];return _0x3972e0;}function fr(_0xec5789,_0x2153da,_0x57386a,_0x4acf7f){_0x2153da['type']===z['MERGE']&&_0x2153da['source']['queryId']!==null&&(f(Ve(_0xec5789['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0xec5789['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x12b47c=_0xec5789['viewCache_'],_0x2657f2=Ru(_0xec5789['processor_'],_0x12b47c,_0x2153da,_0x57386a,_0x4acf7f);return bu(_0xec5789['processor_'],_0x2657f2['viewCache']),f(_0x2657f2['viewCache']['serverCache']['isFullyInitialized']()||!_0x12b47c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xec5789['viewCache_']=_0x2657f2['viewCache'],qo(_0xec5789,_0x2657f2['changes'],_0x2657f2['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x37337e,_0x178b60){const _0x25862d=_0x37337e['viewCache_']['eventCache'],_0x4a7ec9=[];return _0x25862d['getNode']()['isLeafNode']()||_0x25862d['getNode']()['forEachChild'](R,(_0x19277d,_0x15d003)=>{_0x4a7ec9['push'](rt(_0x19277d,_0x15d003));}),_0x25862d['isFullyInitialized']()&&_0x4a7ec9['push'](Lo(_0x25862d['getNode']())),qo(_0x37337e,_0x4a7ec9,_0x25862d['getNode'](),_0x178b60);}function qo(_0x7e0df3,_0x339c33,_0x3dc566,_0x202eb2){const _0x3aa4cc=_0x202eb2?[_0x202eb2]:_0x7e0df3['eventRegistrations_'];return ru(_0x7e0df3['eventGenerator_'],_0x339c33,_0x3dc566,_0x3aa4cc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x3681b0){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x3681b0;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x502509){return _0x502509['views']['size']===0x0;}function os(_0x2cf17b,_0x890bdd,_0x4f102a,_0x8933ba){const _0x2d2fdb=_0x890bdd['source']['queryId'];if(_0x2d2fdb!==null){const _0x535696=_0x2cf17b['views']['get'](_0x2d2fdb);return f(_0x535696!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x535696,_0x890bdd,_0x4f102a,_0x8933ba);}else{let _0x22754c=[];for(const _0x258228 of _0x2cf17b['views']['values']())_0x22754c=_0x22754c['concat'](fr(_0x258228,_0x890bdd,_0x4f102a,_0x8933ba));return _0x22754c;}}function jo(_0xde6b2a,_0x3f7cd9,_0x26f6b4,_0x3e0185,_0x45eda4){const _0x1dd840=_0x3f7cd9['_queryIdentifier'],_0xedb4f1=_0xde6b2a['views']['get'](_0x1dd840);if(!_0xedb4f1){let _0xc5d4b2=Cn(_0x26f6b4,_0x45eda4?_0x3e0185:null),_0x23c012=!0x1;_0xc5d4b2?_0x23c012=!0x0:_0x3e0185 instanceof g?(_0xc5d4b2=is(_0x26f6b4,_0x3e0185),_0x23c012=!0x1):(_0xc5d4b2=g['EMPTY_NODE'],_0x23c012=!0x1);const _0x8e1cf0=Un(new Te(_0xc5d4b2,_0x23c012,!0x1),new Te(_0x3e0185,_0x45eda4,!0x1));return new Du(_0x3f7cd9,_0x8e1cf0);}return _0xedb4f1;}function Hu(_0x227ff2,_0x31a899,_0x3ceb9a,_0x23e7f9,_0x1701f4,_0x47ac61){const _0x3af56f=jo(_0x227ff2,_0x31a899,_0x23e7f9,_0x1701f4,_0x47ac61);return _0x227ff2['views']['has'](_0x31a899['_queryIdentifier'])||_0x227ff2['views']['set'](_0x31a899['_queryIdentifier'],_0x3af56f),Fu(_0x3af56f,_0x3ceb9a),Uu(_0x3af56f,_0x3ceb9a);}function $u(_0xa09302,_0x3383a6,_0x20cb1e,_0x4ffb4a){const _0x17ad7b=_0x3383a6['_queryIdentifier'],_0x12ec62=[];let _0x5e2594=[];const _0x4cad8a=Se(_0xa09302);if(_0x17ad7b==='default'){for(const [_0x5d3d9d,_0x4536f9]of _0xa09302['views']['entries']())_0x5e2594=_0x5e2594['concat'](dr(_0x4536f9,_0x20cb1e,_0x4ffb4a)),ur(_0x4536f9)&&(_0xa09302['views']['delete'](_0x5d3d9d),_0x4536f9['query']['_queryParams']['loadsAllData']()||_0x12ec62['push'](_0x4536f9['query']));}else{const _0x556753=_0xa09302['views']['get'](_0x17ad7b);_0x556753&&(_0x5e2594=_0x5e2594['concat'](dr(_0x556753,_0x20cb1e,_0x4ffb4a)),ur(_0x556753)&&(_0xa09302['views']['delete'](_0x17ad7b),_0x556753['query']['_queryParams']['loadsAllData']()||_0x12ec62['push'](_0x556753['query'])));}return _0x4cad8a&&!Se(_0xa09302)&&_0x12ec62['push'](new(Bu())(_0x3383a6['_repo'],_0x3383a6['_path'])),{'removed':_0x12ec62,'events':_0x5e2594};}function Ko(_0x38d5cd){const _0x552d7f=[];for(const _0x1ddf11 of _0x38d5cd['views']['values']())_0x1ddf11['query']['_queryParams']['loadsAllData']()||_0x552d7f['push'](_0x1ddf11);return _0x552d7f;}function Ie(_0x5b967,_0x7fd18a){let _0x28592e=null;for(const _0x3e80a2 of _0x5b967['views']['values']())_0x28592e=_0x28592e||xu(_0x3e80a2,_0x7fd18a);return _0x28592e;}function Yo(_0x28746d,_0x48bd7d){if(_0x48bd7d['_queryParams']['loadsAllData']())return Bn(_0x28746d);{const _0x10e02a=_0x48bd7d['_queryIdentifier'];return _0x28746d['views']['get'](_0x10e02a);}}function Qo(_0x5f5282,_0x17917e){return Yo(_0x5f5282,_0x17917e)!=null;}function Se(_0x5aedcc){return Bn(_0x5aedcc)!=null;}function Bn(_0x3fde14){for(const _0x2c61dd of _0x3fde14['views']['values']())if(_0x2c61dd['query']['_queryParams']['loadsAllData']())return _0x2c61dd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2f4ea6){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2f4ea6;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x38cdda){this['listenProvider_']=_0x38cdda,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2fed5c,_0x3bf7fb,_0x2d3d91,_0x729246,_0x3ee056){return lu(_0x2fed5c['pendingWriteTree_'],_0x3bf7fb,_0x2d3d91,_0x729246,_0x3ee056),_0x3ee056?_t(_0x2fed5c,new Be(es(),_0x3bf7fb,_0x2d3d91)):[];}function ju(_0x29a326,_0x5129b0,_0x475cd3,_0x3fcf12){hu(_0x29a326['pendingWriteTree_'],_0x5129b0,_0x475cd3,_0x3fcf12);const _0x1b16de=b['fromObject'](_0x475cd3);return _t(_0x29a326,new ot(es(),_0x5129b0,_0x1b16de));}function _e(_0x25a765,_0x97cfb7,_0x333b20=!0x1){const _0x5a4c11=uu(_0x25a765['pendingWriteTree_'],_0x97cfb7);if(du(_0x25a765['pendingWriteTree_'],_0x97cfb7)){let _0x6a93b=new b(null);return _0x5a4c11['snap']!=null?_0x6a93b=_0x6a93b['set'](w(),!0x0):x(_0x5a4c11['children'],_0x4b29c3=>{_0x6a93b=_0x6a93b['set'](new C(_0x4b29c3),!0x0);}),_t(_0x25a765,new In(_0x5a4c11['path'],_0x6a93b,_0x333b20));}else return[];}function Yt(_0x18d1d0,_0x18838b,_0x5941ef){return _t(_0x18d1d0,new Be(ts(),_0x18838b,_0x5941ef));}function Ku(_0x19e721,_0x9ce9e1,_0xbab6b){const _0x3f6537=b['fromObject'](_0xbab6b);return _t(_0x19e721,new ot(ts(),_0x9ce9e1,_0x3f6537));}function Yu(_0x17876d,_0x23267d){return _t(_0x17876d,new Ut(ts(),_0x23267d));}function Qu(_0x4a844e,_0x12f7ea,_0x2a7be4){const _0x32c54d=cs(_0x4a844e,_0x2a7be4);if(_0x32c54d){const _0xb36ba6=ls(_0x32c54d),_0x35829a=_0xb36ba6['path'],_0xdc4270=_0xb36ba6['queryId'],_0x373f97=F(_0x35829a,_0x12f7ea),_0x105792=new Ut(ns(_0xdc4270),_0x373f97);return hs(_0x4a844e,_0x35829a,_0x105792);}else return[];}function An(_0x4fc88b,_0x4fb8d6,_0x1b5958,_0x1b4bf6,_0x21fff1=!0x1){const _0x1e6534=_0x4fb8d6['_path'],_0x5289ae=_0x4fc88b['syncPointTree_']['get'](_0x1e6534);let _0x49093b=[];if(_0x5289ae&&(_0x4fb8d6['_queryIdentifier']==='default'||Qo(_0x5289ae,_0x4fb8d6))){const _0x2d5322=$u(_0x5289ae,_0x4fb8d6,_0x1b5958,_0x1b4bf6);Vu(_0x5289ae)&&(_0x4fc88b['syncPointTree_']=_0x4fc88b['syncPointTree_']['remove'](_0x1e6534));const _0x3661ce=_0x2d5322['removed'];if(_0x49093b=_0x2d5322['events'],!_0x21fff1){const _0x3085b3=_0x3661ce['findIndex'](_0xbdd603=>_0xbdd603['_queryParams']['loadsAllData']())!==-0x1,_0x4682c5=_0x4fc88b['syncPointTree_']['findOnPath'](_0x1e6534,(_0x4bfcfc,_0x540e8a)=>Se(_0x540e8a));if(_0x3085b3&&!_0x4682c5){const _0x6b17ef=_0x4fc88b['syncPointTree_']['subtree'](_0x1e6534);if(!_0x6b17ef['isEmpty']()){const _0x85a8f=Zu(_0x6b17ef);for(let _0x517708=0x0;_0x517708<_0x85a8f['length'];++_0x517708){const _0x28589e=_0x85a8f[_0x517708],_0x327b7d=_0x28589e['query'],_0x6a897c=ea(_0x4fc88b,_0x28589e);_0x4fc88b['listenProvider_']['startListening'](kt(_0x327b7d),Wt(_0x4fc88b,_0x327b7d),_0x6a897c['hashFn'],_0x6a897c['onComplete']);}}}!_0x4682c5&&_0x3661ce['length']>0x0&&!_0x1b4bf6&&(_0x3085b3?_0x4fc88b['listenProvider_']['stopListening'](kt(_0x4fb8d6),null):_0x3661ce['forEach'](_0x52777a=>{const _0x57b396=_0x4fc88b['queryToTagMap']['get'](Hn(_0x52777a));_0x4fc88b['listenProvider_']['stopListening'](kt(_0x52777a),_0x57b396);}));}ed(_0x4fc88b,_0x3661ce);}return _0x49093b;}function Jo(_0x525390,_0x110a45,_0x520cb6,_0x2d6cb2){const _0x2fdb01=cs(_0x525390,_0x2d6cb2);if(_0x2fdb01!=null){const _0x3c25b9=ls(_0x2fdb01),_0x4079ea=_0x3c25b9['path'],_0xa28b32=_0x3c25b9['queryId'],_0x17224c=F(_0x4079ea,_0x110a45),_0x16ee47=new Be(ns(_0xa28b32),_0x17224c,_0x520cb6);return hs(_0x525390,_0x4079ea,_0x16ee47);}else return[];}function Ju(_0x3f8547,_0x211aad,_0x420295,_0x2a9769){const _0x4c64b3=cs(_0x3f8547,_0x2a9769);if(_0x4c64b3){const _0x5b9ee7=ls(_0x4c64b3),_0x2418e1=_0x5b9ee7['path'],_0x354467=_0x5b9ee7['queryId'],_0x34baf4=F(_0x2418e1,_0x211aad),_0x25f122=b['fromObject'](_0x420295),_0x103529=new ot(ns(_0x354467),_0x34baf4,_0x25f122);return hs(_0x3f8547,_0x2418e1,_0x103529);}else return[];}function Ni(_0x276015,_0x127567,_0x4091cf,_0x56a87f=!0x1){const _0x3b8686=_0x127567['_path'];let _0x264b40=null,_0x13a8ae=!0x1;_0x276015['syncPointTree_']['foreachOnPath'](_0x3b8686,(_0x509465,_0x251d48)=>{const _0xcece49=F(_0x509465,_0x3b8686);_0x264b40=_0x264b40||Ie(_0x251d48,_0xcece49),_0x13a8ae=_0x13a8ae||Se(_0x251d48);});let _0x4cdd8f=_0x276015['syncPointTree_']['get'](_0x3b8686);_0x4cdd8f?(_0x13a8ae=_0x13a8ae||Se(_0x4cdd8f),_0x264b40=_0x264b40||Ie(_0x4cdd8f,w())):(_0x4cdd8f=new zo(),_0x276015['syncPointTree_']=_0x276015['syncPointTree_']['set'](_0x3b8686,_0x4cdd8f));let _0x19045d;_0x264b40!=null?_0x19045d=!0x0:(_0x19045d=!0x1,_0x264b40=g['EMPTY_NODE'],_0x276015['syncPointTree_']['subtree'](_0x3b8686)['foreachChild']((_0x4816e8,_0x7701ee)=>{const _0x6feb57=Ie(_0x7701ee,w());_0x6feb57&&(_0x264b40=_0x264b40['updateImmediateChild'](_0x4816e8,_0x6feb57));}));const _0x6846d3=Qo(_0x4cdd8f,_0x127567);if(!_0x6846d3&&!_0x127567['_queryParams']['loadsAllData']()){const _0x5a20f5=Hn(_0x127567);f(!_0x276015['queryToTagMap']['has'](_0x5a20f5),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1e826d=td();_0x276015['queryToTagMap']['set'](_0x5a20f5,_0x1e826d),_0x276015['tagToQueryMap']['set'](_0x1e826d,_0x5a20f5);}const _0x5cb81e=Wn(_0x276015['pendingWriteTree_'],_0x3b8686);let _0x2fc422=Hu(_0x4cdd8f,_0x127567,_0x4091cf,_0x5cb81e,_0x264b40,_0x19045d);if(!_0x6846d3&&!_0x13a8ae&&!_0x56a87f){const _0x397eba=Yo(_0x4cdd8f,_0x127567);_0x2fc422=_0x2fc422['concat'](nd(_0x276015,_0x127567,_0x397eba));}return _0x2fc422;}function Vn(_0x431c20,_0x87c622,_0x388947){const _0x5e8a54=_0x431c20['pendingWriteTree_'],_0x24db59=_0x431c20['syncPointTree_']['findOnPath'](_0x87c622,(_0xc04e24,_0x8521dc)=>{const _0x5001c1=F(_0xc04e24,_0x87c622),_0x5a260a=Ie(_0x8521dc,_0x5001c1);if(_0x5a260a)return _0x5a260a;});return Bo(_0x5e8a54,_0x87c622,_0x24db59,_0x388947,!0x0);}function Xu(_0x3ff1bb,_0x2403bc){const _0x1fc4eb=_0x2403bc['_path'];let _0x33def4=null;_0x3ff1bb['syncPointTree_']['foreachOnPath'](_0x1fc4eb,(_0x2b1afc,_0x4de16e)=>{const _0x54deee=F(_0x2b1afc,_0x1fc4eb);_0x33def4=_0x33def4||Ie(_0x4de16e,_0x54deee);});let _0x22c531=_0x3ff1bb['syncPointTree_']['get'](_0x1fc4eb);_0x22c531?_0x33def4=_0x33def4||Ie(_0x22c531,w()):(_0x22c531=new zo(),_0x3ff1bb['syncPointTree_']=_0x3ff1bb['syncPointTree_']['set'](_0x1fc4eb,_0x22c531));const _0x100fb2=_0x33def4!=null,_0x4fc8e7=_0x100fb2?new Te(_0x33def4,!0x0,!0x1):null,_0x259649=Wn(_0x3ff1bb['pendingWriteTree_'],_0x2403bc['_path']),_0x119262=jo(_0x22c531,_0x2403bc,_0x259649,_0x100fb2?_0x4fc8e7['getNode']():g['EMPTY_NODE'],_0x100fb2);return Lu(_0x119262);}function _t(_0x5f4dd9,_0x398a83){return Xo(_0x398a83,_0x5f4dd9['syncPointTree_'],null,Wn(_0x5f4dd9['pendingWriteTree_'],w()));}function Xo(_0x2953f6,_0x36a7de,_0x37c554,_0x594a09){if(v(_0x2953f6['path']))return Zo(_0x2953f6,_0x36a7de,_0x37c554,_0x594a09);{const _0x146270=_0x36a7de['get'](w());_0x37c554==null&&_0x146270!=null&&(_0x37c554=Ie(_0x146270,w()));let _0x1f91d9=[];const _0xb3ab3e=y(_0x2953f6['path']),_0x2582e3=_0x2953f6['operationForChild'](_0xb3ab3e),_0x1df51e=_0x36a7de['children']['get'](_0xb3ab3e);if(_0x1df51e&&_0x2582e3){const _0x4ccf8c=_0x37c554?_0x37c554['getImmediateChild'](_0xb3ab3e):null,_0x4bb28b=Vo(_0x594a09,_0xb3ab3e);_0x1f91d9=_0x1f91d9['concat'](Xo(_0x2582e3,_0x1df51e,_0x4ccf8c,_0x4bb28b));}return _0x146270&&(_0x1f91d9=_0x1f91d9['concat'](os(_0x146270,_0x2953f6,_0x594a09,_0x37c554))),_0x1f91d9;}}function Zo(_0x10482,_0x2d351f,_0x280085,_0x28e539){const _0x630014=_0x2d351f['get'](w());_0x280085==null&&_0x630014!=null&&(_0x280085=Ie(_0x630014,w()));let _0x5ebd52=[];return _0x2d351f['children']['inorderTraversal']((_0x536750,_0x133679)=>{const _0x54819c=_0x280085?_0x280085['getImmediateChild'](_0x536750):null,_0x30d8c8=Vo(_0x28e539,_0x536750),_0x2346d5=_0x10482['operationForChild'](_0x536750);_0x2346d5&&(_0x5ebd52=_0x5ebd52['concat'](Zo(_0x2346d5,_0x133679,_0x54819c,_0x30d8c8)));}),_0x630014&&(_0x5ebd52=_0x5ebd52['concat'](os(_0x630014,_0x10482,_0x28e539,_0x280085))),_0x5ebd52;}function ea(_0x164b78,_0x26f1b9){const _0x2ac4a9=_0x26f1b9['query'],_0x30cbcb=Wt(_0x164b78,_0x2ac4a9);return{'hashFn':()=>(Mu(_0x26f1b9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x25ee5e=>{if(_0x25ee5e==='ok')return _0x30cbcb?Qu(_0x164b78,_0x2ac4a9['_path'],_0x30cbcb):Yu(_0x164b78,_0x2ac4a9['_path']);{const _0xf999d2=Kl(_0x25ee5e,_0x2ac4a9);return An(_0x164b78,_0x2ac4a9,null,_0xf999d2);}}};}function Wt(_0x38ecc5,_0x2c7f31){const _0x297ec2=Hn(_0x2c7f31);return _0x38ecc5['queryToTagMap']['get'](_0x297ec2);}function Hn(_0x5142c6){return _0x5142c6['_path']['toString']()+'$'+_0x5142c6['_queryIdentifier'];}function cs(_0x3f44a0,_0x4ccc4f){return _0x3f44a0['tagToQueryMap']['get'](_0x4ccc4f);}function ls(_0xd3de85){const _0x576f55=_0xd3de85['indexOf']('$');return f(_0x576f55!==-0x1&&_0x576f55<_0xd3de85['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xd3de85['substr'](_0x576f55+0x1),'path':new C(_0xd3de85['substr'](0x0,_0x576f55))};}function hs(_0x441e17,_0x2d6447,_0x432663){const _0x5009c8=_0x441e17['syncPointTree_']['get'](_0x2d6447);f(_0x5009c8,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1ec720=Wn(_0x441e17['pendingWriteTree_'],_0x2d6447);return os(_0x5009c8,_0x432663,_0x1ec720,null);}function Zu(_0xcbc47f){return _0xcbc47f['fold']((_0x2d92cc,_0x4aa44f,_0x1ffdd5)=>{if(_0x4aa44f&&Se(_0x4aa44f))return[Bn(_0x4aa44f)];{let _0x2f8ebb=[];return _0x4aa44f&&(_0x2f8ebb=Ko(_0x4aa44f)),x(_0x1ffdd5,(_0x589d4a,_0x4fc660)=>{_0x2f8ebb=_0x2f8ebb['concat'](_0x4fc660);}),_0x2f8ebb;}});}function kt(_0x25952b){return _0x25952b['_queryParams']['loadsAllData']()&&!_0x25952b['_queryParams']['isDefault']()?new(qu())(_0x25952b['_repo'],_0x25952b['_path']):_0x25952b;}function ed(_0x5ba590,_0x5cedb1){for(let _0x304626=0x0;_0x304626<_0x5cedb1['length'];++_0x304626){const _0x43974c=_0x5cedb1[_0x304626];if(!_0x43974c['_queryParams']['loadsAllData']()){const _0x67390a=Hn(_0x43974c),_0x3f9785=_0x5ba590['queryToTagMap']['get'](_0x67390a);_0x5ba590['queryToTagMap']['delete'](_0x67390a),_0x5ba590['tagToQueryMap']['delete'](_0x3f9785);}}}function td(){return zu++;}function nd(_0x2d03f,_0x222385,_0x7d084b){const _0x8c790e=_0x222385['_path'],_0x1c73d2=Wt(_0x2d03f,_0x222385),_0x29c7f8=ea(_0x2d03f,_0x7d084b),_0x497abf=_0x2d03f['listenProvider_']['startListening'](kt(_0x222385),_0x1c73d2,_0x29c7f8['hashFn'],_0x29c7f8['onComplete']),_0x88df4f=_0x2d03f['syncPointTree_']['subtree'](_0x8c790e);if(_0x1c73d2)f(!Se(_0x88df4f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x400a4f=_0x88df4f['fold']((_0x49d371,_0x4656c8,_0x4b8932)=>{if(!v(_0x49d371)&&_0x4656c8&&Se(_0x4656c8))return[Bn(_0x4656c8)['query']];{let _0x54914e=[];return _0x4656c8&&(_0x54914e=_0x54914e['concat'](Ko(_0x4656c8)['map'](_0xae9ca3=>_0xae9ca3['query']))),x(_0x4b8932,(_0x2a3d3c,_0x54e4e9)=>{_0x54914e=_0x54914e['concat'](_0x54e4e9);}),_0x54914e;}});for(let _0x410173=0x0;_0x410173<_0x400a4f['length'];++_0x410173){const _0x499a6a=_0x400a4f[_0x410173];_0x2d03f['listenProvider_']['stopListening'](kt(_0x499a6a),Wt(_0x2d03f,_0x499a6a));}}return _0x497abf;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x509973){this['node_']=_0x509973;}['getImmediateChild'](_0x24d580){const _0x5ada21=this['node_']['getImmediateChild'](_0x24d580);return new us(_0x5ada21);}['node'](){return this['node_'];}}class ds{constructor(_0x5383eb,_0x116990){this['syncTree_']=_0x5383eb,this['path_']=_0x116990;}['getImmediateChild'](_0x409c6f){const _0x128e57=k(this['path_'],_0x409c6f);return new ds(this['syncTree_'],_0x128e57);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x1e5685){return _0x1e5685=_0x1e5685||{},_0x1e5685['timestamp']=_0x1e5685['timestamp']||new Date()['getTime'](),_0x1e5685;},_r=function(_0x5cdc3a,_0x529e5c,_0x4d7b81){if(!_0x5cdc3a||typeof _0x5cdc3a!='object')return _0x5cdc3a;if(f('.sv'in _0x5cdc3a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5cdc3a['.sv']=='string')return sd(_0x5cdc3a['.sv'],_0x529e5c,_0x4d7b81);if(typeof _0x5cdc3a['.sv']=='object')return rd(_0x5cdc3a['.sv'],_0x529e5c);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5cdc3a,null,0x2));},sd=function(_0x6e7822,_0x5114d9,_0x3700c2){switch(_0x6e7822){case'timestamp':return _0x3700c2['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x6e7822);}},rd=function(_0x499c7e,_0x55bbba,_0x211b0b){_0x499c7e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x499c7e,null,0x2));const _0x1372be=_0x499c7e['increment'];typeof _0x1372be!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1372be);const _0x5e4c6a=_0x55bbba['node']();if(f(_0x5e4c6a!==null&&typeof _0x5e4c6a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5e4c6a['isLeafNode']())return _0x1372be;const _0x20b583=_0x5e4c6a['getValue']();return typeof _0x20b583!='number'?_0x1372be:_0x20b583+_0x1372be;},ta=function(_0x1c16f6,_0x9395be,_0x34d8c1,_0x1c215e){return ps(_0x9395be,new ds(_0x34d8c1,_0x1c16f6),_0x1c215e);},fs=function(_0x267b93,_0x54877c,_0x3876f3){return ps(_0x267b93,new us(_0x54877c),_0x3876f3);};function ps(_0x322d4f,_0x2acfe3,_0x2b599b){const _0x193482=_0x322d4f['getPriority']()['val'](),_0x34c042=_r(_0x193482,_0x2acfe3['getImmediateChild']('.priority'),_0x2b599b);let _0x4117f9;if(_0x322d4f['isLeafNode']()){const _0x3b9681=_0x322d4f,_0x539414=_r(_0x3b9681['getValue'](),_0x2acfe3,_0x2b599b);return _0x539414!==_0x3b9681['getValue']()||_0x34c042!==_0x3b9681['getPriority']()['val']()?new D(_0x539414,A(_0x34c042)):_0x322d4f;}else{const _0x436710=_0x322d4f;return _0x4117f9=_0x436710,_0x34c042!==_0x436710['getPriority']()['val']()&&(_0x4117f9=_0x4117f9['updatePriority'](new D(_0x34c042))),_0x436710['forEachChild'](R,(_0x5036be,_0x4be5b1)=>{const _0x169ec0=ps(_0x4be5b1,_0x2acfe3['getImmediateChild'](_0x5036be),_0x2b599b);_0x169ec0!==_0x4be5b1&&(_0x4117f9=_0x4117f9['updateImmediateChild'](_0x5036be,_0x169ec0));}),_0x4117f9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x5bf5c3='',_0x418740=null,_0xcb7538={'children':{},'childCount':0x0}){this['name']=_0x5bf5c3,this['parent']=_0x418740,this['node']=_0xcb7538;}}function $n(_0x4c30fa,_0x29f393){let _0x3c16b0=_0x29f393 instanceof C?_0x29f393:new C(_0x29f393),_0x496674=_0x4c30fa,_0x1222d4=y(_0x3c16b0);for(;_0x1222d4!==null;){const _0x4e173a=Le(_0x496674['node']['children'],_0x1222d4)||{'children':{},'childCount':0x0};_0x496674=new _s(_0x1222d4,_0x496674,_0x4e173a),_0x3c16b0=S(_0x3c16b0),_0x1222d4=y(_0x3c16b0);}return _0x496674;}function je(_0x11be94){return _0x11be94['node']['value'];}function gs(_0x4b8aba,_0x19bc49){_0x4b8aba['node']['value']=_0x19bc49,Oi(_0x4b8aba);}function na(_0x9d637d){return _0x9d637d['node']['childCount']>0x0;}function od(_0x51c22f){return je(_0x51c22f)===void 0x0&&!na(_0x51c22f);}function Gn(_0x28a849,_0x11e79d){x(_0x28a849['node']['children'],(_0x1ecc46,_0x28773d)=>{_0x11e79d(new _s(_0x1ecc46,_0x28a849,_0x28773d));});}function ia(_0x1db39d,_0x4edf68,_0xb03b81,_0x25e5a7){_0xb03b81&&_0x4edf68(_0x1db39d),Gn(_0x1db39d,_0x540b84=>{ia(_0x540b84,_0x4edf68,!0x0);});}function ad(_0x482826,_0x3bc612,_0x22f601){let _0x5332fb=_0x482826['parent'];for(;_0x5332fb!==null;){if(_0x3bc612(_0x5332fb))return!0x0;_0x5332fb=_0x5332fb['parent'];}return!0x1;}function Qt(_0x2737b8){return new C(_0x2737b8['parent']===null?_0x2737b8['name']:Qt(_0x2737b8['parent'])+'/'+_0x2737b8['name']);}function Oi(_0x2759bb){_0x2759bb['parent']!==null&&cd(_0x2759bb['parent'],_0x2759bb['name'],_0x2759bb);}function cd(_0x57db1e,_0x4215a7,_0x3e47ab){const _0x2485e2=od(_0x3e47ab),_0x3e2413=Q(_0x57db1e['node']['children'],_0x4215a7);_0x2485e2&&_0x3e2413?(delete _0x57db1e['node']['children'][_0x4215a7],_0x57db1e['node']['childCount']--,Oi(_0x57db1e)):!_0x2485e2&&!_0x3e2413&&(_0x57db1e['node']['children'][_0x4215a7]=_0x3e47ab['node'],_0x57db1e['node']['childCount']++,Oi(_0x57db1e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x55ce3b){return typeof _0x55ce3b=='string'&&_0x55ce3b['length']!==0x0&&!ld['test'](_0x55ce3b);},sa=function(_0xe180fa){return typeof _0xe180fa=='string'&&_0xe180fa['length']!==0x0&&!hd['test'](_0xe180fa);},ud=function(_0x5ba22d){return _0x5ba22d&&(_0x5ba22d=_0x5ba22d['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x5ba22d);},Bt=function(_0x250687){return _0x250687===null||typeof _0x250687=='string'||typeof _0x250687=='number'&&!xn(_0x250687)||_0x250687&&typeof _0x250687=='object'&&Q(_0x250687,'.sv');},He=function(_0x4229f9,_0x577413,_0x8e0479,_0x11f2cd){_0x11f2cd&&_0x577413===void 0x0||Jt(it(_0x4229f9,'value'),_0x577413,_0x8e0479);},Jt=function(_0xf54e58,_0x3c878e,_0x2a8bf8){const _0xc92a44=_0x2a8bf8 instanceof C?new Ah(_0x2a8bf8,_0xf54e58):_0x2a8bf8;if(_0x3c878e===void 0x0)throw new Error(_0xf54e58+'contains\x20undefined\x20'+Oe(_0xc92a44));if(typeof _0x3c878e=='function')throw new Error(_0xf54e58+'contains\x20a\x20function\x20'+Oe(_0xc92a44)+'\x20with\x20contents\x20=\x20'+_0x3c878e['toString']());if(xn(_0x3c878e))throw new Error(_0xf54e58+'contains\x20'+_0x3c878e['toString']()+'\x20'+Oe(_0xc92a44));if(typeof _0x3c878e=='string'&&_0x3c878e['length']>ui/0x3&&Ln(_0x3c878e)>ui)throw new Error(_0xf54e58+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0xc92a44)+'\x20(\x27'+_0x3c878e['substring'](0x0,0x32)+'...\x27)');if(_0x3c878e&&typeof _0x3c878e=='object'){let _0x35ce94=!0x1,_0x5f4a8b=!0x1;if(x(_0x3c878e,(_0x55c295,_0x25f3c8)=>{if(_0x55c295==='.value')_0x35ce94=!0x0;else{if(_0x55c295!=='.priority'&&_0x55c295!=='.sv'&&(_0x5f4a8b=!0x0,!ms(_0x55c295)))throw new Error(_0xf54e58+'\x20contains\x20an\x20invalid\x20key\x20('+_0x55c295+')\x20'+Oe(_0xc92a44)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xc92a44,_0x55c295),Jt(_0xf54e58,_0x25f3c8,_0xc92a44),Ph(_0xc92a44);}),_0x35ce94&&_0x5f4a8b)throw new Error(_0xf54e58+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0xc92a44)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x25ef3c,_0x14cbc3){let _0x57c8cf,_0xc63792;for(_0x57c8cf=0x0;_0x57c8cf<_0x14cbc3['length'];_0x57c8cf++){_0xc63792=_0x14cbc3[_0x57c8cf];const _0x1e2206=Mt(_0xc63792);for(let _0x1eb2a5=0x0;_0x1eb2a5<_0x1e2206['length'];_0x1eb2a5++)if(!(_0x1e2206[_0x1eb2a5]==='.priority'&&_0x1eb2a5===_0x1e2206['length']-0x1)){if(!ms(_0x1e2206[_0x1eb2a5]))throw new Error(_0x25ef3c+'contains\x20an\x20invalid\x20key\x20('+_0x1e2206[_0x1eb2a5]+')\x20in\x20path\x20'+_0xc63792['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x14cbc3['sort'](Rh);let _0x3905d1=null;for(_0x57c8cf=0x0;_0x57c8cf<_0x14cbc3['length'];_0x57c8cf++){if(_0xc63792=_0x14cbc3[_0x57c8cf],_0x3905d1!==null&&G(_0x3905d1,_0xc63792))throw new Error(_0x25ef3c+'contains\x20a\x20path\x20'+_0x3905d1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xc63792['toString']());_0x3905d1=_0xc63792;}},ra=function(_0x519650,_0x1ccbd4,_0x10995c,_0x479ce7){const _0x156861=it(_0x519650,'values');if(!(_0x1ccbd4&&typeof _0x1ccbd4=='object')||Array['isArray'](_0x1ccbd4))throw new Error(_0x156861+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4a08f9=[];x(_0x1ccbd4,(_0x42ab44,_0x3170d7)=>{const _0x351afa=new C(_0x42ab44);if(Jt(_0x156861,_0x3170d7,k(_0x10995c,_0x351afa)),ji(_0x351afa)==='.priority'&&!Bt(_0x3170d7))throw new Error(_0x156861+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x351afa['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4a08f9['push'](_0x351afa);}),dd(_0x156861,_0x4a08f9);},fd=function(_0x2bef68,_0xdbd8c4,_0x494b76){if(xn(_0xdbd8c4))throw new Error(it(_0x2bef68,'priority')+'is\x20'+_0xdbd8c4['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xdbd8c4))throw new Error(it(_0x2bef68,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x3ad7c6,_0x3e70aa,_0x3e5629,_0x1c7355){if(!sa(_0x3e5629))throw new Error(it(_0x3ad7c6,_0x3e70aa)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3e5629+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x476ecb,_0x1560b9,_0x5cdad8,_0x39a11a){_0x5cdad8&&(_0x5cdad8=_0x5cdad8['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x476ecb,_0x1560b9,_0x5cdad8);},Me=function(_0x2e3921,_0x3c001d){if(y(_0x3c001d)==='.info')throw new Error(_0x2e3921+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0xffe4cc,_0x5a3e4d){const _0x3b7ad5=_0x5a3e4d['path']['toString']();if(typeof _0x5a3e4d['repoInfo']['host']!='string'||_0x5a3e4d['repoInfo']['host']['length']===0x0||!ms(_0x5a3e4d['repoInfo']['namespace'])&&_0x5a3e4d['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3b7ad5['length']!==0x0&&!ud(_0x3b7ad5))throw new Error(it(_0xffe4cc,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x189831,_0x409045){let _0x29dba8=null;for(let _0x38e50e=0x0;_0x38e50e<_0x409045['length'];_0x38e50e++){const _0x4e026c=_0x409045[_0x38e50e],_0x24419a=_0x4e026c['getPath']();_0x29dba8!==null&&!Ki(_0x24419a,_0x29dba8['path'])&&(_0x189831['eventLists_']['push'](_0x29dba8),_0x29dba8=null),_0x29dba8===null&&(_0x29dba8={'events':[],'path':_0x24419a}),_0x29dba8['events']['push'](_0x4e026c);}_0x29dba8&&_0x189831['eventLists_']['push'](_0x29dba8);}function oa(_0x492cf4,_0x376707,_0x2563c1){qn(_0x492cf4,_0x2563c1),aa(_0x492cf4,_0x27503d=>Ki(_0x27503d,_0x376707));}function V(_0x1bb68f,_0x28656c,_0x84a9e8){qn(_0x1bb68f,_0x84a9e8),aa(_0x1bb68f,_0x2657d2=>G(_0x2657d2,_0x28656c)||G(_0x28656c,_0x2657d2));}function aa(_0x306452,_0x433ef8){_0x306452['recursionDepth_']++;let _0x2adc09=!0x0;for(let _0x23fb90=0x0;_0x23fb90<_0x306452['eventLists_']['length'];_0x23fb90++){const _0x31da2e=_0x306452['eventLists_'][_0x23fb90];if(_0x31da2e){const _0x2290d4=_0x31da2e['path'];_0x433ef8(_0x2290d4)?(md(_0x306452['eventLists_'][_0x23fb90]),_0x306452['eventLists_'][_0x23fb90]=null):_0x2adc09=!0x1;}}_0x2adc09&&(_0x306452['eventLists_']=[]),_0x306452['recursionDepth_']--;}function md(_0x2b3a11){for(let _0x5a845f=0x0;_0x5a845f<_0x2b3a11['events']['length'];_0x5a845f++){const _0x1edebd=_0x2b3a11['events'][_0x5a845f];if(_0x1edebd!==null){_0x2b3a11['events'][_0x5a845f]=null;const _0x41d28b=_0x1edebd['getEventRunner']();St&&L('event:\x20'+_0x1edebd['toString']()),ft(_0x41d28b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x509f10,_0x3ec028,_0x3a89bb,_0x50970b){this['repoInfo_']=_0x509f10,this['forceRestClient_']=_0x3ec028,this['authTokenProvider_']=_0x3a89bb,this['appCheckProvider_']=_0x50970b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x37761a,_0x1087f3,_0x3be8eb){if(_0x37761a['stats_']=qi(_0x37761a['repoInfo_']),_0x37761a['forceRestClient_']||Xl())_0x37761a['server_']=new vn(_0x37761a['repoInfo_'],(_0x3cceb5,_0x271acc,_0x34717a,_0x56f09f)=>{gr(_0x37761a,_0x3cceb5,_0x271acc,_0x34717a,_0x56f09f);},_0x37761a['authTokenProvider_'],_0x37761a['appCheckProvider_']),setTimeout(()=>mr(_0x37761a,!0x0),0x0);else{if(typeof _0x3be8eb<'u'&&_0x3be8eb!==null){if(typeof _0x3be8eb!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3be8eb);}catch(_0x1d31b9){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1d31b9);}}_0x37761a['persistentConnection_']=new se(_0x37761a['repoInfo_'],_0x1087f3,(_0x42a5ab,_0x475788,_0x217afd,_0x4f7020)=>{gr(_0x37761a,_0x42a5ab,_0x475788,_0x217afd,_0x4f7020);},_0x39928b=>{mr(_0x37761a,_0x39928b);},_0x150de3=>{Id(_0x37761a,_0x150de3);},_0x37761a['authTokenProvider_'],_0x37761a['appCheckProvider_'],_0x3be8eb),_0x37761a['server_']=_0x37761a['persistentConnection_'];}_0x37761a['authTokenProvider_']['addTokenChangeListener'](_0x59bb9e=>{_0x37761a['server_']['refreshAuthToken'](_0x59bb9e);}),_0x37761a['appCheckProvider_']['addTokenChangeListener'](_0x44a03f=>{_0x37761a['server_']['refreshAppCheckToken'](_0x44a03f['token']);}),_0x37761a['statsReporter_']=ih(_0x37761a['repoInfo_'],()=>new iu(_0x37761a['stats_'],_0x37761a['server_'])),_0x37761a['infoData_']=new Xh(),_0x37761a['infoSyncTree_']=new pr({'startListening':(_0x42d8ef,_0x33410b,_0x612316,_0xc63e9f)=>{let _0x48a33d=[];const _0x1d33d2=_0x37761a['infoData_']['getNode'](_0x42d8ef['_path']);return _0x1d33d2['isEmpty']()||(_0x48a33d=Yt(_0x37761a['infoSyncTree_'],_0x42d8ef['_path'],_0x1d33d2),setTimeout(()=>{_0xc63e9f('ok');},0x0)),_0x48a33d;},'stopListening':()=>{}}),vs(_0x37761a,'connected',!0x1),_0x37761a['serverSyncTree_']=new pr({'startListening':(_0x1d6d6d,_0x283f3f,_0x1012b3,_0xc9be1e)=>(_0x37761a['server_']['listen'](_0x1d6d6d,_0x1012b3,_0x283f3f,(_0x19c31c,_0x438103)=>{const _0x4e90aa=_0xc9be1e(_0x19c31c,_0x438103);V(_0x37761a['eventQueue_'],_0x1d6d6d['_path'],_0x4e90aa);}),[]),'stopListening':(_0x59080d,_0x5a07f2)=>{_0x37761a['server_']['unlisten'](_0x59080d,_0x5a07f2);}});}function la(_0x46cb52){const _0x3f145c=_0x46cb52['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3f145c;}function Xt(_0x3490a7){return id({'timestamp':la(_0x3490a7)});}function gr(_0x481287,_0xbc92bc,_0x2e19bd,_0x157c73,_0x57ce31){_0x481287['dataUpdateCount']++;const _0xdbd41a=new C(_0xbc92bc);_0x2e19bd=_0x481287['interceptServerDataCallback_']?_0x481287['interceptServerDataCallback_'](_0xbc92bc,_0x2e19bd):_0x2e19bd;let _0x415f54=[];if(_0x57ce31){if(_0x157c73){const _0x182407=_n(_0x2e19bd,_0x490080=>A(_0x490080));_0x415f54=Ju(_0x481287['serverSyncTree_'],_0xdbd41a,_0x182407,_0x57ce31);}else{const _0x38cad2=A(_0x2e19bd);_0x415f54=Jo(_0x481287['serverSyncTree_'],_0xdbd41a,_0x38cad2,_0x57ce31);}}else{if(_0x157c73){const _0x19b56a=_n(_0x2e19bd,_0x64a3d1=>A(_0x64a3d1));_0x415f54=Ku(_0x481287['serverSyncTree_'],_0xdbd41a,_0x19b56a);}else{const _0x2da4f0=A(_0x2e19bd);_0x415f54=Yt(_0x481287['serverSyncTree_'],_0xdbd41a,_0x2da4f0);}}let _0x419fca=_0xdbd41a;_0x415f54['length']>0x0&&(_0x419fca=ct(_0x481287,_0xdbd41a)),V(_0x481287['eventQueue_'],_0x419fca,_0x415f54);}function mr(_0x40e581,_0x2d9da2){vs(_0x40e581,'connected',_0x2d9da2),_0x2d9da2===!0x1&&Sd(_0x40e581);}function Id(_0x361ab8,_0xc5e431){x(_0xc5e431,(_0xc2cfe5,_0x180a81)=>{vs(_0x361ab8,_0xc2cfe5,_0x180a81);});}function vs(_0x3a30e8,_0x38fee7,_0x1571ad){const _0x523d73=new C('/.info/'+_0x38fee7),_0x43d925=A(_0x1571ad);_0x3a30e8['infoData_']['updateSnapshot'](_0x523d73,_0x43d925);const _0x328e86=Yt(_0x3a30e8['infoSyncTree_'],_0x523d73,_0x43d925);V(_0x3a30e8['eventQueue_'],_0x523d73,_0x328e86);}function zn(_0x1aeefc){return _0x1aeefc['nextWriteId_']++;}function wd(_0x4d60e2,_0x2f2745,_0x14fe7d){const _0x4cb2af=Xu(_0x4d60e2['serverSyncTree_'],_0x2f2745);return _0x4cb2af!=null?Promise['resolve'](_0x4cb2af):_0x4d60e2['server_']['get'](_0x2f2745)['then'](_0x3518f9=>{const _0xe9979f=A(_0x3518f9)['withIndex'](_0x2f2745['_queryParams']['getIndex']());Ni(_0x4d60e2['serverSyncTree_'],_0x2f2745,_0x14fe7d,!0x0);let _0x502e17;if(_0x2f2745['_queryParams']['loadsAllData']())_0x502e17=Yt(_0x4d60e2['serverSyncTree_'],_0x2f2745['_path'],_0xe9979f);else{const _0x2fa43d=Wt(_0x4d60e2['serverSyncTree_'],_0x2f2745);_0x502e17=Jo(_0x4d60e2['serverSyncTree_'],_0x2f2745['_path'],_0xe9979f,_0x2fa43d);}return V(_0x4d60e2['eventQueue_'],_0x2f2745['_path'],_0x502e17),An(_0x4d60e2['serverSyncTree_'],_0x2f2745,_0x14fe7d,null,!0x0),_0xe9979f;},_0x291e6d=>(gt(_0x4d60e2,'get\x20for\x20query\x20'+O(_0x2f2745)+'\x20failed:\x20'+_0x291e6d),Promise['reject'](new Error(_0x291e6d))));}function Cd(_0x45a75e,_0x5345e6,_0x3b5247,_0x3e639e,_0x5c717b){gt(_0x45a75e,'set',{'path':_0x5345e6['toString'](),'value':_0x3b5247,'priority':_0x3e639e});const _0x1e60ab=Xt(_0x45a75e),_0x1a30c0=A(_0x3b5247,_0x3e639e),_0x38671a=Vn(_0x45a75e['serverSyncTree_'],_0x5345e6),_0x2cbbcb=fs(_0x1a30c0,_0x38671a,_0x1e60ab),_0x5093c4=zn(_0x45a75e),_0xb5ce27=as(_0x45a75e['serverSyncTree_'],_0x5345e6,_0x2cbbcb,_0x5093c4,!0x0);qn(_0x45a75e['eventQueue_'],_0xb5ce27),_0x45a75e['server_']['put'](_0x5345e6['toString'](),_0x1a30c0['val'](!0x0),(_0x14419c,_0x446b87)=>{const _0x1a279d=_0x14419c==='ok';_0x1a279d||U('set\x20at\x20'+_0x5345e6+'\x20failed:\x20'+_0x14419c);const _0x565960=_e(_0x45a75e['serverSyncTree_'],_0x5093c4,!_0x1a279d);V(_0x45a75e['eventQueue_'],_0x5345e6,_0x565960),be(_0x45a75e,_0x5c717b,_0x14419c,_0x446b87);});const _0x25b961=Is(_0x45a75e,_0x5345e6);ct(_0x45a75e,_0x25b961),V(_0x45a75e['eventQueue_'],_0x25b961,[]);}function Td(_0x3e072d,_0x41607e,_0x4f250a,_0x4adcc0){gt(_0x3e072d,'update',{'path':_0x41607e['toString'](),'value':_0x4f250a});let _0x3b87a8=!0x0;const _0x452bb9=Xt(_0x3e072d),_0x4d2d92={};if(x(_0x4f250a,(_0x299b0f,_0x36d68e)=>{_0x3b87a8=!0x1,_0x4d2d92[_0x299b0f]=ta(k(_0x41607e,_0x299b0f),A(_0x36d68e),_0x3e072d['serverSyncTree_'],_0x452bb9);}),_0x3b87a8)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3e072d,_0x4adcc0,'ok',void 0x0);else{const _0x597b38=zn(_0x3e072d),_0x28d379=ju(_0x3e072d['serverSyncTree_'],_0x41607e,_0x4d2d92,_0x597b38);qn(_0x3e072d['eventQueue_'],_0x28d379),_0x3e072d['server_']['merge'](_0x41607e['toString'](),_0x4f250a,(_0x5652a1,_0x3d6251)=>{const _0x360be7=_0x5652a1==='ok';_0x360be7||U('update\x20at\x20'+_0x41607e+'\x20failed:\x20'+_0x5652a1);const _0x209771=_e(_0x3e072d['serverSyncTree_'],_0x597b38,!_0x360be7),_0x8c7860=_0x209771['length']>0x0?ct(_0x3e072d,_0x41607e):_0x41607e;V(_0x3e072d['eventQueue_'],_0x8c7860,_0x209771),be(_0x3e072d,_0x4adcc0,_0x5652a1,_0x3d6251);}),x(_0x4f250a,_0x685f89=>{const _0x10c2fc=Is(_0x3e072d,k(_0x41607e,_0x685f89));ct(_0x3e072d,_0x10c2fc);}),V(_0x3e072d['eventQueue_'],_0x41607e,[]);}}function Sd(_0x4268a6){gt(_0x4268a6,'onDisconnectEvents');const _0x29981d=Xt(_0x4268a6),_0x2a4cca=En();Si(_0x4268a6['onDisconnect_'],w(),(_0x2cd102,_0x3ece25)=>{const _0x4b47c4=ta(_0x2cd102,_0x3ece25,_0x4268a6['serverSyncTree_'],_0x29981d);pt(_0x2a4cca,_0x2cd102,_0x4b47c4);});let _0x2cf0b9=[];Si(_0x2a4cca,w(),(_0x1e1a94,_0x296313)=>{_0x2cf0b9=_0x2cf0b9['concat'](Yt(_0x4268a6['serverSyncTree_'],_0x1e1a94,_0x296313));const _0x3bf55b=Is(_0x4268a6,_0x1e1a94);ct(_0x4268a6,_0x3bf55b);}),_0x4268a6['onDisconnect_']=En(),V(_0x4268a6['eventQueue_'],w(),_0x2cf0b9);}function bd(_0x4c6363,_0x4b4bb5,_0x34f36a){_0x4c6363['server_']['onDisconnectCancel'](_0x4b4bb5['toString'](),(_0x4c77e6,_0x27c3e6)=>{_0x4c77e6==='ok'&&Ti(_0x4c6363['onDisconnect_'],_0x4b4bb5),be(_0x4c6363,_0x34f36a,_0x4c77e6,_0x27c3e6);});}function yr(_0x4012c4,_0x4d0703,_0x44a10e,_0x48a89a){const _0x5da9cb=A(_0x44a10e);_0x4012c4['server_']['onDisconnectPut'](_0x4d0703['toString'](),_0x5da9cb['val'](!0x0),(_0x20d65f,_0x45b2c3)=>{_0x20d65f==='ok'&&pt(_0x4012c4['onDisconnect_'],_0x4d0703,_0x5da9cb),be(_0x4012c4,_0x48a89a,_0x20d65f,_0x45b2c3);});}function Rd(_0x467be0,_0x50ab7d,_0x1bc6b3,_0x23c885,_0x73ae57){const _0x257669=A(_0x1bc6b3,_0x23c885);_0x467be0['server_']['onDisconnectPut'](_0x50ab7d['toString'](),_0x257669['val'](!0x0),(_0x5dcc03,_0x2a4aab)=>{_0x5dcc03==='ok'&&pt(_0x467be0['onDisconnect_'],_0x50ab7d,_0x257669),be(_0x467be0,_0x73ae57,_0x5dcc03,_0x2a4aab);});}function Ad(_0x7c8564,_0x537f8d,_0x2011b8,_0x39d975){if(pn(_0x2011b8)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x7c8564,_0x39d975,'ok',void 0x0);return;}_0x7c8564['server_']['onDisconnectMerge'](_0x537f8d['toString'](),_0x2011b8,(_0x228a14,_0xceec91)=>{_0x228a14==='ok'&&x(_0x2011b8,(_0x4bc0b0,_0x4ca29b)=>{const _0x5af161=A(_0x4ca29b);pt(_0x7c8564['onDisconnect_'],k(_0x537f8d,_0x4bc0b0),_0x5af161);}),be(_0x7c8564,_0x39d975,_0x228a14,_0xceec91);});}function kd(_0x1dad16,_0xaf4092,_0x38a1d2){let _0x201513;y(_0xaf4092['_path'])==='.info'?_0x201513=Ni(_0x1dad16['infoSyncTree_'],_0xaf4092,_0x38a1d2):_0x201513=Ni(_0x1dad16['serverSyncTree_'],_0xaf4092,_0x38a1d2),oa(_0x1dad16['eventQueue_'],_0xaf4092['_path'],_0x201513);}function Pd(_0x84d570,_0x598bd2,_0x5ce986){let _0x11a763;y(_0x598bd2['_path'])==='.info'?_0x11a763=An(_0x84d570['infoSyncTree_'],_0x598bd2,_0x5ce986):_0x11a763=An(_0x84d570['serverSyncTree_'],_0x598bd2,_0x5ce986),oa(_0x84d570['eventQueue_'],_0x598bd2['_path'],_0x11a763);}function ha(_0x3a942b){_0x3a942b['persistentConnection_']&&_0x3a942b['persistentConnection_']['interrupt'](ca);}function Nd(_0x17374e){_0x17374e['persistentConnection_']&&_0x17374e['persistentConnection_']['resume'](ca);}function gt(_0x1daf37,..._0x4ba269){let _0x2ad650='';_0x1daf37['persistentConnection_']&&(_0x2ad650=_0x1daf37['persistentConnection_']['id']+':'),L(_0x2ad650,..._0x4ba269);}function be(_0x23a7bf,_0x1816bd,_0x1dbbf9,_0x3ffa85){_0x1816bd&&ft(()=>{if(_0x1dbbf9==='ok')_0x1816bd(null);else{const _0x3278f6=(_0x1dbbf9||'error')['toUpperCase']();let _0x498fe8=_0x3278f6;_0x3ffa85&&(_0x498fe8+=':\x20'+_0x3ffa85);const _0x217266=new Error(_0x498fe8);_0x217266['code']=_0x3278f6,_0x1816bd(_0x217266);}});}function Od(_0x5af3e6,_0x4b7699,_0x42e025,_0x3673f4,_0x54563,_0x31cd7d){gt(_0x5af3e6,'transaction\x20on\x20'+_0x4b7699);const _0x340136={'path':_0x4b7699,'update':_0x42e025,'onComplete':_0x3673f4,'status':null,'order':so(),'applyLocally':_0x31cd7d,'retryCount':0x0,'unwatcher':_0x54563,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x7f2ab9=Es(_0x5af3e6,_0x4b7699,void 0x0);_0x340136['currentInputSnapshot']=_0x7f2ab9;const _0x1e424d=_0x340136['update'](_0x7f2ab9['val']());if(_0x1e424d===void 0x0)_0x340136['unwatcher'](),_0x340136['currentOutputSnapshotRaw']=null,_0x340136['currentOutputSnapshotResolved']=null,_0x340136['onComplete']&&_0x340136['onComplete'](null,!0x1,_0x340136['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1e424d,_0x340136['path']),_0x340136['status']=0x0;const _0x5db523=$n(_0x5af3e6['transactionQueueTree_'],_0x4b7699),_0xfa171=je(_0x5db523)||[];_0xfa171['push'](_0x340136),gs(_0x5db523,_0xfa171);let _0x4e6f5;typeof _0x1e424d=='object'&&_0x1e424d!==null&&Q(_0x1e424d,'.priority')?(_0x4e6f5=Le(_0x1e424d,'.priority'),f(Bt(_0x4e6f5),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4e6f5=(Vn(_0x5af3e6['serverSyncTree_'],_0x4b7699)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x432a11=Xt(_0x5af3e6),_0x499176=A(_0x1e424d,_0x4e6f5),_0x549dc3=fs(_0x499176,_0x7f2ab9,_0x432a11);_0x340136['currentOutputSnapshotRaw']=_0x499176,_0x340136['currentOutputSnapshotResolved']=_0x549dc3,_0x340136['currentWriteId']=zn(_0x5af3e6);const _0x44cd71=as(_0x5af3e6['serverSyncTree_'],_0x4b7699,_0x549dc3,_0x340136['currentWriteId'],_0x340136['applyLocally']);V(_0x5af3e6['eventQueue_'],_0x4b7699,_0x44cd71),jn(_0x5af3e6,_0x5af3e6['transactionQueueTree_']);}}function Es(_0x5d4865,_0x1c497d,_0x432335){return Vn(_0x5d4865['serverSyncTree_'],_0x1c497d,_0x432335)||g['EMPTY_NODE'];}function jn(_0x190c44,_0x2d63fe=_0x190c44['transactionQueueTree_']){if(_0x2d63fe||Kn(_0x190c44,_0x2d63fe),je(_0x2d63fe)){const _0x5173a5=da(_0x190c44,_0x2d63fe);f(_0x5173a5['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5173a5['every'](_0x335db3=>_0x335db3['status']===0x0)&&Dd(_0x190c44,Qt(_0x2d63fe),_0x5173a5);}else na(_0x2d63fe)&&Gn(_0x2d63fe,_0x1abafe=>{jn(_0x190c44,_0x1abafe);});}function Dd(_0x2c13d6,_0x15c434,_0x9c970a){const _0x129362=_0x9c970a['map'](_0x3db7d2=>_0x3db7d2['currentWriteId']),_0x53d722=Es(_0x2c13d6,_0x15c434,_0x129362);let _0x29c783=_0x53d722;const _0x6d1fa=_0x53d722['hash']();for(let _0x1c4c3a=0x0;_0x1c4c3a<_0x9c970a['length'];_0x1c4c3a++){const _0x4a9ee4=_0x9c970a[_0x1c4c3a];f(_0x4a9ee4['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4a9ee4['status']=0x1,_0x4a9ee4['retryCount']++;const _0x324491=F(_0x15c434,_0x4a9ee4['path']);_0x29c783=_0x29c783['updateChild'](_0x324491,_0x4a9ee4['currentOutputSnapshotRaw']);}const _0x1e8c92=_0x29c783['val'](!0x0),_0x43b043=_0x15c434;_0x2c13d6['server_']['put'](_0x43b043['toString'](),_0x1e8c92,_0x5f096d=>{gt(_0x2c13d6,'transaction\x20put\x20response',{'path':_0x43b043['toString'](),'status':_0x5f096d});let _0x48198c=[];if(_0x5f096d==='ok'){const _0x27010f=[];for(let _0x43934f=0x0;_0x43934f<_0x9c970a['length'];_0x43934f++)_0x9c970a[_0x43934f]['status']=0x2,_0x48198c=_0x48198c['concat'](_e(_0x2c13d6['serverSyncTree_'],_0x9c970a[_0x43934f]['currentWriteId'])),_0x9c970a[_0x43934f]['onComplete']&&_0x27010f['push'](()=>_0x9c970a[_0x43934f]['onComplete'](null,!0x0,_0x9c970a[_0x43934f]['currentOutputSnapshotResolved'])),_0x9c970a[_0x43934f]['unwatcher']();Kn(_0x2c13d6,$n(_0x2c13d6['transactionQueueTree_'],_0x15c434)),jn(_0x2c13d6,_0x2c13d6['transactionQueueTree_']),V(_0x2c13d6['eventQueue_'],_0x15c434,_0x48198c);for(let _0x51b9ee=0x0;_0x51b9ee<_0x27010f['length'];_0x51b9ee++)ft(_0x27010f[_0x51b9ee]);}else{if(_0x5f096d==='datastale'){for(let _0x53e8db=0x0;_0x53e8db<_0x9c970a['length'];_0x53e8db++)_0x9c970a[_0x53e8db]['status']===0x3?_0x9c970a[_0x53e8db]['status']=0x4:_0x9c970a[_0x53e8db]['status']=0x0;}else{U('transaction\x20at\x20'+_0x43b043['toString']()+'\x20failed:\x20'+_0x5f096d);for(let _0x562d44=0x0;_0x562d44<_0x9c970a['length'];_0x562d44++)_0x9c970a[_0x562d44]['status']=0x4,_0x9c970a[_0x562d44]['abortReason']=_0x5f096d;}ct(_0x2c13d6,_0x15c434);}},_0x6d1fa);}function ct(_0x465e09,_0x1e5af6){const _0x471d2d=ua(_0x465e09,_0x1e5af6),_0x1925c8=Qt(_0x471d2d),_0x56aabd=da(_0x465e09,_0x471d2d);return Md(_0x465e09,_0x56aabd,_0x1925c8),_0x1925c8;}function Md(_0x2ee220,_0xeb9daa,_0x412d01){if(_0xeb9daa['length']===0x0)return;const _0x14cc57=[];let _0x55902b=[];const _0x27fd3d=_0xeb9daa['filter'](_0x5b6fe6=>_0x5b6fe6['status']===0x0)['map'](_0x397a6a=>_0x397a6a['currentWriteId']);for(let _0x12ba73=0x0;_0x12ba73<_0xeb9daa['length'];_0x12ba73++){const _0x31339c=_0xeb9daa[_0x12ba73],_0x54f5a2=F(_0x412d01,_0x31339c['path']);let _0x34aa32=!0x1,_0x35fd54;if(f(_0x54f5a2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x31339c['status']===0x4)_0x34aa32=!0x0,_0x35fd54=_0x31339c['abortReason'],_0x55902b=_0x55902b['concat'](_e(_0x2ee220['serverSyncTree_'],_0x31339c['currentWriteId'],!0x0));else{if(_0x31339c['status']===0x0){if(_0x31339c['retryCount']>=yd)_0x34aa32=!0x0,_0x35fd54='maxretry',_0x55902b=_0x55902b['concat'](_e(_0x2ee220['serverSyncTree_'],_0x31339c['currentWriteId'],!0x0));else{const _0x3b94e8=Es(_0x2ee220,_0x31339c['path'],_0x27fd3d);_0x31339c['currentInputSnapshot']=_0x3b94e8;const _0x2983ff=_0xeb9daa[_0x12ba73]['update'](_0x3b94e8['val']());if(_0x2983ff!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2983ff,_0x31339c['path']);let _0xa01d6c=A(_0x2983ff);typeof _0x2983ff=='object'&&_0x2983ff!=null&&Q(_0x2983ff,'.priority')||(_0xa01d6c=_0xa01d6c['updatePriority'](_0x3b94e8['getPriority']()));const _0x9c6685=_0x31339c['currentWriteId'],_0x27268c=Xt(_0x2ee220),_0x137dec=fs(_0xa01d6c,_0x3b94e8,_0x27268c);_0x31339c['currentOutputSnapshotRaw']=_0xa01d6c,_0x31339c['currentOutputSnapshotResolved']=_0x137dec,_0x31339c['currentWriteId']=zn(_0x2ee220),_0x27fd3d['splice'](_0x27fd3d['indexOf'](_0x9c6685),0x1),_0x55902b=_0x55902b['concat'](as(_0x2ee220['serverSyncTree_'],_0x31339c['path'],_0x137dec,_0x31339c['currentWriteId'],_0x31339c['applyLocally'])),_0x55902b=_0x55902b['concat'](_e(_0x2ee220['serverSyncTree_'],_0x9c6685,!0x0));}else _0x34aa32=!0x0,_0x35fd54='nodata',_0x55902b=_0x55902b['concat'](_e(_0x2ee220['serverSyncTree_'],_0x31339c['currentWriteId'],!0x0));}}}V(_0x2ee220['eventQueue_'],_0x412d01,_0x55902b),_0x55902b=[],_0x34aa32&&(_0xeb9daa[_0x12ba73]['status']=0x2,function(_0x5541fe){setTimeout(_0x5541fe,Math['floor'](0x0));}(_0xeb9daa[_0x12ba73]['unwatcher']),_0xeb9daa[_0x12ba73]['onComplete']&&(_0x35fd54==='nodata'?_0x14cc57['push'](()=>_0xeb9daa[_0x12ba73]['onComplete'](null,!0x1,_0xeb9daa[_0x12ba73]['currentInputSnapshot'])):_0x14cc57['push'](()=>_0xeb9daa[_0x12ba73]['onComplete'](new Error(_0x35fd54),!0x1,null))));}Kn(_0x2ee220,_0x2ee220['transactionQueueTree_']);for(let _0xb6bcc8=0x0;_0xb6bcc8<_0x14cc57['length'];_0xb6bcc8++)ft(_0x14cc57[_0xb6bcc8]);jn(_0x2ee220,_0x2ee220['transactionQueueTree_']);}function ua(_0x1f3f6c,_0x4a8306){let _0x404d05,_0xde37f4=_0x1f3f6c['transactionQueueTree_'];for(_0x404d05=y(_0x4a8306);_0x404d05!==null&&je(_0xde37f4)===void 0x0;)_0xde37f4=$n(_0xde37f4,_0x404d05),_0x4a8306=S(_0x4a8306),_0x404d05=y(_0x4a8306);return _0xde37f4;}function da(_0xde62e9,_0x1bb8bd){const _0x1355b6=[];return fa(_0xde62e9,_0x1bb8bd,_0x1355b6),_0x1355b6['sort']((_0x1ecd94,_0x3877c8)=>_0x1ecd94['order']-_0x3877c8['order']),_0x1355b6;}function fa(_0x2ddf22,_0x2e101a,_0x129031){const _0xaabbe0=je(_0x2e101a);if(_0xaabbe0){for(let _0x2415a6=0x0;_0x2415a6<_0xaabbe0['length'];_0x2415a6++)_0x129031['push'](_0xaabbe0[_0x2415a6]);}Gn(_0x2e101a,_0x1a6b73=>{fa(_0x2ddf22,_0x1a6b73,_0x129031);});}function Kn(_0xdac63f,_0xf21944){const _0x4f7a91=je(_0xf21944);if(_0x4f7a91){let _0x2a3fed=0x0;for(let _0x427e00=0x0;_0x427e00<_0x4f7a91['length'];_0x427e00++)_0x4f7a91[_0x427e00]['status']!==0x2&&(_0x4f7a91[_0x2a3fed]=_0x4f7a91[_0x427e00],_0x2a3fed++);_0x4f7a91['length']=_0x2a3fed,gs(_0xf21944,_0x4f7a91['length']>0x0?_0x4f7a91:void 0x0);}Gn(_0xf21944,_0x2b4ae0=>{Kn(_0xdac63f,_0x2b4ae0);});}function Is(_0x302e58,_0x523eb5){const _0x682438=Qt(ua(_0x302e58,_0x523eb5)),_0x39e80e=$n(_0x302e58['transactionQueueTree_'],_0x523eb5);return ad(_0x39e80e,_0x5f51ba=>{di(_0x302e58,_0x5f51ba);}),di(_0x302e58,_0x39e80e),ia(_0x39e80e,_0x40c2ab=>{di(_0x302e58,_0x40c2ab);}),_0x682438;}function di(_0x328451,_0x20e3f2){const _0xf792b9=je(_0x20e3f2);if(_0xf792b9){const _0x3c1bd9=[];let _0x6c651c=[],_0x2a9efc=-0x1;for(let _0x5d3bdd=0x0;_0x5d3bdd<_0xf792b9['length'];_0x5d3bdd++)_0xf792b9[_0x5d3bdd]['status']===0x3||(_0xf792b9[_0x5d3bdd]['status']===0x1?(f(_0x2a9efc===_0x5d3bdd-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2a9efc=_0x5d3bdd,_0xf792b9[_0x5d3bdd]['status']=0x3,_0xf792b9[_0x5d3bdd]['abortReason']='set'):(f(_0xf792b9[_0x5d3bdd]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xf792b9[_0x5d3bdd]['unwatcher'](),_0x6c651c=_0x6c651c['concat'](_e(_0x328451['serverSyncTree_'],_0xf792b9[_0x5d3bdd]['currentWriteId'],!0x0)),_0xf792b9[_0x5d3bdd]['onComplete']&&_0x3c1bd9['push'](_0xf792b9[_0x5d3bdd]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2a9efc===-0x1?gs(_0x20e3f2,void 0x0):_0xf792b9['length']=_0x2a9efc+0x1,V(_0x328451['eventQueue_'],Qt(_0x20e3f2),_0x6c651c);for(let _0x73bf76=0x0;_0x73bf76<_0x3c1bd9['length'];_0x73bf76++)ft(_0x3c1bd9[_0x73bf76]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x55abde){let _0x21c585='';const _0x3574bd=_0x55abde['split']('/');for(let _0x48bef7=0x0;_0x48bef7<_0x3574bd['length'];_0x48bef7++)if(_0x3574bd[_0x48bef7]['length']>0x0){let _0x5661d7=_0x3574bd[_0x48bef7];try{_0x5661d7=decodeURIComponent(_0x5661d7['replace'](/\+/g,'\x20'));}catch{}_0x21c585+='/'+_0x5661d7;}return _0x21c585;}function xd(_0x466df3){const _0xa86f1e={};_0x466df3['charAt'](0x0)==='?'&&(_0x466df3=_0x466df3['substring'](0x1));for(const _0x4ce0a0 of _0x466df3['split']('&')){if(_0x4ce0a0['length']===0x0)continue;const _0x29682e=_0x4ce0a0['split']('=');_0x29682e['length']===0x2?_0xa86f1e[decodeURIComponent(_0x29682e[0x0])]=decodeURIComponent(_0x29682e[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4ce0a0+'\x27\x20in\x20query\x20\x27'+_0x466df3+'\x27');}return _0xa86f1e;}const vr=function(_0x3e4544,_0x3bb261){const _0x58ceaa=Fd(_0x3e4544),_0x98dbd8=_0x58ceaa['namespace'];_0x58ceaa['domain']==='firebase.com'&&ae(_0x58ceaa['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x98dbd8||_0x98dbd8==='undefined')&&_0x58ceaa['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x58ceaa['secure']||$l();const _0x5020fd=_0x58ceaa['scheme']==='ws'||_0x58ceaa['scheme']==='wss';return{'repoInfo':new yo(_0x58ceaa['host'],_0x58ceaa['secure'],_0x98dbd8,_0x5020fd,_0x3bb261,'',_0x98dbd8!==_0x58ceaa['subdomain']),'path':new C(_0x58ceaa['pathString'])};},Fd=function(_0x36d072){let _0x52470f='',_0x5dde36='',_0x2c5854='',_0x30020d='',_0xe444d0='',_0x29949b=!0x0,_0x1d2dcb='https',_0x225d2e=0x1bb;if(typeof _0x36d072=='string'){let _0x52bbaf=_0x36d072['indexOf']('//');_0x52bbaf>=0x0&&(_0x1d2dcb=_0x36d072['substring'](0x0,_0x52bbaf-0x1),_0x36d072=_0x36d072['substring'](_0x52bbaf+0x2));let _0x578e7a=_0x36d072['indexOf']('/');_0x578e7a===-0x1&&(_0x578e7a=_0x36d072['length']);let _0x297a1f=_0x36d072['indexOf']('?');_0x297a1f===-0x1&&(_0x297a1f=_0x36d072['length']),_0x52470f=_0x36d072['substring'](0x0,Math['min'](_0x578e7a,_0x297a1f)),_0x578e7a<_0x297a1f&&(_0x30020d=Ld(_0x36d072['substring'](_0x578e7a,_0x297a1f)));const _0x3db828=xd(_0x36d072['substring'](Math['min'](_0x36d072['length'],_0x297a1f)));_0x52bbaf=_0x52470f['indexOf'](':'),_0x52bbaf>=0x0?(_0x29949b=_0x1d2dcb==='https'||_0x1d2dcb==='wss',_0x225d2e=parseInt(_0x52470f['substring'](_0x52bbaf+0x1),0xa)):_0x52bbaf=_0x52470f['length'];const _0xaaffaf=_0x52470f['slice'](0x0,_0x52bbaf);if(_0xaaffaf['toLowerCase']()==='localhost')_0x5dde36='localhost';else{if(_0xaaffaf['split']('.')['length']<=0x2)_0x5dde36=_0xaaffaf;else{const _0xa74fc9=_0x52470f['indexOf']('.');_0x2c5854=_0x52470f['substring'](0x0,_0xa74fc9)['toLowerCase'](),_0x5dde36=_0x52470f['substring'](_0xa74fc9+0x1),_0xe444d0=_0x2c5854;}}'ns'in _0x3db828&&(_0xe444d0=_0x3db828['ns']);}return{'host':_0x52470f,'port':_0x225d2e,'domain':_0x5dde36,'subdomain':_0x2c5854,'secure':_0x29949b,'scheme':_0x1d2dcb,'pathString':_0x30020d,'namespace':_0xe444d0};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x5e2386=0x0;const _0xb2dd55=[];return function(_0x4ff89e){const _0x496a47=_0x4ff89e===_0x5e2386;_0x5e2386=_0x4ff89e;let _0x43233f;const _0x188f9a=new Array(0x8);for(_0x43233f=0x7;_0x43233f>=0x0;_0x43233f--)_0x188f9a[_0x43233f]=Er['charAt'](_0x4ff89e%0x40),_0x4ff89e=Math['floor'](_0x4ff89e/0x40);f(_0x4ff89e===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2dcd9d=_0x188f9a['join']('');if(_0x496a47){for(_0x43233f=0xb;_0x43233f>=0x0&&_0xb2dd55[_0x43233f]===0x3f;_0x43233f--)_0xb2dd55[_0x43233f]=0x0;_0xb2dd55[_0x43233f]++;}else{for(_0x43233f=0x0;_0x43233f<0xc;_0x43233f++)_0xb2dd55[_0x43233f]=Math['floor'](Math['random']()*0x40);}for(_0x43233f=0x0;_0x43233f<0xc;_0x43233f++)_0x2dcd9d+=Er['charAt'](_0xb2dd55[_0x43233f]);return f(_0x2dcd9d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2dcd9d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x5e1db3,_0x543aa1,_0x85807a,_0x1c0d88){this['eventType']=_0x5e1db3,this['eventRegistration']=_0x543aa1,this['snapshot']=_0x85807a,this['prevName']=_0x1c0d88;}['getPath'](){const _0x55a892=this['snapshot']['ref'];return this['eventType']==='value'?_0x55a892['_path']:_0x55a892['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2dbf78,_0xbc24dc,_0x389d38){this['eventRegistration']=_0x2dbf78,this['error']=_0xbc24dc,this['path']=_0x389d38;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x5639d6,_0x1eae85){this['snapshotCallback']=_0x5639d6,this['cancelCallback']=_0x1eae85;}['onValue'](_0x227df0,_0x17466f){this['snapshotCallback']['call'](null,_0x227df0,_0x17466f);}['onCancel'](_0x29ab7e){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x29ab7e);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3bfed9){return this['snapshotCallback']===_0x3bfed9['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3bfed9['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3bfed9['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5882d6,_0x7049d0){this['_repo']=_0x5882d6,this['_path']=_0x7049d0;}['cancel'](){const _0x442219=new H();return bd(this['_repo'],this['_path'],_0x442219['wrapCallback'](()=>{})),_0x442219['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x47a74e=new H();return yr(this['_repo'],this['_path'],null,_0x47a74e['wrapCallback'](()=>{})),_0x47a74e['promise'];}['set'](_0x59c9f3){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x59c9f3,this['_path'],!0x1);const _0x4e9f04=new H();return yr(this['_repo'],this['_path'],_0x59c9f3,_0x4e9f04['wrapCallback'](()=>{})),_0x4e9f04['promise'];}['setWithPriority'](_0xa7ef90,_0x1530b3){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0xa7ef90,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1530b3);const _0x5eddfa=new H();return Rd(this['_repo'],this['_path'],_0xa7ef90,_0x1530b3,_0x5eddfa['wrapCallback'](()=>{})),_0x5eddfa['promise'];}['update'](_0x234167){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x234167,this['_path']);const _0x29067b=new H();return Ad(this['_repo'],this['_path'],_0x234167,_0x29067b['wrapCallback'](()=>{})),_0x29067b['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x269c9e,_0x1d5cf8,_0x57cee2,_0x2ef45f){this['_repo']=_0x269c9e,this['_path']=_0x1d5cf8,this['_queryParams']=_0x57cee2,this['_orderByCalled']=_0x2ef45f;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1747d4=sr(this['_queryParams']),_0x2458c7=$i(_0x1747d4);return _0x2458c7==='{}'?'default':_0x2458c7;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1ecf5f){if(_0x1ecf5f=P(_0x1ecf5f),!(_0x1ecf5f instanceof Ae))return!0x1;const _0x50e36e=this['_repo']===_0x1ecf5f['_repo'],_0x5ba161=Ki(this['_path'],_0x1ecf5f['_path']),_0x7edad6=this['_queryIdentifier']===_0x1ecf5f['_queryIdentifier'];return _0x50e36e&&_0x5ba161&&_0x7edad6;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4c9e39,_0x1f3393){if(_0x4c9e39['_orderByCalled']===!0x0)throw new Error(_0x1f3393+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1fa288){let _0x140543=null,_0x11f198=null;if(_0x1fa288['hasStart']()&&(_0x140543=_0x1fa288['getIndexStartValue']()),_0x1fa288['hasEnd']()&&(_0x11f198=_0x1fa288['getIndexEndValue']()),_0x1fa288['getIndex']()===ve){const _0x458274='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2aac0d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1fa288['hasStart']()){if(_0x1fa288['getIndexStartName']()!==We)throw new Error(_0x458274);if(typeof _0x140543!='string')throw new Error(_0x2aac0d);}if(_0x1fa288['hasEnd']()){if(_0x1fa288['getIndexEndName']()!==we)throw new Error(_0x458274);if(typeof _0x11f198!='string')throw new Error(_0x2aac0d);}}else{if(_0x1fa288['getIndex']()===R){if(_0x140543!=null&&!Bt(_0x140543)||_0x11f198!=null&&!Bt(_0x11f198))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1fa288['getIndex']()instanceof Ji||_0x1fa288['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x140543!=null&&typeof _0x140543=='object'||_0x11f198!=null&&typeof _0x11f198=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x31c047){if(_0x31c047['hasStart']()&&_0x31c047['hasEnd']()&&_0x31c047['hasLimit']()&&!_0x31c047['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0xf333f4,_0x1043b0){super(_0xf333f4,_0x1043b0,new Zi(),!0x1);}get['parent'](){const _0x188352=Ro(this['_path']);return _0x188352===null?null:new ee(this['_repo'],_0x188352);}get['root'](){let _0xfa1176=this;for(;_0xfa1176['parent']!==null;)_0xfa1176=_0xfa1176['parent'];return _0xfa1176;}}class lt{constructor(_0x28a764,_0x5b425a,_0x2b8be6){this['_node']=_0x28a764,this['ref']=_0x5b425a,this['_index']=_0x2b8be6;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x157326){const _0x56ee47=new C(_0x157326),_0x391c28=Vt(this['ref'],_0x157326);return new lt(this['_node']['getChild'](_0x56ee47),_0x391c28,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1e20f6){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5102b4,_0x2c47d1)=>_0x1e20f6(new lt(_0x2c47d1,Vt(this['ref'],_0x5102b4),R)));}['hasChild'](_0xa0a268){const _0x57e3bc=new C(_0xa0a268);return!this['_node']['getChild'](_0x57e3bc)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1e9b15,_0xe0f39b){return _0x1e9b15=P(_0x1e9b15),_0x1e9b15['_checkNotDeleted']('ref'),_0xe0f39b!==void 0x0?Vt(_0x1e9b15['_root'],_0xe0f39b):_0x1e9b15['_root'];}function Vt(_0x15d509,_0x4fc294){return _0x15d509=P(_0x15d509),y(_0x15d509['_path'])===null?pd('child','path',_0x4fc294):ys('child','path',_0x4fc294),new ee(_0x15d509['_repo'],k(_0x15d509['_path'],_0x4fc294));}function v_(_0x4ecb10){return _0x4ecb10=P(_0x4ecb10),new Vd(_0x4ecb10['_repo'],_0x4ecb10['_path']);}function E_(_0x1ff908,_0x48b492){_0x1ff908=P(_0x1ff908),Me('push',_0x1ff908['_path']),He('push',_0x48b492,_0x1ff908['_path'],!0x0);const _0x3d89a4=la(_0x1ff908['_repo']),_0x397754=Ud(_0x3d89a4),_0x81d905=Vt(_0x1ff908,_0x397754),_0x158751=Vt(_0x1ff908,_0x397754);let _0xc7ac66;return _0x48b492!=null?_0xc7ac66=Hd(_0x158751,_0x48b492)['then'](()=>_0x158751):_0xc7ac66=Promise['resolve'](_0x158751),_0x81d905['then']=_0xc7ac66['then']['bind'](_0xc7ac66),_0x81d905['catch']=_0xc7ac66['then']['bind'](_0xc7ac66,void 0x0),_0x81d905;}function Hd(_0x20a6d9,_0x257384){_0x20a6d9=P(_0x20a6d9),Me('set',_0x20a6d9['_path']),He('set',_0x257384,_0x20a6d9['_path'],!0x1);const _0x106baa=new H();return Cd(_0x20a6d9['_repo'],_0x20a6d9['_path'],_0x257384,null,_0x106baa['wrapCallback'](()=>{})),_0x106baa['promise'];}function I_(_0x394e07,_0x45fafc){ra('update',_0x45fafc,_0x394e07['_path']);const _0x358d38=new H();return Td(_0x394e07['_repo'],_0x394e07['_path'],_0x45fafc,_0x358d38['wrapCallback'](()=>{})),_0x358d38['promise'];}function w_(_0x53af4f){_0x53af4f=P(_0x53af4f);const _0x4d5983=new pa(()=>{}),_0x4fba9c=new Qn(_0x4d5983);return wd(_0x53af4f['_repo'],_0x53af4f,_0x4fba9c)['then'](_0x323620=>new lt(_0x323620,new ee(_0x53af4f['_repo'],_0x53af4f['_path']),_0x53af4f['_queryParams']['getIndex']()));}class Qn{constructor(_0x4a7e34){this['callbackContext']=_0x4a7e34;}['respondsTo'](_0x4f7e4d){return _0x4f7e4d==='value';}['createEvent'](_0x4469a4,_0x120746){const _0x2d980b=_0x120746['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4469a4['snapshotNode'],new ee(_0x120746['_repo'],_0x120746['_path']),_0x2d980b));}['getEventRunner'](_0x517b0e){return _0x517b0e['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x517b0e['error']):()=>this['callbackContext']['onValue'](_0x517b0e['snapshot'],null);}['createCancelEvent'](_0x182867,_0x5b3093){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x182867,_0x5b3093):null;}['matches'](_0x18d28d){return _0x18d28d instanceof Qn?!_0x18d28d['callbackContext']||!this['callbackContext']?!0x0:_0x18d28d['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x56e814,_0x46c639,_0x5029e0,_0x271452,_0x412b6a){const _0x3a8944=new pa(_0x5029e0,void 0x0),_0x4aa92e=new Qn(_0x3a8944);return kd(_0x56e814['_repo'],_0x56e814,_0x4aa92e),()=>Pd(_0x56e814['_repo'],_0x56e814,_0x4aa92e);}function Gd(_0x657a14,_0x2b54f2,_0x5a55a1,_0x4a5eea){return $d(_0x657a14,'value',_0x2b54f2);}class mt{}class ma extends mt{constructor(_0x3963d4,_0x5a053e){super(),this['_value']=_0x3963d4,this['_key']=_0x5a053e,this['type']='endAt';}['_apply'](_0xed5c70){He('endAt',this['_value'],_0xed5c70['_path'],!0x0);const _0x551ea5=Jh(_0xed5c70['_queryParams'],this['_value'],this['_key']);if(ga(_0x551ea5),Yn(_0x551ea5),_0xed5c70['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0xed5c70['_repo'],_0xed5c70['_path'],_0x551ea5,_0xed5c70['_orderByCalled']);}}function C_(_0x399758,_0x3de20c){return new ma(_0x399758,_0x3de20c);}class ya extends mt{constructor(_0x106179,_0x3fdcc2){super(),this['_value']=_0x106179,this['_key']=_0x3fdcc2,this['type']='startAt';}['_apply'](_0x5da280){He('startAt',this['_value'],_0x5da280['_path'],!0x0);const _0x2bf4d7=Qh(_0x5da280['_queryParams'],this['_value'],this['_key']);if(ga(_0x2bf4d7),Yn(_0x2bf4d7),_0x5da280['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5da280['_repo'],_0x5da280['_path'],_0x2bf4d7,_0x5da280['_orderByCalled']);}}function T_(_0x536712=null,_0x1e1271){return new ya(_0x536712,_0x1e1271);}class qd extends mt{constructor(_0x4f0658){super(),this['_limit']=_0x4f0658,this['type']='limitToFirst';}['_apply'](_0x55359a){if(_0x55359a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x55359a['_repo'],_0x55359a['_path'],Yh(_0x55359a['_queryParams'],this['_limit']),_0x55359a['_orderByCalled']);}}function S_(_0xd8ccd5){if(Math['floor'](_0xd8ccd5)!==_0xd8ccd5||_0xd8ccd5<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0xd8ccd5);}class zd extends mt{constructor(_0x53a961){super(),this['_path']=_0x53a961,this['type']='orderByChild';}['_apply'](_0x59a72e){_a(_0x59a72e,'orderByChild');const _0x110918=new C(this['_path']);if(v(_0x110918))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2b5767=new Ji(_0x110918),_0x31d9fd=xo(_0x59a72e['_queryParams'],_0x2b5767);return Yn(_0x31d9fd),new Ae(_0x59a72e['_repo'],_0x59a72e['_path'],_0x31d9fd,!0x0);}}function b_(_0x5b4e8b){if(_0x5b4e8b==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5b4e8b==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5b4e8b==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5b4e8b),new zd(_0x5b4e8b);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4bd072){_a(_0x4bd072,'orderByKey');const _0x3eb279=xo(_0x4bd072['_queryParams'],ve);return Yn(_0x3eb279),new Ae(_0x4bd072['_repo'],_0x4bd072['_path'],_0x3eb279,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x46dc05,_0x15708f){super(),this['_value']=_0x46dc05,this['_key']=_0x15708f,this['type']='equalTo';}['_apply'](_0x2db364){if(He('equalTo',this['_value'],_0x2db364['_path'],!0x1),_0x2db364['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2db364['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2db364));}}function A_(_0x5cf093,_0x4dcf2c){return new Kd(_0x5cf093,_0x4dcf2c);}function k_(_0x39e235,..._0x273f16){let _0x1776a2=P(_0x39e235);for(const _0x3c6945 of _0x273f16)_0x1776a2=_0x3c6945['_apply'](_0x1776a2);return _0x1776a2;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x2c9d36,_0x441b55,_0x27694e,_0x20f2b5){const _0x35aee2=_0x441b55['lastIndexOf'](':'),_0x1005a8=_0x441b55['substring'](0x0,_0x35aee2),_0x48fd0a=qt(_0x1005a8);_0x2c9d36['repoInfo_']=new yo(_0x441b55,_0x48fd0a,_0x2c9d36['repoInfo_']['namespace'],_0x2c9d36['repoInfo_']['webSocketOnly'],_0x2c9d36['repoInfo_']['nodeAdmin'],_0x2c9d36['repoInfo_']['persistenceKey'],_0x2c9d36['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x27694e),_0x20f2b5&&(_0x2c9d36['authTokenProvider_']=_0x20f2b5);}function Xd(_0xc9b1eb,_0x58912a,_0x6d29ff,_0x277376,_0x3d5cf6){let _0x2c4c67=_0x277376||_0xc9b1eb['options']['databaseURL'];_0x2c4c67===void 0x0&&(_0xc9b1eb['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0xc9b1eb['options']['projectId']),_0x2c4c67=_0xc9b1eb['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4553c3=vr(_0x2c4c67,_0x3d5cf6),_0x14f51c=_0x4553c3['repoInfo'],_0x21b5f3;typeof process<'u'&&Bs&&(_0x21b5f3=Bs[Yd]),_0x21b5f3?(_0x2c4c67='http://'+_0x21b5f3+'?ns='+_0x14f51c['namespace'],_0x4553c3=vr(_0x2c4c67,_0x3d5cf6),_0x14f51c=_0x4553c3['repoInfo']):_0x4553c3['repoInfo']['secure'];const _0x11844f=new eh(_0xc9b1eb['name'],_0xc9b1eb['options'],_0x58912a);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4553c3),v(_0x4553c3['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5c664e=ef(_0x14f51c,_0xc9b1eb,_0x11844f,new Zl(_0xc9b1eb,_0x6d29ff));return new tf(_0x5c664e,_0xc9b1eb);}function Zd(_0x877334,_0x12e8a4){const _0x55d01a=Di[_0x12e8a4];(!_0x55d01a||_0x55d01a[_0x877334['key']]!==_0x877334)&&ae('Database\x20'+_0x12e8a4+'('+_0x877334['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x877334),delete _0x55d01a[_0x877334['key']];}function ef(_0x5a858b,_0x351446,_0x14d1f2,_0x1ed1e2){let _0x58e7a7=Di[_0x351446['name']];_0x58e7a7||(_0x58e7a7={},Di[_0x351446['name']]=_0x58e7a7);let _0x4e7564=_0x58e7a7[_0x5a858b['toURLString']()];return _0x4e7564&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4e7564=new vd(_0x5a858b,Qd,_0x14d1f2,_0x1ed1e2),_0x58e7a7[_0x5a858b['toURLString']()]=_0x4e7564,_0x4e7564;}class tf{constructor(_0x635a2a,_0x4f8824){this['_repoInternal']=_0x635a2a,this['app']=_0x4f8824,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4fb098){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4fb098+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4bc4e0=Zr(),_0x53154a){const _0x39ec59=Hi(_0x4bc4e0,'database')['getImmediate']({'identifier':_0x53154a});if(!_0x39ec59['_instanceStarted']){const _0x30de21=hc('database');_0x30de21&&nf(_0x39ec59,..._0x30de21);}return _0x39ec59;}function nf(_0x4852c5,_0x4a722e,_0x8c24f7,_0x38e02f={}){_0x4852c5=P(_0x4852c5),_0x4852c5['_checkNotDeleted']('useEmulator');const _0x1c7488=_0x4a722e+':'+_0x8c24f7,_0x1f53aa=_0x4852c5['_repoInternal'];if(_0x4852c5['_instanceStarted']){if(_0x1c7488===_0x4852c5['_repoInternal']['repoInfo_']['host']&&xe(_0x38e02f,_0x1f53aa['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x13cbd4;if(_0x1f53aa['repoInfo_']['nodeAdmin'])_0x38e02f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x13cbd4=new an(an['OWNER']);else{if(_0x38e02f['mockUserToken']){const _0x2c8372=typeof _0x38e02f['mockUserToken']=='string'?_0x38e02f['mockUserToken']:uc(_0x38e02f['mockUserToken'],_0x4852c5['app']['options']['projectId']);_0x13cbd4=new an(_0x2c8372);}}qt(_0x4a722e)&&Qr(_0x4a722e),Jd(_0x1f53aa,_0x1c7488,_0x38e02f,_0x13cbd4);}function N_(_0x56e366){_0x56e366=P(_0x56e366),_0x56e366['_checkNotDeleted']('goOffline'),ha(_0x56e366['_repo']);}function O_(_0x140a60){_0x140a60=P(_0x140a60),_0x140a60['_checkNotDeleted']('goOnline'),Nd(_0x140a60['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x2fccc5){Ul(dt),st(new Fe('database',(_0x36c327,{instanceIdentifier:_0x2198c9})=>{const _0x53f249=_0x36c327['getProvider']('app')['getImmediate'](),_0x526b78=_0x36c327['getProvider']('auth-internal'),_0xbc0ef5=_0x36c327['getProvider']('app-check-internal');return Xd(_0x53f249,_0x526b78,_0xbc0ef5,_0x2198c9);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x2fccc5),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x2642d2,_0x3e678c){this['committed']=_0x2642d2,this['snapshot']=_0x3e678c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x217dd6,_0x299489,_0x1343a9){if(_0x217dd6=P(_0x217dd6),Me('Reference.transaction',_0x217dd6['_path']),_0x217dd6['key']==='.length'||_0x217dd6['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x217dd6['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3590bb=!0x0,_0x186a96=new H(),_0x4a2757=(_0x5cea5b,_0x18d782,_0x4605b7)=>{let _0x4b22db=null;_0x5cea5b?_0x186a96['reject'](_0x5cea5b):(_0x4b22db=new lt(_0x4605b7,new ee(_0x217dd6['_repo'],_0x217dd6['_path']),R),_0x186a96['resolve'](new of(_0x18d782,_0x4b22db)));},_0xbfab71=Gd(_0x217dd6,()=>{});return Od(_0x217dd6['_repo'],_0x217dd6['_path'],_0x299489,_0x4a2757,_0xbfab71,_0x3590bb),_0x186a96['promise'];}se['prototype']['simpleListen']=function(_0x47f9ef,_0x5a773b){this['sendRequest']('q',{'p':_0x47f9ef},_0x5a773b);},se['prototype']['echo']=function(_0x2d058b,_0x1f876b){this['sendRequest']('echo',{'d':_0x2d058b},_0x1f876b);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x3e1d5e,..._0xdff9dc){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x3e1d5e,..._0xdff9dc);}function cn(_0x56b19d,..._0x2a7093){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x56b19d,..._0x2a7093);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x428166,..._0x2ff6b9){throw ws(_0x428166,..._0x2ff6b9);}function X(_0x4a1104,..._0x93eecb){return ws(_0x4a1104,..._0x93eecb);}function Ia(_0x3db830,_0x422352,_0x4d3b13){const _0x1e90bd={...af(),[_0x422352]:_0x4d3b13};return new Gt('auth','Firebase',_0x1e90bd)['create'](_0x422352,{'appName':_0x3db830['name']});}function re(_0x3c1b15){return Ia(_0x3c1b15,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xb68c46,..._0x38c105){if(typeof _0xb68c46!='string'){const _0x2833c9=_0x38c105[0x0],_0x4569e5=[..._0x38c105['slice'](0x1)];return _0x4569e5[0x0]&&(_0x4569e5[0x0]['appName']=_0xb68c46['name']),_0xb68c46['_errorFactory']['create'](_0x2833c9,..._0x4569e5);}return Ea['create'](_0xb68c46,..._0x38c105);}function m(_0xa429d1,_0x125cc0,..._0x2a02d6){if(!_0xa429d1)throw ws(_0x125cc0,..._0x2a02d6);}function ne(_0x14dc61){const _0x3552fc='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x14dc61;throw cn(_0x3552fc),new Error(_0x3552fc);}function ce(_0xcff967,_0x19e093){_0xcff967||ne(_0x19e093);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x25d07f;return typeof self<'u'&&((_0x25d07f=self['location'])==null?void 0x0:_0x25d07f['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x8b307f;return typeof self<'u'&&((_0x8b307f=self['location'])==null?void 0x0:_0x8b307f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x30e852=navigator;return _0x30e852['languages']&&_0x30e852['languages'][0x0]||_0x30e852['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x18dbf9,_0x5a0ba1){this['shortDelay']=_0x18dbf9,this['longDelay']=_0x5a0ba1,ce(_0x5a0ba1>_0x18dbf9,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x1a966d,_0x3c1538){ce(_0x1a966d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x476da5}=_0x1a966d['emulator'];return _0x3c1538?''+_0x476da5+(_0x3c1538['startsWith']('/')?_0x3c1538['slice'](0x1):_0x3c1538):_0x476da5;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x133a7c,_0x47495e,_0x1a0f33){this['fetchImpl']=_0x133a7c,_0x47495e&&(this['headersImpl']=_0x47495e),_0x1a0f33&&(this['responseImpl']=_0x1a0f33);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x348308,_0x465bee){return _0x348308['tenantId']&&!_0x465bee['tenantId']?{..._0x465bee,'tenantId':_0x348308['tenantId']}:_0x465bee;}async function Pe(_0x3a9cc2,_0x164115,_0xe594b,_0x16e640,_0x297334={}){return Ca(_0x3a9cc2,_0x297334,async()=>{let _0x38be1b={},_0x3a3115={};_0x16e640&&(_0x164115==='GET'?_0x3a3115=_0x16e640:_0x38be1b={'body':JSON['stringify'](_0x16e640)});const _0x3f6674=ut({..._0x3a3115,'key':_0x3a9cc2['config']['apiKey']})['slice'](0x1),_0x179a03=await _0x3a9cc2['_getAdditionalHeaders']();_0x179a03['Content-Type']='application/json',_0x3a9cc2['languageCode']&&(_0x179a03['X-Firebase-Locale']=_0x3a9cc2['languageCode']);const _0x438d8f={'method':_0x164115,'headers':_0x179a03,..._0x38be1b};return dc()||(_0x438d8f['referrerPolicy']='strict-origin-when-cross-origin'),_0x3a9cc2['emulatorConfig']&&qt(_0x3a9cc2['emulatorConfig']['host'])&&(_0x438d8f['credentials']='include'),wa['fetch']()(await Ta(_0x3a9cc2,_0x3a9cc2['config']['apiHost'],_0xe594b,_0x3f6674),_0x438d8f);});}async function Ca(_0x2ec563,_0x29dae8,_0x7dec14){_0x2ec563['_canInitEmulator']=!0x1;const _0x42a5f0={...df,..._0x29dae8};try{const _0x2b79cb=new gf(_0x2ec563),_0xc6613a=await Promise['race']([_0x7dec14(),_0x2b79cb['promise']]);_0x2b79cb['clearNetworkTimeout']();const _0x5d3dcc=await _0xc6613a['json']();if('needConfirmation'in _0x5d3dcc)throw on(_0x2ec563,'account-exists-with-different-credential',_0x5d3dcc);if(_0xc6613a['ok']&&!('errorMessage'in _0x5d3dcc))return _0x5d3dcc;{const _0x27dfd0=_0xc6613a['ok']?_0x5d3dcc['errorMessage']:_0x5d3dcc['error']['message'],[_0x47e24d,_0x5630df]=_0x27dfd0['split']('\x20:\x20');if(_0x47e24d==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2ec563,'credential-already-in-use',_0x5d3dcc);if(_0x47e24d==='EMAIL_EXISTS')throw on(_0x2ec563,'email-already-in-use',_0x5d3dcc);if(_0x47e24d==='USER_DISABLED')throw on(_0x2ec563,'user-disabled',_0x5d3dcc);const _0x29cba2=_0x42a5f0[_0x47e24d]||_0x47e24d['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5630df)throw Ia(_0x2ec563,_0x29cba2,_0x5630df);Y(_0x2ec563,_0x29cba2);}}catch(_0x35bb58){if(_0x35bb58 instanceof Re)throw _0x35bb58;Y(_0x2ec563,'network-request-failed',{'message':String(_0x35bb58)});}}async function en(_0x232da2,_0x5c813b,_0xb60326,_0x19d3c1,_0x9d658e={}){const _0x4975d6=await Pe(_0x232da2,_0x5c813b,_0xb60326,_0x19d3c1,_0x9d658e);return'mfaPendingCredential'in _0x4975d6&&Y(_0x232da2,'multi-factor-auth-required',{'_serverResponse':_0x4975d6}),_0x4975d6;}async function Ta(_0x47fd33,_0x13f456,_0x36300f,_0x5259b7){const _0x25a32c=''+_0x13f456+_0x36300f+'?'+_0x5259b7,_0x51eef3=_0x47fd33,_0x4fa82d=_0x51eef3['config']['emulator']?Cs(_0x47fd33['config'],_0x25a32c):_0x47fd33['config']['apiScheme']+'://'+_0x25a32c;return ff['includes'](_0x36300f)&&(await _0x51eef3['_persistenceManagerAvailable'],_0x51eef3['_getPersistenceType']()==='COOKIE')?_0x51eef3['_getPersistence']()['_getFinalTarget'](_0x4fa82d)['toString']():_0x4fa82d;}function _f(_0x468603){switch(_0x468603){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x36c453){this['auth']=_0x36c453,this['timer']=null,this['promise']=new Promise((_0x8fd8d6,_0x278e9c)=>{this['timer']=setTimeout(()=>_0x278e9c(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x1d2e07,_0x370b4e,_0x137f8f){const _0x4f10e6={'appName':_0x1d2e07['name']};_0x137f8f['email']&&(_0x4f10e6['email']=_0x137f8f['email']),_0x137f8f['phoneNumber']&&(_0x4f10e6['phoneNumber']=_0x137f8f['phoneNumber']);const _0x2576b0=X(_0x1d2e07,_0x370b4e,_0x4f10e6);return _0x2576b0['customData']['_tokenResponse']=_0x137f8f,_0x2576b0;}function wr(_0x191cf9){return _0x191cf9!==void 0x0&&_0x191cf9['enterprise']!==void 0x0;}class mf{constructor(_0xe84fbf){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0xe84fbf['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0xe84fbf['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0xe84fbf['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x189897){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x8682d4 of this['recaptchaEnforcementState'])if(_0x8682d4['provider']&&_0x8682d4['provider']===_0x189897)return _f(_0x8682d4['enforcementState']);return null;}['isProviderEnabled'](_0x24dbfe){return this['getProviderEnforcementState'](_0x24dbfe)==='ENFORCE'||this['getProviderEnforcementState'](_0x24dbfe)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x381fc3,_0x49d876){return Pe(_0x381fc3,'GET','/v2/recaptchaConfig',ke(_0x381fc3,_0x49d876));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x123b6a,_0x22f705){return Pe(_0x123b6a,'POST','/v1/accounts:delete',_0x22f705);}async function Pn(_0x4cf307,_0x27bd88){return Pe(_0x4cf307,'POST','/v1/accounts:lookup',_0x27bd88);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2b5fd6){if(_0x2b5fd6)try{const _0x43939e=new Date(Number(_0x2b5fd6));if(!isNaN(_0x43939e['getTime']()))return _0x43939e['toUTCString']();}catch{}}async function Ef(_0x280691,_0x408d79=!0x1){const _0x1d4253=P(_0x280691),_0x2cc1fe=await _0x1d4253['getIdToken'](_0x408d79),_0x5cea95=Ts(_0x2cc1fe);m(_0x5cea95&&_0x5cea95['exp']&&_0x5cea95['auth_time']&&_0x5cea95['iat'],_0x1d4253['auth'],'internal-error');const _0x3673c8=typeof _0x5cea95['firebase']=='object'?_0x5cea95['firebase']:void 0x0,_0x11cf5d=_0x3673c8==null?void 0x0:_0x3673c8['sign_in_provider'];return{'claims':_0x5cea95,'token':_0x2cc1fe,'authTime':Pt(fi(_0x5cea95['auth_time'])),'issuedAtTime':Pt(fi(_0x5cea95['iat'])),'expirationTime':Pt(fi(_0x5cea95['exp'])),'signInProvider':_0x11cf5d||null,'signInSecondFactor':(_0x3673c8==null?void 0x0:_0x3673c8['sign_in_second_factor'])||null};}function fi(_0x2be18f){return Number(_0x2be18f)*0x3e8;}function Ts(_0x21db6d){const [_0x31f7b0,_0x232233,_0x16f8f7]=_0x21db6d['split']('.');if(_0x31f7b0===void 0x0||_0x232233===void 0x0||_0x16f8f7===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x10a4e3=fn(_0x232233);return _0x10a4e3?JSON['parse'](_0x10a4e3):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x258612){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x258612==null?void 0x0:_0x258612['toString']()),null;}}function Cr(_0x576f31){const _0x380cfa=Ts(_0x576f31);return m(_0x380cfa,'internal-error'),m(typeof _0x380cfa['exp']<'u','internal-error'),m(typeof _0x380cfa['iat']<'u','internal-error'),Number(_0x380cfa['exp'])-Number(_0x380cfa['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x30fc69,_0xcdf3a3,_0x2055c3=!0x1){if(_0x2055c3)return _0xcdf3a3;try{return await _0xcdf3a3;}catch(_0x4eb02b){throw _0x4eb02b instanceof Re&&If(_0x4eb02b)&&_0x30fc69['auth']['currentUser']===_0x30fc69&&await _0x30fc69['auth']['signOut'](),_0x4eb02b;}}function If({code:_0x271956}){return _0x271956==='auth/user-disabled'||_0x271956==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x24894c){this['user']=_0x24894c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x307371){if(_0x307371){const _0x32e107=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x32e107;}else{this['errorBackoff']=0x7530;const _0x1773df=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1773df);}}['schedule'](_0x176bbc=!0x1){if(!this['isRunning'])return;const _0x51414a=this['getInterval'](_0x176bbc);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x51414a);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1fc6af){(_0x1fc6af==null?void 0x0:_0x1fc6af['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x31e88e,_0x526f98){this['createdAt']=_0x31e88e,this['lastLoginAt']=_0x526f98,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x3668e7){this['createdAt']=_0x3668e7['createdAt'],this['lastLoginAt']=_0x3668e7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x4e12c1){var _0x5910e4;const _0x56f7e5=_0x4e12c1['auth'],_0x561eb3=await _0x4e12c1['getIdToken'](),_0x2a84d9=await Ht(_0x4e12c1,Pn(_0x56f7e5,{'idToken':_0x561eb3}));m(_0x2a84d9==null?void 0x0:_0x2a84d9['users']['length'],_0x56f7e5,'internal-error');const _0xd01db5=_0x2a84d9['users'][0x0];_0x4e12c1['_notifyReloadListener'](_0xd01db5);const _0x503139=(_0x5910e4=_0xd01db5['providerUserInfo'])!=null&&_0x5910e4['length']?Sa(_0xd01db5['providerUserInfo']):[],_0x365073=Tf(_0x4e12c1['providerData'],_0x503139),_0x4f022c=_0x4e12c1['isAnonymous'],_0x5239c2=!(_0x4e12c1['email']&&_0xd01db5['passwordHash'])&&!(_0x365073!=null&&_0x365073['length']),_0x224a0f=_0x4f022c?_0x5239c2:!0x1,_0x4eca91={'uid':_0xd01db5['localId'],'displayName':_0xd01db5['displayName']||null,'photoURL':_0xd01db5['photoUrl']||null,'email':_0xd01db5['email']||null,'emailVerified':_0xd01db5['emailVerified']||!0x1,'phoneNumber':_0xd01db5['phoneNumber']||null,'tenantId':_0xd01db5['tenantId']||null,'providerData':_0x365073,'metadata':new Li(_0xd01db5['createdAt'],_0xd01db5['lastLoginAt']),'isAnonymous':_0x224a0f};Object['assign'](_0x4e12c1,_0x4eca91);}async function Cf(_0x110c09){const _0x1ca633=P(_0x110c09);await Nn(_0x1ca633),await _0x1ca633['auth']['_persistUserIfCurrent'](_0x1ca633),_0x1ca633['auth']['_notifyListenersIfCurrent'](_0x1ca633);}function Tf(_0x545082,_0x196d60){return[..._0x545082['filter'](_0x367f85=>!_0x196d60['some'](_0x11e2c9=>_0x11e2c9['providerId']===_0x367f85['providerId'])),..._0x196d60];}function Sa(_0x3c011a){return _0x3c011a['map'](({providerId:_0x23a0bc,..._0x3ce873})=>({'providerId':_0x23a0bc,'uid':_0x3ce873['rawId']||'','displayName':_0x3ce873['displayName']||null,'email':_0x3ce873['email']||null,'phoneNumber':_0x3ce873['phoneNumber']||null,'photoURL':_0x3ce873['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x5da3b9,_0x27b639){const _0x3178df=await Ca(_0x5da3b9,{},async()=>{const _0x333163=ut({'grant_type':'refresh_token','refresh_token':_0x27b639})['slice'](0x1),{tokenApiHost:_0x18be8b,apiKey:_0x12e64f}=_0x5da3b9['config'],_0x3c2458=await Ta(_0x5da3b9,_0x18be8b,'/v1/token','key='+_0x12e64f),_0x5a9846=await _0x5da3b9['_getAdditionalHeaders']();_0x5a9846['Content-Type']='application/x-www-form-urlencoded';const _0x53d731={'method':'POST','headers':_0x5a9846,'body':_0x333163};return _0x5da3b9['emulatorConfig']&&qt(_0x5da3b9['emulatorConfig']['host'])&&(_0x53d731['credentials']='include'),wa['fetch']()(_0x3c2458,_0x53d731);});return{'accessToken':_0x3178df['access_token'],'expiresIn':_0x3178df['expires_in'],'refreshToken':_0x3178df['refresh_token']};}async function bf(_0x344802,_0x2fc95b){return Pe(_0x344802,'POST','/v2/accounts:revokeToken',ke(_0x344802,_0x2fc95b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x32ca62){m(_0x32ca62['idToken'],'internal-error'),m(typeof _0x32ca62['idToken']<'u','internal-error'),m(typeof _0x32ca62['refreshToken']<'u','internal-error');const _0x1d3194='expiresIn'in _0x32ca62&&typeof _0x32ca62['expiresIn']<'u'?Number(_0x32ca62['expiresIn']):Cr(_0x32ca62['idToken']);this['updateTokensAndExpiration'](_0x32ca62['idToken'],_0x32ca62['refreshToken'],_0x1d3194);}['updateFromIdToken'](_0x52f59f){m(_0x52f59f['length']!==0x0,'internal-error');const _0x36732d=Cr(_0x52f59f);this['updateTokensAndExpiration'](_0x52f59f,null,_0x36732d);}async['getToken'](_0x29a335,_0x184141=!0x1){return!_0x184141&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x29a335,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x29a335,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x28a6c1,_0x5e16ce){const {accessToken:_0x55db4d,refreshToken:_0x210a13,expiresIn:_0x1e11cd}=await Sf(_0x28a6c1,_0x5e16ce);this['updateTokensAndExpiration'](_0x55db4d,_0x210a13,Number(_0x1e11cd));}['updateTokensAndExpiration'](_0x333196,_0x37e964,_0x26800c){this['refreshToken']=_0x37e964||null,this['accessToken']=_0x333196||null,this['expirationTime']=Date['now']()+_0x26800c*0x3e8;}static['fromJSON'](_0x3280b8,_0x1774a6){const {refreshToken:_0x4c0e7f,accessToken:_0x3ae11e,expirationTime:_0x422cc4}=_0x1774a6,_0x1fed2f=new et();return _0x4c0e7f&&(m(typeof _0x4c0e7f=='string','internal-error',{'appName':_0x3280b8}),_0x1fed2f['refreshToken']=_0x4c0e7f),_0x3ae11e&&(m(typeof _0x3ae11e=='string','internal-error',{'appName':_0x3280b8}),_0x1fed2f['accessToken']=_0x3ae11e),_0x422cc4&&(m(typeof _0x422cc4=='number','internal-error',{'appName':_0x3280b8}),_0x1fed2f['expirationTime']=_0x422cc4),_0x1fed2f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x562ce4){this['accessToken']=_0x562ce4['accessToken'],this['refreshToken']=_0x562ce4['refreshToken'],this['expirationTime']=_0x562ce4['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x206599,_0x3728ad){m(typeof _0x206599=='string'||typeof _0x206599>'u','internal-error',{'appName':_0x3728ad});}class j{constructor({uid:_0xe0df44,auth:_0x2ab1e0,stsTokenManager:_0x38fa4a,..._0x2ddd35}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xe0df44,this['auth']=_0x2ab1e0,this['stsTokenManager']=_0x38fa4a,this['accessToken']=_0x38fa4a['accessToken'],this['displayName']=_0x2ddd35['displayName']||null,this['email']=_0x2ddd35['email']||null,this['emailVerified']=_0x2ddd35['emailVerified']||!0x1,this['phoneNumber']=_0x2ddd35['phoneNumber']||null,this['photoURL']=_0x2ddd35['photoURL']||null,this['isAnonymous']=_0x2ddd35['isAnonymous']||!0x1,this['tenantId']=_0x2ddd35['tenantId']||null,this['providerData']=_0x2ddd35['providerData']?[..._0x2ddd35['providerData']]:[],this['metadata']=new Li(_0x2ddd35['createdAt']||void 0x0,_0x2ddd35['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2a9d79){const _0x5ad492=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x2a9d79));return m(_0x5ad492,this['auth'],'internal-error'),this['accessToken']!==_0x5ad492&&(this['accessToken']=_0x5ad492,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5ad492;}['getIdTokenResult'](_0x23a6d9){return Ef(this,_0x23a6d9);}['reload'](){return Cf(this);}['_assign'](_0x3fe71a){this!==_0x3fe71a&&(m(this['uid']===_0x3fe71a['uid'],this['auth'],'internal-error'),this['displayName']=_0x3fe71a['displayName'],this['photoURL']=_0x3fe71a['photoURL'],this['email']=_0x3fe71a['email'],this['emailVerified']=_0x3fe71a['emailVerified'],this['phoneNumber']=_0x3fe71a['phoneNumber'],this['isAnonymous']=_0x3fe71a['isAnonymous'],this['tenantId']=_0x3fe71a['tenantId'],this['providerData']=_0x3fe71a['providerData']['map'](_0x5b5361=>({..._0x5b5361})),this['metadata']['_copy'](_0x3fe71a['metadata']),this['stsTokenManager']['_assign'](_0x3fe71a['stsTokenManager']));}['_clone'](_0x382fc2){const _0x305cd3=new j({...this,'auth':_0x382fc2,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x305cd3['metadata']['_copy'](this['metadata']),_0x305cd3;}['_onReload'](_0xeb7736){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xeb7736,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x11de83){this['reloadListener']?this['reloadListener'](_0x11de83):this['reloadUserInfo']=_0x11de83;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xa3536a,_0x5ba3c6=!0x1){let _0x216df8=!0x1;_0xa3536a['idToken']&&_0xa3536a['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xa3536a),_0x216df8=!0x0),_0x5ba3c6&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x216df8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x626593=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x626593})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x48e300=>({..._0x48e300})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x21a2da,_0x32a2e4){const _0x999b90=_0x32a2e4['displayName']??void 0x0,_0x277154=_0x32a2e4['email']??void 0x0,_0x7155fe=_0x32a2e4['phoneNumber']??void 0x0,_0x363b0e=_0x32a2e4['photoURL']??void 0x0,_0x5288a=_0x32a2e4['tenantId']??void 0x0,_0x53d611=_0x32a2e4['_redirectEventId']??void 0x0,_0x3625da=_0x32a2e4['createdAt']??void 0x0,_0x36a339=_0x32a2e4['lastLoginAt']??void 0x0,{uid:_0x5363f6,emailVerified:_0x1ccd7e,isAnonymous:_0x2b71fd,providerData:_0x4a4b21,stsTokenManager:_0x4dda04}=_0x32a2e4;m(_0x5363f6&&_0x4dda04,_0x21a2da,'internal-error');const _0x23a754=et['fromJSON'](this['name'],_0x4dda04);m(typeof _0x5363f6=='string',_0x21a2da,'internal-error'),le(_0x999b90,_0x21a2da['name']),le(_0x277154,_0x21a2da['name']),m(typeof _0x1ccd7e=='boolean',_0x21a2da,'internal-error'),m(typeof _0x2b71fd=='boolean',_0x21a2da,'internal-error'),le(_0x7155fe,_0x21a2da['name']),le(_0x363b0e,_0x21a2da['name']),le(_0x5288a,_0x21a2da['name']),le(_0x53d611,_0x21a2da['name']),le(_0x3625da,_0x21a2da['name']),le(_0x36a339,_0x21a2da['name']);const _0x147ac0=new j({'uid':_0x5363f6,'auth':_0x21a2da,'email':_0x277154,'emailVerified':_0x1ccd7e,'displayName':_0x999b90,'isAnonymous':_0x2b71fd,'photoURL':_0x363b0e,'phoneNumber':_0x7155fe,'tenantId':_0x5288a,'stsTokenManager':_0x23a754,'createdAt':_0x3625da,'lastLoginAt':_0x36a339});return _0x4a4b21&&Array['isArray'](_0x4a4b21)&&(_0x147ac0['providerData']=_0x4a4b21['map'](_0x359cce=>({..._0x359cce}))),_0x53d611&&(_0x147ac0['_redirectEventId']=_0x53d611),_0x147ac0;}static async['_fromIdTokenResponse'](_0x57597b,_0x2d8d30,_0x286987=!0x1){const _0x26a133=new et();_0x26a133['updateFromServerResponse'](_0x2d8d30);const _0x105f79=new j({'uid':_0x2d8d30['localId'],'auth':_0x57597b,'stsTokenManager':_0x26a133,'isAnonymous':_0x286987});return await Nn(_0x105f79),_0x105f79;}static async['_fromGetAccountInfoResponse'](_0xfb0299,_0x3c4f60,_0x1b3665){const _0x51d1c0=_0x3c4f60['users'][0x0];m(_0x51d1c0['localId']!==void 0x0,'internal-error');const _0x353b63=_0x51d1c0['providerUserInfo']!==void 0x0?Sa(_0x51d1c0['providerUserInfo']):[],_0x45ef42=!(_0x51d1c0['email']&&_0x51d1c0['passwordHash'])&&!(_0x353b63!=null&&_0x353b63['length']),_0xf0cacb=new et();_0xf0cacb['updateFromIdToken'](_0x1b3665);const _0x3c8ff8=new j({'uid':_0x51d1c0['localId'],'auth':_0xfb0299,'stsTokenManager':_0xf0cacb,'isAnonymous':_0x45ef42}),_0x543df1={'uid':_0x51d1c0['localId'],'displayName':_0x51d1c0['displayName']||null,'photoURL':_0x51d1c0['photoUrl']||null,'email':_0x51d1c0['email']||null,'emailVerified':_0x51d1c0['emailVerified']||!0x1,'phoneNumber':_0x51d1c0['phoneNumber']||null,'tenantId':_0x51d1c0['tenantId']||null,'providerData':_0x353b63,'metadata':new Li(_0x51d1c0['createdAt'],_0x51d1c0['lastLoginAt']),'isAnonymous':!(_0x51d1c0['email']&&_0x51d1c0['passwordHash'])&&!(_0x353b63!=null&&_0x353b63['length'])};return Object['assign'](_0x3c8ff8,_0x543df1),_0x3c8ff8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x15ad1b){ce(_0x15ad1b instanceof Function,'Expected\x20a\x20class\x20definition');let _0x35a595=Tr['get'](_0x15ad1b);return _0x35a595?(ce(_0x35a595 instanceof _0x15ad1b,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x35a595):(_0x35a595=new _0x15ad1b(),Tr['set'](_0x15ad1b,_0x35a595),_0x35a595);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x141392,_0x5bffee){this['storage'][_0x141392]=_0x5bffee;}async['_get'](_0x509c2a){const _0x303bf0=this['storage'][_0x509c2a];return _0x303bf0===void 0x0?null:_0x303bf0;}async['_remove'](_0x266d7a){delete this['storage'][_0x266d7a];}['_addListener'](_0x75c0f,_0x1728d5){}['_removeListener'](_0x351bbe,_0x2a2715){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x511786,_0x7de84b,_0x3f3dcb){return'firebase:'+_0x511786+':'+_0x7de84b+':'+_0x3f3dcb;}class tt{constructor(_0x64d780,_0x367ec6,_0xaff717){this['persistence']=_0x64d780,this['auth']=_0x367ec6,this['userKey']=_0xaff717;const {config:_0x23b8c2,name:_0x3265f0}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x23b8c2['apiKey'],_0x3265f0),this['fullPersistenceKey']=ln('persistence',_0x23b8c2['apiKey'],_0x3265f0),this['boundEventHandler']=_0x367ec6['_onStorageEvent']['bind'](_0x367ec6),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x516864){return this['persistence']['_set'](this['fullUserKey'],_0x516864['toJSON']());}async['getCurrentUser'](){const _0x56d1df=await this['persistence']['_get'](this['fullUserKey']);if(!_0x56d1df)return null;if(typeof _0x56d1df=='string'){const _0x42d05a=await Pn(this['auth'],{'idToken':_0x56d1df})['catch'](()=>{});return _0x42d05a?j['_fromGetAccountInfoResponse'](this['auth'],_0x42d05a,_0x56d1df):null;}return j['_fromJSON'](this['auth'],_0x56d1df);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x291a4d){if(this['persistence']===_0x291a4d)return;const _0x392152=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x291a4d,_0x392152)return this['setCurrentUser'](_0x392152);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x591f0a,_0x2e3f9f,_0xa48853='authUser'){if(!_0x2e3f9f['length'])return new tt(ie(Sr),_0x591f0a,_0xa48853);const _0x4c90d1=(await Promise['all'](_0x2e3f9f['map'](async _0x549043=>{if(await _0x549043['_isAvailable']())return _0x549043;})))['filter'](_0x55d9d1=>_0x55d9d1);let _0x3b3717=_0x4c90d1[0x0]||ie(Sr);const _0x4595b3=ln(_0xa48853,_0x591f0a['config']['apiKey'],_0x591f0a['name']);let _0x1f8001=null;for(const _0x4599b4 of _0x2e3f9f)try{const _0xd7e383=await _0x4599b4['_get'](_0x4595b3);if(_0xd7e383){let _0x29100b;if(typeof _0xd7e383=='string'){const _0x42b83a=await Pn(_0x591f0a,{'idToken':_0xd7e383})['catch'](()=>{});if(!_0x42b83a)break;_0x29100b=await j['_fromGetAccountInfoResponse'](_0x591f0a,_0x42b83a,_0xd7e383);}else _0x29100b=j['_fromJSON'](_0x591f0a,_0xd7e383);_0x4599b4!==_0x3b3717&&(_0x1f8001=_0x29100b),_0x3b3717=_0x4599b4;break;}}catch{}const _0x14113f=_0x4c90d1['filter'](_0x160508=>_0x160508['_shouldAllowMigration']);return!_0x3b3717['_shouldAllowMigration']||!_0x14113f['length']?new tt(_0x3b3717,_0x591f0a,_0xa48853):(_0x3b3717=_0x14113f[0x0],_0x1f8001&&await _0x3b3717['_set'](_0x4595b3,_0x1f8001['toJSON']()),await Promise['all'](_0x2e3f9f['map'](async _0x5b3157=>{if(_0x5b3157!==_0x3b3717)try{await _0x5b3157['_remove'](_0x4595b3);}catch{}})),new tt(_0x3b3717,_0x591f0a,_0xa48853));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x53feb7){const _0x55d957=_0x53feb7['toLowerCase']();if(_0x55d957['includes']('opera/')||_0x55d957['includes']('opr/')||_0x55d957['includes']('opios/'))return'Opera';if(Pa(_0x55d957))return'IEMobile';if(_0x55d957['includes']('msie')||_0x55d957['includes']('trident/'))return'IE';if(_0x55d957['includes']('edge/'))return'Edge';if(Ra(_0x55d957))return'Firefox';if(_0x55d957['includes']('silk/'))return'Silk';if(Oa(_0x55d957))return'Blackberry';if(Da(_0x55d957))return'Webos';if(Aa(_0x55d957))return'Safari';if((_0x55d957['includes']('chrome/')||ka(_0x55d957))&&!_0x55d957['includes']('edge/'))return'Chrome';if(Na(_0x55d957))return'Android';{const _0x1b7e94=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4e6d5d=_0x53feb7['match'](_0x1b7e94);if((_0x4e6d5d==null?void 0x0:_0x4e6d5d['length'])===0x2)return _0x4e6d5d[0x1];}return'Other';}function Ra(_0x1f7a48=W()){return/firefox\//i['test'](_0x1f7a48);}function Aa(_0x56d228=W()){const _0x47b092=_0x56d228['toLowerCase']();return _0x47b092['includes']('safari/')&&!_0x47b092['includes']('chrome/')&&!_0x47b092['includes']('crios/')&&!_0x47b092['includes']('android');}function ka(_0x591772=W()){return/crios\//i['test'](_0x591772);}function Pa(_0x3722b2=W()){return/iemobile/i['test'](_0x3722b2);}function Na(_0x346ed7=W()){return/android/i['test'](_0x346ed7);}function Oa(_0x3978b7=W()){return/blackberry/i['test'](_0x3978b7);}function Da(_0x9eee0=W()){return/webos/i['test'](_0x9eee0);}function Ss(_0xd66edc=W()){return/iphone|ipad|ipod/i['test'](_0xd66edc)||/macintosh/i['test'](_0xd66edc)&&/mobile/i['test'](_0xd66edc);}function Rf(_0x296389=W()){var _0x537187;return Ss(_0x296389)&&!!((_0x537187=window['navigator'])!=null&&_0x537187['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x51a706=W()){return Ss(_0x51a706)||Na(_0x51a706)||Da(_0x51a706)||Oa(_0x51a706)||/windows phone/i['test'](_0x51a706)||Pa(_0x51a706);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5212b5,_0x530298=[]){let _0x408748;switch(_0x5212b5){case'Browser':_0x408748=br(W());break;case'Worker':_0x408748=br(W())+'-'+_0x5212b5;break;default:_0x408748=_0x5212b5;}const _0x4527b8=_0x530298['length']?_0x530298['join'](','):'FirebaseCore-web';return _0x408748+'/JsCore/'+dt+'/'+_0x4527b8;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x8defb4){this['auth']=_0x8defb4,this['queue']=[];}['pushCallback'](_0x30379b,_0x5b6f62){const _0x429987=_0x297c64=>new Promise((_0xf26cc4,_0x1d5762)=>{try{const _0xaa5d92=_0x30379b(_0x297c64);_0xf26cc4(_0xaa5d92);}catch(_0x53efc2){_0x1d5762(_0x53efc2);}});_0x429987['onAbort']=_0x5b6f62,this['queue']['push'](_0x429987);const _0x4335ed=this['queue']['length']-0x1;return()=>{this['queue'][_0x4335ed]=()=>Promise['resolve']();};}async['runMiddleware'](_0x15a5f7){if(this['auth']['currentUser']===_0x15a5f7)return;const _0xbdb6e2=[];try{for(const _0xbad313 of this['queue'])await _0xbad313(_0x15a5f7),_0xbad313['onAbort']&&_0xbdb6e2['push'](_0xbad313['onAbort']);}catch(_0x52c62d){_0xbdb6e2['reverse']();for(const _0x920ba0 of _0xbdb6e2)try{_0x920ba0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x52c62d==null?void 0x0:_0x52c62d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x520189,_0x4bb8cf={}){return Pe(_0x520189,'GET','/v2/passwordPolicy',ke(_0x520189,_0x4bb8cf));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x1a519c){var _0x3d0416;const _0x483dfc=_0x1a519c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x483dfc['minPasswordLength']??Nf,_0x483dfc['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x483dfc['maxPasswordLength']),_0x483dfc['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x483dfc['containsLowercaseCharacter']),_0x483dfc['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x483dfc['containsUppercaseCharacter']),_0x483dfc['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x483dfc['containsNumericCharacter']),_0x483dfc['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x483dfc['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1a519c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3d0416=_0x1a519c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3d0416['join'](''))??'',this['forceUpgradeOnSignin']=_0x1a519c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1a519c['schemaVersion'];}['validatePassword'](_0x5bc05c){const _0x91cf24={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5bc05c,_0x91cf24),this['validatePasswordCharacterOptions'](_0x5bc05c,_0x91cf24),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['meetsMinPasswordLength']??!0x0),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['meetsMaxPasswordLength']??!0x0),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['containsLowercaseLetter']??!0x0),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['containsUppercaseLetter']??!0x0),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['containsNumericCharacter']??!0x0),_0x91cf24['isValid']&&(_0x91cf24['isValid']=_0x91cf24['containsNonAlphanumericCharacter']??!0x0),_0x91cf24;}['validatePasswordLengthOptions'](_0x215a34,_0xb67958){const _0x3e603e=this['customStrengthOptions']['minPasswordLength'],_0x117a7a=this['customStrengthOptions']['maxPasswordLength'];_0x3e603e&&(_0xb67958['meetsMinPasswordLength']=_0x215a34['length']>=_0x3e603e),_0x117a7a&&(_0xb67958['meetsMaxPasswordLength']=_0x215a34['length']<=_0x117a7a);}['validatePasswordCharacterOptions'](_0xc285ba,_0x596ab3){this['updatePasswordCharacterOptionsStatuses'](_0x596ab3,!0x1,!0x1,!0x1,!0x1);let _0x44d19b;for(let _0x40df20=0x0;_0x40df20<_0xc285ba['length'];_0x40df20++)_0x44d19b=_0xc285ba['charAt'](_0x40df20),this['updatePasswordCharacterOptionsStatuses'](_0x596ab3,_0x44d19b>='a'&&_0x44d19b<='z',_0x44d19b>='A'&&_0x44d19b<='Z',_0x44d19b>='0'&&_0x44d19b<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x44d19b));}['updatePasswordCharacterOptionsStatuses'](_0x5869ec,_0x3a6a54,_0x31d5a4,_0x34b6fb,_0x5dea6a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5869ec['containsLowercaseLetter']||(_0x5869ec['containsLowercaseLetter']=_0x3a6a54)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5869ec['containsUppercaseLetter']||(_0x5869ec['containsUppercaseLetter']=_0x31d5a4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5869ec['containsNumericCharacter']||(_0x5869ec['containsNumericCharacter']=_0x34b6fb)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5869ec['containsNonAlphanumericCharacter']||(_0x5869ec['containsNonAlphanumericCharacter']=_0x5dea6a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0xe7cf42,_0x4dcefc,_0x30cf62,_0x341aa4){this['app']=_0xe7cf42,this['heartbeatServiceProvider']=_0x4dcefc,this['appCheckServiceProvider']=_0x30cf62,this['config']=_0x341aa4,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xe7cf42['name'],this['clientVersion']=_0x341aa4['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x17386b=>this['_resolvePersistenceManagerAvailable']=_0x17386b);}['_initializeWithPersistence'](_0x687a85,_0x28e9e9){return _0x28e9e9&&(this['_popupRedirectResolver']=ie(_0x28e9e9)),this['_initializationPromise']=this['queue'](async()=>{var _0x547974,_0x398276,_0x4a122e;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x687a85),(_0x547974=this['_resolvePersistenceManagerAvailable'])==null||_0x547974['call'](this),!this['_deleted'])){if((_0x398276=this['_popupRedirectResolver'])!=null&&_0x398276['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x28e9e9),this['lastNotifiedUid']=((_0x4a122e=this['currentUser'])==null?void 0x0:_0x4a122e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2d42e9=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2d42e9)){if(this['currentUser']&&_0x2d42e9&&this['currentUser']['uid']===_0x2d42e9['uid']){this['_currentUser']['_assign'](_0x2d42e9),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2d42e9,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x43a248){try{const _0x334d04=await Pn(this,{'idToken':_0x43a248}),_0x48499c=await j['_fromGetAccountInfoResponse'](this,_0x334d04,_0x43a248);await this['directlySetCurrentUser'](_0x48499c);}catch(_0x400c52){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x400c52),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x384adb){var _0x56e0b4;if($(this['app'])){const _0x5dafa3=this['app']['settings']['authIdToken'];return _0x5dafa3?new Promise(_0xe9de6a=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5dafa3)['then'](_0xe9de6a,_0xe9de6a));}):this['directlySetCurrentUser'](null);}const _0x21c0f8=await this['assertedPersistence']['getCurrentUser']();let _0x4e2317=_0x21c0f8,_0x5b4ba6=!0x1;if(_0x384adb&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3994b5=(_0x56e0b4=this['redirectUser'])==null?void 0x0:_0x56e0b4['_redirectEventId'],_0x2d51cd=_0x4e2317==null?void 0x0:_0x4e2317['_redirectEventId'],_0x14a678=await this['tryRedirectSignIn'](_0x384adb);(!_0x3994b5||_0x3994b5===_0x2d51cd)&&(_0x14a678!=null&&_0x14a678['user'])&&(_0x4e2317=_0x14a678['user'],_0x5b4ba6=!0x0);}if(!_0x4e2317)return this['directlySetCurrentUser'](null);if(!_0x4e2317['_redirectEventId']){if(_0x5b4ba6)try{await this['beforeStateQueue']['runMiddleware'](_0x4e2317);}catch(_0x3e252c){_0x4e2317=_0x21c0f8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3e252c));}return _0x4e2317?this['reloadAndSetCurrentUserOrClear'](_0x4e2317):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4e2317['_redirectEventId']?this['directlySetCurrentUser'](_0x4e2317):this['reloadAndSetCurrentUserOrClear'](_0x4e2317);}async['tryRedirectSignIn'](_0x255c7d){let _0x284629=null;try{_0x284629=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x255c7d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x284629;}async['reloadAndSetCurrentUserOrClear'](_0x4e33ac){try{await Nn(_0x4e33ac);}catch(_0xd13dee){if((_0xd13dee==null?void 0x0:_0xd13dee['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4e33ac);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x38e392){if($(this['app']))return Promise['reject'](re(this));const _0x1c2533=_0x38e392?P(_0x38e392):null;return _0x1c2533&&m(_0x1c2533['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1c2533&&_0x1c2533['_clone'](this));}async['_updateCurrentUser'](_0x140ba5,_0x376bf0=!0x1){if(!this['_deleted'])return _0x140ba5&&m(this['tenantId']===_0x140ba5['tenantId'],this,'tenant-id-mismatch'),_0x376bf0||await this['beforeStateQueue']['runMiddleware'](_0x140ba5),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x140ba5),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x194354){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x194354));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x23c222){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x356d55=this['_getPasswordPolicyInternal']();return _0x356d55['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x356d55['validatePassword'](_0x23c222);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4af064=await Pf(this),_0x282ea3=new Of(_0x4af064);this['tenantId']===null?this['_projectPasswordPolicy']=_0x282ea3:this['_tenantPasswordPolicies'][this['tenantId']]=_0x282ea3;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x17f7e9){this['_errorFactory']=new Gt('auth','Firebase',_0x17f7e9());}['onAuthStateChanged'](_0x2a1d84,_0x26f002,_0x9fa3f9){return this['registerStateListener'](this['authStateSubscription'],_0x2a1d84,_0x26f002,_0x9fa3f9);}['beforeAuthStateChanged'](_0x1514f2,_0x5af866){return this['beforeStateQueue']['pushCallback'](_0x1514f2,_0x5af866);}['onIdTokenChanged'](_0x279b5a,_0x16a740,_0x3f30be){return this['registerStateListener'](this['idTokenSubscription'],_0x279b5a,_0x16a740,_0x3f30be);}['authStateReady'](){return new Promise((_0x42aca2,_0x2057e3)=>{if(this['currentUser'])_0x42aca2();else{const _0x2ae9c0=this['onAuthStateChanged'](()=>{_0x2ae9c0(),_0x42aca2();},_0x2057e3);}});}async['revokeAccessToken'](_0x23dcf5){if(this['currentUser']){const _0x3c14b8=await this['currentUser']['getIdToken'](),_0x318d9c={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x23dcf5,'idToken':_0x3c14b8};this['tenantId']!=null&&(_0x318d9c['tenantId']=this['tenantId']),await bf(this,_0x318d9c);}}['toJSON'](){var _0x38971a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x38971a=this['_currentUser'])==null?void 0x0:_0x38971a['toJSON']()};}async['_setRedirectUser'](_0x3fd752,_0x5804bb){const _0x523e3e=await this['getOrInitRedirectPersistenceManager'](_0x5804bb);return _0x3fd752===null?_0x523e3e['removeCurrentUser']():_0x523e3e['setCurrentUser'](_0x3fd752);}async['getOrInitRedirectPersistenceManager'](_0x394c5f){if(!this['redirectPersistenceManager']){const _0x9ba164=_0x394c5f&&ie(_0x394c5f)||this['_popupRedirectResolver'];m(_0x9ba164,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x9ba164['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4d0570){var _0x2a351c,_0xaa7b39;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2a351c=this['_currentUser'])==null?void 0x0:_0x2a351c['_redirectEventId'])===_0x4d0570?this['_currentUser']:((_0xaa7b39=this['redirectUser'])==null?void 0x0:_0xaa7b39['_redirectEventId'])===_0x4d0570?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x35aafa){if(_0x35aafa===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x35aafa));}['_notifyListenersIfCurrent'](_0x3b9ead){_0x3b9ead===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5294bd;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x30fd93=((_0x5294bd=this['currentUser'])==null?void 0x0:_0x5294bd['uid'])??null;this['lastNotifiedUid']!==_0x30fd93&&(this['lastNotifiedUid']=_0x30fd93,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2a8004,_0x834224,_0x4827bc,_0x49c201){if(this['_deleted'])return()=>{};const _0x49b4ac=typeof _0x834224=='function'?_0x834224:_0x834224['next']['bind'](_0x834224);let _0x3e003d=!0x1;const _0x527cbf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x527cbf,this,'internal-error'),_0x527cbf['then'](()=>{_0x3e003d||_0x49b4ac(this['currentUser']);}),typeof _0x834224=='function'){const _0x5800ec=_0x2a8004['addObserver'](_0x834224,_0x4827bc,_0x49c201);return()=>{_0x3e003d=!0x0,_0x5800ec();};}else{const _0x260e6f=_0x2a8004['addObserver'](_0x834224);return()=>{_0x3e003d=!0x0,_0x260e6f();};}}async['directlySetCurrentUser'](_0xef54b3){this['currentUser']&&this['currentUser']!==_0xef54b3&&this['_currentUser']['_stopProactiveRefresh'](),_0xef54b3&&this['isProactiveRefreshEnabled']&&_0xef54b3['_startProactiveRefresh'](),this['currentUser']=_0xef54b3,_0xef54b3?await this['assertedPersistence']['setCurrentUser'](_0xef54b3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x488496){return this['operations']=this['operations']['then'](_0x488496,_0x488496),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1fdeae){!_0x1fdeae||this['frameworks']['includes'](_0x1fdeae)||(this['frameworks']['push'](_0x1fdeae),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x51a9d8;const _0x2a52c5={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2a52c5['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4566fb=await((_0x51a9d8=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x51a9d8['getHeartbeatsHeader']());_0x4566fb&&(_0x2a52c5['X-Firebase-Client']=_0x4566fb);const _0xefd0f7=await this['_getAppCheckToken']();return _0xefd0f7&&(_0x2a52c5['X-Firebase-AppCheck']=_0xefd0f7),_0x2a52c5;}async['_getAppCheckToken'](){var _0x3a55a1;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x19d43b=await((_0x3a55a1=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3a55a1['getToken']());return _0x19d43b!=null&&_0x19d43b['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x19d43b['error']),_0x19d43b==null?void 0x0:_0x19d43b['token'];}}function Ke(_0x4ddb49){return P(_0x4ddb49);}class Rr{constructor(_0x2e0615){this['auth']=_0x2e0615,this['observer']=null,this['addObserver']=Tc(_0x14506f=>this['observer']=_0x14506f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x3893a9){Jn=_0x3893a9;}function xa(_0x123c71){return Jn['loadJS'](_0x123c71);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x2b10ed){return'__'+_0x2b10ed+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x3a54d0){_0x3a54d0();}['execute'](_0x216449,_0x5d6292){return Promise['resolve']('token');}['render'](_0x376e18,_0x2b30b0){return'';}}class Wf{['ready'](_0x10087a){_0x10087a();}['execute'](_0x10546a,_0x582705){return Promise['resolve']('token');}['render'](_0x439bb1,_0x204187){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0xc37457){this['type']=Bf,this['auth']=Ke(_0xc37457);}async['verify'](_0x3560ce='verify',_0x26b499=!0x1){async function _0x5547f7(_0xedcf44){if(!_0x26b499){if(_0xedcf44['tenantId']==null&&_0xedcf44['_agentRecaptchaConfig']!=null)return _0xedcf44['_agentRecaptchaConfig']['siteKey'];if(_0xedcf44['tenantId']!=null&&_0xedcf44['_tenantRecaptchaConfigs'][_0xedcf44['tenantId']]!==void 0x0)return _0xedcf44['_tenantRecaptchaConfigs'][_0xedcf44['tenantId']]['siteKey'];}return new Promise(async(_0x1cbb56,_0x202d9d)=>{yf(_0xedcf44,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x39621b=>{if(_0x39621b['recaptchaKey']===void 0x0)_0x202d9d(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x52ed61=new mf(_0x39621b);return _0xedcf44['tenantId']==null?_0xedcf44['_agentRecaptchaConfig']=_0x52ed61:_0xedcf44['_tenantRecaptchaConfigs'][_0xedcf44['tenantId']]=_0x52ed61,_0x1cbb56(_0x52ed61['siteKey']);}})['catch'](_0x449d43=>{_0x202d9d(_0x449d43);});});}function _0x3c1e0e(_0x1e29c6,_0x3289d2,_0x59f2cb){const _0x82aad2=window['grecaptcha'];wr(_0x82aad2)?_0x82aad2['enterprise']['ready'](()=>{_0x82aad2['enterprise']['execute'](_0x1e29c6,{'action':_0x3560ce})['then'](_0x47baee=>{_0x3289d2(_0x47baee);})['catch'](()=>{_0x3289d2(Fa);});}):_0x59f2cb(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x535243,_0x18e25d)=>{_0x5547f7(this['auth'])['then'](async _0x45596c=>{if(!_0x26b499&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x3c1e0e(_0x45596c,_0x535243,_0x18e25d);else{if(typeof window>'u'){_0x18e25d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2cabe4=Lf();_0x2cabe4['length']!==0x0&&(_0x2cabe4+=_0x45596c+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x1d3580;(_0x1d3580=he['scriptInjectionDeferred'])==null||_0x1d3580['resolve']();},xa(_0x2cabe4)['then'](()=>{var _0x143249;return(_0x143249=he['scriptInjectionDeferred'])==null?void 0x0:_0x143249['promise'];})['then'](()=>{_0x3c1e0e(_0x45596c,_0x535243,_0x18e25d);})['catch'](_0x35da5f=>{_0x18e25d(_0x35da5f);});}})['catch'](_0x38d0e9=>{_0x18e25d(_0x38d0e9);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x1c03d4,_0xad6797,_0x3d29f0,_0x44369c=!0x1,_0x412954=!0x1){const _0x24b1b4=new he(_0x1c03d4);let _0x41fcf4;if(_0x412954)_0x41fcf4=Fa;else try{_0x41fcf4=await _0x24b1b4['verify'](_0x3d29f0);}catch{_0x41fcf4=await _0x24b1b4['verify'](_0x3d29f0,!0x0);}const _0x412b8f={..._0xad6797};if(_0x3d29f0==='mfaSmsEnrollment'||_0x3d29f0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x412b8f){const _0x1423e8=_0x412b8f['phoneEnrollmentInfo']['phoneNumber'],_0x2aedd0=_0x412b8f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x412b8f,{'phoneEnrollmentInfo':{'phoneNumber':_0x1423e8,'recaptchaToken':_0x2aedd0,'captchaResponse':_0x41fcf4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x412b8f){const _0x154f28=_0x412b8f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x412b8f,{'phoneSignInInfo':{'recaptchaToken':_0x154f28,'captchaResponse':_0x41fcf4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x412b8f;}return _0x44369c?Object['assign'](_0x412b8f,{'captchaResp':_0x41fcf4}):Object['assign'](_0x412b8f,{'captchaResponse':_0x41fcf4}),Object['assign'](_0x412b8f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x412b8f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x412b8f;}async function xi(_0x16c5b7,_0x272ee4,_0x48f161,_0x9de2a,_0x5a5687){var _0x15a70b;if((_0x15a70b=_0x16c5b7['_getRecaptchaConfig']())!=null&&_0x15a70b['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3c9aad=await kr(_0x16c5b7,_0x272ee4,_0x48f161,_0x48f161==='getOobCode');return _0x9de2a(_0x16c5b7,_0x3c9aad);}else return _0x9de2a(_0x16c5b7,_0x272ee4)['catch'](async _0x20147c=>{if(_0x20147c['code']==='auth/missing-recaptcha-token'){console['log'](_0x48f161+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4147c2=await kr(_0x16c5b7,_0x272ee4,_0x48f161,_0x48f161==='getOobCode');return _0x9de2a(_0x16c5b7,_0x4147c2);}else return Promise['reject'](_0x20147c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x542903,_0x28bcb8){const _0x26e4a9=Hi(_0x542903,'auth');if(_0x26e4a9['isInitialized']()){const _0x24023b=_0x26e4a9['getImmediate'](),_0x4207f1=_0x26e4a9['getOptions']();if(xe(_0x4207f1,_0x28bcb8??{}))return _0x24023b;Y(_0x24023b,'already-initialized');}return _0x26e4a9['initialize']({'options':_0x28bcb8});}function Hf(_0xe81d26,_0x358b08){const _0x23623a=(_0x358b08==null?void 0x0:_0x358b08['persistence'])||[],_0x5b0a68=(Array['isArray'](_0x23623a)?_0x23623a:[_0x23623a])['map'](ie);_0x358b08!=null&&_0x358b08['errorMap']&&_0xe81d26['_updateErrorMap'](_0x358b08['errorMap']),_0xe81d26['_initializeWithPersistence'](_0x5b0a68,_0x358b08==null?void 0x0:_0x358b08['popupRedirectResolver']);}function $f(_0x1091e5,_0x275f57,_0x208c03){const _0x10c221=Ke(_0x1091e5);m(/^https?:\/\//['test'](_0x275f57),_0x10c221,'invalid-emulator-scheme');const _0x26de78=!0x1,_0x47a3e5=Ua(_0x275f57),{host:_0x591040,port:_0x3b3645}=Gf(_0x275f57),_0x22cd86=_0x3b3645===null?'':':'+_0x3b3645,_0x6b893a={'url':_0x47a3e5+'//'+_0x591040+_0x22cd86+'/'},_0x481967=Object['freeze']({'host':_0x591040,'port':_0x3b3645,'protocol':_0x47a3e5['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x26de78})});if(!_0x10c221['_canInitEmulator']){m(_0x10c221['config']['emulator']&&_0x10c221['emulatorConfig'],_0x10c221,'emulator-config-failed'),m(xe(_0x6b893a,_0x10c221['config']['emulator'])&&xe(_0x481967,_0x10c221['emulatorConfig']),_0x10c221,'emulator-config-failed');return;}_0x10c221['config']['emulator']=_0x6b893a,_0x10c221['emulatorConfig']=_0x481967,_0x10c221['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x591040)?Qr(_0x47a3e5+'//'+_0x591040+_0x22cd86):qf();}function Ua(_0x3c1d45){const _0x1ddc7b=_0x3c1d45['indexOf'](':');return _0x1ddc7b<0x0?'':_0x3c1d45['substr'](0x0,_0x1ddc7b+0x1);}function Gf(_0x3e18ba){const _0x2486fb=Ua(_0x3e18ba),_0x761536=/(\/\/)?([^?#/]+)/['exec'](_0x3e18ba['substr'](_0x2486fb['length']));if(!_0x761536)return{'host':'','port':null};const _0x5ef924=_0x761536[0x2]['split']('@')['pop']()||'',_0x388691=/^(\[[^\]]+\])(:|$)/['exec'](_0x5ef924);if(_0x388691){const _0x101cc5=_0x388691[0x1];return{'host':_0x101cc5,'port':Pr(_0x5ef924['substr'](_0x101cc5['length']+0x1))};}else{const [_0x375bb3,_0x47b7fd]=_0x5ef924['split'](':');return{'host':_0x375bb3,'port':Pr(_0x47b7fd)};}}function Pr(_0x3c6467){if(!_0x3c6467)return null;const _0xb13406=Number(_0x3c6467);return isNaN(_0xb13406)?null:_0xb13406;}function qf(){function _0x57f212(){const _0x4bcb3d=document['createElement']('p'),_0x3ff6ab=_0x4bcb3d['style'];_0x4bcb3d['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x3ff6ab['position']='fixed',_0x3ff6ab['width']='100%',_0x3ff6ab['backgroundColor']='#ffffff',_0x3ff6ab['border']='.1em\x20solid\x20#000000',_0x3ff6ab['color']='#b50000',_0x3ff6ab['bottom']='0px',_0x3ff6ab['left']='0px',_0x3ff6ab['margin']='0px',_0x3ff6ab['zIndex']='10000',_0x3ff6ab['textAlign']='center',_0x4bcb3d['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4bcb3d);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x57f212):_0x57f212());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x1ad4e2,_0x436cf1){this['providerId']=_0x1ad4e2,this['signInMethod']=_0x436cf1;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2c8b03){return ne('not\x20implemented');}['_linkToIdToken'](_0x39d356,_0x32ff71){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1a956a){return ne('not\x20implemented');}}async function zf(_0x2c9eca,_0x7e18d0){return Pe(_0x2c9eca,'POST','/v1/accounts:signUp',_0x7e18d0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x4d9050,_0x4729a5){return en(_0x4d9050,'POST','/v1/accounts:signInWithPassword',ke(_0x4d9050,_0x4729a5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1b493f,_0x5c87f7){return en(_0x1b493f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1b493f,_0x5c87f7));}async function Yf(_0x3c1b35,_0x10f03f){return en(_0x3c1b35,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3c1b35,_0x10f03f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x39b14d,_0x28204e,_0x3345ea,_0x3c705b=null){super('password',_0x3345ea),this['_email']=_0x39b14d,this['_password']=_0x28204e,this['_tenantId']=_0x3c705b;}static['_fromEmailAndPassword'](_0x54ffb2,_0x2e0e9f){return new $t(_0x54ffb2,_0x2e0e9f,'password');}static['_fromEmailAndCode'](_0xc3538d,_0x2504b3,_0x2d9e00=null){return new $t(_0xc3538d,_0x2504b3,'emailLink',_0x2d9e00);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1e1ea1){const _0x2d23ac=typeof _0x1e1ea1=='string'?JSON['parse'](_0x1e1ea1):_0x1e1ea1;if(_0x2d23ac!=null&&_0x2d23ac['email']&&(_0x2d23ac!=null&&_0x2d23ac['password'])){if(_0x2d23ac['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2d23ac['email'],_0x2d23ac['password']);if(_0x2d23ac['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2d23ac['email'],_0x2d23ac['password'],_0x2d23ac['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1b74c9){switch(this['signInMethod']){case'password':const _0x457f0a={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1b74c9,_0x457f0a,'signInWithPassword',jf);case'emailLink':return Kf(_0x1b74c9,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1b74c9,'internal-error');}}async['_linkToIdToken'](_0x5925b0,_0x11985d){switch(this['signInMethod']){case'password':const _0x1db060={'idToken':_0x11985d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5925b0,_0x1db060,'signUpPassword',zf);case'emailLink':return Yf(_0x5925b0,{'idToken':_0x11985d,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5925b0,'internal-error');}}['_getReauthenticationResolver'](_0x3c5680){return this['_getIdTokenResponse'](_0x3c5680);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1cbdf3,_0x3e3423){return en(_0x1cbdf3,'POST','/v1/accounts:signInWithIdp',ke(_0x1cbdf3,_0x3e3423));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x32d676){const _0x595c85=new $e(_0x32d676['providerId'],_0x32d676['signInMethod']);return _0x32d676['idToken']||_0x32d676['accessToken']?(_0x32d676['idToken']&&(_0x595c85['idToken']=_0x32d676['idToken']),_0x32d676['accessToken']&&(_0x595c85['accessToken']=_0x32d676['accessToken']),_0x32d676['nonce']&&!_0x32d676['pendingToken']&&(_0x595c85['nonce']=_0x32d676['nonce']),_0x32d676['pendingToken']&&(_0x595c85['pendingToken']=_0x32d676['pendingToken'])):_0x32d676['oauthToken']&&_0x32d676['oauthTokenSecret']?(_0x595c85['accessToken']=_0x32d676['oauthToken'],_0x595c85['secret']=_0x32d676['oauthTokenSecret']):Y('argument-error'),_0x595c85;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5c16b1){const _0xc563e1=typeof _0x5c16b1=='string'?JSON['parse'](_0x5c16b1):_0x5c16b1,{providerId:_0x3cbcf0,signInMethod:_0x5145db,..._0x56b367}=_0xc563e1;if(!_0x3cbcf0||!_0x5145db)return null;const _0x4e4d78=new $e(_0x3cbcf0,_0x5145db);return _0x4e4d78['idToken']=_0x56b367['idToken']||void 0x0,_0x4e4d78['accessToken']=_0x56b367['accessToken']||void 0x0,_0x4e4d78['secret']=_0x56b367['secret'],_0x4e4d78['nonce']=_0x56b367['nonce'],_0x4e4d78['pendingToken']=_0x56b367['pendingToken']||null,_0x4e4d78;}['_getIdTokenResponse'](_0x611089){const _0x25e74a=this['buildRequest']();return nt(_0x611089,_0x25e74a);}['_linkToIdToken'](_0x2599c2,_0x388f81){const _0x47224c=this['buildRequest']();return _0x47224c['idToken']=_0x388f81,nt(_0x2599c2,_0x47224c);}['_getReauthenticationResolver'](_0x2a6f26){const _0x26993e=this['buildRequest']();return _0x26993e['autoCreate']=!0x1,nt(_0x2a6f26,_0x26993e);}['buildRequest'](){const _0x2b4377={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2b4377['pendingToken']=this['pendingToken'];else{const _0x82428a={};this['idToken']&&(_0x82428a['id_token']=this['idToken']),this['accessToken']&&(_0x82428a['access_token']=this['accessToken']),this['secret']&&(_0x82428a['oauth_token_secret']=this['secret']),_0x82428a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x82428a['nonce']=this['nonce']),_0x2b4377['postBody']=ut(_0x82428a);}return _0x2b4377;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x310513){switch(_0x310513){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x45353b){const _0x1d7b3b=Ct(Tt(_0x45353b))['link'],_0x49ea00=_0x1d7b3b?Ct(Tt(_0x1d7b3b))['deep_link_id']:null,_0x11e006=Ct(Tt(_0x45353b))['deep_link_id'];return(_0x11e006?Ct(Tt(_0x11e006))['link']:null)||_0x11e006||_0x49ea00||_0x1d7b3b||_0x45353b;}class Rs{constructor(_0x158aa1){const _0x3c01ff=Ct(Tt(_0x158aa1)),_0x1bc6ec=_0x3c01ff['apiKey']??null,_0x170c15=_0x3c01ff['oobCode']??null,_0xd8a454=Jf(_0x3c01ff['mode']??null);m(_0x1bc6ec&&_0x170c15&&_0xd8a454,'argument-error'),this['apiKey']=_0x1bc6ec,this['operation']=_0xd8a454,this['code']=_0x170c15,this['continueUrl']=_0x3c01ff['continueUrl']??null,this['languageCode']=_0x3c01ff['lang']??null,this['tenantId']=_0x3c01ff['tenantId']??null;}static['parseLink'](_0x20f7fe){const _0x3dbd96=Xf(_0x20f7fe);try{return new Rs(_0x3dbd96);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x11500e,_0x36c524){return $t['_fromEmailAndPassword'](_0x11500e,_0x36c524);}static['credentialWithLink'](_0x3ef3cd,_0x51c84a){const _0x401523=Rs['parseLink'](_0x51c84a);return m(_0x401523,'argument-error'),$t['_fromEmailAndCode'](_0x3ef3cd,_0x401523['code'],_0x401523['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2e9e67){this['providerId']=_0x2e9e67,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3dc3ba){this['defaultLanguageCode']=_0x3dc3ba;}['setCustomParameters'](_0x3688f2){return this['customParameters']=_0x3688f2,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x59e703){return this['scopes']['includes'](_0x59e703)||this['scopes']['push'](_0x59e703),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x32eb88){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x32eb88});}static['credentialFromResult'](_0x4020e2){return ue['credentialFromTaggedObject'](_0x4020e2);}static['credentialFromError'](_0x26c96a){return ue['credentialFromTaggedObject'](_0x26c96a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x44b327}){if(!_0x44b327||!('oauthAccessToken'in _0x44b327)||!_0x44b327['oauthAccessToken'])return null;try{return ue['credential'](_0x44b327['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1dfcb5,_0x5ef3ee){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1dfcb5,'accessToken':_0x5ef3ee});}static['credentialFromResult'](_0x3e1c66){return de['credentialFromTaggedObject'](_0x3e1c66);}static['credentialFromError'](_0x2b5a8b){return de['credentialFromTaggedObject'](_0x2b5a8b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x40bc66}){if(!_0x40bc66)return null;const {oauthIdToken:_0x87cddc,oauthAccessToken:_0x24ecfc}=_0x40bc66;if(!_0x87cddc&&!_0x24ecfc)return null;try{return de['credential'](_0x87cddc,_0x24ecfc);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4ea160){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4ea160});}static['credentialFromResult'](_0x166d5d){return fe['credentialFromTaggedObject'](_0x166d5d);}static['credentialFromError'](_0x434a23){return fe['credentialFromTaggedObject'](_0x434a23['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x408758}){if(!_0x408758||!('oauthAccessToken'in _0x408758)||!_0x408758['oauthAccessToken'])return null;try{return fe['credential'](_0x408758['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0xbdb21b,_0x3c75f0){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0xbdb21b,'oauthTokenSecret':_0x3c75f0});}static['credentialFromResult'](_0x28f4db){return pe['credentialFromTaggedObject'](_0x28f4db);}static['credentialFromError'](_0x335738){return pe['credentialFromTaggedObject'](_0x335738['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x175bf6}){if(!_0x175bf6)return null;const {oauthAccessToken:_0x1bd39c,oauthTokenSecret:_0x3b2d81}=_0x175bf6;if(!_0x1bd39c||!_0x3b2d81)return null;try{return pe['credential'](_0x1bd39c,_0x3b2d81);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2a4ea6,_0x3f7fca){return en(_0x2a4ea6,'POST','/v1/accounts:signUp',ke(_0x2a4ea6,_0x3f7fca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x55583c){this['user']=_0x55583c['user'],this['providerId']=_0x55583c['providerId'],this['_tokenResponse']=_0x55583c['_tokenResponse'],this['operationType']=_0x55583c['operationType'];}static async['_fromIdTokenResponse'](_0x1f4fac,_0x2b18b1,_0x5d4060,_0x4b3ef5=!0x1){const _0x5ef3e2=await j['_fromIdTokenResponse'](_0x1f4fac,_0x5d4060,_0x4b3ef5),_0x4fec09=Nr(_0x5d4060);return new Ge({'user':_0x5ef3e2,'providerId':_0x4fec09,'_tokenResponse':_0x5d4060,'operationType':_0x2b18b1});}static async['_forOperation'](_0x41ae85,_0x32324c,_0x2b1cdb){await _0x41ae85['_updateTokensIfNecessary'](_0x2b1cdb,!0x0);const _0x1c3997=Nr(_0x2b1cdb);return new Ge({'user':_0x41ae85,'providerId':_0x1c3997,'_tokenResponse':_0x2b1cdb,'operationType':_0x32324c});}}function Nr(_0x4edf5f){return _0x4edf5f['providerId']?_0x4edf5f['providerId']:'phoneNumber'in _0x4edf5f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x30e31d,_0x11399f,_0x53564c,_0x4e6875){super(_0x11399f['code'],_0x11399f['message']),this['operationType']=_0x53564c,this['user']=_0x4e6875,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x30e31d['name'],'tenantId':_0x30e31d['tenantId']??void 0x0,'_serverResponse':_0x11399f['customData']['_serverResponse'],'operationType':_0x53564c};}static['_fromErrorAndOperation'](_0xbc2469,_0x207c5f,_0x3a3ab8,_0xa5d2c4){return new On(_0xbc2469,_0x207c5f,_0x3a3ab8,_0xa5d2c4);}}function Ba(_0x3268f0,_0x3e33e4,_0x24a77d,_0x450354){return(_0x3e33e4==='reauthenticate'?_0x24a77d['_getReauthenticationResolver'](_0x3268f0):_0x24a77d['_getIdTokenResponse'](_0x3268f0))['catch'](_0x5c94ab=>{throw _0x5c94ab['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3268f0,_0x5c94ab,_0x3e33e4,_0x450354):_0x5c94ab;});}async function ep(_0x152ce7,_0x435d27,_0x42be0e=!0x1){const _0x3608db=await Ht(_0x152ce7,_0x435d27['_linkToIdToken'](_0x152ce7['auth'],await _0x152ce7['getIdToken']()),_0x42be0e);return Ge['_forOperation'](_0x152ce7,'link',_0x3608db);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x389ce8,_0x3e2bd1,_0x23d773=!0x1){const {auth:_0x417774}=_0x389ce8;if($(_0x417774['app']))return Promise['reject'](re(_0x417774));const _0x39936c='reauthenticate';try{const _0x520937=await Ht(_0x389ce8,Ba(_0x417774,_0x39936c,_0x3e2bd1,_0x389ce8),_0x23d773);m(_0x520937['idToken'],_0x417774,'internal-error');const _0x33b7ca=Ts(_0x520937['idToken']);m(_0x33b7ca,_0x417774,'internal-error');const {sub:_0x3e17d4}=_0x33b7ca;return m(_0x389ce8['uid']===_0x3e17d4,_0x417774,'user-mismatch'),Ge['_forOperation'](_0x389ce8,_0x39936c,_0x520937);}catch(_0x5ac88e){throw(_0x5ac88e==null?void 0x0:_0x5ac88e['code'])==='auth/user-not-found'&&Y(_0x417774,'user-mismatch'),_0x5ac88e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x36e28f,_0x42e433,_0x26e9fd=!0x1){if($(_0x36e28f['app']))return Promise['reject'](re(_0x36e28f));const _0xbbeaf1='signIn',_0x566bf3=await Ba(_0x36e28f,_0xbbeaf1,_0x42e433),_0x17a15c=await Ge['_fromIdTokenResponse'](_0x36e28f,_0xbbeaf1,_0x566bf3);return _0x26e9fd||await _0x36e28f['_updateCurrentUser'](_0x17a15c['user']),_0x17a15c;}async function np(_0x7554ed,_0x20b06c){return Va(Ke(_0x7554ed),_0x20b06c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x8ac8e){const _0xf23603=Ke(_0x8ac8e);_0xf23603['_getPasswordPolicyInternal']()&&await _0xf23603['_updatePasswordPolicy']();}async function L_(_0x6d302b,_0x484924,_0x4a3fd9){if($(_0x6d302b['app']))return Promise['reject'](re(_0x6d302b));const _0x7fc80d=Ke(_0x6d302b),_0x3b11b8=await xi(_0x7fc80d,{'returnSecureToken':!0x0,'email':_0x484924,'password':_0x4a3fd9,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x50fd81=>{throw _0x50fd81['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x6d302b),_0x50fd81;}),_0x3b8fa9=await Ge['_fromIdTokenResponse'](_0x7fc80d,'signIn',_0x3b11b8);return await _0x7fc80d['_updateCurrentUser'](_0x3b8fa9['user']),_0x3b8fa9;}function x_(_0x191615,_0x2342f4,_0x406bba){return $(_0x191615['app'])?Promise['reject'](re(_0x191615)):np(P(_0x191615),yt['credential'](_0x2342f4,_0x406bba))['catch'](async _0xa71bbb=>{throw _0xa71bbb['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x191615),_0xa71bbb;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x835f66,_0x1359fd){return P(_0x835f66)['setPersistence'](_0x1359fd);}function ip(_0xb3ff29,_0x5379ca,_0xd6f6f6,_0x2c42c2){return P(_0xb3ff29)['onIdTokenChanged'](_0x5379ca,_0xd6f6f6,_0x2c42c2);}function sp(_0x354d4f,_0x382ed8,_0x3c363a){return P(_0x354d4f)['beforeAuthStateChanged'](_0x382ed8,_0x3c363a);}function U_(_0x11535a,_0xeba8e7,_0x44a29e,_0x59d45d){return P(_0x11535a)['onAuthStateChanged'](_0xeba8e7,_0x44a29e,_0x59d45d);}function W_(_0x4371e1){return P(_0x4371e1)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x259899,_0x31195a){this['storageRetriever']=_0x259899,this['type']=_0x31195a;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5f4a8d,_0x106956){return this['storage']['setItem'](_0x5f4a8d,JSON['stringify'](_0x106956)),Promise['resolve']();}['_get'](_0x4c64da){const _0x3543cd=this['storage']['getItem'](_0x4c64da);return Promise['resolve'](_0x3543cd?JSON['parse'](_0x3543cd):null);}['_remove'](_0x527680){return this['storage']['removeItem'](_0x527680),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1a3717,_0xff9211)=>this['onStorageEvent'](_0x1a3717,_0xff9211),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3b26d2){for(const _0x80d576 of Object['keys'](this['listeners'])){const _0x3329d9=this['storage']['getItem'](_0x80d576),_0xc4c886=this['localCache'][_0x80d576];_0x3329d9!==_0xc4c886&&_0x3b26d2(_0x80d576,_0xc4c886,_0x3329d9);}}['onStorageEvent'](_0x53b05c,_0x47d9fa=!0x1){if(!_0x53b05c['key']){this['forAllChangedKeys']((_0x3887ad,_0x4d3012,_0x597e94)=>{this['notifyListeners'](_0x3887ad,_0x597e94);});return;}const _0x38700a=_0x53b05c['key'];_0x47d9fa?this['detachListener']():this['stopPolling']();const _0x177d01=()=>{const _0x191597=this['storage']['getItem'](_0x38700a);!_0x47d9fa&&this['localCache'][_0x38700a]===_0x191597||this['notifyListeners'](_0x38700a,_0x191597);},_0x17dec8=this['storage']['getItem'](_0x38700a);Af()&&_0x17dec8!==_0x53b05c['newValue']&&_0x53b05c['newValue']!==_0x53b05c['oldValue']?setTimeout(_0x177d01,op):_0x177d01();}['notifyListeners'](_0x522a21,_0x325a8e){this['localCache'][_0x522a21]=_0x325a8e;const _0x402c44=this['listeners'][_0x522a21];if(_0x402c44){for(const _0x3a9fd6 of Array['from'](_0x402c44))_0x3a9fd6(_0x325a8e&&JSON['parse'](_0x325a8e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x56f292,_0x4f5895,_0x266e6c)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x56f292,'oldValue':_0x4f5895,'newValue':_0x266e6c}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x595b85,_0x1e4fa1){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x595b85]||(this['listeners'][_0x595b85]=new Set(),this['localCache'][_0x595b85]=this['storage']['getItem'](_0x595b85)),this['listeners'][_0x595b85]['add'](_0x1e4fa1);}['_removeListener'](_0x4827fb,_0x156b93){this['listeners'][_0x4827fb]&&(this['listeners'][_0x4827fb]['delete'](_0x156b93),this['listeners'][_0x4827fb]['size']===0x0&&delete this['listeners'][_0x4827fb]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x630edb,_0x5b88bc){await super['_set'](_0x630edb,_0x5b88bc),this['localCache'][_0x630edb]=JSON['stringify'](_0x5b88bc);}async['_get'](_0x33d6c0){const _0x1ae1e1=await super['_get'](_0x33d6c0);return this['localCache'][_0x33d6c0]=JSON['stringify'](_0x1ae1e1),_0x1ae1e1;}async['_remove'](_0x3bdd6f){await super['_remove'](_0x3bdd6f),delete this['localCache'][_0x3bdd6f];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5ddea6,_0x55f2e5){}['_removeListener'](_0x23edc5,_0x5e0dfe){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0xe1dc79){return Promise['all'](_0xe1dc79['map'](async _0x17de65=>{try{return{'fulfilled':!0x0,'value':await _0x17de65};}catch(_0x537194){return{'fulfilled':!0x1,'reason':_0x537194};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x39447f){this['eventTarget']=_0x39447f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x284c78){const _0x2b2a41=this['receivers']['find'](_0x2b7548=>_0x2b7548['isListeningto'](_0x284c78));if(_0x2b2a41)return _0x2b2a41;const _0x27240f=new Xn(_0x284c78);return this['receivers']['push'](_0x27240f),_0x27240f;}['isListeningto'](_0x330b0b){return this['eventTarget']===_0x330b0b;}async['handleEvent'](_0x27ef40){const _0x2416f5=_0x27ef40,{eventId:_0x23ab58,eventType:_0x1f941e,data:_0x329f4e}=_0x2416f5['data'],_0x58f76c=this['handlersMap'][_0x1f941e];if(!(_0x58f76c!=null&&_0x58f76c['size']))return;_0x2416f5['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x23ab58,'eventType':_0x1f941e});const _0x540a8c=Array['from'](_0x58f76c)['map'](async _0x3a855f=>_0x3a855f(_0x2416f5['origin'],_0x329f4e)),_0x267998=await cp(_0x540a8c);_0x2416f5['ports'][0x0]['postMessage']({'status':'done','eventId':_0x23ab58,'eventType':_0x1f941e,'response':_0x267998});}['_subscribe'](_0x1899bf,_0x527db6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1899bf]||(this['handlersMap'][_0x1899bf]=new Set()),this['handlersMap'][_0x1899bf]['add'](_0x527db6);}['_unsubscribe'](_0xcb7656,_0x4575ba){this['handlersMap'][_0xcb7656]&&_0x4575ba&&this['handlersMap'][_0xcb7656]['delete'](_0x4575ba),(!_0x4575ba||this['handlersMap'][_0xcb7656]['size']===0x0)&&delete this['handlersMap'][_0xcb7656],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x17b15c='',_0x481c3a=0xa){let _0x58fe8d='';for(let _0x3f7d26=0x0;_0x3f7d26<_0x481c3a;_0x3f7d26++)_0x58fe8d+=Math['floor'](Math['random']()*0xa);return _0x17b15c+_0x58fe8d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0xe271a8){this['target']=_0xe271a8,this['handlers']=new Set();}['removeMessageHandler'](_0xfc65){_0xfc65['messageChannel']&&(_0xfc65['messageChannel']['port1']['removeEventListener']('message',_0xfc65['onMessage']),_0xfc65['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xfc65);}async['_send'](_0x3ed7b3,_0x45a419,_0x575348=0x32){const _0x296cde=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x296cde)throw new Error('connection_unavailable');let _0x369b69,_0x2789f3;return new Promise((_0x40d3c7,_0x58d9b2)=>{const _0x1926d2=As('',0x14);_0x296cde['port1']['start']();const _0x10645e=setTimeout(()=>{_0x58d9b2(new Error('unsupported_event'));},_0x575348);_0x2789f3={'messageChannel':_0x296cde,'onMessage'(_0x18c0f9){const _0x416c8d=_0x18c0f9;if(_0x416c8d['data']['eventId']===_0x1926d2)switch(_0x416c8d['data']['status']){case'ack':clearTimeout(_0x10645e),_0x369b69=setTimeout(()=>{_0x58d9b2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x369b69),_0x40d3c7(_0x416c8d['data']['response']);break;default:clearTimeout(_0x10645e),clearTimeout(_0x369b69),_0x58d9b2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2789f3),_0x296cde['port1']['addEventListener']('message',_0x2789f3['onMessage']),this['target']['postMessage']({'eventType':_0x3ed7b3,'eventId':_0x1926d2,'data':_0x45a419},[_0x296cde['port2']]);})['finally'](()=>{_0x2789f3&&this['removeMessageHandler'](_0x2789f3);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x105d12){Z()['location']['href']=_0x105d12;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1cccc2;return((_0x1cccc2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1cccc2['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x2d3ccf){this['request']=_0x2d3ccf;}['toPromise'](){return new Promise((_0x2008d3,_0x271c0c)=>{this['request']['addEventListener']('success',()=>{_0x2008d3(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x271c0c(this['request']['error']);});});}}function Zn(_0x4b8adc,_0x2459a0){return _0x4b8adc['transaction']([Mn],_0x2459a0?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x4235d2=indexedDB['deleteDatabase'](Ka);return new nn(_0x4235d2)['toPromise']();}function Qa(){const _0x2ae9ff=indexedDB['open'](Ka,pp);return new Promise((_0x433738,_0x3f4887)=>{_0x2ae9ff['addEventListener']('error',()=>{_0x3f4887(_0x2ae9ff['error']);}),_0x2ae9ff['addEventListener']('upgradeneeded',()=>{const _0x5304ea=_0x2ae9ff['result'];try{_0x5304ea['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x1c56e4){_0x3f4887(_0x1c56e4);}}),_0x2ae9ff['addEventListener']('success',async()=>{const _0x10d4d9=_0x2ae9ff['result'];_0x10d4d9['objectStoreNames']['contains'](Mn)?_0x433738(_0x10d4d9):(_0x10d4d9['close'](),await _p(),_0x433738(await Qa()));});});}async function Or(_0x40a5bc,_0x5356cf,_0x13e82b){const _0x3ca855=Zn(_0x40a5bc,!0x0)['put']({[Ya]:_0x5356cf,'value':_0x13e82b});return new nn(_0x3ca855)['toPromise']();}async function gp(_0x5141d5,_0x47b3f4){const _0x3d88e4=Zn(_0x5141d5,!0x1)['get'](_0x47b3f4),_0x37c02f=await new nn(_0x3d88e4)['toPromise']();return _0x37c02f===void 0x0?null:_0x37c02f['value'];}function Dr(_0x76eb62,_0x36b1a3){const _0x32f991=Zn(_0x76eb62,!0x0)['delete'](_0x36b1a3);return new nn(_0x32f991)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x27a0de){let _0x4d8f7e=0x0;for(;;)try{const _0x4a0632=await this['_openDb']();return await _0x27a0de(_0x4a0632);}catch(_0x55f6c6){if(_0x4d8f7e++>yp)throw _0x55f6c6;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2a3b5c,_0xcbf1f4)=>({'keyProcessed':(await this['_poll']())['includes'](_0xcbf1f4['key'])})),this['receiver']['_subscribe']('ping',async(_0x4a5ecc,_0x32a0e4)=>['keyChanged']);}async['initializeSender'](){var _0x29c104,_0x2134d4;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x5e44df=await this['sender']['_send']('ping',{},0x320);_0x5e44df&&(_0x29c104=_0x5e44df[0x0])!=null&&_0x29c104['fulfilled']&&(_0x2134d4=_0x5e44df[0x0])!=null&&_0x2134d4['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x13e01d){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x13e01d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x99c0c3=>{await Or(_0x99c0c3,Dn,'1'),await Dr(_0x99c0c3,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x303120){this['pendingWrites']++;try{await _0x303120();}finally{this['pendingWrites']--;}}async['_set'](_0x3fa400,_0x41582b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4dc554=>Or(_0x4dc554,_0x3fa400,_0x41582b)),this['localCache'][_0x3fa400]=_0x41582b,this['notifyServiceWorker'](_0x3fa400)));}async['_get'](_0x96ba81){const _0x5cae95=await this['_withRetries'](_0x735a16=>gp(_0x735a16,_0x96ba81));return this['localCache'][_0x96ba81]=_0x5cae95,_0x5cae95;}async['_remove'](_0x538a3c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1d3693=>Dr(_0x1d3693,_0x538a3c)),delete this['localCache'][_0x538a3c],this['notifyServiceWorker'](_0x538a3c)));}async['_poll'](){const _0x1a584f=await this['_withRetries'](_0x4eec14=>{const _0xf55f5e=Zn(_0x4eec14,!0x1)['getAll']();return new nn(_0xf55f5e)['toPromise']();});if(!_0x1a584f)return[];if(this['pendingWrites']!==0x0)return[];const _0x52383e=[],_0x2ac2b7=new Set();if(_0x1a584f['length']!==0x0){for(const {fbase_key:_0xfa5d4f,value:_0x35e9cd}of _0x1a584f)_0x2ac2b7['add'](_0xfa5d4f),JSON['stringify'](this['localCache'][_0xfa5d4f])!==JSON['stringify'](_0x35e9cd)&&(this['notifyListeners'](_0xfa5d4f,_0x35e9cd),_0x52383e['push'](_0xfa5d4f));}for(const _0x1615b2 of Object['keys'](this['localCache']))this['localCache'][_0x1615b2]&&!_0x2ac2b7['has'](_0x1615b2)&&(this['notifyListeners'](_0x1615b2,null),_0x52383e['push'](_0x1615b2));return _0x52383e;}['notifyListeners'](_0xcc107b,_0x382460){this['localCache'][_0xcc107b]=_0x382460;const _0x56949f=this['listeners'][_0xcc107b];if(_0x56949f){for(const _0x2b2b19 of Array['from'](_0x56949f))_0x2b2b19(_0x382460);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x54b8ae,_0xeaa27c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x54b8ae]||(this['listeners'][_0x54b8ae]=new Set(),this['_get'](_0x54b8ae)),this['listeners'][_0x54b8ae]['add'](_0xeaa27c);}['_removeListener'](_0x560b35,_0x1f5025){this['listeners'][_0x560b35]&&(this['listeners'][_0x560b35]['delete'](_0x1f5025),this['listeners'][_0x560b35]['size']===0x0&&delete this['listeners'][_0x560b35]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5d2653,_0x1422cc){return _0x1422cc?ie(_0x1422cc):(m(_0x5d2653['_popupRedirectResolver'],_0x5d2653,'argument-error'),_0x5d2653['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1a30fa){super('custom','custom'),this['params']=_0x1a30fa;}['_getIdTokenResponse'](_0x4d9b63){return nt(_0x4d9b63,this['_buildIdpRequest']());}['_linkToIdToken'](_0x79b94,_0x779a2){return nt(_0x79b94,this['_buildIdpRequest'](_0x779a2));}['_getReauthenticationResolver'](_0x52593){return nt(_0x52593,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x52571a){const _0x2e14d2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x52571a&&(_0x2e14d2['idToken']=_0x52571a),_0x2e14d2;}}function Ip(_0x3f5a87){return Va(_0x3f5a87['auth'],new ks(_0x3f5a87),_0x3f5a87['bypassAuthState']);}function wp(_0x4c5304){const {auth:_0xf8f9e6,user:_0x3920e4}=_0x4c5304;return m(_0x3920e4,_0xf8f9e6,'internal-error'),tp(_0x3920e4,new ks(_0x4c5304),_0x4c5304['bypassAuthState']);}async function Cp(_0x34a8d1){const {auth:_0x388fb8,user:_0x1bc85c}=_0x34a8d1;return m(_0x1bc85c,_0x388fb8,'internal-error'),ep(_0x1bc85c,new ks(_0x34a8d1),_0x34a8d1['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x38db3d,_0x2c210a,_0x4d11b2,_0xe5668d,_0x1589fa=!0x1){this['auth']=_0x38db3d,this['resolver']=_0x4d11b2,this['user']=_0xe5668d,this['bypassAuthState']=_0x1589fa,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2c210a)?_0x2c210a:[_0x2c210a];}['execute'](){return new Promise(async(_0x39853d,_0x1e8518)=>{this['pendingPromise']={'resolve':_0x39853d,'reject':_0x1e8518};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x70de45){this['reject'](_0x70de45);}});}async['onAuthEvent'](_0x5eb767){const {urlResponse:_0x26f6ad,sessionId:_0x3a3d39,postBody:_0x3c6b00,tenantId:_0x3d45d4,error:_0x1cea94,type:_0x18ec00}=_0x5eb767;if(_0x1cea94){this['reject'](_0x1cea94);return;}const _0x2ec747={'auth':this['auth'],'requestUri':_0x26f6ad,'sessionId':_0x3a3d39,'tenantId':_0x3d45d4||void 0x0,'postBody':_0x3c6b00||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x18ec00)(_0x2ec747));}catch(_0x4dba20){this['reject'](_0x4dba20);}}['onError'](_0x1bc988){this['reject'](_0x1bc988);}['getIdpTask'](_0x157660){switch(_0x157660){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x56fbb2){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x56fbb2),this['unregisterAndCleanUp']();}['reject'](_0x9a79ce){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x9a79ce),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x3f3b2a,_0x5d8948,_0x363c14,_0x37be19,_0x19d7d2){super(_0x3f3b2a,_0x5d8948,_0x37be19,_0x19d7d2),this['provider']=_0x363c14,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x24cbe4=await this['execute']();return m(_0x24cbe4,this['auth'],'internal-error'),_0x24cbe4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x369bf2=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x369bf2),this['authWindow']['associatedEvent']=_0x369bf2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3252d3=>{this['reject'](_0x3252d3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x9a7008=>{_0x9a7008||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x23bed5;return((_0x23bed5=this['authWindow'])==null?void 0x0:_0x23bed5['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x15681f=()=>{var _0x54a7ce,_0x571220;if((_0x571220=(_0x54a7ce=this['authWindow'])==null?void 0x0:_0x54a7ce['window'])!=null&&_0x571220['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x15681f,Tp['get']());};_0x15681f();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x23ed16,_0x336460,_0x49665a=!0x1){super(_0x23ed16,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x336460,void 0x0,_0x49665a),this['eventId']=null;}async['execute'](){let _0x2ae6ed=hn['get'](this['auth']['_key']());if(!_0x2ae6ed){try{const _0x28b28c=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x2ae6ed=()=>Promise['resolve'](_0x28b28c);}catch(_0x50281e){_0x2ae6ed=()=>Promise['reject'](_0x50281e);}hn['set'](this['auth']['_key'](),_0x2ae6ed);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2ae6ed();}async['onAuthEvent'](_0x4d9e12){if(_0x4d9e12['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4d9e12);if(_0x4d9e12['type']==='unknown'){this['resolve'](null);return;}if(_0x4d9e12['eventId']){const _0x2bf2b1=await this['auth']['_redirectUserForId'](_0x4d9e12['eventId']);if(_0x2bf2b1)return this['user']=_0x2bf2b1,super['onAuthEvent'](_0x4d9e12);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3d6355,_0x2ed708){const _0x263559=Pp(_0x2ed708),_0x126e0f=kp(_0x3d6355);if(!await _0x126e0f['_isAvailable']())return!0x1;const _0x4574e3=await _0x126e0f['_get'](_0x263559)==='true';return await _0x126e0f['_remove'](_0x263559),_0x4574e3;}function Ap(_0x50835d,_0x1b738d){hn['set'](_0x50835d['_key'](),_0x1b738d);}function kp(_0x4fd7e8){return ie(_0x4fd7e8['_redirectPersistence']);}function Pp(_0x308c1d){return ln(Sp,_0x308c1d['config']['apiKey'],_0x308c1d['name']);}async function Np(_0x5b1b77,_0xb43dc,_0x1944ad=!0x1){if($(_0x5b1b77['app']))return Promise['reject'](re(_0x5b1b77));const _0x2548cf=Ke(_0x5b1b77),_0x59c0b3=Ep(_0x2548cf,_0xb43dc),_0xbb441e=await new bp(_0x2548cf,_0x59c0b3,_0x1944ad)['execute']();return _0xbb441e&&!_0x1944ad&&(delete _0xbb441e['user']['_redirectEventId'],await _0x2548cf['_persistUserIfCurrent'](_0xbb441e['user']),await _0x2548cf['_setRedirectUser'](null,_0xb43dc)),_0xbb441e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x6abd89){this['auth']=_0x6abd89,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3ff8cf){this['consumers']['add'](_0x3ff8cf),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3ff8cf)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3ff8cf),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x186fe9){this['consumers']['delete'](_0x186fe9);}['onEvent'](_0x20a2de){if(this['hasEventBeenHandled'](_0x20a2de))return!0x1;let _0x367fe3=!0x1;return this['consumers']['forEach'](_0x2d4b7a=>{this['isEventForConsumer'](_0x20a2de,_0x2d4b7a)&&(_0x367fe3=!0x0,this['sendToConsumer'](_0x20a2de,_0x2d4b7a),this['saveEventToCache'](_0x20a2de));}),this['hasHandledPotentialRedirect']||!Mp(_0x20a2de)||(this['hasHandledPotentialRedirect']=!0x0,_0x367fe3||(this['queuedRedirectEvent']=_0x20a2de,_0x367fe3=!0x0)),_0x367fe3;}['sendToConsumer'](_0x33f5f9,_0x2068f0){var _0x526fb4;if(_0x33f5f9['error']&&!Za(_0x33f5f9)){const _0x3e06e3=((_0x526fb4=_0x33f5f9['error']['code'])==null?void 0x0:_0x526fb4['split']('auth/')[0x1])||'internal-error';_0x2068f0['onError'](X(this['auth'],_0x3e06e3));}else _0x2068f0['onAuthEvent'](_0x33f5f9);}['isEventForConsumer'](_0x457d7c,_0x23dab0){const _0x67fdb9=_0x23dab0['eventId']===null||!!_0x457d7c['eventId']&&_0x457d7c['eventId']===_0x23dab0['eventId'];return _0x23dab0['filter']['includes'](_0x457d7c['type'])&&_0x67fdb9;}['hasEventBeenHandled'](_0x40c057){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x40c057));}['saveEventToCache'](_0xa523ef){this['cachedEventUids']['add'](Mr(_0xa523ef)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1056a7){return[_0x1056a7['type'],_0x1056a7['eventId'],_0x1056a7['sessionId'],_0x1056a7['tenantId']]['filter'](_0x120f15=>_0x120f15)['join']('-');}function Za({type:_0x3e5270,error:_0x310547}){return _0x3e5270==='unknown'&&(_0x310547==null?void 0x0:_0x310547['code'])==='auth/no-auth-event';}function Mp(_0x59e443){switch(_0x59e443['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x59e443);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x28b643,_0x45b705={}){return Pe(_0x28b643,'GET','/v1/projects',_0x45b705);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x443519){if(_0x443519['config']['emulator'])return;const {authorizedDomains:_0x3ab2fe}=await Lp(_0x443519);for(const _0xa93c6a of _0x3ab2fe)try{if(Wp(_0xa93c6a))return;}catch{}Y(_0x443519,'unauthorized-domain');}function Wp(_0x2613dd){const _0x26c024=Mi(),{protocol:_0x12dbf0,hostname:_0x5db342}=new URL(_0x26c024);if(_0x2613dd['startsWith']('chrome-extension://')){const _0x504b95=new URL(_0x2613dd);return _0x504b95['hostname']===''&&_0x5db342===''?_0x12dbf0==='chrome-extension:'&&_0x2613dd['replace']('chrome-extension://','')===_0x26c024['replace']('chrome-extension://',''):_0x12dbf0==='chrome-extension:'&&_0x504b95['hostname']===_0x5db342;}if(!Fp['test'](_0x12dbf0))return!0x1;if(xp['test'](_0x2613dd))return _0x5db342===_0x2613dd;const _0x6b98c1=_0x2613dd['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x6b98c1+'|'+_0x6b98c1+')$','i')['test'](_0x5db342);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x54c754=Z()['___jsl'];if(_0x54c754!=null&&_0x54c754['H']){for(const _0x2bc01d of Object['keys'](_0x54c754['H']))if(_0x54c754['H'][_0x2bc01d]['r']=_0x54c754['H'][_0x2bc01d]['r']||[],_0x54c754['H'][_0x2bc01d]['L']=_0x54c754['H'][_0x2bc01d]['L']||[],_0x54c754['H'][_0x2bc01d]['r']=[..._0x54c754['H'][_0x2bc01d]['L']],_0x54c754['CP']){for(let _0x10195b=0x0;_0x10195b<_0x54c754['CP']['length'];_0x10195b++)_0x54c754['CP'][_0x10195b]=null;}}}function Vp(_0x563302){return new Promise((_0x5dfac4,_0x2ae50a)=>{var _0x5996c7,_0xbbfdcd,_0x799d42;function _0x2dbdc0(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5dfac4(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x2ae50a(X(_0x563302,'network-request-failed'));},'timeout':Bp['get']()});}if((_0xbbfdcd=(_0x5996c7=Z()['gapi'])==null?void 0x0:_0x5996c7['iframes'])!=null&&_0xbbfdcd['Iframe'])_0x5dfac4(gapi['iframes']['getContext']());else{if((_0x799d42=Z()['gapi'])!=null&&_0x799d42['load'])_0x2dbdc0();else{const _0x4b85e4=Ff('iframefcb');return Z()[_0x4b85e4]=()=>{gapi['load']?_0x2dbdc0():_0x2ae50a(X(_0x563302,'network-request-failed'));},xa(xf()+'?onload='+_0x4b85e4)['catch'](_0x43567b=>_0x2ae50a(_0x43567b));}}})['catch'](_0x561f9e=>{throw un=null,_0x561f9e;});}let un=null;function Hp(_0x48575a){return un=un||Vp(_0x48575a),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x4d8734){const _0x451e3d=_0x4d8734['config'];m(_0x451e3d['authDomain'],_0x4d8734,'auth-domain-config-required');const _0x3d73e8=_0x451e3d['emulator']?Cs(_0x451e3d,qp):'https://'+_0x4d8734['config']['authDomain']+'/'+Gp,_0x106a6d={'apiKey':_0x451e3d['apiKey'],'appName':_0x4d8734['name'],'v':dt},_0x2551ee=jp['get'](_0x4d8734['config']['apiHost']);_0x2551ee&&(_0x106a6d['eid']=_0x2551ee);const _0x1b8af4=_0x4d8734['_getFrameworks']();return _0x1b8af4['length']&&(_0x106a6d['fw']=_0x1b8af4['join'](',')),_0x3d73e8+'?'+ut(_0x106a6d)['slice'](0x1);}async function Yp(_0x5bc535){const _0xaaf149=await Hp(_0x5bc535),_0x2a681a=Z()['gapi'];return m(_0x2a681a,_0x5bc535,'internal-error'),_0xaaf149['open']({'where':document['body'],'url':Kp(_0x5bc535),'messageHandlersFilter':_0x2a681a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x46de0d=>new Promise(async(_0x1c3ed5,_0x164215)=>{await _0x46de0d['restyle']({'setHideOnLeave':!0x1});const _0x56053e=X(_0x5bc535,'network-request-failed'),_0x54f034=Z()['setTimeout'](()=>{_0x164215(_0x56053e);},$p['get']());function _0x224625(){Z()['clearTimeout'](_0x54f034),_0x1c3ed5(_0x46de0d);}_0x46de0d['ping'](_0x224625)['then'](_0x224625,()=>{_0x164215(_0x56053e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x5c78ef){this['window']=_0x5c78ef,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x39420c,_0x4189d2,_0x487d17,_0x305163=Jp,_0x46c0ee=Xp){const _0x4b612a=Math['max']((window['screen']['availHeight']-_0x46c0ee)/0x2,0x0)['toString'](),_0x456c07=Math['max']((window['screen']['availWidth']-_0x305163)/0x2,0x0)['toString']();let _0x3daec0='';const _0x2dc6c7={...Qp,'width':_0x305163['toString'](),'height':_0x46c0ee['toString'](),'top':_0x4b612a,'left':_0x456c07},_0x129854=W()['toLowerCase']();_0x487d17&&(_0x3daec0=ka(_0x129854)?Zp:_0x487d17),Ra(_0x129854)&&(_0x4189d2=_0x4189d2||e_,_0x2dc6c7['scrollbars']='yes');const _0x5385c0=Object['entries'](_0x2dc6c7)['reduce']((_0x392ba5,[_0x209831,_0x3fe97b])=>''+_0x392ba5+_0x209831+'='+_0x3fe97b+',','');if(Rf(_0x129854)&&_0x3daec0!=='_self')return n_(_0x4189d2||'',_0x3daec0),new xr(null);const _0x37ad96=window['open'](_0x4189d2||'',_0x3daec0,_0x5385c0);m(_0x37ad96,_0x39420c,'popup-blocked');try{_0x37ad96['focus']();}catch{}return new xr(_0x37ad96);}function n_(_0x1eb91e,_0x10a2e8){const _0x2d4a41=document['createElement']('a');_0x2d4a41['href']=_0x1eb91e,_0x2d4a41['target']=_0x10a2e8;const _0x41a501=document['createEvent']('MouseEvent');_0x41a501['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2d4a41['dispatchEvent'](_0x41a501);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x4d5304,_0x2417a9,_0x12d2b3,_0x216855,_0x4532ce,_0x441795){m(_0x4d5304['config']['authDomain'],_0x4d5304,'auth-domain-config-required'),m(_0x4d5304['config']['apiKey'],_0x4d5304,'invalid-api-key');const _0x544c32={'apiKey':_0x4d5304['config']['apiKey'],'appName':_0x4d5304['name'],'authType':_0x12d2b3,'redirectUrl':_0x216855,'v':dt,'eventId':_0x4532ce};if(_0x2417a9 instanceof Wa){_0x2417a9['setDefaultLanguage'](_0x4d5304['languageCode']),_0x544c32['providerId']=_0x2417a9['providerId']||'',pn(_0x2417a9['getCustomParameters']())||(_0x544c32['customParameters']=JSON['stringify'](_0x2417a9['getCustomParameters']()));for(const [_0x54237f,_0x514320]of Object['entries']({}))_0x544c32[_0x54237f]=_0x514320;}if(_0x2417a9 instanceof tn){const _0x22dc91=_0x2417a9['getScopes']()['filter'](_0x514c4e=>_0x514c4e!=='');_0x22dc91['length']>0x0&&(_0x544c32['scopes']=_0x22dc91['join'](','));}_0x4d5304['tenantId']&&(_0x544c32['tid']=_0x4d5304['tenantId']);const _0x354d46=_0x544c32;for(const _0x507c83 of Object['keys'](_0x354d46))_0x354d46[_0x507c83]===void 0x0&&delete _0x354d46[_0x507c83];const _0x2a1211=await _0x4d5304['_getAppCheckToken'](),_0x233d64=_0x2a1211?'#'+r_+'='+encodeURIComponent(_0x2a1211):'';return o_(_0x4d5304)+'?'+ut(_0x354d46)['slice'](0x1)+_0x233d64;}function o_({config:_0x44ef14}){return _0x44ef14['emulator']?Cs(_0x44ef14,s_):'https://'+_0x44ef14['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x5b2dfe,_0x2c680f,_0x368ccb,_0x3e0f5d){var _0xe7bc56;ce((_0xe7bc56=this['eventManagers'][_0x5b2dfe['_key']()])==null?void 0x0:_0xe7bc56['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2dda57=await Fr(_0x5b2dfe,_0x2c680f,_0x368ccb,Mi(),_0x3e0f5d);return t_(_0x5b2dfe,_0x2dda57,As());}async['_openRedirect'](_0x3c6791,_0x1909a3,_0x4f1d21,_0x5c3797){await this['_originValidation'](_0x3c6791);const _0x4aa0db=await Fr(_0x3c6791,_0x1909a3,_0x4f1d21,Mi(),_0x5c3797);return hp(_0x4aa0db),new Promise(()=>{});}['_initialize'](_0x373cd8){const _0x6b8d47=_0x373cd8['_key']();if(this['eventManagers'][_0x6b8d47]){const {manager:_0x11ea5f,promise:_0x11b9fe}=this['eventManagers'][_0x6b8d47];return _0x11ea5f?Promise['resolve'](_0x11ea5f):(ce(_0x11b9fe,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x11b9fe);}const _0x5ecd0a=this['initAndGetManager'](_0x373cd8);return this['eventManagers'][_0x6b8d47]={'promise':_0x5ecd0a},_0x5ecd0a['catch'](()=>{delete this['eventManagers'][_0x6b8d47];}),_0x5ecd0a;}async['initAndGetManager'](_0x1ab716){const _0x42b219=await Yp(_0x1ab716),_0x57820f=new Dp(_0x1ab716);return _0x42b219['register']('authEvent',_0x5ef283=>(m(_0x5ef283==null?void 0x0:_0x5ef283['authEvent'],_0x1ab716,'invalid-auth-event'),{'status':_0x57820f['onEvent'](_0x5ef283['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1ab716['_key']()]={'manager':_0x57820f},this['iframes'][_0x1ab716['_key']()]=_0x42b219,_0x57820f;}['_isIframeWebStorageSupported'](_0x392edd,_0x11c1e0){this['iframes'][_0x392edd['_key']()]['send'](pi,{'type':pi},_0x19b309=>{var _0x3762d0;const _0xb7da80=(_0x3762d0=_0x19b309==null?void 0x0:_0x19b309[0x0])==null?void 0x0:_0x3762d0[pi];_0xb7da80!==void 0x0&&_0x11c1e0(!!_0xb7da80),Y(_0x392edd,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x22684c){const _0x2bf8cf=_0x22684c['_key']();return this['originValidationPromises'][_0x2bf8cf]||(this['originValidationPromises'][_0x2bf8cf]=Up(_0x22684c)),this['originValidationPromises'][_0x2bf8cf];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x52089a){this['auth']=_0x52089a,this['internalListeners']=new Map();}['getUid'](){var _0x2e5513;return this['assertAuthConfigured'](),((_0x2e5513=this['auth']['currentUser'])==null?void 0x0:_0x2e5513['uid'])||null;}async['getToken'](_0x446f45){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x446f45)}:null;}['addAuthTokenListener'](_0x2e1e71){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2e1e71))return;const _0x5bd784=this['auth']['onIdTokenChanged'](_0x5d5ef3=>{_0x2e1e71((_0x5d5ef3==null?void 0x0:_0x5d5ef3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2e1e71,_0x5bd784),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x337db7){this['assertAuthConfigured']();const _0x51eb7f=this['internalListeners']['get'](_0x337db7);_0x51eb7f&&(this['internalListeners']['delete'](_0x337db7),_0x51eb7f(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x315b2d){switch(_0x315b2d){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2559f7){st(new Fe('auth',(_0x1ead54,{options:_0x3a4da6})=>{const _0x452ca7=_0x1ead54['getProvider']('app')['getImmediate'](),_0x3bd72c=_0x1ead54['getProvider']('heartbeat'),_0x178c45=_0x1ead54['getProvider']('app-check-internal'),{apiKey:_0x46fec1,authDomain:_0x18cadc}=_0x452ca7['options'];m(_0x46fec1&&!_0x46fec1['includes'](':'),'invalid-api-key',{'appName':_0x452ca7['name']});const _0x2e9ec1={'apiKey':_0x46fec1,'authDomain':_0x18cadc,'clientPlatform':_0x2559f7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2559f7)},_0x4f1d42=new Df(_0x452ca7,_0x3bd72c,_0x178c45,_0x2e9ec1);return Hf(_0x4f1d42,_0x3a4da6),_0x4f1d42;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x22214b,_0x339305,_0x5bb70a)=>{_0x22214b['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x358413=>{const _0x4b903b=Ke(_0x358413['getProvider']('auth')['getImmediate']());return(_0xbfcd=>new l_(_0xbfcd))(_0x4b903b);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2559f7)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x50cd67=>async _0x38a241=>{const _0x1a70df=_0x38a241&&await _0x38a241['getIdTokenResult'](),_0x4c0f1a=_0x1a70df&&(new Date()['getTime']()-Date['parse'](_0x1a70df['issuedAtTime']))/0x3e8;if(_0x4c0f1a&&_0x4c0f1a>f_)return;const _0x275503=_0x1a70df==null?void 0x0:_0x1a70df['token'];Br!==_0x275503&&(Br=_0x275503,await fetch(_0x50cd67,{'method':_0x275503?'POST':'DELETE','headers':_0x275503?{'Authorization':'Bearer\x20'+_0x275503}:{}}));};function B_(_0x1aed4c=Zr()){const _0x532a2c=Hi(_0x1aed4c,'auth');if(_0x532a2c['isInitialized']())return _0x532a2c['getImmediate']();const _0x1400e4=Vf(_0x1aed4c,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0xf6e65f=jr('authTokenSyncURL');if(_0xf6e65f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1d5833=new URL(_0xf6e65f,location['origin']);if(location['origin']===_0x1d5833['origin']){const _0x138c80=p_(_0x1d5833['toString']());sp(_0x1400e4,_0x138c80,()=>_0x138c80(_0x1400e4['currentUser'])),ip(_0x1400e4,_0x43c53f=>_0x138c80(_0x43c53f));}}const _0xb9ca88=qr('auth');return _0xb9ca88&&$f(_0x1400e4,'http://'+_0xb9ca88),_0x1400e4;}function __(){var _0x354ae4;return((_0x354ae4=document['getElementsByTagName']('head'))==null?void 0x0:_0x354ae4[0x0])??document;}Mf({'loadJS'(_0x595d86){return new Promise((_0x191fb3,_0x5d8b79)=>{const _0x5e288b=document['createElement']('script');_0x5e288b['setAttribute']('src',_0x595d86),_0x5e288b['onload']=_0x191fb3,_0x5e288b['onerror']=_0xd2fe1f=>{const _0x1ad303=X('internal-error');_0x1ad303['customData']=_0xd2fe1f,_0x5d8b79(_0x1ad303);},_0x5e288b['type']='text/javascript',_0x5e288b['charset']='UTF-8',__()['appendChild'](_0x5e288b);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};