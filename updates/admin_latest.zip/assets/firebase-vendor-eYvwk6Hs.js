const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x426aef,_0x23efb3){if(!_0x426aef)throw ht(_0x23efb3);},ht=function(_0x2bf046){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2bf046);},Hr=function(_0x14dec9){const _0x52b521=[];let _0x187107=0x0;for(let _0x4532d3=0x0;_0x4532d3<_0x14dec9['length'];_0x4532d3++){let _0x2dfbdb=_0x14dec9['charCodeAt'](_0x4532d3);_0x2dfbdb<0x80?_0x52b521[_0x187107++]=_0x2dfbdb:_0x2dfbdb<0x800?(_0x52b521[_0x187107++]=_0x2dfbdb>>0x6|0xc0,_0x52b521[_0x187107++]=_0x2dfbdb&0x3f|0x80):(_0x2dfbdb&0xfc00)===0xd800&&_0x4532d3+0x1<_0x14dec9['length']&&(_0x14dec9['charCodeAt'](_0x4532d3+0x1)&0xfc00)===0xdc00?(_0x2dfbdb=0x10000+((_0x2dfbdb&0x3ff)<<0xa)+(_0x14dec9['charCodeAt'](++_0x4532d3)&0x3ff),_0x52b521[_0x187107++]=_0x2dfbdb>>0x12|0xf0,_0x52b521[_0x187107++]=_0x2dfbdb>>0xc&0x3f|0x80,_0x52b521[_0x187107++]=_0x2dfbdb>>0x6&0x3f|0x80,_0x52b521[_0x187107++]=_0x2dfbdb&0x3f|0x80):(_0x52b521[_0x187107++]=_0x2dfbdb>>0xc|0xe0,_0x52b521[_0x187107++]=_0x2dfbdb>>0x6&0x3f|0x80,_0x52b521[_0x187107++]=_0x2dfbdb&0x3f|0x80);}return _0x52b521;},nc=function(_0x2598bb){const _0x274fbc=[];let _0x2c138a=0x0,_0x49aa3f=0x0;for(;_0x2c138a<_0x2598bb['length'];){const _0x290847=_0x2598bb[_0x2c138a++];if(_0x290847<0x80)_0x274fbc[_0x49aa3f++]=String['fromCharCode'](_0x290847);else{if(_0x290847>0xbf&&_0x290847<0xe0){const _0x553c45=_0x2598bb[_0x2c138a++];_0x274fbc[_0x49aa3f++]=String['fromCharCode']((_0x290847&0x1f)<<0x6|_0x553c45&0x3f);}else{if(_0x290847>0xef&&_0x290847<0x16d){const _0x13d43d=_0x2598bb[_0x2c138a++],_0x4e1ee0=_0x2598bb[_0x2c138a++],_0x3c67d4=_0x2598bb[_0x2c138a++],_0x4e3597=((_0x290847&0x7)<<0x12|(_0x13d43d&0x3f)<<0xc|(_0x4e1ee0&0x3f)<<0x6|_0x3c67d4&0x3f)-0x10000;_0x274fbc[_0x49aa3f++]=String['fromCharCode'](0xd800+(_0x4e3597>>0xa)),_0x274fbc[_0x49aa3f++]=String['fromCharCode'](0xdc00+(_0x4e3597&0x3ff));}else{const _0x2d6847=_0x2598bb[_0x2c138a++],_0x3e5544=_0x2598bb[_0x2c138a++];_0x274fbc[_0x49aa3f++]=String['fromCharCode']((_0x290847&0xf)<<0xc|(_0x2d6847&0x3f)<<0x6|_0x3e5544&0x3f);}}}}return _0x274fbc['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x479530,_0xf34f9c){if(!Array['isArray'](_0x479530))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x11e653=_0xf34f9c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x983669=[];for(let _0x31e66e=0x0;_0x31e66e<_0x479530['length'];_0x31e66e+=0x3){const _0x535fec=_0x479530[_0x31e66e],_0x24aca0=_0x31e66e+0x1<_0x479530['length'],_0x45e89c=_0x24aca0?_0x479530[_0x31e66e+0x1]:0x0,_0x1c86cc=_0x31e66e+0x2<_0x479530['length'],_0x1d907f=_0x1c86cc?_0x479530[_0x31e66e+0x2]:0x0,_0x163141=_0x535fec>>0x2,_0x1bb909=(_0x535fec&0x3)<<0x4|_0x45e89c>>0x4;let _0x2ca0e9=(_0x45e89c&0xf)<<0x2|_0x1d907f>>0x6,_0x556329=_0x1d907f&0x3f;_0x1c86cc||(_0x556329=0x40,_0x24aca0||(_0x2ca0e9=0x40)),_0x983669['push'](_0x11e653[_0x163141],_0x11e653[_0x1bb909],_0x11e653[_0x2ca0e9],_0x11e653[_0x556329]);}return _0x983669['join']('');},'encodeString'(_0x20b5d9,_0x4e388c){return this['HAS_NATIVE_SUPPORT']&&!_0x4e388c?btoa(_0x20b5d9):this['encodeByteArray'](Hr(_0x20b5d9),_0x4e388c);},'decodeString'(_0x311c13,_0x182c68){return this['HAS_NATIVE_SUPPORT']&&!_0x182c68?atob(_0x311c13):nc(this['decodeStringToByteArray'](_0x311c13,_0x182c68));},'decodeStringToByteArray'(_0x159888,_0x31e638){this['init_']();const _0x153d9d=_0x31e638?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x268ba4=[];for(let _0x58df3b=0x0;_0x58df3b<_0x159888['length'];){const _0x3dd429=_0x153d9d[_0x159888['charAt'](_0x58df3b++)],_0x22e0b3=_0x58df3b<_0x159888['length']?_0x153d9d[_0x159888['charAt'](_0x58df3b)]:0x0;++_0x58df3b;const _0x4fb21e=_0x58df3b<_0x159888['length']?_0x153d9d[_0x159888['charAt'](_0x58df3b)]:0x40;++_0x58df3b;const _0x369226=_0x58df3b<_0x159888['length']?_0x153d9d[_0x159888['charAt'](_0x58df3b)]:0x40;if(++_0x58df3b,_0x3dd429==null||_0x22e0b3==null||_0x4fb21e==null||_0x369226==null)throw new ic();const _0x19a300=_0x3dd429<<0x2|_0x22e0b3>>0x4;if(_0x268ba4['push'](_0x19a300),_0x4fb21e!==0x40){const _0x18f30c=_0x22e0b3<<0x4&0xf0|_0x4fb21e>>0x2;if(_0x268ba4['push'](_0x18f30c),_0x369226!==0x40){const _0x482ed0=_0x4fb21e<<0x6&0xc0|_0x369226;_0x268ba4['push'](_0x482ed0);}}}return _0x268ba4;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4d460a=0x0;_0x4d460a<this['ENCODED_VALS']['length'];_0x4d460a++)this['byteToCharMap_'][_0x4d460a]=this['ENCODED_VALS']['charAt'](_0x4d460a),this['charToByteMap_'][this['byteToCharMap_'][_0x4d460a]]=_0x4d460a,this['byteToCharMapWebSafe_'][_0x4d460a]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4d460a),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4d460a]]=_0x4d460a,_0x4d460a>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4d460a)]=_0x4d460a,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4d460a)]=_0x4d460a);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x45a51d){const _0x903329=Hr(_0x45a51d);return Fi['encodeByteArray'](_0x903329,!0x0);},dn=function(_0x4366f8){return $r(_0x4366f8)['replace'](/\./g,'');},fn=function(_0x39e5c6){try{return Fi['decodeString'](_0x39e5c6,!0x0);}catch(_0x2e2ffe){console['error']('base64Decode\x20failed:\x20',_0x2e2ffe);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0xbf8035){return Gr(void 0x0,_0xbf8035);}function Gr(_0x41ad19,_0x1ff00b){if(!(_0x1ff00b instanceof Object))return _0x1ff00b;switch(_0x1ff00b['constructor']){case Date:const _0x1d942f=_0x1ff00b;return new Date(_0x1d942f['getTime']());case Object:_0x41ad19===void 0x0&&(_0x41ad19={});break;case Array:_0x41ad19=[];break;default:return _0x1ff00b;}for(const _0x18b51d in _0x1ff00b)!_0x1ff00b['hasOwnProperty'](_0x18b51d)||!rc(_0x18b51d)||(_0x41ad19[_0x18b51d]=Gr(_0x41ad19[_0x18b51d],_0x1ff00b[_0x18b51d]));return _0x41ad19;}function rc(_0x2686e4){return _0x2686e4!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x4ea759=Ps['__FIREBASE_DEFAULTS__'];if(_0x4ea759)return JSON['parse'](_0x4ea759);},lc=()=>{if(typeof document>'u')return;let _0x477a83;try{_0x477a83=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x499044=_0x477a83&&fn(_0x477a83[0x1]);return _0x499044&&JSON['parse'](_0x499044);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3aacca){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3aacca);return;}},qr=_0x5c2478=>{var _0xda4250,_0xd982eb;return(_0xd982eb=(_0xda4250=Ui())==null?void 0x0:_0xda4250['emulatorHosts'])==null?void 0x0:_0xd982eb[_0x5c2478];},hc=_0x1f2e4f=>{const _0x350442=qr(_0x1f2e4f);if(!_0x350442)return;const _0x1e7948=_0x350442['lastIndexOf'](':');if(_0x1e7948<=0x0||_0x1e7948+0x1===_0x350442['length'])throw new Error('Invalid\x20host\x20'+_0x350442+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0xfc4bd2=parseInt(_0x350442['substring'](_0x1e7948+0x1),0xa);return _0x350442[0x0]==='['?[_0x350442['substring'](0x1,_0x1e7948-0x1),_0xfc4bd2]:[_0x350442['substring'](0x0,_0x1e7948),_0xfc4bd2];},zr=()=>{var _0x32e3dd;return(_0x32e3dd=Ui())==null?void 0x0:_0x32e3dd['config'];},jr=_0x167ca2=>{var _0x26080a;return(_0x26080a=Ui())==null?void 0x0:_0x26080a['_'+_0x167ca2];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x23e66a,_0x3bb9f0)=>{this['resolve']=_0x23e66a,this['reject']=_0x3bb9f0;});}['wrapCallback'](_0x5b2fc2){return(_0x18a7b5,_0x3cc882)=>{_0x18a7b5?this['reject'](_0x18a7b5):this['resolve'](_0x3cc882),typeof _0x5b2fc2=='function'&&(this['promise']['catch'](()=>{}),_0x5b2fc2['length']===0x1?_0x5b2fc2(_0x18a7b5):_0x5b2fc2(_0x18a7b5,_0x3cc882));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4c93cf,_0x5d0448){if(_0x4c93cf['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x21deb1={'alg':'none','type':'JWT'},_0xe00b7e=_0x5d0448||'demo-project',_0x2f54c4=_0x4c93cf['iat']||0x0,_0x2738b2=_0x4c93cf['sub']||_0x4c93cf['user_id'];if(!_0x2738b2)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x481c44={'iss':'https://securetoken.google.com/'+_0xe00b7e,'aud':_0xe00b7e,'iat':_0x2f54c4,'exp':_0x2f54c4+0xe10,'auth_time':_0x2f54c4,'sub':_0x2738b2,'user_id':_0x2738b2,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4c93cf};return[dn(JSON['stringify'](_0x21deb1)),dn(JSON['stringify'](_0x481c44)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4bbdd1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4bbdd1=='object'&&_0x4bbdd1['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x23fa98=W();return _0x23fa98['indexOf']('MSIE\x20')>=0x0||_0x23fa98['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x4f18a1,_0x412bfc)=>{try{let _0x45dcb3=!0x0;const _0x8aa21f='validate-browser-context-for-indexeddb-analytics-module',_0x13d5b7=self['indexedDB']['open'](_0x8aa21f);_0x13d5b7['onsuccess']=()=>{_0x13d5b7['result']['close'](),_0x45dcb3||self['indexedDB']['deleteDatabase'](_0x8aa21f),_0x4f18a1(!0x0);},_0x13d5b7['onupgradeneeded']=()=>{_0x45dcb3=!0x1;},_0x13d5b7['onerror']=()=>{var _0xbc50d1;_0x412bfc(((_0xbc50d1=_0x13d5b7['error'])==null?void 0x0:_0xbc50d1['message'])||'');};}catch(_0x35645f){_0x412bfc(_0x35645f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x366d3b,_0x5792e0,_0x1ec98d){super(_0x5792e0),this['code']=_0x366d3b,this['customData']=_0x1ec98d,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x272130,_0x262141,_0x13c3a9){this['service']=_0x272130,this['serviceName']=_0x262141,this['errors']=_0x13c3a9;}['create'](_0x83be3c,..._0xeb0d2){const _0x3f4341=_0xeb0d2[0x0]||{},_0x2c0c49=this['service']+'/'+_0x83be3c,_0x2b81eb=this['errors'][_0x83be3c],_0x3e0358=_0x2b81eb?vc(_0x2b81eb,_0x3f4341):'Error',_0x41815a=this['serviceName']+':\x20'+_0x3e0358+'\x20('+_0x2c0c49+').';return new Re(_0x2c0c49,_0x41815a,_0x3f4341);}}function vc(_0x4e0fa8,_0x5cc566){return _0x4e0fa8['replace'](Ec,(_0x31e81f,_0xdc1f79)=>{const _0x288de3=_0x5cc566[_0xdc1f79];return _0x288de3!=null?String(_0x288de3):'<'+_0xdc1f79+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x55d9e8){return JSON['parse'](_0x55d9e8);}function O(_0x34dfb8){return JSON['stringify'](_0x34dfb8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5a1c8e){let _0x1f6cb4={},_0xeacd3d={},_0xb799d8={},_0x1dff52='';try{const _0x4f5800=_0x5a1c8e['split']('.');_0x1f6cb4=Nt(fn(_0x4f5800[0x0])||''),_0xeacd3d=Nt(fn(_0x4f5800[0x1])||''),_0x1dff52=_0x4f5800[0x2],_0xb799d8=_0xeacd3d['d']||{},delete _0xeacd3d['d'];}catch{}return{'header':_0x1f6cb4,'claims':_0xeacd3d,'data':_0xb799d8,'signature':_0x1dff52};},Ic=function(_0x1cf423){const _0x4fba29=Yr(_0x1cf423),_0x48c0df=_0x4fba29['claims'];return!!_0x48c0df&&typeof _0x48c0df=='object'&&_0x48c0df['hasOwnProperty']('iat');},wc=function(_0x12b88c){const _0x4c8339=Yr(_0x12b88c)['claims'];return typeof _0x4c8339=='object'&&_0x4c8339['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4adeed,_0x52dabb){return Object['prototype']['hasOwnProperty']['call'](_0x4adeed,_0x52dabb);}function Le(_0x2ced1c,_0xc2816c){if(Object['prototype']['hasOwnProperty']['call'](_0x2ced1c,_0xc2816c))return _0x2ced1c[_0xc2816c];}function pn(_0x1dd427){for(const _0x43304f in _0x1dd427)if(Object['prototype']['hasOwnProperty']['call'](_0x1dd427,_0x43304f))return!0x1;return!0x0;}function _n(_0x427a8d,_0x682a87,_0x4130c7){const _0x2bd1e3={};for(const _0x2052bd in _0x427a8d)Object['prototype']['hasOwnProperty']['call'](_0x427a8d,_0x2052bd)&&(_0x2bd1e3[_0x2052bd]=_0x682a87['call'](_0x4130c7,_0x427a8d[_0x2052bd],_0x2052bd,_0x427a8d));return _0x2bd1e3;}function xe(_0x203242,_0xc2eaf0){if(_0x203242===_0xc2eaf0)return!0x0;const _0x461e37=Object['keys'](_0x203242),_0x211b78=Object['keys'](_0xc2eaf0);for(const _0x4da490 of _0x461e37){if(!_0x211b78['includes'](_0x4da490))return!0x1;const _0x4231d1=_0x203242[_0x4da490],_0x53d3b2=_0xc2eaf0[_0x4da490];if(Ns(_0x4231d1)&&Ns(_0x53d3b2)){if(!xe(_0x4231d1,_0x53d3b2))return!0x1;}else{if(_0x4231d1!==_0x53d3b2)return!0x1;}}for(const _0x24ddea of _0x211b78)if(!_0x461e37['includes'](_0x24ddea))return!0x1;return!0x0;}function Ns(_0x3b2798){return _0x3b2798!==null&&typeof _0x3b2798=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x376d58){const _0x21bd4d=[];for(const [_0x1bd8c6,_0x226b07]of Object['entries'](_0x376d58))Array['isArray'](_0x226b07)?_0x226b07['forEach'](_0x4ddf15=>{_0x21bd4d['push'](encodeURIComponent(_0x1bd8c6)+'='+encodeURIComponent(_0x4ddf15));}):_0x21bd4d['push'](encodeURIComponent(_0x1bd8c6)+'='+encodeURIComponent(_0x226b07));return _0x21bd4d['length']?'&'+_0x21bd4d['join']('&'):'';}function Ct(_0x380ad4){const _0x4fedd2={};return _0x380ad4['replace'](/^\?/,'')['split']('&')['forEach'](_0x28a31a=>{if(_0x28a31a){const [_0x4e078a,_0x160958]=_0x28a31a['split']('=');_0x4fedd2[decodeURIComponent(_0x4e078a)]=decodeURIComponent(_0x160958);}}),_0x4fedd2;}function Tt(_0x526100){const _0x4ee384=_0x526100['indexOf']('?');if(!_0x4ee384)return'';const _0x477056=_0x526100['indexOf']('#',_0x4ee384);return _0x526100['substring'](_0x4ee384,_0x477056>0x0?_0x477056:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x198b80=0x1;_0x198b80<this['blockSize'];++_0x198b80)this['pad_'][_0x198b80]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3234db,_0x200e76){_0x200e76||(_0x200e76=0x0);const _0x14c7ed=this['W_'];if(typeof _0x3234db=='string'){for(let _0x40ea51=0x0;_0x40ea51<0x10;_0x40ea51++)_0x14c7ed[_0x40ea51]=_0x3234db['charCodeAt'](_0x200e76)<<0x18|_0x3234db['charCodeAt'](_0x200e76+0x1)<<0x10|_0x3234db['charCodeAt'](_0x200e76+0x2)<<0x8|_0x3234db['charCodeAt'](_0x200e76+0x3),_0x200e76+=0x4;}else{for(let _0x2d57c4=0x0;_0x2d57c4<0x10;_0x2d57c4++)_0x14c7ed[_0x2d57c4]=_0x3234db[_0x200e76]<<0x18|_0x3234db[_0x200e76+0x1]<<0x10|_0x3234db[_0x200e76+0x2]<<0x8|_0x3234db[_0x200e76+0x3],_0x200e76+=0x4;}for(let _0x332850=0x10;_0x332850<0x50;_0x332850++){const _0x17e2ff=_0x14c7ed[_0x332850-0x3]^_0x14c7ed[_0x332850-0x8]^_0x14c7ed[_0x332850-0xe]^_0x14c7ed[_0x332850-0x10];_0x14c7ed[_0x332850]=(_0x17e2ff<<0x1|_0x17e2ff>>>0x1f)&0xffffffff;}let _0x3c5219=this['chain_'][0x0],_0x3c7914=this['chain_'][0x1],_0x4d19f8=this['chain_'][0x2],_0x24d1a1=this['chain_'][0x3],_0x140413=this['chain_'][0x4],_0x12785b,_0x58b9c5;for(let _0x3c8ce5=0x0;_0x3c8ce5<0x50;_0x3c8ce5++){_0x3c8ce5<0x28?_0x3c8ce5<0x14?(_0x12785b=_0x24d1a1^_0x3c7914&(_0x4d19f8^_0x24d1a1),_0x58b9c5=0x5a827999):(_0x12785b=_0x3c7914^_0x4d19f8^_0x24d1a1,_0x58b9c5=0x6ed9eba1):_0x3c8ce5<0x3c?(_0x12785b=_0x3c7914&_0x4d19f8|_0x24d1a1&(_0x3c7914|_0x4d19f8),_0x58b9c5=0x8f1bbcdc):(_0x12785b=_0x3c7914^_0x4d19f8^_0x24d1a1,_0x58b9c5=0xca62c1d6);const _0x2d188c=(_0x3c5219<<0x5|_0x3c5219>>>0x1b)+_0x12785b+_0x140413+_0x58b9c5+_0x14c7ed[_0x3c8ce5]&0xffffffff;_0x140413=_0x24d1a1,_0x24d1a1=_0x4d19f8,_0x4d19f8=(_0x3c7914<<0x1e|_0x3c7914>>>0x2)&0xffffffff,_0x3c7914=_0x3c5219,_0x3c5219=_0x2d188c;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3c5219&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3c7914&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4d19f8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x24d1a1&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x140413&0xffffffff;}['update'](_0x1b8d70,_0x154c5a){if(_0x1b8d70==null)return;_0x154c5a===void 0x0&&(_0x154c5a=_0x1b8d70['length']);const _0x59a954=_0x154c5a-this['blockSize'];let _0x4b10fe=0x0;const _0xfb392f=this['buf_'];let _0x479f7f=this['inbuf_'];for(;_0x4b10fe<_0x154c5a;){if(_0x479f7f===0x0){for(;_0x4b10fe<=_0x59a954;)this['compress_'](_0x1b8d70,_0x4b10fe),_0x4b10fe+=this['blockSize'];}if(typeof _0x1b8d70=='string'){for(;_0x4b10fe<_0x154c5a;)if(_0xfb392f[_0x479f7f]=_0x1b8d70['charCodeAt'](_0x4b10fe),++_0x479f7f,++_0x4b10fe,_0x479f7f===this['blockSize']){this['compress_'](_0xfb392f),_0x479f7f=0x0;break;}}else{for(;_0x4b10fe<_0x154c5a;)if(_0xfb392f[_0x479f7f]=_0x1b8d70[_0x4b10fe],++_0x479f7f,++_0x4b10fe,_0x479f7f===this['blockSize']){this['compress_'](_0xfb392f),_0x479f7f=0x0;break;}}}this['inbuf_']=_0x479f7f,this['total_']+=_0x154c5a;}['digest'](){const _0x5c4743=[];let _0x2eebc7=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4269b5=this['blockSize']-0x1;_0x4269b5>=0x38;_0x4269b5--)this['buf_'][_0x4269b5]=_0x2eebc7&0xff,_0x2eebc7/=0x100;this['compress_'](this['buf_']);let _0x16a98d=0x0;for(let _0x139780=0x0;_0x139780<0x5;_0x139780++)for(let _0x5dc69a=0x18;_0x5dc69a>=0x0;_0x5dc69a-=0x8)_0x5c4743[_0x16a98d]=this['chain_'][_0x139780]>>_0x5dc69a&0xff,++_0x16a98d;return _0x5c4743;}}function Tc(_0x464394,_0xefab65){const _0xdf5000=new Sc(_0x464394,_0xefab65);return _0xdf5000['subscribe']['bind'](_0xdf5000);}class Sc{constructor(_0x3e9307,_0x2a39c6){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2a39c6,this['task']['then'](()=>{_0x3e9307(this);})['catch'](_0x2e79bc=>{this['error'](_0x2e79bc);});}['next'](_0x5d76fe){this['forEachObserver'](_0x36149a=>{_0x36149a['next'](_0x5d76fe);});}['error'](_0x2d7c5d){this['forEachObserver'](_0x317ff2=>{_0x317ff2['error'](_0x2d7c5d);}),this['close'](_0x2d7c5d);}['complete'](){this['forEachObserver'](_0x1338b8=>{_0x1338b8['complete']();}),this['close']();}['subscribe'](_0x2b1802,_0xabbdf1,_0x3db523){let _0x457cba;if(_0x2b1802===void 0x0&&_0xabbdf1===void 0x0&&_0x3db523===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2b1802,['next','error','complete'])?_0x457cba=_0x2b1802:_0x457cba={'next':_0x2b1802,'error':_0xabbdf1,'complete':_0x3db523},_0x457cba['next']===void 0x0&&(_0x457cba['next']=ti),_0x457cba['error']===void 0x0&&(_0x457cba['error']=ti),_0x457cba['complete']===void 0x0&&(_0x457cba['complete']=ti);const _0x1cf142=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x457cba['error'](this['finalError']):_0x457cba['complete']();}catch{}}),this['observers']['push'](_0x457cba),_0x1cf142;}['unsubscribeOne'](_0x37747f){this['observers']===void 0x0||this['observers'][_0x37747f]===void 0x0||(delete this['observers'][_0x37747f],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3ae092){if(!this['finalized']){for(let _0x516e03=0x0;_0x516e03<this['observers']['length'];_0x516e03++)this['sendOne'](_0x516e03,_0x3ae092);}}['sendOne'](_0x457473,_0xfaab0b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x457473]!==void 0x0)try{_0xfaab0b(this['observers'][_0x457473]);}catch(_0xf4f38c){typeof console<'u'&&console['error']&&console['error'](_0xf4f38c);}});}['close'](_0x3cf2b8){this['finalized']||(this['finalized']=!0x0,_0x3cf2b8!==void 0x0&&(this['finalError']=_0x3cf2b8),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x555e81,_0x1be5cb){if(typeof _0x555e81!='object'||_0x555e81===null)return!0x1;for(const _0x2fa092 of _0x1be5cb)if(_0x2fa092 in _0x555e81&&typeof _0x555e81[_0x2fa092]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x2be7e5,_0xf2666e){return _0x2be7e5+'\x20failed:\x20'+_0xf2666e+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x43097b){const _0x2ae353=[];let _0x2d9359=0x0;for(let _0x4f02a0=0x0;_0x4f02a0<_0x43097b['length'];_0x4f02a0++){let _0x3c7066=_0x43097b['charCodeAt'](_0x4f02a0);if(_0x3c7066>=0xd800&&_0x3c7066<=0xdbff){const _0x152af6=_0x3c7066-0xd800;_0x4f02a0++,f(_0x4f02a0<_0x43097b['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x401d4a=_0x43097b['charCodeAt'](_0x4f02a0)-0xdc00;_0x3c7066=0x10000+(_0x152af6<<0xa)+_0x401d4a;}_0x3c7066<0x80?_0x2ae353[_0x2d9359++]=_0x3c7066:_0x3c7066<0x800?(_0x2ae353[_0x2d9359++]=_0x3c7066>>0x6|0xc0,_0x2ae353[_0x2d9359++]=_0x3c7066&0x3f|0x80):_0x3c7066<0x10000?(_0x2ae353[_0x2d9359++]=_0x3c7066>>0xc|0xe0,_0x2ae353[_0x2d9359++]=_0x3c7066>>0x6&0x3f|0x80,_0x2ae353[_0x2d9359++]=_0x3c7066&0x3f|0x80):(_0x2ae353[_0x2d9359++]=_0x3c7066>>0x12|0xf0,_0x2ae353[_0x2d9359++]=_0x3c7066>>0xc&0x3f|0x80,_0x2ae353[_0x2d9359++]=_0x3c7066>>0x6&0x3f|0x80,_0x2ae353[_0x2d9359++]=_0x3c7066&0x3f|0x80);}return _0x2ae353;},Ln=function(_0xfab8e3){let _0x2ab85f=0x0;for(let _0x3ebe94=0x0;_0x3ebe94<_0xfab8e3['length'];_0x3ebe94++){const _0x2ddedc=_0xfab8e3['charCodeAt'](_0x3ebe94);_0x2ddedc<0x80?_0x2ab85f++:_0x2ddedc<0x800?_0x2ab85f+=0x2:_0x2ddedc>=0xd800&&_0x2ddedc<=0xdbff?(_0x2ab85f+=0x4,_0x3ebe94++):_0x2ab85f+=0x3;}return _0x2ab85f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x5b5c84){return _0x5b5c84&&_0x5b5c84['_delegate']?_0x5b5c84['_delegate']:_0x5b5c84;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x1d5b02){try{return(_0x1d5b02['startsWith']('http://')||_0x1d5b02['startsWith']('https://')?new URL(_0x1d5b02)['hostname']:_0x1d5b02)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x5d1265){return(await fetch(_0x5d1265,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x339d56,_0x4671aa,_0x5a7f76){this['name']=_0x339d56,this['instanceFactory']=_0x4671aa,this['type']=_0x5a7f76,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x326907){return this['instantiationMode']=_0x326907,this;}['setMultipleInstances'](_0x382e24){return this['multipleInstances']=_0x382e24,this;}['setServiceProps'](_0x1151e8){return this['serviceProps']=_0x1151e8,this;}['setInstanceCreatedCallback'](_0x4fa795){return this['onInstanceCreated']=_0x4fa795,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xb0c2de,_0x2c84c4){this['name']=_0xb0c2de,this['container']=_0x2c84c4,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x148262){const _0x350287=this['normalizeInstanceIdentifier'](_0x148262);if(!this['instancesDeferred']['has'](_0x350287)){const _0x3a7341=new H();if(this['instancesDeferred']['set'](_0x350287,_0x3a7341),this['isInitialized'](_0x350287)||this['shouldAutoInitialize']())try{const _0x185e95=this['getOrInitializeService']({'instanceIdentifier':_0x350287});_0x185e95&&_0x3a7341['resolve'](_0x185e95);}catch{}}return this['instancesDeferred']['get'](_0x350287)['promise'];}['getImmediate'](_0x537fc3){const _0x593aee=this['normalizeInstanceIdentifier'](_0x537fc3==null?void 0x0:_0x537fc3['identifier']),_0x4b8ade=(_0x537fc3==null?void 0x0:_0x537fc3['optional'])??!0x1;if(this['isInitialized'](_0x593aee)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x593aee});}catch(_0x3ad5d8){if(_0x4b8ade)return null;throw _0x3ad5d8;}else{if(_0x4b8ade)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2fdc11){if(_0x2fdc11['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2fdc11['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2fdc11,!!this['shouldAutoInitialize']()){if(Pc(_0x2fdc11))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x2de579,_0x3a4639]of this['instancesDeferred']['entries']()){const _0x3a4036=this['normalizeInstanceIdentifier'](_0x2de579);try{const _0x15bfb0=this['getOrInitializeService']({'instanceIdentifier':_0x3a4036});_0x3a4639['resolve'](_0x15bfb0);}catch{}}}}['clearInstance'](_0x38c049=Ne){this['instancesDeferred']['delete'](_0x38c049),this['instancesOptions']['delete'](_0x38c049),this['instances']['delete'](_0x38c049);}async['delete'](){const _0xe76c11=Array['from'](this['instances']['values']());await Promise['all']([..._0xe76c11['filter'](_0x55a6f5=>'INTERNAL'in _0x55a6f5)['map'](_0x410127=>_0x410127['INTERNAL']['delete']()),..._0xe76c11['filter'](_0x2749d3=>'_delete'in _0x2749d3)['map'](_0x178cde=>_0x178cde['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x63feb0=Ne){return this['instances']['has'](_0x63feb0);}['getOptions'](_0x10d7d0=Ne){return this['instancesOptions']['get'](_0x10d7d0)||{};}['initialize'](_0x217d1c={}){const {options:_0x49af8a={}}=_0x217d1c,_0x302cae=this['normalizeInstanceIdentifier'](_0x217d1c['instanceIdentifier']);if(this['isInitialized'](_0x302cae))throw Error(this['name']+'('+_0x302cae+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x39fba3=this['getOrInitializeService']({'instanceIdentifier':_0x302cae,'options':_0x49af8a});for(const [_0x479547,_0x2ea525]of this['instancesDeferred']['entries']()){const _0x5a3aa0=this['normalizeInstanceIdentifier'](_0x479547);_0x302cae===_0x5a3aa0&&_0x2ea525['resolve'](_0x39fba3);}return _0x39fba3;}['onInit'](_0x2c6564,_0x1f57c6){const _0x18f0ce=this['normalizeInstanceIdentifier'](_0x1f57c6),_0x40ab75=this['onInitCallbacks']['get'](_0x18f0ce)??new Set();_0x40ab75['add'](_0x2c6564),this['onInitCallbacks']['set'](_0x18f0ce,_0x40ab75);const _0x2a34fe=this['instances']['get'](_0x18f0ce);return _0x2a34fe&&_0x2c6564(_0x2a34fe,_0x18f0ce),()=>{_0x40ab75['delete'](_0x2c6564);};}['invokeOnInitCallbacks'](_0x342e46,_0x162f41){const _0x5d94da=this['onInitCallbacks']['get'](_0x162f41);if(_0x5d94da){for(const _0x2123b4 of _0x5d94da)try{_0x2123b4(_0x342e46,_0x162f41);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x189a9f,options:_0x2c8807={}}){let _0x3c0e3b=this['instances']['get'](_0x189a9f);if(!_0x3c0e3b&&this['component']&&(_0x3c0e3b=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x189a9f),'options':_0x2c8807}),this['instances']['set'](_0x189a9f,_0x3c0e3b),this['instancesOptions']['set'](_0x189a9f,_0x2c8807),this['invokeOnInitCallbacks'](_0x3c0e3b,_0x189a9f),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x189a9f,_0x3c0e3b);}catch{}return _0x3c0e3b||null;}['normalizeInstanceIdentifier'](_0x5e892f=Ne){return this['component']?this['component']['multipleInstances']?_0x5e892f:Ne:_0x5e892f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2bd7b9){return _0x2bd7b9===Ne?void 0x0:_0x2bd7b9;}function Pc(_0x100e19){return _0x100e19['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4ae220){this['name']=_0x4ae220,this['providers']=new Map();}['addComponent'](_0x5819cc){const _0x2fd983=this['getProvider'](_0x5819cc['name']);if(_0x2fd983['isComponentSet']())throw new Error('Component\x20'+_0x5819cc['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2fd983['setComponent'](_0x5819cc);}['addOrOverwriteComponent'](_0x43c22b){this['getProvider'](_0x43c22b['name'])['isComponentSet']()&&this['providers']['delete'](_0x43c22b['name']),this['addComponent'](_0x43c22b);}['getProvider'](_0x20a93f){if(this['providers']['has'](_0x20a93f))return this['providers']['get'](_0x20a93f);const _0x3ab483=new Ac(_0x20a93f,this);return this['providers']['set'](_0x20a93f,_0x3ab483),_0x3ab483;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x17c877){_0x17c877[_0x17c877['DEBUG']=0x0]='DEBUG',_0x17c877[_0x17c877['VERBOSE']=0x1]='VERBOSE',_0x17c877[_0x17c877['INFO']=0x2]='INFO',_0x17c877[_0x17c877['WARN']=0x3]='WARN',_0x17c877[_0x17c877['ERROR']=0x4]='ERROR',_0x17c877[_0x17c877['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5d4be6,_0xaa9c7a,..._0x1c0948)=>{if(_0xaa9c7a<_0x5d4be6['logLevel'])return;const _0x1685a9=new Date()['toISOString'](),_0x23a211=Mc[_0xaa9c7a];if(_0x23a211)console[_0x23a211]('['+_0x1685a9+']\x20\x20'+_0x5d4be6['name']+':',..._0x1c0948);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xaa9c7a+')');};class Bi{constructor(_0x497ec1){this['name']=_0x497ec1,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x226b74){if(!(_0x226b74 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x226b74+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x226b74;}['setLogLevel'](_0x47be5f){this['_logLevel']=typeof _0x47be5f=='string'?Oc[_0x47be5f]:_0x47be5f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x333e23){if(typeof _0x333e23!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x333e23;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1665cf){this['_userLogHandler']=_0x1665cf;}['debug'](..._0x5dac7a){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5dac7a),this['_logHandler'](this,T['DEBUG'],..._0x5dac7a);}['log'](..._0x54c2ff){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x54c2ff),this['_logHandler'](this,T['VERBOSE'],..._0x54c2ff);}['info'](..._0x7ee2d3){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x7ee2d3),this['_logHandler'](this,T['INFO'],..._0x7ee2d3);}['warn'](..._0x40aec8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x40aec8),this['_logHandler'](this,T['WARN'],..._0x40aec8);}['error'](..._0x55ce0e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x55ce0e),this['_logHandler'](this,T['ERROR'],..._0x55ce0e);}}const xc=(_0x2fec5b,_0x3522dc)=>_0x3522dc['some'](_0x3f0f3a=>_0x2fec5b instanceof _0x3f0f3a);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0xcbca53){const _0x25538b=new Promise((_0x5da9a8,_0xda04b2)=>{const _0x375c1b=()=>{_0xcbca53['removeEventListener']('success',_0x366220),_0xcbca53['removeEventListener']('error',_0x11c890);},_0x366220=()=>{_0x5da9a8(ge(_0xcbca53['result'])),_0x375c1b();},_0x11c890=()=>{_0xda04b2(_0xcbca53['error']),_0x375c1b();};_0xcbca53['addEventListener']('success',_0x366220),_0xcbca53['addEventListener']('error',_0x11c890);});return _0x25538b['then'](_0x434320=>{_0x434320 instanceof IDBCursor&&Jr['set'](_0x434320,_0xcbca53);})['catch'](()=>{}),Vi['set'](_0x25538b,_0xcbca53),_0x25538b;}function Bc(_0x3b76a1){if(_i['has'](_0x3b76a1))return;const _0x3337f8=new Promise((_0x591fa,_0x1b1501)=>{const _0x1e8e7d=()=>{_0x3b76a1['removeEventListener']('complete',_0x2dc2f7),_0x3b76a1['removeEventListener']('error',_0x566199),_0x3b76a1['removeEventListener']('abort',_0x566199);},_0x2dc2f7=()=>{_0x591fa(),_0x1e8e7d();},_0x566199=()=>{_0x1b1501(_0x3b76a1['error']||new DOMException('AbortError','AbortError')),_0x1e8e7d();};_0x3b76a1['addEventListener']('complete',_0x2dc2f7),_0x3b76a1['addEventListener']('error',_0x566199),_0x3b76a1['addEventListener']('abort',_0x566199);});_i['set'](_0x3b76a1,_0x3337f8);}let gi={'get'(_0x301776,_0x5c53e7,_0x46e6d7){if(_0x301776 instanceof IDBTransaction){if(_0x5c53e7==='done')return _i['get'](_0x301776);if(_0x5c53e7==='objectStoreNames')return _0x301776['objectStoreNames']||Xr['get'](_0x301776);if(_0x5c53e7==='store')return _0x46e6d7['objectStoreNames'][0x1]?void 0x0:_0x46e6d7['objectStore'](_0x46e6d7['objectStoreNames'][0x0]);}return ge(_0x301776[_0x5c53e7]);},'set'(_0x5c7ee8,_0x378f89,_0x1c374f){return _0x5c7ee8[_0x378f89]=_0x1c374f,!0x0;},'has'(_0x19550f,_0x810620){return _0x19550f instanceof IDBTransaction&&(_0x810620==='done'||_0x810620==='store')?!0x0:_0x810620 in _0x19550f;}};function Vc(_0x4607d6){gi=_0x4607d6(gi);}function Hc(_0x3e6cc0){return _0x3e6cc0===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x39efe0,..._0x4b9d10){const _0x5cb2ab=_0x3e6cc0['call'](ii(this),_0x39efe0,..._0x4b9d10);return Xr['set'](_0x5cb2ab,_0x39efe0['sort']?_0x39efe0['sort']():[_0x39efe0]),ge(_0x5cb2ab);}:Uc()['includes'](_0x3e6cc0)?function(..._0x5c8e6d){return _0x3e6cc0['apply'](ii(this),_0x5c8e6d),ge(Jr['get'](this));}:function(..._0xed594e){return ge(_0x3e6cc0['apply'](ii(this),_0xed594e));};}function $c(_0x31fe3d){return typeof _0x31fe3d=='function'?Hc(_0x31fe3d):(_0x31fe3d instanceof IDBTransaction&&Bc(_0x31fe3d),xc(_0x31fe3d,Fc())?new Proxy(_0x31fe3d,gi):_0x31fe3d);}function ge(_0x4eae3d){if(_0x4eae3d instanceof IDBRequest)return Wc(_0x4eae3d);if(ni['has'](_0x4eae3d))return ni['get'](_0x4eae3d);const _0x3d26d9=$c(_0x4eae3d);return _0x3d26d9!==_0x4eae3d&&(ni['set'](_0x4eae3d,_0x3d26d9),Vi['set'](_0x3d26d9,_0x4eae3d)),_0x3d26d9;}const ii=_0x923fd8=>Vi['get'](_0x923fd8);function Gc(_0x2cc379,_0x874b6f,{blocked:_0x43ddc0,upgrade:_0x367adb,blocking:_0x13c4f6,terminated:_0x2ef16}={}){const _0x268e14=indexedDB['open'](_0x2cc379,_0x874b6f),_0x1a1a1c=ge(_0x268e14);return _0x367adb&&_0x268e14['addEventListener']('upgradeneeded',_0x3db43d=>{_0x367adb(ge(_0x268e14['result']),_0x3db43d['oldVersion'],_0x3db43d['newVersion'],ge(_0x268e14['transaction']),_0x3db43d);}),_0x43ddc0&&_0x268e14['addEventListener']('blocked',_0x469c28=>_0x43ddc0(_0x469c28['oldVersion'],_0x469c28['newVersion'],_0x469c28)),_0x1a1a1c['then'](_0x7b1bb7=>{_0x2ef16&&_0x7b1bb7['addEventListener']('close',()=>_0x2ef16()),_0x13c4f6&&_0x7b1bb7['addEventListener']('versionchange',_0x36b3e4=>_0x13c4f6(_0x36b3e4['oldVersion'],_0x36b3e4['newVersion'],_0x36b3e4));})['catch'](()=>{}),_0x1a1a1c;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x4250ee,_0x4c2259){if(!(_0x4250ee instanceof IDBDatabase&&!(_0x4c2259 in _0x4250ee)&&typeof _0x4c2259=='string'))return;if(si['get'](_0x4c2259))return si['get'](_0x4c2259);const _0x36841d=_0x4c2259['replace'](/FromIndex$/,''),_0x4e7ae5=_0x4c2259!==_0x36841d,_0x25e690=zc['includes'](_0x36841d);if(!(_0x36841d in(_0x4e7ae5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x25e690||qc['includes'](_0x36841d)))return;const _0x53c61c=async function(_0x201400,..._0x4a6e0c){const _0x135bfa=this['transaction'](_0x201400,_0x25e690?'readwrite':'readonly');let _0x46ea80=_0x135bfa['store'];return _0x4e7ae5&&(_0x46ea80=_0x46ea80['index'](_0x4a6e0c['shift']())),(await Promise['all']([_0x46ea80[_0x36841d](..._0x4a6e0c),_0x25e690&&_0x135bfa['done']]))[0x0];};return si['set'](_0x4c2259,_0x53c61c),_0x53c61c;}Vc(_0x48b132=>({..._0x48b132,'get':(_0x5e7b8e,_0x59de58,_0x13c4b6)=>Ms(_0x5e7b8e,_0x59de58)||_0x48b132['get'](_0x5e7b8e,_0x59de58,_0x13c4b6),'has':(_0x1fb397,_0xa74623)=>!!Ms(_0x1fb397,_0xa74623)||_0x48b132['has'](_0x1fb397,_0xa74623)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x288e57){this['container']=_0x288e57;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xa0fb21=>{if(Kc(_0xa0fb21)){const _0x3e8379=_0xa0fb21['getImmediate']();return _0x3e8379['library']+'/'+_0x3e8379['version'];}else return null;})['filter'](_0x598262=>_0x598262)['join']('\x20');}}function Kc(_0x5e9b6e){const _0x39beaa=_0x5e9b6e['getComponent']();return(_0x39beaa==null?void 0x0:_0x39beaa['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xb1fdcd,_0x37436c){try{_0xb1fdcd['container']['addComponent'](_0x37436c);}catch(_0x418ecb){oe['debug']('Component\x20'+_0x37436c['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xb1fdcd['name'],_0x418ecb);}}function st(_0x4a9fb1){const _0x42cbcf=_0x4a9fb1['name'];if(Ei['has'](_0x42cbcf))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x42cbcf+'.'),!0x1;Ei['set'](_0x42cbcf,_0x4a9fb1);for(const _0x243542 of Ue['values']())xs(_0x243542,_0x4a9fb1);for(const _0x5923ac of vi['values']())xs(_0x5923ac,_0x4a9fb1);return!0x0;}function Hi(_0x2bb51c,_0xc4a034){const _0x5b5a82=_0x2bb51c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5b5a82&&_0x5b5a82['triggerHeartbeat'](),_0x2bb51c['container']['getProvider'](_0xc4a034);}function $(_0x23220e){return _0x23220e==null?!0x1:_0x23220e['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x534c67,_0xe49232,_0x1b7ba6){this['_isDeleted']=!0x1,this['_options']={..._0x534c67},this['_config']={..._0xe49232},this['_name']=_0xe49232['name'],this['_automaticDataCollectionEnabled']=_0xe49232['automaticDataCollectionEnabled'],this['_container']=_0x1b7ba6,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5f0659){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5f0659;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x17e4ff){this['_isDeleted']=_0x17e4ff;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3c4e58,_0x2f3c5b={}){let _0x444e80=_0x3c4e58;typeof _0x2f3c5b!='object'&&(_0x2f3c5b={'name':_0x2f3c5b});const _0x516814={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x2f3c5b},_0x56bb2d=_0x516814['name'];if(typeof _0x56bb2d!='string'||!_0x56bb2d)throw me['create']('bad-app-name',{'appName':String(_0x56bb2d)});if(_0x444e80||(_0x444e80=zr()),!_0x444e80)throw me['create']('no-options');const _0x4c23c4=Ue['get'](_0x56bb2d);if(_0x4c23c4){if(xe(_0x444e80,_0x4c23c4['options'])&&xe(_0x516814,_0x4c23c4['config']))return _0x4c23c4;throw me['create']('duplicate-app',{'appName':_0x56bb2d});}const _0x10a3db=new Nc(_0x56bb2d);for(const _0x51b2e6 of Ei['values']())_0x10a3db['addComponent'](_0x51b2e6);const _0x46bb82=new Tl(_0x444e80,_0x516814,_0x10a3db);return Ue['set'](_0x56bb2d,_0x46bb82),_0x46bb82;}function Zr(_0x27d2b3=yi){const _0xda2408=Ue['get'](_0x27d2b3);if(!_0xda2408&&_0x27d2b3===yi&&zr())return Sl();if(!_0xda2408)throw me['create']('no-app',{'appName':_0x27d2b3});return _0xda2408;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x4be231){let _0x1193c1=!0x1;const _0x33678e=_0x4be231['name'];Ue['has'](_0x33678e)?(_0x1193c1=!0x0,Ue['delete'](_0x33678e)):vi['has'](_0x33678e)&&_0x4be231['decRefCount']()<=0x0&&(vi['delete'](_0x33678e),_0x1193c1=!0x0),_0x1193c1&&(await Promise['all'](_0x4be231['container']['getProviders']()['map'](_0x2681bb=>_0x2681bb['delete']())),_0x4be231['isDeleted']=!0x0);}function ye(_0x13a876,_0x2435b8,_0xa56c14){let _0x5c5742=wl[_0x13a876]??_0x13a876;_0xa56c14&&(_0x5c5742+='-'+_0xa56c14);const _0x26de2b=_0x5c5742['match'](/\s|\//),_0x221881=_0x2435b8['match'](/\s|\//);if(_0x26de2b||_0x221881){const _0x53a9fa=['Unable\x20to\x20register\x20library\x20\x22'+_0x5c5742+'\x22\x20with\x20version\x20\x22'+_0x2435b8+'\x22:'];_0x26de2b&&_0x53a9fa['push']('library\x20name\x20\x22'+_0x5c5742+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x26de2b&&_0x221881&&_0x53a9fa['push']('and'),_0x221881&&_0x53a9fa['push']('version\x20name\x20\x22'+_0x2435b8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x53a9fa['join']('\x20'));return;}st(new Fe(_0x5c5742+'-version',()=>({'library':_0x5c5742,'version':_0x2435b8}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x34154e,_0x454076)=>{switch(_0x454076){case 0x0:try{_0x34154e['createObjectStore'](Ot);}catch(_0x15f0e2){console['warn'](_0x15f0e2);}}}})['catch'](_0x683565=>{throw me['create']('idb-open',{'originalErrorMessage':_0x683565['message']});})),ri;}async function Al(_0x44d0d5){try{const _0x2d6669=(await eo())['transaction'](Ot),_0x480c69=await _0x2d6669['objectStore'](Ot)['get'](to(_0x44d0d5));return await _0x2d6669['done'],_0x480c69;}catch(_0x2706f3){if(_0x2706f3 instanceof Re)oe['warn'](_0x2706f3['message']);else{const _0xda52ce=me['create']('idb-get',{'originalErrorMessage':_0x2706f3==null?void 0x0:_0x2706f3['message']});oe['warn'](_0xda52ce['message']);}}}async function Fs(_0x418fd0,_0x10e9a7){try{const _0xa4a84e=(await eo())['transaction'](Ot,'readwrite');await _0xa4a84e['objectStore'](Ot)['put'](_0x10e9a7,to(_0x418fd0)),await _0xa4a84e['done'];}catch(_0x12ffa0){if(_0x12ffa0 instanceof Re)oe['warn'](_0x12ffa0['message']);else{const _0x3ef60e=me['create']('idb-set',{'originalErrorMessage':_0x12ffa0==null?void 0x0:_0x12ffa0['message']});oe['warn'](_0x3ef60e['message']);}}}function to(_0x26ee7d){return _0x26ee7d['name']+'!'+_0x26ee7d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0xf1b835){this['container']=_0xf1b835,this['_heartbeatsCache']=null;const _0x77e508=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x77e508),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x191730=>(this['_heartbeatsCache']=_0x191730,_0x191730));}async['triggerHeartbeat'](){var _0x214625,_0x3eed04;try{const _0x1f9ef9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x231e5f=Us();if(((_0x214625=this['_heartbeatsCache'])==null?void 0x0:_0x214625['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3eed04=this['_heartbeatsCache'])==null?void 0x0:_0x3eed04['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x231e5f||this['_heartbeatsCache']['heartbeats']['some'](_0x507ef0=>_0x507ef0['date']===_0x231e5f))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x231e5f,'agent':_0x1f9ef9}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x172caf=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x172caf,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xbc90c5){oe['warn'](_0xbc90c5);}}async['getHeartbeatsHeader'](){var _0x32b945;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x32b945=this['_heartbeatsCache'])==null?void 0x0:_0x32b945['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3b45ba=Us(),{heartbeatsToSend:_0x3137ae,unsentEntries:_0x2e83c4}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2927ae=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3137ae}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3b45ba,_0x2e83c4['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2e83c4,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2927ae;}catch(_0x2fe45c){return oe['warn'](_0x2fe45c),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x44d60f,_0x1aa60d=kl){const _0x461cfd=[];let _0x409d0b=_0x44d60f['slice']();for(const _0x4cfa6c of _0x44d60f){const _0xc0ec7e=_0x461cfd['find'](_0x3212d5=>_0x3212d5['agent']===_0x4cfa6c['agent']);if(_0xc0ec7e){if(_0xc0ec7e['dates']['push'](_0x4cfa6c['date']),Ws(_0x461cfd)>_0x1aa60d){_0xc0ec7e['dates']['pop']();break;}}else{if(_0x461cfd['push']({'agent':_0x4cfa6c['agent'],'dates':[_0x4cfa6c['date']]}),Ws(_0x461cfd)>_0x1aa60d){_0x461cfd['pop']();break;}}_0x409d0b=_0x409d0b['slice'](0x1);}return{'heartbeatsToSend':_0x461cfd,'unsentEntries':_0x409d0b};}class Dl{constructor(_0x4835fe){this['app']=_0x4835fe,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x8af27e=await Al(this['app']);return _0x8af27e!=null&&_0x8af27e['heartbeats']?_0x8af27e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x170c5f){if(await this['_canUseIndexedDBPromise']){const _0x21e740=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x170c5f['lastSentHeartbeatDate']??_0x21e740['lastSentHeartbeatDate'],'heartbeats':_0x170c5f['heartbeats']});}else return;}async['add'](_0x1aa750){if(await this['_canUseIndexedDBPromise']){const _0x3ac5e7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1aa750['lastSentHeartbeatDate']??_0x3ac5e7['lastSentHeartbeatDate'],'heartbeats':[..._0x3ac5e7['heartbeats'],..._0x1aa750['heartbeats']]});}else return;}}function Ws(_0x566a2a){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x566a2a}))['length'];}function Ml(_0x48d15e){if(_0x48d15e['length']===0x0)return-0x1;let _0x1ade37=0x0,_0x470daa=_0x48d15e[0x0]['date'];for(let _0xd56fa0=0x1;_0xd56fa0<_0x48d15e['length'];_0xd56fa0++)_0x48d15e[_0xd56fa0]['date']<_0x470daa&&(_0x470daa=_0x48d15e[_0xd56fa0]['date'],_0x1ade37=_0xd56fa0);return _0x1ade37;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x18946f){st(new Fe('platform-logger',_0x2372fb=>new jc(_0x2372fb),'PRIVATE')),st(new Fe('heartbeat',_0x6b4ab8=>new Nl(_0x6b4ab8),'PRIVATE')),ye(mi,Ls,_0x18946f),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x26f7a5){no=_0x26f7a5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1c6e11){this['domStorage_']=_0x1c6e11,this['prefix_']='firebase:';}['set'](_0x34c7f2,_0x155445){_0x155445==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x34c7f2)):this['domStorage_']['setItem'](this['prefixedName_'](_0x34c7f2),O(_0x155445));}['get'](_0x1b957c){const _0x1bf29b=this['domStorage_']['getItem'](this['prefixedName_'](_0x1b957c));return _0x1bf29b==null?null:Nt(_0x1bf29b);}['remove'](_0x1e4ccf){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1e4ccf));}['prefixedName_'](_0x4fa98e){return this['prefix_']+_0x4fa98e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x335a38,_0x1041b6){_0x1041b6==null?delete this['cache_'][_0x335a38]:this['cache_'][_0x335a38]=_0x1041b6;}['get'](_0x552ff2){return Q(this['cache_'],_0x552ff2)?this['cache_'][_0x552ff2]:null;}['remove'](_0x5a6231){delete this['cache_'][_0x5a6231];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4a083a){try{if(typeof window<'u'&&typeof window[_0x4a083a]<'u'){const _0x460ab2=window[_0x4a083a];return _0x460ab2['setItem']('firebase:sentinel','cache'),_0x460ab2['removeItem']('firebase:sentinel'),new Wl(_0x460ab2);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x2a4fa5=0x1;return function(){return _0x2a4fa5++;};}()),ro=function(_0x1d0605){const _0x1457a2=Rc(_0x1d0605),_0xa38a3=new Cc();_0xa38a3['update'](_0x1457a2);const _0x5856aa=_0xa38a3['digest']();return Fi['encodeByteArray'](_0x5856aa);},zt=function(..._0x26a511){let _0x22459e='';for(let _0x3e8a62=0x0;_0x3e8a62<_0x26a511['length'];_0x3e8a62++){const _0x255a10=_0x26a511[_0x3e8a62];Array['isArray'](_0x255a10)||_0x255a10&&typeof _0x255a10=='object'&&typeof _0x255a10['length']=='number'?_0x22459e+=zt['apply'](null,_0x255a10):typeof _0x255a10=='object'?_0x22459e+=O(_0x255a10):_0x22459e+=_0x255a10,_0x22459e+='\x20';}return _0x22459e;};let St=null,$s=!0x0;const Hl=function(_0x588296,_0x51838a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x416867){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x1fa0c9=zt['apply'](null,_0x416867);St(_0x1fa0c9);}},jt=function(_0x5f58e2){return function(..._0x30eb80){L(_0x5f58e2,..._0x30eb80);};},Ii=function(..._0xd37045){const _0x40e1fb='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0xd37045);Ze['error'](_0x40e1fb);},ae=function(..._0x473d40){const _0x4bf276='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x473d40);throw Ze['error'](_0x4bf276),new Error(_0x4bf276);},U=function(..._0x275b8a){const _0x3df7e9='FIREBASE\x20WARNING:\x20'+zt(..._0x275b8a);Ze['warn'](_0x3df7e9);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3355bf){return typeof _0x3355bf=='number'&&(_0x3355bf!==_0x3355bf||_0x3355bf===Number['POSITIVE_INFINITY']||_0x3355bf===Number['NEGATIVE_INFINITY']);},Gl=function(_0x5a6cb6){if(document['readyState']==='complete')_0x5a6cb6();else{let _0x3cb110=!0x1;const _0x59f7c8=function(){if(!document['body']){setTimeout(_0x59f7c8,Math['floor'](0xa));return;}_0x3cb110||(_0x3cb110=!0x0,_0x5a6cb6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x59f7c8,!0x1),window['addEventListener']('load',_0x59f7c8,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x59f7c8();}),window['attachEvent']('onload',_0x59f7c8));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0xbd458b,_0xe8d455){if(_0xbd458b===_0xe8d455)return 0x0;if(_0xbd458b===We||_0xe8d455===we)return-0x1;if(_0xe8d455===We||_0xbd458b===we)return 0x1;{const _0x48a77f=Gs(_0xbd458b),_0x2cf26d=Gs(_0xe8d455);return _0x48a77f!==null?_0x2cf26d!==null?_0x48a77f-_0x2cf26d===0x0?_0xbd458b['length']-_0xe8d455['length']:_0x48a77f-_0x2cf26d:-0x1:_0x2cf26d!==null?0x1:_0xbd458b<_0xe8d455?-0x1:0x1;}},ql=function(_0x5d2db0,_0xfff3ac){return _0x5d2db0===_0xfff3ac?0x0:_0x5d2db0<_0xfff3ac?-0x1:0x1;},vt=function(_0x42ef2a,_0x2de0c5){if(_0x2de0c5&&_0x42ef2a in _0x2de0c5)return _0x2de0c5[_0x42ef2a];throw new Error('Missing\x20required\x20key\x20('+_0x42ef2a+')\x20in\x20object:\x20'+O(_0x2de0c5));},$i=function(_0x47a577){if(typeof _0x47a577!='object'||_0x47a577===null)return O(_0x47a577);const _0x15d9a8=[];for(const _0x8e11b5 in _0x47a577)_0x15d9a8['push'](_0x8e11b5);_0x15d9a8['sort']();let _0x2e5ade='{';for(let _0x3ff263=0x0;_0x3ff263<_0x15d9a8['length'];_0x3ff263++)_0x3ff263!==0x0&&(_0x2e5ade+=','),_0x2e5ade+=O(_0x15d9a8[_0x3ff263]),_0x2e5ade+=':',_0x2e5ade+=$i(_0x47a577[_0x15d9a8[_0x3ff263]]);return _0x2e5ade+='}',_0x2e5ade;},oo=function(_0x988b46,_0x54247c){const _0x2563d1=_0x988b46['length'];if(_0x2563d1<=_0x54247c)return[_0x988b46];const _0x4c837c=[];for(let _0x28e95a=0x0;_0x28e95a<_0x2563d1;_0x28e95a+=_0x54247c)_0x28e95a+_0x54247c>_0x2563d1?_0x4c837c['push'](_0x988b46['substring'](_0x28e95a,_0x2563d1)):_0x4c837c['push'](_0x988b46['substring'](_0x28e95a,_0x28e95a+_0x54247c));return _0x4c837c;};function x(_0x35aad8,_0x241b74){for(const _0x5b6ac5 in _0x35aad8)_0x35aad8['hasOwnProperty'](_0x5b6ac5)&&_0x241b74(_0x5b6ac5,_0x35aad8[_0x5b6ac5]);}const ao=function(_0x35d7fb){f(!xn(_0x35d7fb),'Invalid\x20JSON\x20number');const _0x12804d=0xb,_0x9013bd=0x34,_0x2ccc18=(0x1<<_0x12804d-0x1)-0x1;let _0x2680a9,_0x37e631,_0x5365d7,_0x1996d2,_0x27da9c;_0x35d7fb===0x0?(_0x37e631=0x0,_0x5365d7=0x0,_0x2680a9=0x1/_0x35d7fb===-0x1/0x0?0x1:0x0):(_0x2680a9=_0x35d7fb<0x0,_0x35d7fb=Math['abs'](_0x35d7fb),_0x35d7fb>=Math['pow'](0x2,0x1-_0x2ccc18)?(_0x1996d2=Math['min'](Math['floor'](Math['log'](_0x35d7fb)/Math['LN2']),_0x2ccc18),_0x37e631=_0x1996d2+_0x2ccc18,_0x5365d7=Math['round'](_0x35d7fb*Math['pow'](0x2,_0x9013bd-_0x1996d2)-Math['pow'](0x2,_0x9013bd))):(_0x37e631=0x0,_0x5365d7=Math['round'](_0x35d7fb/Math['pow'](0x2,0x1-_0x2ccc18-_0x9013bd))));const _0x506776=[];for(_0x27da9c=_0x9013bd;_0x27da9c;_0x27da9c-=0x1)_0x506776['push'](_0x5365d7%0x2?0x1:0x0),_0x5365d7=Math['floor'](_0x5365d7/0x2);for(_0x27da9c=_0x12804d;_0x27da9c;_0x27da9c-=0x1)_0x506776['push'](_0x37e631%0x2?0x1:0x0),_0x37e631=Math['floor'](_0x37e631/0x2);_0x506776['push'](_0x2680a9?0x1:0x0),_0x506776['reverse']();const _0x1423cf=_0x506776['join']('');let _0xe99f82='';for(_0x27da9c=0x0;_0x27da9c<0x40;_0x27da9c+=0x8){let _0x4731d0=parseInt(_0x1423cf['substr'](_0x27da9c,0x8),0x2)['toString'](0x10);_0x4731d0['length']===0x1&&(_0x4731d0='0'+_0x4731d0),_0xe99f82=_0xe99f82+_0x4731d0;}return _0xe99f82['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3f035d,_0x289fcb){let _0x4da0fb='Unknown\x20Error';_0x3f035d==='too_big'?_0x4da0fb='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3f035d==='permission_denied'?_0x4da0fb='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3f035d==='unavailable'&&(_0x4da0fb='The\x20service\x20is\x20unavailable');const _0x2714e5=new Error(_0x3f035d+'\x20at\x20'+_0x289fcb['_path']['toString']()+':\x20'+_0x4da0fb);return _0x2714e5['code']=_0x3f035d['toUpperCase'](),_0x2714e5;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x31b69c){if(Yl['test'](_0x31b69c)){const _0x319d25=Number(_0x31b69c);if(_0x319d25>=Ql&&_0x319d25<=Jl)return _0x319d25;}return null;},ft=function(_0x45cd52){try{_0x45cd52();}catch(_0xce86f2){setTimeout(()=>{const _0x3cf7a3=_0xce86f2['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x3cf7a3),_0xce86f2;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x232e6c,_0x312127){const _0x1ac7d2=setTimeout(_0x232e6c,_0x312127);return typeof _0x1ac7d2=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1ac7d2):typeof _0x1ac7d2=='object'&&_0x1ac7d2['unref']&&_0x1ac7d2['unref'](),_0x1ac7d2;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x54e12d,_0x4d100b){this['appCheckProvider']=_0x4d100b,this['appName']=_0x54e12d['name'],$(_0x54e12d)&&_0x54e12d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x54e12d['settings']['appCheckToken']),this['appCheck']=_0x4d100b==null?void 0x0:_0x4d100b['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4d100b==null||_0x4d100b['get']()['then'](_0x399953=>this['appCheck']=_0x399953);}['getToken'](_0x36ca10){if(this['serverAppAppCheckToken']){if(_0x36ca10)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x36ca10):new Promise((_0x36f1af,_0x1d5246)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x36ca10)['then'](_0x36f1af,_0x1d5246):_0x36f1af(null);},0x0);});}['addTokenChangeListener'](_0x48373f){var _0x182bb3;(_0x182bb3=this['appCheckProvider'])==null||_0x182bb3['get']()['then'](_0x4a4959=>_0x4a4959['addTokenListener'](_0x48373f));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x12c738,_0x5badd7,_0x23a305){this['appName_']=_0x12c738,this['firebaseOptions_']=_0x5badd7,this['authProvider_']=_0x23a305,this['auth_']=null,this['auth_']=_0x23a305['getImmediate']({'optional':!0x0}),this['auth_']||_0x23a305['onInit'](_0x3085c3=>this['auth_']=_0x3085c3);}['getToken'](_0x3cbc53){return this['auth_']?this['auth_']['getToken'](_0x3cbc53)['catch'](_0x57155e=>_0x57155e&&_0x57155e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x57155e)):new Promise((_0x587542,_0x46e26d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3cbc53)['then'](_0x587542,_0x46e26d):_0x587542(null);},0x0);});}['addTokenChangeListener'](_0x207b4f){this['auth_']?this['auth_']['addAuthTokenListener'](_0x207b4f):this['authProvider_']['get']()['then'](_0xa8b18c=>_0xa8b18c['addAuthTokenListener'](_0x207b4f));}['removeTokenChangeListener'](_0x5ed90f){this['authProvider_']['get']()['then'](_0x4e0607=>_0x4e0607['removeAuthTokenListener'](_0x5ed90f));}['notifyForInvalidToken'](){let _0x15cae5='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x15cae5+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x15cae5+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x15cae5+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x15cae5);}}class an{constructor(_0x2f2138){this['accessToken']=_0x2f2138;}['getToken'](_0x566803){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x16cb37){_0x16cb37(this['accessToken']);}['removeTokenChangeListener'](_0xd42155){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1df9fb,_0x1251e0,_0x2aad48,_0x74c7ba,_0x509ba4=!0x1,_0x1a5b04='',_0x18794a=!0x1,_0x3d10b5=!0x1,_0x14ed02=null){this['secure']=_0x1251e0,this['namespace']=_0x2aad48,this['webSocketOnly']=_0x74c7ba,this['nodeAdmin']=_0x509ba4,this['persistenceKey']=_0x1a5b04,this['includeNamespaceInQueryParams']=_0x18794a,this['isUsingEmulator']=_0x3d10b5,this['emulatorOptions']=_0x14ed02,this['_host']=_0x1df9fb['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x1df9fb)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4d030d){_0x4d030d!==this['internalHost']&&(this['internalHost']=_0x4d030d,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x10c7dc=this['toURLString']();return this['persistenceKey']&&(_0x10c7dc+='<'+this['persistenceKey']+'>'),_0x10c7dc;}['toURLString'](){const _0x590e9f=this['secure']?'https://':'http://',_0x1f9ee4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x590e9f+this['host']+'/'+_0x1f9ee4;}}function th(_0x1c42f2){return _0x1c42f2['host']!==_0x1c42f2['internalHost']||_0x1c42f2['isCustomHost']()||_0x1c42f2['includeNamespaceInQueryParams'];}function vo(_0x5cd1b2,_0x6589f6,_0x251e1d){f(typeof _0x6589f6=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x251e1d=='object','typeof\x20params\x20must\x20==\x20object');let _0x46e025;if(_0x6589f6===go)_0x46e025=(_0x5cd1b2['secure']?'wss://':'ws://')+_0x5cd1b2['internalHost']+'/.ws?';else{if(_0x6589f6===mo)_0x46e025=(_0x5cd1b2['secure']?'https://':'http://')+_0x5cd1b2['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x6589f6);}th(_0x5cd1b2)&&(_0x251e1d['ns']=_0x5cd1b2['namespace']);const _0x1611d2=[];return x(_0x251e1d,(_0x2e201f,_0x548581)=>{_0x1611d2['push'](_0x2e201f+'='+_0x548581);}),_0x46e025+_0x1611d2['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3c4ad9,_0x5c7a19=0x1){Q(this['counters_'],_0x3c4ad9)||(this['counters_'][_0x3c4ad9]=0x0),this['counters_'][_0x3c4ad9]+=_0x5c7a19;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x523f42){const _0x10aa83=_0x523f42['toString']();return oi[_0x10aa83]||(oi[_0x10aa83]=new nh()),oi[_0x10aa83];}function ih(_0x3f223d,_0x297f17){const _0x240546=_0x3f223d['toString']();return ai[_0x240546]||(ai[_0x240546]=_0x297f17()),ai[_0x240546];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x2021ce){this['onMessage_']=_0x2021ce,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2a254a,_0x4f3e7){this['closeAfterResponse']=_0x2a254a,this['onClose']=_0x4f3e7,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x46d130,_0x251135){for(this['pendingResponses'][_0x46d130]=_0x251135;this['pendingResponses'][this['currentResponseNum']];){const _0x4d773f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5f1888=0x0;_0x5f1888<_0x4d773f['length'];++_0x5f1888)_0x4d773f[_0x5f1888]&&ft(()=>{this['onMessage_'](_0x4d773f[_0x5f1888]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0xb06f36,_0xcda0d4,_0xdcfc9c,_0x48ea3d,_0x464f2e,_0x355a99,_0x86cbeb){this['connId']=_0xb06f36,this['repoInfo']=_0xcda0d4,this['applicationId']=_0xdcfc9c,this['appCheckToken']=_0x48ea3d,this['authToken']=_0x464f2e,this['transportSessionId']=_0x355a99,this['lastSessionId']=_0x86cbeb,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0xb06f36),this['stats_']=qi(_0xcda0d4),this['urlFn']=_0x4fbff5=>(this['appCheckToken']&&(_0x4fbff5[wi]=this['appCheckToken']),vo(_0xcda0d4,mo,_0x4fbff5));}['open'](_0x4dbff1,_0x2c737b){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2c737b,this['myPacketOrderer']=new sh(_0x4dbff1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x3d6df2)=>{const [_0x2e3772,_0x3e4fad,_0xbcf725,_0x4dbaf6,_0xf7afba]=_0x3d6df2;if(this['incrementIncomingBytes_'](_0x3d6df2),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2e3772===qs)this['id']=_0x3e4fad,this['password']=_0xbcf725;else{if(_0x2e3772===rh)_0x3e4fad?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3e4fad,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2e3772);}}},(..._0xb99e5c)=>{const [_0x44407f,_0x557008]=_0xb99e5c;this['incrementIncomingBytes_'](_0xb99e5c),this['myPacketOrderer']['handleResponse'](_0x44407f,_0x557008);},()=>{this['onClosed_']();},this['urlFn']);const _0x48c007={};_0x48c007[qs]='t',_0x48c007[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x48c007[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x48c007[co]=Gi,this['transportSessionId']&&(_0x48c007[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x48c007[po]=this['lastSessionId']),this['applicationId']&&(_0x48c007[_o]=this['applicationId']),this['appCheckToken']&&(_0x48c007[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x48c007[ho]=uo);const _0x2634be=this['urlFn'](_0x48c007);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2634be),this['scriptTagHolder']['addTag'](_0x2634be,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3032bb){const _0x49bbbb=O(_0x3032bb);this['bytesSent']+=_0x49bbbb['length'],this['stats_']['incrementCounter']('bytes_sent',_0x49bbbb['length']);const _0x1d41d9=$r(_0x49bbbb),_0x278d5c=oo(_0x1d41d9,fh);for(let _0x277e60=0x0;_0x277e60<_0x278d5c['length'];_0x277e60++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x278d5c['length'],_0x278d5c[_0x277e60]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xe35d34,_0x2c639c){this['myDisconnFrame']=document['createElement']('iframe');const _0x18f2fa={};_0x18f2fa[dh]='t',_0x18f2fa[Eo]=_0xe35d34,_0x18f2fa[Io]=_0x2c639c,this['myDisconnFrame']['src']=this['urlFn'](_0x18f2fa),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1042bc){const _0x33a649=O(_0x1042bc)['length'];this['bytesReceived']+=_0x33a649,this['stats_']['incrementCounter']('bytes_received',_0x33a649);}}class zi{constructor(_0x5dc866,_0x2f4e04,_0x185c1e,_0x5f4ec4){this['onDisconnect']=_0x185c1e,this['urlFn']=_0x5f4ec4,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5dc866,window[ah+this['uniqueCallbackIdentifier']]=_0x2f4e04,this['myIFrame']=zi['createIFrame_']();let _0x43b827='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x43b827='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4d691b='<html><body>'+_0x43b827+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4d691b),this['myIFrame']['doc']['close']();}catch(_0x158902){L('frame\x20writing\x20exception'),_0x158902['stack']&&L(_0x158902['stack']),L(_0x158902);}}}static['createIFrame_'](){const _0x247fd7=document['createElement']('iframe');if(_0x247fd7['style']['display']='none',document['body']){document['body']['appendChild'](_0x247fd7);try{_0x247fd7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1adb6e=document['domain'];_0x247fd7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1adb6e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x247fd7['contentDocument']?_0x247fd7['doc']=_0x247fd7['contentDocument']:_0x247fd7['contentWindow']?_0x247fd7['doc']=_0x247fd7['contentWindow']['document']:_0x247fd7['document']&&(_0x247fd7['doc']=_0x247fd7['document']),_0x247fd7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x34351b=this['onDisconnect'];_0x34351b&&(this['onDisconnect']=null,_0x34351b());}['startLongPoll'](_0xe775fc,_0x1103a1){for(this['myID']=_0xe775fc,this['myPW']=_0x1103a1,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x36e101={};_0x36e101[Eo]=this['myID'],_0x36e101[Io]=this['myPW'],_0x36e101[wo]=this['currentSerial'];let _0x27cd67=this['urlFn'](_0x36e101),_0x207370='',_0x1b0daa=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x207370['length']<=Co;){const _0x1d9199=this['pendingSegs']['shift']();_0x207370=_0x207370+'&'+lh+_0x1b0daa+'='+_0x1d9199['seg']+'&'+hh+_0x1b0daa+'='+_0x1d9199['ts']+'&'+uh+_0x1b0daa+'='+_0x1d9199['d'],_0x1b0daa++;}return _0x27cd67=_0x27cd67+_0x207370,this['addLongPollTag_'](_0x27cd67,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x47f234,_0x3277d4,_0xd6012e){this['pendingSegs']['push']({'seg':_0x47f234,'ts':_0x3277d4,'d':_0xd6012e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x489c4d,_0x4a93ad){this['outstandingRequests']['add'](_0x4a93ad);const _0x21a17a=()=>{this['outstandingRequests']['delete'](_0x4a93ad),this['newRequest_']();},_0x23aed2=setTimeout(_0x21a17a,Math['floor'](ph)),_0x3119ee=()=>{clearTimeout(_0x23aed2),_0x21a17a();};this['addTag'](_0x489c4d,_0x3119ee);}['addTag'](_0x294a38,_0x30dbfb){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xbd5782=this['myIFrame']['doc']['createElement']('script');_0xbd5782['type']='text/javascript',_0xbd5782['async']=!0x0,_0xbd5782['src']=_0x294a38,_0xbd5782['onload']=_0xbd5782['onreadystatechange']=function(){const _0x6afa20=_0xbd5782['readyState'];(!_0x6afa20||_0x6afa20==='loaded'||_0x6afa20==='complete')&&(_0xbd5782['onload']=_0xbd5782['onreadystatechange']=null,_0xbd5782['parentNode']&&_0xbd5782['parentNode']['removeChild'](_0xbd5782),_0x30dbfb());},_0xbd5782['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x294a38),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xbd5782);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x224d7d,_0x2977e2,_0x5d58b5,_0x4aea23,_0x176d54,_0x286358,_0x56f10f){this['connId']=_0x224d7d,this['applicationId']=_0x5d58b5,this['appCheckToken']=_0x4aea23,this['authToken']=_0x176d54,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x2977e2),this['connURL']=q['connectionURL_'](_0x2977e2,_0x286358,_0x56f10f,_0x4aea23,_0x5d58b5),this['nodeAdmin']=_0x2977e2['nodeAdmin'];}static['connectionURL_'](_0x4d7b04,_0x4e94dd,_0x192383,_0x53e053,_0x298139){const _0x25ba65={};return _0x25ba65[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x25ba65[ho]=uo),_0x4e94dd&&(_0x25ba65[lo]=_0x4e94dd),_0x192383&&(_0x25ba65[po]=_0x192383),_0x53e053&&(_0x25ba65[wi]=_0x53e053),_0x298139&&(_0x25ba65[_o]=_0x298139),vo(_0x4d7b04,go,_0x25ba65);}['open'](_0x13558b,_0x4dd824){this['onDisconnect']=_0x4dd824,this['onMessage']=_0x13558b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5bc247;_c(),this['mySock']=new gn(this['connURL'],[],_0x5bc247);}catch(_0x46860e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x212dbf=_0x46860e['message']||_0x46860e['data'];_0x212dbf&&this['log_'](_0x212dbf),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1c6eaf=>{this['handleIncomingFrame'](_0x1c6eaf);},this['mySock']['onerror']=_0x145b3a=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x523648=_0x145b3a['message']||_0x145b3a['data'];_0x523648&&this['log_'](_0x523648),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x22361f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5bf990=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2c3278=navigator['userAgent']['match'](_0x5bf990);_0x2c3278&&_0x2c3278['length']>0x1&&parseFloat(_0x2c3278[0x1])<4.4&&(_0x22361f=!0x0);}return!_0x22361f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x32fe2b){if(this['frames']['push'](_0x32fe2b),this['frames']['length']===this['totalFrames']){const _0x181922=this['frames']['join']('');this['frames']=null;const _0x369a90=Nt(_0x181922);this['onMessage'](_0x369a90);}}['handleNewFrameCount_'](_0xceac19){this['totalFrames']=_0xceac19,this['frames']=[];}['extractFrameCount_'](_0x179aab){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x179aab['length']<=0x6){const _0x42024e=Number(_0x179aab);if(!isNaN(_0x42024e))return this['handleNewFrameCount_'](_0x42024e),null;}return this['handleNewFrameCount_'](0x1),_0x179aab;}['handleIncomingFrame'](_0x382272){if(this['mySock']===null)return;const _0x5b8524=_0x382272['data'];if(this['bytesReceived']+=_0x5b8524['length'],this['stats_']['incrementCounter']('bytes_received',_0x5b8524['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5b8524);else{const _0x837fff=this['extractFrameCount_'](_0x5b8524);_0x837fff!==null&&this['appendFrame_'](_0x837fff);}}['send'](_0x1c6861){this['resetKeepAlive']();const _0x304569=O(_0x1c6861);this['bytesSent']+=_0x304569['length'],this['stats_']['incrementCounter']('bytes_sent',_0x304569['length']);const _0x5b3709=oo(_0x304569,gh);_0x5b3709['length']>0x1&&this['sendString_'](String(_0x5b3709['length']));for(let _0x463c99=0x0;_0x463c99<_0x5b3709['length'];_0x463c99++)this['sendString_'](_0x5b3709[_0x463c99]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x26a4d9){try{this['mySock']['send'](_0x26a4d9);}catch(_0x479cd0){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x479cd0['message']||_0x479cd0['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5d579d){this['initTransports_'](_0x5d579d);}['initTransports_'](_0xb97576){const _0x283e21=q&&q['isAvailable']();let _0x20edc6=_0x283e21&&!q['previouslyFailed']();if(_0xb97576['webSocketOnly']&&(_0x283e21||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x20edc6=!0x0),_0x20edc6)this['transports_']=[q];else{const _0x5d0232=this['transports_']=[];for(const _0x476c0a of Dt['ALL_TRANSPORTS'])_0x476c0a&&_0x476c0a['isAvailable']()&&_0x5d0232['push'](_0x476c0a);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x17b922,_0x1666ed,_0x188fc1,_0x2fde9b,_0xce1785,_0x355bc7,_0x34d4b8,_0x15f8cb,_0x3e390c,_0x2c3191){this['id']=_0x17b922,this['repoInfo_']=_0x1666ed,this['applicationId_']=_0x188fc1,this['appCheckToken_']=_0x2fde9b,this['authToken_']=_0xce1785,this['onMessage_']=_0x355bc7,this['onReady_']=_0x34d4b8,this['onDisconnect_']=_0x15f8cb,this['onKill_']=_0x3e390c,this['lastSessionId']=_0x2c3191,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x1666ed),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3361a5=this['transportManager_']['initialTransport']();this['conn_']=new _0x3361a5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3361a5['responsesRequiredToBeHealthy']||0x0;const _0x3a2048=this['connReceiver_'](this['conn_']),_0x59f3b1=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3a2048,_0x59f3b1);},Math['floor'](0x0));const _0x341e47=_0x3361a5['healthyTimeout']||0x0;_0x341e47>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x341e47)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2c913c){return _0x573c7d=>{_0x2c913c===this['conn_']?this['onConnectionLost_'](_0x573c7d):_0x2c913c===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x570e84){return _0x7ab9b=>{this['state_']!==0x2&&(_0x570e84===this['rx_']?this['onPrimaryMessageReceived_'](_0x7ab9b):_0x570e84===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x7ab9b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x56a297){const _0x203f25={'t':'d','d':_0x56a297};this['sendData_'](_0x203f25);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x438144){if(ci in _0x438144){const _0x234bd5=_0x438144[ci];_0x234bd5===Ys?this['upgradeIfSecondaryHealthy_']():_0x234bd5===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x234bd5===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x2e952a){const _0x1bfbd3=vt('t',_0x2e952a),_0xf50678=vt('d',_0x2e952a);if(_0x1bfbd3==='c')this['onSecondaryControl_'](_0xf50678);else{if(_0x1bfbd3==='d')this['pendingDataMessages']['push'](_0xf50678);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1bfbd3);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5ef4d5){const _0x6766c7=vt('t',_0x5ef4d5),_0x178608=vt('d',_0x5ef4d5);_0x6766c7==='c'?this['onControl_'](_0x178608):_0x6766c7==='d'&&this['onDataMessage_'](_0x178608);}['onDataMessage_'](_0x3827d5){this['onPrimaryResponse_'](),this['onMessage_'](_0x3827d5);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x786c00){const _0x5e28d7=vt(ci,_0x786c00);if(zs in _0x786c00){const _0x6a1282=_0x786c00[zs];if(_0x5e28d7===Th){const _0x12bf54={..._0x6a1282};this['repoInfo_']['isUsingEmulator']&&(_0x12bf54['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x12bf54);}else{if(_0x5e28d7===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x50482b=0x0;_0x50482b<this['pendingDataMessages']['length'];++_0x50482b)this['onDataMessage_'](this['pendingDataMessages'][_0x50482b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5e28d7===wh?this['onConnectionShutdown_'](_0x6a1282):_0x5e28d7===js?this['onReset_'](_0x6a1282):_0x5e28d7===Ch?Ii('Server\x20Error:\x20'+_0x6a1282):_0x5e28d7===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x5e28d7);}}}['onHandshake_'](_0x1b62e2){const _0x27ba5f=_0x1b62e2['ts'],_0x36211d=_0x1b62e2['v'],_0x2fc8d1=_0x1b62e2['h'];this['sessionId']=_0x1b62e2['s'],this['repoInfo_']['host']=_0x2fc8d1,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x27ba5f),Gi!==_0x36211d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2e6ece=this['transportManager_']['upgradeTransport']();_0x2e6ece&&this['startUpgrade_'](_0x2e6ece);}['startUpgrade_'](_0x50f8c7){this['secondaryConn_']=new _0x50f8c7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x50f8c7['responsesRequiredToBeHealthy']||0x0;const _0x139c7e=this['connReceiver_'](this['secondaryConn_']),_0xc8368a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x139c7e,_0xc8368a),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x56cbe6){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x56cbe6),this['repoInfo_']['host']=_0x56cbe6,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x510db9,_0x2aa834){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x510db9,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2aa834,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xf8342a=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xf8342a||this['rx_']===_0xf8342a)&&this['close']();}['onConnectionLost_'](_0x378480){this['conn_']=null,!_0x378480&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xf679c0){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xf679c0),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5eaa87){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5eaa87);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x5a868f,_0x1a5e49,_0x5ffc89,_0x50d6ec){}['merge'](_0x5c6e1c,_0x2783ca,_0x5dd6ab,_0x3fa35c){}['refreshAuthToken'](_0x59528c){}['refreshAppCheckToken'](_0x3e6669){}['onDisconnectPut'](_0x99fcfc,_0x186036,_0x598f2b){}['onDisconnectMerge'](_0x266d57,_0x453c81,_0x4327f2){}['onDisconnectCancel'](_0x53ee28,_0x512b15){}['reportStats'](_0x179570){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x13dada){this['allowedEvents_']=_0x13dada,this['listeners_']={},f(Array['isArray'](_0x13dada)&&_0x13dada['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x4e5b67,..._0x472c73){if(Array['isArray'](this['listeners_'][_0x4e5b67])){const _0xf41d6d=[...this['listeners_'][_0x4e5b67]];for(let _0x26c1f8=0x0;_0x26c1f8<_0xf41d6d['length'];_0x26c1f8++)_0xf41d6d[_0x26c1f8]['callback']['apply'](_0xf41d6d[_0x26c1f8]['context'],_0x472c73);}}['on'](_0x4f061c,_0x65cb1c,_0x349f5e){this['validateEventType_'](_0x4f061c),this['listeners_'][_0x4f061c]=this['listeners_'][_0x4f061c]||[],this['listeners_'][_0x4f061c]['push']({'callback':_0x65cb1c,'context':_0x349f5e});const _0x145adc=this['getInitialEvent'](_0x4f061c);_0x145adc&&_0x65cb1c['apply'](_0x349f5e,_0x145adc);}['off'](_0x32ad2d,_0x4951ff,_0x1a90d8){this['validateEventType_'](_0x32ad2d);const _0x127624=this['listeners_'][_0x32ad2d]||[];for(let _0x4c0e25=0x0;_0x4c0e25<_0x127624['length'];_0x4c0e25++)if(_0x127624[_0x4c0e25]['callback']===_0x4951ff&&(!_0x1a90d8||_0x1a90d8===_0x127624[_0x4c0e25]['context'])){_0x127624['splice'](_0x4c0e25,0x1);return;}}['validateEventType_'](_0x515069){f(this['allowedEvents_']['find'](_0x3c9fcc=>_0x3c9fcc===_0x515069),'Unknown\x20event:\x20'+_0x515069);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5cb9ee){return f(_0x5cb9ee==='online','Unknown\x20event\x20type:\x20'+_0x5cb9ee),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x54c213,_0x372843){if(_0x372843===void 0x0){this['pieces_']=_0x54c213['split']('/');let _0xa87f92=0x0;for(let _0x13da92=0x0;_0x13da92<this['pieces_']['length'];_0x13da92++)this['pieces_'][_0x13da92]['length']>0x0&&(this['pieces_'][_0xa87f92]=this['pieces_'][_0x13da92],_0xa87f92++);this['pieces_']['length']=_0xa87f92,this['pieceNum_']=0x0;}else this['pieces_']=_0x54c213,this['pieceNum_']=_0x372843;}['toString'](){let _0x342c56='';for(let _0x523ae7=this['pieceNum_'];_0x523ae7<this['pieces_']['length'];_0x523ae7++)this['pieces_'][_0x523ae7]!==''&&(_0x342c56+='/'+this['pieces_'][_0x523ae7]);return _0x342c56||'/';}}function w(){return new C('');}function y(_0x4848fc){return _0x4848fc['pieceNum_']>=_0x4848fc['pieces_']['length']?null:_0x4848fc['pieces_'][_0x4848fc['pieceNum_']];}function Ce(_0x10844d){return _0x10844d['pieces_']['length']-_0x10844d['pieceNum_'];}function S(_0x3e9996){let _0x219980=_0x3e9996['pieceNum_'];return _0x219980<_0x3e9996['pieces_']['length']&&_0x219980++,new C(_0x3e9996['pieces_'],_0x219980);}function ji(_0x3e871d){return _0x3e871d['pieceNum_']<_0x3e871d['pieces_']['length']?_0x3e871d['pieces_'][_0x3e871d['pieces_']['length']-0x1]:null;}function bh(_0x1f6c4c){let _0x2f193e='';for(let _0x1070a6=_0x1f6c4c['pieceNum_'];_0x1070a6<_0x1f6c4c['pieces_']['length'];_0x1070a6++)_0x1f6c4c['pieces_'][_0x1070a6]!==''&&(_0x2f193e+='/'+encodeURIComponent(String(_0x1f6c4c['pieces_'][_0x1070a6])));return _0x2f193e||'/';}function Mt(_0x1a1ecf,_0x1ff622=0x0){return _0x1a1ecf['pieces_']['slice'](_0x1a1ecf['pieceNum_']+_0x1ff622);}function Ro(_0x4f297e){if(_0x4f297e['pieceNum_']>=_0x4f297e['pieces_']['length'])return null;const _0x3e943f=[];for(let _0x199068=_0x4f297e['pieceNum_'];_0x199068<_0x4f297e['pieces_']['length']-0x1;_0x199068++)_0x3e943f['push'](_0x4f297e['pieces_'][_0x199068]);return new C(_0x3e943f,0x0);}function k(_0x1b4c6a,_0x3834d8){const _0x14cde0=[];for(let _0x467559=_0x1b4c6a['pieceNum_'];_0x467559<_0x1b4c6a['pieces_']['length'];_0x467559++)_0x14cde0['push'](_0x1b4c6a['pieces_'][_0x467559]);if(_0x3834d8 instanceof C){for(let _0x476025=_0x3834d8['pieceNum_'];_0x476025<_0x3834d8['pieces_']['length'];_0x476025++)_0x14cde0['push'](_0x3834d8['pieces_'][_0x476025]);}else{const _0x59d985=_0x3834d8['split']('/');for(let _0x3193b5=0x0;_0x3193b5<_0x59d985['length'];_0x3193b5++)_0x59d985[_0x3193b5]['length']>0x0&&_0x14cde0['push'](_0x59d985[_0x3193b5]);}return new C(_0x14cde0,0x0);}function v(_0x1d93a3){return _0x1d93a3['pieceNum_']>=_0x1d93a3['pieces_']['length'];}function F(_0x2a28d8,_0x432c79){const _0x338f5e=y(_0x2a28d8),_0x2dfb89=y(_0x432c79);if(_0x338f5e===null)return _0x432c79;if(_0x338f5e===_0x2dfb89)return F(S(_0x2a28d8),S(_0x432c79));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x432c79+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2a28d8+')');}function Rh(_0x363a8d,_0x5ddcbe){const _0x1be8fe=Mt(_0x363a8d,0x0),_0x672527=Mt(_0x5ddcbe,0x0);for(let _0x3dbd46=0x0;_0x3dbd46<_0x1be8fe['length']&&_0x3dbd46<_0x672527['length'];_0x3dbd46++){const _0x1ee0fb=qe(_0x1be8fe[_0x3dbd46],_0x672527[_0x3dbd46]);if(_0x1ee0fb!==0x0)return _0x1ee0fb;}return _0x1be8fe['length']===_0x672527['length']?0x0:_0x1be8fe['length']<_0x672527['length']?-0x1:0x1;}function Ki(_0x1ee11a,_0x374e8a){if(Ce(_0x1ee11a)!==Ce(_0x374e8a))return!0x1;for(let _0x5a75e7=_0x1ee11a['pieceNum_'],_0x11939c=_0x374e8a['pieceNum_'];_0x5a75e7<=_0x1ee11a['pieces_']['length'];_0x5a75e7++,_0x11939c++)if(_0x1ee11a['pieces_'][_0x5a75e7]!==_0x374e8a['pieces_'][_0x11939c])return!0x1;return!0x0;}function G(_0x18a89a,_0x817b47){let _0x369a4e=_0x18a89a['pieceNum_'],_0x3f51a4=_0x817b47['pieceNum_'];if(Ce(_0x18a89a)>Ce(_0x817b47))return!0x1;for(;_0x369a4e<_0x18a89a['pieces_']['length'];){if(_0x18a89a['pieces_'][_0x369a4e]!==_0x817b47['pieces_'][_0x3f51a4])return!0x1;++_0x369a4e,++_0x3f51a4;}return!0x0;}class Ah{constructor(_0x4c3570,_0x298f6d){this['errorPrefix_']=_0x298f6d,this['parts_']=Mt(_0x4c3570,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2fdaa0=0x0;_0x2fdaa0<this['parts_']['length'];_0x2fdaa0++)this['byteLength_']+=Ln(this['parts_'][_0x2fdaa0]);Ao(this);}}function kh(_0x4fd1ec,_0x126071){_0x4fd1ec['parts_']['length']>0x0&&(_0x4fd1ec['byteLength_']+=0x1),_0x4fd1ec['parts_']['push'](_0x126071),_0x4fd1ec['byteLength_']+=Ln(_0x126071),Ao(_0x4fd1ec);}function Ph(_0x5d3496){const _0x572bff=_0x5d3496['parts_']['pop']();_0x5d3496['byteLength_']-=Ln(_0x572bff),_0x5d3496['parts_']['length']>0x0&&(_0x5d3496['byteLength_']-=0x1);}function Ao(_0x76ff55){if(_0x76ff55['byteLength_']>Zs)throw new Error(_0x76ff55['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x76ff55['byteLength_']+').');if(_0x76ff55['parts_']['length']>Xs)throw new Error(_0x76ff55['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x76ff55));}function Oe(_0x3ba197){return _0x3ba197['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3ba197['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x28d46d,_0x23add3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x23add3='visibilitychange',_0x28d46d='hidden'):typeof document['mozHidden']<'u'?(_0x23add3='mozvisibilitychange',_0x28d46d='mozHidden'):typeof document['msHidden']<'u'?(_0x23add3='msvisibilitychange',_0x28d46d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x23add3='webkitvisibilitychange',_0x28d46d='webkitHidden')),this['visible_']=!0x0,_0x23add3&&document['addEventListener'](_0x23add3,()=>{const _0x20c346=!document[_0x28d46d];_0x20c346!==this['visible_']&&(this['visible_']=_0x20c346,this['trigger']('visible',_0x20c346));},!0x1);}['getInitialEvent'](_0x5cbeee){return f(_0x5cbeee==='visible','Unknown\x20event\x20type:\x20'+_0x5cbeee),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x173dbe,_0x4ba55c,_0x549cb2,_0x250871,_0x81d3ee,_0x4d9394,_0x1e94e0,_0x26272b){if(super(),this['repoInfo_']=_0x173dbe,this['applicationId_']=_0x4ba55c,this['onDataUpdate_']=_0x549cb2,this['onConnectStatus_']=_0x250871,this['onServerInfoUpdate_']=_0x81d3ee,this['authTokenProvider_']=_0x4d9394,this['appCheckTokenProvider_']=_0x1e94e0,this['authOverride_']=_0x26272b,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x26272b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x173dbe['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x13fed1,_0x1ac67d,_0x28dab5){const _0x193d10=++this['requestNumber_'],_0x368754={'r':_0x193d10,'a':_0x13fed1,'b':_0x1ac67d};this['log_'](O(_0x368754)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x368754),_0x28dab5&&(this['requestCBHash_'][_0x193d10]=_0x28dab5);}['get'](_0x47ff8c){this['initConnection_']();const _0x20e3d8=new H(),_0x4a582c={'action':'g','request':{'p':_0x47ff8c['_path']['toString'](),'q':_0x47ff8c['_queryObject']},'onComplete':_0x4c0fdd=>{const _0x1c2790=_0x4c0fdd['d'];_0x4c0fdd['s']==='ok'?_0x20e3d8['resolve'](_0x1c2790):_0x20e3d8['reject'](_0x1c2790);}};this['outstandingGets_']['push'](_0x4a582c),this['outstandingGetCount_']++;const _0x228da4=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x228da4),_0x20e3d8['promise'];}['listen'](_0xe37524,_0x66cec8,_0x1ec227,_0x3dd939){this['initConnection_']();const _0xc9a002=_0xe37524['_queryIdentifier'],_0x20babf=_0xe37524['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x20babf+'\x20'+_0xc9a002),this['listens']['has'](_0x20babf)||this['listens']['set'](_0x20babf,new Map()),f(_0xe37524['_queryParams']['isDefault']()||!_0xe37524['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x20babf)['has'](_0xc9a002),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1eb03f={'onComplete':_0x3dd939,'hashFn':_0x66cec8,'query':_0xe37524,'tag':_0x1ec227};this['listens']['get'](_0x20babf)['set'](_0xc9a002,_0x1eb03f),this['connected_']&&this['sendListen_'](_0x1eb03f);}['sendGet_'](_0x46dfba){const _0x1ab3f9=this['outstandingGets_'][_0x46dfba];this['sendRequest']('g',_0x1ab3f9['request'],_0xf0de12=>{delete this['outstandingGets_'][_0x46dfba],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1ab3f9['onComplete']&&_0x1ab3f9['onComplete'](_0xf0de12);});}['sendListen_'](_0x5c9f1e){const _0x3ab46c=_0x5c9f1e['query'],_0xab64f4=_0x3ab46c['_path']['toString'](),_0x39bac6=_0x3ab46c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0xab64f4+'\x20for\x20'+_0x39bac6);const _0x48d21b={'p':_0xab64f4},_0x4aafd7='q';_0x5c9f1e['tag']&&(_0x48d21b['q']=_0x3ab46c['_queryObject'],_0x48d21b['t']=_0x5c9f1e['tag']),_0x48d21b['h']=_0x5c9f1e['hashFn'](),this['sendRequest'](_0x4aafd7,_0x48d21b,_0x14825f=>{const _0x5cc1e9=_0x14825f['d'],_0x557bc4=_0x14825f['s'];se['warnOnListenWarnings_'](_0x5cc1e9,_0x3ab46c),(this['listens']['get'](_0xab64f4)&&this['listens']['get'](_0xab64f4)['get'](_0x39bac6))===_0x5c9f1e&&(this['log_']('listen\x20response',_0x14825f),_0x557bc4!=='ok'&&this['removeListen_'](_0xab64f4,_0x39bac6),_0x5c9f1e['onComplete']&&_0x5c9f1e['onComplete'](_0x557bc4,_0x5cc1e9));});}static['warnOnListenWarnings_'](_0x48fcd5,_0x190ba9){if(_0x48fcd5&&typeof _0x48fcd5=='object'&&Q(_0x48fcd5,'w')){const _0x338ea1=Le(_0x48fcd5,'w');if(Array['isArray'](_0x338ea1)&&~_0x338ea1['indexOf']('no_index')){const _0x4da08c='\x22.indexOn\x22:\x20\x22'+_0x190ba9['_queryParams']['getIndex']()['toString']()+'\x22',_0x585d47=_0x190ba9['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4da08c+'\x20at\x20'+_0x585d47+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1a0b97){this['authToken_']=_0x1a0b97,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1a0b97);}['reduceReconnectDelayIfAdminCredential_'](_0x4a0cae){(_0x4a0cae&&_0x4a0cae['length']===0x28||wc(_0x4a0cae))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x52bf68){this['appCheckToken_']=_0x52bf68,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x19c100=this['authToken_'],_0x2f58fc=Ic(_0x19c100)?'auth':'gauth',_0x8c53b6={'cred':_0x19c100};this['authOverride_']===null?_0x8c53b6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x8c53b6['authvar']=this['authOverride_']),this['sendRequest'](_0x2f58fc,_0x8c53b6,_0x363588=>{const _0x46f1b4=_0x363588['s'],_0x36ccbf=_0x363588['d']||'error';this['authToken_']===_0x19c100&&(_0x46f1b4==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x46f1b4,_0x36ccbf));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x208dd0=>{const _0x2decdf=_0x208dd0['s'],_0x3216fa=_0x208dd0['d']||'error';_0x2decdf==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2decdf,_0x3216fa);});}['unlisten'](_0x44218e,_0x2da2e8){const _0x2edadd=_0x44218e['_path']['toString'](),_0x161260=_0x44218e['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2edadd+'\x20'+_0x161260),f(_0x44218e['_queryParams']['isDefault']()||!_0x44218e['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2edadd,_0x161260)&&this['connected_']&&this['sendUnlisten_'](_0x2edadd,_0x161260,_0x44218e['_queryObject'],_0x2da2e8);}['sendUnlisten_'](_0x44aeff,_0x3db754,_0x1d5d74,_0x72af85){this['log_']('Unlisten\x20on\x20'+_0x44aeff+'\x20for\x20'+_0x3db754);const _0x4c9eac={'p':_0x44aeff},_0x51dbcf='n';_0x72af85&&(_0x4c9eac['q']=_0x1d5d74,_0x4c9eac['t']=_0x72af85),this['sendRequest'](_0x51dbcf,_0x4c9eac);}['onDisconnectPut'](_0x956daf,_0x541275,_0x4173cf){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x956daf,_0x541275,_0x4173cf):this['onDisconnectRequestQueue_']['push']({'pathString':_0x956daf,'action':'o','data':_0x541275,'onComplete':_0x4173cf});}['onDisconnectMerge'](_0x2d7061,_0x594702,_0x275ec6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2d7061,_0x594702,_0x275ec6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2d7061,'action':'om','data':_0x594702,'onComplete':_0x275ec6});}['onDisconnectCancel'](_0xfbcb0,_0x209974){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xfbcb0,null,_0x209974):this['onDisconnectRequestQueue_']['push']({'pathString':_0xfbcb0,'action':'oc','data':null,'onComplete':_0x209974});}['sendOnDisconnect_'](_0x3790fe,_0x381229,_0x54f3d3,_0x54f9fb){const _0x134d1c={'p':_0x381229,'d':_0x54f3d3};this['log_']('onDisconnect\x20'+_0x3790fe,_0x134d1c),this['sendRequest'](_0x3790fe,_0x134d1c,_0x5cae7b=>{_0x54f9fb&&setTimeout(()=>{_0x54f9fb(_0x5cae7b['s'],_0x5cae7b['d']);},Math['floor'](0x0));});}['put'](_0x5f1ca9,_0x45603d,_0x5aa147,_0x27a636){this['putInternal']('p',_0x5f1ca9,_0x45603d,_0x5aa147,_0x27a636);}['merge'](_0x30a48e,_0x3c00b2,_0x5ca1c0,_0x55e0b0){this['putInternal']('m',_0x30a48e,_0x3c00b2,_0x5ca1c0,_0x55e0b0);}['putInternal'](_0x122f71,_0x17826d,_0x60422e,_0x48667b,_0x40aeca){this['initConnection_']();const _0x2a3c2a={'p':_0x17826d,'d':_0x60422e};_0x40aeca!==void 0x0&&(_0x2a3c2a['h']=_0x40aeca),this['outstandingPuts_']['push']({'action':_0x122f71,'request':_0x2a3c2a,'onComplete':_0x48667b}),this['outstandingPutCount_']++;const _0xdb6d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xdb6d):this['log_']('Buffering\x20put:\x20'+_0x17826d);}['sendPut_'](_0x970811){const _0x21e0a2=this['outstandingPuts_'][_0x970811]['action'],_0x1192fb=this['outstandingPuts_'][_0x970811]['request'],_0x1ca1e8=this['outstandingPuts_'][_0x970811]['onComplete'];this['outstandingPuts_'][_0x970811]['queued']=this['connected_'],this['sendRequest'](_0x21e0a2,_0x1192fb,_0x59930a=>{this['log_'](_0x21e0a2+'\x20response',_0x59930a),delete this['outstandingPuts_'][_0x970811],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1ca1e8&&_0x1ca1e8(_0x59930a['s'],_0x59930a['d']);});}['reportStats'](_0x2da499){if(this['connected_']){const _0x5d8bba={'c':_0x2da499};this['log_']('reportStats',_0x5d8bba),this['sendRequest']('s',_0x5d8bba,_0x20caeb=>{if(_0x20caeb['s']!=='ok'){const _0x48ee0a=_0x20caeb['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x48ee0a);}});}}['onDataMessage_'](_0x4834bf){if('r'in _0x4834bf){this['log_']('from\x20server:\x20'+O(_0x4834bf));const _0x39cf76=_0x4834bf['r'],_0x3c9a62=this['requestCBHash_'][_0x39cf76];_0x3c9a62&&(delete this['requestCBHash_'][_0x39cf76],_0x3c9a62(_0x4834bf['b']));}else{if('error'in _0x4834bf)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4834bf['error'];'a'in _0x4834bf&&this['onDataPush_'](_0x4834bf['a'],_0x4834bf['b']);}}['onDataPush_'](_0x56927c,_0x21aabe){this['log_']('handleServerMessage',_0x56927c,_0x21aabe),_0x56927c==='d'?this['onDataUpdate_'](_0x21aabe['p'],_0x21aabe['d'],!0x1,_0x21aabe['t']):_0x56927c==='m'?this['onDataUpdate_'](_0x21aabe['p'],_0x21aabe['d'],!0x0,_0x21aabe['t']):_0x56927c==='c'?this['onListenRevoked_'](_0x21aabe['p'],_0x21aabe['q']):_0x56927c==='ac'?this['onAuthRevoked_'](_0x21aabe['s'],_0x21aabe['d']):_0x56927c==='apc'?this['onAppCheckRevoked_'](_0x21aabe['s'],_0x21aabe['d']):_0x56927c==='sd'?this['onSecurityDebugPacket_'](_0x21aabe):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x56927c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x47de1f,_0x2dccb6){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x47de1f),this['lastSessionId']=_0x2dccb6,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x58760f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x58760f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x64f29d){_0x64f29d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x64f29d;}['onOnline_'](_0x3bef89){_0x3bef89?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4606ec=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1db0bc=Math['max'](0x0,this['reconnectDelay_']-_0x4606ec);_0x1db0bc=Math['random']()*_0x1db0bc,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1db0bc+'ms'),this['scheduleConnect_'](_0x1db0bc),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4b1948=this['onDataMessage_']['bind'](this),_0x46084f=this['onReady_']['bind'](this),_0x28327d=this['onRealtimeDisconnect_']['bind'](this),_0x2a6908=this['id']+':'+se['nextConnectionId_']++,_0x1ca123=this['lastSessionId'];let _0x57a0e0=!0x1,_0x53d102=null;const _0x44748c=function(){_0x53d102?_0x53d102['close']():(_0x57a0e0=!0x0,_0x28327d());},_0x720787=function(_0x5d7f38){f(_0x53d102,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x53d102['sendRequest'](_0x5d7f38);};this['realtime_']={'close':_0x44748c,'sendRequest':_0x720787};const _0x6b35e5=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5a7b10,_0x45e7de]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x6b35e5),this['appCheckTokenProvider_']['getToken'](_0x6b35e5)]);_0x57a0e0?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5a7b10&&_0x5a7b10['accessToken'],this['appCheckToken_']=_0x45e7de&&_0x45e7de['token'],_0x53d102=new Sh(_0x2a6908,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4b1948,_0x46084f,_0x28327d,_0xad086e=>{U(_0xad086e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1ca123));}catch(_0xe7b94){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xe7b94),_0x57a0e0||(this['repoInfo_']['nodeAdmin']&&U(_0xe7b94),_0x44748c());}}}['interrupt'](_0x5d16f3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5d16f3),this['interruptReasons_'][_0x5d16f3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x33ed20){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x33ed20),delete this['interruptReasons_'][_0x33ed20],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x19a636){const _0x3aa4d7=_0x19a636-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3aa4d7});}['cancelSentTransactions_'](){for(let _0x4a5653=0x0;_0x4a5653<this['outstandingPuts_']['length'];_0x4a5653++){const _0x1ced60=this['outstandingPuts_'][_0x4a5653];_0x1ced60&&'h'in _0x1ced60['request']&&_0x1ced60['queued']&&(_0x1ced60['onComplete']&&_0x1ced60['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4a5653],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x35066b,_0x183d49){let _0x534c09;_0x183d49?_0x534c09=_0x183d49['map'](_0x32e7fe=>$i(_0x32e7fe))['join']('$'):_0x534c09='default';const _0x57af91=this['removeListen_'](_0x35066b,_0x534c09);_0x57af91&&_0x57af91['onComplete']&&_0x57af91['onComplete']('permission_denied');}['removeListen_'](_0x1fab28,_0x2feb48){const _0x37c40b=new C(_0x1fab28)['toString']();let _0x5e80b8;if(this['listens']['has'](_0x37c40b)){const _0x4e27de=this['listens']['get'](_0x37c40b);_0x5e80b8=_0x4e27de['get'](_0x2feb48),_0x4e27de['delete'](_0x2feb48),_0x4e27de['size']===0x0&&this['listens']['delete'](_0x37c40b);}else _0x5e80b8=void 0x0;return _0x5e80b8;}['onAuthRevoked_'](_0x19410b,_0x71933a){L('Auth\x20token\x20revoked:\x20'+_0x19410b+'/'+_0x71933a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x19410b==='invalid_token'||_0x19410b==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5454cd,_0x3215f1){L('App\x20check\x20token\x20revoked:\x20'+_0x5454cd+'/'+_0x3215f1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5454cd==='invalid_token'||_0x5454cd==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0xcdcd22){this['securityDebugCallback_']?this['securityDebugCallback_'](_0xcdcd22):'msg'in _0xcdcd22&&console['log']('FIREBASE:\x20'+_0xcdcd22['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5bd78e of this['listens']['values']())for(const _0x493e05 of _0x5bd78e['values']())this['sendListen_'](_0x493e05);for(let _0x2d21f9=0x0;_0x2d21f9<this['outstandingPuts_']['length'];_0x2d21f9++)this['outstandingPuts_'][_0x2d21f9]&&this['sendPut_'](_0x2d21f9);for(;this['onDisconnectRequestQueue_']['length'];){const _0x412186=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x412186['action'],_0x412186['pathString'],_0x412186['data'],_0x412186['onComplete']);}for(let _0x3b10f8=0x0;_0x3b10f8<this['outstandingGets_']['length'];_0x3b10f8++)this['outstandingGets_'][_0x3b10f8]&&this['sendGet_'](_0x3b10f8);}['sendConnectStats_'](){const _0x3d4221={};let _0x5669b8='js';_0x3d4221['sdk.'+_0x5669b8+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x3d4221['framework.cordova']=0x1:Kr()&&(_0x3d4221['framework.reactnative']=0x1),this['reportStats'](_0x3d4221);}['shouldReconnect_'](){const _0x3a15f3=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x3a15f3;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2e6ecf,_0x158047){this['name']=_0x2e6ecf,this['node']=_0x158047;}static['Wrap'](_0x33aeb4,_0x43bdc7){return new E(_0x33aeb4,_0x43bdc7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2d29fd,_0x5a8909){const _0x5e1391=new E(We,_0x2d29fd),_0x116c81=new E(We,_0x5a8909);return this['compare'](_0x5e1391,_0x116c81)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x733a3b){sn=_0x733a3b;}['compare'](_0x2dc453,_0x574a0c){return qe(_0x2dc453['name'],_0x574a0c['name']);}['isDefinedOn'](_0x328d3b){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x136c78,_0x166565){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x48f7ec,_0x467a66){return f(typeof _0x48f7ec=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x48f7ec,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x1dc5fa,_0x51c693,_0x3e3ffb,_0x2b5f48,_0x3ea88d=null){this['isReverse_']=_0x2b5f48,this['resultGenerator_']=_0x3ea88d,this['nodeStack_']=[];let _0x2cb9aa=0x1;for(;!_0x1dc5fa['isEmpty']();)if(_0x1dc5fa=_0x1dc5fa,_0x2cb9aa=_0x51c693?_0x3e3ffb(_0x1dc5fa['key'],_0x51c693):0x1,_0x2b5f48&&(_0x2cb9aa*=-0x1),_0x2cb9aa<0x0)this['isReverse_']?_0x1dc5fa=_0x1dc5fa['left']:_0x1dc5fa=_0x1dc5fa['right'];else{if(_0x2cb9aa===0x0){this['nodeStack_']['push'](_0x1dc5fa);break;}else this['nodeStack_']['push'](_0x1dc5fa),this['isReverse_']?_0x1dc5fa=_0x1dc5fa['right']:_0x1dc5fa=_0x1dc5fa['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2d1d2a=this['nodeStack_']['pop'](),_0x873ada;if(this['resultGenerator_']?_0x873ada=this['resultGenerator_'](_0x2d1d2a['key'],_0x2d1d2a['value']):_0x873ada={'key':_0x2d1d2a['key'],'value':_0x2d1d2a['value']},this['isReverse_']){for(_0x2d1d2a=_0x2d1d2a['left'];!_0x2d1d2a['isEmpty']();)this['nodeStack_']['push'](_0x2d1d2a),_0x2d1d2a=_0x2d1d2a['right'];}else{for(_0x2d1d2a=_0x2d1d2a['right'];!_0x2d1d2a['isEmpty']();)this['nodeStack_']['push'](_0x2d1d2a),_0x2d1d2a=_0x2d1d2a['left'];}return _0x873ada;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x51a599=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x51a599['key'],_0x51a599['value']):{'key':_0x51a599['key'],'value':_0x51a599['value']};}}class M{constructor(_0x4d0eb4,_0x59a6a3,_0x43460d,_0x22424c,_0x53bf3b){this['key']=_0x4d0eb4,this['value']=_0x59a6a3,this['color']=_0x43460d??M['RED'],this['left']=_0x22424c??B['EMPTY_NODE'],this['right']=_0x53bf3b??B['EMPTY_NODE'];}['copy'](_0x39a390,_0x4e90c0,_0x5cb397,_0x3736ac,_0x3565bc){return new M(_0x39a390??this['key'],_0x4e90c0??this['value'],_0x5cb397??this['color'],_0x3736ac??this['left'],_0x3565bc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2536d9){return this['left']['inorderTraversal'](_0x2536d9)||!!_0x2536d9(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2536d9);}['reverseTraversal'](_0x235efe){return this['right']['reverseTraversal'](_0x235efe)||_0x235efe(this['key'],this['value'])||this['left']['reverseTraversal'](_0x235efe);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4611ee,_0x1fb9c6,_0x2dd193){let _0x46f2e4=this;const _0x28e4d8=_0x2dd193(_0x4611ee,_0x46f2e4['key']);return _0x28e4d8<0x0?_0x46f2e4=_0x46f2e4['copy'](null,null,null,_0x46f2e4['left']['insert'](_0x4611ee,_0x1fb9c6,_0x2dd193),null):_0x28e4d8===0x0?_0x46f2e4=_0x46f2e4['copy'](null,_0x1fb9c6,null,null,null):_0x46f2e4=_0x46f2e4['copy'](null,null,null,null,_0x46f2e4['right']['insert'](_0x4611ee,_0x1fb9c6,_0x2dd193)),_0x46f2e4['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x98a2c4=this;return!_0x98a2c4['left']['isRed_']()&&!_0x98a2c4['left']['left']['isRed_']()&&(_0x98a2c4=_0x98a2c4['moveRedLeft_']()),_0x98a2c4=_0x98a2c4['copy'](null,null,null,_0x98a2c4['left']['removeMin_'](),null),_0x98a2c4['fixUp_']();}['remove'](_0x16fe4e,_0x2d8390){let _0x30b7aa,_0x3d1449;if(_0x30b7aa=this,_0x2d8390(_0x16fe4e,_0x30b7aa['key'])<0x0)!_0x30b7aa['left']['isEmpty']()&&!_0x30b7aa['left']['isRed_']()&&!_0x30b7aa['left']['left']['isRed_']()&&(_0x30b7aa=_0x30b7aa['moveRedLeft_']()),_0x30b7aa=_0x30b7aa['copy'](null,null,null,_0x30b7aa['left']['remove'](_0x16fe4e,_0x2d8390),null);else{if(_0x30b7aa['left']['isRed_']()&&(_0x30b7aa=_0x30b7aa['rotateRight_']()),!_0x30b7aa['right']['isEmpty']()&&!_0x30b7aa['right']['isRed_']()&&!_0x30b7aa['right']['left']['isRed_']()&&(_0x30b7aa=_0x30b7aa['moveRedRight_']()),_0x2d8390(_0x16fe4e,_0x30b7aa['key'])===0x0){if(_0x30b7aa['right']['isEmpty']())return B['EMPTY_NODE'];_0x3d1449=_0x30b7aa['right']['min_'](),_0x30b7aa=_0x30b7aa['copy'](_0x3d1449['key'],_0x3d1449['value'],null,null,_0x30b7aa['right']['removeMin_']());}_0x30b7aa=_0x30b7aa['copy'](null,null,null,null,_0x30b7aa['right']['remove'](_0x16fe4e,_0x2d8390));}return _0x30b7aa['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x62ef4c=this;return _0x62ef4c['right']['isRed_']()&&!_0x62ef4c['left']['isRed_']()&&(_0x62ef4c=_0x62ef4c['rotateLeft_']()),_0x62ef4c['left']['isRed_']()&&_0x62ef4c['left']['left']['isRed_']()&&(_0x62ef4c=_0x62ef4c['rotateRight_']()),_0x62ef4c['left']['isRed_']()&&_0x62ef4c['right']['isRed_']()&&(_0x62ef4c=_0x62ef4c['colorFlip_']()),_0x62ef4c;}['moveRedLeft_'](){let _0x49398f=this['colorFlip_']();return _0x49398f['right']['left']['isRed_']()&&(_0x49398f=_0x49398f['copy'](null,null,null,null,_0x49398f['right']['rotateRight_']()),_0x49398f=_0x49398f['rotateLeft_'](),_0x49398f=_0x49398f['colorFlip_']()),_0x49398f;}['moveRedRight_'](){let _0x57e14d=this['colorFlip_']();return _0x57e14d['left']['left']['isRed_']()&&(_0x57e14d=_0x57e14d['rotateRight_'](),_0x57e14d=_0x57e14d['colorFlip_']()),_0x57e14d;}['rotateLeft_'](){const _0x54c592=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x54c592,null);}['rotateRight_'](){const _0x4189f9=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4189f9);}['colorFlip_'](){const _0x5bcd81=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xbb7739=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5bcd81,_0xbb7739);}['checkMaxDepth_'](){const _0x451891=this['check_']();return Math['pow'](0x2,_0x451891)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1f73b9=this['left']['check_']();if(_0x1f73b9!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1f73b9+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1c8880,_0x2bc569,_0x14b89c,_0x5e7d23,_0x1f3047){return this;}['insert'](_0x1a3205,_0x37da68,_0xe71a02){return new M(_0x1a3205,_0x37da68,null);}['remove'](_0x2e0f07,_0x338f87){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x47e963){return!0x1;}['reverseTraversal'](_0x408e10){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x44307a,_0x2ee59a=B['EMPTY_NODE']){this['comparator_']=_0x44307a,this['root_']=_0x2ee59a;}['insert'](_0x3989f2,_0x54852d){return new B(this['comparator_'],this['root_']['insert'](_0x3989f2,_0x54852d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5c32c8){return new B(this['comparator_'],this['root_']['remove'](_0x5c32c8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x594f2){let _0x2bb331,_0x400bb2=this['root_'];for(;!_0x400bb2['isEmpty']();){if(_0x2bb331=this['comparator_'](_0x594f2,_0x400bb2['key']),_0x2bb331===0x0)return _0x400bb2['value'];_0x2bb331<0x0?_0x400bb2=_0x400bb2['left']:_0x2bb331>0x0&&(_0x400bb2=_0x400bb2['right']);}return null;}['getPredecessorKey'](_0x5e5968){let _0x18401a,_0x654b20=this['root_'],_0xb938b8=null;for(;!_0x654b20['isEmpty']();)if(_0x18401a=this['comparator_'](_0x5e5968,_0x654b20['key']),_0x18401a===0x0){if(_0x654b20['left']['isEmpty']())return _0xb938b8?_0xb938b8['key']:null;for(_0x654b20=_0x654b20['left'];!_0x654b20['right']['isEmpty']();)_0x654b20=_0x654b20['right'];return _0x654b20['key'];}else _0x18401a<0x0?_0x654b20=_0x654b20['left']:_0x18401a>0x0&&(_0xb938b8=_0x654b20,_0x654b20=_0x654b20['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2a30cc){return this['root_']['inorderTraversal'](_0x2a30cc);}['reverseTraversal'](_0x19f755){return this['root_']['reverseTraversal'](_0x19f755);}['getIterator'](_0x1caab3){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x1caab3);}['getIteratorFrom'](_0x9f09c,_0x58530a){return new rn(this['root_'],_0x9f09c,this['comparator_'],!0x1,_0x58530a);}['getReverseIteratorFrom'](_0x2bdb89,_0x46f2f4){return new rn(this['root_'],_0x2bdb89,this['comparator_'],!0x0,_0x46f2f4);}['getReverseIterator'](_0x27f358){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x27f358);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x59cedd,_0x13dedd){return qe(_0x59cedd['name'],_0x13dedd['name']);}function Qi(_0x149a7f,_0x45035e){return qe(_0x149a7f,_0x45035e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x53f022){Ci=_0x53f022;}const Po=function(_0xaa18d0){return typeof _0xaa18d0=='number'?'number:'+ao(_0xaa18d0):'string:'+_0xaa18d0;},No=function(_0x5ac660){if(_0x5ac660['isLeafNode']()){const _0x885f36=_0x5ac660['val']();f(typeof _0x885f36=='string'||typeof _0x885f36=='number'||typeof _0x885f36=='object'&&Q(_0x885f36,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5ac660===Ci||_0x5ac660['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5ac660===Ci||_0x5ac660['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x3ec3ce){nr=_0x3ec3ce;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x919904,_0x27f401=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x919904,this['priorityNode_']=_0x27f401,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4a6f2b){return new D(this['value_'],_0x4a6f2b);}['getImmediateChild'](_0x3cda5b){return _0x3cda5b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4e2c83){return v(_0x4e2c83)?this:y(_0x4e2c83)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x54b117,_0x1d7d57){return null;}['updateImmediateChild'](_0x33df32,_0x32128c){return _0x33df32==='.priority'?this['updatePriority'](_0x32128c):_0x32128c['isEmpty']()&&_0x33df32!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x33df32,_0x32128c)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4cff1f,_0x5d8b0d){const _0x204c1b=y(_0x4cff1f);return _0x204c1b===null?_0x5d8b0d:_0x5d8b0d['isEmpty']()&&_0x204c1b!=='.priority'?this:(f(_0x204c1b!=='.priority'||Ce(_0x4cff1f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x204c1b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x4cff1f),_0x5d8b0d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x14ea80,_0x14a618){return!0x1;}['val'](_0x47c501){return _0x47c501&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5f0333='';this['priorityNode_']['isEmpty']()||(_0x5f0333+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x28476b=typeof this['value_'];_0x5f0333+=_0x28476b+':',_0x28476b==='number'?_0x5f0333+=ao(this['value_']):_0x5f0333+=this['value_'],this['lazyHash_']=ro(_0x5f0333);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3ee205){return _0x3ee205===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3ee205 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3ee205['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3ee205));}['compareToLeafNode_'](_0x1d9a77){const _0x58b075=typeof _0x1d9a77['value_'],_0xe3de57=typeof this['value_'],_0x24a8ed=D['VALUE_TYPE_ORDER']['indexOf'](_0x58b075),_0x1cb530=D['VALUE_TYPE_ORDER']['indexOf'](_0xe3de57);return f(_0x24a8ed>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x58b075),f(_0x1cb530>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xe3de57),_0x24a8ed===_0x1cb530?_0xe3de57==='object'?0x0:this['value_']<_0x1d9a77['value_']?-0x1:this['value_']===_0x1d9a77['value_']?0x0:0x1:_0x1cb530-_0x24a8ed;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5d7ca9){if(_0x5d7ca9===this)return!0x0;if(_0x5d7ca9['isLeafNode']()){const _0x5ea932=_0x5d7ca9;return this['value_']===_0x5ea932['value_']&&this['priorityNode_']['equals'](_0x5ea932['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x31ecc6){Oo=_0x31ecc6;}function Wh(_0x2f274c){Do=_0x2f274c;}class Bh extends Fn{['compare'](_0x99d7a0,_0xb8c621){const _0x29ea55=_0x99d7a0['node']['getPriority'](),_0x33bbe8=_0xb8c621['node']['getPriority'](),_0x4e12f8=_0x29ea55['compareTo'](_0x33bbe8);return _0x4e12f8===0x0?qe(_0x99d7a0['name'],_0xb8c621['name']):_0x4e12f8;}['isDefinedOn'](_0x1113b6){return!_0x1113b6['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2b74f9,_0x3ccb06){return!_0x2b74f9['getPriority']()['equals'](_0x3ccb06['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x310f46,_0x2aa5ce){const _0x5e1eed=Oo(_0x310f46);return new E(_0x2aa5ce,new D('[PRIORITY-POST]',_0x5e1eed));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1f9044){const _0x33de05=_0x1fac3e=>parseInt(Math['log'](_0x1fac3e)/Vh,0xa),_0x435642=_0x4bf6bd=>parseInt(Array(_0x4bf6bd+0x1)['join']('1'),0x2);this['count']=_0x33de05(_0x1f9044+0x1),this['current_']=this['count']-0x1;const _0x581e44=_0x435642(this['count']);this['bits_']=_0x1f9044+0x1&_0x581e44;}['nextBitIsOne'](){const _0x2448f5=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2448f5;}}const yn=function(_0x2cf561,_0x5e0684,_0x410e79,_0x20fcf8){_0x2cf561['sort'](_0x5e0684);const _0x29bca1=function(_0x448ae3,_0x5805c0){const _0x4b65a4=_0x5805c0-_0x448ae3;let _0x5727a2,_0x1a514e;if(_0x4b65a4===0x0)return null;if(_0x4b65a4===0x1)return _0x5727a2=_0x2cf561[_0x448ae3],_0x1a514e=_0x410e79?_0x410e79(_0x5727a2):_0x5727a2,new M(_0x1a514e,_0x5727a2['node'],M['BLACK'],null,null);{const _0x2705c9=parseInt(_0x4b65a4/0x2,0xa)+_0x448ae3,_0x4f4554=_0x29bca1(_0x448ae3,_0x2705c9),_0x520dd7=_0x29bca1(_0x2705c9+0x1,_0x5805c0);return _0x5727a2=_0x2cf561[_0x2705c9],_0x1a514e=_0x410e79?_0x410e79(_0x5727a2):_0x5727a2,new M(_0x1a514e,_0x5727a2['node'],M['BLACK'],_0x4f4554,_0x520dd7);}},_0x55a699=function(_0x424e92){let _0x409326=null,_0x591b41=null,_0x28de64=_0x2cf561['length'];const _0x163a32=function(_0x491962,_0x291f4e){const _0x2d7b36=_0x28de64-_0x491962,_0x4e8960=_0x28de64;_0x28de64-=_0x491962;const _0x35ee18=_0x29bca1(_0x2d7b36+0x1,_0x4e8960),_0x819eb5=_0x2cf561[_0x2d7b36],_0x2305eb=_0x410e79?_0x410e79(_0x819eb5):_0x819eb5;_0x103ba2(new M(_0x2305eb,_0x819eb5['node'],_0x291f4e,null,_0x35ee18));},_0x103ba2=function(_0x55a3d7){_0x409326?(_0x409326['left']=_0x55a3d7,_0x409326=_0x55a3d7):(_0x591b41=_0x55a3d7,_0x409326=_0x55a3d7);};for(let _0x5d4581=0x0;_0x5d4581<_0x424e92['count'];++_0x5d4581){const _0x2fa2c1=_0x424e92['nextBitIsOne'](),_0x19d7a0=Math['pow'](0x2,_0x424e92['count']-(_0x5d4581+0x1));_0x2fa2c1?_0x163a32(_0x19d7a0,M['BLACK']):(_0x163a32(_0x19d7a0,M['BLACK']),_0x163a32(_0x19d7a0,M['RED']));}return _0x591b41;},_0x399579=new Hh(_0x2cf561['length']),_0x1078f2=_0x55a699(_0x399579);return new B(_0x20fcf8||_0x5e0684,_0x1078f2);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x469213,_0xcd3570){this['indexes_']=_0x469213,this['indexSet_']=_0xcd3570;}['get'](_0x847db6){const _0x445757=Le(this['indexes_'],_0x847db6);if(!_0x445757)throw new Error('No\x20index\x20defined\x20for\x20'+_0x847db6);return _0x445757 instanceof B?_0x445757:null;}['hasIndex'](_0x516aec){return Q(this['indexSet_'],_0x516aec['toString']());}['addIndex'](_0x5e1e24,_0x20f87b){f(_0x5e1e24!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xc39f85=[];let _0x22b5d5=!0x1;const _0xe97e79=_0x20f87b['getIterator'](E['Wrap']);let _0x28ac97=_0xe97e79['getNext']();for(;_0x28ac97;)_0x22b5d5=_0x22b5d5||_0x5e1e24['isDefinedOn'](_0x28ac97['node']),_0xc39f85['push'](_0x28ac97),_0x28ac97=_0xe97e79['getNext']();let _0x5470ff;_0x22b5d5?_0x5470ff=yn(_0xc39f85,_0x5e1e24['getCompare']()):_0x5470ff=Qe;const _0x46ec30=_0x5e1e24['toString'](),_0x49e5a5={...this['indexSet_']};_0x49e5a5[_0x46ec30]=_0x5e1e24;const _0x482d5c={...this['indexes_']};return _0x482d5c[_0x46ec30]=_0x5470ff,new te(_0x482d5c,_0x49e5a5);}['addToIndexes'](_0x490f47,_0x825f88){const _0x2e436b=_n(this['indexes_'],(_0x3f310b,_0x596e21)=>{const _0x12b0e7=Le(this['indexSet_'],_0x596e21);if(f(_0x12b0e7,'Missing\x20index\x20implementation\x20for\x20'+_0x596e21),_0x3f310b===Qe){if(_0x12b0e7['isDefinedOn'](_0x490f47['node'])){const _0x14a6f3=[],_0x4f2b6e=_0x825f88['getIterator'](E['Wrap']);let _0x2d493b=_0x4f2b6e['getNext']();for(;_0x2d493b;)_0x2d493b['name']!==_0x490f47['name']&&_0x14a6f3['push'](_0x2d493b),_0x2d493b=_0x4f2b6e['getNext']();return _0x14a6f3['push'](_0x490f47),yn(_0x14a6f3,_0x12b0e7['getCompare']());}else return Qe;}else{const _0xe50c0=_0x825f88['get'](_0x490f47['name']);let _0x39b79=_0x3f310b;return _0xe50c0&&(_0x39b79=_0x39b79['remove'](new E(_0x490f47['name'],_0xe50c0))),_0x39b79['insert'](_0x490f47,_0x490f47['node']);}});return new te(_0x2e436b,this['indexSet_']);}['removeFromIndexes'](_0x2c7c08,_0x17ae15){const _0x41c44c=_n(this['indexes_'],_0x3fef1d=>{if(_0x3fef1d===Qe)return _0x3fef1d;{const _0x270d0a=_0x17ae15['get'](_0x2c7c08['name']);return _0x270d0a?_0x3fef1d['remove'](new E(_0x2c7c08['name'],_0x270d0a)):_0x3fef1d;}});return new te(_0x41c44c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x3efce7,_0x348ccc,_0xf57852){this['children_']=_0x3efce7,this['priorityNode_']=_0x348ccc,this['indexMap_']=_0xf57852,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x388af4){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x388af4,this['indexMap_']);}['getImmediateChild'](_0x116ebd){if(_0x116ebd==='.priority')return this['getPriority']();{const _0x318156=this['children_']['get'](_0x116ebd);return _0x318156===null?It:_0x318156;}}['getChild'](_0x18fe80){const _0x3f80ec=y(_0x18fe80);return _0x3f80ec===null?this:this['getImmediateChild'](_0x3f80ec)['getChild'](S(_0x18fe80));}['hasChild'](_0x4b9c11){return this['children_']['get'](_0x4b9c11)!==null;}['updateImmediateChild'](_0x57f305,_0x54e133){if(f(_0x54e133,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x57f305==='.priority')return this['updatePriority'](_0x54e133);{const _0x3b68cd=new E(_0x57f305,_0x54e133);let _0xee6947,_0x5c37c0;_0x54e133['isEmpty']()?(_0xee6947=this['children_']['remove'](_0x57f305),_0x5c37c0=this['indexMap_']['removeFromIndexes'](_0x3b68cd,this['children_'])):(_0xee6947=this['children_']['insert'](_0x57f305,_0x54e133),_0x5c37c0=this['indexMap_']['addToIndexes'](_0x3b68cd,this['children_']));const _0x18391c=_0xee6947['isEmpty']()?It:this['priorityNode_'];return new g(_0xee6947,_0x18391c,_0x5c37c0);}}['updateChild'](_0x4c09b4,_0x476b16){const _0x9dea90=y(_0x4c09b4);if(_0x9dea90===null)return _0x476b16;{f(y(_0x4c09b4)!=='.priority'||Ce(_0x4c09b4)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x51e9d8=this['getImmediateChild'](_0x9dea90)['updateChild'](S(_0x4c09b4),_0x476b16);return this['updateImmediateChild'](_0x9dea90,_0x51e9d8);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x13053e){if(this['isEmpty']())return null;const _0x5dc0c8={};let _0x368141=0x0,_0x1cad5e=0x0,_0x3c76e3=!0x0;if(this['forEachChild'](R,(_0x10b2ec,_0x4af71b)=>{_0x5dc0c8[_0x10b2ec]=_0x4af71b['val'](_0x13053e),_0x368141++,_0x3c76e3&&g['INTEGER_REGEXP_']['test'](_0x10b2ec)?_0x1cad5e=Math['max'](_0x1cad5e,Number(_0x10b2ec)):_0x3c76e3=!0x1;}),!_0x13053e&&_0x3c76e3&&_0x1cad5e<0x2*_0x368141){const _0x22ffdb=[];for(const _0x587e2c in _0x5dc0c8)_0x22ffdb[_0x587e2c]=_0x5dc0c8[_0x587e2c];return _0x22ffdb;}else return _0x13053e&&!this['getPriority']()['isEmpty']()&&(_0x5dc0c8['.priority']=this['getPriority']()['val']()),_0x5dc0c8;}['hash'](){if(this['lazyHash_']===null){let _0x3d7ab5='';this['getPriority']()['isEmpty']()||(_0x3d7ab5+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x21d4b7,_0x425ff7)=>{const _0x428e38=_0x425ff7['hash']();_0x428e38!==''&&(_0x3d7ab5+=':'+_0x21d4b7+':'+_0x428e38);}),this['lazyHash_']=_0x3d7ab5===''?'':ro(_0x3d7ab5);}return this['lazyHash_'];}['getPredecessorChildName'](_0x49fdec,_0x35c6aa,_0x4b42b7){const _0x3d3f18=this['resolveIndex_'](_0x4b42b7);if(_0x3d3f18){const _0x158b87=_0x3d3f18['getPredecessorKey'](new E(_0x49fdec,_0x35c6aa));return _0x158b87?_0x158b87['name']:null;}else return this['children_']['getPredecessorKey'](_0x49fdec);}['getFirstChildName'](_0x2cd71a){const _0x59b503=this['resolveIndex_'](_0x2cd71a);if(_0x59b503){const _0x5bc927=_0x59b503['minKey']();return _0x5bc927&&_0x5bc927['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5bf76e){const _0x233fe6=this['getFirstChildName'](_0x5bf76e);return _0x233fe6?new E(_0x233fe6,this['children_']['get'](_0x233fe6)):null;}['getLastChildName'](_0x5c05c7){const _0x1ac772=this['resolveIndex_'](_0x5c05c7);if(_0x1ac772){const _0x534e7e=_0x1ac772['maxKey']();return _0x534e7e&&_0x534e7e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4b441b){const _0x4bd3ea=this['getLastChildName'](_0x4b441b);return _0x4bd3ea?new E(_0x4bd3ea,this['children_']['get'](_0x4bd3ea)):null;}['forEachChild'](_0x2b786e,_0x50b662){const _0x1b0453=this['resolveIndex_'](_0x2b786e);return _0x1b0453?_0x1b0453['inorderTraversal'](_0x2ffc2a=>_0x50b662(_0x2ffc2a['name'],_0x2ffc2a['node'])):this['children_']['inorderTraversal'](_0x50b662);}['getIterator'](_0x28d909){return this['getIteratorFrom'](_0x28d909['minPost'](),_0x28d909);}['getIteratorFrom'](_0x44d22d,_0x15ef5e){const _0x11ff11=this['resolveIndex_'](_0x15ef5e);if(_0x11ff11)return _0x11ff11['getIteratorFrom'](_0x44d22d,_0x22372f=>_0x22372f);{const _0x3e28df=this['children_']['getIteratorFrom'](_0x44d22d['name'],E['Wrap']);let _0x1d7d29=_0x3e28df['peek']();for(;_0x1d7d29!=null&&_0x15ef5e['compare'](_0x1d7d29,_0x44d22d)<0x0;)_0x3e28df['getNext'](),_0x1d7d29=_0x3e28df['peek']();return _0x3e28df;}}['getReverseIterator'](_0x9e7107){return this['getReverseIteratorFrom'](_0x9e7107['maxPost'](),_0x9e7107);}['getReverseIteratorFrom'](_0x150088,_0x361e08){const _0x942e0d=this['resolveIndex_'](_0x361e08);if(_0x942e0d)return _0x942e0d['getReverseIteratorFrom'](_0x150088,_0x51ed29=>_0x51ed29);{const _0x1c0d6e=this['children_']['getReverseIteratorFrom'](_0x150088['name'],E['Wrap']);let _0x235211=_0x1c0d6e['peek']();for(;_0x235211!=null&&_0x361e08['compare'](_0x235211,_0x150088)>0x0;)_0x1c0d6e['getNext'](),_0x235211=_0x1c0d6e['peek']();return _0x1c0d6e;}}['compareTo'](_0x2f7d31){return this['isEmpty']()?_0x2f7d31['isEmpty']()?0x0:-0x1:_0x2f7d31['isLeafNode']()||_0x2f7d31['isEmpty']()?0x1:_0x2f7d31===Kt?-0x1:0x0;}['withIndex'](_0x566f1e){if(_0x566f1e===ve||this['indexMap_']['hasIndex'](_0x566f1e))return this;{const _0x3857c4=this['indexMap_']['addIndex'](_0x566f1e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3857c4);}}['isIndexed'](_0x160160){return _0x160160===ve||this['indexMap_']['hasIndex'](_0x160160);}['equals'](_0x4486f0){if(_0x4486f0===this)return!0x0;if(_0x4486f0['isLeafNode']())return!0x1;{const _0x3cf3a0=_0x4486f0;if(this['getPriority']()['equals'](_0x3cf3a0['getPriority']())){if(this['children_']['count']()===_0x3cf3a0['children_']['count']()){const _0x55e4ac=this['getIterator'](R),_0x5abb1f=_0x3cf3a0['getIterator'](R);let _0xa85caa=_0x55e4ac['getNext'](),_0x24c3c5=_0x5abb1f['getNext']();for(;_0xa85caa&&_0x24c3c5;){if(_0xa85caa['name']!==_0x24c3c5['name']||!_0xa85caa['node']['equals'](_0x24c3c5['node']))return!0x1;_0xa85caa=_0x55e4ac['getNext'](),_0x24c3c5=_0x5abb1f['getNext']();}return _0xa85caa===null&&_0x24c3c5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5856ff){return _0x5856ff===ve?null:this['indexMap_']['get'](_0x5856ff['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x507ca9){return _0x507ca9===this?0x0:0x1;}['equals'](_0x2df293){return _0x2df293===this;}['getPriority'](){return this;}['getImmediateChild'](_0x7ab4e0){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3e6091,_0x2853b3=null){if(_0x3e6091===null)return g['EMPTY_NODE'];if(typeof _0x3e6091=='object'&&'.priority'in _0x3e6091&&(_0x2853b3=_0x3e6091['.priority']),f(_0x2853b3===null||typeof _0x2853b3=='string'||typeof _0x2853b3=='number'||typeof _0x2853b3=='object'&&'.sv'in _0x2853b3,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2853b3),typeof _0x3e6091=='object'&&'.value'in _0x3e6091&&_0x3e6091['.value']!==null&&(_0x3e6091=_0x3e6091['.value']),typeof _0x3e6091!='object'||'.sv'in _0x3e6091){const _0x5615cb=_0x3e6091;return new D(_0x5615cb,A(_0x2853b3));}if(!(_0x3e6091 instanceof Array)&&Gh){const _0xb093a2=[];let _0x3f5cba=!0x1;if(x(_0x3e6091,(_0x46dacd,_0x451582)=>{if(_0x46dacd['substring'](0x0,0x1)!=='.'){const _0x421d40=A(_0x451582);_0x421d40['isEmpty']()||(_0x3f5cba=_0x3f5cba||!_0x421d40['getPriority']()['isEmpty'](),_0xb093a2['push'](new E(_0x46dacd,_0x421d40)));}}),_0xb093a2['length']===0x0)return g['EMPTY_NODE'];const _0x1fff69=yn(_0xb093a2,xh,_0x4321dc=>_0x4321dc['name'],Qi);if(_0x3f5cba){const _0x45d9f6=yn(_0xb093a2,R['getCompare']());return new g(_0x1fff69,A(_0x2853b3),new te({'.priority':_0x45d9f6},{'.priority':R}));}else return new g(_0x1fff69,A(_0x2853b3),te['Default']);}else{let _0x58b86d=g['EMPTY_NODE'];return x(_0x3e6091,(_0x4f8b64,_0x108277)=>{if(Q(_0x3e6091,_0x4f8b64)&&_0x4f8b64['substring'](0x0,0x1)!=='.'){const _0x1e00ef=A(_0x108277);(_0x1e00ef['isLeafNode']()||!_0x1e00ef['isEmpty']())&&(_0x58b86d=_0x58b86d['updateImmediateChild'](_0x4f8b64,_0x1e00ef));}}),_0x58b86d['updatePriority'](A(_0x2853b3));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x283113){super(),this['indexPath_']=_0x283113,f(!v(_0x283113)&&y(_0x283113)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3cd417){return _0x3cd417['getChild'](this['indexPath_']);}['isDefinedOn'](_0x444ae8){return!_0x444ae8['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2c5206,_0x17400a){const _0x41a5f2=this['extractChild'](_0x2c5206['node']),_0x421696=this['extractChild'](_0x17400a['node']),_0x1bb628=_0x41a5f2['compareTo'](_0x421696);return _0x1bb628===0x0?qe(_0x2c5206['name'],_0x17400a['name']):_0x1bb628;}['makePost'](_0x1eba9c,_0x40be5d){const _0x4c57b1=A(_0x1eba9c),_0x3eb362=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4c57b1);return new E(_0x40be5d,_0x3eb362);}['maxPost'](){const _0x2b2f25=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x2b2f25);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x23cc2a,_0x3812fb){const _0x4961b5=_0x23cc2a['node']['compareTo'](_0x3812fb['node']);return _0x4961b5===0x0?qe(_0x23cc2a['name'],_0x3812fb['name']):_0x4961b5;}['isDefinedOn'](_0x168b39){return!0x0;}['indexedValueChanged'](_0x41e084,_0x4c2589){return!_0x41e084['equals'](_0x4c2589);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4f1a2e,_0x23d150){const _0x37ee15=A(_0x4f1a2e);return new E(_0x23d150,_0x37ee15);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x429d85){return{'type':'value','snapshotNode':_0x429d85};}function rt(_0xcc3cc7,_0x52bfe6){return{'type':'child_added','snapshotNode':_0x52bfe6,'childName':_0xcc3cc7};}function Lt(_0x503e26,_0x5b1c11){return{'type':'child_removed','snapshotNode':_0x5b1c11,'childName':_0x503e26};}function xt(_0x45d9d4,_0x343f33,_0x43984e){return{'type':'child_changed','snapshotNode':_0x343f33,'childName':_0x45d9d4,'oldSnap':_0x43984e};}function zh(_0x4bfea6,_0x581c09){return{'type':'child_moved','snapshotNode':_0x581c09,'childName':_0x4bfea6};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1d1888){this['index_']=_0x1d1888;}['updateChild'](_0x2d555b,_0x4f412c,_0x2fc8bb,_0x31cffe,_0xee75c6,_0x3b7225){f(_0x2d555b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x57c968=_0x2d555b['getImmediateChild'](_0x4f412c);return _0x57c968['getChild'](_0x31cffe)['equals'](_0x2fc8bb['getChild'](_0x31cffe))&&_0x57c968['isEmpty']()===_0x2fc8bb['isEmpty']()||(_0x3b7225!=null&&(_0x2fc8bb['isEmpty']()?_0x2d555b['hasChild'](_0x4f412c)?_0x3b7225['trackChildChange'](Lt(_0x4f412c,_0x57c968)):f(_0x2d555b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x57c968['isEmpty']()?_0x3b7225['trackChildChange'](rt(_0x4f412c,_0x2fc8bb)):_0x3b7225['trackChildChange'](xt(_0x4f412c,_0x2fc8bb,_0x57c968))),_0x2d555b['isLeafNode']()&&_0x2fc8bb['isEmpty']())?_0x2d555b:_0x2d555b['updateImmediateChild'](_0x4f412c,_0x2fc8bb)['withIndex'](this['index_']);}['updateFullNode'](_0x51a54c,_0x4400ad,_0x2148cf){return _0x2148cf!=null&&(_0x51a54c['isLeafNode']()||_0x51a54c['forEachChild'](R,(_0x2f62a7,_0xcef2e)=>{_0x4400ad['hasChild'](_0x2f62a7)||_0x2148cf['trackChildChange'](Lt(_0x2f62a7,_0xcef2e));}),_0x4400ad['isLeafNode']()||_0x4400ad['forEachChild'](R,(_0x147f49,_0x3e425e)=>{if(_0x51a54c['hasChild'](_0x147f49)){const _0x4f3fd4=_0x51a54c['getImmediateChild'](_0x147f49);_0x4f3fd4['equals'](_0x3e425e)||_0x2148cf['trackChildChange'](xt(_0x147f49,_0x3e425e,_0x4f3fd4));}else _0x2148cf['trackChildChange'](rt(_0x147f49,_0x3e425e));})),_0x4400ad['withIndex'](this['index_']);}['updatePriority'](_0x33a761,_0x2bdc91){return _0x33a761['isEmpty']()?g['EMPTY_NODE']:_0x33a761['updatePriority'](_0x2bdc91);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x45553e){this['indexedFilter_']=new Xi(_0x45553e['getIndex']()),this['index_']=_0x45553e['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x45553e),this['endPost_']=Ft['getEndPost_'](_0x45553e),this['startIsInclusive_']=!_0x45553e['startAfterSet_'],this['endIsInclusive_']=!_0x45553e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1fc926){const _0x46ab14=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1fc926)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1fc926)<0x0,_0x27cc4a=this['endIsInclusive_']?this['index_']['compare'](_0x1fc926,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1fc926,this['getEndPost']())<0x0;return _0x46ab14&&_0x27cc4a;}['updateChild'](_0xe36165,_0xd05c26,_0x17a56d,_0x2d4eba,_0x5cdbb8,_0x36c0e3){return this['matches'](new E(_0xd05c26,_0x17a56d))||(_0x17a56d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xe36165,_0xd05c26,_0x17a56d,_0x2d4eba,_0x5cdbb8,_0x36c0e3);}['updateFullNode'](_0x32e54b,_0x413af5,_0x1e5908){_0x413af5['isLeafNode']()&&(_0x413af5=g['EMPTY_NODE']);let _0x5aa0f5=_0x413af5['withIndex'](this['index_']);_0x5aa0f5=_0x5aa0f5['updatePriority'](g['EMPTY_NODE']);const _0x4fe5d3=this;return _0x413af5['forEachChild'](R,(_0x22ecdc,_0x40b826)=>{_0x4fe5d3['matches'](new E(_0x22ecdc,_0x40b826))||(_0x5aa0f5=_0x5aa0f5['updateImmediateChild'](_0x22ecdc,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x32e54b,_0x5aa0f5,_0x1e5908);}['updatePriority'](_0x5f2a86,_0x598052){return _0x5f2a86;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x302bd7){if(_0x302bd7['hasStart']()){const _0x581040=_0x302bd7['getIndexStartName']();return _0x302bd7['getIndex']()['makePost'](_0x302bd7['getIndexStartValue'](),_0x581040);}else return _0x302bd7['getIndex']()['minPost']();}static['getEndPost_'](_0x1c035a){if(_0x1c035a['hasEnd']()){const _0x43ef15=_0x1c035a['getIndexEndName']();return _0x1c035a['getIndex']()['makePost'](_0x1c035a['getIndexEndValue'](),_0x43ef15);}else return _0x1c035a['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2306cc){this['withinDirectionalStart']=_0x3a6dde=>this['reverse_']?this['withinEndPost'](_0x3a6dde):this['withinStartPost'](_0x3a6dde),this['withinDirectionalEnd']=_0x41e5c6=>this['reverse_']?this['withinStartPost'](_0x41e5c6):this['withinEndPost'](_0x41e5c6),this['withinStartPost']=_0x10c210=>{const _0x1f3e2f=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x10c210);return this['startIsInclusive_']?_0x1f3e2f<=0x0:_0x1f3e2f<0x0;},this['withinEndPost']=_0x425157=>{const _0x124365=this['index_']['compare'](_0x425157,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x124365<=0x0:_0x124365<0x0;},this['rangedFilter_']=new Ft(_0x2306cc),this['index_']=_0x2306cc['getIndex'](),this['limit_']=_0x2306cc['getLimit'](),this['reverse_']=!_0x2306cc['isViewFromLeft'](),this['startIsInclusive_']=!_0x2306cc['startAfterSet_'],this['endIsInclusive_']=!_0x2306cc['endBeforeSet_'];}['updateChild'](_0x2796dd,_0x84295e,_0x3af0b1,_0x9aba5f,_0x1115fc,_0x52dc92){return this['rangedFilter_']['matches'](new E(_0x84295e,_0x3af0b1))||(_0x3af0b1=g['EMPTY_NODE']),_0x2796dd['getImmediateChild'](_0x84295e)['equals'](_0x3af0b1)?_0x2796dd:_0x2796dd['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2796dd,_0x84295e,_0x3af0b1,_0x9aba5f,_0x1115fc,_0x52dc92):this['fullLimitUpdateChild_'](_0x2796dd,_0x84295e,_0x3af0b1,_0x1115fc,_0x52dc92);}['updateFullNode'](_0x106b5a,_0x157d29,_0x311ed4){let _0x59f99e;if(_0x157d29['isLeafNode']()||_0x157d29['isEmpty']())_0x59f99e=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x157d29['numChildren']()&&_0x157d29['isIndexed'](this['index_'])){_0x59f99e=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x7e4924;this['reverse_']?_0x7e4924=_0x157d29['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x7e4924=_0x157d29['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x207c3b=0x0;for(;_0x7e4924['hasNext']()&&_0x207c3b<this['limit_'];){const _0x45391d=_0x7e4924['getNext']();if(this['withinDirectionalStart'](_0x45391d)){if(this['withinDirectionalEnd'](_0x45391d))_0x59f99e=_0x59f99e['updateImmediateChild'](_0x45391d['name'],_0x45391d['node']),_0x207c3b++;else break;}else continue;}}else{_0x59f99e=_0x157d29['withIndex'](this['index_']),_0x59f99e=_0x59f99e['updatePriority'](g['EMPTY_NODE']);let _0x50f3b0;this['reverse_']?_0x50f3b0=_0x59f99e['getReverseIterator'](this['index_']):_0x50f3b0=_0x59f99e['getIterator'](this['index_']);let _0x5af3a1=0x0;for(;_0x50f3b0['hasNext']();){const _0x49d798=_0x50f3b0['getNext']();_0x5af3a1<this['limit_']&&this['withinDirectionalStart'](_0x49d798)&&this['withinDirectionalEnd'](_0x49d798)?_0x5af3a1++:_0x59f99e=_0x59f99e['updateImmediateChild'](_0x49d798['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x106b5a,_0x59f99e,_0x311ed4);}['updatePriority'](_0x20634f,_0x46f9a9){return _0x20634f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4cb181,_0x5cfb8e,_0x1f1195,_0x467df7,_0x413764){let _0x254502;if(this['reverse_']){const _0x59c6a7=this['index_']['getCompare']();_0x254502=(_0x17f3a8,_0xfb244)=>_0x59c6a7(_0xfb244,_0x17f3a8);}else _0x254502=this['index_']['getCompare']();const _0x10970c=_0x4cb181;f(_0x10970c['numChildren']()===this['limit_'],'');const _0x2502a4=new E(_0x5cfb8e,_0x1f1195),_0x21dc39=this['reverse_']?_0x10970c['getFirstChild'](this['index_']):_0x10970c['getLastChild'](this['index_']),_0x166779=this['rangedFilter_']['matches'](_0x2502a4);if(_0x10970c['hasChild'](_0x5cfb8e)){const _0x5c7070=_0x10970c['getImmediateChild'](_0x5cfb8e);let _0x23dfa0=_0x467df7['getChildAfterChild'](this['index_'],_0x21dc39,this['reverse_']);for(;_0x23dfa0!=null&&(_0x23dfa0['name']===_0x5cfb8e||_0x10970c['hasChild'](_0x23dfa0['name']));)_0x23dfa0=_0x467df7['getChildAfterChild'](this['index_'],_0x23dfa0,this['reverse_']);const _0x15bd75=_0x23dfa0==null?0x1:_0x254502(_0x23dfa0,_0x2502a4);if(_0x166779&&!_0x1f1195['isEmpty']()&&_0x15bd75>=0x0)return _0x413764!=null&&_0x413764['trackChildChange'](xt(_0x5cfb8e,_0x1f1195,_0x5c7070)),_0x10970c['updateImmediateChild'](_0x5cfb8e,_0x1f1195);{_0x413764!=null&&_0x413764['trackChildChange'](Lt(_0x5cfb8e,_0x5c7070));const _0x4db2ec=_0x10970c['updateImmediateChild'](_0x5cfb8e,g['EMPTY_NODE']);return _0x23dfa0!=null&&this['rangedFilter_']['matches'](_0x23dfa0)?(_0x413764!=null&&_0x413764['trackChildChange'](rt(_0x23dfa0['name'],_0x23dfa0['node'])),_0x4db2ec['updateImmediateChild'](_0x23dfa0['name'],_0x23dfa0['node'])):_0x4db2ec;}}else return _0x1f1195['isEmpty']()?_0x4cb181:_0x166779&&_0x254502(_0x21dc39,_0x2502a4)>=0x0?(_0x413764!=null&&(_0x413764['trackChildChange'](Lt(_0x21dc39['name'],_0x21dc39['node'])),_0x413764['trackChildChange'](rt(_0x5cfb8e,_0x1f1195))),_0x10970c['updateImmediateChild'](_0x5cfb8e,_0x1f1195)['updateImmediateChild'](_0x21dc39['name'],g['EMPTY_NODE'])):_0x4cb181;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x729f7b=new Zi();return _0x729f7b['limitSet_']=this['limitSet_'],_0x729f7b['limit_']=this['limit_'],_0x729f7b['startSet_']=this['startSet_'],_0x729f7b['startAfterSet_']=this['startAfterSet_'],_0x729f7b['indexStartValue_']=this['indexStartValue_'],_0x729f7b['startNameSet_']=this['startNameSet_'],_0x729f7b['indexStartName_']=this['indexStartName_'],_0x729f7b['endSet_']=this['endSet_'],_0x729f7b['endBeforeSet_']=this['endBeforeSet_'],_0x729f7b['indexEndValue_']=this['indexEndValue_'],_0x729f7b['endNameSet_']=this['endNameSet_'],_0x729f7b['indexEndName_']=this['indexEndName_'],_0x729f7b['index_']=this['index_'],_0x729f7b['viewFrom_']=this['viewFrom_'],_0x729f7b;}}function Kh(_0x4d03f9){return _0x4d03f9['loadsAllData']()?new Xi(_0x4d03f9['getIndex']()):_0x4d03f9['hasLimit']()?new jh(_0x4d03f9):new Ft(_0x4d03f9);}function Yh(_0x16606f,_0x22689d){const _0x4b921b=_0x16606f['copy']();return _0x4b921b['limitSet_']=!0x0,_0x4b921b['limit_']=_0x22689d,_0x4b921b['viewFrom_']='l',_0x4b921b;}function Qh(_0x1da915,_0x2f5e76,_0x1e00c7){const _0x253bb8=_0x1da915['copy']();return _0x253bb8['startSet_']=!0x0,_0x2f5e76===void 0x0&&(_0x2f5e76=null),_0x253bb8['indexStartValue_']=_0x2f5e76,_0x1e00c7!=null?(_0x253bb8['startNameSet_']=!0x0,_0x253bb8['indexStartName_']=_0x1e00c7):(_0x253bb8['startNameSet_']=!0x1,_0x253bb8['indexStartName_']=''),_0x253bb8;}function Jh(_0x57c732,_0x37682f,_0x176a6b){const _0x83cfff=_0x57c732['copy']();return _0x83cfff['endSet_']=!0x0,_0x37682f===void 0x0&&(_0x37682f=null),_0x83cfff['indexEndValue_']=_0x37682f,_0x176a6b!==void 0x0?(_0x83cfff['endNameSet_']=!0x0,_0x83cfff['indexEndName_']=_0x176a6b):(_0x83cfff['endNameSet_']=!0x1,_0x83cfff['indexEndName_']=''),_0x83cfff;}function xo(_0x2463aa,_0x5deeb8){const _0x2b1673=_0x2463aa['copy']();return _0x2b1673['index_']=_0x5deeb8,_0x2b1673;}function ir(_0x25bdfb){const _0x2a1236={};if(_0x25bdfb['isDefault']())return _0x2a1236;let _0x234978;if(_0x25bdfb['index_']===R?_0x234978='$priority':_0x25bdfb['index_']===Mo?_0x234978='$value':_0x25bdfb['index_']===ve?_0x234978='$key':(f(_0x25bdfb['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x234978=_0x25bdfb['index_']['toString']()),_0x2a1236['orderBy']=O(_0x234978),_0x25bdfb['startSet_']){const _0x26f163=_0x25bdfb['startAfterSet_']?'startAfter':'startAt';_0x2a1236[_0x26f163]=O(_0x25bdfb['indexStartValue_']),_0x25bdfb['startNameSet_']&&(_0x2a1236[_0x26f163]+=','+O(_0x25bdfb['indexStartName_']));}if(_0x25bdfb['endSet_']){const _0x10f4e2=_0x25bdfb['endBeforeSet_']?'endBefore':'endAt';_0x2a1236[_0x10f4e2]=O(_0x25bdfb['indexEndValue_']),_0x25bdfb['endNameSet_']&&(_0x2a1236[_0x10f4e2]+=','+O(_0x25bdfb['indexEndName_']));}return _0x25bdfb['limitSet_']&&(_0x25bdfb['isViewFromLeft']()?_0x2a1236['limitToFirst']=_0x25bdfb['limit_']:_0x2a1236['limitToLast']=_0x25bdfb['limit_']),_0x2a1236;}function sr(_0x1c5c7e){const _0x2027ba={};if(_0x1c5c7e['startSet_']&&(_0x2027ba['sp']=_0x1c5c7e['indexStartValue_'],_0x1c5c7e['startNameSet_']&&(_0x2027ba['sn']=_0x1c5c7e['indexStartName_']),_0x2027ba['sin']=!_0x1c5c7e['startAfterSet_']),_0x1c5c7e['endSet_']&&(_0x2027ba['ep']=_0x1c5c7e['indexEndValue_'],_0x1c5c7e['endNameSet_']&&(_0x2027ba['en']=_0x1c5c7e['indexEndName_']),_0x2027ba['ein']=!_0x1c5c7e['endBeforeSet_']),_0x1c5c7e['limitSet_']){_0x2027ba['l']=_0x1c5c7e['limit_'];let _0x175695=_0x1c5c7e['viewFrom_'];_0x175695===''&&(_0x1c5c7e['isViewFromLeft']()?_0x175695='l':_0x175695='r'),_0x2027ba['vf']=_0x175695;}return _0x1c5c7e['index_']!==R&&(_0x2027ba['i']=_0x1c5c7e['index_']['toString']()),_0x2027ba;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x82e49d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x11500e,_0x17d6f1){return _0x17d6f1!==void 0x0?'tag$'+_0x17d6f1:(f(_0x11500e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x11500e['_path']['toString']());}constructor(_0x2fb9c3,_0x460ff2,_0xda321e,_0x4dda86){super(),this['repoInfo_']=_0x2fb9c3,this['onDataUpdate_']=_0x460ff2,this['authTokenProvider_']=_0xda321e,this['appCheckTokenProvider_']=_0x4dda86,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x571a18,_0x286d59,_0x5c36d7,_0x365421){const _0x2d5ae3=_0x571a18['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2d5ae3+'\x20'+_0x571a18['_queryIdentifier']);const _0x360001=vn['getListenId_'](_0x571a18,_0x5c36d7),_0x1b9ac1={};this['listens_'][_0x360001]=_0x1b9ac1;const _0x1d02e5=ir(_0x571a18['_queryParams']);this['restRequest_'](_0x2d5ae3+'.json',_0x1d02e5,(_0x725f85,_0x42a3d0)=>{let _0x1e3c83=_0x42a3d0;if(_0x725f85===0x194&&(_0x1e3c83=null,_0x725f85=null),_0x725f85===null&&this['onDataUpdate_'](_0x2d5ae3,_0x1e3c83,!0x1,_0x5c36d7),Le(this['listens_'],_0x360001)===_0x1b9ac1){let _0x1bca9c;_0x725f85?_0x725f85===0x191?_0x1bca9c='permission_denied':_0x1bca9c='rest_error:'+_0x725f85:_0x1bca9c='ok',_0x365421(_0x1bca9c,null);}});}['unlisten'](_0x1632b2,_0x2c0178){const _0x1207c=vn['getListenId_'](_0x1632b2,_0x2c0178);delete this['listens_'][_0x1207c];}['get'](_0x5e421a){const _0x28e3cd=ir(_0x5e421a['_queryParams']),_0xf19a05=_0x5e421a['_path']['toString'](),_0x393a76=new H();return this['restRequest_'](_0xf19a05+'.json',_0x28e3cd,(_0x34c14f,_0xf06516)=>{let _0x4a442a=_0xf06516;_0x34c14f===0x194&&(_0x4a442a=null,_0x34c14f=null),_0x34c14f===null?(this['onDataUpdate_'](_0xf19a05,_0x4a442a,!0x1,null),_0x393a76['resolve'](_0x4a442a)):_0x393a76['reject'](new Error(_0x4a442a));}),_0x393a76['promise'];}['refreshAuthToken'](_0x28fa4c){}['restRequest_'](_0x403832,_0x15b999={},_0xd18ea1){return _0x15b999['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2d4b33,_0x4583cc])=>{_0x2d4b33&&_0x2d4b33['accessToken']&&(_0x15b999['auth']=_0x2d4b33['accessToken']),_0x4583cc&&_0x4583cc['token']&&(_0x15b999['ac']=_0x4583cc['token']);const _0x142056=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x403832+'?ns='+this['repoInfo_']['namespace']+ut(_0x15b999);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x142056);const _0x43d752=new XMLHttpRequest();_0x43d752['onreadystatechange']=()=>{if(_0xd18ea1&&_0x43d752['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x142056+'\x20received.\x20status:',_0x43d752['status'],'response:',_0x43d752['responseText']);let _0x22256a=null;if(_0x43d752['status']>=0xc8&&_0x43d752['status']<0x12c){try{_0x22256a=Nt(_0x43d752['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x142056+':\x20'+_0x43d752['responseText']);}_0xd18ea1(null,_0x22256a);}else _0x43d752['status']!==0x191&&_0x43d752['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x142056+'\x20Status:\x20'+_0x43d752['status']),_0xd18ea1(_0x43d752['status']);_0xd18ea1=null;}},_0x43d752['open']('GET',_0x142056,!0x0),_0x43d752['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3c53f8){return this['rootNode_']['getChild'](_0x3c53f8);}['updateSnapshot'](_0x52ada4,_0x457e56){this['rootNode_']=this['rootNode_']['updateChild'](_0x52ada4,_0x457e56);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x4ee473,_0x4cd1d2,_0x12a91a){if(v(_0x4cd1d2))_0x4ee473['value']=_0x12a91a,_0x4ee473['children']['clear']();else{if(_0x4ee473['value']!==null)_0x4ee473['value']=_0x4ee473['value']['updateChild'](_0x4cd1d2,_0x12a91a);else{const _0x136d16=y(_0x4cd1d2);_0x4ee473['children']['has'](_0x136d16)||_0x4ee473['children']['set'](_0x136d16,En());const _0x2d3e21=_0x4ee473['children']['get'](_0x136d16);_0x4cd1d2=S(_0x4cd1d2),pt(_0x2d3e21,_0x4cd1d2,_0x12a91a);}}}function Ti(_0x183fe2,_0x45ca32){if(v(_0x45ca32))return _0x183fe2['value']=null,_0x183fe2['children']['clear'](),!0x0;if(_0x183fe2['value']!==null){if(_0x183fe2['value']['isLeafNode']())return!0x1;{const _0x10e924=_0x183fe2['value'];return _0x183fe2['value']=null,_0x10e924['forEachChild'](R,(_0x5e54af,_0x3d5620)=>{pt(_0x183fe2,new C(_0x5e54af),_0x3d5620);}),Ti(_0x183fe2,_0x45ca32);}}else{if(_0x183fe2['children']['size']>0x0){const _0x5c945f=y(_0x45ca32);return _0x45ca32=S(_0x45ca32),_0x183fe2['children']['has'](_0x5c945f)&&Ti(_0x183fe2['children']['get'](_0x5c945f),_0x45ca32)&&_0x183fe2['children']['delete'](_0x5c945f),_0x183fe2['children']['size']===0x0;}else return!0x0;}}function Si(_0x4478f5,_0xf2e9ef,_0x102149){_0x4478f5['value']!==null?_0x102149(_0xf2e9ef,_0x4478f5['value']):Zh(_0x4478f5,(_0x399281,_0x9bd253)=>{const _0x56b0b4=new C(_0xf2e9ef['toString']()+'/'+_0x399281);Si(_0x9bd253,_0x56b0b4,_0x102149);});}function Zh(_0x188feb,_0x481c17){_0x188feb['children']['forEach']((_0x8d626d,_0x6b3b99)=>{_0x481c17(_0x6b3b99,_0x8d626d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0xc4e621){this['collection_']=_0xc4e621,this['last_']=null;}['get'](){const _0x5dbe20=this['collection_']['get'](),_0x1df9e7={..._0x5dbe20};return this['last_']&&x(this['last_'],(_0x4c218d,_0x5ab779)=>{_0x1df9e7[_0x4c218d]=_0x1df9e7[_0x4c218d]-_0x5ab779;}),this['last_']=_0x5dbe20,_0x1df9e7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x58b942,_0x1b2a1d){this['server_']=_0x1b2a1d,this['statsToReport_']={},this['statsListener_']=new eu(_0x58b942);const _0x3c3271=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3c3271));}['reportStats_'](){const _0x3aa733=this['statsListener_']['get'](),_0x36d1b4={};let _0x52e1b9=!0x1;x(_0x3aa733,(_0x16a563,_0x1aa7fb)=>{_0x1aa7fb>0x0&&Q(this['statsToReport_'],_0x16a563)&&(_0x36d1b4[_0x16a563]=_0x1aa7fb,_0x52e1b9=!0x0);}),_0x52e1b9&&this['server_']['reportStats'](_0x36d1b4),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x5ab5d0){_0x5ab5d0[_0x5ab5d0['OVERWRITE']=0x0]='OVERWRITE',_0x5ab5d0[_0x5ab5d0['MERGE']=0x1]='MERGE',_0x5ab5d0[_0x5ab5d0['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5ab5d0[_0x5ab5d0['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x3a7909){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3a7909,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xba9fa8,_0x501f0,_0x41b7c7){this['path']=_0xba9fa8,this['affectedTree']=_0x501f0,this['revert']=_0x41b7c7,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x23db68){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x45a5c5=this['affectedTree']['subtree'](new C(_0x23db68));return new In(w(),_0x45a5c5,this['revert']);}}else return f(y(this['path'])===_0x23db68,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x30e4e5,_0x5851f5){this['source']=_0x30e4e5,this['path']=_0x5851f5,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4b4b42){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x43130f,_0x466494,_0x33531e){this['source']=_0x43130f,this['path']=_0x466494,this['snap']=_0x33531e,this['type']=z['OVERWRITE'];}['operationForChild'](_0xd663e0){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xd663e0)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x275f50,_0x24d46a,_0x2eb398){this['source']=_0x275f50,this['path']=_0x24d46a,this['children']=_0x2eb398,this['type']=z['MERGE'];}['operationForChild'](_0x14d48d){if(v(this['path'])){const _0x4ccf4e=this['children']['subtree'](new C(_0x14d48d));return _0x4ccf4e['isEmpty']()?null:_0x4ccf4e['value']?new Be(this['source'],w(),_0x4ccf4e['value']):new ot(this['source'],w(),_0x4ccf4e);}else return f(y(this['path'])===_0x14d48d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x4eada5,_0x2b7e4d,_0x71e5ad){this['node_']=_0x4eada5,this['fullyInitialized_']=_0x2b7e4d,this['filtered_']=_0x71e5ad;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x916fd5){if(v(_0x916fd5))return this['isFullyInitialized']()&&!this['filtered_'];const _0x48c4fd=y(_0x916fd5);return this['isCompleteForChild'](_0x48c4fd);}['isCompleteForChild'](_0x4e1469){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4e1469);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x4b1570){this['query_']=_0x4b1570,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xf81c66,_0x413a9c,_0x2ae7d8,_0x47d752){const _0x344055=[],_0x513a7d=[];return _0x413a9c['forEach'](_0xc1b24c=>{_0xc1b24c['type']==='child_changed'&&_0xf81c66['index_']['indexedValueChanged'](_0xc1b24c['oldSnap'],_0xc1b24c['snapshotNode'])&&_0x513a7d['push'](zh(_0xc1b24c['childName'],_0xc1b24c['snapshotNode']));}),wt(_0xf81c66,_0x344055,'child_removed',_0x413a9c,_0x47d752,_0x2ae7d8),wt(_0xf81c66,_0x344055,'child_added',_0x413a9c,_0x47d752,_0x2ae7d8),wt(_0xf81c66,_0x344055,'child_moved',_0x513a7d,_0x47d752,_0x2ae7d8),wt(_0xf81c66,_0x344055,'child_changed',_0x413a9c,_0x47d752,_0x2ae7d8),wt(_0xf81c66,_0x344055,'value',_0x413a9c,_0x47d752,_0x2ae7d8),_0x344055;}function wt(_0x20da31,_0xda6b7c,_0xe8af0d,_0x122e9a,_0x2054cc,_0x64707a){const _0x1680ea=_0x122e9a['filter'](_0x3830fd=>_0x3830fd['type']===_0xe8af0d);_0x1680ea['sort']((_0x4858e8,_0x58e806)=>au(_0x20da31,_0x4858e8,_0x58e806)),_0x1680ea['forEach'](_0x32e8ad=>{const _0x146fe1=ou(_0x20da31,_0x32e8ad,_0x64707a);_0x2054cc['forEach'](_0x259f28=>{_0x259f28['respondsTo'](_0x32e8ad['type'])&&_0xda6b7c['push'](_0x259f28['createEvent'](_0x146fe1,_0x20da31['query_']));});});}function ou(_0x5e1e5c,_0x11b028,_0x71c401){return _0x11b028['type']==='value'||_0x11b028['type']==='child_removed'||(_0x11b028['prevName']=_0x71c401['getPredecessorChildName'](_0x11b028['childName'],_0x11b028['snapshotNode'],_0x5e1e5c['index_'])),_0x11b028;}function au(_0x1ed7ab,_0x1218be,_0x4a8b79){if(_0x1218be['childName']==null||_0x4a8b79['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x548baf=new E(_0x1218be['childName'],_0x1218be['snapshotNode']),_0x268032=new E(_0x4a8b79['childName'],_0x4a8b79['snapshotNode']);return _0x1ed7ab['index_']['compare'](_0x548baf,_0x268032);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x3dbf7f,_0x34a0c7){return{'eventCache':_0x3dbf7f,'serverCache':_0x34a0c7};}function Rt(_0x1151ea,_0x15a6fa,_0x3a49f1,_0x4d6c5b){return Un(new Te(_0x15a6fa,_0x3a49f1,_0x4d6c5b),_0x1151ea['serverCache']);}function Fo(_0x1e3b2a,_0x12acd6,_0x3ea266,_0x32c6ee){return Un(_0x1e3b2a['eventCache'],new Te(_0x12acd6,_0x3ea266,_0x32c6ee));}function wn(_0x1388dc){return _0x1388dc['eventCache']['isFullyInitialized']()?_0x1388dc['eventCache']['getNode']():null;}function Ve(_0x3fcb4a){return _0x3fcb4a['serverCache']['isFullyInitialized']()?_0x3fcb4a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x4e3d31){let _0x40deeb=new b(null);return x(_0x4e3d31,(_0x3a1663,_0x1ee6aa)=>{_0x40deeb=_0x40deeb['set'](new C(_0x3a1663),_0x1ee6aa);}),_0x40deeb;}constructor(_0x88987,_0x3d4470=cu()){this['value']=_0x88987,this['children']=_0x3d4470;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x52e581,_0x4677c3){if(this['value']!=null&&_0x4677c3(this['value']))return{'path':w(),'value':this['value']};if(v(_0x52e581))return null;{const _0x29c40a=y(_0x52e581),_0xe5f773=this['children']['get'](_0x29c40a);if(_0xe5f773!==null){const _0x26f0d9=_0xe5f773['findRootMostMatchingPathAndValue'](S(_0x52e581),_0x4677c3);return _0x26f0d9!=null?{'path':k(new C(_0x29c40a),_0x26f0d9['path']),'value':_0x26f0d9['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x44faff){return this['findRootMostMatchingPathAndValue'](_0x44faff,()=>!0x0);}['subtree'](_0x14cc6b){if(v(_0x14cc6b))return this;{const _0x174e5f=y(_0x14cc6b),_0x201b85=this['children']['get'](_0x174e5f);return _0x201b85!==null?_0x201b85['subtree'](S(_0x14cc6b)):new b(null);}}['set'](_0x1cf735,_0x1cbe79){if(v(_0x1cf735))return new b(_0x1cbe79,this['children']);{const _0x1d6194=y(_0x1cf735),_0x524268=(this['children']['get'](_0x1d6194)||new b(null))['set'](S(_0x1cf735),_0x1cbe79),_0x82b2c9=this['children']['insert'](_0x1d6194,_0x524268);return new b(this['value'],_0x82b2c9);}}['remove'](_0x156874){if(v(_0x156874))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0xd0a2f6=y(_0x156874),_0x52f5ce=this['children']['get'](_0xd0a2f6);if(_0x52f5ce){const _0x2b3893=_0x52f5ce['remove'](S(_0x156874));let _0x447e7f;return _0x2b3893['isEmpty']()?_0x447e7f=this['children']['remove'](_0xd0a2f6):_0x447e7f=this['children']['insert'](_0xd0a2f6,_0x2b3893),this['value']===null&&_0x447e7f['isEmpty']()?new b(null):new b(this['value'],_0x447e7f);}else return this;}}['get'](_0x5184be){if(v(_0x5184be))return this['value'];{const _0x34d28b=y(_0x5184be),_0xfa7dff=this['children']['get'](_0x34d28b);return _0xfa7dff?_0xfa7dff['get'](S(_0x5184be)):null;}}['setTree'](_0xca47e,_0xa8be81){if(v(_0xca47e))return _0xa8be81;{const _0x3aaae6=y(_0xca47e),_0x5c5bd1=(this['children']['get'](_0x3aaae6)||new b(null))['setTree'](S(_0xca47e),_0xa8be81);let _0x1168f4;return _0x5c5bd1['isEmpty']()?_0x1168f4=this['children']['remove'](_0x3aaae6):_0x1168f4=this['children']['insert'](_0x3aaae6,_0x5c5bd1),new b(this['value'],_0x1168f4);}}['fold'](_0x44bbcf){return this['fold_'](w(),_0x44bbcf);}['fold_'](_0x274d2c,_0x248bdf){const _0xc17bf1={};return this['children']['inorderTraversal']((_0x134df0,_0x3a76be)=>{_0xc17bf1[_0x134df0]=_0x3a76be['fold_'](k(_0x274d2c,_0x134df0),_0x248bdf);}),_0x248bdf(_0x274d2c,this['value'],_0xc17bf1);}['findOnPath'](_0x1de475,_0x3f87dc){return this['findOnPath_'](_0x1de475,w(),_0x3f87dc);}['findOnPath_'](_0xd14f51,_0x5ddf17,_0x279e8b){const _0x431338=this['value']?_0x279e8b(_0x5ddf17,this['value']):!0x1;if(_0x431338)return _0x431338;if(v(_0xd14f51))return null;{const _0x53e88c=y(_0xd14f51),_0x32005a=this['children']['get'](_0x53e88c);return _0x32005a?_0x32005a['findOnPath_'](S(_0xd14f51),k(_0x5ddf17,_0x53e88c),_0x279e8b):null;}}['foreachOnPath'](_0x3b9d8e,_0x314769){return this['foreachOnPath_'](_0x3b9d8e,w(),_0x314769);}['foreachOnPath_'](_0x1e3642,_0x46c7a4,_0x171886){if(v(_0x1e3642))return this;{this['value']&&_0x171886(_0x46c7a4,this['value']);const _0xb4c8f=y(_0x1e3642),_0x3f164a=this['children']['get'](_0xb4c8f);return _0x3f164a?_0x3f164a['foreachOnPath_'](S(_0x1e3642),k(_0x46c7a4,_0xb4c8f),_0x171886):new b(null);}}['foreach'](_0x426e40){this['foreach_'](w(),_0x426e40);}['foreach_'](_0x10dd88,_0x4adbc8){this['children']['inorderTraversal']((_0x4c385e,_0x344119)=>{_0x344119['foreach_'](k(_0x10dd88,_0x4c385e),_0x4adbc8);}),this['value']&&_0x4adbc8(_0x10dd88,this['value']);}['foreachChild'](_0x3a5be5){this['children']['inorderTraversal']((_0x4e8f7e,_0x2ce399)=>{_0x2ce399['value']&&_0x3a5be5(_0x4e8f7e,_0x2ce399['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x437f60){this['writeTree_']=_0x437f60;}static['empty'](){return new K(new b(null));}}function At(_0x312eb7,_0x480991,_0xbf17b4){if(v(_0x480991))return new K(new b(_0xbf17b4));{const _0xf44fae=_0x312eb7['writeTree_']['findRootMostValueAndPath'](_0x480991);if(_0xf44fae!=null){const _0x18cbd4=_0xf44fae['path'];let _0x18f28e=_0xf44fae['value'];const _0x24d4d5=F(_0x18cbd4,_0x480991);return _0x18f28e=_0x18f28e['updateChild'](_0x24d4d5,_0xbf17b4),new K(_0x312eb7['writeTree_']['set'](_0x18cbd4,_0x18f28e));}else{const _0x578898=new b(_0xbf17b4),_0x231383=_0x312eb7['writeTree_']['setTree'](_0x480991,_0x578898);return new K(_0x231383);}}}function bi(_0x1f4714,_0x5f4c2b,_0x3cfa0c){let _0xa54f1=_0x1f4714;return x(_0x3cfa0c,(_0x38738f,_0x2fb284)=>{_0xa54f1=At(_0xa54f1,k(_0x5f4c2b,_0x38738f),_0x2fb284);}),_0xa54f1;}function or(_0x2bedae,_0x4b75d5){if(v(_0x4b75d5))return K['empty']();{const _0x485283=_0x2bedae['writeTree_']['setTree'](_0x4b75d5,new b(null));return new K(_0x485283);}}function Ri(_0x1293d1,_0x3fe9f7){return ze(_0x1293d1,_0x3fe9f7)!=null;}function ze(_0xaf3210,_0x39633c){const _0x522f9b=_0xaf3210['writeTree_']['findRootMostValueAndPath'](_0x39633c);return _0x522f9b!=null?_0xaf3210['writeTree_']['get'](_0x522f9b['path'])['getChild'](F(_0x522f9b['path'],_0x39633c)):null;}function ar(_0xc2ff07){const _0xb172ba=[],_0x5c9de8=_0xc2ff07['writeTree_']['value'];return _0x5c9de8!=null?_0x5c9de8['isLeafNode']()||_0x5c9de8['forEachChild'](R,(_0x28e95d,_0x2ca560)=>{_0xb172ba['push'](new E(_0x28e95d,_0x2ca560));}):_0xc2ff07['writeTree_']['children']['inorderTraversal']((_0x5f1372,_0x15d656)=>{_0x15d656['value']!=null&&_0xb172ba['push'](new E(_0x5f1372,_0x15d656['value']));}),_0xb172ba;}function Ee(_0x1ba68b,_0x53f252){if(v(_0x53f252))return _0x1ba68b;{const _0x53d9ac=ze(_0x1ba68b,_0x53f252);return _0x53d9ac!=null?new K(new b(_0x53d9ac)):new K(_0x1ba68b['writeTree_']['subtree'](_0x53f252));}}function Ai(_0x3664d4){return _0x3664d4['writeTree_']['isEmpty']();}function at(_0x15c333,_0x5bdae8){return Uo(w(),_0x15c333['writeTree_'],_0x5bdae8);}function Uo(_0x490a58,_0x3d138d,_0x14ec13){if(_0x3d138d['value']!=null)return _0x14ec13['updateChild'](_0x490a58,_0x3d138d['value']);{let _0x16c553=null;return _0x3d138d['children']['inorderTraversal']((_0x1e906b,_0x24fe4f)=>{_0x1e906b==='.priority'?(f(_0x24fe4f['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x16c553=_0x24fe4f['value']):_0x14ec13=Uo(k(_0x490a58,_0x1e906b),_0x24fe4f,_0x14ec13);}),!_0x14ec13['getChild'](_0x490a58)['isEmpty']()&&_0x16c553!==null&&(_0x14ec13=_0x14ec13['updateChild'](k(_0x490a58,'.priority'),_0x16c553)),_0x14ec13;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5b36d4,_0x5747b9){return Ho(_0x5747b9,_0x5b36d4);}function lu(_0x47e0ed,_0x90bcb7,_0x35eb0c,_0xe366ed,_0x33fe0){f(_0xe366ed>_0x47e0ed['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x33fe0===void 0x0&&(_0x33fe0=!0x0),_0x47e0ed['allWrites']['push']({'path':_0x90bcb7,'snap':_0x35eb0c,'writeId':_0xe366ed,'visible':_0x33fe0}),_0x33fe0&&(_0x47e0ed['visibleWrites']=At(_0x47e0ed['visibleWrites'],_0x90bcb7,_0x35eb0c)),_0x47e0ed['lastWriteId']=_0xe366ed;}function hu(_0x420449,_0x2a89dd,_0xd38d19,_0x4c6b3e){f(_0x4c6b3e>_0x420449['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x420449['allWrites']['push']({'path':_0x2a89dd,'children':_0xd38d19,'writeId':_0x4c6b3e,'visible':!0x0}),_0x420449['visibleWrites']=bi(_0x420449['visibleWrites'],_0x2a89dd,_0xd38d19),_0x420449['lastWriteId']=_0x4c6b3e;}function uu(_0x11b98c,_0x50b10e){for(let _0x59644e=0x0;_0x59644e<_0x11b98c['allWrites']['length'];_0x59644e++){const _0xc43e60=_0x11b98c['allWrites'][_0x59644e];if(_0xc43e60['writeId']===_0x50b10e)return _0xc43e60;}return null;}function du(_0x4e163b,_0x573564){const _0x40830f=_0x4e163b['allWrites']['findIndex'](_0x204128=>_0x204128['writeId']===_0x573564);f(_0x40830f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x68b3a2=_0x4e163b['allWrites'][_0x40830f];_0x4e163b['allWrites']['splice'](_0x40830f,0x1);let _0x1d71c5=_0x68b3a2['visible'],_0x5ae14c=!0x1,_0x491d6b=_0x4e163b['allWrites']['length']-0x1;for(;_0x1d71c5&&_0x491d6b>=0x0;){const _0x555582=_0x4e163b['allWrites'][_0x491d6b];_0x555582['visible']&&(_0x491d6b>=_0x40830f&&fu(_0x555582,_0x68b3a2['path'])?_0x1d71c5=!0x1:G(_0x68b3a2['path'],_0x555582['path'])&&(_0x5ae14c=!0x0)),_0x491d6b--;}if(_0x1d71c5){if(_0x5ae14c)return pu(_0x4e163b),!0x0;if(_0x68b3a2['snap'])_0x4e163b['visibleWrites']=or(_0x4e163b['visibleWrites'],_0x68b3a2['path']);else{const _0xcd1558=_0x68b3a2['children'];x(_0xcd1558,_0xe92b5=>{_0x4e163b['visibleWrites']=or(_0x4e163b['visibleWrites'],k(_0x68b3a2['path'],_0xe92b5));});}return!0x0;}else return!0x1;}function fu(_0x1e176b,_0x59cee9){if(_0x1e176b['snap'])return G(_0x1e176b['path'],_0x59cee9);for(const _0x11c79a in _0x1e176b['children'])if(_0x1e176b['children']['hasOwnProperty'](_0x11c79a)&&G(k(_0x1e176b['path'],_0x11c79a),_0x59cee9))return!0x0;return!0x1;}function pu(_0x530a56){_0x530a56['visibleWrites']=Wo(_0x530a56['allWrites'],_u,w()),_0x530a56['allWrites']['length']>0x0?_0x530a56['lastWriteId']=_0x530a56['allWrites'][_0x530a56['allWrites']['length']-0x1]['writeId']:_0x530a56['lastWriteId']=-0x1;}function _u(_0x18df8a){return _0x18df8a['visible'];}function Wo(_0x123cfc,_0x49c21d,_0x3297e3){let _0x5d148a=K['empty']();for(let _0x4ec76a=0x0;_0x4ec76a<_0x123cfc['length'];++_0x4ec76a){const _0x2a5876=_0x123cfc[_0x4ec76a];if(_0x49c21d(_0x2a5876)){const _0x5140d0=_0x2a5876['path'];let _0x125022;if(_0x2a5876['snap'])G(_0x3297e3,_0x5140d0)?(_0x125022=F(_0x3297e3,_0x5140d0),_0x5d148a=At(_0x5d148a,_0x125022,_0x2a5876['snap'])):G(_0x5140d0,_0x3297e3)&&(_0x125022=F(_0x5140d0,_0x3297e3),_0x5d148a=At(_0x5d148a,w(),_0x2a5876['snap']['getChild'](_0x125022)));else{if(_0x2a5876['children']){if(G(_0x3297e3,_0x5140d0))_0x125022=F(_0x3297e3,_0x5140d0),_0x5d148a=bi(_0x5d148a,_0x125022,_0x2a5876['children']);else{if(G(_0x5140d0,_0x3297e3)){if(_0x125022=F(_0x5140d0,_0x3297e3),v(_0x125022))_0x5d148a=bi(_0x5d148a,w(),_0x2a5876['children']);else{const _0xb2cca2=Le(_0x2a5876['children'],y(_0x125022));if(_0xb2cca2){const _0xc8b9d5=_0xb2cca2['getChild'](S(_0x125022));_0x5d148a=At(_0x5d148a,w(),_0xc8b9d5);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5d148a;}function Bo(_0x365d3c,_0x444987,_0x5e15eb,_0x15621a,_0x2222e8){if(!_0x15621a&&!_0x2222e8){const _0x303627=ze(_0x365d3c['visibleWrites'],_0x444987);if(_0x303627!=null)return _0x303627;{const _0x397248=Ee(_0x365d3c['visibleWrites'],_0x444987);if(Ai(_0x397248))return _0x5e15eb;if(_0x5e15eb==null&&!Ri(_0x397248,w()))return null;{const _0x23fdb4=_0x5e15eb||g['EMPTY_NODE'];return at(_0x397248,_0x23fdb4);}}}else{const _0xe5e39a=Ee(_0x365d3c['visibleWrites'],_0x444987);if(!_0x2222e8&&Ai(_0xe5e39a))return _0x5e15eb;if(!_0x2222e8&&_0x5e15eb==null&&!Ri(_0xe5e39a,w()))return null;{const _0x319c26=function(_0x1878fb){return(_0x1878fb['visible']||_0x2222e8)&&(!_0x15621a||!~_0x15621a['indexOf'](_0x1878fb['writeId']))&&(G(_0x1878fb['path'],_0x444987)||G(_0x444987,_0x1878fb['path']));},_0x32cdf9=Wo(_0x365d3c['allWrites'],_0x319c26,_0x444987),_0x1344fd=_0x5e15eb||g['EMPTY_NODE'];return at(_0x32cdf9,_0x1344fd);}}}function gu(_0x48f3af,_0x327dfa,_0x40b51c){let _0x52e948=g['EMPTY_NODE'];const _0x4dec7a=ze(_0x48f3af['visibleWrites'],_0x327dfa);if(_0x4dec7a)return _0x4dec7a['isLeafNode']()||_0x4dec7a['forEachChild'](R,(_0x322e75,_0x4d8cf5)=>{_0x52e948=_0x52e948['updateImmediateChild'](_0x322e75,_0x4d8cf5);}),_0x52e948;if(_0x40b51c){const _0x63e983=Ee(_0x48f3af['visibleWrites'],_0x327dfa);return _0x40b51c['forEachChild'](R,(_0x16893a,_0x594a15)=>{const _0x48eb46=at(Ee(_0x63e983,new C(_0x16893a)),_0x594a15);_0x52e948=_0x52e948['updateImmediateChild'](_0x16893a,_0x48eb46);}),ar(_0x63e983)['forEach'](_0x280623=>{_0x52e948=_0x52e948['updateImmediateChild'](_0x280623['name'],_0x280623['node']);}),_0x52e948;}else{const _0x343655=Ee(_0x48f3af['visibleWrites'],_0x327dfa);return ar(_0x343655)['forEach'](_0xa0cf6d=>{_0x52e948=_0x52e948['updateImmediateChild'](_0xa0cf6d['name'],_0xa0cf6d['node']);}),_0x52e948;}}function mu(_0x59439a,_0x197586,_0x573da6,_0x3d9090,_0x25d40b){f(_0x3d9090||_0x25d40b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x54c70c=k(_0x197586,_0x573da6);if(Ri(_0x59439a['visibleWrites'],_0x54c70c))return null;{const _0x2c3b9e=Ee(_0x59439a['visibleWrites'],_0x54c70c);return Ai(_0x2c3b9e)?_0x25d40b['getChild'](_0x573da6):at(_0x2c3b9e,_0x25d40b['getChild'](_0x573da6));}}function yu(_0x42b33e,_0xf0b330,_0x3d5c5a,_0x210502){const _0x481745=k(_0xf0b330,_0x3d5c5a),_0x2f1de1=ze(_0x42b33e['visibleWrites'],_0x481745);if(_0x2f1de1!=null)return _0x2f1de1;if(_0x210502['isCompleteForChild'](_0x3d5c5a)){const _0x3d44fc=Ee(_0x42b33e['visibleWrites'],_0x481745);return at(_0x3d44fc,_0x210502['getNode']()['getImmediateChild'](_0x3d5c5a));}else return null;}function vu(_0x4341bf,_0x2dc4cd){return ze(_0x4341bf['visibleWrites'],_0x2dc4cd);}function Eu(_0x4b25bb,_0x228261,_0x2e63cd,_0x3bfe6b,_0x2fab84,_0x5d00d3,_0x588d56){let _0x191aab;const _0x487568=Ee(_0x4b25bb['visibleWrites'],_0x228261),_0x5a1569=ze(_0x487568,w());if(_0x5a1569!=null)_0x191aab=_0x5a1569;else{if(_0x2e63cd!=null)_0x191aab=at(_0x487568,_0x2e63cd);else return[];}if(_0x191aab=_0x191aab['withIndex'](_0x588d56),!_0x191aab['isEmpty']()&&!_0x191aab['isLeafNode']()){const _0x58bf1b=[],_0x3104d6=_0x588d56['getCompare'](),_0xb37af4=_0x5d00d3?_0x191aab['getReverseIteratorFrom'](_0x3bfe6b,_0x588d56):_0x191aab['getIteratorFrom'](_0x3bfe6b,_0x588d56);let _0x5cef09=_0xb37af4['getNext']();for(;_0x5cef09&&_0x58bf1b['length']<_0x2fab84;)_0x3104d6(_0x5cef09,_0x3bfe6b)!==0x0&&_0x58bf1b['push'](_0x5cef09),_0x5cef09=_0xb37af4['getNext']();return _0x58bf1b;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x57c9aa,_0x267c88,_0x4fd724,_0x340f05){return Bo(_0x57c9aa['writeTree'],_0x57c9aa['treePath'],_0x267c88,_0x4fd724,_0x340f05);}function is(_0x4f6670,_0x17528c){return gu(_0x4f6670['writeTree'],_0x4f6670['treePath'],_0x17528c);}function cr(_0x2000b7,_0x4e500f,_0x4e5940,_0x2f5513){return mu(_0x2000b7['writeTree'],_0x2000b7['treePath'],_0x4e500f,_0x4e5940,_0x2f5513);}function Tn(_0x35a0cd,_0x4d8e60){return vu(_0x35a0cd['writeTree'],k(_0x35a0cd['treePath'],_0x4d8e60));}function wu(_0x2631a5,_0x15fa98,_0x32c80e,_0x58903f,_0x400a96,_0xa9b4ef){return Eu(_0x2631a5['writeTree'],_0x2631a5['treePath'],_0x15fa98,_0x32c80e,_0x58903f,_0x400a96,_0xa9b4ef);}function ss(_0xb82377,_0x693d6f,_0x2f5002){return yu(_0xb82377['writeTree'],_0xb82377['treePath'],_0x693d6f,_0x2f5002);}function Vo(_0x5df5d3,_0x3104cc){return Ho(k(_0x5df5d3['treePath'],_0x3104cc),_0x5df5d3['writeTree']);}function Ho(_0x3788bf,_0x45839a){return{'treePath':_0x3788bf,'writeTree':_0x45839a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x27b8b3){const _0x357581=_0x27b8b3['type'],_0x3ba98f=_0x27b8b3['childName'];f(_0x357581==='child_added'||_0x357581==='child_changed'||_0x357581==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3ba98f!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x51f100=this['changeMap']['get'](_0x3ba98f);if(_0x51f100){const _0x897edc=_0x51f100['type'];if(_0x357581==='child_added'&&_0x897edc==='child_removed')this['changeMap']['set'](_0x3ba98f,xt(_0x3ba98f,_0x27b8b3['snapshotNode'],_0x51f100['snapshotNode']));else{if(_0x357581==='child_removed'&&_0x897edc==='child_added')this['changeMap']['delete'](_0x3ba98f);else{if(_0x357581==='child_removed'&&_0x897edc==='child_changed')this['changeMap']['set'](_0x3ba98f,Lt(_0x3ba98f,_0x51f100['oldSnap']));else{if(_0x357581==='child_changed'&&_0x897edc==='child_added')this['changeMap']['set'](_0x3ba98f,rt(_0x3ba98f,_0x27b8b3['snapshotNode']));else{if(_0x357581==='child_changed'&&_0x897edc==='child_changed')this['changeMap']['set'](_0x3ba98f,xt(_0x3ba98f,_0x27b8b3['snapshotNode'],_0x51f100['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x27b8b3+'\x20occurred\x20after\x20'+_0x51f100);}}}}}else this['changeMap']['set'](_0x3ba98f,_0x27b8b3);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x2f69ca){return null;}['getChildAfterChild'](_0x50eba6,_0xdf4a43,_0x29dd0e){return null;}}const $o=new Tu();class rs{constructor(_0x418a5a,_0x475e6d,_0x5b9559=null){this['writes_']=_0x418a5a,this['viewCache_']=_0x475e6d,this['optCompleteServerCache_']=_0x5b9559;}['getCompleteChild'](_0x5e5c4b){const _0x4a9b71=this['viewCache_']['eventCache'];if(_0x4a9b71['isCompleteForChild'](_0x5e5c4b))return _0x4a9b71['getNode']()['getImmediateChild'](_0x5e5c4b);{const _0x50219f=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x5e5c4b,_0x50219f);}}['getChildAfterChild'](_0x12cec5,_0x306574,_0x1640ab){const _0x30f3d3=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x53098a=wu(this['writes_'],_0x30f3d3,_0x306574,0x1,_0x1640ab,_0x12cec5);return _0x53098a['length']===0x0?null:_0x53098a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3557b8){return{'filter':_0x3557b8};}function bu(_0x24240a,_0x4b9987){f(_0x4b9987['eventCache']['getNode']()['isIndexed'](_0x24240a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4b9987['serverCache']['getNode']()['isIndexed'](_0x24240a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x117785,_0x2dcf2d,_0x36853b,_0x34f396,_0x4a0906){const _0x5cd43d=new Cu();let _0x35d516,_0x323082;if(_0x36853b['type']===z['OVERWRITE']){const _0x3a02a3=_0x36853b;_0x3a02a3['source']['fromUser']?_0x35d516=ki(_0x117785,_0x2dcf2d,_0x3a02a3['path'],_0x3a02a3['snap'],_0x34f396,_0x4a0906,_0x5cd43d):(f(_0x3a02a3['source']['fromServer'],'Unknown\x20source.'),_0x323082=_0x3a02a3['source']['tagged']||_0x2dcf2d['serverCache']['isFiltered']()&&!v(_0x3a02a3['path']),_0x35d516=Sn(_0x117785,_0x2dcf2d,_0x3a02a3['path'],_0x3a02a3['snap'],_0x34f396,_0x4a0906,_0x323082,_0x5cd43d));}else{if(_0x36853b['type']===z['MERGE']){const _0x1fe127=_0x36853b;_0x1fe127['source']['fromUser']?_0x35d516=ku(_0x117785,_0x2dcf2d,_0x1fe127['path'],_0x1fe127['children'],_0x34f396,_0x4a0906,_0x5cd43d):(f(_0x1fe127['source']['fromServer'],'Unknown\x20source.'),_0x323082=_0x1fe127['source']['tagged']||_0x2dcf2d['serverCache']['isFiltered'](),_0x35d516=Pi(_0x117785,_0x2dcf2d,_0x1fe127['path'],_0x1fe127['children'],_0x34f396,_0x4a0906,_0x323082,_0x5cd43d));}else{if(_0x36853b['type']===z['ACK_USER_WRITE']){const _0x172a9b=_0x36853b;_0x172a9b['revert']?_0x35d516=Ou(_0x117785,_0x2dcf2d,_0x172a9b['path'],_0x34f396,_0x4a0906,_0x5cd43d):_0x35d516=Pu(_0x117785,_0x2dcf2d,_0x172a9b['path'],_0x172a9b['affectedTree'],_0x34f396,_0x4a0906,_0x5cd43d);}else{if(_0x36853b['type']===z['LISTEN_COMPLETE'])_0x35d516=Nu(_0x117785,_0x2dcf2d,_0x36853b['path'],_0x34f396,_0x5cd43d);else throw ht('Unknown\x20operation\x20type:\x20'+_0x36853b['type']);}}}const _0x4cd880=_0x5cd43d['getChanges']();return Au(_0x2dcf2d,_0x35d516,_0x4cd880),{'viewCache':_0x35d516,'changes':_0x4cd880};}function Au(_0x386d8e,_0x318239,_0x2f4225){const _0x1e137e=_0x318239['eventCache'];if(_0x1e137e['isFullyInitialized']()){const _0x3ca377=_0x1e137e['getNode']()['isLeafNode']()||_0x1e137e['getNode']()['isEmpty'](),_0x31bc6d=wn(_0x386d8e);(_0x2f4225['length']>0x0||!_0x386d8e['eventCache']['isFullyInitialized']()||_0x3ca377&&!_0x1e137e['getNode']()['equals'](_0x31bc6d)||!_0x1e137e['getNode']()['getPriority']()['equals'](_0x31bc6d['getPriority']()))&&_0x2f4225['push'](Lo(wn(_0x318239)));}}function Go(_0x372c75,_0x8d8ec4,_0x392218,_0x4f1aa8,_0x6bf929,_0x1e8433){const _0x17ce9d=_0x8d8ec4['eventCache'];if(Tn(_0x4f1aa8,_0x392218)!=null)return _0x8d8ec4;{let _0x225ec3,_0x1ceaa5;if(v(_0x392218)){if(f(_0x8d8ec4['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x8d8ec4['serverCache']['isFiltered']()){const _0x10e3ee=Ve(_0x8d8ec4),_0x10e456=_0x10e3ee instanceof g?_0x10e3ee:g['EMPTY_NODE'],_0xc04a07=is(_0x4f1aa8,_0x10e456);_0x225ec3=_0x372c75['filter']['updateFullNode'](_0x8d8ec4['eventCache']['getNode'](),_0xc04a07,_0x1e8433);}else{const _0x50a60f=Cn(_0x4f1aa8,Ve(_0x8d8ec4));_0x225ec3=_0x372c75['filter']['updateFullNode'](_0x8d8ec4['eventCache']['getNode'](),_0x50a60f,_0x1e8433);}}else{const _0x33fe66=y(_0x392218);if(_0x33fe66==='.priority'){f(Ce(_0x392218)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xb299b7=_0x17ce9d['getNode']();_0x1ceaa5=_0x8d8ec4['serverCache']['getNode']();const _0x4cd08f=cr(_0x4f1aa8,_0x392218,_0xb299b7,_0x1ceaa5);_0x4cd08f!=null?_0x225ec3=_0x372c75['filter']['updatePriority'](_0xb299b7,_0x4cd08f):_0x225ec3=_0x17ce9d['getNode']();}else{const _0x33f405=S(_0x392218);let _0x291644;if(_0x17ce9d['isCompleteForChild'](_0x33fe66)){_0x1ceaa5=_0x8d8ec4['serverCache']['getNode']();const _0x328d46=cr(_0x4f1aa8,_0x392218,_0x17ce9d['getNode'](),_0x1ceaa5);_0x328d46!=null?_0x291644=_0x17ce9d['getNode']()['getImmediateChild'](_0x33fe66)['updateChild'](_0x33f405,_0x328d46):_0x291644=_0x17ce9d['getNode']()['getImmediateChild'](_0x33fe66);}else _0x291644=ss(_0x4f1aa8,_0x33fe66,_0x8d8ec4['serverCache']);_0x291644!=null?_0x225ec3=_0x372c75['filter']['updateChild'](_0x17ce9d['getNode'](),_0x33fe66,_0x291644,_0x33f405,_0x6bf929,_0x1e8433):_0x225ec3=_0x17ce9d['getNode']();}}return Rt(_0x8d8ec4,_0x225ec3,_0x17ce9d['isFullyInitialized']()||v(_0x392218),_0x372c75['filter']['filtersNodes']());}}function Sn(_0x101bf8,_0xf32eee,_0x5b4d14,_0x25a49e,_0x2fb44e,_0x2d02ac,_0x4fa028,_0x417133){const _0x1a92ca=_0xf32eee['serverCache'];let _0x3a1094;const _0x56f287=_0x4fa028?_0x101bf8['filter']:_0x101bf8['filter']['getIndexedFilter']();if(v(_0x5b4d14))_0x3a1094=_0x56f287['updateFullNode'](_0x1a92ca['getNode'](),_0x25a49e,null);else{if(_0x56f287['filtersNodes']()&&!_0x1a92ca['isFiltered']()){const _0x5d27ff=_0x1a92ca['getNode']()['updateChild'](_0x5b4d14,_0x25a49e);_0x3a1094=_0x56f287['updateFullNode'](_0x1a92ca['getNode'](),_0x5d27ff,null);}else{const _0x2aad0b=y(_0x5b4d14);if(!_0x1a92ca['isCompleteForPath'](_0x5b4d14)&&Ce(_0x5b4d14)>0x1)return _0xf32eee;const _0x543589=S(_0x5b4d14),_0x54cf01=_0x1a92ca['getNode']()['getImmediateChild'](_0x2aad0b)['updateChild'](_0x543589,_0x25a49e);_0x2aad0b==='.priority'?_0x3a1094=_0x56f287['updatePriority'](_0x1a92ca['getNode'](),_0x54cf01):_0x3a1094=_0x56f287['updateChild'](_0x1a92ca['getNode'](),_0x2aad0b,_0x54cf01,_0x543589,$o,null);}}const _0x39abf6=Fo(_0xf32eee,_0x3a1094,_0x1a92ca['isFullyInitialized']()||v(_0x5b4d14),_0x56f287['filtersNodes']()),_0x221161=new rs(_0x2fb44e,_0x39abf6,_0x2d02ac);return Go(_0x101bf8,_0x39abf6,_0x5b4d14,_0x2fb44e,_0x221161,_0x417133);}function ki(_0x4e565a,_0x55b1a3,_0x2a2c02,_0xd7eeb4,_0x43a5b9,_0x35fad0,_0x1acccb){const _0x30615a=_0x55b1a3['eventCache'];let _0x5b24dc,_0x3c77f2;const _0x295e53=new rs(_0x43a5b9,_0x55b1a3,_0x35fad0);if(v(_0x2a2c02))_0x3c77f2=_0x4e565a['filter']['updateFullNode'](_0x55b1a3['eventCache']['getNode'](),_0xd7eeb4,_0x1acccb),_0x5b24dc=Rt(_0x55b1a3,_0x3c77f2,!0x0,_0x4e565a['filter']['filtersNodes']());else{const _0x29a51f=y(_0x2a2c02);if(_0x29a51f==='.priority')_0x3c77f2=_0x4e565a['filter']['updatePriority'](_0x55b1a3['eventCache']['getNode'](),_0xd7eeb4),_0x5b24dc=Rt(_0x55b1a3,_0x3c77f2,_0x30615a['isFullyInitialized'](),_0x30615a['isFiltered']());else{const _0x1cba53=S(_0x2a2c02),_0xda23ce=_0x30615a['getNode']()['getImmediateChild'](_0x29a51f);let _0x2e64ab;if(v(_0x1cba53))_0x2e64ab=_0xd7eeb4;else{const _0x4c5293=_0x295e53['getCompleteChild'](_0x29a51f);_0x4c5293!=null?ji(_0x1cba53)==='.priority'&&_0x4c5293['getChild'](Ro(_0x1cba53))['isEmpty']()?_0x2e64ab=_0x4c5293:_0x2e64ab=_0x4c5293['updateChild'](_0x1cba53,_0xd7eeb4):_0x2e64ab=g['EMPTY_NODE'];}if(_0xda23ce['equals'](_0x2e64ab))_0x5b24dc=_0x55b1a3;else{const _0x20a9e7=_0x4e565a['filter']['updateChild'](_0x30615a['getNode'](),_0x29a51f,_0x2e64ab,_0x1cba53,_0x295e53,_0x1acccb);_0x5b24dc=Rt(_0x55b1a3,_0x20a9e7,_0x30615a['isFullyInitialized'](),_0x4e565a['filter']['filtersNodes']());}}}return _0x5b24dc;}function lr(_0x177673,_0x2693f1){return _0x177673['eventCache']['isCompleteForChild'](_0x2693f1);}function ku(_0x3bd1ab,_0x3a922b,_0x5c8e40,_0xc5fdc,_0x5661c7,_0x10989b,_0x4c52f2){let _0x59978c=_0x3a922b;return _0xc5fdc['foreach']((_0x5260e2,_0x219928)=>{const _0x48e9e1=k(_0x5c8e40,_0x5260e2);lr(_0x3a922b,y(_0x48e9e1))&&(_0x59978c=ki(_0x3bd1ab,_0x59978c,_0x48e9e1,_0x219928,_0x5661c7,_0x10989b,_0x4c52f2));}),_0xc5fdc['foreach']((_0x2cc7f8,_0x11fe83)=>{const _0xb8e8ac=k(_0x5c8e40,_0x2cc7f8);lr(_0x3a922b,y(_0xb8e8ac))||(_0x59978c=ki(_0x3bd1ab,_0x59978c,_0xb8e8ac,_0x11fe83,_0x5661c7,_0x10989b,_0x4c52f2));}),_0x59978c;}function hr(_0x522887,_0x4baa38,_0x39d2fb){return _0x39d2fb['foreach']((_0x167bfb,_0x45501b)=>{_0x4baa38=_0x4baa38['updateChild'](_0x167bfb,_0x45501b);}),_0x4baa38;}function Pi(_0x147c67,_0xdc9906,_0x4389cf,_0x400abe,_0x480601,_0x3ba77e,_0x55ba58,_0x10f445){if(_0xdc9906['serverCache']['getNode']()['isEmpty']()&&!_0xdc9906['serverCache']['isFullyInitialized']())return _0xdc9906;let _0x345f67=_0xdc9906,_0x387b66;v(_0x4389cf)?_0x387b66=_0x400abe:_0x387b66=new b(null)['setTree'](_0x4389cf,_0x400abe);const _0x4a2072=_0xdc9906['serverCache']['getNode']();return _0x387b66['children']['inorderTraversal']((_0x563096,_0x571761)=>{if(_0x4a2072['hasChild'](_0x563096)){const _0x596dbd=_0xdc9906['serverCache']['getNode']()['getImmediateChild'](_0x563096),_0x1060cf=hr(_0x147c67,_0x596dbd,_0x571761);_0x345f67=Sn(_0x147c67,_0x345f67,new C(_0x563096),_0x1060cf,_0x480601,_0x3ba77e,_0x55ba58,_0x10f445);}}),_0x387b66['children']['inorderTraversal']((_0x134cd9,_0x439ce6)=>{const _0x43dd5e=!_0xdc9906['serverCache']['isCompleteForChild'](_0x134cd9)&&_0x439ce6['value']===null;if(!_0x4a2072['hasChild'](_0x134cd9)&&!_0x43dd5e){const _0x39f3fb=_0xdc9906['serverCache']['getNode']()['getImmediateChild'](_0x134cd9),_0x378aec=hr(_0x147c67,_0x39f3fb,_0x439ce6);_0x345f67=Sn(_0x147c67,_0x345f67,new C(_0x134cd9),_0x378aec,_0x480601,_0x3ba77e,_0x55ba58,_0x10f445);}}),_0x345f67;}function Pu(_0x12646b,_0x577037,_0x5807f0,_0x2b3804,_0x3fce57,_0x434cd6,_0x215332){if(Tn(_0x3fce57,_0x5807f0)!=null)return _0x577037;const _0x1af70c=_0x577037['serverCache']['isFiltered'](),_0x4a34b6=_0x577037['serverCache'];if(_0x2b3804['value']!=null){if(v(_0x5807f0)&&_0x4a34b6['isFullyInitialized']()||_0x4a34b6['isCompleteForPath'](_0x5807f0))return Sn(_0x12646b,_0x577037,_0x5807f0,_0x4a34b6['getNode']()['getChild'](_0x5807f0),_0x3fce57,_0x434cd6,_0x1af70c,_0x215332);if(v(_0x5807f0)){let _0x42e567=new b(null);return _0x4a34b6['getNode']()['forEachChild'](ve,(_0x3b0e80,_0x573a50)=>{_0x42e567=_0x42e567['set'](new C(_0x3b0e80),_0x573a50);}),Pi(_0x12646b,_0x577037,_0x5807f0,_0x42e567,_0x3fce57,_0x434cd6,_0x1af70c,_0x215332);}else return _0x577037;}else{let _0x41a90f=new b(null);return _0x2b3804['foreach']((_0x2f6703,_0xde2334)=>{const _0x1b501b=k(_0x5807f0,_0x2f6703);_0x4a34b6['isCompleteForPath'](_0x1b501b)&&(_0x41a90f=_0x41a90f['set'](_0x2f6703,_0x4a34b6['getNode']()['getChild'](_0x1b501b)));}),Pi(_0x12646b,_0x577037,_0x5807f0,_0x41a90f,_0x3fce57,_0x434cd6,_0x1af70c,_0x215332);}}function Nu(_0x4dd8e8,_0x46b8f2,_0x2ecfe3,_0x4daf48,_0x20cf22){const _0x26083a=_0x46b8f2['serverCache'],_0x1f35d7=Fo(_0x46b8f2,_0x26083a['getNode'](),_0x26083a['isFullyInitialized']()||v(_0x2ecfe3),_0x26083a['isFiltered']());return Go(_0x4dd8e8,_0x1f35d7,_0x2ecfe3,_0x4daf48,$o,_0x20cf22);}function Ou(_0x1e84ea,_0xa0bad4,_0x870d08,_0x4c5653,_0x471fc3,_0xf46d02){let _0x17f612;if(Tn(_0x4c5653,_0x870d08)!=null)return _0xa0bad4;{const _0xd8b714=new rs(_0x4c5653,_0xa0bad4,_0x471fc3),_0x54da19=_0xa0bad4['eventCache']['getNode']();let _0x1e64a2;if(v(_0x870d08)||y(_0x870d08)==='.priority'){let _0x5baa12;if(_0xa0bad4['serverCache']['isFullyInitialized']())_0x5baa12=Cn(_0x4c5653,Ve(_0xa0bad4));else{const _0x16b895=_0xa0bad4['serverCache']['getNode']();f(_0x16b895 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5baa12=is(_0x4c5653,_0x16b895);}_0x5baa12=_0x5baa12,_0x1e64a2=_0x1e84ea['filter']['updateFullNode'](_0x54da19,_0x5baa12,_0xf46d02);}else{const _0x367343=y(_0x870d08);let _0x301b06=ss(_0x4c5653,_0x367343,_0xa0bad4['serverCache']);_0x301b06==null&&_0xa0bad4['serverCache']['isCompleteForChild'](_0x367343)&&(_0x301b06=_0x54da19['getImmediateChild'](_0x367343)),_0x301b06!=null?_0x1e64a2=_0x1e84ea['filter']['updateChild'](_0x54da19,_0x367343,_0x301b06,S(_0x870d08),_0xd8b714,_0xf46d02):_0xa0bad4['eventCache']['getNode']()['hasChild'](_0x367343)?_0x1e64a2=_0x1e84ea['filter']['updateChild'](_0x54da19,_0x367343,g['EMPTY_NODE'],S(_0x870d08),_0xd8b714,_0xf46d02):_0x1e64a2=_0x54da19,_0x1e64a2['isEmpty']()&&_0xa0bad4['serverCache']['isFullyInitialized']()&&(_0x17f612=Cn(_0x4c5653,Ve(_0xa0bad4)),_0x17f612['isLeafNode']()&&(_0x1e64a2=_0x1e84ea['filter']['updateFullNode'](_0x1e64a2,_0x17f612,_0xf46d02)));}return _0x17f612=_0xa0bad4['serverCache']['isFullyInitialized']()||Tn(_0x4c5653,w())!=null,Rt(_0xa0bad4,_0x1e64a2,_0x17f612,_0x1e84ea['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x2eb5bd,_0x342b2e){this['query_']=_0x2eb5bd,this['eventRegistrations_']=[];const _0x270eed=this['query_']['_queryParams'],_0x3563f5=new Xi(_0x270eed['getIndex']()),_0x14ce47=Kh(_0x270eed);this['processor_']=Su(_0x14ce47);const _0x4ad5cf=_0x342b2e['serverCache'],_0x2bdf3c=_0x342b2e['eventCache'],_0x53796c=_0x3563f5['updateFullNode'](g['EMPTY_NODE'],_0x4ad5cf['getNode'](),null),_0x252514=_0x14ce47['updateFullNode'](g['EMPTY_NODE'],_0x2bdf3c['getNode'](),null),_0x53a814=new Te(_0x53796c,_0x4ad5cf['isFullyInitialized'](),_0x3563f5['filtersNodes']()),_0x4d093c=new Te(_0x252514,_0x2bdf3c['isFullyInitialized'](),_0x14ce47['filtersNodes']());this['viewCache_']=Un(_0x4d093c,_0x53a814),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x525083){return _0x525083['viewCache_']['serverCache']['getNode']();}function Lu(_0x4008fe){return wn(_0x4008fe['viewCache_']);}function xu(_0x41443b,_0x36c970){const _0x1f297f=Ve(_0x41443b['viewCache_']);return _0x1f297f&&(_0x41443b['query']['_queryParams']['loadsAllData']()||!v(_0x36c970)&&!_0x1f297f['getImmediateChild'](y(_0x36c970))['isEmpty']())?_0x1f297f['getChild'](_0x36c970):null;}function ur(_0x1791bf){return _0x1791bf['eventRegistrations_']['length']===0x0;}function Fu(_0x3f6c27,_0x14c5d1){_0x3f6c27['eventRegistrations_']['push'](_0x14c5d1);}function dr(_0x51f3b2,_0x5620b6,_0x1c292a){const _0x27dbe2=[];if(_0x1c292a){f(_0x5620b6==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1d5e7c=_0x51f3b2['query']['_path'];_0x51f3b2['eventRegistrations_']['forEach'](_0x550092=>{const _0x4983b2=_0x550092['createCancelEvent'](_0x1c292a,_0x1d5e7c);_0x4983b2&&_0x27dbe2['push'](_0x4983b2);});}if(_0x5620b6){let _0x3f5c18=[];for(let _0x5b2fdd=0x0;_0x5b2fdd<_0x51f3b2['eventRegistrations_']['length'];++_0x5b2fdd){const _0x412147=_0x51f3b2['eventRegistrations_'][_0x5b2fdd];if(!_0x412147['matches'](_0x5620b6))_0x3f5c18['push'](_0x412147);else{if(_0x5620b6['hasAnyCallback']()){_0x3f5c18=_0x3f5c18['concat'](_0x51f3b2['eventRegistrations_']['slice'](_0x5b2fdd+0x1));break;}}}_0x51f3b2['eventRegistrations_']=_0x3f5c18;}else _0x51f3b2['eventRegistrations_']=[];return _0x27dbe2;}function fr(_0x4eef50,_0x2116a7,_0x2ab700,_0x33eb45){_0x2116a7['type']===z['MERGE']&&_0x2116a7['source']['queryId']!==null&&(f(Ve(_0x4eef50['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x4eef50['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x282b03=_0x4eef50['viewCache_'],_0x267047=Ru(_0x4eef50['processor_'],_0x282b03,_0x2116a7,_0x2ab700,_0x33eb45);return bu(_0x4eef50['processor_'],_0x267047['viewCache']),f(_0x267047['viewCache']['serverCache']['isFullyInitialized']()||!_0x282b03['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4eef50['viewCache_']=_0x267047['viewCache'],qo(_0x4eef50,_0x267047['changes'],_0x267047['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x338f80,_0x10930b){const _0x2a5b0e=_0x338f80['viewCache_']['eventCache'],_0xb75328=[];return _0x2a5b0e['getNode']()['isLeafNode']()||_0x2a5b0e['getNode']()['forEachChild'](R,(_0x687709,_0x197f40)=>{_0xb75328['push'](rt(_0x687709,_0x197f40));}),_0x2a5b0e['isFullyInitialized']()&&_0xb75328['push'](Lo(_0x2a5b0e['getNode']())),qo(_0x338f80,_0xb75328,_0x2a5b0e['getNode'](),_0x10930b);}function qo(_0x1a2c50,_0x2c0135,_0x5f0bc7,_0x4fcd6b){const _0xc4e7ba=_0x4fcd6b?[_0x4fcd6b]:_0x1a2c50['eventRegistrations_'];return ru(_0x1a2c50['eventGenerator_'],_0x2c0135,_0x5f0bc7,_0xc4e7ba);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x35fcf9){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x35fcf9;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5c3f65){return _0x5c3f65['views']['size']===0x0;}function os(_0x52d1b8,_0x81dd1f,_0x3f684a,_0x38a3fb){const _0x5db419=_0x81dd1f['source']['queryId'];if(_0x5db419!==null){const _0x53fa9c=_0x52d1b8['views']['get'](_0x5db419);return f(_0x53fa9c!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x53fa9c,_0x81dd1f,_0x3f684a,_0x38a3fb);}else{let _0x448525=[];for(const _0x3e5820 of _0x52d1b8['views']['values']())_0x448525=_0x448525['concat'](fr(_0x3e5820,_0x81dd1f,_0x3f684a,_0x38a3fb));return _0x448525;}}function jo(_0x3ac684,_0x2e4fca,_0x1d6e50,_0x462a4f,_0x1975f7){const _0x454851=_0x2e4fca['_queryIdentifier'],_0x119bdb=_0x3ac684['views']['get'](_0x454851);if(!_0x119bdb){let _0x4144a6=Cn(_0x1d6e50,_0x1975f7?_0x462a4f:null),_0x4d2a41=!0x1;_0x4144a6?_0x4d2a41=!0x0:_0x462a4f instanceof g?(_0x4144a6=is(_0x1d6e50,_0x462a4f),_0x4d2a41=!0x1):(_0x4144a6=g['EMPTY_NODE'],_0x4d2a41=!0x1);const _0x3b79da=Un(new Te(_0x4144a6,_0x4d2a41,!0x1),new Te(_0x462a4f,_0x1975f7,!0x1));return new Du(_0x2e4fca,_0x3b79da);}return _0x119bdb;}function Hu(_0x30175c,_0xac4c84,_0x4bca39,_0x1524c8,_0x3229b8,_0x168f75){const _0xcb0554=jo(_0x30175c,_0xac4c84,_0x1524c8,_0x3229b8,_0x168f75);return _0x30175c['views']['has'](_0xac4c84['_queryIdentifier'])||_0x30175c['views']['set'](_0xac4c84['_queryIdentifier'],_0xcb0554),Fu(_0xcb0554,_0x4bca39),Uu(_0xcb0554,_0x4bca39);}function $u(_0x385655,_0x1a41b5,_0x484cce,_0x278041){const _0x41cb0d=_0x1a41b5['_queryIdentifier'],_0x3eb14e=[];let _0x15bbcc=[];const _0x3b0f36=Se(_0x385655);if(_0x41cb0d==='default'){for(const [_0x58c890,_0x22b6e7]of _0x385655['views']['entries']())_0x15bbcc=_0x15bbcc['concat'](dr(_0x22b6e7,_0x484cce,_0x278041)),ur(_0x22b6e7)&&(_0x385655['views']['delete'](_0x58c890),_0x22b6e7['query']['_queryParams']['loadsAllData']()||_0x3eb14e['push'](_0x22b6e7['query']));}else{const _0x21f945=_0x385655['views']['get'](_0x41cb0d);_0x21f945&&(_0x15bbcc=_0x15bbcc['concat'](dr(_0x21f945,_0x484cce,_0x278041)),ur(_0x21f945)&&(_0x385655['views']['delete'](_0x41cb0d),_0x21f945['query']['_queryParams']['loadsAllData']()||_0x3eb14e['push'](_0x21f945['query'])));}return _0x3b0f36&&!Se(_0x385655)&&_0x3eb14e['push'](new(Bu())(_0x1a41b5['_repo'],_0x1a41b5['_path'])),{'removed':_0x3eb14e,'events':_0x15bbcc};}function Ko(_0x5384a9){const _0x54b68f=[];for(const _0x22205d of _0x5384a9['views']['values']())_0x22205d['query']['_queryParams']['loadsAllData']()||_0x54b68f['push'](_0x22205d);return _0x54b68f;}function Ie(_0x1628ce,_0x2a300c){let _0x33eca2=null;for(const _0x23d983 of _0x1628ce['views']['values']())_0x33eca2=_0x33eca2||xu(_0x23d983,_0x2a300c);return _0x33eca2;}function Yo(_0x21b84c,_0x3a20f0){if(_0x3a20f0['_queryParams']['loadsAllData']())return Bn(_0x21b84c);{const _0x539397=_0x3a20f0['_queryIdentifier'];return _0x21b84c['views']['get'](_0x539397);}}function Qo(_0x985891,_0x44e9cd){return Yo(_0x985891,_0x44e9cd)!=null;}function Se(_0x3e4718){return Bn(_0x3e4718)!=null;}function Bn(_0x1bbeab){for(const _0x368365 of _0x1bbeab['views']['values']())if(_0x368365['query']['_queryParams']['loadsAllData']())return _0x368365;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xe1f4f1){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xe1f4f1;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xa48a9b){this['listenProvider_']=_0xa48a9b,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x203f29,_0x38792a,_0x1bebd1,_0x293e63,_0xea37d3){return lu(_0x203f29['pendingWriteTree_'],_0x38792a,_0x1bebd1,_0x293e63,_0xea37d3),_0xea37d3?_t(_0x203f29,new Be(es(),_0x38792a,_0x1bebd1)):[];}function ju(_0x2a4994,_0x2b3380,_0x578333,_0x3bfe0b){hu(_0x2a4994['pendingWriteTree_'],_0x2b3380,_0x578333,_0x3bfe0b);const _0x2b10a0=b['fromObject'](_0x578333);return _t(_0x2a4994,new ot(es(),_0x2b3380,_0x2b10a0));}function _e(_0x33d211,_0x23fac7,_0x2323fe=!0x1){const _0x400573=uu(_0x33d211['pendingWriteTree_'],_0x23fac7);if(du(_0x33d211['pendingWriteTree_'],_0x23fac7)){let _0xa1e822=new b(null);return _0x400573['snap']!=null?_0xa1e822=_0xa1e822['set'](w(),!0x0):x(_0x400573['children'],_0x55f6ad=>{_0xa1e822=_0xa1e822['set'](new C(_0x55f6ad),!0x0);}),_t(_0x33d211,new In(_0x400573['path'],_0xa1e822,_0x2323fe));}else return[];}function Yt(_0x1cfc0a,_0x27fafe,_0xf9b5f4){return _t(_0x1cfc0a,new Be(ts(),_0x27fafe,_0xf9b5f4));}function Ku(_0x4dc4ed,_0x49986e,_0x17f0e9){const _0x406936=b['fromObject'](_0x17f0e9);return _t(_0x4dc4ed,new ot(ts(),_0x49986e,_0x406936));}function Yu(_0x52a268,_0x2884ff){return _t(_0x52a268,new Ut(ts(),_0x2884ff));}function Qu(_0x316b3b,_0x46bdb9,_0x31f01c){const _0x4b915f=cs(_0x316b3b,_0x31f01c);if(_0x4b915f){const _0x59f324=ls(_0x4b915f),_0xdcb3c8=_0x59f324['path'],_0x211d0d=_0x59f324['queryId'],_0x464bd0=F(_0xdcb3c8,_0x46bdb9),_0x37f36f=new Ut(ns(_0x211d0d),_0x464bd0);return hs(_0x316b3b,_0xdcb3c8,_0x37f36f);}else return[];}function An(_0x37abf4,_0x5cbea7,_0x34c181,_0x53d9ce,_0x2d1c25=!0x1){const _0xb91102=_0x5cbea7['_path'],_0x45995e=_0x37abf4['syncPointTree_']['get'](_0xb91102);let _0x43c9d1=[];if(_0x45995e&&(_0x5cbea7['_queryIdentifier']==='default'||Qo(_0x45995e,_0x5cbea7))){const _0x1ff4ef=$u(_0x45995e,_0x5cbea7,_0x34c181,_0x53d9ce);Vu(_0x45995e)&&(_0x37abf4['syncPointTree_']=_0x37abf4['syncPointTree_']['remove'](_0xb91102));const _0x1560cd=_0x1ff4ef['removed'];if(_0x43c9d1=_0x1ff4ef['events'],!_0x2d1c25){const _0x1d61e0=_0x1560cd['findIndex'](_0x1738be=>_0x1738be['_queryParams']['loadsAllData']())!==-0x1,_0x29bba3=_0x37abf4['syncPointTree_']['findOnPath'](_0xb91102,(_0x59536f,_0x91d08e)=>Se(_0x91d08e));if(_0x1d61e0&&!_0x29bba3){const _0x50fa70=_0x37abf4['syncPointTree_']['subtree'](_0xb91102);if(!_0x50fa70['isEmpty']()){const _0x41bf78=Zu(_0x50fa70);for(let _0x567ed8=0x0;_0x567ed8<_0x41bf78['length'];++_0x567ed8){const _0x6660ed=_0x41bf78[_0x567ed8],_0x200795=_0x6660ed['query'],_0x601d69=ea(_0x37abf4,_0x6660ed);_0x37abf4['listenProvider_']['startListening'](kt(_0x200795),Wt(_0x37abf4,_0x200795),_0x601d69['hashFn'],_0x601d69['onComplete']);}}}!_0x29bba3&&_0x1560cd['length']>0x0&&!_0x53d9ce&&(_0x1d61e0?_0x37abf4['listenProvider_']['stopListening'](kt(_0x5cbea7),null):_0x1560cd['forEach'](_0x550e83=>{const _0x93fb87=_0x37abf4['queryToTagMap']['get'](Hn(_0x550e83));_0x37abf4['listenProvider_']['stopListening'](kt(_0x550e83),_0x93fb87);}));}ed(_0x37abf4,_0x1560cd);}return _0x43c9d1;}function Jo(_0x73c7e7,_0x2da81c,_0x31fdfb,_0x4e4d91){const _0x1b3044=cs(_0x73c7e7,_0x4e4d91);if(_0x1b3044!=null){const _0x9ec334=ls(_0x1b3044),_0x4ffed3=_0x9ec334['path'],_0x22aace=_0x9ec334['queryId'],_0x1faaa=F(_0x4ffed3,_0x2da81c),_0x46bca9=new Be(ns(_0x22aace),_0x1faaa,_0x31fdfb);return hs(_0x73c7e7,_0x4ffed3,_0x46bca9);}else return[];}function Ju(_0x31baf0,_0x8cca8c,_0x337821,_0x769b53){const _0x538f96=cs(_0x31baf0,_0x769b53);if(_0x538f96){const _0xfd7f8f=ls(_0x538f96),_0x204943=_0xfd7f8f['path'],_0x21061b=_0xfd7f8f['queryId'],_0x2e0a92=F(_0x204943,_0x8cca8c),_0x539d85=b['fromObject'](_0x337821),_0x5b979c=new ot(ns(_0x21061b),_0x2e0a92,_0x539d85);return hs(_0x31baf0,_0x204943,_0x5b979c);}else return[];}function Ni(_0x2828b4,_0x9a3b0d,_0xc6e46d,_0x3b5e09=!0x1){const _0x139bb3=_0x9a3b0d['_path'];let _0x2dcb9f=null,_0x5f0fc8=!0x1;_0x2828b4['syncPointTree_']['foreachOnPath'](_0x139bb3,(_0x4782ea,_0xe1173f)=>{const _0x442eff=F(_0x4782ea,_0x139bb3);_0x2dcb9f=_0x2dcb9f||Ie(_0xe1173f,_0x442eff),_0x5f0fc8=_0x5f0fc8||Se(_0xe1173f);});let _0x258e0c=_0x2828b4['syncPointTree_']['get'](_0x139bb3);_0x258e0c?(_0x5f0fc8=_0x5f0fc8||Se(_0x258e0c),_0x2dcb9f=_0x2dcb9f||Ie(_0x258e0c,w())):(_0x258e0c=new zo(),_0x2828b4['syncPointTree_']=_0x2828b4['syncPointTree_']['set'](_0x139bb3,_0x258e0c));let _0x4e5dff;_0x2dcb9f!=null?_0x4e5dff=!0x0:(_0x4e5dff=!0x1,_0x2dcb9f=g['EMPTY_NODE'],_0x2828b4['syncPointTree_']['subtree'](_0x139bb3)['foreachChild']((_0x1a98fe,_0x48cffc)=>{const _0x5082a9=Ie(_0x48cffc,w());_0x5082a9&&(_0x2dcb9f=_0x2dcb9f['updateImmediateChild'](_0x1a98fe,_0x5082a9));}));const _0x410920=Qo(_0x258e0c,_0x9a3b0d);if(!_0x410920&&!_0x9a3b0d['_queryParams']['loadsAllData']()){const _0x401d25=Hn(_0x9a3b0d);f(!_0x2828b4['queryToTagMap']['has'](_0x401d25),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xe88fcf=td();_0x2828b4['queryToTagMap']['set'](_0x401d25,_0xe88fcf),_0x2828b4['tagToQueryMap']['set'](_0xe88fcf,_0x401d25);}const _0x1a2483=Wn(_0x2828b4['pendingWriteTree_'],_0x139bb3);let _0x32935b=Hu(_0x258e0c,_0x9a3b0d,_0xc6e46d,_0x1a2483,_0x2dcb9f,_0x4e5dff);if(!_0x410920&&!_0x5f0fc8&&!_0x3b5e09){const _0x298b1f=Yo(_0x258e0c,_0x9a3b0d);_0x32935b=_0x32935b['concat'](nd(_0x2828b4,_0x9a3b0d,_0x298b1f));}return _0x32935b;}function Vn(_0x3c81ce,_0x33a49,_0x520680){const _0x413310=_0x3c81ce['pendingWriteTree_'],_0xa10f57=_0x3c81ce['syncPointTree_']['findOnPath'](_0x33a49,(_0x95631c,_0x3ad4ba)=>{const _0x4bc9f7=F(_0x95631c,_0x33a49),_0x91e240=Ie(_0x3ad4ba,_0x4bc9f7);if(_0x91e240)return _0x91e240;});return Bo(_0x413310,_0x33a49,_0xa10f57,_0x520680,!0x0);}function Xu(_0xfee7c6,_0x48a68c){const _0x588b92=_0x48a68c['_path'];let _0x57cb45=null;_0xfee7c6['syncPointTree_']['foreachOnPath'](_0x588b92,(_0x3a99bb,_0x5947ca)=>{const _0xf53f44=F(_0x3a99bb,_0x588b92);_0x57cb45=_0x57cb45||Ie(_0x5947ca,_0xf53f44);});let _0x31ed16=_0xfee7c6['syncPointTree_']['get'](_0x588b92);_0x31ed16?_0x57cb45=_0x57cb45||Ie(_0x31ed16,w()):(_0x31ed16=new zo(),_0xfee7c6['syncPointTree_']=_0xfee7c6['syncPointTree_']['set'](_0x588b92,_0x31ed16));const _0x1b921c=_0x57cb45!=null,_0x2712a1=_0x1b921c?new Te(_0x57cb45,!0x0,!0x1):null,_0x224e79=Wn(_0xfee7c6['pendingWriteTree_'],_0x48a68c['_path']),_0x3bf850=jo(_0x31ed16,_0x48a68c,_0x224e79,_0x1b921c?_0x2712a1['getNode']():g['EMPTY_NODE'],_0x1b921c);return Lu(_0x3bf850);}function _t(_0x416aa7,_0x4f11b5){return Xo(_0x4f11b5,_0x416aa7['syncPointTree_'],null,Wn(_0x416aa7['pendingWriteTree_'],w()));}function Xo(_0x7e4a9f,_0x8c5e75,_0x3312ca,_0x7fda24){if(v(_0x7e4a9f['path']))return Zo(_0x7e4a9f,_0x8c5e75,_0x3312ca,_0x7fda24);{const _0x2ff778=_0x8c5e75['get'](w());_0x3312ca==null&&_0x2ff778!=null&&(_0x3312ca=Ie(_0x2ff778,w()));let _0x37f235=[];const _0x38e1ec=y(_0x7e4a9f['path']),_0x2b84f5=_0x7e4a9f['operationForChild'](_0x38e1ec),_0x412da6=_0x8c5e75['children']['get'](_0x38e1ec);if(_0x412da6&&_0x2b84f5){const _0x5133d8=_0x3312ca?_0x3312ca['getImmediateChild'](_0x38e1ec):null,_0x3ba847=Vo(_0x7fda24,_0x38e1ec);_0x37f235=_0x37f235['concat'](Xo(_0x2b84f5,_0x412da6,_0x5133d8,_0x3ba847));}return _0x2ff778&&(_0x37f235=_0x37f235['concat'](os(_0x2ff778,_0x7e4a9f,_0x7fda24,_0x3312ca))),_0x37f235;}}function Zo(_0x2aefde,_0x3efe73,_0x46ca40,_0x418b61){const _0x719bbc=_0x3efe73['get'](w());_0x46ca40==null&&_0x719bbc!=null&&(_0x46ca40=Ie(_0x719bbc,w()));let _0x53a768=[];return _0x3efe73['children']['inorderTraversal']((_0x502be9,_0x1caf1e)=>{const _0x5d397e=_0x46ca40?_0x46ca40['getImmediateChild'](_0x502be9):null,_0x1bcdcf=Vo(_0x418b61,_0x502be9),_0x4f16ff=_0x2aefde['operationForChild'](_0x502be9);_0x4f16ff&&(_0x53a768=_0x53a768['concat'](Zo(_0x4f16ff,_0x1caf1e,_0x5d397e,_0x1bcdcf)));}),_0x719bbc&&(_0x53a768=_0x53a768['concat'](os(_0x719bbc,_0x2aefde,_0x418b61,_0x46ca40))),_0x53a768;}function ea(_0x5a8534,_0x479d33){const _0x1f204e=_0x479d33['query'],_0x5dc981=Wt(_0x5a8534,_0x1f204e);return{'hashFn':()=>(Mu(_0x479d33)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x412dd2=>{if(_0x412dd2==='ok')return _0x5dc981?Qu(_0x5a8534,_0x1f204e['_path'],_0x5dc981):Yu(_0x5a8534,_0x1f204e['_path']);{const _0x120972=Kl(_0x412dd2,_0x1f204e);return An(_0x5a8534,_0x1f204e,null,_0x120972);}}};}function Wt(_0xe8aa4e,_0x25f218){const _0x1b18ab=Hn(_0x25f218);return _0xe8aa4e['queryToTagMap']['get'](_0x1b18ab);}function Hn(_0x1101ed){return _0x1101ed['_path']['toString']()+'$'+_0x1101ed['_queryIdentifier'];}function cs(_0x45cfdd,_0x52a564){return _0x45cfdd['tagToQueryMap']['get'](_0x52a564);}function ls(_0x2ed72a){const _0x37c5b8=_0x2ed72a['indexOf']('$');return f(_0x37c5b8!==-0x1&&_0x37c5b8<_0x2ed72a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2ed72a['substr'](_0x37c5b8+0x1),'path':new C(_0x2ed72a['substr'](0x0,_0x37c5b8))};}function hs(_0x3f13a6,_0xfa8ad6,_0x27bd8a){const _0x34cb15=_0x3f13a6['syncPointTree_']['get'](_0xfa8ad6);f(_0x34cb15,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x333f70=Wn(_0x3f13a6['pendingWriteTree_'],_0xfa8ad6);return os(_0x34cb15,_0x27bd8a,_0x333f70,null);}function Zu(_0x3371e2){return _0x3371e2['fold']((_0x85b60e,_0x14211e,_0x150d4e)=>{if(_0x14211e&&Se(_0x14211e))return[Bn(_0x14211e)];{let _0x1e6c89=[];return _0x14211e&&(_0x1e6c89=Ko(_0x14211e)),x(_0x150d4e,(_0x91cacc,_0x2fff14)=>{_0x1e6c89=_0x1e6c89['concat'](_0x2fff14);}),_0x1e6c89;}});}function kt(_0x5b168d){return _0x5b168d['_queryParams']['loadsAllData']()&&!_0x5b168d['_queryParams']['isDefault']()?new(qu())(_0x5b168d['_repo'],_0x5b168d['_path']):_0x5b168d;}function ed(_0x3bb9cb,_0x10b43f){for(let _0x5c2ab3=0x0;_0x5c2ab3<_0x10b43f['length'];++_0x5c2ab3){const _0x345c3f=_0x10b43f[_0x5c2ab3];if(!_0x345c3f['_queryParams']['loadsAllData']()){const _0x35ea15=Hn(_0x345c3f),_0x2092d5=_0x3bb9cb['queryToTagMap']['get'](_0x35ea15);_0x3bb9cb['queryToTagMap']['delete'](_0x35ea15),_0x3bb9cb['tagToQueryMap']['delete'](_0x2092d5);}}}function td(){return zu++;}function nd(_0x3e963b,_0x4f0678,_0x2d0ddb){const _0x4427ca=_0x4f0678['_path'],_0x2bf8e6=Wt(_0x3e963b,_0x4f0678),_0x170b5e=ea(_0x3e963b,_0x2d0ddb),_0x2efed6=_0x3e963b['listenProvider_']['startListening'](kt(_0x4f0678),_0x2bf8e6,_0x170b5e['hashFn'],_0x170b5e['onComplete']),_0x1614b3=_0x3e963b['syncPointTree_']['subtree'](_0x4427ca);if(_0x2bf8e6)f(!Se(_0x1614b3['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x170578=_0x1614b3['fold']((_0x1d6eb5,_0x253042,_0x2cc5d7)=>{if(!v(_0x1d6eb5)&&_0x253042&&Se(_0x253042))return[Bn(_0x253042)['query']];{let _0x29d162=[];return _0x253042&&(_0x29d162=_0x29d162['concat'](Ko(_0x253042)['map'](_0x314c0d=>_0x314c0d['query']))),x(_0x2cc5d7,(_0x229166,_0x4d9a88)=>{_0x29d162=_0x29d162['concat'](_0x4d9a88);}),_0x29d162;}});for(let _0xa803b0=0x0;_0xa803b0<_0x170578['length'];++_0xa803b0){const _0x212a24=_0x170578[_0xa803b0];_0x3e963b['listenProvider_']['stopListening'](kt(_0x212a24),Wt(_0x3e963b,_0x212a24));}}return _0x2efed6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x28348d){this['node_']=_0x28348d;}['getImmediateChild'](_0x83b5fb){const _0x517513=this['node_']['getImmediateChild'](_0x83b5fb);return new us(_0x517513);}['node'](){return this['node_'];}}class ds{constructor(_0x262690,_0x4a94c6){this['syncTree_']=_0x262690,this['path_']=_0x4a94c6;}['getImmediateChild'](_0x642819){const _0x1c69e8=k(this['path_'],_0x642819);return new ds(this['syncTree_'],_0x1c69e8);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x288091){return _0x288091=_0x288091||{},_0x288091['timestamp']=_0x288091['timestamp']||new Date()['getTime'](),_0x288091;},_r=function(_0xa7cc8,_0x16d69c,_0x416756){if(!_0xa7cc8||typeof _0xa7cc8!='object')return _0xa7cc8;if(f('.sv'in _0xa7cc8,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xa7cc8['.sv']=='string')return sd(_0xa7cc8['.sv'],_0x16d69c,_0x416756);if(typeof _0xa7cc8['.sv']=='object')return rd(_0xa7cc8['.sv'],_0x16d69c);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xa7cc8,null,0x2));},sd=function(_0x1af426,_0x4fa7e4,_0x12ece6){switch(_0x1af426){case'timestamp':return _0x12ece6['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1af426);}},rd=function(_0x41f22f,_0xd36bfa,_0x561c98){_0x41f22f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x41f22f,null,0x2));const _0x5616a6=_0x41f22f['increment'];typeof _0x5616a6!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5616a6);const _0x5e5314=_0xd36bfa['node']();if(f(_0x5e5314!==null&&typeof _0x5e5314<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5e5314['isLeafNode']())return _0x5616a6;const _0x2c7fc9=_0x5e5314['getValue']();return typeof _0x2c7fc9!='number'?_0x5616a6:_0x2c7fc9+_0x5616a6;},ta=function(_0x1a83dd,_0x39be53,_0x28e6c7,_0x32681e){return ps(_0x39be53,new ds(_0x28e6c7,_0x1a83dd),_0x32681e);},fs=function(_0x247ac9,_0xf05902,_0x21a410){return ps(_0x247ac9,new us(_0xf05902),_0x21a410);};function ps(_0x236292,_0x951a3f,_0x40d390){const _0x2ef53c=_0x236292['getPriority']()['val'](),_0x663597=_r(_0x2ef53c,_0x951a3f['getImmediateChild']('.priority'),_0x40d390);let _0x462013;if(_0x236292['isLeafNode']()){const _0x5cce26=_0x236292,_0x4078b2=_r(_0x5cce26['getValue'](),_0x951a3f,_0x40d390);return _0x4078b2!==_0x5cce26['getValue']()||_0x663597!==_0x5cce26['getPriority']()['val']()?new D(_0x4078b2,A(_0x663597)):_0x236292;}else{const _0x19cd7b=_0x236292;return _0x462013=_0x19cd7b,_0x663597!==_0x19cd7b['getPriority']()['val']()&&(_0x462013=_0x462013['updatePriority'](new D(_0x663597))),_0x19cd7b['forEachChild'](R,(_0x5d649d,_0x3230ef)=>{const _0x218f2a=ps(_0x3230ef,_0x951a3f['getImmediateChild'](_0x5d649d),_0x40d390);_0x218f2a!==_0x3230ef&&(_0x462013=_0x462013['updateImmediateChild'](_0x5d649d,_0x218f2a));}),_0x462013;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x1cf932='',_0x17a11e=null,_0x5115f1={'children':{},'childCount':0x0}){this['name']=_0x1cf932,this['parent']=_0x17a11e,this['node']=_0x5115f1;}}function $n(_0x4963a7,_0x172e4a){let _0x5f206c=_0x172e4a instanceof C?_0x172e4a:new C(_0x172e4a),_0x3026ce=_0x4963a7,_0x46b4b3=y(_0x5f206c);for(;_0x46b4b3!==null;){const _0x2cdec2=Le(_0x3026ce['node']['children'],_0x46b4b3)||{'children':{},'childCount':0x0};_0x3026ce=new _s(_0x46b4b3,_0x3026ce,_0x2cdec2),_0x5f206c=S(_0x5f206c),_0x46b4b3=y(_0x5f206c);}return _0x3026ce;}function je(_0x26c073){return _0x26c073['node']['value'];}function gs(_0x5f5cf3,_0x374671){_0x5f5cf3['node']['value']=_0x374671,Oi(_0x5f5cf3);}function na(_0x4595e2){return _0x4595e2['node']['childCount']>0x0;}function od(_0x389d22){return je(_0x389d22)===void 0x0&&!na(_0x389d22);}function Gn(_0x43b157,_0x42f86f){x(_0x43b157['node']['children'],(_0x269807,_0x227530)=>{_0x42f86f(new _s(_0x269807,_0x43b157,_0x227530));});}function ia(_0x32678d,_0x55cb3a,_0x97b180,_0x2c3887){_0x97b180&&_0x55cb3a(_0x32678d),Gn(_0x32678d,_0x58ef11=>{ia(_0x58ef11,_0x55cb3a,!0x0);});}function ad(_0xbe34b0,_0x429a5a,_0x4805cf){let _0x13d052=_0xbe34b0['parent'];for(;_0x13d052!==null;){if(_0x429a5a(_0x13d052))return!0x0;_0x13d052=_0x13d052['parent'];}return!0x1;}function Qt(_0xc079e1){return new C(_0xc079e1['parent']===null?_0xc079e1['name']:Qt(_0xc079e1['parent'])+'/'+_0xc079e1['name']);}function Oi(_0x47f245){_0x47f245['parent']!==null&&cd(_0x47f245['parent'],_0x47f245['name'],_0x47f245);}function cd(_0x1587e2,_0x5c85e8,_0x539865){const _0xd9be8e=od(_0x539865),_0x432610=Q(_0x1587e2['node']['children'],_0x5c85e8);_0xd9be8e&&_0x432610?(delete _0x1587e2['node']['children'][_0x5c85e8],_0x1587e2['node']['childCount']--,Oi(_0x1587e2)):!_0xd9be8e&&!_0x432610&&(_0x1587e2['node']['children'][_0x5c85e8]=_0x539865['node'],_0x1587e2['node']['childCount']++,Oi(_0x1587e2));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3d2cc3){return typeof _0x3d2cc3=='string'&&_0x3d2cc3['length']!==0x0&&!ld['test'](_0x3d2cc3);},sa=function(_0x261eca){return typeof _0x261eca=='string'&&_0x261eca['length']!==0x0&&!hd['test'](_0x261eca);},ud=function(_0xf83587){return _0xf83587&&(_0xf83587=_0xf83587['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xf83587);},Bt=function(_0xbcd8c5){return _0xbcd8c5===null||typeof _0xbcd8c5=='string'||typeof _0xbcd8c5=='number'&&!xn(_0xbcd8c5)||_0xbcd8c5&&typeof _0xbcd8c5=='object'&&Q(_0xbcd8c5,'.sv');},He=function(_0x3ec5be,_0x536690,_0x10534a,_0x575869){_0x575869&&_0x536690===void 0x0||Jt(it(_0x3ec5be,'value'),_0x536690,_0x10534a);},Jt=function(_0x5d9539,_0x5c513a,_0x4527c1){const _0x5ba30d=_0x4527c1 instanceof C?new Ah(_0x4527c1,_0x5d9539):_0x4527c1;if(_0x5c513a===void 0x0)throw new Error(_0x5d9539+'contains\x20undefined\x20'+Oe(_0x5ba30d));if(typeof _0x5c513a=='function')throw new Error(_0x5d9539+'contains\x20a\x20function\x20'+Oe(_0x5ba30d)+'\x20with\x20contents\x20=\x20'+_0x5c513a['toString']());if(xn(_0x5c513a))throw new Error(_0x5d9539+'contains\x20'+_0x5c513a['toString']()+'\x20'+Oe(_0x5ba30d));if(typeof _0x5c513a=='string'&&_0x5c513a['length']>ui/0x3&&Ln(_0x5c513a)>ui)throw new Error(_0x5d9539+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x5ba30d)+'\x20(\x27'+_0x5c513a['substring'](0x0,0x32)+'...\x27)');if(_0x5c513a&&typeof _0x5c513a=='object'){let _0x7b2234=!0x1,_0x361b3e=!0x1;if(x(_0x5c513a,(_0xcd0aa3,_0x65cf87)=>{if(_0xcd0aa3==='.value')_0x7b2234=!0x0;else{if(_0xcd0aa3!=='.priority'&&_0xcd0aa3!=='.sv'&&(_0x361b3e=!0x0,!ms(_0xcd0aa3)))throw new Error(_0x5d9539+'\x20contains\x20an\x20invalid\x20key\x20('+_0xcd0aa3+')\x20'+Oe(_0x5ba30d)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5ba30d,_0xcd0aa3),Jt(_0x5d9539,_0x65cf87,_0x5ba30d),Ph(_0x5ba30d);}),_0x7b2234&&_0x361b3e)throw new Error(_0x5d9539+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x5ba30d)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x541579,_0x45b388){let _0x574bd5,_0x5ae29d;for(_0x574bd5=0x0;_0x574bd5<_0x45b388['length'];_0x574bd5++){_0x5ae29d=_0x45b388[_0x574bd5];const _0x13ce1c=Mt(_0x5ae29d);for(let _0x475b9f=0x0;_0x475b9f<_0x13ce1c['length'];_0x475b9f++)if(!(_0x13ce1c[_0x475b9f]==='.priority'&&_0x475b9f===_0x13ce1c['length']-0x1)){if(!ms(_0x13ce1c[_0x475b9f]))throw new Error(_0x541579+'contains\x20an\x20invalid\x20key\x20('+_0x13ce1c[_0x475b9f]+')\x20in\x20path\x20'+_0x5ae29d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x45b388['sort'](Rh);let _0x2e1b59=null;for(_0x574bd5=0x0;_0x574bd5<_0x45b388['length'];_0x574bd5++){if(_0x5ae29d=_0x45b388[_0x574bd5],_0x2e1b59!==null&&G(_0x2e1b59,_0x5ae29d))throw new Error(_0x541579+'contains\x20a\x20path\x20'+_0x2e1b59['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5ae29d['toString']());_0x2e1b59=_0x5ae29d;}},ra=function(_0x37f2e9,_0x3c8ce1,_0x47da19,_0x5e36e0){const _0x161f57=it(_0x37f2e9,'values');if(!(_0x3c8ce1&&typeof _0x3c8ce1=='object')||Array['isArray'](_0x3c8ce1))throw new Error(_0x161f57+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5c099e=[];x(_0x3c8ce1,(_0x585b9b,_0x56457d)=>{const _0x7f02a3=new C(_0x585b9b);if(Jt(_0x161f57,_0x56457d,k(_0x47da19,_0x7f02a3)),ji(_0x7f02a3)==='.priority'&&!Bt(_0x56457d))throw new Error(_0x161f57+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x7f02a3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5c099e['push'](_0x7f02a3);}),dd(_0x161f57,_0x5c099e);},fd=function(_0x545ca0,_0x5cf364,_0x402a84){if(xn(_0x5cf364))throw new Error(it(_0x545ca0,'priority')+'is\x20'+_0x5cf364['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x5cf364))throw new Error(it(_0x545ca0,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x23d1e8,_0x437fa8,_0x29a4e9,_0x2b7f49){if(!sa(_0x29a4e9))throw new Error(it(_0x23d1e8,_0x437fa8)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x29a4e9+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x22829e,_0x387057,_0xfb33dc,_0x4448a4){_0xfb33dc&&(_0xfb33dc=_0xfb33dc['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x22829e,_0x387057,_0xfb33dc);},Me=function(_0xe3cd52,_0x5adcf7){if(y(_0x5adcf7)==='.info')throw new Error(_0xe3cd52+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x36d535,_0x2d8c83){const _0x4d495f=_0x2d8c83['path']['toString']();if(typeof _0x2d8c83['repoInfo']['host']!='string'||_0x2d8c83['repoInfo']['host']['length']===0x0||!ms(_0x2d8c83['repoInfo']['namespace'])&&_0x2d8c83['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4d495f['length']!==0x0&&!ud(_0x4d495f))throw new Error(it(_0x36d535,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3b306c,_0x3512be){let _0x33bc6e=null;for(let _0x33802b=0x0;_0x33802b<_0x3512be['length'];_0x33802b++){const _0x2daab2=_0x3512be[_0x33802b],_0x4ff4f5=_0x2daab2['getPath']();_0x33bc6e!==null&&!Ki(_0x4ff4f5,_0x33bc6e['path'])&&(_0x3b306c['eventLists_']['push'](_0x33bc6e),_0x33bc6e=null),_0x33bc6e===null&&(_0x33bc6e={'events':[],'path':_0x4ff4f5}),_0x33bc6e['events']['push'](_0x2daab2);}_0x33bc6e&&_0x3b306c['eventLists_']['push'](_0x33bc6e);}function oa(_0x4620d9,_0x15b537,_0x2a436e){qn(_0x4620d9,_0x2a436e),aa(_0x4620d9,_0x3f5de8=>Ki(_0x3f5de8,_0x15b537));}function V(_0x5d7006,_0x3c2f5c,_0x50233a){qn(_0x5d7006,_0x50233a),aa(_0x5d7006,_0x2bb25c=>G(_0x2bb25c,_0x3c2f5c)||G(_0x3c2f5c,_0x2bb25c));}function aa(_0xa6e4c0,_0x2add5a){_0xa6e4c0['recursionDepth_']++;let _0x24de0a=!0x0;for(let _0x4d3342=0x0;_0x4d3342<_0xa6e4c0['eventLists_']['length'];_0x4d3342++){const _0x5b63b0=_0xa6e4c0['eventLists_'][_0x4d3342];if(_0x5b63b0){const _0x142df7=_0x5b63b0['path'];_0x2add5a(_0x142df7)?(md(_0xa6e4c0['eventLists_'][_0x4d3342]),_0xa6e4c0['eventLists_'][_0x4d3342]=null):_0x24de0a=!0x1;}}_0x24de0a&&(_0xa6e4c0['eventLists_']=[]),_0xa6e4c0['recursionDepth_']--;}function md(_0x264bc1){for(let _0x41942b=0x0;_0x41942b<_0x264bc1['events']['length'];_0x41942b++){const _0xa14dd8=_0x264bc1['events'][_0x41942b];if(_0xa14dd8!==null){_0x264bc1['events'][_0x41942b]=null;const _0xa90849=_0xa14dd8['getEventRunner']();St&&L('event:\x20'+_0xa14dd8['toString']()),ft(_0xa90849);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x49f3b5,_0x383bca,_0x5043af,_0x2b9c1c){this['repoInfo_']=_0x49f3b5,this['forceRestClient_']=_0x383bca,this['authTokenProvider_']=_0x5043af,this['appCheckProvider_']=_0x2b9c1c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1b9d10,_0x3d163d,_0xba6f87){if(_0x1b9d10['stats_']=qi(_0x1b9d10['repoInfo_']),_0x1b9d10['forceRestClient_']||Xl())_0x1b9d10['server_']=new vn(_0x1b9d10['repoInfo_'],(_0x3468c3,_0x2e4bd4,_0x1abb8c,_0x438328)=>{gr(_0x1b9d10,_0x3468c3,_0x2e4bd4,_0x1abb8c,_0x438328);},_0x1b9d10['authTokenProvider_'],_0x1b9d10['appCheckProvider_']),setTimeout(()=>mr(_0x1b9d10,!0x0),0x0);else{if(typeof _0xba6f87<'u'&&_0xba6f87!==null){if(typeof _0xba6f87!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xba6f87);}catch(_0x383c85){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x383c85);}}_0x1b9d10['persistentConnection_']=new se(_0x1b9d10['repoInfo_'],_0x3d163d,(_0x1a034b,_0x4ced7e,_0x2285a5,_0x5d7191)=>{gr(_0x1b9d10,_0x1a034b,_0x4ced7e,_0x2285a5,_0x5d7191);},_0x2d22e5=>{mr(_0x1b9d10,_0x2d22e5);},_0x2b1487=>{Id(_0x1b9d10,_0x2b1487);},_0x1b9d10['authTokenProvider_'],_0x1b9d10['appCheckProvider_'],_0xba6f87),_0x1b9d10['server_']=_0x1b9d10['persistentConnection_'];}_0x1b9d10['authTokenProvider_']['addTokenChangeListener'](_0x391f3f=>{_0x1b9d10['server_']['refreshAuthToken'](_0x391f3f);}),_0x1b9d10['appCheckProvider_']['addTokenChangeListener'](_0x322508=>{_0x1b9d10['server_']['refreshAppCheckToken'](_0x322508['token']);}),_0x1b9d10['statsReporter_']=ih(_0x1b9d10['repoInfo_'],()=>new iu(_0x1b9d10['stats_'],_0x1b9d10['server_'])),_0x1b9d10['infoData_']=new Xh(),_0x1b9d10['infoSyncTree_']=new pr({'startListening':(_0xb59c9f,_0x445b2d,_0x2aa9b4,_0x29d31c)=>{let _0xb675b=[];const _0x208049=_0x1b9d10['infoData_']['getNode'](_0xb59c9f['_path']);return _0x208049['isEmpty']()||(_0xb675b=Yt(_0x1b9d10['infoSyncTree_'],_0xb59c9f['_path'],_0x208049),setTimeout(()=>{_0x29d31c('ok');},0x0)),_0xb675b;},'stopListening':()=>{}}),vs(_0x1b9d10,'connected',!0x1),_0x1b9d10['serverSyncTree_']=new pr({'startListening':(_0x467b5f,_0x588b4e,_0x2e7b25,_0x48f52b)=>(_0x1b9d10['server_']['listen'](_0x467b5f,_0x2e7b25,_0x588b4e,(_0x2cc164,_0x557171)=>{const _0x39ba2b=_0x48f52b(_0x2cc164,_0x557171);V(_0x1b9d10['eventQueue_'],_0x467b5f['_path'],_0x39ba2b);}),[]),'stopListening':(_0x251813,_0x58a7a6)=>{_0x1b9d10['server_']['unlisten'](_0x251813,_0x58a7a6);}});}function la(_0x40d2c7){const _0x2239ec=_0x40d2c7['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2239ec;}function Xt(_0x23d652){return id({'timestamp':la(_0x23d652)});}function gr(_0x58f9a9,_0x2e02ac,_0x2a7401,_0x2aea7f,_0x1ecd9f){_0x58f9a9['dataUpdateCount']++;const _0x3404a0=new C(_0x2e02ac);_0x2a7401=_0x58f9a9['interceptServerDataCallback_']?_0x58f9a9['interceptServerDataCallback_'](_0x2e02ac,_0x2a7401):_0x2a7401;let _0x32bc3f=[];if(_0x1ecd9f){if(_0x2aea7f){const _0x256dc1=_n(_0x2a7401,_0x5021fd=>A(_0x5021fd));_0x32bc3f=Ju(_0x58f9a9['serverSyncTree_'],_0x3404a0,_0x256dc1,_0x1ecd9f);}else{const _0x168226=A(_0x2a7401);_0x32bc3f=Jo(_0x58f9a9['serverSyncTree_'],_0x3404a0,_0x168226,_0x1ecd9f);}}else{if(_0x2aea7f){const _0x4356b6=_n(_0x2a7401,_0x34985d=>A(_0x34985d));_0x32bc3f=Ku(_0x58f9a9['serverSyncTree_'],_0x3404a0,_0x4356b6);}else{const _0x40a78d=A(_0x2a7401);_0x32bc3f=Yt(_0x58f9a9['serverSyncTree_'],_0x3404a0,_0x40a78d);}}let _0x3f6ad2=_0x3404a0;_0x32bc3f['length']>0x0&&(_0x3f6ad2=ct(_0x58f9a9,_0x3404a0)),V(_0x58f9a9['eventQueue_'],_0x3f6ad2,_0x32bc3f);}function mr(_0x5f2dfe,_0x6a4a14){vs(_0x5f2dfe,'connected',_0x6a4a14),_0x6a4a14===!0x1&&Sd(_0x5f2dfe);}function Id(_0x4e0092,_0x5475e5){x(_0x5475e5,(_0x56c29a,_0x2b327b)=>{vs(_0x4e0092,_0x56c29a,_0x2b327b);});}function vs(_0x1c632f,_0x1afd4e,_0x169d5f){const _0xe55cd8=new C('/.info/'+_0x1afd4e),_0x385705=A(_0x169d5f);_0x1c632f['infoData_']['updateSnapshot'](_0xe55cd8,_0x385705);const _0x3b8309=Yt(_0x1c632f['infoSyncTree_'],_0xe55cd8,_0x385705);V(_0x1c632f['eventQueue_'],_0xe55cd8,_0x3b8309);}function zn(_0x42ea7e){return _0x42ea7e['nextWriteId_']++;}function wd(_0x48f6e0,_0x1878da,_0xa184d0){const _0x294a0c=Xu(_0x48f6e0['serverSyncTree_'],_0x1878da);return _0x294a0c!=null?Promise['resolve'](_0x294a0c):_0x48f6e0['server_']['get'](_0x1878da)['then'](_0x10bfea=>{const _0x5165d7=A(_0x10bfea)['withIndex'](_0x1878da['_queryParams']['getIndex']());Ni(_0x48f6e0['serverSyncTree_'],_0x1878da,_0xa184d0,!0x0);let _0x458726;if(_0x1878da['_queryParams']['loadsAllData']())_0x458726=Yt(_0x48f6e0['serverSyncTree_'],_0x1878da['_path'],_0x5165d7);else{const _0x39bd10=Wt(_0x48f6e0['serverSyncTree_'],_0x1878da);_0x458726=Jo(_0x48f6e0['serverSyncTree_'],_0x1878da['_path'],_0x5165d7,_0x39bd10);}return V(_0x48f6e0['eventQueue_'],_0x1878da['_path'],_0x458726),An(_0x48f6e0['serverSyncTree_'],_0x1878da,_0xa184d0,null,!0x0),_0x5165d7;},_0x43dbd7=>(gt(_0x48f6e0,'get\x20for\x20query\x20'+O(_0x1878da)+'\x20failed:\x20'+_0x43dbd7),Promise['reject'](new Error(_0x43dbd7))));}function Cd(_0x534910,_0x5a9e68,_0xbe8460,_0x204d2f,_0x22bbd2){gt(_0x534910,'set',{'path':_0x5a9e68['toString'](),'value':_0xbe8460,'priority':_0x204d2f});const _0xfcbbed=Xt(_0x534910),_0x18daf7=A(_0xbe8460,_0x204d2f),_0x55789d=Vn(_0x534910['serverSyncTree_'],_0x5a9e68),_0x408e5c=fs(_0x18daf7,_0x55789d,_0xfcbbed),_0x376740=zn(_0x534910),_0x2311ec=as(_0x534910['serverSyncTree_'],_0x5a9e68,_0x408e5c,_0x376740,!0x0);qn(_0x534910['eventQueue_'],_0x2311ec),_0x534910['server_']['put'](_0x5a9e68['toString'](),_0x18daf7['val'](!0x0),(_0x2d18d2,_0x37fa04)=>{const _0x103919=_0x2d18d2==='ok';_0x103919||U('set\x20at\x20'+_0x5a9e68+'\x20failed:\x20'+_0x2d18d2);const _0x2f0a9a=_e(_0x534910['serverSyncTree_'],_0x376740,!_0x103919);V(_0x534910['eventQueue_'],_0x5a9e68,_0x2f0a9a),be(_0x534910,_0x22bbd2,_0x2d18d2,_0x37fa04);});const _0x5a7976=Is(_0x534910,_0x5a9e68);ct(_0x534910,_0x5a7976),V(_0x534910['eventQueue_'],_0x5a7976,[]);}function Td(_0x138609,_0x2bfd8a,_0x60ad9,_0x56df2b){gt(_0x138609,'update',{'path':_0x2bfd8a['toString'](),'value':_0x60ad9});let _0x39bdfa=!0x0;const _0xd126b7=Xt(_0x138609),_0x5c91b0={};if(x(_0x60ad9,(_0xc687c2,_0x16c30f)=>{_0x39bdfa=!0x1,_0x5c91b0[_0xc687c2]=ta(k(_0x2bfd8a,_0xc687c2),A(_0x16c30f),_0x138609['serverSyncTree_'],_0xd126b7);}),_0x39bdfa)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x138609,_0x56df2b,'ok',void 0x0);else{const _0x5d1786=zn(_0x138609),_0x4d2cd0=ju(_0x138609['serverSyncTree_'],_0x2bfd8a,_0x5c91b0,_0x5d1786);qn(_0x138609['eventQueue_'],_0x4d2cd0),_0x138609['server_']['merge'](_0x2bfd8a['toString'](),_0x60ad9,(_0x298996,_0x5aae60)=>{const _0xe9606b=_0x298996==='ok';_0xe9606b||U('update\x20at\x20'+_0x2bfd8a+'\x20failed:\x20'+_0x298996);const _0x38ee53=_e(_0x138609['serverSyncTree_'],_0x5d1786,!_0xe9606b),_0x2d2905=_0x38ee53['length']>0x0?ct(_0x138609,_0x2bfd8a):_0x2bfd8a;V(_0x138609['eventQueue_'],_0x2d2905,_0x38ee53),be(_0x138609,_0x56df2b,_0x298996,_0x5aae60);}),x(_0x60ad9,_0x21878a=>{const _0x42dab5=Is(_0x138609,k(_0x2bfd8a,_0x21878a));ct(_0x138609,_0x42dab5);}),V(_0x138609['eventQueue_'],_0x2bfd8a,[]);}}function Sd(_0x59ffbf){gt(_0x59ffbf,'onDisconnectEvents');const _0x52b276=Xt(_0x59ffbf),_0x510188=En();Si(_0x59ffbf['onDisconnect_'],w(),(_0x1889a9,_0x9061a9)=>{const _0x230a30=ta(_0x1889a9,_0x9061a9,_0x59ffbf['serverSyncTree_'],_0x52b276);pt(_0x510188,_0x1889a9,_0x230a30);});let _0x1cc592=[];Si(_0x510188,w(),(_0x37998a,_0x2d671e)=>{_0x1cc592=_0x1cc592['concat'](Yt(_0x59ffbf['serverSyncTree_'],_0x37998a,_0x2d671e));const _0x3cebed=Is(_0x59ffbf,_0x37998a);ct(_0x59ffbf,_0x3cebed);}),_0x59ffbf['onDisconnect_']=En(),V(_0x59ffbf['eventQueue_'],w(),_0x1cc592);}function bd(_0x302edc,_0x5bc4c9,_0x50de1b){_0x302edc['server_']['onDisconnectCancel'](_0x5bc4c9['toString'](),(_0x12f5e4,_0xc1e34e)=>{_0x12f5e4==='ok'&&Ti(_0x302edc['onDisconnect_'],_0x5bc4c9),be(_0x302edc,_0x50de1b,_0x12f5e4,_0xc1e34e);});}function yr(_0xcb9319,_0x5d5acd,_0x4e4900,_0x6df5e1){const _0x767c52=A(_0x4e4900);_0xcb9319['server_']['onDisconnectPut'](_0x5d5acd['toString'](),_0x767c52['val'](!0x0),(_0x39808f,_0x5210df)=>{_0x39808f==='ok'&&pt(_0xcb9319['onDisconnect_'],_0x5d5acd,_0x767c52),be(_0xcb9319,_0x6df5e1,_0x39808f,_0x5210df);});}function Rd(_0x1e9f2a,_0x2dd093,_0x172e8b,_0x921e15,_0x201fb7){const _0x26fef7=A(_0x172e8b,_0x921e15);_0x1e9f2a['server_']['onDisconnectPut'](_0x2dd093['toString'](),_0x26fef7['val'](!0x0),(_0x153da2,_0x3164d4)=>{_0x153da2==='ok'&&pt(_0x1e9f2a['onDisconnect_'],_0x2dd093,_0x26fef7),be(_0x1e9f2a,_0x201fb7,_0x153da2,_0x3164d4);});}function Ad(_0x1abd2f,_0x25d6db,_0x4a69be,_0x5e412a){if(pn(_0x4a69be)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1abd2f,_0x5e412a,'ok',void 0x0);return;}_0x1abd2f['server_']['onDisconnectMerge'](_0x25d6db['toString'](),_0x4a69be,(_0x2df8a1,_0x320a88)=>{_0x2df8a1==='ok'&&x(_0x4a69be,(_0x3a597c,_0x37d467)=>{const _0x4b177b=A(_0x37d467);pt(_0x1abd2f['onDisconnect_'],k(_0x25d6db,_0x3a597c),_0x4b177b);}),be(_0x1abd2f,_0x5e412a,_0x2df8a1,_0x320a88);});}function kd(_0x1949b5,_0x17d000,_0x32cbae){let _0x54a955;y(_0x17d000['_path'])==='.info'?_0x54a955=Ni(_0x1949b5['infoSyncTree_'],_0x17d000,_0x32cbae):_0x54a955=Ni(_0x1949b5['serverSyncTree_'],_0x17d000,_0x32cbae),oa(_0x1949b5['eventQueue_'],_0x17d000['_path'],_0x54a955);}function Pd(_0x292a4f,_0x43019b,_0x11104f){let _0x58f2b3;y(_0x43019b['_path'])==='.info'?_0x58f2b3=An(_0x292a4f['infoSyncTree_'],_0x43019b,_0x11104f):_0x58f2b3=An(_0x292a4f['serverSyncTree_'],_0x43019b,_0x11104f),oa(_0x292a4f['eventQueue_'],_0x43019b['_path'],_0x58f2b3);}function ha(_0x22d83d){_0x22d83d['persistentConnection_']&&_0x22d83d['persistentConnection_']['interrupt'](ca);}function Nd(_0x7bc1a9){_0x7bc1a9['persistentConnection_']&&_0x7bc1a9['persistentConnection_']['resume'](ca);}function gt(_0x32114f,..._0x12a8ae){let _0x3b0a89='';_0x32114f['persistentConnection_']&&(_0x3b0a89=_0x32114f['persistentConnection_']['id']+':'),L(_0x3b0a89,..._0x12a8ae);}function be(_0x58eb49,_0x43c0ec,_0x333a53,_0x1e23cc){_0x43c0ec&&ft(()=>{if(_0x333a53==='ok')_0x43c0ec(null);else{const _0x73dddf=(_0x333a53||'error')['toUpperCase']();let _0x4a0a94=_0x73dddf;_0x1e23cc&&(_0x4a0a94+=':\x20'+_0x1e23cc);const _0x41bfe1=new Error(_0x4a0a94);_0x41bfe1['code']=_0x73dddf,_0x43c0ec(_0x41bfe1);}});}function Od(_0x2b5950,_0x120126,_0x4a3b41,_0x591f10,_0x2e67ff,_0x5b07c9){gt(_0x2b5950,'transaction\x20on\x20'+_0x120126);const _0x497d9c={'path':_0x120126,'update':_0x4a3b41,'onComplete':_0x591f10,'status':null,'order':so(),'applyLocally':_0x5b07c9,'retryCount':0x0,'unwatcher':_0x2e67ff,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x277242=Es(_0x2b5950,_0x120126,void 0x0);_0x497d9c['currentInputSnapshot']=_0x277242;const _0x4c8278=_0x497d9c['update'](_0x277242['val']());if(_0x4c8278===void 0x0)_0x497d9c['unwatcher'](),_0x497d9c['currentOutputSnapshotRaw']=null,_0x497d9c['currentOutputSnapshotResolved']=null,_0x497d9c['onComplete']&&_0x497d9c['onComplete'](null,!0x1,_0x497d9c['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c8278,_0x497d9c['path']),_0x497d9c['status']=0x0;const _0x533d4f=$n(_0x2b5950['transactionQueueTree_'],_0x120126),_0x1a198a=je(_0x533d4f)||[];_0x1a198a['push'](_0x497d9c),gs(_0x533d4f,_0x1a198a);let _0x4c7f51;typeof _0x4c8278=='object'&&_0x4c8278!==null&&Q(_0x4c8278,'.priority')?(_0x4c7f51=Le(_0x4c8278,'.priority'),f(Bt(_0x4c7f51),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4c7f51=(Vn(_0x2b5950['serverSyncTree_'],_0x120126)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3c7b64=Xt(_0x2b5950),_0x412e57=A(_0x4c8278,_0x4c7f51),_0x30af3c=fs(_0x412e57,_0x277242,_0x3c7b64);_0x497d9c['currentOutputSnapshotRaw']=_0x412e57,_0x497d9c['currentOutputSnapshotResolved']=_0x30af3c,_0x497d9c['currentWriteId']=zn(_0x2b5950);const _0x2d1343=as(_0x2b5950['serverSyncTree_'],_0x120126,_0x30af3c,_0x497d9c['currentWriteId'],_0x497d9c['applyLocally']);V(_0x2b5950['eventQueue_'],_0x120126,_0x2d1343),jn(_0x2b5950,_0x2b5950['transactionQueueTree_']);}}function Es(_0x54cfa3,_0x1a91dc,_0x5d3fd9){return Vn(_0x54cfa3['serverSyncTree_'],_0x1a91dc,_0x5d3fd9)||g['EMPTY_NODE'];}function jn(_0x3c36be,_0x4917f0=_0x3c36be['transactionQueueTree_']){if(_0x4917f0||Kn(_0x3c36be,_0x4917f0),je(_0x4917f0)){const _0x4d1f08=da(_0x3c36be,_0x4917f0);f(_0x4d1f08['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4d1f08['every'](_0x328bed=>_0x328bed['status']===0x0)&&Dd(_0x3c36be,Qt(_0x4917f0),_0x4d1f08);}else na(_0x4917f0)&&Gn(_0x4917f0,_0x30cae6=>{jn(_0x3c36be,_0x30cae6);});}function Dd(_0x1f4109,_0x140d53,_0x55b476){const _0x744459=_0x55b476['map'](_0x42d700=>_0x42d700['currentWriteId']),_0x27ee23=Es(_0x1f4109,_0x140d53,_0x744459);let _0x3b3331=_0x27ee23;const _0x3f8327=_0x27ee23['hash']();for(let _0x5685df=0x0;_0x5685df<_0x55b476['length'];_0x5685df++){const _0x4b33ba=_0x55b476[_0x5685df];f(_0x4b33ba['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4b33ba['status']=0x1,_0x4b33ba['retryCount']++;const _0x5df92b=F(_0x140d53,_0x4b33ba['path']);_0x3b3331=_0x3b3331['updateChild'](_0x5df92b,_0x4b33ba['currentOutputSnapshotRaw']);}const _0x54fb1d=_0x3b3331['val'](!0x0),_0xa54cc4=_0x140d53;_0x1f4109['server_']['put'](_0xa54cc4['toString'](),_0x54fb1d,_0x20e579=>{gt(_0x1f4109,'transaction\x20put\x20response',{'path':_0xa54cc4['toString'](),'status':_0x20e579});let _0x290f09=[];if(_0x20e579==='ok'){const _0x383771=[];for(let _0xc7e785=0x0;_0xc7e785<_0x55b476['length'];_0xc7e785++)_0x55b476[_0xc7e785]['status']=0x2,_0x290f09=_0x290f09['concat'](_e(_0x1f4109['serverSyncTree_'],_0x55b476[_0xc7e785]['currentWriteId'])),_0x55b476[_0xc7e785]['onComplete']&&_0x383771['push'](()=>_0x55b476[_0xc7e785]['onComplete'](null,!0x0,_0x55b476[_0xc7e785]['currentOutputSnapshotResolved'])),_0x55b476[_0xc7e785]['unwatcher']();Kn(_0x1f4109,$n(_0x1f4109['transactionQueueTree_'],_0x140d53)),jn(_0x1f4109,_0x1f4109['transactionQueueTree_']),V(_0x1f4109['eventQueue_'],_0x140d53,_0x290f09);for(let _0x19b281=0x0;_0x19b281<_0x383771['length'];_0x19b281++)ft(_0x383771[_0x19b281]);}else{if(_0x20e579==='datastale'){for(let _0x12d061=0x0;_0x12d061<_0x55b476['length'];_0x12d061++)_0x55b476[_0x12d061]['status']===0x3?_0x55b476[_0x12d061]['status']=0x4:_0x55b476[_0x12d061]['status']=0x0;}else{U('transaction\x20at\x20'+_0xa54cc4['toString']()+'\x20failed:\x20'+_0x20e579);for(let _0x2bd4db=0x0;_0x2bd4db<_0x55b476['length'];_0x2bd4db++)_0x55b476[_0x2bd4db]['status']=0x4,_0x55b476[_0x2bd4db]['abortReason']=_0x20e579;}ct(_0x1f4109,_0x140d53);}},_0x3f8327);}function ct(_0x12814b,_0x46daf7){const _0x20d20e=ua(_0x12814b,_0x46daf7),_0x24568e=Qt(_0x20d20e),_0x4c84c3=da(_0x12814b,_0x20d20e);return Md(_0x12814b,_0x4c84c3,_0x24568e),_0x24568e;}function Md(_0x12587e,_0x5b66c2,_0x515bcd){if(_0x5b66c2['length']===0x0)return;const _0x1f698e=[];let _0xde3bc1=[];const _0x4abd44=_0x5b66c2['filter'](_0x3add16=>_0x3add16['status']===0x0)['map'](_0x31928a=>_0x31928a['currentWriteId']);for(let _0x1fc7f8=0x0;_0x1fc7f8<_0x5b66c2['length'];_0x1fc7f8++){const _0x4441af=_0x5b66c2[_0x1fc7f8],_0x1ce94d=F(_0x515bcd,_0x4441af['path']);let _0x19c826=!0x1,_0x172732;if(f(_0x1ce94d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4441af['status']===0x4)_0x19c826=!0x0,_0x172732=_0x4441af['abortReason'],_0xde3bc1=_0xde3bc1['concat'](_e(_0x12587e['serverSyncTree_'],_0x4441af['currentWriteId'],!0x0));else{if(_0x4441af['status']===0x0){if(_0x4441af['retryCount']>=yd)_0x19c826=!0x0,_0x172732='maxretry',_0xde3bc1=_0xde3bc1['concat'](_e(_0x12587e['serverSyncTree_'],_0x4441af['currentWriteId'],!0x0));else{const _0x17f046=Es(_0x12587e,_0x4441af['path'],_0x4abd44);_0x4441af['currentInputSnapshot']=_0x17f046;const _0x33e047=_0x5b66c2[_0x1fc7f8]['update'](_0x17f046['val']());if(_0x33e047!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x33e047,_0x4441af['path']);let _0x311cb2=A(_0x33e047);typeof _0x33e047=='object'&&_0x33e047!=null&&Q(_0x33e047,'.priority')||(_0x311cb2=_0x311cb2['updatePriority'](_0x17f046['getPriority']()));const _0x1694e8=_0x4441af['currentWriteId'],_0x1127ce=Xt(_0x12587e),_0x1eda49=fs(_0x311cb2,_0x17f046,_0x1127ce);_0x4441af['currentOutputSnapshotRaw']=_0x311cb2,_0x4441af['currentOutputSnapshotResolved']=_0x1eda49,_0x4441af['currentWriteId']=zn(_0x12587e),_0x4abd44['splice'](_0x4abd44['indexOf'](_0x1694e8),0x1),_0xde3bc1=_0xde3bc1['concat'](as(_0x12587e['serverSyncTree_'],_0x4441af['path'],_0x1eda49,_0x4441af['currentWriteId'],_0x4441af['applyLocally'])),_0xde3bc1=_0xde3bc1['concat'](_e(_0x12587e['serverSyncTree_'],_0x1694e8,!0x0));}else _0x19c826=!0x0,_0x172732='nodata',_0xde3bc1=_0xde3bc1['concat'](_e(_0x12587e['serverSyncTree_'],_0x4441af['currentWriteId'],!0x0));}}}V(_0x12587e['eventQueue_'],_0x515bcd,_0xde3bc1),_0xde3bc1=[],_0x19c826&&(_0x5b66c2[_0x1fc7f8]['status']=0x2,function(_0x58361c){setTimeout(_0x58361c,Math['floor'](0x0));}(_0x5b66c2[_0x1fc7f8]['unwatcher']),_0x5b66c2[_0x1fc7f8]['onComplete']&&(_0x172732==='nodata'?_0x1f698e['push'](()=>_0x5b66c2[_0x1fc7f8]['onComplete'](null,!0x1,_0x5b66c2[_0x1fc7f8]['currentInputSnapshot'])):_0x1f698e['push'](()=>_0x5b66c2[_0x1fc7f8]['onComplete'](new Error(_0x172732),!0x1,null))));}Kn(_0x12587e,_0x12587e['transactionQueueTree_']);for(let _0xa38d18=0x0;_0xa38d18<_0x1f698e['length'];_0xa38d18++)ft(_0x1f698e[_0xa38d18]);jn(_0x12587e,_0x12587e['transactionQueueTree_']);}function ua(_0x14055c,_0x29f506){let _0x5ba0cd,_0x3e22fa=_0x14055c['transactionQueueTree_'];for(_0x5ba0cd=y(_0x29f506);_0x5ba0cd!==null&&je(_0x3e22fa)===void 0x0;)_0x3e22fa=$n(_0x3e22fa,_0x5ba0cd),_0x29f506=S(_0x29f506),_0x5ba0cd=y(_0x29f506);return _0x3e22fa;}function da(_0x193844,_0x2117a1){const _0x274145=[];return fa(_0x193844,_0x2117a1,_0x274145),_0x274145['sort']((_0xfbd5ec,_0x45a5df)=>_0xfbd5ec['order']-_0x45a5df['order']),_0x274145;}function fa(_0xd824b0,_0x2570de,_0x40a2fc){const _0xea1501=je(_0x2570de);if(_0xea1501){for(let _0x1ec878=0x0;_0x1ec878<_0xea1501['length'];_0x1ec878++)_0x40a2fc['push'](_0xea1501[_0x1ec878]);}Gn(_0x2570de,_0x42e8ac=>{fa(_0xd824b0,_0x42e8ac,_0x40a2fc);});}function Kn(_0x4b3279,_0x1f39a0){const _0x35ac29=je(_0x1f39a0);if(_0x35ac29){let _0x24c923=0x0;for(let _0x320182=0x0;_0x320182<_0x35ac29['length'];_0x320182++)_0x35ac29[_0x320182]['status']!==0x2&&(_0x35ac29[_0x24c923]=_0x35ac29[_0x320182],_0x24c923++);_0x35ac29['length']=_0x24c923,gs(_0x1f39a0,_0x35ac29['length']>0x0?_0x35ac29:void 0x0);}Gn(_0x1f39a0,_0x432157=>{Kn(_0x4b3279,_0x432157);});}function Is(_0x327a4e,_0x540e9f){const _0x1c1624=Qt(ua(_0x327a4e,_0x540e9f)),_0x312d35=$n(_0x327a4e['transactionQueueTree_'],_0x540e9f);return ad(_0x312d35,_0x3a24dc=>{di(_0x327a4e,_0x3a24dc);}),di(_0x327a4e,_0x312d35),ia(_0x312d35,_0x421afb=>{di(_0x327a4e,_0x421afb);}),_0x1c1624;}function di(_0x164fce,_0x34f175){const _0xf60aa4=je(_0x34f175);if(_0xf60aa4){const _0x47eec8=[];let _0x15e425=[],_0x1c3564=-0x1;for(let _0x56e43a=0x0;_0x56e43a<_0xf60aa4['length'];_0x56e43a++)_0xf60aa4[_0x56e43a]['status']===0x3||(_0xf60aa4[_0x56e43a]['status']===0x1?(f(_0x1c3564===_0x56e43a-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1c3564=_0x56e43a,_0xf60aa4[_0x56e43a]['status']=0x3,_0xf60aa4[_0x56e43a]['abortReason']='set'):(f(_0xf60aa4[_0x56e43a]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xf60aa4[_0x56e43a]['unwatcher'](),_0x15e425=_0x15e425['concat'](_e(_0x164fce['serverSyncTree_'],_0xf60aa4[_0x56e43a]['currentWriteId'],!0x0)),_0xf60aa4[_0x56e43a]['onComplete']&&_0x47eec8['push'](_0xf60aa4[_0x56e43a]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1c3564===-0x1?gs(_0x34f175,void 0x0):_0xf60aa4['length']=_0x1c3564+0x1,V(_0x164fce['eventQueue_'],Qt(_0x34f175),_0x15e425);for(let _0x594c30=0x0;_0x594c30<_0x47eec8['length'];_0x594c30++)ft(_0x47eec8[_0x594c30]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x23d167){let _0x426bfe='';const _0x20f3a1=_0x23d167['split']('/');for(let _0x256d81=0x0;_0x256d81<_0x20f3a1['length'];_0x256d81++)if(_0x20f3a1[_0x256d81]['length']>0x0){let _0x459748=_0x20f3a1[_0x256d81];try{_0x459748=decodeURIComponent(_0x459748['replace'](/\+/g,'\x20'));}catch{}_0x426bfe+='/'+_0x459748;}return _0x426bfe;}function xd(_0x3701bc){const _0x249029={};_0x3701bc['charAt'](0x0)==='?'&&(_0x3701bc=_0x3701bc['substring'](0x1));for(const _0xe7708e of _0x3701bc['split']('&')){if(_0xe7708e['length']===0x0)continue;const _0x248e2c=_0xe7708e['split']('=');_0x248e2c['length']===0x2?_0x249029[decodeURIComponent(_0x248e2c[0x0])]=decodeURIComponent(_0x248e2c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xe7708e+'\x27\x20in\x20query\x20\x27'+_0x3701bc+'\x27');}return _0x249029;}const vr=function(_0x1bcbc4,_0x548235){const _0x23b8c3=Fd(_0x1bcbc4),_0x499ed6=_0x23b8c3['namespace'];_0x23b8c3['domain']==='firebase.com'&&ae(_0x23b8c3['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x499ed6||_0x499ed6==='undefined')&&_0x23b8c3['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x23b8c3['secure']||$l();const _0x3f1e1e=_0x23b8c3['scheme']==='ws'||_0x23b8c3['scheme']==='wss';return{'repoInfo':new yo(_0x23b8c3['host'],_0x23b8c3['secure'],_0x499ed6,_0x3f1e1e,_0x548235,'',_0x499ed6!==_0x23b8c3['subdomain']),'path':new C(_0x23b8c3['pathString'])};},Fd=function(_0x502dea){let _0x1ede91='',_0x5823ea='',_0x496bcb='',_0x3c834a='',_0x3e8d32='',_0xebaa63=!0x0,_0x4d26ef='https',_0x49a45e=0x1bb;if(typeof _0x502dea=='string'){let _0x46bd67=_0x502dea['indexOf']('//');_0x46bd67>=0x0&&(_0x4d26ef=_0x502dea['substring'](0x0,_0x46bd67-0x1),_0x502dea=_0x502dea['substring'](_0x46bd67+0x2));let _0x1d65d7=_0x502dea['indexOf']('/');_0x1d65d7===-0x1&&(_0x1d65d7=_0x502dea['length']);let _0x381483=_0x502dea['indexOf']('?');_0x381483===-0x1&&(_0x381483=_0x502dea['length']),_0x1ede91=_0x502dea['substring'](0x0,Math['min'](_0x1d65d7,_0x381483)),_0x1d65d7<_0x381483&&(_0x3c834a=Ld(_0x502dea['substring'](_0x1d65d7,_0x381483)));const _0x3e8d7d=xd(_0x502dea['substring'](Math['min'](_0x502dea['length'],_0x381483)));_0x46bd67=_0x1ede91['indexOf'](':'),_0x46bd67>=0x0?(_0xebaa63=_0x4d26ef==='https'||_0x4d26ef==='wss',_0x49a45e=parseInt(_0x1ede91['substring'](_0x46bd67+0x1),0xa)):_0x46bd67=_0x1ede91['length'];const _0x3aa9d0=_0x1ede91['slice'](0x0,_0x46bd67);if(_0x3aa9d0['toLowerCase']()==='localhost')_0x5823ea='localhost';else{if(_0x3aa9d0['split']('.')['length']<=0x2)_0x5823ea=_0x3aa9d0;else{const _0x439877=_0x1ede91['indexOf']('.');_0x496bcb=_0x1ede91['substring'](0x0,_0x439877)['toLowerCase'](),_0x5823ea=_0x1ede91['substring'](_0x439877+0x1),_0x3e8d32=_0x496bcb;}}'ns'in _0x3e8d7d&&(_0x3e8d32=_0x3e8d7d['ns']);}return{'host':_0x1ede91,'port':_0x49a45e,'domain':_0x5823ea,'subdomain':_0x496bcb,'secure':_0xebaa63,'scheme':_0x4d26ef,'pathString':_0x3c834a,'namespace':_0x3e8d32};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x20f7d8=0x0;const _0x271a90=[];return function(_0x53adab){const _0x2d10aa=_0x53adab===_0x20f7d8;_0x20f7d8=_0x53adab;let _0x41f9f8;const _0x1325d7=new Array(0x8);for(_0x41f9f8=0x7;_0x41f9f8>=0x0;_0x41f9f8--)_0x1325d7[_0x41f9f8]=Er['charAt'](_0x53adab%0x40),_0x53adab=Math['floor'](_0x53adab/0x40);f(_0x53adab===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x18484c=_0x1325d7['join']('');if(_0x2d10aa){for(_0x41f9f8=0xb;_0x41f9f8>=0x0&&_0x271a90[_0x41f9f8]===0x3f;_0x41f9f8--)_0x271a90[_0x41f9f8]=0x0;_0x271a90[_0x41f9f8]++;}else{for(_0x41f9f8=0x0;_0x41f9f8<0xc;_0x41f9f8++)_0x271a90[_0x41f9f8]=Math['floor'](Math['random']()*0x40);}for(_0x41f9f8=0x0;_0x41f9f8<0xc;_0x41f9f8++)_0x18484c+=Er['charAt'](_0x271a90[_0x41f9f8]);return f(_0x18484c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x18484c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0xf4804,_0x19e80d,_0x1830c,_0x14307c){this['eventType']=_0xf4804,this['eventRegistration']=_0x19e80d,this['snapshot']=_0x1830c,this['prevName']=_0x14307c;}['getPath'](){const _0x2df02e=this['snapshot']['ref'];return this['eventType']==='value'?_0x2df02e['_path']:_0x2df02e['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x53d1bd,_0x5b956b,_0x420950){this['eventRegistration']=_0x53d1bd,this['error']=_0x5b956b,this['path']=_0x420950;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2c1827,_0x552590){this['snapshotCallback']=_0x2c1827,this['cancelCallback']=_0x552590;}['onValue'](_0x1eda8d,_0x42aeb2){this['snapshotCallback']['call'](null,_0x1eda8d,_0x42aeb2);}['onCancel'](_0x4ed8aa){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4ed8aa);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x36ec13){return this['snapshotCallback']===_0x36ec13['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x36ec13['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x36ec13['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3fb2a3,_0x37249b){this['_repo']=_0x3fb2a3,this['_path']=_0x37249b;}['cancel'](){const _0x34a20f=new H();return bd(this['_repo'],this['_path'],_0x34a20f['wrapCallback'](()=>{})),_0x34a20f['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0xb1dab9=new H();return yr(this['_repo'],this['_path'],null,_0xb1dab9['wrapCallback'](()=>{})),_0xb1dab9['promise'];}['set'](_0x2ff9b0){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2ff9b0,this['_path'],!0x1);const _0x385688=new H();return yr(this['_repo'],this['_path'],_0x2ff9b0,_0x385688['wrapCallback'](()=>{})),_0x385688['promise'];}['setWithPriority'](_0x4af41c,_0x4f165e){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x4af41c,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4f165e);const _0x4a81e1=new H();return Rd(this['_repo'],this['_path'],_0x4af41c,_0x4f165e,_0x4a81e1['wrapCallback'](()=>{})),_0x4a81e1['promise'];}['update'](_0xc45db0){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0xc45db0,this['_path']);const _0x324369=new H();return Ad(this['_repo'],this['_path'],_0xc45db0,_0x324369['wrapCallback'](()=>{})),_0x324369['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4fab8a,_0x489449,_0x44f8c8,_0x42a6a6){this['_repo']=_0x4fab8a,this['_path']=_0x489449,this['_queryParams']=_0x44f8c8,this['_orderByCalled']=_0x42a6a6;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4ba4fa=sr(this['_queryParams']),_0xcb6f11=$i(_0x4ba4fa);return _0xcb6f11==='{}'?'default':_0xcb6f11;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x166382){if(_0x166382=P(_0x166382),!(_0x166382 instanceof Ae))return!0x1;const _0x5444c2=this['_repo']===_0x166382['_repo'],_0x3d6f8b=Ki(this['_path'],_0x166382['_path']),_0x76f765=this['_queryIdentifier']===_0x166382['_queryIdentifier'];return _0x5444c2&&_0x3d6f8b&&_0x76f765;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x393883,_0x7049f3){if(_0x393883['_orderByCalled']===!0x0)throw new Error(_0x7049f3+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x3a6d42){let _0x2a6130=null,_0x3fc18b=null;if(_0x3a6d42['hasStart']()&&(_0x2a6130=_0x3a6d42['getIndexStartValue']()),_0x3a6d42['hasEnd']()&&(_0x3fc18b=_0x3a6d42['getIndexEndValue']()),_0x3a6d42['getIndex']()===ve){const _0x4e721c='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2c0809='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3a6d42['hasStart']()){if(_0x3a6d42['getIndexStartName']()!==We)throw new Error(_0x4e721c);if(typeof _0x2a6130!='string')throw new Error(_0x2c0809);}if(_0x3a6d42['hasEnd']()){if(_0x3a6d42['getIndexEndName']()!==we)throw new Error(_0x4e721c);if(typeof _0x3fc18b!='string')throw new Error(_0x2c0809);}}else{if(_0x3a6d42['getIndex']()===R){if(_0x2a6130!=null&&!Bt(_0x2a6130)||_0x3fc18b!=null&&!Bt(_0x3fc18b))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3a6d42['getIndex']()instanceof Ji||_0x3a6d42['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2a6130!=null&&typeof _0x2a6130=='object'||_0x3fc18b!=null&&typeof _0x3fc18b=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x11d572){if(_0x11d572['hasStart']()&&_0x11d572['hasEnd']()&&_0x11d572['hasLimit']()&&!_0x11d572['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x184b8c,_0x221175){super(_0x184b8c,_0x221175,new Zi(),!0x1);}get['parent'](){const _0x157e35=Ro(this['_path']);return _0x157e35===null?null:new ee(this['_repo'],_0x157e35);}get['root'](){let _0xa2ffcc=this;for(;_0xa2ffcc['parent']!==null;)_0xa2ffcc=_0xa2ffcc['parent'];return _0xa2ffcc;}}class lt{constructor(_0x1f6767,_0x56fc00,_0x39549a){this['_node']=_0x1f6767,this['ref']=_0x56fc00,this['_index']=_0x39549a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1ada3e){const _0x2e3f1f=new C(_0x1ada3e),_0x472ac6=Vt(this['ref'],_0x1ada3e);return new lt(this['_node']['getChild'](_0x2e3f1f),_0x472ac6,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x22c0ef){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3fdb2c,_0x3c5e33)=>_0x22c0ef(new lt(_0x3c5e33,Vt(this['ref'],_0x3fdb2c),R)));}['hasChild'](_0x8823e7){const _0x27679d=new C(_0x8823e7);return!this['_node']['getChild'](_0x27679d)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1c9c0e,_0x2ff2e1){return _0x1c9c0e=P(_0x1c9c0e),_0x1c9c0e['_checkNotDeleted']('ref'),_0x2ff2e1!==void 0x0?Vt(_0x1c9c0e['_root'],_0x2ff2e1):_0x1c9c0e['_root'];}function Vt(_0xccd676,_0x24fa98){return _0xccd676=P(_0xccd676),y(_0xccd676['_path'])===null?pd('child','path',_0x24fa98):ys('child','path',_0x24fa98),new ee(_0xccd676['_repo'],k(_0xccd676['_path'],_0x24fa98));}function v_(_0x269e69){return _0x269e69=P(_0x269e69),new Vd(_0x269e69['_repo'],_0x269e69['_path']);}function E_(_0x16c15f,_0xe9aaf9){_0x16c15f=P(_0x16c15f),Me('push',_0x16c15f['_path']),He('push',_0xe9aaf9,_0x16c15f['_path'],!0x0);const _0x592907=la(_0x16c15f['_repo']),_0x5b40f0=Ud(_0x592907),_0x2e64ee=Vt(_0x16c15f,_0x5b40f0),_0x7f5c86=Vt(_0x16c15f,_0x5b40f0);let _0x449898;return _0xe9aaf9!=null?_0x449898=Hd(_0x7f5c86,_0xe9aaf9)['then'](()=>_0x7f5c86):_0x449898=Promise['resolve'](_0x7f5c86),_0x2e64ee['then']=_0x449898['then']['bind'](_0x449898),_0x2e64ee['catch']=_0x449898['then']['bind'](_0x449898,void 0x0),_0x2e64ee;}function Hd(_0x1de116,_0x4b4b14){_0x1de116=P(_0x1de116),Me('set',_0x1de116['_path']),He('set',_0x4b4b14,_0x1de116['_path'],!0x1);const _0x20a702=new H();return Cd(_0x1de116['_repo'],_0x1de116['_path'],_0x4b4b14,null,_0x20a702['wrapCallback'](()=>{})),_0x20a702['promise'];}function I_(_0x30cffa,_0x247299){ra('update',_0x247299,_0x30cffa['_path']);const _0xa5681f=new H();return Td(_0x30cffa['_repo'],_0x30cffa['_path'],_0x247299,_0xa5681f['wrapCallback'](()=>{})),_0xa5681f['promise'];}function w_(_0x563a6b){_0x563a6b=P(_0x563a6b);const _0x168b71=new pa(()=>{}),_0x5889de=new Qn(_0x168b71);return wd(_0x563a6b['_repo'],_0x563a6b,_0x5889de)['then'](_0x284776=>new lt(_0x284776,new ee(_0x563a6b['_repo'],_0x563a6b['_path']),_0x563a6b['_queryParams']['getIndex']()));}class Qn{constructor(_0x577560){this['callbackContext']=_0x577560;}['respondsTo'](_0x58145b){return _0x58145b==='value';}['createEvent'](_0x5d896a,_0x443211){const _0x1ecb90=_0x443211['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x5d896a['snapshotNode'],new ee(_0x443211['_repo'],_0x443211['_path']),_0x1ecb90));}['getEventRunner'](_0x4db256){return _0x4db256['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4db256['error']):()=>this['callbackContext']['onValue'](_0x4db256['snapshot'],null);}['createCancelEvent'](_0x332de1,_0xeaed79){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x332de1,_0xeaed79):null;}['matches'](_0x518fc4){return _0x518fc4 instanceof Qn?!_0x518fc4['callbackContext']||!this['callbackContext']?!0x0:_0x518fc4['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x8c8372,_0x116e25,_0x125dd9,_0x3ea46c,_0x2de9ee){const _0x58daae=new pa(_0x125dd9,void 0x0),_0x1ff049=new Qn(_0x58daae);return kd(_0x8c8372['_repo'],_0x8c8372,_0x1ff049),()=>Pd(_0x8c8372['_repo'],_0x8c8372,_0x1ff049);}function Gd(_0x2d1f43,_0x1dcd93,_0x5a3c36,_0x2ee714){return $d(_0x2d1f43,'value',_0x1dcd93);}class mt{}class ma extends mt{constructor(_0x331c0b,_0x24c3ac){super(),this['_value']=_0x331c0b,this['_key']=_0x24c3ac,this['type']='endAt';}['_apply'](_0x35766a){He('endAt',this['_value'],_0x35766a['_path'],!0x0);const _0x3a432d=Jh(_0x35766a['_queryParams'],this['_value'],this['_key']);if(ga(_0x3a432d),Yn(_0x3a432d),_0x35766a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x35766a['_repo'],_0x35766a['_path'],_0x3a432d,_0x35766a['_orderByCalled']);}}function C_(_0x441955,_0x35c535){return new ma(_0x441955,_0x35c535);}class ya extends mt{constructor(_0x520932,_0x473361){super(),this['_value']=_0x520932,this['_key']=_0x473361,this['type']='startAt';}['_apply'](_0x5300b5){He('startAt',this['_value'],_0x5300b5['_path'],!0x0);const _0x3260ac=Qh(_0x5300b5['_queryParams'],this['_value'],this['_key']);if(ga(_0x3260ac),Yn(_0x3260ac),_0x5300b5['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5300b5['_repo'],_0x5300b5['_path'],_0x3260ac,_0x5300b5['_orderByCalled']);}}function T_(_0x3712d4=null,_0x518dfd){return new ya(_0x3712d4,_0x518dfd);}class qd extends mt{constructor(_0xbef227){super(),this['_limit']=_0xbef227,this['type']='limitToFirst';}['_apply'](_0x225ac3){if(_0x225ac3['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x225ac3['_repo'],_0x225ac3['_path'],Yh(_0x225ac3['_queryParams'],this['_limit']),_0x225ac3['_orderByCalled']);}}function S_(_0x5218cb){if(Math['floor'](_0x5218cb)!==_0x5218cb||_0x5218cb<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x5218cb);}class zd extends mt{constructor(_0x54e652){super(),this['_path']=_0x54e652,this['type']='orderByChild';}['_apply'](_0x392c9c){_a(_0x392c9c,'orderByChild');const _0x4fc3df=new C(this['_path']);if(v(_0x4fc3df))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4564ea=new Ji(_0x4fc3df),_0x256b97=xo(_0x392c9c['_queryParams'],_0x4564ea);return Yn(_0x256b97),new Ae(_0x392c9c['_repo'],_0x392c9c['_path'],_0x256b97,!0x0);}}function b_(_0x552225){if(_0x552225==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x552225==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x552225==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x552225),new zd(_0x552225);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3d8ea8){_a(_0x3d8ea8,'orderByKey');const _0x64d20a=xo(_0x3d8ea8['_queryParams'],ve);return Yn(_0x64d20a),new Ae(_0x3d8ea8['_repo'],_0x3d8ea8['_path'],_0x64d20a,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0xf99d3b,_0x42cee5){super(),this['_value']=_0xf99d3b,this['_key']=_0x42cee5,this['type']='equalTo';}['_apply'](_0x3bbffe){if(He('equalTo',this['_value'],_0x3bbffe['_path'],!0x1),_0x3bbffe['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3bbffe['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3bbffe));}}function A_(_0x3c7f68,_0x1f2a64){return new Kd(_0x3c7f68,_0x1f2a64);}function k_(_0x1591b8,..._0x4e6029){let _0x55b788=P(_0x1591b8);for(const _0x24df4c of _0x4e6029)_0x55b788=_0x24df4c['_apply'](_0x55b788);return _0x55b788;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x5d11e3,_0xc04e74,_0x2cacde,_0x46db91){const _0x2aba93=_0xc04e74['lastIndexOf'](':'),_0x3b2633=_0xc04e74['substring'](0x0,_0x2aba93),_0x17f6b9=qt(_0x3b2633);_0x5d11e3['repoInfo_']=new yo(_0xc04e74,_0x17f6b9,_0x5d11e3['repoInfo_']['namespace'],_0x5d11e3['repoInfo_']['webSocketOnly'],_0x5d11e3['repoInfo_']['nodeAdmin'],_0x5d11e3['repoInfo_']['persistenceKey'],_0x5d11e3['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2cacde),_0x46db91&&(_0x5d11e3['authTokenProvider_']=_0x46db91);}function Xd(_0x2da7ba,_0x387561,_0x545d37,_0x22ff2b,_0x5063e2){let _0x22be73=_0x22ff2b||_0x2da7ba['options']['databaseURL'];_0x22be73===void 0x0&&(_0x2da7ba['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2da7ba['options']['projectId']),_0x22be73=_0x2da7ba['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4f17ce=vr(_0x22be73,_0x5063e2),_0x40312f=_0x4f17ce['repoInfo'],_0x4703fc;typeof process<'u'&&Bs&&(_0x4703fc=Bs[Yd]),_0x4703fc?(_0x22be73='http://'+_0x4703fc+'?ns='+_0x40312f['namespace'],_0x4f17ce=vr(_0x22be73,_0x5063e2),_0x40312f=_0x4f17ce['repoInfo']):_0x4f17ce['repoInfo']['secure'];const _0x32ca92=new eh(_0x2da7ba['name'],_0x2da7ba['options'],_0x387561);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4f17ce),v(_0x4f17ce['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1003cd=ef(_0x40312f,_0x2da7ba,_0x32ca92,new Zl(_0x2da7ba,_0x545d37));return new tf(_0x1003cd,_0x2da7ba);}function Zd(_0x505084,_0xb39536){const _0x4481dc=Di[_0xb39536];(!_0x4481dc||_0x4481dc[_0x505084['key']]!==_0x505084)&&ae('Database\x20'+_0xb39536+'('+_0x505084['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x505084),delete _0x4481dc[_0x505084['key']];}function ef(_0x5015ef,_0x1d0bf5,_0x3930d4,_0x3aa191){let _0x1a2d21=Di[_0x1d0bf5['name']];_0x1a2d21||(_0x1a2d21={},Di[_0x1d0bf5['name']]=_0x1a2d21);let _0x48121b=_0x1a2d21[_0x5015ef['toURLString']()];return _0x48121b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x48121b=new vd(_0x5015ef,Qd,_0x3930d4,_0x3aa191),_0x1a2d21[_0x5015ef['toURLString']()]=_0x48121b,_0x48121b;}class tf{constructor(_0x65fffe,_0x22296d){this['_repoInternal']=_0x65fffe,this['app']=_0x22296d,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x39a316){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x39a316+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x26718a=Zr(),_0x527d78){const _0x3b5e96=Hi(_0x26718a,'database')['getImmediate']({'identifier':_0x527d78});if(!_0x3b5e96['_instanceStarted']){const _0x1badc3=hc('database');_0x1badc3&&nf(_0x3b5e96,..._0x1badc3);}return _0x3b5e96;}function nf(_0x26a720,_0x40e7ea,_0x182e65,_0x256a1c={}){_0x26a720=P(_0x26a720),_0x26a720['_checkNotDeleted']('useEmulator');const _0x523fce=_0x40e7ea+':'+_0x182e65,_0x1f76b4=_0x26a720['_repoInternal'];if(_0x26a720['_instanceStarted']){if(_0x523fce===_0x26a720['_repoInternal']['repoInfo_']['host']&&xe(_0x256a1c,_0x1f76b4['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x438304;if(_0x1f76b4['repoInfo_']['nodeAdmin'])_0x256a1c['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x438304=new an(an['OWNER']);else{if(_0x256a1c['mockUserToken']){const _0x33cb9d=typeof _0x256a1c['mockUserToken']=='string'?_0x256a1c['mockUserToken']:uc(_0x256a1c['mockUserToken'],_0x26a720['app']['options']['projectId']);_0x438304=new an(_0x33cb9d);}}qt(_0x40e7ea)&&Qr(_0x40e7ea),Jd(_0x1f76b4,_0x523fce,_0x256a1c,_0x438304);}function N_(_0x35e7ba){_0x35e7ba=P(_0x35e7ba),_0x35e7ba['_checkNotDeleted']('goOffline'),ha(_0x35e7ba['_repo']);}function O_(_0xd8f513){_0xd8f513=P(_0xd8f513),_0xd8f513['_checkNotDeleted']('goOnline'),Nd(_0xd8f513['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x16e3fa){Ul(dt),st(new Fe('database',(_0x3030ca,{instanceIdentifier:_0x2ca80e})=>{const _0x48c38e=_0x3030ca['getProvider']('app')['getImmediate'](),_0x481af6=_0x3030ca['getProvider']('auth-internal'),_0x484260=_0x3030ca['getProvider']('app-check-internal');return Xd(_0x48c38e,_0x481af6,_0x484260,_0x2ca80e);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x16e3fa),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x4481d8,_0xf3597d){this['committed']=_0x4481d8,this['snapshot']=_0xf3597d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x5f5a70,_0xdbe0da,_0x2a6db1){if(_0x5f5a70=P(_0x5f5a70),Me('Reference.transaction',_0x5f5a70['_path']),_0x5f5a70['key']==='.length'||_0x5f5a70['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5f5a70['key']+'\x20is\x20a\x20read-only\x20object.';const _0x488308=!0x0,_0x5c6f7e=new H(),_0x5a4959=(_0x38a322,_0x6042cf,_0x445053)=>{let _0x1f20b2=null;_0x38a322?_0x5c6f7e['reject'](_0x38a322):(_0x1f20b2=new lt(_0x445053,new ee(_0x5f5a70['_repo'],_0x5f5a70['_path']),R),_0x5c6f7e['resolve'](new of(_0x6042cf,_0x1f20b2)));},_0x164631=Gd(_0x5f5a70,()=>{});return Od(_0x5f5a70['_repo'],_0x5f5a70['_path'],_0xdbe0da,_0x5a4959,_0x164631,_0x488308),_0x5c6f7e['promise'];}se['prototype']['simpleListen']=function(_0x318c00,_0x37bcee){this['sendRequest']('q',{'p':_0x318c00},_0x37bcee);},se['prototype']['echo']=function(_0xd60fa0,_0xa66d1d){this['sendRequest']('echo',{'d':_0xd60fa0},_0xa66d1d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x1013e8,..._0x3d0ecd){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x1013e8,..._0x3d0ecd);}function cn(_0x5041d0,..._0x2ed644){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5041d0,..._0x2ed644);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x51873e,..._0x3ef1a1){throw ws(_0x51873e,..._0x3ef1a1);}function X(_0x5c3b4e,..._0x5a51fc){return ws(_0x5c3b4e,..._0x5a51fc);}function Ia(_0x425cbd,_0x41b32c,_0x2b5e33){const _0x29e221={...af(),[_0x41b32c]:_0x2b5e33};return new Gt('auth','Firebase',_0x29e221)['create'](_0x41b32c,{'appName':_0x425cbd['name']});}function re(_0x45ecf1){return Ia(_0x45ecf1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1153a4,..._0x264eb5){if(typeof _0x1153a4!='string'){const _0x30b9dc=_0x264eb5[0x0],_0x4a8ea2=[..._0x264eb5['slice'](0x1)];return _0x4a8ea2[0x0]&&(_0x4a8ea2[0x0]['appName']=_0x1153a4['name']),_0x1153a4['_errorFactory']['create'](_0x30b9dc,..._0x4a8ea2);}return Ea['create'](_0x1153a4,..._0x264eb5);}function m(_0x21065e,_0x2ac76f,..._0x5037be){if(!_0x21065e)throw ws(_0x2ac76f,..._0x5037be);}function ne(_0x2effc5){const _0xf24286='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2effc5;throw cn(_0xf24286),new Error(_0xf24286);}function ce(_0x107b1b,_0x328dcc){_0x107b1b||ne(_0x328dcc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x31ba3a;return typeof self<'u'&&((_0x31ba3a=self['location'])==null?void 0x0:_0x31ba3a['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x45d73a;return typeof self<'u'&&((_0x45d73a=self['location'])==null?void 0x0:_0x45d73a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0xe829=navigator;return _0xe829['languages']&&_0xe829['languages'][0x0]||_0xe829['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5999f9,_0x2c889d){this['shortDelay']=_0x5999f9,this['longDelay']=_0x2c889d,ce(_0x2c889d>_0x5999f9,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xfda229,_0xba8b5f){ce(_0xfda229['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3352bd}=_0xfda229['emulator'];return _0xba8b5f?''+_0x3352bd+(_0xba8b5f['startsWith']('/')?_0xba8b5f['slice'](0x1):_0xba8b5f):_0x3352bd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x27f9ff,_0x339d37,_0x14ad02){this['fetchImpl']=_0x27f9ff,_0x339d37&&(this['headersImpl']=_0x339d37),_0x14ad02&&(this['responseImpl']=_0x14ad02);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4a076d,_0x298d17){return _0x4a076d['tenantId']&&!_0x298d17['tenantId']?{..._0x298d17,'tenantId':_0x4a076d['tenantId']}:_0x298d17;}async function Pe(_0x857f0,_0x4a1ce7,_0x142ed8,_0x5498c3,_0x221c31={}){return Ca(_0x857f0,_0x221c31,async()=>{let _0x17711e={},_0x311162={};_0x5498c3&&(_0x4a1ce7==='GET'?_0x311162=_0x5498c3:_0x17711e={'body':JSON['stringify'](_0x5498c3)});const _0x55ca5a=ut({..._0x311162,'key':_0x857f0['config']['apiKey']})['slice'](0x1),_0x21208c=await _0x857f0['_getAdditionalHeaders']();_0x21208c['Content-Type']='application/json',_0x857f0['languageCode']&&(_0x21208c['X-Firebase-Locale']=_0x857f0['languageCode']);const _0x46b73f={'method':_0x4a1ce7,'headers':_0x21208c,..._0x17711e};return dc()||(_0x46b73f['referrerPolicy']='strict-origin-when-cross-origin'),_0x857f0['emulatorConfig']&&qt(_0x857f0['emulatorConfig']['host'])&&(_0x46b73f['credentials']='include'),wa['fetch']()(await Ta(_0x857f0,_0x857f0['config']['apiHost'],_0x142ed8,_0x55ca5a),_0x46b73f);});}async function Ca(_0x4f3fa5,_0x34cd42,_0x4276bb){_0x4f3fa5['_canInitEmulator']=!0x1;const _0x1f2ae0={...df,..._0x34cd42};try{const _0x58d2aa=new gf(_0x4f3fa5),_0x395675=await Promise['race']([_0x4276bb(),_0x58d2aa['promise']]);_0x58d2aa['clearNetworkTimeout']();const _0x4d086f=await _0x395675['json']();if('needConfirmation'in _0x4d086f)throw on(_0x4f3fa5,'account-exists-with-different-credential',_0x4d086f);if(_0x395675['ok']&&!('errorMessage'in _0x4d086f))return _0x4d086f;{const _0x363e88=_0x395675['ok']?_0x4d086f['errorMessage']:_0x4d086f['error']['message'],[_0xd104cf,_0xa55889]=_0x363e88['split']('\x20:\x20');if(_0xd104cf==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x4f3fa5,'credential-already-in-use',_0x4d086f);if(_0xd104cf==='EMAIL_EXISTS')throw on(_0x4f3fa5,'email-already-in-use',_0x4d086f);if(_0xd104cf==='USER_DISABLED')throw on(_0x4f3fa5,'user-disabled',_0x4d086f);const _0x31e5f9=_0x1f2ae0[_0xd104cf]||_0xd104cf['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xa55889)throw Ia(_0x4f3fa5,_0x31e5f9,_0xa55889);Y(_0x4f3fa5,_0x31e5f9);}}catch(_0x2a6eec){if(_0x2a6eec instanceof Re)throw _0x2a6eec;Y(_0x4f3fa5,'network-request-failed',{'message':String(_0x2a6eec)});}}async function en(_0x1d5e43,_0x1a5958,_0x275041,_0x23e790,_0x1108f2={}){const _0x39b0d4=await Pe(_0x1d5e43,_0x1a5958,_0x275041,_0x23e790,_0x1108f2);return'mfaPendingCredential'in _0x39b0d4&&Y(_0x1d5e43,'multi-factor-auth-required',{'_serverResponse':_0x39b0d4}),_0x39b0d4;}async function Ta(_0x4a3d9a,_0x1e9ae8,_0x570662,_0x3b16a2){const _0x537601=''+_0x1e9ae8+_0x570662+'?'+_0x3b16a2,_0x460269=_0x4a3d9a,_0xf486a5=_0x460269['config']['emulator']?Cs(_0x4a3d9a['config'],_0x537601):_0x4a3d9a['config']['apiScheme']+'://'+_0x537601;return ff['includes'](_0x570662)&&(await _0x460269['_persistenceManagerAvailable'],_0x460269['_getPersistenceType']()==='COOKIE')?_0x460269['_getPersistence']()['_getFinalTarget'](_0xf486a5)['toString']():_0xf486a5;}function _f(_0x533e06){switch(_0x533e06){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3c201f){this['auth']=_0x3c201f,this['timer']=null,this['promise']=new Promise((_0x5e2fd4,_0x1589ca)=>{this['timer']=setTimeout(()=>_0x1589ca(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x2e2fa7,_0x33a823,_0x415408){const _0x334b80={'appName':_0x2e2fa7['name']};_0x415408['email']&&(_0x334b80['email']=_0x415408['email']),_0x415408['phoneNumber']&&(_0x334b80['phoneNumber']=_0x415408['phoneNumber']);const _0x221a0e=X(_0x2e2fa7,_0x33a823,_0x334b80);return _0x221a0e['customData']['_tokenResponse']=_0x415408,_0x221a0e;}function wr(_0x40e3d9){return _0x40e3d9!==void 0x0&&_0x40e3d9['enterprise']!==void 0x0;}class mf{constructor(_0x459250){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x459250['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x459250['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x459250['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x230b62){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2f7f4a of this['recaptchaEnforcementState'])if(_0x2f7f4a['provider']&&_0x2f7f4a['provider']===_0x230b62)return _f(_0x2f7f4a['enforcementState']);return null;}['isProviderEnabled'](_0x5044e5){return this['getProviderEnforcementState'](_0x5044e5)==='ENFORCE'||this['getProviderEnforcementState'](_0x5044e5)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1a4d55,_0x4cf21e){return Pe(_0x1a4d55,'GET','/v2/recaptchaConfig',ke(_0x1a4d55,_0x4cf21e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x57d33f,_0x48914c){return Pe(_0x57d33f,'POST','/v1/accounts:delete',_0x48914c);}async function Pn(_0x1e5813,_0x17ecbf){return Pe(_0x1e5813,'POST','/v1/accounts:lookup',_0x17ecbf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x4b9cbb){if(_0x4b9cbb)try{const _0x15f44f=new Date(Number(_0x4b9cbb));if(!isNaN(_0x15f44f['getTime']()))return _0x15f44f['toUTCString']();}catch{}}async function Ef(_0x2af818,_0x42cd77=!0x1){const _0x27b251=P(_0x2af818),_0xb1ceaa=await _0x27b251['getIdToken'](_0x42cd77),_0x457735=Ts(_0xb1ceaa);m(_0x457735&&_0x457735['exp']&&_0x457735['auth_time']&&_0x457735['iat'],_0x27b251['auth'],'internal-error');const _0x5394b3=typeof _0x457735['firebase']=='object'?_0x457735['firebase']:void 0x0,_0x4389eb=_0x5394b3==null?void 0x0:_0x5394b3['sign_in_provider'];return{'claims':_0x457735,'token':_0xb1ceaa,'authTime':Pt(fi(_0x457735['auth_time'])),'issuedAtTime':Pt(fi(_0x457735['iat'])),'expirationTime':Pt(fi(_0x457735['exp'])),'signInProvider':_0x4389eb||null,'signInSecondFactor':(_0x5394b3==null?void 0x0:_0x5394b3['sign_in_second_factor'])||null};}function fi(_0x2ee1c6){return Number(_0x2ee1c6)*0x3e8;}function Ts(_0x27592c){const [_0x3dba3f,_0x3c53bd,_0x45c71e]=_0x27592c['split']('.');if(_0x3dba3f===void 0x0||_0x3c53bd===void 0x0||_0x45c71e===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3819da=fn(_0x3c53bd);return _0x3819da?JSON['parse'](_0x3819da):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4ade43){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4ade43==null?void 0x0:_0x4ade43['toString']()),null;}}function Cr(_0x4f7a0c){const _0x490f26=Ts(_0x4f7a0c);return m(_0x490f26,'internal-error'),m(typeof _0x490f26['exp']<'u','internal-error'),m(typeof _0x490f26['iat']<'u','internal-error'),Number(_0x490f26['exp'])-Number(_0x490f26['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x93e733,_0x26f6c9,_0x68631f=!0x1){if(_0x68631f)return _0x26f6c9;try{return await _0x26f6c9;}catch(_0x3adc74){throw _0x3adc74 instanceof Re&&If(_0x3adc74)&&_0x93e733['auth']['currentUser']===_0x93e733&&await _0x93e733['auth']['signOut'](),_0x3adc74;}}function If({code:_0x5ab784}){return _0x5ab784==='auth/user-disabled'||_0x5ab784==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x137243){this['user']=_0x137243,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x32bcf8){if(_0x32bcf8){const _0x4ce7dd=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4ce7dd;}else{this['errorBackoff']=0x7530;const _0xc48249=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xc48249);}}['schedule'](_0x592f3f=!0x1){if(!this['isRunning'])return;const _0x528e17=this['getInterval'](_0x592f3f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x528e17);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1f1b26){(_0x1f1b26==null?void 0x0:_0x1f1b26['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x56b664,_0x253864){this['createdAt']=_0x56b664,this['lastLoginAt']=_0x253864,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x402ae4){this['createdAt']=_0x402ae4['createdAt'],this['lastLoginAt']=_0x402ae4['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x287179){var _0x3fb444;const _0x5f06bf=_0x287179['auth'],_0x4256b4=await _0x287179['getIdToken'](),_0x1ba805=await Ht(_0x287179,Pn(_0x5f06bf,{'idToken':_0x4256b4}));m(_0x1ba805==null?void 0x0:_0x1ba805['users']['length'],_0x5f06bf,'internal-error');const _0x49e010=_0x1ba805['users'][0x0];_0x287179['_notifyReloadListener'](_0x49e010);const _0x6d7802=(_0x3fb444=_0x49e010['providerUserInfo'])!=null&&_0x3fb444['length']?Sa(_0x49e010['providerUserInfo']):[],_0x259aee=Tf(_0x287179['providerData'],_0x6d7802),_0x1710d8=_0x287179['isAnonymous'],_0x22c13b=!(_0x287179['email']&&_0x49e010['passwordHash'])&&!(_0x259aee!=null&&_0x259aee['length']),_0x59833c=_0x1710d8?_0x22c13b:!0x1,_0x132f3e={'uid':_0x49e010['localId'],'displayName':_0x49e010['displayName']||null,'photoURL':_0x49e010['photoUrl']||null,'email':_0x49e010['email']||null,'emailVerified':_0x49e010['emailVerified']||!0x1,'phoneNumber':_0x49e010['phoneNumber']||null,'tenantId':_0x49e010['tenantId']||null,'providerData':_0x259aee,'metadata':new Li(_0x49e010['createdAt'],_0x49e010['lastLoginAt']),'isAnonymous':_0x59833c};Object['assign'](_0x287179,_0x132f3e);}async function Cf(_0x658884){const _0x4a8aa7=P(_0x658884);await Nn(_0x4a8aa7),await _0x4a8aa7['auth']['_persistUserIfCurrent'](_0x4a8aa7),_0x4a8aa7['auth']['_notifyListenersIfCurrent'](_0x4a8aa7);}function Tf(_0x59a530,_0x35fbb8){return[..._0x59a530['filter'](_0x458f14=>!_0x35fbb8['some'](_0xb185e6=>_0xb185e6['providerId']===_0x458f14['providerId'])),..._0x35fbb8];}function Sa(_0x5100dd){return _0x5100dd['map'](({providerId:_0xe1f4f5,..._0x379625})=>({'providerId':_0xe1f4f5,'uid':_0x379625['rawId']||'','displayName':_0x379625['displayName']||null,'email':_0x379625['email']||null,'phoneNumber':_0x379625['phoneNumber']||null,'photoURL':_0x379625['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x27056e,_0x2699c5){const _0xb4696=await Ca(_0x27056e,{},async()=>{const _0x4a0862=ut({'grant_type':'refresh_token','refresh_token':_0x2699c5})['slice'](0x1),{tokenApiHost:_0x3461f7,apiKey:_0x4ec7de}=_0x27056e['config'],_0x479886=await Ta(_0x27056e,_0x3461f7,'/v1/token','key='+_0x4ec7de),_0x21473e=await _0x27056e['_getAdditionalHeaders']();_0x21473e['Content-Type']='application/x-www-form-urlencoded';const _0x37a241={'method':'POST','headers':_0x21473e,'body':_0x4a0862};return _0x27056e['emulatorConfig']&&qt(_0x27056e['emulatorConfig']['host'])&&(_0x37a241['credentials']='include'),wa['fetch']()(_0x479886,_0x37a241);});return{'accessToken':_0xb4696['access_token'],'expiresIn':_0xb4696['expires_in'],'refreshToken':_0xb4696['refresh_token']};}async function bf(_0x587f37,_0x587a54){return Pe(_0x587f37,'POST','/v2/accounts:revokeToken',ke(_0x587f37,_0x587a54));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x45e5af){m(_0x45e5af['idToken'],'internal-error'),m(typeof _0x45e5af['idToken']<'u','internal-error'),m(typeof _0x45e5af['refreshToken']<'u','internal-error');const _0x55a2f8='expiresIn'in _0x45e5af&&typeof _0x45e5af['expiresIn']<'u'?Number(_0x45e5af['expiresIn']):Cr(_0x45e5af['idToken']);this['updateTokensAndExpiration'](_0x45e5af['idToken'],_0x45e5af['refreshToken'],_0x55a2f8);}['updateFromIdToken'](_0x33380f){m(_0x33380f['length']!==0x0,'internal-error');const _0x578fde=Cr(_0x33380f);this['updateTokensAndExpiration'](_0x33380f,null,_0x578fde);}async['getToken'](_0x1081ca,_0xb0427b=!0x1){return!_0xb0427b&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1081ca,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1081ca,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4acf07,_0x5b9754){const {accessToken:_0x3e8a26,refreshToken:_0x4bce03,expiresIn:_0x4335dc}=await Sf(_0x4acf07,_0x5b9754);this['updateTokensAndExpiration'](_0x3e8a26,_0x4bce03,Number(_0x4335dc));}['updateTokensAndExpiration'](_0xc82862,_0x4c9433,_0xa6c213){this['refreshToken']=_0x4c9433||null,this['accessToken']=_0xc82862||null,this['expirationTime']=Date['now']()+_0xa6c213*0x3e8;}static['fromJSON'](_0x30a36d,_0x3136e5){const {refreshToken:_0x4791b9,accessToken:_0x4ce67e,expirationTime:_0x45ddd7}=_0x3136e5,_0x1f4e0f=new et();return _0x4791b9&&(m(typeof _0x4791b9=='string','internal-error',{'appName':_0x30a36d}),_0x1f4e0f['refreshToken']=_0x4791b9),_0x4ce67e&&(m(typeof _0x4ce67e=='string','internal-error',{'appName':_0x30a36d}),_0x1f4e0f['accessToken']=_0x4ce67e),_0x45ddd7&&(m(typeof _0x45ddd7=='number','internal-error',{'appName':_0x30a36d}),_0x1f4e0f['expirationTime']=_0x45ddd7),_0x1f4e0f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x330ecb){this['accessToken']=_0x330ecb['accessToken'],this['refreshToken']=_0x330ecb['refreshToken'],this['expirationTime']=_0x330ecb['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3ac10b,_0x3b957d){m(typeof _0x3ac10b=='string'||typeof _0x3ac10b>'u','internal-error',{'appName':_0x3b957d});}class j{constructor({uid:_0x1f33d3,auth:_0x1e48e4,stsTokenManager:_0x46762d,..._0x54c73e}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1f33d3,this['auth']=_0x1e48e4,this['stsTokenManager']=_0x46762d,this['accessToken']=_0x46762d['accessToken'],this['displayName']=_0x54c73e['displayName']||null,this['email']=_0x54c73e['email']||null,this['emailVerified']=_0x54c73e['emailVerified']||!0x1,this['phoneNumber']=_0x54c73e['phoneNumber']||null,this['photoURL']=_0x54c73e['photoURL']||null,this['isAnonymous']=_0x54c73e['isAnonymous']||!0x1,this['tenantId']=_0x54c73e['tenantId']||null,this['providerData']=_0x54c73e['providerData']?[..._0x54c73e['providerData']]:[],this['metadata']=new Li(_0x54c73e['createdAt']||void 0x0,_0x54c73e['lastLoginAt']||void 0x0);}async['getIdToken'](_0xa3d470){const _0x69002f=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0xa3d470));return m(_0x69002f,this['auth'],'internal-error'),this['accessToken']!==_0x69002f&&(this['accessToken']=_0x69002f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x69002f;}['getIdTokenResult'](_0x187ccd){return Ef(this,_0x187ccd);}['reload'](){return Cf(this);}['_assign'](_0x55bdc7){this!==_0x55bdc7&&(m(this['uid']===_0x55bdc7['uid'],this['auth'],'internal-error'),this['displayName']=_0x55bdc7['displayName'],this['photoURL']=_0x55bdc7['photoURL'],this['email']=_0x55bdc7['email'],this['emailVerified']=_0x55bdc7['emailVerified'],this['phoneNumber']=_0x55bdc7['phoneNumber'],this['isAnonymous']=_0x55bdc7['isAnonymous'],this['tenantId']=_0x55bdc7['tenantId'],this['providerData']=_0x55bdc7['providerData']['map'](_0x3b877b=>({..._0x3b877b})),this['metadata']['_copy'](_0x55bdc7['metadata']),this['stsTokenManager']['_assign'](_0x55bdc7['stsTokenManager']));}['_clone'](_0x23e7d9){const _0x297218=new j({...this,'auth':_0x23e7d9,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x297218['metadata']['_copy'](this['metadata']),_0x297218;}['_onReload'](_0x4c30e0){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4c30e0,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x15686d){this['reloadListener']?this['reloadListener'](_0x15686d):this['reloadUserInfo']=_0x15686d;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1b3061,_0x1d149b=!0x1){let _0x5f08e5=!0x1;_0x1b3061['idToken']&&_0x1b3061['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1b3061),_0x5f08e5=!0x0),_0x1d149b&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5f08e5&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1ccce8=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x1ccce8})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x320404=>({..._0x320404})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x581d75,_0x487138){const _0x24f513=_0x487138['displayName']??void 0x0,_0x1056d2=_0x487138['email']??void 0x0,_0x49e99d=_0x487138['phoneNumber']??void 0x0,_0x303e14=_0x487138['photoURL']??void 0x0,_0x5aff89=_0x487138['tenantId']??void 0x0,_0x36a9e4=_0x487138['_redirectEventId']??void 0x0,_0x4ae9c8=_0x487138['createdAt']??void 0x0,_0x39bd1f=_0x487138['lastLoginAt']??void 0x0,{uid:_0x391da3,emailVerified:_0x32b2bb,isAnonymous:_0x340593,providerData:_0x334852,stsTokenManager:_0x3b01bc}=_0x487138;m(_0x391da3&&_0x3b01bc,_0x581d75,'internal-error');const _0x557717=et['fromJSON'](this['name'],_0x3b01bc);m(typeof _0x391da3=='string',_0x581d75,'internal-error'),le(_0x24f513,_0x581d75['name']),le(_0x1056d2,_0x581d75['name']),m(typeof _0x32b2bb=='boolean',_0x581d75,'internal-error'),m(typeof _0x340593=='boolean',_0x581d75,'internal-error'),le(_0x49e99d,_0x581d75['name']),le(_0x303e14,_0x581d75['name']),le(_0x5aff89,_0x581d75['name']),le(_0x36a9e4,_0x581d75['name']),le(_0x4ae9c8,_0x581d75['name']),le(_0x39bd1f,_0x581d75['name']);const _0x29d717=new j({'uid':_0x391da3,'auth':_0x581d75,'email':_0x1056d2,'emailVerified':_0x32b2bb,'displayName':_0x24f513,'isAnonymous':_0x340593,'photoURL':_0x303e14,'phoneNumber':_0x49e99d,'tenantId':_0x5aff89,'stsTokenManager':_0x557717,'createdAt':_0x4ae9c8,'lastLoginAt':_0x39bd1f});return _0x334852&&Array['isArray'](_0x334852)&&(_0x29d717['providerData']=_0x334852['map'](_0x4277a7=>({..._0x4277a7}))),_0x36a9e4&&(_0x29d717['_redirectEventId']=_0x36a9e4),_0x29d717;}static async['_fromIdTokenResponse'](_0x558209,_0x2bcf96,_0xbbb124=!0x1){const _0x11bbf8=new et();_0x11bbf8['updateFromServerResponse'](_0x2bcf96);const _0x2be8df=new j({'uid':_0x2bcf96['localId'],'auth':_0x558209,'stsTokenManager':_0x11bbf8,'isAnonymous':_0xbbb124});return await Nn(_0x2be8df),_0x2be8df;}static async['_fromGetAccountInfoResponse'](_0x5ea5dc,_0x9c3d5b,_0x567a23){const _0x497b38=_0x9c3d5b['users'][0x0];m(_0x497b38['localId']!==void 0x0,'internal-error');const _0x234a70=_0x497b38['providerUserInfo']!==void 0x0?Sa(_0x497b38['providerUserInfo']):[],_0x2279ae=!(_0x497b38['email']&&_0x497b38['passwordHash'])&&!(_0x234a70!=null&&_0x234a70['length']),_0x65018b=new et();_0x65018b['updateFromIdToken'](_0x567a23);const _0x48e518=new j({'uid':_0x497b38['localId'],'auth':_0x5ea5dc,'stsTokenManager':_0x65018b,'isAnonymous':_0x2279ae}),_0x3ec3c0={'uid':_0x497b38['localId'],'displayName':_0x497b38['displayName']||null,'photoURL':_0x497b38['photoUrl']||null,'email':_0x497b38['email']||null,'emailVerified':_0x497b38['emailVerified']||!0x1,'phoneNumber':_0x497b38['phoneNumber']||null,'tenantId':_0x497b38['tenantId']||null,'providerData':_0x234a70,'metadata':new Li(_0x497b38['createdAt'],_0x497b38['lastLoginAt']),'isAnonymous':!(_0x497b38['email']&&_0x497b38['passwordHash'])&&!(_0x234a70!=null&&_0x234a70['length'])};return Object['assign'](_0x48e518,_0x3ec3c0),_0x48e518;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1063d3){ce(_0x1063d3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3ae2b6=Tr['get'](_0x1063d3);return _0x3ae2b6?(ce(_0x3ae2b6 instanceof _0x1063d3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3ae2b6):(_0x3ae2b6=new _0x1063d3(),Tr['set'](_0x1063d3,_0x3ae2b6),_0x3ae2b6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2f4735,_0x117f88){this['storage'][_0x2f4735]=_0x117f88;}async['_get'](_0x538713){const _0x3f0849=this['storage'][_0x538713];return _0x3f0849===void 0x0?null:_0x3f0849;}async['_remove'](_0x2a746c){delete this['storage'][_0x2a746c];}['_addListener'](_0x1fbd42,_0x38b664){}['_removeListener'](_0xdc59db,_0x3c4ca0){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x2714eb,_0x5222f8,_0x535651){return'firebase:'+_0x2714eb+':'+_0x5222f8+':'+_0x535651;}class tt{constructor(_0x271326,_0x4e4bfa,_0x119502){this['persistence']=_0x271326,this['auth']=_0x4e4bfa,this['userKey']=_0x119502;const {config:_0x4d8db9,name:_0x21215e}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x4d8db9['apiKey'],_0x21215e),this['fullPersistenceKey']=ln('persistence',_0x4d8db9['apiKey'],_0x21215e),this['boundEventHandler']=_0x4e4bfa['_onStorageEvent']['bind'](_0x4e4bfa),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xc387cb){return this['persistence']['_set'](this['fullUserKey'],_0xc387cb['toJSON']());}async['getCurrentUser'](){const _0x4ab1ca=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4ab1ca)return null;if(typeof _0x4ab1ca=='string'){const _0x3db48c=await Pn(this['auth'],{'idToken':_0x4ab1ca})['catch'](()=>{});return _0x3db48c?j['_fromGetAccountInfoResponse'](this['auth'],_0x3db48c,_0x4ab1ca):null;}return j['_fromJSON'](this['auth'],_0x4ab1ca);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5191ec){if(this['persistence']===_0x5191ec)return;const _0x1eb030=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5191ec,_0x1eb030)return this['setCurrentUser'](_0x1eb030);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x22914b,_0x4edd5a,_0x2d0b26='authUser'){if(!_0x4edd5a['length'])return new tt(ie(Sr),_0x22914b,_0x2d0b26);const _0xd5fefa=(await Promise['all'](_0x4edd5a['map'](async _0x575ed8=>{if(await _0x575ed8['_isAvailable']())return _0x575ed8;})))['filter'](_0x4cbd03=>_0x4cbd03);let _0x174247=_0xd5fefa[0x0]||ie(Sr);const _0x5db0f9=ln(_0x2d0b26,_0x22914b['config']['apiKey'],_0x22914b['name']);let _0x545206=null;for(const _0x4157b0 of _0x4edd5a)try{const _0xaf690a=await _0x4157b0['_get'](_0x5db0f9);if(_0xaf690a){let _0x5d811e;if(typeof _0xaf690a=='string'){const _0x104039=await Pn(_0x22914b,{'idToken':_0xaf690a})['catch'](()=>{});if(!_0x104039)break;_0x5d811e=await j['_fromGetAccountInfoResponse'](_0x22914b,_0x104039,_0xaf690a);}else _0x5d811e=j['_fromJSON'](_0x22914b,_0xaf690a);_0x4157b0!==_0x174247&&(_0x545206=_0x5d811e),_0x174247=_0x4157b0;break;}}catch{}const _0x2d4fa0=_0xd5fefa['filter'](_0x381fca=>_0x381fca['_shouldAllowMigration']);return!_0x174247['_shouldAllowMigration']||!_0x2d4fa0['length']?new tt(_0x174247,_0x22914b,_0x2d0b26):(_0x174247=_0x2d4fa0[0x0],_0x545206&&await _0x174247['_set'](_0x5db0f9,_0x545206['toJSON']()),await Promise['all'](_0x4edd5a['map'](async _0x30d38e=>{if(_0x30d38e!==_0x174247)try{await _0x30d38e['_remove'](_0x5db0f9);}catch{}})),new tt(_0x174247,_0x22914b,_0x2d0b26));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x48f4b4){const _0x10209c=_0x48f4b4['toLowerCase']();if(_0x10209c['includes']('opera/')||_0x10209c['includes']('opr/')||_0x10209c['includes']('opios/'))return'Opera';if(Pa(_0x10209c))return'IEMobile';if(_0x10209c['includes']('msie')||_0x10209c['includes']('trident/'))return'IE';if(_0x10209c['includes']('edge/'))return'Edge';if(Ra(_0x10209c))return'Firefox';if(_0x10209c['includes']('silk/'))return'Silk';if(Oa(_0x10209c))return'Blackberry';if(Da(_0x10209c))return'Webos';if(Aa(_0x10209c))return'Safari';if((_0x10209c['includes']('chrome/')||ka(_0x10209c))&&!_0x10209c['includes']('edge/'))return'Chrome';if(Na(_0x10209c))return'Android';{const _0x5deec7=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x492a9e=_0x48f4b4['match'](_0x5deec7);if((_0x492a9e==null?void 0x0:_0x492a9e['length'])===0x2)return _0x492a9e[0x1];}return'Other';}function Ra(_0x34a8b6=W()){return/firefox\//i['test'](_0x34a8b6);}function Aa(_0x20b550=W()){const _0x25ac1d=_0x20b550['toLowerCase']();return _0x25ac1d['includes']('safari/')&&!_0x25ac1d['includes']('chrome/')&&!_0x25ac1d['includes']('crios/')&&!_0x25ac1d['includes']('android');}function ka(_0x184331=W()){return/crios\//i['test'](_0x184331);}function Pa(_0x548555=W()){return/iemobile/i['test'](_0x548555);}function Na(_0x1e13e9=W()){return/android/i['test'](_0x1e13e9);}function Oa(_0x18a2d3=W()){return/blackberry/i['test'](_0x18a2d3);}function Da(_0x28ddd5=W()){return/webos/i['test'](_0x28ddd5);}function Ss(_0x3f975a=W()){return/iphone|ipad|ipod/i['test'](_0x3f975a)||/macintosh/i['test'](_0x3f975a)&&/mobile/i['test'](_0x3f975a);}function Rf(_0x7cea72=W()){var _0x20b152;return Ss(_0x7cea72)&&!!((_0x20b152=window['navigator'])!=null&&_0x20b152['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x63e618=W()){return Ss(_0x63e618)||Na(_0x63e618)||Da(_0x63e618)||Oa(_0x63e618)||/windows phone/i['test'](_0x63e618)||Pa(_0x63e618);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x550b2b,_0x2e4d90=[]){let _0x23b5fd;switch(_0x550b2b){case'Browser':_0x23b5fd=br(W());break;case'Worker':_0x23b5fd=br(W())+'-'+_0x550b2b;break;default:_0x23b5fd=_0x550b2b;}const _0x262e02=_0x2e4d90['length']?_0x2e4d90['join'](','):'FirebaseCore-web';return _0x23b5fd+'/JsCore/'+dt+'/'+_0x262e02;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x12152b){this['auth']=_0x12152b,this['queue']=[];}['pushCallback'](_0x1c6512,_0x23662d){const _0x57988e=_0x249c87=>new Promise((_0x2dd096,_0x5efa7e)=>{try{const _0x591cf8=_0x1c6512(_0x249c87);_0x2dd096(_0x591cf8);}catch(_0x423ecd){_0x5efa7e(_0x423ecd);}});_0x57988e['onAbort']=_0x23662d,this['queue']['push'](_0x57988e);const _0x45bdb8=this['queue']['length']-0x1;return()=>{this['queue'][_0x45bdb8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x480393){if(this['auth']['currentUser']===_0x480393)return;const _0x2786ab=[];try{for(const _0x365460 of this['queue'])await _0x365460(_0x480393),_0x365460['onAbort']&&_0x2786ab['push'](_0x365460['onAbort']);}catch(_0xacca4e){_0x2786ab['reverse']();for(const _0x1c7b89 of _0x2786ab)try{_0x1c7b89();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xacca4e==null?void 0x0:_0xacca4e['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x57efae,_0x2bd7d7={}){return Pe(_0x57efae,'GET','/v2/passwordPolicy',ke(_0x57efae,_0x2bd7d7));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x379b8e){var _0x4c6ad3;const _0x561b7a=_0x379b8e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x561b7a['minPasswordLength']??Nf,_0x561b7a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x561b7a['maxPasswordLength']),_0x561b7a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x561b7a['containsLowercaseCharacter']),_0x561b7a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x561b7a['containsUppercaseCharacter']),_0x561b7a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x561b7a['containsNumericCharacter']),_0x561b7a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x561b7a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x379b8e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4c6ad3=_0x379b8e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4c6ad3['join'](''))??'',this['forceUpgradeOnSignin']=_0x379b8e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x379b8e['schemaVersion'];}['validatePassword'](_0x2f7598){const _0x20f5eb={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2f7598,_0x20f5eb),this['validatePasswordCharacterOptions'](_0x2f7598,_0x20f5eb),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['meetsMinPasswordLength']??!0x0),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['meetsMaxPasswordLength']??!0x0),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['containsLowercaseLetter']??!0x0),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['containsUppercaseLetter']??!0x0),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['containsNumericCharacter']??!0x0),_0x20f5eb['isValid']&&(_0x20f5eb['isValid']=_0x20f5eb['containsNonAlphanumericCharacter']??!0x0),_0x20f5eb;}['validatePasswordLengthOptions'](_0x3be135,_0x3f9e86){const _0xd40545=this['customStrengthOptions']['minPasswordLength'],_0x3d4b1d=this['customStrengthOptions']['maxPasswordLength'];_0xd40545&&(_0x3f9e86['meetsMinPasswordLength']=_0x3be135['length']>=_0xd40545),_0x3d4b1d&&(_0x3f9e86['meetsMaxPasswordLength']=_0x3be135['length']<=_0x3d4b1d);}['validatePasswordCharacterOptions'](_0x255c21,_0xd01e72){this['updatePasswordCharacterOptionsStatuses'](_0xd01e72,!0x1,!0x1,!0x1,!0x1);let _0x3a6856;for(let _0x14763d=0x0;_0x14763d<_0x255c21['length'];_0x14763d++)_0x3a6856=_0x255c21['charAt'](_0x14763d),this['updatePasswordCharacterOptionsStatuses'](_0xd01e72,_0x3a6856>='a'&&_0x3a6856<='z',_0x3a6856>='A'&&_0x3a6856<='Z',_0x3a6856>='0'&&_0x3a6856<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3a6856));}['updatePasswordCharacterOptionsStatuses'](_0x140342,_0x4d1521,_0xc5b56b,_0x498e77,_0xba527a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x140342['containsLowercaseLetter']||(_0x140342['containsLowercaseLetter']=_0x4d1521)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x140342['containsUppercaseLetter']||(_0x140342['containsUppercaseLetter']=_0xc5b56b)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x140342['containsNumericCharacter']||(_0x140342['containsNumericCharacter']=_0x498e77)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x140342['containsNonAlphanumericCharacter']||(_0x140342['containsNonAlphanumericCharacter']=_0xba527a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x17796d,_0x560af1,_0x4ef3a2,_0x558e18){this['app']=_0x17796d,this['heartbeatServiceProvider']=_0x560af1,this['appCheckServiceProvider']=_0x4ef3a2,this['config']=_0x558e18,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x17796d['name'],this['clientVersion']=_0x558e18['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x398193=>this['_resolvePersistenceManagerAvailable']=_0x398193);}['_initializeWithPersistence'](_0x4693c7,_0x1bcc69){return _0x1bcc69&&(this['_popupRedirectResolver']=ie(_0x1bcc69)),this['_initializationPromise']=this['queue'](async()=>{var _0x57fce5,_0x1ab841,_0xda9c2a;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4693c7),(_0x57fce5=this['_resolvePersistenceManagerAvailable'])==null||_0x57fce5['call'](this),!this['_deleted'])){if((_0x1ab841=this['_popupRedirectResolver'])!=null&&_0x1ab841['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1bcc69),this['lastNotifiedUid']=((_0xda9c2a=this['currentUser'])==null?void 0x0:_0xda9c2a['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x24939e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x24939e)){if(this['currentUser']&&_0x24939e&&this['currentUser']['uid']===_0x24939e['uid']){this['_currentUser']['_assign'](_0x24939e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x24939e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x26c574){try{const _0x14e8d8=await Pn(this,{'idToken':_0x26c574}),_0x3695ba=await j['_fromGetAccountInfoResponse'](this,_0x14e8d8,_0x26c574);await this['directlySetCurrentUser'](_0x3695ba);}catch(_0x42bdc3){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x42bdc3),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5b7b86){var _0x5da541;if($(this['app'])){const _0x3456d3=this['app']['settings']['authIdToken'];return _0x3456d3?new Promise(_0x1addc8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3456d3)['then'](_0x1addc8,_0x1addc8));}):this['directlySetCurrentUser'](null);}const _0xe2f3c8=await this['assertedPersistence']['getCurrentUser']();let _0x583c18=_0xe2f3c8,_0x530efc=!0x1;if(_0x5b7b86&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1feecc=(_0x5da541=this['redirectUser'])==null?void 0x0:_0x5da541['_redirectEventId'],_0x57d77f=_0x583c18==null?void 0x0:_0x583c18['_redirectEventId'],_0x2498c5=await this['tryRedirectSignIn'](_0x5b7b86);(!_0x1feecc||_0x1feecc===_0x57d77f)&&(_0x2498c5!=null&&_0x2498c5['user'])&&(_0x583c18=_0x2498c5['user'],_0x530efc=!0x0);}if(!_0x583c18)return this['directlySetCurrentUser'](null);if(!_0x583c18['_redirectEventId']){if(_0x530efc)try{await this['beforeStateQueue']['runMiddleware'](_0x583c18);}catch(_0x458e87){_0x583c18=_0xe2f3c8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x458e87));}return _0x583c18?this['reloadAndSetCurrentUserOrClear'](_0x583c18):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x583c18['_redirectEventId']?this['directlySetCurrentUser'](_0x583c18):this['reloadAndSetCurrentUserOrClear'](_0x583c18);}async['tryRedirectSignIn'](_0x1d2e0a){let _0x1e1f5e=null;try{_0x1e1f5e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1d2e0a,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1e1f5e;}async['reloadAndSetCurrentUserOrClear'](_0x18d860){try{await Nn(_0x18d860);}catch(_0x1ffb0a){if((_0x1ffb0a==null?void 0x0:_0x1ffb0a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x18d860);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5805e5){if($(this['app']))return Promise['reject'](re(this));const _0x4e94d9=_0x5805e5?P(_0x5805e5):null;return _0x4e94d9&&m(_0x4e94d9['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4e94d9&&_0x4e94d9['_clone'](this));}async['_updateCurrentUser'](_0x1eb1e4,_0x20fcfa=!0x1){if(!this['_deleted'])return _0x1eb1e4&&m(this['tenantId']===_0x1eb1e4['tenantId'],this,'tenant-id-mismatch'),_0x20fcfa||await this['beforeStateQueue']['runMiddleware'](_0x1eb1e4),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1eb1e4),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5ea697){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5ea697));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x428cf7){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x57b193=this['_getPasswordPolicyInternal']();return _0x57b193['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x57b193['validatePassword'](_0x428cf7);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3fea69=await Pf(this),_0x1afbfb=new Of(_0x3fea69);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1afbfb:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1afbfb;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5a984f){this['_errorFactory']=new Gt('auth','Firebase',_0x5a984f());}['onAuthStateChanged'](_0x53cc2d,_0x1e7cd9,_0x56181f){return this['registerStateListener'](this['authStateSubscription'],_0x53cc2d,_0x1e7cd9,_0x56181f);}['beforeAuthStateChanged'](_0x5c214e,_0x405283){return this['beforeStateQueue']['pushCallback'](_0x5c214e,_0x405283);}['onIdTokenChanged'](_0x16533f,_0x3753c7,_0x17ec77){return this['registerStateListener'](this['idTokenSubscription'],_0x16533f,_0x3753c7,_0x17ec77);}['authStateReady'](){return new Promise((_0x33a682,_0x5abc4b)=>{if(this['currentUser'])_0x33a682();else{const _0x5e88e0=this['onAuthStateChanged'](()=>{_0x5e88e0(),_0x33a682();},_0x5abc4b);}});}async['revokeAccessToken'](_0x35b370){if(this['currentUser']){const _0x29c82d=await this['currentUser']['getIdToken'](),_0x1664ea={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x35b370,'idToken':_0x29c82d};this['tenantId']!=null&&(_0x1664ea['tenantId']=this['tenantId']),await bf(this,_0x1664ea);}}['toJSON'](){var _0x18eeec;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x18eeec=this['_currentUser'])==null?void 0x0:_0x18eeec['toJSON']()};}async['_setRedirectUser'](_0x9f8401,_0x2fd555){const _0x4057bb=await this['getOrInitRedirectPersistenceManager'](_0x2fd555);return _0x9f8401===null?_0x4057bb['removeCurrentUser']():_0x4057bb['setCurrentUser'](_0x9f8401);}async['getOrInitRedirectPersistenceManager'](_0x29d5a9){if(!this['redirectPersistenceManager']){const _0x206d49=_0x29d5a9&&ie(_0x29d5a9)||this['_popupRedirectResolver'];m(_0x206d49,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x206d49['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x14c6ef){var _0x54ac4c,_0x55bd66;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x54ac4c=this['_currentUser'])==null?void 0x0:_0x54ac4c['_redirectEventId'])===_0x14c6ef?this['_currentUser']:((_0x55bd66=this['redirectUser'])==null?void 0x0:_0x55bd66['_redirectEventId'])===_0x14c6ef?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x309a82){if(_0x309a82===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x309a82));}['_notifyListenersIfCurrent'](_0xcf9814){_0xcf9814===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2547fd;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x22a636=((_0x2547fd=this['currentUser'])==null?void 0x0:_0x2547fd['uid'])??null;this['lastNotifiedUid']!==_0x22a636&&(this['lastNotifiedUid']=_0x22a636,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x9240fd,_0x310852,_0x1ce87c,_0x42259c){if(this['_deleted'])return()=>{};const _0x2947de=typeof _0x310852=='function'?_0x310852:_0x310852['next']['bind'](_0x310852);let _0x5602fb=!0x1;const _0x1f929a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1f929a,this,'internal-error'),_0x1f929a['then'](()=>{_0x5602fb||_0x2947de(this['currentUser']);}),typeof _0x310852=='function'){const _0x53f69b=_0x9240fd['addObserver'](_0x310852,_0x1ce87c,_0x42259c);return()=>{_0x5602fb=!0x0,_0x53f69b();};}else{const _0x41b6d6=_0x9240fd['addObserver'](_0x310852);return()=>{_0x5602fb=!0x0,_0x41b6d6();};}}async['directlySetCurrentUser'](_0x266011){this['currentUser']&&this['currentUser']!==_0x266011&&this['_currentUser']['_stopProactiveRefresh'](),_0x266011&&this['isProactiveRefreshEnabled']&&_0x266011['_startProactiveRefresh'](),this['currentUser']=_0x266011,_0x266011?await this['assertedPersistence']['setCurrentUser'](_0x266011):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x598b3b){return this['operations']=this['operations']['then'](_0x598b3b,_0x598b3b),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x54606f){!_0x54606f||this['frameworks']['includes'](_0x54606f)||(this['frameworks']['push'](_0x54606f),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x17b7ad;const _0x55b604={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x55b604['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xd17145=await((_0x17b7ad=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x17b7ad['getHeartbeatsHeader']());_0xd17145&&(_0x55b604['X-Firebase-Client']=_0xd17145);const _0x38b047=await this['_getAppCheckToken']();return _0x38b047&&(_0x55b604['X-Firebase-AppCheck']=_0x38b047),_0x55b604;}async['_getAppCheckToken'](){var _0x5ce237;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x248378=await((_0x5ce237=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5ce237['getToken']());return _0x248378!=null&&_0x248378['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x248378['error']),_0x248378==null?void 0x0:_0x248378['token'];}}function Ke(_0x524820){return P(_0x524820);}class Rr{constructor(_0x5db5eb){this['auth']=_0x5db5eb,this['observer']=null,this['addObserver']=Tc(_0x50beac=>this['observer']=_0x50beac);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5cf341){Jn=_0x5cf341;}function xa(_0x1b4a3e){return Jn['loadJS'](_0x1b4a3e);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x33e596){return'__'+_0x33e596+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x4aecea){_0x4aecea();}['execute'](_0x46d920,_0x4b5a3e){return Promise['resolve']('token');}['render'](_0x25ebf9,_0x442751){return'';}}class Wf{['ready'](_0x464e6c){_0x464e6c();}['execute'](_0x11d5c9,_0x1e50a7){return Promise['resolve']('token');}['render'](_0xe5e4c3,_0x31fc70){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x4aafd1){this['type']=Bf,this['auth']=Ke(_0x4aafd1);}async['verify'](_0x152b46='verify',_0x191fa7=!0x1){async function _0x42bd34(_0x5a03a4){if(!_0x191fa7){if(_0x5a03a4['tenantId']==null&&_0x5a03a4['_agentRecaptchaConfig']!=null)return _0x5a03a4['_agentRecaptchaConfig']['siteKey'];if(_0x5a03a4['tenantId']!=null&&_0x5a03a4['_tenantRecaptchaConfigs'][_0x5a03a4['tenantId']]!==void 0x0)return _0x5a03a4['_tenantRecaptchaConfigs'][_0x5a03a4['tenantId']]['siteKey'];}return new Promise(async(_0x5b3f7e,_0x284049)=>{yf(_0x5a03a4,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x471831=>{if(_0x471831['recaptchaKey']===void 0x0)_0x284049(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x26649d=new mf(_0x471831);return _0x5a03a4['tenantId']==null?_0x5a03a4['_agentRecaptchaConfig']=_0x26649d:_0x5a03a4['_tenantRecaptchaConfigs'][_0x5a03a4['tenantId']]=_0x26649d,_0x5b3f7e(_0x26649d['siteKey']);}})['catch'](_0x1b8db5=>{_0x284049(_0x1b8db5);});});}function _0x19656a(_0x20529a,_0x46517c,_0x226e61){const _0x2128b8=window['grecaptcha'];wr(_0x2128b8)?_0x2128b8['enterprise']['ready'](()=>{_0x2128b8['enterprise']['execute'](_0x20529a,{'action':_0x152b46})['then'](_0x4ba96b=>{_0x46517c(_0x4ba96b);})['catch'](()=>{_0x46517c(Fa);});}):_0x226e61(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x541623,_0x551f9a)=>{_0x42bd34(this['auth'])['then'](async _0x471738=>{if(!_0x191fa7&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x19656a(_0x471738,_0x541623,_0x551f9a);else{if(typeof window>'u'){_0x551f9a(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x271b4d=Lf();_0x271b4d['length']!==0x0&&(_0x271b4d+=_0x471738+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x255b6c;(_0x255b6c=he['scriptInjectionDeferred'])==null||_0x255b6c['resolve']();},xa(_0x271b4d)['then'](()=>{var _0x4ddc55;return(_0x4ddc55=he['scriptInjectionDeferred'])==null?void 0x0:_0x4ddc55['promise'];})['then'](()=>{_0x19656a(_0x471738,_0x541623,_0x551f9a);})['catch'](_0x6aa5b6=>{_0x551f9a(_0x6aa5b6);});}})['catch'](_0x576b1b=>{_0x551f9a(_0x576b1b);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x43096d,_0x1433e3,_0x39f6fb,_0x2089d4=!0x1,_0x174f9c=!0x1){const _0x1f2107=new he(_0x43096d);let _0x314b3e;if(_0x174f9c)_0x314b3e=Fa;else try{_0x314b3e=await _0x1f2107['verify'](_0x39f6fb);}catch{_0x314b3e=await _0x1f2107['verify'](_0x39f6fb,!0x0);}const _0x3a8bcc={..._0x1433e3};if(_0x39f6fb==='mfaSmsEnrollment'||_0x39f6fb==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3a8bcc){const _0x3d6d70=_0x3a8bcc['phoneEnrollmentInfo']['phoneNumber'],_0x487ceb=_0x3a8bcc['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3a8bcc,{'phoneEnrollmentInfo':{'phoneNumber':_0x3d6d70,'recaptchaToken':_0x487ceb,'captchaResponse':_0x314b3e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3a8bcc){const _0x4baf53=_0x3a8bcc['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3a8bcc,{'phoneSignInInfo':{'recaptchaToken':_0x4baf53,'captchaResponse':_0x314b3e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3a8bcc;}return _0x2089d4?Object['assign'](_0x3a8bcc,{'captchaResp':_0x314b3e}):Object['assign'](_0x3a8bcc,{'captchaResponse':_0x314b3e}),Object['assign'](_0x3a8bcc,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3a8bcc,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3a8bcc;}async function xi(_0x1f82a6,_0x3ee476,_0x366e9f,_0x239c2b,_0x2ccf1e){var _0x302c41;if((_0x302c41=_0x1f82a6['_getRecaptchaConfig']())!=null&&_0x302c41['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x27b283=await kr(_0x1f82a6,_0x3ee476,_0x366e9f,_0x366e9f==='getOobCode');return _0x239c2b(_0x1f82a6,_0x27b283);}else return _0x239c2b(_0x1f82a6,_0x3ee476)['catch'](async _0x1fcd4d=>{if(_0x1fcd4d['code']==='auth/missing-recaptcha-token'){console['log'](_0x366e9f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3a5894=await kr(_0x1f82a6,_0x3ee476,_0x366e9f,_0x366e9f==='getOobCode');return _0x239c2b(_0x1f82a6,_0x3a5894);}else return Promise['reject'](_0x1fcd4d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x75493b,_0x57f6c1){const _0x6e1a40=Hi(_0x75493b,'auth');if(_0x6e1a40['isInitialized']()){const _0x10bbee=_0x6e1a40['getImmediate'](),_0x6df3a8=_0x6e1a40['getOptions']();if(xe(_0x6df3a8,_0x57f6c1??{}))return _0x10bbee;Y(_0x10bbee,'already-initialized');}return _0x6e1a40['initialize']({'options':_0x57f6c1});}function Hf(_0x3efa3f,_0x5d4ef){const _0x2340b5=(_0x5d4ef==null?void 0x0:_0x5d4ef['persistence'])||[],_0x45da3c=(Array['isArray'](_0x2340b5)?_0x2340b5:[_0x2340b5])['map'](ie);_0x5d4ef!=null&&_0x5d4ef['errorMap']&&_0x3efa3f['_updateErrorMap'](_0x5d4ef['errorMap']),_0x3efa3f['_initializeWithPersistence'](_0x45da3c,_0x5d4ef==null?void 0x0:_0x5d4ef['popupRedirectResolver']);}function $f(_0x5f541a,_0x19c2c2,_0x31421c){const _0xfe7fbc=Ke(_0x5f541a);m(/^https?:\/\//['test'](_0x19c2c2),_0xfe7fbc,'invalid-emulator-scheme');const _0x28bdc5=!0x1,_0x432c00=Ua(_0x19c2c2),{host:_0x12717e,port:_0x297e06}=Gf(_0x19c2c2),_0x10390d=_0x297e06===null?'':':'+_0x297e06,_0x1a1189={'url':_0x432c00+'//'+_0x12717e+_0x10390d+'/'},_0x56b239=Object['freeze']({'host':_0x12717e,'port':_0x297e06,'protocol':_0x432c00['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x28bdc5})});if(!_0xfe7fbc['_canInitEmulator']){m(_0xfe7fbc['config']['emulator']&&_0xfe7fbc['emulatorConfig'],_0xfe7fbc,'emulator-config-failed'),m(xe(_0x1a1189,_0xfe7fbc['config']['emulator'])&&xe(_0x56b239,_0xfe7fbc['emulatorConfig']),_0xfe7fbc,'emulator-config-failed');return;}_0xfe7fbc['config']['emulator']=_0x1a1189,_0xfe7fbc['emulatorConfig']=_0x56b239,_0xfe7fbc['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x12717e)?Qr(_0x432c00+'//'+_0x12717e+_0x10390d):qf();}function Ua(_0x3b9964){const _0x367104=_0x3b9964['indexOf'](':');return _0x367104<0x0?'':_0x3b9964['substr'](0x0,_0x367104+0x1);}function Gf(_0x108bcd){const _0x5d5c72=Ua(_0x108bcd),_0x515b1e=/(\/\/)?([^?#/]+)/['exec'](_0x108bcd['substr'](_0x5d5c72['length']));if(!_0x515b1e)return{'host':'','port':null};const _0x1183e0=_0x515b1e[0x2]['split']('@')['pop']()||'',_0x5b0e0b=/^(\[[^\]]+\])(:|$)/['exec'](_0x1183e0);if(_0x5b0e0b){const _0x4d98a0=_0x5b0e0b[0x1];return{'host':_0x4d98a0,'port':Pr(_0x1183e0['substr'](_0x4d98a0['length']+0x1))};}else{const [_0x158592,_0x333fd1]=_0x1183e0['split'](':');return{'host':_0x158592,'port':Pr(_0x333fd1)};}}function Pr(_0x49c8fa){if(!_0x49c8fa)return null;const _0x552a03=Number(_0x49c8fa);return isNaN(_0x552a03)?null:_0x552a03;}function qf(){function _0x3f90cd(){const _0x386813=document['createElement']('p'),_0x535a63=_0x386813['style'];_0x386813['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x535a63['position']='fixed',_0x535a63['width']='100%',_0x535a63['backgroundColor']='#ffffff',_0x535a63['border']='.1em\x20solid\x20#000000',_0x535a63['color']='#b50000',_0x535a63['bottom']='0px',_0x535a63['left']='0px',_0x535a63['margin']='0px',_0x535a63['zIndex']='10000',_0x535a63['textAlign']='center',_0x386813['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x386813);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3f90cd):_0x3f90cd());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5ab439,_0x44e2fa){this['providerId']=_0x5ab439,this['signInMethod']=_0x44e2fa;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x522f4a){return ne('not\x20implemented');}['_linkToIdToken'](_0x8e3e26,_0x5b7c60){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x11a9a9){return ne('not\x20implemented');}}async function zf(_0x599d5f,_0x6730be){return Pe(_0x599d5f,'POST','/v1/accounts:signUp',_0x6730be);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x4a12b1,_0x129679){return en(_0x4a12b1,'POST','/v1/accounts:signInWithPassword',ke(_0x4a12b1,_0x129679));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x59053a,_0x5393ef){return en(_0x59053a,'POST','/v1/accounts:signInWithEmailLink',ke(_0x59053a,_0x5393ef));}async function Yf(_0x2675a3,_0x3c0945){return en(_0x2675a3,'POST','/v1/accounts:signInWithEmailLink',ke(_0x2675a3,_0x3c0945));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1f3c70,_0x5ac3bc,_0x4b6306,_0x1b0732=null){super('password',_0x4b6306),this['_email']=_0x1f3c70,this['_password']=_0x5ac3bc,this['_tenantId']=_0x1b0732;}static['_fromEmailAndPassword'](_0x19d340,_0x4bd7bb){return new $t(_0x19d340,_0x4bd7bb,'password');}static['_fromEmailAndCode'](_0x336e32,_0x5c0fdb,_0x4eb337=null){return new $t(_0x336e32,_0x5c0fdb,'emailLink',_0x4eb337);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x20cf32){const _0x37e386=typeof _0x20cf32=='string'?JSON['parse'](_0x20cf32):_0x20cf32;if(_0x37e386!=null&&_0x37e386['email']&&(_0x37e386!=null&&_0x37e386['password'])){if(_0x37e386['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x37e386['email'],_0x37e386['password']);if(_0x37e386['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x37e386['email'],_0x37e386['password'],_0x37e386['tenantId']);}return null;}async['_getIdTokenResponse'](_0x225b47){switch(this['signInMethod']){case'password':const _0x73c25b={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x225b47,_0x73c25b,'signInWithPassword',jf);case'emailLink':return Kf(_0x225b47,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x225b47,'internal-error');}}async['_linkToIdToken'](_0x4c9a5e,_0x3ef570){switch(this['signInMethod']){case'password':const _0x2dadd5={'idToken':_0x3ef570,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4c9a5e,_0x2dadd5,'signUpPassword',zf);case'emailLink':return Yf(_0x4c9a5e,{'idToken':_0x3ef570,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4c9a5e,'internal-error');}}['_getReauthenticationResolver'](_0x423924){return this['_getIdTokenResponse'](_0x423924);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0xbd8e32,_0x21b2f7){return en(_0xbd8e32,'POST','/v1/accounts:signInWithIdp',ke(_0xbd8e32,_0x21b2f7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2957be){const _0x4365a1=new $e(_0x2957be['providerId'],_0x2957be['signInMethod']);return _0x2957be['idToken']||_0x2957be['accessToken']?(_0x2957be['idToken']&&(_0x4365a1['idToken']=_0x2957be['idToken']),_0x2957be['accessToken']&&(_0x4365a1['accessToken']=_0x2957be['accessToken']),_0x2957be['nonce']&&!_0x2957be['pendingToken']&&(_0x4365a1['nonce']=_0x2957be['nonce']),_0x2957be['pendingToken']&&(_0x4365a1['pendingToken']=_0x2957be['pendingToken'])):_0x2957be['oauthToken']&&_0x2957be['oauthTokenSecret']?(_0x4365a1['accessToken']=_0x2957be['oauthToken'],_0x4365a1['secret']=_0x2957be['oauthTokenSecret']):Y('argument-error'),_0x4365a1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x291325){const _0x25b488=typeof _0x291325=='string'?JSON['parse'](_0x291325):_0x291325,{providerId:_0xeb6f94,signInMethod:_0x9e5923,..._0x1cc31a}=_0x25b488;if(!_0xeb6f94||!_0x9e5923)return null;const _0x289104=new $e(_0xeb6f94,_0x9e5923);return _0x289104['idToken']=_0x1cc31a['idToken']||void 0x0,_0x289104['accessToken']=_0x1cc31a['accessToken']||void 0x0,_0x289104['secret']=_0x1cc31a['secret'],_0x289104['nonce']=_0x1cc31a['nonce'],_0x289104['pendingToken']=_0x1cc31a['pendingToken']||null,_0x289104;}['_getIdTokenResponse'](_0x2801c0){const _0xbe8eae=this['buildRequest']();return nt(_0x2801c0,_0xbe8eae);}['_linkToIdToken'](_0x2790b1,_0x16029c){const _0xe8b703=this['buildRequest']();return _0xe8b703['idToken']=_0x16029c,nt(_0x2790b1,_0xe8b703);}['_getReauthenticationResolver'](_0x5da63c){const _0x1fb444=this['buildRequest']();return _0x1fb444['autoCreate']=!0x1,nt(_0x5da63c,_0x1fb444);}['buildRequest'](){const _0x54b7d9={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x54b7d9['pendingToken']=this['pendingToken'];else{const _0x4eab92={};this['idToken']&&(_0x4eab92['id_token']=this['idToken']),this['accessToken']&&(_0x4eab92['access_token']=this['accessToken']),this['secret']&&(_0x4eab92['oauth_token_secret']=this['secret']),_0x4eab92['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4eab92['nonce']=this['nonce']),_0x54b7d9['postBody']=ut(_0x4eab92);}return _0x54b7d9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x315d17){switch(_0x315d17){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x210c0a){const _0x5a0704=Ct(Tt(_0x210c0a))['link'],_0x53a05f=_0x5a0704?Ct(Tt(_0x5a0704))['deep_link_id']:null,_0x91f6a4=Ct(Tt(_0x210c0a))['deep_link_id'];return(_0x91f6a4?Ct(Tt(_0x91f6a4))['link']:null)||_0x91f6a4||_0x53a05f||_0x5a0704||_0x210c0a;}class Rs{constructor(_0x4b5126){const _0x54c177=Ct(Tt(_0x4b5126)),_0x5b1f94=_0x54c177['apiKey']??null,_0x6d888c=_0x54c177['oobCode']??null,_0x3cae36=Jf(_0x54c177['mode']??null);m(_0x5b1f94&&_0x6d888c&&_0x3cae36,'argument-error'),this['apiKey']=_0x5b1f94,this['operation']=_0x3cae36,this['code']=_0x6d888c,this['continueUrl']=_0x54c177['continueUrl']??null,this['languageCode']=_0x54c177['lang']??null,this['tenantId']=_0x54c177['tenantId']??null;}static['parseLink'](_0x9cb4d5){const _0x247f48=Xf(_0x9cb4d5);try{return new Rs(_0x247f48);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x5083a0,_0x22ea11){return $t['_fromEmailAndPassword'](_0x5083a0,_0x22ea11);}static['credentialWithLink'](_0x1013b6,_0x5cfbaf){const _0x500fbf=Rs['parseLink'](_0x5cfbaf);return m(_0x500fbf,'argument-error'),$t['_fromEmailAndCode'](_0x1013b6,_0x500fbf['code'],_0x500fbf['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x4b6133){this['providerId']=_0x4b6133,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4bf762){this['defaultLanguageCode']=_0x4bf762;}['setCustomParameters'](_0x4a0042){return this['customParameters']=_0x4a0042,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3cff6f){return this['scopes']['includes'](_0x3cff6f)||this['scopes']['push'](_0x3cff6f),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4224b0){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4224b0});}static['credentialFromResult'](_0x28bbcb){return ue['credentialFromTaggedObject'](_0x28bbcb);}static['credentialFromError'](_0x45b6c8){return ue['credentialFromTaggedObject'](_0x45b6c8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x319b5c}){if(!_0x319b5c||!('oauthAccessToken'in _0x319b5c)||!_0x319b5c['oauthAccessToken'])return null;try{return ue['credential'](_0x319b5c['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5db587,_0x599631){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5db587,'accessToken':_0x599631});}static['credentialFromResult'](_0x224de8){return de['credentialFromTaggedObject'](_0x224de8);}static['credentialFromError'](_0x3bf67c){return de['credentialFromTaggedObject'](_0x3bf67c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1cf9f7}){if(!_0x1cf9f7)return null;const {oauthIdToken:_0x81a14a,oauthAccessToken:_0x4ce7b0}=_0x1cf9f7;if(!_0x81a14a&&!_0x4ce7b0)return null;try{return de['credential'](_0x81a14a,_0x4ce7b0);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4502a8){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4502a8});}static['credentialFromResult'](_0x5193f5){return fe['credentialFromTaggedObject'](_0x5193f5);}static['credentialFromError'](_0x109d04){return fe['credentialFromTaggedObject'](_0x109d04['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22591e}){if(!_0x22591e||!('oauthAccessToken'in _0x22591e)||!_0x22591e['oauthAccessToken'])return null;try{return fe['credential'](_0x22591e['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x2d32ad,_0x42ed64){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2d32ad,'oauthTokenSecret':_0x42ed64});}static['credentialFromResult'](_0x30647b){return pe['credentialFromTaggedObject'](_0x30647b);}static['credentialFromError'](_0x415672){return pe['credentialFromTaggedObject'](_0x415672['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x51c4f6}){if(!_0x51c4f6)return null;const {oauthAccessToken:_0xe56f8a,oauthTokenSecret:_0x3f0f6e}=_0x51c4f6;if(!_0xe56f8a||!_0x3f0f6e)return null;try{return pe['credential'](_0xe56f8a,_0x3f0f6e);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x950f4b,_0x2697bd){return en(_0x950f4b,'POST','/v1/accounts:signUp',ke(_0x950f4b,_0x2697bd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0xfb9606){this['user']=_0xfb9606['user'],this['providerId']=_0xfb9606['providerId'],this['_tokenResponse']=_0xfb9606['_tokenResponse'],this['operationType']=_0xfb9606['operationType'];}static async['_fromIdTokenResponse'](_0x4303f7,_0x51084c,_0x573591,_0x3a71fe=!0x1){const _0x26ff95=await j['_fromIdTokenResponse'](_0x4303f7,_0x573591,_0x3a71fe),_0x1fc437=Nr(_0x573591);return new Ge({'user':_0x26ff95,'providerId':_0x1fc437,'_tokenResponse':_0x573591,'operationType':_0x51084c});}static async['_forOperation'](_0x52c050,_0x6d0297,_0x77a226){await _0x52c050['_updateTokensIfNecessary'](_0x77a226,!0x0);const _0x29a8f4=Nr(_0x77a226);return new Ge({'user':_0x52c050,'providerId':_0x29a8f4,'_tokenResponse':_0x77a226,'operationType':_0x6d0297});}}function Nr(_0x3caad2){return _0x3caad2['providerId']?_0x3caad2['providerId']:'phoneNumber'in _0x3caad2?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x1ce66f,_0x513aa0,_0xf8930b,_0x375ea2){super(_0x513aa0['code'],_0x513aa0['message']),this['operationType']=_0xf8930b,this['user']=_0x375ea2,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x1ce66f['name'],'tenantId':_0x1ce66f['tenantId']??void 0x0,'_serverResponse':_0x513aa0['customData']['_serverResponse'],'operationType':_0xf8930b};}static['_fromErrorAndOperation'](_0x5ada5d,_0x47072e,_0x5028e5,_0x2b6c36){return new On(_0x5ada5d,_0x47072e,_0x5028e5,_0x2b6c36);}}function Ba(_0x167117,_0x4e1a98,_0xfecb95,_0x3a0fa7){return(_0x4e1a98==='reauthenticate'?_0xfecb95['_getReauthenticationResolver'](_0x167117):_0xfecb95['_getIdTokenResponse'](_0x167117))['catch'](_0x3fa061=>{throw _0x3fa061['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x167117,_0x3fa061,_0x4e1a98,_0x3a0fa7):_0x3fa061;});}async function ep(_0x644714,_0x6206e4,_0x5690fe=!0x1){const _0x1add34=await Ht(_0x644714,_0x6206e4['_linkToIdToken'](_0x644714['auth'],await _0x644714['getIdToken']()),_0x5690fe);return Ge['_forOperation'](_0x644714,'link',_0x1add34);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x5986ed,_0x2a08a1,_0x3bcf8d=!0x1){const {auth:_0x5839f6}=_0x5986ed;if($(_0x5839f6['app']))return Promise['reject'](re(_0x5839f6));const _0x406585='reauthenticate';try{const _0x264c56=await Ht(_0x5986ed,Ba(_0x5839f6,_0x406585,_0x2a08a1,_0x5986ed),_0x3bcf8d);m(_0x264c56['idToken'],_0x5839f6,'internal-error');const _0x4a5631=Ts(_0x264c56['idToken']);m(_0x4a5631,_0x5839f6,'internal-error');const {sub:_0x166a5d}=_0x4a5631;return m(_0x5986ed['uid']===_0x166a5d,_0x5839f6,'user-mismatch'),Ge['_forOperation'](_0x5986ed,_0x406585,_0x264c56);}catch(_0x4f9758){throw(_0x4f9758==null?void 0x0:_0x4f9758['code'])==='auth/user-not-found'&&Y(_0x5839f6,'user-mismatch'),_0x4f9758;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4ec6ec,_0x50f323,_0x77930e=!0x1){if($(_0x4ec6ec['app']))return Promise['reject'](re(_0x4ec6ec));const _0x1de296='signIn',_0x278fc8=await Ba(_0x4ec6ec,_0x1de296,_0x50f323),_0x76cac6=await Ge['_fromIdTokenResponse'](_0x4ec6ec,_0x1de296,_0x278fc8);return _0x77930e||await _0x4ec6ec['_updateCurrentUser'](_0x76cac6['user']),_0x76cac6;}async function np(_0x419464,_0x263250){return Va(Ke(_0x419464),_0x263250);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x3ecd35){const _0x2e6fe1=Ke(_0x3ecd35);_0x2e6fe1['_getPasswordPolicyInternal']()&&await _0x2e6fe1['_updatePasswordPolicy']();}async function L_(_0x1a31d4,_0x18a2e6,_0x436beb){if($(_0x1a31d4['app']))return Promise['reject'](re(_0x1a31d4));const _0x4fab12=Ke(_0x1a31d4),_0x33d0b5=await xi(_0x4fab12,{'returnSecureToken':!0x0,'email':_0x18a2e6,'password':_0x436beb,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x3efdef=>{throw _0x3efdef['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1a31d4),_0x3efdef;}),_0x3c6576=await Ge['_fromIdTokenResponse'](_0x4fab12,'signIn',_0x33d0b5);return await _0x4fab12['_updateCurrentUser'](_0x3c6576['user']),_0x3c6576;}function x_(_0x44d684,_0x2785d6,_0x433869){return $(_0x44d684['app'])?Promise['reject'](re(_0x44d684)):np(P(_0x44d684),yt['credential'](_0x2785d6,_0x433869))['catch'](async _0x4fa324=>{throw _0x4fa324['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x44d684),_0x4fa324;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x10d936,_0x17da7c){return P(_0x10d936)['setPersistence'](_0x17da7c);}function ip(_0x59a5d6,_0x173fc1,_0x4af0d4,_0x47dab6){return P(_0x59a5d6)['onIdTokenChanged'](_0x173fc1,_0x4af0d4,_0x47dab6);}function sp(_0x470382,_0x357245,_0x4a72fb){return P(_0x470382)['beforeAuthStateChanged'](_0x357245,_0x4a72fb);}function U_(_0x2b378f,_0x3994dc,_0x2ca375,_0xd10c6a){return P(_0x2b378f)['onAuthStateChanged'](_0x3994dc,_0x2ca375,_0xd10c6a);}function W_(_0x638b36){return P(_0x638b36)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x51805f,_0x8ab19){this['storageRetriever']=_0x51805f,this['type']=_0x8ab19;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xc9e6d8,_0x2f9d21){return this['storage']['setItem'](_0xc9e6d8,JSON['stringify'](_0x2f9d21)),Promise['resolve']();}['_get'](_0xcbd5be){const _0x12177f=this['storage']['getItem'](_0xcbd5be);return Promise['resolve'](_0x12177f?JSON['parse'](_0x12177f):null);}['_remove'](_0x500cf9){return this['storage']['removeItem'](_0x500cf9),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5d8315,_0x190dd3)=>this['onStorageEvent'](_0x5d8315,_0x190dd3),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x6d10b5){for(const _0x38115f of Object['keys'](this['listeners'])){const _0x509cfc=this['storage']['getItem'](_0x38115f),_0x464238=this['localCache'][_0x38115f];_0x509cfc!==_0x464238&&_0x6d10b5(_0x38115f,_0x464238,_0x509cfc);}}['onStorageEvent'](_0x47ac39,_0x547315=!0x1){if(!_0x47ac39['key']){this['forAllChangedKeys']((_0x3e8715,_0x374ac8,_0x340b64)=>{this['notifyListeners'](_0x3e8715,_0x340b64);});return;}const _0x3cffb8=_0x47ac39['key'];_0x547315?this['detachListener']():this['stopPolling']();const _0x146d6b=()=>{const _0x15d4b7=this['storage']['getItem'](_0x3cffb8);!_0x547315&&this['localCache'][_0x3cffb8]===_0x15d4b7||this['notifyListeners'](_0x3cffb8,_0x15d4b7);},_0x522c41=this['storage']['getItem'](_0x3cffb8);Af()&&_0x522c41!==_0x47ac39['newValue']&&_0x47ac39['newValue']!==_0x47ac39['oldValue']?setTimeout(_0x146d6b,op):_0x146d6b();}['notifyListeners'](_0x3ce0c4,_0x45f3d9){this['localCache'][_0x3ce0c4]=_0x45f3d9;const _0x208ccb=this['listeners'][_0x3ce0c4];if(_0x208ccb){for(const _0x3a74a4 of Array['from'](_0x208ccb))_0x3a74a4(_0x45f3d9&&JSON['parse'](_0x45f3d9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3c141a,_0x41c3c1,_0xca6efe)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3c141a,'oldValue':_0x41c3c1,'newValue':_0xca6efe}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xb993b2,_0x2a16e3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xb993b2]||(this['listeners'][_0xb993b2]=new Set(),this['localCache'][_0xb993b2]=this['storage']['getItem'](_0xb993b2)),this['listeners'][_0xb993b2]['add'](_0x2a16e3);}['_removeListener'](_0x22f847,_0x44262e){this['listeners'][_0x22f847]&&(this['listeners'][_0x22f847]['delete'](_0x44262e),this['listeners'][_0x22f847]['size']===0x0&&delete this['listeners'][_0x22f847]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1dcbb4,_0x1f3e55){await super['_set'](_0x1dcbb4,_0x1f3e55),this['localCache'][_0x1dcbb4]=JSON['stringify'](_0x1f3e55);}async['_get'](_0x2786ae){const _0xb713b=await super['_get'](_0x2786ae);return this['localCache'][_0x2786ae]=JSON['stringify'](_0xb713b),_0xb713b;}async['_remove'](_0x11cb4a){await super['_remove'](_0x11cb4a),delete this['localCache'][_0x11cb4a];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x45164,_0x316d11){}['_removeListener'](_0x4b4051,_0x382585){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5357bc){return Promise['all'](_0x5357bc['map'](async _0x408186=>{try{return{'fulfilled':!0x0,'value':await _0x408186};}catch(_0x489aeb){return{'fulfilled':!0x1,'reason':_0x489aeb};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x110f1c){this['eventTarget']=_0x110f1c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1c6a27){const _0x1842f4=this['receivers']['find'](_0x83dae7=>_0x83dae7['isListeningto'](_0x1c6a27));if(_0x1842f4)return _0x1842f4;const _0x9336aa=new Xn(_0x1c6a27);return this['receivers']['push'](_0x9336aa),_0x9336aa;}['isListeningto'](_0x173ecc){return this['eventTarget']===_0x173ecc;}async['handleEvent'](_0x301496){const _0x29dfb6=_0x301496,{eventId:_0x49b9fc,eventType:_0x228da1,data:_0x23a6ed}=_0x29dfb6['data'],_0x31a886=this['handlersMap'][_0x228da1];if(!(_0x31a886!=null&&_0x31a886['size']))return;_0x29dfb6['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x49b9fc,'eventType':_0x228da1});const _0x3c17bf=Array['from'](_0x31a886)['map'](async _0x5a6b9e=>_0x5a6b9e(_0x29dfb6['origin'],_0x23a6ed)),_0x439e77=await cp(_0x3c17bf);_0x29dfb6['ports'][0x0]['postMessage']({'status':'done','eventId':_0x49b9fc,'eventType':_0x228da1,'response':_0x439e77});}['_subscribe'](_0x9f7e19,_0x5b1b2a){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x9f7e19]||(this['handlersMap'][_0x9f7e19]=new Set()),this['handlersMap'][_0x9f7e19]['add'](_0x5b1b2a);}['_unsubscribe'](_0x22bca8,_0x241601){this['handlersMap'][_0x22bca8]&&_0x241601&&this['handlersMap'][_0x22bca8]['delete'](_0x241601),(!_0x241601||this['handlersMap'][_0x22bca8]['size']===0x0)&&delete this['handlersMap'][_0x22bca8],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x2c2856='',_0x5085e7=0xa){let _0x1ea9af='';for(let _0x14a74d=0x0;_0x14a74d<_0x5085e7;_0x14a74d++)_0x1ea9af+=Math['floor'](Math['random']()*0xa);return _0x2c2856+_0x1ea9af;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x322f6b){this['target']=_0x322f6b,this['handlers']=new Set();}['removeMessageHandler'](_0x426408){_0x426408['messageChannel']&&(_0x426408['messageChannel']['port1']['removeEventListener']('message',_0x426408['onMessage']),_0x426408['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x426408);}async['_send'](_0x3af6c,_0x434862,_0x512a69=0x32){const _0x21eb18=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x21eb18)throw new Error('connection_unavailable');let _0x1537e7,_0x166eb7;return new Promise((_0x2c5d16,_0x226714)=>{const _0x4ee3cf=As('',0x14);_0x21eb18['port1']['start']();const _0x5d2bed=setTimeout(()=>{_0x226714(new Error('unsupported_event'));},_0x512a69);_0x166eb7={'messageChannel':_0x21eb18,'onMessage'(_0x5e699c){const _0x891c24=_0x5e699c;if(_0x891c24['data']['eventId']===_0x4ee3cf)switch(_0x891c24['data']['status']){case'ack':clearTimeout(_0x5d2bed),_0x1537e7=setTimeout(()=>{_0x226714(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1537e7),_0x2c5d16(_0x891c24['data']['response']);break;default:clearTimeout(_0x5d2bed),clearTimeout(_0x1537e7),_0x226714(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x166eb7),_0x21eb18['port1']['addEventListener']('message',_0x166eb7['onMessage']),this['target']['postMessage']({'eventType':_0x3af6c,'eventId':_0x4ee3cf,'data':_0x434862},[_0x21eb18['port2']]);})['finally'](()=>{_0x166eb7&&this['removeMessageHandler'](_0x166eb7);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0xf29d0e){Z()['location']['href']=_0xf29d0e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2c0704;return((_0x2c0704=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2c0704['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4b48c1){this['request']=_0x4b48c1;}['toPromise'](){return new Promise((_0x16045a,_0x3f6198)=>{this['request']['addEventListener']('success',()=>{_0x16045a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3f6198(this['request']['error']);});});}}function Zn(_0x54bae0,_0x58359d){return _0x54bae0['transaction']([Mn],_0x58359d?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x886ad=indexedDB['deleteDatabase'](Ka);return new nn(_0x886ad)['toPromise']();}function Qa(){const _0x28e951=indexedDB['open'](Ka,pp);return new Promise((_0xb0dfaa,_0x49c0a6)=>{_0x28e951['addEventListener']('error',()=>{_0x49c0a6(_0x28e951['error']);}),_0x28e951['addEventListener']('upgradeneeded',()=>{const _0x958900=_0x28e951['result'];try{_0x958900['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x25999f){_0x49c0a6(_0x25999f);}}),_0x28e951['addEventListener']('success',async()=>{const _0x25a6f4=_0x28e951['result'];_0x25a6f4['objectStoreNames']['contains'](Mn)?_0xb0dfaa(_0x25a6f4):(_0x25a6f4['close'](),await _p(),_0xb0dfaa(await Qa()));});});}async function Or(_0x149465,_0x34a3ce,_0x38124d){const _0xe9a8a3=Zn(_0x149465,!0x0)['put']({[Ya]:_0x34a3ce,'value':_0x38124d});return new nn(_0xe9a8a3)['toPromise']();}async function gp(_0x51a724,_0xf37e84){const _0x163ad7=Zn(_0x51a724,!0x1)['get'](_0xf37e84),_0x47d829=await new nn(_0x163ad7)['toPromise']();return _0x47d829===void 0x0?null:_0x47d829['value'];}function Dr(_0x8c7fa3,_0x4a17aa){const _0x1b83ce=Zn(_0x8c7fa3,!0x0)['delete'](_0x4a17aa);return new nn(_0x1b83ce)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1fd10c){let _0x41696e=0x0;for(;;)try{const _0x8dff58=await this['_openDb']();return await _0x1fd10c(_0x8dff58);}catch(_0x5743bb){if(_0x41696e++>yp)throw _0x5743bb;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x31c3dd,_0x3bebbe)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3bebbe['key'])})),this['receiver']['_subscribe']('ping',async(_0x354eb0,_0x5a4f44)=>['keyChanged']);}async['initializeSender'](){var _0x2bdd9d,_0x1a8258;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x551575=await this['sender']['_send']('ping',{},0x320);_0x551575&&(_0x2bdd9d=_0x551575[0x0])!=null&&_0x2bdd9d['fulfilled']&&(_0x1a8258=_0x551575[0x0])!=null&&_0x1a8258['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x194555){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x194555},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5868d3=>{await Or(_0x5868d3,Dn,'1'),await Dr(_0x5868d3,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x178c74){this['pendingWrites']++;try{await _0x178c74();}finally{this['pendingWrites']--;}}async['_set'](_0x59c860,_0x431e48){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x26fbca=>Or(_0x26fbca,_0x59c860,_0x431e48)),this['localCache'][_0x59c860]=_0x431e48,this['notifyServiceWorker'](_0x59c860)));}async['_get'](_0x309610){const _0x567372=await this['_withRetries'](_0x515ff2=>gp(_0x515ff2,_0x309610));return this['localCache'][_0x309610]=_0x567372,_0x567372;}async['_remove'](_0x1f569e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x736ef3=>Dr(_0x736ef3,_0x1f569e)),delete this['localCache'][_0x1f569e],this['notifyServiceWorker'](_0x1f569e)));}async['_poll'](){const _0x67a271=await this['_withRetries'](_0x511793=>{const _0x2579a6=Zn(_0x511793,!0x1)['getAll']();return new nn(_0x2579a6)['toPromise']();});if(!_0x67a271)return[];if(this['pendingWrites']!==0x0)return[];const _0x85c5da=[],_0x291bd6=new Set();if(_0x67a271['length']!==0x0){for(const {fbase_key:_0x1ba3ac,value:_0x109040}of _0x67a271)_0x291bd6['add'](_0x1ba3ac),JSON['stringify'](this['localCache'][_0x1ba3ac])!==JSON['stringify'](_0x109040)&&(this['notifyListeners'](_0x1ba3ac,_0x109040),_0x85c5da['push'](_0x1ba3ac));}for(const _0x11b3e8 of Object['keys'](this['localCache']))this['localCache'][_0x11b3e8]&&!_0x291bd6['has'](_0x11b3e8)&&(this['notifyListeners'](_0x11b3e8,null),_0x85c5da['push'](_0x11b3e8));return _0x85c5da;}['notifyListeners'](_0x3fcd53,_0x21e6c9){this['localCache'][_0x3fcd53]=_0x21e6c9;const _0x1cdf81=this['listeners'][_0x3fcd53];if(_0x1cdf81){for(const _0x39f6bf of Array['from'](_0x1cdf81))_0x39f6bf(_0x21e6c9);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x366ef7,_0x1faabf){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x366ef7]||(this['listeners'][_0x366ef7]=new Set(),this['_get'](_0x366ef7)),this['listeners'][_0x366ef7]['add'](_0x1faabf);}['_removeListener'](_0x3c1f1b,_0x58a28b){this['listeners'][_0x3c1f1b]&&(this['listeners'][_0x3c1f1b]['delete'](_0x58a28b),this['listeners'][_0x3c1f1b]['size']===0x0&&delete this['listeners'][_0x3c1f1b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x7f0200,_0x48f5d2){return _0x48f5d2?ie(_0x48f5d2):(m(_0x7f0200['_popupRedirectResolver'],_0x7f0200,'argument-error'),_0x7f0200['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x29ee2d){super('custom','custom'),this['params']=_0x29ee2d;}['_getIdTokenResponse'](_0x4bfcd2){return nt(_0x4bfcd2,this['_buildIdpRequest']());}['_linkToIdToken'](_0x250b5c,_0x3da7e1){return nt(_0x250b5c,this['_buildIdpRequest'](_0x3da7e1));}['_getReauthenticationResolver'](_0xb5bb01){return nt(_0xb5bb01,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x8020f7){const _0xfa870d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x8020f7&&(_0xfa870d['idToken']=_0x8020f7),_0xfa870d;}}function Ip(_0x198bab){return Va(_0x198bab['auth'],new ks(_0x198bab),_0x198bab['bypassAuthState']);}function wp(_0x1f4e36){const {auth:_0x29646b,user:_0x2075db}=_0x1f4e36;return m(_0x2075db,_0x29646b,'internal-error'),tp(_0x2075db,new ks(_0x1f4e36),_0x1f4e36['bypassAuthState']);}async function Cp(_0x1e4bcf){const {auth:_0x4cd2d3,user:_0x48d9aa}=_0x1e4bcf;return m(_0x48d9aa,_0x4cd2d3,'internal-error'),ep(_0x48d9aa,new ks(_0x1e4bcf),_0x1e4bcf['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x1506b6,_0x3e150e,_0x6381e9,_0x56a306,_0x524e44=!0x1){this['auth']=_0x1506b6,this['resolver']=_0x6381e9,this['user']=_0x56a306,this['bypassAuthState']=_0x524e44,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3e150e)?_0x3e150e:[_0x3e150e];}['execute'](){return new Promise(async(_0x26044f,_0x36f054)=>{this['pendingPromise']={'resolve':_0x26044f,'reject':_0x36f054};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x26b208){this['reject'](_0x26b208);}});}async['onAuthEvent'](_0x2eed0c){const {urlResponse:_0x15ee93,sessionId:_0x5c624d,postBody:_0xd7b11b,tenantId:_0x68a806,error:_0x3311ba,type:_0x2ed606}=_0x2eed0c;if(_0x3311ba){this['reject'](_0x3311ba);return;}const _0x2993f9={'auth':this['auth'],'requestUri':_0x15ee93,'sessionId':_0x5c624d,'tenantId':_0x68a806||void 0x0,'postBody':_0xd7b11b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2ed606)(_0x2993f9));}catch(_0x4d165e){this['reject'](_0x4d165e);}}['onError'](_0x1df733){this['reject'](_0x1df733);}['getIdpTask'](_0x3b2c22){switch(_0x3b2c22){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x343de5){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x343de5),this['unregisterAndCleanUp']();}['reject'](_0x28babb){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x28babb),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x14477b,_0x584d4b,_0x252747,_0x3c8e52,_0x2b5d64){super(_0x14477b,_0x584d4b,_0x3c8e52,_0x2b5d64),this['provider']=_0x252747,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x16f4a9=await this['execute']();return m(_0x16f4a9,this['auth'],'internal-error'),_0x16f4a9;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x288fa7=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x288fa7),this['authWindow']['associatedEvent']=_0x288fa7,this['resolver']['_originValidation'](this['auth'])['catch'](_0x27766e=>{this['reject'](_0x27766e);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x48b594=>{_0x48b594||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x54acc1;return((_0x54acc1=this['authWindow'])==null?void 0x0:_0x54acc1['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3bedcc=()=>{var _0x248439,_0x78d696;if((_0x78d696=(_0x248439=this['authWindow'])==null?void 0x0:_0x248439['window'])!=null&&_0x78d696['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3bedcc,Tp['get']());};_0x3bedcc();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x1f2e55,_0x495363,_0x5ddf09=!0x1){super(_0x1f2e55,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x495363,void 0x0,_0x5ddf09),this['eventId']=null;}async['execute'](){let _0x2926ca=hn['get'](this['auth']['_key']());if(!_0x2926ca){try{const _0x6b4ffd=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x2926ca=()=>Promise['resolve'](_0x6b4ffd);}catch(_0x2fe1fb){_0x2926ca=()=>Promise['reject'](_0x2fe1fb);}hn['set'](this['auth']['_key'](),_0x2926ca);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2926ca();}async['onAuthEvent'](_0x33f3ad){if(_0x33f3ad['type']==='signInViaRedirect')return super['onAuthEvent'](_0x33f3ad);if(_0x33f3ad['type']==='unknown'){this['resolve'](null);return;}if(_0x33f3ad['eventId']){const _0x41b46c=await this['auth']['_redirectUserForId'](_0x33f3ad['eventId']);if(_0x41b46c)return this['user']=_0x41b46c,super['onAuthEvent'](_0x33f3ad);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x424836,_0x13bd71){const _0x5647c1=Pp(_0x13bd71),_0x2f7caa=kp(_0x424836);if(!await _0x2f7caa['_isAvailable']())return!0x1;const _0x411f27=await _0x2f7caa['_get'](_0x5647c1)==='true';return await _0x2f7caa['_remove'](_0x5647c1),_0x411f27;}function Ap(_0x16a2ea,_0x28811f){hn['set'](_0x16a2ea['_key'](),_0x28811f);}function kp(_0x577333){return ie(_0x577333['_redirectPersistence']);}function Pp(_0x33dc0d){return ln(Sp,_0x33dc0d['config']['apiKey'],_0x33dc0d['name']);}async function Np(_0x4ca3c6,_0x4c3d8f,_0x3491e1=!0x1){if($(_0x4ca3c6['app']))return Promise['reject'](re(_0x4ca3c6));const _0x47db9f=Ke(_0x4ca3c6),_0x23db5e=Ep(_0x47db9f,_0x4c3d8f),_0x12d834=await new bp(_0x47db9f,_0x23db5e,_0x3491e1)['execute']();return _0x12d834&&!_0x3491e1&&(delete _0x12d834['user']['_redirectEventId'],await _0x47db9f['_persistUserIfCurrent'](_0x12d834['user']),await _0x47db9f['_setRedirectUser'](null,_0x4c3d8f)),_0x12d834;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x1facab){this['auth']=_0x1facab,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1e02cc){this['consumers']['add'](_0x1e02cc),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1e02cc)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1e02cc),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4e1b1c){this['consumers']['delete'](_0x4e1b1c);}['onEvent'](_0x4123d3){if(this['hasEventBeenHandled'](_0x4123d3))return!0x1;let _0xa9cadd=!0x1;return this['consumers']['forEach'](_0xeb56a2=>{this['isEventForConsumer'](_0x4123d3,_0xeb56a2)&&(_0xa9cadd=!0x0,this['sendToConsumer'](_0x4123d3,_0xeb56a2),this['saveEventToCache'](_0x4123d3));}),this['hasHandledPotentialRedirect']||!Mp(_0x4123d3)||(this['hasHandledPotentialRedirect']=!0x0,_0xa9cadd||(this['queuedRedirectEvent']=_0x4123d3,_0xa9cadd=!0x0)),_0xa9cadd;}['sendToConsumer'](_0x4064fe,_0xabf9df){var _0xf3227c;if(_0x4064fe['error']&&!Za(_0x4064fe)){const _0x3e03e7=((_0xf3227c=_0x4064fe['error']['code'])==null?void 0x0:_0xf3227c['split']('auth/')[0x1])||'internal-error';_0xabf9df['onError'](X(this['auth'],_0x3e03e7));}else _0xabf9df['onAuthEvent'](_0x4064fe);}['isEventForConsumer'](_0x5611d6,_0x1ba23e){const _0x305599=_0x1ba23e['eventId']===null||!!_0x5611d6['eventId']&&_0x5611d6['eventId']===_0x1ba23e['eventId'];return _0x1ba23e['filter']['includes'](_0x5611d6['type'])&&_0x305599;}['hasEventBeenHandled'](_0x4dbc66){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x4dbc66));}['saveEventToCache'](_0x22bae5){this['cachedEventUids']['add'](Mr(_0x22bae5)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1b3977){return[_0x1b3977['type'],_0x1b3977['eventId'],_0x1b3977['sessionId'],_0x1b3977['tenantId']]['filter'](_0xfeaafe=>_0xfeaafe)['join']('-');}function Za({type:_0x1d879e,error:_0x203555}){return _0x1d879e==='unknown'&&(_0x203555==null?void 0x0:_0x203555['code'])==='auth/no-auth-event';}function Mp(_0x35d127){switch(_0x35d127['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x35d127);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x2a7f03,_0xc39bcc={}){return Pe(_0x2a7f03,'GET','/v1/projects',_0xc39bcc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x40ba10){if(_0x40ba10['config']['emulator'])return;const {authorizedDomains:_0x375262}=await Lp(_0x40ba10);for(const _0xd1e068 of _0x375262)try{if(Wp(_0xd1e068))return;}catch{}Y(_0x40ba10,'unauthorized-domain');}function Wp(_0x576558){const _0x2bcea7=Mi(),{protocol:_0xd823cd,hostname:_0xa49257}=new URL(_0x2bcea7);if(_0x576558['startsWith']('chrome-extension://')){const _0x3450be=new URL(_0x576558);return _0x3450be['hostname']===''&&_0xa49257===''?_0xd823cd==='chrome-extension:'&&_0x576558['replace']('chrome-extension://','')===_0x2bcea7['replace']('chrome-extension://',''):_0xd823cd==='chrome-extension:'&&_0x3450be['hostname']===_0xa49257;}if(!Fp['test'](_0xd823cd))return!0x1;if(xp['test'](_0x576558))return _0xa49257===_0x576558;const _0x3267ba=_0x576558['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3267ba+'|'+_0x3267ba+')$','i')['test'](_0xa49257);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x4cde31=Z()['___jsl'];if(_0x4cde31!=null&&_0x4cde31['H']){for(const _0x5713b2 of Object['keys'](_0x4cde31['H']))if(_0x4cde31['H'][_0x5713b2]['r']=_0x4cde31['H'][_0x5713b2]['r']||[],_0x4cde31['H'][_0x5713b2]['L']=_0x4cde31['H'][_0x5713b2]['L']||[],_0x4cde31['H'][_0x5713b2]['r']=[..._0x4cde31['H'][_0x5713b2]['L']],_0x4cde31['CP']){for(let _0x692955=0x0;_0x692955<_0x4cde31['CP']['length'];_0x692955++)_0x4cde31['CP'][_0x692955]=null;}}}function Vp(_0x4e15b3){return new Promise((_0x38c4c7,_0x236aeb)=>{var _0x5efaf4,_0x3919db,_0x4f8f9d;function _0x20bb1f(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x38c4c7(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x236aeb(X(_0x4e15b3,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x3919db=(_0x5efaf4=Z()['gapi'])==null?void 0x0:_0x5efaf4['iframes'])!=null&&_0x3919db['Iframe'])_0x38c4c7(gapi['iframes']['getContext']());else{if((_0x4f8f9d=Z()['gapi'])!=null&&_0x4f8f9d['load'])_0x20bb1f();else{const _0x3ac3da=Ff('iframefcb');return Z()[_0x3ac3da]=()=>{gapi['load']?_0x20bb1f():_0x236aeb(X(_0x4e15b3,'network-request-failed'));},xa(xf()+'?onload='+_0x3ac3da)['catch'](_0x2e504c=>_0x236aeb(_0x2e504c));}}})['catch'](_0x41ee4e=>{throw un=null,_0x41ee4e;});}let un=null;function Hp(_0x50903f){return un=un||Vp(_0x50903f),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x194cf8){const _0x573934=_0x194cf8['config'];m(_0x573934['authDomain'],_0x194cf8,'auth-domain-config-required');const _0x4c5b3f=_0x573934['emulator']?Cs(_0x573934,qp):'https://'+_0x194cf8['config']['authDomain']+'/'+Gp,_0x24ffd0={'apiKey':_0x573934['apiKey'],'appName':_0x194cf8['name'],'v':dt},_0xbca592=jp['get'](_0x194cf8['config']['apiHost']);_0xbca592&&(_0x24ffd0['eid']=_0xbca592);const _0x5a5655=_0x194cf8['_getFrameworks']();return _0x5a5655['length']&&(_0x24ffd0['fw']=_0x5a5655['join'](',')),_0x4c5b3f+'?'+ut(_0x24ffd0)['slice'](0x1);}async function Yp(_0x1911fd){const _0x4eef51=await Hp(_0x1911fd),_0x2c5eb7=Z()['gapi'];return m(_0x2c5eb7,_0x1911fd,'internal-error'),_0x4eef51['open']({'where':document['body'],'url':Kp(_0x1911fd),'messageHandlersFilter':_0x2c5eb7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x4b6f38=>new Promise(async(_0x1443db,_0x24248e)=>{await _0x4b6f38['restyle']({'setHideOnLeave':!0x1});const _0x15d640=X(_0x1911fd,'network-request-failed'),_0x3b0f34=Z()['setTimeout'](()=>{_0x24248e(_0x15d640);},$p['get']());function _0x3b6c44(){Z()['clearTimeout'](_0x3b0f34),_0x1443db(_0x4b6f38);}_0x4b6f38['ping'](_0x3b6c44)['then'](_0x3b6c44,()=>{_0x24248e(_0x15d640);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x87b2ba){this['window']=_0x87b2ba,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x15a9d4,_0x4cbe3e,_0x4f507c,_0x122349=Jp,_0x343618=Xp){const _0x23c25d=Math['max']((window['screen']['availHeight']-_0x343618)/0x2,0x0)['toString'](),_0x4c06e7=Math['max']((window['screen']['availWidth']-_0x122349)/0x2,0x0)['toString']();let _0x100560='';const _0x136ae0={...Qp,'width':_0x122349['toString'](),'height':_0x343618['toString'](),'top':_0x23c25d,'left':_0x4c06e7},_0x1252e3=W()['toLowerCase']();_0x4f507c&&(_0x100560=ka(_0x1252e3)?Zp:_0x4f507c),Ra(_0x1252e3)&&(_0x4cbe3e=_0x4cbe3e||e_,_0x136ae0['scrollbars']='yes');const _0x2df89a=Object['entries'](_0x136ae0)['reduce']((_0x53bfaf,[_0x387f16,_0x5b46c1])=>''+_0x53bfaf+_0x387f16+'='+_0x5b46c1+',','');if(Rf(_0x1252e3)&&_0x100560!=='_self')return n_(_0x4cbe3e||'',_0x100560),new xr(null);const _0x6e2b35=window['open'](_0x4cbe3e||'',_0x100560,_0x2df89a);m(_0x6e2b35,_0x15a9d4,'popup-blocked');try{_0x6e2b35['focus']();}catch{}return new xr(_0x6e2b35);}function n_(_0x2e19a7,_0x364df0){const _0x2dcfe2=document['createElement']('a');_0x2dcfe2['href']=_0x2e19a7,_0x2dcfe2['target']=_0x364df0;const _0x232b88=document['createEvent']('MouseEvent');_0x232b88['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2dcfe2['dispatchEvent'](_0x232b88);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x4ea03e,_0x3fc903,_0x1a40ff,_0x447121,_0xe204a2,_0x3ef193){m(_0x4ea03e['config']['authDomain'],_0x4ea03e,'auth-domain-config-required'),m(_0x4ea03e['config']['apiKey'],_0x4ea03e,'invalid-api-key');const _0x5ea187={'apiKey':_0x4ea03e['config']['apiKey'],'appName':_0x4ea03e['name'],'authType':_0x1a40ff,'redirectUrl':_0x447121,'v':dt,'eventId':_0xe204a2};if(_0x3fc903 instanceof Wa){_0x3fc903['setDefaultLanguage'](_0x4ea03e['languageCode']),_0x5ea187['providerId']=_0x3fc903['providerId']||'',pn(_0x3fc903['getCustomParameters']())||(_0x5ea187['customParameters']=JSON['stringify'](_0x3fc903['getCustomParameters']()));for(const [_0x1d6012,_0x32598c]of Object['entries']({}))_0x5ea187[_0x1d6012]=_0x32598c;}if(_0x3fc903 instanceof tn){const _0x26f505=_0x3fc903['getScopes']()['filter'](_0x2b5893=>_0x2b5893!=='');_0x26f505['length']>0x0&&(_0x5ea187['scopes']=_0x26f505['join'](','));}_0x4ea03e['tenantId']&&(_0x5ea187['tid']=_0x4ea03e['tenantId']);const _0x109f5c=_0x5ea187;for(const _0x3560b3 of Object['keys'](_0x109f5c))_0x109f5c[_0x3560b3]===void 0x0&&delete _0x109f5c[_0x3560b3];const _0x4ca727=await _0x4ea03e['_getAppCheckToken'](),_0x1269f5=_0x4ca727?'#'+r_+'='+encodeURIComponent(_0x4ca727):'';return o_(_0x4ea03e)+'?'+ut(_0x109f5c)['slice'](0x1)+_0x1269f5;}function o_({config:_0x3858f0}){return _0x3858f0['emulator']?Cs(_0x3858f0,s_):'https://'+_0x3858f0['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x2db1a1,_0x40e393,_0x1514a8,_0x391432){var _0xa6021d;ce((_0xa6021d=this['eventManagers'][_0x2db1a1['_key']()])==null?void 0x0:_0xa6021d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3689a7=await Fr(_0x2db1a1,_0x40e393,_0x1514a8,Mi(),_0x391432);return t_(_0x2db1a1,_0x3689a7,As());}async['_openRedirect'](_0x4f8628,_0x5db596,_0x5d45b6,_0x9f53cb){await this['_originValidation'](_0x4f8628);const _0x58f21f=await Fr(_0x4f8628,_0x5db596,_0x5d45b6,Mi(),_0x9f53cb);return hp(_0x58f21f),new Promise(()=>{});}['_initialize'](_0x486668){const _0x1e512b=_0x486668['_key']();if(this['eventManagers'][_0x1e512b]){const {manager:_0x23359c,promise:_0x2369f9}=this['eventManagers'][_0x1e512b];return _0x23359c?Promise['resolve'](_0x23359c):(ce(_0x2369f9,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2369f9);}const _0x4b21c8=this['initAndGetManager'](_0x486668);return this['eventManagers'][_0x1e512b]={'promise':_0x4b21c8},_0x4b21c8['catch'](()=>{delete this['eventManagers'][_0x1e512b];}),_0x4b21c8;}async['initAndGetManager'](_0x3d8006){const _0x398eb8=await Yp(_0x3d8006),_0x4485b9=new Dp(_0x3d8006);return _0x398eb8['register']('authEvent',_0x252831=>(m(_0x252831==null?void 0x0:_0x252831['authEvent'],_0x3d8006,'invalid-auth-event'),{'status':_0x4485b9['onEvent'](_0x252831['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3d8006['_key']()]={'manager':_0x4485b9},this['iframes'][_0x3d8006['_key']()]=_0x398eb8,_0x4485b9;}['_isIframeWebStorageSupported'](_0x4ddc1a,_0x567fa8){this['iframes'][_0x4ddc1a['_key']()]['send'](pi,{'type':pi},_0x50567f=>{var _0x3e3669;const _0xa76683=(_0x3e3669=_0x50567f==null?void 0x0:_0x50567f[0x0])==null?void 0x0:_0x3e3669[pi];_0xa76683!==void 0x0&&_0x567fa8(!!_0xa76683),Y(_0x4ddc1a,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x14b8fe){const _0x40ad84=_0x14b8fe['_key']();return this['originValidationPromises'][_0x40ad84]||(this['originValidationPromises'][_0x40ad84]=Up(_0x14b8fe)),this['originValidationPromises'][_0x40ad84];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3cf5af){this['auth']=_0x3cf5af,this['internalListeners']=new Map();}['getUid'](){var _0x3624a6;return this['assertAuthConfigured'](),((_0x3624a6=this['auth']['currentUser'])==null?void 0x0:_0x3624a6['uid'])||null;}async['getToken'](_0xfbff40){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xfbff40)}:null;}['addAuthTokenListener'](_0x35a129){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x35a129))return;const _0x4c745a=this['auth']['onIdTokenChanged'](_0x16c51f=>{_0x35a129((_0x16c51f==null?void 0x0:_0x16c51f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x35a129,_0x4c745a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xea9e76){this['assertAuthConfigured']();const _0x1cdaa3=this['internalListeners']['get'](_0xea9e76);_0x1cdaa3&&(this['internalListeners']['delete'](_0xea9e76),_0x1cdaa3(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3f54c4){switch(_0x3f54c4){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0xde8ce3){st(new Fe('auth',(_0x2b704d,{options:_0x14a8b4})=>{const _0x52af73=_0x2b704d['getProvider']('app')['getImmediate'](),_0xc448c6=_0x2b704d['getProvider']('heartbeat'),_0x3675cb=_0x2b704d['getProvider']('app-check-internal'),{apiKey:_0x2242fc,authDomain:_0x3b94e0}=_0x52af73['options'];m(_0x2242fc&&!_0x2242fc['includes'](':'),'invalid-api-key',{'appName':_0x52af73['name']});const _0x5b38c5={'apiKey':_0x2242fc,'authDomain':_0x3b94e0,'clientPlatform':_0xde8ce3,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xde8ce3)},_0x21b034=new Df(_0x52af73,_0xc448c6,_0x3675cb,_0x5b38c5);return Hf(_0x21b034,_0x14a8b4),_0x21b034;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x10b90c,_0x428467,_0x281102)=>{_0x10b90c['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x9f4d3c=>{const _0x1f4f5c=Ke(_0x9f4d3c['getProvider']('auth')['getImmediate']());return(_0x24a1a7=>new l_(_0x24a1a7))(_0x1f4f5c);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0xde8ce3)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x57ce68=>async _0x184aa0=>{const _0x1045d9=_0x184aa0&&await _0x184aa0['getIdTokenResult'](),_0x5820ea=_0x1045d9&&(new Date()['getTime']()-Date['parse'](_0x1045d9['issuedAtTime']))/0x3e8;if(_0x5820ea&&_0x5820ea>f_)return;const _0x185bb1=_0x1045d9==null?void 0x0:_0x1045d9['token'];Br!==_0x185bb1&&(Br=_0x185bb1,await fetch(_0x57ce68,{'method':_0x185bb1?'POST':'DELETE','headers':_0x185bb1?{'Authorization':'Bearer\x20'+_0x185bb1}:{}}));};function B_(_0x42e29f=Zr()){const _0x28367f=Hi(_0x42e29f,'auth');if(_0x28367f['isInitialized']())return _0x28367f['getImmediate']();const _0x3d2814=Vf(_0x42e29f,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x5d5ace=jr('authTokenSyncURL');if(_0x5d5ace&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x33678a=new URL(_0x5d5ace,location['origin']);if(location['origin']===_0x33678a['origin']){const _0x57b8d3=p_(_0x33678a['toString']());sp(_0x3d2814,_0x57b8d3,()=>_0x57b8d3(_0x3d2814['currentUser'])),ip(_0x3d2814,_0x5d66fc=>_0x57b8d3(_0x5d66fc));}}const _0x40a732=qr('auth');return _0x40a732&&$f(_0x3d2814,'http://'+_0x40a732),_0x3d2814;}function __(){var _0x527b34;return((_0x527b34=document['getElementsByTagName']('head'))==null?void 0x0:_0x527b34[0x0])??document;}Mf({'loadJS'(_0xb45ca6){return new Promise((_0x1f236a,_0x328fd5)=>{const _0x42fa8d=document['createElement']('script');_0x42fa8d['setAttribute']('src',_0xb45ca6),_0x42fa8d['onload']=_0x1f236a,_0x42fa8d['onerror']=_0x1e0c56=>{const _0x11782e=X('internal-error');_0x11782e['customData']=_0x1e0c56,_0x328fd5(_0x11782e);},_0x42fa8d['type']='text/javascript',_0x42fa8d['charset']='UTF-8',__()['appendChild'](_0x42fa8d);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};