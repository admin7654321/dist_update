const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x56d707,_0x463d08){if(!_0x56d707)throw ht(_0x463d08);},ht=function(_0x304dca){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x304dca);},Hr=function(_0x1c85b7){const _0x2d9554=[];let _0x4d7deb=0x0;for(let _0x296fa0=0x0;_0x296fa0<_0x1c85b7['length'];_0x296fa0++){let _0x57a547=_0x1c85b7['charCodeAt'](_0x296fa0);_0x57a547<0x80?_0x2d9554[_0x4d7deb++]=_0x57a547:_0x57a547<0x800?(_0x2d9554[_0x4d7deb++]=_0x57a547>>0x6|0xc0,_0x2d9554[_0x4d7deb++]=_0x57a547&0x3f|0x80):(_0x57a547&0xfc00)===0xd800&&_0x296fa0+0x1<_0x1c85b7['length']&&(_0x1c85b7['charCodeAt'](_0x296fa0+0x1)&0xfc00)===0xdc00?(_0x57a547=0x10000+((_0x57a547&0x3ff)<<0xa)+(_0x1c85b7['charCodeAt'](++_0x296fa0)&0x3ff),_0x2d9554[_0x4d7deb++]=_0x57a547>>0x12|0xf0,_0x2d9554[_0x4d7deb++]=_0x57a547>>0xc&0x3f|0x80,_0x2d9554[_0x4d7deb++]=_0x57a547>>0x6&0x3f|0x80,_0x2d9554[_0x4d7deb++]=_0x57a547&0x3f|0x80):(_0x2d9554[_0x4d7deb++]=_0x57a547>>0xc|0xe0,_0x2d9554[_0x4d7deb++]=_0x57a547>>0x6&0x3f|0x80,_0x2d9554[_0x4d7deb++]=_0x57a547&0x3f|0x80);}return _0x2d9554;},nc=function(_0x32ca2e){const _0x51c824=[];let _0x28dcd2=0x0,_0x1fb866=0x0;for(;_0x28dcd2<_0x32ca2e['length'];){const _0x56eb71=_0x32ca2e[_0x28dcd2++];if(_0x56eb71<0x80)_0x51c824[_0x1fb866++]=String['fromCharCode'](_0x56eb71);else{if(_0x56eb71>0xbf&&_0x56eb71<0xe0){const _0x23d511=_0x32ca2e[_0x28dcd2++];_0x51c824[_0x1fb866++]=String['fromCharCode']((_0x56eb71&0x1f)<<0x6|_0x23d511&0x3f);}else{if(_0x56eb71>0xef&&_0x56eb71<0x16d){const _0x1b1532=_0x32ca2e[_0x28dcd2++],_0x529206=_0x32ca2e[_0x28dcd2++],_0x237934=_0x32ca2e[_0x28dcd2++],_0x4670fd=((_0x56eb71&0x7)<<0x12|(_0x1b1532&0x3f)<<0xc|(_0x529206&0x3f)<<0x6|_0x237934&0x3f)-0x10000;_0x51c824[_0x1fb866++]=String['fromCharCode'](0xd800+(_0x4670fd>>0xa)),_0x51c824[_0x1fb866++]=String['fromCharCode'](0xdc00+(_0x4670fd&0x3ff));}else{const _0x342c71=_0x32ca2e[_0x28dcd2++],_0x280a0c=_0x32ca2e[_0x28dcd2++];_0x51c824[_0x1fb866++]=String['fromCharCode']((_0x56eb71&0xf)<<0xc|(_0x342c71&0x3f)<<0x6|_0x280a0c&0x3f);}}}}return _0x51c824['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x45d191,_0x17505c){if(!Array['isArray'](_0x45d191))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1e3367=_0x17505c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xf50f95=[];for(let _0x3a215e=0x0;_0x3a215e<_0x45d191['length'];_0x3a215e+=0x3){const _0x2be45c=_0x45d191[_0x3a215e],_0x119258=_0x3a215e+0x1<_0x45d191['length'],_0x3f8483=_0x119258?_0x45d191[_0x3a215e+0x1]:0x0,_0x508569=_0x3a215e+0x2<_0x45d191['length'],_0xae79ec=_0x508569?_0x45d191[_0x3a215e+0x2]:0x0,_0x18755e=_0x2be45c>>0x2,_0xa7c232=(_0x2be45c&0x3)<<0x4|_0x3f8483>>0x4;let _0x169ed2=(_0x3f8483&0xf)<<0x2|_0xae79ec>>0x6,_0x57d079=_0xae79ec&0x3f;_0x508569||(_0x57d079=0x40,_0x119258||(_0x169ed2=0x40)),_0xf50f95['push'](_0x1e3367[_0x18755e],_0x1e3367[_0xa7c232],_0x1e3367[_0x169ed2],_0x1e3367[_0x57d079]);}return _0xf50f95['join']('');},'encodeString'(_0x54e221,_0x582076){return this['HAS_NATIVE_SUPPORT']&&!_0x582076?btoa(_0x54e221):this['encodeByteArray'](Hr(_0x54e221),_0x582076);},'decodeString'(_0x2fd02d,_0x4cb91b){return this['HAS_NATIVE_SUPPORT']&&!_0x4cb91b?atob(_0x2fd02d):nc(this['decodeStringToByteArray'](_0x2fd02d,_0x4cb91b));},'decodeStringToByteArray'(_0x52fa71,_0x20ef06){this['init_']();const _0x4769b0=_0x20ef06?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x39a741=[];for(let _0x182505=0x0;_0x182505<_0x52fa71['length'];){const _0x585be8=_0x4769b0[_0x52fa71['charAt'](_0x182505++)],_0x29560e=_0x182505<_0x52fa71['length']?_0x4769b0[_0x52fa71['charAt'](_0x182505)]:0x0;++_0x182505;const _0x1b9897=_0x182505<_0x52fa71['length']?_0x4769b0[_0x52fa71['charAt'](_0x182505)]:0x40;++_0x182505;const _0x579b25=_0x182505<_0x52fa71['length']?_0x4769b0[_0x52fa71['charAt'](_0x182505)]:0x40;if(++_0x182505,_0x585be8==null||_0x29560e==null||_0x1b9897==null||_0x579b25==null)throw new ic();const _0x1db25e=_0x585be8<<0x2|_0x29560e>>0x4;if(_0x39a741['push'](_0x1db25e),_0x1b9897!==0x40){const _0x1c388d=_0x29560e<<0x4&0xf0|_0x1b9897>>0x2;if(_0x39a741['push'](_0x1c388d),_0x579b25!==0x40){const _0x4d5e18=_0x1b9897<<0x6&0xc0|_0x579b25;_0x39a741['push'](_0x4d5e18);}}}return _0x39a741;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x656c9=0x0;_0x656c9<this['ENCODED_VALS']['length'];_0x656c9++)this['byteToCharMap_'][_0x656c9]=this['ENCODED_VALS']['charAt'](_0x656c9),this['charToByteMap_'][this['byteToCharMap_'][_0x656c9]]=_0x656c9,this['byteToCharMapWebSafe_'][_0x656c9]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x656c9),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x656c9]]=_0x656c9,_0x656c9>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x656c9)]=_0x656c9,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x656c9)]=_0x656c9);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x366017){const _0x17c41d=Hr(_0x366017);return Fi['encodeByteArray'](_0x17c41d,!0x0);},dn=function(_0x63b020){return $r(_0x63b020)['replace'](/\./g,'');},fn=function(_0x22dd9f){try{return Fi['decodeString'](_0x22dd9f,!0x0);}catch(_0x53700b){console['error']('base64Decode\x20failed:\x20',_0x53700b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x274ef1){return Gr(void 0x0,_0x274ef1);}function Gr(_0x52d98e,_0x455f56){if(!(_0x455f56 instanceof Object))return _0x455f56;switch(_0x455f56['constructor']){case Date:const _0xe95a23=_0x455f56;return new Date(_0xe95a23['getTime']());case Object:_0x52d98e===void 0x0&&(_0x52d98e={});break;case Array:_0x52d98e=[];break;default:return _0x455f56;}for(const _0x5704dc in _0x455f56)!_0x455f56['hasOwnProperty'](_0x5704dc)||!rc(_0x5704dc)||(_0x52d98e[_0x5704dc]=Gr(_0x52d98e[_0x5704dc],_0x455f56[_0x5704dc]));return _0x52d98e;}function rc(_0x518dec){return _0x518dec!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x2c5ba3=Ps['__FIREBASE_DEFAULTS__'];if(_0x2c5ba3)return JSON['parse'](_0x2c5ba3);},lc=()=>{if(typeof document>'u')return;let _0xdcb7d6;try{_0xdcb7d6=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x55de6c=_0xdcb7d6&&fn(_0xdcb7d6[0x1]);return _0x55de6c&&JSON['parse'](_0x55de6c);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x280607){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x280607);return;}},qr=_0x2f6d01=>{var _0x5a6126,_0x179772;return(_0x179772=(_0x5a6126=Ui())==null?void 0x0:_0x5a6126['emulatorHosts'])==null?void 0x0:_0x179772[_0x2f6d01];},hc=_0x20ef6d=>{const _0x559bdb=qr(_0x20ef6d);if(!_0x559bdb)return;const _0x563e01=_0x559bdb['lastIndexOf'](':');if(_0x563e01<=0x0||_0x563e01+0x1===_0x559bdb['length'])throw new Error('Invalid\x20host\x20'+_0x559bdb+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x57bcb6=parseInt(_0x559bdb['substring'](_0x563e01+0x1),0xa);return _0x559bdb[0x0]==='['?[_0x559bdb['substring'](0x1,_0x563e01-0x1),_0x57bcb6]:[_0x559bdb['substring'](0x0,_0x563e01),_0x57bcb6];},zr=()=>{var _0x39618e;return(_0x39618e=Ui())==null?void 0x0:_0x39618e['config'];},jr=_0xc45e20=>{var _0x375ca2;return(_0x375ca2=Ui())==null?void 0x0:_0x375ca2['_'+_0xc45e20];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x46a706,_0x1dc8ab)=>{this['resolve']=_0x46a706,this['reject']=_0x1dc8ab;});}['wrapCallback'](_0x304e90){return(_0x4422f8,_0x3e812f)=>{_0x4422f8?this['reject'](_0x4422f8):this['resolve'](_0x3e812f),typeof _0x304e90=='function'&&(this['promise']['catch'](()=>{}),_0x304e90['length']===0x1?_0x304e90(_0x4422f8):_0x304e90(_0x4422f8,_0x3e812f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x57637e,_0x22acb5){if(_0x57637e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x29e222={'alg':'none','type':'JWT'},_0x45fc1e=_0x22acb5||'demo-project',_0x45d83c=_0x57637e['iat']||0x0,_0x5ddbf7=_0x57637e['sub']||_0x57637e['user_id'];if(!_0x5ddbf7)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x51a9fc={'iss':'https://securetoken.google.com/'+_0x45fc1e,'aud':_0x45fc1e,'iat':_0x45d83c,'exp':_0x45d83c+0xe10,'auth_time':_0x45d83c,'sub':_0x5ddbf7,'user_id':_0x5ddbf7,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x57637e};return[dn(JSON['stringify'](_0x29e222)),dn(JSON['stringify'](_0x51a9fc)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x375d40=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x375d40=='object'&&_0x375d40['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x38ed90=W();return _0x38ed90['indexOf']('MSIE\x20')>=0x0||_0x38ed90['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x5e7e26,_0x46dbb5)=>{try{let _0x8b5fd7=!0x0;const _0xaf9e60='validate-browser-context-for-indexeddb-analytics-module',_0x3c9578=self['indexedDB']['open'](_0xaf9e60);_0x3c9578['onsuccess']=()=>{_0x3c9578['result']['close'](),_0x8b5fd7||self['indexedDB']['deleteDatabase'](_0xaf9e60),_0x5e7e26(!0x0);},_0x3c9578['onupgradeneeded']=()=>{_0x8b5fd7=!0x1;},_0x3c9578['onerror']=()=>{var _0x1ca67d;_0x46dbb5(((_0x1ca67d=_0x3c9578['error'])==null?void 0x0:_0x1ca67d['message'])||'');};}catch(_0x5c4b7f){_0x46dbb5(_0x5c4b7f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x36e62b,_0x4ce66d,_0x3e8b7f){super(_0x4ce66d),this['code']=_0x36e62b,this['customData']=_0x3e8b7f,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x151d40,_0xbaec54,_0x138c4f){this['service']=_0x151d40,this['serviceName']=_0xbaec54,this['errors']=_0x138c4f;}['create'](_0x81223e,..._0x2936c1){const _0x20427d=_0x2936c1[0x0]||{},_0x15641a=this['service']+'/'+_0x81223e,_0xa27a17=this['errors'][_0x81223e],_0x1a647f=_0xa27a17?vc(_0xa27a17,_0x20427d):'Error',_0x550a9b=this['serviceName']+':\x20'+_0x1a647f+'\x20('+_0x15641a+').';return new Re(_0x15641a,_0x550a9b,_0x20427d);}}function vc(_0x246005,_0x5e4dbc){return _0x246005['replace'](Ec,(_0x570039,_0x4066af)=>{const _0x5512a7=_0x5e4dbc[_0x4066af];return _0x5512a7!=null?String(_0x5512a7):'<'+_0x4066af+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x49afb0){return JSON['parse'](_0x49afb0);}function O(_0x1cd684){return JSON['stringify'](_0x1cd684);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x214aec){let _0x4b76c6={},_0x176f4a={},_0x1e3a67={},_0x25c532='';try{const _0xf397bc=_0x214aec['split']('.');_0x4b76c6=Nt(fn(_0xf397bc[0x0])||''),_0x176f4a=Nt(fn(_0xf397bc[0x1])||''),_0x25c532=_0xf397bc[0x2],_0x1e3a67=_0x176f4a['d']||{},delete _0x176f4a['d'];}catch{}return{'header':_0x4b76c6,'claims':_0x176f4a,'data':_0x1e3a67,'signature':_0x25c532};},Ic=function(_0x5b31d7){const _0x2fd9e7=Yr(_0x5b31d7),_0x475238=_0x2fd9e7['claims'];return!!_0x475238&&typeof _0x475238=='object'&&_0x475238['hasOwnProperty']('iat');},wc=function(_0x199042){const _0x2d903=Yr(_0x199042)['claims'];return typeof _0x2d903=='object'&&_0x2d903['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x588778,_0x48772e){return Object['prototype']['hasOwnProperty']['call'](_0x588778,_0x48772e);}function Le(_0x4d294b,_0x37b62d){if(Object['prototype']['hasOwnProperty']['call'](_0x4d294b,_0x37b62d))return _0x4d294b[_0x37b62d];}function pn(_0x16d2e0){for(const _0x2d39ab in _0x16d2e0)if(Object['prototype']['hasOwnProperty']['call'](_0x16d2e0,_0x2d39ab))return!0x1;return!0x0;}function _n(_0x2998a4,_0x1c293b,_0x36a437){const _0xb6c7f9={};for(const _0x5a7460 in _0x2998a4)Object['prototype']['hasOwnProperty']['call'](_0x2998a4,_0x5a7460)&&(_0xb6c7f9[_0x5a7460]=_0x1c293b['call'](_0x36a437,_0x2998a4[_0x5a7460],_0x5a7460,_0x2998a4));return _0xb6c7f9;}function xe(_0x2c404d,_0x5789e7){if(_0x2c404d===_0x5789e7)return!0x0;const _0x59c63f=Object['keys'](_0x2c404d),_0x3eb572=Object['keys'](_0x5789e7);for(const _0x371fd7 of _0x59c63f){if(!_0x3eb572['includes'](_0x371fd7))return!0x1;const _0x44f2af=_0x2c404d[_0x371fd7],_0x4250c0=_0x5789e7[_0x371fd7];if(Ns(_0x44f2af)&&Ns(_0x4250c0)){if(!xe(_0x44f2af,_0x4250c0))return!0x1;}else{if(_0x44f2af!==_0x4250c0)return!0x1;}}for(const _0x320bb7 of _0x3eb572)if(!_0x59c63f['includes'](_0x320bb7))return!0x1;return!0x0;}function Ns(_0x537ce8){return _0x537ce8!==null&&typeof _0x537ce8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x29d37e){const _0x19a01b=[];for(const [_0x4e311c,_0x2616a5]of Object['entries'](_0x29d37e))Array['isArray'](_0x2616a5)?_0x2616a5['forEach'](_0x291fa9=>{_0x19a01b['push'](encodeURIComponent(_0x4e311c)+'='+encodeURIComponent(_0x291fa9));}):_0x19a01b['push'](encodeURIComponent(_0x4e311c)+'='+encodeURIComponent(_0x2616a5));return _0x19a01b['length']?'&'+_0x19a01b['join']('&'):'';}function Ct(_0x1197d2){const _0x2f1b21={};return _0x1197d2['replace'](/^\?/,'')['split']('&')['forEach'](_0x2f420b=>{if(_0x2f420b){const [_0x57029d,_0x3e0ab7]=_0x2f420b['split']('=');_0x2f1b21[decodeURIComponent(_0x57029d)]=decodeURIComponent(_0x3e0ab7);}}),_0x2f1b21;}function Tt(_0x553065){const _0x5882c4=_0x553065['indexOf']('?');if(!_0x5882c4)return'';const _0x363fd6=_0x553065['indexOf']('#',_0x5882c4);return _0x553065['substring'](_0x5882c4,_0x363fd6>0x0?_0x363fd6:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x52925c=0x1;_0x52925c<this['blockSize'];++_0x52925c)this['pad_'][_0x52925c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1d56d3,_0x277037){_0x277037||(_0x277037=0x0);const _0x573e0d=this['W_'];if(typeof _0x1d56d3=='string'){for(let _0x48cb24=0x0;_0x48cb24<0x10;_0x48cb24++)_0x573e0d[_0x48cb24]=_0x1d56d3['charCodeAt'](_0x277037)<<0x18|_0x1d56d3['charCodeAt'](_0x277037+0x1)<<0x10|_0x1d56d3['charCodeAt'](_0x277037+0x2)<<0x8|_0x1d56d3['charCodeAt'](_0x277037+0x3),_0x277037+=0x4;}else{for(let _0x46ed81=0x0;_0x46ed81<0x10;_0x46ed81++)_0x573e0d[_0x46ed81]=_0x1d56d3[_0x277037]<<0x18|_0x1d56d3[_0x277037+0x1]<<0x10|_0x1d56d3[_0x277037+0x2]<<0x8|_0x1d56d3[_0x277037+0x3],_0x277037+=0x4;}for(let _0x5558ec=0x10;_0x5558ec<0x50;_0x5558ec++){const _0x1b7daf=_0x573e0d[_0x5558ec-0x3]^_0x573e0d[_0x5558ec-0x8]^_0x573e0d[_0x5558ec-0xe]^_0x573e0d[_0x5558ec-0x10];_0x573e0d[_0x5558ec]=(_0x1b7daf<<0x1|_0x1b7daf>>>0x1f)&0xffffffff;}let _0x18034f=this['chain_'][0x0],_0x41bcae=this['chain_'][0x1],_0x24afe5=this['chain_'][0x2],_0x279a23=this['chain_'][0x3],_0x57dc9d=this['chain_'][0x4],_0x21241a,_0x3900c4;for(let _0x530f03=0x0;_0x530f03<0x50;_0x530f03++){_0x530f03<0x28?_0x530f03<0x14?(_0x21241a=_0x279a23^_0x41bcae&(_0x24afe5^_0x279a23),_0x3900c4=0x5a827999):(_0x21241a=_0x41bcae^_0x24afe5^_0x279a23,_0x3900c4=0x6ed9eba1):_0x530f03<0x3c?(_0x21241a=_0x41bcae&_0x24afe5|_0x279a23&(_0x41bcae|_0x24afe5),_0x3900c4=0x8f1bbcdc):(_0x21241a=_0x41bcae^_0x24afe5^_0x279a23,_0x3900c4=0xca62c1d6);const _0x12f0a7=(_0x18034f<<0x5|_0x18034f>>>0x1b)+_0x21241a+_0x57dc9d+_0x3900c4+_0x573e0d[_0x530f03]&0xffffffff;_0x57dc9d=_0x279a23,_0x279a23=_0x24afe5,_0x24afe5=(_0x41bcae<<0x1e|_0x41bcae>>>0x2)&0xffffffff,_0x41bcae=_0x18034f,_0x18034f=_0x12f0a7;}this['chain_'][0x0]=this['chain_'][0x0]+_0x18034f&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x41bcae&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x24afe5&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x279a23&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x57dc9d&0xffffffff;}['update'](_0x2dc106,_0x3a92ee){if(_0x2dc106==null)return;_0x3a92ee===void 0x0&&(_0x3a92ee=_0x2dc106['length']);const _0x703d5b=_0x3a92ee-this['blockSize'];let _0x427ad9=0x0;const _0x43f53f=this['buf_'];let _0x5e9242=this['inbuf_'];for(;_0x427ad9<_0x3a92ee;){if(_0x5e9242===0x0){for(;_0x427ad9<=_0x703d5b;)this['compress_'](_0x2dc106,_0x427ad9),_0x427ad9+=this['blockSize'];}if(typeof _0x2dc106=='string'){for(;_0x427ad9<_0x3a92ee;)if(_0x43f53f[_0x5e9242]=_0x2dc106['charCodeAt'](_0x427ad9),++_0x5e9242,++_0x427ad9,_0x5e9242===this['blockSize']){this['compress_'](_0x43f53f),_0x5e9242=0x0;break;}}else{for(;_0x427ad9<_0x3a92ee;)if(_0x43f53f[_0x5e9242]=_0x2dc106[_0x427ad9],++_0x5e9242,++_0x427ad9,_0x5e9242===this['blockSize']){this['compress_'](_0x43f53f),_0x5e9242=0x0;break;}}}this['inbuf_']=_0x5e9242,this['total_']+=_0x3a92ee;}['digest'](){const _0x43cd21=[];let _0x22b114=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x143fcc=this['blockSize']-0x1;_0x143fcc>=0x38;_0x143fcc--)this['buf_'][_0x143fcc]=_0x22b114&0xff,_0x22b114/=0x100;this['compress_'](this['buf_']);let _0x986ab3=0x0;for(let _0x7c701c=0x0;_0x7c701c<0x5;_0x7c701c++)for(let _0x5d0caf=0x18;_0x5d0caf>=0x0;_0x5d0caf-=0x8)_0x43cd21[_0x986ab3]=this['chain_'][_0x7c701c]>>_0x5d0caf&0xff,++_0x986ab3;return _0x43cd21;}}function Tc(_0x545589,_0x537eb7){const _0xf99634=new Sc(_0x545589,_0x537eb7);return _0xf99634['subscribe']['bind'](_0xf99634);}class Sc{constructor(_0x5bee35,_0x26d552){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x26d552,this['task']['then'](()=>{_0x5bee35(this);})['catch'](_0x2e2f94=>{this['error'](_0x2e2f94);});}['next'](_0x39a892){this['forEachObserver'](_0x4b0c3e=>{_0x4b0c3e['next'](_0x39a892);});}['error'](_0x5e92cb){this['forEachObserver'](_0x8392c1=>{_0x8392c1['error'](_0x5e92cb);}),this['close'](_0x5e92cb);}['complete'](){this['forEachObserver'](_0x2d8e41=>{_0x2d8e41['complete']();}),this['close']();}['subscribe'](_0x169014,_0x860b13,_0x5e99d6){let _0xf32c7;if(_0x169014===void 0x0&&_0x860b13===void 0x0&&_0x5e99d6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x169014,['next','error','complete'])?_0xf32c7=_0x169014:_0xf32c7={'next':_0x169014,'error':_0x860b13,'complete':_0x5e99d6},_0xf32c7['next']===void 0x0&&(_0xf32c7['next']=ti),_0xf32c7['error']===void 0x0&&(_0xf32c7['error']=ti),_0xf32c7['complete']===void 0x0&&(_0xf32c7['complete']=ti);const _0x4972e2=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xf32c7['error'](this['finalError']):_0xf32c7['complete']();}catch{}}),this['observers']['push'](_0xf32c7),_0x4972e2;}['unsubscribeOne'](_0x5c5f36){this['observers']===void 0x0||this['observers'][_0x5c5f36]===void 0x0||(delete this['observers'][_0x5c5f36],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5de9a4){if(!this['finalized']){for(let _0xfd00ea=0x0;_0xfd00ea<this['observers']['length'];_0xfd00ea++)this['sendOne'](_0xfd00ea,_0x5de9a4);}}['sendOne'](_0x2b3e0e,_0x3d854a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2b3e0e]!==void 0x0)try{_0x3d854a(this['observers'][_0x2b3e0e]);}catch(_0xd314eb){typeof console<'u'&&console['error']&&console['error'](_0xd314eb);}});}['close'](_0x3cc82b){this['finalized']||(this['finalized']=!0x0,_0x3cc82b!==void 0x0&&(this['finalError']=_0x3cc82b),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x543ea4,_0x54ea78){if(typeof _0x543ea4!='object'||_0x543ea4===null)return!0x1;for(const _0x7bde45 of _0x54ea78)if(_0x7bde45 in _0x543ea4&&typeof _0x543ea4[_0x7bde45]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1f8c5e,_0xee4203){return _0x1f8c5e+'\x20failed:\x20'+_0xee4203+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x39fe02){const _0x4dae18=[];let _0x4ebc42=0x0;for(let _0x26edd6=0x0;_0x26edd6<_0x39fe02['length'];_0x26edd6++){let _0x20f57d=_0x39fe02['charCodeAt'](_0x26edd6);if(_0x20f57d>=0xd800&&_0x20f57d<=0xdbff){const _0xbc075a=_0x20f57d-0xd800;_0x26edd6++,f(_0x26edd6<_0x39fe02['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4b5ae9=_0x39fe02['charCodeAt'](_0x26edd6)-0xdc00;_0x20f57d=0x10000+(_0xbc075a<<0xa)+_0x4b5ae9;}_0x20f57d<0x80?_0x4dae18[_0x4ebc42++]=_0x20f57d:_0x20f57d<0x800?(_0x4dae18[_0x4ebc42++]=_0x20f57d>>0x6|0xc0,_0x4dae18[_0x4ebc42++]=_0x20f57d&0x3f|0x80):_0x20f57d<0x10000?(_0x4dae18[_0x4ebc42++]=_0x20f57d>>0xc|0xe0,_0x4dae18[_0x4ebc42++]=_0x20f57d>>0x6&0x3f|0x80,_0x4dae18[_0x4ebc42++]=_0x20f57d&0x3f|0x80):(_0x4dae18[_0x4ebc42++]=_0x20f57d>>0x12|0xf0,_0x4dae18[_0x4ebc42++]=_0x20f57d>>0xc&0x3f|0x80,_0x4dae18[_0x4ebc42++]=_0x20f57d>>0x6&0x3f|0x80,_0x4dae18[_0x4ebc42++]=_0x20f57d&0x3f|0x80);}return _0x4dae18;},Ln=function(_0x35f08f){let _0x1521b7=0x0;for(let _0x4c7614=0x0;_0x4c7614<_0x35f08f['length'];_0x4c7614++){const _0x384933=_0x35f08f['charCodeAt'](_0x4c7614);_0x384933<0x80?_0x1521b7++:_0x384933<0x800?_0x1521b7+=0x2:_0x384933>=0xd800&&_0x384933<=0xdbff?(_0x1521b7+=0x4,_0x4c7614++):_0x1521b7+=0x3;}return _0x1521b7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x1f8a47){return _0x1f8a47&&_0x1f8a47['_delegate']?_0x1f8a47['_delegate']:_0x1f8a47;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x4134e2){try{return(_0x4134e2['startsWith']('http://')||_0x4134e2['startsWith']('https://')?new URL(_0x4134e2)['hostname']:_0x4134e2)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0xe1e787){return(await fetch(_0xe1e787,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x32d871,_0x5d2301,_0x1284b1){this['name']=_0x32d871,this['instanceFactory']=_0x5d2301,this['type']=_0x1284b1,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3279b3){return this['instantiationMode']=_0x3279b3,this;}['setMultipleInstances'](_0x503164){return this['multipleInstances']=_0x503164,this;}['setServiceProps'](_0x48e490){return this['serviceProps']=_0x48e490,this;}['setInstanceCreatedCallback'](_0x31d034){return this['onInstanceCreated']=_0x31d034,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5a9149,_0x69948a){this['name']=_0x5a9149,this['container']=_0x69948a,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1dd559){const _0x587c23=this['normalizeInstanceIdentifier'](_0x1dd559);if(!this['instancesDeferred']['has'](_0x587c23)){const _0x124ea3=new H();if(this['instancesDeferred']['set'](_0x587c23,_0x124ea3),this['isInitialized'](_0x587c23)||this['shouldAutoInitialize']())try{const _0x482b53=this['getOrInitializeService']({'instanceIdentifier':_0x587c23});_0x482b53&&_0x124ea3['resolve'](_0x482b53);}catch{}}return this['instancesDeferred']['get'](_0x587c23)['promise'];}['getImmediate'](_0x238ce5){const _0x5b8ca1=this['normalizeInstanceIdentifier'](_0x238ce5==null?void 0x0:_0x238ce5['identifier']),_0x429b42=(_0x238ce5==null?void 0x0:_0x238ce5['optional'])??!0x1;if(this['isInitialized'](_0x5b8ca1)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5b8ca1});}catch(_0x4422b1){if(_0x429b42)return null;throw _0x4422b1;}else{if(_0x429b42)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x26a59a){if(_0x26a59a['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x26a59a['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x26a59a,!!this['shouldAutoInitialize']()){if(Pc(_0x26a59a))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x266ce9,_0x8a8f6d]of this['instancesDeferred']['entries']()){const _0xac58d5=this['normalizeInstanceIdentifier'](_0x266ce9);try{const _0x563cac=this['getOrInitializeService']({'instanceIdentifier':_0xac58d5});_0x8a8f6d['resolve'](_0x563cac);}catch{}}}}['clearInstance'](_0x533547=Ne){this['instancesDeferred']['delete'](_0x533547),this['instancesOptions']['delete'](_0x533547),this['instances']['delete'](_0x533547);}async['delete'](){const _0x214c3d=Array['from'](this['instances']['values']());await Promise['all']([..._0x214c3d['filter'](_0x1047a5=>'INTERNAL'in _0x1047a5)['map'](_0x343aa4=>_0x343aa4['INTERNAL']['delete']()),..._0x214c3d['filter'](_0x44b260=>'_delete'in _0x44b260)['map'](_0x238e8f=>_0x238e8f['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1f0b62=Ne){return this['instances']['has'](_0x1f0b62);}['getOptions'](_0x7cab2d=Ne){return this['instancesOptions']['get'](_0x7cab2d)||{};}['initialize'](_0x1f6035={}){const {options:_0x1c56ea={}}=_0x1f6035,_0x5792f9=this['normalizeInstanceIdentifier'](_0x1f6035['instanceIdentifier']);if(this['isInitialized'](_0x5792f9))throw Error(this['name']+'('+_0x5792f9+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x134a3c=this['getOrInitializeService']({'instanceIdentifier':_0x5792f9,'options':_0x1c56ea});for(const [_0x1e8183,_0x20f961]of this['instancesDeferred']['entries']()){const _0x2c0847=this['normalizeInstanceIdentifier'](_0x1e8183);_0x5792f9===_0x2c0847&&_0x20f961['resolve'](_0x134a3c);}return _0x134a3c;}['onInit'](_0x1f4a70,_0x397c35){const _0x34c13c=this['normalizeInstanceIdentifier'](_0x397c35),_0xc305ed=this['onInitCallbacks']['get'](_0x34c13c)??new Set();_0xc305ed['add'](_0x1f4a70),this['onInitCallbacks']['set'](_0x34c13c,_0xc305ed);const _0x230802=this['instances']['get'](_0x34c13c);return _0x230802&&_0x1f4a70(_0x230802,_0x34c13c),()=>{_0xc305ed['delete'](_0x1f4a70);};}['invokeOnInitCallbacks'](_0x97e9cd,_0x4142b4){const _0x2021fa=this['onInitCallbacks']['get'](_0x4142b4);if(_0x2021fa){for(const _0x512aba of _0x2021fa)try{_0x512aba(_0x97e9cd,_0x4142b4);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2f1c22,options:_0x4cad81={}}){let _0x1e05eb=this['instances']['get'](_0x2f1c22);if(!_0x1e05eb&&this['component']&&(_0x1e05eb=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2f1c22),'options':_0x4cad81}),this['instances']['set'](_0x2f1c22,_0x1e05eb),this['instancesOptions']['set'](_0x2f1c22,_0x4cad81),this['invokeOnInitCallbacks'](_0x1e05eb,_0x2f1c22),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2f1c22,_0x1e05eb);}catch{}return _0x1e05eb||null;}['normalizeInstanceIdentifier'](_0x32dc22=Ne){return this['component']?this['component']['multipleInstances']?_0x32dc22:Ne:_0x32dc22;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5a8411){return _0x5a8411===Ne?void 0x0:_0x5a8411;}function Pc(_0x5f4f7b){return _0x5f4f7b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x222cb5){this['name']=_0x222cb5,this['providers']=new Map();}['addComponent'](_0x572be4){const _0x50dd34=this['getProvider'](_0x572be4['name']);if(_0x50dd34['isComponentSet']())throw new Error('Component\x20'+_0x572be4['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x50dd34['setComponent'](_0x572be4);}['addOrOverwriteComponent'](_0x33fa99){this['getProvider'](_0x33fa99['name'])['isComponentSet']()&&this['providers']['delete'](_0x33fa99['name']),this['addComponent'](_0x33fa99);}['getProvider'](_0x4181c1){if(this['providers']['has'](_0x4181c1))return this['providers']['get'](_0x4181c1);const _0x1a2726=new Ac(_0x4181c1,this);return this['providers']['set'](_0x4181c1,_0x1a2726),_0x1a2726;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2f2acd){_0x2f2acd[_0x2f2acd['DEBUG']=0x0]='DEBUG',_0x2f2acd[_0x2f2acd['VERBOSE']=0x1]='VERBOSE',_0x2f2acd[_0x2f2acd['INFO']=0x2]='INFO',_0x2f2acd[_0x2f2acd['WARN']=0x3]='WARN',_0x2f2acd[_0x2f2acd['ERROR']=0x4]='ERROR',_0x2f2acd[_0x2f2acd['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x409361,_0x592dd4,..._0x3c239e)=>{if(_0x592dd4<_0x409361['logLevel'])return;const _0x40ec44=new Date()['toISOString'](),_0x249ac0=Mc[_0x592dd4];if(_0x249ac0)console[_0x249ac0]('['+_0x40ec44+']\x20\x20'+_0x409361['name']+':',..._0x3c239e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x592dd4+')');};class Bi{constructor(_0x36d8c8){this['name']=_0x36d8c8,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x57abfa){if(!(_0x57abfa in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x57abfa+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x57abfa;}['setLogLevel'](_0x12c1fb){this['_logLevel']=typeof _0x12c1fb=='string'?Oc[_0x12c1fb]:_0x12c1fb;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x28708b){if(typeof _0x28708b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x28708b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2646f9){this['_userLogHandler']=_0x2646f9;}['debug'](..._0x5e493c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5e493c),this['_logHandler'](this,T['DEBUG'],..._0x5e493c);}['log'](..._0x11ebe8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x11ebe8),this['_logHandler'](this,T['VERBOSE'],..._0x11ebe8);}['info'](..._0x3e3b23){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3e3b23),this['_logHandler'](this,T['INFO'],..._0x3e3b23);}['warn'](..._0x1c137e){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1c137e),this['_logHandler'](this,T['WARN'],..._0x1c137e);}['error'](..._0x244a6e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x244a6e),this['_logHandler'](this,T['ERROR'],..._0x244a6e);}}const xc=(_0x2ea762,_0x4c8310)=>_0x4c8310['some'](_0xfa0d72=>_0x2ea762 instanceof _0xfa0d72);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x23602a){const _0x193774=new Promise((_0x1d4d72,_0x4fa7ba)=>{const _0x3b6ee0=()=>{_0x23602a['removeEventListener']('success',_0x271726),_0x23602a['removeEventListener']('error',_0x91bbc5);},_0x271726=()=>{_0x1d4d72(ge(_0x23602a['result'])),_0x3b6ee0();},_0x91bbc5=()=>{_0x4fa7ba(_0x23602a['error']),_0x3b6ee0();};_0x23602a['addEventListener']('success',_0x271726),_0x23602a['addEventListener']('error',_0x91bbc5);});return _0x193774['then'](_0x109e9c=>{_0x109e9c instanceof IDBCursor&&Jr['set'](_0x109e9c,_0x23602a);})['catch'](()=>{}),Vi['set'](_0x193774,_0x23602a),_0x193774;}function Bc(_0x2362b4){if(_i['has'](_0x2362b4))return;const _0x568326=new Promise((_0x1ab10e,_0x5bf9be)=>{const _0x55eb97=()=>{_0x2362b4['removeEventListener']('complete',_0x4bba63),_0x2362b4['removeEventListener']('error',_0x43cbdd),_0x2362b4['removeEventListener']('abort',_0x43cbdd);},_0x4bba63=()=>{_0x1ab10e(),_0x55eb97();},_0x43cbdd=()=>{_0x5bf9be(_0x2362b4['error']||new DOMException('AbortError','AbortError')),_0x55eb97();};_0x2362b4['addEventListener']('complete',_0x4bba63),_0x2362b4['addEventListener']('error',_0x43cbdd),_0x2362b4['addEventListener']('abort',_0x43cbdd);});_i['set'](_0x2362b4,_0x568326);}let gi={'get'(_0x2e752a,_0x4c62c9,_0x395b81){if(_0x2e752a instanceof IDBTransaction){if(_0x4c62c9==='done')return _i['get'](_0x2e752a);if(_0x4c62c9==='objectStoreNames')return _0x2e752a['objectStoreNames']||Xr['get'](_0x2e752a);if(_0x4c62c9==='store')return _0x395b81['objectStoreNames'][0x1]?void 0x0:_0x395b81['objectStore'](_0x395b81['objectStoreNames'][0x0]);}return ge(_0x2e752a[_0x4c62c9]);},'set'(_0x278010,_0x2f6e47,_0x15d62d){return _0x278010[_0x2f6e47]=_0x15d62d,!0x0;},'has'(_0x5720a3,_0x222da8){return _0x5720a3 instanceof IDBTransaction&&(_0x222da8==='done'||_0x222da8==='store')?!0x0:_0x222da8 in _0x5720a3;}};function Vc(_0x2e7c2b){gi=_0x2e7c2b(gi);}function Hc(_0x4b44d5){return _0x4b44d5===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x37c60f,..._0x13c0d4){const _0x2d0518=_0x4b44d5['call'](ii(this),_0x37c60f,..._0x13c0d4);return Xr['set'](_0x2d0518,_0x37c60f['sort']?_0x37c60f['sort']():[_0x37c60f]),ge(_0x2d0518);}:Uc()['includes'](_0x4b44d5)?function(..._0x2d0778){return _0x4b44d5['apply'](ii(this),_0x2d0778),ge(Jr['get'](this));}:function(..._0x5edce4){return ge(_0x4b44d5['apply'](ii(this),_0x5edce4));};}function $c(_0x433ac1){return typeof _0x433ac1=='function'?Hc(_0x433ac1):(_0x433ac1 instanceof IDBTransaction&&Bc(_0x433ac1),xc(_0x433ac1,Fc())?new Proxy(_0x433ac1,gi):_0x433ac1);}function ge(_0x37fd34){if(_0x37fd34 instanceof IDBRequest)return Wc(_0x37fd34);if(ni['has'](_0x37fd34))return ni['get'](_0x37fd34);const _0x4effcd=$c(_0x37fd34);return _0x4effcd!==_0x37fd34&&(ni['set'](_0x37fd34,_0x4effcd),Vi['set'](_0x4effcd,_0x37fd34)),_0x4effcd;}const ii=_0x1a798f=>Vi['get'](_0x1a798f);function Gc(_0x1c95d2,_0x5d27ce,{blocked:_0x541e16,upgrade:_0x5e0810,blocking:_0x3affd7,terminated:_0x51e36b}={}){const _0x112395=indexedDB['open'](_0x1c95d2,_0x5d27ce),_0x402a4e=ge(_0x112395);return _0x5e0810&&_0x112395['addEventListener']('upgradeneeded',_0x2926db=>{_0x5e0810(ge(_0x112395['result']),_0x2926db['oldVersion'],_0x2926db['newVersion'],ge(_0x112395['transaction']),_0x2926db);}),_0x541e16&&_0x112395['addEventListener']('blocked',_0x4909af=>_0x541e16(_0x4909af['oldVersion'],_0x4909af['newVersion'],_0x4909af)),_0x402a4e['then'](_0x5b1ff2=>{_0x51e36b&&_0x5b1ff2['addEventListener']('close',()=>_0x51e36b()),_0x3affd7&&_0x5b1ff2['addEventListener']('versionchange',_0x1bc007=>_0x3affd7(_0x1bc007['oldVersion'],_0x1bc007['newVersion'],_0x1bc007));})['catch'](()=>{}),_0x402a4e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x21eef5,_0x407c25){if(!(_0x21eef5 instanceof IDBDatabase&&!(_0x407c25 in _0x21eef5)&&typeof _0x407c25=='string'))return;if(si['get'](_0x407c25))return si['get'](_0x407c25);const _0x5e0a57=_0x407c25['replace'](/FromIndex$/,''),_0x3023a7=_0x407c25!==_0x5e0a57,_0x3e7f85=zc['includes'](_0x5e0a57);if(!(_0x5e0a57 in(_0x3023a7?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3e7f85||qc['includes'](_0x5e0a57)))return;const _0x563616=async function(_0x6ef0bf,..._0x18c082){const _0x5b0100=this['transaction'](_0x6ef0bf,_0x3e7f85?'readwrite':'readonly');let _0x5d74c2=_0x5b0100['store'];return _0x3023a7&&(_0x5d74c2=_0x5d74c2['index'](_0x18c082['shift']())),(await Promise['all']([_0x5d74c2[_0x5e0a57](..._0x18c082),_0x3e7f85&&_0x5b0100['done']]))[0x0];};return si['set'](_0x407c25,_0x563616),_0x563616;}Vc(_0x26f51=>({..._0x26f51,'get':(_0x2e0d7b,_0x62b526,_0x2b86a2)=>Ms(_0x2e0d7b,_0x62b526)||_0x26f51['get'](_0x2e0d7b,_0x62b526,_0x2b86a2),'has':(_0xf155ff,_0x1f5b8c)=>!!Ms(_0xf155ff,_0x1f5b8c)||_0x26f51['has'](_0xf155ff,_0x1f5b8c)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4ea0a9){this['container']=_0x4ea0a9;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3ec443=>{if(Kc(_0x3ec443)){const _0x51deb2=_0x3ec443['getImmediate']();return _0x51deb2['library']+'/'+_0x51deb2['version'];}else return null;})['filter'](_0x2dcef6=>_0x2dcef6)['join']('\x20');}}function Kc(_0x2a61c6){const _0x42520b=_0x2a61c6['getComponent']();return(_0x42520b==null?void 0x0:_0x42520b['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x3c0167,_0x638368){try{_0x3c0167['container']['addComponent'](_0x638368);}catch(_0x174203){oe['debug']('Component\x20'+_0x638368['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3c0167['name'],_0x174203);}}function st(_0x12467c){const _0x21141a=_0x12467c['name'];if(Ei['has'](_0x21141a))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x21141a+'.'),!0x1;Ei['set'](_0x21141a,_0x12467c);for(const _0x4efde0 of Ue['values']())xs(_0x4efde0,_0x12467c);for(const _0x551ae7 of vi['values']())xs(_0x551ae7,_0x12467c);return!0x0;}function Hi(_0x1473bd,_0x4af934){const _0x4878e0=_0x1473bd['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4878e0&&_0x4878e0['triggerHeartbeat'](),_0x1473bd['container']['getProvider'](_0x4af934);}function $(_0x541c1b){return _0x541c1b==null?!0x1:_0x541c1b['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x236f72,_0x84c3ae,_0x5e0c73){this['_isDeleted']=!0x1,this['_options']={..._0x236f72},this['_config']={..._0x84c3ae},this['_name']=_0x84c3ae['name'],this['_automaticDataCollectionEnabled']=_0x84c3ae['automaticDataCollectionEnabled'],this['_container']=_0x5e0c73,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1a46f8){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1a46f8;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1c8dfd){this['_isDeleted']=_0x1c8dfd;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x259a12,_0x3f8b54={}){let _0x2813f8=_0x259a12;typeof _0x3f8b54!='object'&&(_0x3f8b54={'name':_0x3f8b54});const _0x569df1={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x3f8b54},_0x2b921b=_0x569df1['name'];if(typeof _0x2b921b!='string'||!_0x2b921b)throw me['create']('bad-app-name',{'appName':String(_0x2b921b)});if(_0x2813f8||(_0x2813f8=zr()),!_0x2813f8)throw me['create']('no-options');const _0x49dc7d=Ue['get'](_0x2b921b);if(_0x49dc7d){if(xe(_0x2813f8,_0x49dc7d['options'])&&xe(_0x569df1,_0x49dc7d['config']))return _0x49dc7d;throw me['create']('duplicate-app',{'appName':_0x2b921b});}const _0x188a20=new Nc(_0x2b921b);for(const _0x33bba3 of Ei['values']())_0x188a20['addComponent'](_0x33bba3);const _0x590d16=new Tl(_0x2813f8,_0x569df1,_0x188a20);return Ue['set'](_0x2b921b,_0x590d16),_0x590d16;}function Zr(_0x473ebe=yi){const _0x12e7b5=Ue['get'](_0x473ebe);if(!_0x12e7b5&&_0x473ebe===yi&&zr())return Sl();if(!_0x12e7b5)throw me['create']('no-app',{'appName':_0x473ebe});return _0x12e7b5;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x18caf8){let _0x5ae42f=!0x1;const _0x4417c8=_0x18caf8['name'];Ue['has'](_0x4417c8)?(_0x5ae42f=!0x0,Ue['delete'](_0x4417c8)):vi['has'](_0x4417c8)&&_0x18caf8['decRefCount']()<=0x0&&(vi['delete'](_0x4417c8),_0x5ae42f=!0x0),_0x5ae42f&&(await Promise['all'](_0x18caf8['container']['getProviders']()['map'](_0x1ed09f=>_0x1ed09f['delete']())),_0x18caf8['isDeleted']=!0x0);}function ye(_0x2e10ef,_0x138add,_0x1c658b){let _0x21ce3d=wl[_0x2e10ef]??_0x2e10ef;_0x1c658b&&(_0x21ce3d+='-'+_0x1c658b);const _0x185ded=_0x21ce3d['match'](/\s|\//),_0x21fd9d=_0x138add['match'](/\s|\//);if(_0x185ded||_0x21fd9d){const _0x4e3c43=['Unable\x20to\x20register\x20library\x20\x22'+_0x21ce3d+'\x22\x20with\x20version\x20\x22'+_0x138add+'\x22:'];_0x185ded&&_0x4e3c43['push']('library\x20name\x20\x22'+_0x21ce3d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x185ded&&_0x21fd9d&&_0x4e3c43['push']('and'),_0x21fd9d&&_0x4e3c43['push']('version\x20name\x20\x22'+_0x138add+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x4e3c43['join']('\x20'));return;}st(new Fe(_0x21ce3d+'-version',()=>({'library':_0x21ce3d,'version':_0x138add}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x5ca163,_0x36548f)=>{switch(_0x36548f){case 0x0:try{_0x5ca163['createObjectStore'](Ot);}catch(_0x532c65){console['warn'](_0x532c65);}}}})['catch'](_0x5a89f0=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5a89f0['message']});})),ri;}async function Al(_0x249503){try{const _0x206984=(await eo())['transaction'](Ot),_0x4707e2=await _0x206984['objectStore'](Ot)['get'](to(_0x249503));return await _0x206984['done'],_0x4707e2;}catch(_0x340504){if(_0x340504 instanceof Re)oe['warn'](_0x340504['message']);else{const _0x24404e=me['create']('idb-get',{'originalErrorMessage':_0x340504==null?void 0x0:_0x340504['message']});oe['warn'](_0x24404e['message']);}}}async function Fs(_0x3c0663,_0xff8325){try{const _0x1681ff=(await eo())['transaction'](Ot,'readwrite');await _0x1681ff['objectStore'](Ot)['put'](_0xff8325,to(_0x3c0663)),await _0x1681ff['done'];}catch(_0x1d08b0){if(_0x1d08b0 instanceof Re)oe['warn'](_0x1d08b0['message']);else{const _0x3c0ee0=me['create']('idb-set',{'originalErrorMessage':_0x1d08b0==null?void 0x0:_0x1d08b0['message']});oe['warn'](_0x3c0ee0['message']);}}}function to(_0x1e0ae2){return _0x1e0ae2['name']+'!'+_0x1e0ae2['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x13c859){this['container']=_0x13c859,this['_heartbeatsCache']=null;const _0x59dda7=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x59dda7),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4fe9b9=>(this['_heartbeatsCache']=_0x4fe9b9,_0x4fe9b9));}async['triggerHeartbeat'](){var _0x53ce24,_0x94f367;try{const _0x1b97e9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5456dd=Us();if(((_0x53ce24=this['_heartbeatsCache'])==null?void 0x0:_0x53ce24['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x94f367=this['_heartbeatsCache'])==null?void 0x0:_0x94f367['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5456dd||this['_heartbeatsCache']['heartbeats']['some'](_0x185aca=>_0x185aca['date']===_0x5456dd))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5456dd,'agent':_0x1b97e9}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x528874=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x528874,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1fa6bd){oe['warn'](_0x1fa6bd);}}async['getHeartbeatsHeader'](){var _0x332947;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x332947=this['_heartbeatsCache'])==null?void 0x0:_0x332947['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x30940a=Us(),{heartbeatsToSend:_0x528974,unsentEntries:_0x82c4c5}=Ol(this['_heartbeatsCache']['heartbeats']),_0xaa3f1f=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x528974}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x30940a,_0x82c4c5['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x82c4c5,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xaa3f1f;}catch(_0x2cd713){return oe['warn'](_0x2cd713),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x4a91c2,_0x4e6cc5=kl){const _0x442e2e=[];let _0x2e826d=_0x4a91c2['slice']();for(const _0x3cf384 of _0x4a91c2){const _0x22e9d8=_0x442e2e['find'](_0x5c984e=>_0x5c984e['agent']===_0x3cf384['agent']);if(_0x22e9d8){if(_0x22e9d8['dates']['push'](_0x3cf384['date']),Ws(_0x442e2e)>_0x4e6cc5){_0x22e9d8['dates']['pop']();break;}}else{if(_0x442e2e['push']({'agent':_0x3cf384['agent'],'dates':[_0x3cf384['date']]}),Ws(_0x442e2e)>_0x4e6cc5){_0x442e2e['pop']();break;}}_0x2e826d=_0x2e826d['slice'](0x1);}return{'heartbeatsToSend':_0x442e2e,'unsentEntries':_0x2e826d};}class Dl{constructor(_0xaaf499){this['app']=_0xaaf499,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x21e7d8=await Al(this['app']);return _0x21e7d8!=null&&_0x21e7d8['heartbeats']?_0x21e7d8:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x6f33a7){if(await this['_canUseIndexedDBPromise']){const _0x239680=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x6f33a7['lastSentHeartbeatDate']??_0x239680['lastSentHeartbeatDate'],'heartbeats':_0x6f33a7['heartbeats']});}else return;}async['add'](_0x3287f9){if(await this['_canUseIndexedDBPromise']){const _0x1433e6=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3287f9['lastSentHeartbeatDate']??_0x1433e6['lastSentHeartbeatDate'],'heartbeats':[..._0x1433e6['heartbeats'],..._0x3287f9['heartbeats']]});}else return;}}function Ws(_0x5bbbe7){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x5bbbe7}))['length'];}function Ml(_0x19c07f){if(_0x19c07f['length']===0x0)return-0x1;let _0x84f0b=0x0,_0x522e6c=_0x19c07f[0x0]['date'];for(let _0x18f9a8=0x1;_0x18f9a8<_0x19c07f['length'];_0x18f9a8++)_0x19c07f[_0x18f9a8]['date']<_0x522e6c&&(_0x522e6c=_0x19c07f[_0x18f9a8]['date'],_0x84f0b=_0x18f9a8);return _0x84f0b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x34e9d9){st(new Fe('platform-logger',_0x46547f=>new jc(_0x46547f),'PRIVATE')),st(new Fe('heartbeat',_0x4d53cf=>new Nl(_0x4d53cf),'PRIVATE')),ye(mi,Ls,_0x34e9d9),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1ebbac){no=_0x1ebbac;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x23cb3a){this['domStorage_']=_0x23cb3a,this['prefix_']='firebase:';}['set'](_0x25c645,_0x51b35f){_0x51b35f==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x25c645)):this['domStorage_']['setItem'](this['prefixedName_'](_0x25c645),O(_0x51b35f));}['get'](_0x288a3d){const _0x17c31a=this['domStorage_']['getItem'](this['prefixedName_'](_0x288a3d));return _0x17c31a==null?null:Nt(_0x17c31a);}['remove'](_0xccd4e8){this['domStorage_']['removeItem'](this['prefixedName_'](_0xccd4e8));}['prefixedName_'](_0x3cc508){return this['prefix_']+_0x3cc508;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1b625a,_0x590d15){_0x590d15==null?delete this['cache_'][_0x1b625a]:this['cache_'][_0x1b625a]=_0x590d15;}['get'](_0x8dda0f){return Q(this['cache_'],_0x8dda0f)?this['cache_'][_0x8dda0f]:null;}['remove'](_0x11be4d){delete this['cache_'][_0x11be4d];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3887d){try{if(typeof window<'u'&&typeof window[_0x3887d]<'u'){const _0x17ee55=window[_0x3887d];return _0x17ee55['setItem']('firebase:sentinel','cache'),_0x17ee55['removeItem']('firebase:sentinel'),new Wl(_0x17ee55);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4a4172=0x1;return function(){return _0x4a4172++;};}()),ro=function(_0x5a5255){const _0x2647d2=Rc(_0x5a5255),_0x4684ea=new Cc();_0x4684ea['update'](_0x2647d2);const _0x40465b=_0x4684ea['digest']();return Fi['encodeByteArray'](_0x40465b);},zt=function(..._0x4ffad5){let _0x436526='';for(let _0x497576=0x0;_0x497576<_0x4ffad5['length'];_0x497576++){const _0x311f18=_0x4ffad5[_0x497576];Array['isArray'](_0x311f18)||_0x311f18&&typeof _0x311f18=='object'&&typeof _0x311f18['length']=='number'?_0x436526+=zt['apply'](null,_0x311f18):typeof _0x311f18=='object'?_0x436526+=O(_0x311f18):_0x436526+=_0x311f18,_0x436526+='\x20';}return _0x436526;};let St=null,$s=!0x0;const Hl=function(_0x207ca6,_0x29230e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x523f91){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x32cccd=zt['apply'](null,_0x523f91);St(_0x32cccd);}},jt=function(_0x18f91d){return function(..._0xd424a6){L(_0x18f91d,..._0xd424a6);};},Ii=function(..._0x3c86b6){const _0x3f646d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x3c86b6);Ze['error'](_0x3f646d);},ae=function(..._0x59f872){const _0x5a23c9='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x59f872);throw Ze['error'](_0x5a23c9),new Error(_0x5a23c9);},U=function(..._0x474424){const _0xcd243d='FIREBASE\x20WARNING:\x20'+zt(..._0x474424);Ze['warn'](_0xcd243d);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0xb4642){return typeof _0xb4642=='number'&&(_0xb4642!==_0xb4642||_0xb4642===Number['POSITIVE_INFINITY']||_0xb4642===Number['NEGATIVE_INFINITY']);},Gl=function(_0x34d47c){if(document['readyState']==='complete')_0x34d47c();else{let _0x2c6a64=!0x1;const _0x3e86e6=function(){if(!document['body']){setTimeout(_0x3e86e6,Math['floor'](0xa));return;}_0x2c6a64||(_0x2c6a64=!0x0,_0x34d47c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3e86e6,!0x1),window['addEventListener']('load',_0x3e86e6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3e86e6();}),window['attachEvent']('onload',_0x3e86e6));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x235a0a,_0x30391f){if(_0x235a0a===_0x30391f)return 0x0;if(_0x235a0a===We||_0x30391f===we)return-0x1;if(_0x30391f===We||_0x235a0a===we)return 0x1;{const _0x5c0c5b=Gs(_0x235a0a),_0x575166=Gs(_0x30391f);return _0x5c0c5b!==null?_0x575166!==null?_0x5c0c5b-_0x575166===0x0?_0x235a0a['length']-_0x30391f['length']:_0x5c0c5b-_0x575166:-0x1:_0x575166!==null?0x1:_0x235a0a<_0x30391f?-0x1:0x1;}},ql=function(_0x24e0d1,_0x10c43f){return _0x24e0d1===_0x10c43f?0x0:_0x24e0d1<_0x10c43f?-0x1:0x1;},vt=function(_0x300dd0,_0x3a1932){if(_0x3a1932&&_0x300dd0 in _0x3a1932)return _0x3a1932[_0x300dd0];throw new Error('Missing\x20required\x20key\x20('+_0x300dd0+')\x20in\x20object:\x20'+O(_0x3a1932));},$i=function(_0x4eaa36){if(typeof _0x4eaa36!='object'||_0x4eaa36===null)return O(_0x4eaa36);const _0x1ed19c=[];for(const _0xf17f0b in _0x4eaa36)_0x1ed19c['push'](_0xf17f0b);_0x1ed19c['sort']();let _0x1d2e50='{';for(let _0x13f51a=0x0;_0x13f51a<_0x1ed19c['length'];_0x13f51a++)_0x13f51a!==0x0&&(_0x1d2e50+=','),_0x1d2e50+=O(_0x1ed19c[_0x13f51a]),_0x1d2e50+=':',_0x1d2e50+=$i(_0x4eaa36[_0x1ed19c[_0x13f51a]]);return _0x1d2e50+='}',_0x1d2e50;},oo=function(_0x316be0,_0x2e9f97){const _0x43f745=_0x316be0['length'];if(_0x43f745<=_0x2e9f97)return[_0x316be0];const _0x369298=[];for(let _0x540c0e=0x0;_0x540c0e<_0x43f745;_0x540c0e+=_0x2e9f97)_0x540c0e+_0x2e9f97>_0x43f745?_0x369298['push'](_0x316be0['substring'](_0x540c0e,_0x43f745)):_0x369298['push'](_0x316be0['substring'](_0x540c0e,_0x540c0e+_0x2e9f97));return _0x369298;};function x(_0x1ddb23,_0x1bbc9d){for(const _0x1a69f7 in _0x1ddb23)_0x1ddb23['hasOwnProperty'](_0x1a69f7)&&_0x1bbc9d(_0x1a69f7,_0x1ddb23[_0x1a69f7]);}const ao=function(_0x11dfaf){f(!xn(_0x11dfaf),'Invalid\x20JSON\x20number');const _0x29152f=0xb,_0x1d473e=0x34,_0x8c8ab6=(0x1<<_0x29152f-0x1)-0x1;let _0xd702c2,_0x504e91,_0x19bf8d,_0x261af0,_0x25ba6a;_0x11dfaf===0x0?(_0x504e91=0x0,_0x19bf8d=0x0,_0xd702c2=0x1/_0x11dfaf===-0x1/0x0?0x1:0x0):(_0xd702c2=_0x11dfaf<0x0,_0x11dfaf=Math['abs'](_0x11dfaf),_0x11dfaf>=Math['pow'](0x2,0x1-_0x8c8ab6)?(_0x261af0=Math['min'](Math['floor'](Math['log'](_0x11dfaf)/Math['LN2']),_0x8c8ab6),_0x504e91=_0x261af0+_0x8c8ab6,_0x19bf8d=Math['round'](_0x11dfaf*Math['pow'](0x2,_0x1d473e-_0x261af0)-Math['pow'](0x2,_0x1d473e))):(_0x504e91=0x0,_0x19bf8d=Math['round'](_0x11dfaf/Math['pow'](0x2,0x1-_0x8c8ab6-_0x1d473e))));const _0x15950a=[];for(_0x25ba6a=_0x1d473e;_0x25ba6a;_0x25ba6a-=0x1)_0x15950a['push'](_0x19bf8d%0x2?0x1:0x0),_0x19bf8d=Math['floor'](_0x19bf8d/0x2);for(_0x25ba6a=_0x29152f;_0x25ba6a;_0x25ba6a-=0x1)_0x15950a['push'](_0x504e91%0x2?0x1:0x0),_0x504e91=Math['floor'](_0x504e91/0x2);_0x15950a['push'](_0xd702c2?0x1:0x0),_0x15950a['reverse']();const _0x15ea72=_0x15950a['join']('');let _0x16d1c5='';for(_0x25ba6a=0x0;_0x25ba6a<0x40;_0x25ba6a+=0x8){let _0x367575=parseInt(_0x15ea72['substr'](_0x25ba6a,0x8),0x2)['toString'](0x10);_0x367575['length']===0x1&&(_0x367575='0'+_0x367575),_0x16d1c5=_0x16d1c5+_0x367575;}return _0x16d1c5['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x6719ad,_0x199ef9){let _0x27d1f7='Unknown\x20Error';_0x6719ad==='too_big'?_0x27d1f7='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x6719ad==='permission_denied'?_0x27d1f7='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x6719ad==='unavailable'&&(_0x27d1f7='The\x20service\x20is\x20unavailable');const _0x363df1=new Error(_0x6719ad+'\x20at\x20'+_0x199ef9['_path']['toString']()+':\x20'+_0x27d1f7);return _0x363df1['code']=_0x6719ad['toUpperCase'](),_0x363df1;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x11d41c){if(Yl['test'](_0x11d41c)){const _0x54cbc6=Number(_0x11d41c);if(_0x54cbc6>=Ql&&_0x54cbc6<=Jl)return _0x54cbc6;}return null;},ft=function(_0x56cb71){try{_0x56cb71();}catch(_0x55edef){setTimeout(()=>{const _0x40917f=_0x55edef['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x40917f),_0x55edef;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x228c5e,_0x3f26fb){const _0x33bd67=setTimeout(_0x228c5e,_0x3f26fb);return typeof _0x33bd67=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x33bd67):typeof _0x33bd67=='object'&&_0x33bd67['unref']&&_0x33bd67['unref'](),_0x33bd67;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x407b20,_0x55c675){this['appCheckProvider']=_0x55c675,this['appName']=_0x407b20['name'],$(_0x407b20)&&_0x407b20['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x407b20['settings']['appCheckToken']),this['appCheck']=_0x55c675==null?void 0x0:_0x55c675['getImmediate']({'optional':!0x0}),this['appCheck']||_0x55c675==null||_0x55c675['get']()['then'](_0x222dcf=>this['appCheck']=_0x222dcf);}['getToken'](_0x5b3b27){if(this['serverAppAppCheckToken']){if(_0x5b3b27)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5b3b27):new Promise((_0x35c6a5,_0x16a121)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5b3b27)['then'](_0x35c6a5,_0x16a121):_0x35c6a5(null);},0x0);});}['addTokenChangeListener'](_0x1e2689){var _0x4e26a4;(_0x4e26a4=this['appCheckProvider'])==null||_0x4e26a4['get']()['then'](_0x3a2dd8=>_0x3a2dd8['addTokenListener'](_0x1e2689));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1d4177,_0x4ca25b,_0x1a759c){this['appName_']=_0x1d4177,this['firebaseOptions_']=_0x4ca25b,this['authProvider_']=_0x1a759c,this['auth_']=null,this['auth_']=_0x1a759c['getImmediate']({'optional':!0x0}),this['auth_']||_0x1a759c['onInit'](_0x7a5829=>this['auth_']=_0x7a5829);}['getToken'](_0x418ac5){return this['auth_']?this['auth_']['getToken'](_0x418ac5)['catch'](_0x41032a=>_0x41032a&&_0x41032a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x41032a)):new Promise((_0x471983,_0x1efba8)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x418ac5)['then'](_0x471983,_0x1efba8):_0x471983(null);},0x0);});}['addTokenChangeListener'](_0x3f203a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3f203a):this['authProvider_']['get']()['then'](_0x5e5ffb=>_0x5e5ffb['addAuthTokenListener'](_0x3f203a));}['removeTokenChangeListener'](_0x2f8c02){this['authProvider_']['get']()['then'](_0x1d6eb=>_0x1d6eb['removeAuthTokenListener'](_0x2f8c02));}['notifyForInvalidToken'](){let _0x572fdf='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x572fdf+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x572fdf+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x572fdf+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x572fdf);}}class an{constructor(_0xa0bfe7){this['accessToken']=_0xa0bfe7;}['getToken'](_0x59959b){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x23c374){_0x23c374(this['accessToken']);}['removeTokenChangeListener'](_0x282364){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1f737c,_0x10c573,_0x2e9c33,_0x3865c6,_0x23f4f6=!0x1,_0x4c7db4='',_0x5d9166=!0x1,_0xe94c60=!0x1,_0xdb0507=null){this['secure']=_0x10c573,this['namespace']=_0x2e9c33,this['webSocketOnly']=_0x3865c6,this['nodeAdmin']=_0x23f4f6,this['persistenceKey']=_0x4c7db4,this['includeNamespaceInQueryParams']=_0x5d9166,this['isUsingEmulator']=_0xe94c60,this['emulatorOptions']=_0xdb0507,this['_host']=_0x1f737c['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x1f737c)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x540faf){_0x540faf!==this['internalHost']&&(this['internalHost']=_0x540faf,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1e6c96=this['toURLString']();return this['persistenceKey']&&(_0x1e6c96+='<'+this['persistenceKey']+'>'),_0x1e6c96;}['toURLString'](){const _0x1f3ad2=this['secure']?'https://':'http://',_0x1f7817=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1f3ad2+this['host']+'/'+_0x1f7817;}}function th(_0x1abbbe){return _0x1abbbe['host']!==_0x1abbbe['internalHost']||_0x1abbbe['isCustomHost']()||_0x1abbbe['includeNamespaceInQueryParams'];}function vo(_0x50076b,_0x1af814,_0x535611){f(typeof _0x1af814=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x535611=='object','typeof\x20params\x20must\x20==\x20object');let _0x13c155;if(_0x1af814===go)_0x13c155=(_0x50076b['secure']?'wss://':'ws://')+_0x50076b['internalHost']+'/.ws?';else{if(_0x1af814===mo)_0x13c155=(_0x50076b['secure']?'https://':'http://')+_0x50076b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1af814);}th(_0x50076b)&&(_0x535611['ns']=_0x50076b['namespace']);const _0x55a0b3=[];return x(_0x535611,(_0x3a9d16,_0x1d6c73)=>{_0x55a0b3['push'](_0x3a9d16+'='+_0x1d6c73);}),_0x13c155+_0x55a0b3['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x2f2240,_0x13a52b=0x1){Q(this['counters_'],_0x2f2240)||(this['counters_'][_0x2f2240]=0x0),this['counters_'][_0x2f2240]+=_0x13a52b;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x507721){const _0x1c5b79=_0x507721['toString']();return oi[_0x1c5b79]||(oi[_0x1c5b79]=new nh()),oi[_0x1c5b79];}function ih(_0xe2f41c,_0x4c5ea2){const _0x21a3f2=_0xe2f41c['toString']();return ai[_0x21a3f2]||(ai[_0x21a3f2]=_0x4c5ea2()),ai[_0x21a3f2];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x34bdff){this['onMessage_']=_0x34bdff,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5e20d2,_0x8aa95f){this['closeAfterResponse']=_0x5e20d2,this['onClose']=_0x8aa95f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x53d461,_0x53b69c){for(this['pendingResponses'][_0x53d461]=_0x53b69c;this['pendingResponses'][this['currentResponseNum']];){const _0x10532e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2f3a99=0x0;_0x2f3a99<_0x10532e['length'];++_0x2f3a99)_0x10532e[_0x2f3a99]&&ft(()=>{this['onMessage_'](_0x10532e[_0x2f3a99]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2e108e,_0x29bcdc,_0x30ee74,_0x61614a,_0x271e14,_0x166c1c,_0x1a31cf){this['connId']=_0x2e108e,this['repoInfo']=_0x29bcdc,this['applicationId']=_0x30ee74,this['appCheckToken']=_0x61614a,this['authToken']=_0x271e14,this['transportSessionId']=_0x166c1c,this['lastSessionId']=_0x1a31cf,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2e108e),this['stats_']=qi(_0x29bcdc),this['urlFn']=_0x284a97=>(this['appCheckToken']&&(_0x284a97[wi]=this['appCheckToken']),vo(_0x29bcdc,mo,_0x284a97));}['open'](_0x2c7a0d,_0x59981e){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x59981e,this['myPacketOrderer']=new sh(_0x2c7a0d),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x282427)=>{const [_0x3b6aa0,_0x1b7ed9,_0xba57e5,_0x4eba3d,_0x4bb4ce]=_0x282427;if(this['incrementIncomingBytes_'](_0x282427),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3b6aa0===qs)this['id']=_0x1b7ed9,this['password']=_0xba57e5;else{if(_0x3b6aa0===rh)_0x1b7ed9?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1b7ed9,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3b6aa0);}}},(..._0x2d5342)=>{const [_0x1f055b,_0x4a09fd]=_0x2d5342;this['incrementIncomingBytes_'](_0x2d5342),this['myPacketOrderer']['handleResponse'](_0x1f055b,_0x4a09fd);},()=>{this['onClosed_']();},this['urlFn']);const _0xed3119={};_0xed3119[qs]='t',_0xed3119[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xed3119[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xed3119[co]=Gi,this['transportSessionId']&&(_0xed3119[lo]=this['transportSessionId']),this['lastSessionId']&&(_0xed3119[po]=this['lastSessionId']),this['applicationId']&&(_0xed3119[_o]=this['applicationId']),this['appCheckToken']&&(_0xed3119[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xed3119[ho]=uo);const _0x4dd7a8=this['urlFn'](_0xed3119);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4dd7a8),this['scriptTagHolder']['addTag'](_0x4dd7a8,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x53f6b1){const _0x273754=O(_0x53f6b1);this['bytesSent']+=_0x273754['length'],this['stats_']['incrementCounter']('bytes_sent',_0x273754['length']);const _0x2ff980=$r(_0x273754),_0x55a128=oo(_0x2ff980,fh);for(let _0x100754=0x0;_0x100754<_0x55a128['length'];_0x100754++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x55a128['length'],_0x55a128[_0x100754]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1e99fc,_0x31982d){this['myDisconnFrame']=document['createElement']('iframe');const _0x46d221={};_0x46d221[dh]='t',_0x46d221[Eo]=_0x1e99fc,_0x46d221[Io]=_0x31982d,this['myDisconnFrame']['src']=this['urlFn'](_0x46d221),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4b40d2){const _0xc5656e=O(_0x4b40d2)['length'];this['bytesReceived']+=_0xc5656e,this['stats_']['incrementCounter']('bytes_received',_0xc5656e);}}class zi{constructor(_0x5738c9,_0x38a32e,_0xdecf56,_0x45dd90){this['onDisconnect']=_0xdecf56,this['urlFn']=_0x45dd90,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5738c9,window[ah+this['uniqueCallbackIdentifier']]=_0x38a32e,this['myIFrame']=zi['createIFrame_']();let _0x7ade02='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x7ade02='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x13151d='<html><body>'+_0x7ade02+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x13151d),this['myIFrame']['doc']['close']();}catch(_0x1750f5){L('frame\x20writing\x20exception'),_0x1750f5['stack']&&L(_0x1750f5['stack']),L(_0x1750f5);}}}static['createIFrame_'](){const _0x8b7242=document['createElement']('iframe');if(_0x8b7242['style']['display']='none',document['body']){document['body']['appendChild'](_0x8b7242);try{_0x8b7242['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x43d5b4=document['domain'];_0x8b7242['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x43d5b4+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x8b7242['contentDocument']?_0x8b7242['doc']=_0x8b7242['contentDocument']:_0x8b7242['contentWindow']?_0x8b7242['doc']=_0x8b7242['contentWindow']['document']:_0x8b7242['document']&&(_0x8b7242['doc']=_0x8b7242['document']),_0x8b7242;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x452548=this['onDisconnect'];_0x452548&&(this['onDisconnect']=null,_0x452548());}['startLongPoll'](_0x84c2d,_0x3a0b8e){for(this['myID']=_0x84c2d,this['myPW']=_0x3a0b8e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5aa628={};_0x5aa628[Eo]=this['myID'],_0x5aa628[Io]=this['myPW'],_0x5aa628[wo]=this['currentSerial'];let _0x1d38a8=this['urlFn'](_0x5aa628),_0x3c5e7a='',_0x2c764a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x3c5e7a['length']<=Co;){const _0x1c0728=this['pendingSegs']['shift']();_0x3c5e7a=_0x3c5e7a+'&'+lh+_0x2c764a+'='+_0x1c0728['seg']+'&'+hh+_0x2c764a+'='+_0x1c0728['ts']+'&'+uh+_0x2c764a+'='+_0x1c0728['d'],_0x2c764a++;}return _0x1d38a8=_0x1d38a8+_0x3c5e7a,this['addLongPollTag_'](_0x1d38a8,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2c25c1,_0x6c8312,_0x43c890){this['pendingSegs']['push']({'seg':_0x2c25c1,'ts':_0x6c8312,'d':_0x43c890}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x9939ea,_0x55982b){this['outstandingRequests']['add'](_0x55982b);const _0x5e03d2=()=>{this['outstandingRequests']['delete'](_0x55982b),this['newRequest_']();},_0x3e29fd=setTimeout(_0x5e03d2,Math['floor'](ph)),_0x572227=()=>{clearTimeout(_0x3e29fd),_0x5e03d2();};this['addTag'](_0x9939ea,_0x572227);}['addTag'](_0x54fb24,_0x339257){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2ea730=this['myIFrame']['doc']['createElement']('script');_0x2ea730['type']='text/javascript',_0x2ea730['async']=!0x0,_0x2ea730['src']=_0x54fb24,_0x2ea730['onload']=_0x2ea730['onreadystatechange']=function(){const _0x22e54c=_0x2ea730['readyState'];(!_0x22e54c||_0x22e54c==='loaded'||_0x22e54c==='complete')&&(_0x2ea730['onload']=_0x2ea730['onreadystatechange']=null,_0x2ea730['parentNode']&&_0x2ea730['parentNode']['removeChild'](_0x2ea730),_0x339257());},_0x2ea730['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x54fb24),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2ea730);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x540974,_0x379cf3,_0x388aee,_0x1c9744,_0x2135ad,_0xea7159,_0x3d301e){this['connId']=_0x540974,this['applicationId']=_0x388aee,this['appCheckToken']=_0x1c9744,this['authToken']=_0x2135ad,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x379cf3),this['connURL']=q['connectionURL_'](_0x379cf3,_0xea7159,_0x3d301e,_0x1c9744,_0x388aee),this['nodeAdmin']=_0x379cf3['nodeAdmin'];}static['connectionURL_'](_0xfbda8f,_0x3dc55e,_0x591726,_0x57346a,_0x313a8e){const _0x3c6ca9={};return _0x3c6ca9[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3c6ca9[ho]=uo),_0x3dc55e&&(_0x3c6ca9[lo]=_0x3dc55e),_0x591726&&(_0x3c6ca9[po]=_0x591726),_0x57346a&&(_0x3c6ca9[wi]=_0x57346a),_0x313a8e&&(_0x3c6ca9[_o]=_0x313a8e),vo(_0xfbda8f,go,_0x3c6ca9);}['open'](_0x2eb38d,_0x2fec62){this['onDisconnect']=_0x2fec62,this['onMessage']=_0x2eb38d,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5bcf49;_c(),this['mySock']=new gn(this['connURL'],[],_0x5bcf49);}catch(_0x17954b){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x452434=_0x17954b['message']||_0x17954b['data'];_0x452434&&this['log_'](_0x452434),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1f4566=>{this['handleIncomingFrame'](_0x1f4566);},this['mySock']['onerror']=_0x3590a8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x9913da=_0x3590a8['message']||_0x3590a8['data'];_0x9913da&&this['log_'](_0x9913da),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x378892=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4fbc34=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x439605=navigator['userAgent']['match'](_0x4fbc34);_0x439605&&_0x439605['length']>0x1&&parseFloat(_0x439605[0x1])<4.4&&(_0x378892=!0x0);}return!_0x378892&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x23ceec){if(this['frames']['push'](_0x23ceec),this['frames']['length']===this['totalFrames']){const _0x91b57c=this['frames']['join']('');this['frames']=null;const _0x2e0015=Nt(_0x91b57c);this['onMessage'](_0x2e0015);}}['handleNewFrameCount_'](_0x435df8){this['totalFrames']=_0x435df8,this['frames']=[];}['extractFrameCount_'](_0x6948f5){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x6948f5['length']<=0x6){const _0x1232e3=Number(_0x6948f5);if(!isNaN(_0x1232e3))return this['handleNewFrameCount_'](_0x1232e3),null;}return this['handleNewFrameCount_'](0x1),_0x6948f5;}['handleIncomingFrame'](_0x41b46d){if(this['mySock']===null)return;const _0x21db4f=_0x41b46d['data'];if(this['bytesReceived']+=_0x21db4f['length'],this['stats_']['incrementCounter']('bytes_received',_0x21db4f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x21db4f);else{const _0x35831c=this['extractFrameCount_'](_0x21db4f);_0x35831c!==null&&this['appendFrame_'](_0x35831c);}}['send'](_0x569089){this['resetKeepAlive']();const _0x1a48a4=O(_0x569089);this['bytesSent']+=_0x1a48a4['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1a48a4['length']);const _0x1714aa=oo(_0x1a48a4,gh);_0x1714aa['length']>0x1&&this['sendString_'](String(_0x1714aa['length']));for(let _0x1026e7=0x0;_0x1026e7<_0x1714aa['length'];_0x1026e7++)this['sendString_'](_0x1714aa[_0x1026e7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3f4b50){try{this['mySock']['send'](_0x3f4b50);}catch(_0x5c2178){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5c2178['message']||_0x5c2178['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x152180){this['initTransports_'](_0x152180);}['initTransports_'](_0x36a50a){const _0x552960=q&&q['isAvailable']();let _0x2c9457=_0x552960&&!q['previouslyFailed']();if(_0x36a50a['webSocketOnly']&&(_0x552960||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2c9457=!0x0),_0x2c9457)this['transports_']=[q];else{const _0x1d070e=this['transports_']=[];for(const _0x6b6d24 of Dt['ALL_TRANSPORTS'])_0x6b6d24&&_0x6b6d24['isAvailable']()&&_0x1d070e['push'](_0x6b6d24);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x56113c,_0x57b1c9,_0x958f1d,_0x221157,_0xe5b84a,_0x4af56f,_0x17819f,_0x3deeaf,_0xb4d829,_0x385042){this['id']=_0x56113c,this['repoInfo_']=_0x57b1c9,this['applicationId_']=_0x958f1d,this['appCheckToken_']=_0x221157,this['authToken_']=_0xe5b84a,this['onMessage_']=_0x4af56f,this['onReady_']=_0x17819f,this['onDisconnect_']=_0x3deeaf,this['onKill_']=_0xb4d829,this['lastSessionId']=_0x385042,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x57b1c9),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5ab27e=this['transportManager_']['initialTransport']();this['conn_']=new _0x5ab27e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5ab27e['responsesRequiredToBeHealthy']||0x0;const _0x46e6a4=this['connReceiver_'](this['conn_']),_0x28b32b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x46e6a4,_0x28b32b);},Math['floor'](0x0));const _0x51ce82=_0x5ab27e['healthyTimeout']||0x0;_0x51ce82>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x51ce82)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x140ab9){return _0x4754db=>{_0x140ab9===this['conn_']?this['onConnectionLost_'](_0x4754db):_0x140ab9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x48d50b){return _0x52b712=>{this['state_']!==0x2&&(_0x48d50b===this['rx_']?this['onPrimaryMessageReceived_'](_0x52b712):_0x48d50b===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x52b712):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xd02868){const _0x333534={'t':'d','d':_0xd02868};this['sendData_'](_0x333534);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x27b8fa){if(ci in _0x27b8fa){const _0x3931f6=_0x27b8fa[ci];_0x3931f6===Ys?this['upgradeIfSecondaryHealthy_']():_0x3931f6===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3931f6===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3441c7){const _0x3c5af1=vt('t',_0x3441c7),_0x457079=vt('d',_0x3441c7);if(_0x3c5af1==='c')this['onSecondaryControl_'](_0x457079);else{if(_0x3c5af1==='d')this['pendingDataMessages']['push'](_0x457079);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3c5af1);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2861eb){const _0x6af0b6=vt('t',_0x2861eb),_0x2cee6b=vt('d',_0x2861eb);_0x6af0b6==='c'?this['onControl_'](_0x2cee6b):_0x6af0b6==='d'&&this['onDataMessage_'](_0x2cee6b);}['onDataMessage_'](_0x2a5ec8){this['onPrimaryResponse_'](),this['onMessage_'](_0x2a5ec8);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x575662){const _0x1e9c3c=vt(ci,_0x575662);if(zs in _0x575662){const _0x547109=_0x575662[zs];if(_0x1e9c3c===Th){const _0x234fce={..._0x547109};this['repoInfo_']['isUsingEmulator']&&(_0x234fce['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x234fce);}else{if(_0x1e9c3c===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5a2489=0x0;_0x5a2489<this['pendingDataMessages']['length'];++_0x5a2489)this['onDataMessage_'](this['pendingDataMessages'][_0x5a2489]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1e9c3c===wh?this['onConnectionShutdown_'](_0x547109):_0x1e9c3c===js?this['onReset_'](_0x547109):_0x1e9c3c===Ch?Ii('Server\x20Error:\x20'+_0x547109):_0x1e9c3c===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1e9c3c);}}}['onHandshake_'](_0x3e2ceb){const _0x1242af=_0x3e2ceb['ts'],_0x5a1373=_0x3e2ceb['v'],_0x4ba609=_0x3e2ceb['h'];this['sessionId']=_0x3e2ceb['s'],this['repoInfo_']['host']=_0x4ba609,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1242af),Gi!==_0x5a1373&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4d19fe=this['transportManager_']['upgradeTransport']();_0x4d19fe&&this['startUpgrade_'](_0x4d19fe);}['startUpgrade_'](_0x53b984){this['secondaryConn_']=new _0x53b984(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x53b984['responsesRequiredToBeHealthy']||0x0;const _0x5f8d20=this['connReceiver_'](this['secondaryConn_']),_0x13147e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5f8d20,_0x13147e),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x21ee05){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x21ee05),this['repoInfo_']['host']=_0x21ee05,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3250db,_0x1f187b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3250db,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1f187b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x17f725=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x17f725||this['rx_']===_0x17f725)&&this['close']();}['onConnectionLost_'](_0x2fe18f){this['conn_']=null,!_0x2fe18f&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x50046f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x50046f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x13c206){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x13c206);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1e7767,_0x5ede78,_0x478d54,_0x50b8eb){}['merge'](_0x304b68,_0x466d9b,_0x122edc,_0x3c2a47){}['refreshAuthToken'](_0x327a45){}['refreshAppCheckToken'](_0x5266f4){}['onDisconnectPut'](_0x13f585,_0x4f16dd,_0xe3c50b){}['onDisconnectMerge'](_0x50e2eb,_0xf40020,_0x14da44){}['onDisconnectCancel'](_0x41dd24,_0x18b2e5){}['reportStats'](_0x191b66){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x40c77b){this['allowedEvents_']=_0x40c77b,this['listeners_']={},f(Array['isArray'](_0x40c77b)&&_0x40c77b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5f3dae,..._0x3e55c9){if(Array['isArray'](this['listeners_'][_0x5f3dae])){const _0x429d33=[...this['listeners_'][_0x5f3dae]];for(let _0xb0af8c=0x0;_0xb0af8c<_0x429d33['length'];_0xb0af8c++)_0x429d33[_0xb0af8c]['callback']['apply'](_0x429d33[_0xb0af8c]['context'],_0x3e55c9);}}['on'](_0x2e385a,_0x5254e7,_0x21173a){this['validateEventType_'](_0x2e385a),this['listeners_'][_0x2e385a]=this['listeners_'][_0x2e385a]||[],this['listeners_'][_0x2e385a]['push']({'callback':_0x5254e7,'context':_0x21173a});const _0x53270b=this['getInitialEvent'](_0x2e385a);_0x53270b&&_0x5254e7['apply'](_0x21173a,_0x53270b);}['off'](_0x9c108,_0x281eb9,_0x48a75d){this['validateEventType_'](_0x9c108);const _0x48846b=this['listeners_'][_0x9c108]||[];for(let _0x124c59=0x0;_0x124c59<_0x48846b['length'];_0x124c59++)if(_0x48846b[_0x124c59]['callback']===_0x281eb9&&(!_0x48a75d||_0x48a75d===_0x48846b[_0x124c59]['context'])){_0x48846b['splice'](_0x124c59,0x1);return;}}['validateEventType_'](_0x2f4f04){f(this['allowedEvents_']['find'](_0x4c7cad=>_0x4c7cad===_0x2f4f04),'Unknown\x20event:\x20'+_0x2f4f04);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x274892){return f(_0x274892==='online','Unknown\x20event\x20type:\x20'+_0x274892),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x5af30c,_0x3ec710){if(_0x3ec710===void 0x0){this['pieces_']=_0x5af30c['split']('/');let _0x386196=0x0;for(let _0x1d7964=0x0;_0x1d7964<this['pieces_']['length'];_0x1d7964++)this['pieces_'][_0x1d7964]['length']>0x0&&(this['pieces_'][_0x386196]=this['pieces_'][_0x1d7964],_0x386196++);this['pieces_']['length']=_0x386196,this['pieceNum_']=0x0;}else this['pieces_']=_0x5af30c,this['pieceNum_']=_0x3ec710;}['toString'](){let _0x56aa47='';for(let _0x54f288=this['pieceNum_'];_0x54f288<this['pieces_']['length'];_0x54f288++)this['pieces_'][_0x54f288]!==''&&(_0x56aa47+='/'+this['pieces_'][_0x54f288]);return _0x56aa47||'/';}}function w(){return new C('');}function y(_0x131c9c){return _0x131c9c['pieceNum_']>=_0x131c9c['pieces_']['length']?null:_0x131c9c['pieces_'][_0x131c9c['pieceNum_']];}function Ce(_0xfb97b7){return _0xfb97b7['pieces_']['length']-_0xfb97b7['pieceNum_'];}function S(_0x1ec099){let _0x245a82=_0x1ec099['pieceNum_'];return _0x245a82<_0x1ec099['pieces_']['length']&&_0x245a82++,new C(_0x1ec099['pieces_'],_0x245a82);}function ji(_0x46bf0c){return _0x46bf0c['pieceNum_']<_0x46bf0c['pieces_']['length']?_0x46bf0c['pieces_'][_0x46bf0c['pieces_']['length']-0x1]:null;}function bh(_0x42bedd){let _0x265bb8='';for(let _0x4122fc=_0x42bedd['pieceNum_'];_0x4122fc<_0x42bedd['pieces_']['length'];_0x4122fc++)_0x42bedd['pieces_'][_0x4122fc]!==''&&(_0x265bb8+='/'+encodeURIComponent(String(_0x42bedd['pieces_'][_0x4122fc])));return _0x265bb8||'/';}function Mt(_0x4e8d46,_0xa96e61=0x0){return _0x4e8d46['pieces_']['slice'](_0x4e8d46['pieceNum_']+_0xa96e61);}function Ro(_0x13924f){if(_0x13924f['pieceNum_']>=_0x13924f['pieces_']['length'])return null;const _0x3c7e7a=[];for(let _0xc603da=_0x13924f['pieceNum_'];_0xc603da<_0x13924f['pieces_']['length']-0x1;_0xc603da++)_0x3c7e7a['push'](_0x13924f['pieces_'][_0xc603da]);return new C(_0x3c7e7a,0x0);}function k(_0x41d4f6,_0x1e962a){const _0x49a62a=[];for(let _0x4ad1c1=_0x41d4f6['pieceNum_'];_0x4ad1c1<_0x41d4f6['pieces_']['length'];_0x4ad1c1++)_0x49a62a['push'](_0x41d4f6['pieces_'][_0x4ad1c1]);if(_0x1e962a instanceof C){for(let _0x4668ca=_0x1e962a['pieceNum_'];_0x4668ca<_0x1e962a['pieces_']['length'];_0x4668ca++)_0x49a62a['push'](_0x1e962a['pieces_'][_0x4668ca]);}else{const _0x1cca1b=_0x1e962a['split']('/');for(let _0x41c99b=0x0;_0x41c99b<_0x1cca1b['length'];_0x41c99b++)_0x1cca1b[_0x41c99b]['length']>0x0&&_0x49a62a['push'](_0x1cca1b[_0x41c99b]);}return new C(_0x49a62a,0x0);}function v(_0x3ad6f0){return _0x3ad6f0['pieceNum_']>=_0x3ad6f0['pieces_']['length'];}function F(_0x1d81e4,_0x14ff57){const _0x3e7a78=y(_0x1d81e4),_0x1feeff=y(_0x14ff57);if(_0x3e7a78===null)return _0x14ff57;if(_0x3e7a78===_0x1feeff)return F(S(_0x1d81e4),S(_0x14ff57));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x14ff57+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1d81e4+')');}function Rh(_0x56f2fe,_0x5068a5){const _0x5cb45d=Mt(_0x56f2fe,0x0),_0xcee885=Mt(_0x5068a5,0x0);for(let _0x5d3cba=0x0;_0x5d3cba<_0x5cb45d['length']&&_0x5d3cba<_0xcee885['length'];_0x5d3cba++){const _0x263c93=qe(_0x5cb45d[_0x5d3cba],_0xcee885[_0x5d3cba]);if(_0x263c93!==0x0)return _0x263c93;}return _0x5cb45d['length']===_0xcee885['length']?0x0:_0x5cb45d['length']<_0xcee885['length']?-0x1:0x1;}function Ki(_0x20eca5,_0x395972){if(Ce(_0x20eca5)!==Ce(_0x395972))return!0x1;for(let _0x168f4b=_0x20eca5['pieceNum_'],_0x43acbd=_0x395972['pieceNum_'];_0x168f4b<=_0x20eca5['pieces_']['length'];_0x168f4b++,_0x43acbd++)if(_0x20eca5['pieces_'][_0x168f4b]!==_0x395972['pieces_'][_0x43acbd])return!0x1;return!0x0;}function G(_0x4ce31e,_0xab898b){let _0x537387=_0x4ce31e['pieceNum_'],_0x9a99cb=_0xab898b['pieceNum_'];if(Ce(_0x4ce31e)>Ce(_0xab898b))return!0x1;for(;_0x537387<_0x4ce31e['pieces_']['length'];){if(_0x4ce31e['pieces_'][_0x537387]!==_0xab898b['pieces_'][_0x9a99cb])return!0x1;++_0x537387,++_0x9a99cb;}return!0x0;}class Ah{constructor(_0x246024,_0x4ba04d){this['errorPrefix_']=_0x4ba04d,this['parts_']=Mt(_0x246024,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x60ccfc=0x0;_0x60ccfc<this['parts_']['length'];_0x60ccfc++)this['byteLength_']+=Ln(this['parts_'][_0x60ccfc]);Ao(this);}}function kh(_0x5c1ffc,_0x50e740){_0x5c1ffc['parts_']['length']>0x0&&(_0x5c1ffc['byteLength_']+=0x1),_0x5c1ffc['parts_']['push'](_0x50e740),_0x5c1ffc['byteLength_']+=Ln(_0x50e740),Ao(_0x5c1ffc);}function Ph(_0x2f7ee6){const _0x192fd7=_0x2f7ee6['parts_']['pop']();_0x2f7ee6['byteLength_']-=Ln(_0x192fd7),_0x2f7ee6['parts_']['length']>0x0&&(_0x2f7ee6['byteLength_']-=0x1);}function Ao(_0x22ecbb){if(_0x22ecbb['byteLength_']>Zs)throw new Error(_0x22ecbb['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x22ecbb['byteLength_']+').');if(_0x22ecbb['parts_']['length']>Xs)throw new Error(_0x22ecbb['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x22ecbb));}function Oe(_0x1823d0){return _0x1823d0['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1823d0['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x4be59e,_0x3b0b62;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3b0b62='visibilitychange',_0x4be59e='hidden'):typeof document['mozHidden']<'u'?(_0x3b0b62='mozvisibilitychange',_0x4be59e='mozHidden'):typeof document['msHidden']<'u'?(_0x3b0b62='msvisibilitychange',_0x4be59e='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3b0b62='webkitvisibilitychange',_0x4be59e='webkitHidden')),this['visible_']=!0x0,_0x3b0b62&&document['addEventListener'](_0x3b0b62,()=>{const _0x5c4b44=!document[_0x4be59e];_0x5c4b44!==this['visible_']&&(this['visible_']=_0x5c4b44,this['trigger']('visible',_0x5c4b44));},!0x1);}['getInitialEvent'](_0x35577c){return f(_0x35577c==='visible','Unknown\x20event\x20type:\x20'+_0x35577c),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x5aad27,_0x57f4a8,_0x1e0dc2,_0x603fc3,_0x276bdd,_0x53b650,_0x480d31,_0x11682a){if(super(),this['repoInfo_']=_0x5aad27,this['applicationId_']=_0x57f4a8,this['onDataUpdate_']=_0x1e0dc2,this['onConnectStatus_']=_0x603fc3,this['onServerInfoUpdate_']=_0x276bdd,this['authTokenProvider_']=_0x53b650,this['appCheckTokenProvider_']=_0x480d31,this['authOverride_']=_0x11682a,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x11682a)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5aad27['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x159887,_0x2ad778,_0x2a192e){const _0x1353f5=++this['requestNumber_'],_0x5c8a52={'r':_0x1353f5,'a':_0x159887,'b':_0x2ad778};this['log_'](O(_0x5c8a52)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5c8a52),_0x2a192e&&(this['requestCBHash_'][_0x1353f5]=_0x2a192e);}['get'](_0x35a8cd){this['initConnection_']();const _0x412291=new H(),_0x209b2d={'action':'g','request':{'p':_0x35a8cd['_path']['toString'](),'q':_0x35a8cd['_queryObject']},'onComplete':_0x2be820=>{const _0x3a70f8=_0x2be820['d'];_0x2be820['s']==='ok'?_0x412291['resolve'](_0x3a70f8):_0x412291['reject'](_0x3a70f8);}};this['outstandingGets_']['push'](_0x209b2d),this['outstandingGetCount_']++;const _0x5adc1a=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5adc1a),_0x412291['promise'];}['listen'](_0x393d2d,_0x4031e3,_0xe79fc5,_0x1f1a47){this['initConnection_']();const _0xa87a2d=_0x393d2d['_queryIdentifier'],_0x4d5cee=_0x393d2d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4d5cee+'\x20'+_0xa87a2d),this['listens']['has'](_0x4d5cee)||this['listens']['set'](_0x4d5cee,new Map()),f(_0x393d2d['_queryParams']['isDefault']()||!_0x393d2d['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4d5cee)['has'](_0xa87a2d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x725249={'onComplete':_0x1f1a47,'hashFn':_0x4031e3,'query':_0x393d2d,'tag':_0xe79fc5};this['listens']['get'](_0x4d5cee)['set'](_0xa87a2d,_0x725249),this['connected_']&&this['sendListen_'](_0x725249);}['sendGet_'](_0x4a07e3){const _0x44ec1a=this['outstandingGets_'][_0x4a07e3];this['sendRequest']('g',_0x44ec1a['request'],_0x117872=>{delete this['outstandingGets_'][_0x4a07e3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x44ec1a['onComplete']&&_0x44ec1a['onComplete'](_0x117872);});}['sendListen_'](_0x2ba2f6){const _0x1fd999=_0x2ba2f6['query'],_0x35bd10=_0x1fd999['_path']['toString'](),_0x276a15=_0x1fd999['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x35bd10+'\x20for\x20'+_0x276a15);const _0x403721={'p':_0x35bd10},_0x32255a='q';_0x2ba2f6['tag']&&(_0x403721['q']=_0x1fd999['_queryObject'],_0x403721['t']=_0x2ba2f6['tag']),_0x403721['h']=_0x2ba2f6['hashFn'](),this['sendRequest'](_0x32255a,_0x403721,_0x5d2de2=>{const _0x306a2c=_0x5d2de2['d'],_0x35aed5=_0x5d2de2['s'];se['warnOnListenWarnings_'](_0x306a2c,_0x1fd999),(this['listens']['get'](_0x35bd10)&&this['listens']['get'](_0x35bd10)['get'](_0x276a15))===_0x2ba2f6&&(this['log_']('listen\x20response',_0x5d2de2),_0x35aed5!=='ok'&&this['removeListen_'](_0x35bd10,_0x276a15),_0x2ba2f6['onComplete']&&_0x2ba2f6['onComplete'](_0x35aed5,_0x306a2c));});}static['warnOnListenWarnings_'](_0x315d3b,_0x378cc1){if(_0x315d3b&&typeof _0x315d3b=='object'&&Q(_0x315d3b,'w')){const _0x53d8a1=Le(_0x315d3b,'w');if(Array['isArray'](_0x53d8a1)&&~_0x53d8a1['indexOf']('no_index')){const _0x24a878='\x22.indexOn\x22:\x20\x22'+_0x378cc1['_queryParams']['getIndex']()['toString']()+'\x22',_0x4291a4=_0x378cc1['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x24a878+'\x20at\x20'+_0x4291a4+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x252a34){this['authToken_']=_0x252a34,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x252a34);}['reduceReconnectDelayIfAdminCredential_'](_0x144c86){(_0x144c86&&_0x144c86['length']===0x28||wc(_0x144c86))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x346362){this['appCheckToken_']=_0x346362,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x20e417=this['authToken_'],_0x12ddc4=Ic(_0x20e417)?'auth':'gauth',_0x40268d={'cred':_0x20e417};this['authOverride_']===null?_0x40268d['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x40268d['authvar']=this['authOverride_']),this['sendRequest'](_0x12ddc4,_0x40268d,_0x3770ee=>{const _0x453bd7=_0x3770ee['s'],_0x201355=_0x3770ee['d']||'error';this['authToken_']===_0x20e417&&(_0x453bd7==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x453bd7,_0x201355));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2305aa=>{const _0x8de3ae=_0x2305aa['s'],_0x3ad40d=_0x2305aa['d']||'error';_0x8de3ae==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x8de3ae,_0x3ad40d);});}['unlisten'](_0x19279c,_0x5b54cd){const _0x164fb8=_0x19279c['_path']['toString'](),_0x5de116=_0x19279c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x164fb8+'\x20'+_0x5de116),f(_0x19279c['_queryParams']['isDefault']()||!_0x19279c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x164fb8,_0x5de116)&&this['connected_']&&this['sendUnlisten_'](_0x164fb8,_0x5de116,_0x19279c['_queryObject'],_0x5b54cd);}['sendUnlisten_'](_0x18157e,_0x15756c,_0x44f1a2,_0xd0faf9){this['log_']('Unlisten\x20on\x20'+_0x18157e+'\x20for\x20'+_0x15756c);const _0x559577={'p':_0x18157e},_0x526841='n';_0xd0faf9&&(_0x559577['q']=_0x44f1a2,_0x559577['t']=_0xd0faf9),this['sendRequest'](_0x526841,_0x559577);}['onDisconnectPut'](_0x35a470,_0x2924a8,_0x4f8ed9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x35a470,_0x2924a8,_0x4f8ed9):this['onDisconnectRequestQueue_']['push']({'pathString':_0x35a470,'action':'o','data':_0x2924a8,'onComplete':_0x4f8ed9});}['onDisconnectMerge'](_0x195193,_0x39a10d,_0x565a52){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x195193,_0x39a10d,_0x565a52):this['onDisconnectRequestQueue_']['push']({'pathString':_0x195193,'action':'om','data':_0x39a10d,'onComplete':_0x565a52});}['onDisconnectCancel'](_0x52803a,_0x1830ae){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x52803a,null,_0x1830ae):this['onDisconnectRequestQueue_']['push']({'pathString':_0x52803a,'action':'oc','data':null,'onComplete':_0x1830ae});}['sendOnDisconnect_'](_0x198534,_0x27b09d,_0x4c2fc9,_0x352cdb){const _0x512a83={'p':_0x27b09d,'d':_0x4c2fc9};this['log_']('onDisconnect\x20'+_0x198534,_0x512a83),this['sendRequest'](_0x198534,_0x512a83,_0x5b55ac=>{_0x352cdb&&setTimeout(()=>{_0x352cdb(_0x5b55ac['s'],_0x5b55ac['d']);},Math['floor'](0x0));});}['put'](_0x4717f5,_0x58e2b1,_0x39bfcb,_0x1c5dc8){this['putInternal']('p',_0x4717f5,_0x58e2b1,_0x39bfcb,_0x1c5dc8);}['merge'](_0x570b59,_0x48dc8a,_0x54b771,_0x1da311){this['putInternal']('m',_0x570b59,_0x48dc8a,_0x54b771,_0x1da311);}['putInternal'](_0x149d85,_0xe6cb01,_0x10f784,_0x3bd243,_0x1b899a){this['initConnection_']();const _0x472928={'p':_0xe6cb01,'d':_0x10f784};_0x1b899a!==void 0x0&&(_0x472928['h']=_0x1b899a),this['outstandingPuts_']['push']({'action':_0x149d85,'request':_0x472928,'onComplete':_0x3bd243}),this['outstandingPutCount_']++;const _0x35a41e=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x35a41e):this['log_']('Buffering\x20put:\x20'+_0xe6cb01);}['sendPut_'](_0x1a2be9){const _0x1fc107=this['outstandingPuts_'][_0x1a2be9]['action'],_0x3c2f0a=this['outstandingPuts_'][_0x1a2be9]['request'],_0x348c37=this['outstandingPuts_'][_0x1a2be9]['onComplete'];this['outstandingPuts_'][_0x1a2be9]['queued']=this['connected_'],this['sendRequest'](_0x1fc107,_0x3c2f0a,_0x7b5cd3=>{this['log_'](_0x1fc107+'\x20response',_0x7b5cd3),delete this['outstandingPuts_'][_0x1a2be9],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x348c37&&_0x348c37(_0x7b5cd3['s'],_0x7b5cd3['d']);});}['reportStats'](_0x380fee){if(this['connected_']){const _0x4adf5f={'c':_0x380fee};this['log_']('reportStats',_0x4adf5f),this['sendRequest']('s',_0x4adf5f,_0x17a11e=>{if(_0x17a11e['s']!=='ok'){const _0x1aff80=_0x17a11e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x1aff80);}});}}['onDataMessage_'](_0x56f0c3){if('r'in _0x56f0c3){this['log_']('from\x20server:\x20'+O(_0x56f0c3));const _0x51fd74=_0x56f0c3['r'],_0x47951b=this['requestCBHash_'][_0x51fd74];_0x47951b&&(delete this['requestCBHash_'][_0x51fd74],_0x47951b(_0x56f0c3['b']));}else{if('error'in _0x56f0c3)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x56f0c3['error'];'a'in _0x56f0c3&&this['onDataPush_'](_0x56f0c3['a'],_0x56f0c3['b']);}}['onDataPush_'](_0x56115c,_0x436ec7){this['log_']('handleServerMessage',_0x56115c,_0x436ec7),_0x56115c==='d'?this['onDataUpdate_'](_0x436ec7['p'],_0x436ec7['d'],!0x1,_0x436ec7['t']):_0x56115c==='m'?this['onDataUpdate_'](_0x436ec7['p'],_0x436ec7['d'],!0x0,_0x436ec7['t']):_0x56115c==='c'?this['onListenRevoked_'](_0x436ec7['p'],_0x436ec7['q']):_0x56115c==='ac'?this['onAuthRevoked_'](_0x436ec7['s'],_0x436ec7['d']):_0x56115c==='apc'?this['onAppCheckRevoked_'](_0x436ec7['s'],_0x436ec7['d']):_0x56115c==='sd'?this['onSecurityDebugPacket_'](_0x436ec7):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x56115c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x530dde,_0x13fb76){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x530dde),this['lastSessionId']=_0x13fb76,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xdff277){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xdff277));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x479dfa){_0x479dfa&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x479dfa;}['onOnline_'](_0x3f6558){_0x3f6558?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x58a1b5=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x29c509=Math['max'](0x0,this['reconnectDelay_']-_0x58a1b5);_0x29c509=Math['random']()*_0x29c509,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x29c509+'ms'),this['scheduleConnect_'](_0x29c509),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3d8f21=this['onDataMessage_']['bind'](this),_0x516630=this['onReady_']['bind'](this),_0x1e7836=this['onRealtimeDisconnect_']['bind'](this),_0x31852e=this['id']+':'+se['nextConnectionId_']++,_0x177054=this['lastSessionId'];let _0x3720e9=!0x1,_0xe13669=null;const _0x3dfb6f=function(){_0xe13669?_0xe13669['close']():(_0x3720e9=!0x0,_0x1e7836());},_0x1da4f8=function(_0x57bd1c){f(_0xe13669,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xe13669['sendRequest'](_0x57bd1c);};this['realtime_']={'close':_0x3dfb6f,'sendRequest':_0x1da4f8};const _0x14495c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x102008,_0x5304ef]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x14495c),this['appCheckTokenProvider_']['getToken'](_0x14495c)]);_0x3720e9?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x102008&&_0x102008['accessToken'],this['appCheckToken_']=_0x5304ef&&_0x5304ef['token'],_0xe13669=new Sh(_0x31852e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3d8f21,_0x516630,_0x1e7836,_0x21ef07=>{U(_0x21ef07+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x177054));}catch(_0x7f3fe9){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x7f3fe9),_0x3720e9||(this['repoInfo_']['nodeAdmin']&&U(_0x7f3fe9),_0x3dfb6f());}}}['interrupt'](_0x548011){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x548011),this['interruptReasons_'][_0x548011]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x164e47){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x164e47),delete this['interruptReasons_'][_0x164e47],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2a4ae5){const _0x676b2a=_0x2a4ae5-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x676b2a});}['cancelSentTransactions_'](){for(let _0x405211=0x0;_0x405211<this['outstandingPuts_']['length'];_0x405211++){const _0x40991f=this['outstandingPuts_'][_0x405211];_0x40991f&&'h'in _0x40991f['request']&&_0x40991f['queued']&&(_0x40991f['onComplete']&&_0x40991f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x405211],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x384854,_0x1cee65){let _0x7e72bd;_0x1cee65?_0x7e72bd=_0x1cee65['map'](_0x31cf00=>$i(_0x31cf00))['join']('$'):_0x7e72bd='default';const _0x1ab6aa=this['removeListen_'](_0x384854,_0x7e72bd);_0x1ab6aa&&_0x1ab6aa['onComplete']&&_0x1ab6aa['onComplete']('permission_denied');}['removeListen_'](_0x41d702,_0x12bb4d){const _0x290d0e=new C(_0x41d702)['toString']();let _0x148ca5;if(this['listens']['has'](_0x290d0e)){const _0x198c46=this['listens']['get'](_0x290d0e);_0x148ca5=_0x198c46['get'](_0x12bb4d),_0x198c46['delete'](_0x12bb4d),_0x198c46['size']===0x0&&this['listens']['delete'](_0x290d0e);}else _0x148ca5=void 0x0;return _0x148ca5;}['onAuthRevoked_'](_0x3e8200,_0x1fdc39){L('Auth\x20token\x20revoked:\x20'+_0x3e8200+'/'+_0x1fdc39),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3e8200==='invalid_token'||_0x3e8200==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x251119,_0x2c5cd1){L('App\x20check\x20token\x20revoked:\x20'+_0x251119+'/'+_0x2c5cd1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x251119==='invalid_token'||_0x251119==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x42186b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x42186b):'msg'in _0x42186b&&console['log']('FIREBASE:\x20'+_0x42186b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xc3f3b6 of this['listens']['values']())for(const _0x47ca35 of _0xc3f3b6['values']())this['sendListen_'](_0x47ca35);for(let _0x1ed985=0x0;_0x1ed985<this['outstandingPuts_']['length'];_0x1ed985++)this['outstandingPuts_'][_0x1ed985]&&this['sendPut_'](_0x1ed985);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3f1585=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3f1585['action'],_0x3f1585['pathString'],_0x3f1585['data'],_0x3f1585['onComplete']);}for(let _0x44cb42=0x0;_0x44cb42<this['outstandingGets_']['length'];_0x44cb42++)this['outstandingGets_'][_0x44cb42]&&this['sendGet_'](_0x44cb42);}['sendConnectStats_'](){const _0x1abd19={};let _0x34ebf1='js';_0x1abd19['sdk.'+_0x34ebf1+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x1abd19['framework.cordova']=0x1:Kr()&&(_0x1abd19['framework.reactnative']=0x1),this['reportStats'](_0x1abd19);}['shouldReconnect_'](){const _0x33f5ef=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x33f5ef;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3446ae,_0x594d79){this['name']=_0x3446ae,this['node']=_0x594d79;}static['Wrap'](_0x5efbbe,_0x33168b){return new E(_0x5efbbe,_0x33168b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5ad21e,_0x57d661){const _0x337733=new E(We,_0x5ad21e),_0x2f3b3c=new E(We,_0x57d661);return this['compare'](_0x337733,_0x2f3b3c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2594a9){sn=_0x2594a9;}['compare'](_0x194145,_0x4df270){return qe(_0x194145['name'],_0x4df270['name']);}['isDefinedOn'](_0xe4113a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3baf92,_0x5919dd){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x303495,_0x4fa2a5){return f(typeof _0x303495=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x303495,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3e1c02,_0x5ae60e,_0x49c052,_0x26cc87,_0x381893=null){this['isReverse_']=_0x26cc87,this['resultGenerator_']=_0x381893,this['nodeStack_']=[];let _0x4ad489=0x1;for(;!_0x3e1c02['isEmpty']();)if(_0x3e1c02=_0x3e1c02,_0x4ad489=_0x5ae60e?_0x49c052(_0x3e1c02['key'],_0x5ae60e):0x1,_0x26cc87&&(_0x4ad489*=-0x1),_0x4ad489<0x0)this['isReverse_']?_0x3e1c02=_0x3e1c02['left']:_0x3e1c02=_0x3e1c02['right'];else{if(_0x4ad489===0x0){this['nodeStack_']['push'](_0x3e1c02);break;}else this['nodeStack_']['push'](_0x3e1c02),this['isReverse_']?_0x3e1c02=_0x3e1c02['right']:_0x3e1c02=_0x3e1c02['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x448005=this['nodeStack_']['pop'](),_0x280e61;if(this['resultGenerator_']?_0x280e61=this['resultGenerator_'](_0x448005['key'],_0x448005['value']):_0x280e61={'key':_0x448005['key'],'value':_0x448005['value']},this['isReverse_']){for(_0x448005=_0x448005['left'];!_0x448005['isEmpty']();)this['nodeStack_']['push'](_0x448005),_0x448005=_0x448005['right'];}else{for(_0x448005=_0x448005['right'];!_0x448005['isEmpty']();)this['nodeStack_']['push'](_0x448005),_0x448005=_0x448005['left'];}return _0x280e61;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1eeece=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1eeece['key'],_0x1eeece['value']):{'key':_0x1eeece['key'],'value':_0x1eeece['value']};}}class M{constructor(_0x4ae26d,_0x4a24ad,_0x53fcc8,_0x4beede,_0x1f306e){this['key']=_0x4ae26d,this['value']=_0x4a24ad,this['color']=_0x53fcc8??M['RED'],this['left']=_0x4beede??B['EMPTY_NODE'],this['right']=_0x1f306e??B['EMPTY_NODE'];}['copy'](_0x74cb00,_0x18a710,_0x462fac,_0x508f31,_0x11f814){return new M(_0x74cb00??this['key'],_0x18a710??this['value'],_0x462fac??this['color'],_0x508f31??this['left'],_0x11f814??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x310ab5){return this['left']['inorderTraversal'](_0x310ab5)||!!_0x310ab5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x310ab5);}['reverseTraversal'](_0x532f80){return this['right']['reverseTraversal'](_0x532f80)||_0x532f80(this['key'],this['value'])||this['left']['reverseTraversal'](_0x532f80);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x531d4e,_0x1f7ca4,_0x769922){let _0x546f27=this;const _0xb46a51=_0x769922(_0x531d4e,_0x546f27['key']);return _0xb46a51<0x0?_0x546f27=_0x546f27['copy'](null,null,null,_0x546f27['left']['insert'](_0x531d4e,_0x1f7ca4,_0x769922),null):_0xb46a51===0x0?_0x546f27=_0x546f27['copy'](null,_0x1f7ca4,null,null,null):_0x546f27=_0x546f27['copy'](null,null,null,null,_0x546f27['right']['insert'](_0x531d4e,_0x1f7ca4,_0x769922)),_0x546f27['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x25fa35=this;return!_0x25fa35['left']['isRed_']()&&!_0x25fa35['left']['left']['isRed_']()&&(_0x25fa35=_0x25fa35['moveRedLeft_']()),_0x25fa35=_0x25fa35['copy'](null,null,null,_0x25fa35['left']['removeMin_'](),null),_0x25fa35['fixUp_']();}['remove'](_0x197fe0,_0x12dd72){let _0x5c9c5e,_0x2dd58a;if(_0x5c9c5e=this,_0x12dd72(_0x197fe0,_0x5c9c5e['key'])<0x0)!_0x5c9c5e['left']['isEmpty']()&&!_0x5c9c5e['left']['isRed_']()&&!_0x5c9c5e['left']['left']['isRed_']()&&(_0x5c9c5e=_0x5c9c5e['moveRedLeft_']()),_0x5c9c5e=_0x5c9c5e['copy'](null,null,null,_0x5c9c5e['left']['remove'](_0x197fe0,_0x12dd72),null);else{if(_0x5c9c5e['left']['isRed_']()&&(_0x5c9c5e=_0x5c9c5e['rotateRight_']()),!_0x5c9c5e['right']['isEmpty']()&&!_0x5c9c5e['right']['isRed_']()&&!_0x5c9c5e['right']['left']['isRed_']()&&(_0x5c9c5e=_0x5c9c5e['moveRedRight_']()),_0x12dd72(_0x197fe0,_0x5c9c5e['key'])===0x0){if(_0x5c9c5e['right']['isEmpty']())return B['EMPTY_NODE'];_0x2dd58a=_0x5c9c5e['right']['min_'](),_0x5c9c5e=_0x5c9c5e['copy'](_0x2dd58a['key'],_0x2dd58a['value'],null,null,_0x5c9c5e['right']['removeMin_']());}_0x5c9c5e=_0x5c9c5e['copy'](null,null,null,null,_0x5c9c5e['right']['remove'](_0x197fe0,_0x12dd72));}return _0x5c9c5e['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2ec9db=this;return _0x2ec9db['right']['isRed_']()&&!_0x2ec9db['left']['isRed_']()&&(_0x2ec9db=_0x2ec9db['rotateLeft_']()),_0x2ec9db['left']['isRed_']()&&_0x2ec9db['left']['left']['isRed_']()&&(_0x2ec9db=_0x2ec9db['rotateRight_']()),_0x2ec9db['left']['isRed_']()&&_0x2ec9db['right']['isRed_']()&&(_0x2ec9db=_0x2ec9db['colorFlip_']()),_0x2ec9db;}['moveRedLeft_'](){let _0x343352=this['colorFlip_']();return _0x343352['right']['left']['isRed_']()&&(_0x343352=_0x343352['copy'](null,null,null,null,_0x343352['right']['rotateRight_']()),_0x343352=_0x343352['rotateLeft_'](),_0x343352=_0x343352['colorFlip_']()),_0x343352;}['moveRedRight_'](){let _0x2a0338=this['colorFlip_']();return _0x2a0338['left']['left']['isRed_']()&&(_0x2a0338=_0x2a0338['rotateRight_'](),_0x2a0338=_0x2a0338['colorFlip_']()),_0x2a0338;}['rotateLeft_'](){const _0x3473bb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3473bb,null);}['rotateRight_'](){const _0x2574ae=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2574ae);}['colorFlip_'](){const _0x86c34a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x441363=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x86c34a,_0x441363);}['checkMaxDepth_'](){const _0xfa9c05=this['check_']();return Math['pow'](0x2,_0xfa9c05)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2ed924=this['left']['check_']();if(_0x2ed924!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2ed924+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5d195f,_0x56974b,_0x4b042b,_0x43625c,_0x2a6789){return this;}['insert'](_0x526f43,_0x16ecc9,_0x351143){return new M(_0x526f43,_0x16ecc9,null);}['remove'](_0x24baf4,_0x196bb1){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x12e8fe){return!0x1;}['reverseTraversal'](_0x436b45){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x555bca,_0x81154e=B['EMPTY_NODE']){this['comparator_']=_0x555bca,this['root_']=_0x81154e;}['insert'](_0x847803,_0x5ee4e3){return new B(this['comparator_'],this['root_']['insert'](_0x847803,_0x5ee4e3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4331b1){return new B(this['comparator_'],this['root_']['remove'](_0x4331b1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x416089){let _0x49c3c4,_0x1b70f1=this['root_'];for(;!_0x1b70f1['isEmpty']();){if(_0x49c3c4=this['comparator_'](_0x416089,_0x1b70f1['key']),_0x49c3c4===0x0)return _0x1b70f1['value'];_0x49c3c4<0x0?_0x1b70f1=_0x1b70f1['left']:_0x49c3c4>0x0&&(_0x1b70f1=_0x1b70f1['right']);}return null;}['getPredecessorKey'](_0x3ecac0){let _0x2b6958,_0x378734=this['root_'],_0x1d38e8=null;for(;!_0x378734['isEmpty']();)if(_0x2b6958=this['comparator_'](_0x3ecac0,_0x378734['key']),_0x2b6958===0x0){if(_0x378734['left']['isEmpty']())return _0x1d38e8?_0x1d38e8['key']:null;for(_0x378734=_0x378734['left'];!_0x378734['right']['isEmpty']();)_0x378734=_0x378734['right'];return _0x378734['key'];}else _0x2b6958<0x0?_0x378734=_0x378734['left']:_0x2b6958>0x0&&(_0x1d38e8=_0x378734,_0x378734=_0x378734['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5c682a){return this['root_']['inorderTraversal'](_0x5c682a);}['reverseTraversal'](_0xbdbee9){return this['root_']['reverseTraversal'](_0xbdbee9);}['getIterator'](_0x3f6c2f){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x3f6c2f);}['getIteratorFrom'](_0x46c1e6,_0x195eed){return new rn(this['root_'],_0x46c1e6,this['comparator_'],!0x1,_0x195eed);}['getReverseIteratorFrom'](_0x493965,_0x2b5274){return new rn(this['root_'],_0x493965,this['comparator_'],!0x0,_0x2b5274);}['getReverseIterator'](_0x245589){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x245589);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x289d91,_0x2899b6){return qe(_0x289d91['name'],_0x2899b6['name']);}function Qi(_0xd4f91c,_0x7fe0af){return qe(_0xd4f91c,_0x7fe0af);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x42efc9){Ci=_0x42efc9;}const Po=function(_0x39f914){return typeof _0x39f914=='number'?'number:'+ao(_0x39f914):'string:'+_0x39f914;},No=function(_0x5603e7){if(_0x5603e7['isLeafNode']()){const _0x4374a4=_0x5603e7['val']();f(typeof _0x4374a4=='string'||typeof _0x4374a4=='number'||typeof _0x4374a4=='object'&&Q(_0x4374a4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5603e7===Ci||_0x5603e7['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5603e7===Ci||_0x5603e7['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x24a395){nr=_0x24a395;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x11ff22,_0x2aeb92=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x11ff22,this['priorityNode_']=_0x2aeb92,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x471288){return new D(this['value_'],_0x471288);}['getImmediateChild'](_0x4c4ae5){return _0x4c4ae5==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3e068c){return v(_0x3e068c)?this:y(_0x3e068c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x23b3bd,_0x10cd92){return null;}['updateImmediateChild'](_0x32f6fe,_0x1c2a38){return _0x32f6fe==='.priority'?this['updatePriority'](_0x1c2a38):_0x1c2a38['isEmpty']()&&_0x32f6fe!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x32f6fe,_0x1c2a38)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x206230,_0x151cbb){const _0x4fd4c9=y(_0x206230);return _0x4fd4c9===null?_0x151cbb:_0x151cbb['isEmpty']()&&_0x4fd4c9!=='.priority'?this:(f(_0x4fd4c9!=='.priority'||Ce(_0x206230)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4fd4c9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x206230),_0x151cbb)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3f9a5a,_0x3483d0){return!0x1;}['val'](_0x4beae3){return _0x4beae3&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3a917d='';this['priorityNode_']['isEmpty']()||(_0x3a917d+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3eef5a=typeof this['value_'];_0x3a917d+=_0x3eef5a+':',_0x3eef5a==='number'?_0x3a917d+=ao(this['value_']):_0x3a917d+=this['value_'],this['lazyHash_']=ro(_0x3a917d);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3f82be){return _0x3f82be===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3f82be instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3f82be['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3f82be));}['compareToLeafNode_'](_0x52f3e2){const _0x437ace=typeof _0x52f3e2['value_'],_0x441502=typeof this['value_'],_0x303377=D['VALUE_TYPE_ORDER']['indexOf'](_0x437ace),_0x2c892c=D['VALUE_TYPE_ORDER']['indexOf'](_0x441502);return f(_0x303377>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x437ace),f(_0x2c892c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x441502),_0x303377===_0x2c892c?_0x441502==='object'?0x0:this['value_']<_0x52f3e2['value_']?-0x1:this['value_']===_0x52f3e2['value_']?0x0:0x1:_0x2c892c-_0x303377;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x51c7c4){if(_0x51c7c4===this)return!0x0;if(_0x51c7c4['isLeafNode']()){const _0x200486=_0x51c7c4;return this['value_']===_0x200486['value_']&&this['priorityNode_']['equals'](_0x200486['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x132937){Oo=_0x132937;}function Wh(_0x317684){Do=_0x317684;}class Bh extends Fn{['compare'](_0x358705,_0x18e3c1){const _0x2ede3f=_0x358705['node']['getPriority'](),_0xad1316=_0x18e3c1['node']['getPriority'](),_0x349d20=_0x2ede3f['compareTo'](_0xad1316);return _0x349d20===0x0?qe(_0x358705['name'],_0x18e3c1['name']):_0x349d20;}['isDefinedOn'](_0x25e097){return!_0x25e097['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xfe5a21,_0x16561f){return!_0xfe5a21['getPriority']()['equals'](_0x16561f['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x391de9,_0x458855){const _0x5e5667=Oo(_0x391de9);return new E(_0x458855,new D('[PRIORITY-POST]',_0x5e5667));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x170c79){const _0x30e8b7=_0x4ab065=>parseInt(Math['log'](_0x4ab065)/Vh,0xa),_0xb6efdb=_0xf22e9c=>parseInt(Array(_0xf22e9c+0x1)['join']('1'),0x2);this['count']=_0x30e8b7(_0x170c79+0x1),this['current_']=this['count']-0x1;const _0x200065=_0xb6efdb(this['count']);this['bits_']=_0x170c79+0x1&_0x200065;}['nextBitIsOne'](){const _0x516b2d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x516b2d;}}const yn=function(_0x26ea78,_0x4234d7,_0xdc7610,_0x2f9cca){_0x26ea78['sort'](_0x4234d7);const _0x4658c9=function(_0x8dab60,_0x4677d0){const _0x1c094e=_0x4677d0-_0x8dab60;let _0x538a0d,_0x5730c0;if(_0x1c094e===0x0)return null;if(_0x1c094e===0x1)return _0x538a0d=_0x26ea78[_0x8dab60],_0x5730c0=_0xdc7610?_0xdc7610(_0x538a0d):_0x538a0d,new M(_0x5730c0,_0x538a0d['node'],M['BLACK'],null,null);{const _0x695a2f=parseInt(_0x1c094e/0x2,0xa)+_0x8dab60,_0x317cdb=_0x4658c9(_0x8dab60,_0x695a2f),_0x4d20e5=_0x4658c9(_0x695a2f+0x1,_0x4677d0);return _0x538a0d=_0x26ea78[_0x695a2f],_0x5730c0=_0xdc7610?_0xdc7610(_0x538a0d):_0x538a0d,new M(_0x5730c0,_0x538a0d['node'],M['BLACK'],_0x317cdb,_0x4d20e5);}},_0x5abd58=function(_0x9ddd4d){let _0x5e327f=null,_0xbdee52=null,_0xaafa31=_0x26ea78['length'];const _0x226022=function(_0x529e9f,_0x1fcfe7){const _0x186300=_0xaafa31-_0x529e9f,_0x4fd411=_0xaafa31;_0xaafa31-=_0x529e9f;const _0x44e2a0=_0x4658c9(_0x186300+0x1,_0x4fd411),_0xcaa776=_0x26ea78[_0x186300],_0xa101ff=_0xdc7610?_0xdc7610(_0xcaa776):_0xcaa776;_0x105c15(new M(_0xa101ff,_0xcaa776['node'],_0x1fcfe7,null,_0x44e2a0));},_0x105c15=function(_0x2573b7){_0x5e327f?(_0x5e327f['left']=_0x2573b7,_0x5e327f=_0x2573b7):(_0xbdee52=_0x2573b7,_0x5e327f=_0x2573b7);};for(let _0x5508a5=0x0;_0x5508a5<_0x9ddd4d['count'];++_0x5508a5){const _0x40ada9=_0x9ddd4d['nextBitIsOne'](),_0x2c0c27=Math['pow'](0x2,_0x9ddd4d['count']-(_0x5508a5+0x1));_0x40ada9?_0x226022(_0x2c0c27,M['BLACK']):(_0x226022(_0x2c0c27,M['BLACK']),_0x226022(_0x2c0c27,M['RED']));}return _0xbdee52;},_0x468544=new Hh(_0x26ea78['length']),_0x2c10e0=_0x5abd58(_0x468544);return new B(_0x2f9cca||_0x4234d7,_0x2c10e0);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x15c19a,_0x3b51db){this['indexes_']=_0x15c19a,this['indexSet_']=_0x3b51db;}['get'](_0x37a7a3){const _0x1e6a7d=Le(this['indexes_'],_0x37a7a3);if(!_0x1e6a7d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x37a7a3);return _0x1e6a7d instanceof B?_0x1e6a7d:null;}['hasIndex'](_0x22a577){return Q(this['indexSet_'],_0x22a577['toString']());}['addIndex'](_0x57a907,_0x26e3fa){f(_0x57a907!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2578cd=[];let _0x6e4f65=!0x1;const _0x379184=_0x26e3fa['getIterator'](E['Wrap']);let _0x5993a1=_0x379184['getNext']();for(;_0x5993a1;)_0x6e4f65=_0x6e4f65||_0x57a907['isDefinedOn'](_0x5993a1['node']),_0x2578cd['push'](_0x5993a1),_0x5993a1=_0x379184['getNext']();let _0x463ee6;_0x6e4f65?_0x463ee6=yn(_0x2578cd,_0x57a907['getCompare']()):_0x463ee6=Qe;const _0x225f3e=_0x57a907['toString'](),_0x562356={...this['indexSet_']};_0x562356[_0x225f3e]=_0x57a907;const _0x4a9f94={...this['indexes_']};return _0x4a9f94[_0x225f3e]=_0x463ee6,new te(_0x4a9f94,_0x562356);}['addToIndexes'](_0x442117,_0x111588){const _0x16ad52=_n(this['indexes_'],(_0x7790af,_0x755a67)=>{const _0x463402=Le(this['indexSet_'],_0x755a67);if(f(_0x463402,'Missing\x20index\x20implementation\x20for\x20'+_0x755a67),_0x7790af===Qe){if(_0x463402['isDefinedOn'](_0x442117['node'])){const _0x144d32=[],_0x53da7a=_0x111588['getIterator'](E['Wrap']);let _0x10af8f=_0x53da7a['getNext']();for(;_0x10af8f;)_0x10af8f['name']!==_0x442117['name']&&_0x144d32['push'](_0x10af8f),_0x10af8f=_0x53da7a['getNext']();return _0x144d32['push'](_0x442117),yn(_0x144d32,_0x463402['getCompare']());}else return Qe;}else{const _0xe08305=_0x111588['get'](_0x442117['name']);let _0x209ca2=_0x7790af;return _0xe08305&&(_0x209ca2=_0x209ca2['remove'](new E(_0x442117['name'],_0xe08305))),_0x209ca2['insert'](_0x442117,_0x442117['node']);}});return new te(_0x16ad52,this['indexSet_']);}['removeFromIndexes'](_0x5c38c7,_0x1573e1){const _0x56a140=_n(this['indexes_'],_0x32e804=>{if(_0x32e804===Qe)return _0x32e804;{const _0x492451=_0x1573e1['get'](_0x5c38c7['name']);return _0x492451?_0x32e804['remove'](new E(_0x5c38c7['name'],_0x492451)):_0x32e804;}});return new te(_0x56a140,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x196fe9,_0x2d4b1e,_0x1a42a8){this['children_']=_0x196fe9,this['priorityNode_']=_0x2d4b1e,this['indexMap_']=_0x1a42a8,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x287d1e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x287d1e,this['indexMap_']);}['getImmediateChild'](_0x30fabe){if(_0x30fabe==='.priority')return this['getPriority']();{const _0x31a02c=this['children_']['get'](_0x30fabe);return _0x31a02c===null?It:_0x31a02c;}}['getChild'](_0x364028){const _0xeced2a=y(_0x364028);return _0xeced2a===null?this:this['getImmediateChild'](_0xeced2a)['getChild'](S(_0x364028));}['hasChild'](_0x3fdd7f){return this['children_']['get'](_0x3fdd7f)!==null;}['updateImmediateChild'](_0xf671c4,_0x390784){if(f(_0x390784,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xf671c4==='.priority')return this['updatePriority'](_0x390784);{const _0x59dec1=new E(_0xf671c4,_0x390784);let _0xad4519,_0x3ff23d;_0x390784['isEmpty']()?(_0xad4519=this['children_']['remove'](_0xf671c4),_0x3ff23d=this['indexMap_']['removeFromIndexes'](_0x59dec1,this['children_'])):(_0xad4519=this['children_']['insert'](_0xf671c4,_0x390784),_0x3ff23d=this['indexMap_']['addToIndexes'](_0x59dec1,this['children_']));const _0x4f0603=_0xad4519['isEmpty']()?It:this['priorityNode_'];return new g(_0xad4519,_0x4f0603,_0x3ff23d);}}['updateChild'](_0x425471,_0x3276e9){const _0xbe14b6=y(_0x425471);if(_0xbe14b6===null)return _0x3276e9;{f(y(_0x425471)!=='.priority'||Ce(_0x425471)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1a6a08=this['getImmediateChild'](_0xbe14b6)['updateChild'](S(_0x425471),_0x3276e9);return this['updateImmediateChild'](_0xbe14b6,_0x1a6a08);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xccd975){if(this['isEmpty']())return null;const _0x1e3421={};let _0x411927=0x0,_0xc454b5=0x0,_0x261452=!0x0;if(this['forEachChild'](R,(_0x3ca53c,_0x4ac7b5)=>{_0x1e3421[_0x3ca53c]=_0x4ac7b5['val'](_0xccd975),_0x411927++,_0x261452&&g['INTEGER_REGEXP_']['test'](_0x3ca53c)?_0xc454b5=Math['max'](_0xc454b5,Number(_0x3ca53c)):_0x261452=!0x1;}),!_0xccd975&&_0x261452&&_0xc454b5<0x2*_0x411927){const _0x655be5=[];for(const _0x35b73b in _0x1e3421)_0x655be5[_0x35b73b]=_0x1e3421[_0x35b73b];return _0x655be5;}else return _0xccd975&&!this['getPriority']()['isEmpty']()&&(_0x1e3421['.priority']=this['getPriority']()['val']()),_0x1e3421;}['hash'](){if(this['lazyHash_']===null){let _0x4af78c='';this['getPriority']()['isEmpty']()||(_0x4af78c+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2b24e4,_0x3e6b94)=>{const _0x29e921=_0x3e6b94['hash']();_0x29e921!==''&&(_0x4af78c+=':'+_0x2b24e4+':'+_0x29e921);}),this['lazyHash_']=_0x4af78c===''?'':ro(_0x4af78c);}return this['lazyHash_'];}['getPredecessorChildName'](_0x11c10b,_0x25f8a0,_0x53de18){const _0x526634=this['resolveIndex_'](_0x53de18);if(_0x526634){const _0x124715=_0x526634['getPredecessorKey'](new E(_0x11c10b,_0x25f8a0));return _0x124715?_0x124715['name']:null;}else return this['children_']['getPredecessorKey'](_0x11c10b);}['getFirstChildName'](_0x16f94e){const _0x4ce08a=this['resolveIndex_'](_0x16f94e);if(_0x4ce08a){const _0x33e4d8=_0x4ce08a['minKey']();return _0x33e4d8&&_0x33e4d8['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x25baa1){const _0x55d540=this['getFirstChildName'](_0x25baa1);return _0x55d540?new E(_0x55d540,this['children_']['get'](_0x55d540)):null;}['getLastChildName'](_0x5c09c1){const _0x9ec2db=this['resolveIndex_'](_0x5c09c1);if(_0x9ec2db){const _0x13e42d=_0x9ec2db['maxKey']();return _0x13e42d&&_0x13e42d['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1e56c1){const _0x181ad8=this['getLastChildName'](_0x1e56c1);return _0x181ad8?new E(_0x181ad8,this['children_']['get'](_0x181ad8)):null;}['forEachChild'](_0x9cab6,_0x4c1520){const _0x14596d=this['resolveIndex_'](_0x9cab6);return _0x14596d?_0x14596d['inorderTraversal'](_0x1650f5=>_0x4c1520(_0x1650f5['name'],_0x1650f5['node'])):this['children_']['inorderTraversal'](_0x4c1520);}['getIterator'](_0xa4fdc1){return this['getIteratorFrom'](_0xa4fdc1['minPost'](),_0xa4fdc1);}['getIteratorFrom'](_0x2ceead,_0x5a7a27){const _0x4a4405=this['resolveIndex_'](_0x5a7a27);if(_0x4a4405)return _0x4a4405['getIteratorFrom'](_0x2ceead,_0x496322=>_0x496322);{const _0x363e64=this['children_']['getIteratorFrom'](_0x2ceead['name'],E['Wrap']);let _0xf6431f=_0x363e64['peek']();for(;_0xf6431f!=null&&_0x5a7a27['compare'](_0xf6431f,_0x2ceead)<0x0;)_0x363e64['getNext'](),_0xf6431f=_0x363e64['peek']();return _0x363e64;}}['getReverseIterator'](_0x2f7aba){return this['getReverseIteratorFrom'](_0x2f7aba['maxPost'](),_0x2f7aba);}['getReverseIteratorFrom'](_0x25478f,_0x7adc32){const _0x2da574=this['resolveIndex_'](_0x7adc32);if(_0x2da574)return _0x2da574['getReverseIteratorFrom'](_0x25478f,_0x560b7e=>_0x560b7e);{const _0x139cab=this['children_']['getReverseIteratorFrom'](_0x25478f['name'],E['Wrap']);let _0x5753d0=_0x139cab['peek']();for(;_0x5753d0!=null&&_0x7adc32['compare'](_0x5753d0,_0x25478f)>0x0;)_0x139cab['getNext'](),_0x5753d0=_0x139cab['peek']();return _0x139cab;}}['compareTo'](_0x43458f){return this['isEmpty']()?_0x43458f['isEmpty']()?0x0:-0x1:_0x43458f['isLeafNode']()||_0x43458f['isEmpty']()?0x1:_0x43458f===Kt?-0x1:0x0;}['withIndex'](_0x451981){if(_0x451981===ve||this['indexMap_']['hasIndex'](_0x451981))return this;{const _0x5d8046=this['indexMap_']['addIndex'](_0x451981,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5d8046);}}['isIndexed'](_0x3f0b3f){return _0x3f0b3f===ve||this['indexMap_']['hasIndex'](_0x3f0b3f);}['equals'](_0x3eec77){if(_0x3eec77===this)return!0x0;if(_0x3eec77['isLeafNode']())return!0x1;{const _0x93f4f7=_0x3eec77;if(this['getPriority']()['equals'](_0x93f4f7['getPriority']())){if(this['children_']['count']()===_0x93f4f7['children_']['count']()){const _0x1063c7=this['getIterator'](R),_0x375687=_0x93f4f7['getIterator'](R);let _0x5e7d01=_0x1063c7['getNext'](),_0x3acf5d=_0x375687['getNext']();for(;_0x5e7d01&&_0x3acf5d;){if(_0x5e7d01['name']!==_0x3acf5d['name']||!_0x5e7d01['node']['equals'](_0x3acf5d['node']))return!0x1;_0x5e7d01=_0x1063c7['getNext'](),_0x3acf5d=_0x375687['getNext']();}return _0x5e7d01===null&&_0x3acf5d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4bf683){return _0x4bf683===ve?null:this['indexMap_']['get'](_0x4bf683['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x1e70d3){return _0x1e70d3===this?0x0:0x1;}['equals'](_0x33018d){return _0x33018d===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5a9e6a){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x585a0f,_0x5ea9e1=null){if(_0x585a0f===null)return g['EMPTY_NODE'];if(typeof _0x585a0f=='object'&&'.priority'in _0x585a0f&&(_0x5ea9e1=_0x585a0f['.priority']),f(_0x5ea9e1===null||typeof _0x5ea9e1=='string'||typeof _0x5ea9e1=='number'||typeof _0x5ea9e1=='object'&&'.sv'in _0x5ea9e1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5ea9e1),typeof _0x585a0f=='object'&&'.value'in _0x585a0f&&_0x585a0f['.value']!==null&&(_0x585a0f=_0x585a0f['.value']),typeof _0x585a0f!='object'||'.sv'in _0x585a0f){const _0x4d8c48=_0x585a0f;return new D(_0x4d8c48,A(_0x5ea9e1));}if(!(_0x585a0f instanceof Array)&&Gh){const _0x2c7b3b=[];let _0x247794=!0x1;if(x(_0x585a0f,(_0x586ec2,_0x4db2c0)=>{if(_0x586ec2['substring'](0x0,0x1)!=='.'){const _0x4577b1=A(_0x4db2c0);_0x4577b1['isEmpty']()||(_0x247794=_0x247794||!_0x4577b1['getPriority']()['isEmpty'](),_0x2c7b3b['push'](new E(_0x586ec2,_0x4577b1)));}}),_0x2c7b3b['length']===0x0)return g['EMPTY_NODE'];const _0x518332=yn(_0x2c7b3b,xh,_0x470268=>_0x470268['name'],Qi);if(_0x247794){const _0x47944c=yn(_0x2c7b3b,R['getCompare']());return new g(_0x518332,A(_0x5ea9e1),new te({'.priority':_0x47944c},{'.priority':R}));}else return new g(_0x518332,A(_0x5ea9e1),te['Default']);}else{let _0xb8708c=g['EMPTY_NODE'];return x(_0x585a0f,(_0x501378,_0x5c9a32)=>{if(Q(_0x585a0f,_0x501378)&&_0x501378['substring'](0x0,0x1)!=='.'){const _0x1c4b59=A(_0x5c9a32);(_0x1c4b59['isLeafNode']()||!_0x1c4b59['isEmpty']())&&(_0xb8708c=_0xb8708c['updateImmediateChild'](_0x501378,_0x1c4b59));}}),_0xb8708c['updatePriority'](A(_0x5ea9e1));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x1c677d){super(),this['indexPath_']=_0x1c677d,f(!v(_0x1c677d)&&y(_0x1c677d)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1bef30){return _0x1bef30['getChild'](this['indexPath_']);}['isDefinedOn'](_0x42338a){return!_0x42338a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2182d1,_0x1a2dfe){const _0x3d7939=this['extractChild'](_0x2182d1['node']),_0x2ddae8=this['extractChild'](_0x1a2dfe['node']),_0x15dfab=_0x3d7939['compareTo'](_0x2ddae8);return _0x15dfab===0x0?qe(_0x2182d1['name'],_0x1a2dfe['name']):_0x15dfab;}['makePost'](_0x1532a7,_0x142835){const _0x283fc4=A(_0x1532a7),_0x10ec15=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x283fc4);return new E(_0x142835,_0x10ec15);}['maxPost'](){const _0x42fb5a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x42fb5a);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x486f51,_0x3d437a){const _0x41ded9=_0x486f51['node']['compareTo'](_0x3d437a['node']);return _0x41ded9===0x0?qe(_0x486f51['name'],_0x3d437a['name']):_0x41ded9;}['isDefinedOn'](_0x1b11ac){return!0x0;}['indexedValueChanged'](_0x440b66,_0x324408){return!_0x440b66['equals'](_0x324408);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x43b2e4,_0x4d3579){const _0x4be988=A(_0x43b2e4);return new E(_0x4d3579,_0x4be988);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xab5a97){return{'type':'value','snapshotNode':_0xab5a97};}function rt(_0x33e3c3,_0x3d8bd7){return{'type':'child_added','snapshotNode':_0x3d8bd7,'childName':_0x33e3c3};}function Lt(_0x335819,_0x15996f){return{'type':'child_removed','snapshotNode':_0x15996f,'childName':_0x335819};}function xt(_0x575399,_0x552922,_0x294878){return{'type':'child_changed','snapshotNode':_0x552922,'childName':_0x575399,'oldSnap':_0x294878};}function zh(_0x33b9cd,_0x382766){return{'type':'child_moved','snapshotNode':_0x382766,'childName':_0x33b9cd};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x2ebfc1){this['index_']=_0x2ebfc1;}['updateChild'](_0x15596f,_0x3586e5,_0x637089,_0x1107b4,_0x12d9ae,_0x475483){f(_0x15596f['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3cc8a2=_0x15596f['getImmediateChild'](_0x3586e5);return _0x3cc8a2['getChild'](_0x1107b4)['equals'](_0x637089['getChild'](_0x1107b4))&&_0x3cc8a2['isEmpty']()===_0x637089['isEmpty']()||(_0x475483!=null&&(_0x637089['isEmpty']()?_0x15596f['hasChild'](_0x3586e5)?_0x475483['trackChildChange'](Lt(_0x3586e5,_0x3cc8a2)):f(_0x15596f['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3cc8a2['isEmpty']()?_0x475483['trackChildChange'](rt(_0x3586e5,_0x637089)):_0x475483['trackChildChange'](xt(_0x3586e5,_0x637089,_0x3cc8a2))),_0x15596f['isLeafNode']()&&_0x637089['isEmpty']())?_0x15596f:_0x15596f['updateImmediateChild'](_0x3586e5,_0x637089)['withIndex'](this['index_']);}['updateFullNode'](_0x5d23f8,_0x180885,_0x7cfa1f){return _0x7cfa1f!=null&&(_0x5d23f8['isLeafNode']()||_0x5d23f8['forEachChild'](R,(_0x808e50,_0x3a22f6)=>{_0x180885['hasChild'](_0x808e50)||_0x7cfa1f['trackChildChange'](Lt(_0x808e50,_0x3a22f6));}),_0x180885['isLeafNode']()||_0x180885['forEachChild'](R,(_0x389388,_0x550e5e)=>{if(_0x5d23f8['hasChild'](_0x389388)){const _0xfa927d=_0x5d23f8['getImmediateChild'](_0x389388);_0xfa927d['equals'](_0x550e5e)||_0x7cfa1f['trackChildChange'](xt(_0x389388,_0x550e5e,_0xfa927d));}else _0x7cfa1f['trackChildChange'](rt(_0x389388,_0x550e5e));})),_0x180885['withIndex'](this['index_']);}['updatePriority'](_0xf9e050,_0x6456a6){return _0xf9e050['isEmpty']()?g['EMPTY_NODE']:_0xf9e050['updatePriority'](_0x6456a6);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x1e84f9){this['indexedFilter_']=new Xi(_0x1e84f9['getIndex']()),this['index_']=_0x1e84f9['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x1e84f9),this['endPost_']=Ft['getEndPost_'](_0x1e84f9),this['startIsInclusive_']=!_0x1e84f9['startAfterSet_'],this['endIsInclusive_']=!_0x1e84f9['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x39a0d1){const _0x5e99d0=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x39a0d1)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x39a0d1)<0x0,_0x4a2e58=this['endIsInclusive_']?this['index_']['compare'](_0x39a0d1,this['getEndPost']())<=0x0:this['index_']['compare'](_0x39a0d1,this['getEndPost']())<0x0;return _0x5e99d0&&_0x4a2e58;}['updateChild'](_0x1bf35b,_0x4c8931,_0x4d0519,_0x434daa,_0x130f39,_0x137b33){return this['matches'](new E(_0x4c8931,_0x4d0519))||(_0x4d0519=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1bf35b,_0x4c8931,_0x4d0519,_0x434daa,_0x130f39,_0x137b33);}['updateFullNode'](_0x46182e,_0x4c9d16,_0x518437){_0x4c9d16['isLeafNode']()&&(_0x4c9d16=g['EMPTY_NODE']);let _0x404816=_0x4c9d16['withIndex'](this['index_']);_0x404816=_0x404816['updatePriority'](g['EMPTY_NODE']);const _0x185d4a=this;return _0x4c9d16['forEachChild'](R,(_0x559dc7,_0x2f6210)=>{_0x185d4a['matches'](new E(_0x559dc7,_0x2f6210))||(_0x404816=_0x404816['updateImmediateChild'](_0x559dc7,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x46182e,_0x404816,_0x518437);}['updatePriority'](_0x41bb8d,_0x28c00f){return _0x41bb8d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x18a562){if(_0x18a562['hasStart']()){const _0x5c0537=_0x18a562['getIndexStartName']();return _0x18a562['getIndex']()['makePost'](_0x18a562['getIndexStartValue'](),_0x5c0537);}else return _0x18a562['getIndex']()['minPost']();}static['getEndPost_'](_0xa7d24b){if(_0xa7d24b['hasEnd']()){const _0x2c4e84=_0xa7d24b['getIndexEndName']();return _0xa7d24b['getIndex']()['makePost'](_0xa7d24b['getIndexEndValue'](),_0x2c4e84);}else return _0xa7d24b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1aae27){this['withinDirectionalStart']=_0xbde933=>this['reverse_']?this['withinEndPost'](_0xbde933):this['withinStartPost'](_0xbde933),this['withinDirectionalEnd']=_0x4c9756=>this['reverse_']?this['withinStartPost'](_0x4c9756):this['withinEndPost'](_0x4c9756),this['withinStartPost']=_0xb3d9fb=>{const _0x5d15e3=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xb3d9fb);return this['startIsInclusive_']?_0x5d15e3<=0x0:_0x5d15e3<0x0;},this['withinEndPost']=_0x301ee9=>{const _0x19268c=this['index_']['compare'](_0x301ee9,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x19268c<=0x0:_0x19268c<0x0;},this['rangedFilter_']=new Ft(_0x1aae27),this['index_']=_0x1aae27['getIndex'](),this['limit_']=_0x1aae27['getLimit'](),this['reverse_']=!_0x1aae27['isViewFromLeft'](),this['startIsInclusive_']=!_0x1aae27['startAfterSet_'],this['endIsInclusive_']=!_0x1aae27['endBeforeSet_'];}['updateChild'](_0x2f2f02,_0xfdf300,_0x285e2f,_0x2ff0c7,_0x32a3b8,_0x3b7f65){return this['rangedFilter_']['matches'](new E(_0xfdf300,_0x285e2f))||(_0x285e2f=g['EMPTY_NODE']),_0x2f2f02['getImmediateChild'](_0xfdf300)['equals'](_0x285e2f)?_0x2f2f02:_0x2f2f02['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2f2f02,_0xfdf300,_0x285e2f,_0x2ff0c7,_0x32a3b8,_0x3b7f65):this['fullLimitUpdateChild_'](_0x2f2f02,_0xfdf300,_0x285e2f,_0x32a3b8,_0x3b7f65);}['updateFullNode'](_0x57bdc7,_0x86ec32,_0x1fc5d3){let _0x1df564;if(_0x86ec32['isLeafNode']()||_0x86ec32['isEmpty']())_0x1df564=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x86ec32['numChildren']()&&_0x86ec32['isIndexed'](this['index_'])){_0x1df564=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x253baf;this['reverse_']?_0x253baf=_0x86ec32['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x253baf=_0x86ec32['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x305774=0x0;for(;_0x253baf['hasNext']()&&_0x305774<this['limit_'];){const _0x4f6e61=_0x253baf['getNext']();if(this['withinDirectionalStart'](_0x4f6e61)){if(this['withinDirectionalEnd'](_0x4f6e61))_0x1df564=_0x1df564['updateImmediateChild'](_0x4f6e61['name'],_0x4f6e61['node']),_0x305774++;else break;}else continue;}}else{_0x1df564=_0x86ec32['withIndex'](this['index_']),_0x1df564=_0x1df564['updatePriority'](g['EMPTY_NODE']);let _0x55618e;this['reverse_']?_0x55618e=_0x1df564['getReverseIterator'](this['index_']):_0x55618e=_0x1df564['getIterator'](this['index_']);let _0x27ab3f=0x0;for(;_0x55618e['hasNext']();){const _0x4113b3=_0x55618e['getNext']();_0x27ab3f<this['limit_']&&this['withinDirectionalStart'](_0x4113b3)&&this['withinDirectionalEnd'](_0x4113b3)?_0x27ab3f++:_0x1df564=_0x1df564['updateImmediateChild'](_0x4113b3['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x57bdc7,_0x1df564,_0x1fc5d3);}['updatePriority'](_0x10bdcf,_0x59d7ae){return _0x10bdcf;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5e814a,_0x35407b,_0xf31a4c,_0x5b8299,_0x1cb0bf){let _0x2c2f3e;if(this['reverse_']){const _0x24aa6e=this['index_']['getCompare']();_0x2c2f3e=(_0x22203c,_0x301059)=>_0x24aa6e(_0x301059,_0x22203c);}else _0x2c2f3e=this['index_']['getCompare']();const _0xe5d033=_0x5e814a;f(_0xe5d033['numChildren']()===this['limit_'],'');const _0x64c8e2=new E(_0x35407b,_0xf31a4c),_0x960334=this['reverse_']?_0xe5d033['getFirstChild'](this['index_']):_0xe5d033['getLastChild'](this['index_']),_0x514b4b=this['rangedFilter_']['matches'](_0x64c8e2);if(_0xe5d033['hasChild'](_0x35407b)){const _0x2e12c9=_0xe5d033['getImmediateChild'](_0x35407b);let _0x26306b=_0x5b8299['getChildAfterChild'](this['index_'],_0x960334,this['reverse_']);for(;_0x26306b!=null&&(_0x26306b['name']===_0x35407b||_0xe5d033['hasChild'](_0x26306b['name']));)_0x26306b=_0x5b8299['getChildAfterChild'](this['index_'],_0x26306b,this['reverse_']);const _0x5f1d3a=_0x26306b==null?0x1:_0x2c2f3e(_0x26306b,_0x64c8e2);if(_0x514b4b&&!_0xf31a4c['isEmpty']()&&_0x5f1d3a>=0x0)return _0x1cb0bf!=null&&_0x1cb0bf['trackChildChange'](xt(_0x35407b,_0xf31a4c,_0x2e12c9)),_0xe5d033['updateImmediateChild'](_0x35407b,_0xf31a4c);{_0x1cb0bf!=null&&_0x1cb0bf['trackChildChange'](Lt(_0x35407b,_0x2e12c9));const _0x56a9a4=_0xe5d033['updateImmediateChild'](_0x35407b,g['EMPTY_NODE']);return _0x26306b!=null&&this['rangedFilter_']['matches'](_0x26306b)?(_0x1cb0bf!=null&&_0x1cb0bf['trackChildChange'](rt(_0x26306b['name'],_0x26306b['node'])),_0x56a9a4['updateImmediateChild'](_0x26306b['name'],_0x26306b['node'])):_0x56a9a4;}}else return _0xf31a4c['isEmpty']()?_0x5e814a:_0x514b4b&&_0x2c2f3e(_0x960334,_0x64c8e2)>=0x0?(_0x1cb0bf!=null&&(_0x1cb0bf['trackChildChange'](Lt(_0x960334['name'],_0x960334['node'])),_0x1cb0bf['trackChildChange'](rt(_0x35407b,_0xf31a4c))),_0xe5d033['updateImmediateChild'](_0x35407b,_0xf31a4c)['updateImmediateChild'](_0x960334['name'],g['EMPTY_NODE'])):_0x5e814a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x28b046=new Zi();return _0x28b046['limitSet_']=this['limitSet_'],_0x28b046['limit_']=this['limit_'],_0x28b046['startSet_']=this['startSet_'],_0x28b046['startAfterSet_']=this['startAfterSet_'],_0x28b046['indexStartValue_']=this['indexStartValue_'],_0x28b046['startNameSet_']=this['startNameSet_'],_0x28b046['indexStartName_']=this['indexStartName_'],_0x28b046['endSet_']=this['endSet_'],_0x28b046['endBeforeSet_']=this['endBeforeSet_'],_0x28b046['indexEndValue_']=this['indexEndValue_'],_0x28b046['endNameSet_']=this['endNameSet_'],_0x28b046['indexEndName_']=this['indexEndName_'],_0x28b046['index_']=this['index_'],_0x28b046['viewFrom_']=this['viewFrom_'],_0x28b046;}}function Kh(_0x4fc086){return _0x4fc086['loadsAllData']()?new Xi(_0x4fc086['getIndex']()):_0x4fc086['hasLimit']()?new jh(_0x4fc086):new Ft(_0x4fc086);}function Yh(_0x2eecb7,_0x1a76e1){const _0x485b3f=_0x2eecb7['copy']();return _0x485b3f['limitSet_']=!0x0,_0x485b3f['limit_']=_0x1a76e1,_0x485b3f['viewFrom_']='l',_0x485b3f;}function Qh(_0x696727,_0x392e3e,_0x9714a0){const _0x6af2fc=_0x696727['copy']();return _0x6af2fc['startSet_']=!0x0,_0x392e3e===void 0x0&&(_0x392e3e=null),_0x6af2fc['indexStartValue_']=_0x392e3e,_0x9714a0!=null?(_0x6af2fc['startNameSet_']=!0x0,_0x6af2fc['indexStartName_']=_0x9714a0):(_0x6af2fc['startNameSet_']=!0x1,_0x6af2fc['indexStartName_']=''),_0x6af2fc;}function Jh(_0x587677,_0x5dc037,_0x15e5d2){const _0x1afae3=_0x587677['copy']();return _0x1afae3['endSet_']=!0x0,_0x5dc037===void 0x0&&(_0x5dc037=null),_0x1afae3['indexEndValue_']=_0x5dc037,_0x15e5d2!==void 0x0?(_0x1afae3['endNameSet_']=!0x0,_0x1afae3['indexEndName_']=_0x15e5d2):(_0x1afae3['endNameSet_']=!0x1,_0x1afae3['indexEndName_']=''),_0x1afae3;}function xo(_0x40dfde,_0x469dfc){const _0x59f4d9=_0x40dfde['copy']();return _0x59f4d9['index_']=_0x469dfc,_0x59f4d9;}function ir(_0x3c197b){const _0x139c32={};if(_0x3c197b['isDefault']())return _0x139c32;let _0xe79718;if(_0x3c197b['index_']===R?_0xe79718='$priority':_0x3c197b['index_']===Mo?_0xe79718='$value':_0x3c197b['index_']===ve?_0xe79718='$key':(f(_0x3c197b['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0xe79718=_0x3c197b['index_']['toString']()),_0x139c32['orderBy']=O(_0xe79718),_0x3c197b['startSet_']){const _0x450c9a=_0x3c197b['startAfterSet_']?'startAfter':'startAt';_0x139c32[_0x450c9a]=O(_0x3c197b['indexStartValue_']),_0x3c197b['startNameSet_']&&(_0x139c32[_0x450c9a]+=','+O(_0x3c197b['indexStartName_']));}if(_0x3c197b['endSet_']){const _0x13bf70=_0x3c197b['endBeforeSet_']?'endBefore':'endAt';_0x139c32[_0x13bf70]=O(_0x3c197b['indexEndValue_']),_0x3c197b['endNameSet_']&&(_0x139c32[_0x13bf70]+=','+O(_0x3c197b['indexEndName_']));}return _0x3c197b['limitSet_']&&(_0x3c197b['isViewFromLeft']()?_0x139c32['limitToFirst']=_0x3c197b['limit_']:_0x139c32['limitToLast']=_0x3c197b['limit_']),_0x139c32;}function sr(_0x2b7519){const _0x53acf7={};if(_0x2b7519['startSet_']&&(_0x53acf7['sp']=_0x2b7519['indexStartValue_'],_0x2b7519['startNameSet_']&&(_0x53acf7['sn']=_0x2b7519['indexStartName_']),_0x53acf7['sin']=!_0x2b7519['startAfterSet_']),_0x2b7519['endSet_']&&(_0x53acf7['ep']=_0x2b7519['indexEndValue_'],_0x2b7519['endNameSet_']&&(_0x53acf7['en']=_0x2b7519['indexEndName_']),_0x53acf7['ein']=!_0x2b7519['endBeforeSet_']),_0x2b7519['limitSet_']){_0x53acf7['l']=_0x2b7519['limit_'];let _0x91ee3f=_0x2b7519['viewFrom_'];_0x91ee3f===''&&(_0x2b7519['isViewFromLeft']()?_0x91ee3f='l':_0x91ee3f='r'),_0x53acf7['vf']=_0x91ee3f;}return _0x2b7519['index_']!==R&&(_0x53acf7['i']=_0x2b7519['index_']['toString']()),_0x53acf7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x50cdeb){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x43c9e7,_0x29bca4){return _0x29bca4!==void 0x0?'tag$'+_0x29bca4:(f(_0x43c9e7['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x43c9e7['_path']['toString']());}constructor(_0x45559e,_0x583d6b,_0x52334b,_0x47023a){super(),this['repoInfo_']=_0x45559e,this['onDataUpdate_']=_0x583d6b,this['authTokenProvider_']=_0x52334b,this['appCheckTokenProvider_']=_0x47023a,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x39b412,_0x52697c,_0x3a6dd2,_0x8826f0){const _0x11c4df=_0x39b412['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x11c4df+'\x20'+_0x39b412['_queryIdentifier']);const _0x242c89=vn['getListenId_'](_0x39b412,_0x3a6dd2),_0x1ec30c={};this['listens_'][_0x242c89]=_0x1ec30c;const _0x45330e=ir(_0x39b412['_queryParams']);this['restRequest_'](_0x11c4df+'.json',_0x45330e,(_0x125491,_0xb16458)=>{let _0x5adbbf=_0xb16458;if(_0x125491===0x194&&(_0x5adbbf=null,_0x125491=null),_0x125491===null&&this['onDataUpdate_'](_0x11c4df,_0x5adbbf,!0x1,_0x3a6dd2),Le(this['listens_'],_0x242c89)===_0x1ec30c){let _0x257659;_0x125491?_0x125491===0x191?_0x257659='permission_denied':_0x257659='rest_error:'+_0x125491:_0x257659='ok',_0x8826f0(_0x257659,null);}});}['unlisten'](_0x5dac93,_0x1a695f){const _0x416c6b=vn['getListenId_'](_0x5dac93,_0x1a695f);delete this['listens_'][_0x416c6b];}['get'](_0x44d859){const _0x710530=ir(_0x44d859['_queryParams']),_0x1084d4=_0x44d859['_path']['toString'](),_0x1a6fe5=new H();return this['restRequest_'](_0x1084d4+'.json',_0x710530,(_0x467b1d,_0x1f0c76)=>{let _0x376563=_0x1f0c76;_0x467b1d===0x194&&(_0x376563=null,_0x467b1d=null),_0x467b1d===null?(this['onDataUpdate_'](_0x1084d4,_0x376563,!0x1,null),_0x1a6fe5['resolve'](_0x376563)):_0x1a6fe5['reject'](new Error(_0x376563));}),_0x1a6fe5['promise'];}['refreshAuthToken'](_0x363a6e){}['restRequest_'](_0x19d6d8,_0x14ecb1={},_0x2eb17d){return _0x14ecb1['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5b6c29,_0x28c0fe])=>{_0x5b6c29&&_0x5b6c29['accessToken']&&(_0x14ecb1['auth']=_0x5b6c29['accessToken']),_0x28c0fe&&_0x28c0fe['token']&&(_0x14ecb1['ac']=_0x28c0fe['token']);const _0xcd15f0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x19d6d8+'?ns='+this['repoInfo_']['namespace']+ut(_0x14ecb1);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xcd15f0);const _0x567d7f=new XMLHttpRequest();_0x567d7f['onreadystatechange']=()=>{if(_0x2eb17d&&_0x567d7f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xcd15f0+'\x20received.\x20status:',_0x567d7f['status'],'response:',_0x567d7f['responseText']);let _0x559b29=null;if(_0x567d7f['status']>=0xc8&&_0x567d7f['status']<0x12c){try{_0x559b29=Nt(_0x567d7f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xcd15f0+':\x20'+_0x567d7f['responseText']);}_0x2eb17d(null,_0x559b29);}else _0x567d7f['status']!==0x191&&_0x567d7f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xcd15f0+'\x20Status:\x20'+_0x567d7f['status']),_0x2eb17d(_0x567d7f['status']);_0x2eb17d=null;}},_0x567d7f['open']('GET',_0xcd15f0,!0x0),_0x567d7f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x16a478){return this['rootNode_']['getChild'](_0x16a478);}['updateSnapshot'](_0x12002f,_0x24ceae){this['rootNode_']=this['rootNode_']['updateChild'](_0x12002f,_0x24ceae);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x112dac,_0x110d3b,_0x4d0afb){if(v(_0x110d3b))_0x112dac['value']=_0x4d0afb,_0x112dac['children']['clear']();else{if(_0x112dac['value']!==null)_0x112dac['value']=_0x112dac['value']['updateChild'](_0x110d3b,_0x4d0afb);else{const _0x1edc09=y(_0x110d3b);_0x112dac['children']['has'](_0x1edc09)||_0x112dac['children']['set'](_0x1edc09,En());const _0x5e0fc6=_0x112dac['children']['get'](_0x1edc09);_0x110d3b=S(_0x110d3b),pt(_0x5e0fc6,_0x110d3b,_0x4d0afb);}}}function Ti(_0x2871a2,_0x1b6586){if(v(_0x1b6586))return _0x2871a2['value']=null,_0x2871a2['children']['clear'](),!0x0;if(_0x2871a2['value']!==null){if(_0x2871a2['value']['isLeafNode']())return!0x1;{const _0x4e9fe2=_0x2871a2['value'];return _0x2871a2['value']=null,_0x4e9fe2['forEachChild'](R,(_0x52649c,_0x875686)=>{pt(_0x2871a2,new C(_0x52649c),_0x875686);}),Ti(_0x2871a2,_0x1b6586);}}else{if(_0x2871a2['children']['size']>0x0){const _0x25a375=y(_0x1b6586);return _0x1b6586=S(_0x1b6586),_0x2871a2['children']['has'](_0x25a375)&&Ti(_0x2871a2['children']['get'](_0x25a375),_0x1b6586)&&_0x2871a2['children']['delete'](_0x25a375),_0x2871a2['children']['size']===0x0;}else return!0x0;}}function Si(_0x32e80a,_0x4cde47,_0x19bf51){_0x32e80a['value']!==null?_0x19bf51(_0x4cde47,_0x32e80a['value']):Zh(_0x32e80a,(_0x359ddd,_0x3d33cb)=>{const _0x41ff8d=new C(_0x4cde47['toString']()+'/'+_0x359ddd);Si(_0x3d33cb,_0x41ff8d,_0x19bf51);});}function Zh(_0x3eda7f,_0x5568ba){_0x3eda7f['children']['forEach']((_0xb4c46,_0x367047)=>{_0x5568ba(_0x367047,_0xb4c46);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4617a7){this['collection_']=_0x4617a7,this['last_']=null;}['get'](){const _0xbf0fbb=this['collection_']['get'](),_0x588d9b={..._0xbf0fbb};return this['last_']&&x(this['last_'],(_0x46ffc5,_0x3a6f36)=>{_0x588d9b[_0x46ffc5]=_0x588d9b[_0x46ffc5]-_0x3a6f36;}),this['last_']=_0xbf0fbb,_0x588d9b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0xc9fcad,_0x36fc3e){this['server_']=_0x36fc3e,this['statsToReport_']={},this['statsListener_']=new eu(_0xc9fcad);const _0x5517d3=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5517d3));}['reportStats_'](){const _0x39dc18=this['statsListener_']['get'](),_0x237eed={};let _0x4335ed=!0x1;x(_0x39dc18,(_0x18f01b,_0x27f3e5)=>{_0x27f3e5>0x0&&Q(this['statsToReport_'],_0x18f01b)&&(_0x237eed[_0x18f01b]=_0x27f3e5,_0x4335ed=!0x0);}),_0x4335ed&&this['server_']['reportStats'](_0x237eed),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x54787c){_0x54787c[_0x54787c['OVERWRITE']=0x0]='OVERWRITE',_0x54787c[_0x54787c['MERGE']=0x1]='MERGE',_0x54787c[_0x54787c['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x54787c[_0x54787c['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x35bb3e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x35bb3e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1200d0,_0x5e5da7,_0x140a22){this['path']=_0x1200d0,this['affectedTree']=_0x5e5da7,this['revert']=_0x140a22,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0xc69946){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x525458=this['affectedTree']['subtree'](new C(_0xc69946));return new In(w(),_0x525458,this['revert']);}}else return f(y(this['path'])===_0xc69946,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x385230,_0x4ea957){this['source']=_0x385230,this['path']=_0x4ea957,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0xecb6eb){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x21903e,_0x186e48,_0x352dd3){this['source']=_0x21903e,this['path']=_0x186e48,this['snap']=_0x352dd3,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1c9980){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1c9980)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x2ffe01,_0x48dfe8,_0x25db90){this['source']=_0x2ffe01,this['path']=_0x48dfe8,this['children']=_0x25db90,this['type']=z['MERGE'];}['operationForChild'](_0x2f1ab7){if(v(this['path'])){const _0x4e8aad=this['children']['subtree'](new C(_0x2f1ab7));return _0x4e8aad['isEmpty']()?null:_0x4e8aad['value']?new Be(this['source'],w(),_0x4e8aad['value']):new ot(this['source'],w(),_0x4e8aad);}else return f(y(this['path'])===_0x2f1ab7,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x527b73,_0x407f08,_0x3abaf1){this['node_']=_0x527b73,this['fullyInitialized_']=_0x407f08,this['filtered_']=_0x3abaf1;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x436651){if(v(_0x436651))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1cc060=y(_0x436651);return this['isCompleteForChild'](_0x1cc060);}['isCompleteForChild'](_0x2b1f21){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2b1f21);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x5cb1e2){this['query_']=_0x5cb1e2,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1b150c,_0x3c8b7a,_0x2bb25b,_0x4e6c44){const _0x233ca5=[],_0x4996b8=[];return _0x3c8b7a['forEach'](_0x17e0a0=>{_0x17e0a0['type']==='child_changed'&&_0x1b150c['index_']['indexedValueChanged'](_0x17e0a0['oldSnap'],_0x17e0a0['snapshotNode'])&&_0x4996b8['push'](zh(_0x17e0a0['childName'],_0x17e0a0['snapshotNode']));}),wt(_0x1b150c,_0x233ca5,'child_removed',_0x3c8b7a,_0x4e6c44,_0x2bb25b),wt(_0x1b150c,_0x233ca5,'child_added',_0x3c8b7a,_0x4e6c44,_0x2bb25b),wt(_0x1b150c,_0x233ca5,'child_moved',_0x4996b8,_0x4e6c44,_0x2bb25b),wt(_0x1b150c,_0x233ca5,'child_changed',_0x3c8b7a,_0x4e6c44,_0x2bb25b),wt(_0x1b150c,_0x233ca5,'value',_0x3c8b7a,_0x4e6c44,_0x2bb25b),_0x233ca5;}function wt(_0x18d309,_0x457873,_0x40f160,_0x19e7aa,_0x5ad209,_0x1ae22f){const _0xbf1c8e=_0x19e7aa['filter'](_0x46596f=>_0x46596f['type']===_0x40f160);_0xbf1c8e['sort']((_0x453234,_0x562217)=>au(_0x18d309,_0x453234,_0x562217)),_0xbf1c8e['forEach'](_0x11d2a9=>{const _0x23c09b=ou(_0x18d309,_0x11d2a9,_0x1ae22f);_0x5ad209['forEach'](_0x14fe78=>{_0x14fe78['respondsTo'](_0x11d2a9['type'])&&_0x457873['push'](_0x14fe78['createEvent'](_0x23c09b,_0x18d309['query_']));});});}function ou(_0x5b020e,_0x2a1caf,_0x4db5d9){return _0x2a1caf['type']==='value'||_0x2a1caf['type']==='child_removed'||(_0x2a1caf['prevName']=_0x4db5d9['getPredecessorChildName'](_0x2a1caf['childName'],_0x2a1caf['snapshotNode'],_0x5b020e['index_'])),_0x2a1caf;}function au(_0x328473,_0xa5c1ed,_0x233d7f){if(_0xa5c1ed['childName']==null||_0x233d7f['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x236dee=new E(_0xa5c1ed['childName'],_0xa5c1ed['snapshotNode']),_0x353d36=new E(_0x233d7f['childName'],_0x233d7f['snapshotNode']);return _0x328473['index_']['compare'](_0x236dee,_0x353d36);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x11603d,_0x4a28ea){return{'eventCache':_0x11603d,'serverCache':_0x4a28ea};}function Rt(_0x28aeb8,_0x39ec49,_0x272af6,_0x3440ed){return Un(new Te(_0x39ec49,_0x272af6,_0x3440ed),_0x28aeb8['serverCache']);}function Fo(_0x527e54,_0x54833f,_0x18fedb,_0x41eaa3){return Un(_0x527e54['eventCache'],new Te(_0x54833f,_0x18fedb,_0x41eaa3));}function wn(_0x3fca24){return _0x3fca24['eventCache']['isFullyInitialized']()?_0x3fca24['eventCache']['getNode']():null;}function Ve(_0x50fa2f){return _0x50fa2f['serverCache']['isFullyInitialized']()?_0x50fa2f['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0xe94be8){let _0xc7b32=new b(null);return x(_0xe94be8,(_0x336298,_0x2eb717)=>{_0xc7b32=_0xc7b32['set'](new C(_0x336298),_0x2eb717);}),_0xc7b32;}constructor(_0x39011c,_0x22b57c=cu()){this['value']=_0x39011c,this['children']=_0x22b57c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1acc3f,_0x5c7389){if(this['value']!=null&&_0x5c7389(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1acc3f))return null;{const _0x2670f9=y(_0x1acc3f),_0x6f1b77=this['children']['get'](_0x2670f9);if(_0x6f1b77!==null){const _0x196dda=_0x6f1b77['findRootMostMatchingPathAndValue'](S(_0x1acc3f),_0x5c7389);return _0x196dda!=null?{'path':k(new C(_0x2670f9),_0x196dda['path']),'value':_0x196dda['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4c56b0){return this['findRootMostMatchingPathAndValue'](_0x4c56b0,()=>!0x0);}['subtree'](_0x3282f0){if(v(_0x3282f0))return this;{const _0x309849=y(_0x3282f0),_0x4e5cf4=this['children']['get'](_0x309849);return _0x4e5cf4!==null?_0x4e5cf4['subtree'](S(_0x3282f0)):new b(null);}}['set'](_0x122f0d,_0xd0d0f8){if(v(_0x122f0d))return new b(_0xd0d0f8,this['children']);{const _0x3986bc=y(_0x122f0d),_0xbfa094=(this['children']['get'](_0x3986bc)||new b(null))['set'](S(_0x122f0d),_0xd0d0f8),_0x4c186c=this['children']['insert'](_0x3986bc,_0xbfa094);return new b(this['value'],_0x4c186c);}}['remove'](_0x1c4969){if(v(_0x1c4969))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x236055=y(_0x1c4969),_0x1af477=this['children']['get'](_0x236055);if(_0x1af477){const _0x58c2a9=_0x1af477['remove'](S(_0x1c4969));let _0x47e16f;return _0x58c2a9['isEmpty']()?_0x47e16f=this['children']['remove'](_0x236055):_0x47e16f=this['children']['insert'](_0x236055,_0x58c2a9),this['value']===null&&_0x47e16f['isEmpty']()?new b(null):new b(this['value'],_0x47e16f);}else return this;}}['get'](_0x139d09){if(v(_0x139d09))return this['value'];{const _0x59c365=y(_0x139d09),_0x9e202b=this['children']['get'](_0x59c365);return _0x9e202b?_0x9e202b['get'](S(_0x139d09)):null;}}['setTree'](_0x43262d,_0x215c65){if(v(_0x43262d))return _0x215c65;{const _0x102b4f=y(_0x43262d),_0x7bb4bf=(this['children']['get'](_0x102b4f)||new b(null))['setTree'](S(_0x43262d),_0x215c65);let _0x5e99fb;return _0x7bb4bf['isEmpty']()?_0x5e99fb=this['children']['remove'](_0x102b4f):_0x5e99fb=this['children']['insert'](_0x102b4f,_0x7bb4bf),new b(this['value'],_0x5e99fb);}}['fold'](_0x3fa9b1){return this['fold_'](w(),_0x3fa9b1);}['fold_'](_0x5f3a30,_0x579147){const _0x2e2650={};return this['children']['inorderTraversal']((_0x13d456,_0x2469a9)=>{_0x2e2650[_0x13d456]=_0x2469a9['fold_'](k(_0x5f3a30,_0x13d456),_0x579147);}),_0x579147(_0x5f3a30,this['value'],_0x2e2650);}['findOnPath'](_0xfd7d21,_0x2e17e8){return this['findOnPath_'](_0xfd7d21,w(),_0x2e17e8);}['findOnPath_'](_0x57eb5b,_0x3bc528,_0x5590b9){const _0x4b33ea=this['value']?_0x5590b9(_0x3bc528,this['value']):!0x1;if(_0x4b33ea)return _0x4b33ea;if(v(_0x57eb5b))return null;{const _0x321e50=y(_0x57eb5b),_0x4380ca=this['children']['get'](_0x321e50);return _0x4380ca?_0x4380ca['findOnPath_'](S(_0x57eb5b),k(_0x3bc528,_0x321e50),_0x5590b9):null;}}['foreachOnPath'](_0x104ac2,_0x5ab882){return this['foreachOnPath_'](_0x104ac2,w(),_0x5ab882);}['foreachOnPath_'](_0x58768a,_0x3b9742,_0xf6f165){if(v(_0x58768a))return this;{this['value']&&_0xf6f165(_0x3b9742,this['value']);const _0x5570fe=y(_0x58768a),_0x1d3c2b=this['children']['get'](_0x5570fe);return _0x1d3c2b?_0x1d3c2b['foreachOnPath_'](S(_0x58768a),k(_0x3b9742,_0x5570fe),_0xf6f165):new b(null);}}['foreach'](_0x321452){this['foreach_'](w(),_0x321452);}['foreach_'](_0x3b457f,_0x2cf5c6){this['children']['inorderTraversal']((_0x2a3930,_0x56a8d6)=>{_0x56a8d6['foreach_'](k(_0x3b457f,_0x2a3930),_0x2cf5c6);}),this['value']&&_0x2cf5c6(_0x3b457f,this['value']);}['foreachChild'](_0x517368){this['children']['inorderTraversal']((_0x4048b7,_0x3cbf33)=>{_0x3cbf33['value']&&_0x517368(_0x4048b7,_0x3cbf33['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x19be0a){this['writeTree_']=_0x19be0a;}static['empty'](){return new K(new b(null));}}function At(_0x4b81ff,_0x2424e7,_0x303f46){if(v(_0x2424e7))return new K(new b(_0x303f46));{const _0x3fcb0c=_0x4b81ff['writeTree_']['findRootMostValueAndPath'](_0x2424e7);if(_0x3fcb0c!=null){const _0x129e0c=_0x3fcb0c['path'];let _0x54f183=_0x3fcb0c['value'];const _0x50396d=F(_0x129e0c,_0x2424e7);return _0x54f183=_0x54f183['updateChild'](_0x50396d,_0x303f46),new K(_0x4b81ff['writeTree_']['set'](_0x129e0c,_0x54f183));}else{const _0x2da1a3=new b(_0x303f46),_0x4e847f=_0x4b81ff['writeTree_']['setTree'](_0x2424e7,_0x2da1a3);return new K(_0x4e847f);}}}function bi(_0x2b1c31,_0x152dbe,_0x11620e){let _0x132847=_0x2b1c31;return x(_0x11620e,(_0x224bf1,_0x3f1471)=>{_0x132847=At(_0x132847,k(_0x152dbe,_0x224bf1),_0x3f1471);}),_0x132847;}function or(_0x1458c3,_0x55a369){if(v(_0x55a369))return K['empty']();{const _0x34bb01=_0x1458c3['writeTree_']['setTree'](_0x55a369,new b(null));return new K(_0x34bb01);}}function Ri(_0x1a9368,_0x4dca54){return ze(_0x1a9368,_0x4dca54)!=null;}function ze(_0x16edc0,_0x5d8de4){const _0x457e8d=_0x16edc0['writeTree_']['findRootMostValueAndPath'](_0x5d8de4);return _0x457e8d!=null?_0x16edc0['writeTree_']['get'](_0x457e8d['path'])['getChild'](F(_0x457e8d['path'],_0x5d8de4)):null;}function ar(_0x314114){const _0x927c05=[],_0xc7413=_0x314114['writeTree_']['value'];return _0xc7413!=null?_0xc7413['isLeafNode']()||_0xc7413['forEachChild'](R,(_0x318335,_0x65eea)=>{_0x927c05['push'](new E(_0x318335,_0x65eea));}):_0x314114['writeTree_']['children']['inorderTraversal']((_0x6147d2,_0x3f9818)=>{_0x3f9818['value']!=null&&_0x927c05['push'](new E(_0x6147d2,_0x3f9818['value']));}),_0x927c05;}function Ee(_0x1a4e8c,_0x3fa5fb){if(v(_0x3fa5fb))return _0x1a4e8c;{const _0x1af82b=ze(_0x1a4e8c,_0x3fa5fb);return _0x1af82b!=null?new K(new b(_0x1af82b)):new K(_0x1a4e8c['writeTree_']['subtree'](_0x3fa5fb));}}function Ai(_0x472461){return _0x472461['writeTree_']['isEmpty']();}function at(_0x1efd3c,_0x788a03){return Uo(w(),_0x1efd3c['writeTree_'],_0x788a03);}function Uo(_0xd764e9,_0x5e2576,_0xc8c30e){if(_0x5e2576['value']!=null)return _0xc8c30e['updateChild'](_0xd764e9,_0x5e2576['value']);{let _0x418c01=null;return _0x5e2576['children']['inorderTraversal']((_0x48e75f,_0x1bdc00)=>{_0x48e75f==='.priority'?(f(_0x1bdc00['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x418c01=_0x1bdc00['value']):_0xc8c30e=Uo(k(_0xd764e9,_0x48e75f),_0x1bdc00,_0xc8c30e);}),!_0xc8c30e['getChild'](_0xd764e9)['isEmpty']()&&_0x418c01!==null&&(_0xc8c30e=_0xc8c30e['updateChild'](k(_0xd764e9,'.priority'),_0x418c01)),_0xc8c30e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x310ad8,_0x14ab4c){return Ho(_0x14ab4c,_0x310ad8);}function lu(_0x1d2f70,_0x5f2cd5,_0x349f8d,_0x48b611,_0x4bebae){f(_0x48b611>_0x1d2f70['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4bebae===void 0x0&&(_0x4bebae=!0x0),_0x1d2f70['allWrites']['push']({'path':_0x5f2cd5,'snap':_0x349f8d,'writeId':_0x48b611,'visible':_0x4bebae}),_0x4bebae&&(_0x1d2f70['visibleWrites']=At(_0x1d2f70['visibleWrites'],_0x5f2cd5,_0x349f8d)),_0x1d2f70['lastWriteId']=_0x48b611;}function hu(_0x455b91,_0xe3846b,_0x308f6a,_0x54f3a0){f(_0x54f3a0>_0x455b91['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x455b91['allWrites']['push']({'path':_0xe3846b,'children':_0x308f6a,'writeId':_0x54f3a0,'visible':!0x0}),_0x455b91['visibleWrites']=bi(_0x455b91['visibleWrites'],_0xe3846b,_0x308f6a),_0x455b91['lastWriteId']=_0x54f3a0;}function uu(_0x2cbe0c,_0x28bd88){for(let _0x27895e=0x0;_0x27895e<_0x2cbe0c['allWrites']['length'];_0x27895e++){const _0x23d529=_0x2cbe0c['allWrites'][_0x27895e];if(_0x23d529['writeId']===_0x28bd88)return _0x23d529;}return null;}function du(_0x137cab,_0x5479f4){const _0x356ea9=_0x137cab['allWrites']['findIndex'](_0x40187b=>_0x40187b['writeId']===_0x5479f4);f(_0x356ea9>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xd8f233=_0x137cab['allWrites'][_0x356ea9];_0x137cab['allWrites']['splice'](_0x356ea9,0x1);let _0x51a443=_0xd8f233['visible'],_0x1ec05d=!0x1,_0x23d60e=_0x137cab['allWrites']['length']-0x1;for(;_0x51a443&&_0x23d60e>=0x0;){const _0x507744=_0x137cab['allWrites'][_0x23d60e];_0x507744['visible']&&(_0x23d60e>=_0x356ea9&&fu(_0x507744,_0xd8f233['path'])?_0x51a443=!0x1:G(_0xd8f233['path'],_0x507744['path'])&&(_0x1ec05d=!0x0)),_0x23d60e--;}if(_0x51a443){if(_0x1ec05d)return pu(_0x137cab),!0x0;if(_0xd8f233['snap'])_0x137cab['visibleWrites']=or(_0x137cab['visibleWrites'],_0xd8f233['path']);else{const _0xcd152a=_0xd8f233['children'];x(_0xcd152a,_0xff6668=>{_0x137cab['visibleWrites']=or(_0x137cab['visibleWrites'],k(_0xd8f233['path'],_0xff6668));});}return!0x0;}else return!0x1;}function fu(_0x4dd443,_0x9bc86c){if(_0x4dd443['snap'])return G(_0x4dd443['path'],_0x9bc86c);for(const _0x3aedf1 in _0x4dd443['children'])if(_0x4dd443['children']['hasOwnProperty'](_0x3aedf1)&&G(k(_0x4dd443['path'],_0x3aedf1),_0x9bc86c))return!0x0;return!0x1;}function pu(_0x22f3ae){_0x22f3ae['visibleWrites']=Wo(_0x22f3ae['allWrites'],_u,w()),_0x22f3ae['allWrites']['length']>0x0?_0x22f3ae['lastWriteId']=_0x22f3ae['allWrites'][_0x22f3ae['allWrites']['length']-0x1]['writeId']:_0x22f3ae['lastWriteId']=-0x1;}function _u(_0x4b51db){return _0x4b51db['visible'];}function Wo(_0x16e2bd,_0x2897e0,_0x538d2d){let _0x262bf1=K['empty']();for(let _0x192151=0x0;_0x192151<_0x16e2bd['length'];++_0x192151){const _0x545a41=_0x16e2bd[_0x192151];if(_0x2897e0(_0x545a41)){const _0x868b80=_0x545a41['path'];let _0x3f1364;if(_0x545a41['snap'])G(_0x538d2d,_0x868b80)?(_0x3f1364=F(_0x538d2d,_0x868b80),_0x262bf1=At(_0x262bf1,_0x3f1364,_0x545a41['snap'])):G(_0x868b80,_0x538d2d)&&(_0x3f1364=F(_0x868b80,_0x538d2d),_0x262bf1=At(_0x262bf1,w(),_0x545a41['snap']['getChild'](_0x3f1364)));else{if(_0x545a41['children']){if(G(_0x538d2d,_0x868b80))_0x3f1364=F(_0x538d2d,_0x868b80),_0x262bf1=bi(_0x262bf1,_0x3f1364,_0x545a41['children']);else{if(G(_0x868b80,_0x538d2d)){if(_0x3f1364=F(_0x868b80,_0x538d2d),v(_0x3f1364))_0x262bf1=bi(_0x262bf1,w(),_0x545a41['children']);else{const _0x324306=Le(_0x545a41['children'],y(_0x3f1364));if(_0x324306){const _0x41b469=_0x324306['getChild'](S(_0x3f1364));_0x262bf1=At(_0x262bf1,w(),_0x41b469);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x262bf1;}function Bo(_0x138fb3,_0xb4c05b,_0x14f540,_0x5cfe9b,_0x249e1a){if(!_0x5cfe9b&&!_0x249e1a){const _0x1fbb73=ze(_0x138fb3['visibleWrites'],_0xb4c05b);if(_0x1fbb73!=null)return _0x1fbb73;{const _0x110a46=Ee(_0x138fb3['visibleWrites'],_0xb4c05b);if(Ai(_0x110a46))return _0x14f540;if(_0x14f540==null&&!Ri(_0x110a46,w()))return null;{const _0x206582=_0x14f540||g['EMPTY_NODE'];return at(_0x110a46,_0x206582);}}}else{const _0x3a9eab=Ee(_0x138fb3['visibleWrites'],_0xb4c05b);if(!_0x249e1a&&Ai(_0x3a9eab))return _0x14f540;if(!_0x249e1a&&_0x14f540==null&&!Ri(_0x3a9eab,w()))return null;{const _0x1a46b3=function(_0x4b1016){return(_0x4b1016['visible']||_0x249e1a)&&(!_0x5cfe9b||!~_0x5cfe9b['indexOf'](_0x4b1016['writeId']))&&(G(_0x4b1016['path'],_0xb4c05b)||G(_0xb4c05b,_0x4b1016['path']));},_0xabffa9=Wo(_0x138fb3['allWrites'],_0x1a46b3,_0xb4c05b),_0x4fb044=_0x14f540||g['EMPTY_NODE'];return at(_0xabffa9,_0x4fb044);}}}function gu(_0x46b47d,_0x5ae7b5,_0xde6b5d){let _0x4eeebf=g['EMPTY_NODE'];const _0x3c4826=ze(_0x46b47d['visibleWrites'],_0x5ae7b5);if(_0x3c4826)return _0x3c4826['isLeafNode']()||_0x3c4826['forEachChild'](R,(_0x5402e8,_0x4ce2b2)=>{_0x4eeebf=_0x4eeebf['updateImmediateChild'](_0x5402e8,_0x4ce2b2);}),_0x4eeebf;if(_0xde6b5d){const _0x596725=Ee(_0x46b47d['visibleWrites'],_0x5ae7b5);return _0xde6b5d['forEachChild'](R,(_0x51ba2d,_0x38a7be)=>{const _0x32afbd=at(Ee(_0x596725,new C(_0x51ba2d)),_0x38a7be);_0x4eeebf=_0x4eeebf['updateImmediateChild'](_0x51ba2d,_0x32afbd);}),ar(_0x596725)['forEach'](_0x3a393f=>{_0x4eeebf=_0x4eeebf['updateImmediateChild'](_0x3a393f['name'],_0x3a393f['node']);}),_0x4eeebf;}else{const _0x3bc3af=Ee(_0x46b47d['visibleWrites'],_0x5ae7b5);return ar(_0x3bc3af)['forEach'](_0x158fee=>{_0x4eeebf=_0x4eeebf['updateImmediateChild'](_0x158fee['name'],_0x158fee['node']);}),_0x4eeebf;}}function mu(_0x21f5d6,_0x5c92e7,_0x220624,_0x4f3e1a,_0x593b0e){f(_0x4f3e1a||_0x593b0e,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x495cd8=k(_0x5c92e7,_0x220624);if(Ri(_0x21f5d6['visibleWrites'],_0x495cd8))return null;{const _0x7c0230=Ee(_0x21f5d6['visibleWrites'],_0x495cd8);return Ai(_0x7c0230)?_0x593b0e['getChild'](_0x220624):at(_0x7c0230,_0x593b0e['getChild'](_0x220624));}}function yu(_0x435f3e,_0x1b283d,_0x2e4401,_0x219c73){const _0x144f86=k(_0x1b283d,_0x2e4401),_0x1c3dc6=ze(_0x435f3e['visibleWrites'],_0x144f86);if(_0x1c3dc6!=null)return _0x1c3dc6;if(_0x219c73['isCompleteForChild'](_0x2e4401)){const _0x3fb10c=Ee(_0x435f3e['visibleWrites'],_0x144f86);return at(_0x3fb10c,_0x219c73['getNode']()['getImmediateChild'](_0x2e4401));}else return null;}function vu(_0x4562d0,_0x43eb55){return ze(_0x4562d0['visibleWrites'],_0x43eb55);}function Eu(_0x2cee09,_0x1bb57a,_0x220c31,_0x58c549,_0x2fe073,_0x198a03,_0x2dcc1b){let _0x481396;const _0x227c82=Ee(_0x2cee09['visibleWrites'],_0x1bb57a),_0x1ef1e3=ze(_0x227c82,w());if(_0x1ef1e3!=null)_0x481396=_0x1ef1e3;else{if(_0x220c31!=null)_0x481396=at(_0x227c82,_0x220c31);else return[];}if(_0x481396=_0x481396['withIndex'](_0x2dcc1b),!_0x481396['isEmpty']()&&!_0x481396['isLeafNode']()){const _0x427ce0=[],_0x34b457=_0x2dcc1b['getCompare'](),_0x9e02f7=_0x198a03?_0x481396['getReverseIteratorFrom'](_0x58c549,_0x2dcc1b):_0x481396['getIteratorFrom'](_0x58c549,_0x2dcc1b);let _0x2c7603=_0x9e02f7['getNext']();for(;_0x2c7603&&_0x427ce0['length']<_0x2fe073;)_0x34b457(_0x2c7603,_0x58c549)!==0x0&&_0x427ce0['push'](_0x2c7603),_0x2c7603=_0x9e02f7['getNext']();return _0x427ce0;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x5f633b,_0x4faa87,_0x58f411,_0x2e90ef){return Bo(_0x5f633b['writeTree'],_0x5f633b['treePath'],_0x4faa87,_0x58f411,_0x2e90ef);}function is(_0x4b1234,_0x4d6adc){return gu(_0x4b1234['writeTree'],_0x4b1234['treePath'],_0x4d6adc);}function cr(_0x3d1a54,_0x6eb14b,_0x32507a,_0x181431){return mu(_0x3d1a54['writeTree'],_0x3d1a54['treePath'],_0x6eb14b,_0x32507a,_0x181431);}function Tn(_0x20958f,_0x24509b){return vu(_0x20958f['writeTree'],k(_0x20958f['treePath'],_0x24509b));}function wu(_0x299fd2,_0x54dbe5,_0x22abe0,_0x127e88,_0x7924be,_0x2b28fa){return Eu(_0x299fd2['writeTree'],_0x299fd2['treePath'],_0x54dbe5,_0x22abe0,_0x127e88,_0x7924be,_0x2b28fa);}function ss(_0x3b3c47,_0x4a7f0f,_0x5468ce){return yu(_0x3b3c47['writeTree'],_0x3b3c47['treePath'],_0x4a7f0f,_0x5468ce);}function Vo(_0x393848,_0x703f3f){return Ho(k(_0x393848['treePath'],_0x703f3f),_0x393848['writeTree']);}function Ho(_0x2d0c13,_0x5b8835){return{'treePath':_0x2d0c13,'writeTree':_0x5b8835};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x21f08b){const _0x5c43fa=_0x21f08b['type'],_0x1c697e=_0x21f08b['childName'];f(_0x5c43fa==='child_added'||_0x5c43fa==='child_changed'||_0x5c43fa==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1c697e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5de13e=this['changeMap']['get'](_0x1c697e);if(_0x5de13e){const _0x2483b8=_0x5de13e['type'];if(_0x5c43fa==='child_added'&&_0x2483b8==='child_removed')this['changeMap']['set'](_0x1c697e,xt(_0x1c697e,_0x21f08b['snapshotNode'],_0x5de13e['snapshotNode']));else{if(_0x5c43fa==='child_removed'&&_0x2483b8==='child_added')this['changeMap']['delete'](_0x1c697e);else{if(_0x5c43fa==='child_removed'&&_0x2483b8==='child_changed')this['changeMap']['set'](_0x1c697e,Lt(_0x1c697e,_0x5de13e['oldSnap']));else{if(_0x5c43fa==='child_changed'&&_0x2483b8==='child_added')this['changeMap']['set'](_0x1c697e,rt(_0x1c697e,_0x21f08b['snapshotNode']));else{if(_0x5c43fa==='child_changed'&&_0x2483b8==='child_changed')this['changeMap']['set'](_0x1c697e,xt(_0x1c697e,_0x21f08b['snapshotNode'],_0x5de13e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x21f08b+'\x20occurred\x20after\x20'+_0x5de13e);}}}}}else this['changeMap']['set'](_0x1c697e,_0x21f08b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x20fbf9){return null;}['getChildAfterChild'](_0x492435,_0x5afa5e,_0xd04286){return null;}}const $o=new Tu();class rs{constructor(_0x12e754,_0x3df966,_0x242e9c=null){this['writes_']=_0x12e754,this['viewCache_']=_0x3df966,this['optCompleteServerCache_']=_0x242e9c;}['getCompleteChild'](_0x49a7e9){const _0x51c447=this['viewCache_']['eventCache'];if(_0x51c447['isCompleteForChild'](_0x49a7e9))return _0x51c447['getNode']()['getImmediateChild'](_0x49a7e9);{const _0x313844=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x49a7e9,_0x313844);}}['getChildAfterChild'](_0x538990,_0x5c1c82,_0x3a7888){const _0x5454be=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x626cad=wu(this['writes_'],_0x5454be,_0x5c1c82,0x1,_0x3a7888,_0x538990);return _0x626cad['length']===0x0?null:_0x626cad[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x958cf7){return{'filter':_0x958cf7};}function bu(_0x1702d8,_0x3b01fb){f(_0x3b01fb['eventCache']['getNode']()['isIndexed'](_0x1702d8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3b01fb['serverCache']['getNode']()['isIndexed'](_0x1702d8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x10ccd0,_0xb75c35,_0x1cc707,_0x7866e,_0x4d8673){const _0x26a739=new Cu();let _0x5277f5,_0x56afc2;if(_0x1cc707['type']===z['OVERWRITE']){const _0x1d7664=_0x1cc707;_0x1d7664['source']['fromUser']?_0x5277f5=ki(_0x10ccd0,_0xb75c35,_0x1d7664['path'],_0x1d7664['snap'],_0x7866e,_0x4d8673,_0x26a739):(f(_0x1d7664['source']['fromServer'],'Unknown\x20source.'),_0x56afc2=_0x1d7664['source']['tagged']||_0xb75c35['serverCache']['isFiltered']()&&!v(_0x1d7664['path']),_0x5277f5=Sn(_0x10ccd0,_0xb75c35,_0x1d7664['path'],_0x1d7664['snap'],_0x7866e,_0x4d8673,_0x56afc2,_0x26a739));}else{if(_0x1cc707['type']===z['MERGE']){const _0x371fc9=_0x1cc707;_0x371fc9['source']['fromUser']?_0x5277f5=ku(_0x10ccd0,_0xb75c35,_0x371fc9['path'],_0x371fc9['children'],_0x7866e,_0x4d8673,_0x26a739):(f(_0x371fc9['source']['fromServer'],'Unknown\x20source.'),_0x56afc2=_0x371fc9['source']['tagged']||_0xb75c35['serverCache']['isFiltered'](),_0x5277f5=Pi(_0x10ccd0,_0xb75c35,_0x371fc9['path'],_0x371fc9['children'],_0x7866e,_0x4d8673,_0x56afc2,_0x26a739));}else{if(_0x1cc707['type']===z['ACK_USER_WRITE']){const _0x5521e7=_0x1cc707;_0x5521e7['revert']?_0x5277f5=Ou(_0x10ccd0,_0xb75c35,_0x5521e7['path'],_0x7866e,_0x4d8673,_0x26a739):_0x5277f5=Pu(_0x10ccd0,_0xb75c35,_0x5521e7['path'],_0x5521e7['affectedTree'],_0x7866e,_0x4d8673,_0x26a739);}else{if(_0x1cc707['type']===z['LISTEN_COMPLETE'])_0x5277f5=Nu(_0x10ccd0,_0xb75c35,_0x1cc707['path'],_0x7866e,_0x26a739);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1cc707['type']);}}}const _0x5a5d2f=_0x26a739['getChanges']();return Au(_0xb75c35,_0x5277f5,_0x5a5d2f),{'viewCache':_0x5277f5,'changes':_0x5a5d2f};}function Au(_0x2d88db,_0x19257d,_0x1509a0){const _0x2684f9=_0x19257d['eventCache'];if(_0x2684f9['isFullyInitialized']()){const _0x43a2d6=_0x2684f9['getNode']()['isLeafNode']()||_0x2684f9['getNode']()['isEmpty'](),_0x54b191=wn(_0x2d88db);(_0x1509a0['length']>0x0||!_0x2d88db['eventCache']['isFullyInitialized']()||_0x43a2d6&&!_0x2684f9['getNode']()['equals'](_0x54b191)||!_0x2684f9['getNode']()['getPriority']()['equals'](_0x54b191['getPriority']()))&&_0x1509a0['push'](Lo(wn(_0x19257d)));}}function Go(_0x201b30,_0x47fc33,_0x393068,_0x284230,_0x13cb79,_0x51f641){const _0x367368=_0x47fc33['eventCache'];if(Tn(_0x284230,_0x393068)!=null)return _0x47fc33;{let _0x593566,_0xea68fa;if(v(_0x393068)){if(f(_0x47fc33['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x47fc33['serverCache']['isFiltered']()){const _0x3f69cd=Ve(_0x47fc33),_0x1bbebf=_0x3f69cd instanceof g?_0x3f69cd:g['EMPTY_NODE'],_0xe17dca=is(_0x284230,_0x1bbebf);_0x593566=_0x201b30['filter']['updateFullNode'](_0x47fc33['eventCache']['getNode'](),_0xe17dca,_0x51f641);}else{const _0x1e591e=Cn(_0x284230,Ve(_0x47fc33));_0x593566=_0x201b30['filter']['updateFullNode'](_0x47fc33['eventCache']['getNode'](),_0x1e591e,_0x51f641);}}else{const _0x5dd1e0=y(_0x393068);if(_0x5dd1e0==='.priority'){f(Ce(_0x393068)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x5536ee=_0x367368['getNode']();_0xea68fa=_0x47fc33['serverCache']['getNode']();const _0x39856f=cr(_0x284230,_0x393068,_0x5536ee,_0xea68fa);_0x39856f!=null?_0x593566=_0x201b30['filter']['updatePriority'](_0x5536ee,_0x39856f):_0x593566=_0x367368['getNode']();}else{const _0x2138f6=S(_0x393068);let _0x26f8e3;if(_0x367368['isCompleteForChild'](_0x5dd1e0)){_0xea68fa=_0x47fc33['serverCache']['getNode']();const _0x12a2e4=cr(_0x284230,_0x393068,_0x367368['getNode'](),_0xea68fa);_0x12a2e4!=null?_0x26f8e3=_0x367368['getNode']()['getImmediateChild'](_0x5dd1e0)['updateChild'](_0x2138f6,_0x12a2e4):_0x26f8e3=_0x367368['getNode']()['getImmediateChild'](_0x5dd1e0);}else _0x26f8e3=ss(_0x284230,_0x5dd1e0,_0x47fc33['serverCache']);_0x26f8e3!=null?_0x593566=_0x201b30['filter']['updateChild'](_0x367368['getNode'](),_0x5dd1e0,_0x26f8e3,_0x2138f6,_0x13cb79,_0x51f641):_0x593566=_0x367368['getNode']();}}return Rt(_0x47fc33,_0x593566,_0x367368['isFullyInitialized']()||v(_0x393068),_0x201b30['filter']['filtersNodes']());}}function Sn(_0x4c76ef,_0x4be876,_0x4c88e4,_0x5b6157,_0x5ac994,_0x3659a8,_0x47986b,_0x23f35b){const _0x4c2ff1=_0x4be876['serverCache'];let _0x3942c0;const _0x4d91ab=_0x47986b?_0x4c76ef['filter']:_0x4c76ef['filter']['getIndexedFilter']();if(v(_0x4c88e4))_0x3942c0=_0x4d91ab['updateFullNode'](_0x4c2ff1['getNode'](),_0x5b6157,null);else{if(_0x4d91ab['filtersNodes']()&&!_0x4c2ff1['isFiltered']()){const _0x1eb0f9=_0x4c2ff1['getNode']()['updateChild'](_0x4c88e4,_0x5b6157);_0x3942c0=_0x4d91ab['updateFullNode'](_0x4c2ff1['getNode'](),_0x1eb0f9,null);}else{const _0x3ef015=y(_0x4c88e4);if(!_0x4c2ff1['isCompleteForPath'](_0x4c88e4)&&Ce(_0x4c88e4)>0x1)return _0x4be876;const _0x4039aa=S(_0x4c88e4),_0x62c93d=_0x4c2ff1['getNode']()['getImmediateChild'](_0x3ef015)['updateChild'](_0x4039aa,_0x5b6157);_0x3ef015==='.priority'?_0x3942c0=_0x4d91ab['updatePriority'](_0x4c2ff1['getNode'](),_0x62c93d):_0x3942c0=_0x4d91ab['updateChild'](_0x4c2ff1['getNode'](),_0x3ef015,_0x62c93d,_0x4039aa,$o,null);}}const _0x365e7b=Fo(_0x4be876,_0x3942c0,_0x4c2ff1['isFullyInitialized']()||v(_0x4c88e4),_0x4d91ab['filtersNodes']()),_0x390d82=new rs(_0x5ac994,_0x365e7b,_0x3659a8);return Go(_0x4c76ef,_0x365e7b,_0x4c88e4,_0x5ac994,_0x390d82,_0x23f35b);}function ki(_0x27ad7,_0x2e6db3,_0x23ddf0,_0x520b0e,_0x335aa3,_0x104bba,_0x10ba96){const _0x9b9af=_0x2e6db3['eventCache'];let _0x1063f9,_0x4908af;const _0x1f9248=new rs(_0x335aa3,_0x2e6db3,_0x104bba);if(v(_0x23ddf0))_0x4908af=_0x27ad7['filter']['updateFullNode'](_0x2e6db3['eventCache']['getNode'](),_0x520b0e,_0x10ba96),_0x1063f9=Rt(_0x2e6db3,_0x4908af,!0x0,_0x27ad7['filter']['filtersNodes']());else{const _0xe8edd4=y(_0x23ddf0);if(_0xe8edd4==='.priority')_0x4908af=_0x27ad7['filter']['updatePriority'](_0x2e6db3['eventCache']['getNode'](),_0x520b0e),_0x1063f9=Rt(_0x2e6db3,_0x4908af,_0x9b9af['isFullyInitialized'](),_0x9b9af['isFiltered']());else{const _0x207f7d=S(_0x23ddf0),_0x533c2f=_0x9b9af['getNode']()['getImmediateChild'](_0xe8edd4);let _0x4a662d;if(v(_0x207f7d))_0x4a662d=_0x520b0e;else{const _0x451fda=_0x1f9248['getCompleteChild'](_0xe8edd4);_0x451fda!=null?ji(_0x207f7d)==='.priority'&&_0x451fda['getChild'](Ro(_0x207f7d))['isEmpty']()?_0x4a662d=_0x451fda:_0x4a662d=_0x451fda['updateChild'](_0x207f7d,_0x520b0e):_0x4a662d=g['EMPTY_NODE'];}if(_0x533c2f['equals'](_0x4a662d))_0x1063f9=_0x2e6db3;else{const _0x8af253=_0x27ad7['filter']['updateChild'](_0x9b9af['getNode'](),_0xe8edd4,_0x4a662d,_0x207f7d,_0x1f9248,_0x10ba96);_0x1063f9=Rt(_0x2e6db3,_0x8af253,_0x9b9af['isFullyInitialized'](),_0x27ad7['filter']['filtersNodes']());}}}return _0x1063f9;}function lr(_0x1933f7,_0x20d8bb){return _0x1933f7['eventCache']['isCompleteForChild'](_0x20d8bb);}function ku(_0x2c4c5f,_0x2cec58,_0x2edb83,_0x4c7941,_0x390ed5,_0x1511f0,_0x4abca8){let _0x66a8dd=_0x2cec58;return _0x4c7941['foreach']((_0x244de3,_0x13cf01)=>{const _0x283587=k(_0x2edb83,_0x244de3);lr(_0x2cec58,y(_0x283587))&&(_0x66a8dd=ki(_0x2c4c5f,_0x66a8dd,_0x283587,_0x13cf01,_0x390ed5,_0x1511f0,_0x4abca8));}),_0x4c7941['foreach']((_0x17e876,_0x5e24bb)=>{const _0x1a8f73=k(_0x2edb83,_0x17e876);lr(_0x2cec58,y(_0x1a8f73))||(_0x66a8dd=ki(_0x2c4c5f,_0x66a8dd,_0x1a8f73,_0x5e24bb,_0x390ed5,_0x1511f0,_0x4abca8));}),_0x66a8dd;}function hr(_0xb101ee,_0x1a4ab8,_0x238f1f){return _0x238f1f['foreach']((_0x52d155,_0x2c81b5)=>{_0x1a4ab8=_0x1a4ab8['updateChild'](_0x52d155,_0x2c81b5);}),_0x1a4ab8;}function Pi(_0x1e871d,_0x1a59ba,_0x3c84ec,_0x1f4c7c,_0x2fc7a,_0x4b6507,_0x1edbbe,_0x11c81c){if(_0x1a59ba['serverCache']['getNode']()['isEmpty']()&&!_0x1a59ba['serverCache']['isFullyInitialized']())return _0x1a59ba;let _0x57c7d9=_0x1a59ba,_0xb9e712;v(_0x3c84ec)?_0xb9e712=_0x1f4c7c:_0xb9e712=new b(null)['setTree'](_0x3c84ec,_0x1f4c7c);const _0x121fc9=_0x1a59ba['serverCache']['getNode']();return _0xb9e712['children']['inorderTraversal']((_0x412746,_0x4544ad)=>{if(_0x121fc9['hasChild'](_0x412746)){const _0x44d160=_0x1a59ba['serverCache']['getNode']()['getImmediateChild'](_0x412746),_0x533635=hr(_0x1e871d,_0x44d160,_0x4544ad);_0x57c7d9=Sn(_0x1e871d,_0x57c7d9,new C(_0x412746),_0x533635,_0x2fc7a,_0x4b6507,_0x1edbbe,_0x11c81c);}}),_0xb9e712['children']['inorderTraversal']((_0x4544ea,_0x585768)=>{const _0x5afb5b=!_0x1a59ba['serverCache']['isCompleteForChild'](_0x4544ea)&&_0x585768['value']===null;if(!_0x121fc9['hasChild'](_0x4544ea)&&!_0x5afb5b){const _0x591156=_0x1a59ba['serverCache']['getNode']()['getImmediateChild'](_0x4544ea),_0x1d88c6=hr(_0x1e871d,_0x591156,_0x585768);_0x57c7d9=Sn(_0x1e871d,_0x57c7d9,new C(_0x4544ea),_0x1d88c6,_0x2fc7a,_0x4b6507,_0x1edbbe,_0x11c81c);}}),_0x57c7d9;}function Pu(_0x3305fd,_0xb91e39,_0x203003,_0x508d34,_0x369321,_0x321569,_0x3d316c){if(Tn(_0x369321,_0x203003)!=null)return _0xb91e39;const _0x32e14f=_0xb91e39['serverCache']['isFiltered'](),_0x221893=_0xb91e39['serverCache'];if(_0x508d34['value']!=null){if(v(_0x203003)&&_0x221893['isFullyInitialized']()||_0x221893['isCompleteForPath'](_0x203003))return Sn(_0x3305fd,_0xb91e39,_0x203003,_0x221893['getNode']()['getChild'](_0x203003),_0x369321,_0x321569,_0x32e14f,_0x3d316c);if(v(_0x203003)){let _0x11beed=new b(null);return _0x221893['getNode']()['forEachChild'](ve,(_0x5e2aee,_0x3eb956)=>{_0x11beed=_0x11beed['set'](new C(_0x5e2aee),_0x3eb956);}),Pi(_0x3305fd,_0xb91e39,_0x203003,_0x11beed,_0x369321,_0x321569,_0x32e14f,_0x3d316c);}else return _0xb91e39;}else{let _0x4883fa=new b(null);return _0x508d34['foreach']((_0x32aec9,_0x49c39b)=>{const _0x394b81=k(_0x203003,_0x32aec9);_0x221893['isCompleteForPath'](_0x394b81)&&(_0x4883fa=_0x4883fa['set'](_0x32aec9,_0x221893['getNode']()['getChild'](_0x394b81)));}),Pi(_0x3305fd,_0xb91e39,_0x203003,_0x4883fa,_0x369321,_0x321569,_0x32e14f,_0x3d316c);}}function Nu(_0x51f83c,_0x9a6fbb,_0x1600ad,_0x3d7742,_0x4772e7){const _0x42ccef=_0x9a6fbb['serverCache'],_0x363daa=Fo(_0x9a6fbb,_0x42ccef['getNode'](),_0x42ccef['isFullyInitialized']()||v(_0x1600ad),_0x42ccef['isFiltered']());return Go(_0x51f83c,_0x363daa,_0x1600ad,_0x3d7742,$o,_0x4772e7);}function Ou(_0x3d9d17,_0x3421ac,_0x99d123,_0x30ff8b,_0x293453,_0x137a39){let _0x1d98b4;if(Tn(_0x30ff8b,_0x99d123)!=null)return _0x3421ac;{const _0xa4201e=new rs(_0x30ff8b,_0x3421ac,_0x293453),_0x2933d7=_0x3421ac['eventCache']['getNode']();let _0x44cc63;if(v(_0x99d123)||y(_0x99d123)==='.priority'){let _0xe9fbb;if(_0x3421ac['serverCache']['isFullyInitialized']())_0xe9fbb=Cn(_0x30ff8b,Ve(_0x3421ac));else{const _0xf1f543=_0x3421ac['serverCache']['getNode']();f(_0xf1f543 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xe9fbb=is(_0x30ff8b,_0xf1f543);}_0xe9fbb=_0xe9fbb,_0x44cc63=_0x3d9d17['filter']['updateFullNode'](_0x2933d7,_0xe9fbb,_0x137a39);}else{const _0x1aa171=y(_0x99d123);let _0x300827=ss(_0x30ff8b,_0x1aa171,_0x3421ac['serverCache']);_0x300827==null&&_0x3421ac['serverCache']['isCompleteForChild'](_0x1aa171)&&(_0x300827=_0x2933d7['getImmediateChild'](_0x1aa171)),_0x300827!=null?_0x44cc63=_0x3d9d17['filter']['updateChild'](_0x2933d7,_0x1aa171,_0x300827,S(_0x99d123),_0xa4201e,_0x137a39):_0x3421ac['eventCache']['getNode']()['hasChild'](_0x1aa171)?_0x44cc63=_0x3d9d17['filter']['updateChild'](_0x2933d7,_0x1aa171,g['EMPTY_NODE'],S(_0x99d123),_0xa4201e,_0x137a39):_0x44cc63=_0x2933d7,_0x44cc63['isEmpty']()&&_0x3421ac['serverCache']['isFullyInitialized']()&&(_0x1d98b4=Cn(_0x30ff8b,Ve(_0x3421ac)),_0x1d98b4['isLeafNode']()&&(_0x44cc63=_0x3d9d17['filter']['updateFullNode'](_0x44cc63,_0x1d98b4,_0x137a39)));}return _0x1d98b4=_0x3421ac['serverCache']['isFullyInitialized']()||Tn(_0x30ff8b,w())!=null,Rt(_0x3421ac,_0x44cc63,_0x1d98b4,_0x3d9d17['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x407038,_0x204d10){this['query_']=_0x407038,this['eventRegistrations_']=[];const _0x505a3d=this['query_']['_queryParams'],_0x38ab19=new Xi(_0x505a3d['getIndex']()),_0x26b15b=Kh(_0x505a3d);this['processor_']=Su(_0x26b15b);const _0x47d1be=_0x204d10['serverCache'],_0x2eda27=_0x204d10['eventCache'],_0xcf11d6=_0x38ab19['updateFullNode'](g['EMPTY_NODE'],_0x47d1be['getNode'](),null),_0x3cd440=_0x26b15b['updateFullNode'](g['EMPTY_NODE'],_0x2eda27['getNode'](),null),_0x199059=new Te(_0xcf11d6,_0x47d1be['isFullyInitialized'](),_0x38ab19['filtersNodes']()),_0xbe93b7=new Te(_0x3cd440,_0x2eda27['isFullyInitialized'](),_0x26b15b['filtersNodes']());this['viewCache_']=Un(_0xbe93b7,_0x199059),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2b0f2e){return _0x2b0f2e['viewCache_']['serverCache']['getNode']();}function Lu(_0x5c2111){return wn(_0x5c2111['viewCache_']);}function xu(_0x1329bb,_0x507f4b){const _0x411921=Ve(_0x1329bb['viewCache_']);return _0x411921&&(_0x1329bb['query']['_queryParams']['loadsAllData']()||!v(_0x507f4b)&&!_0x411921['getImmediateChild'](y(_0x507f4b))['isEmpty']())?_0x411921['getChild'](_0x507f4b):null;}function ur(_0x5267d8){return _0x5267d8['eventRegistrations_']['length']===0x0;}function Fu(_0x47e9b1,_0x3dd676){_0x47e9b1['eventRegistrations_']['push'](_0x3dd676);}function dr(_0x2e72ef,_0x6cfa57,_0x17b498){const _0x5b6c96=[];if(_0x17b498){f(_0x6cfa57==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x15c373=_0x2e72ef['query']['_path'];_0x2e72ef['eventRegistrations_']['forEach'](_0x1d0e98=>{const _0x43c043=_0x1d0e98['createCancelEvent'](_0x17b498,_0x15c373);_0x43c043&&_0x5b6c96['push'](_0x43c043);});}if(_0x6cfa57){let _0x13ea5c=[];for(let _0x2c2162=0x0;_0x2c2162<_0x2e72ef['eventRegistrations_']['length'];++_0x2c2162){const _0x3b7c45=_0x2e72ef['eventRegistrations_'][_0x2c2162];if(!_0x3b7c45['matches'](_0x6cfa57))_0x13ea5c['push'](_0x3b7c45);else{if(_0x6cfa57['hasAnyCallback']()){_0x13ea5c=_0x13ea5c['concat'](_0x2e72ef['eventRegistrations_']['slice'](_0x2c2162+0x1));break;}}}_0x2e72ef['eventRegistrations_']=_0x13ea5c;}else _0x2e72ef['eventRegistrations_']=[];return _0x5b6c96;}function fr(_0x5f0beb,_0x4868ac,_0x181a19,_0x5087ff){_0x4868ac['type']===z['MERGE']&&_0x4868ac['source']['queryId']!==null&&(f(Ve(_0x5f0beb['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x5f0beb['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x19065a=_0x5f0beb['viewCache_'],_0xb60a27=Ru(_0x5f0beb['processor_'],_0x19065a,_0x4868ac,_0x181a19,_0x5087ff);return bu(_0x5f0beb['processor_'],_0xb60a27['viewCache']),f(_0xb60a27['viewCache']['serverCache']['isFullyInitialized']()||!_0x19065a['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5f0beb['viewCache_']=_0xb60a27['viewCache'],qo(_0x5f0beb,_0xb60a27['changes'],_0xb60a27['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x46bb85,_0x1e9771){const _0x1a7832=_0x46bb85['viewCache_']['eventCache'],_0x41eca6=[];return _0x1a7832['getNode']()['isLeafNode']()||_0x1a7832['getNode']()['forEachChild'](R,(_0xa70736,_0x296f48)=>{_0x41eca6['push'](rt(_0xa70736,_0x296f48));}),_0x1a7832['isFullyInitialized']()&&_0x41eca6['push'](Lo(_0x1a7832['getNode']())),qo(_0x46bb85,_0x41eca6,_0x1a7832['getNode'](),_0x1e9771);}function qo(_0x4834e5,_0x35f579,_0x375e9d,_0x2ef955){const _0x2f5fda=_0x2ef955?[_0x2ef955]:_0x4834e5['eventRegistrations_'];return ru(_0x4834e5['eventGenerator_'],_0x35f579,_0x375e9d,_0x2f5fda);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x596da9){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x596da9;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x298911){return _0x298911['views']['size']===0x0;}function os(_0x35100d,_0x208d33,_0x59f8c6,_0x3e9883){const _0x568f6a=_0x208d33['source']['queryId'];if(_0x568f6a!==null){const _0x7e4ae5=_0x35100d['views']['get'](_0x568f6a);return f(_0x7e4ae5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x7e4ae5,_0x208d33,_0x59f8c6,_0x3e9883);}else{let _0x467124=[];for(const _0x35e350 of _0x35100d['views']['values']())_0x467124=_0x467124['concat'](fr(_0x35e350,_0x208d33,_0x59f8c6,_0x3e9883));return _0x467124;}}function jo(_0x31193a,_0x5d51c0,_0x3c8e63,_0x17de04,_0x3d8b39){const _0x59eda6=_0x5d51c0['_queryIdentifier'],_0x28f960=_0x31193a['views']['get'](_0x59eda6);if(!_0x28f960){let _0x14de17=Cn(_0x3c8e63,_0x3d8b39?_0x17de04:null),_0x5d0b1a=!0x1;_0x14de17?_0x5d0b1a=!0x0:_0x17de04 instanceof g?(_0x14de17=is(_0x3c8e63,_0x17de04),_0x5d0b1a=!0x1):(_0x14de17=g['EMPTY_NODE'],_0x5d0b1a=!0x1);const _0x110abf=Un(new Te(_0x14de17,_0x5d0b1a,!0x1),new Te(_0x17de04,_0x3d8b39,!0x1));return new Du(_0x5d51c0,_0x110abf);}return _0x28f960;}function Hu(_0x3703d8,_0xe70825,_0x11e072,_0x1c373c,_0xc2c20c,_0x26a68f){const _0x28f404=jo(_0x3703d8,_0xe70825,_0x1c373c,_0xc2c20c,_0x26a68f);return _0x3703d8['views']['has'](_0xe70825['_queryIdentifier'])||_0x3703d8['views']['set'](_0xe70825['_queryIdentifier'],_0x28f404),Fu(_0x28f404,_0x11e072),Uu(_0x28f404,_0x11e072);}function $u(_0x41be40,_0x4e3304,_0x3fc9b9,_0x46d163){const _0x57046a=_0x4e3304['_queryIdentifier'],_0x42e9dc=[];let _0x1c9399=[];const _0x5bfa86=Se(_0x41be40);if(_0x57046a==='default'){for(const [_0x4ad9e9,_0x95e3a2]of _0x41be40['views']['entries']())_0x1c9399=_0x1c9399['concat'](dr(_0x95e3a2,_0x3fc9b9,_0x46d163)),ur(_0x95e3a2)&&(_0x41be40['views']['delete'](_0x4ad9e9),_0x95e3a2['query']['_queryParams']['loadsAllData']()||_0x42e9dc['push'](_0x95e3a2['query']));}else{const _0x106db=_0x41be40['views']['get'](_0x57046a);_0x106db&&(_0x1c9399=_0x1c9399['concat'](dr(_0x106db,_0x3fc9b9,_0x46d163)),ur(_0x106db)&&(_0x41be40['views']['delete'](_0x57046a),_0x106db['query']['_queryParams']['loadsAllData']()||_0x42e9dc['push'](_0x106db['query'])));}return _0x5bfa86&&!Se(_0x41be40)&&_0x42e9dc['push'](new(Bu())(_0x4e3304['_repo'],_0x4e3304['_path'])),{'removed':_0x42e9dc,'events':_0x1c9399};}function Ko(_0x4e8153){const _0x20337c=[];for(const _0x22f64f of _0x4e8153['views']['values']())_0x22f64f['query']['_queryParams']['loadsAllData']()||_0x20337c['push'](_0x22f64f);return _0x20337c;}function Ie(_0x2ded5d,_0x211eab){let _0x5f13cb=null;for(const _0x5319f8 of _0x2ded5d['views']['values']())_0x5f13cb=_0x5f13cb||xu(_0x5319f8,_0x211eab);return _0x5f13cb;}function Yo(_0x1e9718,_0x519d6f){if(_0x519d6f['_queryParams']['loadsAllData']())return Bn(_0x1e9718);{const _0x18420d=_0x519d6f['_queryIdentifier'];return _0x1e9718['views']['get'](_0x18420d);}}function Qo(_0xdca514,_0x1944f8){return Yo(_0xdca514,_0x1944f8)!=null;}function Se(_0x5543cb){return Bn(_0x5543cb)!=null;}function Bn(_0x39e7c1){for(const _0x536fbd of _0x39e7c1['views']['values']())if(_0x536fbd['query']['_queryParams']['loadsAllData']())return _0x536fbd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3a51be){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3a51be;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2260b0){this['listenProvider_']=_0x2260b0,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x322a73,_0x5c387e,_0x4fe9a2,_0x3f8de0,_0x5be40d){return lu(_0x322a73['pendingWriteTree_'],_0x5c387e,_0x4fe9a2,_0x3f8de0,_0x5be40d),_0x5be40d?_t(_0x322a73,new Be(es(),_0x5c387e,_0x4fe9a2)):[];}function ju(_0x58ff9f,_0x48cbc0,_0x35b07f,_0x2507cc){hu(_0x58ff9f['pendingWriteTree_'],_0x48cbc0,_0x35b07f,_0x2507cc);const _0xf9e257=b['fromObject'](_0x35b07f);return _t(_0x58ff9f,new ot(es(),_0x48cbc0,_0xf9e257));}function _e(_0x4c4f59,_0x45de3f,_0x37c6af=!0x1){const _0x3f4736=uu(_0x4c4f59['pendingWriteTree_'],_0x45de3f);if(du(_0x4c4f59['pendingWriteTree_'],_0x45de3f)){let _0x566c2b=new b(null);return _0x3f4736['snap']!=null?_0x566c2b=_0x566c2b['set'](w(),!0x0):x(_0x3f4736['children'],_0x2a0644=>{_0x566c2b=_0x566c2b['set'](new C(_0x2a0644),!0x0);}),_t(_0x4c4f59,new In(_0x3f4736['path'],_0x566c2b,_0x37c6af));}else return[];}function Yt(_0x1d449d,_0x165504,_0x54077f){return _t(_0x1d449d,new Be(ts(),_0x165504,_0x54077f));}function Ku(_0xa1a791,_0x3d3fa3,_0x3309fc){const _0x1e527f=b['fromObject'](_0x3309fc);return _t(_0xa1a791,new ot(ts(),_0x3d3fa3,_0x1e527f));}function Yu(_0x51226b,_0x193f20){return _t(_0x51226b,new Ut(ts(),_0x193f20));}function Qu(_0x2f9b4e,_0x4ce321,_0x5c9cb6){const _0x13a892=cs(_0x2f9b4e,_0x5c9cb6);if(_0x13a892){const _0x20a4e3=ls(_0x13a892),_0x1d175c=_0x20a4e3['path'],_0x56d12e=_0x20a4e3['queryId'],_0x43f3e1=F(_0x1d175c,_0x4ce321),_0xf02e95=new Ut(ns(_0x56d12e),_0x43f3e1);return hs(_0x2f9b4e,_0x1d175c,_0xf02e95);}else return[];}function An(_0x11a95f,_0x41faa0,_0x2fcf2e,_0xb1b3c5,_0x3a614c=!0x1){const _0x3f07cf=_0x41faa0['_path'],_0x2ea19c=_0x11a95f['syncPointTree_']['get'](_0x3f07cf);let _0x536362=[];if(_0x2ea19c&&(_0x41faa0['_queryIdentifier']==='default'||Qo(_0x2ea19c,_0x41faa0))){const _0x219075=$u(_0x2ea19c,_0x41faa0,_0x2fcf2e,_0xb1b3c5);Vu(_0x2ea19c)&&(_0x11a95f['syncPointTree_']=_0x11a95f['syncPointTree_']['remove'](_0x3f07cf));const _0x605d3e=_0x219075['removed'];if(_0x536362=_0x219075['events'],!_0x3a614c){const _0x451a6f=_0x605d3e['findIndex'](_0x5ab9ff=>_0x5ab9ff['_queryParams']['loadsAllData']())!==-0x1,_0x5bf404=_0x11a95f['syncPointTree_']['findOnPath'](_0x3f07cf,(_0x2ac9e3,_0x3778a7)=>Se(_0x3778a7));if(_0x451a6f&&!_0x5bf404){const _0x1527e6=_0x11a95f['syncPointTree_']['subtree'](_0x3f07cf);if(!_0x1527e6['isEmpty']()){const _0xec1259=Zu(_0x1527e6);for(let _0x243b4e=0x0;_0x243b4e<_0xec1259['length'];++_0x243b4e){const _0x438227=_0xec1259[_0x243b4e],_0x3198c3=_0x438227['query'],_0x41423c=ea(_0x11a95f,_0x438227);_0x11a95f['listenProvider_']['startListening'](kt(_0x3198c3),Wt(_0x11a95f,_0x3198c3),_0x41423c['hashFn'],_0x41423c['onComplete']);}}}!_0x5bf404&&_0x605d3e['length']>0x0&&!_0xb1b3c5&&(_0x451a6f?_0x11a95f['listenProvider_']['stopListening'](kt(_0x41faa0),null):_0x605d3e['forEach'](_0x68ca24=>{const _0x1c9513=_0x11a95f['queryToTagMap']['get'](Hn(_0x68ca24));_0x11a95f['listenProvider_']['stopListening'](kt(_0x68ca24),_0x1c9513);}));}ed(_0x11a95f,_0x605d3e);}return _0x536362;}function Jo(_0x2f7908,_0x21fd36,_0x519259,_0x2ba6c2){const _0x21d008=cs(_0x2f7908,_0x2ba6c2);if(_0x21d008!=null){const _0x3da303=ls(_0x21d008),_0x5a8cb9=_0x3da303['path'],_0x2426dd=_0x3da303['queryId'],_0x181d6d=F(_0x5a8cb9,_0x21fd36),_0x389d26=new Be(ns(_0x2426dd),_0x181d6d,_0x519259);return hs(_0x2f7908,_0x5a8cb9,_0x389d26);}else return[];}function Ju(_0xdbed56,_0xbe6237,_0x2b56d2,_0x226935){const _0x4606f2=cs(_0xdbed56,_0x226935);if(_0x4606f2){const _0x116df0=ls(_0x4606f2),_0x1f26bb=_0x116df0['path'],_0x29b898=_0x116df0['queryId'],_0x5c31ca=F(_0x1f26bb,_0xbe6237),_0x111c2b=b['fromObject'](_0x2b56d2),_0x5df140=new ot(ns(_0x29b898),_0x5c31ca,_0x111c2b);return hs(_0xdbed56,_0x1f26bb,_0x5df140);}else return[];}function Ni(_0x5e536d,_0x4a3078,_0x1dd244,_0x28f1bb=!0x1){const _0x62b2a3=_0x4a3078['_path'];let _0x4824c4=null,_0x3e58ee=!0x1;_0x5e536d['syncPointTree_']['foreachOnPath'](_0x62b2a3,(_0x4b9b58,_0x1f9191)=>{const _0xf398ed=F(_0x4b9b58,_0x62b2a3);_0x4824c4=_0x4824c4||Ie(_0x1f9191,_0xf398ed),_0x3e58ee=_0x3e58ee||Se(_0x1f9191);});let _0x120581=_0x5e536d['syncPointTree_']['get'](_0x62b2a3);_0x120581?(_0x3e58ee=_0x3e58ee||Se(_0x120581),_0x4824c4=_0x4824c4||Ie(_0x120581,w())):(_0x120581=new zo(),_0x5e536d['syncPointTree_']=_0x5e536d['syncPointTree_']['set'](_0x62b2a3,_0x120581));let _0x5371e3;_0x4824c4!=null?_0x5371e3=!0x0:(_0x5371e3=!0x1,_0x4824c4=g['EMPTY_NODE'],_0x5e536d['syncPointTree_']['subtree'](_0x62b2a3)['foreachChild']((_0x30a13f,_0x288617)=>{const _0x40e3ab=Ie(_0x288617,w());_0x40e3ab&&(_0x4824c4=_0x4824c4['updateImmediateChild'](_0x30a13f,_0x40e3ab));}));const _0x8e5be9=Qo(_0x120581,_0x4a3078);if(!_0x8e5be9&&!_0x4a3078['_queryParams']['loadsAllData']()){const _0x5ecb11=Hn(_0x4a3078);f(!_0x5e536d['queryToTagMap']['has'](_0x5ecb11),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xc5b442=td();_0x5e536d['queryToTagMap']['set'](_0x5ecb11,_0xc5b442),_0x5e536d['tagToQueryMap']['set'](_0xc5b442,_0x5ecb11);}const _0x2f75a6=Wn(_0x5e536d['pendingWriteTree_'],_0x62b2a3);let _0x5b17d9=Hu(_0x120581,_0x4a3078,_0x1dd244,_0x2f75a6,_0x4824c4,_0x5371e3);if(!_0x8e5be9&&!_0x3e58ee&&!_0x28f1bb){const _0x1e9d95=Yo(_0x120581,_0x4a3078);_0x5b17d9=_0x5b17d9['concat'](nd(_0x5e536d,_0x4a3078,_0x1e9d95));}return _0x5b17d9;}function Vn(_0x3fb7e7,_0x5d0114,_0x3c2c50){const _0x5c7849=_0x3fb7e7['pendingWriteTree_'],_0x279c8d=_0x3fb7e7['syncPointTree_']['findOnPath'](_0x5d0114,(_0x5ababa,_0x1f9efb)=>{const _0x5ea075=F(_0x5ababa,_0x5d0114),_0x219221=Ie(_0x1f9efb,_0x5ea075);if(_0x219221)return _0x219221;});return Bo(_0x5c7849,_0x5d0114,_0x279c8d,_0x3c2c50,!0x0);}function Xu(_0x39b1d7,_0x1234fe){const _0x68a627=_0x1234fe['_path'];let _0x4d30fb=null;_0x39b1d7['syncPointTree_']['foreachOnPath'](_0x68a627,(_0x486a41,_0x5d429c)=>{const _0x5a09f9=F(_0x486a41,_0x68a627);_0x4d30fb=_0x4d30fb||Ie(_0x5d429c,_0x5a09f9);});let _0x416a2d=_0x39b1d7['syncPointTree_']['get'](_0x68a627);_0x416a2d?_0x4d30fb=_0x4d30fb||Ie(_0x416a2d,w()):(_0x416a2d=new zo(),_0x39b1d7['syncPointTree_']=_0x39b1d7['syncPointTree_']['set'](_0x68a627,_0x416a2d));const _0xaaccd9=_0x4d30fb!=null,_0x53ef92=_0xaaccd9?new Te(_0x4d30fb,!0x0,!0x1):null,_0x93493f=Wn(_0x39b1d7['pendingWriteTree_'],_0x1234fe['_path']),_0x428643=jo(_0x416a2d,_0x1234fe,_0x93493f,_0xaaccd9?_0x53ef92['getNode']():g['EMPTY_NODE'],_0xaaccd9);return Lu(_0x428643);}function _t(_0x5d697d,_0x3e95c8){return Xo(_0x3e95c8,_0x5d697d['syncPointTree_'],null,Wn(_0x5d697d['pendingWriteTree_'],w()));}function Xo(_0xfcbe52,_0x44206f,_0x2511e4,_0x38f0a2){if(v(_0xfcbe52['path']))return Zo(_0xfcbe52,_0x44206f,_0x2511e4,_0x38f0a2);{const _0x353454=_0x44206f['get'](w());_0x2511e4==null&&_0x353454!=null&&(_0x2511e4=Ie(_0x353454,w()));let _0x3d78b2=[];const _0x2b85a0=y(_0xfcbe52['path']),_0x25b5b3=_0xfcbe52['operationForChild'](_0x2b85a0),_0x5a13b7=_0x44206f['children']['get'](_0x2b85a0);if(_0x5a13b7&&_0x25b5b3){const _0x171902=_0x2511e4?_0x2511e4['getImmediateChild'](_0x2b85a0):null,_0x590a80=Vo(_0x38f0a2,_0x2b85a0);_0x3d78b2=_0x3d78b2['concat'](Xo(_0x25b5b3,_0x5a13b7,_0x171902,_0x590a80));}return _0x353454&&(_0x3d78b2=_0x3d78b2['concat'](os(_0x353454,_0xfcbe52,_0x38f0a2,_0x2511e4))),_0x3d78b2;}}function Zo(_0x5074e4,_0x5353d1,_0x13ee1c,_0x647801){const _0x493dff=_0x5353d1['get'](w());_0x13ee1c==null&&_0x493dff!=null&&(_0x13ee1c=Ie(_0x493dff,w()));let _0x15d4eb=[];return _0x5353d1['children']['inorderTraversal']((_0x32eddf,_0x452777)=>{const _0x30a989=_0x13ee1c?_0x13ee1c['getImmediateChild'](_0x32eddf):null,_0x1dc229=Vo(_0x647801,_0x32eddf),_0x189b99=_0x5074e4['operationForChild'](_0x32eddf);_0x189b99&&(_0x15d4eb=_0x15d4eb['concat'](Zo(_0x189b99,_0x452777,_0x30a989,_0x1dc229)));}),_0x493dff&&(_0x15d4eb=_0x15d4eb['concat'](os(_0x493dff,_0x5074e4,_0x647801,_0x13ee1c))),_0x15d4eb;}function ea(_0x554c06,_0x2c5148){const _0xe9950e=_0x2c5148['query'],_0x4c9296=Wt(_0x554c06,_0xe9950e);return{'hashFn':()=>(Mu(_0x2c5148)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x26599b=>{if(_0x26599b==='ok')return _0x4c9296?Qu(_0x554c06,_0xe9950e['_path'],_0x4c9296):Yu(_0x554c06,_0xe9950e['_path']);{const _0x5457cb=Kl(_0x26599b,_0xe9950e);return An(_0x554c06,_0xe9950e,null,_0x5457cb);}}};}function Wt(_0x22b0dd,_0x400646){const _0x321f25=Hn(_0x400646);return _0x22b0dd['queryToTagMap']['get'](_0x321f25);}function Hn(_0x1c4454){return _0x1c4454['_path']['toString']()+'$'+_0x1c4454['_queryIdentifier'];}function cs(_0x27d588,_0x423237){return _0x27d588['tagToQueryMap']['get'](_0x423237);}function ls(_0x4946f0){const _0x1aeee6=_0x4946f0['indexOf']('$');return f(_0x1aeee6!==-0x1&&_0x1aeee6<_0x4946f0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4946f0['substr'](_0x1aeee6+0x1),'path':new C(_0x4946f0['substr'](0x0,_0x1aeee6))};}function hs(_0x4b9688,_0x36f586,_0x5bb8fc){const _0x5635a0=_0x4b9688['syncPointTree_']['get'](_0x36f586);f(_0x5635a0,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1df4df=Wn(_0x4b9688['pendingWriteTree_'],_0x36f586);return os(_0x5635a0,_0x5bb8fc,_0x1df4df,null);}function Zu(_0x52d3ff){return _0x52d3ff['fold']((_0x260230,_0x3e10fd,_0x53f986)=>{if(_0x3e10fd&&Se(_0x3e10fd))return[Bn(_0x3e10fd)];{let _0x302df3=[];return _0x3e10fd&&(_0x302df3=Ko(_0x3e10fd)),x(_0x53f986,(_0x94619b,_0x8c19e1)=>{_0x302df3=_0x302df3['concat'](_0x8c19e1);}),_0x302df3;}});}function kt(_0x358bef){return _0x358bef['_queryParams']['loadsAllData']()&&!_0x358bef['_queryParams']['isDefault']()?new(qu())(_0x358bef['_repo'],_0x358bef['_path']):_0x358bef;}function ed(_0x3dc7b3,_0x1bf6a2){for(let _0x1e5384=0x0;_0x1e5384<_0x1bf6a2['length'];++_0x1e5384){const _0x1cdbbd=_0x1bf6a2[_0x1e5384];if(!_0x1cdbbd['_queryParams']['loadsAllData']()){const _0x4a0819=Hn(_0x1cdbbd),_0x5adbaf=_0x3dc7b3['queryToTagMap']['get'](_0x4a0819);_0x3dc7b3['queryToTagMap']['delete'](_0x4a0819),_0x3dc7b3['tagToQueryMap']['delete'](_0x5adbaf);}}}function td(){return zu++;}function nd(_0x413674,_0x7b89c9,_0x8c1d54){const _0x4e2ba5=_0x7b89c9['_path'],_0x5ca3ff=Wt(_0x413674,_0x7b89c9),_0x47b632=ea(_0x413674,_0x8c1d54),_0x46ef68=_0x413674['listenProvider_']['startListening'](kt(_0x7b89c9),_0x5ca3ff,_0x47b632['hashFn'],_0x47b632['onComplete']),_0x1f58e2=_0x413674['syncPointTree_']['subtree'](_0x4e2ba5);if(_0x5ca3ff)f(!Se(_0x1f58e2['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3e65ff=_0x1f58e2['fold']((_0x111a61,_0x57f628,_0x50deb8)=>{if(!v(_0x111a61)&&_0x57f628&&Se(_0x57f628))return[Bn(_0x57f628)['query']];{let _0x310e12=[];return _0x57f628&&(_0x310e12=_0x310e12['concat'](Ko(_0x57f628)['map'](_0x1179c4=>_0x1179c4['query']))),x(_0x50deb8,(_0x496723,_0x56fa1a)=>{_0x310e12=_0x310e12['concat'](_0x56fa1a);}),_0x310e12;}});for(let _0x3a2c65=0x0;_0x3a2c65<_0x3e65ff['length'];++_0x3a2c65){const _0x36a253=_0x3e65ff[_0x3a2c65];_0x413674['listenProvider_']['stopListening'](kt(_0x36a253),Wt(_0x413674,_0x36a253));}}return _0x46ef68;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x4ef721){this['node_']=_0x4ef721;}['getImmediateChild'](_0x30bf98){const _0x5da797=this['node_']['getImmediateChild'](_0x30bf98);return new us(_0x5da797);}['node'](){return this['node_'];}}class ds{constructor(_0x42487a,_0x26de3d){this['syncTree_']=_0x42487a,this['path_']=_0x26de3d;}['getImmediateChild'](_0x59a1b5){const _0x1dcc93=k(this['path_'],_0x59a1b5);return new ds(this['syncTree_'],_0x1dcc93);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x1bde4e){return _0x1bde4e=_0x1bde4e||{},_0x1bde4e['timestamp']=_0x1bde4e['timestamp']||new Date()['getTime'](),_0x1bde4e;},_r=function(_0x1449a7,_0x47ab63,_0x32c3e2){if(!_0x1449a7||typeof _0x1449a7!='object')return _0x1449a7;if(f('.sv'in _0x1449a7,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1449a7['.sv']=='string')return sd(_0x1449a7['.sv'],_0x47ab63,_0x32c3e2);if(typeof _0x1449a7['.sv']=='object')return rd(_0x1449a7['.sv'],_0x47ab63);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1449a7,null,0x2));},sd=function(_0x3fecd0,_0x5e2241,_0x4ce246){switch(_0x3fecd0){case'timestamp':return _0x4ce246['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3fecd0);}},rd=function(_0x407339,_0x2f7d2c,_0xe607ab){_0x407339['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x407339,null,0x2));const _0xd855db=_0x407339['increment'];typeof _0xd855db!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xd855db);const _0x3d4084=_0x2f7d2c['node']();if(f(_0x3d4084!==null&&typeof _0x3d4084<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3d4084['isLeafNode']())return _0xd855db;const _0x9513c1=_0x3d4084['getValue']();return typeof _0x9513c1!='number'?_0xd855db:_0x9513c1+_0xd855db;},ta=function(_0x49df4c,_0x74336,_0x3a80bd,_0x41fc4f){return ps(_0x74336,new ds(_0x3a80bd,_0x49df4c),_0x41fc4f);},fs=function(_0x93eccd,_0x4a8f0d,_0x5bbcd0){return ps(_0x93eccd,new us(_0x4a8f0d),_0x5bbcd0);};function ps(_0x45c36d,_0x3c409e,_0x27e91b){const _0x503f51=_0x45c36d['getPriority']()['val'](),_0xa4d15b=_r(_0x503f51,_0x3c409e['getImmediateChild']('.priority'),_0x27e91b);let _0x1d5e1b;if(_0x45c36d['isLeafNode']()){const _0x3422b0=_0x45c36d,_0x26c52b=_r(_0x3422b0['getValue'](),_0x3c409e,_0x27e91b);return _0x26c52b!==_0x3422b0['getValue']()||_0xa4d15b!==_0x3422b0['getPriority']()['val']()?new D(_0x26c52b,A(_0xa4d15b)):_0x45c36d;}else{const _0x46212f=_0x45c36d;return _0x1d5e1b=_0x46212f,_0xa4d15b!==_0x46212f['getPriority']()['val']()&&(_0x1d5e1b=_0x1d5e1b['updatePriority'](new D(_0xa4d15b))),_0x46212f['forEachChild'](R,(_0x548be5,_0x134618)=>{const _0x4197ca=ps(_0x134618,_0x3c409e['getImmediateChild'](_0x548be5),_0x27e91b);_0x4197ca!==_0x134618&&(_0x1d5e1b=_0x1d5e1b['updateImmediateChild'](_0x548be5,_0x4197ca));}),_0x1d5e1b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x236575='',_0x367cd7=null,_0x5ac6d8={'children':{},'childCount':0x0}){this['name']=_0x236575,this['parent']=_0x367cd7,this['node']=_0x5ac6d8;}}function $n(_0x387d64,_0x4eb854){let _0xd9ddec=_0x4eb854 instanceof C?_0x4eb854:new C(_0x4eb854),_0x83768f=_0x387d64,_0xf2e46a=y(_0xd9ddec);for(;_0xf2e46a!==null;){const _0x3c0eba=Le(_0x83768f['node']['children'],_0xf2e46a)||{'children':{},'childCount':0x0};_0x83768f=new _s(_0xf2e46a,_0x83768f,_0x3c0eba),_0xd9ddec=S(_0xd9ddec),_0xf2e46a=y(_0xd9ddec);}return _0x83768f;}function je(_0x387130){return _0x387130['node']['value'];}function gs(_0x49804a,_0x2f1dea){_0x49804a['node']['value']=_0x2f1dea,Oi(_0x49804a);}function na(_0x109f29){return _0x109f29['node']['childCount']>0x0;}function od(_0x1bd3a0){return je(_0x1bd3a0)===void 0x0&&!na(_0x1bd3a0);}function Gn(_0x32953e,_0x3356f4){x(_0x32953e['node']['children'],(_0x4e779a,_0x5374ae)=>{_0x3356f4(new _s(_0x4e779a,_0x32953e,_0x5374ae));});}function ia(_0x2a6b4e,_0x208719,_0x1e9e16,_0x492eaf){_0x1e9e16&&_0x208719(_0x2a6b4e),Gn(_0x2a6b4e,_0x26c772=>{ia(_0x26c772,_0x208719,!0x0);});}function ad(_0x554dce,_0x3bc2dc,_0x53aa36){let _0x366f80=_0x554dce['parent'];for(;_0x366f80!==null;){if(_0x3bc2dc(_0x366f80))return!0x0;_0x366f80=_0x366f80['parent'];}return!0x1;}function Qt(_0x5a430e){return new C(_0x5a430e['parent']===null?_0x5a430e['name']:Qt(_0x5a430e['parent'])+'/'+_0x5a430e['name']);}function Oi(_0x59c521){_0x59c521['parent']!==null&&cd(_0x59c521['parent'],_0x59c521['name'],_0x59c521);}function cd(_0x3200c4,_0x124b29,_0x272351){const _0x353def=od(_0x272351),_0x46809f=Q(_0x3200c4['node']['children'],_0x124b29);_0x353def&&_0x46809f?(delete _0x3200c4['node']['children'][_0x124b29],_0x3200c4['node']['childCount']--,Oi(_0x3200c4)):!_0x353def&&!_0x46809f&&(_0x3200c4['node']['children'][_0x124b29]=_0x272351['node'],_0x3200c4['node']['childCount']++,Oi(_0x3200c4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x511a5f){return typeof _0x511a5f=='string'&&_0x511a5f['length']!==0x0&&!ld['test'](_0x511a5f);},sa=function(_0x484a84){return typeof _0x484a84=='string'&&_0x484a84['length']!==0x0&&!hd['test'](_0x484a84);},ud=function(_0x512d00){return _0x512d00&&(_0x512d00=_0x512d00['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x512d00);},Bt=function(_0x8cb926){return _0x8cb926===null||typeof _0x8cb926=='string'||typeof _0x8cb926=='number'&&!xn(_0x8cb926)||_0x8cb926&&typeof _0x8cb926=='object'&&Q(_0x8cb926,'.sv');},He=function(_0x5b9b17,_0x323f7e,_0x4ffb03,_0x359845){_0x359845&&_0x323f7e===void 0x0||Jt(it(_0x5b9b17,'value'),_0x323f7e,_0x4ffb03);},Jt=function(_0x2d52c4,_0x5b2397,_0x215171){const _0x217b1a=_0x215171 instanceof C?new Ah(_0x215171,_0x2d52c4):_0x215171;if(_0x5b2397===void 0x0)throw new Error(_0x2d52c4+'contains\x20undefined\x20'+Oe(_0x217b1a));if(typeof _0x5b2397=='function')throw new Error(_0x2d52c4+'contains\x20a\x20function\x20'+Oe(_0x217b1a)+'\x20with\x20contents\x20=\x20'+_0x5b2397['toString']());if(xn(_0x5b2397))throw new Error(_0x2d52c4+'contains\x20'+_0x5b2397['toString']()+'\x20'+Oe(_0x217b1a));if(typeof _0x5b2397=='string'&&_0x5b2397['length']>ui/0x3&&Ln(_0x5b2397)>ui)throw new Error(_0x2d52c4+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x217b1a)+'\x20(\x27'+_0x5b2397['substring'](0x0,0x32)+'...\x27)');if(_0x5b2397&&typeof _0x5b2397=='object'){let _0x3aeca7=!0x1,_0x557472=!0x1;if(x(_0x5b2397,(_0x15487c,_0x536453)=>{if(_0x15487c==='.value')_0x3aeca7=!0x0;else{if(_0x15487c!=='.priority'&&_0x15487c!=='.sv'&&(_0x557472=!0x0,!ms(_0x15487c)))throw new Error(_0x2d52c4+'\x20contains\x20an\x20invalid\x20key\x20('+_0x15487c+')\x20'+Oe(_0x217b1a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x217b1a,_0x15487c),Jt(_0x2d52c4,_0x536453,_0x217b1a),Ph(_0x217b1a);}),_0x3aeca7&&_0x557472)throw new Error(_0x2d52c4+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x217b1a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1ce7f8,_0x9b6ce8){let _0x4f1f94,_0x379efe;for(_0x4f1f94=0x0;_0x4f1f94<_0x9b6ce8['length'];_0x4f1f94++){_0x379efe=_0x9b6ce8[_0x4f1f94];const _0x186ba8=Mt(_0x379efe);for(let _0x4e358f=0x0;_0x4e358f<_0x186ba8['length'];_0x4e358f++)if(!(_0x186ba8[_0x4e358f]==='.priority'&&_0x4e358f===_0x186ba8['length']-0x1)){if(!ms(_0x186ba8[_0x4e358f]))throw new Error(_0x1ce7f8+'contains\x20an\x20invalid\x20key\x20('+_0x186ba8[_0x4e358f]+')\x20in\x20path\x20'+_0x379efe['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x9b6ce8['sort'](Rh);let _0x3c0744=null;for(_0x4f1f94=0x0;_0x4f1f94<_0x9b6ce8['length'];_0x4f1f94++){if(_0x379efe=_0x9b6ce8[_0x4f1f94],_0x3c0744!==null&&G(_0x3c0744,_0x379efe))throw new Error(_0x1ce7f8+'contains\x20a\x20path\x20'+_0x3c0744['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x379efe['toString']());_0x3c0744=_0x379efe;}},ra=function(_0x205a41,_0x1e2f4c,_0x12b768,_0x1b6daa){const _0x4e273b=it(_0x205a41,'values');if(!(_0x1e2f4c&&typeof _0x1e2f4c=='object')||Array['isArray'](_0x1e2f4c))throw new Error(_0x4e273b+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x570943=[];x(_0x1e2f4c,(_0x5c56cc,_0x84f0aa)=>{const _0x587c41=new C(_0x5c56cc);if(Jt(_0x4e273b,_0x84f0aa,k(_0x12b768,_0x587c41)),ji(_0x587c41)==='.priority'&&!Bt(_0x84f0aa))throw new Error(_0x4e273b+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x587c41['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x570943['push'](_0x587c41);}),dd(_0x4e273b,_0x570943);},fd=function(_0x28d24a,_0x42c538,_0x251c5f){if(xn(_0x42c538))throw new Error(it(_0x28d24a,'priority')+'is\x20'+_0x42c538['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x42c538))throw new Error(it(_0x28d24a,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x7efb99,_0x3524fb,_0x3e8ca0,_0x277c1f){if(!sa(_0x3e8ca0))throw new Error(it(_0x7efb99,_0x3524fb)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3e8ca0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x384e65,_0x12ed7f,_0xf624cd,_0x1a36ef){_0xf624cd&&(_0xf624cd=_0xf624cd['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x384e65,_0x12ed7f,_0xf624cd);},Me=function(_0x598261,_0x5c85c6){if(y(_0x5c85c6)==='.info')throw new Error(_0x598261+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3d7fd1,_0x56a0dc){const _0x370a5f=_0x56a0dc['path']['toString']();if(typeof _0x56a0dc['repoInfo']['host']!='string'||_0x56a0dc['repoInfo']['host']['length']===0x0||!ms(_0x56a0dc['repoInfo']['namespace'])&&_0x56a0dc['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x370a5f['length']!==0x0&&!ud(_0x370a5f))throw new Error(it(_0x3d7fd1,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0xdbc1cb,_0x1a7b0b){let _0x36b5ed=null;for(let _0x40a6e0=0x0;_0x40a6e0<_0x1a7b0b['length'];_0x40a6e0++){const _0x31b7cd=_0x1a7b0b[_0x40a6e0],_0x2e5d65=_0x31b7cd['getPath']();_0x36b5ed!==null&&!Ki(_0x2e5d65,_0x36b5ed['path'])&&(_0xdbc1cb['eventLists_']['push'](_0x36b5ed),_0x36b5ed=null),_0x36b5ed===null&&(_0x36b5ed={'events':[],'path':_0x2e5d65}),_0x36b5ed['events']['push'](_0x31b7cd);}_0x36b5ed&&_0xdbc1cb['eventLists_']['push'](_0x36b5ed);}function oa(_0x7fab68,_0x12397d,_0x2b14f9){qn(_0x7fab68,_0x2b14f9),aa(_0x7fab68,_0x1a86a9=>Ki(_0x1a86a9,_0x12397d));}function V(_0x2c9a28,_0xd923df,_0x4047d0){qn(_0x2c9a28,_0x4047d0),aa(_0x2c9a28,_0x32ab01=>G(_0x32ab01,_0xd923df)||G(_0xd923df,_0x32ab01));}function aa(_0xb52236,_0x14ace5){_0xb52236['recursionDepth_']++;let _0x160dab=!0x0;for(let _0x2dbb85=0x0;_0x2dbb85<_0xb52236['eventLists_']['length'];_0x2dbb85++){const _0x458d5f=_0xb52236['eventLists_'][_0x2dbb85];if(_0x458d5f){const _0x50b544=_0x458d5f['path'];_0x14ace5(_0x50b544)?(md(_0xb52236['eventLists_'][_0x2dbb85]),_0xb52236['eventLists_'][_0x2dbb85]=null):_0x160dab=!0x1;}}_0x160dab&&(_0xb52236['eventLists_']=[]),_0xb52236['recursionDepth_']--;}function md(_0x2f06da){for(let _0x454b99=0x0;_0x454b99<_0x2f06da['events']['length'];_0x454b99++){const _0x236f34=_0x2f06da['events'][_0x454b99];if(_0x236f34!==null){_0x2f06da['events'][_0x454b99]=null;const _0x554bf9=_0x236f34['getEventRunner']();St&&L('event:\x20'+_0x236f34['toString']()),ft(_0x554bf9);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x41b6a9,_0x3196f6,_0x18ed82,_0x53e3ab){this['repoInfo_']=_0x41b6a9,this['forceRestClient_']=_0x3196f6,this['authTokenProvider_']=_0x18ed82,this['appCheckProvider_']=_0x53e3ab,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x56d7ab,_0x3b89e7,_0x17519b){if(_0x56d7ab['stats_']=qi(_0x56d7ab['repoInfo_']),_0x56d7ab['forceRestClient_']||Xl())_0x56d7ab['server_']=new vn(_0x56d7ab['repoInfo_'],(_0x5626e1,_0x43397e,_0x56427a,_0xd68113)=>{gr(_0x56d7ab,_0x5626e1,_0x43397e,_0x56427a,_0xd68113);},_0x56d7ab['authTokenProvider_'],_0x56d7ab['appCheckProvider_']),setTimeout(()=>mr(_0x56d7ab,!0x0),0x0);else{if(typeof _0x17519b<'u'&&_0x17519b!==null){if(typeof _0x17519b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x17519b);}catch(_0x480b44){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x480b44);}}_0x56d7ab['persistentConnection_']=new se(_0x56d7ab['repoInfo_'],_0x3b89e7,(_0x25aed7,_0xc1d662,_0x5a3c76,_0x52fd56)=>{gr(_0x56d7ab,_0x25aed7,_0xc1d662,_0x5a3c76,_0x52fd56);},_0x257b5b=>{mr(_0x56d7ab,_0x257b5b);},_0x756c64=>{Id(_0x56d7ab,_0x756c64);},_0x56d7ab['authTokenProvider_'],_0x56d7ab['appCheckProvider_'],_0x17519b),_0x56d7ab['server_']=_0x56d7ab['persistentConnection_'];}_0x56d7ab['authTokenProvider_']['addTokenChangeListener'](_0x16db53=>{_0x56d7ab['server_']['refreshAuthToken'](_0x16db53);}),_0x56d7ab['appCheckProvider_']['addTokenChangeListener'](_0x42b8a5=>{_0x56d7ab['server_']['refreshAppCheckToken'](_0x42b8a5['token']);}),_0x56d7ab['statsReporter_']=ih(_0x56d7ab['repoInfo_'],()=>new iu(_0x56d7ab['stats_'],_0x56d7ab['server_'])),_0x56d7ab['infoData_']=new Xh(),_0x56d7ab['infoSyncTree_']=new pr({'startListening':(_0x59824e,_0x3ffc7c,_0x2d1190,_0x267ba6)=>{let _0x51c43f=[];const _0x4153e0=_0x56d7ab['infoData_']['getNode'](_0x59824e['_path']);return _0x4153e0['isEmpty']()||(_0x51c43f=Yt(_0x56d7ab['infoSyncTree_'],_0x59824e['_path'],_0x4153e0),setTimeout(()=>{_0x267ba6('ok');},0x0)),_0x51c43f;},'stopListening':()=>{}}),vs(_0x56d7ab,'connected',!0x1),_0x56d7ab['serverSyncTree_']=new pr({'startListening':(_0x111256,_0x304b03,_0x122a7b,_0x145b90)=>(_0x56d7ab['server_']['listen'](_0x111256,_0x122a7b,_0x304b03,(_0x3981eb,_0x2be78e)=>{const _0x1fa4dd=_0x145b90(_0x3981eb,_0x2be78e);V(_0x56d7ab['eventQueue_'],_0x111256['_path'],_0x1fa4dd);}),[]),'stopListening':(_0x3b392f,_0x21b5c0)=>{_0x56d7ab['server_']['unlisten'](_0x3b392f,_0x21b5c0);}});}function la(_0x1419be){const _0x9cec47=_0x1419be['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x9cec47;}function Xt(_0x297b89){return id({'timestamp':la(_0x297b89)});}function gr(_0x143b52,_0x410c4e,_0x136ee2,_0x33e5dc,_0x2602ca){_0x143b52['dataUpdateCount']++;const _0x147b11=new C(_0x410c4e);_0x136ee2=_0x143b52['interceptServerDataCallback_']?_0x143b52['interceptServerDataCallback_'](_0x410c4e,_0x136ee2):_0x136ee2;let _0x25708c=[];if(_0x2602ca){if(_0x33e5dc){const _0x4ee1d3=_n(_0x136ee2,_0x7e8006=>A(_0x7e8006));_0x25708c=Ju(_0x143b52['serverSyncTree_'],_0x147b11,_0x4ee1d3,_0x2602ca);}else{const _0x12977d=A(_0x136ee2);_0x25708c=Jo(_0x143b52['serverSyncTree_'],_0x147b11,_0x12977d,_0x2602ca);}}else{if(_0x33e5dc){const _0x22aa95=_n(_0x136ee2,_0x1e1d6e=>A(_0x1e1d6e));_0x25708c=Ku(_0x143b52['serverSyncTree_'],_0x147b11,_0x22aa95);}else{const _0x9cba68=A(_0x136ee2);_0x25708c=Yt(_0x143b52['serverSyncTree_'],_0x147b11,_0x9cba68);}}let _0x569594=_0x147b11;_0x25708c['length']>0x0&&(_0x569594=ct(_0x143b52,_0x147b11)),V(_0x143b52['eventQueue_'],_0x569594,_0x25708c);}function mr(_0x38a364,_0xb914dd){vs(_0x38a364,'connected',_0xb914dd),_0xb914dd===!0x1&&Sd(_0x38a364);}function Id(_0x4cc539,_0x321608){x(_0x321608,(_0x38a311,_0x2b6d96)=>{vs(_0x4cc539,_0x38a311,_0x2b6d96);});}function vs(_0x13bf13,_0x3c543f,_0x5f2450){const _0xef04fe=new C('/.info/'+_0x3c543f),_0x39a2ae=A(_0x5f2450);_0x13bf13['infoData_']['updateSnapshot'](_0xef04fe,_0x39a2ae);const _0x112aab=Yt(_0x13bf13['infoSyncTree_'],_0xef04fe,_0x39a2ae);V(_0x13bf13['eventQueue_'],_0xef04fe,_0x112aab);}function zn(_0x167f5f){return _0x167f5f['nextWriteId_']++;}function wd(_0x4262bc,_0x11bfd5,_0x2d44d0){const _0x37ded1=Xu(_0x4262bc['serverSyncTree_'],_0x11bfd5);return _0x37ded1!=null?Promise['resolve'](_0x37ded1):_0x4262bc['server_']['get'](_0x11bfd5)['then'](_0x1f685f=>{const _0x26e48d=A(_0x1f685f)['withIndex'](_0x11bfd5['_queryParams']['getIndex']());Ni(_0x4262bc['serverSyncTree_'],_0x11bfd5,_0x2d44d0,!0x0);let _0x3bd4e3;if(_0x11bfd5['_queryParams']['loadsAllData']())_0x3bd4e3=Yt(_0x4262bc['serverSyncTree_'],_0x11bfd5['_path'],_0x26e48d);else{const _0x441f6c=Wt(_0x4262bc['serverSyncTree_'],_0x11bfd5);_0x3bd4e3=Jo(_0x4262bc['serverSyncTree_'],_0x11bfd5['_path'],_0x26e48d,_0x441f6c);}return V(_0x4262bc['eventQueue_'],_0x11bfd5['_path'],_0x3bd4e3),An(_0x4262bc['serverSyncTree_'],_0x11bfd5,_0x2d44d0,null,!0x0),_0x26e48d;},_0x358911=>(gt(_0x4262bc,'get\x20for\x20query\x20'+O(_0x11bfd5)+'\x20failed:\x20'+_0x358911),Promise['reject'](new Error(_0x358911))));}function Cd(_0x48537e,_0xc2ef6a,_0x520135,_0x20b0d3,_0x577b09){gt(_0x48537e,'set',{'path':_0xc2ef6a['toString'](),'value':_0x520135,'priority':_0x20b0d3});const _0x512978=Xt(_0x48537e),_0x28d21d=A(_0x520135,_0x20b0d3),_0x26a7ad=Vn(_0x48537e['serverSyncTree_'],_0xc2ef6a),_0x2f6523=fs(_0x28d21d,_0x26a7ad,_0x512978),_0x4edd1a=zn(_0x48537e),_0x2b6615=as(_0x48537e['serverSyncTree_'],_0xc2ef6a,_0x2f6523,_0x4edd1a,!0x0);qn(_0x48537e['eventQueue_'],_0x2b6615),_0x48537e['server_']['put'](_0xc2ef6a['toString'](),_0x28d21d['val'](!0x0),(_0x19cb68,_0x5521be)=>{const _0x584dbb=_0x19cb68==='ok';_0x584dbb||U('set\x20at\x20'+_0xc2ef6a+'\x20failed:\x20'+_0x19cb68);const _0x3aaed1=_e(_0x48537e['serverSyncTree_'],_0x4edd1a,!_0x584dbb);V(_0x48537e['eventQueue_'],_0xc2ef6a,_0x3aaed1),be(_0x48537e,_0x577b09,_0x19cb68,_0x5521be);});const _0xa5dbdb=Is(_0x48537e,_0xc2ef6a);ct(_0x48537e,_0xa5dbdb),V(_0x48537e['eventQueue_'],_0xa5dbdb,[]);}function Td(_0x2f7512,_0x2abe34,_0xe27894,_0xa755fc){gt(_0x2f7512,'update',{'path':_0x2abe34['toString'](),'value':_0xe27894});let _0x17c09d=!0x0;const _0x528523=Xt(_0x2f7512),_0x18e6cc={};if(x(_0xe27894,(_0x5e76d3,_0x190f1d)=>{_0x17c09d=!0x1,_0x18e6cc[_0x5e76d3]=ta(k(_0x2abe34,_0x5e76d3),A(_0x190f1d),_0x2f7512['serverSyncTree_'],_0x528523);}),_0x17c09d)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2f7512,_0xa755fc,'ok',void 0x0);else{const _0x88e74e=zn(_0x2f7512),_0x178c23=ju(_0x2f7512['serverSyncTree_'],_0x2abe34,_0x18e6cc,_0x88e74e);qn(_0x2f7512['eventQueue_'],_0x178c23),_0x2f7512['server_']['merge'](_0x2abe34['toString'](),_0xe27894,(_0x36e5a8,_0x47ee3d)=>{const _0x5965ac=_0x36e5a8==='ok';_0x5965ac||U('update\x20at\x20'+_0x2abe34+'\x20failed:\x20'+_0x36e5a8);const _0x4e651f=_e(_0x2f7512['serverSyncTree_'],_0x88e74e,!_0x5965ac),_0x4bb716=_0x4e651f['length']>0x0?ct(_0x2f7512,_0x2abe34):_0x2abe34;V(_0x2f7512['eventQueue_'],_0x4bb716,_0x4e651f),be(_0x2f7512,_0xa755fc,_0x36e5a8,_0x47ee3d);}),x(_0xe27894,_0x193e09=>{const _0x174c92=Is(_0x2f7512,k(_0x2abe34,_0x193e09));ct(_0x2f7512,_0x174c92);}),V(_0x2f7512['eventQueue_'],_0x2abe34,[]);}}function Sd(_0x3b19b5){gt(_0x3b19b5,'onDisconnectEvents');const _0x37c788=Xt(_0x3b19b5),_0x1e24e1=En();Si(_0x3b19b5['onDisconnect_'],w(),(_0x1bc3a9,_0x294cef)=>{const _0x49915a=ta(_0x1bc3a9,_0x294cef,_0x3b19b5['serverSyncTree_'],_0x37c788);pt(_0x1e24e1,_0x1bc3a9,_0x49915a);});let _0x51c5cf=[];Si(_0x1e24e1,w(),(_0xcd23f0,_0x312d23)=>{_0x51c5cf=_0x51c5cf['concat'](Yt(_0x3b19b5['serverSyncTree_'],_0xcd23f0,_0x312d23));const _0x1e2298=Is(_0x3b19b5,_0xcd23f0);ct(_0x3b19b5,_0x1e2298);}),_0x3b19b5['onDisconnect_']=En(),V(_0x3b19b5['eventQueue_'],w(),_0x51c5cf);}function bd(_0x4c550a,_0x202f3f,_0x15f6b6){_0x4c550a['server_']['onDisconnectCancel'](_0x202f3f['toString'](),(_0x24cad5,_0x337bc1)=>{_0x24cad5==='ok'&&Ti(_0x4c550a['onDisconnect_'],_0x202f3f),be(_0x4c550a,_0x15f6b6,_0x24cad5,_0x337bc1);});}function yr(_0x3266bf,_0x425c36,_0x5f1864,_0x174412){const _0x52ce4b=A(_0x5f1864);_0x3266bf['server_']['onDisconnectPut'](_0x425c36['toString'](),_0x52ce4b['val'](!0x0),(_0x3a4e14,_0x11c9d1)=>{_0x3a4e14==='ok'&&pt(_0x3266bf['onDisconnect_'],_0x425c36,_0x52ce4b),be(_0x3266bf,_0x174412,_0x3a4e14,_0x11c9d1);});}function Rd(_0x4c82b3,_0x28b424,_0x544882,_0x2c35f0,_0x2510bb){const _0x52322c=A(_0x544882,_0x2c35f0);_0x4c82b3['server_']['onDisconnectPut'](_0x28b424['toString'](),_0x52322c['val'](!0x0),(_0x2f05d4,_0x1cabae)=>{_0x2f05d4==='ok'&&pt(_0x4c82b3['onDisconnect_'],_0x28b424,_0x52322c),be(_0x4c82b3,_0x2510bb,_0x2f05d4,_0x1cabae);});}function Ad(_0x2cee33,_0x131ed4,_0x576622,_0x20b5a7){if(pn(_0x576622)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2cee33,_0x20b5a7,'ok',void 0x0);return;}_0x2cee33['server_']['onDisconnectMerge'](_0x131ed4['toString'](),_0x576622,(_0x29a7e2,_0x4edd3d)=>{_0x29a7e2==='ok'&&x(_0x576622,(_0x372319,_0xd2b021)=>{const _0xa829d0=A(_0xd2b021);pt(_0x2cee33['onDisconnect_'],k(_0x131ed4,_0x372319),_0xa829d0);}),be(_0x2cee33,_0x20b5a7,_0x29a7e2,_0x4edd3d);});}function kd(_0x526474,_0x330c46,_0x3123a7){let _0x3500ff;y(_0x330c46['_path'])==='.info'?_0x3500ff=Ni(_0x526474['infoSyncTree_'],_0x330c46,_0x3123a7):_0x3500ff=Ni(_0x526474['serverSyncTree_'],_0x330c46,_0x3123a7),oa(_0x526474['eventQueue_'],_0x330c46['_path'],_0x3500ff);}function Pd(_0x33093b,_0xfdca31,_0x31c5f3){let _0x561e38;y(_0xfdca31['_path'])==='.info'?_0x561e38=An(_0x33093b['infoSyncTree_'],_0xfdca31,_0x31c5f3):_0x561e38=An(_0x33093b['serverSyncTree_'],_0xfdca31,_0x31c5f3),oa(_0x33093b['eventQueue_'],_0xfdca31['_path'],_0x561e38);}function ha(_0x23918a){_0x23918a['persistentConnection_']&&_0x23918a['persistentConnection_']['interrupt'](ca);}function Nd(_0xcafb21){_0xcafb21['persistentConnection_']&&_0xcafb21['persistentConnection_']['resume'](ca);}function gt(_0x523428,..._0xd721d6){let _0x22c136='';_0x523428['persistentConnection_']&&(_0x22c136=_0x523428['persistentConnection_']['id']+':'),L(_0x22c136,..._0xd721d6);}function be(_0xace6aa,_0x414842,_0x4aafdc,_0x532b12){_0x414842&&ft(()=>{if(_0x4aafdc==='ok')_0x414842(null);else{const _0x1e49be=(_0x4aafdc||'error')['toUpperCase']();let _0x487a12=_0x1e49be;_0x532b12&&(_0x487a12+=':\x20'+_0x532b12);const _0x1f4aad=new Error(_0x487a12);_0x1f4aad['code']=_0x1e49be,_0x414842(_0x1f4aad);}});}function Od(_0x14558c,_0x3ad3f3,_0x266ed2,_0xdcfaa,_0x5e6ee8,_0xf9f66a){gt(_0x14558c,'transaction\x20on\x20'+_0x3ad3f3);const _0x541a73={'path':_0x3ad3f3,'update':_0x266ed2,'onComplete':_0xdcfaa,'status':null,'order':so(),'applyLocally':_0xf9f66a,'retryCount':0x0,'unwatcher':_0x5e6ee8,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x591d61=Es(_0x14558c,_0x3ad3f3,void 0x0);_0x541a73['currentInputSnapshot']=_0x591d61;const _0x484b1c=_0x541a73['update'](_0x591d61['val']());if(_0x484b1c===void 0x0)_0x541a73['unwatcher'](),_0x541a73['currentOutputSnapshotRaw']=null,_0x541a73['currentOutputSnapshotResolved']=null,_0x541a73['onComplete']&&_0x541a73['onComplete'](null,!0x1,_0x541a73['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x484b1c,_0x541a73['path']),_0x541a73['status']=0x0;const _0x1e65f2=$n(_0x14558c['transactionQueueTree_'],_0x3ad3f3),_0x5c4f59=je(_0x1e65f2)||[];_0x5c4f59['push'](_0x541a73),gs(_0x1e65f2,_0x5c4f59);let _0x5a14b9;typeof _0x484b1c=='object'&&_0x484b1c!==null&&Q(_0x484b1c,'.priority')?(_0x5a14b9=Le(_0x484b1c,'.priority'),f(Bt(_0x5a14b9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5a14b9=(Vn(_0x14558c['serverSyncTree_'],_0x3ad3f3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3bf596=Xt(_0x14558c),_0x8ed60c=A(_0x484b1c,_0x5a14b9),_0x98ae3f=fs(_0x8ed60c,_0x591d61,_0x3bf596);_0x541a73['currentOutputSnapshotRaw']=_0x8ed60c,_0x541a73['currentOutputSnapshotResolved']=_0x98ae3f,_0x541a73['currentWriteId']=zn(_0x14558c);const _0x224702=as(_0x14558c['serverSyncTree_'],_0x3ad3f3,_0x98ae3f,_0x541a73['currentWriteId'],_0x541a73['applyLocally']);V(_0x14558c['eventQueue_'],_0x3ad3f3,_0x224702),jn(_0x14558c,_0x14558c['transactionQueueTree_']);}}function Es(_0x16c8e9,_0x39185f,_0xc79850){return Vn(_0x16c8e9['serverSyncTree_'],_0x39185f,_0xc79850)||g['EMPTY_NODE'];}function jn(_0x5e0873,_0x124deb=_0x5e0873['transactionQueueTree_']){if(_0x124deb||Kn(_0x5e0873,_0x124deb),je(_0x124deb)){const _0x289e04=da(_0x5e0873,_0x124deb);f(_0x289e04['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x289e04['every'](_0x53e88a=>_0x53e88a['status']===0x0)&&Dd(_0x5e0873,Qt(_0x124deb),_0x289e04);}else na(_0x124deb)&&Gn(_0x124deb,_0x318fd4=>{jn(_0x5e0873,_0x318fd4);});}function Dd(_0x47570a,_0x3dfeba,_0x5c2e7d){const _0x51ebed=_0x5c2e7d['map'](_0x587884=>_0x587884['currentWriteId']),_0x2d02fe=Es(_0x47570a,_0x3dfeba,_0x51ebed);let _0x4c071b=_0x2d02fe;const _0x5d1699=_0x2d02fe['hash']();for(let _0x557096=0x0;_0x557096<_0x5c2e7d['length'];_0x557096++){const _0x4f133d=_0x5c2e7d[_0x557096];f(_0x4f133d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4f133d['status']=0x1,_0x4f133d['retryCount']++;const _0x40ccd4=F(_0x3dfeba,_0x4f133d['path']);_0x4c071b=_0x4c071b['updateChild'](_0x40ccd4,_0x4f133d['currentOutputSnapshotRaw']);}const _0x5c6528=_0x4c071b['val'](!0x0),_0x3a5dd7=_0x3dfeba;_0x47570a['server_']['put'](_0x3a5dd7['toString'](),_0x5c6528,_0xa00623=>{gt(_0x47570a,'transaction\x20put\x20response',{'path':_0x3a5dd7['toString'](),'status':_0xa00623});let _0x2fd7d9=[];if(_0xa00623==='ok'){const _0x1841c4=[];for(let _0x1c51cf=0x0;_0x1c51cf<_0x5c2e7d['length'];_0x1c51cf++)_0x5c2e7d[_0x1c51cf]['status']=0x2,_0x2fd7d9=_0x2fd7d9['concat'](_e(_0x47570a['serverSyncTree_'],_0x5c2e7d[_0x1c51cf]['currentWriteId'])),_0x5c2e7d[_0x1c51cf]['onComplete']&&_0x1841c4['push'](()=>_0x5c2e7d[_0x1c51cf]['onComplete'](null,!0x0,_0x5c2e7d[_0x1c51cf]['currentOutputSnapshotResolved'])),_0x5c2e7d[_0x1c51cf]['unwatcher']();Kn(_0x47570a,$n(_0x47570a['transactionQueueTree_'],_0x3dfeba)),jn(_0x47570a,_0x47570a['transactionQueueTree_']),V(_0x47570a['eventQueue_'],_0x3dfeba,_0x2fd7d9);for(let _0x4a715b=0x0;_0x4a715b<_0x1841c4['length'];_0x4a715b++)ft(_0x1841c4[_0x4a715b]);}else{if(_0xa00623==='datastale'){for(let _0x5f3a50=0x0;_0x5f3a50<_0x5c2e7d['length'];_0x5f3a50++)_0x5c2e7d[_0x5f3a50]['status']===0x3?_0x5c2e7d[_0x5f3a50]['status']=0x4:_0x5c2e7d[_0x5f3a50]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3a5dd7['toString']()+'\x20failed:\x20'+_0xa00623);for(let _0x376af7=0x0;_0x376af7<_0x5c2e7d['length'];_0x376af7++)_0x5c2e7d[_0x376af7]['status']=0x4,_0x5c2e7d[_0x376af7]['abortReason']=_0xa00623;}ct(_0x47570a,_0x3dfeba);}},_0x5d1699);}function ct(_0x1d703b,_0x6e3445){const _0x3beadb=ua(_0x1d703b,_0x6e3445),_0x30861c=Qt(_0x3beadb),_0x25410f=da(_0x1d703b,_0x3beadb);return Md(_0x1d703b,_0x25410f,_0x30861c),_0x30861c;}function Md(_0x555037,_0x31c922,_0x5390e5){if(_0x31c922['length']===0x0)return;const _0x22fb26=[];let _0x9299fe=[];const _0x3c911a=_0x31c922['filter'](_0x459709=>_0x459709['status']===0x0)['map'](_0x54da5a=>_0x54da5a['currentWriteId']);for(let _0x5849bb=0x0;_0x5849bb<_0x31c922['length'];_0x5849bb++){const _0x4c1ccc=_0x31c922[_0x5849bb],_0x12aa98=F(_0x5390e5,_0x4c1ccc['path']);let _0x302f61=!0x1,_0xfbf95;if(f(_0x12aa98!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4c1ccc['status']===0x4)_0x302f61=!0x0,_0xfbf95=_0x4c1ccc['abortReason'],_0x9299fe=_0x9299fe['concat'](_e(_0x555037['serverSyncTree_'],_0x4c1ccc['currentWriteId'],!0x0));else{if(_0x4c1ccc['status']===0x0){if(_0x4c1ccc['retryCount']>=yd)_0x302f61=!0x0,_0xfbf95='maxretry',_0x9299fe=_0x9299fe['concat'](_e(_0x555037['serverSyncTree_'],_0x4c1ccc['currentWriteId'],!0x0));else{const _0x558147=Es(_0x555037,_0x4c1ccc['path'],_0x3c911a);_0x4c1ccc['currentInputSnapshot']=_0x558147;const _0x2194f8=_0x31c922[_0x5849bb]['update'](_0x558147['val']());if(_0x2194f8!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2194f8,_0x4c1ccc['path']);let _0x3dc5c4=A(_0x2194f8);typeof _0x2194f8=='object'&&_0x2194f8!=null&&Q(_0x2194f8,'.priority')||(_0x3dc5c4=_0x3dc5c4['updatePriority'](_0x558147['getPriority']()));const _0x275a8f=_0x4c1ccc['currentWriteId'],_0x50d14b=Xt(_0x555037),_0x5c6129=fs(_0x3dc5c4,_0x558147,_0x50d14b);_0x4c1ccc['currentOutputSnapshotRaw']=_0x3dc5c4,_0x4c1ccc['currentOutputSnapshotResolved']=_0x5c6129,_0x4c1ccc['currentWriteId']=zn(_0x555037),_0x3c911a['splice'](_0x3c911a['indexOf'](_0x275a8f),0x1),_0x9299fe=_0x9299fe['concat'](as(_0x555037['serverSyncTree_'],_0x4c1ccc['path'],_0x5c6129,_0x4c1ccc['currentWriteId'],_0x4c1ccc['applyLocally'])),_0x9299fe=_0x9299fe['concat'](_e(_0x555037['serverSyncTree_'],_0x275a8f,!0x0));}else _0x302f61=!0x0,_0xfbf95='nodata',_0x9299fe=_0x9299fe['concat'](_e(_0x555037['serverSyncTree_'],_0x4c1ccc['currentWriteId'],!0x0));}}}V(_0x555037['eventQueue_'],_0x5390e5,_0x9299fe),_0x9299fe=[],_0x302f61&&(_0x31c922[_0x5849bb]['status']=0x2,function(_0x57c76d){setTimeout(_0x57c76d,Math['floor'](0x0));}(_0x31c922[_0x5849bb]['unwatcher']),_0x31c922[_0x5849bb]['onComplete']&&(_0xfbf95==='nodata'?_0x22fb26['push'](()=>_0x31c922[_0x5849bb]['onComplete'](null,!0x1,_0x31c922[_0x5849bb]['currentInputSnapshot'])):_0x22fb26['push'](()=>_0x31c922[_0x5849bb]['onComplete'](new Error(_0xfbf95),!0x1,null))));}Kn(_0x555037,_0x555037['transactionQueueTree_']);for(let _0x3b8f9b=0x0;_0x3b8f9b<_0x22fb26['length'];_0x3b8f9b++)ft(_0x22fb26[_0x3b8f9b]);jn(_0x555037,_0x555037['transactionQueueTree_']);}function ua(_0x44877e,_0x1dfc57){let _0x3580ca,_0x1d2923=_0x44877e['transactionQueueTree_'];for(_0x3580ca=y(_0x1dfc57);_0x3580ca!==null&&je(_0x1d2923)===void 0x0;)_0x1d2923=$n(_0x1d2923,_0x3580ca),_0x1dfc57=S(_0x1dfc57),_0x3580ca=y(_0x1dfc57);return _0x1d2923;}function da(_0x30f6f1,_0x17dd48){const _0x6c1f3c=[];return fa(_0x30f6f1,_0x17dd48,_0x6c1f3c),_0x6c1f3c['sort']((_0x54290d,_0x23b619)=>_0x54290d['order']-_0x23b619['order']),_0x6c1f3c;}function fa(_0x5d2f3a,_0x49fe3c,_0x157288){const _0x620114=je(_0x49fe3c);if(_0x620114){for(let _0x2704b4=0x0;_0x2704b4<_0x620114['length'];_0x2704b4++)_0x157288['push'](_0x620114[_0x2704b4]);}Gn(_0x49fe3c,_0x4bcba2=>{fa(_0x5d2f3a,_0x4bcba2,_0x157288);});}function Kn(_0x52eedb,_0x59a3d1){const _0x1efa3b=je(_0x59a3d1);if(_0x1efa3b){let _0x3f2275=0x0;for(let _0x324886=0x0;_0x324886<_0x1efa3b['length'];_0x324886++)_0x1efa3b[_0x324886]['status']!==0x2&&(_0x1efa3b[_0x3f2275]=_0x1efa3b[_0x324886],_0x3f2275++);_0x1efa3b['length']=_0x3f2275,gs(_0x59a3d1,_0x1efa3b['length']>0x0?_0x1efa3b:void 0x0);}Gn(_0x59a3d1,_0xcb0a5a=>{Kn(_0x52eedb,_0xcb0a5a);});}function Is(_0x14156f,_0x3220b3){const _0x12cdca=Qt(ua(_0x14156f,_0x3220b3)),_0x68cf83=$n(_0x14156f['transactionQueueTree_'],_0x3220b3);return ad(_0x68cf83,_0x54cc09=>{di(_0x14156f,_0x54cc09);}),di(_0x14156f,_0x68cf83),ia(_0x68cf83,_0x3fc06c=>{di(_0x14156f,_0x3fc06c);}),_0x12cdca;}function di(_0x15b4b7,_0x2916aa){const _0x578de8=je(_0x2916aa);if(_0x578de8){const _0x54d4cf=[];let _0x39e8f8=[],_0x3a9d7d=-0x1;for(let _0xb96ff9=0x0;_0xb96ff9<_0x578de8['length'];_0xb96ff9++)_0x578de8[_0xb96ff9]['status']===0x3||(_0x578de8[_0xb96ff9]['status']===0x1?(f(_0x3a9d7d===_0xb96ff9-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3a9d7d=_0xb96ff9,_0x578de8[_0xb96ff9]['status']=0x3,_0x578de8[_0xb96ff9]['abortReason']='set'):(f(_0x578de8[_0xb96ff9]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x578de8[_0xb96ff9]['unwatcher'](),_0x39e8f8=_0x39e8f8['concat'](_e(_0x15b4b7['serverSyncTree_'],_0x578de8[_0xb96ff9]['currentWriteId'],!0x0)),_0x578de8[_0xb96ff9]['onComplete']&&_0x54d4cf['push'](_0x578de8[_0xb96ff9]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3a9d7d===-0x1?gs(_0x2916aa,void 0x0):_0x578de8['length']=_0x3a9d7d+0x1,V(_0x15b4b7['eventQueue_'],Qt(_0x2916aa),_0x39e8f8);for(let _0x2819d7=0x0;_0x2819d7<_0x54d4cf['length'];_0x2819d7++)ft(_0x54d4cf[_0x2819d7]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0xeb7f22){let _0x307781='';const _0x517e28=_0xeb7f22['split']('/');for(let _0x6a6173=0x0;_0x6a6173<_0x517e28['length'];_0x6a6173++)if(_0x517e28[_0x6a6173]['length']>0x0){let _0x366f3d=_0x517e28[_0x6a6173];try{_0x366f3d=decodeURIComponent(_0x366f3d['replace'](/\+/g,'\x20'));}catch{}_0x307781+='/'+_0x366f3d;}return _0x307781;}function xd(_0x26855b){const _0x46913b={};_0x26855b['charAt'](0x0)==='?'&&(_0x26855b=_0x26855b['substring'](0x1));for(const _0x5b247f of _0x26855b['split']('&')){if(_0x5b247f['length']===0x0)continue;const _0x506bea=_0x5b247f['split']('=');_0x506bea['length']===0x2?_0x46913b[decodeURIComponent(_0x506bea[0x0])]=decodeURIComponent(_0x506bea[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5b247f+'\x27\x20in\x20query\x20\x27'+_0x26855b+'\x27');}return _0x46913b;}const vr=function(_0x1ea6e2,_0x48c70a){const _0x404e15=Fd(_0x1ea6e2),_0x5d7dc6=_0x404e15['namespace'];_0x404e15['domain']==='firebase.com'&&ae(_0x404e15['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5d7dc6||_0x5d7dc6==='undefined')&&_0x404e15['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x404e15['secure']||$l();const _0x91634a=_0x404e15['scheme']==='ws'||_0x404e15['scheme']==='wss';return{'repoInfo':new yo(_0x404e15['host'],_0x404e15['secure'],_0x5d7dc6,_0x91634a,_0x48c70a,'',_0x5d7dc6!==_0x404e15['subdomain']),'path':new C(_0x404e15['pathString'])};},Fd=function(_0x2da10e){let _0x404a00='',_0x4db702='',_0x4e1410='',_0x25fbb3='',_0x5d8dd9='',_0x3cced6=!0x0,_0x44a878='https',_0x560cd5=0x1bb;if(typeof _0x2da10e=='string'){let _0x5365a3=_0x2da10e['indexOf']('//');_0x5365a3>=0x0&&(_0x44a878=_0x2da10e['substring'](0x0,_0x5365a3-0x1),_0x2da10e=_0x2da10e['substring'](_0x5365a3+0x2));let _0x56ed6f=_0x2da10e['indexOf']('/');_0x56ed6f===-0x1&&(_0x56ed6f=_0x2da10e['length']);let _0x4b2435=_0x2da10e['indexOf']('?');_0x4b2435===-0x1&&(_0x4b2435=_0x2da10e['length']),_0x404a00=_0x2da10e['substring'](0x0,Math['min'](_0x56ed6f,_0x4b2435)),_0x56ed6f<_0x4b2435&&(_0x25fbb3=Ld(_0x2da10e['substring'](_0x56ed6f,_0x4b2435)));const _0x11c4a9=xd(_0x2da10e['substring'](Math['min'](_0x2da10e['length'],_0x4b2435)));_0x5365a3=_0x404a00['indexOf'](':'),_0x5365a3>=0x0?(_0x3cced6=_0x44a878==='https'||_0x44a878==='wss',_0x560cd5=parseInt(_0x404a00['substring'](_0x5365a3+0x1),0xa)):_0x5365a3=_0x404a00['length'];const _0x132623=_0x404a00['slice'](0x0,_0x5365a3);if(_0x132623['toLowerCase']()==='localhost')_0x4db702='localhost';else{if(_0x132623['split']('.')['length']<=0x2)_0x4db702=_0x132623;else{const _0x5b9c51=_0x404a00['indexOf']('.');_0x4e1410=_0x404a00['substring'](0x0,_0x5b9c51)['toLowerCase'](),_0x4db702=_0x404a00['substring'](_0x5b9c51+0x1),_0x5d8dd9=_0x4e1410;}}'ns'in _0x11c4a9&&(_0x5d8dd9=_0x11c4a9['ns']);}return{'host':_0x404a00,'port':_0x560cd5,'domain':_0x4db702,'subdomain':_0x4e1410,'secure':_0x3cced6,'scheme':_0x44a878,'pathString':_0x25fbb3,'namespace':_0x5d8dd9};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x485b31=0x0;const _0x26e61c=[];return function(_0x4897c5){const _0x415ea0=_0x4897c5===_0x485b31;_0x485b31=_0x4897c5;let _0x38af54;const _0x4cc3ab=new Array(0x8);for(_0x38af54=0x7;_0x38af54>=0x0;_0x38af54--)_0x4cc3ab[_0x38af54]=Er['charAt'](_0x4897c5%0x40),_0x4897c5=Math['floor'](_0x4897c5/0x40);f(_0x4897c5===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5e98e2=_0x4cc3ab['join']('');if(_0x415ea0){for(_0x38af54=0xb;_0x38af54>=0x0&&_0x26e61c[_0x38af54]===0x3f;_0x38af54--)_0x26e61c[_0x38af54]=0x0;_0x26e61c[_0x38af54]++;}else{for(_0x38af54=0x0;_0x38af54<0xc;_0x38af54++)_0x26e61c[_0x38af54]=Math['floor'](Math['random']()*0x40);}for(_0x38af54=0x0;_0x38af54<0xc;_0x38af54++)_0x5e98e2+=Er['charAt'](_0x26e61c[_0x38af54]);return f(_0x5e98e2['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5e98e2;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1e8f93,_0x385a8f,_0x52a292,_0x51d4c6){this['eventType']=_0x1e8f93,this['eventRegistration']=_0x385a8f,this['snapshot']=_0x52a292,this['prevName']=_0x51d4c6;}['getPath'](){const _0x1c7303=this['snapshot']['ref'];return this['eventType']==='value'?_0x1c7303['_path']:_0x1c7303['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2f8c3c,_0xfcfb7b,_0x1d4f6b){this['eventRegistration']=_0x2f8c3c,this['error']=_0xfcfb7b,this['path']=_0x1d4f6b;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1bf25e,_0x548e2c){this['snapshotCallback']=_0x1bf25e,this['cancelCallback']=_0x548e2c;}['onValue'](_0x2a6ed8,_0x1eafe7){this['snapshotCallback']['call'](null,_0x2a6ed8,_0x1eafe7);}['onCancel'](_0x4b804b){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4b804b);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3d38ed){return this['snapshotCallback']===_0x3d38ed['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3d38ed['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3d38ed['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2ac62a,_0x445ab5){this['_repo']=_0x2ac62a,this['_path']=_0x445ab5;}['cancel'](){const _0x24e6bb=new H();return bd(this['_repo'],this['_path'],_0x24e6bb['wrapCallback'](()=>{})),_0x24e6bb['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2dd54e=new H();return yr(this['_repo'],this['_path'],null,_0x2dd54e['wrapCallback'](()=>{})),_0x2dd54e['promise'];}['set'](_0x35d0d1){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x35d0d1,this['_path'],!0x1);const _0x4686da=new H();return yr(this['_repo'],this['_path'],_0x35d0d1,_0x4686da['wrapCallback'](()=>{})),_0x4686da['promise'];}['setWithPriority'](_0x7dd56f,_0x52199d){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x7dd56f,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x52199d);const _0x2a6a55=new H();return Rd(this['_repo'],this['_path'],_0x7dd56f,_0x52199d,_0x2a6a55['wrapCallback'](()=>{})),_0x2a6a55['promise'];}['update'](_0x14089d){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x14089d,this['_path']);const _0x20b90f=new H();return Ad(this['_repo'],this['_path'],_0x14089d,_0x20b90f['wrapCallback'](()=>{})),_0x20b90f['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x1d2791,_0x32ba49,_0x2f6605,_0x42fd1a){this['_repo']=_0x1d2791,this['_path']=_0x32ba49,this['_queryParams']=_0x2f6605,this['_orderByCalled']=_0x42fd1a;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x19f0eb=sr(this['_queryParams']),_0x33302b=$i(_0x19f0eb);return _0x33302b==='{}'?'default':_0x33302b;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2ccd81){if(_0x2ccd81=P(_0x2ccd81),!(_0x2ccd81 instanceof Ae))return!0x1;const _0x426263=this['_repo']===_0x2ccd81['_repo'],_0x16df1e=Ki(this['_path'],_0x2ccd81['_path']),_0x507c01=this['_queryIdentifier']===_0x2ccd81['_queryIdentifier'];return _0x426263&&_0x16df1e&&_0x507c01;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1f0583,_0x1f9289){if(_0x1f0583['_orderByCalled']===!0x0)throw new Error(_0x1f9289+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x503957){let _0x4b442c=null,_0x1b7ac7=null;if(_0x503957['hasStart']()&&(_0x4b442c=_0x503957['getIndexStartValue']()),_0x503957['hasEnd']()&&(_0x1b7ac7=_0x503957['getIndexEndValue']()),_0x503957['getIndex']()===ve){const _0x14fde7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x21116e='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x503957['hasStart']()){if(_0x503957['getIndexStartName']()!==We)throw new Error(_0x14fde7);if(typeof _0x4b442c!='string')throw new Error(_0x21116e);}if(_0x503957['hasEnd']()){if(_0x503957['getIndexEndName']()!==we)throw new Error(_0x14fde7);if(typeof _0x1b7ac7!='string')throw new Error(_0x21116e);}}else{if(_0x503957['getIndex']()===R){if(_0x4b442c!=null&&!Bt(_0x4b442c)||_0x1b7ac7!=null&&!Bt(_0x1b7ac7))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x503957['getIndex']()instanceof Ji||_0x503957['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4b442c!=null&&typeof _0x4b442c=='object'||_0x1b7ac7!=null&&typeof _0x1b7ac7=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1fc3d7){if(_0x1fc3d7['hasStart']()&&_0x1fc3d7['hasEnd']()&&_0x1fc3d7['hasLimit']()&&!_0x1fc3d7['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x50b0c5,_0x365a84){super(_0x50b0c5,_0x365a84,new Zi(),!0x1);}get['parent'](){const _0x58786b=Ro(this['_path']);return _0x58786b===null?null:new ee(this['_repo'],_0x58786b);}get['root'](){let _0x176d1d=this;for(;_0x176d1d['parent']!==null;)_0x176d1d=_0x176d1d['parent'];return _0x176d1d;}}class lt{constructor(_0xef8a00,_0x533433,_0x49b809){this['_node']=_0xef8a00,this['ref']=_0x533433,this['_index']=_0x49b809;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x481962){const _0x5abd4c=new C(_0x481962),_0x38e363=Vt(this['ref'],_0x481962);return new lt(this['_node']['getChild'](_0x5abd4c),_0x38e363,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1c05de){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x57c789,_0x291c1f)=>_0x1c05de(new lt(_0x291c1f,Vt(this['ref'],_0x57c789),R)));}['hasChild'](_0x3e9207){const _0x533e80=new C(_0x3e9207);return!this['_node']['getChild'](_0x533e80)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x3a9d7f,_0x3f7c22){return _0x3a9d7f=P(_0x3a9d7f),_0x3a9d7f['_checkNotDeleted']('ref'),_0x3f7c22!==void 0x0?Vt(_0x3a9d7f['_root'],_0x3f7c22):_0x3a9d7f['_root'];}function Vt(_0xe8140d,_0x5a8448){return _0xe8140d=P(_0xe8140d),y(_0xe8140d['_path'])===null?pd('child','path',_0x5a8448):ys('child','path',_0x5a8448),new ee(_0xe8140d['_repo'],k(_0xe8140d['_path'],_0x5a8448));}function v_(_0xfbcee){return _0xfbcee=P(_0xfbcee),new Vd(_0xfbcee['_repo'],_0xfbcee['_path']);}function E_(_0x2a385b,_0x5d2ce7){_0x2a385b=P(_0x2a385b),Me('push',_0x2a385b['_path']),He('push',_0x5d2ce7,_0x2a385b['_path'],!0x0);const _0x2c634a=la(_0x2a385b['_repo']),_0xed95cb=Ud(_0x2c634a),_0xeb2540=Vt(_0x2a385b,_0xed95cb),_0x1e31ec=Vt(_0x2a385b,_0xed95cb);let _0x408c7b;return _0x5d2ce7!=null?_0x408c7b=Hd(_0x1e31ec,_0x5d2ce7)['then'](()=>_0x1e31ec):_0x408c7b=Promise['resolve'](_0x1e31ec),_0xeb2540['then']=_0x408c7b['then']['bind'](_0x408c7b),_0xeb2540['catch']=_0x408c7b['then']['bind'](_0x408c7b,void 0x0),_0xeb2540;}function Hd(_0x17b309,_0x23a8f3){_0x17b309=P(_0x17b309),Me('set',_0x17b309['_path']),He('set',_0x23a8f3,_0x17b309['_path'],!0x1);const _0x4dc984=new H();return Cd(_0x17b309['_repo'],_0x17b309['_path'],_0x23a8f3,null,_0x4dc984['wrapCallback'](()=>{})),_0x4dc984['promise'];}function I_(_0x230714,_0x13f694){ra('update',_0x13f694,_0x230714['_path']);const _0x244dda=new H();return Td(_0x230714['_repo'],_0x230714['_path'],_0x13f694,_0x244dda['wrapCallback'](()=>{})),_0x244dda['promise'];}function w_(_0x5b9ac2){_0x5b9ac2=P(_0x5b9ac2);const _0x13e675=new pa(()=>{}),_0x33e634=new Qn(_0x13e675);return wd(_0x5b9ac2['_repo'],_0x5b9ac2,_0x33e634)['then'](_0x265fc4=>new lt(_0x265fc4,new ee(_0x5b9ac2['_repo'],_0x5b9ac2['_path']),_0x5b9ac2['_queryParams']['getIndex']()));}class Qn{constructor(_0x578d8e){this['callbackContext']=_0x578d8e;}['respondsTo'](_0x2f4bc6){return _0x2f4bc6==='value';}['createEvent'](_0x454c3e,_0x1e821c){const _0x307729=_0x1e821c['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x454c3e['snapshotNode'],new ee(_0x1e821c['_repo'],_0x1e821c['_path']),_0x307729));}['getEventRunner'](_0x25512d){return _0x25512d['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x25512d['error']):()=>this['callbackContext']['onValue'](_0x25512d['snapshot'],null);}['createCancelEvent'](_0x4435f0,_0xa517cc){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4435f0,_0xa517cc):null;}['matches'](_0x298675){return _0x298675 instanceof Qn?!_0x298675['callbackContext']||!this['callbackContext']?!0x0:_0x298675['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0xb7ab46,_0x202785,_0x4da709,_0x22d355,_0x448327){const _0x36ad33=new pa(_0x4da709,void 0x0),_0xdf7a31=new Qn(_0x36ad33);return kd(_0xb7ab46['_repo'],_0xb7ab46,_0xdf7a31),()=>Pd(_0xb7ab46['_repo'],_0xb7ab46,_0xdf7a31);}function Gd(_0x234b9c,_0x493b96,_0x139f41,_0x311259){return $d(_0x234b9c,'value',_0x493b96);}class mt{}class ma extends mt{constructor(_0x10237c,_0x5f8254){super(),this['_value']=_0x10237c,this['_key']=_0x5f8254,this['type']='endAt';}['_apply'](_0x21a5c2){He('endAt',this['_value'],_0x21a5c2['_path'],!0x0);const _0x2d5540=Jh(_0x21a5c2['_queryParams'],this['_value'],this['_key']);if(ga(_0x2d5540),Yn(_0x2d5540),_0x21a5c2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x21a5c2['_repo'],_0x21a5c2['_path'],_0x2d5540,_0x21a5c2['_orderByCalled']);}}function C_(_0x5a838a,_0x359ca4){return new ma(_0x5a838a,_0x359ca4);}class ya extends mt{constructor(_0x1a817b,_0x11a960){super(),this['_value']=_0x1a817b,this['_key']=_0x11a960,this['type']='startAt';}['_apply'](_0x3f7d48){He('startAt',this['_value'],_0x3f7d48['_path'],!0x0);const _0xd6f85b=Qh(_0x3f7d48['_queryParams'],this['_value'],this['_key']);if(ga(_0xd6f85b),Yn(_0xd6f85b),_0x3f7d48['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x3f7d48['_repo'],_0x3f7d48['_path'],_0xd6f85b,_0x3f7d48['_orderByCalled']);}}function T_(_0x354bbe=null,_0x101a3b){return new ya(_0x354bbe,_0x101a3b);}class qd extends mt{constructor(_0x581302){super(),this['_limit']=_0x581302,this['type']='limitToFirst';}['_apply'](_0x570bb0){if(_0x570bb0['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x570bb0['_repo'],_0x570bb0['_path'],Yh(_0x570bb0['_queryParams'],this['_limit']),_0x570bb0['_orderByCalled']);}}function S_(_0x3598fe){if(Math['floor'](_0x3598fe)!==_0x3598fe||_0x3598fe<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3598fe);}class zd extends mt{constructor(_0x3ac21e){super(),this['_path']=_0x3ac21e,this['type']='orderByChild';}['_apply'](_0x4ef65c){_a(_0x4ef65c,'orderByChild');const _0x6f50fc=new C(this['_path']);if(v(_0x6f50fc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x48a7c1=new Ji(_0x6f50fc),_0x447179=xo(_0x4ef65c['_queryParams'],_0x48a7c1);return Yn(_0x447179),new Ae(_0x4ef65c['_repo'],_0x4ef65c['_path'],_0x447179,!0x0);}}function b_(_0xf38c41){if(_0xf38c41==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xf38c41==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xf38c41==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0xf38c41),new zd(_0xf38c41);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x757e36){_a(_0x757e36,'orderByKey');const _0x297a3c=xo(_0x757e36['_queryParams'],ve);return Yn(_0x297a3c),new Ae(_0x757e36['_repo'],_0x757e36['_path'],_0x297a3c,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x2c434a,_0x92587c){super(),this['_value']=_0x2c434a,this['_key']=_0x92587c,this['type']='equalTo';}['_apply'](_0x445ccb){if(He('equalTo',this['_value'],_0x445ccb['_path'],!0x1),_0x445ccb['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x445ccb['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x445ccb));}}function A_(_0x155828,_0x2af1cc){return new Kd(_0x155828,_0x2af1cc);}function k_(_0x494fbb,..._0x1287e0){let _0x11da72=P(_0x494fbb);for(const _0x39320c of _0x1287e0)_0x11da72=_0x39320c['_apply'](_0x11da72);return _0x11da72;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x256891,_0x32cfee,_0x501175,_0x580b10){const _0x9a201=_0x32cfee['lastIndexOf'](':'),_0x2efb0b=_0x32cfee['substring'](0x0,_0x9a201),_0x4200a5=qt(_0x2efb0b);_0x256891['repoInfo_']=new yo(_0x32cfee,_0x4200a5,_0x256891['repoInfo_']['namespace'],_0x256891['repoInfo_']['webSocketOnly'],_0x256891['repoInfo_']['nodeAdmin'],_0x256891['repoInfo_']['persistenceKey'],_0x256891['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x501175),_0x580b10&&(_0x256891['authTokenProvider_']=_0x580b10);}function Xd(_0x241347,_0x4815b7,_0x553e64,_0x125b5d,_0x56354d){let _0x195a7e=_0x125b5d||_0x241347['options']['databaseURL'];_0x195a7e===void 0x0&&(_0x241347['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x241347['options']['projectId']),_0x195a7e=_0x241347['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4648f0=vr(_0x195a7e,_0x56354d),_0x3223eb=_0x4648f0['repoInfo'],_0x3a69b0;typeof process<'u'&&Bs&&(_0x3a69b0=Bs[Yd]),_0x3a69b0?(_0x195a7e='http://'+_0x3a69b0+'?ns='+_0x3223eb['namespace'],_0x4648f0=vr(_0x195a7e,_0x56354d),_0x3223eb=_0x4648f0['repoInfo']):_0x4648f0['repoInfo']['secure'];const _0x127af5=new eh(_0x241347['name'],_0x241347['options'],_0x4815b7);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4648f0),v(_0x4648f0['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4063a1=ef(_0x3223eb,_0x241347,_0x127af5,new Zl(_0x241347,_0x553e64));return new tf(_0x4063a1,_0x241347);}function Zd(_0x164fb7,_0x22dd22){const _0x56eb19=Di[_0x22dd22];(!_0x56eb19||_0x56eb19[_0x164fb7['key']]!==_0x164fb7)&&ae('Database\x20'+_0x22dd22+'('+_0x164fb7['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x164fb7),delete _0x56eb19[_0x164fb7['key']];}function ef(_0x3a1115,_0x1e1be7,_0x2b4098,_0x570cb6){let _0xdb07fa=Di[_0x1e1be7['name']];_0xdb07fa||(_0xdb07fa={},Di[_0x1e1be7['name']]=_0xdb07fa);let _0x2ad5b3=_0xdb07fa[_0x3a1115['toURLString']()];return _0x2ad5b3&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2ad5b3=new vd(_0x3a1115,Qd,_0x2b4098,_0x570cb6),_0xdb07fa[_0x3a1115['toURLString']()]=_0x2ad5b3,_0x2ad5b3;}class tf{constructor(_0x5db255,_0xf9e01c){this['_repoInternal']=_0x5db255,this['app']=_0xf9e01c,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x489ca5){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x489ca5+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4084e1=Zr(),_0x3dbb8c){const _0x44d6fa=Hi(_0x4084e1,'database')['getImmediate']({'identifier':_0x3dbb8c});if(!_0x44d6fa['_instanceStarted']){const _0x17f3fe=hc('database');_0x17f3fe&&nf(_0x44d6fa,..._0x17f3fe);}return _0x44d6fa;}function nf(_0x10b8df,_0x1135fd,_0x45761a,_0x3cf253={}){_0x10b8df=P(_0x10b8df),_0x10b8df['_checkNotDeleted']('useEmulator');const _0x9faff5=_0x1135fd+':'+_0x45761a,_0x384948=_0x10b8df['_repoInternal'];if(_0x10b8df['_instanceStarted']){if(_0x9faff5===_0x10b8df['_repoInternal']['repoInfo_']['host']&&xe(_0x3cf253,_0x384948['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2c923a;if(_0x384948['repoInfo_']['nodeAdmin'])_0x3cf253['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2c923a=new an(an['OWNER']);else{if(_0x3cf253['mockUserToken']){const _0x48e8be=typeof _0x3cf253['mockUserToken']=='string'?_0x3cf253['mockUserToken']:uc(_0x3cf253['mockUserToken'],_0x10b8df['app']['options']['projectId']);_0x2c923a=new an(_0x48e8be);}}qt(_0x1135fd)&&Qr(_0x1135fd),Jd(_0x384948,_0x9faff5,_0x3cf253,_0x2c923a);}function N_(_0x44ae5a){_0x44ae5a=P(_0x44ae5a),_0x44ae5a['_checkNotDeleted']('goOffline'),ha(_0x44ae5a['_repo']);}function O_(_0x3f58ce){_0x3f58ce=P(_0x3f58ce),_0x3f58ce['_checkNotDeleted']('goOnline'),Nd(_0x3f58ce['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x59234f){Ul(dt),st(new Fe('database',(_0x4dfcc7,{instanceIdentifier:_0x301d62})=>{const _0x37605d=_0x4dfcc7['getProvider']('app')['getImmediate'](),_0x23e34c=_0x4dfcc7['getProvider']('auth-internal'),_0x2f60cb=_0x4dfcc7['getProvider']('app-check-internal');return Xd(_0x37605d,_0x23e34c,_0x2f60cb,_0x301d62);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x59234f),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x31be98,_0x555088){this['committed']=_0x31be98,this['snapshot']=_0x555088;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x395e50,_0x506c0d,_0x4f2c4b){if(_0x395e50=P(_0x395e50),Me('Reference.transaction',_0x395e50['_path']),_0x395e50['key']==='.length'||_0x395e50['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x395e50['key']+'\x20is\x20a\x20read-only\x20object.';const _0x11ec53=!0x0,_0x35214b=new H(),_0x45eb9d=(_0x236fc3,_0x5c5343,_0x4b5753)=>{let _0x1993d6=null;_0x236fc3?_0x35214b['reject'](_0x236fc3):(_0x1993d6=new lt(_0x4b5753,new ee(_0x395e50['_repo'],_0x395e50['_path']),R),_0x35214b['resolve'](new of(_0x5c5343,_0x1993d6)));},_0xfb8ceb=Gd(_0x395e50,()=>{});return Od(_0x395e50['_repo'],_0x395e50['_path'],_0x506c0d,_0x45eb9d,_0xfb8ceb,_0x11ec53),_0x35214b['promise'];}se['prototype']['simpleListen']=function(_0x592410,_0x3ae349){this['sendRequest']('q',{'p':_0x592410},_0x3ae349);},se['prototype']['echo']=function(_0x50afd1,_0x32e0e6){this['sendRequest']('echo',{'d':_0x50afd1},_0x32e0e6);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x47844c,..._0x1478de){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x47844c,..._0x1478de);}function cn(_0x5010af,..._0x25fcc7){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5010af,..._0x25fcc7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x45882a,..._0x232205){throw ws(_0x45882a,..._0x232205);}function X(_0x386cb9,..._0x51ae8f){return ws(_0x386cb9,..._0x51ae8f);}function Ia(_0x2d4f6c,_0x6d3eb4,_0xc1f813){const _0x2d226b={...af(),[_0x6d3eb4]:_0xc1f813};return new Gt('auth','Firebase',_0x2d226b)['create'](_0x6d3eb4,{'appName':_0x2d4f6c['name']});}function re(_0x47c2b6){return Ia(_0x47c2b6,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1066b2,..._0xdbf55b){if(typeof _0x1066b2!='string'){const _0x135761=_0xdbf55b[0x0],_0xc779a0=[..._0xdbf55b['slice'](0x1)];return _0xc779a0[0x0]&&(_0xc779a0[0x0]['appName']=_0x1066b2['name']),_0x1066b2['_errorFactory']['create'](_0x135761,..._0xc779a0);}return Ea['create'](_0x1066b2,..._0xdbf55b);}function m(_0x3ec248,_0x3993d1,..._0x78e9f0){if(!_0x3ec248)throw ws(_0x3993d1,..._0x78e9f0);}function ne(_0x532592){const _0x28ab12='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x532592;throw cn(_0x28ab12),new Error(_0x28ab12);}function ce(_0x47c6b9,_0x453396){_0x47c6b9||ne(_0x453396);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x4892c8;return typeof self<'u'&&((_0x4892c8=self['location'])==null?void 0x0:_0x4892c8['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x215d90;return typeof self<'u'&&((_0x215d90=self['location'])==null?void 0x0:_0x215d90['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5dd275=navigator;return _0x5dd275['languages']&&_0x5dd275['languages'][0x0]||_0x5dd275['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4a2935,_0x42a6f3){this['shortDelay']=_0x4a2935,this['longDelay']=_0x42a6f3,ce(_0x42a6f3>_0x4a2935,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2809f1,_0x4a150d){ce(_0x2809f1['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x36080e}=_0x2809f1['emulator'];return _0x4a150d?''+_0x36080e+(_0x4a150d['startsWith']('/')?_0x4a150d['slice'](0x1):_0x4a150d):_0x36080e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x32f54a,_0x1eaff3,_0x277f01){this['fetchImpl']=_0x32f54a,_0x1eaff3&&(this['headersImpl']=_0x1eaff3),_0x277f01&&(this['responseImpl']=_0x277f01);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x30044b,_0x1e5512){return _0x30044b['tenantId']&&!_0x1e5512['tenantId']?{..._0x1e5512,'tenantId':_0x30044b['tenantId']}:_0x1e5512;}async function Pe(_0x5802fd,_0x3a4e84,_0x5298a1,_0x4fab98,_0xd06e20={}){return Ca(_0x5802fd,_0xd06e20,async()=>{let _0x4376e7={},_0x19a5ef={};_0x4fab98&&(_0x3a4e84==='GET'?_0x19a5ef=_0x4fab98:_0x4376e7={'body':JSON['stringify'](_0x4fab98)});const _0x238abf=ut({..._0x19a5ef,'key':_0x5802fd['config']['apiKey']})['slice'](0x1),_0x17adc9=await _0x5802fd['_getAdditionalHeaders']();_0x17adc9['Content-Type']='application/json',_0x5802fd['languageCode']&&(_0x17adc9['X-Firebase-Locale']=_0x5802fd['languageCode']);const _0x59e4d8={'method':_0x3a4e84,'headers':_0x17adc9,..._0x4376e7};return dc()||(_0x59e4d8['referrerPolicy']='strict-origin-when-cross-origin'),_0x5802fd['emulatorConfig']&&qt(_0x5802fd['emulatorConfig']['host'])&&(_0x59e4d8['credentials']='include'),wa['fetch']()(await Ta(_0x5802fd,_0x5802fd['config']['apiHost'],_0x5298a1,_0x238abf),_0x59e4d8);});}async function Ca(_0xb0c3cf,_0x1a7868,_0x31fef4){_0xb0c3cf['_canInitEmulator']=!0x1;const _0x46918c={...df,..._0x1a7868};try{const _0x225d34=new gf(_0xb0c3cf),_0x57c51a=await Promise['race']([_0x31fef4(),_0x225d34['promise']]);_0x225d34['clearNetworkTimeout']();const _0x3d5e81=await _0x57c51a['json']();if('needConfirmation'in _0x3d5e81)throw on(_0xb0c3cf,'account-exists-with-different-credential',_0x3d5e81);if(_0x57c51a['ok']&&!('errorMessage'in _0x3d5e81))return _0x3d5e81;{const _0x2f454b=_0x57c51a['ok']?_0x3d5e81['errorMessage']:_0x3d5e81['error']['message'],[_0x4caa5b,_0x37062c]=_0x2f454b['split']('\x20:\x20');if(_0x4caa5b==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0xb0c3cf,'credential-already-in-use',_0x3d5e81);if(_0x4caa5b==='EMAIL_EXISTS')throw on(_0xb0c3cf,'email-already-in-use',_0x3d5e81);if(_0x4caa5b==='USER_DISABLED')throw on(_0xb0c3cf,'user-disabled',_0x3d5e81);const _0x5af0ec=_0x46918c[_0x4caa5b]||_0x4caa5b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x37062c)throw Ia(_0xb0c3cf,_0x5af0ec,_0x37062c);Y(_0xb0c3cf,_0x5af0ec);}}catch(_0x33f064){if(_0x33f064 instanceof Re)throw _0x33f064;Y(_0xb0c3cf,'network-request-failed',{'message':String(_0x33f064)});}}async function en(_0x5e9c6b,_0x21cb39,_0x1f0acf,_0x37a2e4,_0x56947e={}){const _0xba7966=await Pe(_0x5e9c6b,_0x21cb39,_0x1f0acf,_0x37a2e4,_0x56947e);return'mfaPendingCredential'in _0xba7966&&Y(_0x5e9c6b,'multi-factor-auth-required',{'_serverResponse':_0xba7966}),_0xba7966;}async function Ta(_0x121eda,_0x445f00,_0xa96e6,_0x52656a){const _0x331e9f=''+_0x445f00+_0xa96e6+'?'+_0x52656a,_0x368456=_0x121eda,_0x4addcd=_0x368456['config']['emulator']?Cs(_0x121eda['config'],_0x331e9f):_0x121eda['config']['apiScheme']+'://'+_0x331e9f;return ff['includes'](_0xa96e6)&&(await _0x368456['_persistenceManagerAvailable'],_0x368456['_getPersistenceType']()==='COOKIE')?_0x368456['_getPersistence']()['_getFinalTarget'](_0x4addcd)['toString']():_0x4addcd;}function _f(_0x159001){switch(_0x159001){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1f2f21){this['auth']=_0x1f2f21,this['timer']=null,this['promise']=new Promise((_0x448f4c,_0x5a506e)=>{this['timer']=setTimeout(()=>_0x5a506e(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x239e91,_0x1b4cac,_0x34bf65){const _0x162359={'appName':_0x239e91['name']};_0x34bf65['email']&&(_0x162359['email']=_0x34bf65['email']),_0x34bf65['phoneNumber']&&(_0x162359['phoneNumber']=_0x34bf65['phoneNumber']);const _0x4ad8fd=X(_0x239e91,_0x1b4cac,_0x162359);return _0x4ad8fd['customData']['_tokenResponse']=_0x34bf65,_0x4ad8fd;}function wr(_0x1ceede){return _0x1ceede!==void 0x0&&_0x1ceede['enterprise']!==void 0x0;}class mf{constructor(_0x5eb449){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5eb449['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5eb449['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5eb449['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x493b63){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x58b974 of this['recaptchaEnforcementState'])if(_0x58b974['provider']&&_0x58b974['provider']===_0x493b63)return _f(_0x58b974['enforcementState']);return null;}['isProviderEnabled'](_0x49cedf){return this['getProviderEnforcementState'](_0x49cedf)==='ENFORCE'||this['getProviderEnforcementState'](_0x49cedf)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1cea97,_0x3441bc){return Pe(_0x1cea97,'GET','/v2/recaptchaConfig',ke(_0x1cea97,_0x3441bc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x5935e3,_0x27a2db){return Pe(_0x5935e3,'POST','/v1/accounts:delete',_0x27a2db);}async function Pn(_0x1685a7,_0x15269b){return Pe(_0x1685a7,'POST','/v1/accounts:lookup',_0x15269b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x4d14f9){if(_0x4d14f9)try{const _0x51be86=new Date(Number(_0x4d14f9));if(!isNaN(_0x51be86['getTime']()))return _0x51be86['toUTCString']();}catch{}}async function Ef(_0x449da9,_0xf7b492=!0x1){const _0x501e09=P(_0x449da9),_0x5e4988=await _0x501e09['getIdToken'](_0xf7b492),_0x213ed0=Ts(_0x5e4988);m(_0x213ed0&&_0x213ed0['exp']&&_0x213ed0['auth_time']&&_0x213ed0['iat'],_0x501e09['auth'],'internal-error');const _0xb1a405=typeof _0x213ed0['firebase']=='object'?_0x213ed0['firebase']:void 0x0,_0x895a75=_0xb1a405==null?void 0x0:_0xb1a405['sign_in_provider'];return{'claims':_0x213ed0,'token':_0x5e4988,'authTime':Pt(fi(_0x213ed0['auth_time'])),'issuedAtTime':Pt(fi(_0x213ed0['iat'])),'expirationTime':Pt(fi(_0x213ed0['exp'])),'signInProvider':_0x895a75||null,'signInSecondFactor':(_0xb1a405==null?void 0x0:_0xb1a405['sign_in_second_factor'])||null};}function fi(_0x3cebf9){return Number(_0x3cebf9)*0x3e8;}function Ts(_0x54c0d8){const [_0x3bc7f7,_0x48caeb,_0x34ba38]=_0x54c0d8['split']('.');if(_0x3bc7f7===void 0x0||_0x48caeb===void 0x0||_0x34ba38===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0xe33224=fn(_0x48caeb);return _0xe33224?JSON['parse'](_0xe33224):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5483f5){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5483f5==null?void 0x0:_0x5483f5['toString']()),null;}}function Cr(_0x508f55){const _0x2ec442=Ts(_0x508f55);return m(_0x2ec442,'internal-error'),m(typeof _0x2ec442['exp']<'u','internal-error'),m(typeof _0x2ec442['iat']<'u','internal-error'),Number(_0x2ec442['exp'])-Number(_0x2ec442['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x153bc2,_0x2f1282,_0x4cef84=!0x1){if(_0x4cef84)return _0x2f1282;try{return await _0x2f1282;}catch(_0x2f7316){throw _0x2f7316 instanceof Re&&If(_0x2f7316)&&_0x153bc2['auth']['currentUser']===_0x153bc2&&await _0x153bc2['auth']['signOut'](),_0x2f7316;}}function If({code:_0x564aab}){return _0x564aab==='auth/user-disabled'||_0x564aab==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x568b17){this['user']=_0x568b17,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x55407d){if(_0x55407d){const _0x409380=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x409380;}else{this['errorBackoff']=0x7530;const _0x1ea189=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1ea189);}}['schedule'](_0x2c211b=!0x1){if(!this['isRunning'])return;const _0x231dce=this['getInterval'](_0x2c211b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x231dce);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x383451){(_0x383451==null?void 0x0:_0x383451['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x212461,_0x53d976){this['createdAt']=_0x212461,this['lastLoginAt']=_0x53d976,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x519728){this['createdAt']=_0x519728['createdAt'],this['lastLoginAt']=_0x519728['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x451bd9){var _0x411c9d;const _0x1f509e=_0x451bd9['auth'],_0x504b3c=await _0x451bd9['getIdToken'](),_0x53a950=await Ht(_0x451bd9,Pn(_0x1f509e,{'idToken':_0x504b3c}));m(_0x53a950==null?void 0x0:_0x53a950['users']['length'],_0x1f509e,'internal-error');const _0x5e376d=_0x53a950['users'][0x0];_0x451bd9['_notifyReloadListener'](_0x5e376d);const _0x2908f7=(_0x411c9d=_0x5e376d['providerUserInfo'])!=null&&_0x411c9d['length']?Sa(_0x5e376d['providerUserInfo']):[],_0x1559d7=Tf(_0x451bd9['providerData'],_0x2908f7),_0x2122e5=_0x451bd9['isAnonymous'],_0x2239bf=!(_0x451bd9['email']&&_0x5e376d['passwordHash'])&&!(_0x1559d7!=null&&_0x1559d7['length']),_0xf833e3=_0x2122e5?_0x2239bf:!0x1,_0x1924c3={'uid':_0x5e376d['localId'],'displayName':_0x5e376d['displayName']||null,'photoURL':_0x5e376d['photoUrl']||null,'email':_0x5e376d['email']||null,'emailVerified':_0x5e376d['emailVerified']||!0x1,'phoneNumber':_0x5e376d['phoneNumber']||null,'tenantId':_0x5e376d['tenantId']||null,'providerData':_0x1559d7,'metadata':new Li(_0x5e376d['createdAt'],_0x5e376d['lastLoginAt']),'isAnonymous':_0xf833e3};Object['assign'](_0x451bd9,_0x1924c3);}async function Cf(_0x26673b){const _0x5637c8=P(_0x26673b);await Nn(_0x5637c8),await _0x5637c8['auth']['_persistUserIfCurrent'](_0x5637c8),_0x5637c8['auth']['_notifyListenersIfCurrent'](_0x5637c8);}function Tf(_0x176bc4,_0x5810f8){return[..._0x176bc4['filter'](_0x1fd9d7=>!_0x5810f8['some'](_0x8852d7=>_0x8852d7['providerId']===_0x1fd9d7['providerId'])),..._0x5810f8];}function Sa(_0x33c5f4){return _0x33c5f4['map'](({providerId:_0x3160a0,..._0x14f799})=>({'providerId':_0x3160a0,'uid':_0x14f799['rawId']||'','displayName':_0x14f799['displayName']||null,'email':_0x14f799['email']||null,'phoneNumber':_0x14f799['phoneNumber']||null,'photoURL':_0x14f799['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x28d03f,_0x374326){const _0x3d0c1e=await Ca(_0x28d03f,{},async()=>{const _0x47d93a=ut({'grant_type':'refresh_token','refresh_token':_0x374326})['slice'](0x1),{tokenApiHost:_0xbb94d4,apiKey:_0x838518}=_0x28d03f['config'],_0x56d30c=await Ta(_0x28d03f,_0xbb94d4,'/v1/token','key='+_0x838518),_0x82ecde=await _0x28d03f['_getAdditionalHeaders']();_0x82ecde['Content-Type']='application/x-www-form-urlencoded';const _0x4861d6={'method':'POST','headers':_0x82ecde,'body':_0x47d93a};return _0x28d03f['emulatorConfig']&&qt(_0x28d03f['emulatorConfig']['host'])&&(_0x4861d6['credentials']='include'),wa['fetch']()(_0x56d30c,_0x4861d6);});return{'accessToken':_0x3d0c1e['access_token'],'expiresIn':_0x3d0c1e['expires_in'],'refreshToken':_0x3d0c1e['refresh_token']};}async function bf(_0x4c9e5d,_0x38693c){return Pe(_0x4c9e5d,'POST','/v2/accounts:revokeToken',ke(_0x4c9e5d,_0x38693c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x528813){m(_0x528813['idToken'],'internal-error'),m(typeof _0x528813['idToken']<'u','internal-error'),m(typeof _0x528813['refreshToken']<'u','internal-error');const _0x297f3a='expiresIn'in _0x528813&&typeof _0x528813['expiresIn']<'u'?Number(_0x528813['expiresIn']):Cr(_0x528813['idToken']);this['updateTokensAndExpiration'](_0x528813['idToken'],_0x528813['refreshToken'],_0x297f3a);}['updateFromIdToken'](_0x5694cf){m(_0x5694cf['length']!==0x0,'internal-error');const _0x269362=Cr(_0x5694cf);this['updateTokensAndExpiration'](_0x5694cf,null,_0x269362);}async['getToken'](_0x48bdc3,_0xfe3fb7=!0x1){return!_0xfe3fb7&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x48bdc3,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x48bdc3,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x34eb93,_0xccb67f){const {accessToken:_0x3a0f62,refreshToken:_0x56d69c,expiresIn:_0x5f3891}=await Sf(_0x34eb93,_0xccb67f);this['updateTokensAndExpiration'](_0x3a0f62,_0x56d69c,Number(_0x5f3891));}['updateTokensAndExpiration'](_0x3135a4,_0x306a5a,_0x1e670f){this['refreshToken']=_0x306a5a||null,this['accessToken']=_0x3135a4||null,this['expirationTime']=Date['now']()+_0x1e670f*0x3e8;}static['fromJSON'](_0x2044cb,_0x7d3d92){const {refreshToken:_0x17f0f7,accessToken:_0x180a32,expirationTime:_0x2ec12a}=_0x7d3d92,_0x36b3ec=new et();return _0x17f0f7&&(m(typeof _0x17f0f7=='string','internal-error',{'appName':_0x2044cb}),_0x36b3ec['refreshToken']=_0x17f0f7),_0x180a32&&(m(typeof _0x180a32=='string','internal-error',{'appName':_0x2044cb}),_0x36b3ec['accessToken']=_0x180a32),_0x2ec12a&&(m(typeof _0x2ec12a=='number','internal-error',{'appName':_0x2044cb}),_0x36b3ec['expirationTime']=_0x2ec12a),_0x36b3ec;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x39bf4f){this['accessToken']=_0x39bf4f['accessToken'],this['refreshToken']=_0x39bf4f['refreshToken'],this['expirationTime']=_0x39bf4f['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x151322,_0x29bcba){m(typeof _0x151322=='string'||typeof _0x151322>'u','internal-error',{'appName':_0x29bcba});}class j{constructor({uid:_0x2b4c8a,auth:_0x468c4d,stsTokenManager:_0x3c7210,..._0x4c98c2}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2b4c8a,this['auth']=_0x468c4d,this['stsTokenManager']=_0x3c7210,this['accessToken']=_0x3c7210['accessToken'],this['displayName']=_0x4c98c2['displayName']||null,this['email']=_0x4c98c2['email']||null,this['emailVerified']=_0x4c98c2['emailVerified']||!0x1,this['phoneNumber']=_0x4c98c2['phoneNumber']||null,this['photoURL']=_0x4c98c2['photoURL']||null,this['isAnonymous']=_0x4c98c2['isAnonymous']||!0x1,this['tenantId']=_0x4c98c2['tenantId']||null,this['providerData']=_0x4c98c2['providerData']?[..._0x4c98c2['providerData']]:[],this['metadata']=new Li(_0x4c98c2['createdAt']||void 0x0,_0x4c98c2['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5e0c7a){const _0x3599db=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x5e0c7a));return m(_0x3599db,this['auth'],'internal-error'),this['accessToken']!==_0x3599db&&(this['accessToken']=_0x3599db,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3599db;}['getIdTokenResult'](_0x176015){return Ef(this,_0x176015);}['reload'](){return Cf(this);}['_assign'](_0x4324d6){this!==_0x4324d6&&(m(this['uid']===_0x4324d6['uid'],this['auth'],'internal-error'),this['displayName']=_0x4324d6['displayName'],this['photoURL']=_0x4324d6['photoURL'],this['email']=_0x4324d6['email'],this['emailVerified']=_0x4324d6['emailVerified'],this['phoneNumber']=_0x4324d6['phoneNumber'],this['isAnonymous']=_0x4324d6['isAnonymous'],this['tenantId']=_0x4324d6['tenantId'],this['providerData']=_0x4324d6['providerData']['map'](_0x3343b6=>({..._0x3343b6})),this['metadata']['_copy'](_0x4324d6['metadata']),this['stsTokenManager']['_assign'](_0x4324d6['stsTokenManager']));}['_clone'](_0x51772f){const _0x52ddbb=new j({...this,'auth':_0x51772f,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x52ddbb['metadata']['_copy'](this['metadata']),_0x52ddbb;}['_onReload'](_0x1a8496){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1a8496,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x52f9b7){this['reloadListener']?this['reloadListener'](_0x52f9b7):this['reloadUserInfo']=_0x52f9b7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xa9dff5,_0x51bc9c=!0x1){let _0x46514f=!0x1;_0xa9dff5['idToken']&&_0xa9dff5['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xa9dff5),_0x46514f=!0x0),_0x51bc9c&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x46514f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2729fa=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x2729fa})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4447b7=>({..._0x4447b7})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x439556,_0x480bb1){const _0x4df9c0=_0x480bb1['displayName']??void 0x0,_0x19fbf2=_0x480bb1['email']??void 0x0,_0x2235d3=_0x480bb1['phoneNumber']??void 0x0,_0x80f8a3=_0x480bb1['photoURL']??void 0x0,_0xaadf19=_0x480bb1['tenantId']??void 0x0,_0x3519a5=_0x480bb1['_redirectEventId']??void 0x0,_0x5524b2=_0x480bb1['createdAt']??void 0x0,_0x44c072=_0x480bb1['lastLoginAt']??void 0x0,{uid:_0x5bad7c,emailVerified:_0x7092e6,isAnonymous:_0x393779,providerData:_0x39d6c8,stsTokenManager:_0x25f18a}=_0x480bb1;m(_0x5bad7c&&_0x25f18a,_0x439556,'internal-error');const _0x353cab=et['fromJSON'](this['name'],_0x25f18a);m(typeof _0x5bad7c=='string',_0x439556,'internal-error'),le(_0x4df9c0,_0x439556['name']),le(_0x19fbf2,_0x439556['name']),m(typeof _0x7092e6=='boolean',_0x439556,'internal-error'),m(typeof _0x393779=='boolean',_0x439556,'internal-error'),le(_0x2235d3,_0x439556['name']),le(_0x80f8a3,_0x439556['name']),le(_0xaadf19,_0x439556['name']),le(_0x3519a5,_0x439556['name']),le(_0x5524b2,_0x439556['name']),le(_0x44c072,_0x439556['name']);const _0x47b945=new j({'uid':_0x5bad7c,'auth':_0x439556,'email':_0x19fbf2,'emailVerified':_0x7092e6,'displayName':_0x4df9c0,'isAnonymous':_0x393779,'photoURL':_0x80f8a3,'phoneNumber':_0x2235d3,'tenantId':_0xaadf19,'stsTokenManager':_0x353cab,'createdAt':_0x5524b2,'lastLoginAt':_0x44c072});return _0x39d6c8&&Array['isArray'](_0x39d6c8)&&(_0x47b945['providerData']=_0x39d6c8['map'](_0x9f5a88=>({..._0x9f5a88}))),_0x3519a5&&(_0x47b945['_redirectEventId']=_0x3519a5),_0x47b945;}static async['_fromIdTokenResponse'](_0x2b24b5,_0x19dc80,_0x5d874f=!0x1){const _0x41565a=new et();_0x41565a['updateFromServerResponse'](_0x19dc80);const _0x4ae96d=new j({'uid':_0x19dc80['localId'],'auth':_0x2b24b5,'stsTokenManager':_0x41565a,'isAnonymous':_0x5d874f});return await Nn(_0x4ae96d),_0x4ae96d;}static async['_fromGetAccountInfoResponse'](_0x5be925,_0x356483,_0x4ba6f0){const _0x20fb94=_0x356483['users'][0x0];m(_0x20fb94['localId']!==void 0x0,'internal-error');const _0x35d36b=_0x20fb94['providerUserInfo']!==void 0x0?Sa(_0x20fb94['providerUserInfo']):[],_0x5e9ef0=!(_0x20fb94['email']&&_0x20fb94['passwordHash'])&&!(_0x35d36b!=null&&_0x35d36b['length']),_0x2eb611=new et();_0x2eb611['updateFromIdToken'](_0x4ba6f0);const _0x2dfe55=new j({'uid':_0x20fb94['localId'],'auth':_0x5be925,'stsTokenManager':_0x2eb611,'isAnonymous':_0x5e9ef0}),_0x986869={'uid':_0x20fb94['localId'],'displayName':_0x20fb94['displayName']||null,'photoURL':_0x20fb94['photoUrl']||null,'email':_0x20fb94['email']||null,'emailVerified':_0x20fb94['emailVerified']||!0x1,'phoneNumber':_0x20fb94['phoneNumber']||null,'tenantId':_0x20fb94['tenantId']||null,'providerData':_0x35d36b,'metadata':new Li(_0x20fb94['createdAt'],_0x20fb94['lastLoginAt']),'isAnonymous':!(_0x20fb94['email']&&_0x20fb94['passwordHash'])&&!(_0x35d36b!=null&&_0x35d36b['length'])};return Object['assign'](_0x2dfe55,_0x986869),_0x2dfe55;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4ccba4){ce(_0x4ccba4 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5842ab=Tr['get'](_0x4ccba4);return _0x5842ab?(ce(_0x5842ab instanceof _0x4ccba4,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5842ab):(_0x5842ab=new _0x4ccba4(),Tr['set'](_0x4ccba4,_0x5842ab),_0x5842ab);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2b11b1,_0x324387){this['storage'][_0x2b11b1]=_0x324387;}async['_get'](_0x876c30){const _0x34f4c8=this['storage'][_0x876c30];return _0x34f4c8===void 0x0?null:_0x34f4c8;}async['_remove'](_0x34966c){delete this['storage'][_0x34966c];}['_addListener'](_0x62ef15,_0x353e7e){}['_removeListener'](_0xce2521,_0x50eb4d){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x18fdb6,_0x182e5f,_0x205d2a){return'firebase:'+_0x18fdb6+':'+_0x182e5f+':'+_0x205d2a;}class tt{constructor(_0x46f482,_0x6a989,_0x43047f){this['persistence']=_0x46f482,this['auth']=_0x6a989,this['userKey']=_0x43047f;const {config:_0xc88ff1,name:_0x472ed8}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0xc88ff1['apiKey'],_0x472ed8),this['fullPersistenceKey']=ln('persistence',_0xc88ff1['apiKey'],_0x472ed8),this['boundEventHandler']=_0x6a989['_onStorageEvent']['bind'](_0x6a989),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x12bf4c){return this['persistence']['_set'](this['fullUserKey'],_0x12bf4c['toJSON']());}async['getCurrentUser'](){const _0x16fba6=await this['persistence']['_get'](this['fullUserKey']);if(!_0x16fba6)return null;if(typeof _0x16fba6=='string'){const _0x947afa=await Pn(this['auth'],{'idToken':_0x16fba6})['catch'](()=>{});return _0x947afa?j['_fromGetAccountInfoResponse'](this['auth'],_0x947afa,_0x16fba6):null;}return j['_fromJSON'](this['auth'],_0x16fba6);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x443e58){if(this['persistence']===_0x443e58)return;const _0x6729e3=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x443e58,_0x6729e3)return this['setCurrentUser'](_0x6729e3);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x296ec2,_0x35680d,_0x359d37='authUser'){if(!_0x35680d['length'])return new tt(ie(Sr),_0x296ec2,_0x359d37);const _0x29c22b=(await Promise['all'](_0x35680d['map'](async _0x42943e=>{if(await _0x42943e['_isAvailable']())return _0x42943e;})))['filter'](_0x415987=>_0x415987);let _0x309da2=_0x29c22b[0x0]||ie(Sr);const _0x3409b6=ln(_0x359d37,_0x296ec2['config']['apiKey'],_0x296ec2['name']);let _0x506c12=null;for(const _0x35af58 of _0x35680d)try{const _0x3c47bb=await _0x35af58['_get'](_0x3409b6);if(_0x3c47bb){let _0x1154ff;if(typeof _0x3c47bb=='string'){const _0x4245b4=await Pn(_0x296ec2,{'idToken':_0x3c47bb})['catch'](()=>{});if(!_0x4245b4)break;_0x1154ff=await j['_fromGetAccountInfoResponse'](_0x296ec2,_0x4245b4,_0x3c47bb);}else _0x1154ff=j['_fromJSON'](_0x296ec2,_0x3c47bb);_0x35af58!==_0x309da2&&(_0x506c12=_0x1154ff),_0x309da2=_0x35af58;break;}}catch{}const _0x19b260=_0x29c22b['filter'](_0xc87400=>_0xc87400['_shouldAllowMigration']);return!_0x309da2['_shouldAllowMigration']||!_0x19b260['length']?new tt(_0x309da2,_0x296ec2,_0x359d37):(_0x309da2=_0x19b260[0x0],_0x506c12&&await _0x309da2['_set'](_0x3409b6,_0x506c12['toJSON']()),await Promise['all'](_0x35680d['map'](async _0x2aaa0d=>{if(_0x2aaa0d!==_0x309da2)try{await _0x2aaa0d['_remove'](_0x3409b6);}catch{}})),new tt(_0x309da2,_0x296ec2,_0x359d37));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x553089){const _0x44c8b8=_0x553089['toLowerCase']();if(_0x44c8b8['includes']('opera/')||_0x44c8b8['includes']('opr/')||_0x44c8b8['includes']('opios/'))return'Opera';if(Pa(_0x44c8b8))return'IEMobile';if(_0x44c8b8['includes']('msie')||_0x44c8b8['includes']('trident/'))return'IE';if(_0x44c8b8['includes']('edge/'))return'Edge';if(Ra(_0x44c8b8))return'Firefox';if(_0x44c8b8['includes']('silk/'))return'Silk';if(Oa(_0x44c8b8))return'Blackberry';if(Da(_0x44c8b8))return'Webos';if(Aa(_0x44c8b8))return'Safari';if((_0x44c8b8['includes']('chrome/')||ka(_0x44c8b8))&&!_0x44c8b8['includes']('edge/'))return'Chrome';if(Na(_0x44c8b8))return'Android';{const _0x1a7f93=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4ede8f=_0x553089['match'](_0x1a7f93);if((_0x4ede8f==null?void 0x0:_0x4ede8f['length'])===0x2)return _0x4ede8f[0x1];}return'Other';}function Ra(_0x96c8ad=W()){return/firefox\//i['test'](_0x96c8ad);}function Aa(_0x2dbff7=W()){const _0x391b54=_0x2dbff7['toLowerCase']();return _0x391b54['includes']('safari/')&&!_0x391b54['includes']('chrome/')&&!_0x391b54['includes']('crios/')&&!_0x391b54['includes']('android');}function ka(_0x3754f7=W()){return/crios\//i['test'](_0x3754f7);}function Pa(_0x4a54e8=W()){return/iemobile/i['test'](_0x4a54e8);}function Na(_0x44db62=W()){return/android/i['test'](_0x44db62);}function Oa(_0xc91f34=W()){return/blackberry/i['test'](_0xc91f34);}function Da(_0x30dbde=W()){return/webos/i['test'](_0x30dbde);}function Ss(_0x5c6853=W()){return/iphone|ipad|ipod/i['test'](_0x5c6853)||/macintosh/i['test'](_0x5c6853)&&/mobile/i['test'](_0x5c6853);}function Rf(_0x2b1cbb=W()){var _0x2affb9;return Ss(_0x2b1cbb)&&!!((_0x2affb9=window['navigator'])!=null&&_0x2affb9['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3d2b3e=W()){return Ss(_0x3d2b3e)||Na(_0x3d2b3e)||Da(_0x3d2b3e)||Oa(_0x3d2b3e)||/windows phone/i['test'](_0x3d2b3e)||Pa(_0x3d2b3e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5931ae,_0x25cdaa=[]){let _0x184652;switch(_0x5931ae){case'Browser':_0x184652=br(W());break;case'Worker':_0x184652=br(W())+'-'+_0x5931ae;break;default:_0x184652=_0x5931ae;}const _0x33a3c4=_0x25cdaa['length']?_0x25cdaa['join'](','):'FirebaseCore-web';return _0x184652+'/JsCore/'+dt+'/'+_0x33a3c4;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3eb925){this['auth']=_0x3eb925,this['queue']=[];}['pushCallback'](_0x202151,_0x558412){const _0x12ecf8=_0x23ccdf=>new Promise((_0x5627b3,_0x5060ec)=>{try{const _0x2f271b=_0x202151(_0x23ccdf);_0x5627b3(_0x2f271b);}catch(_0x37d819){_0x5060ec(_0x37d819);}});_0x12ecf8['onAbort']=_0x558412,this['queue']['push'](_0x12ecf8);const _0x200a90=this['queue']['length']-0x1;return()=>{this['queue'][_0x200a90]=()=>Promise['resolve']();};}async['runMiddleware'](_0x28a5d0){if(this['auth']['currentUser']===_0x28a5d0)return;const _0x4e47f7=[];try{for(const _0x4fdfaf of this['queue'])await _0x4fdfaf(_0x28a5d0),_0x4fdfaf['onAbort']&&_0x4e47f7['push'](_0x4fdfaf['onAbort']);}catch(_0x3b4607){_0x4e47f7['reverse']();for(const _0xd153fc of _0x4e47f7)try{_0xd153fc();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3b4607==null?void 0x0:_0x3b4607['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0xfabc8b,_0x864c6={}){return Pe(_0xfabc8b,'GET','/v2/passwordPolicy',ke(_0xfabc8b,_0x864c6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x24cd13){var _0x3ffbf0;const _0x3a2f1c=_0x24cd13['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3a2f1c['minPasswordLength']??Nf,_0x3a2f1c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3a2f1c['maxPasswordLength']),_0x3a2f1c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3a2f1c['containsLowercaseCharacter']),_0x3a2f1c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3a2f1c['containsUppercaseCharacter']),_0x3a2f1c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3a2f1c['containsNumericCharacter']),_0x3a2f1c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3a2f1c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x24cd13['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3ffbf0=_0x24cd13['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3ffbf0['join'](''))??'',this['forceUpgradeOnSignin']=_0x24cd13['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x24cd13['schemaVersion'];}['validatePassword'](_0x1ae509){const _0x4f1378={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1ae509,_0x4f1378),this['validatePasswordCharacterOptions'](_0x1ae509,_0x4f1378),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['meetsMinPasswordLength']??!0x0),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['meetsMaxPasswordLength']??!0x0),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['containsLowercaseLetter']??!0x0),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['containsUppercaseLetter']??!0x0),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['containsNumericCharacter']??!0x0),_0x4f1378['isValid']&&(_0x4f1378['isValid']=_0x4f1378['containsNonAlphanumericCharacter']??!0x0),_0x4f1378;}['validatePasswordLengthOptions'](_0x88d3bf,_0x42dbef){const _0xf87414=this['customStrengthOptions']['minPasswordLength'],_0x307eab=this['customStrengthOptions']['maxPasswordLength'];_0xf87414&&(_0x42dbef['meetsMinPasswordLength']=_0x88d3bf['length']>=_0xf87414),_0x307eab&&(_0x42dbef['meetsMaxPasswordLength']=_0x88d3bf['length']<=_0x307eab);}['validatePasswordCharacterOptions'](_0x37e29d,_0x145446){this['updatePasswordCharacterOptionsStatuses'](_0x145446,!0x1,!0x1,!0x1,!0x1);let _0x24d577;for(let _0x5244c2=0x0;_0x5244c2<_0x37e29d['length'];_0x5244c2++)_0x24d577=_0x37e29d['charAt'](_0x5244c2),this['updatePasswordCharacterOptionsStatuses'](_0x145446,_0x24d577>='a'&&_0x24d577<='z',_0x24d577>='A'&&_0x24d577<='Z',_0x24d577>='0'&&_0x24d577<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x24d577));}['updatePasswordCharacterOptionsStatuses'](_0x22e6c8,_0x191317,_0x56df18,_0x8c02a0,_0x20f41e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x22e6c8['containsLowercaseLetter']||(_0x22e6c8['containsLowercaseLetter']=_0x191317)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x22e6c8['containsUppercaseLetter']||(_0x22e6c8['containsUppercaseLetter']=_0x56df18)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x22e6c8['containsNumericCharacter']||(_0x22e6c8['containsNumericCharacter']=_0x8c02a0)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x22e6c8['containsNonAlphanumericCharacter']||(_0x22e6c8['containsNonAlphanumericCharacter']=_0x20f41e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x529c54,_0x429cc8,_0x456b2f,_0x2ec2f4){this['app']=_0x529c54,this['heartbeatServiceProvider']=_0x429cc8,this['appCheckServiceProvider']=_0x456b2f,this['config']=_0x2ec2f4,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x529c54['name'],this['clientVersion']=_0x2ec2f4['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1ba269=>this['_resolvePersistenceManagerAvailable']=_0x1ba269);}['_initializeWithPersistence'](_0x302a26,_0x4b312a){return _0x4b312a&&(this['_popupRedirectResolver']=ie(_0x4b312a)),this['_initializationPromise']=this['queue'](async()=>{var _0x5711ce,_0x2f2777,_0x37c76b;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x302a26),(_0x5711ce=this['_resolvePersistenceManagerAvailable'])==null||_0x5711ce['call'](this),!this['_deleted'])){if((_0x2f2777=this['_popupRedirectResolver'])!=null&&_0x2f2777['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4b312a),this['lastNotifiedUid']=((_0x37c76b=this['currentUser'])==null?void 0x0:_0x37c76b['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2760d0=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2760d0)){if(this['currentUser']&&_0x2760d0&&this['currentUser']['uid']===_0x2760d0['uid']){this['_currentUser']['_assign'](_0x2760d0),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2760d0,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2f60f7){try{const _0x1619a1=await Pn(this,{'idToken':_0x2f60f7}),_0x2f1ac9=await j['_fromGetAccountInfoResponse'](this,_0x1619a1,_0x2f60f7);await this['directlySetCurrentUser'](_0x2f1ac9);}catch(_0x208a96){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x208a96),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4214a7){var _0x1c8d55;if($(this['app'])){const _0x461744=this['app']['settings']['authIdToken'];return _0x461744?new Promise(_0x2f7811=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x461744)['then'](_0x2f7811,_0x2f7811));}):this['directlySetCurrentUser'](null);}const _0x483a3d=await this['assertedPersistence']['getCurrentUser']();let _0x57fb04=_0x483a3d,_0x5a4c8a=!0x1;if(_0x4214a7&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x59faab=(_0x1c8d55=this['redirectUser'])==null?void 0x0:_0x1c8d55['_redirectEventId'],_0x5e37e7=_0x57fb04==null?void 0x0:_0x57fb04['_redirectEventId'],_0x3b0f89=await this['tryRedirectSignIn'](_0x4214a7);(!_0x59faab||_0x59faab===_0x5e37e7)&&(_0x3b0f89!=null&&_0x3b0f89['user'])&&(_0x57fb04=_0x3b0f89['user'],_0x5a4c8a=!0x0);}if(!_0x57fb04)return this['directlySetCurrentUser'](null);if(!_0x57fb04['_redirectEventId']){if(_0x5a4c8a)try{await this['beforeStateQueue']['runMiddleware'](_0x57fb04);}catch(_0x1a9092){_0x57fb04=_0x483a3d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1a9092));}return _0x57fb04?this['reloadAndSetCurrentUserOrClear'](_0x57fb04):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x57fb04['_redirectEventId']?this['directlySetCurrentUser'](_0x57fb04):this['reloadAndSetCurrentUserOrClear'](_0x57fb04);}async['tryRedirectSignIn'](_0x4bb743){let _0x4557ae=null;try{_0x4557ae=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4bb743,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4557ae;}async['reloadAndSetCurrentUserOrClear'](_0x3cbbcd){try{await Nn(_0x3cbbcd);}catch(_0x4a0781){if((_0x4a0781==null?void 0x0:_0x4a0781['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3cbbcd);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x15226d){if($(this['app']))return Promise['reject'](re(this));const _0x5cc522=_0x15226d?P(_0x15226d):null;return _0x5cc522&&m(_0x5cc522['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5cc522&&_0x5cc522['_clone'](this));}async['_updateCurrentUser'](_0x884851,_0x3e44ef=!0x1){if(!this['_deleted'])return _0x884851&&m(this['tenantId']===_0x884851['tenantId'],this,'tenant-id-mismatch'),_0x3e44ef||await this['beforeStateQueue']['runMiddleware'](_0x884851),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x884851),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1336b1){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1336b1));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2c1482){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0xecdc90=this['_getPasswordPolicyInternal']();return _0xecdc90['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0xecdc90['validatePassword'](_0x2c1482);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4e64ae=await Pf(this),_0x21d915=new Of(_0x4e64ae);this['tenantId']===null?this['_projectPasswordPolicy']=_0x21d915:this['_tenantPasswordPolicies'][this['tenantId']]=_0x21d915;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3f8c19){this['_errorFactory']=new Gt('auth','Firebase',_0x3f8c19());}['onAuthStateChanged'](_0x1d537c,_0x374fb3,_0x2c8ea6){return this['registerStateListener'](this['authStateSubscription'],_0x1d537c,_0x374fb3,_0x2c8ea6);}['beforeAuthStateChanged'](_0x5d5ce4,_0xd5b72f){return this['beforeStateQueue']['pushCallback'](_0x5d5ce4,_0xd5b72f);}['onIdTokenChanged'](_0x2dbe3a,_0x163239,_0x52be08){return this['registerStateListener'](this['idTokenSubscription'],_0x2dbe3a,_0x163239,_0x52be08);}['authStateReady'](){return new Promise((_0x28c0b1,_0x58a3c5)=>{if(this['currentUser'])_0x28c0b1();else{const _0x43f9c4=this['onAuthStateChanged'](()=>{_0x43f9c4(),_0x28c0b1();},_0x58a3c5);}});}async['revokeAccessToken'](_0x52fac0){if(this['currentUser']){const _0x454841=await this['currentUser']['getIdToken'](),_0x417eb0={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x52fac0,'idToken':_0x454841};this['tenantId']!=null&&(_0x417eb0['tenantId']=this['tenantId']),await bf(this,_0x417eb0);}}['toJSON'](){var _0xf4841b;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xf4841b=this['_currentUser'])==null?void 0x0:_0xf4841b['toJSON']()};}async['_setRedirectUser'](_0x50bd09,_0x53e922){const _0x25f95c=await this['getOrInitRedirectPersistenceManager'](_0x53e922);return _0x50bd09===null?_0x25f95c['removeCurrentUser']():_0x25f95c['setCurrentUser'](_0x50bd09);}async['getOrInitRedirectPersistenceManager'](_0x29109e){if(!this['redirectPersistenceManager']){const _0x39d856=_0x29109e&&ie(_0x29109e)||this['_popupRedirectResolver'];m(_0x39d856,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x39d856['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xaf2649){var _0x27384d,_0x27f93b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x27384d=this['_currentUser'])==null?void 0x0:_0x27384d['_redirectEventId'])===_0xaf2649?this['_currentUser']:((_0x27f93b=this['redirectUser'])==null?void 0x0:_0x27f93b['_redirectEventId'])===_0xaf2649?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x26d864){if(_0x26d864===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x26d864));}['_notifyListenersIfCurrent'](_0x2ca2e5){_0x2ca2e5===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x45aa00;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x33bf86=((_0x45aa00=this['currentUser'])==null?void 0x0:_0x45aa00['uid'])??null;this['lastNotifiedUid']!==_0x33bf86&&(this['lastNotifiedUid']=_0x33bf86,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4d50fb,_0x5550be,_0x3c82b6,_0x26a4d2){if(this['_deleted'])return()=>{};const _0x4685fa=typeof _0x5550be=='function'?_0x5550be:_0x5550be['next']['bind'](_0x5550be);let _0x5c123a=!0x1;const _0xba1fd6=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xba1fd6,this,'internal-error'),_0xba1fd6['then'](()=>{_0x5c123a||_0x4685fa(this['currentUser']);}),typeof _0x5550be=='function'){const _0x3c71c2=_0x4d50fb['addObserver'](_0x5550be,_0x3c82b6,_0x26a4d2);return()=>{_0x5c123a=!0x0,_0x3c71c2();};}else{const _0x5e1b2b=_0x4d50fb['addObserver'](_0x5550be);return()=>{_0x5c123a=!0x0,_0x5e1b2b();};}}async['directlySetCurrentUser'](_0x1289b6){this['currentUser']&&this['currentUser']!==_0x1289b6&&this['_currentUser']['_stopProactiveRefresh'](),_0x1289b6&&this['isProactiveRefreshEnabled']&&_0x1289b6['_startProactiveRefresh'](),this['currentUser']=_0x1289b6,_0x1289b6?await this['assertedPersistence']['setCurrentUser'](_0x1289b6):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5e78d5){return this['operations']=this['operations']['then'](_0x5e78d5,_0x5e78d5),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x18cb6c){!_0x18cb6c||this['frameworks']['includes'](_0x18cb6c)||(this['frameworks']['push'](_0x18cb6c),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2452c0;const _0x1f070d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1f070d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3a8672=await((_0x2452c0=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2452c0['getHeartbeatsHeader']());_0x3a8672&&(_0x1f070d['X-Firebase-Client']=_0x3a8672);const _0xeea0f0=await this['_getAppCheckToken']();return _0xeea0f0&&(_0x1f070d['X-Firebase-AppCheck']=_0xeea0f0),_0x1f070d;}async['_getAppCheckToken'](){var _0x527a3d;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3b2f4b=await((_0x527a3d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x527a3d['getToken']());return _0x3b2f4b!=null&&_0x3b2f4b['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3b2f4b['error']),_0x3b2f4b==null?void 0x0:_0x3b2f4b['token'];}}function Ke(_0x2cbdc4){return P(_0x2cbdc4);}class Rr{constructor(_0x2a9886){this['auth']=_0x2a9886,this['observer']=null,this['addObserver']=Tc(_0x4c15e9=>this['observer']=_0x4c15e9);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x254305){Jn=_0x254305;}function xa(_0x247a09){return Jn['loadJS'](_0x247a09);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x3684d6){return'__'+_0x3684d6+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x2a44d6){_0x2a44d6();}['execute'](_0xf50f9a,_0x9b426e){return Promise['resolve']('token');}['render'](_0x310cb4,_0x393b8d){return'';}}class Wf{['ready'](_0x44450b){_0x44450b();}['execute'](_0x44733a,_0x361442){return Promise['resolve']('token');}['render'](_0x2bfc8a,_0x5738b3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x335f25){this['type']=Bf,this['auth']=Ke(_0x335f25);}async['verify'](_0x86dfec='verify',_0x32d3d3=!0x1){async function _0x1a326e(_0x150d1d){if(!_0x32d3d3){if(_0x150d1d['tenantId']==null&&_0x150d1d['_agentRecaptchaConfig']!=null)return _0x150d1d['_agentRecaptchaConfig']['siteKey'];if(_0x150d1d['tenantId']!=null&&_0x150d1d['_tenantRecaptchaConfigs'][_0x150d1d['tenantId']]!==void 0x0)return _0x150d1d['_tenantRecaptchaConfigs'][_0x150d1d['tenantId']]['siteKey'];}return new Promise(async(_0x232455,_0x2cd042)=>{yf(_0x150d1d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x181f38=>{if(_0x181f38['recaptchaKey']===void 0x0)_0x2cd042(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3a1603=new mf(_0x181f38);return _0x150d1d['tenantId']==null?_0x150d1d['_agentRecaptchaConfig']=_0x3a1603:_0x150d1d['_tenantRecaptchaConfigs'][_0x150d1d['tenantId']]=_0x3a1603,_0x232455(_0x3a1603['siteKey']);}})['catch'](_0x5730e2=>{_0x2cd042(_0x5730e2);});});}function _0x384137(_0x15d426,_0x1b2c90,_0x1e8097){const _0x4c2013=window['grecaptcha'];wr(_0x4c2013)?_0x4c2013['enterprise']['ready'](()=>{_0x4c2013['enterprise']['execute'](_0x15d426,{'action':_0x86dfec})['then'](_0x29d6d5=>{_0x1b2c90(_0x29d6d5);})['catch'](()=>{_0x1b2c90(Fa);});}):_0x1e8097(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x260cbe,_0x5236bb)=>{_0x1a326e(this['auth'])['then'](async _0x122a71=>{if(!_0x32d3d3&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x384137(_0x122a71,_0x260cbe,_0x5236bb);else{if(typeof window>'u'){_0x5236bb(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3bacb8=Lf();_0x3bacb8['length']!==0x0&&(_0x3bacb8+=_0x122a71+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x2978e4;(_0x2978e4=he['scriptInjectionDeferred'])==null||_0x2978e4['resolve']();},xa(_0x3bacb8)['then'](()=>{var _0x20bb94;return(_0x20bb94=he['scriptInjectionDeferred'])==null?void 0x0:_0x20bb94['promise'];})['then'](()=>{_0x384137(_0x122a71,_0x260cbe,_0x5236bb);})['catch'](_0x2772f2=>{_0x5236bb(_0x2772f2);});}})['catch'](_0x391016=>{_0x5236bb(_0x391016);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x1b6a85,_0x29883c,_0xe77030,_0x7efcd5=!0x1,_0x4a3cde=!0x1){const _0xeea4d=new he(_0x1b6a85);let _0x2d0a7b;if(_0x4a3cde)_0x2d0a7b=Fa;else try{_0x2d0a7b=await _0xeea4d['verify'](_0xe77030);}catch{_0x2d0a7b=await _0xeea4d['verify'](_0xe77030,!0x0);}const _0xa59984={..._0x29883c};if(_0xe77030==='mfaSmsEnrollment'||_0xe77030==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0xa59984){const _0x1fb814=_0xa59984['phoneEnrollmentInfo']['phoneNumber'],_0x2a6d40=_0xa59984['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0xa59984,{'phoneEnrollmentInfo':{'phoneNumber':_0x1fb814,'recaptchaToken':_0x2a6d40,'captchaResponse':_0x2d0a7b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0xa59984){const _0x36ddd4=_0xa59984['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0xa59984,{'phoneSignInInfo':{'recaptchaToken':_0x36ddd4,'captchaResponse':_0x2d0a7b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0xa59984;}return _0x7efcd5?Object['assign'](_0xa59984,{'captchaResp':_0x2d0a7b}):Object['assign'](_0xa59984,{'captchaResponse':_0x2d0a7b}),Object['assign'](_0xa59984,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0xa59984,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0xa59984;}async function xi(_0x5ac874,_0x2d6a03,_0x16adf8,_0x2e3624,_0x22e99b){var _0x33cbf6;if((_0x33cbf6=_0x5ac874['_getRecaptchaConfig']())!=null&&_0x33cbf6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x596010=await kr(_0x5ac874,_0x2d6a03,_0x16adf8,_0x16adf8==='getOobCode');return _0x2e3624(_0x5ac874,_0x596010);}else return _0x2e3624(_0x5ac874,_0x2d6a03)['catch'](async _0x173939=>{if(_0x173939['code']==='auth/missing-recaptcha-token'){console['log'](_0x16adf8+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x406207=await kr(_0x5ac874,_0x2d6a03,_0x16adf8,_0x16adf8==='getOobCode');return _0x2e3624(_0x5ac874,_0x406207);}else return Promise['reject'](_0x173939);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0xa65d2a,_0x32a69b){const _0xc0dc1a=Hi(_0xa65d2a,'auth');if(_0xc0dc1a['isInitialized']()){const _0x5c9454=_0xc0dc1a['getImmediate'](),_0x546147=_0xc0dc1a['getOptions']();if(xe(_0x546147,_0x32a69b??{}))return _0x5c9454;Y(_0x5c9454,'already-initialized');}return _0xc0dc1a['initialize']({'options':_0x32a69b});}function Hf(_0x3c8667,_0x341a10){const _0x4c6865=(_0x341a10==null?void 0x0:_0x341a10['persistence'])||[],_0x53c049=(Array['isArray'](_0x4c6865)?_0x4c6865:[_0x4c6865])['map'](ie);_0x341a10!=null&&_0x341a10['errorMap']&&_0x3c8667['_updateErrorMap'](_0x341a10['errorMap']),_0x3c8667['_initializeWithPersistence'](_0x53c049,_0x341a10==null?void 0x0:_0x341a10['popupRedirectResolver']);}function $f(_0x4a3ce3,_0x4d2dd7,_0x4ade68){const _0x31e696=Ke(_0x4a3ce3);m(/^https?:\/\//['test'](_0x4d2dd7),_0x31e696,'invalid-emulator-scheme');const _0x3257cd=!0x1,_0x70b686=Ua(_0x4d2dd7),{host:_0x24f958,port:_0x5a2a37}=Gf(_0x4d2dd7),_0xc712d=_0x5a2a37===null?'':':'+_0x5a2a37,_0x290fc0={'url':_0x70b686+'//'+_0x24f958+_0xc712d+'/'},_0x40fd5f=Object['freeze']({'host':_0x24f958,'port':_0x5a2a37,'protocol':_0x70b686['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3257cd})});if(!_0x31e696['_canInitEmulator']){m(_0x31e696['config']['emulator']&&_0x31e696['emulatorConfig'],_0x31e696,'emulator-config-failed'),m(xe(_0x290fc0,_0x31e696['config']['emulator'])&&xe(_0x40fd5f,_0x31e696['emulatorConfig']),_0x31e696,'emulator-config-failed');return;}_0x31e696['config']['emulator']=_0x290fc0,_0x31e696['emulatorConfig']=_0x40fd5f,_0x31e696['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x24f958)?Qr(_0x70b686+'//'+_0x24f958+_0xc712d):qf();}function Ua(_0x104193){const _0x190b48=_0x104193['indexOf'](':');return _0x190b48<0x0?'':_0x104193['substr'](0x0,_0x190b48+0x1);}function Gf(_0xdde6fa){const _0xc20e5f=Ua(_0xdde6fa),_0x34938b=/(\/\/)?([^?#/]+)/['exec'](_0xdde6fa['substr'](_0xc20e5f['length']));if(!_0x34938b)return{'host':'','port':null};const _0x1f8e00=_0x34938b[0x2]['split']('@')['pop']()||'',_0x5a5604=/^(\[[^\]]+\])(:|$)/['exec'](_0x1f8e00);if(_0x5a5604){const _0x41542d=_0x5a5604[0x1];return{'host':_0x41542d,'port':Pr(_0x1f8e00['substr'](_0x41542d['length']+0x1))};}else{const [_0x5b2190,_0x43d89a]=_0x1f8e00['split'](':');return{'host':_0x5b2190,'port':Pr(_0x43d89a)};}}function Pr(_0xbc4620){if(!_0xbc4620)return null;const _0x4d52ac=Number(_0xbc4620);return isNaN(_0x4d52ac)?null:_0x4d52ac;}function qf(){function _0x556744(){const _0x28cea2=document['createElement']('p'),_0x2ebb1f=_0x28cea2['style'];_0x28cea2['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2ebb1f['position']='fixed',_0x2ebb1f['width']='100%',_0x2ebb1f['backgroundColor']='#ffffff',_0x2ebb1f['border']='.1em\x20solid\x20#000000',_0x2ebb1f['color']='#b50000',_0x2ebb1f['bottom']='0px',_0x2ebb1f['left']='0px',_0x2ebb1f['margin']='0px',_0x2ebb1f['zIndex']='10000',_0x2ebb1f['textAlign']='center',_0x28cea2['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x28cea2);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x556744):_0x556744());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3462b9,_0x1e815f){this['providerId']=_0x3462b9,this['signInMethod']=_0x1e815f;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0xc684a5){return ne('not\x20implemented');}['_linkToIdToken'](_0x1d2c35,_0x6d9036){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1d85ee){return ne('not\x20implemented');}}async function zf(_0x3cc99a,_0x15ae89){return Pe(_0x3cc99a,'POST','/v1/accounts:signUp',_0x15ae89);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x543299,_0x13455e){return en(_0x543299,'POST','/v1/accounts:signInWithPassword',ke(_0x543299,_0x13455e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x23421b,_0x5df48d){return en(_0x23421b,'POST','/v1/accounts:signInWithEmailLink',ke(_0x23421b,_0x5df48d));}async function Yf(_0x263fcc,_0x26b80b){return en(_0x263fcc,'POST','/v1/accounts:signInWithEmailLink',ke(_0x263fcc,_0x26b80b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x449aa3,_0x251d45,_0x32ca72,_0x4682b3=null){super('password',_0x32ca72),this['_email']=_0x449aa3,this['_password']=_0x251d45,this['_tenantId']=_0x4682b3;}static['_fromEmailAndPassword'](_0x457087,_0x569112){return new $t(_0x457087,_0x569112,'password');}static['_fromEmailAndCode'](_0x53b461,_0xea6330,_0x279f92=null){return new $t(_0x53b461,_0xea6330,'emailLink',_0x279f92);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2da6f1){const _0x1a6fb5=typeof _0x2da6f1=='string'?JSON['parse'](_0x2da6f1):_0x2da6f1;if(_0x1a6fb5!=null&&_0x1a6fb5['email']&&(_0x1a6fb5!=null&&_0x1a6fb5['password'])){if(_0x1a6fb5['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1a6fb5['email'],_0x1a6fb5['password']);if(_0x1a6fb5['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1a6fb5['email'],_0x1a6fb5['password'],_0x1a6fb5['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5f370c){switch(this['signInMethod']){case'password':const _0x11e905={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5f370c,_0x11e905,'signInWithPassword',jf);case'emailLink':return Kf(_0x5f370c,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5f370c,'internal-error');}}async['_linkToIdToken'](_0x582c1d,_0x153086){switch(this['signInMethod']){case'password':const _0x55b5ee={'idToken':_0x153086,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x582c1d,_0x55b5ee,'signUpPassword',zf);case'emailLink':return Yf(_0x582c1d,{'idToken':_0x153086,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x582c1d,'internal-error');}}['_getReauthenticationResolver'](_0x55d6c8){return this['_getIdTokenResponse'](_0x55d6c8);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1ba85d,_0x48071c){return en(_0x1ba85d,'POST','/v1/accounts:signInWithIdp',ke(_0x1ba85d,_0x48071c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x29898c){const _0x2ba3fb=new $e(_0x29898c['providerId'],_0x29898c['signInMethod']);return _0x29898c['idToken']||_0x29898c['accessToken']?(_0x29898c['idToken']&&(_0x2ba3fb['idToken']=_0x29898c['idToken']),_0x29898c['accessToken']&&(_0x2ba3fb['accessToken']=_0x29898c['accessToken']),_0x29898c['nonce']&&!_0x29898c['pendingToken']&&(_0x2ba3fb['nonce']=_0x29898c['nonce']),_0x29898c['pendingToken']&&(_0x2ba3fb['pendingToken']=_0x29898c['pendingToken'])):_0x29898c['oauthToken']&&_0x29898c['oauthTokenSecret']?(_0x2ba3fb['accessToken']=_0x29898c['oauthToken'],_0x2ba3fb['secret']=_0x29898c['oauthTokenSecret']):Y('argument-error'),_0x2ba3fb;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x19a517){const _0x34b4a5=typeof _0x19a517=='string'?JSON['parse'](_0x19a517):_0x19a517,{providerId:_0x2acd71,signInMethod:_0x463e4f,..._0x27887e}=_0x34b4a5;if(!_0x2acd71||!_0x463e4f)return null;const _0x4593ae=new $e(_0x2acd71,_0x463e4f);return _0x4593ae['idToken']=_0x27887e['idToken']||void 0x0,_0x4593ae['accessToken']=_0x27887e['accessToken']||void 0x0,_0x4593ae['secret']=_0x27887e['secret'],_0x4593ae['nonce']=_0x27887e['nonce'],_0x4593ae['pendingToken']=_0x27887e['pendingToken']||null,_0x4593ae;}['_getIdTokenResponse'](_0x28bdb7){const _0x4a7ad6=this['buildRequest']();return nt(_0x28bdb7,_0x4a7ad6);}['_linkToIdToken'](_0x3b4acb,_0x55aaa3){const _0x4c6913=this['buildRequest']();return _0x4c6913['idToken']=_0x55aaa3,nt(_0x3b4acb,_0x4c6913);}['_getReauthenticationResolver'](_0x55221a){const _0x152da0=this['buildRequest']();return _0x152da0['autoCreate']=!0x1,nt(_0x55221a,_0x152da0);}['buildRequest'](){const _0x499374={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x499374['pendingToken']=this['pendingToken'];else{const _0x172576={};this['idToken']&&(_0x172576['id_token']=this['idToken']),this['accessToken']&&(_0x172576['access_token']=this['accessToken']),this['secret']&&(_0x172576['oauth_token_secret']=this['secret']),_0x172576['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x172576['nonce']=this['nonce']),_0x499374['postBody']=ut(_0x172576);}return _0x499374;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1da94d){switch(_0x1da94d){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x3e641e){const _0x362ec9=Ct(Tt(_0x3e641e))['link'],_0x4e9afc=_0x362ec9?Ct(Tt(_0x362ec9))['deep_link_id']:null,_0x392e9c=Ct(Tt(_0x3e641e))['deep_link_id'];return(_0x392e9c?Ct(Tt(_0x392e9c))['link']:null)||_0x392e9c||_0x4e9afc||_0x362ec9||_0x3e641e;}class Rs{constructor(_0xa88729){const _0x4c73b1=Ct(Tt(_0xa88729)),_0x4f3608=_0x4c73b1['apiKey']??null,_0x129236=_0x4c73b1['oobCode']??null,_0x4c0ed0=Jf(_0x4c73b1['mode']??null);m(_0x4f3608&&_0x129236&&_0x4c0ed0,'argument-error'),this['apiKey']=_0x4f3608,this['operation']=_0x4c0ed0,this['code']=_0x129236,this['continueUrl']=_0x4c73b1['continueUrl']??null,this['languageCode']=_0x4c73b1['lang']??null,this['tenantId']=_0x4c73b1['tenantId']??null;}static['parseLink'](_0x589e7f){const _0x100fd0=Xf(_0x589e7f);try{return new Rs(_0x100fd0);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x239fc5,_0x51bb46){return $t['_fromEmailAndPassword'](_0x239fc5,_0x51bb46);}static['credentialWithLink'](_0x5e8501,_0x1f355b){const _0xe91b66=Rs['parseLink'](_0x1f355b);return m(_0xe91b66,'argument-error'),$t['_fromEmailAndCode'](_0x5e8501,_0xe91b66['code'],_0xe91b66['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x249a30){this['providerId']=_0x249a30,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2940d8){this['defaultLanguageCode']=_0x2940d8;}['setCustomParameters'](_0x40993b){return this['customParameters']=_0x40993b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x48748f){return this['scopes']['includes'](_0x48748f)||this['scopes']['push'](_0x48748f),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2d20f7){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2d20f7});}static['credentialFromResult'](_0x18e725){return ue['credentialFromTaggedObject'](_0x18e725);}static['credentialFromError'](_0x179429){return ue['credentialFromTaggedObject'](_0x179429['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x50407a}){if(!_0x50407a||!('oauthAccessToken'in _0x50407a)||!_0x50407a['oauthAccessToken'])return null;try{return ue['credential'](_0x50407a['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x469efe,_0x5203ae){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x469efe,'accessToken':_0x5203ae});}static['credentialFromResult'](_0x900f4){return de['credentialFromTaggedObject'](_0x900f4);}static['credentialFromError'](_0x1f39e3){return de['credentialFromTaggedObject'](_0x1f39e3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x415f6d}){if(!_0x415f6d)return null;const {oauthIdToken:_0x527378,oauthAccessToken:_0x57408d}=_0x415f6d;if(!_0x527378&&!_0x57408d)return null;try{return de['credential'](_0x527378,_0x57408d);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x17316e){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x17316e});}static['credentialFromResult'](_0x2e9e7e){return fe['credentialFromTaggedObject'](_0x2e9e7e);}static['credentialFromError'](_0x20bc38){return fe['credentialFromTaggedObject'](_0x20bc38['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x471692}){if(!_0x471692||!('oauthAccessToken'in _0x471692)||!_0x471692['oauthAccessToken'])return null;try{return fe['credential'](_0x471692['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x88958a,_0xd54e31){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x88958a,'oauthTokenSecret':_0xd54e31});}static['credentialFromResult'](_0x3a2183){return pe['credentialFromTaggedObject'](_0x3a2183);}static['credentialFromError'](_0x12c0f0){return pe['credentialFromTaggedObject'](_0x12c0f0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x38509c}){if(!_0x38509c)return null;const {oauthAccessToken:_0x50b880,oauthTokenSecret:_0x5c642a}=_0x38509c;if(!_0x50b880||!_0x5c642a)return null;try{return pe['credential'](_0x50b880,_0x5c642a);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x39bb93,_0x1c7569){return en(_0x39bb93,'POST','/v1/accounts:signUp',ke(_0x39bb93,_0x1c7569));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x163cd4){this['user']=_0x163cd4['user'],this['providerId']=_0x163cd4['providerId'],this['_tokenResponse']=_0x163cd4['_tokenResponse'],this['operationType']=_0x163cd4['operationType'];}static async['_fromIdTokenResponse'](_0x6118df,_0x4767e7,_0x5f4396,_0x1e70ad=!0x1){const _0x35e82b=await j['_fromIdTokenResponse'](_0x6118df,_0x5f4396,_0x1e70ad),_0x1915b6=Nr(_0x5f4396);return new Ge({'user':_0x35e82b,'providerId':_0x1915b6,'_tokenResponse':_0x5f4396,'operationType':_0x4767e7});}static async['_forOperation'](_0x2e2946,_0x106161,_0x3984fd){await _0x2e2946['_updateTokensIfNecessary'](_0x3984fd,!0x0);const _0x33e70b=Nr(_0x3984fd);return new Ge({'user':_0x2e2946,'providerId':_0x33e70b,'_tokenResponse':_0x3984fd,'operationType':_0x106161});}}function Nr(_0x58cc30){return _0x58cc30['providerId']?_0x58cc30['providerId']:'phoneNumber'in _0x58cc30?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x1347aa,_0x167b42,_0x1ea9f8,_0x141a52){super(_0x167b42['code'],_0x167b42['message']),this['operationType']=_0x1ea9f8,this['user']=_0x141a52,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x1347aa['name'],'tenantId':_0x1347aa['tenantId']??void 0x0,'_serverResponse':_0x167b42['customData']['_serverResponse'],'operationType':_0x1ea9f8};}static['_fromErrorAndOperation'](_0xc09ab8,_0x4ea5f3,_0x4920fb,_0x2e5871){return new On(_0xc09ab8,_0x4ea5f3,_0x4920fb,_0x2e5871);}}function Ba(_0x546bd2,_0x31d58e,_0x3f19f,_0x4dcb96){return(_0x31d58e==='reauthenticate'?_0x3f19f['_getReauthenticationResolver'](_0x546bd2):_0x3f19f['_getIdTokenResponse'](_0x546bd2))['catch'](_0xee9864=>{throw _0xee9864['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x546bd2,_0xee9864,_0x31d58e,_0x4dcb96):_0xee9864;});}async function ep(_0x2a0071,_0x45630a,_0x508809=!0x1){const _0x4e5ddb=await Ht(_0x2a0071,_0x45630a['_linkToIdToken'](_0x2a0071['auth'],await _0x2a0071['getIdToken']()),_0x508809);return Ge['_forOperation'](_0x2a0071,'link',_0x4e5ddb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x5e30ae,_0x443e27,_0xcbca4d=!0x1){const {auth:_0x33c727}=_0x5e30ae;if($(_0x33c727['app']))return Promise['reject'](re(_0x33c727));const _0x56f3e3='reauthenticate';try{const _0x244f7a=await Ht(_0x5e30ae,Ba(_0x33c727,_0x56f3e3,_0x443e27,_0x5e30ae),_0xcbca4d);m(_0x244f7a['idToken'],_0x33c727,'internal-error');const _0x45f24c=Ts(_0x244f7a['idToken']);m(_0x45f24c,_0x33c727,'internal-error');const {sub:_0x3559f6}=_0x45f24c;return m(_0x5e30ae['uid']===_0x3559f6,_0x33c727,'user-mismatch'),Ge['_forOperation'](_0x5e30ae,_0x56f3e3,_0x244f7a);}catch(_0x363bc1){throw(_0x363bc1==null?void 0x0:_0x363bc1['code'])==='auth/user-not-found'&&Y(_0x33c727,'user-mismatch'),_0x363bc1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x49dcb6,_0x5af7ea,_0x1f665f=!0x1){if($(_0x49dcb6['app']))return Promise['reject'](re(_0x49dcb6));const _0x3db0c9='signIn',_0x13a516=await Ba(_0x49dcb6,_0x3db0c9,_0x5af7ea),_0xf34419=await Ge['_fromIdTokenResponse'](_0x49dcb6,_0x3db0c9,_0x13a516);return _0x1f665f||await _0x49dcb6['_updateCurrentUser'](_0xf34419['user']),_0xf34419;}async function np(_0x262b3f,_0x2deacc){return Va(Ke(_0x262b3f),_0x2deacc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4e26f5){const _0x4919e8=Ke(_0x4e26f5);_0x4919e8['_getPasswordPolicyInternal']()&&await _0x4919e8['_updatePasswordPolicy']();}async function L_(_0x587f07,_0x1a2866,_0x469231){if($(_0x587f07['app']))return Promise['reject'](re(_0x587f07));const _0x3152eb=Ke(_0x587f07),_0x328d21=await xi(_0x3152eb,{'returnSecureToken':!0x0,'email':_0x1a2866,'password':_0x469231,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x2492ef=>{throw _0x2492ef['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x587f07),_0x2492ef;}),_0x46cb6b=await Ge['_fromIdTokenResponse'](_0x3152eb,'signIn',_0x328d21);return await _0x3152eb['_updateCurrentUser'](_0x46cb6b['user']),_0x46cb6b;}function x_(_0x886491,_0x2a6de7,_0x5de873){return $(_0x886491['app'])?Promise['reject'](re(_0x886491)):np(P(_0x886491),yt['credential'](_0x2a6de7,_0x5de873))['catch'](async _0x3a5044=>{throw _0x3a5044['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x886491),_0x3a5044;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0xb3551,_0x21a72d){return P(_0xb3551)['setPersistence'](_0x21a72d);}function ip(_0xdb9154,_0x5c9233,_0x27533f,_0x2de03b){return P(_0xdb9154)['onIdTokenChanged'](_0x5c9233,_0x27533f,_0x2de03b);}function sp(_0x1b0885,_0x2d76d9,_0x61e3e0){return P(_0x1b0885)['beforeAuthStateChanged'](_0x2d76d9,_0x61e3e0);}function U_(_0x1f1cea,_0x40c652,_0x247e68,_0x151836){return P(_0x1f1cea)['onAuthStateChanged'](_0x40c652,_0x247e68,_0x151836);}function W_(_0x316648){return P(_0x316648)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4621d8,_0x5df79c){this['storageRetriever']=_0x4621d8,this['type']=_0x5df79c;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4fab1e,_0x41b72c){return this['storage']['setItem'](_0x4fab1e,JSON['stringify'](_0x41b72c)),Promise['resolve']();}['_get'](_0x32310a){const _0x1b5bd9=this['storage']['getItem'](_0x32310a);return Promise['resolve'](_0x1b5bd9?JSON['parse'](_0x1b5bd9):null);}['_remove'](_0x58df11){return this['storage']['removeItem'](_0x58df11),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x28f990,_0x5f3658)=>this['onStorageEvent'](_0x28f990,_0x5f3658),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1d5bfe){for(const _0x6e3a57 of Object['keys'](this['listeners'])){const _0x47acc2=this['storage']['getItem'](_0x6e3a57),_0x28d04b=this['localCache'][_0x6e3a57];_0x47acc2!==_0x28d04b&&_0x1d5bfe(_0x6e3a57,_0x28d04b,_0x47acc2);}}['onStorageEvent'](_0xdf51e7,_0x5fedf7=!0x1){if(!_0xdf51e7['key']){this['forAllChangedKeys']((_0x1b46cd,_0x3781a1,_0x590f14)=>{this['notifyListeners'](_0x1b46cd,_0x590f14);});return;}const _0x38e21c=_0xdf51e7['key'];_0x5fedf7?this['detachListener']():this['stopPolling']();const _0x5c0c64=()=>{const _0x204d61=this['storage']['getItem'](_0x38e21c);!_0x5fedf7&&this['localCache'][_0x38e21c]===_0x204d61||this['notifyListeners'](_0x38e21c,_0x204d61);},_0x6ecfff=this['storage']['getItem'](_0x38e21c);Af()&&_0x6ecfff!==_0xdf51e7['newValue']&&_0xdf51e7['newValue']!==_0xdf51e7['oldValue']?setTimeout(_0x5c0c64,op):_0x5c0c64();}['notifyListeners'](_0x925981,_0x3e9864){this['localCache'][_0x925981]=_0x3e9864;const _0x219115=this['listeners'][_0x925981];if(_0x219115){for(const _0x5d5b95 of Array['from'](_0x219115))_0x5d5b95(_0x3e9864&&JSON['parse'](_0x3e9864));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x18cba,_0x5f5580,_0x517a05)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x18cba,'oldValue':_0x5f5580,'newValue':_0x517a05}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x46a28d,_0x28587){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x46a28d]||(this['listeners'][_0x46a28d]=new Set(),this['localCache'][_0x46a28d]=this['storage']['getItem'](_0x46a28d)),this['listeners'][_0x46a28d]['add'](_0x28587);}['_removeListener'](_0x1ce0a4,_0x43a011){this['listeners'][_0x1ce0a4]&&(this['listeners'][_0x1ce0a4]['delete'](_0x43a011),this['listeners'][_0x1ce0a4]['size']===0x0&&delete this['listeners'][_0x1ce0a4]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x230723,_0x14c61a){await super['_set'](_0x230723,_0x14c61a),this['localCache'][_0x230723]=JSON['stringify'](_0x14c61a);}async['_get'](_0x493874){const _0x5cf8ac=await super['_get'](_0x493874);return this['localCache'][_0x493874]=JSON['stringify'](_0x5cf8ac),_0x5cf8ac;}async['_remove'](_0x4174c2){await super['_remove'](_0x4174c2),delete this['localCache'][_0x4174c2];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x39d188,_0x475678){}['_removeListener'](_0x38a719,_0x1c4e1d){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x11ab55){return Promise['all'](_0x11ab55['map'](async _0x4dcd3e=>{try{return{'fulfilled':!0x0,'value':await _0x4dcd3e};}catch(_0x8ba817){return{'fulfilled':!0x1,'reason':_0x8ba817};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x3dad90){this['eventTarget']=_0x3dad90,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x28e194){const _0x142bcf=this['receivers']['find'](_0x259281=>_0x259281['isListeningto'](_0x28e194));if(_0x142bcf)return _0x142bcf;const _0x3a9153=new Xn(_0x28e194);return this['receivers']['push'](_0x3a9153),_0x3a9153;}['isListeningto'](_0x156108){return this['eventTarget']===_0x156108;}async['handleEvent'](_0x303399){const _0x5b5ecd=_0x303399,{eventId:_0x122f6f,eventType:_0xe284d0,data:_0x4ea2db}=_0x5b5ecd['data'],_0x468723=this['handlersMap'][_0xe284d0];if(!(_0x468723!=null&&_0x468723['size']))return;_0x5b5ecd['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x122f6f,'eventType':_0xe284d0});const _0x12a745=Array['from'](_0x468723)['map'](async _0x3ed513=>_0x3ed513(_0x5b5ecd['origin'],_0x4ea2db)),_0x45b85a=await cp(_0x12a745);_0x5b5ecd['ports'][0x0]['postMessage']({'status':'done','eventId':_0x122f6f,'eventType':_0xe284d0,'response':_0x45b85a});}['_subscribe'](_0x187ae8,_0x23a1e0){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x187ae8]||(this['handlersMap'][_0x187ae8]=new Set()),this['handlersMap'][_0x187ae8]['add'](_0x23a1e0);}['_unsubscribe'](_0x55d530,_0x436af8){this['handlersMap'][_0x55d530]&&_0x436af8&&this['handlersMap'][_0x55d530]['delete'](_0x436af8),(!_0x436af8||this['handlersMap'][_0x55d530]['size']===0x0)&&delete this['handlersMap'][_0x55d530],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4500dc='',_0x488f1f=0xa){let _0xa3a021='';for(let _0x1defdc=0x0;_0x1defdc<_0x488f1f;_0x1defdc++)_0xa3a021+=Math['floor'](Math['random']()*0xa);return _0x4500dc+_0xa3a021;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x15e821){this['target']=_0x15e821,this['handlers']=new Set();}['removeMessageHandler'](_0x1b8064){_0x1b8064['messageChannel']&&(_0x1b8064['messageChannel']['port1']['removeEventListener']('message',_0x1b8064['onMessage']),_0x1b8064['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1b8064);}async['_send'](_0x125bfe,_0x2265e6,_0x195b70=0x32){const _0x4d9dd3=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4d9dd3)throw new Error('connection_unavailable');let _0x5a4311,_0x37fae6;return new Promise((_0x50a51c,_0x5e4e2f)=>{const _0x47a273=As('',0x14);_0x4d9dd3['port1']['start']();const _0x1dc34e=setTimeout(()=>{_0x5e4e2f(new Error('unsupported_event'));},_0x195b70);_0x37fae6={'messageChannel':_0x4d9dd3,'onMessage'(_0x1197b3){const _0x408e34=_0x1197b3;if(_0x408e34['data']['eventId']===_0x47a273)switch(_0x408e34['data']['status']){case'ack':clearTimeout(_0x1dc34e),_0x5a4311=setTimeout(()=>{_0x5e4e2f(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5a4311),_0x50a51c(_0x408e34['data']['response']);break;default:clearTimeout(_0x1dc34e),clearTimeout(_0x5a4311),_0x5e4e2f(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x37fae6),_0x4d9dd3['port1']['addEventListener']('message',_0x37fae6['onMessage']),this['target']['postMessage']({'eventType':_0x125bfe,'eventId':_0x47a273,'data':_0x2265e6},[_0x4d9dd3['port2']]);})['finally'](()=>{_0x37fae6&&this['removeMessageHandler'](_0x37fae6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x196396){Z()['location']['href']=_0x196396;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2943ec;return((_0x2943ec=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2943ec['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x22d356){this['request']=_0x22d356;}['toPromise'](){return new Promise((_0x4b53a8,_0x4f413f)=>{this['request']['addEventListener']('success',()=>{_0x4b53a8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4f413f(this['request']['error']);});});}}function Zn(_0x56b64f,_0x3377fb){return _0x56b64f['transaction']([Mn],_0x3377fb?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x4d8389=indexedDB['deleteDatabase'](Ka);return new nn(_0x4d8389)['toPromise']();}function Qa(){const _0xcaca61=indexedDB['open'](Ka,pp);return new Promise((_0x4170f5,_0x1f0548)=>{_0xcaca61['addEventListener']('error',()=>{_0x1f0548(_0xcaca61['error']);}),_0xcaca61['addEventListener']('upgradeneeded',()=>{const _0x355051=_0xcaca61['result'];try{_0x355051['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x239324){_0x1f0548(_0x239324);}}),_0xcaca61['addEventListener']('success',async()=>{const _0x5cb1dc=_0xcaca61['result'];_0x5cb1dc['objectStoreNames']['contains'](Mn)?_0x4170f5(_0x5cb1dc):(_0x5cb1dc['close'](),await _p(),_0x4170f5(await Qa()));});});}async function Or(_0x3bd661,_0x2276a7,_0x4e5b4d){const _0x558ca3=Zn(_0x3bd661,!0x0)['put']({[Ya]:_0x2276a7,'value':_0x4e5b4d});return new nn(_0x558ca3)['toPromise']();}async function gp(_0x8fa7ea,_0x2e9b14){const _0x3b1cde=Zn(_0x8fa7ea,!0x1)['get'](_0x2e9b14),_0x4ff61d=await new nn(_0x3b1cde)['toPromise']();return _0x4ff61d===void 0x0?null:_0x4ff61d['value'];}function Dr(_0x3d2b5c,_0x40589b){const _0xa550f4=Zn(_0x3d2b5c,!0x0)['delete'](_0x40589b);return new nn(_0xa550f4)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x25585a){let _0x1196c8=0x0;for(;;)try{const _0x3d06c7=await this['_openDb']();return await _0x25585a(_0x3d06c7);}catch(_0x34e968){if(_0x1196c8++>yp)throw _0x34e968;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x1d9ada,_0x25afc4)=>({'keyProcessed':(await this['_poll']())['includes'](_0x25afc4['key'])})),this['receiver']['_subscribe']('ping',async(_0x3b4035,_0x3855e2)=>['keyChanged']);}async['initializeSender'](){var _0x4259dd,_0x1a042f;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2d71a0=await this['sender']['_send']('ping',{},0x320);_0x2d71a0&&(_0x4259dd=_0x2d71a0[0x0])!=null&&_0x4259dd['fulfilled']&&(_0x1a042f=_0x2d71a0[0x0])!=null&&_0x1a042f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x484005){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x484005},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3adf4a=>{await Or(_0x3adf4a,Dn,'1'),await Dr(_0x3adf4a,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3ff999){this['pendingWrites']++;try{await _0x3ff999();}finally{this['pendingWrites']--;}}async['_set'](_0x3cd84a,_0x375131){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3310be=>Or(_0x3310be,_0x3cd84a,_0x375131)),this['localCache'][_0x3cd84a]=_0x375131,this['notifyServiceWorker'](_0x3cd84a)));}async['_get'](_0x487eba){const _0x3659db=await this['_withRetries'](_0x6ff9ac=>gp(_0x6ff9ac,_0x487eba));return this['localCache'][_0x487eba]=_0x3659db,_0x3659db;}async['_remove'](_0xc8cea5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x22bcdc=>Dr(_0x22bcdc,_0xc8cea5)),delete this['localCache'][_0xc8cea5],this['notifyServiceWorker'](_0xc8cea5)));}async['_poll'](){const _0x4dea73=await this['_withRetries'](_0x47106e=>{const _0x23b61c=Zn(_0x47106e,!0x1)['getAll']();return new nn(_0x23b61c)['toPromise']();});if(!_0x4dea73)return[];if(this['pendingWrites']!==0x0)return[];const _0x37d4e3=[],_0x48adbc=new Set();if(_0x4dea73['length']!==0x0){for(const {fbase_key:_0x14c4cc,value:_0x49d666}of _0x4dea73)_0x48adbc['add'](_0x14c4cc),JSON['stringify'](this['localCache'][_0x14c4cc])!==JSON['stringify'](_0x49d666)&&(this['notifyListeners'](_0x14c4cc,_0x49d666),_0x37d4e3['push'](_0x14c4cc));}for(const _0x3a407b of Object['keys'](this['localCache']))this['localCache'][_0x3a407b]&&!_0x48adbc['has'](_0x3a407b)&&(this['notifyListeners'](_0x3a407b,null),_0x37d4e3['push'](_0x3a407b));return _0x37d4e3;}['notifyListeners'](_0xae6e42,_0x1ce6e1){this['localCache'][_0xae6e42]=_0x1ce6e1;const _0x3bb62d=this['listeners'][_0xae6e42];if(_0x3bb62d){for(const _0x167d6d of Array['from'](_0x3bb62d))_0x167d6d(_0x1ce6e1);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x30cd19,_0x22441d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x30cd19]||(this['listeners'][_0x30cd19]=new Set(),this['_get'](_0x30cd19)),this['listeners'][_0x30cd19]['add'](_0x22441d);}['_removeListener'](_0x2669a0,_0x4e7956){this['listeners'][_0x2669a0]&&(this['listeners'][_0x2669a0]['delete'](_0x4e7956),this['listeners'][_0x2669a0]['size']===0x0&&delete this['listeners'][_0x2669a0]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x35d281,_0x3a569e){return _0x3a569e?ie(_0x3a569e):(m(_0x35d281['_popupRedirectResolver'],_0x35d281,'argument-error'),_0x35d281['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x397845){super('custom','custom'),this['params']=_0x397845;}['_getIdTokenResponse'](_0x5860d9){return nt(_0x5860d9,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3935d6,_0x17e0fe){return nt(_0x3935d6,this['_buildIdpRequest'](_0x17e0fe));}['_getReauthenticationResolver'](_0x51dd6e){return nt(_0x51dd6e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x8f7ba7){const _0x3c4855={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x8f7ba7&&(_0x3c4855['idToken']=_0x8f7ba7),_0x3c4855;}}function Ip(_0x8acff3){return Va(_0x8acff3['auth'],new ks(_0x8acff3),_0x8acff3['bypassAuthState']);}function wp(_0xbb0c21){const {auth:_0x18f30d,user:_0x490b65}=_0xbb0c21;return m(_0x490b65,_0x18f30d,'internal-error'),tp(_0x490b65,new ks(_0xbb0c21),_0xbb0c21['bypassAuthState']);}async function Cp(_0x1d328d){const {auth:_0x1aa66b,user:_0x210f11}=_0x1d328d;return m(_0x210f11,_0x1aa66b,'internal-error'),ep(_0x210f11,new ks(_0x1d328d),_0x1d328d['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x5f3fae,_0x311eb5,_0x1063aa,_0xe71550,_0xf70087=!0x1){this['auth']=_0x5f3fae,this['resolver']=_0x1063aa,this['user']=_0xe71550,this['bypassAuthState']=_0xf70087,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x311eb5)?_0x311eb5:[_0x311eb5];}['execute'](){return new Promise(async(_0x13be8b,_0x1072d8)=>{this['pendingPromise']={'resolve':_0x13be8b,'reject':_0x1072d8};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2febef){this['reject'](_0x2febef);}});}async['onAuthEvent'](_0xe80e02){const {urlResponse:_0x284534,sessionId:_0x14a2a3,postBody:_0x410cb7,tenantId:_0x40c16d,error:_0x474616,type:_0x2da9bd}=_0xe80e02;if(_0x474616){this['reject'](_0x474616);return;}const _0x5a8ef8={'auth':this['auth'],'requestUri':_0x284534,'sessionId':_0x14a2a3,'tenantId':_0x40c16d||void 0x0,'postBody':_0x410cb7||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2da9bd)(_0x5a8ef8));}catch(_0x2e76ea){this['reject'](_0x2e76ea);}}['onError'](_0x14b4dd){this['reject'](_0x14b4dd);}['getIdpTask'](_0x5bc3e9){switch(_0x5bc3e9){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x57e0ec){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x57e0ec),this['unregisterAndCleanUp']();}['reject'](_0x52f124){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x52f124),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5c8416,_0x594f31,_0x5b2a7e,_0x190a76,_0x525912){super(_0x5c8416,_0x594f31,_0x190a76,_0x525912),this['provider']=_0x5b2a7e,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x254ba4=await this['execute']();return m(_0x254ba4,this['auth'],'internal-error'),_0x254ba4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2d0091=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2d0091),this['authWindow']['associatedEvent']=_0x2d0091,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4170cd=>{this['reject'](_0x4170cd);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4ae1ec=>{_0x4ae1ec||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3ca6cf;return((_0x3ca6cf=this['authWindow'])==null?void 0x0:_0x3ca6cf['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1197bc=()=>{var _0x14d503,_0x37d5d7;if((_0x37d5d7=(_0x14d503=this['authWindow'])==null?void 0x0:_0x14d503['window'])!=null&&_0x37d5d7['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1197bc,Tp['get']());};_0x1197bc();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x205a5c,_0x5c12f6,_0x247e9d=!0x1){super(_0x205a5c,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5c12f6,void 0x0,_0x247e9d),this['eventId']=null;}async['execute'](){let _0x370c98=hn['get'](this['auth']['_key']());if(!_0x370c98){try{const _0x5d8dbb=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x370c98=()=>Promise['resolve'](_0x5d8dbb);}catch(_0x5964fa){_0x370c98=()=>Promise['reject'](_0x5964fa);}hn['set'](this['auth']['_key'](),_0x370c98);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x370c98();}async['onAuthEvent'](_0x325d0f){if(_0x325d0f['type']==='signInViaRedirect')return super['onAuthEvent'](_0x325d0f);if(_0x325d0f['type']==='unknown'){this['resolve'](null);return;}if(_0x325d0f['eventId']){const _0x2dc993=await this['auth']['_redirectUserForId'](_0x325d0f['eventId']);if(_0x2dc993)return this['user']=_0x2dc993,super['onAuthEvent'](_0x325d0f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x475937,_0x3f1e9a){const _0x2553c0=Pp(_0x3f1e9a),_0x4f5ecb=kp(_0x475937);if(!await _0x4f5ecb['_isAvailable']())return!0x1;const _0xf48028=await _0x4f5ecb['_get'](_0x2553c0)==='true';return await _0x4f5ecb['_remove'](_0x2553c0),_0xf48028;}function Ap(_0xda48bd,_0x586b2d){hn['set'](_0xda48bd['_key'](),_0x586b2d);}function kp(_0x2a55f1){return ie(_0x2a55f1['_redirectPersistence']);}function Pp(_0x5b3e33){return ln(Sp,_0x5b3e33['config']['apiKey'],_0x5b3e33['name']);}async function Np(_0x5793fe,_0x3e0530,_0x595408=!0x1){if($(_0x5793fe['app']))return Promise['reject'](re(_0x5793fe));const _0x3051ac=Ke(_0x5793fe),_0xe0310f=Ep(_0x3051ac,_0x3e0530),_0x498f2d=await new bp(_0x3051ac,_0xe0310f,_0x595408)['execute']();return _0x498f2d&&!_0x595408&&(delete _0x498f2d['user']['_redirectEventId'],await _0x3051ac['_persistUserIfCurrent'](_0x498f2d['user']),await _0x3051ac['_setRedirectUser'](null,_0x3e0530)),_0x498f2d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x5e7288){this['auth']=_0x5e7288,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xb7f1d){this['consumers']['add'](_0xb7f1d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xb7f1d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xb7f1d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x525f8b){this['consumers']['delete'](_0x525f8b);}['onEvent'](_0x151fd0){if(this['hasEventBeenHandled'](_0x151fd0))return!0x1;let _0xe4cf43=!0x1;return this['consumers']['forEach'](_0x479573=>{this['isEventForConsumer'](_0x151fd0,_0x479573)&&(_0xe4cf43=!0x0,this['sendToConsumer'](_0x151fd0,_0x479573),this['saveEventToCache'](_0x151fd0));}),this['hasHandledPotentialRedirect']||!Mp(_0x151fd0)||(this['hasHandledPotentialRedirect']=!0x0,_0xe4cf43||(this['queuedRedirectEvent']=_0x151fd0,_0xe4cf43=!0x0)),_0xe4cf43;}['sendToConsumer'](_0x3152c2,_0x249fa6){var _0x3a2576;if(_0x3152c2['error']&&!Za(_0x3152c2)){const _0xa5e21f=((_0x3a2576=_0x3152c2['error']['code'])==null?void 0x0:_0x3a2576['split']('auth/')[0x1])||'internal-error';_0x249fa6['onError'](X(this['auth'],_0xa5e21f));}else _0x249fa6['onAuthEvent'](_0x3152c2);}['isEventForConsumer'](_0x26d93a,_0x4e99e6){const _0x467f06=_0x4e99e6['eventId']===null||!!_0x26d93a['eventId']&&_0x26d93a['eventId']===_0x4e99e6['eventId'];return _0x4e99e6['filter']['includes'](_0x26d93a['type'])&&_0x467f06;}['hasEventBeenHandled'](_0x4369fb){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x4369fb));}['saveEventToCache'](_0x2041dd){this['cachedEventUids']['add'](Mr(_0x2041dd)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x580ffd){return[_0x580ffd['type'],_0x580ffd['eventId'],_0x580ffd['sessionId'],_0x580ffd['tenantId']]['filter'](_0x52e441=>_0x52e441)['join']('-');}function Za({type:_0x531cea,error:_0x3e6981}){return _0x531cea==='unknown'&&(_0x3e6981==null?void 0x0:_0x3e6981['code'])==='auth/no-auth-event';}function Mp(_0x33eaf0){switch(_0x33eaf0['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x33eaf0);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x58c8f1,_0x16631a={}){return Pe(_0x58c8f1,'GET','/v1/projects',_0x16631a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3a1640){if(_0x3a1640['config']['emulator'])return;const {authorizedDomains:_0x41791a}=await Lp(_0x3a1640);for(const _0x12fb7f of _0x41791a)try{if(Wp(_0x12fb7f))return;}catch{}Y(_0x3a1640,'unauthorized-domain');}function Wp(_0x272c49){const _0x19b2ba=Mi(),{protocol:_0x5dca9c,hostname:_0x5ecc0c}=new URL(_0x19b2ba);if(_0x272c49['startsWith']('chrome-extension://')){const _0x122d60=new URL(_0x272c49);return _0x122d60['hostname']===''&&_0x5ecc0c===''?_0x5dca9c==='chrome-extension:'&&_0x272c49['replace']('chrome-extension://','')===_0x19b2ba['replace']('chrome-extension://',''):_0x5dca9c==='chrome-extension:'&&_0x122d60['hostname']===_0x5ecc0c;}if(!Fp['test'](_0x5dca9c))return!0x1;if(xp['test'](_0x272c49))return _0x5ecc0c===_0x272c49;const _0xa86a7=_0x272c49['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xa86a7+'|'+_0xa86a7+')$','i')['test'](_0x5ecc0c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x520a31=Z()['___jsl'];if(_0x520a31!=null&&_0x520a31['H']){for(const _0x560df8 of Object['keys'](_0x520a31['H']))if(_0x520a31['H'][_0x560df8]['r']=_0x520a31['H'][_0x560df8]['r']||[],_0x520a31['H'][_0x560df8]['L']=_0x520a31['H'][_0x560df8]['L']||[],_0x520a31['H'][_0x560df8]['r']=[..._0x520a31['H'][_0x560df8]['L']],_0x520a31['CP']){for(let _0x1f1532=0x0;_0x1f1532<_0x520a31['CP']['length'];_0x1f1532++)_0x520a31['CP'][_0x1f1532]=null;}}}function Vp(_0x56a773){return new Promise((_0x125da0,_0x516d99)=>{var _0x1cb9c8,_0x1010e6,_0x33191f;function _0x587b51(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x125da0(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x516d99(X(_0x56a773,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x1010e6=(_0x1cb9c8=Z()['gapi'])==null?void 0x0:_0x1cb9c8['iframes'])!=null&&_0x1010e6['Iframe'])_0x125da0(gapi['iframes']['getContext']());else{if((_0x33191f=Z()['gapi'])!=null&&_0x33191f['load'])_0x587b51();else{const _0x213acb=Ff('iframefcb');return Z()[_0x213acb]=()=>{gapi['load']?_0x587b51():_0x516d99(X(_0x56a773,'network-request-failed'));},xa(xf()+'?onload='+_0x213acb)['catch'](_0x1342c9=>_0x516d99(_0x1342c9));}}})['catch'](_0x59aac8=>{throw un=null,_0x59aac8;});}let un=null;function Hp(_0x28c0b3){return un=un||Vp(_0x28c0b3),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x50f7d7){const _0x42ebbd=_0x50f7d7['config'];m(_0x42ebbd['authDomain'],_0x50f7d7,'auth-domain-config-required');const _0x2c38db=_0x42ebbd['emulator']?Cs(_0x42ebbd,qp):'https://'+_0x50f7d7['config']['authDomain']+'/'+Gp,_0x2f4c42={'apiKey':_0x42ebbd['apiKey'],'appName':_0x50f7d7['name'],'v':dt},_0x3b0bbf=jp['get'](_0x50f7d7['config']['apiHost']);_0x3b0bbf&&(_0x2f4c42['eid']=_0x3b0bbf);const _0x44e4ac=_0x50f7d7['_getFrameworks']();return _0x44e4ac['length']&&(_0x2f4c42['fw']=_0x44e4ac['join'](',')),_0x2c38db+'?'+ut(_0x2f4c42)['slice'](0x1);}async function Yp(_0x47f759){const _0x30b9c3=await Hp(_0x47f759),_0x15c953=Z()['gapi'];return m(_0x15c953,_0x47f759,'internal-error'),_0x30b9c3['open']({'where':document['body'],'url':Kp(_0x47f759),'messageHandlersFilter':_0x15c953['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x42861d=>new Promise(async(_0xffc281,_0x4da5f6)=>{await _0x42861d['restyle']({'setHideOnLeave':!0x1});const _0x4e6ee4=X(_0x47f759,'network-request-failed'),_0x36f858=Z()['setTimeout'](()=>{_0x4da5f6(_0x4e6ee4);},$p['get']());function _0x31af59(){Z()['clearTimeout'](_0x36f858),_0xffc281(_0x42861d);}_0x42861d['ping'](_0x31af59)['then'](_0x31af59,()=>{_0x4da5f6(_0x4e6ee4);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0xea8dcf){this['window']=_0xea8dcf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xe14ce3,_0x157737,_0x5b32e5,_0xd8bddc=Jp,_0x57f6de=Xp){const _0x47c021=Math['max']((window['screen']['availHeight']-_0x57f6de)/0x2,0x0)['toString'](),_0x2249fb=Math['max']((window['screen']['availWidth']-_0xd8bddc)/0x2,0x0)['toString']();let _0x30e574='';const _0x1717d0={...Qp,'width':_0xd8bddc['toString'](),'height':_0x57f6de['toString'](),'top':_0x47c021,'left':_0x2249fb},_0x49c1d6=W()['toLowerCase']();_0x5b32e5&&(_0x30e574=ka(_0x49c1d6)?Zp:_0x5b32e5),Ra(_0x49c1d6)&&(_0x157737=_0x157737||e_,_0x1717d0['scrollbars']='yes');const _0x4c05b1=Object['entries'](_0x1717d0)['reduce']((_0x3a3a3f,[_0x344a39,_0x48ec83])=>''+_0x3a3a3f+_0x344a39+'='+_0x48ec83+',','');if(Rf(_0x49c1d6)&&_0x30e574!=='_self')return n_(_0x157737||'',_0x30e574),new xr(null);const _0x389c86=window['open'](_0x157737||'',_0x30e574,_0x4c05b1);m(_0x389c86,_0xe14ce3,'popup-blocked');try{_0x389c86['focus']();}catch{}return new xr(_0x389c86);}function n_(_0x2b9e31,_0x41700b){const _0x11baa2=document['createElement']('a');_0x11baa2['href']=_0x2b9e31,_0x11baa2['target']=_0x41700b;const _0x61810=document['createEvent']('MouseEvent');_0x61810['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x11baa2['dispatchEvent'](_0x61810);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x16585e,_0x5aee28,_0x561ded,_0xd8c804,_0x25069c,_0x305d23){m(_0x16585e['config']['authDomain'],_0x16585e,'auth-domain-config-required'),m(_0x16585e['config']['apiKey'],_0x16585e,'invalid-api-key');const _0x26773f={'apiKey':_0x16585e['config']['apiKey'],'appName':_0x16585e['name'],'authType':_0x561ded,'redirectUrl':_0xd8c804,'v':dt,'eventId':_0x25069c};if(_0x5aee28 instanceof Wa){_0x5aee28['setDefaultLanguage'](_0x16585e['languageCode']),_0x26773f['providerId']=_0x5aee28['providerId']||'',pn(_0x5aee28['getCustomParameters']())||(_0x26773f['customParameters']=JSON['stringify'](_0x5aee28['getCustomParameters']()));for(const [_0x9f3732,_0x3fd833]of Object['entries']({}))_0x26773f[_0x9f3732]=_0x3fd833;}if(_0x5aee28 instanceof tn){const _0xad2a1e=_0x5aee28['getScopes']()['filter'](_0x13d2c7=>_0x13d2c7!=='');_0xad2a1e['length']>0x0&&(_0x26773f['scopes']=_0xad2a1e['join'](','));}_0x16585e['tenantId']&&(_0x26773f['tid']=_0x16585e['tenantId']);const _0x56997a=_0x26773f;for(const _0x4f8f18 of Object['keys'](_0x56997a))_0x56997a[_0x4f8f18]===void 0x0&&delete _0x56997a[_0x4f8f18];const _0x1b9883=await _0x16585e['_getAppCheckToken'](),_0x42dde7=_0x1b9883?'#'+r_+'='+encodeURIComponent(_0x1b9883):'';return o_(_0x16585e)+'?'+ut(_0x56997a)['slice'](0x1)+_0x42dde7;}function o_({config:_0x148f0a}){return _0x148f0a['emulator']?Cs(_0x148f0a,s_):'https://'+_0x148f0a['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x588210,_0x4419e3,_0x42b2fb,_0x16b644){var _0x155d41;ce((_0x155d41=this['eventManagers'][_0x588210['_key']()])==null?void 0x0:_0x155d41['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4eb64c=await Fr(_0x588210,_0x4419e3,_0x42b2fb,Mi(),_0x16b644);return t_(_0x588210,_0x4eb64c,As());}async['_openRedirect'](_0x5b7677,_0x5ae391,_0x40f911,_0x27186d){await this['_originValidation'](_0x5b7677);const _0x339107=await Fr(_0x5b7677,_0x5ae391,_0x40f911,Mi(),_0x27186d);return hp(_0x339107),new Promise(()=>{});}['_initialize'](_0x139b31){const _0x3fc215=_0x139b31['_key']();if(this['eventManagers'][_0x3fc215]){const {manager:_0x6ee9f6,promise:_0x112d35}=this['eventManagers'][_0x3fc215];return _0x6ee9f6?Promise['resolve'](_0x6ee9f6):(ce(_0x112d35,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x112d35);}const _0x16a46a=this['initAndGetManager'](_0x139b31);return this['eventManagers'][_0x3fc215]={'promise':_0x16a46a},_0x16a46a['catch'](()=>{delete this['eventManagers'][_0x3fc215];}),_0x16a46a;}async['initAndGetManager'](_0x2a8843){const _0x28d150=await Yp(_0x2a8843),_0x385762=new Dp(_0x2a8843);return _0x28d150['register']('authEvent',_0x51d045=>(m(_0x51d045==null?void 0x0:_0x51d045['authEvent'],_0x2a8843,'invalid-auth-event'),{'status':_0x385762['onEvent'](_0x51d045['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2a8843['_key']()]={'manager':_0x385762},this['iframes'][_0x2a8843['_key']()]=_0x28d150,_0x385762;}['_isIframeWebStorageSupported'](_0x2baea0,_0x43b76f){this['iframes'][_0x2baea0['_key']()]['send'](pi,{'type':pi},_0x5b9fe2=>{var _0x11d2c4;const _0x28ecb8=(_0x11d2c4=_0x5b9fe2==null?void 0x0:_0x5b9fe2[0x0])==null?void 0x0:_0x11d2c4[pi];_0x28ecb8!==void 0x0&&_0x43b76f(!!_0x28ecb8),Y(_0x2baea0,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3eaceb){const _0x2318a0=_0x3eaceb['_key']();return this['originValidationPromises'][_0x2318a0]||(this['originValidationPromises'][_0x2318a0]=Up(_0x3eaceb)),this['originValidationPromises'][_0x2318a0];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x31aec3){this['auth']=_0x31aec3,this['internalListeners']=new Map();}['getUid'](){var _0x15cdc;return this['assertAuthConfigured'](),((_0x15cdc=this['auth']['currentUser'])==null?void 0x0:_0x15cdc['uid'])||null;}async['getToken'](_0x242f11){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x242f11)}:null;}['addAuthTokenListener'](_0x188c79){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x188c79))return;const _0xdbe1ea=this['auth']['onIdTokenChanged'](_0x59882a=>{_0x188c79((_0x59882a==null?void 0x0:_0x59882a['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x188c79,_0xdbe1ea),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x40a1f5){this['assertAuthConfigured']();const _0x57af54=this['internalListeners']['get'](_0x40a1f5);_0x57af54&&(this['internalListeners']['delete'](_0x40a1f5),_0x57af54(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1943f7){switch(_0x1943f7){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2bca7f){st(new Fe('auth',(_0x542db7,{options:_0x2eefb9})=>{const _0x381b4a=_0x542db7['getProvider']('app')['getImmediate'](),_0x4f21cc=_0x542db7['getProvider']('heartbeat'),_0x2b76b0=_0x542db7['getProvider']('app-check-internal'),{apiKey:_0x408a3b,authDomain:_0x16635a}=_0x381b4a['options'];m(_0x408a3b&&!_0x408a3b['includes'](':'),'invalid-api-key',{'appName':_0x381b4a['name']});const _0x1b3e41={'apiKey':_0x408a3b,'authDomain':_0x16635a,'clientPlatform':_0x2bca7f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2bca7f)},_0x5ca9c9=new Df(_0x381b4a,_0x4f21cc,_0x2b76b0,_0x1b3e41);return Hf(_0x5ca9c9,_0x2eefb9),_0x5ca9c9;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x46ff84,_0x27e2ed,_0x12021c)=>{_0x46ff84['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0xa7b94a=>{const _0x2cda54=Ke(_0xa7b94a['getProvider']('auth')['getImmediate']());return(_0x597a55=>new l_(_0x597a55))(_0x2cda54);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2bca7f)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x16ff36=>async _0x22e7c1=>{const _0x1987f6=_0x22e7c1&&await _0x22e7c1['getIdTokenResult'](),_0x3fbafb=_0x1987f6&&(new Date()['getTime']()-Date['parse'](_0x1987f6['issuedAtTime']))/0x3e8;if(_0x3fbafb&&_0x3fbafb>f_)return;const _0x3a61e0=_0x1987f6==null?void 0x0:_0x1987f6['token'];Br!==_0x3a61e0&&(Br=_0x3a61e0,await fetch(_0x16ff36,{'method':_0x3a61e0?'POST':'DELETE','headers':_0x3a61e0?{'Authorization':'Bearer\x20'+_0x3a61e0}:{}}));};function B_(_0x17830a=Zr()){const _0x40bbeb=Hi(_0x17830a,'auth');if(_0x40bbeb['isInitialized']())return _0x40bbeb['getImmediate']();const _0x3b6780=Vf(_0x17830a,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x48d49a=jr('authTokenSyncURL');if(_0x48d49a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x25d3a8=new URL(_0x48d49a,location['origin']);if(location['origin']===_0x25d3a8['origin']){const _0x5a0f2e=p_(_0x25d3a8['toString']());sp(_0x3b6780,_0x5a0f2e,()=>_0x5a0f2e(_0x3b6780['currentUser'])),ip(_0x3b6780,_0x355e09=>_0x5a0f2e(_0x355e09));}}const _0x366113=qr('auth');return _0x366113&&$f(_0x3b6780,'http://'+_0x366113),_0x3b6780;}function __(){var _0x52a862;return((_0x52a862=document['getElementsByTagName']('head'))==null?void 0x0:_0x52a862[0x0])??document;}Mf({'loadJS'(_0x2f1a9d){return new Promise((_0x41f803,_0x482b8)=>{const _0x599d3d=document['createElement']('script');_0x599d3d['setAttribute']('src',_0x2f1a9d),_0x599d3d['onload']=_0x41f803,_0x599d3d['onerror']=_0x30b949=>{const _0x43190a=X('internal-error');_0x43190a['customData']=_0x30b949,_0x482b8(_0x43190a);},_0x599d3d['type']='text/javascript',_0x599d3d['charset']='UTF-8',__()['appendChild'](_0x599d3d);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};