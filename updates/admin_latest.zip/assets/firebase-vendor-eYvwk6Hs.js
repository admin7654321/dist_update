const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3dbd77,_0x505339){if(!_0x3dbd77)throw ht(_0x505339);},ht=function(_0x204abd){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x204abd);},Hr=function(_0x1de2d7){const _0x5158bf=[];let _0x4078ae=0x0;for(let _0x2c3977=0x0;_0x2c3977<_0x1de2d7['length'];_0x2c3977++){let _0x2d4118=_0x1de2d7['charCodeAt'](_0x2c3977);_0x2d4118<0x80?_0x5158bf[_0x4078ae++]=_0x2d4118:_0x2d4118<0x800?(_0x5158bf[_0x4078ae++]=_0x2d4118>>0x6|0xc0,_0x5158bf[_0x4078ae++]=_0x2d4118&0x3f|0x80):(_0x2d4118&0xfc00)===0xd800&&_0x2c3977+0x1<_0x1de2d7['length']&&(_0x1de2d7['charCodeAt'](_0x2c3977+0x1)&0xfc00)===0xdc00?(_0x2d4118=0x10000+((_0x2d4118&0x3ff)<<0xa)+(_0x1de2d7['charCodeAt'](++_0x2c3977)&0x3ff),_0x5158bf[_0x4078ae++]=_0x2d4118>>0x12|0xf0,_0x5158bf[_0x4078ae++]=_0x2d4118>>0xc&0x3f|0x80,_0x5158bf[_0x4078ae++]=_0x2d4118>>0x6&0x3f|0x80,_0x5158bf[_0x4078ae++]=_0x2d4118&0x3f|0x80):(_0x5158bf[_0x4078ae++]=_0x2d4118>>0xc|0xe0,_0x5158bf[_0x4078ae++]=_0x2d4118>>0x6&0x3f|0x80,_0x5158bf[_0x4078ae++]=_0x2d4118&0x3f|0x80);}return _0x5158bf;},nc=function(_0x45231b){const _0x3a1fb7=[];let _0x23e165=0x0,_0x553527=0x0;for(;_0x23e165<_0x45231b['length'];){const _0x48cbf0=_0x45231b[_0x23e165++];if(_0x48cbf0<0x80)_0x3a1fb7[_0x553527++]=String['fromCharCode'](_0x48cbf0);else{if(_0x48cbf0>0xbf&&_0x48cbf0<0xe0){const _0x1a9f5d=_0x45231b[_0x23e165++];_0x3a1fb7[_0x553527++]=String['fromCharCode']((_0x48cbf0&0x1f)<<0x6|_0x1a9f5d&0x3f);}else{if(_0x48cbf0>0xef&&_0x48cbf0<0x16d){const _0x433282=_0x45231b[_0x23e165++],_0x414f0f=_0x45231b[_0x23e165++],_0x16363a=_0x45231b[_0x23e165++],_0x44ed44=((_0x48cbf0&0x7)<<0x12|(_0x433282&0x3f)<<0xc|(_0x414f0f&0x3f)<<0x6|_0x16363a&0x3f)-0x10000;_0x3a1fb7[_0x553527++]=String['fromCharCode'](0xd800+(_0x44ed44>>0xa)),_0x3a1fb7[_0x553527++]=String['fromCharCode'](0xdc00+(_0x44ed44&0x3ff));}else{const _0x5a3931=_0x45231b[_0x23e165++],_0x76fdf4=_0x45231b[_0x23e165++];_0x3a1fb7[_0x553527++]=String['fromCharCode']((_0x48cbf0&0xf)<<0xc|(_0x5a3931&0x3f)<<0x6|_0x76fdf4&0x3f);}}}}return _0x3a1fb7['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x34fe5d,_0x3e5c5f){if(!Array['isArray'](_0x34fe5d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x555ff4=_0x3e5c5f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3f303b=[];for(let _0x493117=0x0;_0x493117<_0x34fe5d['length'];_0x493117+=0x3){const _0x49f76e=_0x34fe5d[_0x493117],_0x2770f9=_0x493117+0x1<_0x34fe5d['length'],_0x49d909=_0x2770f9?_0x34fe5d[_0x493117+0x1]:0x0,_0x1cbb91=_0x493117+0x2<_0x34fe5d['length'],_0x31d5ec=_0x1cbb91?_0x34fe5d[_0x493117+0x2]:0x0,_0x1f6d1d=_0x49f76e>>0x2,_0x139f76=(_0x49f76e&0x3)<<0x4|_0x49d909>>0x4;let _0x4099fb=(_0x49d909&0xf)<<0x2|_0x31d5ec>>0x6,_0x2458d9=_0x31d5ec&0x3f;_0x1cbb91||(_0x2458d9=0x40,_0x2770f9||(_0x4099fb=0x40)),_0x3f303b['push'](_0x555ff4[_0x1f6d1d],_0x555ff4[_0x139f76],_0x555ff4[_0x4099fb],_0x555ff4[_0x2458d9]);}return _0x3f303b['join']('');},'encodeString'(_0x3c739b,_0x35bee4){return this['HAS_NATIVE_SUPPORT']&&!_0x35bee4?btoa(_0x3c739b):this['encodeByteArray'](Hr(_0x3c739b),_0x35bee4);},'decodeString'(_0xfeeca4,_0x1c8af0){return this['HAS_NATIVE_SUPPORT']&&!_0x1c8af0?atob(_0xfeeca4):nc(this['decodeStringToByteArray'](_0xfeeca4,_0x1c8af0));},'decodeStringToByteArray'(_0x52c3fb,_0x1c563d){this['init_']();const _0x411360=_0x1c563d?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x42cec2=[];for(let _0x281c32=0x0;_0x281c32<_0x52c3fb['length'];){const _0x4a9f32=_0x411360[_0x52c3fb['charAt'](_0x281c32++)],_0x406171=_0x281c32<_0x52c3fb['length']?_0x411360[_0x52c3fb['charAt'](_0x281c32)]:0x0;++_0x281c32;const _0x2c46ae=_0x281c32<_0x52c3fb['length']?_0x411360[_0x52c3fb['charAt'](_0x281c32)]:0x40;++_0x281c32;const _0x32a5b4=_0x281c32<_0x52c3fb['length']?_0x411360[_0x52c3fb['charAt'](_0x281c32)]:0x40;if(++_0x281c32,_0x4a9f32==null||_0x406171==null||_0x2c46ae==null||_0x32a5b4==null)throw new ic();const _0x1a930b=_0x4a9f32<<0x2|_0x406171>>0x4;if(_0x42cec2['push'](_0x1a930b),_0x2c46ae!==0x40){const _0x2a6713=_0x406171<<0x4&0xf0|_0x2c46ae>>0x2;if(_0x42cec2['push'](_0x2a6713),_0x32a5b4!==0x40){const _0x2309fd=_0x2c46ae<<0x6&0xc0|_0x32a5b4;_0x42cec2['push'](_0x2309fd);}}}return _0x42cec2;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x22e66b=0x0;_0x22e66b<this['ENCODED_VALS']['length'];_0x22e66b++)this['byteToCharMap_'][_0x22e66b]=this['ENCODED_VALS']['charAt'](_0x22e66b),this['charToByteMap_'][this['byteToCharMap_'][_0x22e66b]]=_0x22e66b,this['byteToCharMapWebSafe_'][_0x22e66b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x22e66b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x22e66b]]=_0x22e66b,_0x22e66b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x22e66b)]=_0x22e66b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x22e66b)]=_0x22e66b);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x56478a){const _0x37ed93=Hr(_0x56478a);return Fi['encodeByteArray'](_0x37ed93,!0x0);},dn=function(_0x503afc){return $r(_0x503afc)['replace'](/\./g,'');},fn=function(_0x374091){try{return Fi['decodeString'](_0x374091,!0x0);}catch(_0x171020){console['error']('base64Decode\x20failed:\x20',_0x171020);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x25c6ca){return Gr(void 0x0,_0x25c6ca);}function Gr(_0x26b0fb,_0x5ea157){if(!(_0x5ea157 instanceof Object))return _0x5ea157;switch(_0x5ea157['constructor']){case Date:const _0x69e9d0=_0x5ea157;return new Date(_0x69e9d0['getTime']());case Object:_0x26b0fb===void 0x0&&(_0x26b0fb={});break;case Array:_0x26b0fb=[];break;default:return _0x5ea157;}for(const _0x281e95 in _0x5ea157)!_0x5ea157['hasOwnProperty'](_0x281e95)||!rc(_0x281e95)||(_0x26b0fb[_0x281e95]=Gr(_0x26b0fb[_0x281e95],_0x5ea157[_0x281e95]));return _0x26b0fb;}function rc(_0x27f956){return _0x27f956!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1912f2=Ps['__FIREBASE_DEFAULTS__'];if(_0x1912f2)return JSON['parse'](_0x1912f2);},lc=()=>{if(typeof document>'u')return;let _0x5422d9;try{_0x5422d9=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2585ea=_0x5422d9&&fn(_0x5422d9[0x1]);return _0x2585ea&&JSON['parse'](_0x2585ea);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x51c291){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x51c291);return;}},qr=_0x1c27f6=>{var _0x448d25,_0x12f955;return(_0x12f955=(_0x448d25=Ui())==null?void 0x0:_0x448d25['emulatorHosts'])==null?void 0x0:_0x12f955[_0x1c27f6];},hc=_0x4cf4b1=>{const _0xf5a099=qr(_0x4cf4b1);if(!_0xf5a099)return;const _0x26a421=_0xf5a099['lastIndexOf'](':');if(_0x26a421<=0x0||_0x26a421+0x1===_0xf5a099['length'])throw new Error('Invalid\x20host\x20'+_0xf5a099+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2c5117=parseInt(_0xf5a099['substring'](_0x26a421+0x1),0xa);return _0xf5a099[0x0]==='['?[_0xf5a099['substring'](0x1,_0x26a421-0x1),_0x2c5117]:[_0xf5a099['substring'](0x0,_0x26a421),_0x2c5117];},zr=()=>{var _0x268053;return(_0x268053=Ui())==null?void 0x0:_0x268053['config'];},jr=_0x237665=>{var _0x17214a;return(_0x17214a=Ui())==null?void 0x0:_0x17214a['_'+_0x237665];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4eb514,_0x416a66)=>{this['resolve']=_0x4eb514,this['reject']=_0x416a66;});}['wrapCallback'](_0x2a8b59){return(_0x28de82,_0x1f5b57)=>{_0x28de82?this['reject'](_0x28de82):this['resolve'](_0x1f5b57),typeof _0x2a8b59=='function'&&(this['promise']['catch'](()=>{}),_0x2a8b59['length']===0x1?_0x2a8b59(_0x28de82):_0x2a8b59(_0x28de82,_0x1f5b57));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x247b12,_0x489bec){if(_0x247b12['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x2d81c0={'alg':'none','type':'JWT'},_0x4feef2=_0x489bec||'demo-project',_0x48ad26=_0x247b12['iat']||0x0,_0x32062b=_0x247b12['sub']||_0x247b12['user_id'];if(!_0x32062b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2c6686={'iss':'https://securetoken.google.com/'+_0x4feef2,'aud':_0x4feef2,'iat':_0x48ad26,'exp':_0x48ad26+0xe10,'auth_time':_0x48ad26,'sub':_0x32062b,'user_id':_0x32062b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x247b12};return[dn(JSON['stringify'](_0x2d81c0)),dn(JSON['stringify'](_0x2c6686)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5a70c5=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5a70c5=='object'&&_0x5a70c5['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1d4a9c=W();return _0x1d4a9c['indexOf']('MSIE\x20')>=0x0||_0x1d4a9c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x503f40,_0x3b3542)=>{try{let _0x24943d=!0x0;const _0xba5f3f='validate-browser-context-for-indexeddb-analytics-module',_0x460578=self['indexedDB']['open'](_0xba5f3f);_0x460578['onsuccess']=()=>{_0x460578['result']['close'](),_0x24943d||self['indexedDB']['deleteDatabase'](_0xba5f3f),_0x503f40(!0x0);},_0x460578['onupgradeneeded']=()=>{_0x24943d=!0x1;},_0x460578['onerror']=()=>{var _0x36578b;_0x3b3542(((_0x36578b=_0x460578['error'])==null?void 0x0:_0x36578b['message'])||'');};}catch(_0x2773ba){_0x3b3542(_0x2773ba);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x52efdb,_0x19c7c3,_0x201f52){super(_0x19c7c3),this['code']=_0x52efdb,this['customData']=_0x201f52,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x51d691,_0xec32fa,_0x49592a){this['service']=_0x51d691,this['serviceName']=_0xec32fa,this['errors']=_0x49592a;}['create'](_0x41531e,..._0x38196c){const _0x18907d=_0x38196c[0x0]||{},_0x1f3205=this['service']+'/'+_0x41531e,_0x4b8f84=this['errors'][_0x41531e],_0x580d8f=_0x4b8f84?vc(_0x4b8f84,_0x18907d):'Error',_0x4219e7=this['serviceName']+':\x20'+_0x580d8f+'\x20('+_0x1f3205+').';return new Re(_0x1f3205,_0x4219e7,_0x18907d);}}function vc(_0x475f2a,_0x5a7528){return _0x475f2a['replace'](Ec,(_0xfcc91d,_0x19063c)=>{const _0x10dcca=_0x5a7528[_0x19063c];return _0x10dcca!=null?String(_0x10dcca):'<'+_0x19063c+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2def5c){return JSON['parse'](_0x2def5c);}function O(_0x5b2cf3){return JSON['stringify'](_0x5b2cf3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x84d59d){let _0x1a55cb={},_0x265eaf={},_0x5e1587={},_0x2a53a4='';try{const _0x190c33=_0x84d59d['split']('.');_0x1a55cb=Nt(fn(_0x190c33[0x0])||''),_0x265eaf=Nt(fn(_0x190c33[0x1])||''),_0x2a53a4=_0x190c33[0x2],_0x5e1587=_0x265eaf['d']||{},delete _0x265eaf['d'];}catch{}return{'header':_0x1a55cb,'claims':_0x265eaf,'data':_0x5e1587,'signature':_0x2a53a4};},Ic=function(_0x465982){const _0x75ffa3=Yr(_0x465982),_0xcfcf38=_0x75ffa3['claims'];return!!_0xcfcf38&&typeof _0xcfcf38=='object'&&_0xcfcf38['hasOwnProperty']('iat');},wc=function(_0x2a6309){const _0x5977e5=Yr(_0x2a6309)['claims'];return typeof _0x5977e5=='object'&&_0x5977e5['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x234e45,_0x4e5d33){return Object['prototype']['hasOwnProperty']['call'](_0x234e45,_0x4e5d33);}function Le(_0x1b09c3,_0x145ed0){if(Object['prototype']['hasOwnProperty']['call'](_0x1b09c3,_0x145ed0))return _0x1b09c3[_0x145ed0];}function pn(_0x175c28){for(const _0x209817 in _0x175c28)if(Object['prototype']['hasOwnProperty']['call'](_0x175c28,_0x209817))return!0x1;return!0x0;}function _n(_0x2780d5,_0x123f6f,_0x33558c){const _0x170300={};for(const _0x1e0778 in _0x2780d5)Object['prototype']['hasOwnProperty']['call'](_0x2780d5,_0x1e0778)&&(_0x170300[_0x1e0778]=_0x123f6f['call'](_0x33558c,_0x2780d5[_0x1e0778],_0x1e0778,_0x2780d5));return _0x170300;}function xe(_0x35959c,_0x52915e){if(_0x35959c===_0x52915e)return!0x0;const _0x1b3089=Object['keys'](_0x35959c),_0x4f5511=Object['keys'](_0x52915e);for(const _0xb3059c of _0x1b3089){if(!_0x4f5511['includes'](_0xb3059c))return!0x1;const _0x23473a=_0x35959c[_0xb3059c],_0x283b2f=_0x52915e[_0xb3059c];if(Ns(_0x23473a)&&Ns(_0x283b2f)){if(!xe(_0x23473a,_0x283b2f))return!0x1;}else{if(_0x23473a!==_0x283b2f)return!0x1;}}for(const _0x851dbe of _0x4f5511)if(!_0x1b3089['includes'](_0x851dbe))return!0x1;return!0x0;}function Ns(_0x2eea9c){return _0x2eea9c!==null&&typeof _0x2eea9c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4a3e2a){const _0xe21abb=[];for(const [_0x4044a1,_0x53198d]of Object['entries'](_0x4a3e2a))Array['isArray'](_0x53198d)?_0x53198d['forEach'](_0x5792f5=>{_0xe21abb['push'](encodeURIComponent(_0x4044a1)+'='+encodeURIComponent(_0x5792f5));}):_0xe21abb['push'](encodeURIComponent(_0x4044a1)+'='+encodeURIComponent(_0x53198d));return _0xe21abb['length']?'&'+_0xe21abb['join']('&'):'';}function Ct(_0x2aa7f9){const _0x378f7f={};return _0x2aa7f9['replace'](/^\?/,'')['split']('&')['forEach'](_0x12893d=>{if(_0x12893d){const [_0x4dcba1,_0x2b3c77]=_0x12893d['split']('=');_0x378f7f[decodeURIComponent(_0x4dcba1)]=decodeURIComponent(_0x2b3c77);}}),_0x378f7f;}function Tt(_0x4b7b1e){const _0x17d8f4=_0x4b7b1e['indexOf']('?');if(!_0x17d8f4)return'';const _0x4f0c6e=_0x4b7b1e['indexOf']('#',_0x17d8f4);return _0x4b7b1e['substring'](_0x17d8f4,_0x4f0c6e>0x0?_0x4f0c6e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x40ad80=0x1;_0x40ad80<this['blockSize'];++_0x40ad80)this['pad_'][_0x40ad80]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x43a153,_0x1fe492){_0x1fe492||(_0x1fe492=0x0);const _0x5affcd=this['W_'];if(typeof _0x43a153=='string'){for(let _0x406169=0x0;_0x406169<0x10;_0x406169++)_0x5affcd[_0x406169]=_0x43a153['charCodeAt'](_0x1fe492)<<0x18|_0x43a153['charCodeAt'](_0x1fe492+0x1)<<0x10|_0x43a153['charCodeAt'](_0x1fe492+0x2)<<0x8|_0x43a153['charCodeAt'](_0x1fe492+0x3),_0x1fe492+=0x4;}else{for(let _0x43287c=0x0;_0x43287c<0x10;_0x43287c++)_0x5affcd[_0x43287c]=_0x43a153[_0x1fe492]<<0x18|_0x43a153[_0x1fe492+0x1]<<0x10|_0x43a153[_0x1fe492+0x2]<<0x8|_0x43a153[_0x1fe492+0x3],_0x1fe492+=0x4;}for(let _0x41269a=0x10;_0x41269a<0x50;_0x41269a++){const _0x5f2a8b=_0x5affcd[_0x41269a-0x3]^_0x5affcd[_0x41269a-0x8]^_0x5affcd[_0x41269a-0xe]^_0x5affcd[_0x41269a-0x10];_0x5affcd[_0x41269a]=(_0x5f2a8b<<0x1|_0x5f2a8b>>>0x1f)&0xffffffff;}let _0x1c4825=this['chain_'][0x0],_0x1b0af2=this['chain_'][0x1],_0x1bec55=this['chain_'][0x2],_0x47cb4b=this['chain_'][0x3],_0x109e05=this['chain_'][0x4],_0x19901e,_0x2be2e0;for(let _0x2a0850=0x0;_0x2a0850<0x50;_0x2a0850++){_0x2a0850<0x28?_0x2a0850<0x14?(_0x19901e=_0x47cb4b^_0x1b0af2&(_0x1bec55^_0x47cb4b),_0x2be2e0=0x5a827999):(_0x19901e=_0x1b0af2^_0x1bec55^_0x47cb4b,_0x2be2e0=0x6ed9eba1):_0x2a0850<0x3c?(_0x19901e=_0x1b0af2&_0x1bec55|_0x47cb4b&(_0x1b0af2|_0x1bec55),_0x2be2e0=0x8f1bbcdc):(_0x19901e=_0x1b0af2^_0x1bec55^_0x47cb4b,_0x2be2e0=0xca62c1d6);const _0x3d7402=(_0x1c4825<<0x5|_0x1c4825>>>0x1b)+_0x19901e+_0x109e05+_0x2be2e0+_0x5affcd[_0x2a0850]&0xffffffff;_0x109e05=_0x47cb4b,_0x47cb4b=_0x1bec55,_0x1bec55=(_0x1b0af2<<0x1e|_0x1b0af2>>>0x2)&0xffffffff,_0x1b0af2=_0x1c4825,_0x1c4825=_0x3d7402;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1c4825&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1b0af2&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1bec55&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x47cb4b&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x109e05&0xffffffff;}['update'](_0xe70c61,_0x23e8c5){if(_0xe70c61==null)return;_0x23e8c5===void 0x0&&(_0x23e8c5=_0xe70c61['length']);const _0xf78c5e=_0x23e8c5-this['blockSize'];let _0x2c6af3=0x0;const _0x2a3285=this['buf_'];let _0x573a02=this['inbuf_'];for(;_0x2c6af3<_0x23e8c5;){if(_0x573a02===0x0){for(;_0x2c6af3<=_0xf78c5e;)this['compress_'](_0xe70c61,_0x2c6af3),_0x2c6af3+=this['blockSize'];}if(typeof _0xe70c61=='string'){for(;_0x2c6af3<_0x23e8c5;)if(_0x2a3285[_0x573a02]=_0xe70c61['charCodeAt'](_0x2c6af3),++_0x573a02,++_0x2c6af3,_0x573a02===this['blockSize']){this['compress_'](_0x2a3285),_0x573a02=0x0;break;}}else{for(;_0x2c6af3<_0x23e8c5;)if(_0x2a3285[_0x573a02]=_0xe70c61[_0x2c6af3],++_0x573a02,++_0x2c6af3,_0x573a02===this['blockSize']){this['compress_'](_0x2a3285),_0x573a02=0x0;break;}}}this['inbuf_']=_0x573a02,this['total_']+=_0x23e8c5;}['digest'](){const _0x213732=[];let _0x5223ca=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x31a991=this['blockSize']-0x1;_0x31a991>=0x38;_0x31a991--)this['buf_'][_0x31a991]=_0x5223ca&0xff,_0x5223ca/=0x100;this['compress_'](this['buf_']);let _0x48ae2b=0x0;for(let _0x32bdb0=0x0;_0x32bdb0<0x5;_0x32bdb0++)for(let _0x4c525b=0x18;_0x4c525b>=0x0;_0x4c525b-=0x8)_0x213732[_0x48ae2b]=this['chain_'][_0x32bdb0]>>_0x4c525b&0xff,++_0x48ae2b;return _0x213732;}}function Tc(_0x1c412d,_0x472349){const _0x379b39=new Sc(_0x1c412d,_0x472349);return _0x379b39['subscribe']['bind'](_0x379b39);}class Sc{constructor(_0x547b4f,_0xc3b778){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xc3b778,this['task']['then'](()=>{_0x547b4f(this);})['catch'](_0x560b5f=>{this['error'](_0x560b5f);});}['next'](_0x4da01a){this['forEachObserver'](_0x188140=>{_0x188140['next'](_0x4da01a);});}['error'](_0x187113){this['forEachObserver'](_0x2d9240=>{_0x2d9240['error'](_0x187113);}),this['close'](_0x187113);}['complete'](){this['forEachObserver'](_0x2daad1=>{_0x2daad1['complete']();}),this['close']();}['subscribe'](_0xbf618b,_0x4bcc8f,_0xed3d43){let _0x15c28b;if(_0xbf618b===void 0x0&&_0x4bcc8f===void 0x0&&_0xed3d43===void 0x0)throw new Error('Missing\x20Observer.');bc(_0xbf618b,['next','error','complete'])?_0x15c28b=_0xbf618b:_0x15c28b={'next':_0xbf618b,'error':_0x4bcc8f,'complete':_0xed3d43},_0x15c28b['next']===void 0x0&&(_0x15c28b['next']=ti),_0x15c28b['error']===void 0x0&&(_0x15c28b['error']=ti),_0x15c28b['complete']===void 0x0&&(_0x15c28b['complete']=ti);const _0x38d7ec=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x15c28b['error'](this['finalError']):_0x15c28b['complete']();}catch{}}),this['observers']['push'](_0x15c28b),_0x38d7ec;}['unsubscribeOne'](_0x2c46a5){this['observers']===void 0x0||this['observers'][_0x2c46a5]===void 0x0||(delete this['observers'][_0x2c46a5],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x44b7d5){if(!this['finalized']){for(let _0x1f5040=0x0;_0x1f5040<this['observers']['length'];_0x1f5040++)this['sendOne'](_0x1f5040,_0x44b7d5);}}['sendOne'](_0x4c58a9,_0x1c817d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4c58a9]!==void 0x0)try{_0x1c817d(this['observers'][_0x4c58a9]);}catch(_0x34395b){typeof console<'u'&&console['error']&&console['error'](_0x34395b);}});}['close'](_0x50e639){this['finalized']||(this['finalized']=!0x0,_0x50e639!==void 0x0&&(this['finalError']=_0x50e639),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3f571f,_0x4fa2d2){if(typeof _0x3f571f!='object'||_0x3f571f===null)return!0x1;for(const _0x3e7635 of _0x4fa2d2)if(_0x3e7635 in _0x3f571f&&typeof _0x3f571f[_0x3e7635]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x125a02,_0x3ff5e6){return _0x125a02+'\x20failed:\x20'+_0x3ff5e6+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x147c6f){const _0x275538=[];let _0x542b57=0x0;for(let _0x6a58=0x0;_0x6a58<_0x147c6f['length'];_0x6a58++){let _0x6358c0=_0x147c6f['charCodeAt'](_0x6a58);if(_0x6358c0>=0xd800&&_0x6358c0<=0xdbff){const _0xeb951d=_0x6358c0-0xd800;_0x6a58++,f(_0x6a58<_0x147c6f['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x133744=_0x147c6f['charCodeAt'](_0x6a58)-0xdc00;_0x6358c0=0x10000+(_0xeb951d<<0xa)+_0x133744;}_0x6358c0<0x80?_0x275538[_0x542b57++]=_0x6358c0:_0x6358c0<0x800?(_0x275538[_0x542b57++]=_0x6358c0>>0x6|0xc0,_0x275538[_0x542b57++]=_0x6358c0&0x3f|0x80):_0x6358c0<0x10000?(_0x275538[_0x542b57++]=_0x6358c0>>0xc|0xe0,_0x275538[_0x542b57++]=_0x6358c0>>0x6&0x3f|0x80,_0x275538[_0x542b57++]=_0x6358c0&0x3f|0x80):(_0x275538[_0x542b57++]=_0x6358c0>>0x12|0xf0,_0x275538[_0x542b57++]=_0x6358c0>>0xc&0x3f|0x80,_0x275538[_0x542b57++]=_0x6358c0>>0x6&0x3f|0x80,_0x275538[_0x542b57++]=_0x6358c0&0x3f|0x80);}return _0x275538;},Ln=function(_0x5957c5){let _0x516eb3=0x0;for(let _0x36df39=0x0;_0x36df39<_0x5957c5['length'];_0x36df39++){const _0xe58e27=_0x5957c5['charCodeAt'](_0x36df39);_0xe58e27<0x80?_0x516eb3++:_0xe58e27<0x800?_0x516eb3+=0x2:_0xe58e27>=0xd800&&_0xe58e27<=0xdbff?(_0x516eb3+=0x4,_0x36df39++):_0x516eb3+=0x3;}return _0x516eb3;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x350bac){return _0x350bac&&_0x350bac['_delegate']?_0x350bac['_delegate']:_0x350bac;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x437e26){try{return(_0x437e26['startsWith']('http://')||_0x437e26['startsWith']('https://')?new URL(_0x437e26)['hostname']:_0x437e26)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x337499){return(await fetch(_0x337499,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x6d8e52,_0x52e54c,_0x19a0e0){this['name']=_0x6d8e52,this['instanceFactory']=_0x52e54c,this['type']=_0x19a0e0,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3ba7f2){return this['instantiationMode']=_0x3ba7f2,this;}['setMultipleInstances'](_0x4e9c16){return this['multipleInstances']=_0x4e9c16,this;}['setServiceProps'](_0x1ee2b7){return this['serviceProps']=_0x1ee2b7,this;}['setInstanceCreatedCallback'](_0x4b130c){return this['onInstanceCreated']=_0x4b130c,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xced15a,_0x455b86){this['name']=_0xced15a,this['container']=_0x455b86,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x49a652){const _0x4e3677=this['normalizeInstanceIdentifier'](_0x49a652);if(!this['instancesDeferred']['has'](_0x4e3677)){const _0x92b90a=new H();if(this['instancesDeferred']['set'](_0x4e3677,_0x92b90a),this['isInitialized'](_0x4e3677)||this['shouldAutoInitialize']())try{const _0x87ad98=this['getOrInitializeService']({'instanceIdentifier':_0x4e3677});_0x87ad98&&_0x92b90a['resolve'](_0x87ad98);}catch{}}return this['instancesDeferred']['get'](_0x4e3677)['promise'];}['getImmediate'](_0x2ffecf){const _0x549d83=this['normalizeInstanceIdentifier'](_0x2ffecf==null?void 0x0:_0x2ffecf['identifier']),_0x158018=(_0x2ffecf==null?void 0x0:_0x2ffecf['optional'])??!0x1;if(this['isInitialized'](_0x549d83)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x549d83});}catch(_0x2d8c84){if(_0x158018)return null;throw _0x2d8c84;}else{if(_0x158018)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x274cfb){if(_0x274cfb['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x274cfb['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x274cfb,!!this['shouldAutoInitialize']()){if(Pc(_0x274cfb))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0xe456c5,_0x3fe4a9]of this['instancesDeferred']['entries']()){const _0x3115a0=this['normalizeInstanceIdentifier'](_0xe456c5);try{const _0x4b6f11=this['getOrInitializeService']({'instanceIdentifier':_0x3115a0});_0x3fe4a9['resolve'](_0x4b6f11);}catch{}}}}['clearInstance'](_0x2fb00d=Ne){this['instancesDeferred']['delete'](_0x2fb00d),this['instancesOptions']['delete'](_0x2fb00d),this['instances']['delete'](_0x2fb00d);}async['delete'](){const _0x277cab=Array['from'](this['instances']['values']());await Promise['all']([..._0x277cab['filter'](_0x57b210=>'INTERNAL'in _0x57b210)['map'](_0x596825=>_0x596825['INTERNAL']['delete']()),..._0x277cab['filter'](_0x33c55d=>'_delete'in _0x33c55d)['map'](_0x4b5b80=>_0x4b5b80['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x183915=Ne){return this['instances']['has'](_0x183915);}['getOptions'](_0x5d25d9=Ne){return this['instancesOptions']['get'](_0x5d25d9)||{};}['initialize'](_0x4ae748={}){const {options:_0x195cc3={}}=_0x4ae748,_0x5733a4=this['normalizeInstanceIdentifier'](_0x4ae748['instanceIdentifier']);if(this['isInitialized'](_0x5733a4))throw Error(this['name']+'('+_0x5733a4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4648ae=this['getOrInitializeService']({'instanceIdentifier':_0x5733a4,'options':_0x195cc3});for(const [_0x4e1cdb,_0x4257a2]of this['instancesDeferred']['entries']()){const _0xf86912=this['normalizeInstanceIdentifier'](_0x4e1cdb);_0x5733a4===_0xf86912&&_0x4257a2['resolve'](_0x4648ae);}return _0x4648ae;}['onInit'](_0x3b114a,_0x4943f5){const _0x2a44e2=this['normalizeInstanceIdentifier'](_0x4943f5),_0x23a2c5=this['onInitCallbacks']['get'](_0x2a44e2)??new Set();_0x23a2c5['add'](_0x3b114a),this['onInitCallbacks']['set'](_0x2a44e2,_0x23a2c5);const _0x35f0d1=this['instances']['get'](_0x2a44e2);return _0x35f0d1&&_0x3b114a(_0x35f0d1,_0x2a44e2),()=>{_0x23a2c5['delete'](_0x3b114a);};}['invokeOnInitCallbacks'](_0x1f0b0b,_0x11cf90){const _0x2c5702=this['onInitCallbacks']['get'](_0x11cf90);if(_0x2c5702){for(const _0x33d03d of _0x2c5702)try{_0x33d03d(_0x1f0b0b,_0x11cf90);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xd79916,options:_0x108991={}}){let _0x43dd82=this['instances']['get'](_0xd79916);if(!_0x43dd82&&this['component']&&(_0x43dd82=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0xd79916),'options':_0x108991}),this['instances']['set'](_0xd79916,_0x43dd82),this['instancesOptions']['set'](_0xd79916,_0x108991),this['invokeOnInitCallbacks'](_0x43dd82,_0xd79916),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xd79916,_0x43dd82);}catch{}return _0x43dd82||null;}['normalizeInstanceIdentifier'](_0xdfc660=Ne){return this['component']?this['component']['multipleInstances']?_0xdfc660:Ne:_0xdfc660;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x327dec){return _0x327dec===Ne?void 0x0:_0x327dec;}function Pc(_0x3253ed){return _0x3253ed['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x1ddd0f){this['name']=_0x1ddd0f,this['providers']=new Map();}['addComponent'](_0x724978){const _0xdffe0=this['getProvider'](_0x724978['name']);if(_0xdffe0['isComponentSet']())throw new Error('Component\x20'+_0x724978['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xdffe0['setComponent'](_0x724978);}['addOrOverwriteComponent'](_0x5b1fcc){this['getProvider'](_0x5b1fcc['name'])['isComponentSet']()&&this['providers']['delete'](_0x5b1fcc['name']),this['addComponent'](_0x5b1fcc);}['getProvider'](_0x22af0d){if(this['providers']['has'](_0x22af0d))return this['providers']['get'](_0x22af0d);const _0x31cb1a=new Ac(_0x22af0d,this);return this['providers']['set'](_0x22af0d,_0x31cb1a),_0x31cb1a;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x167d3f){_0x167d3f[_0x167d3f['DEBUG']=0x0]='DEBUG',_0x167d3f[_0x167d3f['VERBOSE']=0x1]='VERBOSE',_0x167d3f[_0x167d3f['INFO']=0x2]='INFO',_0x167d3f[_0x167d3f['WARN']=0x3]='WARN',_0x167d3f[_0x167d3f['ERROR']=0x4]='ERROR',_0x167d3f[_0x167d3f['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x115e78,_0x59c610,..._0x417b50)=>{if(_0x59c610<_0x115e78['logLevel'])return;const _0x20c894=new Date()['toISOString'](),_0x433982=Mc[_0x59c610];if(_0x433982)console[_0x433982]('['+_0x20c894+']\x20\x20'+_0x115e78['name']+':',..._0x417b50);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x59c610+')');};class Bi{constructor(_0x34a4b8){this['name']=_0x34a4b8,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x398268){if(!(_0x398268 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x398268+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x398268;}['setLogLevel'](_0x2c2397){this['_logLevel']=typeof _0x2c2397=='string'?Oc[_0x2c2397]:_0x2c2397;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3f469c){if(typeof _0x3f469c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3f469c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5d2538){this['_userLogHandler']=_0x5d2538;}['debug'](..._0x73105b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x73105b),this['_logHandler'](this,T['DEBUG'],..._0x73105b);}['log'](..._0x6fa4cd){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x6fa4cd),this['_logHandler'](this,T['VERBOSE'],..._0x6fa4cd);}['info'](..._0x1f81b1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1f81b1),this['_logHandler'](this,T['INFO'],..._0x1f81b1);}['warn'](..._0x5359e8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x5359e8),this['_logHandler'](this,T['WARN'],..._0x5359e8);}['error'](..._0x58c0ca){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x58c0ca),this['_logHandler'](this,T['ERROR'],..._0x58c0ca);}}const xc=(_0x515595,_0x320f1b)=>_0x320f1b['some'](_0x2240dd=>_0x515595 instanceof _0x2240dd);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x56a4c2){const _0xa6c9d2=new Promise((_0x174e2b,_0x105dd2)=>{const _0x147d67=()=>{_0x56a4c2['removeEventListener']('success',_0x475dc1),_0x56a4c2['removeEventListener']('error',_0x599566);},_0x475dc1=()=>{_0x174e2b(ge(_0x56a4c2['result'])),_0x147d67();},_0x599566=()=>{_0x105dd2(_0x56a4c2['error']),_0x147d67();};_0x56a4c2['addEventListener']('success',_0x475dc1),_0x56a4c2['addEventListener']('error',_0x599566);});return _0xa6c9d2['then'](_0x4074d3=>{_0x4074d3 instanceof IDBCursor&&Jr['set'](_0x4074d3,_0x56a4c2);})['catch'](()=>{}),Vi['set'](_0xa6c9d2,_0x56a4c2),_0xa6c9d2;}function Bc(_0x275f18){if(_i['has'](_0x275f18))return;const _0x56ebbc=new Promise((_0x2467ce,_0x8bb1c3)=>{const _0x4968e=()=>{_0x275f18['removeEventListener']('complete',_0x42f32f),_0x275f18['removeEventListener']('error',_0x345b31),_0x275f18['removeEventListener']('abort',_0x345b31);},_0x42f32f=()=>{_0x2467ce(),_0x4968e();},_0x345b31=()=>{_0x8bb1c3(_0x275f18['error']||new DOMException('AbortError','AbortError')),_0x4968e();};_0x275f18['addEventListener']('complete',_0x42f32f),_0x275f18['addEventListener']('error',_0x345b31),_0x275f18['addEventListener']('abort',_0x345b31);});_i['set'](_0x275f18,_0x56ebbc);}let gi={'get'(_0xbfc24c,_0x5d6edd,_0x41a465){if(_0xbfc24c instanceof IDBTransaction){if(_0x5d6edd==='done')return _i['get'](_0xbfc24c);if(_0x5d6edd==='objectStoreNames')return _0xbfc24c['objectStoreNames']||Xr['get'](_0xbfc24c);if(_0x5d6edd==='store')return _0x41a465['objectStoreNames'][0x1]?void 0x0:_0x41a465['objectStore'](_0x41a465['objectStoreNames'][0x0]);}return ge(_0xbfc24c[_0x5d6edd]);},'set'(_0x37baaf,_0x3dab13,_0x1a22f1){return _0x37baaf[_0x3dab13]=_0x1a22f1,!0x0;},'has'(_0x42c29f,_0x51ba1b){return _0x42c29f instanceof IDBTransaction&&(_0x51ba1b==='done'||_0x51ba1b==='store')?!0x0:_0x51ba1b in _0x42c29f;}};function Vc(_0x45dbc9){gi=_0x45dbc9(gi);}function Hc(_0x5490f8){return _0x5490f8===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4d04a6,..._0x421bb4){const _0x5c3f63=_0x5490f8['call'](ii(this),_0x4d04a6,..._0x421bb4);return Xr['set'](_0x5c3f63,_0x4d04a6['sort']?_0x4d04a6['sort']():[_0x4d04a6]),ge(_0x5c3f63);}:Uc()['includes'](_0x5490f8)?function(..._0x12e5ce){return _0x5490f8['apply'](ii(this),_0x12e5ce),ge(Jr['get'](this));}:function(..._0x4df537){return ge(_0x5490f8['apply'](ii(this),_0x4df537));};}function $c(_0x503eab){return typeof _0x503eab=='function'?Hc(_0x503eab):(_0x503eab instanceof IDBTransaction&&Bc(_0x503eab),xc(_0x503eab,Fc())?new Proxy(_0x503eab,gi):_0x503eab);}function ge(_0x1032ac){if(_0x1032ac instanceof IDBRequest)return Wc(_0x1032ac);if(ni['has'](_0x1032ac))return ni['get'](_0x1032ac);const _0x59253f=$c(_0x1032ac);return _0x59253f!==_0x1032ac&&(ni['set'](_0x1032ac,_0x59253f),Vi['set'](_0x59253f,_0x1032ac)),_0x59253f;}const ii=_0x1bc94c=>Vi['get'](_0x1bc94c);function Gc(_0x25b492,_0x5e92cb,{blocked:_0x4b328c,upgrade:_0x65d74a,blocking:_0x9f365f,terminated:_0x10f7fa}={}){const _0x33c933=indexedDB['open'](_0x25b492,_0x5e92cb),_0x59d349=ge(_0x33c933);return _0x65d74a&&_0x33c933['addEventListener']('upgradeneeded',_0x23c737=>{_0x65d74a(ge(_0x33c933['result']),_0x23c737['oldVersion'],_0x23c737['newVersion'],ge(_0x33c933['transaction']),_0x23c737);}),_0x4b328c&&_0x33c933['addEventListener']('blocked',_0x14890a=>_0x4b328c(_0x14890a['oldVersion'],_0x14890a['newVersion'],_0x14890a)),_0x59d349['then'](_0x1d6455=>{_0x10f7fa&&_0x1d6455['addEventListener']('close',()=>_0x10f7fa()),_0x9f365f&&_0x1d6455['addEventListener']('versionchange',_0x37b3dd=>_0x9f365f(_0x37b3dd['oldVersion'],_0x37b3dd['newVersion'],_0x37b3dd));})['catch'](()=>{}),_0x59d349;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x17f74c,_0x273e94){if(!(_0x17f74c instanceof IDBDatabase&&!(_0x273e94 in _0x17f74c)&&typeof _0x273e94=='string'))return;if(si['get'](_0x273e94))return si['get'](_0x273e94);const _0x5f0562=_0x273e94['replace'](/FromIndex$/,''),_0x1765a7=_0x273e94!==_0x5f0562,_0x3ebb18=zc['includes'](_0x5f0562);if(!(_0x5f0562 in(_0x1765a7?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3ebb18||qc['includes'](_0x5f0562)))return;const _0x4cf429=async function(_0x24d440,..._0x128dd3){const _0x4dacdd=this['transaction'](_0x24d440,_0x3ebb18?'readwrite':'readonly');let _0xda0531=_0x4dacdd['store'];return _0x1765a7&&(_0xda0531=_0xda0531['index'](_0x128dd3['shift']())),(await Promise['all']([_0xda0531[_0x5f0562](..._0x128dd3),_0x3ebb18&&_0x4dacdd['done']]))[0x0];};return si['set'](_0x273e94,_0x4cf429),_0x4cf429;}Vc(_0x4f5f41=>({..._0x4f5f41,'get':(_0x213282,_0x1d74cf,_0x2a70ee)=>Ms(_0x213282,_0x1d74cf)||_0x4f5f41['get'](_0x213282,_0x1d74cf,_0x2a70ee),'has':(_0x1c82b6,_0x3b2184)=>!!Ms(_0x1c82b6,_0x3b2184)||_0x4f5f41['has'](_0x1c82b6,_0x3b2184)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x36f839){this['container']=_0x36f839;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x279b73=>{if(Kc(_0x279b73)){const _0x23c713=_0x279b73['getImmediate']();return _0x23c713['library']+'/'+_0x23c713['version'];}else return null;})['filter'](_0xc0ca9f=>_0xc0ca9f)['join']('\x20');}}function Kc(_0x3bea44){const _0x45c89e=_0x3bea44['getComponent']();return(_0x45c89e==null?void 0x0:_0x45c89e['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x238cdc,_0x4692cb){try{_0x238cdc['container']['addComponent'](_0x4692cb);}catch(_0x59fd0e){oe['debug']('Component\x20'+_0x4692cb['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x238cdc['name'],_0x59fd0e);}}function st(_0x4261f3){const _0x28d349=_0x4261f3['name'];if(Ei['has'](_0x28d349))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x28d349+'.'),!0x1;Ei['set'](_0x28d349,_0x4261f3);for(const _0x56fc01 of Ue['values']())xs(_0x56fc01,_0x4261f3);for(const _0x230379 of vi['values']())xs(_0x230379,_0x4261f3);return!0x0;}function Hi(_0xb2f124,_0x2c47dd){const _0x388b7f=_0xb2f124['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x388b7f&&_0x388b7f['triggerHeartbeat'](),_0xb2f124['container']['getProvider'](_0x2c47dd);}function $(_0x4015c3){return _0x4015c3==null?!0x1:_0x4015c3['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x348fca,_0x4103fa,_0x4b2d28){this['_isDeleted']=!0x1,this['_options']={..._0x348fca},this['_config']={..._0x4103fa},this['_name']=_0x4103fa['name'],this['_automaticDataCollectionEnabled']=_0x4103fa['automaticDataCollectionEnabled'],this['_container']=_0x4b2d28,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3f06a5){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3f06a5;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0xd8c2bc){this['_isDeleted']=_0xd8c2bc;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x900d7d,_0x58c770={}){let _0x1d15ac=_0x900d7d;typeof _0x58c770!='object'&&(_0x58c770={'name':_0x58c770});const _0x34863d={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x58c770},_0x514c23=_0x34863d['name'];if(typeof _0x514c23!='string'||!_0x514c23)throw me['create']('bad-app-name',{'appName':String(_0x514c23)});if(_0x1d15ac||(_0x1d15ac=zr()),!_0x1d15ac)throw me['create']('no-options');const _0x27af92=Ue['get'](_0x514c23);if(_0x27af92){if(xe(_0x1d15ac,_0x27af92['options'])&&xe(_0x34863d,_0x27af92['config']))return _0x27af92;throw me['create']('duplicate-app',{'appName':_0x514c23});}const _0x3ef235=new Nc(_0x514c23);for(const _0x184247 of Ei['values']())_0x3ef235['addComponent'](_0x184247);const _0xb1cc2a=new Tl(_0x1d15ac,_0x34863d,_0x3ef235);return Ue['set'](_0x514c23,_0xb1cc2a),_0xb1cc2a;}function Zr(_0x1b6853=yi){const _0x3912be=Ue['get'](_0x1b6853);if(!_0x3912be&&_0x1b6853===yi&&zr())return Sl();if(!_0x3912be)throw me['create']('no-app',{'appName':_0x1b6853});return _0x3912be;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x478f7d){let _0x50495c=!0x1;const _0xe9d8da=_0x478f7d['name'];Ue['has'](_0xe9d8da)?(_0x50495c=!0x0,Ue['delete'](_0xe9d8da)):vi['has'](_0xe9d8da)&&_0x478f7d['decRefCount']()<=0x0&&(vi['delete'](_0xe9d8da),_0x50495c=!0x0),_0x50495c&&(await Promise['all'](_0x478f7d['container']['getProviders']()['map'](_0x267e12=>_0x267e12['delete']())),_0x478f7d['isDeleted']=!0x0);}function ye(_0x1691ea,_0x328651,_0x2ca386){let _0x3e2960=wl[_0x1691ea]??_0x1691ea;_0x2ca386&&(_0x3e2960+='-'+_0x2ca386);const _0x4a9e3c=_0x3e2960['match'](/\s|\//),_0x17545b=_0x328651['match'](/\s|\//);if(_0x4a9e3c||_0x17545b){const _0x498ac0=['Unable\x20to\x20register\x20library\x20\x22'+_0x3e2960+'\x22\x20with\x20version\x20\x22'+_0x328651+'\x22:'];_0x4a9e3c&&_0x498ac0['push']('library\x20name\x20\x22'+_0x3e2960+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4a9e3c&&_0x17545b&&_0x498ac0['push']('and'),_0x17545b&&_0x498ac0['push']('version\x20name\x20\x22'+_0x328651+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x498ac0['join']('\x20'));return;}st(new Fe(_0x3e2960+'-version',()=>({'library':_0x3e2960,'version':_0x328651}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x2e3aa8,_0x1f53f0)=>{switch(_0x1f53f0){case 0x0:try{_0x2e3aa8['createObjectStore'](Ot);}catch(_0x5db4de){console['warn'](_0x5db4de);}}}})['catch'](_0x25f6f9=>{throw me['create']('idb-open',{'originalErrorMessage':_0x25f6f9['message']});})),ri;}async function Al(_0x5df256){try{const _0x1ebc52=(await eo())['transaction'](Ot),_0x5792bd=await _0x1ebc52['objectStore'](Ot)['get'](to(_0x5df256));return await _0x1ebc52['done'],_0x5792bd;}catch(_0x4bcf4b){if(_0x4bcf4b instanceof Re)oe['warn'](_0x4bcf4b['message']);else{const _0x4a7f4=me['create']('idb-get',{'originalErrorMessage':_0x4bcf4b==null?void 0x0:_0x4bcf4b['message']});oe['warn'](_0x4a7f4['message']);}}}async function Fs(_0xa00da7,_0x51aa22){try{const _0x2034c8=(await eo())['transaction'](Ot,'readwrite');await _0x2034c8['objectStore'](Ot)['put'](_0x51aa22,to(_0xa00da7)),await _0x2034c8['done'];}catch(_0xf036be){if(_0xf036be instanceof Re)oe['warn'](_0xf036be['message']);else{const _0x284a66=me['create']('idb-set',{'originalErrorMessage':_0xf036be==null?void 0x0:_0xf036be['message']});oe['warn'](_0x284a66['message']);}}}function to(_0x471034){return _0x471034['name']+'!'+_0x471034['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x1e4833){this['container']=_0x1e4833,this['_heartbeatsCache']=null;const _0x1391d6=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1391d6),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3c8ff5=>(this['_heartbeatsCache']=_0x3c8ff5,_0x3c8ff5));}async['triggerHeartbeat'](){var _0x3388db,_0x56f76f;try{const _0x17f291=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2649e9=Us();if(((_0x3388db=this['_heartbeatsCache'])==null?void 0x0:_0x3388db['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x56f76f=this['_heartbeatsCache'])==null?void 0x0:_0x56f76f['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2649e9||this['_heartbeatsCache']['heartbeats']['some'](_0xd4ded2=>_0xd4ded2['date']===_0x2649e9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2649e9,'agent':_0x17f291}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x42d686=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x42d686,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x45d673){oe['warn'](_0x45d673);}}async['getHeartbeatsHeader'](){var _0x193b49;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x193b49=this['_heartbeatsCache'])==null?void 0x0:_0x193b49['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x338193=Us(),{heartbeatsToSend:_0x540279,unsentEntries:_0x633a64}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2effcf=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x540279}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x338193,_0x633a64['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x633a64,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2effcf;}catch(_0x497279){return oe['warn'](_0x497279),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2959ae,_0x15034f=kl){const _0x2bdf29=[];let _0x3a8543=_0x2959ae['slice']();for(const _0xf74a9a of _0x2959ae){const _0x20afdb=_0x2bdf29['find'](_0x579596=>_0x579596['agent']===_0xf74a9a['agent']);if(_0x20afdb){if(_0x20afdb['dates']['push'](_0xf74a9a['date']),Ws(_0x2bdf29)>_0x15034f){_0x20afdb['dates']['pop']();break;}}else{if(_0x2bdf29['push']({'agent':_0xf74a9a['agent'],'dates':[_0xf74a9a['date']]}),Ws(_0x2bdf29)>_0x15034f){_0x2bdf29['pop']();break;}}_0x3a8543=_0x3a8543['slice'](0x1);}return{'heartbeatsToSend':_0x2bdf29,'unsentEntries':_0x3a8543};}class Dl{constructor(_0x332988){this['app']=_0x332988,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x38b8bf=await Al(this['app']);return _0x38b8bf!=null&&_0x38b8bf['heartbeats']?_0x38b8bf:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x55c8cc){if(await this['_canUseIndexedDBPromise']){const _0x454d0a=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x55c8cc['lastSentHeartbeatDate']??_0x454d0a['lastSentHeartbeatDate'],'heartbeats':_0x55c8cc['heartbeats']});}else return;}async['add'](_0xf2ab3d){if(await this['_canUseIndexedDBPromise']){const _0x3cb0f1=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xf2ab3d['lastSentHeartbeatDate']??_0x3cb0f1['lastSentHeartbeatDate'],'heartbeats':[..._0x3cb0f1['heartbeats'],..._0xf2ab3d['heartbeats']]});}else return;}}function Ws(_0x3e6002){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3e6002}))['length'];}function Ml(_0x270a0a){if(_0x270a0a['length']===0x0)return-0x1;let _0x54b8a2=0x0,_0x298762=_0x270a0a[0x0]['date'];for(let _0x57c71b=0x1;_0x57c71b<_0x270a0a['length'];_0x57c71b++)_0x270a0a[_0x57c71b]['date']<_0x298762&&(_0x298762=_0x270a0a[_0x57c71b]['date'],_0x54b8a2=_0x57c71b);return _0x54b8a2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x20d15b){st(new Fe('platform-logger',_0xb1ec44=>new jc(_0xb1ec44),'PRIVATE')),st(new Fe('heartbeat',_0x57dc6d=>new Nl(_0x57dc6d),'PRIVATE')),ye(mi,Ls,_0x20d15b),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1cbf5e){no=_0x1cbf5e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x512098){this['domStorage_']=_0x512098,this['prefix_']='firebase:';}['set'](_0x405cbc,_0x26123b){_0x26123b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x405cbc)):this['domStorage_']['setItem'](this['prefixedName_'](_0x405cbc),O(_0x26123b));}['get'](_0x10fc81){const _0x2437a0=this['domStorage_']['getItem'](this['prefixedName_'](_0x10fc81));return _0x2437a0==null?null:Nt(_0x2437a0);}['remove'](_0x321127){this['domStorage_']['removeItem'](this['prefixedName_'](_0x321127));}['prefixedName_'](_0x15ed21){return this['prefix_']+_0x15ed21;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x136368,_0x11a868){_0x11a868==null?delete this['cache_'][_0x136368]:this['cache_'][_0x136368]=_0x11a868;}['get'](_0x178da6){return Q(this['cache_'],_0x178da6)?this['cache_'][_0x178da6]:null;}['remove'](_0x2450a8){delete this['cache_'][_0x2450a8];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x44ed6b){try{if(typeof window<'u'&&typeof window[_0x44ed6b]<'u'){const _0x433123=window[_0x44ed6b];return _0x433123['setItem']('firebase:sentinel','cache'),_0x433123['removeItem']('firebase:sentinel'),new Wl(_0x433123);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4376e1=0x1;return function(){return _0x4376e1++;};}()),ro=function(_0x192285){const _0xc602c0=Rc(_0x192285),_0xafbae3=new Cc();_0xafbae3['update'](_0xc602c0);const _0x559fdc=_0xafbae3['digest']();return Fi['encodeByteArray'](_0x559fdc);},zt=function(..._0x324826){let _0x3f77aa='';for(let _0xe83d12=0x0;_0xe83d12<_0x324826['length'];_0xe83d12++){const _0x244dda=_0x324826[_0xe83d12];Array['isArray'](_0x244dda)||_0x244dda&&typeof _0x244dda=='object'&&typeof _0x244dda['length']=='number'?_0x3f77aa+=zt['apply'](null,_0x244dda):typeof _0x244dda=='object'?_0x3f77aa+=O(_0x244dda):_0x3f77aa+=_0x244dda,_0x3f77aa+='\x20';}return _0x3f77aa;};let St=null,$s=!0x0;const Hl=function(_0x3fbd1f,_0xc6b16a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x383e42){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x567ea3=zt['apply'](null,_0x383e42);St(_0x567ea3);}},jt=function(_0x119669){return function(..._0x5a026c){L(_0x119669,..._0x5a026c);};},Ii=function(..._0x2d58cb){const _0x17aa44='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2d58cb);Ze['error'](_0x17aa44);},ae=function(..._0x235ded){const _0x1ef064='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x235ded);throw Ze['error'](_0x1ef064),new Error(_0x1ef064);},U=function(..._0x160d30){const _0xedb0f2='FIREBASE\x20WARNING:\x20'+zt(..._0x160d30);Ze['warn'](_0xedb0f2);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0xd8e35f){return typeof _0xd8e35f=='number'&&(_0xd8e35f!==_0xd8e35f||_0xd8e35f===Number['POSITIVE_INFINITY']||_0xd8e35f===Number['NEGATIVE_INFINITY']);},Gl=function(_0x49e898){if(document['readyState']==='complete')_0x49e898();else{let _0x5b10df=!0x1;const _0x4602e6=function(){if(!document['body']){setTimeout(_0x4602e6,Math['floor'](0xa));return;}_0x5b10df||(_0x5b10df=!0x0,_0x49e898());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4602e6,!0x1),window['addEventListener']('load',_0x4602e6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4602e6();}),window['attachEvent']('onload',_0x4602e6));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x3994cc,_0x5eb12a){if(_0x3994cc===_0x5eb12a)return 0x0;if(_0x3994cc===We||_0x5eb12a===we)return-0x1;if(_0x5eb12a===We||_0x3994cc===we)return 0x1;{const _0x4fec8c=Gs(_0x3994cc),_0x5cce37=Gs(_0x5eb12a);return _0x4fec8c!==null?_0x5cce37!==null?_0x4fec8c-_0x5cce37===0x0?_0x3994cc['length']-_0x5eb12a['length']:_0x4fec8c-_0x5cce37:-0x1:_0x5cce37!==null?0x1:_0x3994cc<_0x5eb12a?-0x1:0x1;}},ql=function(_0x5cc855,_0x4e8bd9){return _0x5cc855===_0x4e8bd9?0x0:_0x5cc855<_0x4e8bd9?-0x1:0x1;},vt=function(_0x207b42,_0xb6d487){if(_0xb6d487&&_0x207b42 in _0xb6d487)return _0xb6d487[_0x207b42];throw new Error('Missing\x20required\x20key\x20('+_0x207b42+')\x20in\x20object:\x20'+O(_0xb6d487));},$i=function(_0x1392b2){if(typeof _0x1392b2!='object'||_0x1392b2===null)return O(_0x1392b2);const _0x218e88=[];for(const _0x33303f in _0x1392b2)_0x218e88['push'](_0x33303f);_0x218e88['sort']();let _0x2c58fe='{';for(let _0x5da7e0=0x0;_0x5da7e0<_0x218e88['length'];_0x5da7e0++)_0x5da7e0!==0x0&&(_0x2c58fe+=','),_0x2c58fe+=O(_0x218e88[_0x5da7e0]),_0x2c58fe+=':',_0x2c58fe+=$i(_0x1392b2[_0x218e88[_0x5da7e0]]);return _0x2c58fe+='}',_0x2c58fe;},oo=function(_0x598b69,_0x43f827){const _0x1d26be=_0x598b69['length'];if(_0x1d26be<=_0x43f827)return[_0x598b69];const _0x1d3726=[];for(let _0xf7f0b9=0x0;_0xf7f0b9<_0x1d26be;_0xf7f0b9+=_0x43f827)_0xf7f0b9+_0x43f827>_0x1d26be?_0x1d3726['push'](_0x598b69['substring'](_0xf7f0b9,_0x1d26be)):_0x1d3726['push'](_0x598b69['substring'](_0xf7f0b9,_0xf7f0b9+_0x43f827));return _0x1d3726;};function x(_0x3c4b99,_0x3727c3){for(const _0x34890e in _0x3c4b99)_0x3c4b99['hasOwnProperty'](_0x34890e)&&_0x3727c3(_0x34890e,_0x3c4b99[_0x34890e]);}const ao=function(_0xd8777d){f(!xn(_0xd8777d),'Invalid\x20JSON\x20number');const _0x33767e=0xb,_0x57e0db=0x34,_0x44e8d9=(0x1<<_0x33767e-0x1)-0x1;let _0x317cd7,_0x1810c4,_0x5e8739,_0xc63d61,_0x1d7d24;_0xd8777d===0x0?(_0x1810c4=0x0,_0x5e8739=0x0,_0x317cd7=0x1/_0xd8777d===-0x1/0x0?0x1:0x0):(_0x317cd7=_0xd8777d<0x0,_0xd8777d=Math['abs'](_0xd8777d),_0xd8777d>=Math['pow'](0x2,0x1-_0x44e8d9)?(_0xc63d61=Math['min'](Math['floor'](Math['log'](_0xd8777d)/Math['LN2']),_0x44e8d9),_0x1810c4=_0xc63d61+_0x44e8d9,_0x5e8739=Math['round'](_0xd8777d*Math['pow'](0x2,_0x57e0db-_0xc63d61)-Math['pow'](0x2,_0x57e0db))):(_0x1810c4=0x0,_0x5e8739=Math['round'](_0xd8777d/Math['pow'](0x2,0x1-_0x44e8d9-_0x57e0db))));const _0x214ca3=[];for(_0x1d7d24=_0x57e0db;_0x1d7d24;_0x1d7d24-=0x1)_0x214ca3['push'](_0x5e8739%0x2?0x1:0x0),_0x5e8739=Math['floor'](_0x5e8739/0x2);for(_0x1d7d24=_0x33767e;_0x1d7d24;_0x1d7d24-=0x1)_0x214ca3['push'](_0x1810c4%0x2?0x1:0x0),_0x1810c4=Math['floor'](_0x1810c4/0x2);_0x214ca3['push'](_0x317cd7?0x1:0x0),_0x214ca3['reverse']();const _0x13d4a8=_0x214ca3['join']('');let _0x350e30='';for(_0x1d7d24=0x0;_0x1d7d24<0x40;_0x1d7d24+=0x8){let _0x228319=parseInt(_0x13d4a8['substr'](_0x1d7d24,0x8),0x2)['toString'](0x10);_0x228319['length']===0x1&&(_0x228319='0'+_0x228319),_0x350e30=_0x350e30+_0x228319;}return _0x350e30['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x25e730,_0x1d6e6b){let _0x2f1f2e='Unknown\x20Error';_0x25e730==='too_big'?_0x2f1f2e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x25e730==='permission_denied'?_0x2f1f2e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x25e730==='unavailable'&&(_0x2f1f2e='The\x20service\x20is\x20unavailable');const _0x5d9480=new Error(_0x25e730+'\x20at\x20'+_0x1d6e6b['_path']['toString']()+':\x20'+_0x2f1f2e);return _0x5d9480['code']=_0x25e730['toUpperCase'](),_0x5d9480;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x126302){if(Yl['test'](_0x126302)){const _0x348dfb=Number(_0x126302);if(_0x348dfb>=Ql&&_0x348dfb<=Jl)return _0x348dfb;}return null;},ft=function(_0x37150e){try{_0x37150e();}catch(_0x4c6761){setTimeout(()=>{const _0x12dc4e=_0x4c6761['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x12dc4e),_0x4c6761;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x27aab3,_0x582d24){const _0x28b2d1=setTimeout(_0x27aab3,_0x582d24);return typeof _0x28b2d1=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x28b2d1):typeof _0x28b2d1=='object'&&_0x28b2d1['unref']&&_0x28b2d1['unref'](),_0x28b2d1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x19bc68,_0x371a87){this['appCheckProvider']=_0x371a87,this['appName']=_0x19bc68['name'],$(_0x19bc68)&&_0x19bc68['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x19bc68['settings']['appCheckToken']),this['appCheck']=_0x371a87==null?void 0x0:_0x371a87['getImmediate']({'optional':!0x0}),this['appCheck']||_0x371a87==null||_0x371a87['get']()['then'](_0x23bc9c=>this['appCheck']=_0x23bc9c);}['getToken'](_0x2ad143){if(this['serverAppAppCheckToken']){if(_0x2ad143)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2ad143):new Promise((_0x2e1d13,_0x34e70d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2ad143)['then'](_0x2e1d13,_0x34e70d):_0x2e1d13(null);},0x0);});}['addTokenChangeListener'](_0x3962be){var _0x4f9301;(_0x4f9301=this['appCheckProvider'])==null||_0x4f9301['get']()['then'](_0x11f92e=>_0x11f92e['addTokenListener'](_0x3962be));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xb2ada3,_0x607262,_0x1b19e4){this['appName_']=_0xb2ada3,this['firebaseOptions_']=_0x607262,this['authProvider_']=_0x1b19e4,this['auth_']=null,this['auth_']=_0x1b19e4['getImmediate']({'optional':!0x0}),this['auth_']||_0x1b19e4['onInit'](_0x29ccdb=>this['auth_']=_0x29ccdb);}['getToken'](_0x479200){return this['auth_']?this['auth_']['getToken'](_0x479200)['catch'](_0x37d7b2=>_0x37d7b2&&_0x37d7b2['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x37d7b2)):new Promise((_0x5594f4,_0x1d7279)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x479200)['then'](_0x5594f4,_0x1d7279):_0x5594f4(null);},0x0);});}['addTokenChangeListener'](_0x279fa5){this['auth_']?this['auth_']['addAuthTokenListener'](_0x279fa5):this['authProvider_']['get']()['then'](_0x4c657f=>_0x4c657f['addAuthTokenListener'](_0x279fa5));}['removeTokenChangeListener'](_0x51b8ad){this['authProvider_']['get']()['then'](_0x578dfb=>_0x578dfb['removeAuthTokenListener'](_0x51b8ad));}['notifyForInvalidToken'](){let _0x492a58='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x492a58+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x492a58+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x492a58+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x492a58);}}class an{constructor(_0x1b5f15){this['accessToken']=_0x1b5f15;}['getToken'](_0x42d3e7){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xacee21){_0xacee21(this['accessToken']);}['removeTokenChangeListener'](_0x435a2f){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x201c04,_0xac6a8c,_0x5c9192,_0x21939b,_0x3e4e34=!0x1,_0x2a4279='',_0x4f41dd=!0x1,_0x457d84=!0x1,_0x47a842=null){this['secure']=_0xac6a8c,this['namespace']=_0x5c9192,this['webSocketOnly']=_0x21939b,this['nodeAdmin']=_0x3e4e34,this['persistenceKey']=_0x2a4279,this['includeNamespaceInQueryParams']=_0x4f41dd,this['isUsingEmulator']=_0x457d84,this['emulatorOptions']=_0x47a842,this['_host']=_0x201c04['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x201c04)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x293507){_0x293507!==this['internalHost']&&(this['internalHost']=_0x293507,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x470c88=this['toURLString']();return this['persistenceKey']&&(_0x470c88+='<'+this['persistenceKey']+'>'),_0x470c88;}['toURLString'](){const _0x5e06e4=this['secure']?'https://':'http://',_0x2fca00=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5e06e4+this['host']+'/'+_0x2fca00;}}function th(_0x4055ce){return _0x4055ce['host']!==_0x4055ce['internalHost']||_0x4055ce['isCustomHost']()||_0x4055ce['includeNamespaceInQueryParams'];}function vo(_0x525312,_0x2ab887,_0x5e6b4c){f(typeof _0x2ab887=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5e6b4c=='object','typeof\x20params\x20must\x20==\x20object');let _0x1a6910;if(_0x2ab887===go)_0x1a6910=(_0x525312['secure']?'wss://':'ws://')+_0x525312['internalHost']+'/.ws?';else{if(_0x2ab887===mo)_0x1a6910=(_0x525312['secure']?'https://':'http://')+_0x525312['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2ab887);}th(_0x525312)&&(_0x5e6b4c['ns']=_0x525312['namespace']);const _0x471483=[];return x(_0x5e6b4c,(_0x384469,_0x26b8d3)=>{_0x471483['push'](_0x384469+'='+_0x26b8d3);}),_0x1a6910+_0x471483['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1a7473,_0x43f799=0x1){Q(this['counters_'],_0x1a7473)||(this['counters_'][_0x1a7473]=0x0),this['counters_'][_0x1a7473]+=_0x43f799;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x4ae9c7){const _0x15e31a=_0x4ae9c7['toString']();return oi[_0x15e31a]||(oi[_0x15e31a]=new nh()),oi[_0x15e31a];}function ih(_0x3d4d4d,_0x476422){const _0x1f8486=_0x3d4d4d['toString']();return ai[_0x1f8486]||(ai[_0x1f8486]=_0x476422()),ai[_0x1f8486];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4b3264){this['onMessage_']=_0x4b3264,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x47e829,_0x4c3ec2){this['closeAfterResponse']=_0x47e829,this['onClose']=_0x4c3ec2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x54f042,_0x320555){for(this['pendingResponses'][_0x54f042]=_0x320555;this['pendingResponses'][this['currentResponseNum']];){const _0xb0362f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5926f1=0x0;_0x5926f1<_0xb0362f['length'];++_0x5926f1)_0xb0362f[_0x5926f1]&&ft(()=>{this['onMessage_'](_0xb0362f[_0x5926f1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x4bd71a,_0x17c220,_0x208d96,_0x23176a,_0x39106f,_0x1eeb3e,_0x2749ca){this['connId']=_0x4bd71a,this['repoInfo']=_0x17c220,this['applicationId']=_0x208d96,this['appCheckToken']=_0x23176a,this['authToken']=_0x39106f,this['transportSessionId']=_0x1eeb3e,this['lastSessionId']=_0x2749ca,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x4bd71a),this['stats_']=qi(_0x17c220),this['urlFn']=_0x59219b=>(this['appCheckToken']&&(_0x59219b[wi]=this['appCheckToken']),vo(_0x17c220,mo,_0x59219b));}['open'](_0x5515e7,_0xc0d3e7){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xc0d3e7,this['myPacketOrderer']=new sh(_0x5515e7),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x42f69c)=>{const [_0x33c8d8,_0x4501c6,_0x122365,_0x3092b9,_0x4c7d6a]=_0x42f69c;if(this['incrementIncomingBytes_'](_0x42f69c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x33c8d8===qs)this['id']=_0x4501c6,this['password']=_0x122365;else{if(_0x33c8d8===rh)_0x4501c6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4501c6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x33c8d8);}}},(..._0x3d2ee9)=>{const [_0x47241d,_0x5b3c91]=_0x3d2ee9;this['incrementIncomingBytes_'](_0x3d2ee9),this['myPacketOrderer']['handleResponse'](_0x47241d,_0x5b3c91);},()=>{this['onClosed_']();},this['urlFn']);const _0x5e351a={};_0x5e351a[qs]='t',_0x5e351a[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5e351a[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5e351a[co]=Gi,this['transportSessionId']&&(_0x5e351a[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5e351a[po]=this['lastSessionId']),this['applicationId']&&(_0x5e351a[_o]=this['applicationId']),this['appCheckToken']&&(_0x5e351a[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5e351a[ho]=uo);const _0x20d797=this['urlFn'](_0x5e351a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x20d797),this['scriptTagHolder']['addTag'](_0x20d797,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xc511ad){const _0x40b9a7=O(_0xc511ad);this['bytesSent']+=_0x40b9a7['length'],this['stats_']['incrementCounter']('bytes_sent',_0x40b9a7['length']);const _0x1e224e=$r(_0x40b9a7),_0x5e048d=oo(_0x1e224e,fh);for(let _0x186b05=0x0;_0x186b05<_0x5e048d['length'];_0x186b05++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5e048d['length'],_0x5e048d[_0x186b05]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4ccd71,_0x357462){this['myDisconnFrame']=document['createElement']('iframe');const _0x43e964={};_0x43e964[dh]='t',_0x43e964[Eo]=_0x4ccd71,_0x43e964[Io]=_0x357462,this['myDisconnFrame']['src']=this['urlFn'](_0x43e964),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xa996e5){const _0x2669c1=O(_0xa996e5)['length'];this['bytesReceived']+=_0x2669c1,this['stats_']['incrementCounter']('bytes_received',_0x2669c1);}}class zi{constructor(_0x282d2c,_0x45a180,_0x243c5d,_0x4a48f1){this['onDisconnect']=_0x243c5d,this['urlFn']=_0x4a48f1,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x282d2c,window[ah+this['uniqueCallbackIdentifier']]=_0x45a180,this['myIFrame']=zi['createIFrame_']();let _0x1a3691='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1a3691='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1779db='<html><body>'+_0x1a3691+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1779db),this['myIFrame']['doc']['close']();}catch(_0x5c66ad){L('frame\x20writing\x20exception'),_0x5c66ad['stack']&&L(_0x5c66ad['stack']),L(_0x5c66ad);}}}static['createIFrame_'](){const _0x291252=document['createElement']('iframe');if(_0x291252['style']['display']='none',document['body']){document['body']['appendChild'](_0x291252);try{_0x291252['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x38f092=document['domain'];_0x291252['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x38f092+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x291252['contentDocument']?_0x291252['doc']=_0x291252['contentDocument']:_0x291252['contentWindow']?_0x291252['doc']=_0x291252['contentWindow']['document']:_0x291252['document']&&(_0x291252['doc']=_0x291252['document']),_0x291252;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0xe54c87=this['onDisconnect'];_0xe54c87&&(this['onDisconnect']=null,_0xe54c87());}['startLongPoll'](_0x32a6d9,_0x4133e6){for(this['myID']=_0x32a6d9,this['myPW']=_0x4133e6,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2d956f={};_0x2d956f[Eo]=this['myID'],_0x2d956f[Io]=this['myPW'],_0x2d956f[wo]=this['currentSerial'];let _0x12b0b2=this['urlFn'](_0x2d956f),_0x201378='',_0x1b6a20=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x201378['length']<=Co;){const _0x29321d=this['pendingSegs']['shift']();_0x201378=_0x201378+'&'+lh+_0x1b6a20+'='+_0x29321d['seg']+'&'+hh+_0x1b6a20+'='+_0x29321d['ts']+'&'+uh+_0x1b6a20+'='+_0x29321d['d'],_0x1b6a20++;}return _0x12b0b2=_0x12b0b2+_0x201378,this['addLongPollTag_'](_0x12b0b2,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1c6b20,_0x32647c,_0x252426){this['pendingSegs']['push']({'seg':_0x1c6b20,'ts':_0x32647c,'d':_0x252426}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x318532,_0x167fb7){this['outstandingRequests']['add'](_0x167fb7);const _0x56ee68=()=>{this['outstandingRequests']['delete'](_0x167fb7),this['newRequest_']();},_0x2fcc84=setTimeout(_0x56ee68,Math['floor'](ph)),_0x304a6e=()=>{clearTimeout(_0x2fcc84),_0x56ee68();};this['addTag'](_0x318532,_0x304a6e);}['addTag'](_0x41de47,_0x145ec0){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4dacbc=this['myIFrame']['doc']['createElement']('script');_0x4dacbc['type']='text/javascript',_0x4dacbc['async']=!0x0,_0x4dacbc['src']=_0x41de47,_0x4dacbc['onload']=_0x4dacbc['onreadystatechange']=function(){const _0x1d639a=_0x4dacbc['readyState'];(!_0x1d639a||_0x1d639a==='loaded'||_0x1d639a==='complete')&&(_0x4dacbc['onload']=_0x4dacbc['onreadystatechange']=null,_0x4dacbc['parentNode']&&_0x4dacbc['parentNode']['removeChild'](_0x4dacbc),_0x145ec0());},_0x4dacbc['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x41de47),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4dacbc);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x43afef,_0x4e700f,_0x26f23b,_0x202710,_0x39a823,_0x31ef5a,_0x24e5cf){this['connId']=_0x43afef,this['applicationId']=_0x26f23b,this['appCheckToken']=_0x202710,this['authToken']=_0x39a823,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x4e700f),this['connURL']=q['connectionURL_'](_0x4e700f,_0x31ef5a,_0x24e5cf,_0x202710,_0x26f23b),this['nodeAdmin']=_0x4e700f['nodeAdmin'];}static['connectionURL_'](_0x24609e,_0x1420f1,_0x165f23,_0x3a9418,_0x9d3318){const _0x253b31={};return _0x253b31[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x253b31[ho]=uo),_0x1420f1&&(_0x253b31[lo]=_0x1420f1),_0x165f23&&(_0x253b31[po]=_0x165f23),_0x3a9418&&(_0x253b31[wi]=_0x3a9418),_0x9d3318&&(_0x253b31[_o]=_0x9d3318),vo(_0x24609e,go,_0x253b31);}['open'](_0x18c3ab,_0x550bf0){this['onDisconnect']=_0x550bf0,this['onMessage']=_0x18c3ab,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x56c6f6;_c(),this['mySock']=new gn(this['connURL'],[],_0x56c6f6);}catch(_0x252446){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2f5be9=_0x252446['message']||_0x252446['data'];_0x2f5be9&&this['log_'](_0x2f5be9),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4a7009=>{this['handleIncomingFrame'](_0x4a7009);},this['mySock']['onerror']=_0xf019ea=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4d0ade=_0xf019ea['message']||_0xf019ea['data'];_0x4d0ade&&this['log_'](_0x4d0ade),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5dce84=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2421fd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x37ed1e=navigator['userAgent']['match'](_0x2421fd);_0x37ed1e&&_0x37ed1e['length']>0x1&&parseFloat(_0x37ed1e[0x1])<4.4&&(_0x5dce84=!0x0);}return!_0x5dce84&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5037d5){if(this['frames']['push'](_0x5037d5),this['frames']['length']===this['totalFrames']){const _0x3f0cb6=this['frames']['join']('');this['frames']=null;const _0x3facfa=Nt(_0x3f0cb6);this['onMessage'](_0x3facfa);}}['handleNewFrameCount_'](_0xf82beb){this['totalFrames']=_0xf82beb,this['frames']=[];}['extractFrameCount_'](_0x426822){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x426822['length']<=0x6){const _0x2aadbe=Number(_0x426822);if(!isNaN(_0x2aadbe))return this['handleNewFrameCount_'](_0x2aadbe),null;}return this['handleNewFrameCount_'](0x1),_0x426822;}['handleIncomingFrame'](_0x3c9a6e){if(this['mySock']===null)return;const _0x1b8554=_0x3c9a6e['data'];if(this['bytesReceived']+=_0x1b8554['length'],this['stats_']['incrementCounter']('bytes_received',_0x1b8554['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1b8554);else{const _0x177638=this['extractFrameCount_'](_0x1b8554);_0x177638!==null&&this['appendFrame_'](_0x177638);}}['send'](_0x399734){this['resetKeepAlive']();const _0x11e541=O(_0x399734);this['bytesSent']+=_0x11e541['length'],this['stats_']['incrementCounter']('bytes_sent',_0x11e541['length']);const _0x1b8110=oo(_0x11e541,gh);_0x1b8110['length']>0x1&&this['sendString_'](String(_0x1b8110['length']));for(let _0x465be8=0x0;_0x465be8<_0x1b8110['length'];_0x465be8++)this['sendString_'](_0x1b8110[_0x465be8]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x310bac){try{this['mySock']['send'](_0x310bac);}catch(_0x52939a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x52939a['message']||_0x52939a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x18f32e){this['initTransports_'](_0x18f32e);}['initTransports_'](_0x1f637d){const _0x25b27f=q&&q['isAvailable']();let _0x41c621=_0x25b27f&&!q['previouslyFailed']();if(_0x1f637d['webSocketOnly']&&(_0x25b27f||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x41c621=!0x0),_0x41c621)this['transports_']=[q];else{const _0x4384a4=this['transports_']=[];for(const _0x2ea361 of Dt['ALL_TRANSPORTS'])_0x2ea361&&_0x2ea361['isAvailable']()&&_0x4384a4['push'](_0x2ea361);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x13f3fe,_0x3b1c11,_0xec64c9,_0x30a7e6,_0x51b657,_0x15aa7f,_0x5dc4fe,_0x3ab531,_0x504675,_0x3d5476){this['id']=_0x13f3fe,this['repoInfo_']=_0x3b1c11,this['applicationId_']=_0xec64c9,this['appCheckToken_']=_0x30a7e6,this['authToken_']=_0x51b657,this['onMessage_']=_0x15aa7f,this['onReady_']=_0x5dc4fe,this['onDisconnect_']=_0x3ab531,this['onKill_']=_0x504675,this['lastSessionId']=_0x3d5476,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3b1c11),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x47572f=this['transportManager_']['initialTransport']();this['conn_']=new _0x47572f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x47572f['responsesRequiredToBeHealthy']||0x0;const _0x1bcfaa=this['connReceiver_'](this['conn_']),_0x5bdd20=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1bcfaa,_0x5bdd20);},Math['floor'](0x0));const _0x397279=_0x47572f['healthyTimeout']||0x0;_0x397279>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x397279)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1294a8){return _0x4be2df=>{_0x1294a8===this['conn_']?this['onConnectionLost_'](_0x4be2df):_0x1294a8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5e4bce){return _0x4cd9dd=>{this['state_']!==0x2&&(_0x5e4bce===this['rx_']?this['onPrimaryMessageReceived_'](_0x4cd9dd):_0x5e4bce===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4cd9dd):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x70ae53){const _0x31387b={'t':'d','d':_0x70ae53};this['sendData_'](_0x31387b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x26b979){if(ci in _0x26b979){const _0x25657e=_0x26b979[ci];_0x25657e===Ys?this['upgradeIfSecondaryHealthy_']():_0x25657e===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x25657e===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x46b38f){const _0x2fa969=vt('t',_0x46b38f),_0x21ef7b=vt('d',_0x46b38f);if(_0x2fa969==='c')this['onSecondaryControl_'](_0x21ef7b);else{if(_0x2fa969==='d')this['pendingDataMessages']['push'](_0x21ef7b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x2fa969);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2214d3){const _0x3ec204=vt('t',_0x2214d3),_0xb59c21=vt('d',_0x2214d3);_0x3ec204==='c'?this['onControl_'](_0xb59c21):_0x3ec204==='d'&&this['onDataMessage_'](_0xb59c21);}['onDataMessage_'](_0x728ec9){this['onPrimaryResponse_'](),this['onMessage_'](_0x728ec9);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x54b539){const _0xf246d5=vt(ci,_0x54b539);if(zs in _0x54b539){const _0x5275cc=_0x54b539[zs];if(_0xf246d5===Th){const _0x44ba14={..._0x5275cc};this['repoInfo_']['isUsingEmulator']&&(_0x44ba14['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x44ba14);}else{if(_0xf246d5===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1c0d27=0x0;_0x1c0d27<this['pendingDataMessages']['length'];++_0x1c0d27)this['onDataMessage_'](this['pendingDataMessages'][_0x1c0d27]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xf246d5===wh?this['onConnectionShutdown_'](_0x5275cc):_0xf246d5===js?this['onReset_'](_0x5275cc):_0xf246d5===Ch?Ii('Server\x20Error:\x20'+_0x5275cc):_0xf246d5===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xf246d5);}}}['onHandshake_'](_0x131501){const _0xc10854=_0x131501['ts'],_0x5d6991=_0x131501['v'],_0x529157=_0x131501['h'];this['sessionId']=_0x131501['s'],this['repoInfo_']['host']=_0x529157,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xc10854),Gi!==_0x5d6991&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5b4b87=this['transportManager_']['upgradeTransport']();_0x5b4b87&&this['startUpgrade_'](_0x5b4b87);}['startUpgrade_'](_0x51dd90){this['secondaryConn_']=new _0x51dd90(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x51dd90['responsesRequiredToBeHealthy']||0x0;const _0x4330c2=this['connReceiver_'](this['secondaryConn_']),_0x422010=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4330c2,_0x422010),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x6b89fc){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x6b89fc),this['repoInfo_']['host']=_0x6b89fc,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x368fae,_0xd25f1e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x368fae,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xd25f1e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x16ea1c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x16ea1c||this['rx_']===_0x16ea1c)&&this['close']();}['onConnectionLost_'](_0x2daf4c){this['conn_']=null,!_0x2daf4c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x495b68){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x495b68),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3d3690){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3d3690);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x10b762,_0x2d2bf9,_0x54dcd5,_0x1eaedc){}['merge'](_0x2cfdbc,_0x3477ec,_0x51574e,_0x214a53){}['refreshAuthToken'](_0x2cc91d){}['refreshAppCheckToken'](_0x574c36){}['onDisconnectPut'](_0x333125,_0x5695e2,_0x546be9){}['onDisconnectMerge'](_0x40b685,_0x419f78,_0xe0e35b){}['onDisconnectCancel'](_0x47c9fe,_0x20409e){}['reportStats'](_0x187d83){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x59e3e8){this['allowedEvents_']=_0x59e3e8,this['listeners_']={},f(Array['isArray'](_0x59e3e8)&&_0x59e3e8['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1e152e,..._0x1d6961){if(Array['isArray'](this['listeners_'][_0x1e152e])){const _0x2d3d04=[...this['listeners_'][_0x1e152e]];for(let _0x17d29e=0x0;_0x17d29e<_0x2d3d04['length'];_0x17d29e++)_0x2d3d04[_0x17d29e]['callback']['apply'](_0x2d3d04[_0x17d29e]['context'],_0x1d6961);}}['on'](_0x5bc713,_0x10ca55,_0x1bce68){this['validateEventType_'](_0x5bc713),this['listeners_'][_0x5bc713]=this['listeners_'][_0x5bc713]||[],this['listeners_'][_0x5bc713]['push']({'callback':_0x10ca55,'context':_0x1bce68});const _0x32f495=this['getInitialEvent'](_0x5bc713);_0x32f495&&_0x10ca55['apply'](_0x1bce68,_0x32f495);}['off'](_0x36c8ec,_0x6f4650,_0x543ce3){this['validateEventType_'](_0x36c8ec);const _0x2ca0b1=this['listeners_'][_0x36c8ec]||[];for(let _0x41c320=0x0;_0x41c320<_0x2ca0b1['length'];_0x41c320++)if(_0x2ca0b1[_0x41c320]['callback']===_0x6f4650&&(!_0x543ce3||_0x543ce3===_0x2ca0b1[_0x41c320]['context'])){_0x2ca0b1['splice'](_0x41c320,0x1);return;}}['validateEventType_'](_0x1a7e6b){f(this['allowedEvents_']['find'](_0x1b9fe5=>_0x1b9fe5===_0x1a7e6b),'Unknown\x20event:\x20'+_0x1a7e6b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x183739){return f(_0x183739==='online','Unknown\x20event\x20type:\x20'+_0x183739),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x19433b,_0x18cd28){if(_0x18cd28===void 0x0){this['pieces_']=_0x19433b['split']('/');let _0x3907a5=0x0;for(let _0x40bf18=0x0;_0x40bf18<this['pieces_']['length'];_0x40bf18++)this['pieces_'][_0x40bf18]['length']>0x0&&(this['pieces_'][_0x3907a5]=this['pieces_'][_0x40bf18],_0x3907a5++);this['pieces_']['length']=_0x3907a5,this['pieceNum_']=0x0;}else this['pieces_']=_0x19433b,this['pieceNum_']=_0x18cd28;}['toString'](){let _0x2c0e0a='';for(let _0x625d03=this['pieceNum_'];_0x625d03<this['pieces_']['length'];_0x625d03++)this['pieces_'][_0x625d03]!==''&&(_0x2c0e0a+='/'+this['pieces_'][_0x625d03]);return _0x2c0e0a||'/';}}function w(){return new C('');}function y(_0x1c196c){return _0x1c196c['pieceNum_']>=_0x1c196c['pieces_']['length']?null:_0x1c196c['pieces_'][_0x1c196c['pieceNum_']];}function Ce(_0x17f872){return _0x17f872['pieces_']['length']-_0x17f872['pieceNum_'];}function S(_0x941277){let _0x3f01b3=_0x941277['pieceNum_'];return _0x3f01b3<_0x941277['pieces_']['length']&&_0x3f01b3++,new C(_0x941277['pieces_'],_0x3f01b3);}function ji(_0x573274){return _0x573274['pieceNum_']<_0x573274['pieces_']['length']?_0x573274['pieces_'][_0x573274['pieces_']['length']-0x1]:null;}function bh(_0x41c72d){let _0x7face6='';for(let _0x13ef3a=_0x41c72d['pieceNum_'];_0x13ef3a<_0x41c72d['pieces_']['length'];_0x13ef3a++)_0x41c72d['pieces_'][_0x13ef3a]!==''&&(_0x7face6+='/'+encodeURIComponent(String(_0x41c72d['pieces_'][_0x13ef3a])));return _0x7face6||'/';}function Mt(_0x18b81f,_0xb5e0b0=0x0){return _0x18b81f['pieces_']['slice'](_0x18b81f['pieceNum_']+_0xb5e0b0);}function Ro(_0x2d9357){if(_0x2d9357['pieceNum_']>=_0x2d9357['pieces_']['length'])return null;const _0x23349f=[];for(let _0x1a6565=_0x2d9357['pieceNum_'];_0x1a6565<_0x2d9357['pieces_']['length']-0x1;_0x1a6565++)_0x23349f['push'](_0x2d9357['pieces_'][_0x1a6565]);return new C(_0x23349f,0x0);}function k(_0xadf90c,_0x2a0d6f){const _0x5dcdf2=[];for(let _0x3663aa=_0xadf90c['pieceNum_'];_0x3663aa<_0xadf90c['pieces_']['length'];_0x3663aa++)_0x5dcdf2['push'](_0xadf90c['pieces_'][_0x3663aa]);if(_0x2a0d6f instanceof C){for(let _0x594d60=_0x2a0d6f['pieceNum_'];_0x594d60<_0x2a0d6f['pieces_']['length'];_0x594d60++)_0x5dcdf2['push'](_0x2a0d6f['pieces_'][_0x594d60]);}else{const _0x4eb8ad=_0x2a0d6f['split']('/');for(let _0x2bb595=0x0;_0x2bb595<_0x4eb8ad['length'];_0x2bb595++)_0x4eb8ad[_0x2bb595]['length']>0x0&&_0x5dcdf2['push'](_0x4eb8ad[_0x2bb595]);}return new C(_0x5dcdf2,0x0);}function v(_0x43e2ed){return _0x43e2ed['pieceNum_']>=_0x43e2ed['pieces_']['length'];}function F(_0x3833ce,_0x459f73){const _0xcc25e9=y(_0x3833ce),_0x555eb0=y(_0x459f73);if(_0xcc25e9===null)return _0x459f73;if(_0xcc25e9===_0x555eb0)return F(S(_0x3833ce),S(_0x459f73));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x459f73+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3833ce+')');}function Rh(_0x26bb9c,_0x3abc73){const _0x14cab8=Mt(_0x26bb9c,0x0),_0x186d52=Mt(_0x3abc73,0x0);for(let _0x2e210e=0x0;_0x2e210e<_0x14cab8['length']&&_0x2e210e<_0x186d52['length'];_0x2e210e++){const _0x231f71=qe(_0x14cab8[_0x2e210e],_0x186d52[_0x2e210e]);if(_0x231f71!==0x0)return _0x231f71;}return _0x14cab8['length']===_0x186d52['length']?0x0:_0x14cab8['length']<_0x186d52['length']?-0x1:0x1;}function Ki(_0x470bde,_0x2476bb){if(Ce(_0x470bde)!==Ce(_0x2476bb))return!0x1;for(let _0x4cc0e3=_0x470bde['pieceNum_'],_0x518b5b=_0x2476bb['pieceNum_'];_0x4cc0e3<=_0x470bde['pieces_']['length'];_0x4cc0e3++,_0x518b5b++)if(_0x470bde['pieces_'][_0x4cc0e3]!==_0x2476bb['pieces_'][_0x518b5b])return!0x1;return!0x0;}function G(_0x456f62,_0x348b7e){let _0x1dc9d0=_0x456f62['pieceNum_'],_0x7823f8=_0x348b7e['pieceNum_'];if(Ce(_0x456f62)>Ce(_0x348b7e))return!0x1;for(;_0x1dc9d0<_0x456f62['pieces_']['length'];){if(_0x456f62['pieces_'][_0x1dc9d0]!==_0x348b7e['pieces_'][_0x7823f8])return!0x1;++_0x1dc9d0,++_0x7823f8;}return!0x0;}class Ah{constructor(_0x1c3128,_0x52be36){this['errorPrefix_']=_0x52be36,this['parts_']=Mt(_0x1c3128,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x58ffb6=0x0;_0x58ffb6<this['parts_']['length'];_0x58ffb6++)this['byteLength_']+=Ln(this['parts_'][_0x58ffb6]);Ao(this);}}function kh(_0x56be81,_0x3f4b76){_0x56be81['parts_']['length']>0x0&&(_0x56be81['byteLength_']+=0x1),_0x56be81['parts_']['push'](_0x3f4b76),_0x56be81['byteLength_']+=Ln(_0x3f4b76),Ao(_0x56be81);}function Ph(_0x5bbb1b){const _0x162ff4=_0x5bbb1b['parts_']['pop']();_0x5bbb1b['byteLength_']-=Ln(_0x162ff4),_0x5bbb1b['parts_']['length']>0x0&&(_0x5bbb1b['byteLength_']-=0x1);}function Ao(_0x568949){if(_0x568949['byteLength_']>Zs)throw new Error(_0x568949['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x568949['byteLength_']+').');if(_0x568949['parts_']['length']>Xs)throw new Error(_0x568949['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x568949));}function Oe(_0x2bf88e){return _0x2bf88e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2bf88e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x55c346,_0x39c234;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x39c234='visibilitychange',_0x55c346='hidden'):typeof document['mozHidden']<'u'?(_0x39c234='mozvisibilitychange',_0x55c346='mozHidden'):typeof document['msHidden']<'u'?(_0x39c234='msvisibilitychange',_0x55c346='msHidden'):typeof document['webkitHidden']<'u'&&(_0x39c234='webkitvisibilitychange',_0x55c346='webkitHidden')),this['visible_']=!0x0,_0x39c234&&document['addEventListener'](_0x39c234,()=>{const _0x591ee5=!document[_0x55c346];_0x591ee5!==this['visible_']&&(this['visible_']=_0x591ee5,this['trigger']('visible',_0x591ee5));},!0x1);}['getInitialEvent'](_0x2b40d0){return f(_0x2b40d0==='visible','Unknown\x20event\x20type:\x20'+_0x2b40d0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x30de91,_0x500140,_0x59d6f6,_0x238f7d,_0x22c254,_0xe8748a,_0x179977,_0x334143){if(super(),this['repoInfo_']=_0x30de91,this['applicationId_']=_0x500140,this['onDataUpdate_']=_0x59d6f6,this['onConnectStatus_']=_0x238f7d,this['onServerInfoUpdate_']=_0x22c254,this['authTokenProvider_']=_0xe8748a,this['appCheckTokenProvider_']=_0x179977,this['authOverride_']=_0x334143,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x334143)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x30de91['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x421333,_0x36f60e,_0x4e598f){const _0xcba291=++this['requestNumber_'],_0x3cfd14={'r':_0xcba291,'a':_0x421333,'b':_0x36f60e};this['log_'](O(_0x3cfd14)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3cfd14),_0x4e598f&&(this['requestCBHash_'][_0xcba291]=_0x4e598f);}['get'](_0x4b4a8c){this['initConnection_']();const _0x7efa29=new H(),_0x34c03c={'action':'g','request':{'p':_0x4b4a8c['_path']['toString'](),'q':_0x4b4a8c['_queryObject']},'onComplete':_0x109ca9=>{const _0xbf08b7=_0x109ca9['d'];_0x109ca9['s']==='ok'?_0x7efa29['resolve'](_0xbf08b7):_0x7efa29['reject'](_0xbf08b7);}};this['outstandingGets_']['push'](_0x34c03c),this['outstandingGetCount_']++;const _0x36832c=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x36832c),_0x7efa29['promise'];}['listen'](_0x495b41,_0x12ba4a,_0x36411b,_0x2f87de){this['initConnection_']();const _0x1c32ad=_0x495b41['_queryIdentifier'],_0x3c71ea=_0x495b41['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3c71ea+'\x20'+_0x1c32ad),this['listens']['has'](_0x3c71ea)||this['listens']['set'](_0x3c71ea,new Map()),f(_0x495b41['_queryParams']['isDefault']()||!_0x495b41['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3c71ea)['has'](_0x1c32ad),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x39f25d={'onComplete':_0x2f87de,'hashFn':_0x12ba4a,'query':_0x495b41,'tag':_0x36411b};this['listens']['get'](_0x3c71ea)['set'](_0x1c32ad,_0x39f25d),this['connected_']&&this['sendListen_'](_0x39f25d);}['sendGet_'](_0x3c8fd4){const _0x2f25a5=this['outstandingGets_'][_0x3c8fd4];this['sendRequest']('g',_0x2f25a5['request'],_0xd93f75=>{delete this['outstandingGets_'][_0x3c8fd4],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2f25a5['onComplete']&&_0x2f25a5['onComplete'](_0xd93f75);});}['sendListen_'](_0x578a5a){const _0x57af51=_0x578a5a['query'],_0x2c5dee=_0x57af51['_path']['toString'](),_0x288106=_0x57af51['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2c5dee+'\x20for\x20'+_0x288106);const _0x1b5073={'p':_0x2c5dee},_0x1ea604='q';_0x578a5a['tag']&&(_0x1b5073['q']=_0x57af51['_queryObject'],_0x1b5073['t']=_0x578a5a['tag']),_0x1b5073['h']=_0x578a5a['hashFn'](),this['sendRequest'](_0x1ea604,_0x1b5073,_0x4920a4=>{const _0x206832=_0x4920a4['d'],_0x42c4a2=_0x4920a4['s'];se['warnOnListenWarnings_'](_0x206832,_0x57af51),(this['listens']['get'](_0x2c5dee)&&this['listens']['get'](_0x2c5dee)['get'](_0x288106))===_0x578a5a&&(this['log_']('listen\x20response',_0x4920a4),_0x42c4a2!=='ok'&&this['removeListen_'](_0x2c5dee,_0x288106),_0x578a5a['onComplete']&&_0x578a5a['onComplete'](_0x42c4a2,_0x206832));});}static['warnOnListenWarnings_'](_0x3789be,_0x2ece1c){if(_0x3789be&&typeof _0x3789be=='object'&&Q(_0x3789be,'w')){const _0x49a417=Le(_0x3789be,'w');if(Array['isArray'](_0x49a417)&&~_0x49a417['indexOf']('no_index')){const _0x489610='\x22.indexOn\x22:\x20\x22'+_0x2ece1c['_queryParams']['getIndex']()['toString']()+'\x22',_0x550815=_0x2ece1c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x489610+'\x20at\x20'+_0x550815+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4125c4){this['authToken_']=_0x4125c4,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4125c4);}['reduceReconnectDelayIfAdminCredential_'](_0x22adfe){(_0x22adfe&&_0x22adfe['length']===0x28||wc(_0x22adfe))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x5b24a8){this['appCheckToken_']=_0x5b24a8,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xc8349f=this['authToken_'],_0x3c17b6=Ic(_0xc8349f)?'auth':'gauth',_0x513d75={'cred':_0xc8349f};this['authOverride_']===null?_0x513d75['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x513d75['authvar']=this['authOverride_']),this['sendRequest'](_0x3c17b6,_0x513d75,_0x5a2587=>{const _0x20dd8f=_0x5a2587['s'],_0x43f399=_0x5a2587['d']||'error';this['authToken_']===_0xc8349f&&(_0x20dd8f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x20dd8f,_0x43f399));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3d39c0=>{const _0x350cca=_0x3d39c0['s'],_0x22505a=_0x3d39c0['d']||'error';_0x350cca==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x350cca,_0x22505a);});}['unlisten'](_0x14ca46,_0xce8c74){const _0x5d08a9=_0x14ca46['_path']['toString'](),_0x4088bd=_0x14ca46['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5d08a9+'\x20'+_0x4088bd),f(_0x14ca46['_queryParams']['isDefault']()||!_0x14ca46['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5d08a9,_0x4088bd)&&this['connected_']&&this['sendUnlisten_'](_0x5d08a9,_0x4088bd,_0x14ca46['_queryObject'],_0xce8c74);}['sendUnlisten_'](_0x420f05,_0xf237a6,_0x2184b5,_0x19470c){this['log_']('Unlisten\x20on\x20'+_0x420f05+'\x20for\x20'+_0xf237a6);const _0x5b86a2={'p':_0x420f05},_0x1c15a1='n';_0x19470c&&(_0x5b86a2['q']=_0x2184b5,_0x5b86a2['t']=_0x19470c),this['sendRequest'](_0x1c15a1,_0x5b86a2);}['onDisconnectPut'](_0x597c6d,_0x42d1d9,_0x54570d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x597c6d,_0x42d1d9,_0x54570d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x597c6d,'action':'o','data':_0x42d1d9,'onComplete':_0x54570d});}['onDisconnectMerge'](_0x1cf123,_0x1538fb,_0x344d7a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1cf123,_0x1538fb,_0x344d7a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1cf123,'action':'om','data':_0x1538fb,'onComplete':_0x344d7a});}['onDisconnectCancel'](_0x3f62b8,_0x1846a6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3f62b8,null,_0x1846a6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3f62b8,'action':'oc','data':null,'onComplete':_0x1846a6});}['sendOnDisconnect_'](_0x5e6481,_0x4113a4,_0x70400a,_0x7deb1d){const _0x2da958={'p':_0x4113a4,'d':_0x70400a};this['log_']('onDisconnect\x20'+_0x5e6481,_0x2da958),this['sendRequest'](_0x5e6481,_0x2da958,_0x2bedc5=>{_0x7deb1d&&setTimeout(()=>{_0x7deb1d(_0x2bedc5['s'],_0x2bedc5['d']);},Math['floor'](0x0));});}['put'](_0x13c171,_0x451760,_0x13c4c2,_0x12c671){this['putInternal']('p',_0x13c171,_0x451760,_0x13c4c2,_0x12c671);}['merge'](_0x42c954,_0x246bae,_0x125666,_0x41e88d){this['putInternal']('m',_0x42c954,_0x246bae,_0x125666,_0x41e88d);}['putInternal'](_0x23d87b,_0x2fa794,_0x1ba9a9,_0xeb44b6,_0x37f2e5){this['initConnection_']();const _0x9c7ab2={'p':_0x2fa794,'d':_0x1ba9a9};_0x37f2e5!==void 0x0&&(_0x9c7ab2['h']=_0x37f2e5),this['outstandingPuts_']['push']({'action':_0x23d87b,'request':_0x9c7ab2,'onComplete':_0xeb44b6}),this['outstandingPutCount_']++;const _0x2d890a=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2d890a):this['log_']('Buffering\x20put:\x20'+_0x2fa794);}['sendPut_'](_0xfcac02){const _0xc93dca=this['outstandingPuts_'][_0xfcac02]['action'],_0x3f9dbd=this['outstandingPuts_'][_0xfcac02]['request'],_0x31e943=this['outstandingPuts_'][_0xfcac02]['onComplete'];this['outstandingPuts_'][_0xfcac02]['queued']=this['connected_'],this['sendRequest'](_0xc93dca,_0x3f9dbd,_0x21ab6b=>{this['log_'](_0xc93dca+'\x20response',_0x21ab6b),delete this['outstandingPuts_'][_0xfcac02],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x31e943&&_0x31e943(_0x21ab6b['s'],_0x21ab6b['d']);});}['reportStats'](_0x2f2904){if(this['connected_']){const _0x4c85e0={'c':_0x2f2904};this['log_']('reportStats',_0x4c85e0),this['sendRequest']('s',_0x4c85e0,_0x1aacf6=>{if(_0x1aacf6['s']!=='ok'){const _0x5e7972=_0x1aacf6['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5e7972);}});}}['onDataMessage_'](_0x3791cb){if('r'in _0x3791cb){this['log_']('from\x20server:\x20'+O(_0x3791cb));const _0x13bf15=_0x3791cb['r'],_0x441003=this['requestCBHash_'][_0x13bf15];_0x441003&&(delete this['requestCBHash_'][_0x13bf15],_0x441003(_0x3791cb['b']));}else{if('error'in _0x3791cb)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x3791cb['error'];'a'in _0x3791cb&&this['onDataPush_'](_0x3791cb['a'],_0x3791cb['b']);}}['onDataPush_'](_0x214a20,_0x292518){this['log_']('handleServerMessage',_0x214a20,_0x292518),_0x214a20==='d'?this['onDataUpdate_'](_0x292518['p'],_0x292518['d'],!0x1,_0x292518['t']):_0x214a20==='m'?this['onDataUpdate_'](_0x292518['p'],_0x292518['d'],!0x0,_0x292518['t']):_0x214a20==='c'?this['onListenRevoked_'](_0x292518['p'],_0x292518['q']):_0x214a20==='ac'?this['onAuthRevoked_'](_0x292518['s'],_0x292518['d']):_0x214a20==='apc'?this['onAppCheckRevoked_'](_0x292518['s'],_0x292518['d']):_0x214a20==='sd'?this['onSecurityDebugPacket_'](_0x292518):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x214a20)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1c8c52,_0x13d2e3){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1c8c52),this['lastSessionId']=_0x13d2e3,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x27993a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x27993a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x57b8f4){_0x57b8f4&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x57b8f4;}['onOnline_'](_0x462701){_0x462701?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4c9399=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xb745d6=Math['max'](0x0,this['reconnectDelay_']-_0x4c9399);_0xb745d6=Math['random']()*_0xb745d6,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xb745d6+'ms'),this['scheduleConnect_'](_0xb745d6),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x357e2d=this['onDataMessage_']['bind'](this),_0xb5c5b4=this['onReady_']['bind'](this),_0x474abf=this['onRealtimeDisconnect_']['bind'](this),_0x3a8d2d=this['id']+':'+se['nextConnectionId_']++,_0x185993=this['lastSessionId'];let _0x3e2087=!0x1,_0xab5cd6=null;const _0x84300a=function(){_0xab5cd6?_0xab5cd6['close']():(_0x3e2087=!0x0,_0x474abf());},_0x465919=function(_0xf0dc4c){f(_0xab5cd6,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xab5cd6['sendRequest'](_0xf0dc4c);};this['realtime_']={'close':_0x84300a,'sendRequest':_0x465919};const _0x2bfcb2=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3d2ddb,_0xf44c9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2bfcb2),this['appCheckTokenProvider_']['getToken'](_0x2bfcb2)]);_0x3e2087?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3d2ddb&&_0x3d2ddb['accessToken'],this['appCheckToken_']=_0xf44c9&&_0xf44c9['token'],_0xab5cd6=new Sh(_0x3a8d2d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x357e2d,_0xb5c5b4,_0x474abf,_0x3d1269=>{U(_0x3d1269+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x185993));}catch(_0x4edabf){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4edabf),_0x3e2087||(this['repoInfo_']['nodeAdmin']&&U(_0x4edabf),_0x84300a());}}}['interrupt'](_0x463a74){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x463a74),this['interruptReasons_'][_0x463a74]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3c3adf){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3c3adf),delete this['interruptReasons_'][_0x3c3adf],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x54adf9){const _0x1a48b6=_0x54adf9-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1a48b6});}['cancelSentTransactions_'](){for(let _0x33e864=0x0;_0x33e864<this['outstandingPuts_']['length'];_0x33e864++){const _0x308ce6=this['outstandingPuts_'][_0x33e864];_0x308ce6&&'h'in _0x308ce6['request']&&_0x308ce6['queued']&&(_0x308ce6['onComplete']&&_0x308ce6['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x33e864],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x44d18b,_0x35b52a){let _0x42e4f4;_0x35b52a?_0x42e4f4=_0x35b52a['map'](_0x1f3316=>$i(_0x1f3316))['join']('$'):_0x42e4f4='default';const _0x5cd15a=this['removeListen_'](_0x44d18b,_0x42e4f4);_0x5cd15a&&_0x5cd15a['onComplete']&&_0x5cd15a['onComplete']('permission_denied');}['removeListen_'](_0x1b92aa,_0x23d1f6){const _0x4d7c54=new C(_0x1b92aa)['toString']();let _0x18a9f1;if(this['listens']['has'](_0x4d7c54)){const _0x3545b8=this['listens']['get'](_0x4d7c54);_0x18a9f1=_0x3545b8['get'](_0x23d1f6),_0x3545b8['delete'](_0x23d1f6),_0x3545b8['size']===0x0&&this['listens']['delete'](_0x4d7c54);}else _0x18a9f1=void 0x0;return _0x18a9f1;}['onAuthRevoked_'](_0x467208,_0x583835){L('Auth\x20token\x20revoked:\x20'+_0x467208+'/'+_0x583835),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x467208==='invalid_token'||_0x467208==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2980a4,_0x4f4cb3){L('App\x20check\x20token\x20revoked:\x20'+_0x2980a4+'/'+_0x4f4cb3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2980a4==='invalid_token'||_0x2980a4==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3f437e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3f437e):'msg'in _0x3f437e&&console['log']('FIREBASE:\x20'+_0x3f437e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x48c38a of this['listens']['values']())for(const _0xe8a3f7 of _0x48c38a['values']())this['sendListen_'](_0xe8a3f7);for(let _0x3097ad=0x0;_0x3097ad<this['outstandingPuts_']['length'];_0x3097ad++)this['outstandingPuts_'][_0x3097ad]&&this['sendPut_'](_0x3097ad);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2ae07d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2ae07d['action'],_0x2ae07d['pathString'],_0x2ae07d['data'],_0x2ae07d['onComplete']);}for(let _0x3e3e8a=0x0;_0x3e3e8a<this['outstandingGets_']['length'];_0x3e3e8a++)this['outstandingGets_'][_0x3e3e8a]&&this['sendGet_'](_0x3e3e8a);}['sendConnectStats_'](){const _0x565166={};let _0x40deac='js';_0x565166['sdk.'+_0x40deac+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x565166['framework.cordova']=0x1:Kr()&&(_0x565166['framework.reactnative']=0x1),this['reportStats'](_0x565166);}['shouldReconnect_'](){const _0x4240ed=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x4240ed;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x57f051,_0x488a8a){this['name']=_0x57f051,this['node']=_0x488a8a;}static['Wrap'](_0x3ecc50,_0x3d7dfc){return new E(_0x3ecc50,_0x3d7dfc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x29cccc,_0x556ba7){const _0x383e9e=new E(We,_0x29cccc),_0x311505=new E(We,_0x556ba7);return this['compare'](_0x383e9e,_0x311505)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x248523){sn=_0x248523;}['compare'](_0x33fe23,_0x4a87d6){return qe(_0x33fe23['name'],_0x4a87d6['name']);}['isDefinedOn'](_0x3e7e2f){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x38331c,_0x2f03f2){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x131825,_0x5b1e8c){return f(typeof _0x131825=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x131825,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x263888,_0x127eba,_0x24f96c,_0x8116da,_0x87f403=null){this['isReverse_']=_0x8116da,this['resultGenerator_']=_0x87f403,this['nodeStack_']=[];let _0x5a3ac7=0x1;for(;!_0x263888['isEmpty']();)if(_0x263888=_0x263888,_0x5a3ac7=_0x127eba?_0x24f96c(_0x263888['key'],_0x127eba):0x1,_0x8116da&&(_0x5a3ac7*=-0x1),_0x5a3ac7<0x0)this['isReverse_']?_0x263888=_0x263888['left']:_0x263888=_0x263888['right'];else{if(_0x5a3ac7===0x0){this['nodeStack_']['push'](_0x263888);break;}else this['nodeStack_']['push'](_0x263888),this['isReverse_']?_0x263888=_0x263888['right']:_0x263888=_0x263888['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5c5e8a=this['nodeStack_']['pop'](),_0x4d3c0a;if(this['resultGenerator_']?_0x4d3c0a=this['resultGenerator_'](_0x5c5e8a['key'],_0x5c5e8a['value']):_0x4d3c0a={'key':_0x5c5e8a['key'],'value':_0x5c5e8a['value']},this['isReverse_']){for(_0x5c5e8a=_0x5c5e8a['left'];!_0x5c5e8a['isEmpty']();)this['nodeStack_']['push'](_0x5c5e8a),_0x5c5e8a=_0x5c5e8a['right'];}else{for(_0x5c5e8a=_0x5c5e8a['right'];!_0x5c5e8a['isEmpty']();)this['nodeStack_']['push'](_0x5c5e8a),_0x5c5e8a=_0x5c5e8a['left'];}return _0x4d3c0a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x445864=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x445864['key'],_0x445864['value']):{'key':_0x445864['key'],'value':_0x445864['value']};}}class M{constructor(_0x4b3080,_0x53b473,_0x22e691,_0x57e658,_0x2ec6f3){this['key']=_0x4b3080,this['value']=_0x53b473,this['color']=_0x22e691??M['RED'],this['left']=_0x57e658??B['EMPTY_NODE'],this['right']=_0x2ec6f3??B['EMPTY_NODE'];}['copy'](_0xa318a2,_0x7113fc,_0x612886,_0x4dbf05,_0x1d2426){return new M(_0xa318a2??this['key'],_0x7113fc??this['value'],_0x612886??this['color'],_0x4dbf05??this['left'],_0x1d2426??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x599f56){return this['left']['inorderTraversal'](_0x599f56)||!!_0x599f56(this['key'],this['value'])||this['right']['inorderTraversal'](_0x599f56);}['reverseTraversal'](_0x485dbe){return this['right']['reverseTraversal'](_0x485dbe)||_0x485dbe(this['key'],this['value'])||this['left']['reverseTraversal'](_0x485dbe);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2905d3,_0x71e957,_0x12608d){let _0x12bf1c=this;const _0x24ed12=_0x12608d(_0x2905d3,_0x12bf1c['key']);return _0x24ed12<0x0?_0x12bf1c=_0x12bf1c['copy'](null,null,null,_0x12bf1c['left']['insert'](_0x2905d3,_0x71e957,_0x12608d),null):_0x24ed12===0x0?_0x12bf1c=_0x12bf1c['copy'](null,_0x71e957,null,null,null):_0x12bf1c=_0x12bf1c['copy'](null,null,null,null,_0x12bf1c['right']['insert'](_0x2905d3,_0x71e957,_0x12608d)),_0x12bf1c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2d7a96=this;return!_0x2d7a96['left']['isRed_']()&&!_0x2d7a96['left']['left']['isRed_']()&&(_0x2d7a96=_0x2d7a96['moveRedLeft_']()),_0x2d7a96=_0x2d7a96['copy'](null,null,null,_0x2d7a96['left']['removeMin_'](),null),_0x2d7a96['fixUp_']();}['remove'](_0x126dd9,_0x33a543){let _0x470bef,_0x44313a;if(_0x470bef=this,_0x33a543(_0x126dd9,_0x470bef['key'])<0x0)!_0x470bef['left']['isEmpty']()&&!_0x470bef['left']['isRed_']()&&!_0x470bef['left']['left']['isRed_']()&&(_0x470bef=_0x470bef['moveRedLeft_']()),_0x470bef=_0x470bef['copy'](null,null,null,_0x470bef['left']['remove'](_0x126dd9,_0x33a543),null);else{if(_0x470bef['left']['isRed_']()&&(_0x470bef=_0x470bef['rotateRight_']()),!_0x470bef['right']['isEmpty']()&&!_0x470bef['right']['isRed_']()&&!_0x470bef['right']['left']['isRed_']()&&(_0x470bef=_0x470bef['moveRedRight_']()),_0x33a543(_0x126dd9,_0x470bef['key'])===0x0){if(_0x470bef['right']['isEmpty']())return B['EMPTY_NODE'];_0x44313a=_0x470bef['right']['min_'](),_0x470bef=_0x470bef['copy'](_0x44313a['key'],_0x44313a['value'],null,null,_0x470bef['right']['removeMin_']());}_0x470bef=_0x470bef['copy'](null,null,null,null,_0x470bef['right']['remove'](_0x126dd9,_0x33a543));}return _0x470bef['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3ff4b1=this;return _0x3ff4b1['right']['isRed_']()&&!_0x3ff4b1['left']['isRed_']()&&(_0x3ff4b1=_0x3ff4b1['rotateLeft_']()),_0x3ff4b1['left']['isRed_']()&&_0x3ff4b1['left']['left']['isRed_']()&&(_0x3ff4b1=_0x3ff4b1['rotateRight_']()),_0x3ff4b1['left']['isRed_']()&&_0x3ff4b1['right']['isRed_']()&&(_0x3ff4b1=_0x3ff4b1['colorFlip_']()),_0x3ff4b1;}['moveRedLeft_'](){let _0x4c8f2b=this['colorFlip_']();return _0x4c8f2b['right']['left']['isRed_']()&&(_0x4c8f2b=_0x4c8f2b['copy'](null,null,null,null,_0x4c8f2b['right']['rotateRight_']()),_0x4c8f2b=_0x4c8f2b['rotateLeft_'](),_0x4c8f2b=_0x4c8f2b['colorFlip_']()),_0x4c8f2b;}['moveRedRight_'](){let _0x5d1c4c=this['colorFlip_']();return _0x5d1c4c['left']['left']['isRed_']()&&(_0x5d1c4c=_0x5d1c4c['rotateRight_'](),_0x5d1c4c=_0x5d1c4c['colorFlip_']()),_0x5d1c4c;}['rotateLeft_'](){const _0x1281a3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1281a3,null);}['rotateRight_'](){const _0x3f4382=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3f4382);}['colorFlip_'](){const _0x19ad6d=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x18b3d8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x19ad6d,_0x18b3d8);}['checkMaxDepth_'](){const _0x4f5670=this['check_']();return Math['pow'](0x2,_0x4f5670)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x408425=this['left']['check_']();if(_0x408425!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x408425+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x56302a,_0xa3a6b4,_0x5da7b2,_0x4de938,_0x3da91e){return this;}['insert'](_0x3eb303,_0x3ee319,_0x80d332){return new M(_0x3eb303,_0x3ee319,null);}['remove'](_0x1285cd,_0x5e825a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x43a439){return!0x1;}['reverseTraversal'](_0x15b08f){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x143bc5,_0x41ddbe=B['EMPTY_NODE']){this['comparator_']=_0x143bc5,this['root_']=_0x41ddbe;}['insert'](_0x47bd34,_0x457f73){return new B(this['comparator_'],this['root_']['insert'](_0x47bd34,_0x457f73,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x7eaf76){return new B(this['comparator_'],this['root_']['remove'](_0x7eaf76,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x39d984){let _0x562081,_0x5144bb=this['root_'];for(;!_0x5144bb['isEmpty']();){if(_0x562081=this['comparator_'](_0x39d984,_0x5144bb['key']),_0x562081===0x0)return _0x5144bb['value'];_0x562081<0x0?_0x5144bb=_0x5144bb['left']:_0x562081>0x0&&(_0x5144bb=_0x5144bb['right']);}return null;}['getPredecessorKey'](_0x592976){let _0x592f67,_0x2fa162=this['root_'],_0x20cc9c=null;for(;!_0x2fa162['isEmpty']();)if(_0x592f67=this['comparator_'](_0x592976,_0x2fa162['key']),_0x592f67===0x0){if(_0x2fa162['left']['isEmpty']())return _0x20cc9c?_0x20cc9c['key']:null;for(_0x2fa162=_0x2fa162['left'];!_0x2fa162['right']['isEmpty']();)_0x2fa162=_0x2fa162['right'];return _0x2fa162['key'];}else _0x592f67<0x0?_0x2fa162=_0x2fa162['left']:_0x592f67>0x0&&(_0x20cc9c=_0x2fa162,_0x2fa162=_0x2fa162['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x8c42b9){return this['root_']['inorderTraversal'](_0x8c42b9);}['reverseTraversal'](_0x142c6b){return this['root_']['reverseTraversal'](_0x142c6b);}['getIterator'](_0x289416){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x289416);}['getIteratorFrom'](_0x86c9a4,_0xc3e2c3){return new rn(this['root_'],_0x86c9a4,this['comparator_'],!0x1,_0xc3e2c3);}['getReverseIteratorFrom'](_0x1ffa63,_0x5b8588){return new rn(this['root_'],_0x1ffa63,this['comparator_'],!0x0,_0x5b8588);}['getReverseIterator'](_0x5846b9){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5846b9);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2ece8a,_0x591c0f){return qe(_0x2ece8a['name'],_0x591c0f['name']);}function Qi(_0x586bd5,_0x34be6a){return qe(_0x586bd5,_0x34be6a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4d24f5){Ci=_0x4d24f5;}const Po=function(_0x532fe1){return typeof _0x532fe1=='number'?'number:'+ao(_0x532fe1):'string:'+_0x532fe1;},No=function(_0x24766b){if(_0x24766b['isLeafNode']()){const _0x1e0076=_0x24766b['val']();f(typeof _0x1e0076=='string'||typeof _0x1e0076=='number'||typeof _0x1e0076=='object'&&Q(_0x1e0076,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x24766b===Ci||_0x24766b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x24766b===Ci||_0x24766b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x36c6ef){nr=_0x36c6ef;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x31f8f9,_0x394a9d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x31f8f9,this['priorityNode_']=_0x394a9d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4ab211){return new D(this['value_'],_0x4ab211);}['getImmediateChild'](_0x36c12e){return _0x36c12e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4f6095){return v(_0x4f6095)?this:y(_0x4f6095)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x38229e,_0x17b2c4){return null;}['updateImmediateChild'](_0x1ada7d,_0x144b1d){return _0x1ada7d==='.priority'?this['updatePriority'](_0x144b1d):_0x144b1d['isEmpty']()&&_0x1ada7d!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1ada7d,_0x144b1d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x35a893,_0x3bf4ab){const _0x22a951=y(_0x35a893);return _0x22a951===null?_0x3bf4ab:_0x3bf4ab['isEmpty']()&&_0x22a951!=='.priority'?this:(f(_0x22a951!=='.priority'||Ce(_0x35a893)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x22a951,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x35a893),_0x3bf4ab)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4cc660,_0xd5091f){return!0x1;}['val'](_0xb4ec05){return _0xb4ec05&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x177d63='';this['priorityNode_']['isEmpty']()||(_0x177d63+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x52537d=typeof this['value_'];_0x177d63+=_0x52537d+':',_0x52537d==='number'?_0x177d63+=ao(this['value_']):_0x177d63+=this['value_'],this['lazyHash_']=ro(_0x177d63);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xc83680){return _0xc83680===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xc83680 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xc83680['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xc83680));}['compareToLeafNode_'](_0x39dd79){const _0xa91a97=typeof _0x39dd79['value_'],_0x59e7ab=typeof this['value_'],_0x5884db=D['VALUE_TYPE_ORDER']['indexOf'](_0xa91a97),_0x35e694=D['VALUE_TYPE_ORDER']['indexOf'](_0x59e7ab);return f(_0x5884db>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xa91a97),f(_0x35e694>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x59e7ab),_0x5884db===_0x35e694?_0x59e7ab==='object'?0x0:this['value_']<_0x39dd79['value_']?-0x1:this['value_']===_0x39dd79['value_']?0x0:0x1:_0x35e694-_0x5884db;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x559227){if(_0x559227===this)return!0x0;if(_0x559227['isLeafNode']()){const _0x32825c=_0x559227;return this['value_']===_0x32825c['value_']&&this['priorityNode_']['equals'](_0x32825c['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3de701){Oo=_0x3de701;}function Wh(_0x335a8f){Do=_0x335a8f;}class Bh extends Fn{['compare'](_0x2c7c26,_0x137605){const _0x2251a3=_0x2c7c26['node']['getPriority'](),_0x52bd20=_0x137605['node']['getPriority'](),_0x18c35a=_0x2251a3['compareTo'](_0x52bd20);return _0x18c35a===0x0?qe(_0x2c7c26['name'],_0x137605['name']):_0x18c35a;}['isDefinedOn'](_0x3d268f){return!_0x3d268f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2fcb7c,_0x309d1c){return!_0x2fcb7c['getPriority']()['equals'](_0x309d1c['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x67e73b,_0x2eb81c){const _0x49c410=Oo(_0x67e73b);return new E(_0x2eb81c,new D('[PRIORITY-POST]',_0x49c410));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x59e478){const _0xa56b83=_0x3bcd86=>parseInt(Math['log'](_0x3bcd86)/Vh,0xa),_0x458110=_0x564157=>parseInt(Array(_0x564157+0x1)['join']('1'),0x2);this['count']=_0xa56b83(_0x59e478+0x1),this['current_']=this['count']-0x1;const _0x5c11a2=_0x458110(this['count']);this['bits_']=_0x59e478+0x1&_0x5c11a2;}['nextBitIsOne'](){const _0x41972c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x41972c;}}const yn=function(_0x24bb16,_0x596d29,_0xe8600f,_0x40e193){_0x24bb16['sort'](_0x596d29);const _0x499e65=function(_0x1e7938,_0x5c3adf){const _0x485904=_0x5c3adf-_0x1e7938;let _0x1e8ee3,_0x384be3;if(_0x485904===0x0)return null;if(_0x485904===0x1)return _0x1e8ee3=_0x24bb16[_0x1e7938],_0x384be3=_0xe8600f?_0xe8600f(_0x1e8ee3):_0x1e8ee3,new M(_0x384be3,_0x1e8ee3['node'],M['BLACK'],null,null);{const _0x8dec8a=parseInt(_0x485904/0x2,0xa)+_0x1e7938,_0x143421=_0x499e65(_0x1e7938,_0x8dec8a),_0x1523f9=_0x499e65(_0x8dec8a+0x1,_0x5c3adf);return _0x1e8ee3=_0x24bb16[_0x8dec8a],_0x384be3=_0xe8600f?_0xe8600f(_0x1e8ee3):_0x1e8ee3,new M(_0x384be3,_0x1e8ee3['node'],M['BLACK'],_0x143421,_0x1523f9);}},_0x55d6d0=function(_0x179377){let _0x45b366=null,_0x4bb74b=null,_0x61122e=_0x24bb16['length'];const _0x5756e9=function(_0x50f88d,_0x2e48d5){const _0x36f711=_0x61122e-_0x50f88d,_0x4a5b15=_0x61122e;_0x61122e-=_0x50f88d;const _0x28ffe0=_0x499e65(_0x36f711+0x1,_0x4a5b15),_0x302dff=_0x24bb16[_0x36f711],_0x3ddb28=_0xe8600f?_0xe8600f(_0x302dff):_0x302dff;_0x47ae77(new M(_0x3ddb28,_0x302dff['node'],_0x2e48d5,null,_0x28ffe0));},_0x47ae77=function(_0xa8a086){_0x45b366?(_0x45b366['left']=_0xa8a086,_0x45b366=_0xa8a086):(_0x4bb74b=_0xa8a086,_0x45b366=_0xa8a086);};for(let _0x485908=0x0;_0x485908<_0x179377['count'];++_0x485908){const _0x117b33=_0x179377['nextBitIsOne'](),_0x5797f7=Math['pow'](0x2,_0x179377['count']-(_0x485908+0x1));_0x117b33?_0x5756e9(_0x5797f7,M['BLACK']):(_0x5756e9(_0x5797f7,M['BLACK']),_0x5756e9(_0x5797f7,M['RED']));}return _0x4bb74b;},_0xbbe448=new Hh(_0x24bb16['length']),_0x8de214=_0x55d6d0(_0xbbe448);return new B(_0x40e193||_0x596d29,_0x8de214);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x546357,_0x1edb6f){this['indexes_']=_0x546357,this['indexSet_']=_0x1edb6f;}['get'](_0x834dea){const _0x3fa1f6=Le(this['indexes_'],_0x834dea);if(!_0x3fa1f6)throw new Error('No\x20index\x20defined\x20for\x20'+_0x834dea);return _0x3fa1f6 instanceof B?_0x3fa1f6:null;}['hasIndex'](_0x4459c4){return Q(this['indexSet_'],_0x4459c4['toString']());}['addIndex'](_0xd8bef5,_0x1963c3){f(_0xd8bef5!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x31fd94=[];let _0x47983c=!0x1;const _0x43b39c=_0x1963c3['getIterator'](E['Wrap']);let _0x29ece3=_0x43b39c['getNext']();for(;_0x29ece3;)_0x47983c=_0x47983c||_0xd8bef5['isDefinedOn'](_0x29ece3['node']),_0x31fd94['push'](_0x29ece3),_0x29ece3=_0x43b39c['getNext']();let _0x2e3d1a;_0x47983c?_0x2e3d1a=yn(_0x31fd94,_0xd8bef5['getCompare']()):_0x2e3d1a=Qe;const _0x1fdf98=_0xd8bef5['toString'](),_0x5c8f7f={...this['indexSet_']};_0x5c8f7f[_0x1fdf98]=_0xd8bef5;const _0x12c020={...this['indexes_']};return _0x12c020[_0x1fdf98]=_0x2e3d1a,new te(_0x12c020,_0x5c8f7f);}['addToIndexes'](_0x1af3fa,_0x45c020){const _0xc88ea4=_n(this['indexes_'],(_0x182af5,_0x229dd9)=>{const _0x52cddd=Le(this['indexSet_'],_0x229dd9);if(f(_0x52cddd,'Missing\x20index\x20implementation\x20for\x20'+_0x229dd9),_0x182af5===Qe){if(_0x52cddd['isDefinedOn'](_0x1af3fa['node'])){const _0x5da257=[],_0x5339ab=_0x45c020['getIterator'](E['Wrap']);let _0x282752=_0x5339ab['getNext']();for(;_0x282752;)_0x282752['name']!==_0x1af3fa['name']&&_0x5da257['push'](_0x282752),_0x282752=_0x5339ab['getNext']();return _0x5da257['push'](_0x1af3fa),yn(_0x5da257,_0x52cddd['getCompare']());}else return Qe;}else{const _0x402747=_0x45c020['get'](_0x1af3fa['name']);let _0x220099=_0x182af5;return _0x402747&&(_0x220099=_0x220099['remove'](new E(_0x1af3fa['name'],_0x402747))),_0x220099['insert'](_0x1af3fa,_0x1af3fa['node']);}});return new te(_0xc88ea4,this['indexSet_']);}['removeFromIndexes'](_0x1abaa1,_0x2dce76){const _0x6f36c5=_n(this['indexes_'],_0xd6f8d5=>{if(_0xd6f8d5===Qe)return _0xd6f8d5;{const _0x261735=_0x2dce76['get'](_0x1abaa1['name']);return _0x261735?_0xd6f8d5['remove'](new E(_0x1abaa1['name'],_0x261735)):_0xd6f8d5;}});return new te(_0x6f36c5,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x397a34,_0xcc4baa,_0x4e15c0){this['children_']=_0x397a34,this['priorityNode_']=_0xcc4baa,this['indexMap_']=_0x4e15c0,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1b4ba4){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1b4ba4,this['indexMap_']);}['getImmediateChild'](_0x598065){if(_0x598065==='.priority')return this['getPriority']();{const _0x8a74b9=this['children_']['get'](_0x598065);return _0x8a74b9===null?It:_0x8a74b9;}}['getChild'](_0x411a91){const _0x49d57d=y(_0x411a91);return _0x49d57d===null?this:this['getImmediateChild'](_0x49d57d)['getChild'](S(_0x411a91));}['hasChild'](_0x42c69d){return this['children_']['get'](_0x42c69d)!==null;}['updateImmediateChild'](_0x3251f7,_0x32b692){if(f(_0x32b692,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3251f7==='.priority')return this['updatePriority'](_0x32b692);{const _0x5f03be=new E(_0x3251f7,_0x32b692);let _0x5ec6ae,_0x48698d;_0x32b692['isEmpty']()?(_0x5ec6ae=this['children_']['remove'](_0x3251f7),_0x48698d=this['indexMap_']['removeFromIndexes'](_0x5f03be,this['children_'])):(_0x5ec6ae=this['children_']['insert'](_0x3251f7,_0x32b692),_0x48698d=this['indexMap_']['addToIndexes'](_0x5f03be,this['children_']));const _0x4c8e7c=_0x5ec6ae['isEmpty']()?It:this['priorityNode_'];return new g(_0x5ec6ae,_0x4c8e7c,_0x48698d);}}['updateChild'](_0x32a5a5,_0x5b37e7){const _0x1d95f2=y(_0x32a5a5);if(_0x1d95f2===null)return _0x5b37e7;{f(y(_0x32a5a5)!=='.priority'||Ce(_0x32a5a5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x255e0a=this['getImmediateChild'](_0x1d95f2)['updateChild'](S(_0x32a5a5),_0x5b37e7);return this['updateImmediateChild'](_0x1d95f2,_0x255e0a);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xf2dedd){if(this['isEmpty']())return null;const _0x2159b5={};let _0x36c883=0x0,_0x462480=0x0,_0x16ae62=!0x0;if(this['forEachChild'](R,(_0x4f91da,_0x534e63)=>{_0x2159b5[_0x4f91da]=_0x534e63['val'](_0xf2dedd),_0x36c883++,_0x16ae62&&g['INTEGER_REGEXP_']['test'](_0x4f91da)?_0x462480=Math['max'](_0x462480,Number(_0x4f91da)):_0x16ae62=!0x1;}),!_0xf2dedd&&_0x16ae62&&_0x462480<0x2*_0x36c883){const _0x4374c2=[];for(const _0x2c3c79 in _0x2159b5)_0x4374c2[_0x2c3c79]=_0x2159b5[_0x2c3c79];return _0x4374c2;}else return _0xf2dedd&&!this['getPriority']()['isEmpty']()&&(_0x2159b5['.priority']=this['getPriority']()['val']()),_0x2159b5;}['hash'](){if(this['lazyHash_']===null){let _0x298cb9='';this['getPriority']()['isEmpty']()||(_0x298cb9+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1a6d15,_0x2727a8)=>{const _0x2f43aa=_0x2727a8['hash']();_0x2f43aa!==''&&(_0x298cb9+=':'+_0x1a6d15+':'+_0x2f43aa);}),this['lazyHash_']=_0x298cb9===''?'':ro(_0x298cb9);}return this['lazyHash_'];}['getPredecessorChildName'](_0x70b72e,_0x482813,_0x3604d4){const _0x5391ee=this['resolveIndex_'](_0x3604d4);if(_0x5391ee){const _0x55eafc=_0x5391ee['getPredecessorKey'](new E(_0x70b72e,_0x482813));return _0x55eafc?_0x55eafc['name']:null;}else return this['children_']['getPredecessorKey'](_0x70b72e);}['getFirstChildName'](_0x54119b){const _0x248df4=this['resolveIndex_'](_0x54119b);if(_0x248df4){const _0x564be4=_0x248df4['minKey']();return _0x564be4&&_0x564be4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1471d6){const _0x370b4c=this['getFirstChildName'](_0x1471d6);return _0x370b4c?new E(_0x370b4c,this['children_']['get'](_0x370b4c)):null;}['getLastChildName'](_0x8b153c){const _0x1d85b2=this['resolveIndex_'](_0x8b153c);if(_0x1d85b2){const _0x1b4ded=_0x1d85b2['maxKey']();return _0x1b4ded&&_0x1b4ded['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x30668d){const _0x2a89eb=this['getLastChildName'](_0x30668d);return _0x2a89eb?new E(_0x2a89eb,this['children_']['get'](_0x2a89eb)):null;}['forEachChild'](_0x1b9989,_0x3c2ddd){const _0x37a4e0=this['resolveIndex_'](_0x1b9989);return _0x37a4e0?_0x37a4e0['inorderTraversal'](_0x3e7f92=>_0x3c2ddd(_0x3e7f92['name'],_0x3e7f92['node'])):this['children_']['inorderTraversal'](_0x3c2ddd);}['getIterator'](_0x420dac){return this['getIteratorFrom'](_0x420dac['minPost'](),_0x420dac);}['getIteratorFrom'](_0x1ed7f7,_0x19ea86){const _0x497e55=this['resolveIndex_'](_0x19ea86);if(_0x497e55)return _0x497e55['getIteratorFrom'](_0x1ed7f7,_0x49c308=>_0x49c308);{const _0x4e4430=this['children_']['getIteratorFrom'](_0x1ed7f7['name'],E['Wrap']);let _0xc24703=_0x4e4430['peek']();for(;_0xc24703!=null&&_0x19ea86['compare'](_0xc24703,_0x1ed7f7)<0x0;)_0x4e4430['getNext'](),_0xc24703=_0x4e4430['peek']();return _0x4e4430;}}['getReverseIterator'](_0x524c6c){return this['getReverseIteratorFrom'](_0x524c6c['maxPost'](),_0x524c6c);}['getReverseIteratorFrom'](_0x2e49fb,_0x3acf01){const _0x13167c=this['resolveIndex_'](_0x3acf01);if(_0x13167c)return _0x13167c['getReverseIteratorFrom'](_0x2e49fb,_0x29db0f=>_0x29db0f);{const _0xa84c0f=this['children_']['getReverseIteratorFrom'](_0x2e49fb['name'],E['Wrap']);let _0x45641f=_0xa84c0f['peek']();for(;_0x45641f!=null&&_0x3acf01['compare'](_0x45641f,_0x2e49fb)>0x0;)_0xa84c0f['getNext'](),_0x45641f=_0xa84c0f['peek']();return _0xa84c0f;}}['compareTo'](_0x50c8f2){return this['isEmpty']()?_0x50c8f2['isEmpty']()?0x0:-0x1:_0x50c8f2['isLeafNode']()||_0x50c8f2['isEmpty']()?0x1:_0x50c8f2===Kt?-0x1:0x0;}['withIndex'](_0x34921f){if(_0x34921f===ve||this['indexMap_']['hasIndex'](_0x34921f))return this;{const _0x53d385=this['indexMap_']['addIndex'](_0x34921f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x53d385);}}['isIndexed'](_0x51da4b){return _0x51da4b===ve||this['indexMap_']['hasIndex'](_0x51da4b);}['equals'](_0x42cdda){if(_0x42cdda===this)return!0x0;if(_0x42cdda['isLeafNode']())return!0x1;{const _0x4d4006=_0x42cdda;if(this['getPriority']()['equals'](_0x4d4006['getPriority']())){if(this['children_']['count']()===_0x4d4006['children_']['count']()){const _0xaf9560=this['getIterator'](R),_0x17ebd8=_0x4d4006['getIterator'](R);let _0x507861=_0xaf9560['getNext'](),_0x17d69f=_0x17ebd8['getNext']();for(;_0x507861&&_0x17d69f;){if(_0x507861['name']!==_0x17d69f['name']||!_0x507861['node']['equals'](_0x17d69f['node']))return!0x1;_0x507861=_0xaf9560['getNext'](),_0x17d69f=_0x17ebd8['getNext']();}return _0x507861===null&&_0x17d69f===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x18f47c){return _0x18f47c===ve?null:this['indexMap_']['get'](_0x18f47c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x5123fe){return _0x5123fe===this?0x0:0x1;}['equals'](_0x50fce5){return _0x50fce5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x105b16){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x5b18ba,_0xdbefb2=null){if(_0x5b18ba===null)return g['EMPTY_NODE'];if(typeof _0x5b18ba=='object'&&'.priority'in _0x5b18ba&&(_0xdbefb2=_0x5b18ba['.priority']),f(_0xdbefb2===null||typeof _0xdbefb2=='string'||typeof _0xdbefb2=='number'||typeof _0xdbefb2=='object'&&'.sv'in _0xdbefb2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xdbefb2),typeof _0x5b18ba=='object'&&'.value'in _0x5b18ba&&_0x5b18ba['.value']!==null&&(_0x5b18ba=_0x5b18ba['.value']),typeof _0x5b18ba!='object'||'.sv'in _0x5b18ba){const _0x1f0f4b=_0x5b18ba;return new D(_0x1f0f4b,A(_0xdbefb2));}if(!(_0x5b18ba instanceof Array)&&Gh){const _0x4deba4=[];let _0x7b71fc=!0x1;if(x(_0x5b18ba,(_0x37f629,_0x11d61a)=>{if(_0x37f629['substring'](0x0,0x1)!=='.'){const _0x2db0bd=A(_0x11d61a);_0x2db0bd['isEmpty']()||(_0x7b71fc=_0x7b71fc||!_0x2db0bd['getPriority']()['isEmpty'](),_0x4deba4['push'](new E(_0x37f629,_0x2db0bd)));}}),_0x4deba4['length']===0x0)return g['EMPTY_NODE'];const _0x425f51=yn(_0x4deba4,xh,_0x52b869=>_0x52b869['name'],Qi);if(_0x7b71fc){const _0x3d7f1c=yn(_0x4deba4,R['getCompare']());return new g(_0x425f51,A(_0xdbefb2),new te({'.priority':_0x3d7f1c},{'.priority':R}));}else return new g(_0x425f51,A(_0xdbefb2),te['Default']);}else{let _0x176b2f=g['EMPTY_NODE'];return x(_0x5b18ba,(_0xf5bdf4,_0x51e617)=>{if(Q(_0x5b18ba,_0xf5bdf4)&&_0xf5bdf4['substring'](0x0,0x1)!=='.'){const _0x87b9eb=A(_0x51e617);(_0x87b9eb['isLeafNode']()||!_0x87b9eb['isEmpty']())&&(_0x176b2f=_0x176b2f['updateImmediateChild'](_0xf5bdf4,_0x87b9eb));}}),_0x176b2f['updatePriority'](A(_0xdbefb2));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x69cdc0){super(),this['indexPath_']=_0x69cdc0,f(!v(_0x69cdc0)&&y(_0x69cdc0)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xc23779){return _0xc23779['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3db38e){return!_0x3db38e['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x294f18,_0x129db4){const _0x4212e3=this['extractChild'](_0x294f18['node']),_0x45c598=this['extractChild'](_0x129db4['node']),_0x3602b7=_0x4212e3['compareTo'](_0x45c598);return _0x3602b7===0x0?qe(_0x294f18['name'],_0x129db4['name']):_0x3602b7;}['makePost'](_0x26cbf7,_0x3b23dd){const _0x5f51e9=A(_0x26cbf7),_0x440769=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5f51e9);return new E(_0x3b23dd,_0x440769);}['maxPost'](){const _0x18fdce=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x18fdce);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x31c32e,_0x3dcd09){const _0x353757=_0x31c32e['node']['compareTo'](_0x3dcd09['node']);return _0x353757===0x0?qe(_0x31c32e['name'],_0x3dcd09['name']):_0x353757;}['isDefinedOn'](_0x423de6){return!0x0;}['indexedValueChanged'](_0x153480,_0x53080e){return!_0x153480['equals'](_0x53080e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x34302c,_0x43f852){const _0x26e8c3=A(_0x34302c);return new E(_0x43f852,_0x26e8c3);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x4c8a9d){return{'type':'value','snapshotNode':_0x4c8a9d};}function rt(_0x4faf3a,_0x54db5c){return{'type':'child_added','snapshotNode':_0x54db5c,'childName':_0x4faf3a};}function Lt(_0x13a3d3,_0x1a1831){return{'type':'child_removed','snapshotNode':_0x1a1831,'childName':_0x13a3d3};}function xt(_0x2d7c86,_0x1801ce,_0x4b26ee){return{'type':'child_changed','snapshotNode':_0x1801ce,'childName':_0x2d7c86,'oldSnap':_0x4b26ee};}function zh(_0x1dbfd4,_0x3e432d){return{'type':'child_moved','snapshotNode':_0x3e432d,'childName':_0x1dbfd4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x196bbb){this['index_']=_0x196bbb;}['updateChild'](_0x58ed90,_0x15a3c9,_0x329f1d,_0x273530,_0x41bfb2,_0x546505){f(_0x58ed90['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x48a0d6=_0x58ed90['getImmediateChild'](_0x15a3c9);return _0x48a0d6['getChild'](_0x273530)['equals'](_0x329f1d['getChild'](_0x273530))&&_0x48a0d6['isEmpty']()===_0x329f1d['isEmpty']()||(_0x546505!=null&&(_0x329f1d['isEmpty']()?_0x58ed90['hasChild'](_0x15a3c9)?_0x546505['trackChildChange'](Lt(_0x15a3c9,_0x48a0d6)):f(_0x58ed90['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x48a0d6['isEmpty']()?_0x546505['trackChildChange'](rt(_0x15a3c9,_0x329f1d)):_0x546505['trackChildChange'](xt(_0x15a3c9,_0x329f1d,_0x48a0d6))),_0x58ed90['isLeafNode']()&&_0x329f1d['isEmpty']())?_0x58ed90:_0x58ed90['updateImmediateChild'](_0x15a3c9,_0x329f1d)['withIndex'](this['index_']);}['updateFullNode'](_0x4ede25,_0x28d6c0,_0x4b82a5){return _0x4b82a5!=null&&(_0x4ede25['isLeafNode']()||_0x4ede25['forEachChild'](R,(_0x41b74c,_0x17c326)=>{_0x28d6c0['hasChild'](_0x41b74c)||_0x4b82a5['trackChildChange'](Lt(_0x41b74c,_0x17c326));}),_0x28d6c0['isLeafNode']()||_0x28d6c0['forEachChild'](R,(_0x6e184f,_0x13c003)=>{if(_0x4ede25['hasChild'](_0x6e184f)){const _0x1d67e5=_0x4ede25['getImmediateChild'](_0x6e184f);_0x1d67e5['equals'](_0x13c003)||_0x4b82a5['trackChildChange'](xt(_0x6e184f,_0x13c003,_0x1d67e5));}else _0x4b82a5['trackChildChange'](rt(_0x6e184f,_0x13c003));})),_0x28d6c0['withIndex'](this['index_']);}['updatePriority'](_0x343b0e,_0x45462b){return _0x343b0e['isEmpty']()?g['EMPTY_NODE']:_0x343b0e['updatePriority'](_0x45462b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x49820a){this['indexedFilter_']=new Xi(_0x49820a['getIndex']()),this['index_']=_0x49820a['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x49820a),this['endPost_']=Ft['getEndPost_'](_0x49820a),this['startIsInclusive_']=!_0x49820a['startAfterSet_'],this['endIsInclusive_']=!_0x49820a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4d6960){const _0x38ec61=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4d6960)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4d6960)<0x0,_0x2c33d2=this['endIsInclusive_']?this['index_']['compare'](_0x4d6960,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4d6960,this['getEndPost']())<0x0;return _0x38ec61&&_0x2c33d2;}['updateChild'](_0x5cab6f,_0x4f8df6,_0x599f66,_0x3bfe0d,_0x391e5f,_0x138cdb){return this['matches'](new E(_0x4f8df6,_0x599f66))||(_0x599f66=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5cab6f,_0x4f8df6,_0x599f66,_0x3bfe0d,_0x391e5f,_0x138cdb);}['updateFullNode'](_0x24c383,_0xf9d6a4,_0x164382){_0xf9d6a4['isLeafNode']()&&(_0xf9d6a4=g['EMPTY_NODE']);let _0x5ceae5=_0xf9d6a4['withIndex'](this['index_']);_0x5ceae5=_0x5ceae5['updatePriority'](g['EMPTY_NODE']);const _0x42759c=this;return _0xf9d6a4['forEachChild'](R,(_0x2ede13,_0x5784ce)=>{_0x42759c['matches'](new E(_0x2ede13,_0x5784ce))||(_0x5ceae5=_0x5ceae5['updateImmediateChild'](_0x2ede13,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x24c383,_0x5ceae5,_0x164382);}['updatePriority'](_0x5de7f6,_0x46c9c5){return _0x5de7f6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3d080e){if(_0x3d080e['hasStart']()){const _0x23ae6a=_0x3d080e['getIndexStartName']();return _0x3d080e['getIndex']()['makePost'](_0x3d080e['getIndexStartValue'](),_0x23ae6a);}else return _0x3d080e['getIndex']()['minPost']();}static['getEndPost_'](_0xc5884c){if(_0xc5884c['hasEnd']()){const _0x8b9d90=_0xc5884c['getIndexEndName']();return _0xc5884c['getIndex']()['makePost'](_0xc5884c['getIndexEndValue'](),_0x8b9d90);}else return _0xc5884c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0xc991e9){this['withinDirectionalStart']=_0x5fe910=>this['reverse_']?this['withinEndPost'](_0x5fe910):this['withinStartPost'](_0x5fe910),this['withinDirectionalEnd']=_0xc53c27=>this['reverse_']?this['withinStartPost'](_0xc53c27):this['withinEndPost'](_0xc53c27),this['withinStartPost']=_0x5a33dd=>{const _0x16dffd=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5a33dd);return this['startIsInclusive_']?_0x16dffd<=0x0:_0x16dffd<0x0;},this['withinEndPost']=_0x177e83=>{const _0x38078c=this['index_']['compare'](_0x177e83,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x38078c<=0x0:_0x38078c<0x0;},this['rangedFilter_']=new Ft(_0xc991e9),this['index_']=_0xc991e9['getIndex'](),this['limit_']=_0xc991e9['getLimit'](),this['reverse_']=!_0xc991e9['isViewFromLeft'](),this['startIsInclusive_']=!_0xc991e9['startAfterSet_'],this['endIsInclusive_']=!_0xc991e9['endBeforeSet_'];}['updateChild'](_0xb2a2fc,_0x851311,_0x14a730,_0x2eaa04,_0x1ff01e,_0xaa1137){return this['rangedFilter_']['matches'](new E(_0x851311,_0x14a730))||(_0x14a730=g['EMPTY_NODE']),_0xb2a2fc['getImmediateChild'](_0x851311)['equals'](_0x14a730)?_0xb2a2fc:_0xb2a2fc['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xb2a2fc,_0x851311,_0x14a730,_0x2eaa04,_0x1ff01e,_0xaa1137):this['fullLimitUpdateChild_'](_0xb2a2fc,_0x851311,_0x14a730,_0x1ff01e,_0xaa1137);}['updateFullNode'](_0x2ee99e,_0xd958dc,_0x5e5288){let _0x223d99;if(_0xd958dc['isLeafNode']()||_0xd958dc['isEmpty']())_0x223d99=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xd958dc['numChildren']()&&_0xd958dc['isIndexed'](this['index_'])){_0x223d99=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1dd91e;this['reverse_']?_0x1dd91e=_0xd958dc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1dd91e=_0xd958dc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2ac9ea=0x0;for(;_0x1dd91e['hasNext']()&&_0x2ac9ea<this['limit_'];){const _0x23e573=_0x1dd91e['getNext']();if(this['withinDirectionalStart'](_0x23e573)){if(this['withinDirectionalEnd'](_0x23e573))_0x223d99=_0x223d99['updateImmediateChild'](_0x23e573['name'],_0x23e573['node']),_0x2ac9ea++;else break;}else continue;}}else{_0x223d99=_0xd958dc['withIndex'](this['index_']),_0x223d99=_0x223d99['updatePriority'](g['EMPTY_NODE']);let _0x1de33a;this['reverse_']?_0x1de33a=_0x223d99['getReverseIterator'](this['index_']):_0x1de33a=_0x223d99['getIterator'](this['index_']);let _0x500b1e=0x0;for(;_0x1de33a['hasNext']();){const _0x28ab98=_0x1de33a['getNext']();_0x500b1e<this['limit_']&&this['withinDirectionalStart'](_0x28ab98)&&this['withinDirectionalEnd'](_0x28ab98)?_0x500b1e++:_0x223d99=_0x223d99['updateImmediateChild'](_0x28ab98['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2ee99e,_0x223d99,_0x5e5288);}['updatePriority'](_0x28453a,_0x314593){return _0x28453a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xb3d2e9,_0xe73daa,_0x3814ab,_0x181ec4,_0x4af75f){let _0x24eaf7;if(this['reverse_']){const _0x1dd38b=this['index_']['getCompare']();_0x24eaf7=(_0x29ab10,_0x4d2405)=>_0x1dd38b(_0x4d2405,_0x29ab10);}else _0x24eaf7=this['index_']['getCompare']();const _0xd6f51d=_0xb3d2e9;f(_0xd6f51d['numChildren']()===this['limit_'],'');const _0x1f0886=new E(_0xe73daa,_0x3814ab),_0x3a2182=this['reverse_']?_0xd6f51d['getFirstChild'](this['index_']):_0xd6f51d['getLastChild'](this['index_']),_0x2402e7=this['rangedFilter_']['matches'](_0x1f0886);if(_0xd6f51d['hasChild'](_0xe73daa)){const _0x47d49a=_0xd6f51d['getImmediateChild'](_0xe73daa);let _0x1a2261=_0x181ec4['getChildAfterChild'](this['index_'],_0x3a2182,this['reverse_']);for(;_0x1a2261!=null&&(_0x1a2261['name']===_0xe73daa||_0xd6f51d['hasChild'](_0x1a2261['name']));)_0x1a2261=_0x181ec4['getChildAfterChild'](this['index_'],_0x1a2261,this['reverse_']);const _0xa98d54=_0x1a2261==null?0x1:_0x24eaf7(_0x1a2261,_0x1f0886);if(_0x2402e7&&!_0x3814ab['isEmpty']()&&_0xa98d54>=0x0)return _0x4af75f!=null&&_0x4af75f['trackChildChange'](xt(_0xe73daa,_0x3814ab,_0x47d49a)),_0xd6f51d['updateImmediateChild'](_0xe73daa,_0x3814ab);{_0x4af75f!=null&&_0x4af75f['trackChildChange'](Lt(_0xe73daa,_0x47d49a));const _0xad5a27=_0xd6f51d['updateImmediateChild'](_0xe73daa,g['EMPTY_NODE']);return _0x1a2261!=null&&this['rangedFilter_']['matches'](_0x1a2261)?(_0x4af75f!=null&&_0x4af75f['trackChildChange'](rt(_0x1a2261['name'],_0x1a2261['node'])),_0xad5a27['updateImmediateChild'](_0x1a2261['name'],_0x1a2261['node'])):_0xad5a27;}}else return _0x3814ab['isEmpty']()?_0xb3d2e9:_0x2402e7&&_0x24eaf7(_0x3a2182,_0x1f0886)>=0x0?(_0x4af75f!=null&&(_0x4af75f['trackChildChange'](Lt(_0x3a2182['name'],_0x3a2182['node'])),_0x4af75f['trackChildChange'](rt(_0xe73daa,_0x3814ab))),_0xd6f51d['updateImmediateChild'](_0xe73daa,_0x3814ab)['updateImmediateChild'](_0x3a2182['name'],g['EMPTY_NODE'])):_0xb3d2e9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2d8a75=new Zi();return _0x2d8a75['limitSet_']=this['limitSet_'],_0x2d8a75['limit_']=this['limit_'],_0x2d8a75['startSet_']=this['startSet_'],_0x2d8a75['startAfterSet_']=this['startAfterSet_'],_0x2d8a75['indexStartValue_']=this['indexStartValue_'],_0x2d8a75['startNameSet_']=this['startNameSet_'],_0x2d8a75['indexStartName_']=this['indexStartName_'],_0x2d8a75['endSet_']=this['endSet_'],_0x2d8a75['endBeforeSet_']=this['endBeforeSet_'],_0x2d8a75['indexEndValue_']=this['indexEndValue_'],_0x2d8a75['endNameSet_']=this['endNameSet_'],_0x2d8a75['indexEndName_']=this['indexEndName_'],_0x2d8a75['index_']=this['index_'],_0x2d8a75['viewFrom_']=this['viewFrom_'],_0x2d8a75;}}function Kh(_0x22dba9){return _0x22dba9['loadsAllData']()?new Xi(_0x22dba9['getIndex']()):_0x22dba9['hasLimit']()?new jh(_0x22dba9):new Ft(_0x22dba9);}function Yh(_0x2df10e,_0x4babca){const _0x10921b=_0x2df10e['copy']();return _0x10921b['limitSet_']=!0x0,_0x10921b['limit_']=_0x4babca,_0x10921b['viewFrom_']='l',_0x10921b;}function Qh(_0x3732c7,_0x123e0a,_0x54a0a5){const _0x3776ec=_0x3732c7['copy']();return _0x3776ec['startSet_']=!0x0,_0x123e0a===void 0x0&&(_0x123e0a=null),_0x3776ec['indexStartValue_']=_0x123e0a,_0x54a0a5!=null?(_0x3776ec['startNameSet_']=!0x0,_0x3776ec['indexStartName_']=_0x54a0a5):(_0x3776ec['startNameSet_']=!0x1,_0x3776ec['indexStartName_']=''),_0x3776ec;}function Jh(_0x2a2eaf,_0x242d05,_0x49a9d2){const _0x120665=_0x2a2eaf['copy']();return _0x120665['endSet_']=!0x0,_0x242d05===void 0x0&&(_0x242d05=null),_0x120665['indexEndValue_']=_0x242d05,_0x49a9d2!==void 0x0?(_0x120665['endNameSet_']=!0x0,_0x120665['indexEndName_']=_0x49a9d2):(_0x120665['endNameSet_']=!0x1,_0x120665['indexEndName_']=''),_0x120665;}function xo(_0x28c18c,_0x2bde85){const _0x1a86eb=_0x28c18c['copy']();return _0x1a86eb['index_']=_0x2bde85,_0x1a86eb;}function ir(_0x24140a){const _0x4dc212={};if(_0x24140a['isDefault']())return _0x4dc212;let _0x234aa4;if(_0x24140a['index_']===R?_0x234aa4='$priority':_0x24140a['index_']===Mo?_0x234aa4='$value':_0x24140a['index_']===ve?_0x234aa4='$key':(f(_0x24140a['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x234aa4=_0x24140a['index_']['toString']()),_0x4dc212['orderBy']=O(_0x234aa4),_0x24140a['startSet_']){const _0x1a0920=_0x24140a['startAfterSet_']?'startAfter':'startAt';_0x4dc212[_0x1a0920]=O(_0x24140a['indexStartValue_']),_0x24140a['startNameSet_']&&(_0x4dc212[_0x1a0920]+=','+O(_0x24140a['indexStartName_']));}if(_0x24140a['endSet_']){const _0x3e25f7=_0x24140a['endBeforeSet_']?'endBefore':'endAt';_0x4dc212[_0x3e25f7]=O(_0x24140a['indexEndValue_']),_0x24140a['endNameSet_']&&(_0x4dc212[_0x3e25f7]+=','+O(_0x24140a['indexEndName_']));}return _0x24140a['limitSet_']&&(_0x24140a['isViewFromLeft']()?_0x4dc212['limitToFirst']=_0x24140a['limit_']:_0x4dc212['limitToLast']=_0x24140a['limit_']),_0x4dc212;}function sr(_0x3aaa51){const _0x1a82e6={};if(_0x3aaa51['startSet_']&&(_0x1a82e6['sp']=_0x3aaa51['indexStartValue_'],_0x3aaa51['startNameSet_']&&(_0x1a82e6['sn']=_0x3aaa51['indexStartName_']),_0x1a82e6['sin']=!_0x3aaa51['startAfterSet_']),_0x3aaa51['endSet_']&&(_0x1a82e6['ep']=_0x3aaa51['indexEndValue_'],_0x3aaa51['endNameSet_']&&(_0x1a82e6['en']=_0x3aaa51['indexEndName_']),_0x1a82e6['ein']=!_0x3aaa51['endBeforeSet_']),_0x3aaa51['limitSet_']){_0x1a82e6['l']=_0x3aaa51['limit_'];let _0x16caf0=_0x3aaa51['viewFrom_'];_0x16caf0===''&&(_0x3aaa51['isViewFromLeft']()?_0x16caf0='l':_0x16caf0='r'),_0x1a82e6['vf']=_0x16caf0;}return _0x3aaa51['index_']!==R&&(_0x1a82e6['i']=_0x3aaa51['index_']['toString']()),_0x1a82e6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2c8028){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1ed3fc,_0x1204b9){return _0x1204b9!==void 0x0?'tag$'+_0x1204b9:(f(_0x1ed3fc['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1ed3fc['_path']['toString']());}constructor(_0x1c96fc,_0x3a785a,_0xa26b19,_0x582701){super(),this['repoInfo_']=_0x1c96fc,this['onDataUpdate_']=_0x3a785a,this['authTokenProvider_']=_0xa26b19,this['appCheckTokenProvider_']=_0x582701,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x250d63,_0x558499,_0x12944f,_0x440c0b){const _0x23f7b2=_0x250d63['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x23f7b2+'\x20'+_0x250d63['_queryIdentifier']);const _0x49543a=vn['getListenId_'](_0x250d63,_0x12944f),_0x1ec476={};this['listens_'][_0x49543a]=_0x1ec476;const _0x5c770e=ir(_0x250d63['_queryParams']);this['restRequest_'](_0x23f7b2+'.json',_0x5c770e,(_0x2c7821,_0x4c424d)=>{let _0x59ebd0=_0x4c424d;if(_0x2c7821===0x194&&(_0x59ebd0=null,_0x2c7821=null),_0x2c7821===null&&this['onDataUpdate_'](_0x23f7b2,_0x59ebd0,!0x1,_0x12944f),Le(this['listens_'],_0x49543a)===_0x1ec476){let _0x6065af;_0x2c7821?_0x2c7821===0x191?_0x6065af='permission_denied':_0x6065af='rest_error:'+_0x2c7821:_0x6065af='ok',_0x440c0b(_0x6065af,null);}});}['unlisten'](_0x5d177f,_0x3483ac){const _0xb9a616=vn['getListenId_'](_0x5d177f,_0x3483ac);delete this['listens_'][_0xb9a616];}['get'](_0x25c285){const _0x44f72a=ir(_0x25c285['_queryParams']),_0x4126c2=_0x25c285['_path']['toString'](),_0x3335c9=new H();return this['restRequest_'](_0x4126c2+'.json',_0x44f72a,(_0x4f7304,_0x427b83)=>{let _0x4f7058=_0x427b83;_0x4f7304===0x194&&(_0x4f7058=null,_0x4f7304=null),_0x4f7304===null?(this['onDataUpdate_'](_0x4126c2,_0x4f7058,!0x1,null),_0x3335c9['resolve'](_0x4f7058)):_0x3335c9['reject'](new Error(_0x4f7058));}),_0x3335c9['promise'];}['refreshAuthToken'](_0x4382ee){}['restRequest_'](_0x1536cd,_0x11cf27={},_0x5cd2c9){return _0x11cf27['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x45d983,_0x2114e0])=>{_0x45d983&&_0x45d983['accessToken']&&(_0x11cf27['auth']=_0x45d983['accessToken']),_0x2114e0&&_0x2114e0['token']&&(_0x11cf27['ac']=_0x2114e0['token']);const _0x24238e=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1536cd+'?ns='+this['repoInfo_']['namespace']+ut(_0x11cf27);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x24238e);const _0x570773=new XMLHttpRequest();_0x570773['onreadystatechange']=()=>{if(_0x5cd2c9&&_0x570773['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x24238e+'\x20received.\x20status:',_0x570773['status'],'response:',_0x570773['responseText']);let _0x509e05=null;if(_0x570773['status']>=0xc8&&_0x570773['status']<0x12c){try{_0x509e05=Nt(_0x570773['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x24238e+':\x20'+_0x570773['responseText']);}_0x5cd2c9(null,_0x509e05);}else _0x570773['status']!==0x191&&_0x570773['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x24238e+'\x20Status:\x20'+_0x570773['status']),_0x5cd2c9(_0x570773['status']);_0x5cd2c9=null;}},_0x570773['open']('GET',_0x24238e,!0x0),_0x570773['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x127351){return this['rootNode_']['getChild'](_0x127351);}['updateSnapshot'](_0x3f294e,_0x387cf7){this['rootNode_']=this['rootNode_']['updateChild'](_0x3f294e,_0x387cf7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x4cbda4,_0x12399f,_0x2cb173){if(v(_0x12399f))_0x4cbda4['value']=_0x2cb173,_0x4cbda4['children']['clear']();else{if(_0x4cbda4['value']!==null)_0x4cbda4['value']=_0x4cbda4['value']['updateChild'](_0x12399f,_0x2cb173);else{const _0x66db3f=y(_0x12399f);_0x4cbda4['children']['has'](_0x66db3f)||_0x4cbda4['children']['set'](_0x66db3f,En());const _0x3214f1=_0x4cbda4['children']['get'](_0x66db3f);_0x12399f=S(_0x12399f),pt(_0x3214f1,_0x12399f,_0x2cb173);}}}function Ti(_0x2e3ff7,_0x1c689d){if(v(_0x1c689d))return _0x2e3ff7['value']=null,_0x2e3ff7['children']['clear'](),!0x0;if(_0x2e3ff7['value']!==null){if(_0x2e3ff7['value']['isLeafNode']())return!0x1;{const _0x400142=_0x2e3ff7['value'];return _0x2e3ff7['value']=null,_0x400142['forEachChild'](R,(_0x418e76,_0x2e762a)=>{pt(_0x2e3ff7,new C(_0x418e76),_0x2e762a);}),Ti(_0x2e3ff7,_0x1c689d);}}else{if(_0x2e3ff7['children']['size']>0x0){const _0xa25dac=y(_0x1c689d);return _0x1c689d=S(_0x1c689d),_0x2e3ff7['children']['has'](_0xa25dac)&&Ti(_0x2e3ff7['children']['get'](_0xa25dac),_0x1c689d)&&_0x2e3ff7['children']['delete'](_0xa25dac),_0x2e3ff7['children']['size']===0x0;}else return!0x0;}}function Si(_0x4ae0a7,_0x4722fd,_0xf900c8){_0x4ae0a7['value']!==null?_0xf900c8(_0x4722fd,_0x4ae0a7['value']):Zh(_0x4ae0a7,(_0x5189d8,_0x1b7c30)=>{const _0x44503b=new C(_0x4722fd['toString']()+'/'+_0x5189d8);Si(_0x1b7c30,_0x44503b,_0xf900c8);});}function Zh(_0x4aa632,_0x27068a){_0x4aa632['children']['forEach']((_0x1efd2d,_0x296372)=>{_0x27068a(_0x296372,_0x1efd2d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x12ca26){this['collection_']=_0x12ca26,this['last_']=null;}['get'](){const _0xb62881=this['collection_']['get'](),_0x52d932={..._0xb62881};return this['last_']&&x(this['last_'],(_0x28167f,_0x22fa4b)=>{_0x52d932[_0x28167f]=_0x52d932[_0x28167f]-_0x22fa4b;}),this['last_']=_0xb62881,_0x52d932;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x192f50,_0x23f561){this['server_']=_0x23f561,this['statsToReport_']={},this['statsListener_']=new eu(_0x192f50);const _0x2fe68a=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x2fe68a));}['reportStats_'](){const _0x5a837f=this['statsListener_']['get'](),_0x2ca77c={};let _0x57a7aa=!0x1;x(_0x5a837f,(_0xb2e83c,_0x355e09)=>{_0x355e09>0x0&&Q(this['statsToReport_'],_0xb2e83c)&&(_0x2ca77c[_0xb2e83c]=_0x355e09,_0x57a7aa=!0x0);}),_0x57a7aa&&this['server_']['reportStats'](_0x2ca77c),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x21d162){_0x21d162[_0x21d162['OVERWRITE']=0x0]='OVERWRITE',_0x21d162[_0x21d162['MERGE']=0x1]='MERGE',_0x21d162[_0x21d162['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x21d162[_0x21d162['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x411922){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x411922,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xa003b6,_0x2dda1b,_0x41bb21){this['path']=_0xa003b6,this['affectedTree']=_0x2dda1b,this['revert']=_0x41bb21,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3d662f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5c053c=this['affectedTree']['subtree'](new C(_0x3d662f));return new In(w(),_0x5c053c,this['revert']);}}else return f(y(this['path'])===_0x3d662f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x406331,_0x22e9ca){this['source']=_0x406331,this['path']=_0x22e9ca,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x312f5f){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4fae4a,_0x1f62c2,_0x25044d){this['source']=_0x4fae4a,this['path']=_0x1f62c2,this['snap']=_0x25044d,this['type']=z['OVERWRITE'];}['operationForChild'](_0x18ffae){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x18ffae)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x1559f0,_0x28b482,_0x326332){this['source']=_0x1559f0,this['path']=_0x28b482,this['children']=_0x326332,this['type']=z['MERGE'];}['operationForChild'](_0x40e186){if(v(this['path'])){const _0x23b5ba=this['children']['subtree'](new C(_0x40e186));return _0x23b5ba['isEmpty']()?null:_0x23b5ba['value']?new Be(this['source'],w(),_0x23b5ba['value']):new ot(this['source'],w(),_0x23b5ba);}else return f(y(this['path'])===_0x40e186,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x4b16bb,_0x676fb9,_0x3bdd24){this['node_']=_0x4b16bb,this['fullyInitialized_']=_0x676fb9,this['filtered_']=_0x3bdd24;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x21ab83){if(v(_0x21ab83))return this['isFullyInitialized']()&&!this['filtered_'];const _0x406537=y(_0x21ab83);return this['isCompleteForChild'](_0x406537);}['isCompleteForChild'](_0x409f1f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x409f1f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x11761b){this['query_']=_0x11761b,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x245e56,_0x48a4f3,_0x26f869,_0x5ca0ca){const _0x2373fc=[],_0x2b8d01=[];return _0x48a4f3['forEach'](_0x33dece=>{_0x33dece['type']==='child_changed'&&_0x245e56['index_']['indexedValueChanged'](_0x33dece['oldSnap'],_0x33dece['snapshotNode'])&&_0x2b8d01['push'](zh(_0x33dece['childName'],_0x33dece['snapshotNode']));}),wt(_0x245e56,_0x2373fc,'child_removed',_0x48a4f3,_0x5ca0ca,_0x26f869),wt(_0x245e56,_0x2373fc,'child_added',_0x48a4f3,_0x5ca0ca,_0x26f869),wt(_0x245e56,_0x2373fc,'child_moved',_0x2b8d01,_0x5ca0ca,_0x26f869),wt(_0x245e56,_0x2373fc,'child_changed',_0x48a4f3,_0x5ca0ca,_0x26f869),wt(_0x245e56,_0x2373fc,'value',_0x48a4f3,_0x5ca0ca,_0x26f869),_0x2373fc;}function wt(_0x49af3d,_0xb48796,_0x430abc,_0x2f2262,_0x133770,_0x46b205){const _0x4a1a37=_0x2f2262['filter'](_0x308da1=>_0x308da1['type']===_0x430abc);_0x4a1a37['sort']((_0x5e6a94,_0x313cec)=>au(_0x49af3d,_0x5e6a94,_0x313cec)),_0x4a1a37['forEach'](_0x43221d=>{const _0x514354=ou(_0x49af3d,_0x43221d,_0x46b205);_0x133770['forEach'](_0x111a66=>{_0x111a66['respondsTo'](_0x43221d['type'])&&_0xb48796['push'](_0x111a66['createEvent'](_0x514354,_0x49af3d['query_']));});});}function ou(_0x47b468,_0x4aa27a,_0x28804b){return _0x4aa27a['type']==='value'||_0x4aa27a['type']==='child_removed'||(_0x4aa27a['prevName']=_0x28804b['getPredecessorChildName'](_0x4aa27a['childName'],_0x4aa27a['snapshotNode'],_0x47b468['index_'])),_0x4aa27a;}function au(_0x570e6d,_0x3ab964,_0x45a34d){if(_0x3ab964['childName']==null||_0x45a34d['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x46243a=new E(_0x3ab964['childName'],_0x3ab964['snapshotNode']),_0x214a9a=new E(_0x45a34d['childName'],_0x45a34d['snapshotNode']);return _0x570e6d['index_']['compare'](_0x46243a,_0x214a9a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x314dfc,_0x18c284){return{'eventCache':_0x314dfc,'serverCache':_0x18c284};}function Rt(_0x2f1036,_0x38c683,_0x448541,_0x39ef53){return Un(new Te(_0x38c683,_0x448541,_0x39ef53),_0x2f1036['serverCache']);}function Fo(_0x2dc968,_0x38e807,_0x2ea190,_0x5842e3){return Un(_0x2dc968['eventCache'],new Te(_0x38e807,_0x2ea190,_0x5842e3));}function wn(_0x2b4533){return _0x2b4533['eventCache']['isFullyInitialized']()?_0x2b4533['eventCache']['getNode']():null;}function Ve(_0x4a1fe4){return _0x4a1fe4['serverCache']['isFullyInitialized']()?_0x4a1fe4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x3e14d1){let _0x68e3af=new b(null);return x(_0x3e14d1,(_0x36f83f,_0x13c9f5)=>{_0x68e3af=_0x68e3af['set'](new C(_0x36f83f),_0x13c9f5);}),_0x68e3af;}constructor(_0x588deb,_0x416e2d=cu()){this['value']=_0x588deb,this['children']=_0x416e2d;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x102427,_0x48caad){if(this['value']!=null&&_0x48caad(this['value']))return{'path':w(),'value':this['value']};if(v(_0x102427))return null;{const _0x791a91=y(_0x102427),_0x44cc36=this['children']['get'](_0x791a91);if(_0x44cc36!==null){const _0x2514a3=_0x44cc36['findRootMostMatchingPathAndValue'](S(_0x102427),_0x48caad);return _0x2514a3!=null?{'path':k(new C(_0x791a91),_0x2514a3['path']),'value':_0x2514a3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x43e634){return this['findRootMostMatchingPathAndValue'](_0x43e634,()=>!0x0);}['subtree'](_0x570439){if(v(_0x570439))return this;{const _0x1d5b08=y(_0x570439),_0x511be9=this['children']['get'](_0x1d5b08);return _0x511be9!==null?_0x511be9['subtree'](S(_0x570439)):new b(null);}}['set'](_0x1a3d7a,_0x3c0418){if(v(_0x1a3d7a))return new b(_0x3c0418,this['children']);{const _0x3b3ed7=y(_0x1a3d7a),_0x22be14=(this['children']['get'](_0x3b3ed7)||new b(null))['set'](S(_0x1a3d7a),_0x3c0418),_0x4b1b0f=this['children']['insert'](_0x3b3ed7,_0x22be14);return new b(this['value'],_0x4b1b0f);}}['remove'](_0x480367){if(v(_0x480367))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5a6c88=y(_0x480367),_0x2f78a9=this['children']['get'](_0x5a6c88);if(_0x2f78a9){const _0x54515b=_0x2f78a9['remove'](S(_0x480367));let _0x5901cb;return _0x54515b['isEmpty']()?_0x5901cb=this['children']['remove'](_0x5a6c88):_0x5901cb=this['children']['insert'](_0x5a6c88,_0x54515b),this['value']===null&&_0x5901cb['isEmpty']()?new b(null):new b(this['value'],_0x5901cb);}else return this;}}['get'](_0x2ac384){if(v(_0x2ac384))return this['value'];{const _0x4c8be8=y(_0x2ac384),_0x224010=this['children']['get'](_0x4c8be8);return _0x224010?_0x224010['get'](S(_0x2ac384)):null;}}['setTree'](_0x52cf71,_0x446b1d){if(v(_0x52cf71))return _0x446b1d;{const _0x48d124=y(_0x52cf71),_0x1510f1=(this['children']['get'](_0x48d124)||new b(null))['setTree'](S(_0x52cf71),_0x446b1d);let _0x2d0e8d;return _0x1510f1['isEmpty']()?_0x2d0e8d=this['children']['remove'](_0x48d124):_0x2d0e8d=this['children']['insert'](_0x48d124,_0x1510f1),new b(this['value'],_0x2d0e8d);}}['fold'](_0x39c10c){return this['fold_'](w(),_0x39c10c);}['fold_'](_0x5b842f,_0x4b99ea){const _0x1abf4d={};return this['children']['inorderTraversal']((_0x742ae0,_0x482cbf)=>{_0x1abf4d[_0x742ae0]=_0x482cbf['fold_'](k(_0x5b842f,_0x742ae0),_0x4b99ea);}),_0x4b99ea(_0x5b842f,this['value'],_0x1abf4d);}['findOnPath'](_0x4e8c4e,_0x3bc8bb){return this['findOnPath_'](_0x4e8c4e,w(),_0x3bc8bb);}['findOnPath_'](_0x5232ce,_0x1127f2,_0x339d0c){const _0x4f7d3d=this['value']?_0x339d0c(_0x1127f2,this['value']):!0x1;if(_0x4f7d3d)return _0x4f7d3d;if(v(_0x5232ce))return null;{const _0x355147=y(_0x5232ce),_0x517211=this['children']['get'](_0x355147);return _0x517211?_0x517211['findOnPath_'](S(_0x5232ce),k(_0x1127f2,_0x355147),_0x339d0c):null;}}['foreachOnPath'](_0x36abfb,_0x53ac9e){return this['foreachOnPath_'](_0x36abfb,w(),_0x53ac9e);}['foreachOnPath_'](_0x36f75b,_0x9aa63c,_0x459956){if(v(_0x36f75b))return this;{this['value']&&_0x459956(_0x9aa63c,this['value']);const _0x5c061e=y(_0x36f75b),_0x285482=this['children']['get'](_0x5c061e);return _0x285482?_0x285482['foreachOnPath_'](S(_0x36f75b),k(_0x9aa63c,_0x5c061e),_0x459956):new b(null);}}['foreach'](_0x5d14c9){this['foreach_'](w(),_0x5d14c9);}['foreach_'](_0x3ef1ff,_0xe3370f){this['children']['inorderTraversal']((_0x286d25,_0x4ac7dc)=>{_0x4ac7dc['foreach_'](k(_0x3ef1ff,_0x286d25),_0xe3370f);}),this['value']&&_0xe3370f(_0x3ef1ff,this['value']);}['foreachChild'](_0x2720e7){this['children']['inorderTraversal']((_0x534f00,_0x686863)=>{_0x686863['value']&&_0x2720e7(_0x534f00,_0x686863['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x2efa8e){this['writeTree_']=_0x2efa8e;}static['empty'](){return new K(new b(null));}}function At(_0x4188dc,_0x589d32,_0x3c6588){if(v(_0x589d32))return new K(new b(_0x3c6588));{const _0x310e1b=_0x4188dc['writeTree_']['findRootMostValueAndPath'](_0x589d32);if(_0x310e1b!=null){const _0x5b259b=_0x310e1b['path'];let _0x468261=_0x310e1b['value'];const _0x5bdf82=F(_0x5b259b,_0x589d32);return _0x468261=_0x468261['updateChild'](_0x5bdf82,_0x3c6588),new K(_0x4188dc['writeTree_']['set'](_0x5b259b,_0x468261));}else{const _0xda72a8=new b(_0x3c6588),_0x1a9a81=_0x4188dc['writeTree_']['setTree'](_0x589d32,_0xda72a8);return new K(_0x1a9a81);}}}function bi(_0x34f885,_0x2950dc,_0x3d8917){let _0xcc7327=_0x34f885;return x(_0x3d8917,(_0x47622c,_0x298f97)=>{_0xcc7327=At(_0xcc7327,k(_0x2950dc,_0x47622c),_0x298f97);}),_0xcc7327;}function or(_0xbbe8c5,_0x33935b){if(v(_0x33935b))return K['empty']();{const _0x270f5a=_0xbbe8c5['writeTree_']['setTree'](_0x33935b,new b(null));return new K(_0x270f5a);}}function Ri(_0x253b6c,_0x2b3098){return ze(_0x253b6c,_0x2b3098)!=null;}function ze(_0x596857,_0x404452){const _0x209e70=_0x596857['writeTree_']['findRootMostValueAndPath'](_0x404452);return _0x209e70!=null?_0x596857['writeTree_']['get'](_0x209e70['path'])['getChild'](F(_0x209e70['path'],_0x404452)):null;}function ar(_0x1ce3bb){const _0x4f9fdf=[],_0x167272=_0x1ce3bb['writeTree_']['value'];return _0x167272!=null?_0x167272['isLeafNode']()||_0x167272['forEachChild'](R,(_0x5e648a,_0x56ab68)=>{_0x4f9fdf['push'](new E(_0x5e648a,_0x56ab68));}):_0x1ce3bb['writeTree_']['children']['inorderTraversal']((_0x1cfd1a,_0x59edad)=>{_0x59edad['value']!=null&&_0x4f9fdf['push'](new E(_0x1cfd1a,_0x59edad['value']));}),_0x4f9fdf;}function Ee(_0x39232d,_0x459e35){if(v(_0x459e35))return _0x39232d;{const _0x575103=ze(_0x39232d,_0x459e35);return _0x575103!=null?new K(new b(_0x575103)):new K(_0x39232d['writeTree_']['subtree'](_0x459e35));}}function Ai(_0x16b6d3){return _0x16b6d3['writeTree_']['isEmpty']();}function at(_0xc25adf,_0x1381dd){return Uo(w(),_0xc25adf['writeTree_'],_0x1381dd);}function Uo(_0x5e0aa9,_0x247e91,_0x2937bf){if(_0x247e91['value']!=null)return _0x2937bf['updateChild'](_0x5e0aa9,_0x247e91['value']);{let _0x27282b=null;return _0x247e91['children']['inorderTraversal']((_0x2d606d,_0x3d0e46)=>{_0x2d606d==='.priority'?(f(_0x3d0e46['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x27282b=_0x3d0e46['value']):_0x2937bf=Uo(k(_0x5e0aa9,_0x2d606d),_0x3d0e46,_0x2937bf);}),!_0x2937bf['getChild'](_0x5e0aa9)['isEmpty']()&&_0x27282b!==null&&(_0x2937bf=_0x2937bf['updateChild'](k(_0x5e0aa9,'.priority'),_0x27282b)),_0x2937bf;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x3ee7ac,_0x217be9){return Ho(_0x217be9,_0x3ee7ac);}function lu(_0x7ca80b,_0x84cad9,_0x45ac4e,_0x5a5cae,_0x1fe7c9){f(_0x5a5cae>_0x7ca80b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1fe7c9===void 0x0&&(_0x1fe7c9=!0x0),_0x7ca80b['allWrites']['push']({'path':_0x84cad9,'snap':_0x45ac4e,'writeId':_0x5a5cae,'visible':_0x1fe7c9}),_0x1fe7c9&&(_0x7ca80b['visibleWrites']=At(_0x7ca80b['visibleWrites'],_0x84cad9,_0x45ac4e)),_0x7ca80b['lastWriteId']=_0x5a5cae;}function hu(_0x1be709,_0x33ae78,_0x32db9e,_0x1160b8){f(_0x1160b8>_0x1be709['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1be709['allWrites']['push']({'path':_0x33ae78,'children':_0x32db9e,'writeId':_0x1160b8,'visible':!0x0}),_0x1be709['visibleWrites']=bi(_0x1be709['visibleWrites'],_0x33ae78,_0x32db9e),_0x1be709['lastWriteId']=_0x1160b8;}function uu(_0x209583,_0x5c1ba5){for(let _0x5326ae=0x0;_0x5326ae<_0x209583['allWrites']['length'];_0x5326ae++){const _0x1b8498=_0x209583['allWrites'][_0x5326ae];if(_0x1b8498['writeId']===_0x5c1ba5)return _0x1b8498;}return null;}function du(_0x115b2e,_0x34f053){const _0x3d42c4=_0x115b2e['allWrites']['findIndex'](_0x2413f8=>_0x2413f8['writeId']===_0x34f053);f(_0x3d42c4>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x56ea1a=_0x115b2e['allWrites'][_0x3d42c4];_0x115b2e['allWrites']['splice'](_0x3d42c4,0x1);let _0x2e2da1=_0x56ea1a['visible'],_0x4106f6=!0x1,_0x210a93=_0x115b2e['allWrites']['length']-0x1;for(;_0x2e2da1&&_0x210a93>=0x0;){const _0x82e3de=_0x115b2e['allWrites'][_0x210a93];_0x82e3de['visible']&&(_0x210a93>=_0x3d42c4&&fu(_0x82e3de,_0x56ea1a['path'])?_0x2e2da1=!0x1:G(_0x56ea1a['path'],_0x82e3de['path'])&&(_0x4106f6=!0x0)),_0x210a93--;}if(_0x2e2da1){if(_0x4106f6)return pu(_0x115b2e),!0x0;if(_0x56ea1a['snap'])_0x115b2e['visibleWrites']=or(_0x115b2e['visibleWrites'],_0x56ea1a['path']);else{const _0x5333b8=_0x56ea1a['children'];x(_0x5333b8,_0x31bf35=>{_0x115b2e['visibleWrites']=or(_0x115b2e['visibleWrites'],k(_0x56ea1a['path'],_0x31bf35));});}return!0x0;}else return!0x1;}function fu(_0x5496f3,_0x57c608){if(_0x5496f3['snap'])return G(_0x5496f3['path'],_0x57c608);for(const _0x93fed6 in _0x5496f3['children'])if(_0x5496f3['children']['hasOwnProperty'](_0x93fed6)&&G(k(_0x5496f3['path'],_0x93fed6),_0x57c608))return!0x0;return!0x1;}function pu(_0x28b459){_0x28b459['visibleWrites']=Wo(_0x28b459['allWrites'],_u,w()),_0x28b459['allWrites']['length']>0x0?_0x28b459['lastWriteId']=_0x28b459['allWrites'][_0x28b459['allWrites']['length']-0x1]['writeId']:_0x28b459['lastWriteId']=-0x1;}function _u(_0x14af64){return _0x14af64['visible'];}function Wo(_0x5c4ca0,_0x47015e,_0x19484f){let _0x47384d=K['empty']();for(let _0x3ad4a4=0x0;_0x3ad4a4<_0x5c4ca0['length'];++_0x3ad4a4){const _0x4ca0c1=_0x5c4ca0[_0x3ad4a4];if(_0x47015e(_0x4ca0c1)){const _0x129a0b=_0x4ca0c1['path'];let _0x3bbeb6;if(_0x4ca0c1['snap'])G(_0x19484f,_0x129a0b)?(_0x3bbeb6=F(_0x19484f,_0x129a0b),_0x47384d=At(_0x47384d,_0x3bbeb6,_0x4ca0c1['snap'])):G(_0x129a0b,_0x19484f)&&(_0x3bbeb6=F(_0x129a0b,_0x19484f),_0x47384d=At(_0x47384d,w(),_0x4ca0c1['snap']['getChild'](_0x3bbeb6)));else{if(_0x4ca0c1['children']){if(G(_0x19484f,_0x129a0b))_0x3bbeb6=F(_0x19484f,_0x129a0b),_0x47384d=bi(_0x47384d,_0x3bbeb6,_0x4ca0c1['children']);else{if(G(_0x129a0b,_0x19484f)){if(_0x3bbeb6=F(_0x129a0b,_0x19484f),v(_0x3bbeb6))_0x47384d=bi(_0x47384d,w(),_0x4ca0c1['children']);else{const _0x3c3ec5=Le(_0x4ca0c1['children'],y(_0x3bbeb6));if(_0x3c3ec5){const _0x4e4a20=_0x3c3ec5['getChild'](S(_0x3bbeb6));_0x47384d=At(_0x47384d,w(),_0x4e4a20);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x47384d;}function Bo(_0x115b76,_0x8ca61e,_0x6ef2cd,_0x1b5c05,_0x1b4c70){if(!_0x1b5c05&&!_0x1b4c70){const _0x2c361b=ze(_0x115b76['visibleWrites'],_0x8ca61e);if(_0x2c361b!=null)return _0x2c361b;{const _0x2a6a40=Ee(_0x115b76['visibleWrites'],_0x8ca61e);if(Ai(_0x2a6a40))return _0x6ef2cd;if(_0x6ef2cd==null&&!Ri(_0x2a6a40,w()))return null;{const _0x18ccd4=_0x6ef2cd||g['EMPTY_NODE'];return at(_0x2a6a40,_0x18ccd4);}}}else{const _0x188361=Ee(_0x115b76['visibleWrites'],_0x8ca61e);if(!_0x1b4c70&&Ai(_0x188361))return _0x6ef2cd;if(!_0x1b4c70&&_0x6ef2cd==null&&!Ri(_0x188361,w()))return null;{const _0x3dabde=function(_0x3464c0){return(_0x3464c0['visible']||_0x1b4c70)&&(!_0x1b5c05||!~_0x1b5c05['indexOf'](_0x3464c0['writeId']))&&(G(_0x3464c0['path'],_0x8ca61e)||G(_0x8ca61e,_0x3464c0['path']));},_0xa6ffb1=Wo(_0x115b76['allWrites'],_0x3dabde,_0x8ca61e),_0xb0588=_0x6ef2cd||g['EMPTY_NODE'];return at(_0xa6ffb1,_0xb0588);}}}function gu(_0x1419c1,_0x49343a,_0x1e11e1){let _0x2ef544=g['EMPTY_NODE'];const _0x51b7a3=ze(_0x1419c1['visibleWrites'],_0x49343a);if(_0x51b7a3)return _0x51b7a3['isLeafNode']()||_0x51b7a3['forEachChild'](R,(_0x54ec53,_0x340e33)=>{_0x2ef544=_0x2ef544['updateImmediateChild'](_0x54ec53,_0x340e33);}),_0x2ef544;if(_0x1e11e1){const _0x1866c5=Ee(_0x1419c1['visibleWrites'],_0x49343a);return _0x1e11e1['forEachChild'](R,(_0x1db7a6,_0x24d42a)=>{const _0xa6ea83=at(Ee(_0x1866c5,new C(_0x1db7a6)),_0x24d42a);_0x2ef544=_0x2ef544['updateImmediateChild'](_0x1db7a6,_0xa6ea83);}),ar(_0x1866c5)['forEach'](_0xa5bfa0=>{_0x2ef544=_0x2ef544['updateImmediateChild'](_0xa5bfa0['name'],_0xa5bfa0['node']);}),_0x2ef544;}else{const _0x38b8eb=Ee(_0x1419c1['visibleWrites'],_0x49343a);return ar(_0x38b8eb)['forEach'](_0x5479c1=>{_0x2ef544=_0x2ef544['updateImmediateChild'](_0x5479c1['name'],_0x5479c1['node']);}),_0x2ef544;}}function mu(_0x469f5a,_0xfb5419,_0x1713f4,_0x1015f5,_0x2a0563){f(_0x1015f5||_0x2a0563,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x42dae9=k(_0xfb5419,_0x1713f4);if(Ri(_0x469f5a['visibleWrites'],_0x42dae9))return null;{const _0x10aa9a=Ee(_0x469f5a['visibleWrites'],_0x42dae9);return Ai(_0x10aa9a)?_0x2a0563['getChild'](_0x1713f4):at(_0x10aa9a,_0x2a0563['getChild'](_0x1713f4));}}function yu(_0x4f4457,_0x114bc3,_0x3ef6f9,_0x229311){const _0x12d74c=k(_0x114bc3,_0x3ef6f9),_0x1b4c20=ze(_0x4f4457['visibleWrites'],_0x12d74c);if(_0x1b4c20!=null)return _0x1b4c20;if(_0x229311['isCompleteForChild'](_0x3ef6f9)){const _0x237cf4=Ee(_0x4f4457['visibleWrites'],_0x12d74c);return at(_0x237cf4,_0x229311['getNode']()['getImmediateChild'](_0x3ef6f9));}else return null;}function vu(_0x479a9a,_0x3aaf4f){return ze(_0x479a9a['visibleWrites'],_0x3aaf4f);}function Eu(_0x3e7d2e,_0x2dfae1,_0x52cf51,_0x2e1303,_0x1a0e15,_0x4dd62b,_0x3139d1){let _0x5f1d89;const _0x45bc06=Ee(_0x3e7d2e['visibleWrites'],_0x2dfae1),_0x7d577=ze(_0x45bc06,w());if(_0x7d577!=null)_0x5f1d89=_0x7d577;else{if(_0x52cf51!=null)_0x5f1d89=at(_0x45bc06,_0x52cf51);else return[];}if(_0x5f1d89=_0x5f1d89['withIndex'](_0x3139d1),!_0x5f1d89['isEmpty']()&&!_0x5f1d89['isLeafNode']()){const _0x3001fb=[],_0x297035=_0x3139d1['getCompare'](),_0x577660=_0x4dd62b?_0x5f1d89['getReverseIteratorFrom'](_0x2e1303,_0x3139d1):_0x5f1d89['getIteratorFrom'](_0x2e1303,_0x3139d1);let _0x3789b9=_0x577660['getNext']();for(;_0x3789b9&&_0x3001fb['length']<_0x1a0e15;)_0x297035(_0x3789b9,_0x2e1303)!==0x0&&_0x3001fb['push'](_0x3789b9),_0x3789b9=_0x577660['getNext']();return _0x3001fb;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x3a4b9f,_0x4e786e,_0x1d5f8f,_0x285370){return Bo(_0x3a4b9f['writeTree'],_0x3a4b9f['treePath'],_0x4e786e,_0x1d5f8f,_0x285370);}function is(_0x7e27db,_0x45e5d2){return gu(_0x7e27db['writeTree'],_0x7e27db['treePath'],_0x45e5d2);}function cr(_0x157ace,_0x2c77a9,_0x5c04f3,_0x92a1ea){return mu(_0x157ace['writeTree'],_0x157ace['treePath'],_0x2c77a9,_0x5c04f3,_0x92a1ea);}function Tn(_0x113b35,_0x39293e){return vu(_0x113b35['writeTree'],k(_0x113b35['treePath'],_0x39293e));}function wu(_0x223f02,_0x11a567,_0x31aa98,_0x1fec08,_0x1c8f2b,_0x21c6fb){return Eu(_0x223f02['writeTree'],_0x223f02['treePath'],_0x11a567,_0x31aa98,_0x1fec08,_0x1c8f2b,_0x21c6fb);}function ss(_0x3c17da,_0xd04d36,_0x5f590e){return yu(_0x3c17da['writeTree'],_0x3c17da['treePath'],_0xd04d36,_0x5f590e);}function Vo(_0x1a4e71,_0x212cc8){return Ho(k(_0x1a4e71['treePath'],_0x212cc8),_0x1a4e71['writeTree']);}function Ho(_0x409d48,_0x2b25f4){return{'treePath':_0x409d48,'writeTree':_0x2b25f4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1ddd4e){const _0x492f31=_0x1ddd4e['type'],_0x357786=_0x1ddd4e['childName'];f(_0x492f31==='child_added'||_0x492f31==='child_changed'||_0x492f31==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x357786!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x35020a=this['changeMap']['get'](_0x357786);if(_0x35020a){const _0x36370d=_0x35020a['type'];if(_0x492f31==='child_added'&&_0x36370d==='child_removed')this['changeMap']['set'](_0x357786,xt(_0x357786,_0x1ddd4e['snapshotNode'],_0x35020a['snapshotNode']));else{if(_0x492f31==='child_removed'&&_0x36370d==='child_added')this['changeMap']['delete'](_0x357786);else{if(_0x492f31==='child_removed'&&_0x36370d==='child_changed')this['changeMap']['set'](_0x357786,Lt(_0x357786,_0x35020a['oldSnap']));else{if(_0x492f31==='child_changed'&&_0x36370d==='child_added')this['changeMap']['set'](_0x357786,rt(_0x357786,_0x1ddd4e['snapshotNode']));else{if(_0x492f31==='child_changed'&&_0x36370d==='child_changed')this['changeMap']['set'](_0x357786,xt(_0x357786,_0x1ddd4e['snapshotNode'],_0x35020a['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x1ddd4e+'\x20occurred\x20after\x20'+_0x35020a);}}}}}else this['changeMap']['set'](_0x357786,_0x1ddd4e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x14c7ab){return null;}['getChildAfterChild'](_0x1d5c05,_0x1b2588,_0x2babec){return null;}}const $o=new Tu();class rs{constructor(_0x529a76,_0x2c7b2a,_0x45ee34=null){this['writes_']=_0x529a76,this['viewCache_']=_0x2c7b2a,this['optCompleteServerCache_']=_0x45ee34;}['getCompleteChild'](_0x3221eb){const _0x4e8654=this['viewCache_']['eventCache'];if(_0x4e8654['isCompleteForChild'](_0x3221eb))return _0x4e8654['getNode']()['getImmediateChild'](_0x3221eb);{const _0x1d2369=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x3221eb,_0x1d2369);}}['getChildAfterChild'](_0xf898d5,_0x48e42a,_0x587243){const _0x16b276=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x4769e2=wu(this['writes_'],_0x16b276,_0x48e42a,0x1,_0x587243,_0xf898d5);return _0x4769e2['length']===0x0?null:_0x4769e2[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x1416ac){return{'filter':_0x1416ac};}function bu(_0xe8e25a,_0x26ccf3){f(_0x26ccf3['eventCache']['getNode']()['isIndexed'](_0xe8e25a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x26ccf3['serverCache']['getNode']()['isIndexed'](_0xe8e25a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x41b318,_0x56546d,_0x4d0c46,_0x46b8d1,_0x1d8888){const _0x5b83a7=new Cu();let _0x44999c,_0x34cc62;if(_0x4d0c46['type']===z['OVERWRITE']){const _0x3f5c51=_0x4d0c46;_0x3f5c51['source']['fromUser']?_0x44999c=ki(_0x41b318,_0x56546d,_0x3f5c51['path'],_0x3f5c51['snap'],_0x46b8d1,_0x1d8888,_0x5b83a7):(f(_0x3f5c51['source']['fromServer'],'Unknown\x20source.'),_0x34cc62=_0x3f5c51['source']['tagged']||_0x56546d['serverCache']['isFiltered']()&&!v(_0x3f5c51['path']),_0x44999c=Sn(_0x41b318,_0x56546d,_0x3f5c51['path'],_0x3f5c51['snap'],_0x46b8d1,_0x1d8888,_0x34cc62,_0x5b83a7));}else{if(_0x4d0c46['type']===z['MERGE']){const _0x321e55=_0x4d0c46;_0x321e55['source']['fromUser']?_0x44999c=ku(_0x41b318,_0x56546d,_0x321e55['path'],_0x321e55['children'],_0x46b8d1,_0x1d8888,_0x5b83a7):(f(_0x321e55['source']['fromServer'],'Unknown\x20source.'),_0x34cc62=_0x321e55['source']['tagged']||_0x56546d['serverCache']['isFiltered'](),_0x44999c=Pi(_0x41b318,_0x56546d,_0x321e55['path'],_0x321e55['children'],_0x46b8d1,_0x1d8888,_0x34cc62,_0x5b83a7));}else{if(_0x4d0c46['type']===z['ACK_USER_WRITE']){const _0x4b5562=_0x4d0c46;_0x4b5562['revert']?_0x44999c=Ou(_0x41b318,_0x56546d,_0x4b5562['path'],_0x46b8d1,_0x1d8888,_0x5b83a7):_0x44999c=Pu(_0x41b318,_0x56546d,_0x4b5562['path'],_0x4b5562['affectedTree'],_0x46b8d1,_0x1d8888,_0x5b83a7);}else{if(_0x4d0c46['type']===z['LISTEN_COMPLETE'])_0x44999c=Nu(_0x41b318,_0x56546d,_0x4d0c46['path'],_0x46b8d1,_0x5b83a7);else throw ht('Unknown\x20operation\x20type:\x20'+_0x4d0c46['type']);}}}const _0x3dbe08=_0x5b83a7['getChanges']();return Au(_0x56546d,_0x44999c,_0x3dbe08),{'viewCache':_0x44999c,'changes':_0x3dbe08};}function Au(_0x5e960a,_0x21badb,_0x4c5ae7){const _0x347a53=_0x21badb['eventCache'];if(_0x347a53['isFullyInitialized']()){const _0xe6ad27=_0x347a53['getNode']()['isLeafNode']()||_0x347a53['getNode']()['isEmpty'](),_0x6b6e9d=wn(_0x5e960a);(_0x4c5ae7['length']>0x0||!_0x5e960a['eventCache']['isFullyInitialized']()||_0xe6ad27&&!_0x347a53['getNode']()['equals'](_0x6b6e9d)||!_0x347a53['getNode']()['getPriority']()['equals'](_0x6b6e9d['getPriority']()))&&_0x4c5ae7['push'](Lo(wn(_0x21badb)));}}function Go(_0x5b482e,_0x193fd9,_0x57793b,_0x173edc,_0x124ac7,_0x4c24b2){const _0x43a904=_0x193fd9['eventCache'];if(Tn(_0x173edc,_0x57793b)!=null)return _0x193fd9;{let _0x2289a3,_0x53e1d4;if(v(_0x57793b)){if(f(_0x193fd9['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x193fd9['serverCache']['isFiltered']()){const _0x5374e=Ve(_0x193fd9),_0x10072f=_0x5374e instanceof g?_0x5374e:g['EMPTY_NODE'],_0x591c97=is(_0x173edc,_0x10072f);_0x2289a3=_0x5b482e['filter']['updateFullNode'](_0x193fd9['eventCache']['getNode'](),_0x591c97,_0x4c24b2);}else{const _0x25b510=Cn(_0x173edc,Ve(_0x193fd9));_0x2289a3=_0x5b482e['filter']['updateFullNode'](_0x193fd9['eventCache']['getNode'](),_0x25b510,_0x4c24b2);}}else{const _0x3c1f41=y(_0x57793b);if(_0x3c1f41==='.priority'){f(Ce(_0x57793b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2aa354=_0x43a904['getNode']();_0x53e1d4=_0x193fd9['serverCache']['getNode']();const _0x3a7867=cr(_0x173edc,_0x57793b,_0x2aa354,_0x53e1d4);_0x3a7867!=null?_0x2289a3=_0x5b482e['filter']['updatePriority'](_0x2aa354,_0x3a7867):_0x2289a3=_0x43a904['getNode']();}else{const _0x4d7d84=S(_0x57793b);let _0x2c6b3b;if(_0x43a904['isCompleteForChild'](_0x3c1f41)){_0x53e1d4=_0x193fd9['serverCache']['getNode']();const _0x239373=cr(_0x173edc,_0x57793b,_0x43a904['getNode'](),_0x53e1d4);_0x239373!=null?_0x2c6b3b=_0x43a904['getNode']()['getImmediateChild'](_0x3c1f41)['updateChild'](_0x4d7d84,_0x239373):_0x2c6b3b=_0x43a904['getNode']()['getImmediateChild'](_0x3c1f41);}else _0x2c6b3b=ss(_0x173edc,_0x3c1f41,_0x193fd9['serverCache']);_0x2c6b3b!=null?_0x2289a3=_0x5b482e['filter']['updateChild'](_0x43a904['getNode'](),_0x3c1f41,_0x2c6b3b,_0x4d7d84,_0x124ac7,_0x4c24b2):_0x2289a3=_0x43a904['getNode']();}}return Rt(_0x193fd9,_0x2289a3,_0x43a904['isFullyInitialized']()||v(_0x57793b),_0x5b482e['filter']['filtersNodes']());}}function Sn(_0x2721c9,_0x214612,_0x262500,_0x1de84c,_0x4fdfe1,_0x59b477,_0x129a42,_0x580b43){const _0x23518f=_0x214612['serverCache'];let _0x2db133;const _0x213764=_0x129a42?_0x2721c9['filter']:_0x2721c9['filter']['getIndexedFilter']();if(v(_0x262500))_0x2db133=_0x213764['updateFullNode'](_0x23518f['getNode'](),_0x1de84c,null);else{if(_0x213764['filtersNodes']()&&!_0x23518f['isFiltered']()){const _0x199d8f=_0x23518f['getNode']()['updateChild'](_0x262500,_0x1de84c);_0x2db133=_0x213764['updateFullNode'](_0x23518f['getNode'](),_0x199d8f,null);}else{const _0x621587=y(_0x262500);if(!_0x23518f['isCompleteForPath'](_0x262500)&&Ce(_0x262500)>0x1)return _0x214612;const _0x4c5d47=S(_0x262500),_0x490acd=_0x23518f['getNode']()['getImmediateChild'](_0x621587)['updateChild'](_0x4c5d47,_0x1de84c);_0x621587==='.priority'?_0x2db133=_0x213764['updatePriority'](_0x23518f['getNode'](),_0x490acd):_0x2db133=_0x213764['updateChild'](_0x23518f['getNode'](),_0x621587,_0x490acd,_0x4c5d47,$o,null);}}const _0x1829c8=Fo(_0x214612,_0x2db133,_0x23518f['isFullyInitialized']()||v(_0x262500),_0x213764['filtersNodes']()),_0x1e2b95=new rs(_0x4fdfe1,_0x1829c8,_0x59b477);return Go(_0x2721c9,_0x1829c8,_0x262500,_0x4fdfe1,_0x1e2b95,_0x580b43);}function ki(_0x2bdbda,_0x4be27f,_0x48b28a,_0x264478,_0xd87198,_0x273d86,_0x40af3f){const _0x28e2cd=_0x4be27f['eventCache'];let _0x4f9446,_0x185cf2;const _0x33b765=new rs(_0xd87198,_0x4be27f,_0x273d86);if(v(_0x48b28a))_0x185cf2=_0x2bdbda['filter']['updateFullNode'](_0x4be27f['eventCache']['getNode'](),_0x264478,_0x40af3f),_0x4f9446=Rt(_0x4be27f,_0x185cf2,!0x0,_0x2bdbda['filter']['filtersNodes']());else{const _0x1dc33c=y(_0x48b28a);if(_0x1dc33c==='.priority')_0x185cf2=_0x2bdbda['filter']['updatePriority'](_0x4be27f['eventCache']['getNode'](),_0x264478),_0x4f9446=Rt(_0x4be27f,_0x185cf2,_0x28e2cd['isFullyInitialized'](),_0x28e2cd['isFiltered']());else{const _0x56284d=S(_0x48b28a),_0x4827d0=_0x28e2cd['getNode']()['getImmediateChild'](_0x1dc33c);let _0x57890b;if(v(_0x56284d))_0x57890b=_0x264478;else{const _0x2e40fe=_0x33b765['getCompleteChild'](_0x1dc33c);_0x2e40fe!=null?ji(_0x56284d)==='.priority'&&_0x2e40fe['getChild'](Ro(_0x56284d))['isEmpty']()?_0x57890b=_0x2e40fe:_0x57890b=_0x2e40fe['updateChild'](_0x56284d,_0x264478):_0x57890b=g['EMPTY_NODE'];}if(_0x4827d0['equals'](_0x57890b))_0x4f9446=_0x4be27f;else{const _0x247668=_0x2bdbda['filter']['updateChild'](_0x28e2cd['getNode'](),_0x1dc33c,_0x57890b,_0x56284d,_0x33b765,_0x40af3f);_0x4f9446=Rt(_0x4be27f,_0x247668,_0x28e2cd['isFullyInitialized'](),_0x2bdbda['filter']['filtersNodes']());}}}return _0x4f9446;}function lr(_0x39ce95,_0x5d3564){return _0x39ce95['eventCache']['isCompleteForChild'](_0x5d3564);}function ku(_0x2c4fed,_0x30c7df,_0x44526b,_0x17585e,_0x4613e3,_0x261bb5,_0x4e7958){let _0x3d5c0c=_0x30c7df;return _0x17585e['foreach']((_0x5d0b20,_0x51bbd7)=>{const _0x2528aa=k(_0x44526b,_0x5d0b20);lr(_0x30c7df,y(_0x2528aa))&&(_0x3d5c0c=ki(_0x2c4fed,_0x3d5c0c,_0x2528aa,_0x51bbd7,_0x4613e3,_0x261bb5,_0x4e7958));}),_0x17585e['foreach']((_0x4425a3,_0x1c3cf4)=>{const _0x162595=k(_0x44526b,_0x4425a3);lr(_0x30c7df,y(_0x162595))||(_0x3d5c0c=ki(_0x2c4fed,_0x3d5c0c,_0x162595,_0x1c3cf4,_0x4613e3,_0x261bb5,_0x4e7958));}),_0x3d5c0c;}function hr(_0x11a8e3,_0x15cbc4,_0x52c857){return _0x52c857['foreach']((_0x3bb9f9,_0xd7629d)=>{_0x15cbc4=_0x15cbc4['updateChild'](_0x3bb9f9,_0xd7629d);}),_0x15cbc4;}function Pi(_0x4c1a0c,_0x11c814,_0x516cc4,_0xe700b4,_0x559b1e,_0x4f65d9,_0x3f36cd,_0x2398e9){if(_0x11c814['serverCache']['getNode']()['isEmpty']()&&!_0x11c814['serverCache']['isFullyInitialized']())return _0x11c814;let _0x41ca5f=_0x11c814,_0x2864b0;v(_0x516cc4)?_0x2864b0=_0xe700b4:_0x2864b0=new b(null)['setTree'](_0x516cc4,_0xe700b4);const _0x355c91=_0x11c814['serverCache']['getNode']();return _0x2864b0['children']['inorderTraversal']((_0x58317f,_0x52e6e9)=>{if(_0x355c91['hasChild'](_0x58317f)){const _0x4e95a3=_0x11c814['serverCache']['getNode']()['getImmediateChild'](_0x58317f),_0x31900d=hr(_0x4c1a0c,_0x4e95a3,_0x52e6e9);_0x41ca5f=Sn(_0x4c1a0c,_0x41ca5f,new C(_0x58317f),_0x31900d,_0x559b1e,_0x4f65d9,_0x3f36cd,_0x2398e9);}}),_0x2864b0['children']['inorderTraversal']((_0x8aebd,_0x3c41af)=>{const _0x4ec80a=!_0x11c814['serverCache']['isCompleteForChild'](_0x8aebd)&&_0x3c41af['value']===null;if(!_0x355c91['hasChild'](_0x8aebd)&&!_0x4ec80a){const _0x234111=_0x11c814['serverCache']['getNode']()['getImmediateChild'](_0x8aebd),_0x114b52=hr(_0x4c1a0c,_0x234111,_0x3c41af);_0x41ca5f=Sn(_0x4c1a0c,_0x41ca5f,new C(_0x8aebd),_0x114b52,_0x559b1e,_0x4f65d9,_0x3f36cd,_0x2398e9);}}),_0x41ca5f;}function Pu(_0x400af2,_0x1a0486,_0x1a2680,_0x3c3ce7,_0x3f587c,_0x3e460e,_0x9c87d7){if(Tn(_0x3f587c,_0x1a2680)!=null)return _0x1a0486;const _0x351e46=_0x1a0486['serverCache']['isFiltered'](),_0x3705e6=_0x1a0486['serverCache'];if(_0x3c3ce7['value']!=null){if(v(_0x1a2680)&&_0x3705e6['isFullyInitialized']()||_0x3705e6['isCompleteForPath'](_0x1a2680))return Sn(_0x400af2,_0x1a0486,_0x1a2680,_0x3705e6['getNode']()['getChild'](_0x1a2680),_0x3f587c,_0x3e460e,_0x351e46,_0x9c87d7);if(v(_0x1a2680)){let _0x2b19c0=new b(null);return _0x3705e6['getNode']()['forEachChild'](ve,(_0x10b265,_0x1858b2)=>{_0x2b19c0=_0x2b19c0['set'](new C(_0x10b265),_0x1858b2);}),Pi(_0x400af2,_0x1a0486,_0x1a2680,_0x2b19c0,_0x3f587c,_0x3e460e,_0x351e46,_0x9c87d7);}else return _0x1a0486;}else{let _0x23c19c=new b(null);return _0x3c3ce7['foreach']((_0x56afa9,_0x7e8697)=>{const _0xda5547=k(_0x1a2680,_0x56afa9);_0x3705e6['isCompleteForPath'](_0xda5547)&&(_0x23c19c=_0x23c19c['set'](_0x56afa9,_0x3705e6['getNode']()['getChild'](_0xda5547)));}),Pi(_0x400af2,_0x1a0486,_0x1a2680,_0x23c19c,_0x3f587c,_0x3e460e,_0x351e46,_0x9c87d7);}}function Nu(_0x1f772a,_0x152e31,_0x4c9879,_0x3a1840,_0x12e637){const _0x4f209b=_0x152e31['serverCache'],_0x3a4e25=Fo(_0x152e31,_0x4f209b['getNode'](),_0x4f209b['isFullyInitialized']()||v(_0x4c9879),_0x4f209b['isFiltered']());return Go(_0x1f772a,_0x3a4e25,_0x4c9879,_0x3a1840,$o,_0x12e637);}function Ou(_0x5e4451,_0x133906,_0x31fb19,_0x37bf27,_0x5e14f,_0x143b15){let _0x486b4e;if(Tn(_0x37bf27,_0x31fb19)!=null)return _0x133906;{const _0x16e2ea=new rs(_0x37bf27,_0x133906,_0x5e14f),_0x256260=_0x133906['eventCache']['getNode']();let _0x5979c6;if(v(_0x31fb19)||y(_0x31fb19)==='.priority'){let _0x599988;if(_0x133906['serverCache']['isFullyInitialized']())_0x599988=Cn(_0x37bf27,Ve(_0x133906));else{const _0x2ad9e5=_0x133906['serverCache']['getNode']();f(_0x2ad9e5 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x599988=is(_0x37bf27,_0x2ad9e5);}_0x599988=_0x599988,_0x5979c6=_0x5e4451['filter']['updateFullNode'](_0x256260,_0x599988,_0x143b15);}else{const _0x21ec89=y(_0x31fb19);let _0x3bc1ad=ss(_0x37bf27,_0x21ec89,_0x133906['serverCache']);_0x3bc1ad==null&&_0x133906['serverCache']['isCompleteForChild'](_0x21ec89)&&(_0x3bc1ad=_0x256260['getImmediateChild'](_0x21ec89)),_0x3bc1ad!=null?_0x5979c6=_0x5e4451['filter']['updateChild'](_0x256260,_0x21ec89,_0x3bc1ad,S(_0x31fb19),_0x16e2ea,_0x143b15):_0x133906['eventCache']['getNode']()['hasChild'](_0x21ec89)?_0x5979c6=_0x5e4451['filter']['updateChild'](_0x256260,_0x21ec89,g['EMPTY_NODE'],S(_0x31fb19),_0x16e2ea,_0x143b15):_0x5979c6=_0x256260,_0x5979c6['isEmpty']()&&_0x133906['serverCache']['isFullyInitialized']()&&(_0x486b4e=Cn(_0x37bf27,Ve(_0x133906)),_0x486b4e['isLeafNode']()&&(_0x5979c6=_0x5e4451['filter']['updateFullNode'](_0x5979c6,_0x486b4e,_0x143b15)));}return _0x486b4e=_0x133906['serverCache']['isFullyInitialized']()||Tn(_0x37bf27,w())!=null,Rt(_0x133906,_0x5979c6,_0x486b4e,_0x5e4451['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x36d281,_0xd0ab66){this['query_']=_0x36d281,this['eventRegistrations_']=[];const _0x2caea4=this['query_']['_queryParams'],_0x3c65cc=new Xi(_0x2caea4['getIndex']()),_0x577247=Kh(_0x2caea4);this['processor_']=Su(_0x577247);const _0x595ab6=_0xd0ab66['serverCache'],_0x3c834f=_0xd0ab66['eventCache'],_0x548eaf=_0x3c65cc['updateFullNode'](g['EMPTY_NODE'],_0x595ab6['getNode'](),null),_0x52a2bb=_0x577247['updateFullNode'](g['EMPTY_NODE'],_0x3c834f['getNode'](),null),_0x4fd73a=new Te(_0x548eaf,_0x595ab6['isFullyInitialized'](),_0x3c65cc['filtersNodes']()),_0xba7c2f=new Te(_0x52a2bb,_0x3c834f['isFullyInitialized'](),_0x577247['filtersNodes']());this['viewCache_']=Un(_0xba7c2f,_0x4fd73a),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x9ac99f){return _0x9ac99f['viewCache_']['serverCache']['getNode']();}function Lu(_0x41027a){return wn(_0x41027a['viewCache_']);}function xu(_0x2a2cd3,_0x4d1b1c){const _0xc96ac6=Ve(_0x2a2cd3['viewCache_']);return _0xc96ac6&&(_0x2a2cd3['query']['_queryParams']['loadsAllData']()||!v(_0x4d1b1c)&&!_0xc96ac6['getImmediateChild'](y(_0x4d1b1c))['isEmpty']())?_0xc96ac6['getChild'](_0x4d1b1c):null;}function ur(_0x18b09b){return _0x18b09b['eventRegistrations_']['length']===0x0;}function Fu(_0x4b48f0,_0x35f861){_0x4b48f0['eventRegistrations_']['push'](_0x35f861);}function dr(_0x2e49d7,_0x4d187b,_0xd7eb03){const _0x1842a9=[];if(_0xd7eb03){f(_0x4d187b==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2a225b=_0x2e49d7['query']['_path'];_0x2e49d7['eventRegistrations_']['forEach'](_0x290e4c=>{const _0x1815d0=_0x290e4c['createCancelEvent'](_0xd7eb03,_0x2a225b);_0x1815d0&&_0x1842a9['push'](_0x1815d0);});}if(_0x4d187b){let _0x2ed538=[];for(let _0x1a8b83=0x0;_0x1a8b83<_0x2e49d7['eventRegistrations_']['length'];++_0x1a8b83){const _0x5be35b=_0x2e49d7['eventRegistrations_'][_0x1a8b83];if(!_0x5be35b['matches'](_0x4d187b))_0x2ed538['push'](_0x5be35b);else{if(_0x4d187b['hasAnyCallback']()){_0x2ed538=_0x2ed538['concat'](_0x2e49d7['eventRegistrations_']['slice'](_0x1a8b83+0x1));break;}}}_0x2e49d7['eventRegistrations_']=_0x2ed538;}else _0x2e49d7['eventRegistrations_']=[];return _0x1842a9;}function fr(_0x15618f,_0x1e5593,_0x364b25,_0x1dff50){_0x1e5593['type']===z['MERGE']&&_0x1e5593['source']['queryId']!==null&&(f(Ve(_0x15618f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x15618f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x426348=_0x15618f['viewCache_'],_0xb5f94f=Ru(_0x15618f['processor_'],_0x426348,_0x1e5593,_0x364b25,_0x1dff50);return bu(_0x15618f['processor_'],_0xb5f94f['viewCache']),f(_0xb5f94f['viewCache']['serverCache']['isFullyInitialized']()||!_0x426348['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x15618f['viewCache_']=_0xb5f94f['viewCache'],qo(_0x15618f,_0xb5f94f['changes'],_0xb5f94f['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x236a03,_0x156605){const _0x4983cb=_0x236a03['viewCache_']['eventCache'],_0x14c8ac=[];return _0x4983cb['getNode']()['isLeafNode']()||_0x4983cb['getNode']()['forEachChild'](R,(_0x3e4e30,_0x42b276)=>{_0x14c8ac['push'](rt(_0x3e4e30,_0x42b276));}),_0x4983cb['isFullyInitialized']()&&_0x14c8ac['push'](Lo(_0x4983cb['getNode']())),qo(_0x236a03,_0x14c8ac,_0x4983cb['getNode'](),_0x156605);}function qo(_0xc15fd0,_0x1c4441,_0x2fa22c,_0x4e6ac7){const _0x13034f=_0x4e6ac7?[_0x4e6ac7]:_0xc15fd0['eventRegistrations_'];return ru(_0xc15fd0['eventGenerator_'],_0x1c4441,_0x2fa22c,_0x13034f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x24cb27){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x24cb27;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x477412){return _0x477412['views']['size']===0x0;}function os(_0x5a7585,_0x4c8a8b,_0x3a46ce,_0xec4f3f){const _0x462278=_0x4c8a8b['source']['queryId'];if(_0x462278!==null){const _0x1941ee=_0x5a7585['views']['get'](_0x462278);return f(_0x1941ee!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x1941ee,_0x4c8a8b,_0x3a46ce,_0xec4f3f);}else{let _0x4b8e89=[];for(const _0x11c05a of _0x5a7585['views']['values']())_0x4b8e89=_0x4b8e89['concat'](fr(_0x11c05a,_0x4c8a8b,_0x3a46ce,_0xec4f3f));return _0x4b8e89;}}function jo(_0x5b331b,_0x70a265,_0x4625fa,_0x221428,_0x4086c3){const _0x3749c0=_0x70a265['_queryIdentifier'],_0x392518=_0x5b331b['views']['get'](_0x3749c0);if(!_0x392518){let _0x12ac62=Cn(_0x4625fa,_0x4086c3?_0x221428:null),_0x29651a=!0x1;_0x12ac62?_0x29651a=!0x0:_0x221428 instanceof g?(_0x12ac62=is(_0x4625fa,_0x221428),_0x29651a=!0x1):(_0x12ac62=g['EMPTY_NODE'],_0x29651a=!0x1);const _0x4bad78=Un(new Te(_0x12ac62,_0x29651a,!0x1),new Te(_0x221428,_0x4086c3,!0x1));return new Du(_0x70a265,_0x4bad78);}return _0x392518;}function Hu(_0xad67e4,_0x2f7618,_0x459e0a,_0x43be08,_0x24e8ac,_0x3cb67e){const _0x18ff87=jo(_0xad67e4,_0x2f7618,_0x43be08,_0x24e8ac,_0x3cb67e);return _0xad67e4['views']['has'](_0x2f7618['_queryIdentifier'])||_0xad67e4['views']['set'](_0x2f7618['_queryIdentifier'],_0x18ff87),Fu(_0x18ff87,_0x459e0a),Uu(_0x18ff87,_0x459e0a);}function $u(_0x46e965,_0x57d5ca,_0xe67906,_0x46d579){const _0x400524=_0x57d5ca['_queryIdentifier'],_0x53198e=[];let _0x170579=[];const _0x22402b=Se(_0x46e965);if(_0x400524==='default'){for(const [_0x29231d,_0x1dc408]of _0x46e965['views']['entries']())_0x170579=_0x170579['concat'](dr(_0x1dc408,_0xe67906,_0x46d579)),ur(_0x1dc408)&&(_0x46e965['views']['delete'](_0x29231d),_0x1dc408['query']['_queryParams']['loadsAllData']()||_0x53198e['push'](_0x1dc408['query']));}else{const _0x5885b9=_0x46e965['views']['get'](_0x400524);_0x5885b9&&(_0x170579=_0x170579['concat'](dr(_0x5885b9,_0xe67906,_0x46d579)),ur(_0x5885b9)&&(_0x46e965['views']['delete'](_0x400524),_0x5885b9['query']['_queryParams']['loadsAllData']()||_0x53198e['push'](_0x5885b9['query'])));}return _0x22402b&&!Se(_0x46e965)&&_0x53198e['push'](new(Bu())(_0x57d5ca['_repo'],_0x57d5ca['_path'])),{'removed':_0x53198e,'events':_0x170579};}function Ko(_0xd107e){const _0x5c0398=[];for(const _0x30afd5 of _0xd107e['views']['values']())_0x30afd5['query']['_queryParams']['loadsAllData']()||_0x5c0398['push'](_0x30afd5);return _0x5c0398;}function Ie(_0x359855,_0x145b6b){let _0x595d51=null;for(const _0x5e724a of _0x359855['views']['values']())_0x595d51=_0x595d51||xu(_0x5e724a,_0x145b6b);return _0x595d51;}function Yo(_0x2210c6,_0x1dd99d){if(_0x1dd99d['_queryParams']['loadsAllData']())return Bn(_0x2210c6);{const _0x2cd17e=_0x1dd99d['_queryIdentifier'];return _0x2210c6['views']['get'](_0x2cd17e);}}function Qo(_0x17fb24,_0x32c38d){return Yo(_0x17fb24,_0x32c38d)!=null;}function Se(_0x26fab3){return Bn(_0x26fab3)!=null;}function Bn(_0x24f948){for(const _0x2b7842 of _0x24f948['views']['values']())if(_0x2b7842['query']['_queryParams']['loadsAllData']())return _0x2b7842;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3b0280){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3b0280;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x7fd330){this['listenProvider_']=_0x7fd330,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0xf5d236,_0xb89fee,_0x47fcbc,_0x469001,_0x1a9876){return lu(_0xf5d236['pendingWriteTree_'],_0xb89fee,_0x47fcbc,_0x469001,_0x1a9876),_0x1a9876?_t(_0xf5d236,new Be(es(),_0xb89fee,_0x47fcbc)):[];}function ju(_0x4ed3ef,_0x218365,_0x1b7716,_0x8769e0){hu(_0x4ed3ef['pendingWriteTree_'],_0x218365,_0x1b7716,_0x8769e0);const _0x382ad4=b['fromObject'](_0x1b7716);return _t(_0x4ed3ef,new ot(es(),_0x218365,_0x382ad4));}function _e(_0x4b8911,_0x251f22,_0x3ae6ce=!0x1){const _0x55f63c=uu(_0x4b8911['pendingWriteTree_'],_0x251f22);if(du(_0x4b8911['pendingWriteTree_'],_0x251f22)){let _0x240b68=new b(null);return _0x55f63c['snap']!=null?_0x240b68=_0x240b68['set'](w(),!0x0):x(_0x55f63c['children'],_0x558227=>{_0x240b68=_0x240b68['set'](new C(_0x558227),!0x0);}),_t(_0x4b8911,new In(_0x55f63c['path'],_0x240b68,_0x3ae6ce));}else return[];}function Yt(_0x2d25ea,_0x17d00b,_0x4bb725){return _t(_0x2d25ea,new Be(ts(),_0x17d00b,_0x4bb725));}function Ku(_0x36ea61,_0x3575d9,_0x256c52){const _0x356b29=b['fromObject'](_0x256c52);return _t(_0x36ea61,new ot(ts(),_0x3575d9,_0x356b29));}function Yu(_0x9b6a6b,_0x4160f1){return _t(_0x9b6a6b,new Ut(ts(),_0x4160f1));}function Qu(_0x123138,_0x5ea95b,_0x3ec142){const _0x23b912=cs(_0x123138,_0x3ec142);if(_0x23b912){const _0x5d683e=ls(_0x23b912),_0x5362ce=_0x5d683e['path'],_0xd76a9f=_0x5d683e['queryId'],_0x29bb5f=F(_0x5362ce,_0x5ea95b),_0x270585=new Ut(ns(_0xd76a9f),_0x29bb5f);return hs(_0x123138,_0x5362ce,_0x270585);}else return[];}function An(_0x9e1828,_0x248e83,_0x910b37,_0x4fc621,_0x92efd0=!0x1){const _0x34c8ef=_0x248e83['_path'],_0x1c6b90=_0x9e1828['syncPointTree_']['get'](_0x34c8ef);let _0x5ee65a=[];if(_0x1c6b90&&(_0x248e83['_queryIdentifier']==='default'||Qo(_0x1c6b90,_0x248e83))){const _0x10f7e5=$u(_0x1c6b90,_0x248e83,_0x910b37,_0x4fc621);Vu(_0x1c6b90)&&(_0x9e1828['syncPointTree_']=_0x9e1828['syncPointTree_']['remove'](_0x34c8ef));const _0x7a73ff=_0x10f7e5['removed'];if(_0x5ee65a=_0x10f7e5['events'],!_0x92efd0){const _0x4bb70a=_0x7a73ff['findIndex'](_0x7cc67f=>_0x7cc67f['_queryParams']['loadsAllData']())!==-0x1,_0x59b81a=_0x9e1828['syncPointTree_']['findOnPath'](_0x34c8ef,(_0x285354,_0x40d981)=>Se(_0x40d981));if(_0x4bb70a&&!_0x59b81a){const _0x3af8e0=_0x9e1828['syncPointTree_']['subtree'](_0x34c8ef);if(!_0x3af8e0['isEmpty']()){const _0x422b5e=Zu(_0x3af8e0);for(let _0x1f41a8=0x0;_0x1f41a8<_0x422b5e['length'];++_0x1f41a8){const _0x53f1d1=_0x422b5e[_0x1f41a8],_0x4169bf=_0x53f1d1['query'],_0x163bd3=ea(_0x9e1828,_0x53f1d1);_0x9e1828['listenProvider_']['startListening'](kt(_0x4169bf),Wt(_0x9e1828,_0x4169bf),_0x163bd3['hashFn'],_0x163bd3['onComplete']);}}}!_0x59b81a&&_0x7a73ff['length']>0x0&&!_0x4fc621&&(_0x4bb70a?_0x9e1828['listenProvider_']['stopListening'](kt(_0x248e83),null):_0x7a73ff['forEach'](_0x2be9b5=>{const _0x52359b=_0x9e1828['queryToTagMap']['get'](Hn(_0x2be9b5));_0x9e1828['listenProvider_']['stopListening'](kt(_0x2be9b5),_0x52359b);}));}ed(_0x9e1828,_0x7a73ff);}return _0x5ee65a;}function Jo(_0x237e5d,_0x1a5a34,_0x12181a,_0x2f4afb){const _0xae8e8d=cs(_0x237e5d,_0x2f4afb);if(_0xae8e8d!=null){const _0x3e806a=ls(_0xae8e8d),_0x5f4ad3=_0x3e806a['path'],_0x514796=_0x3e806a['queryId'],_0x1fea45=F(_0x5f4ad3,_0x1a5a34),_0x5a59a1=new Be(ns(_0x514796),_0x1fea45,_0x12181a);return hs(_0x237e5d,_0x5f4ad3,_0x5a59a1);}else return[];}function Ju(_0x4f83f2,_0x46bcb6,_0x2905a7,_0x4804cf){const _0x4858ce=cs(_0x4f83f2,_0x4804cf);if(_0x4858ce){const _0x2d99bf=ls(_0x4858ce),_0x42bae5=_0x2d99bf['path'],_0x76e060=_0x2d99bf['queryId'],_0x45fd59=F(_0x42bae5,_0x46bcb6),_0x168330=b['fromObject'](_0x2905a7),_0x5ef36a=new ot(ns(_0x76e060),_0x45fd59,_0x168330);return hs(_0x4f83f2,_0x42bae5,_0x5ef36a);}else return[];}function Ni(_0x3de29b,_0x36665d,_0x5c5c03,_0x6145d2=!0x1){const _0x1ee395=_0x36665d['_path'];let _0x5639d0=null,_0x45a519=!0x1;_0x3de29b['syncPointTree_']['foreachOnPath'](_0x1ee395,(_0x5948cf,_0x2ef169)=>{const _0x1233db=F(_0x5948cf,_0x1ee395);_0x5639d0=_0x5639d0||Ie(_0x2ef169,_0x1233db),_0x45a519=_0x45a519||Se(_0x2ef169);});let _0x36b479=_0x3de29b['syncPointTree_']['get'](_0x1ee395);_0x36b479?(_0x45a519=_0x45a519||Se(_0x36b479),_0x5639d0=_0x5639d0||Ie(_0x36b479,w())):(_0x36b479=new zo(),_0x3de29b['syncPointTree_']=_0x3de29b['syncPointTree_']['set'](_0x1ee395,_0x36b479));let _0xa01a21;_0x5639d0!=null?_0xa01a21=!0x0:(_0xa01a21=!0x1,_0x5639d0=g['EMPTY_NODE'],_0x3de29b['syncPointTree_']['subtree'](_0x1ee395)['foreachChild']((_0x5e8735,_0x3f4cfa)=>{const _0x76d960=Ie(_0x3f4cfa,w());_0x76d960&&(_0x5639d0=_0x5639d0['updateImmediateChild'](_0x5e8735,_0x76d960));}));const _0x34481a=Qo(_0x36b479,_0x36665d);if(!_0x34481a&&!_0x36665d['_queryParams']['loadsAllData']()){const _0x5d2d6a=Hn(_0x36665d);f(!_0x3de29b['queryToTagMap']['has'](_0x5d2d6a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x4a3903=td();_0x3de29b['queryToTagMap']['set'](_0x5d2d6a,_0x4a3903),_0x3de29b['tagToQueryMap']['set'](_0x4a3903,_0x5d2d6a);}const _0x4106b2=Wn(_0x3de29b['pendingWriteTree_'],_0x1ee395);let _0x56161e=Hu(_0x36b479,_0x36665d,_0x5c5c03,_0x4106b2,_0x5639d0,_0xa01a21);if(!_0x34481a&&!_0x45a519&&!_0x6145d2){const _0x4d33ab=Yo(_0x36b479,_0x36665d);_0x56161e=_0x56161e['concat'](nd(_0x3de29b,_0x36665d,_0x4d33ab));}return _0x56161e;}function Vn(_0x1e0a29,_0x908123,_0xe0760d){const _0xb74e3e=_0x1e0a29['pendingWriteTree_'],_0x331b59=_0x1e0a29['syncPointTree_']['findOnPath'](_0x908123,(_0x2fe442,_0x2fb240)=>{const _0x1f3809=F(_0x2fe442,_0x908123),_0x3eada7=Ie(_0x2fb240,_0x1f3809);if(_0x3eada7)return _0x3eada7;});return Bo(_0xb74e3e,_0x908123,_0x331b59,_0xe0760d,!0x0);}function Xu(_0x48c690,_0x4e8fd2){const _0x1f1feb=_0x4e8fd2['_path'];let _0x75e8b8=null;_0x48c690['syncPointTree_']['foreachOnPath'](_0x1f1feb,(_0x5a9698,_0x963ea2)=>{const _0x2abf75=F(_0x5a9698,_0x1f1feb);_0x75e8b8=_0x75e8b8||Ie(_0x963ea2,_0x2abf75);});let _0x42fcfa=_0x48c690['syncPointTree_']['get'](_0x1f1feb);_0x42fcfa?_0x75e8b8=_0x75e8b8||Ie(_0x42fcfa,w()):(_0x42fcfa=new zo(),_0x48c690['syncPointTree_']=_0x48c690['syncPointTree_']['set'](_0x1f1feb,_0x42fcfa));const _0x27c59d=_0x75e8b8!=null,_0x395451=_0x27c59d?new Te(_0x75e8b8,!0x0,!0x1):null,_0x45840b=Wn(_0x48c690['pendingWriteTree_'],_0x4e8fd2['_path']),_0x220185=jo(_0x42fcfa,_0x4e8fd2,_0x45840b,_0x27c59d?_0x395451['getNode']():g['EMPTY_NODE'],_0x27c59d);return Lu(_0x220185);}function _t(_0x29820c,_0xc9b052){return Xo(_0xc9b052,_0x29820c['syncPointTree_'],null,Wn(_0x29820c['pendingWriteTree_'],w()));}function Xo(_0x2ef7d7,_0x13dd2d,_0x18fa9a,_0x532870){if(v(_0x2ef7d7['path']))return Zo(_0x2ef7d7,_0x13dd2d,_0x18fa9a,_0x532870);{const _0x571527=_0x13dd2d['get'](w());_0x18fa9a==null&&_0x571527!=null&&(_0x18fa9a=Ie(_0x571527,w()));let _0xd7f94=[];const _0x493bae=y(_0x2ef7d7['path']),_0xb794a5=_0x2ef7d7['operationForChild'](_0x493bae),_0x20421f=_0x13dd2d['children']['get'](_0x493bae);if(_0x20421f&&_0xb794a5){const _0x11521d=_0x18fa9a?_0x18fa9a['getImmediateChild'](_0x493bae):null,_0x4c7861=Vo(_0x532870,_0x493bae);_0xd7f94=_0xd7f94['concat'](Xo(_0xb794a5,_0x20421f,_0x11521d,_0x4c7861));}return _0x571527&&(_0xd7f94=_0xd7f94['concat'](os(_0x571527,_0x2ef7d7,_0x532870,_0x18fa9a))),_0xd7f94;}}function Zo(_0x12eb59,_0x1e30a6,_0x51c746,_0x2d24e3){const _0x389bc3=_0x1e30a6['get'](w());_0x51c746==null&&_0x389bc3!=null&&(_0x51c746=Ie(_0x389bc3,w()));let _0x10e182=[];return _0x1e30a6['children']['inorderTraversal']((_0x456de4,_0x530b49)=>{const _0x5de0d9=_0x51c746?_0x51c746['getImmediateChild'](_0x456de4):null,_0x2665b5=Vo(_0x2d24e3,_0x456de4),_0x4cf19d=_0x12eb59['operationForChild'](_0x456de4);_0x4cf19d&&(_0x10e182=_0x10e182['concat'](Zo(_0x4cf19d,_0x530b49,_0x5de0d9,_0x2665b5)));}),_0x389bc3&&(_0x10e182=_0x10e182['concat'](os(_0x389bc3,_0x12eb59,_0x2d24e3,_0x51c746))),_0x10e182;}function ea(_0x1dbf7e,_0x2db660){const _0x3d78b9=_0x2db660['query'],_0x4fa6f6=Wt(_0x1dbf7e,_0x3d78b9);return{'hashFn':()=>(Mu(_0x2db660)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x56386a=>{if(_0x56386a==='ok')return _0x4fa6f6?Qu(_0x1dbf7e,_0x3d78b9['_path'],_0x4fa6f6):Yu(_0x1dbf7e,_0x3d78b9['_path']);{const _0x452d24=Kl(_0x56386a,_0x3d78b9);return An(_0x1dbf7e,_0x3d78b9,null,_0x452d24);}}};}function Wt(_0x4afb0b,_0x55e327){const _0x235207=Hn(_0x55e327);return _0x4afb0b['queryToTagMap']['get'](_0x235207);}function Hn(_0x2de178){return _0x2de178['_path']['toString']()+'$'+_0x2de178['_queryIdentifier'];}function cs(_0x338a00,_0x11720e){return _0x338a00['tagToQueryMap']['get'](_0x11720e);}function ls(_0x46cb1b){const _0x39ddab=_0x46cb1b['indexOf']('$');return f(_0x39ddab!==-0x1&&_0x39ddab<_0x46cb1b['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x46cb1b['substr'](_0x39ddab+0x1),'path':new C(_0x46cb1b['substr'](0x0,_0x39ddab))};}function hs(_0x42280c,_0x5ebe34,_0x1aedd1){const _0x348aab=_0x42280c['syncPointTree_']['get'](_0x5ebe34);f(_0x348aab,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x305985=Wn(_0x42280c['pendingWriteTree_'],_0x5ebe34);return os(_0x348aab,_0x1aedd1,_0x305985,null);}function Zu(_0x3f8f8a){return _0x3f8f8a['fold']((_0x26703d,_0x53d811,_0x5c8e0f)=>{if(_0x53d811&&Se(_0x53d811))return[Bn(_0x53d811)];{let _0x1ceaed=[];return _0x53d811&&(_0x1ceaed=Ko(_0x53d811)),x(_0x5c8e0f,(_0x2a7f1b,_0x506899)=>{_0x1ceaed=_0x1ceaed['concat'](_0x506899);}),_0x1ceaed;}});}function kt(_0x448bb8){return _0x448bb8['_queryParams']['loadsAllData']()&&!_0x448bb8['_queryParams']['isDefault']()?new(qu())(_0x448bb8['_repo'],_0x448bb8['_path']):_0x448bb8;}function ed(_0x2f56de,_0x301603){for(let _0xa77643=0x0;_0xa77643<_0x301603['length'];++_0xa77643){const _0x50f605=_0x301603[_0xa77643];if(!_0x50f605['_queryParams']['loadsAllData']()){const _0x577ee4=Hn(_0x50f605),_0x13f644=_0x2f56de['queryToTagMap']['get'](_0x577ee4);_0x2f56de['queryToTagMap']['delete'](_0x577ee4),_0x2f56de['tagToQueryMap']['delete'](_0x13f644);}}}function td(){return zu++;}function nd(_0x49f218,_0x405132,_0x12dd76){const _0x4300d6=_0x405132['_path'],_0x56c2c8=Wt(_0x49f218,_0x405132),_0x30d23d=ea(_0x49f218,_0x12dd76),_0x199828=_0x49f218['listenProvider_']['startListening'](kt(_0x405132),_0x56c2c8,_0x30d23d['hashFn'],_0x30d23d['onComplete']),_0x201dc1=_0x49f218['syncPointTree_']['subtree'](_0x4300d6);if(_0x56c2c8)f(!Se(_0x201dc1['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4a01e1=_0x201dc1['fold']((_0x34b51a,_0x3e07d1,_0x316b8d)=>{if(!v(_0x34b51a)&&_0x3e07d1&&Se(_0x3e07d1))return[Bn(_0x3e07d1)['query']];{let _0x4e863b=[];return _0x3e07d1&&(_0x4e863b=_0x4e863b['concat'](Ko(_0x3e07d1)['map'](_0x222d25=>_0x222d25['query']))),x(_0x316b8d,(_0x1b2bf8,_0x2301b2)=>{_0x4e863b=_0x4e863b['concat'](_0x2301b2);}),_0x4e863b;}});for(let _0x5abec5=0x0;_0x5abec5<_0x4a01e1['length'];++_0x5abec5){const _0x5c30d5=_0x4a01e1[_0x5abec5];_0x49f218['listenProvider_']['stopListening'](kt(_0x5c30d5),Wt(_0x49f218,_0x5c30d5));}}return _0x199828;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x237b01){this['node_']=_0x237b01;}['getImmediateChild'](_0x305f34){const _0x3c6748=this['node_']['getImmediateChild'](_0x305f34);return new us(_0x3c6748);}['node'](){return this['node_'];}}class ds{constructor(_0x4bd350,_0x35f443){this['syncTree_']=_0x4bd350,this['path_']=_0x35f443;}['getImmediateChild'](_0x3c9f28){const _0x255f1f=k(this['path_'],_0x3c9f28);return new ds(this['syncTree_'],_0x255f1f);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x17329b){return _0x17329b=_0x17329b||{},_0x17329b['timestamp']=_0x17329b['timestamp']||new Date()['getTime'](),_0x17329b;},_r=function(_0x2c30db,_0x567a49,_0x274d33){if(!_0x2c30db||typeof _0x2c30db!='object')return _0x2c30db;if(f('.sv'in _0x2c30db,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2c30db['.sv']=='string')return sd(_0x2c30db['.sv'],_0x567a49,_0x274d33);if(typeof _0x2c30db['.sv']=='object')return rd(_0x2c30db['.sv'],_0x567a49);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2c30db,null,0x2));},sd=function(_0x1ae2a8,_0x1a8ae1,_0x586817){switch(_0x1ae2a8){case'timestamp':return _0x586817['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1ae2a8);}},rd=function(_0x22a489,_0x4e7b5f,_0x48ffe8){_0x22a489['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x22a489,null,0x2));const _0x28d6cb=_0x22a489['increment'];typeof _0x28d6cb!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x28d6cb);const _0x12dea6=_0x4e7b5f['node']();if(f(_0x12dea6!==null&&typeof _0x12dea6<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x12dea6['isLeafNode']())return _0x28d6cb;const _0x338d06=_0x12dea6['getValue']();return typeof _0x338d06!='number'?_0x28d6cb:_0x338d06+_0x28d6cb;},ta=function(_0x9970a4,_0x5b6082,_0x1e06ba,_0xbc8f85){return ps(_0x5b6082,new ds(_0x1e06ba,_0x9970a4),_0xbc8f85);},fs=function(_0x1f5cdd,_0x190c87,_0x58ced9){return ps(_0x1f5cdd,new us(_0x190c87),_0x58ced9);};function ps(_0x51a0d9,_0x1e7d5e,_0x52ff50){const _0x2d3775=_0x51a0d9['getPriority']()['val'](),_0x5dc6c0=_r(_0x2d3775,_0x1e7d5e['getImmediateChild']('.priority'),_0x52ff50);let _0xd7acaa;if(_0x51a0d9['isLeafNode']()){const _0xf296b2=_0x51a0d9,_0xbe557=_r(_0xf296b2['getValue'](),_0x1e7d5e,_0x52ff50);return _0xbe557!==_0xf296b2['getValue']()||_0x5dc6c0!==_0xf296b2['getPriority']()['val']()?new D(_0xbe557,A(_0x5dc6c0)):_0x51a0d9;}else{const _0x4ab5d6=_0x51a0d9;return _0xd7acaa=_0x4ab5d6,_0x5dc6c0!==_0x4ab5d6['getPriority']()['val']()&&(_0xd7acaa=_0xd7acaa['updatePriority'](new D(_0x5dc6c0))),_0x4ab5d6['forEachChild'](R,(_0x209183,_0x55ec14)=>{const _0x522803=ps(_0x55ec14,_0x1e7d5e['getImmediateChild'](_0x209183),_0x52ff50);_0x522803!==_0x55ec14&&(_0xd7acaa=_0xd7acaa['updateImmediateChild'](_0x209183,_0x522803));}),_0xd7acaa;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x46b786='',_0x727af9=null,_0x53453d={'children':{},'childCount':0x0}){this['name']=_0x46b786,this['parent']=_0x727af9,this['node']=_0x53453d;}}function $n(_0x4df6a9,_0x28ed4a){let _0x541741=_0x28ed4a instanceof C?_0x28ed4a:new C(_0x28ed4a),_0x3a605e=_0x4df6a9,_0x726d05=y(_0x541741);for(;_0x726d05!==null;){const _0x2cfb44=Le(_0x3a605e['node']['children'],_0x726d05)||{'children':{},'childCount':0x0};_0x3a605e=new _s(_0x726d05,_0x3a605e,_0x2cfb44),_0x541741=S(_0x541741),_0x726d05=y(_0x541741);}return _0x3a605e;}function je(_0x54c86e){return _0x54c86e['node']['value'];}function gs(_0x333df1,_0x535a20){_0x333df1['node']['value']=_0x535a20,Oi(_0x333df1);}function na(_0x5c47be){return _0x5c47be['node']['childCount']>0x0;}function od(_0x2a808f){return je(_0x2a808f)===void 0x0&&!na(_0x2a808f);}function Gn(_0x24fc0f,_0x1d3a76){x(_0x24fc0f['node']['children'],(_0xbc15ef,_0x161d62)=>{_0x1d3a76(new _s(_0xbc15ef,_0x24fc0f,_0x161d62));});}function ia(_0x4e3fab,_0x32e285,_0x5b3bfa,_0x52ce3f){_0x5b3bfa&&_0x32e285(_0x4e3fab),Gn(_0x4e3fab,_0x12bac0=>{ia(_0x12bac0,_0x32e285,!0x0);});}function ad(_0x357b16,_0x26c1bb,_0x33cdd4){let _0x5cbf7d=_0x357b16['parent'];for(;_0x5cbf7d!==null;){if(_0x26c1bb(_0x5cbf7d))return!0x0;_0x5cbf7d=_0x5cbf7d['parent'];}return!0x1;}function Qt(_0x3fe49c){return new C(_0x3fe49c['parent']===null?_0x3fe49c['name']:Qt(_0x3fe49c['parent'])+'/'+_0x3fe49c['name']);}function Oi(_0x497f59){_0x497f59['parent']!==null&&cd(_0x497f59['parent'],_0x497f59['name'],_0x497f59);}function cd(_0x139125,_0x2f6a3e,_0x23decf){const _0x6a9c27=od(_0x23decf),_0x41688a=Q(_0x139125['node']['children'],_0x2f6a3e);_0x6a9c27&&_0x41688a?(delete _0x139125['node']['children'][_0x2f6a3e],_0x139125['node']['childCount']--,Oi(_0x139125)):!_0x6a9c27&&!_0x41688a&&(_0x139125['node']['children'][_0x2f6a3e]=_0x23decf['node'],_0x139125['node']['childCount']++,Oi(_0x139125));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x5554e7){return typeof _0x5554e7=='string'&&_0x5554e7['length']!==0x0&&!ld['test'](_0x5554e7);},sa=function(_0x322065){return typeof _0x322065=='string'&&_0x322065['length']!==0x0&&!hd['test'](_0x322065);},ud=function(_0x25b532){return _0x25b532&&(_0x25b532=_0x25b532['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x25b532);},Bt=function(_0x118108){return _0x118108===null||typeof _0x118108=='string'||typeof _0x118108=='number'&&!xn(_0x118108)||_0x118108&&typeof _0x118108=='object'&&Q(_0x118108,'.sv');},He=function(_0x500941,_0x33e47c,_0x10c94e,_0x35abd8){_0x35abd8&&_0x33e47c===void 0x0||Jt(it(_0x500941,'value'),_0x33e47c,_0x10c94e);},Jt=function(_0x1cea2e,_0x5205e7,_0x194fed){const _0xf4b024=_0x194fed instanceof C?new Ah(_0x194fed,_0x1cea2e):_0x194fed;if(_0x5205e7===void 0x0)throw new Error(_0x1cea2e+'contains\x20undefined\x20'+Oe(_0xf4b024));if(typeof _0x5205e7=='function')throw new Error(_0x1cea2e+'contains\x20a\x20function\x20'+Oe(_0xf4b024)+'\x20with\x20contents\x20=\x20'+_0x5205e7['toString']());if(xn(_0x5205e7))throw new Error(_0x1cea2e+'contains\x20'+_0x5205e7['toString']()+'\x20'+Oe(_0xf4b024));if(typeof _0x5205e7=='string'&&_0x5205e7['length']>ui/0x3&&Ln(_0x5205e7)>ui)throw new Error(_0x1cea2e+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0xf4b024)+'\x20(\x27'+_0x5205e7['substring'](0x0,0x32)+'...\x27)');if(_0x5205e7&&typeof _0x5205e7=='object'){let _0x160c48=!0x1,_0x286000=!0x1;if(x(_0x5205e7,(_0x21a311,_0xe05239)=>{if(_0x21a311==='.value')_0x160c48=!0x0;else{if(_0x21a311!=='.priority'&&_0x21a311!=='.sv'&&(_0x286000=!0x0,!ms(_0x21a311)))throw new Error(_0x1cea2e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x21a311+')\x20'+Oe(_0xf4b024)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xf4b024,_0x21a311),Jt(_0x1cea2e,_0xe05239,_0xf4b024),Ph(_0xf4b024);}),_0x160c48&&_0x286000)throw new Error(_0x1cea2e+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0xf4b024)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2ad34d,_0x840969){let _0x386503,_0x34c049;for(_0x386503=0x0;_0x386503<_0x840969['length'];_0x386503++){_0x34c049=_0x840969[_0x386503];const _0x307434=Mt(_0x34c049);for(let _0x596743=0x0;_0x596743<_0x307434['length'];_0x596743++)if(!(_0x307434[_0x596743]==='.priority'&&_0x596743===_0x307434['length']-0x1)){if(!ms(_0x307434[_0x596743]))throw new Error(_0x2ad34d+'contains\x20an\x20invalid\x20key\x20('+_0x307434[_0x596743]+')\x20in\x20path\x20'+_0x34c049['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x840969['sort'](Rh);let _0x5b6eb3=null;for(_0x386503=0x0;_0x386503<_0x840969['length'];_0x386503++){if(_0x34c049=_0x840969[_0x386503],_0x5b6eb3!==null&&G(_0x5b6eb3,_0x34c049))throw new Error(_0x2ad34d+'contains\x20a\x20path\x20'+_0x5b6eb3['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x34c049['toString']());_0x5b6eb3=_0x34c049;}},ra=function(_0x46172d,_0x1b3c32,_0x40ab7c,_0xf1cb4d){const _0x1fbe82=it(_0x46172d,'values');if(!(_0x1b3c32&&typeof _0x1b3c32=='object')||Array['isArray'](_0x1b3c32))throw new Error(_0x1fbe82+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2154e1=[];x(_0x1b3c32,(_0x53dfc3,_0x4f2760)=>{const _0x399f8d=new C(_0x53dfc3);if(Jt(_0x1fbe82,_0x4f2760,k(_0x40ab7c,_0x399f8d)),ji(_0x399f8d)==='.priority'&&!Bt(_0x4f2760))throw new Error(_0x1fbe82+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x399f8d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2154e1['push'](_0x399f8d);}),dd(_0x1fbe82,_0x2154e1);},fd=function(_0x3a6b97,_0x2f1bb0,_0x5f599a){if(xn(_0x2f1bb0))throw new Error(it(_0x3a6b97,'priority')+'is\x20'+_0x2f1bb0['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2f1bb0))throw new Error(it(_0x3a6b97,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xca10aa,_0x4ee3d9,_0x34beca,_0x28d15b){if(!sa(_0x34beca))throw new Error(it(_0xca10aa,_0x4ee3d9)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x34beca+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4df0d8,_0x24b7ec,_0x387c33,_0x230063){_0x387c33&&(_0x387c33=_0x387c33['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4df0d8,_0x24b7ec,_0x387c33);},Me=function(_0x1b8ef1,_0x352e19){if(y(_0x352e19)==='.info')throw new Error(_0x1b8ef1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x2d74b7,_0x700b65){const _0x103223=_0x700b65['path']['toString']();if(typeof _0x700b65['repoInfo']['host']!='string'||_0x700b65['repoInfo']['host']['length']===0x0||!ms(_0x700b65['repoInfo']['namespace'])&&_0x700b65['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x103223['length']!==0x0&&!ud(_0x103223))throw new Error(it(_0x2d74b7,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3a0d56,_0x187415){let _0x2dcde2=null;for(let _0x48699c=0x0;_0x48699c<_0x187415['length'];_0x48699c++){const _0x848196=_0x187415[_0x48699c],_0x139b5e=_0x848196['getPath']();_0x2dcde2!==null&&!Ki(_0x139b5e,_0x2dcde2['path'])&&(_0x3a0d56['eventLists_']['push'](_0x2dcde2),_0x2dcde2=null),_0x2dcde2===null&&(_0x2dcde2={'events':[],'path':_0x139b5e}),_0x2dcde2['events']['push'](_0x848196);}_0x2dcde2&&_0x3a0d56['eventLists_']['push'](_0x2dcde2);}function oa(_0x473889,_0x3f6413,_0x36ac80){qn(_0x473889,_0x36ac80),aa(_0x473889,_0x4e6f6a=>Ki(_0x4e6f6a,_0x3f6413));}function V(_0x38ec73,_0x2680a0,_0x2aa2b4){qn(_0x38ec73,_0x2aa2b4),aa(_0x38ec73,_0x45909b=>G(_0x45909b,_0x2680a0)||G(_0x2680a0,_0x45909b));}function aa(_0x57d336,_0x2559a9){_0x57d336['recursionDepth_']++;let _0x1631c3=!0x0;for(let _0x3ef5b6=0x0;_0x3ef5b6<_0x57d336['eventLists_']['length'];_0x3ef5b6++){const _0x4f6a07=_0x57d336['eventLists_'][_0x3ef5b6];if(_0x4f6a07){const _0x1e0017=_0x4f6a07['path'];_0x2559a9(_0x1e0017)?(md(_0x57d336['eventLists_'][_0x3ef5b6]),_0x57d336['eventLists_'][_0x3ef5b6]=null):_0x1631c3=!0x1;}}_0x1631c3&&(_0x57d336['eventLists_']=[]),_0x57d336['recursionDepth_']--;}function md(_0x315c24){for(let _0x2c7d06=0x0;_0x2c7d06<_0x315c24['events']['length'];_0x2c7d06++){const _0x2b007a=_0x315c24['events'][_0x2c7d06];if(_0x2b007a!==null){_0x315c24['events'][_0x2c7d06]=null;const _0x5be4b2=_0x2b007a['getEventRunner']();St&&L('event:\x20'+_0x2b007a['toString']()),ft(_0x5be4b2);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3fd714,_0xd9cf8f,_0x46a052,_0x188eb6){this['repoInfo_']=_0x3fd714,this['forceRestClient_']=_0xd9cf8f,this['authTokenProvider_']=_0x46a052,this['appCheckProvider_']=_0x188eb6,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1536fa,_0x33ced0,_0x500912){if(_0x1536fa['stats_']=qi(_0x1536fa['repoInfo_']),_0x1536fa['forceRestClient_']||Xl())_0x1536fa['server_']=new vn(_0x1536fa['repoInfo_'],(_0x403831,_0x217af7,_0x3ad5bb,_0x54753e)=>{gr(_0x1536fa,_0x403831,_0x217af7,_0x3ad5bb,_0x54753e);},_0x1536fa['authTokenProvider_'],_0x1536fa['appCheckProvider_']),setTimeout(()=>mr(_0x1536fa,!0x0),0x0);else{if(typeof _0x500912<'u'&&_0x500912!==null){if(typeof _0x500912!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x500912);}catch(_0x1aec8f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1aec8f);}}_0x1536fa['persistentConnection_']=new se(_0x1536fa['repoInfo_'],_0x33ced0,(_0x287771,_0x5d8f61,_0x197f7c,_0x40042d)=>{gr(_0x1536fa,_0x287771,_0x5d8f61,_0x197f7c,_0x40042d);},_0x3ecc83=>{mr(_0x1536fa,_0x3ecc83);},_0x5a617e=>{Id(_0x1536fa,_0x5a617e);},_0x1536fa['authTokenProvider_'],_0x1536fa['appCheckProvider_'],_0x500912),_0x1536fa['server_']=_0x1536fa['persistentConnection_'];}_0x1536fa['authTokenProvider_']['addTokenChangeListener'](_0x22d42b=>{_0x1536fa['server_']['refreshAuthToken'](_0x22d42b);}),_0x1536fa['appCheckProvider_']['addTokenChangeListener'](_0x2084b3=>{_0x1536fa['server_']['refreshAppCheckToken'](_0x2084b3['token']);}),_0x1536fa['statsReporter_']=ih(_0x1536fa['repoInfo_'],()=>new iu(_0x1536fa['stats_'],_0x1536fa['server_'])),_0x1536fa['infoData_']=new Xh(),_0x1536fa['infoSyncTree_']=new pr({'startListening':(_0x7eb7ce,_0x4f0d9a,_0x5b35cd,_0x51aa5a)=>{let _0x2cfd66=[];const _0x13d58c=_0x1536fa['infoData_']['getNode'](_0x7eb7ce['_path']);return _0x13d58c['isEmpty']()||(_0x2cfd66=Yt(_0x1536fa['infoSyncTree_'],_0x7eb7ce['_path'],_0x13d58c),setTimeout(()=>{_0x51aa5a('ok');},0x0)),_0x2cfd66;},'stopListening':()=>{}}),vs(_0x1536fa,'connected',!0x1),_0x1536fa['serverSyncTree_']=new pr({'startListening':(_0x47a639,_0x4d523a,_0x482fa8,_0x276a55)=>(_0x1536fa['server_']['listen'](_0x47a639,_0x482fa8,_0x4d523a,(_0x503ad6,_0x5c2df5)=>{const _0x531f8b=_0x276a55(_0x503ad6,_0x5c2df5);V(_0x1536fa['eventQueue_'],_0x47a639['_path'],_0x531f8b);}),[]),'stopListening':(_0x175d24,_0x248bf7)=>{_0x1536fa['server_']['unlisten'](_0x175d24,_0x248bf7);}});}function la(_0x110752){const _0xee31de=_0x110752['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xee31de;}function Xt(_0x1a5078){return id({'timestamp':la(_0x1a5078)});}function gr(_0x483ad5,_0x4a73d0,_0x2b89dc,_0x5ecab5,_0x55d415){_0x483ad5['dataUpdateCount']++;const _0x266a3c=new C(_0x4a73d0);_0x2b89dc=_0x483ad5['interceptServerDataCallback_']?_0x483ad5['interceptServerDataCallback_'](_0x4a73d0,_0x2b89dc):_0x2b89dc;let _0x405224=[];if(_0x55d415){if(_0x5ecab5){const _0x58898e=_n(_0x2b89dc,_0xcf4b19=>A(_0xcf4b19));_0x405224=Ju(_0x483ad5['serverSyncTree_'],_0x266a3c,_0x58898e,_0x55d415);}else{const _0x52c217=A(_0x2b89dc);_0x405224=Jo(_0x483ad5['serverSyncTree_'],_0x266a3c,_0x52c217,_0x55d415);}}else{if(_0x5ecab5){const _0x6eb48f=_n(_0x2b89dc,_0x95c5a5=>A(_0x95c5a5));_0x405224=Ku(_0x483ad5['serverSyncTree_'],_0x266a3c,_0x6eb48f);}else{const _0x273501=A(_0x2b89dc);_0x405224=Yt(_0x483ad5['serverSyncTree_'],_0x266a3c,_0x273501);}}let _0x377780=_0x266a3c;_0x405224['length']>0x0&&(_0x377780=ct(_0x483ad5,_0x266a3c)),V(_0x483ad5['eventQueue_'],_0x377780,_0x405224);}function mr(_0x181012,_0x33825b){vs(_0x181012,'connected',_0x33825b),_0x33825b===!0x1&&Sd(_0x181012);}function Id(_0x1872dc,_0x3882e1){x(_0x3882e1,(_0x224dff,_0x7776ea)=>{vs(_0x1872dc,_0x224dff,_0x7776ea);});}function vs(_0x33d631,_0x5a6000,_0x4ba198){const _0x160675=new C('/.info/'+_0x5a6000),_0x4715ce=A(_0x4ba198);_0x33d631['infoData_']['updateSnapshot'](_0x160675,_0x4715ce);const _0x5ef528=Yt(_0x33d631['infoSyncTree_'],_0x160675,_0x4715ce);V(_0x33d631['eventQueue_'],_0x160675,_0x5ef528);}function zn(_0x1203ff){return _0x1203ff['nextWriteId_']++;}function wd(_0x8198de,_0x4ded43,_0x1ae6f5){const _0x205407=Xu(_0x8198de['serverSyncTree_'],_0x4ded43);return _0x205407!=null?Promise['resolve'](_0x205407):_0x8198de['server_']['get'](_0x4ded43)['then'](_0x4143bc=>{const _0x4f7178=A(_0x4143bc)['withIndex'](_0x4ded43['_queryParams']['getIndex']());Ni(_0x8198de['serverSyncTree_'],_0x4ded43,_0x1ae6f5,!0x0);let _0x10d058;if(_0x4ded43['_queryParams']['loadsAllData']())_0x10d058=Yt(_0x8198de['serverSyncTree_'],_0x4ded43['_path'],_0x4f7178);else{const _0x210fe2=Wt(_0x8198de['serverSyncTree_'],_0x4ded43);_0x10d058=Jo(_0x8198de['serverSyncTree_'],_0x4ded43['_path'],_0x4f7178,_0x210fe2);}return V(_0x8198de['eventQueue_'],_0x4ded43['_path'],_0x10d058),An(_0x8198de['serverSyncTree_'],_0x4ded43,_0x1ae6f5,null,!0x0),_0x4f7178;},_0x58a8f0=>(gt(_0x8198de,'get\x20for\x20query\x20'+O(_0x4ded43)+'\x20failed:\x20'+_0x58a8f0),Promise['reject'](new Error(_0x58a8f0))));}function Cd(_0x371127,_0x3d73b3,_0x348a0f,_0x5f560d,_0x543856){gt(_0x371127,'set',{'path':_0x3d73b3['toString'](),'value':_0x348a0f,'priority':_0x5f560d});const _0x37ad84=Xt(_0x371127),_0x1736ed=A(_0x348a0f,_0x5f560d),_0xc7c20d=Vn(_0x371127['serverSyncTree_'],_0x3d73b3),_0xb99e98=fs(_0x1736ed,_0xc7c20d,_0x37ad84),_0xe8ab93=zn(_0x371127),_0x1a6570=as(_0x371127['serverSyncTree_'],_0x3d73b3,_0xb99e98,_0xe8ab93,!0x0);qn(_0x371127['eventQueue_'],_0x1a6570),_0x371127['server_']['put'](_0x3d73b3['toString'](),_0x1736ed['val'](!0x0),(_0x5019c8,_0x2557b5)=>{const _0x16d7f0=_0x5019c8==='ok';_0x16d7f0||U('set\x20at\x20'+_0x3d73b3+'\x20failed:\x20'+_0x5019c8);const _0x4d7283=_e(_0x371127['serverSyncTree_'],_0xe8ab93,!_0x16d7f0);V(_0x371127['eventQueue_'],_0x3d73b3,_0x4d7283),be(_0x371127,_0x543856,_0x5019c8,_0x2557b5);});const _0x48ae37=Is(_0x371127,_0x3d73b3);ct(_0x371127,_0x48ae37),V(_0x371127['eventQueue_'],_0x48ae37,[]);}function Td(_0x4cb2d1,_0x56cc8a,_0x2a6ee9,_0x5ac66c){gt(_0x4cb2d1,'update',{'path':_0x56cc8a['toString'](),'value':_0x2a6ee9});let _0x18d0b3=!0x0;const _0x2b6c0e=Xt(_0x4cb2d1),_0x10312c={};if(x(_0x2a6ee9,(_0x6ac767,_0x4f36dd)=>{_0x18d0b3=!0x1,_0x10312c[_0x6ac767]=ta(k(_0x56cc8a,_0x6ac767),A(_0x4f36dd),_0x4cb2d1['serverSyncTree_'],_0x2b6c0e);}),_0x18d0b3)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4cb2d1,_0x5ac66c,'ok',void 0x0);else{const _0x1ca197=zn(_0x4cb2d1),_0x1950fc=ju(_0x4cb2d1['serverSyncTree_'],_0x56cc8a,_0x10312c,_0x1ca197);qn(_0x4cb2d1['eventQueue_'],_0x1950fc),_0x4cb2d1['server_']['merge'](_0x56cc8a['toString'](),_0x2a6ee9,(_0x844276,_0x1c19c7)=>{const _0xd5e20f=_0x844276==='ok';_0xd5e20f||U('update\x20at\x20'+_0x56cc8a+'\x20failed:\x20'+_0x844276);const _0x10247b=_e(_0x4cb2d1['serverSyncTree_'],_0x1ca197,!_0xd5e20f),_0x593d61=_0x10247b['length']>0x0?ct(_0x4cb2d1,_0x56cc8a):_0x56cc8a;V(_0x4cb2d1['eventQueue_'],_0x593d61,_0x10247b),be(_0x4cb2d1,_0x5ac66c,_0x844276,_0x1c19c7);}),x(_0x2a6ee9,_0x3a9866=>{const _0x5ee003=Is(_0x4cb2d1,k(_0x56cc8a,_0x3a9866));ct(_0x4cb2d1,_0x5ee003);}),V(_0x4cb2d1['eventQueue_'],_0x56cc8a,[]);}}function Sd(_0xdd2312){gt(_0xdd2312,'onDisconnectEvents');const _0x10d721=Xt(_0xdd2312),_0x25c91c=En();Si(_0xdd2312['onDisconnect_'],w(),(_0x18ce3f,_0x9dd5fc)=>{const _0x57e9dd=ta(_0x18ce3f,_0x9dd5fc,_0xdd2312['serverSyncTree_'],_0x10d721);pt(_0x25c91c,_0x18ce3f,_0x57e9dd);});let _0x1e2004=[];Si(_0x25c91c,w(),(_0x57097d,_0x11b9e5)=>{_0x1e2004=_0x1e2004['concat'](Yt(_0xdd2312['serverSyncTree_'],_0x57097d,_0x11b9e5));const _0x577ba3=Is(_0xdd2312,_0x57097d);ct(_0xdd2312,_0x577ba3);}),_0xdd2312['onDisconnect_']=En(),V(_0xdd2312['eventQueue_'],w(),_0x1e2004);}function bd(_0x1f5c4d,_0x1f4b56,_0x9c1519){_0x1f5c4d['server_']['onDisconnectCancel'](_0x1f4b56['toString'](),(_0xfb5139,_0x25722d)=>{_0xfb5139==='ok'&&Ti(_0x1f5c4d['onDisconnect_'],_0x1f4b56),be(_0x1f5c4d,_0x9c1519,_0xfb5139,_0x25722d);});}function yr(_0x4b4178,_0x590d87,_0x2d3690,_0x532f2d){const _0x390b1c=A(_0x2d3690);_0x4b4178['server_']['onDisconnectPut'](_0x590d87['toString'](),_0x390b1c['val'](!0x0),(_0x4e48a8,_0xedc971)=>{_0x4e48a8==='ok'&&pt(_0x4b4178['onDisconnect_'],_0x590d87,_0x390b1c),be(_0x4b4178,_0x532f2d,_0x4e48a8,_0xedc971);});}function Rd(_0xa925b3,_0x110914,_0x19c30e,_0x341f06,_0x382af9){const _0x3f1417=A(_0x19c30e,_0x341f06);_0xa925b3['server_']['onDisconnectPut'](_0x110914['toString'](),_0x3f1417['val'](!0x0),(_0x3f0b17,_0x3c01fb)=>{_0x3f0b17==='ok'&&pt(_0xa925b3['onDisconnect_'],_0x110914,_0x3f1417),be(_0xa925b3,_0x382af9,_0x3f0b17,_0x3c01fb);});}function Ad(_0x2ba442,_0x52fa99,_0x4904fe,_0x311417){if(pn(_0x4904fe)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2ba442,_0x311417,'ok',void 0x0);return;}_0x2ba442['server_']['onDisconnectMerge'](_0x52fa99['toString'](),_0x4904fe,(_0x37574c,_0x2b75b4)=>{_0x37574c==='ok'&&x(_0x4904fe,(_0x2eb47f,_0x2788e7)=>{const _0x4727fb=A(_0x2788e7);pt(_0x2ba442['onDisconnect_'],k(_0x52fa99,_0x2eb47f),_0x4727fb);}),be(_0x2ba442,_0x311417,_0x37574c,_0x2b75b4);});}function kd(_0x44b94e,_0x442b86,_0xd4babf){let _0x3836e6;y(_0x442b86['_path'])==='.info'?_0x3836e6=Ni(_0x44b94e['infoSyncTree_'],_0x442b86,_0xd4babf):_0x3836e6=Ni(_0x44b94e['serverSyncTree_'],_0x442b86,_0xd4babf),oa(_0x44b94e['eventQueue_'],_0x442b86['_path'],_0x3836e6);}function Pd(_0x18ca71,_0x193324,_0x542351){let _0xe2782f;y(_0x193324['_path'])==='.info'?_0xe2782f=An(_0x18ca71['infoSyncTree_'],_0x193324,_0x542351):_0xe2782f=An(_0x18ca71['serverSyncTree_'],_0x193324,_0x542351),oa(_0x18ca71['eventQueue_'],_0x193324['_path'],_0xe2782f);}function ha(_0x4f41d6){_0x4f41d6['persistentConnection_']&&_0x4f41d6['persistentConnection_']['interrupt'](ca);}function Nd(_0x25a5af){_0x25a5af['persistentConnection_']&&_0x25a5af['persistentConnection_']['resume'](ca);}function gt(_0x47c662,..._0x4598cd){let _0x274b67='';_0x47c662['persistentConnection_']&&(_0x274b67=_0x47c662['persistentConnection_']['id']+':'),L(_0x274b67,..._0x4598cd);}function be(_0x2ad000,_0x278017,_0x3ff1b3,_0x1059d5){_0x278017&&ft(()=>{if(_0x3ff1b3==='ok')_0x278017(null);else{const _0x2ff562=(_0x3ff1b3||'error')['toUpperCase']();let _0x1636cf=_0x2ff562;_0x1059d5&&(_0x1636cf+=':\x20'+_0x1059d5);const _0x1e92ad=new Error(_0x1636cf);_0x1e92ad['code']=_0x2ff562,_0x278017(_0x1e92ad);}});}function Od(_0x362150,_0x865d34,_0x4e83ad,_0x2f8de3,_0x45ccd0,_0x525627){gt(_0x362150,'transaction\x20on\x20'+_0x865d34);const _0x4dd2b3={'path':_0x865d34,'update':_0x4e83ad,'onComplete':_0x2f8de3,'status':null,'order':so(),'applyLocally':_0x525627,'retryCount':0x0,'unwatcher':_0x45ccd0,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2b02ac=Es(_0x362150,_0x865d34,void 0x0);_0x4dd2b3['currentInputSnapshot']=_0x2b02ac;const _0x5cb054=_0x4dd2b3['update'](_0x2b02ac['val']());if(_0x5cb054===void 0x0)_0x4dd2b3['unwatcher'](),_0x4dd2b3['currentOutputSnapshotRaw']=null,_0x4dd2b3['currentOutputSnapshotResolved']=null,_0x4dd2b3['onComplete']&&_0x4dd2b3['onComplete'](null,!0x1,_0x4dd2b3['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5cb054,_0x4dd2b3['path']),_0x4dd2b3['status']=0x0;const _0x2c1274=$n(_0x362150['transactionQueueTree_'],_0x865d34),_0x388d29=je(_0x2c1274)||[];_0x388d29['push'](_0x4dd2b3),gs(_0x2c1274,_0x388d29);let _0x397dc9;typeof _0x5cb054=='object'&&_0x5cb054!==null&&Q(_0x5cb054,'.priority')?(_0x397dc9=Le(_0x5cb054,'.priority'),f(Bt(_0x397dc9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x397dc9=(Vn(_0x362150['serverSyncTree_'],_0x865d34)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x110195=Xt(_0x362150),_0x2dad9f=A(_0x5cb054,_0x397dc9),_0x3d1d9f=fs(_0x2dad9f,_0x2b02ac,_0x110195);_0x4dd2b3['currentOutputSnapshotRaw']=_0x2dad9f,_0x4dd2b3['currentOutputSnapshotResolved']=_0x3d1d9f,_0x4dd2b3['currentWriteId']=zn(_0x362150);const _0x14c8c6=as(_0x362150['serverSyncTree_'],_0x865d34,_0x3d1d9f,_0x4dd2b3['currentWriteId'],_0x4dd2b3['applyLocally']);V(_0x362150['eventQueue_'],_0x865d34,_0x14c8c6),jn(_0x362150,_0x362150['transactionQueueTree_']);}}function Es(_0x59a751,_0x14606a,_0x2e196a){return Vn(_0x59a751['serverSyncTree_'],_0x14606a,_0x2e196a)||g['EMPTY_NODE'];}function jn(_0xa4bd35,_0x27818d=_0xa4bd35['transactionQueueTree_']){if(_0x27818d||Kn(_0xa4bd35,_0x27818d),je(_0x27818d)){const _0x55e547=da(_0xa4bd35,_0x27818d);f(_0x55e547['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x55e547['every'](_0x2861b5=>_0x2861b5['status']===0x0)&&Dd(_0xa4bd35,Qt(_0x27818d),_0x55e547);}else na(_0x27818d)&&Gn(_0x27818d,_0x303ef9=>{jn(_0xa4bd35,_0x303ef9);});}function Dd(_0x4b2429,_0x1cbab7,_0x2bff1a){const _0x389cb3=_0x2bff1a['map'](_0x140204=>_0x140204['currentWriteId']),_0x2a029a=Es(_0x4b2429,_0x1cbab7,_0x389cb3);let _0x4e6624=_0x2a029a;const _0x286d81=_0x2a029a['hash']();for(let _0x476898=0x0;_0x476898<_0x2bff1a['length'];_0x476898++){const _0x26192d=_0x2bff1a[_0x476898];f(_0x26192d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x26192d['status']=0x1,_0x26192d['retryCount']++;const _0x521fd1=F(_0x1cbab7,_0x26192d['path']);_0x4e6624=_0x4e6624['updateChild'](_0x521fd1,_0x26192d['currentOutputSnapshotRaw']);}const _0x14b6d4=_0x4e6624['val'](!0x0),_0x4ea40a=_0x1cbab7;_0x4b2429['server_']['put'](_0x4ea40a['toString'](),_0x14b6d4,_0xa7d743=>{gt(_0x4b2429,'transaction\x20put\x20response',{'path':_0x4ea40a['toString'](),'status':_0xa7d743});let _0x44e7fa=[];if(_0xa7d743==='ok'){const _0x2d8967=[];for(let _0x318bc6=0x0;_0x318bc6<_0x2bff1a['length'];_0x318bc6++)_0x2bff1a[_0x318bc6]['status']=0x2,_0x44e7fa=_0x44e7fa['concat'](_e(_0x4b2429['serverSyncTree_'],_0x2bff1a[_0x318bc6]['currentWriteId'])),_0x2bff1a[_0x318bc6]['onComplete']&&_0x2d8967['push'](()=>_0x2bff1a[_0x318bc6]['onComplete'](null,!0x0,_0x2bff1a[_0x318bc6]['currentOutputSnapshotResolved'])),_0x2bff1a[_0x318bc6]['unwatcher']();Kn(_0x4b2429,$n(_0x4b2429['transactionQueueTree_'],_0x1cbab7)),jn(_0x4b2429,_0x4b2429['transactionQueueTree_']),V(_0x4b2429['eventQueue_'],_0x1cbab7,_0x44e7fa);for(let _0x113c92=0x0;_0x113c92<_0x2d8967['length'];_0x113c92++)ft(_0x2d8967[_0x113c92]);}else{if(_0xa7d743==='datastale'){for(let _0x1fea7f=0x0;_0x1fea7f<_0x2bff1a['length'];_0x1fea7f++)_0x2bff1a[_0x1fea7f]['status']===0x3?_0x2bff1a[_0x1fea7f]['status']=0x4:_0x2bff1a[_0x1fea7f]['status']=0x0;}else{U('transaction\x20at\x20'+_0x4ea40a['toString']()+'\x20failed:\x20'+_0xa7d743);for(let _0x1eb718=0x0;_0x1eb718<_0x2bff1a['length'];_0x1eb718++)_0x2bff1a[_0x1eb718]['status']=0x4,_0x2bff1a[_0x1eb718]['abortReason']=_0xa7d743;}ct(_0x4b2429,_0x1cbab7);}},_0x286d81);}function ct(_0x115f7c,_0x396280){const _0x35949e=ua(_0x115f7c,_0x396280),_0xd1168d=Qt(_0x35949e),_0x27b7a7=da(_0x115f7c,_0x35949e);return Md(_0x115f7c,_0x27b7a7,_0xd1168d),_0xd1168d;}function Md(_0x21ded3,_0x4002bc,_0xe689a4){if(_0x4002bc['length']===0x0)return;const _0x97ee44=[];let _0x462300=[];const _0x4cf19e=_0x4002bc['filter'](_0x359088=>_0x359088['status']===0x0)['map'](_0x24c338=>_0x24c338['currentWriteId']);for(let _0x389edc=0x0;_0x389edc<_0x4002bc['length'];_0x389edc++){const _0xdb864d=_0x4002bc[_0x389edc],_0x2cbbd3=F(_0xe689a4,_0xdb864d['path']);let _0x527822=!0x1,_0x2269eb;if(f(_0x2cbbd3!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xdb864d['status']===0x4)_0x527822=!0x0,_0x2269eb=_0xdb864d['abortReason'],_0x462300=_0x462300['concat'](_e(_0x21ded3['serverSyncTree_'],_0xdb864d['currentWriteId'],!0x0));else{if(_0xdb864d['status']===0x0){if(_0xdb864d['retryCount']>=yd)_0x527822=!0x0,_0x2269eb='maxretry',_0x462300=_0x462300['concat'](_e(_0x21ded3['serverSyncTree_'],_0xdb864d['currentWriteId'],!0x0));else{const _0x5e0474=Es(_0x21ded3,_0xdb864d['path'],_0x4cf19e);_0xdb864d['currentInputSnapshot']=_0x5e0474;const _0x306207=_0x4002bc[_0x389edc]['update'](_0x5e0474['val']());if(_0x306207!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x306207,_0xdb864d['path']);let _0x4eb5cd=A(_0x306207);typeof _0x306207=='object'&&_0x306207!=null&&Q(_0x306207,'.priority')||(_0x4eb5cd=_0x4eb5cd['updatePriority'](_0x5e0474['getPriority']()));const _0x567673=_0xdb864d['currentWriteId'],_0x20f1a4=Xt(_0x21ded3),_0xdd0cb=fs(_0x4eb5cd,_0x5e0474,_0x20f1a4);_0xdb864d['currentOutputSnapshotRaw']=_0x4eb5cd,_0xdb864d['currentOutputSnapshotResolved']=_0xdd0cb,_0xdb864d['currentWriteId']=zn(_0x21ded3),_0x4cf19e['splice'](_0x4cf19e['indexOf'](_0x567673),0x1),_0x462300=_0x462300['concat'](as(_0x21ded3['serverSyncTree_'],_0xdb864d['path'],_0xdd0cb,_0xdb864d['currentWriteId'],_0xdb864d['applyLocally'])),_0x462300=_0x462300['concat'](_e(_0x21ded3['serverSyncTree_'],_0x567673,!0x0));}else _0x527822=!0x0,_0x2269eb='nodata',_0x462300=_0x462300['concat'](_e(_0x21ded3['serverSyncTree_'],_0xdb864d['currentWriteId'],!0x0));}}}V(_0x21ded3['eventQueue_'],_0xe689a4,_0x462300),_0x462300=[],_0x527822&&(_0x4002bc[_0x389edc]['status']=0x2,function(_0x151c3f){setTimeout(_0x151c3f,Math['floor'](0x0));}(_0x4002bc[_0x389edc]['unwatcher']),_0x4002bc[_0x389edc]['onComplete']&&(_0x2269eb==='nodata'?_0x97ee44['push'](()=>_0x4002bc[_0x389edc]['onComplete'](null,!0x1,_0x4002bc[_0x389edc]['currentInputSnapshot'])):_0x97ee44['push'](()=>_0x4002bc[_0x389edc]['onComplete'](new Error(_0x2269eb),!0x1,null))));}Kn(_0x21ded3,_0x21ded3['transactionQueueTree_']);for(let _0x270e90=0x0;_0x270e90<_0x97ee44['length'];_0x270e90++)ft(_0x97ee44[_0x270e90]);jn(_0x21ded3,_0x21ded3['transactionQueueTree_']);}function ua(_0x269554,_0x2c4a53){let _0x21a804,_0x2be233=_0x269554['transactionQueueTree_'];for(_0x21a804=y(_0x2c4a53);_0x21a804!==null&&je(_0x2be233)===void 0x0;)_0x2be233=$n(_0x2be233,_0x21a804),_0x2c4a53=S(_0x2c4a53),_0x21a804=y(_0x2c4a53);return _0x2be233;}function da(_0x1c9201,_0x90d71f){const _0xd16fdc=[];return fa(_0x1c9201,_0x90d71f,_0xd16fdc),_0xd16fdc['sort']((_0x49bcad,_0x4e0ea2)=>_0x49bcad['order']-_0x4e0ea2['order']),_0xd16fdc;}function fa(_0x148483,_0x4ae569,_0x40c56d){const _0x27ea1=je(_0x4ae569);if(_0x27ea1){for(let _0x3a55ef=0x0;_0x3a55ef<_0x27ea1['length'];_0x3a55ef++)_0x40c56d['push'](_0x27ea1[_0x3a55ef]);}Gn(_0x4ae569,_0x433b27=>{fa(_0x148483,_0x433b27,_0x40c56d);});}function Kn(_0xc443b2,_0x548fc3){const _0x2ea690=je(_0x548fc3);if(_0x2ea690){let _0x6b4c87=0x0;for(let _0x83f2a9=0x0;_0x83f2a9<_0x2ea690['length'];_0x83f2a9++)_0x2ea690[_0x83f2a9]['status']!==0x2&&(_0x2ea690[_0x6b4c87]=_0x2ea690[_0x83f2a9],_0x6b4c87++);_0x2ea690['length']=_0x6b4c87,gs(_0x548fc3,_0x2ea690['length']>0x0?_0x2ea690:void 0x0);}Gn(_0x548fc3,_0x1786de=>{Kn(_0xc443b2,_0x1786de);});}function Is(_0x10886b,_0x3ed8aa){const _0x4e50cb=Qt(ua(_0x10886b,_0x3ed8aa)),_0x530d6d=$n(_0x10886b['transactionQueueTree_'],_0x3ed8aa);return ad(_0x530d6d,_0x2eb980=>{di(_0x10886b,_0x2eb980);}),di(_0x10886b,_0x530d6d),ia(_0x530d6d,_0x5af4f8=>{di(_0x10886b,_0x5af4f8);}),_0x4e50cb;}function di(_0x3c3510,_0x4692d7){const _0x27746a=je(_0x4692d7);if(_0x27746a){const _0x6614de=[];let _0x2c4cda=[],_0x562ed3=-0x1;for(let _0x236f0c=0x0;_0x236f0c<_0x27746a['length'];_0x236f0c++)_0x27746a[_0x236f0c]['status']===0x3||(_0x27746a[_0x236f0c]['status']===0x1?(f(_0x562ed3===_0x236f0c-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x562ed3=_0x236f0c,_0x27746a[_0x236f0c]['status']=0x3,_0x27746a[_0x236f0c]['abortReason']='set'):(f(_0x27746a[_0x236f0c]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x27746a[_0x236f0c]['unwatcher'](),_0x2c4cda=_0x2c4cda['concat'](_e(_0x3c3510['serverSyncTree_'],_0x27746a[_0x236f0c]['currentWriteId'],!0x0)),_0x27746a[_0x236f0c]['onComplete']&&_0x6614de['push'](_0x27746a[_0x236f0c]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x562ed3===-0x1?gs(_0x4692d7,void 0x0):_0x27746a['length']=_0x562ed3+0x1,V(_0x3c3510['eventQueue_'],Qt(_0x4692d7),_0x2c4cda);for(let _0x50096f=0x0;_0x50096f<_0x6614de['length'];_0x50096f++)ft(_0x6614de[_0x50096f]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x191152){let _0x4a7e34='';const _0x24256e=_0x191152['split']('/');for(let _0xefb760=0x0;_0xefb760<_0x24256e['length'];_0xefb760++)if(_0x24256e[_0xefb760]['length']>0x0){let _0x3cbfa5=_0x24256e[_0xefb760];try{_0x3cbfa5=decodeURIComponent(_0x3cbfa5['replace'](/\+/g,'\x20'));}catch{}_0x4a7e34+='/'+_0x3cbfa5;}return _0x4a7e34;}function xd(_0x1d2eac){const _0x9c31ae={};_0x1d2eac['charAt'](0x0)==='?'&&(_0x1d2eac=_0x1d2eac['substring'](0x1));for(const _0x197f9d of _0x1d2eac['split']('&')){if(_0x197f9d['length']===0x0)continue;const _0x37cb2a=_0x197f9d['split']('=');_0x37cb2a['length']===0x2?_0x9c31ae[decodeURIComponent(_0x37cb2a[0x0])]=decodeURIComponent(_0x37cb2a[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x197f9d+'\x27\x20in\x20query\x20\x27'+_0x1d2eac+'\x27');}return _0x9c31ae;}const vr=function(_0xcb6296,_0x456268){const _0x4450b7=Fd(_0xcb6296),_0x46901a=_0x4450b7['namespace'];_0x4450b7['domain']==='firebase.com'&&ae(_0x4450b7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x46901a||_0x46901a==='undefined')&&_0x4450b7['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4450b7['secure']||$l();const _0x535531=_0x4450b7['scheme']==='ws'||_0x4450b7['scheme']==='wss';return{'repoInfo':new yo(_0x4450b7['host'],_0x4450b7['secure'],_0x46901a,_0x535531,_0x456268,'',_0x46901a!==_0x4450b7['subdomain']),'path':new C(_0x4450b7['pathString'])};},Fd=function(_0x208052){let _0x22626c='',_0xb536b9='',_0x2e319a='',_0x159f45='',_0x14398f='',_0x500ad9=!0x0,_0x349daf='https',_0x3d3cfd=0x1bb;if(typeof _0x208052=='string'){let _0x4217f2=_0x208052['indexOf']('//');_0x4217f2>=0x0&&(_0x349daf=_0x208052['substring'](0x0,_0x4217f2-0x1),_0x208052=_0x208052['substring'](_0x4217f2+0x2));let _0x200aac=_0x208052['indexOf']('/');_0x200aac===-0x1&&(_0x200aac=_0x208052['length']);let _0x336369=_0x208052['indexOf']('?');_0x336369===-0x1&&(_0x336369=_0x208052['length']),_0x22626c=_0x208052['substring'](0x0,Math['min'](_0x200aac,_0x336369)),_0x200aac<_0x336369&&(_0x159f45=Ld(_0x208052['substring'](_0x200aac,_0x336369)));const _0x23f189=xd(_0x208052['substring'](Math['min'](_0x208052['length'],_0x336369)));_0x4217f2=_0x22626c['indexOf'](':'),_0x4217f2>=0x0?(_0x500ad9=_0x349daf==='https'||_0x349daf==='wss',_0x3d3cfd=parseInt(_0x22626c['substring'](_0x4217f2+0x1),0xa)):_0x4217f2=_0x22626c['length'];const _0x346640=_0x22626c['slice'](0x0,_0x4217f2);if(_0x346640['toLowerCase']()==='localhost')_0xb536b9='localhost';else{if(_0x346640['split']('.')['length']<=0x2)_0xb536b9=_0x346640;else{const _0x1bb856=_0x22626c['indexOf']('.');_0x2e319a=_0x22626c['substring'](0x0,_0x1bb856)['toLowerCase'](),_0xb536b9=_0x22626c['substring'](_0x1bb856+0x1),_0x14398f=_0x2e319a;}}'ns'in _0x23f189&&(_0x14398f=_0x23f189['ns']);}return{'host':_0x22626c,'port':_0x3d3cfd,'domain':_0xb536b9,'subdomain':_0x2e319a,'secure':_0x500ad9,'scheme':_0x349daf,'pathString':_0x159f45,'namespace':_0x14398f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x5c5a1f=0x0;const _0x2293c1=[];return function(_0x46d989){const _0x3a357b=_0x46d989===_0x5c5a1f;_0x5c5a1f=_0x46d989;let _0x5201ad;const _0xb9d2a6=new Array(0x8);for(_0x5201ad=0x7;_0x5201ad>=0x0;_0x5201ad--)_0xb9d2a6[_0x5201ad]=Er['charAt'](_0x46d989%0x40),_0x46d989=Math['floor'](_0x46d989/0x40);f(_0x46d989===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x37fd3c=_0xb9d2a6['join']('');if(_0x3a357b){for(_0x5201ad=0xb;_0x5201ad>=0x0&&_0x2293c1[_0x5201ad]===0x3f;_0x5201ad--)_0x2293c1[_0x5201ad]=0x0;_0x2293c1[_0x5201ad]++;}else{for(_0x5201ad=0x0;_0x5201ad<0xc;_0x5201ad++)_0x2293c1[_0x5201ad]=Math['floor'](Math['random']()*0x40);}for(_0x5201ad=0x0;_0x5201ad<0xc;_0x5201ad++)_0x37fd3c+=Er['charAt'](_0x2293c1[_0x5201ad]);return f(_0x37fd3c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x37fd3c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x22fea2,_0x4bd7d5,_0x3d9c67,_0x355dfc){this['eventType']=_0x22fea2,this['eventRegistration']=_0x4bd7d5,this['snapshot']=_0x3d9c67,this['prevName']=_0x355dfc;}['getPath'](){const _0x4c7362=this['snapshot']['ref'];return this['eventType']==='value'?_0x4c7362['_path']:_0x4c7362['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x388cf6,_0x5f2abf,_0x1218c5){this['eventRegistration']=_0x388cf6,this['error']=_0x5f2abf,this['path']=_0x1218c5;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3c251b,_0x50a35d){this['snapshotCallback']=_0x3c251b,this['cancelCallback']=_0x50a35d;}['onValue'](_0x238ad4,_0x5ddc98){this['snapshotCallback']['call'](null,_0x238ad4,_0x5ddc98);}['onCancel'](_0xaa6117){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xaa6117);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2f1045){return this['snapshotCallback']===_0x2f1045['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2f1045['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2f1045['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x52602f,_0x226bfe){this['_repo']=_0x52602f,this['_path']=_0x226bfe;}['cancel'](){const _0x3f7874=new H();return bd(this['_repo'],this['_path'],_0x3f7874['wrapCallback'](()=>{})),_0x3f7874['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x8b9e0b=new H();return yr(this['_repo'],this['_path'],null,_0x8b9e0b['wrapCallback'](()=>{})),_0x8b9e0b['promise'];}['set'](_0x1eb98f){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x1eb98f,this['_path'],!0x1);const _0x48535d=new H();return yr(this['_repo'],this['_path'],_0x1eb98f,_0x48535d['wrapCallback'](()=>{})),_0x48535d['promise'];}['setWithPriority'](_0x1993cb,_0x1fb6da){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x1993cb,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1fb6da);const _0x43a147=new H();return Rd(this['_repo'],this['_path'],_0x1993cb,_0x1fb6da,_0x43a147['wrapCallback'](()=>{})),_0x43a147['promise'];}['update'](_0x515c32){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x515c32,this['_path']);const _0xfb6f63=new H();return Ad(this['_repo'],this['_path'],_0x515c32,_0xfb6f63['wrapCallback'](()=>{})),_0xfb6f63['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x3670fa,_0x2ed576,_0x519085,_0x8a00fc){this['_repo']=_0x3670fa,this['_path']=_0x2ed576,this['_queryParams']=_0x519085,this['_orderByCalled']=_0x8a00fc;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3abc0a=sr(this['_queryParams']),_0x381be1=$i(_0x3abc0a);return _0x381be1==='{}'?'default':_0x381be1;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1c7f15){if(_0x1c7f15=P(_0x1c7f15),!(_0x1c7f15 instanceof Ae))return!0x1;const _0x5b1d3a=this['_repo']===_0x1c7f15['_repo'],_0x3b1eef=Ki(this['_path'],_0x1c7f15['_path']),_0x1823d7=this['_queryIdentifier']===_0x1c7f15['_queryIdentifier'];return _0x5b1d3a&&_0x3b1eef&&_0x1823d7;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x16110e,_0x37cfc2){if(_0x16110e['_orderByCalled']===!0x0)throw new Error(_0x37cfc2+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1ef8ee){let _0x2525e7=null,_0x6cdb44=null;if(_0x1ef8ee['hasStart']()&&(_0x2525e7=_0x1ef8ee['getIndexStartValue']()),_0x1ef8ee['hasEnd']()&&(_0x6cdb44=_0x1ef8ee['getIndexEndValue']()),_0x1ef8ee['getIndex']()===ve){const _0x495d9a='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4f39fc='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1ef8ee['hasStart']()){if(_0x1ef8ee['getIndexStartName']()!==We)throw new Error(_0x495d9a);if(typeof _0x2525e7!='string')throw new Error(_0x4f39fc);}if(_0x1ef8ee['hasEnd']()){if(_0x1ef8ee['getIndexEndName']()!==we)throw new Error(_0x495d9a);if(typeof _0x6cdb44!='string')throw new Error(_0x4f39fc);}}else{if(_0x1ef8ee['getIndex']()===R){if(_0x2525e7!=null&&!Bt(_0x2525e7)||_0x6cdb44!=null&&!Bt(_0x6cdb44))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1ef8ee['getIndex']()instanceof Ji||_0x1ef8ee['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2525e7!=null&&typeof _0x2525e7=='object'||_0x6cdb44!=null&&typeof _0x6cdb44=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4712b1){if(_0x4712b1['hasStart']()&&_0x4712b1['hasEnd']()&&_0x4712b1['hasLimit']()&&!_0x4712b1['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x2a386a,_0x550cd0){super(_0x2a386a,_0x550cd0,new Zi(),!0x1);}get['parent'](){const _0x30ddd3=Ro(this['_path']);return _0x30ddd3===null?null:new ee(this['_repo'],_0x30ddd3);}get['root'](){let _0xd17ca6=this;for(;_0xd17ca6['parent']!==null;)_0xd17ca6=_0xd17ca6['parent'];return _0xd17ca6;}}class lt{constructor(_0x1a3b6d,_0x1bdfd1,_0x46d651){this['_node']=_0x1a3b6d,this['ref']=_0x1bdfd1,this['_index']=_0x46d651;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x32d05a){const _0x21f1c2=new C(_0x32d05a),_0x597fdf=Vt(this['ref'],_0x32d05a);return new lt(this['_node']['getChild'](_0x21f1c2),_0x597fdf,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xfa17c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1a4145,_0x4f2aeb)=>_0xfa17c(new lt(_0x4f2aeb,Vt(this['ref'],_0x1a4145),R)));}['hasChild'](_0x5a107e){const _0x6a7233=new C(_0x5a107e);return!this['_node']['getChild'](_0x6a7233)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1c744f,_0x7d2d74){return _0x1c744f=P(_0x1c744f),_0x1c744f['_checkNotDeleted']('ref'),_0x7d2d74!==void 0x0?Vt(_0x1c744f['_root'],_0x7d2d74):_0x1c744f['_root'];}function Vt(_0x4e7ef9,_0x52ff7e){return _0x4e7ef9=P(_0x4e7ef9),y(_0x4e7ef9['_path'])===null?pd('child','path',_0x52ff7e):ys('child','path',_0x52ff7e),new ee(_0x4e7ef9['_repo'],k(_0x4e7ef9['_path'],_0x52ff7e));}function v_(_0x51df31){return _0x51df31=P(_0x51df31),new Vd(_0x51df31['_repo'],_0x51df31['_path']);}function E_(_0x20bccd,_0x5d3d28){_0x20bccd=P(_0x20bccd),Me('push',_0x20bccd['_path']),He('push',_0x5d3d28,_0x20bccd['_path'],!0x0);const _0x4621c9=la(_0x20bccd['_repo']),_0x5afa07=Ud(_0x4621c9),_0x8ddcc7=Vt(_0x20bccd,_0x5afa07),_0x4f1d8b=Vt(_0x20bccd,_0x5afa07);let _0x320a51;return _0x5d3d28!=null?_0x320a51=Hd(_0x4f1d8b,_0x5d3d28)['then'](()=>_0x4f1d8b):_0x320a51=Promise['resolve'](_0x4f1d8b),_0x8ddcc7['then']=_0x320a51['then']['bind'](_0x320a51),_0x8ddcc7['catch']=_0x320a51['then']['bind'](_0x320a51,void 0x0),_0x8ddcc7;}function Hd(_0x5eae20,_0x1efc24){_0x5eae20=P(_0x5eae20),Me('set',_0x5eae20['_path']),He('set',_0x1efc24,_0x5eae20['_path'],!0x1);const _0x2c6374=new H();return Cd(_0x5eae20['_repo'],_0x5eae20['_path'],_0x1efc24,null,_0x2c6374['wrapCallback'](()=>{})),_0x2c6374['promise'];}function I_(_0x286938,_0x13c23a){ra('update',_0x13c23a,_0x286938['_path']);const _0x2a202f=new H();return Td(_0x286938['_repo'],_0x286938['_path'],_0x13c23a,_0x2a202f['wrapCallback'](()=>{})),_0x2a202f['promise'];}function w_(_0x34c085){_0x34c085=P(_0x34c085);const _0x252e66=new pa(()=>{}),_0x5c639f=new Qn(_0x252e66);return wd(_0x34c085['_repo'],_0x34c085,_0x5c639f)['then'](_0x4667cd=>new lt(_0x4667cd,new ee(_0x34c085['_repo'],_0x34c085['_path']),_0x34c085['_queryParams']['getIndex']()));}class Qn{constructor(_0x37e24f){this['callbackContext']=_0x37e24f;}['respondsTo'](_0x24d0e2){return _0x24d0e2==='value';}['createEvent'](_0x534dd8,_0x33846f){const _0xebac28=_0x33846f['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x534dd8['snapshotNode'],new ee(_0x33846f['_repo'],_0x33846f['_path']),_0xebac28));}['getEventRunner'](_0x45e8a0){return _0x45e8a0['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x45e8a0['error']):()=>this['callbackContext']['onValue'](_0x45e8a0['snapshot'],null);}['createCancelEvent'](_0x51d2c5,_0xb8844d){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x51d2c5,_0xb8844d):null;}['matches'](_0x373986){return _0x373986 instanceof Qn?!_0x373986['callbackContext']||!this['callbackContext']?!0x0:_0x373986['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x3a6d8a,_0x7c566c,_0x4f019f,_0xdbd92e,_0x3879f3){const _0x3b25ce=new pa(_0x4f019f,void 0x0),_0x4b4482=new Qn(_0x3b25ce);return kd(_0x3a6d8a['_repo'],_0x3a6d8a,_0x4b4482),()=>Pd(_0x3a6d8a['_repo'],_0x3a6d8a,_0x4b4482);}function Gd(_0x3fd572,_0x322a78,_0x15092a,_0x20903d){return $d(_0x3fd572,'value',_0x322a78);}class mt{}class ma extends mt{constructor(_0x4817d6,_0x3f207f){super(),this['_value']=_0x4817d6,this['_key']=_0x3f207f,this['type']='endAt';}['_apply'](_0x78682f){He('endAt',this['_value'],_0x78682f['_path'],!0x0);const _0x29759f=Jh(_0x78682f['_queryParams'],this['_value'],this['_key']);if(ga(_0x29759f),Yn(_0x29759f),_0x78682f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x78682f['_repo'],_0x78682f['_path'],_0x29759f,_0x78682f['_orderByCalled']);}}function C_(_0xe6dece,_0x3f4f2c){return new ma(_0xe6dece,_0x3f4f2c);}class ya extends mt{constructor(_0x40a025,_0x34513c){super(),this['_value']=_0x40a025,this['_key']=_0x34513c,this['type']='startAt';}['_apply'](_0x51bac7){He('startAt',this['_value'],_0x51bac7['_path'],!0x0);const _0x455b2c=Qh(_0x51bac7['_queryParams'],this['_value'],this['_key']);if(ga(_0x455b2c),Yn(_0x455b2c),_0x51bac7['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x51bac7['_repo'],_0x51bac7['_path'],_0x455b2c,_0x51bac7['_orderByCalled']);}}function T_(_0x430ef0=null,_0x5db878){return new ya(_0x430ef0,_0x5db878);}class qd extends mt{constructor(_0xd127f0){super(),this['_limit']=_0xd127f0,this['type']='limitToFirst';}['_apply'](_0x5d3874){if(_0x5d3874['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x5d3874['_repo'],_0x5d3874['_path'],Yh(_0x5d3874['_queryParams'],this['_limit']),_0x5d3874['_orderByCalled']);}}function S_(_0x1393ce){if(Math['floor'](_0x1393ce)!==_0x1393ce||_0x1393ce<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x1393ce);}class zd extends mt{constructor(_0x4e28a9){super(),this['_path']=_0x4e28a9,this['type']='orderByChild';}['_apply'](_0x23c024){_a(_0x23c024,'orderByChild');const _0x4e2770=new C(this['_path']);if(v(_0x4e2770))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x26ff8b=new Ji(_0x4e2770),_0x5ad24b=xo(_0x23c024['_queryParams'],_0x26ff8b);return Yn(_0x5ad24b),new Ae(_0x23c024['_repo'],_0x23c024['_path'],_0x5ad24b,!0x0);}}function b_(_0x4d383e){if(_0x4d383e==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4d383e==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4d383e==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x4d383e),new zd(_0x4d383e);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x366785){_a(_0x366785,'orderByKey');const _0x5ebcb2=xo(_0x366785['_queryParams'],ve);return Yn(_0x5ebcb2),new Ae(_0x366785['_repo'],_0x366785['_path'],_0x5ebcb2,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x1f30b9,_0x257f96){super(),this['_value']=_0x1f30b9,this['_key']=_0x257f96,this['type']='equalTo';}['_apply'](_0x59e91c){if(He('equalTo',this['_value'],_0x59e91c['_path'],!0x1),_0x59e91c['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x59e91c['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x59e91c));}}function A_(_0x28fb6f,_0x340947){return new Kd(_0x28fb6f,_0x340947);}function k_(_0x1bf93b,..._0x56b1e6){let _0x2ab6d0=P(_0x1bf93b);for(const _0x1947af of _0x56b1e6)_0x2ab6d0=_0x1947af['_apply'](_0x2ab6d0);return _0x2ab6d0;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x213924,_0x2364a6,_0x547960,_0x5b22eb){const _0x313691=_0x2364a6['lastIndexOf'](':'),_0x2e524a=_0x2364a6['substring'](0x0,_0x313691),_0x205dd8=qt(_0x2e524a);_0x213924['repoInfo_']=new yo(_0x2364a6,_0x205dd8,_0x213924['repoInfo_']['namespace'],_0x213924['repoInfo_']['webSocketOnly'],_0x213924['repoInfo_']['nodeAdmin'],_0x213924['repoInfo_']['persistenceKey'],_0x213924['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x547960),_0x5b22eb&&(_0x213924['authTokenProvider_']=_0x5b22eb);}function Xd(_0x19f9f4,_0x5c291a,_0xc953dd,_0x2ef4f9,_0x221eaa){let _0x242872=_0x2ef4f9||_0x19f9f4['options']['databaseURL'];_0x242872===void 0x0&&(_0x19f9f4['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x19f9f4['options']['projectId']),_0x242872=_0x19f9f4['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x302364=vr(_0x242872,_0x221eaa),_0x4b1b65=_0x302364['repoInfo'],_0x528ab5;typeof process<'u'&&Bs&&(_0x528ab5=Bs[Yd]),_0x528ab5?(_0x242872='http://'+_0x528ab5+'?ns='+_0x4b1b65['namespace'],_0x302364=vr(_0x242872,_0x221eaa),_0x4b1b65=_0x302364['repoInfo']):_0x302364['repoInfo']['secure'];const _0x7ac10d=new eh(_0x19f9f4['name'],_0x19f9f4['options'],_0x5c291a);_d('Invalid\x20Firebase\x20Database\x20URL',_0x302364),v(_0x302364['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x323b96=ef(_0x4b1b65,_0x19f9f4,_0x7ac10d,new Zl(_0x19f9f4,_0xc953dd));return new tf(_0x323b96,_0x19f9f4);}function Zd(_0x376219,_0x4306d2){const _0x3a9f94=Di[_0x4306d2];(!_0x3a9f94||_0x3a9f94[_0x376219['key']]!==_0x376219)&&ae('Database\x20'+_0x4306d2+'('+_0x376219['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x376219),delete _0x3a9f94[_0x376219['key']];}function ef(_0x7ce64,_0x273835,_0xe7beac,_0x5100ed){let _0x1be6ef=Di[_0x273835['name']];_0x1be6ef||(_0x1be6ef={},Di[_0x273835['name']]=_0x1be6ef);let _0x5656ae=_0x1be6ef[_0x7ce64['toURLString']()];return _0x5656ae&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x5656ae=new vd(_0x7ce64,Qd,_0xe7beac,_0x5100ed),_0x1be6ef[_0x7ce64['toURLString']()]=_0x5656ae,_0x5656ae;}class tf{constructor(_0x13cef5,_0x323cc9){this['_repoInternal']=_0x13cef5,this['app']=_0x323cc9,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3d431e){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3d431e+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x37ea97=Zr(),_0x4fc3e7){const _0x831583=Hi(_0x37ea97,'database')['getImmediate']({'identifier':_0x4fc3e7});if(!_0x831583['_instanceStarted']){const _0x3eded1=hc('database');_0x3eded1&&nf(_0x831583,..._0x3eded1);}return _0x831583;}function nf(_0x4d5f37,_0x50067b,_0x4d9b8c,_0x419dc7={}){_0x4d5f37=P(_0x4d5f37),_0x4d5f37['_checkNotDeleted']('useEmulator');const _0x337f4b=_0x50067b+':'+_0x4d9b8c,_0x2be393=_0x4d5f37['_repoInternal'];if(_0x4d5f37['_instanceStarted']){if(_0x337f4b===_0x4d5f37['_repoInternal']['repoInfo_']['host']&&xe(_0x419dc7,_0x2be393['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4ee65d;if(_0x2be393['repoInfo_']['nodeAdmin'])_0x419dc7['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4ee65d=new an(an['OWNER']);else{if(_0x419dc7['mockUserToken']){const _0x4b9f7b=typeof _0x419dc7['mockUserToken']=='string'?_0x419dc7['mockUserToken']:uc(_0x419dc7['mockUserToken'],_0x4d5f37['app']['options']['projectId']);_0x4ee65d=new an(_0x4b9f7b);}}qt(_0x50067b)&&Qr(_0x50067b),Jd(_0x2be393,_0x337f4b,_0x419dc7,_0x4ee65d);}function N_(_0x2c6852){_0x2c6852=P(_0x2c6852),_0x2c6852['_checkNotDeleted']('goOffline'),ha(_0x2c6852['_repo']);}function O_(_0x557cee){_0x557cee=P(_0x557cee),_0x557cee['_checkNotDeleted']('goOnline'),Nd(_0x557cee['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x44b43a){Ul(dt),st(new Fe('database',(_0x5dd0c6,{instanceIdentifier:_0x438a6f})=>{const _0xdc63d7=_0x5dd0c6['getProvider']('app')['getImmediate'](),_0x5a94a1=_0x5dd0c6['getProvider']('auth-internal'),_0x19783b=_0x5dd0c6['getProvider']('app-check-internal');return Xd(_0xdc63d7,_0x5a94a1,_0x19783b,_0x438a6f);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x44b43a),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x193e7d,_0x42ea3c){this['committed']=_0x193e7d,this['snapshot']=_0x42ea3c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x18267f,_0xdcfcae,_0x3c6b67){if(_0x18267f=P(_0x18267f),Me('Reference.transaction',_0x18267f['_path']),_0x18267f['key']==='.length'||_0x18267f['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x18267f['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1470e3=!0x0,_0x1dda59=new H(),_0x477bd2=(_0x26e837,_0x34bf14,_0x356e17)=>{let _0xbf3228=null;_0x26e837?_0x1dda59['reject'](_0x26e837):(_0xbf3228=new lt(_0x356e17,new ee(_0x18267f['_repo'],_0x18267f['_path']),R),_0x1dda59['resolve'](new of(_0x34bf14,_0xbf3228)));},_0x1dc404=Gd(_0x18267f,()=>{});return Od(_0x18267f['_repo'],_0x18267f['_path'],_0xdcfcae,_0x477bd2,_0x1dc404,_0x1470e3),_0x1dda59['promise'];}se['prototype']['simpleListen']=function(_0x4b45f7,_0x121a36){this['sendRequest']('q',{'p':_0x4b45f7},_0x121a36);},se['prototype']['echo']=function(_0x1e64e1,_0x1bbee5){this['sendRequest']('echo',{'d':_0x1e64e1},_0x1bbee5);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0xef2332,..._0x1515c2){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0xef2332,..._0x1515c2);}function cn(_0x368f0d,..._0x217558){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x368f0d,..._0x217558);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1a2d6e,..._0x299a3f){throw ws(_0x1a2d6e,..._0x299a3f);}function X(_0x557071,..._0xe3a3cf){return ws(_0x557071,..._0xe3a3cf);}function Ia(_0x10c71a,_0x259d19,_0x272dd9){const _0x40a830={...af(),[_0x259d19]:_0x272dd9};return new Gt('auth','Firebase',_0x40a830)['create'](_0x259d19,{'appName':_0x10c71a['name']});}function re(_0x4bd0a6){return Ia(_0x4bd0a6,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x16bc70,..._0x1d8035){if(typeof _0x16bc70!='string'){const _0x4a933f=_0x1d8035[0x0],_0x3633c7=[..._0x1d8035['slice'](0x1)];return _0x3633c7[0x0]&&(_0x3633c7[0x0]['appName']=_0x16bc70['name']),_0x16bc70['_errorFactory']['create'](_0x4a933f,..._0x3633c7);}return Ea['create'](_0x16bc70,..._0x1d8035);}function m(_0x43e0c6,_0xb7a57a,..._0x1a7c35){if(!_0x43e0c6)throw ws(_0xb7a57a,..._0x1a7c35);}function ne(_0x1bcac8){const _0x3fac02='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1bcac8;throw cn(_0x3fac02),new Error(_0x3fac02);}function ce(_0x3c5c2a,_0x1176a8){_0x3c5c2a||ne(_0x1176a8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x2cfd5c;return typeof self<'u'&&((_0x2cfd5c=self['location'])==null?void 0x0:_0x2cfd5c['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5eed0f;return typeof self<'u'&&((_0x5eed0f=self['location'])==null?void 0x0:_0x5eed0f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5842df=navigator;return _0x5842df['languages']&&_0x5842df['languages'][0x0]||_0x5842df['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x1b1d36,_0x3ed56d){this['shortDelay']=_0x1b1d36,this['longDelay']=_0x3ed56d,ce(_0x3ed56d>_0x1b1d36,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2e7af6,_0x2de028){ce(_0x2e7af6['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xcd67ea}=_0x2e7af6['emulator'];return _0x2de028?''+_0xcd67ea+(_0x2de028['startsWith']('/')?_0x2de028['slice'](0x1):_0x2de028):_0xcd67ea;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xdda92a,_0xc926c,_0x2eca21){this['fetchImpl']=_0xdda92a,_0xc926c&&(this['headersImpl']=_0xc926c),_0x2eca21&&(this['responseImpl']=_0x2eca21);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x10872c,_0x4435dc){return _0x10872c['tenantId']&&!_0x4435dc['tenantId']?{..._0x4435dc,'tenantId':_0x10872c['tenantId']}:_0x4435dc;}async function Pe(_0x3cbc3e,_0x2d4da4,_0x594b2e,_0x19bdce,_0xcc6bfa={}){return Ca(_0x3cbc3e,_0xcc6bfa,async()=>{let _0x4dcf34={},_0x53a27b={};_0x19bdce&&(_0x2d4da4==='GET'?_0x53a27b=_0x19bdce:_0x4dcf34={'body':JSON['stringify'](_0x19bdce)});const _0x141af3=ut({..._0x53a27b,'key':_0x3cbc3e['config']['apiKey']})['slice'](0x1),_0x12b028=await _0x3cbc3e['_getAdditionalHeaders']();_0x12b028['Content-Type']='application/json',_0x3cbc3e['languageCode']&&(_0x12b028['X-Firebase-Locale']=_0x3cbc3e['languageCode']);const _0x15253a={'method':_0x2d4da4,'headers':_0x12b028,..._0x4dcf34};return dc()||(_0x15253a['referrerPolicy']='strict-origin-when-cross-origin'),_0x3cbc3e['emulatorConfig']&&qt(_0x3cbc3e['emulatorConfig']['host'])&&(_0x15253a['credentials']='include'),wa['fetch']()(await Ta(_0x3cbc3e,_0x3cbc3e['config']['apiHost'],_0x594b2e,_0x141af3),_0x15253a);});}async function Ca(_0x20d9f7,_0x263f83,_0x303402){_0x20d9f7['_canInitEmulator']=!0x1;const _0x43085f={...df,..._0x263f83};try{const _0x5c0e5d=new gf(_0x20d9f7),_0x3d9d30=await Promise['race']([_0x303402(),_0x5c0e5d['promise']]);_0x5c0e5d['clearNetworkTimeout']();const _0x49b790=await _0x3d9d30['json']();if('needConfirmation'in _0x49b790)throw on(_0x20d9f7,'account-exists-with-different-credential',_0x49b790);if(_0x3d9d30['ok']&&!('errorMessage'in _0x49b790))return _0x49b790;{const _0x56a000=_0x3d9d30['ok']?_0x49b790['errorMessage']:_0x49b790['error']['message'],[_0x2a4688,_0x2fa48d]=_0x56a000['split']('\x20:\x20');if(_0x2a4688==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x20d9f7,'credential-already-in-use',_0x49b790);if(_0x2a4688==='EMAIL_EXISTS')throw on(_0x20d9f7,'email-already-in-use',_0x49b790);if(_0x2a4688==='USER_DISABLED')throw on(_0x20d9f7,'user-disabled',_0x49b790);const _0x464925=_0x43085f[_0x2a4688]||_0x2a4688['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2fa48d)throw Ia(_0x20d9f7,_0x464925,_0x2fa48d);Y(_0x20d9f7,_0x464925);}}catch(_0x52f2b2){if(_0x52f2b2 instanceof Re)throw _0x52f2b2;Y(_0x20d9f7,'network-request-failed',{'message':String(_0x52f2b2)});}}async function en(_0x51f88f,_0x4ffda8,_0xa7a825,_0x1f1d56,_0x14c53d={}){const _0x2a3485=await Pe(_0x51f88f,_0x4ffda8,_0xa7a825,_0x1f1d56,_0x14c53d);return'mfaPendingCredential'in _0x2a3485&&Y(_0x51f88f,'multi-factor-auth-required',{'_serverResponse':_0x2a3485}),_0x2a3485;}async function Ta(_0x503f24,_0x364406,_0x5d821b,_0x800bcb){const _0x5c4320=''+_0x364406+_0x5d821b+'?'+_0x800bcb,_0x4dbc49=_0x503f24,_0x3d4077=_0x4dbc49['config']['emulator']?Cs(_0x503f24['config'],_0x5c4320):_0x503f24['config']['apiScheme']+'://'+_0x5c4320;return ff['includes'](_0x5d821b)&&(await _0x4dbc49['_persistenceManagerAvailable'],_0x4dbc49['_getPersistenceType']()==='COOKIE')?_0x4dbc49['_getPersistence']()['_getFinalTarget'](_0x3d4077)['toString']():_0x3d4077;}function _f(_0x36ca89){switch(_0x36ca89){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0xa7b317){this['auth']=_0xa7b317,this['timer']=null,this['promise']=new Promise((_0x4beb37,_0x1ec432)=>{this['timer']=setTimeout(()=>_0x1ec432(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x5371e6,_0x332ef5,_0x56ed0f){const _0x20a07a={'appName':_0x5371e6['name']};_0x56ed0f['email']&&(_0x20a07a['email']=_0x56ed0f['email']),_0x56ed0f['phoneNumber']&&(_0x20a07a['phoneNumber']=_0x56ed0f['phoneNumber']);const _0x1784af=X(_0x5371e6,_0x332ef5,_0x20a07a);return _0x1784af['customData']['_tokenResponse']=_0x56ed0f,_0x1784af;}function wr(_0x33d14e){return _0x33d14e!==void 0x0&&_0x33d14e['enterprise']!==void 0x0;}class mf{constructor(_0x2fcf2a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2fcf2a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2fcf2a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2fcf2a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4a57bb){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x494b63 of this['recaptchaEnforcementState'])if(_0x494b63['provider']&&_0x494b63['provider']===_0x4a57bb)return _f(_0x494b63['enforcementState']);return null;}['isProviderEnabled'](_0x3a3efa){return this['getProviderEnforcementState'](_0x3a3efa)==='ENFORCE'||this['getProviderEnforcementState'](_0x3a3efa)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2ced09,_0x2b3574){return Pe(_0x2ced09,'GET','/v2/recaptchaConfig',ke(_0x2ced09,_0x2b3574));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3484b3,_0x105676){return Pe(_0x3484b3,'POST','/v1/accounts:delete',_0x105676);}async function Pn(_0x2510f6,_0x237a8b){return Pe(_0x2510f6,'POST','/v1/accounts:lookup',_0x237a8b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2ac412){if(_0x2ac412)try{const _0x45b962=new Date(Number(_0x2ac412));if(!isNaN(_0x45b962['getTime']()))return _0x45b962['toUTCString']();}catch{}}async function Ef(_0x5b835b,_0x1aa770=!0x1){const _0x4ad311=P(_0x5b835b),_0x2e4774=await _0x4ad311['getIdToken'](_0x1aa770),_0x49be5a=Ts(_0x2e4774);m(_0x49be5a&&_0x49be5a['exp']&&_0x49be5a['auth_time']&&_0x49be5a['iat'],_0x4ad311['auth'],'internal-error');const _0x39dc67=typeof _0x49be5a['firebase']=='object'?_0x49be5a['firebase']:void 0x0,_0x2ec352=_0x39dc67==null?void 0x0:_0x39dc67['sign_in_provider'];return{'claims':_0x49be5a,'token':_0x2e4774,'authTime':Pt(fi(_0x49be5a['auth_time'])),'issuedAtTime':Pt(fi(_0x49be5a['iat'])),'expirationTime':Pt(fi(_0x49be5a['exp'])),'signInProvider':_0x2ec352||null,'signInSecondFactor':(_0x39dc67==null?void 0x0:_0x39dc67['sign_in_second_factor'])||null};}function fi(_0x3a0b41){return Number(_0x3a0b41)*0x3e8;}function Ts(_0x1d9c65){const [_0x72fcae,_0x283425,_0x23c318]=_0x1d9c65['split']('.');if(_0x72fcae===void 0x0||_0x283425===void 0x0||_0x23c318===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x557269=fn(_0x283425);return _0x557269?JSON['parse'](_0x557269):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x34982a){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x34982a==null?void 0x0:_0x34982a['toString']()),null;}}function Cr(_0x5377a0){const _0x5b3621=Ts(_0x5377a0);return m(_0x5b3621,'internal-error'),m(typeof _0x5b3621['exp']<'u','internal-error'),m(typeof _0x5b3621['iat']<'u','internal-error'),Number(_0x5b3621['exp'])-Number(_0x5b3621['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x30c673,_0x40dc7d,_0x409268=!0x1){if(_0x409268)return _0x40dc7d;try{return await _0x40dc7d;}catch(_0x53651f){throw _0x53651f instanceof Re&&If(_0x53651f)&&_0x30c673['auth']['currentUser']===_0x30c673&&await _0x30c673['auth']['signOut'](),_0x53651f;}}function If({code:_0x527d1d}){return _0x527d1d==='auth/user-disabled'||_0x527d1d==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x21ccf7){this['user']=_0x21ccf7,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1dec16){if(_0x1dec16){const _0x11c3fa=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x11c3fa;}else{this['errorBackoff']=0x7530;const _0x307c70=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x307c70);}}['schedule'](_0x18c0f0=!0x1){if(!this['isRunning'])return;const _0x46e5af=this['getInterval'](_0x18c0f0);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x46e5af);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x53af1d){(_0x53af1d==null?void 0x0:_0x53af1d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x567ccd,_0x559718){this['createdAt']=_0x567ccd,this['lastLoginAt']=_0x559718,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0xe5718c){this['createdAt']=_0xe5718c['createdAt'],this['lastLoginAt']=_0xe5718c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0xeedd94){var _0x5f1881;const _0x50667d=_0xeedd94['auth'],_0x5ef928=await _0xeedd94['getIdToken'](),_0x3c0a1f=await Ht(_0xeedd94,Pn(_0x50667d,{'idToken':_0x5ef928}));m(_0x3c0a1f==null?void 0x0:_0x3c0a1f['users']['length'],_0x50667d,'internal-error');const _0x5b3d0f=_0x3c0a1f['users'][0x0];_0xeedd94['_notifyReloadListener'](_0x5b3d0f);const _0x188606=(_0x5f1881=_0x5b3d0f['providerUserInfo'])!=null&&_0x5f1881['length']?Sa(_0x5b3d0f['providerUserInfo']):[],_0x580140=Tf(_0xeedd94['providerData'],_0x188606),_0x1e8354=_0xeedd94['isAnonymous'],_0x358097=!(_0xeedd94['email']&&_0x5b3d0f['passwordHash'])&&!(_0x580140!=null&&_0x580140['length']),_0x4dd87a=_0x1e8354?_0x358097:!0x1,_0x42494a={'uid':_0x5b3d0f['localId'],'displayName':_0x5b3d0f['displayName']||null,'photoURL':_0x5b3d0f['photoUrl']||null,'email':_0x5b3d0f['email']||null,'emailVerified':_0x5b3d0f['emailVerified']||!0x1,'phoneNumber':_0x5b3d0f['phoneNumber']||null,'tenantId':_0x5b3d0f['tenantId']||null,'providerData':_0x580140,'metadata':new Li(_0x5b3d0f['createdAt'],_0x5b3d0f['lastLoginAt']),'isAnonymous':_0x4dd87a};Object['assign'](_0xeedd94,_0x42494a);}async function Cf(_0x33a2b5){const _0x48171a=P(_0x33a2b5);await Nn(_0x48171a),await _0x48171a['auth']['_persistUserIfCurrent'](_0x48171a),_0x48171a['auth']['_notifyListenersIfCurrent'](_0x48171a);}function Tf(_0xcc675c,_0x238a68){return[..._0xcc675c['filter'](_0x489aa1=>!_0x238a68['some'](_0x508f7f=>_0x508f7f['providerId']===_0x489aa1['providerId'])),..._0x238a68];}function Sa(_0x5b6aff){return _0x5b6aff['map'](({providerId:_0x5a8c35,..._0x4d6b3e})=>({'providerId':_0x5a8c35,'uid':_0x4d6b3e['rawId']||'','displayName':_0x4d6b3e['displayName']||null,'email':_0x4d6b3e['email']||null,'phoneNumber':_0x4d6b3e['phoneNumber']||null,'photoURL':_0x4d6b3e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x158bf2,_0x18cad3){const _0x154412=await Ca(_0x158bf2,{},async()=>{const _0x476ff7=ut({'grant_type':'refresh_token','refresh_token':_0x18cad3})['slice'](0x1),{tokenApiHost:_0xde1c06,apiKey:_0x19d62f}=_0x158bf2['config'],_0x3d3c67=await Ta(_0x158bf2,_0xde1c06,'/v1/token','key='+_0x19d62f),_0x2bb243=await _0x158bf2['_getAdditionalHeaders']();_0x2bb243['Content-Type']='application/x-www-form-urlencoded';const _0x2cfc04={'method':'POST','headers':_0x2bb243,'body':_0x476ff7};return _0x158bf2['emulatorConfig']&&qt(_0x158bf2['emulatorConfig']['host'])&&(_0x2cfc04['credentials']='include'),wa['fetch']()(_0x3d3c67,_0x2cfc04);});return{'accessToken':_0x154412['access_token'],'expiresIn':_0x154412['expires_in'],'refreshToken':_0x154412['refresh_token']};}async function bf(_0x483581,_0x31e506){return Pe(_0x483581,'POST','/v2/accounts:revokeToken',ke(_0x483581,_0x31e506));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4bb066){m(_0x4bb066['idToken'],'internal-error'),m(typeof _0x4bb066['idToken']<'u','internal-error'),m(typeof _0x4bb066['refreshToken']<'u','internal-error');const _0x563c97='expiresIn'in _0x4bb066&&typeof _0x4bb066['expiresIn']<'u'?Number(_0x4bb066['expiresIn']):Cr(_0x4bb066['idToken']);this['updateTokensAndExpiration'](_0x4bb066['idToken'],_0x4bb066['refreshToken'],_0x563c97);}['updateFromIdToken'](_0x738cbe){m(_0x738cbe['length']!==0x0,'internal-error');const _0x348786=Cr(_0x738cbe);this['updateTokensAndExpiration'](_0x738cbe,null,_0x348786);}async['getToken'](_0x21ed73,_0x1ea8db=!0x1){return!_0x1ea8db&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x21ed73,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x21ed73,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1ae392,_0x16060d){const {accessToken:_0x38ae6c,refreshToken:_0x24cdfc,expiresIn:_0x21e73d}=await Sf(_0x1ae392,_0x16060d);this['updateTokensAndExpiration'](_0x38ae6c,_0x24cdfc,Number(_0x21e73d));}['updateTokensAndExpiration'](_0x176f3c,_0x39bedd,_0x5688a5){this['refreshToken']=_0x39bedd||null,this['accessToken']=_0x176f3c||null,this['expirationTime']=Date['now']()+_0x5688a5*0x3e8;}static['fromJSON'](_0x192a3f,_0x47a0aa){const {refreshToken:_0x486fb7,accessToken:_0x4268df,expirationTime:_0x208914}=_0x47a0aa,_0x114e42=new et();return _0x486fb7&&(m(typeof _0x486fb7=='string','internal-error',{'appName':_0x192a3f}),_0x114e42['refreshToken']=_0x486fb7),_0x4268df&&(m(typeof _0x4268df=='string','internal-error',{'appName':_0x192a3f}),_0x114e42['accessToken']=_0x4268df),_0x208914&&(m(typeof _0x208914=='number','internal-error',{'appName':_0x192a3f}),_0x114e42['expirationTime']=_0x208914),_0x114e42;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x38af96){this['accessToken']=_0x38af96['accessToken'],this['refreshToken']=_0x38af96['refreshToken'],this['expirationTime']=_0x38af96['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x5971a0,_0x47e66f){m(typeof _0x5971a0=='string'||typeof _0x5971a0>'u','internal-error',{'appName':_0x47e66f});}class j{constructor({uid:_0x2e8f95,auth:_0xa2de47,stsTokenManager:_0x143dd6,..._0x216e42}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2e8f95,this['auth']=_0xa2de47,this['stsTokenManager']=_0x143dd6,this['accessToken']=_0x143dd6['accessToken'],this['displayName']=_0x216e42['displayName']||null,this['email']=_0x216e42['email']||null,this['emailVerified']=_0x216e42['emailVerified']||!0x1,this['phoneNumber']=_0x216e42['phoneNumber']||null,this['photoURL']=_0x216e42['photoURL']||null,this['isAnonymous']=_0x216e42['isAnonymous']||!0x1,this['tenantId']=_0x216e42['tenantId']||null,this['providerData']=_0x216e42['providerData']?[..._0x216e42['providerData']]:[],this['metadata']=new Li(_0x216e42['createdAt']||void 0x0,_0x216e42['lastLoginAt']||void 0x0);}async['getIdToken'](_0x114689){const _0x50628f=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x114689));return m(_0x50628f,this['auth'],'internal-error'),this['accessToken']!==_0x50628f&&(this['accessToken']=_0x50628f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x50628f;}['getIdTokenResult'](_0x396261){return Ef(this,_0x396261);}['reload'](){return Cf(this);}['_assign'](_0x5f29e0){this!==_0x5f29e0&&(m(this['uid']===_0x5f29e0['uid'],this['auth'],'internal-error'),this['displayName']=_0x5f29e0['displayName'],this['photoURL']=_0x5f29e0['photoURL'],this['email']=_0x5f29e0['email'],this['emailVerified']=_0x5f29e0['emailVerified'],this['phoneNumber']=_0x5f29e0['phoneNumber'],this['isAnonymous']=_0x5f29e0['isAnonymous'],this['tenantId']=_0x5f29e0['tenantId'],this['providerData']=_0x5f29e0['providerData']['map'](_0x44c579=>({..._0x44c579})),this['metadata']['_copy'](_0x5f29e0['metadata']),this['stsTokenManager']['_assign'](_0x5f29e0['stsTokenManager']));}['_clone'](_0x3d845a){const _0x286cc5=new j({...this,'auth':_0x3d845a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x286cc5['metadata']['_copy'](this['metadata']),_0x286cc5;}['_onReload'](_0xf7d537){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xf7d537,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x193ce0){this['reloadListener']?this['reloadListener'](_0x193ce0):this['reloadUserInfo']=_0x193ce0;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x110cea,_0x306adc=!0x1){let _0x3c79d1=!0x1;_0x110cea['idToken']&&_0x110cea['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x110cea),_0x3c79d1=!0x0),_0x306adc&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3c79d1&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0xdd784c=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0xdd784c})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3aa7c2=>({..._0x3aa7c2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x575edb,_0x3cd78c){const _0x44a684=_0x3cd78c['displayName']??void 0x0,_0x379f28=_0x3cd78c['email']??void 0x0,_0x218e37=_0x3cd78c['phoneNumber']??void 0x0,_0x5f446e=_0x3cd78c['photoURL']??void 0x0,_0x59da4b=_0x3cd78c['tenantId']??void 0x0,_0x24ef33=_0x3cd78c['_redirectEventId']??void 0x0,_0x114ab8=_0x3cd78c['createdAt']??void 0x0,_0x4c218f=_0x3cd78c['lastLoginAt']??void 0x0,{uid:_0x33eeb3,emailVerified:_0x400e15,isAnonymous:_0x461869,providerData:_0x322af8,stsTokenManager:_0x370eab}=_0x3cd78c;m(_0x33eeb3&&_0x370eab,_0x575edb,'internal-error');const _0x385723=et['fromJSON'](this['name'],_0x370eab);m(typeof _0x33eeb3=='string',_0x575edb,'internal-error'),le(_0x44a684,_0x575edb['name']),le(_0x379f28,_0x575edb['name']),m(typeof _0x400e15=='boolean',_0x575edb,'internal-error'),m(typeof _0x461869=='boolean',_0x575edb,'internal-error'),le(_0x218e37,_0x575edb['name']),le(_0x5f446e,_0x575edb['name']),le(_0x59da4b,_0x575edb['name']),le(_0x24ef33,_0x575edb['name']),le(_0x114ab8,_0x575edb['name']),le(_0x4c218f,_0x575edb['name']);const _0x4ff005=new j({'uid':_0x33eeb3,'auth':_0x575edb,'email':_0x379f28,'emailVerified':_0x400e15,'displayName':_0x44a684,'isAnonymous':_0x461869,'photoURL':_0x5f446e,'phoneNumber':_0x218e37,'tenantId':_0x59da4b,'stsTokenManager':_0x385723,'createdAt':_0x114ab8,'lastLoginAt':_0x4c218f});return _0x322af8&&Array['isArray'](_0x322af8)&&(_0x4ff005['providerData']=_0x322af8['map'](_0x5d7ce9=>({..._0x5d7ce9}))),_0x24ef33&&(_0x4ff005['_redirectEventId']=_0x24ef33),_0x4ff005;}static async['_fromIdTokenResponse'](_0x521213,_0x819259,_0x2d42eb=!0x1){const _0x5f4669=new et();_0x5f4669['updateFromServerResponse'](_0x819259);const _0x396486=new j({'uid':_0x819259['localId'],'auth':_0x521213,'stsTokenManager':_0x5f4669,'isAnonymous':_0x2d42eb});return await Nn(_0x396486),_0x396486;}static async['_fromGetAccountInfoResponse'](_0x21c47f,_0x43a8da,_0x17cbaa){const _0xe3b9e=_0x43a8da['users'][0x0];m(_0xe3b9e['localId']!==void 0x0,'internal-error');const _0x39c958=_0xe3b9e['providerUserInfo']!==void 0x0?Sa(_0xe3b9e['providerUserInfo']):[],_0x432657=!(_0xe3b9e['email']&&_0xe3b9e['passwordHash'])&&!(_0x39c958!=null&&_0x39c958['length']),_0x3eda9d=new et();_0x3eda9d['updateFromIdToken'](_0x17cbaa);const _0x124dce=new j({'uid':_0xe3b9e['localId'],'auth':_0x21c47f,'stsTokenManager':_0x3eda9d,'isAnonymous':_0x432657}),_0x108181={'uid':_0xe3b9e['localId'],'displayName':_0xe3b9e['displayName']||null,'photoURL':_0xe3b9e['photoUrl']||null,'email':_0xe3b9e['email']||null,'emailVerified':_0xe3b9e['emailVerified']||!0x1,'phoneNumber':_0xe3b9e['phoneNumber']||null,'tenantId':_0xe3b9e['tenantId']||null,'providerData':_0x39c958,'metadata':new Li(_0xe3b9e['createdAt'],_0xe3b9e['lastLoginAt']),'isAnonymous':!(_0xe3b9e['email']&&_0xe3b9e['passwordHash'])&&!(_0x39c958!=null&&_0x39c958['length'])};return Object['assign'](_0x124dce,_0x108181),_0x124dce;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xdada52){ce(_0xdada52 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x9ccb5f=Tr['get'](_0xdada52);return _0x9ccb5f?(ce(_0x9ccb5f instanceof _0xdada52,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x9ccb5f):(_0x9ccb5f=new _0xdada52(),Tr['set'](_0xdada52,_0x9ccb5f),_0x9ccb5f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x69714c,_0x5bcf7e){this['storage'][_0x69714c]=_0x5bcf7e;}async['_get'](_0xe035cd){const _0x186a5e=this['storage'][_0xe035cd];return _0x186a5e===void 0x0?null:_0x186a5e;}async['_remove'](_0xf3c3e2){delete this['storage'][_0xf3c3e2];}['_addListener'](_0x139d06,_0x32fb16){}['_removeListener'](_0x11d07f,_0x4edd52){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x564aa7,_0x14c14,_0x2fcf63){return'firebase:'+_0x564aa7+':'+_0x14c14+':'+_0x2fcf63;}class tt{constructor(_0x9f6aab,_0x4d2615,_0x53b72e){this['persistence']=_0x9f6aab,this['auth']=_0x4d2615,this['userKey']=_0x53b72e;const {config:_0x35b804,name:_0x5b22d6}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x35b804['apiKey'],_0x5b22d6),this['fullPersistenceKey']=ln('persistence',_0x35b804['apiKey'],_0x5b22d6),this['boundEventHandler']=_0x4d2615['_onStorageEvent']['bind'](_0x4d2615),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x400284){return this['persistence']['_set'](this['fullUserKey'],_0x400284['toJSON']());}async['getCurrentUser'](){const _0x18eb8f=await this['persistence']['_get'](this['fullUserKey']);if(!_0x18eb8f)return null;if(typeof _0x18eb8f=='string'){const _0x49430a=await Pn(this['auth'],{'idToken':_0x18eb8f})['catch'](()=>{});return _0x49430a?j['_fromGetAccountInfoResponse'](this['auth'],_0x49430a,_0x18eb8f):null;}return j['_fromJSON'](this['auth'],_0x18eb8f);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2c2057){if(this['persistence']===_0x2c2057)return;const _0x68e597=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2c2057,_0x68e597)return this['setCurrentUser'](_0x68e597);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x339831,_0x1b7346,_0x47ec5d='authUser'){if(!_0x1b7346['length'])return new tt(ie(Sr),_0x339831,_0x47ec5d);const _0x1aab64=(await Promise['all'](_0x1b7346['map'](async _0x3838d4=>{if(await _0x3838d4['_isAvailable']())return _0x3838d4;})))['filter'](_0x367bb7=>_0x367bb7);let _0x3f0cd5=_0x1aab64[0x0]||ie(Sr);const _0x41165f=ln(_0x47ec5d,_0x339831['config']['apiKey'],_0x339831['name']);let _0x3811ad=null;for(const _0x3cf156 of _0x1b7346)try{const _0x5d4348=await _0x3cf156['_get'](_0x41165f);if(_0x5d4348){let _0x426220;if(typeof _0x5d4348=='string'){const _0x5d0c52=await Pn(_0x339831,{'idToken':_0x5d4348})['catch'](()=>{});if(!_0x5d0c52)break;_0x426220=await j['_fromGetAccountInfoResponse'](_0x339831,_0x5d0c52,_0x5d4348);}else _0x426220=j['_fromJSON'](_0x339831,_0x5d4348);_0x3cf156!==_0x3f0cd5&&(_0x3811ad=_0x426220),_0x3f0cd5=_0x3cf156;break;}}catch{}const _0x4903d8=_0x1aab64['filter'](_0x431fe8=>_0x431fe8['_shouldAllowMigration']);return!_0x3f0cd5['_shouldAllowMigration']||!_0x4903d8['length']?new tt(_0x3f0cd5,_0x339831,_0x47ec5d):(_0x3f0cd5=_0x4903d8[0x0],_0x3811ad&&await _0x3f0cd5['_set'](_0x41165f,_0x3811ad['toJSON']()),await Promise['all'](_0x1b7346['map'](async _0x2053f5=>{if(_0x2053f5!==_0x3f0cd5)try{await _0x2053f5['_remove'](_0x41165f);}catch{}})),new tt(_0x3f0cd5,_0x339831,_0x47ec5d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x11aec7){const _0x38f9e8=_0x11aec7['toLowerCase']();if(_0x38f9e8['includes']('opera/')||_0x38f9e8['includes']('opr/')||_0x38f9e8['includes']('opios/'))return'Opera';if(Pa(_0x38f9e8))return'IEMobile';if(_0x38f9e8['includes']('msie')||_0x38f9e8['includes']('trident/'))return'IE';if(_0x38f9e8['includes']('edge/'))return'Edge';if(Ra(_0x38f9e8))return'Firefox';if(_0x38f9e8['includes']('silk/'))return'Silk';if(Oa(_0x38f9e8))return'Blackberry';if(Da(_0x38f9e8))return'Webos';if(Aa(_0x38f9e8))return'Safari';if((_0x38f9e8['includes']('chrome/')||ka(_0x38f9e8))&&!_0x38f9e8['includes']('edge/'))return'Chrome';if(Na(_0x38f9e8))return'Android';{const _0x45b3b2=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x265b33=_0x11aec7['match'](_0x45b3b2);if((_0x265b33==null?void 0x0:_0x265b33['length'])===0x2)return _0x265b33[0x1];}return'Other';}function Ra(_0x4d655a=W()){return/firefox\//i['test'](_0x4d655a);}function Aa(_0xacc4e=W()){const _0x10659b=_0xacc4e['toLowerCase']();return _0x10659b['includes']('safari/')&&!_0x10659b['includes']('chrome/')&&!_0x10659b['includes']('crios/')&&!_0x10659b['includes']('android');}function ka(_0xdf3b19=W()){return/crios\//i['test'](_0xdf3b19);}function Pa(_0x1b54aa=W()){return/iemobile/i['test'](_0x1b54aa);}function Na(_0x74c4e6=W()){return/android/i['test'](_0x74c4e6);}function Oa(_0x146148=W()){return/blackberry/i['test'](_0x146148);}function Da(_0x1c45e6=W()){return/webos/i['test'](_0x1c45e6);}function Ss(_0x329fed=W()){return/iphone|ipad|ipod/i['test'](_0x329fed)||/macintosh/i['test'](_0x329fed)&&/mobile/i['test'](_0x329fed);}function Rf(_0x2fd7aa=W()){var _0x13c0fd;return Ss(_0x2fd7aa)&&!!((_0x13c0fd=window['navigator'])!=null&&_0x13c0fd['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x281fc5=W()){return Ss(_0x281fc5)||Na(_0x281fc5)||Da(_0x281fc5)||Oa(_0x281fc5)||/windows phone/i['test'](_0x281fc5)||Pa(_0x281fc5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1b99df,_0xd6618e=[]){let _0x4ddd5c;switch(_0x1b99df){case'Browser':_0x4ddd5c=br(W());break;case'Worker':_0x4ddd5c=br(W())+'-'+_0x1b99df;break;default:_0x4ddd5c=_0x1b99df;}const _0x29d1ce=_0xd6618e['length']?_0xd6618e['join'](','):'FirebaseCore-web';return _0x4ddd5c+'/JsCore/'+dt+'/'+_0x29d1ce;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x26ea25){this['auth']=_0x26ea25,this['queue']=[];}['pushCallback'](_0xa0a6d1,_0x54c317){const _0x5969e1=_0x39f384=>new Promise((_0x229731,_0x558b8c)=>{try{const _0x554abc=_0xa0a6d1(_0x39f384);_0x229731(_0x554abc);}catch(_0x24477f){_0x558b8c(_0x24477f);}});_0x5969e1['onAbort']=_0x54c317,this['queue']['push'](_0x5969e1);const _0x276c80=this['queue']['length']-0x1;return()=>{this['queue'][_0x276c80]=()=>Promise['resolve']();};}async['runMiddleware'](_0x526ea9){if(this['auth']['currentUser']===_0x526ea9)return;const _0x39be83=[];try{for(const _0x203a18 of this['queue'])await _0x203a18(_0x526ea9),_0x203a18['onAbort']&&_0x39be83['push'](_0x203a18['onAbort']);}catch(_0x36e153){_0x39be83['reverse']();for(const _0x1b521f of _0x39be83)try{_0x1b521f();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x36e153==null?void 0x0:_0x36e153['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x5402b2,_0x2d0e86={}){return Pe(_0x5402b2,'GET','/v2/passwordPolicy',ke(_0x5402b2,_0x2d0e86));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xe22e38){var _0x1494b7;const _0x51f553=_0xe22e38['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x51f553['minPasswordLength']??Nf,_0x51f553['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x51f553['maxPasswordLength']),_0x51f553['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x51f553['containsLowercaseCharacter']),_0x51f553['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x51f553['containsUppercaseCharacter']),_0x51f553['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x51f553['containsNumericCharacter']),_0x51f553['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x51f553['containsNonAlphanumericCharacter']),this['enforcementState']=_0xe22e38['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1494b7=_0xe22e38['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1494b7['join'](''))??'',this['forceUpgradeOnSignin']=_0xe22e38['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xe22e38['schemaVersion'];}['validatePassword'](_0x225ca5){const _0x548ce0={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x225ca5,_0x548ce0),this['validatePasswordCharacterOptions'](_0x225ca5,_0x548ce0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['meetsMinPasswordLength']??!0x0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['meetsMaxPasswordLength']??!0x0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['containsLowercaseLetter']??!0x0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['containsUppercaseLetter']??!0x0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['containsNumericCharacter']??!0x0),_0x548ce0['isValid']&&(_0x548ce0['isValid']=_0x548ce0['containsNonAlphanumericCharacter']??!0x0),_0x548ce0;}['validatePasswordLengthOptions'](_0x311556,_0x16b302){const _0x2b85e2=this['customStrengthOptions']['minPasswordLength'],_0x2396d0=this['customStrengthOptions']['maxPasswordLength'];_0x2b85e2&&(_0x16b302['meetsMinPasswordLength']=_0x311556['length']>=_0x2b85e2),_0x2396d0&&(_0x16b302['meetsMaxPasswordLength']=_0x311556['length']<=_0x2396d0);}['validatePasswordCharacterOptions'](_0x12891c,_0x388139){this['updatePasswordCharacterOptionsStatuses'](_0x388139,!0x1,!0x1,!0x1,!0x1);let _0x5ef418;for(let _0x49b8ff=0x0;_0x49b8ff<_0x12891c['length'];_0x49b8ff++)_0x5ef418=_0x12891c['charAt'](_0x49b8ff),this['updatePasswordCharacterOptionsStatuses'](_0x388139,_0x5ef418>='a'&&_0x5ef418<='z',_0x5ef418>='A'&&_0x5ef418<='Z',_0x5ef418>='0'&&_0x5ef418<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5ef418));}['updatePasswordCharacterOptionsStatuses'](_0x21dc35,_0xada04a,_0x260055,_0x221c86,_0x25c7a0){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x21dc35['containsLowercaseLetter']||(_0x21dc35['containsLowercaseLetter']=_0xada04a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x21dc35['containsUppercaseLetter']||(_0x21dc35['containsUppercaseLetter']=_0x260055)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x21dc35['containsNumericCharacter']||(_0x21dc35['containsNumericCharacter']=_0x221c86)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x21dc35['containsNonAlphanumericCharacter']||(_0x21dc35['containsNonAlphanumericCharacter']=_0x25c7a0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x4d66ab,_0x26840b,_0x275be0,_0x26d6ee){this['app']=_0x4d66ab,this['heartbeatServiceProvider']=_0x26840b,this['appCheckServiceProvider']=_0x275be0,this['config']=_0x26d6ee,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4d66ab['name'],this['clientVersion']=_0x26d6ee['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x33b9a8=>this['_resolvePersistenceManagerAvailable']=_0x33b9a8);}['_initializeWithPersistence'](_0x2200e6,_0xfb7687){return _0xfb7687&&(this['_popupRedirectResolver']=ie(_0xfb7687)),this['_initializationPromise']=this['queue'](async()=>{var _0x1582e8,_0x546cb0,_0x12884b;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2200e6),(_0x1582e8=this['_resolvePersistenceManagerAvailable'])==null||_0x1582e8['call'](this),!this['_deleted'])){if((_0x546cb0=this['_popupRedirectResolver'])!=null&&_0x546cb0['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0xfb7687),this['lastNotifiedUid']=((_0x12884b=this['currentUser'])==null?void 0x0:_0x12884b['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2c95d1=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2c95d1)){if(this['currentUser']&&_0x2c95d1&&this['currentUser']['uid']===_0x2c95d1['uid']){this['_currentUser']['_assign'](_0x2c95d1),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2c95d1,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4e75e6){try{const _0xddd3f7=await Pn(this,{'idToken':_0x4e75e6}),_0x3035b8=await j['_fromGetAccountInfoResponse'](this,_0xddd3f7,_0x4e75e6);await this['directlySetCurrentUser'](_0x3035b8);}catch(_0x2505f8){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2505f8),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x45653b){var _0x9c5ddf;if($(this['app'])){const _0x21f3d6=this['app']['settings']['authIdToken'];return _0x21f3d6?new Promise(_0x2b519b=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x21f3d6)['then'](_0x2b519b,_0x2b519b));}):this['directlySetCurrentUser'](null);}const _0x2a8366=await this['assertedPersistence']['getCurrentUser']();let _0x5c9c64=_0x2a8366,_0x52c5af=!0x1;if(_0x45653b&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x560c40=(_0x9c5ddf=this['redirectUser'])==null?void 0x0:_0x9c5ddf['_redirectEventId'],_0x524e01=_0x5c9c64==null?void 0x0:_0x5c9c64['_redirectEventId'],_0x2d34af=await this['tryRedirectSignIn'](_0x45653b);(!_0x560c40||_0x560c40===_0x524e01)&&(_0x2d34af!=null&&_0x2d34af['user'])&&(_0x5c9c64=_0x2d34af['user'],_0x52c5af=!0x0);}if(!_0x5c9c64)return this['directlySetCurrentUser'](null);if(!_0x5c9c64['_redirectEventId']){if(_0x52c5af)try{await this['beforeStateQueue']['runMiddleware'](_0x5c9c64);}catch(_0x1f1403){_0x5c9c64=_0x2a8366,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1f1403));}return _0x5c9c64?this['reloadAndSetCurrentUserOrClear'](_0x5c9c64):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5c9c64['_redirectEventId']?this['directlySetCurrentUser'](_0x5c9c64):this['reloadAndSetCurrentUserOrClear'](_0x5c9c64);}async['tryRedirectSignIn'](_0x2c63e6){let _0x27406e=null;try{_0x27406e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2c63e6,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x27406e;}async['reloadAndSetCurrentUserOrClear'](_0x4979b8){try{await Nn(_0x4979b8);}catch(_0x4d2d1f){if((_0x4d2d1f==null?void 0x0:_0x4d2d1f['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4979b8);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xe9db){if($(this['app']))return Promise['reject'](re(this));const _0x12c265=_0xe9db?P(_0xe9db):null;return _0x12c265&&m(_0x12c265['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x12c265&&_0x12c265['_clone'](this));}async['_updateCurrentUser'](_0x2cbc00,_0x330686=!0x1){if(!this['_deleted'])return _0x2cbc00&&m(this['tenantId']===_0x2cbc00['tenantId'],this,'tenant-id-mismatch'),_0x330686||await this['beforeStateQueue']['runMiddleware'](_0x2cbc00),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2cbc00),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3d7599){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3d7599));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4c6d61){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2c6d05=this['_getPasswordPolicyInternal']();return _0x2c6d05['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2c6d05['validatePassword'](_0x4c6d61);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3eac36=await Pf(this),_0x26ff20=new Of(_0x3eac36);this['tenantId']===null?this['_projectPasswordPolicy']=_0x26ff20:this['_tenantPasswordPolicies'][this['tenantId']]=_0x26ff20;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2d84d5){this['_errorFactory']=new Gt('auth','Firebase',_0x2d84d5());}['onAuthStateChanged'](_0x1fd931,_0x284e35,_0x48230b){return this['registerStateListener'](this['authStateSubscription'],_0x1fd931,_0x284e35,_0x48230b);}['beforeAuthStateChanged'](_0xc306c6,_0x518fd1){return this['beforeStateQueue']['pushCallback'](_0xc306c6,_0x518fd1);}['onIdTokenChanged'](_0x1d0f66,_0x2d9818,_0x29dd7f){return this['registerStateListener'](this['idTokenSubscription'],_0x1d0f66,_0x2d9818,_0x29dd7f);}['authStateReady'](){return new Promise((_0xef355b,_0xc05b66)=>{if(this['currentUser'])_0xef355b();else{const _0x322141=this['onAuthStateChanged'](()=>{_0x322141(),_0xef355b();},_0xc05b66);}});}async['revokeAccessToken'](_0x243e9d){if(this['currentUser']){const _0x46b9ee=await this['currentUser']['getIdToken'](),_0x5e1e10={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x243e9d,'idToken':_0x46b9ee};this['tenantId']!=null&&(_0x5e1e10['tenantId']=this['tenantId']),await bf(this,_0x5e1e10);}}['toJSON'](){var _0xdbdac9;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xdbdac9=this['_currentUser'])==null?void 0x0:_0xdbdac9['toJSON']()};}async['_setRedirectUser'](_0xf92d7c,_0x20ad02){const _0x50d079=await this['getOrInitRedirectPersistenceManager'](_0x20ad02);return _0xf92d7c===null?_0x50d079['removeCurrentUser']():_0x50d079['setCurrentUser'](_0xf92d7c);}async['getOrInitRedirectPersistenceManager'](_0x1a052e){if(!this['redirectPersistenceManager']){const _0x450eb7=_0x1a052e&&ie(_0x1a052e)||this['_popupRedirectResolver'];m(_0x450eb7,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x450eb7['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2425be){var _0xfb0a9d,_0x49349c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xfb0a9d=this['_currentUser'])==null?void 0x0:_0xfb0a9d['_redirectEventId'])===_0x2425be?this['_currentUser']:((_0x49349c=this['redirectUser'])==null?void 0x0:_0x49349c['_redirectEventId'])===_0x2425be?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x224c7a){if(_0x224c7a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x224c7a));}['_notifyListenersIfCurrent'](_0x5d342a){_0x5d342a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5ccc20;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1ba986=((_0x5ccc20=this['currentUser'])==null?void 0x0:_0x5ccc20['uid'])??null;this['lastNotifiedUid']!==_0x1ba986&&(this['lastNotifiedUid']=_0x1ba986,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x501d82,_0x3ed5e4,_0x450b49,_0x33e361){if(this['_deleted'])return()=>{};const _0x118809=typeof _0x3ed5e4=='function'?_0x3ed5e4:_0x3ed5e4['next']['bind'](_0x3ed5e4);let _0x496150=!0x1;const _0x579f69=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x579f69,this,'internal-error'),_0x579f69['then'](()=>{_0x496150||_0x118809(this['currentUser']);}),typeof _0x3ed5e4=='function'){const _0x2d8279=_0x501d82['addObserver'](_0x3ed5e4,_0x450b49,_0x33e361);return()=>{_0x496150=!0x0,_0x2d8279();};}else{const _0x245aa7=_0x501d82['addObserver'](_0x3ed5e4);return()=>{_0x496150=!0x0,_0x245aa7();};}}async['directlySetCurrentUser'](_0x32686a){this['currentUser']&&this['currentUser']!==_0x32686a&&this['_currentUser']['_stopProactiveRefresh'](),_0x32686a&&this['isProactiveRefreshEnabled']&&_0x32686a['_startProactiveRefresh'](),this['currentUser']=_0x32686a,_0x32686a?await this['assertedPersistence']['setCurrentUser'](_0x32686a):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1227e9){return this['operations']=this['operations']['then'](_0x1227e9,_0x1227e9),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5a174c){!_0x5a174c||this['frameworks']['includes'](_0x5a174c)||(this['frameworks']['push'](_0x5a174c),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x424035;const _0x20f70c={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x20f70c['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x415574=await((_0x424035=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x424035['getHeartbeatsHeader']());_0x415574&&(_0x20f70c['X-Firebase-Client']=_0x415574);const _0x203d7b=await this['_getAppCheckToken']();return _0x203d7b&&(_0x20f70c['X-Firebase-AppCheck']=_0x203d7b),_0x20f70c;}async['_getAppCheckToken'](){var _0x5a6f16;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x58def0=await((_0x5a6f16=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a6f16['getToken']());return _0x58def0!=null&&_0x58def0['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x58def0['error']),_0x58def0==null?void 0x0:_0x58def0['token'];}}function Ke(_0x527583){return P(_0x527583);}class Rr{constructor(_0x51e918){this['auth']=_0x51e918,this['observer']=null,this['addObserver']=Tc(_0x49d386=>this['observer']=_0x49d386);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x376ab7){Jn=_0x376ab7;}function xa(_0x4f573a){return Jn['loadJS'](_0x4f573a);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x57ffb3){return'__'+_0x57ffb3+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x5582dd){_0x5582dd();}['execute'](_0x134cb9,_0x389f77){return Promise['resolve']('token');}['render'](_0x298c51,_0xe88d1){return'';}}class Wf{['ready'](_0x3f8bb3){_0x3f8bb3();}['execute'](_0x4b56f9,_0x317882){return Promise['resolve']('token');}['render'](_0x2b9578,_0x9fbaa3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x154095){this['type']=Bf,this['auth']=Ke(_0x154095);}async['verify'](_0x41b7d6='verify',_0x2e6f35=!0x1){async function _0x510790(_0x4d9722){if(!_0x2e6f35){if(_0x4d9722['tenantId']==null&&_0x4d9722['_agentRecaptchaConfig']!=null)return _0x4d9722['_agentRecaptchaConfig']['siteKey'];if(_0x4d9722['tenantId']!=null&&_0x4d9722['_tenantRecaptchaConfigs'][_0x4d9722['tenantId']]!==void 0x0)return _0x4d9722['_tenantRecaptchaConfigs'][_0x4d9722['tenantId']]['siteKey'];}return new Promise(async(_0x282983,_0x569c2f)=>{yf(_0x4d9722,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4c6955=>{if(_0x4c6955['recaptchaKey']===void 0x0)_0x569c2f(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x30bbd2=new mf(_0x4c6955);return _0x4d9722['tenantId']==null?_0x4d9722['_agentRecaptchaConfig']=_0x30bbd2:_0x4d9722['_tenantRecaptchaConfigs'][_0x4d9722['tenantId']]=_0x30bbd2,_0x282983(_0x30bbd2['siteKey']);}})['catch'](_0x4259c3=>{_0x569c2f(_0x4259c3);});});}function _0x5eb3d3(_0x3499a4,_0x29097b,_0x1db3b2){const _0xadc6b2=window['grecaptcha'];wr(_0xadc6b2)?_0xadc6b2['enterprise']['ready'](()=>{_0xadc6b2['enterprise']['execute'](_0x3499a4,{'action':_0x41b7d6})['then'](_0xdbc090=>{_0x29097b(_0xdbc090);})['catch'](()=>{_0x29097b(Fa);});}):_0x1db3b2(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4727f0,_0x4f6581)=>{_0x510790(this['auth'])['then'](async _0x3db9cc=>{if(!_0x2e6f35&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x5eb3d3(_0x3db9cc,_0x4727f0,_0x4f6581);else{if(typeof window>'u'){_0x4f6581(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x6ce2be=Lf();_0x6ce2be['length']!==0x0&&(_0x6ce2be+=_0x3db9cc+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5898bb;(_0x5898bb=he['scriptInjectionDeferred'])==null||_0x5898bb['resolve']();},xa(_0x6ce2be)['then'](()=>{var _0x4b7812;return(_0x4b7812=he['scriptInjectionDeferred'])==null?void 0x0:_0x4b7812['promise'];})['then'](()=>{_0x5eb3d3(_0x3db9cc,_0x4727f0,_0x4f6581);})['catch'](_0x5eff44=>{_0x4f6581(_0x5eff44);});}})['catch'](_0x3a5233=>{_0x4f6581(_0x3a5233);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x1a4e54,_0x304c45,_0x4b0d57,_0xe792e7=!0x1,_0x11da19=!0x1){const _0x576249=new he(_0x1a4e54);let _0x9e47e6;if(_0x11da19)_0x9e47e6=Fa;else try{_0x9e47e6=await _0x576249['verify'](_0x4b0d57);}catch{_0x9e47e6=await _0x576249['verify'](_0x4b0d57,!0x0);}const _0x300bd0={..._0x304c45};if(_0x4b0d57==='mfaSmsEnrollment'||_0x4b0d57==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x300bd0){const _0x478df8=_0x300bd0['phoneEnrollmentInfo']['phoneNumber'],_0x3e8e7d=_0x300bd0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x300bd0,{'phoneEnrollmentInfo':{'phoneNumber':_0x478df8,'recaptchaToken':_0x3e8e7d,'captchaResponse':_0x9e47e6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x300bd0){const _0x3ee08f=_0x300bd0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x300bd0,{'phoneSignInInfo':{'recaptchaToken':_0x3ee08f,'captchaResponse':_0x9e47e6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x300bd0;}return _0xe792e7?Object['assign'](_0x300bd0,{'captchaResp':_0x9e47e6}):Object['assign'](_0x300bd0,{'captchaResponse':_0x9e47e6}),Object['assign'](_0x300bd0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x300bd0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x300bd0;}async function xi(_0xd74ae2,_0x80c022,_0x21e19b,_0x15c461,_0x24264c){var _0x1ad139;if((_0x1ad139=_0xd74ae2['_getRecaptchaConfig']())!=null&&_0x1ad139['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x29710f=await kr(_0xd74ae2,_0x80c022,_0x21e19b,_0x21e19b==='getOobCode');return _0x15c461(_0xd74ae2,_0x29710f);}else return _0x15c461(_0xd74ae2,_0x80c022)['catch'](async _0x34c48a=>{if(_0x34c48a['code']==='auth/missing-recaptcha-token'){console['log'](_0x21e19b+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1ed245=await kr(_0xd74ae2,_0x80c022,_0x21e19b,_0x21e19b==='getOobCode');return _0x15c461(_0xd74ae2,_0x1ed245);}else return Promise['reject'](_0x34c48a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x439cce,_0x12e60b){const _0x3125b5=Hi(_0x439cce,'auth');if(_0x3125b5['isInitialized']()){const _0x4f439d=_0x3125b5['getImmediate'](),_0x3743e4=_0x3125b5['getOptions']();if(xe(_0x3743e4,_0x12e60b??{}))return _0x4f439d;Y(_0x4f439d,'already-initialized');}return _0x3125b5['initialize']({'options':_0x12e60b});}function Hf(_0x583d15,_0x25d0b4){const _0x2cba2a=(_0x25d0b4==null?void 0x0:_0x25d0b4['persistence'])||[],_0x2e0f3c=(Array['isArray'](_0x2cba2a)?_0x2cba2a:[_0x2cba2a])['map'](ie);_0x25d0b4!=null&&_0x25d0b4['errorMap']&&_0x583d15['_updateErrorMap'](_0x25d0b4['errorMap']),_0x583d15['_initializeWithPersistence'](_0x2e0f3c,_0x25d0b4==null?void 0x0:_0x25d0b4['popupRedirectResolver']);}function $f(_0x4e516a,_0x354956,_0xde1f1e){const _0x11de4e=Ke(_0x4e516a);m(/^https?:\/\//['test'](_0x354956),_0x11de4e,'invalid-emulator-scheme');const _0x517193=!0x1,_0x290a2e=Ua(_0x354956),{host:_0x31f64f,port:_0x3be5e6}=Gf(_0x354956),_0x1bd5d3=_0x3be5e6===null?'':':'+_0x3be5e6,_0x32832b={'url':_0x290a2e+'//'+_0x31f64f+_0x1bd5d3+'/'},_0x2c3b7d=Object['freeze']({'host':_0x31f64f,'port':_0x3be5e6,'protocol':_0x290a2e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x517193})});if(!_0x11de4e['_canInitEmulator']){m(_0x11de4e['config']['emulator']&&_0x11de4e['emulatorConfig'],_0x11de4e,'emulator-config-failed'),m(xe(_0x32832b,_0x11de4e['config']['emulator'])&&xe(_0x2c3b7d,_0x11de4e['emulatorConfig']),_0x11de4e,'emulator-config-failed');return;}_0x11de4e['config']['emulator']=_0x32832b,_0x11de4e['emulatorConfig']=_0x2c3b7d,_0x11de4e['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x31f64f)?Qr(_0x290a2e+'//'+_0x31f64f+_0x1bd5d3):qf();}function Ua(_0x383a9e){const _0x25e9a4=_0x383a9e['indexOf'](':');return _0x25e9a4<0x0?'':_0x383a9e['substr'](0x0,_0x25e9a4+0x1);}function Gf(_0x20aa94){const _0x3d2ff8=Ua(_0x20aa94),_0x30c234=/(\/\/)?([^?#/]+)/['exec'](_0x20aa94['substr'](_0x3d2ff8['length']));if(!_0x30c234)return{'host':'','port':null};const _0x530cd0=_0x30c234[0x2]['split']('@')['pop']()||'',_0xa6373=/^(\[[^\]]+\])(:|$)/['exec'](_0x530cd0);if(_0xa6373){const _0x59123c=_0xa6373[0x1];return{'host':_0x59123c,'port':Pr(_0x530cd0['substr'](_0x59123c['length']+0x1))};}else{const [_0x5d79ef,_0x756cc7]=_0x530cd0['split'](':');return{'host':_0x5d79ef,'port':Pr(_0x756cc7)};}}function Pr(_0x435ed6){if(!_0x435ed6)return null;const _0x3e1c46=Number(_0x435ed6);return isNaN(_0x3e1c46)?null:_0x3e1c46;}function qf(){function _0x3a6d10(){const _0x2d43f0=document['createElement']('p'),_0x54873a=_0x2d43f0['style'];_0x2d43f0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x54873a['position']='fixed',_0x54873a['width']='100%',_0x54873a['backgroundColor']='#ffffff',_0x54873a['border']='.1em\x20solid\x20#000000',_0x54873a['color']='#b50000',_0x54873a['bottom']='0px',_0x54873a['left']='0px',_0x54873a['margin']='0px',_0x54873a['zIndex']='10000',_0x54873a['textAlign']='center',_0x2d43f0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2d43f0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3a6d10):_0x3a6d10());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x20e867,_0xc31b77){this['providerId']=_0x20e867,this['signInMethod']=_0xc31b77;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x1d8438){return ne('not\x20implemented');}['_linkToIdToken'](_0x37eca5,_0x14e44b){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1f2551){return ne('not\x20implemented');}}async function zf(_0x1c3578,_0x439f86){return Pe(_0x1c3578,'POST','/v1/accounts:signUp',_0x439f86);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x473693,_0x453aaf){return en(_0x473693,'POST','/v1/accounts:signInWithPassword',ke(_0x473693,_0x453aaf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x33ddb7,_0x309a46){return en(_0x33ddb7,'POST','/v1/accounts:signInWithEmailLink',ke(_0x33ddb7,_0x309a46));}async function Yf(_0x328f96,_0x3ce54a){return en(_0x328f96,'POST','/v1/accounts:signInWithEmailLink',ke(_0x328f96,_0x3ce54a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x50e3e1,_0x5d00d7,_0x1356f5,_0x97580d=null){super('password',_0x1356f5),this['_email']=_0x50e3e1,this['_password']=_0x5d00d7,this['_tenantId']=_0x97580d;}static['_fromEmailAndPassword'](_0x14bfbb,_0x3caf2b){return new $t(_0x14bfbb,_0x3caf2b,'password');}static['_fromEmailAndCode'](_0x451314,_0x5b4d1f,_0x3db596=null){return new $t(_0x451314,_0x5b4d1f,'emailLink',_0x3db596);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2c1094){const _0x1f265e=typeof _0x2c1094=='string'?JSON['parse'](_0x2c1094):_0x2c1094;if(_0x1f265e!=null&&_0x1f265e['email']&&(_0x1f265e!=null&&_0x1f265e['password'])){if(_0x1f265e['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1f265e['email'],_0x1f265e['password']);if(_0x1f265e['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1f265e['email'],_0x1f265e['password'],_0x1f265e['tenantId']);}return null;}async['_getIdTokenResponse'](_0xeb1cca){switch(this['signInMethod']){case'password':const _0x57e0f5={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0xeb1cca,_0x57e0f5,'signInWithPassword',jf);case'emailLink':return Kf(_0xeb1cca,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0xeb1cca,'internal-error');}}async['_linkToIdToken'](_0x3dae2a,_0x5439f3){switch(this['signInMethod']){case'password':const _0x36e8db={'idToken':_0x5439f3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3dae2a,_0x36e8db,'signUpPassword',zf);case'emailLink':return Yf(_0x3dae2a,{'idToken':_0x5439f3,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3dae2a,'internal-error');}}['_getReauthenticationResolver'](_0x36ac8d){return this['_getIdTokenResponse'](_0x36ac8d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x5a556c,_0x76982b){return en(_0x5a556c,'POST','/v1/accounts:signInWithIdp',ke(_0x5a556c,_0x76982b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x33e88e){const _0x531ef6=new $e(_0x33e88e['providerId'],_0x33e88e['signInMethod']);return _0x33e88e['idToken']||_0x33e88e['accessToken']?(_0x33e88e['idToken']&&(_0x531ef6['idToken']=_0x33e88e['idToken']),_0x33e88e['accessToken']&&(_0x531ef6['accessToken']=_0x33e88e['accessToken']),_0x33e88e['nonce']&&!_0x33e88e['pendingToken']&&(_0x531ef6['nonce']=_0x33e88e['nonce']),_0x33e88e['pendingToken']&&(_0x531ef6['pendingToken']=_0x33e88e['pendingToken'])):_0x33e88e['oauthToken']&&_0x33e88e['oauthTokenSecret']?(_0x531ef6['accessToken']=_0x33e88e['oauthToken'],_0x531ef6['secret']=_0x33e88e['oauthTokenSecret']):Y('argument-error'),_0x531ef6;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4db686){const _0x4e7bc6=typeof _0x4db686=='string'?JSON['parse'](_0x4db686):_0x4db686,{providerId:_0x24b604,signInMethod:_0x18752b,..._0x59f015}=_0x4e7bc6;if(!_0x24b604||!_0x18752b)return null;const _0x11ceaf=new $e(_0x24b604,_0x18752b);return _0x11ceaf['idToken']=_0x59f015['idToken']||void 0x0,_0x11ceaf['accessToken']=_0x59f015['accessToken']||void 0x0,_0x11ceaf['secret']=_0x59f015['secret'],_0x11ceaf['nonce']=_0x59f015['nonce'],_0x11ceaf['pendingToken']=_0x59f015['pendingToken']||null,_0x11ceaf;}['_getIdTokenResponse'](_0x4966ab){const _0x28b01e=this['buildRequest']();return nt(_0x4966ab,_0x28b01e);}['_linkToIdToken'](_0x5ebbbc,_0x2fae31){const _0x48713a=this['buildRequest']();return _0x48713a['idToken']=_0x2fae31,nt(_0x5ebbbc,_0x48713a);}['_getReauthenticationResolver'](_0x437f3a){const _0x3b4ee2=this['buildRequest']();return _0x3b4ee2['autoCreate']=!0x1,nt(_0x437f3a,_0x3b4ee2);}['buildRequest'](){const _0x364c87={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x364c87['pendingToken']=this['pendingToken'];else{const _0x62b8f={};this['idToken']&&(_0x62b8f['id_token']=this['idToken']),this['accessToken']&&(_0x62b8f['access_token']=this['accessToken']),this['secret']&&(_0x62b8f['oauth_token_secret']=this['secret']),_0x62b8f['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x62b8f['nonce']=this['nonce']),_0x364c87['postBody']=ut(_0x62b8f);}return _0x364c87;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1df3dc){switch(_0x1df3dc){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x35a08d){const _0x37a410=Ct(Tt(_0x35a08d))['link'],_0x1379ac=_0x37a410?Ct(Tt(_0x37a410))['deep_link_id']:null,_0x4de8e6=Ct(Tt(_0x35a08d))['deep_link_id'];return(_0x4de8e6?Ct(Tt(_0x4de8e6))['link']:null)||_0x4de8e6||_0x1379ac||_0x37a410||_0x35a08d;}class Rs{constructor(_0x4520b7){const _0xc847c0=Ct(Tt(_0x4520b7)),_0x2e0fbb=_0xc847c0['apiKey']??null,_0x8de2a6=_0xc847c0['oobCode']??null,_0x1ff065=Jf(_0xc847c0['mode']??null);m(_0x2e0fbb&&_0x8de2a6&&_0x1ff065,'argument-error'),this['apiKey']=_0x2e0fbb,this['operation']=_0x1ff065,this['code']=_0x8de2a6,this['continueUrl']=_0xc847c0['continueUrl']??null,this['languageCode']=_0xc847c0['lang']??null,this['tenantId']=_0xc847c0['tenantId']??null;}static['parseLink'](_0x26bbca){const _0x511bbc=Xf(_0x26bbca);try{return new Rs(_0x511bbc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x12f2b4,_0x5dcb93){return $t['_fromEmailAndPassword'](_0x12f2b4,_0x5dcb93);}static['credentialWithLink'](_0x26bc47,_0x225759){const _0x2842a0=Rs['parseLink'](_0x225759);return m(_0x2842a0,'argument-error'),$t['_fromEmailAndCode'](_0x26bc47,_0x2842a0['code'],_0x2842a0['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5cc916){this['providerId']=_0x5cc916,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3d5890){this['defaultLanguageCode']=_0x3d5890;}['setCustomParameters'](_0x361e51){return this['customParameters']=_0x361e51,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x36236a){return this['scopes']['includes'](_0x36236a)||this['scopes']['push'](_0x36236a),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x3b3357){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3b3357});}static['credentialFromResult'](_0x5d78da){return ue['credentialFromTaggedObject'](_0x5d78da);}static['credentialFromError'](_0x49bd28){return ue['credentialFromTaggedObject'](_0x49bd28['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1d0f52}){if(!_0x1d0f52||!('oauthAccessToken'in _0x1d0f52)||!_0x1d0f52['oauthAccessToken'])return null;try{return ue['credential'](_0x1d0f52['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x143b51,_0x5d72a3){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x143b51,'accessToken':_0x5d72a3});}static['credentialFromResult'](_0x1acd87){return de['credentialFromTaggedObject'](_0x1acd87);}static['credentialFromError'](_0xec5cab){return de['credentialFromTaggedObject'](_0xec5cab['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47ec19}){if(!_0x47ec19)return null;const {oauthIdToken:_0x2c2c0d,oauthAccessToken:_0x22caeb}=_0x47ec19;if(!_0x2c2c0d&&!_0x22caeb)return null;try{return de['credential'](_0x2c2c0d,_0x22caeb);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4e3f42){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4e3f42});}static['credentialFromResult'](_0x3af486){return fe['credentialFromTaggedObject'](_0x3af486);}static['credentialFromError'](_0x46557a){return fe['credentialFromTaggedObject'](_0x46557a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x32edc6}){if(!_0x32edc6||!('oauthAccessToken'in _0x32edc6)||!_0x32edc6['oauthAccessToken'])return null;try{return fe['credential'](_0x32edc6['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x5dc304,_0x43fb78){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5dc304,'oauthTokenSecret':_0x43fb78});}static['credentialFromResult'](_0x3ef9d4){return pe['credentialFromTaggedObject'](_0x3ef9d4);}static['credentialFromError'](_0x323fb8){return pe['credentialFromTaggedObject'](_0x323fb8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1fa5a7}){if(!_0x1fa5a7)return null;const {oauthAccessToken:_0xe7b873,oauthTokenSecret:_0x576f25}=_0x1fa5a7;if(!_0xe7b873||!_0x576f25)return null;try{return pe['credential'](_0xe7b873,_0x576f25);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x1c140d,_0x422a2e){return en(_0x1c140d,'POST','/v1/accounts:signUp',ke(_0x1c140d,_0x422a2e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x1b3513){this['user']=_0x1b3513['user'],this['providerId']=_0x1b3513['providerId'],this['_tokenResponse']=_0x1b3513['_tokenResponse'],this['operationType']=_0x1b3513['operationType'];}static async['_fromIdTokenResponse'](_0xcb23b,_0xc878a2,_0x3159d2,_0x2bb2d2=!0x1){const _0x15b774=await j['_fromIdTokenResponse'](_0xcb23b,_0x3159d2,_0x2bb2d2),_0x9910fe=Nr(_0x3159d2);return new Ge({'user':_0x15b774,'providerId':_0x9910fe,'_tokenResponse':_0x3159d2,'operationType':_0xc878a2});}static async['_forOperation'](_0x348a94,_0x81d3a6,_0x1eac69){await _0x348a94['_updateTokensIfNecessary'](_0x1eac69,!0x0);const _0x56758c=Nr(_0x1eac69);return new Ge({'user':_0x348a94,'providerId':_0x56758c,'_tokenResponse':_0x1eac69,'operationType':_0x81d3a6});}}function Nr(_0x596577){return _0x596577['providerId']?_0x596577['providerId']:'phoneNumber'in _0x596577?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x349191,_0x3392b3,_0x471821,_0x4a6082){super(_0x3392b3['code'],_0x3392b3['message']),this['operationType']=_0x471821,this['user']=_0x4a6082,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x349191['name'],'tenantId':_0x349191['tenantId']??void 0x0,'_serverResponse':_0x3392b3['customData']['_serverResponse'],'operationType':_0x471821};}static['_fromErrorAndOperation'](_0x428dee,_0x5841df,_0x3bd090,_0xd4e26e){return new On(_0x428dee,_0x5841df,_0x3bd090,_0xd4e26e);}}function Ba(_0xa4d4b3,_0x37639f,_0x1f6c5c,_0x5e1b24){return(_0x37639f==='reauthenticate'?_0x1f6c5c['_getReauthenticationResolver'](_0xa4d4b3):_0x1f6c5c['_getIdTokenResponse'](_0xa4d4b3))['catch'](_0x235734=>{throw _0x235734['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0xa4d4b3,_0x235734,_0x37639f,_0x5e1b24):_0x235734;});}async function ep(_0x72a46e,_0x2d3197,_0x46b93c=!0x1){const _0x57a1c2=await Ht(_0x72a46e,_0x2d3197['_linkToIdToken'](_0x72a46e['auth'],await _0x72a46e['getIdToken']()),_0x46b93c);return Ge['_forOperation'](_0x72a46e,'link',_0x57a1c2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x36fe00,_0x53a0d8,_0x43a88f=!0x1){const {auth:_0xeaaad7}=_0x36fe00;if($(_0xeaaad7['app']))return Promise['reject'](re(_0xeaaad7));const _0x2758af='reauthenticate';try{const _0x4dea6a=await Ht(_0x36fe00,Ba(_0xeaaad7,_0x2758af,_0x53a0d8,_0x36fe00),_0x43a88f);m(_0x4dea6a['idToken'],_0xeaaad7,'internal-error');const _0x4d6772=Ts(_0x4dea6a['idToken']);m(_0x4d6772,_0xeaaad7,'internal-error');const {sub:_0x30ee86}=_0x4d6772;return m(_0x36fe00['uid']===_0x30ee86,_0xeaaad7,'user-mismatch'),Ge['_forOperation'](_0x36fe00,_0x2758af,_0x4dea6a);}catch(_0x23f36f){throw(_0x23f36f==null?void 0x0:_0x23f36f['code'])==='auth/user-not-found'&&Y(_0xeaaad7,'user-mismatch'),_0x23f36f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1adfd9,_0x4065cc,_0x411045=!0x1){if($(_0x1adfd9['app']))return Promise['reject'](re(_0x1adfd9));const _0x2286f5='signIn',_0x1a13a6=await Ba(_0x1adfd9,_0x2286f5,_0x4065cc),_0x41d692=await Ge['_fromIdTokenResponse'](_0x1adfd9,_0x2286f5,_0x1a13a6);return _0x411045||await _0x1adfd9['_updateCurrentUser'](_0x41d692['user']),_0x41d692;}async function np(_0x3253a7,_0x48d2cf){return Va(Ke(_0x3253a7),_0x48d2cf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x18d55b){const _0x5dacf8=Ke(_0x18d55b);_0x5dacf8['_getPasswordPolicyInternal']()&&await _0x5dacf8['_updatePasswordPolicy']();}async function L_(_0x1e96a4,_0x1a283b,_0x3678e8){if($(_0x1e96a4['app']))return Promise['reject'](re(_0x1e96a4));const _0x30631e=Ke(_0x1e96a4),_0x1f0405=await xi(_0x30631e,{'returnSecureToken':!0x0,'email':_0x1a283b,'password':_0x3678e8,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x4656a9=>{throw _0x4656a9['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1e96a4),_0x4656a9;}),_0x117ac5=await Ge['_fromIdTokenResponse'](_0x30631e,'signIn',_0x1f0405);return await _0x30631e['_updateCurrentUser'](_0x117ac5['user']),_0x117ac5;}function x_(_0x431701,_0x4e81dd,_0x1d7e95){return $(_0x431701['app'])?Promise['reject'](re(_0x431701)):np(P(_0x431701),yt['credential'](_0x4e81dd,_0x1d7e95))['catch'](async _0x14dbcc=>{throw _0x14dbcc['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x431701),_0x14dbcc;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x15ea2e,_0x5d8059){return P(_0x15ea2e)['setPersistence'](_0x5d8059);}function ip(_0x4ed626,_0x57282f,_0x55400c,_0x40867c){return P(_0x4ed626)['onIdTokenChanged'](_0x57282f,_0x55400c,_0x40867c);}function sp(_0x2c6e4a,_0x2e67ab,_0x23d76d){return P(_0x2c6e4a)['beforeAuthStateChanged'](_0x2e67ab,_0x23d76d);}function U_(_0x406d06,_0x427952,_0x4b4921,_0x390f58){return P(_0x406d06)['onAuthStateChanged'](_0x427952,_0x4b4921,_0x390f58);}function W_(_0x3cbb15){return P(_0x3cbb15)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x26117e,_0x5e1019){this['storageRetriever']=_0x26117e,this['type']=_0x5e1019;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2639b2,_0x532290){return this['storage']['setItem'](_0x2639b2,JSON['stringify'](_0x532290)),Promise['resolve']();}['_get'](_0x2b60bc){const _0x103cec=this['storage']['getItem'](_0x2b60bc);return Promise['resolve'](_0x103cec?JSON['parse'](_0x103cec):null);}['_remove'](_0x43240c){return this['storage']['removeItem'](_0x43240c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x37ca86,_0x147b7b)=>this['onStorageEvent'](_0x37ca86,_0x147b7b),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1c1cd1){for(const _0x43dcb5 of Object['keys'](this['listeners'])){const _0x3c25d4=this['storage']['getItem'](_0x43dcb5),_0x50e484=this['localCache'][_0x43dcb5];_0x3c25d4!==_0x50e484&&_0x1c1cd1(_0x43dcb5,_0x50e484,_0x3c25d4);}}['onStorageEvent'](_0x3f9ae5,_0x2204a8=!0x1){if(!_0x3f9ae5['key']){this['forAllChangedKeys']((_0x172ed7,_0x250405,_0x511e46)=>{this['notifyListeners'](_0x172ed7,_0x511e46);});return;}const _0x50f39b=_0x3f9ae5['key'];_0x2204a8?this['detachListener']():this['stopPolling']();const _0x32a1ee=()=>{const _0x90b601=this['storage']['getItem'](_0x50f39b);!_0x2204a8&&this['localCache'][_0x50f39b]===_0x90b601||this['notifyListeners'](_0x50f39b,_0x90b601);},_0x3d1dbb=this['storage']['getItem'](_0x50f39b);Af()&&_0x3d1dbb!==_0x3f9ae5['newValue']&&_0x3f9ae5['newValue']!==_0x3f9ae5['oldValue']?setTimeout(_0x32a1ee,op):_0x32a1ee();}['notifyListeners'](_0x3595ff,_0x4d2f71){this['localCache'][_0x3595ff]=_0x4d2f71;const _0x12da9c=this['listeners'][_0x3595ff];if(_0x12da9c){for(const _0x168a5e of Array['from'](_0x12da9c))_0x168a5e(_0x4d2f71&&JSON['parse'](_0x4d2f71));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x30cf8d,_0x4612c8,_0x418153)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x30cf8d,'oldValue':_0x4612c8,'newValue':_0x418153}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4c3ff0,_0x2be2f3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4c3ff0]||(this['listeners'][_0x4c3ff0]=new Set(),this['localCache'][_0x4c3ff0]=this['storage']['getItem'](_0x4c3ff0)),this['listeners'][_0x4c3ff0]['add'](_0x2be2f3);}['_removeListener'](_0x1c0719,_0x1f04b8){this['listeners'][_0x1c0719]&&(this['listeners'][_0x1c0719]['delete'](_0x1f04b8),this['listeners'][_0x1c0719]['size']===0x0&&delete this['listeners'][_0x1c0719]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x555b97,_0x333886){await super['_set'](_0x555b97,_0x333886),this['localCache'][_0x555b97]=JSON['stringify'](_0x333886);}async['_get'](_0x31ec7e){const _0x7c6831=await super['_get'](_0x31ec7e);return this['localCache'][_0x31ec7e]=JSON['stringify'](_0x7c6831),_0x7c6831;}async['_remove'](_0x2991be){await super['_remove'](_0x2991be),delete this['localCache'][_0x2991be];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xb2548f,_0x522b4f){}['_removeListener'](_0x30f537,_0x468fd2){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2f9adf){return Promise['all'](_0x2f9adf['map'](async _0x745fb8=>{try{return{'fulfilled':!0x0,'value':await _0x745fb8};}catch(_0x1d373){return{'fulfilled':!0x1,'reason':_0x1d373};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4c756c){this['eventTarget']=_0x4c756c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4ac944){const _0x5c2bbe=this['receivers']['find'](_0x5f4826=>_0x5f4826['isListeningto'](_0x4ac944));if(_0x5c2bbe)return _0x5c2bbe;const _0x3e59be=new Xn(_0x4ac944);return this['receivers']['push'](_0x3e59be),_0x3e59be;}['isListeningto'](_0x1906ed){return this['eventTarget']===_0x1906ed;}async['handleEvent'](_0xacfcde){const _0x602fa6=_0xacfcde,{eventId:_0x3bcf69,eventType:_0x2e598b,data:_0x16634e}=_0x602fa6['data'],_0x62f25a=this['handlersMap'][_0x2e598b];if(!(_0x62f25a!=null&&_0x62f25a['size']))return;_0x602fa6['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3bcf69,'eventType':_0x2e598b});const _0x7b641f=Array['from'](_0x62f25a)['map'](async _0x1763ad=>_0x1763ad(_0x602fa6['origin'],_0x16634e)),_0x27735b=await cp(_0x7b641f);_0x602fa6['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3bcf69,'eventType':_0x2e598b,'response':_0x27735b});}['_subscribe'](_0xce4cf1,_0x5de009){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xce4cf1]||(this['handlersMap'][_0xce4cf1]=new Set()),this['handlersMap'][_0xce4cf1]['add'](_0x5de009);}['_unsubscribe'](_0x491714,_0x313fae){this['handlersMap'][_0x491714]&&_0x313fae&&this['handlersMap'][_0x491714]['delete'](_0x313fae),(!_0x313fae||this['handlersMap'][_0x491714]['size']===0x0)&&delete this['handlersMap'][_0x491714],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x15361b='',_0x74c437=0xa){let _0x51ba01='';for(let _0x656655=0x0;_0x656655<_0x74c437;_0x656655++)_0x51ba01+=Math['floor'](Math['random']()*0xa);return _0x15361b+_0x51ba01;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1c898f){this['target']=_0x1c898f,this['handlers']=new Set();}['removeMessageHandler'](_0x4f4546){_0x4f4546['messageChannel']&&(_0x4f4546['messageChannel']['port1']['removeEventListener']('message',_0x4f4546['onMessage']),_0x4f4546['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4f4546);}async['_send'](_0x391313,_0x345685,_0x4203dc=0x32){const _0x109729=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x109729)throw new Error('connection_unavailable');let _0x2c7f4b,_0x49afaf;return new Promise((_0xcc4eb3,_0x2191ea)=>{const _0x14f6a7=As('',0x14);_0x109729['port1']['start']();const _0x18a82a=setTimeout(()=>{_0x2191ea(new Error('unsupported_event'));},_0x4203dc);_0x49afaf={'messageChannel':_0x109729,'onMessage'(_0x3970fa){const _0x10dc58=_0x3970fa;if(_0x10dc58['data']['eventId']===_0x14f6a7)switch(_0x10dc58['data']['status']){case'ack':clearTimeout(_0x18a82a),_0x2c7f4b=setTimeout(()=>{_0x2191ea(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2c7f4b),_0xcc4eb3(_0x10dc58['data']['response']);break;default:clearTimeout(_0x18a82a),clearTimeout(_0x2c7f4b),_0x2191ea(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x49afaf),_0x109729['port1']['addEventListener']('message',_0x49afaf['onMessage']),this['target']['postMessage']({'eventType':_0x391313,'eventId':_0x14f6a7,'data':_0x345685},[_0x109729['port2']]);})['finally'](()=>{_0x49afaf&&this['removeMessageHandler'](_0x49afaf);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4d522e){Z()['location']['href']=_0x4d522e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x518695;return((_0x518695=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x518695['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x302941){this['request']=_0x302941;}['toPromise'](){return new Promise((_0xa86d2e,_0x2f58e1)=>{this['request']['addEventListener']('success',()=>{_0xa86d2e(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2f58e1(this['request']['error']);});});}}function Zn(_0x2f5024,_0x1af0b2){return _0x2f5024['transaction']([Mn],_0x1af0b2?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x54d3c7=indexedDB['deleteDatabase'](Ka);return new nn(_0x54d3c7)['toPromise']();}function Qa(){const _0x537873=indexedDB['open'](Ka,pp);return new Promise((_0x45dcf6,_0x269705)=>{_0x537873['addEventListener']('error',()=>{_0x269705(_0x537873['error']);}),_0x537873['addEventListener']('upgradeneeded',()=>{const _0x504600=_0x537873['result'];try{_0x504600['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x127c43){_0x269705(_0x127c43);}}),_0x537873['addEventListener']('success',async()=>{const _0x10572b=_0x537873['result'];_0x10572b['objectStoreNames']['contains'](Mn)?_0x45dcf6(_0x10572b):(_0x10572b['close'](),await _p(),_0x45dcf6(await Qa()));});});}async function Or(_0x179dda,_0x3f24d7,_0x5b4674){const _0x412e3d=Zn(_0x179dda,!0x0)['put']({[Ya]:_0x3f24d7,'value':_0x5b4674});return new nn(_0x412e3d)['toPromise']();}async function gp(_0x53d2d0,_0x3f4490){const _0x17f8d8=Zn(_0x53d2d0,!0x1)['get'](_0x3f4490),_0x54d27f=await new nn(_0x17f8d8)['toPromise']();return _0x54d27f===void 0x0?null:_0x54d27f['value'];}function Dr(_0x1c26f3,_0x4e9bba){const _0x2f50be=Zn(_0x1c26f3,!0x0)['delete'](_0x4e9bba);return new nn(_0x2f50be)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x254519){let _0x9da4e6=0x0;for(;;)try{const _0x4b70a9=await this['_openDb']();return await _0x254519(_0x4b70a9);}catch(_0x383dfe){if(_0x9da4e6++>yp)throw _0x383dfe;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x3c0a33,_0x24c37a)=>({'keyProcessed':(await this['_poll']())['includes'](_0x24c37a['key'])})),this['receiver']['_subscribe']('ping',async(_0x211502,_0x44112d)=>['keyChanged']);}async['initializeSender'](){var _0x494744,_0x3be7fe;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x25a359=await this['sender']['_send']('ping',{},0x320);_0x25a359&&(_0x494744=_0x25a359[0x0])!=null&&_0x494744['fulfilled']&&(_0x3be7fe=_0x25a359[0x0])!=null&&_0x3be7fe['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4b649d){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4b649d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x50d285=>{await Or(_0x50d285,Dn,'1'),await Dr(_0x50d285,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2dbf87){this['pendingWrites']++;try{await _0x2dbf87();}finally{this['pendingWrites']--;}}async['_set'](_0xeeb429,_0xf370c6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x409154=>Or(_0x409154,_0xeeb429,_0xf370c6)),this['localCache'][_0xeeb429]=_0xf370c6,this['notifyServiceWorker'](_0xeeb429)));}async['_get'](_0x5238f8){const _0x5ac2eb=await this['_withRetries'](_0x538167=>gp(_0x538167,_0x5238f8));return this['localCache'][_0x5238f8]=_0x5ac2eb,_0x5ac2eb;}async['_remove'](_0xc6cb2e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x9be1f8=>Dr(_0x9be1f8,_0xc6cb2e)),delete this['localCache'][_0xc6cb2e],this['notifyServiceWorker'](_0xc6cb2e)));}async['_poll'](){const _0x3a5890=await this['_withRetries'](_0x1d769f=>{const _0x385c9a=Zn(_0x1d769f,!0x1)['getAll']();return new nn(_0x385c9a)['toPromise']();});if(!_0x3a5890)return[];if(this['pendingWrites']!==0x0)return[];const _0x2776ae=[],_0x1d5e9e=new Set();if(_0x3a5890['length']!==0x0){for(const {fbase_key:_0x5df252,value:_0x3eb8c7}of _0x3a5890)_0x1d5e9e['add'](_0x5df252),JSON['stringify'](this['localCache'][_0x5df252])!==JSON['stringify'](_0x3eb8c7)&&(this['notifyListeners'](_0x5df252,_0x3eb8c7),_0x2776ae['push'](_0x5df252));}for(const _0x3bfeb1 of Object['keys'](this['localCache']))this['localCache'][_0x3bfeb1]&&!_0x1d5e9e['has'](_0x3bfeb1)&&(this['notifyListeners'](_0x3bfeb1,null),_0x2776ae['push'](_0x3bfeb1));return _0x2776ae;}['notifyListeners'](_0x1ef2e4,_0x58b193){this['localCache'][_0x1ef2e4]=_0x58b193;const _0x171127=this['listeners'][_0x1ef2e4];if(_0x171127){for(const _0x2c3bd8 of Array['from'](_0x171127))_0x2c3bd8(_0x58b193);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3a6c2a,_0xe4c0f8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3a6c2a]||(this['listeners'][_0x3a6c2a]=new Set(),this['_get'](_0x3a6c2a)),this['listeners'][_0x3a6c2a]['add'](_0xe4c0f8);}['_removeListener'](_0x17060c,_0x5941bd){this['listeners'][_0x17060c]&&(this['listeners'][_0x17060c]['delete'](_0x5941bd),this['listeners'][_0x17060c]['size']===0x0&&delete this['listeners'][_0x17060c]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x558ac8,_0x2bbcf3){return _0x2bbcf3?ie(_0x2bbcf3):(m(_0x558ac8['_popupRedirectResolver'],_0x558ac8,'argument-error'),_0x558ac8['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x460775){super('custom','custom'),this['params']=_0x460775;}['_getIdTokenResponse'](_0x14c078){return nt(_0x14c078,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3d7c50,_0x58ab0c){return nt(_0x3d7c50,this['_buildIdpRequest'](_0x58ab0c));}['_getReauthenticationResolver'](_0x321d39){return nt(_0x321d39,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1734dd){const _0x141fdf={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1734dd&&(_0x141fdf['idToken']=_0x1734dd),_0x141fdf;}}function Ip(_0x1d28fa){return Va(_0x1d28fa['auth'],new ks(_0x1d28fa),_0x1d28fa['bypassAuthState']);}function wp(_0x5ec65e){const {auth:_0x35fa19,user:_0x39bf0e}=_0x5ec65e;return m(_0x39bf0e,_0x35fa19,'internal-error'),tp(_0x39bf0e,new ks(_0x5ec65e),_0x5ec65e['bypassAuthState']);}async function Cp(_0x2f8dd8){const {auth:_0xe37cc3,user:_0x4c9c69}=_0x2f8dd8;return m(_0x4c9c69,_0xe37cc3,'internal-error'),ep(_0x4c9c69,new ks(_0x2f8dd8),_0x2f8dd8['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0xbae5bb,_0x5bd4d1,_0xc35124,_0x446307,_0x3a7c2f=!0x1){this['auth']=_0xbae5bb,this['resolver']=_0xc35124,this['user']=_0x446307,this['bypassAuthState']=_0x3a7c2f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5bd4d1)?_0x5bd4d1:[_0x5bd4d1];}['execute'](){return new Promise(async(_0x1928e2,_0x10db9e)=>{this['pendingPromise']={'resolve':_0x1928e2,'reject':_0x10db9e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3a8439){this['reject'](_0x3a8439);}});}async['onAuthEvent'](_0x12f8ad){const {urlResponse:_0x561461,sessionId:_0x59c000,postBody:_0x2f8a31,tenantId:_0x40ee1a,error:_0x4ca6fe,type:_0x50890d}=_0x12f8ad;if(_0x4ca6fe){this['reject'](_0x4ca6fe);return;}const _0x1b82f7={'auth':this['auth'],'requestUri':_0x561461,'sessionId':_0x59c000,'tenantId':_0x40ee1a||void 0x0,'postBody':_0x2f8a31||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x50890d)(_0x1b82f7));}catch(_0x44ef05){this['reject'](_0x44ef05);}}['onError'](_0x923c08){this['reject'](_0x923c08);}['getIdpTask'](_0x130e6a){switch(_0x130e6a){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x27adfb){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x27adfb),this['unregisterAndCleanUp']();}['reject'](_0x5e5e5b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5e5e5b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0xba43,_0x553835,_0x1a8ca0,_0x295412,_0x327ba9){super(_0xba43,_0x553835,_0x295412,_0x327ba9),this['provider']=_0x1a8ca0,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4e8a94=await this['execute']();return m(_0x4e8a94,this['auth'],'internal-error'),_0x4e8a94;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1ad32f=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1ad32f),this['authWindow']['associatedEvent']=_0x1ad32f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2d3ea3=>{this['reject'](_0x2d3ea3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4644ed=>{_0x4644ed||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4436ae;return((_0x4436ae=this['authWindow'])==null?void 0x0:_0x4436ae['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1776d8=()=>{var _0x47bb88,_0x479269;if((_0x479269=(_0x47bb88=this['authWindow'])==null?void 0x0:_0x47bb88['window'])!=null&&_0x479269['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1776d8,Tp['get']());};_0x1776d8();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x244cdc,_0x173c5a,_0x2d7439=!0x1){super(_0x244cdc,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x173c5a,void 0x0,_0x2d7439),this['eventId']=null;}async['execute'](){let _0x9e3e23=hn['get'](this['auth']['_key']());if(!_0x9e3e23){try{const _0x5b05b8=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x9e3e23=()=>Promise['resolve'](_0x5b05b8);}catch(_0x19cb78){_0x9e3e23=()=>Promise['reject'](_0x19cb78);}hn['set'](this['auth']['_key'](),_0x9e3e23);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x9e3e23();}async['onAuthEvent'](_0x496f82){if(_0x496f82['type']==='signInViaRedirect')return super['onAuthEvent'](_0x496f82);if(_0x496f82['type']==='unknown'){this['resolve'](null);return;}if(_0x496f82['eventId']){const _0x581b01=await this['auth']['_redirectUserForId'](_0x496f82['eventId']);if(_0x581b01)return this['user']=_0x581b01,super['onAuthEvent'](_0x496f82);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x5db47e,_0x1c75ea){const _0x143572=Pp(_0x1c75ea),_0x180600=kp(_0x5db47e);if(!await _0x180600['_isAvailable']())return!0x1;const _0x465d80=await _0x180600['_get'](_0x143572)==='true';return await _0x180600['_remove'](_0x143572),_0x465d80;}function Ap(_0x43afa3,_0x4c4f7d){hn['set'](_0x43afa3['_key'](),_0x4c4f7d);}function kp(_0x5addcd){return ie(_0x5addcd['_redirectPersistence']);}function Pp(_0x3fc447){return ln(Sp,_0x3fc447['config']['apiKey'],_0x3fc447['name']);}async function Np(_0x157b1e,_0xa9c450,_0x20ca0c=!0x1){if($(_0x157b1e['app']))return Promise['reject'](re(_0x157b1e));const _0x47c136=Ke(_0x157b1e),_0x1e6256=Ep(_0x47c136,_0xa9c450),_0x57ef02=await new bp(_0x47c136,_0x1e6256,_0x20ca0c)['execute']();return _0x57ef02&&!_0x20ca0c&&(delete _0x57ef02['user']['_redirectEventId'],await _0x47c136['_persistUserIfCurrent'](_0x57ef02['user']),await _0x47c136['_setRedirectUser'](null,_0xa9c450)),_0x57ef02;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x45b73c){this['auth']=_0x45b73c,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x321ca5){this['consumers']['add'](_0x321ca5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x321ca5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x321ca5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x327a01){this['consumers']['delete'](_0x327a01);}['onEvent'](_0x16ebe9){if(this['hasEventBeenHandled'](_0x16ebe9))return!0x1;let _0x1ab38f=!0x1;return this['consumers']['forEach'](_0x5c62c2=>{this['isEventForConsumer'](_0x16ebe9,_0x5c62c2)&&(_0x1ab38f=!0x0,this['sendToConsumer'](_0x16ebe9,_0x5c62c2),this['saveEventToCache'](_0x16ebe9));}),this['hasHandledPotentialRedirect']||!Mp(_0x16ebe9)||(this['hasHandledPotentialRedirect']=!0x0,_0x1ab38f||(this['queuedRedirectEvent']=_0x16ebe9,_0x1ab38f=!0x0)),_0x1ab38f;}['sendToConsumer'](_0x34b4af,_0x3f7183){var _0x4e84b9;if(_0x34b4af['error']&&!Za(_0x34b4af)){const _0x105f11=((_0x4e84b9=_0x34b4af['error']['code'])==null?void 0x0:_0x4e84b9['split']('auth/')[0x1])||'internal-error';_0x3f7183['onError'](X(this['auth'],_0x105f11));}else _0x3f7183['onAuthEvent'](_0x34b4af);}['isEventForConsumer'](_0x5dced1,_0x56754b){const _0x29b4b7=_0x56754b['eventId']===null||!!_0x5dced1['eventId']&&_0x5dced1['eventId']===_0x56754b['eventId'];return _0x56754b['filter']['includes'](_0x5dced1['type'])&&_0x29b4b7;}['hasEventBeenHandled'](_0x44016b){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x44016b));}['saveEventToCache'](_0x47e9b4){this['cachedEventUids']['add'](Mr(_0x47e9b4)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2899be){return[_0x2899be['type'],_0x2899be['eventId'],_0x2899be['sessionId'],_0x2899be['tenantId']]['filter'](_0x4c6de3=>_0x4c6de3)['join']('-');}function Za({type:_0x1726e0,error:_0x5acdb1}){return _0x1726e0==='unknown'&&(_0x5acdb1==null?void 0x0:_0x5acdb1['code'])==='auth/no-auth-event';}function Mp(_0x207a15){switch(_0x207a15['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x207a15);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3864fe,_0x27436a={}){return Pe(_0x3864fe,'GET','/v1/projects',_0x27436a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x139835){if(_0x139835['config']['emulator'])return;const {authorizedDomains:_0x805b1c}=await Lp(_0x139835);for(const _0x385cc7 of _0x805b1c)try{if(Wp(_0x385cc7))return;}catch{}Y(_0x139835,'unauthorized-domain');}function Wp(_0x5bff2e){const _0x3381ff=Mi(),{protocol:_0x14becc,hostname:_0x4d71b3}=new URL(_0x3381ff);if(_0x5bff2e['startsWith']('chrome-extension://')){const _0x121138=new URL(_0x5bff2e);return _0x121138['hostname']===''&&_0x4d71b3===''?_0x14becc==='chrome-extension:'&&_0x5bff2e['replace']('chrome-extension://','')===_0x3381ff['replace']('chrome-extension://',''):_0x14becc==='chrome-extension:'&&_0x121138['hostname']===_0x4d71b3;}if(!Fp['test'](_0x14becc))return!0x1;if(xp['test'](_0x5bff2e))return _0x4d71b3===_0x5bff2e;const _0x2f8b15=_0x5bff2e['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2f8b15+'|'+_0x2f8b15+')$','i')['test'](_0x4d71b3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x3b1199=Z()['___jsl'];if(_0x3b1199!=null&&_0x3b1199['H']){for(const _0x5be523 of Object['keys'](_0x3b1199['H']))if(_0x3b1199['H'][_0x5be523]['r']=_0x3b1199['H'][_0x5be523]['r']||[],_0x3b1199['H'][_0x5be523]['L']=_0x3b1199['H'][_0x5be523]['L']||[],_0x3b1199['H'][_0x5be523]['r']=[..._0x3b1199['H'][_0x5be523]['L']],_0x3b1199['CP']){for(let _0x4cf5eb=0x0;_0x4cf5eb<_0x3b1199['CP']['length'];_0x4cf5eb++)_0x3b1199['CP'][_0x4cf5eb]=null;}}}function Vp(_0x48e2ab){return new Promise((_0x2c17eb,_0x50222e)=>{var _0x2d9e55,_0x502735,_0x2b124e;function _0xde983c(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2c17eb(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x50222e(X(_0x48e2ab,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x502735=(_0x2d9e55=Z()['gapi'])==null?void 0x0:_0x2d9e55['iframes'])!=null&&_0x502735['Iframe'])_0x2c17eb(gapi['iframes']['getContext']());else{if((_0x2b124e=Z()['gapi'])!=null&&_0x2b124e['load'])_0xde983c();else{const _0xe5be17=Ff('iframefcb');return Z()[_0xe5be17]=()=>{gapi['load']?_0xde983c():_0x50222e(X(_0x48e2ab,'network-request-failed'));},xa(xf()+'?onload='+_0xe5be17)['catch'](_0x56caba=>_0x50222e(_0x56caba));}}})['catch'](_0x5dcf79=>{throw un=null,_0x5dcf79;});}let un=null;function Hp(_0x7f3eff){return un=un||Vp(_0x7f3eff),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x3c4b62){const _0x557194=_0x3c4b62['config'];m(_0x557194['authDomain'],_0x3c4b62,'auth-domain-config-required');const _0x192141=_0x557194['emulator']?Cs(_0x557194,qp):'https://'+_0x3c4b62['config']['authDomain']+'/'+Gp,_0x5f436f={'apiKey':_0x557194['apiKey'],'appName':_0x3c4b62['name'],'v':dt},_0x3435de=jp['get'](_0x3c4b62['config']['apiHost']);_0x3435de&&(_0x5f436f['eid']=_0x3435de);const _0x3d08ed=_0x3c4b62['_getFrameworks']();return _0x3d08ed['length']&&(_0x5f436f['fw']=_0x3d08ed['join'](',')),_0x192141+'?'+ut(_0x5f436f)['slice'](0x1);}async function Yp(_0x4227aa){const _0x269a79=await Hp(_0x4227aa),_0x371f9e=Z()['gapi'];return m(_0x371f9e,_0x4227aa,'internal-error'),_0x269a79['open']({'where':document['body'],'url':Kp(_0x4227aa),'messageHandlersFilter':_0x371f9e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x376a81=>new Promise(async(_0x44aad8,_0x5538a4)=>{await _0x376a81['restyle']({'setHideOnLeave':!0x1});const _0x4d22cf=X(_0x4227aa,'network-request-failed'),_0x4ddb10=Z()['setTimeout'](()=>{_0x5538a4(_0x4d22cf);},$p['get']());function _0x433006(){Z()['clearTimeout'](_0x4ddb10),_0x44aad8(_0x376a81);}_0x376a81['ping'](_0x433006)['then'](_0x433006,()=>{_0x5538a4(_0x4d22cf);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x38748f){this['window']=_0x38748f,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x2eea0b,_0x9f5080,_0x4f0cce,_0x1e74c1=Jp,_0x26c49d=Xp){const _0x2e0c5b=Math['max']((window['screen']['availHeight']-_0x26c49d)/0x2,0x0)['toString'](),_0x6f5379=Math['max']((window['screen']['availWidth']-_0x1e74c1)/0x2,0x0)['toString']();let _0x22642c='';const _0x162694={...Qp,'width':_0x1e74c1['toString'](),'height':_0x26c49d['toString'](),'top':_0x2e0c5b,'left':_0x6f5379},_0xc41bd6=W()['toLowerCase']();_0x4f0cce&&(_0x22642c=ka(_0xc41bd6)?Zp:_0x4f0cce),Ra(_0xc41bd6)&&(_0x9f5080=_0x9f5080||e_,_0x162694['scrollbars']='yes');const _0x58500a=Object['entries'](_0x162694)['reduce']((_0x2b4355,[_0x43f4ad,_0x4a0887])=>''+_0x2b4355+_0x43f4ad+'='+_0x4a0887+',','');if(Rf(_0xc41bd6)&&_0x22642c!=='_self')return n_(_0x9f5080||'',_0x22642c),new xr(null);const _0x22bda0=window['open'](_0x9f5080||'',_0x22642c,_0x58500a);m(_0x22bda0,_0x2eea0b,'popup-blocked');try{_0x22bda0['focus']();}catch{}return new xr(_0x22bda0);}function n_(_0x6b2539,_0x11e870){const _0x28ff55=document['createElement']('a');_0x28ff55['href']=_0x6b2539,_0x28ff55['target']=_0x11e870;const _0x3a02bd=document['createEvent']('MouseEvent');_0x3a02bd['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x28ff55['dispatchEvent'](_0x3a02bd);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x51b1e6,_0x14e1db,_0xb5cfcf,_0x523f76,_0x16b230,_0x40c7f5){m(_0x51b1e6['config']['authDomain'],_0x51b1e6,'auth-domain-config-required'),m(_0x51b1e6['config']['apiKey'],_0x51b1e6,'invalid-api-key');const _0x24c108={'apiKey':_0x51b1e6['config']['apiKey'],'appName':_0x51b1e6['name'],'authType':_0xb5cfcf,'redirectUrl':_0x523f76,'v':dt,'eventId':_0x16b230};if(_0x14e1db instanceof Wa){_0x14e1db['setDefaultLanguage'](_0x51b1e6['languageCode']),_0x24c108['providerId']=_0x14e1db['providerId']||'',pn(_0x14e1db['getCustomParameters']())||(_0x24c108['customParameters']=JSON['stringify'](_0x14e1db['getCustomParameters']()));for(const [_0x3b65fb,_0x5a7587]of Object['entries']({}))_0x24c108[_0x3b65fb]=_0x5a7587;}if(_0x14e1db instanceof tn){const _0x18ce23=_0x14e1db['getScopes']()['filter'](_0x261eb6=>_0x261eb6!=='');_0x18ce23['length']>0x0&&(_0x24c108['scopes']=_0x18ce23['join'](','));}_0x51b1e6['tenantId']&&(_0x24c108['tid']=_0x51b1e6['tenantId']);const _0x321cdd=_0x24c108;for(const _0x318c9b of Object['keys'](_0x321cdd))_0x321cdd[_0x318c9b]===void 0x0&&delete _0x321cdd[_0x318c9b];const _0x4682d0=await _0x51b1e6['_getAppCheckToken'](),_0x193620=_0x4682d0?'#'+r_+'='+encodeURIComponent(_0x4682d0):'';return o_(_0x51b1e6)+'?'+ut(_0x321cdd)['slice'](0x1)+_0x193620;}function o_({config:_0x52a77b}){return _0x52a77b['emulator']?Cs(_0x52a77b,s_):'https://'+_0x52a77b['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x386a91,_0x7f1027,_0x2e1650,_0x349cb2){var _0x44f9a3;ce((_0x44f9a3=this['eventManagers'][_0x386a91['_key']()])==null?void 0x0:_0x44f9a3['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4f4c1c=await Fr(_0x386a91,_0x7f1027,_0x2e1650,Mi(),_0x349cb2);return t_(_0x386a91,_0x4f4c1c,As());}async['_openRedirect'](_0x8a7d1f,_0x421993,_0x174bc4,_0x26e8df){await this['_originValidation'](_0x8a7d1f);const _0x5baafc=await Fr(_0x8a7d1f,_0x421993,_0x174bc4,Mi(),_0x26e8df);return hp(_0x5baafc),new Promise(()=>{});}['_initialize'](_0xa66dc8){const _0x3efddf=_0xa66dc8['_key']();if(this['eventManagers'][_0x3efddf]){const {manager:_0x470ce3,promise:_0x3d040f}=this['eventManagers'][_0x3efddf];return _0x470ce3?Promise['resolve'](_0x470ce3):(ce(_0x3d040f,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3d040f);}const _0x326afd=this['initAndGetManager'](_0xa66dc8);return this['eventManagers'][_0x3efddf]={'promise':_0x326afd},_0x326afd['catch'](()=>{delete this['eventManagers'][_0x3efddf];}),_0x326afd;}async['initAndGetManager'](_0x3f7666){const _0x1272af=await Yp(_0x3f7666),_0x61e0cd=new Dp(_0x3f7666);return _0x1272af['register']('authEvent',_0x434aea=>(m(_0x434aea==null?void 0x0:_0x434aea['authEvent'],_0x3f7666,'invalid-auth-event'),{'status':_0x61e0cd['onEvent'](_0x434aea['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3f7666['_key']()]={'manager':_0x61e0cd},this['iframes'][_0x3f7666['_key']()]=_0x1272af,_0x61e0cd;}['_isIframeWebStorageSupported'](_0x3af77d,_0x42b040){this['iframes'][_0x3af77d['_key']()]['send'](pi,{'type':pi},_0x5ce60e=>{var _0x1556af;const _0x206c37=(_0x1556af=_0x5ce60e==null?void 0x0:_0x5ce60e[0x0])==null?void 0x0:_0x1556af[pi];_0x206c37!==void 0x0&&_0x42b040(!!_0x206c37),Y(_0x3af77d,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xc9f851){const _0x522166=_0xc9f851['_key']();return this['originValidationPromises'][_0x522166]||(this['originValidationPromises'][_0x522166]=Up(_0xc9f851)),this['originValidationPromises'][_0x522166];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x264013){this['auth']=_0x264013,this['internalListeners']=new Map();}['getUid'](){var _0x27442e;return this['assertAuthConfigured'](),((_0x27442e=this['auth']['currentUser'])==null?void 0x0:_0x27442e['uid'])||null;}async['getToken'](_0x4d8c36){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4d8c36)}:null;}['addAuthTokenListener'](_0xc0f138){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xc0f138))return;const _0x2dfb73=this['auth']['onIdTokenChanged'](_0x2e41b3=>{_0xc0f138((_0x2e41b3==null?void 0x0:_0x2e41b3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xc0f138,_0x2dfb73),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xb71902){this['assertAuthConfigured']();const _0x21a037=this['internalListeners']['get'](_0xb71902);_0x21a037&&(this['internalListeners']['delete'](_0xb71902),_0x21a037(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3951b5){switch(_0x3951b5){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x41276e){st(new Fe('auth',(_0x5c55e5,{options:_0x21d328})=>{const _0x5f56e9=_0x5c55e5['getProvider']('app')['getImmediate'](),_0x48a0e7=_0x5c55e5['getProvider']('heartbeat'),_0x340481=_0x5c55e5['getProvider']('app-check-internal'),{apiKey:_0x5b2683,authDomain:_0x4705c2}=_0x5f56e9['options'];m(_0x5b2683&&!_0x5b2683['includes'](':'),'invalid-api-key',{'appName':_0x5f56e9['name']});const _0x5bcd59={'apiKey':_0x5b2683,'authDomain':_0x4705c2,'clientPlatform':_0x41276e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x41276e)},_0x22870f=new Df(_0x5f56e9,_0x48a0e7,_0x340481,_0x5bcd59);return Hf(_0x22870f,_0x21d328),_0x22870f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x33b45b,_0x585145,_0x1b9cf1)=>{_0x33b45b['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x37f6cd=>{const _0x8c6f5f=Ke(_0x37f6cd['getProvider']('auth')['getImmediate']());return(_0x49bbb7=>new l_(_0x49bbb7))(_0x8c6f5f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x41276e)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x4be498=>async _0x260355=>{const _0x4a5a8f=_0x260355&&await _0x260355['getIdTokenResult'](),_0x8245d7=_0x4a5a8f&&(new Date()['getTime']()-Date['parse'](_0x4a5a8f['issuedAtTime']))/0x3e8;if(_0x8245d7&&_0x8245d7>f_)return;const _0x33a3ca=_0x4a5a8f==null?void 0x0:_0x4a5a8f['token'];Br!==_0x33a3ca&&(Br=_0x33a3ca,await fetch(_0x4be498,{'method':_0x33a3ca?'POST':'DELETE','headers':_0x33a3ca?{'Authorization':'Bearer\x20'+_0x33a3ca}:{}}));};function B_(_0x319ece=Zr()){const _0x2d02da=Hi(_0x319ece,'auth');if(_0x2d02da['isInitialized']())return _0x2d02da['getImmediate']();const _0x8325e9=Vf(_0x319ece,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x4af04f=jr('authTokenSyncURL');if(_0x4af04f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1c6ef0=new URL(_0x4af04f,location['origin']);if(location['origin']===_0x1c6ef0['origin']){const _0x167d86=p_(_0x1c6ef0['toString']());sp(_0x8325e9,_0x167d86,()=>_0x167d86(_0x8325e9['currentUser'])),ip(_0x8325e9,_0x273048=>_0x167d86(_0x273048));}}const _0x208180=qr('auth');return _0x208180&&$f(_0x8325e9,'http://'+_0x208180),_0x8325e9;}function __(){var _0x2c9583;return((_0x2c9583=document['getElementsByTagName']('head'))==null?void 0x0:_0x2c9583[0x0])??document;}Mf({'loadJS'(_0x164e34){return new Promise((_0xcc7d9f,_0xc854a3)=>{const _0x2a9c2c=document['createElement']('script');_0x2a9c2c['setAttribute']('src',_0x164e34),_0x2a9c2c['onload']=_0xcc7d9f,_0x2a9c2c['onerror']=_0x51d6c6=>{const _0x50a9a7=X('internal-error');_0x50a9a7['customData']=_0x51d6c6,_0xc854a3(_0x50a9a7);},_0x2a9c2c['type']='text/javascript',_0x2a9c2c['charset']='UTF-8',__()['appendChild'](_0x2a9c2c);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};