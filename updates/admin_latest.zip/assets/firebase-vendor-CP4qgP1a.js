const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4df1eb,_0xa32560){if(!_0x4df1eb)throw ht(_0xa32560);},ht=function(_0x49470b){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x49470b);},Hr=function(_0x523163){const _0x2101c4=[];let _0x4413dc=0x0;for(let _0x4c5d39=0x0;_0x4c5d39<_0x523163['length'];_0x4c5d39++){let _0x4c6df8=_0x523163['charCodeAt'](_0x4c5d39);_0x4c6df8<0x80?_0x2101c4[_0x4413dc++]=_0x4c6df8:_0x4c6df8<0x800?(_0x2101c4[_0x4413dc++]=_0x4c6df8>>0x6|0xc0,_0x2101c4[_0x4413dc++]=_0x4c6df8&0x3f|0x80):(_0x4c6df8&0xfc00)===0xd800&&_0x4c5d39+0x1<_0x523163['length']&&(_0x523163['charCodeAt'](_0x4c5d39+0x1)&0xfc00)===0xdc00?(_0x4c6df8=0x10000+((_0x4c6df8&0x3ff)<<0xa)+(_0x523163['charCodeAt'](++_0x4c5d39)&0x3ff),_0x2101c4[_0x4413dc++]=_0x4c6df8>>0x12|0xf0,_0x2101c4[_0x4413dc++]=_0x4c6df8>>0xc&0x3f|0x80,_0x2101c4[_0x4413dc++]=_0x4c6df8>>0x6&0x3f|0x80,_0x2101c4[_0x4413dc++]=_0x4c6df8&0x3f|0x80):(_0x2101c4[_0x4413dc++]=_0x4c6df8>>0xc|0xe0,_0x2101c4[_0x4413dc++]=_0x4c6df8>>0x6&0x3f|0x80,_0x2101c4[_0x4413dc++]=_0x4c6df8&0x3f|0x80);}return _0x2101c4;},nc=function(_0x3950f1){const _0x373f88=[];let _0x20ee49=0x0,_0xff3234=0x0;for(;_0x20ee49<_0x3950f1['length'];){const _0x2adf83=_0x3950f1[_0x20ee49++];if(_0x2adf83<0x80)_0x373f88[_0xff3234++]=String['fromCharCode'](_0x2adf83);else{if(_0x2adf83>0xbf&&_0x2adf83<0xe0){const _0x218ca1=_0x3950f1[_0x20ee49++];_0x373f88[_0xff3234++]=String['fromCharCode']((_0x2adf83&0x1f)<<0x6|_0x218ca1&0x3f);}else{if(_0x2adf83>0xef&&_0x2adf83<0x16d){const _0x38762d=_0x3950f1[_0x20ee49++],_0x524ee8=_0x3950f1[_0x20ee49++],_0x1d5b4a=_0x3950f1[_0x20ee49++],_0xd6f7af=((_0x2adf83&0x7)<<0x12|(_0x38762d&0x3f)<<0xc|(_0x524ee8&0x3f)<<0x6|_0x1d5b4a&0x3f)-0x10000;_0x373f88[_0xff3234++]=String['fromCharCode'](0xd800+(_0xd6f7af>>0xa)),_0x373f88[_0xff3234++]=String['fromCharCode'](0xdc00+(_0xd6f7af&0x3ff));}else{const _0x4cfd21=_0x3950f1[_0x20ee49++],_0x283d95=_0x3950f1[_0x20ee49++];_0x373f88[_0xff3234++]=String['fromCharCode']((_0x2adf83&0xf)<<0xc|(_0x4cfd21&0x3f)<<0x6|_0x283d95&0x3f);}}}}return _0x373f88['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x514ec0,_0x145125){if(!Array['isArray'](_0x514ec0))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4848dd=_0x145125?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x381872=[];for(let _0x4408da=0x0;_0x4408da<_0x514ec0['length'];_0x4408da+=0x3){const _0x28274f=_0x514ec0[_0x4408da],_0x28af6e=_0x4408da+0x1<_0x514ec0['length'],_0x1286ab=_0x28af6e?_0x514ec0[_0x4408da+0x1]:0x0,_0x3d3699=_0x4408da+0x2<_0x514ec0['length'],_0x13bbd2=_0x3d3699?_0x514ec0[_0x4408da+0x2]:0x0,_0x3f7b7d=_0x28274f>>0x2,_0x19d3d1=(_0x28274f&0x3)<<0x4|_0x1286ab>>0x4;let _0x290264=(_0x1286ab&0xf)<<0x2|_0x13bbd2>>0x6,_0x13319c=_0x13bbd2&0x3f;_0x3d3699||(_0x13319c=0x40,_0x28af6e||(_0x290264=0x40)),_0x381872['push'](_0x4848dd[_0x3f7b7d],_0x4848dd[_0x19d3d1],_0x4848dd[_0x290264],_0x4848dd[_0x13319c]);}return _0x381872['join']('');},'encodeString'(_0x51c24f,_0x45a0ff){return this['HAS_NATIVE_SUPPORT']&&!_0x45a0ff?btoa(_0x51c24f):this['encodeByteArray'](Hr(_0x51c24f),_0x45a0ff);},'decodeString'(_0x5ae7af,_0x2b4315){return this['HAS_NATIVE_SUPPORT']&&!_0x2b4315?atob(_0x5ae7af):nc(this['decodeStringToByteArray'](_0x5ae7af,_0x2b4315));},'decodeStringToByteArray'(_0x3dc84e,_0x340c51){this['init_']();const _0x3336dc=_0x340c51?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x462a6b=[];for(let _0x14107f=0x0;_0x14107f<_0x3dc84e['length'];){const _0x4b6898=_0x3336dc[_0x3dc84e['charAt'](_0x14107f++)],_0xe7b3a3=_0x14107f<_0x3dc84e['length']?_0x3336dc[_0x3dc84e['charAt'](_0x14107f)]:0x0;++_0x14107f;const _0x4016f8=_0x14107f<_0x3dc84e['length']?_0x3336dc[_0x3dc84e['charAt'](_0x14107f)]:0x40;++_0x14107f;const _0x4afa42=_0x14107f<_0x3dc84e['length']?_0x3336dc[_0x3dc84e['charAt'](_0x14107f)]:0x40;if(++_0x14107f,_0x4b6898==null||_0xe7b3a3==null||_0x4016f8==null||_0x4afa42==null)throw new ic();const _0x5ca99e=_0x4b6898<<0x2|_0xe7b3a3>>0x4;if(_0x462a6b['push'](_0x5ca99e),_0x4016f8!==0x40){const _0x4b3537=_0xe7b3a3<<0x4&0xf0|_0x4016f8>>0x2;if(_0x462a6b['push'](_0x4b3537),_0x4afa42!==0x40){const _0x2c6738=_0x4016f8<<0x6&0xc0|_0x4afa42;_0x462a6b['push'](_0x2c6738);}}}return _0x462a6b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x28445d=0x0;_0x28445d<this['ENCODED_VALS']['length'];_0x28445d++)this['byteToCharMap_'][_0x28445d]=this['ENCODED_VALS']['charAt'](_0x28445d),this['charToByteMap_'][this['byteToCharMap_'][_0x28445d]]=_0x28445d,this['byteToCharMapWebSafe_'][_0x28445d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x28445d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x28445d]]=_0x28445d,_0x28445d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x28445d)]=_0x28445d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x28445d)]=_0x28445d);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x263a74){const _0x23d030=Hr(_0x263a74);return Fi['encodeByteArray'](_0x23d030,!0x0);},dn=function(_0x4f90bc){return $r(_0x4f90bc)['replace'](/\./g,'');},fn=function(_0x5d01fa){try{return Fi['decodeString'](_0x5d01fa,!0x0);}catch(_0x676441){console['error']('base64Decode\x20failed:\x20',_0x676441);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x30d4c5){return Gr(void 0x0,_0x30d4c5);}function Gr(_0x1f1d42,_0x5c608c){if(!(_0x5c608c instanceof Object))return _0x5c608c;switch(_0x5c608c['constructor']){case Date:const _0x362fb8=_0x5c608c;return new Date(_0x362fb8['getTime']());case Object:_0x1f1d42===void 0x0&&(_0x1f1d42={});break;case Array:_0x1f1d42=[];break;default:return _0x5c608c;}for(const _0x2fcaaa in _0x5c608c)!_0x5c608c['hasOwnProperty'](_0x2fcaaa)||!rc(_0x2fcaaa)||(_0x1f1d42[_0x2fcaaa]=Gr(_0x1f1d42[_0x2fcaaa],_0x5c608c[_0x2fcaaa]));return _0x1f1d42;}function rc(_0x56244e){return _0x56244e!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x25e97f=Ps['__FIREBASE_DEFAULTS__'];if(_0x25e97f)return JSON['parse'](_0x25e97f);},lc=()=>{if(typeof document>'u')return;let _0x305965;try{_0x305965=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2a61b9=_0x305965&&fn(_0x305965[0x1]);return _0x2a61b9&&JSON['parse'](_0x2a61b9);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3c581a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3c581a);return;}},qr=_0xa733df=>{var _0x487737,_0xf92b92;return(_0xf92b92=(_0x487737=Ui())==null?void 0x0:_0x487737['emulatorHosts'])==null?void 0x0:_0xf92b92[_0xa733df];},hc=_0x5a41e7=>{const _0x4b11eb=qr(_0x5a41e7);if(!_0x4b11eb)return;const _0x4a94e5=_0x4b11eb['lastIndexOf'](':');if(_0x4a94e5<=0x0||_0x4a94e5+0x1===_0x4b11eb['length'])throw new Error('Invalid\x20host\x20'+_0x4b11eb+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5537b9=parseInt(_0x4b11eb['substring'](_0x4a94e5+0x1),0xa);return _0x4b11eb[0x0]==='['?[_0x4b11eb['substring'](0x1,_0x4a94e5-0x1),_0x5537b9]:[_0x4b11eb['substring'](0x0,_0x4a94e5),_0x5537b9];},zr=()=>{var _0x5203c2;return(_0x5203c2=Ui())==null?void 0x0:_0x5203c2['config'];},jr=_0x4994bf=>{var _0x1665fe;return(_0x1665fe=Ui())==null?void 0x0:_0x1665fe['_'+_0x4994bf];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4dc118,_0x13e493)=>{this['resolve']=_0x4dc118,this['reject']=_0x13e493;});}['wrapCallback'](_0x1f8e33){return(_0x2de119,_0x450116)=>{_0x2de119?this['reject'](_0x2de119):this['resolve'](_0x450116),typeof _0x1f8e33=='function'&&(this['promise']['catch'](()=>{}),_0x1f8e33['length']===0x1?_0x1f8e33(_0x2de119):_0x1f8e33(_0x2de119,_0x450116));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x3bfdce,_0x3705e2){if(_0x3bfdce['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x425b3d={'alg':'none','type':'JWT'},_0x3ee8aa=_0x3705e2||'demo-project',_0x2137df=_0x3bfdce['iat']||0x0,_0x4ef849=_0x3bfdce['sub']||_0x3bfdce['user_id'];if(!_0x4ef849)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x266e63={'iss':'https://securetoken.google.com/'+_0x3ee8aa,'aud':_0x3ee8aa,'iat':_0x2137df,'exp':_0x2137df+0xe10,'auth_time':_0x2137df,'sub':_0x4ef849,'user_id':_0x4ef849,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3bfdce};return[dn(JSON['stringify'](_0x425b3d)),dn(JSON['stringify'](_0x266e63)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4934e3=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4934e3=='object'&&_0x4934e3['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x450fb5=W();return _0x450fb5['indexOf']('MSIE\x20')>=0x0||_0x450fb5['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x50c24b,_0x21565e)=>{try{let _0x1cf074=!0x0;const _0x850993='validate-browser-context-for-indexeddb-analytics-module',_0x35cb52=self['indexedDB']['open'](_0x850993);_0x35cb52['onsuccess']=()=>{_0x35cb52['result']['close'](),_0x1cf074||self['indexedDB']['deleteDatabase'](_0x850993),_0x50c24b(!0x0);},_0x35cb52['onupgradeneeded']=()=>{_0x1cf074=!0x1;},_0x35cb52['onerror']=()=>{var _0x1a7afc;_0x21565e(((_0x1a7afc=_0x35cb52['error'])==null?void 0x0:_0x1a7afc['message'])||'');};}catch(_0x29d922){_0x21565e(_0x29d922);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x41ec23,_0x27bfb3,_0x11cc37){super(_0x27bfb3),this['code']=_0x41ec23,this['customData']=_0x11cc37,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x1903f7,_0x159513,_0x4e0a8f){this['service']=_0x1903f7,this['serviceName']=_0x159513,this['errors']=_0x4e0a8f;}['create'](_0x2ae97c,..._0x330511){const _0x2e65b=_0x330511[0x0]||{},_0x2a23d0=this['service']+'/'+_0x2ae97c,_0x351876=this['errors'][_0x2ae97c],_0x428a29=_0x351876?vc(_0x351876,_0x2e65b):'Error',_0x1d0981=this['serviceName']+':\x20'+_0x428a29+'\x20('+_0x2a23d0+').';return new Re(_0x2a23d0,_0x1d0981,_0x2e65b);}}function vc(_0x379331,_0x3ac878){return _0x379331['replace'](Ec,(_0x1ce703,_0x5e2ec8)=>{const _0x4088ef=_0x3ac878[_0x5e2ec8];return _0x4088ef!=null?String(_0x4088ef):'<'+_0x5e2ec8+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x1026c4){return JSON['parse'](_0x1026c4);}function O(_0x1b1b08){return JSON['stringify'](_0x1b1b08);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x510361){let _0x277a6c={},_0x562ff1={},_0x4a5b85={},_0x30dbd7='';try{const _0x41c77a=_0x510361['split']('.');_0x277a6c=Nt(fn(_0x41c77a[0x0])||''),_0x562ff1=Nt(fn(_0x41c77a[0x1])||''),_0x30dbd7=_0x41c77a[0x2],_0x4a5b85=_0x562ff1['d']||{},delete _0x562ff1['d'];}catch{}return{'header':_0x277a6c,'claims':_0x562ff1,'data':_0x4a5b85,'signature':_0x30dbd7};},Ic=function(_0x130b73){const _0x30ea34=Yr(_0x130b73),_0x22a87b=_0x30ea34['claims'];return!!_0x22a87b&&typeof _0x22a87b=='object'&&_0x22a87b['hasOwnProperty']('iat');},wc=function(_0x1b86ce){const _0x5b4d5f=Yr(_0x1b86ce)['claims'];return typeof _0x5b4d5f=='object'&&_0x5b4d5f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x16e858,_0x143ba0){return Object['prototype']['hasOwnProperty']['call'](_0x16e858,_0x143ba0);}function Le(_0x143af7,_0x3fdbed){if(Object['prototype']['hasOwnProperty']['call'](_0x143af7,_0x3fdbed))return _0x143af7[_0x3fdbed];}function pn(_0x693bc1){for(const _0x35e5a4 in _0x693bc1)if(Object['prototype']['hasOwnProperty']['call'](_0x693bc1,_0x35e5a4))return!0x1;return!0x0;}function _n(_0xa3bde3,_0x357891,_0x49c830){const _0x4d41cb={};for(const _0x1f4234 in _0xa3bde3)Object['prototype']['hasOwnProperty']['call'](_0xa3bde3,_0x1f4234)&&(_0x4d41cb[_0x1f4234]=_0x357891['call'](_0x49c830,_0xa3bde3[_0x1f4234],_0x1f4234,_0xa3bde3));return _0x4d41cb;}function xe(_0x4bb074,_0x3992b3){if(_0x4bb074===_0x3992b3)return!0x0;const _0x15e3d7=Object['keys'](_0x4bb074),_0x3767ea=Object['keys'](_0x3992b3);for(const _0x412050 of _0x15e3d7){if(!_0x3767ea['includes'](_0x412050))return!0x1;const _0x45afd3=_0x4bb074[_0x412050],_0x46faeb=_0x3992b3[_0x412050];if(Ns(_0x45afd3)&&Ns(_0x46faeb)){if(!xe(_0x45afd3,_0x46faeb))return!0x1;}else{if(_0x45afd3!==_0x46faeb)return!0x1;}}for(const _0xf0e7a7 of _0x3767ea)if(!_0x15e3d7['includes'](_0xf0e7a7))return!0x1;return!0x0;}function Ns(_0x1ea534){return _0x1ea534!==null&&typeof _0x1ea534=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x17682f){const _0x4633a2=[];for(const [_0x33149c,_0x4c82a8]of Object['entries'](_0x17682f))Array['isArray'](_0x4c82a8)?_0x4c82a8['forEach'](_0x345a3c=>{_0x4633a2['push'](encodeURIComponent(_0x33149c)+'='+encodeURIComponent(_0x345a3c));}):_0x4633a2['push'](encodeURIComponent(_0x33149c)+'='+encodeURIComponent(_0x4c82a8));return _0x4633a2['length']?'&'+_0x4633a2['join']('&'):'';}function Ct(_0x50822b){const _0x2e336f={};return _0x50822b['replace'](/^\?/,'')['split']('&')['forEach'](_0x476dd4=>{if(_0x476dd4){const [_0x533162,_0x361949]=_0x476dd4['split']('=');_0x2e336f[decodeURIComponent(_0x533162)]=decodeURIComponent(_0x361949);}}),_0x2e336f;}function Tt(_0x889aa2){const _0x2c25bc=_0x889aa2['indexOf']('?');if(!_0x2c25bc)return'';const _0xdf8499=_0x889aa2['indexOf']('#',_0x2c25bc);return _0x889aa2['substring'](_0x2c25bc,_0xdf8499>0x0?_0xdf8499:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x15ef60=0x1;_0x15ef60<this['blockSize'];++_0x15ef60)this['pad_'][_0x15ef60]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xace4c9,_0x244142){_0x244142||(_0x244142=0x0);const _0x31c57c=this['W_'];if(typeof _0xace4c9=='string'){for(let _0x50d82f=0x0;_0x50d82f<0x10;_0x50d82f++)_0x31c57c[_0x50d82f]=_0xace4c9['charCodeAt'](_0x244142)<<0x18|_0xace4c9['charCodeAt'](_0x244142+0x1)<<0x10|_0xace4c9['charCodeAt'](_0x244142+0x2)<<0x8|_0xace4c9['charCodeAt'](_0x244142+0x3),_0x244142+=0x4;}else{for(let _0x8b6ba3=0x0;_0x8b6ba3<0x10;_0x8b6ba3++)_0x31c57c[_0x8b6ba3]=_0xace4c9[_0x244142]<<0x18|_0xace4c9[_0x244142+0x1]<<0x10|_0xace4c9[_0x244142+0x2]<<0x8|_0xace4c9[_0x244142+0x3],_0x244142+=0x4;}for(let _0x5a68ef=0x10;_0x5a68ef<0x50;_0x5a68ef++){const _0x345390=_0x31c57c[_0x5a68ef-0x3]^_0x31c57c[_0x5a68ef-0x8]^_0x31c57c[_0x5a68ef-0xe]^_0x31c57c[_0x5a68ef-0x10];_0x31c57c[_0x5a68ef]=(_0x345390<<0x1|_0x345390>>>0x1f)&0xffffffff;}let _0x4bb2ae=this['chain_'][0x0],_0x3d1976=this['chain_'][0x1],_0x424ade=this['chain_'][0x2],_0x111728=this['chain_'][0x3],_0x398c25=this['chain_'][0x4],_0x24f291,_0x3e1588;for(let _0x469e63=0x0;_0x469e63<0x50;_0x469e63++){_0x469e63<0x28?_0x469e63<0x14?(_0x24f291=_0x111728^_0x3d1976&(_0x424ade^_0x111728),_0x3e1588=0x5a827999):(_0x24f291=_0x3d1976^_0x424ade^_0x111728,_0x3e1588=0x6ed9eba1):_0x469e63<0x3c?(_0x24f291=_0x3d1976&_0x424ade|_0x111728&(_0x3d1976|_0x424ade),_0x3e1588=0x8f1bbcdc):(_0x24f291=_0x3d1976^_0x424ade^_0x111728,_0x3e1588=0xca62c1d6);const _0x171f89=(_0x4bb2ae<<0x5|_0x4bb2ae>>>0x1b)+_0x24f291+_0x398c25+_0x3e1588+_0x31c57c[_0x469e63]&0xffffffff;_0x398c25=_0x111728,_0x111728=_0x424ade,_0x424ade=(_0x3d1976<<0x1e|_0x3d1976>>>0x2)&0xffffffff,_0x3d1976=_0x4bb2ae,_0x4bb2ae=_0x171f89;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4bb2ae&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3d1976&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x424ade&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x111728&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x398c25&0xffffffff;}['update'](_0x45ef80,_0x89662e){if(_0x45ef80==null)return;_0x89662e===void 0x0&&(_0x89662e=_0x45ef80['length']);const _0xd04a76=_0x89662e-this['blockSize'];let _0x1d3c31=0x0;const _0x572d6a=this['buf_'];let _0x291638=this['inbuf_'];for(;_0x1d3c31<_0x89662e;){if(_0x291638===0x0){for(;_0x1d3c31<=_0xd04a76;)this['compress_'](_0x45ef80,_0x1d3c31),_0x1d3c31+=this['blockSize'];}if(typeof _0x45ef80=='string'){for(;_0x1d3c31<_0x89662e;)if(_0x572d6a[_0x291638]=_0x45ef80['charCodeAt'](_0x1d3c31),++_0x291638,++_0x1d3c31,_0x291638===this['blockSize']){this['compress_'](_0x572d6a),_0x291638=0x0;break;}}else{for(;_0x1d3c31<_0x89662e;)if(_0x572d6a[_0x291638]=_0x45ef80[_0x1d3c31],++_0x291638,++_0x1d3c31,_0x291638===this['blockSize']){this['compress_'](_0x572d6a),_0x291638=0x0;break;}}}this['inbuf_']=_0x291638,this['total_']+=_0x89662e;}['digest'](){const _0x3cb1ee=[];let _0x5d933f=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4b7244=this['blockSize']-0x1;_0x4b7244>=0x38;_0x4b7244--)this['buf_'][_0x4b7244]=_0x5d933f&0xff,_0x5d933f/=0x100;this['compress_'](this['buf_']);let _0x2f6619=0x0;for(let _0x1ed71e=0x0;_0x1ed71e<0x5;_0x1ed71e++)for(let _0x214246=0x18;_0x214246>=0x0;_0x214246-=0x8)_0x3cb1ee[_0x2f6619]=this['chain_'][_0x1ed71e]>>_0x214246&0xff,++_0x2f6619;return _0x3cb1ee;}}function Tc(_0x12579a,_0x39f47d){const _0x473bee=new Sc(_0x12579a,_0x39f47d);return _0x473bee['subscribe']['bind'](_0x473bee);}class Sc{constructor(_0x141d4e,_0x2b3826){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2b3826,this['task']['then'](()=>{_0x141d4e(this);})['catch'](_0x5dbaaf=>{this['error'](_0x5dbaaf);});}['next'](_0x2847f3){this['forEachObserver'](_0x1f1c29=>{_0x1f1c29['next'](_0x2847f3);});}['error'](_0x28a4c8){this['forEachObserver'](_0x5ab5aa=>{_0x5ab5aa['error'](_0x28a4c8);}),this['close'](_0x28a4c8);}['complete'](){this['forEachObserver'](_0x17a8a4=>{_0x17a8a4['complete']();}),this['close']();}['subscribe'](_0x50c269,_0x58d378,_0x3b2014){let _0x103ebf;if(_0x50c269===void 0x0&&_0x58d378===void 0x0&&_0x3b2014===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x50c269,['next','error','complete'])?_0x103ebf=_0x50c269:_0x103ebf={'next':_0x50c269,'error':_0x58d378,'complete':_0x3b2014},_0x103ebf['next']===void 0x0&&(_0x103ebf['next']=ti),_0x103ebf['error']===void 0x0&&(_0x103ebf['error']=ti),_0x103ebf['complete']===void 0x0&&(_0x103ebf['complete']=ti);const _0x3f0e6e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x103ebf['error'](this['finalError']):_0x103ebf['complete']();}catch{}}),this['observers']['push'](_0x103ebf),_0x3f0e6e;}['unsubscribeOne'](_0x222684){this['observers']===void 0x0||this['observers'][_0x222684]===void 0x0||(delete this['observers'][_0x222684],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x206a94){if(!this['finalized']){for(let _0x4f8168=0x0;_0x4f8168<this['observers']['length'];_0x4f8168++)this['sendOne'](_0x4f8168,_0x206a94);}}['sendOne'](_0x4125b3,_0x3f37c7){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4125b3]!==void 0x0)try{_0x3f37c7(this['observers'][_0x4125b3]);}catch(_0x4e7661){typeof console<'u'&&console['error']&&console['error'](_0x4e7661);}});}['close'](_0x3b2707){this['finalized']||(this['finalized']=!0x0,_0x3b2707!==void 0x0&&(this['finalError']=_0x3b2707),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5cbcc6,_0x281ecb){if(typeof _0x5cbcc6!='object'||_0x5cbcc6===null)return!0x1;for(const _0x53d671 of _0x281ecb)if(_0x53d671 in _0x5cbcc6&&typeof _0x5cbcc6[_0x53d671]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x28c8c2,_0x5fd484){return _0x28c8c2+'\x20failed:\x20'+_0x5fd484+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x991e08){const _0xb010e6=[];let _0x390d10=0x0;for(let _0x30cfa4=0x0;_0x30cfa4<_0x991e08['length'];_0x30cfa4++){let _0x5b80ef=_0x991e08['charCodeAt'](_0x30cfa4);if(_0x5b80ef>=0xd800&&_0x5b80ef<=0xdbff){const _0x47c1e8=_0x5b80ef-0xd800;_0x30cfa4++,f(_0x30cfa4<_0x991e08['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4e21d7=_0x991e08['charCodeAt'](_0x30cfa4)-0xdc00;_0x5b80ef=0x10000+(_0x47c1e8<<0xa)+_0x4e21d7;}_0x5b80ef<0x80?_0xb010e6[_0x390d10++]=_0x5b80ef:_0x5b80ef<0x800?(_0xb010e6[_0x390d10++]=_0x5b80ef>>0x6|0xc0,_0xb010e6[_0x390d10++]=_0x5b80ef&0x3f|0x80):_0x5b80ef<0x10000?(_0xb010e6[_0x390d10++]=_0x5b80ef>>0xc|0xe0,_0xb010e6[_0x390d10++]=_0x5b80ef>>0x6&0x3f|0x80,_0xb010e6[_0x390d10++]=_0x5b80ef&0x3f|0x80):(_0xb010e6[_0x390d10++]=_0x5b80ef>>0x12|0xf0,_0xb010e6[_0x390d10++]=_0x5b80ef>>0xc&0x3f|0x80,_0xb010e6[_0x390d10++]=_0x5b80ef>>0x6&0x3f|0x80,_0xb010e6[_0x390d10++]=_0x5b80ef&0x3f|0x80);}return _0xb010e6;},Ln=function(_0x56c218){let _0x289379=0x0;for(let _0x58a82d=0x0;_0x58a82d<_0x56c218['length'];_0x58a82d++){const _0x48d896=_0x56c218['charCodeAt'](_0x58a82d);_0x48d896<0x80?_0x289379++:_0x48d896<0x800?_0x289379+=0x2:_0x48d896>=0xd800&&_0x48d896<=0xdbff?(_0x289379+=0x4,_0x58a82d++):_0x289379+=0x3;}return _0x289379;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x366e58){return _0x366e58&&_0x366e58['_delegate']?_0x366e58['_delegate']:_0x366e58;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3bf3bc){try{return(_0x3bf3bc['startsWith']('http://')||_0x3bf3bc['startsWith']('https://')?new URL(_0x3bf3bc)['hostname']:_0x3bf3bc)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x517c02){return(await fetch(_0x517c02,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x2d61d5,_0x36e0a0,_0x2bc5b6){this['name']=_0x2d61d5,this['instanceFactory']=_0x36e0a0,this['type']=_0x2bc5b6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x41e9be){return this['instantiationMode']=_0x41e9be,this;}['setMultipleInstances'](_0x193e45){return this['multipleInstances']=_0x193e45,this;}['setServiceProps'](_0x328814){return this['serviceProps']=_0x328814,this;}['setInstanceCreatedCallback'](_0x49ea2a){return this['onInstanceCreated']=_0x49ea2a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x447ff6,_0x5b2db8){this['name']=_0x447ff6,this['container']=_0x5b2db8,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x536f50){const _0x98360f=this['normalizeInstanceIdentifier'](_0x536f50);if(!this['instancesDeferred']['has'](_0x98360f)){const _0xc1821=new H();if(this['instancesDeferred']['set'](_0x98360f,_0xc1821),this['isInitialized'](_0x98360f)||this['shouldAutoInitialize']())try{const _0x3f5c66=this['getOrInitializeService']({'instanceIdentifier':_0x98360f});_0x3f5c66&&_0xc1821['resolve'](_0x3f5c66);}catch{}}return this['instancesDeferred']['get'](_0x98360f)['promise'];}['getImmediate'](_0x13c5db){const _0x4040c2=this['normalizeInstanceIdentifier'](_0x13c5db==null?void 0x0:_0x13c5db['identifier']),_0x168910=(_0x13c5db==null?void 0x0:_0x13c5db['optional'])??!0x1;if(this['isInitialized'](_0x4040c2)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4040c2});}catch(_0x810ed){if(_0x168910)return null;throw _0x810ed;}else{if(_0x168910)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x327a87){if(_0x327a87['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x327a87['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x327a87,!!this['shouldAutoInitialize']()){if(Pc(_0x327a87))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x352f2c,_0x354727]of this['instancesDeferred']['entries']()){const _0x21c2f1=this['normalizeInstanceIdentifier'](_0x352f2c);try{const _0xbaec22=this['getOrInitializeService']({'instanceIdentifier':_0x21c2f1});_0x354727['resolve'](_0xbaec22);}catch{}}}}['clearInstance'](_0x12a522=Ne){this['instancesDeferred']['delete'](_0x12a522),this['instancesOptions']['delete'](_0x12a522),this['instances']['delete'](_0x12a522);}async['delete'](){const _0x3a823b=Array['from'](this['instances']['values']());await Promise['all']([..._0x3a823b['filter'](_0x473889=>'INTERNAL'in _0x473889)['map'](_0x273470=>_0x273470['INTERNAL']['delete']()),..._0x3a823b['filter'](_0x32e427=>'_delete'in _0x32e427)['map'](_0x34f822=>_0x34f822['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4d7c10=Ne){return this['instances']['has'](_0x4d7c10);}['getOptions'](_0x544ab3=Ne){return this['instancesOptions']['get'](_0x544ab3)||{};}['initialize'](_0x44f592={}){const {options:_0x1c63f8={}}=_0x44f592,_0x16d143=this['normalizeInstanceIdentifier'](_0x44f592['instanceIdentifier']);if(this['isInitialized'](_0x16d143))throw Error(this['name']+'('+_0x16d143+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3cfe20=this['getOrInitializeService']({'instanceIdentifier':_0x16d143,'options':_0x1c63f8});for(const [_0xd7265d,_0x1baeb1]of this['instancesDeferred']['entries']()){const _0x545a41=this['normalizeInstanceIdentifier'](_0xd7265d);_0x16d143===_0x545a41&&_0x1baeb1['resolve'](_0x3cfe20);}return _0x3cfe20;}['onInit'](_0x1fc8b4,_0x299652){const _0x176bca=this['normalizeInstanceIdentifier'](_0x299652),_0x5a18b7=this['onInitCallbacks']['get'](_0x176bca)??new Set();_0x5a18b7['add'](_0x1fc8b4),this['onInitCallbacks']['set'](_0x176bca,_0x5a18b7);const _0x31dfae=this['instances']['get'](_0x176bca);return _0x31dfae&&_0x1fc8b4(_0x31dfae,_0x176bca),()=>{_0x5a18b7['delete'](_0x1fc8b4);};}['invokeOnInitCallbacks'](_0xa3c8ee,_0x5d03b5){const _0x30be48=this['onInitCallbacks']['get'](_0x5d03b5);if(_0x30be48){for(const _0x9359 of _0x30be48)try{_0x9359(_0xa3c8ee,_0x5d03b5);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4da3c7,options:_0x3039a1={}}){let _0x52b33d=this['instances']['get'](_0x4da3c7);if(!_0x52b33d&&this['component']&&(_0x52b33d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4da3c7),'options':_0x3039a1}),this['instances']['set'](_0x4da3c7,_0x52b33d),this['instancesOptions']['set'](_0x4da3c7,_0x3039a1),this['invokeOnInitCallbacks'](_0x52b33d,_0x4da3c7),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4da3c7,_0x52b33d);}catch{}return _0x52b33d||null;}['normalizeInstanceIdentifier'](_0x2cbc97=Ne){return this['component']?this['component']['multipleInstances']?_0x2cbc97:Ne:_0x2cbc97;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2de570){return _0x2de570===Ne?void 0x0:_0x2de570;}function Pc(_0x2cae98){return _0x2cae98['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x10490e){this['name']=_0x10490e,this['providers']=new Map();}['addComponent'](_0x7150d8){const _0x9f835=this['getProvider'](_0x7150d8['name']);if(_0x9f835['isComponentSet']())throw new Error('Component\x20'+_0x7150d8['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x9f835['setComponent'](_0x7150d8);}['addOrOverwriteComponent'](_0x47327a){this['getProvider'](_0x47327a['name'])['isComponentSet']()&&this['providers']['delete'](_0x47327a['name']),this['addComponent'](_0x47327a);}['getProvider'](_0x300b9b){if(this['providers']['has'](_0x300b9b))return this['providers']['get'](_0x300b9b);const _0x5e6f63=new Ac(_0x300b9b,this);return this['providers']['set'](_0x300b9b,_0x5e6f63),_0x5e6f63;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2f113c){_0x2f113c[_0x2f113c['DEBUG']=0x0]='DEBUG',_0x2f113c[_0x2f113c['VERBOSE']=0x1]='VERBOSE',_0x2f113c[_0x2f113c['INFO']=0x2]='INFO',_0x2f113c[_0x2f113c['WARN']=0x3]='WARN',_0x2f113c[_0x2f113c['ERROR']=0x4]='ERROR',_0x2f113c[_0x2f113c['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4f7c35,_0x5952ba,..._0x23b924)=>{if(_0x5952ba<_0x4f7c35['logLevel'])return;const _0x31a719=new Date()['toISOString'](),_0x3e0ab7=Mc[_0x5952ba];if(_0x3e0ab7)console[_0x3e0ab7]('['+_0x31a719+']\x20\x20'+_0x4f7c35['name']+':',..._0x23b924);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5952ba+')');};class Bi{constructor(_0x5227af){this['name']=_0x5227af,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x9cfdc8){if(!(_0x9cfdc8 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x9cfdc8+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x9cfdc8;}['setLogLevel'](_0x486bf1){this['_logLevel']=typeof _0x486bf1=='string'?Oc[_0x486bf1]:_0x486bf1;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4443d1){if(typeof _0x4443d1!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4443d1;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x93c8b9){this['_userLogHandler']=_0x93c8b9;}['debug'](..._0x2391f0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2391f0),this['_logHandler'](this,T['DEBUG'],..._0x2391f0);}['log'](..._0x3da358){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3da358),this['_logHandler'](this,T['VERBOSE'],..._0x3da358);}['info'](..._0x5d601b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5d601b),this['_logHandler'](this,T['INFO'],..._0x5d601b);}['warn'](..._0x2276db){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2276db),this['_logHandler'](this,T['WARN'],..._0x2276db);}['error'](..._0x1f42b1){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1f42b1),this['_logHandler'](this,T['ERROR'],..._0x1f42b1);}}const xc=(_0x18def6,_0x27c6b9)=>_0x27c6b9['some'](_0x588998=>_0x18def6 instanceof _0x588998);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x2bd20e){const _0x27f774=new Promise((_0x2f2db7,_0x3e9f56)=>{const _0x2eb15b=()=>{_0x2bd20e['removeEventListener']('success',_0x2ed059),_0x2bd20e['removeEventListener']('error',_0xfc5c6a);},_0x2ed059=()=>{_0x2f2db7(ge(_0x2bd20e['result'])),_0x2eb15b();},_0xfc5c6a=()=>{_0x3e9f56(_0x2bd20e['error']),_0x2eb15b();};_0x2bd20e['addEventListener']('success',_0x2ed059),_0x2bd20e['addEventListener']('error',_0xfc5c6a);});return _0x27f774['then'](_0x6978da=>{_0x6978da instanceof IDBCursor&&Jr['set'](_0x6978da,_0x2bd20e);})['catch'](()=>{}),Vi['set'](_0x27f774,_0x2bd20e),_0x27f774;}function Bc(_0x3284e2){if(_i['has'](_0x3284e2))return;const _0x2deb8b=new Promise((_0x5e5204,_0x234d22)=>{const _0x3632ad=()=>{_0x3284e2['removeEventListener']('complete',_0x1b2908),_0x3284e2['removeEventListener']('error',_0x1e9d9c),_0x3284e2['removeEventListener']('abort',_0x1e9d9c);},_0x1b2908=()=>{_0x5e5204(),_0x3632ad();},_0x1e9d9c=()=>{_0x234d22(_0x3284e2['error']||new DOMException('AbortError','AbortError')),_0x3632ad();};_0x3284e2['addEventListener']('complete',_0x1b2908),_0x3284e2['addEventListener']('error',_0x1e9d9c),_0x3284e2['addEventListener']('abort',_0x1e9d9c);});_i['set'](_0x3284e2,_0x2deb8b);}let gi={'get'(_0x535350,_0x345f27,_0x12ef80){if(_0x535350 instanceof IDBTransaction){if(_0x345f27==='done')return _i['get'](_0x535350);if(_0x345f27==='objectStoreNames')return _0x535350['objectStoreNames']||Xr['get'](_0x535350);if(_0x345f27==='store')return _0x12ef80['objectStoreNames'][0x1]?void 0x0:_0x12ef80['objectStore'](_0x12ef80['objectStoreNames'][0x0]);}return ge(_0x535350[_0x345f27]);},'set'(_0x57c73f,_0x151264,_0x269756){return _0x57c73f[_0x151264]=_0x269756,!0x0;},'has'(_0x408803,_0x2f5ed9){return _0x408803 instanceof IDBTransaction&&(_0x2f5ed9==='done'||_0x2f5ed9==='store')?!0x0:_0x2f5ed9 in _0x408803;}};function Vc(_0x2e32d6){gi=_0x2e32d6(gi);}function Hc(_0x5e7abf){return _0x5e7abf===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x123377,..._0x832ac){const _0x2b758d=_0x5e7abf['call'](ii(this),_0x123377,..._0x832ac);return Xr['set'](_0x2b758d,_0x123377['sort']?_0x123377['sort']():[_0x123377]),ge(_0x2b758d);}:Uc()['includes'](_0x5e7abf)?function(..._0x355ca0){return _0x5e7abf['apply'](ii(this),_0x355ca0),ge(Jr['get'](this));}:function(..._0x2a7c25){return ge(_0x5e7abf['apply'](ii(this),_0x2a7c25));};}function $c(_0x4d3831){return typeof _0x4d3831=='function'?Hc(_0x4d3831):(_0x4d3831 instanceof IDBTransaction&&Bc(_0x4d3831),xc(_0x4d3831,Fc())?new Proxy(_0x4d3831,gi):_0x4d3831);}function ge(_0x3374b5){if(_0x3374b5 instanceof IDBRequest)return Wc(_0x3374b5);if(ni['has'](_0x3374b5))return ni['get'](_0x3374b5);const _0x5e14ee=$c(_0x3374b5);return _0x5e14ee!==_0x3374b5&&(ni['set'](_0x3374b5,_0x5e14ee),Vi['set'](_0x5e14ee,_0x3374b5)),_0x5e14ee;}const ii=_0x48af4a=>Vi['get'](_0x48af4a);function Gc(_0x3381ca,_0x52271a,{blocked:_0x373a59,upgrade:_0x25f560,blocking:_0x206cb0,terminated:_0x6b00c1}={}){const _0xe53d41=indexedDB['open'](_0x3381ca,_0x52271a),_0x497fd4=ge(_0xe53d41);return _0x25f560&&_0xe53d41['addEventListener']('upgradeneeded',_0x31aee7=>{_0x25f560(ge(_0xe53d41['result']),_0x31aee7['oldVersion'],_0x31aee7['newVersion'],ge(_0xe53d41['transaction']),_0x31aee7);}),_0x373a59&&_0xe53d41['addEventListener']('blocked',_0x54e109=>_0x373a59(_0x54e109['oldVersion'],_0x54e109['newVersion'],_0x54e109)),_0x497fd4['then'](_0x216b20=>{_0x6b00c1&&_0x216b20['addEventListener']('close',()=>_0x6b00c1()),_0x206cb0&&_0x216b20['addEventListener']('versionchange',_0xc01578=>_0x206cb0(_0xc01578['oldVersion'],_0xc01578['newVersion'],_0xc01578));})['catch'](()=>{}),_0x497fd4;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x35444f,_0x106cba){if(!(_0x35444f instanceof IDBDatabase&&!(_0x106cba in _0x35444f)&&typeof _0x106cba=='string'))return;if(si['get'](_0x106cba))return si['get'](_0x106cba);const _0x531772=_0x106cba['replace'](/FromIndex$/,''),_0x3e7e9e=_0x106cba!==_0x531772,_0x1c00bc=zc['includes'](_0x531772);if(!(_0x531772 in(_0x3e7e9e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1c00bc||qc['includes'](_0x531772)))return;const _0xb8077c=async function(_0x5e894b,..._0x415511){const _0x5cf1d8=this['transaction'](_0x5e894b,_0x1c00bc?'readwrite':'readonly');let _0x3d3219=_0x5cf1d8['store'];return _0x3e7e9e&&(_0x3d3219=_0x3d3219['index'](_0x415511['shift']())),(await Promise['all']([_0x3d3219[_0x531772](..._0x415511),_0x1c00bc&&_0x5cf1d8['done']]))[0x0];};return si['set'](_0x106cba,_0xb8077c),_0xb8077c;}Vc(_0x11c65c=>({..._0x11c65c,'get':(_0x56a6c7,_0x579202,_0x1824c7)=>Ms(_0x56a6c7,_0x579202)||_0x11c65c['get'](_0x56a6c7,_0x579202,_0x1824c7),'has':(_0x50b33f,_0x47a530)=>!!Ms(_0x50b33f,_0x47a530)||_0x11c65c['has'](_0x50b33f,_0x47a530)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x8ee26d){this['container']=_0x8ee26d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xdfaba=>{if(Kc(_0xdfaba)){const _0x564fe4=_0xdfaba['getImmediate']();return _0x564fe4['library']+'/'+_0x564fe4['version'];}else return null;})['filter'](_0x1e4bef=>_0x1e4bef)['join']('\x20');}}function Kc(_0x3c6131){const _0x38c35d=_0x3c6131['getComponent']();return(_0x38c35d==null?void 0x0:_0x38c35d['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2101cf,_0x4fdcbb){try{_0x2101cf['container']['addComponent'](_0x4fdcbb);}catch(_0x1a3bae){oe['debug']('Component\x20'+_0x4fdcbb['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2101cf['name'],_0x1a3bae);}}function st(_0x1eaffa){const _0x37e285=_0x1eaffa['name'];if(Ei['has'](_0x37e285))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x37e285+'.'),!0x1;Ei['set'](_0x37e285,_0x1eaffa);for(const _0x77f7d9 of Ue['values']())xs(_0x77f7d9,_0x1eaffa);for(const _0x185aa6 of vi['values']())xs(_0x185aa6,_0x1eaffa);return!0x0;}function Hi(_0xc5638a,_0x1d5a53){const _0x3f5955=_0xc5638a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3f5955&&_0x3f5955['triggerHeartbeat'](),_0xc5638a['container']['getProvider'](_0x1d5a53);}function $(_0x273fe7){return _0x273fe7==null?!0x1:_0x273fe7['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5f6570,_0xd57abc,_0x36c014){this['_isDeleted']=!0x1,this['_options']={..._0x5f6570},this['_config']={..._0xd57abc},this['_name']=_0xd57abc['name'],this['_automaticDataCollectionEnabled']=_0xd57abc['automaticDataCollectionEnabled'],this['_container']=_0x36c014,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2c1de3){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2c1de3;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x250d98){this['_isDeleted']=_0x250d98;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x21ab69,_0x376da6={}){let _0x38c47c=_0x21ab69;typeof _0x376da6!='object'&&(_0x376da6={'name':_0x376da6});const _0x2e1d20={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x376da6},_0x124f76=_0x2e1d20['name'];if(typeof _0x124f76!='string'||!_0x124f76)throw me['create']('bad-app-name',{'appName':String(_0x124f76)});if(_0x38c47c||(_0x38c47c=zr()),!_0x38c47c)throw me['create']('no-options');const _0x18ba99=Ue['get'](_0x124f76);if(_0x18ba99){if(xe(_0x38c47c,_0x18ba99['options'])&&xe(_0x2e1d20,_0x18ba99['config']))return _0x18ba99;throw me['create']('duplicate-app',{'appName':_0x124f76});}const _0x2a3b73=new Nc(_0x124f76);for(const _0x570aa2 of Ei['values']())_0x2a3b73['addComponent'](_0x570aa2);const _0x48bdca=new Tl(_0x38c47c,_0x2e1d20,_0x2a3b73);return Ue['set'](_0x124f76,_0x48bdca),_0x48bdca;}function Zr(_0x34e2a4=yi){const _0x2ed825=Ue['get'](_0x34e2a4);if(!_0x2ed825&&_0x34e2a4===yi&&zr())return Sl();if(!_0x2ed825)throw me['create']('no-app',{'appName':_0x34e2a4});return _0x2ed825;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x602db5){let _0xbb90c5=!0x1;const _0x495d7c=_0x602db5['name'];Ue['has'](_0x495d7c)?(_0xbb90c5=!0x0,Ue['delete'](_0x495d7c)):vi['has'](_0x495d7c)&&_0x602db5['decRefCount']()<=0x0&&(vi['delete'](_0x495d7c),_0xbb90c5=!0x0),_0xbb90c5&&(await Promise['all'](_0x602db5['container']['getProviders']()['map'](_0x692b5f=>_0x692b5f['delete']())),_0x602db5['isDeleted']=!0x0);}function ye(_0x734b44,_0x3751fe,_0x3f4424){let _0x3e096b=wl[_0x734b44]??_0x734b44;_0x3f4424&&(_0x3e096b+='-'+_0x3f4424);const _0x4aa338=_0x3e096b['match'](/\s|\//),_0x3d8a74=_0x3751fe['match'](/\s|\//);if(_0x4aa338||_0x3d8a74){const _0x36b33e=['Unable\x20to\x20register\x20library\x20\x22'+_0x3e096b+'\x22\x20with\x20version\x20\x22'+_0x3751fe+'\x22:'];_0x4aa338&&_0x36b33e['push']('library\x20name\x20\x22'+_0x3e096b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4aa338&&_0x3d8a74&&_0x36b33e['push']('and'),_0x3d8a74&&_0x36b33e['push']('version\x20name\x20\x22'+_0x3751fe+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x36b33e['join']('\x20'));return;}st(new Fe(_0x3e096b+'-version',()=>({'library':_0x3e096b,'version':_0x3751fe}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x4d2562,_0x1ea87a)=>{switch(_0x1ea87a){case 0x0:try{_0x4d2562['createObjectStore'](Ot);}catch(_0x312efe){console['warn'](_0x312efe);}}}})['catch'](_0x4c3464=>{throw me['create']('idb-open',{'originalErrorMessage':_0x4c3464['message']});})),ri;}async function Al(_0x26823a){try{const _0x4bb8e5=(await eo())['transaction'](Ot),_0x1187b1=await _0x4bb8e5['objectStore'](Ot)['get'](to(_0x26823a));return await _0x4bb8e5['done'],_0x1187b1;}catch(_0x4960ef){if(_0x4960ef instanceof Re)oe['warn'](_0x4960ef['message']);else{const _0x581f67=me['create']('idb-get',{'originalErrorMessage':_0x4960ef==null?void 0x0:_0x4960ef['message']});oe['warn'](_0x581f67['message']);}}}async function Fs(_0x1c435b,_0x451b9b){try{const _0xd8f0ff=(await eo())['transaction'](Ot,'readwrite');await _0xd8f0ff['objectStore'](Ot)['put'](_0x451b9b,to(_0x1c435b)),await _0xd8f0ff['done'];}catch(_0x3b38db){if(_0x3b38db instanceof Re)oe['warn'](_0x3b38db['message']);else{const _0x1d51b7=me['create']('idb-set',{'originalErrorMessage':_0x3b38db==null?void 0x0:_0x3b38db['message']});oe['warn'](_0x1d51b7['message']);}}}function to(_0x4633d6){return _0x4633d6['name']+'!'+_0x4633d6['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x310de5){this['container']=_0x310de5,this['_heartbeatsCache']=null;const _0x53dc47=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x53dc47),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xa4e06f=>(this['_heartbeatsCache']=_0xa4e06f,_0xa4e06f));}async['triggerHeartbeat'](){var _0x322656,_0x17ed0d;try{const _0x22a67a=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2d61a7=Us();if(((_0x322656=this['_heartbeatsCache'])==null?void 0x0:_0x322656['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x17ed0d=this['_heartbeatsCache'])==null?void 0x0:_0x17ed0d['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2d61a7||this['_heartbeatsCache']['heartbeats']['some'](_0x5a484d=>_0x5a484d['date']===_0x2d61a7))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2d61a7,'agent':_0x22a67a}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x175584=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x175584,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1905fa){oe['warn'](_0x1905fa);}}async['getHeartbeatsHeader'](){var _0x1c2d82;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1c2d82=this['_heartbeatsCache'])==null?void 0x0:_0x1c2d82['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x268f2c=Us(),{heartbeatsToSend:_0x4e1f99,unsentEntries:_0xd9cc7f}=Ol(this['_heartbeatsCache']['heartbeats']),_0x11687c=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4e1f99}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x268f2c,_0xd9cc7f['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xd9cc7f,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x11687c;}catch(_0x44da82){return oe['warn'](_0x44da82),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5a6160,_0x2f9da5=kl){const _0x4728c8=[];let _0x4dce62=_0x5a6160['slice']();for(const _0x369c5c of _0x5a6160){const _0x7e49d=_0x4728c8['find'](_0x45ffbb=>_0x45ffbb['agent']===_0x369c5c['agent']);if(_0x7e49d){if(_0x7e49d['dates']['push'](_0x369c5c['date']),Ws(_0x4728c8)>_0x2f9da5){_0x7e49d['dates']['pop']();break;}}else{if(_0x4728c8['push']({'agent':_0x369c5c['agent'],'dates':[_0x369c5c['date']]}),Ws(_0x4728c8)>_0x2f9da5){_0x4728c8['pop']();break;}}_0x4dce62=_0x4dce62['slice'](0x1);}return{'heartbeatsToSend':_0x4728c8,'unsentEntries':_0x4dce62};}class Dl{constructor(_0x12a5cf){this['app']=_0x12a5cf,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x57e107=await Al(this['app']);return _0x57e107!=null&&_0x57e107['heartbeats']?_0x57e107:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x52f9fb){if(await this['_canUseIndexedDBPromise']){const _0x21da34=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x52f9fb['lastSentHeartbeatDate']??_0x21da34['lastSentHeartbeatDate'],'heartbeats':_0x52f9fb['heartbeats']});}else return;}async['add'](_0x2a9b67){if(await this['_canUseIndexedDBPromise']){const _0x52b99d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2a9b67['lastSentHeartbeatDate']??_0x52b99d['lastSentHeartbeatDate'],'heartbeats':[..._0x52b99d['heartbeats'],..._0x2a9b67['heartbeats']]});}else return;}}function Ws(_0x3de429){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3de429}))['length'];}function Ml(_0x29cb53){if(_0x29cb53['length']===0x0)return-0x1;let _0x11fdf1=0x0,_0x3e6df7=_0x29cb53[0x0]['date'];for(let _0x10e6c9=0x1;_0x10e6c9<_0x29cb53['length'];_0x10e6c9++)_0x29cb53[_0x10e6c9]['date']<_0x3e6df7&&(_0x3e6df7=_0x29cb53[_0x10e6c9]['date'],_0x11fdf1=_0x10e6c9);return _0x11fdf1;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x336004){st(new Fe('platform-logger',_0x5ee5e3=>new jc(_0x5ee5e3),'PRIVATE')),st(new Fe('heartbeat',_0x2090e8=>new Nl(_0x2090e8),'PRIVATE')),ye(mi,Ls,_0x336004),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2add56){no=_0x2add56;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x500670){this['domStorage_']=_0x500670,this['prefix_']='firebase:';}['set'](_0x2d5728,_0x5f254b){_0x5f254b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2d5728)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2d5728),O(_0x5f254b));}['get'](_0x15679d){const _0x590729=this['domStorage_']['getItem'](this['prefixedName_'](_0x15679d));return _0x590729==null?null:Nt(_0x590729);}['remove'](_0x59853d){this['domStorage_']['removeItem'](this['prefixedName_'](_0x59853d));}['prefixedName_'](_0x4c4798){return this['prefix_']+_0x4c4798;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x211f41,_0x35e26e){_0x35e26e==null?delete this['cache_'][_0x211f41]:this['cache_'][_0x211f41]=_0x35e26e;}['get'](_0x498402){return Q(this['cache_'],_0x498402)?this['cache_'][_0x498402]:null;}['remove'](_0x26fb22){delete this['cache_'][_0x26fb22];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x35bae1){try{if(typeof window<'u'&&typeof window[_0x35bae1]<'u'){const _0x5df75b=window[_0x35bae1];return _0x5df75b['setItem']('firebase:sentinel','cache'),_0x5df75b['removeItem']('firebase:sentinel'),new Wl(_0x5df75b);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x292fb=0x1;return function(){return _0x292fb++;};}()),ro=function(_0x4251b9){const _0x1b1f6c=Rc(_0x4251b9),_0x50ab5d=new Cc();_0x50ab5d['update'](_0x1b1f6c);const _0x1c804d=_0x50ab5d['digest']();return Fi['encodeByteArray'](_0x1c804d);},zt=function(..._0x133a35){let _0x2d8e15='';for(let _0x2b1b0d=0x0;_0x2b1b0d<_0x133a35['length'];_0x2b1b0d++){const _0x464122=_0x133a35[_0x2b1b0d];Array['isArray'](_0x464122)||_0x464122&&typeof _0x464122=='object'&&typeof _0x464122['length']=='number'?_0x2d8e15+=zt['apply'](null,_0x464122):typeof _0x464122=='object'?_0x2d8e15+=O(_0x464122):_0x2d8e15+=_0x464122,_0x2d8e15+='\x20';}return _0x2d8e15;};let St=null,$s=!0x0;const Hl=function(_0xd4776d,_0x4d29d5){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x4b18a1){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x11a2db=zt['apply'](null,_0x4b18a1);St(_0x11a2db);}},jt=function(_0x1c9002){return function(..._0x36fe81){L(_0x1c9002,..._0x36fe81);};},Ii=function(..._0x28d270){const _0x1cc065='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x28d270);Ze['error'](_0x1cc065);},ae=function(..._0x2838ce){const _0x37cac1='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x2838ce);throw Ze['error'](_0x37cac1),new Error(_0x37cac1);},U=function(..._0x334500){const _0x378a21='FIREBASE\x20WARNING:\x20'+zt(..._0x334500);Ze['warn'](_0x378a21);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2396ca){return typeof _0x2396ca=='number'&&(_0x2396ca!==_0x2396ca||_0x2396ca===Number['POSITIVE_INFINITY']||_0x2396ca===Number['NEGATIVE_INFINITY']);},Gl=function(_0x56e9e4){if(document['readyState']==='complete')_0x56e9e4();else{let _0x2e3e0d=!0x1;const _0x20367f=function(){if(!document['body']){setTimeout(_0x20367f,Math['floor'](0xa));return;}_0x2e3e0d||(_0x2e3e0d=!0x0,_0x56e9e4());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x20367f,!0x1),window['addEventListener']('load',_0x20367f,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x20367f();}),window['attachEvent']('onload',_0x20367f));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4a9b48,_0x33b0d6){if(_0x4a9b48===_0x33b0d6)return 0x0;if(_0x4a9b48===We||_0x33b0d6===we)return-0x1;if(_0x33b0d6===We||_0x4a9b48===we)return 0x1;{const _0x5c45f5=Gs(_0x4a9b48),_0x69671d=Gs(_0x33b0d6);return _0x5c45f5!==null?_0x69671d!==null?_0x5c45f5-_0x69671d===0x0?_0x4a9b48['length']-_0x33b0d6['length']:_0x5c45f5-_0x69671d:-0x1:_0x69671d!==null?0x1:_0x4a9b48<_0x33b0d6?-0x1:0x1;}},ql=function(_0x1d0ac4,_0x5e5bb3){return _0x1d0ac4===_0x5e5bb3?0x0:_0x1d0ac4<_0x5e5bb3?-0x1:0x1;},vt=function(_0x41c217,_0x5b33d5){if(_0x5b33d5&&_0x41c217 in _0x5b33d5)return _0x5b33d5[_0x41c217];throw new Error('Missing\x20required\x20key\x20('+_0x41c217+')\x20in\x20object:\x20'+O(_0x5b33d5));},$i=function(_0x1edb99){if(typeof _0x1edb99!='object'||_0x1edb99===null)return O(_0x1edb99);const _0x10e62a=[];for(const _0x5d83f7 in _0x1edb99)_0x10e62a['push'](_0x5d83f7);_0x10e62a['sort']();let _0x3d06f1='{';for(let _0x5abfd2=0x0;_0x5abfd2<_0x10e62a['length'];_0x5abfd2++)_0x5abfd2!==0x0&&(_0x3d06f1+=','),_0x3d06f1+=O(_0x10e62a[_0x5abfd2]),_0x3d06f1+=':',_0x3d06f1+=$i(_0x1edb99[_0x10e62a[_0x5abfd2]]);return _0x3d06f1+='}',_0x3d06f1;},oo=function(_0x3a455b,_0x58057d){const _0x5e80db=_0x3a455b['length'];if(_0x5e80db<=_0x58057d)return[_0x3a455b];const _0x5d91cf=[];for(let _0xcfd33c=0x0;_0xcfd33c<_0x5e80db;_0xcfd33c+=_0x58057d)_0xcfd33c+_0x58057d>_0x5e80db?_0x5d91cf['push'](_0x3a455b['substring'](_0xcfd33c,_0x5e80db)):_0x5d91cf['push'](_0x3a455b['substring'](_0xcfd33c,_0xcfd33c+_0x58057d));return _0x5d91cf;};function x(_0x50d913,_0x206052){for(const _0x585ace in _0x50d913)_0x50d913['hasOwnProperty'](_0x585ace)&&_0x206052(_0x585ace,_0x50d913[_0x585ace]);}const ao=function(_0x64416b){f(!xn(_0x64416b),'Invalid\x20JSON\x20number');const _0x16e08d=0xb,_0x39f785=0x34,_0x1f670b=(0x1<<_0x16e08d-0x1)-0x1;let _0xd515d6,_0x1ae0c5,_0x2f9b5d,_0x45d223,_0x1d1f54;_0x64416b===0x0?(_0x1ae0c5=0x0,_0x2f9b5d=0x0,_0xd515d6=0x1/_0x64416b===-0x1/0x0?0x1:0x0):(_0xd515d6=_0x64416b<0x0,_0x64416b=Math['abs'](_0x64416b),_0x64416b>=Math['pow'](0x2,0x1-_0x1f670b)?(_0x45d223=Math['min'](Math['floor'](Math['log'](_0x64416b)/Math['LN2']),_0x1f670b),_0x1ae0c5=_0x45d223+_0x1f670b,_0x2f9b5d=Math['round'](_0x64416b*Math['pow'](0x2,_0x39f785-_0x45d223)-Math['pow'](0x2,_0x39f785))):(_0x1ae0c5=0x0,_0x2f9b5d=Math['round'](_0x64416b/Math['pow'](0x2,0x1-_0x1f670b-_0x39f785))));const _0x43cdf5=[];for(_0x1d1f54=_0x39f785;_0x1d1f54;_0x1d1f54-=0x1)_0x43cdf5['push'](_0x2f9b5d%0x2?0x1:0x0),_0x2f9b5d=Math['floor'](_0x2f9b5d/0x2);for(_0x1d1f54=_0x16e08d;_0x1d1f54;_0x1d1f54-=0x1)_0x43cdf5['push'](_0x1ae0c5%0x2?0x1:0x0),_0x1ae0c5=Math['floor'](_0x1ae0c5/0x2);_0x43cdf5['push'](_0xd515d6?0x1:0x0),_0x43cdf5['reverse']();const _0x5d71a8=_0x43cdf5['join']('');let _0x272448='';for(_0x1d1f54=0x0;_0x1d1f54<0x40;_0x1d1f54+=0x8){let _0x5451d3=parseInt(_0x5d71a8['substr'](_0x1d1f54,0x8),0x2)['toString'](0x10);_0x5451d3['length']===0x1&&(_0x5451d3='0'+_0x5451d3),_0x272448=_0x272448+_0x5451d3;}return _0x272448['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0xf745f9,_0x31fc18){let _0x123974='Unknown\x20Error';_0xf745f9==='too_big'?_0x123974='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xf745f9==='permission_denied'?_0x123974='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xf745f9==='unavailable'&&(_0x123974='The\x20service\x20is\x20unavailable');const _0x4d9fd2=new Error(_0xf745f9+'\x20at\x20'+_0x31fc18['_path']['toString']()+':\x20'+_0x123974);return _0x4d9fd2['code']=_0xf745f9['toUpperCase'](),_0x4d9fd2;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x6fbc3b){if(Yl['test'](_0x6fbc3b)){const _0x1a57ec=Number(_0x6fbc3b);if(_0x1a57ec>=Ql&&_0x1a57ec<=Jl)return _0x1a57ec;}return null;},ft=function(_0x5154bb){try{_0x5154bb();}catch(_0x267844){setTimeout(()=>{const _0x40fdb5=_0x267844['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x40fdb5),_0x267844;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x2bec6d,_0x5d1518){const _0x2d7560=setTimeout(_0x2bec6d,_0x5d1518);return typeof _0x2d7560=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2d7560):typeof _0x2d7560=='object'&&_0x2d7560['unref']&&_0x2d7560['unref'](),_0x2d7560;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x25cf9c,_0x19185a){this['appCheckProvider']=_0x19185a,this['appName']=_0x25cf9c['name'],$(_0x25cf9c)&&_0x25cf9c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x25cf9c['settings']['appCheckToken']),this['appCheck']=_0x19185a==null?void 0x0:_0x19185a['getImmediate']({'optional':!0x0}),this['appCheck']||_0x19185a==null||_0x19185a['get']()['then'](_0xaf580c=>this['appCheck']=_0xaf580c);}['getToken'](_0x20fd5b){if(this['serverAppAppCheckToken']){if(_0x20fd5b)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x20fd5b):new Promise((_0x403a81,_0x44ae1a)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x20fd5b)['then'](_0x403a81,_0x44ae1a):_0x403a81(null);},0x0);});}['addTokenChangeListener'](_0x12e775){var _0xa74a2d;(_0xa74a2d=this['appCheckProvider'])==null||_0xa74a2d['get']()['then'](_0x3db729=>_0x3db729['addTokenListener'](_0x12e775));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2dac28,_0x153da3,_0x46a06d){this['appName_']=_0x2dac28,this['firebaseOptions_']=_0x153da3,this['authProvider_']=_0x46a06d,this['auth_']=null,this['auth_']=_0x46a06d['getImmediate']({'optional':!0x0}),this['auth_']||_0x46a06d['onInit'](_0x2a7042=>this['auth_']=_0x2a7042);}['getToken'](_0x2adc8d){return this['auth_']?this['auth_']['getToken'](_0x2adc8d)['catch'](_0x1fbbc5=>_0x1fbbc5&&_0x1fbbc5['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1fbbc5)):new Promise((_0x149a04,_0xfa3ec3)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2adc8d)['then'](_0x149a04,_0xfa3ec3):_0x149a04(null);},0x0);});}['addTokenChangeListener'](_0x43f820){this['auth_']?this['auth_']['addAuthTokenListener'](_0x43f820):this['authProvider_']['get']()['then'](_0x280bb5=>_0x280bb5['addAuthTokenListener'](_0x43f820));}['removeTokenChangeListener'](_0x542b12){this['authProvider_']['get']()['then'](_0x2d7b84=>_0x2d7b84['removeAuthTokenListener'](_0x542b12));}['notifyForInvalidToken'](){let _0x32c9f7='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x32c9f7+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x32c9f7+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x32c9f7+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x32c9f7);}}class an{constructor(_0x500b3d){this['accessToken']=_0x500b3d;}['getToken'](_0x232731){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4a31fa){_0x4a31fa(this['accessToken']);}['removeTokenChangeListener'](_0x16f45f){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x381d35,_0x20f3a6,_0x4750f8,_0x1c5cb1,_0x1394b9=!0x1,_0x6ad010='',_0x52d7d9=!0x1,_0x4721b2=!0x1,_0x3b8bd9=null){this['secure']=_0x20f3a6,this['namespace']=_0x4750f8,this['webSocketOnly']=_0x1c5cb1,this['nodeAdmin']=_0x1394b9,this['persistenceKey']=_0x6ad010,this['includeNamespaceInQueryParams']=_0x52d7d9,this['isUsingEmulator']=_0x4721b2,this['emulatorOptions']=_0x3b8bd9,this['_host']=_0x381d35['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x381d35)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x38f902){_0x38f902!==this['internalHost']&&(this['internalHost']=_0x38f902,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1afc31=this['toURLString']();return this['persistenceKey']&&(_0x1afc31+='<'+this['persistenceKey']+'>'),_0x1afc31;}['toURLString'](){const _0x4e55ea=this['secure']?'https://':'http://',_0x2b42eb=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4e55ea+this['host']+'/'+_0x2b42eb;}}function th(_0x307fa1){return _0x307fa1['host']!==_0x307fa1['internalHost']||_0x307fa1['isCustomHost']()||_0x307fa1['includeNamespaceInQueryParams'];}function vo(_0x5ce466,_0x3fb9ba,_0x6e94c9){f(typeof _0x3fb9ba=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x6e94c9=='object','typeof\x20params\x20must\x20==\x20object');let _0x388a35;if(_0x3fb9ba===go)_0x388a35=(_0x5ce466['secure']?'wss://':'ws://')+_0x5ce466['internalHost']+'/.ws?';else{if(_0x3fb9ba===mo)_0x388a35=(_0x5ce466['secure']?'https://':'http://')+_0x5ce466['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3fb9ba);}th(_0x5ce466)&&(_0x6e94c9['ns']=_0x5ce466['namespace']);const _0x273854=[];return x(_0x6e94c9,(_0x4d32c0,_0x10119e)=>{_0x273854['push'](_0x4d32c0+'='+_0x10119e);}),_0x388a35+_0x273854['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1dd0e9,_0x56d291=0x1){Q(this['counters_'],_0x1dd0e9)||(this['counters_'][_0x1dd0e9]=0x0),this['counters_'][_0x1dd0e9]+=_0x56d291;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x36d04c){const _0x13fbdd=_0x36d04c['toString']();return oi[_0x13fbdd]||(oi[_0x13fbdd]=new nh()),oi[_0x13fbdd];}function ih(_0x254d7b,_0x59cf00){const _0x2c52df=_0x254d7b['toString']();return ai[_0x2c52df]||(ai[_0x2c52df]=_0x59cf00()),ai[_0x2c52df];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x1cb488){this['onMessage_']=_0x1cb488,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x57f42d,_0x5166cb){this['closeAfterResponse']=_0x57f42d,this['onClose']=_0x5166cb,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3cd5bd,_0x513995){for(this['pendingResponses'][_0x3cd5bd]=_0x513995;this['pendingResponses'][this['currentResponseNum']];){const _0x50b3cc=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x14d4e8=0x0;_0x14d4e8<_0x50b3cc['length'];++_0x14d4e8)_0x50b3cc[_0x14d4e8]&&ft(()=>{this['onMessage_'](_0x50b3cc[_0x14d4e8]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x1e3745,_0x8e92ec,_0x5c02d6,_0x41304b,_0x1b8e38,_0xd4c854,_0x4aa910){this['connId']=_0x1e3745,this['repoInfo']=_0x8e92ec,this['applicationId']=_0x5c02d6,this['appCheckToken']=_0x41304b,this['authToken']=_0x1b8e38,this['transportSessionId']=_0xd4c854,this['lastSessionId']=_0x4aa910,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x1e3745),this['stats_']=qi(_0x8e92ec),this['urlFn']=_0x2a4cbe=>(this['appCheckToken']&&(_0x2a4cbe[wi]=this['appCheckToken']),vo(_0x8e92ec,mo,_0x2a4cbe));}['open'](_0x31f674,_0x147fa6){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x147fa6,this['myPacketOrderer']=new sh(_0x31f674),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x781a0e)=>{const [_0x391209,_0x338883,_0x2f2a02,_0x46781f,_0x51143d]=_0x781a0e;if(this['incrementIncomingBytes_'](_0x781a0e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x391209===qs)this['id']=_0x338883,this['password']=_0x2f2a02;else{if(_0x391209===rh)_0x338883?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x338883,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x391209);}}},(..._0x291ed3)=>{const [_0x3086ea,_0xad4dfd]=_0x291ed3;this['incrementIncomingBytes_'](_0x291ed3),this['myPacketOrderer']['handleResponse'](_0x3086ea,_0xad4dfd);},()=>{this['onClosed_']();},this['urlFn']);const _0x3373fc={};_0x3373fc[qs]='t',_0x3373fc[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3373fc[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3373fc[co]=Gi,this['transportSessionId']&&(_0x3373fc[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3373fc[po]=this['lastSessionId']),this['applicationId']&&(_0x3373fc[_o]=this['applicationId']),this['appCheckToken']&&(_0x3373fc[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3373fc[ho]=uo);const _0x4f57fd=this['urlFn'](_0x3373fc);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4f57fd),this['scriptTagHolder']['addTag'](_0x4f57fd,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x178c54){const _0x114d89=O(_0x178c54);this['bytesSent']+=_0x114d89['length'],this['stats_']['incrementCounter']('bytes_sent',_0x114d89['length']);const _0x23e057=$r(_0x114d89),_0xbac083=oo(_0x23e057,fh);for(let _0x2fe8f8=0x0;_0x2fe8f8<_0xbac083['length'];_0x2fe8f8++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xbac083['length'],_0xbac083[_0x2fe8f8]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x57d01a,_0x12f6c6){this['myDisconnFrame']=document['createElement']('iframe');const _0x421bf0={};_0x421bf0[dh]='t',_0x421bf0[Eo]=_0x57d01a,_0x421bf0[Io]=_0x12f6c6,this['myDisconnFrame']['src']=this['urlFn'](_0x421bf0),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x15d5d4){const _0x3a895c=O(_0x15d5d4)['length'];this['bytesReceived']+=_0x3a895c,this['stats_']['incrementCounter']('bytes_received',_0x3a895c);}}class zi{constructor(_0x45f2b1,_0x2df540,_0x314b54,_0x142c1a){this['onDisconnect']=_0x314b54,this['urlFn']=_0x142c1a,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x45f2b1,window[ah+this['uniqueCallbackIdentifier']]=_0x2df540,this['myIFrame']=zi['createIFrame_']();let _0x373e03='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x373e03='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x27457a='<html><body>'+_0x373e03+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x27457a),this['myIFrame']['doc']['close']();}catch(_0x369498){L('frame\x20writing\x20exception'),_0x369498['stack']&&L(_0x369498['stack']),L(_0x369498);}}}static['createIFrame_'](){const _0x219840=document['createElement']('iframe');if(_0x219840['style']['display']='none',document['body']){document['body']['appendChild'](_0x219840);try{_0x219840['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x6fa8f=document['domain'];_0x219840['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x6fa8f+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x219840['contentDocument']?_0x219840['doc']=_0x219840['contentDocument']:_0x219840['contentWindow']?_0x219840['doc']=_0x219840['contentWindow']['document']:_0x219840['document']&&(_0x219840['doc']=_0x219840['document']),_0x219840;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4e7b98=this['onDisconnect'];_0x4e7b98&&(this['onDisconnect']=null,_0x4e7b98());}['startLongPoll'](_0x548ef9,_0x42234b){for(this['myID']=_0x548ef9,this['myPW']=_0x42234b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3f65fd={};_0x3f65fd[Eo]=this['myID'],_0x3f65fd[Io]=this['myPW'],_0x3f65fd[wo]=this['currentSerial'];let _0x3bd5e3=this['urlFn'](_0x3f65fd),_0x246488='',_0x3bf75a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x246488['length']<=Co;){const _0x1f743d=this['pendingSegs']['shift']();_0x246488=_0x246488+'&'+lh+_0x3bf75a+'='+_0x1f743d['seg']+'&'+hh+_0x3bf75a+'='+_0x1f743d['ts']+'&'+uh+_0x3bf75a+'='+_0x1f743d['d'],_0x3bf75a++;}return _0x3bd5e3=_0x3bd5e3+_0x246488,this['addLongPollTag_'](_0x3bd5e3,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3e2320,_0x349093,_0x42de3d){this['pendingSegs']['push']({'seg':_0x3e2320,'ts':_0x349093,'d':_0x42de3d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x52368e,_0x329ecf){this['outstandingRequests']['add'](_0x329ecf);const _0xec77a3=()=>{this['outstandingRequests']['delete'](_0x329ecf),this['newRequest_']();},_0x977221=setTimeout(_0xec77a3,Math['floor'](ph)),_0x64fd9a=()=>{clearTimeout(_0x977221),_0xec77a3();};this['addTag'](_0x52368e,_0x64fd9a);}['addTag'](_0x171e10,_0x4b3c11){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xc40aad=this['myIFrame']['doc']['createElement']('script');_0xc40aad['type']='text/javascript',_0xc40aad['async']=!0x0,_0xc40aad['src']=_0x171e10,_0xc40aad['onload']=_0xc40aad['onreadystatechange']=function(){const _0xffa080=_0xc40aad['readyState'];(!_0xffa080||_0xffa080==='loaded'||_0xffa080==='complete')&&(_0xc40aad['onload']=_0xc40aad['onreadystatechange']=null,_0xc40aad['parentNode']&&_0xc40aad['parentNode']['removeChild'](_0xc40aad),_0x4b3c11());},_0xc40aad['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x171e10),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xc40aad);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x313f58,_0x38a563,_0x554f37,_0x41b73e,_0x46b187,_0x140489,_0x24cb17){this['connId']=_0x313f58,this['applicationId']=_0x554f37,this['appCheckToken']=_0x41b73e,this['authToken']=_0x46b187,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x38a563),this['connURL']=q['connectionURL_'](_0x38a563,_0x140489,_0x24cb17,_0x41b73e,_0x554f37),this['nodeAdmin']=_0x38a563['nodeAdmin'];}static['connectionURL_'](_0x10aa9f,_0x20576e,_0x53268e,_0x1ba2c7,_0x1fa9fa){const _0x3bea4c={};return _0x3bea4c[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3bea4c[ho]=uo),_0x20576e&&(_0x3bea4c[lo]=_0x20576e),_0x53268e&&(_0x3bea4c[po]=_0x53268e),_0x1ba2c7&&(_0x3bea4c[wi]=_0x1ba2c7),_0x1fa9fa&&(_0x3bea4c[_o]=_0x1fa9fa),vo(_0x10aa9f,go,_0x3bea4c);}['open'](_0x4bb45e,_0x4fe8db){this['onDisconnect']=_0x4fe8db,this['onMessage']=_0x4bb45e,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x281afb;_c(),this['mySock']=new gn(this['connURL'],[],_0x281afb);}catch(_0x212e11){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x537100=_0x212e11['message']||_0x212e11['data'];_0x537100&&this['log_'](_0x537100),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x177a49=>{this['handleIncomingFrame'](_0x177a49);},this['mySock']['onerror']=_0x5e2eee=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5e0460=_0x5e2eee['message']||_0x5e2eee['data'];_0x5e0460&&this['log_'](_0x5e0460),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5581f1=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x23ffc5=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x25a1c8=navigator['userAgent']['match'](_0x23ffc5);_0x25a1c8&&_0x25a1c8['length']>0x1&&parseFloat(_0x25a1c8[0x1])<4.4&&(_0x5581f1=!0x0);}return!_0x5581f1&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x197267){if(this['frames']['push'](_0x197267),this['frames']['length']===this['totalFrames']){const _0x38911c=this['frames']['join']('');this['frames']=null;const _0x3c36ff=Nt(_0x38911c);this['onMessage'](_0x3c36ff);}}['handleNewFrameCount_'](_0x11ffd0){this['totalFrames']=_0x11ffd0,this['frames']=[];}['extractFrameCount_'](_0xecee50){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xecee50['length']<=0x6){const _0x21dadd=Number(_0xecee50);if(!isNaN(_0x21dadd))return this['handleNewFrameCount_'](_0x21dadd),null;}return this['handleNewFrameCount_'](0x1),_0xecee50;}['handleIncomingFrame'](_0x24ee61){if(this['mySock']===null)return;const _0x41c3d4=_0x24ee61['data'];if(this['bytesReceived']+=_0x41c3d4['length'],this['stats_']['incrementCounter']('bytes_received',_0x41c3d4['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x41c3d4);else{const _0x2133ef=this['extractFrameCount_'](_0x41c3d4);_0x2133ef!==null&&this['appendFrame_'](_0x2133ef);}}['send'](_0x26ae90){this['resetKeepAlive']();const _0x183c2d=O(_0x26ae90);this['bytesSent']+=_0x183c2d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x183c2d['length']);const _0x5a0abe=oo(_0x183c2d,gh);_0x5a0abe['length']>0x1&&this['sendString_'](String(_0x5a0abe['length']));for(let _0x10041b=0x0;_0x10041b<_0x5a0abe['length'];_0x10041b++)this['sendString_'](_0x5a0abe[_0x10041b]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x5e238e){try{this['mySock']['send'](_0x5e238e);}catch(_0x26e2b7){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x26e2b7['message']||_0x26e2b7['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1355a4){this['initTransports_'](_0x1355a4);}['initTransports_'](_0x330c5f){const _0x79bd74=q&&q['isAvailable']();let _0x209be7=_0x79bd74&&!q['previouslyFailed']();if(_0x330c5f['webSocketOnly']&&(_0x79bd74||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x209be7=!0x0),_0x209be7)this['transports_']=[q];else{const _0x1c793b=this['transports_']=[];for(const _0x5dedba of Dt['ALL_TRANSPORTS'])_0x5dedba&&_0x5dedba['isAvailable']()&&_0x1c793b['push'](_0x5dedba);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x959769,_0x44cbed,_0x3be3e5,_0x5a43bb,_0x1910ea,_0x4ad01a,_0x2b2951,_0x566bac,_0x4e7f73,_0x8cdac4){this['id']=_0x959769,this['repoInfo_']=_0x44cbed,this['applicationId_']=_0x3be3e5,this['appCheckToken_']=_0x5a43bb,this['authToken_']=_0x1910ea,this['onMessage_']=_0x4ad01a,this['onReady_']=_0x2b2951,this['onDisconnect_']=_0x566bac,this['onKill_']=_0x4e7f73,this['lastSessionId']=_0x8cdac4,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x44cbed),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5044d5=this['transportManager_']['initialTransport']();this['conn_']=new _0x5044d5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5044d5['responsesRequiredToBeHealthy']||0x0;const _0x17c66d=this['connReceiver_'](this['conn_']),_0x4ec1d1=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x17c66d,_0x4ec1d1);},Math['floor'](0x0));const _0x11432c=_0x5044d5['healthyTimeout']||0x0;_0x11432c>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x11432c)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x494061){return _0x31c245=>{_0x494061===this['conn_']?this['onConnectionLost_'](_0x31c245):_0x494061===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x15db17){return _0x4c5a3e=>{this['state_']!==0x2&&(_0x15db17===this['rx_']?this['onPrimaryMessageReceived_'](_0x4c5a3e):_0x15db17===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4c5a3e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xce9c86){const _0x1feef9={'t':'d','d':_0xce9c86};this['sendData_'](_0x1feef9);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x50b222){if(ci in _0x50b222){const _0x394fc8=_0x50b222[ci];_0x394fc8===Ys?this['upgradeIfSecondaryHealthy_']():_0x394fc8===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x394fc8===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4f29b8){const _0x2a5c85=vt('t',_0x4f29b8),_0x508c96=vt('d',_0x4f29b8);if(_0x2a5c85==='c')this['onSecondaryControl_'](_0x508c96);else{if(_0x2a5c85==='d')this['pendingDataMessages']['push'](_0x508c96);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x2a5c85);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5258ca){const _0x1f3463=vt('t',_0x5258ca),_0x593205=vt('d',_0x5258ca);_0x1f3463==='c'?this['onControl_'](_0x593205):_0x1f3463==='d'&&this['onDataMessage_'](_0x593205);}['onDataMessage_'](_0x351387){this['onPrimaryResponse_'](),this['onMessage_'](_0x351387);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x52a315){const _0x280362=vt(ci,_0x52a315);if(zs in _0x52a315){const _0x7d8fb4=_0x52a315[zs];if(_0x280362===Th){const _0x8c4fb9={..._0x7d8fb4};this['repoInfo_']['isUsingEmulator']&&(_0x8c4fb9['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x8c4fb9);}else{if(_0x280362===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x37e035=0x0;_0x37e035<this['pendingDataMessages']['length'];++_0x37e035)this['onDataMessage_'](this['pendingDataMessages'][_0x37e035]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x280362===wh?this['onConnectionShutdown_'](_0x7d8fb4):_0x280362===js?this['onReset_'](_0x7d8fb4):_0x280362===Ch?Ii('Server\x20Error:\x20'+_0x7d8fb4):_0x280362===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x280362);}}}['onHandshake_'](_0x47afc3){const _0x590a74=_0x47afc3['ts'],_0x1dd75f=_0x47afc3['v'],_0x5d9586=_0x47afc3['h'];this['sessionId']=_0x47afc3['s'],this['repoInfo_']['host']=_0x5d9586,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x590a74),Gi!==_0x1dd75f&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x204afa=this['transportManager_']['upgradeTransport']();_0x204afa&&this['startUpgrade_'](_0x204afa);}['startUpgrade_'](_0x4682ec){this['secondaryConn_']=new _0x4682ec(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4682ec['responsesRequiredToBeHealthy']||0x0;const _0x8652db=this['connReceiver_'](this['secondaryConn_']),_0x4e2230=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x8652db,_0x4e2230),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x495917){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x495917),this['repoInfo_']['host']=_0x495917,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x483b0e,_0xcdbe76){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x483b0e,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xcdbe76,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xb7a29c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xb7a29c||this['rx_']===_0xb7a29c)&&this['close']();}['onConnectionLost_'](_0x237760){this['conn_']=null,!_0x237760&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5ce382){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5ce382),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x722938){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x722938);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x28c313,_0xa49adb,_0x110ffe,_0x17df10){}['merge'](_0x3053b7,_0x439f8d,_0xab345c,_0x38a197){}['refreshAuthToken'](_0x312f65){}['refreshAppCheckToken'](_0x1f1524){}['onDisconnectPut'](_0x409044,_0x7d18f8,_0x4e5275){}['onDisconnectMerge'](_0x39f6af,_0x2c87bc,_0x531cbe){}['onDisconnectCancel'](_0x23d966,_0x2492a3){}['reportStats'](_0x163283){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x590e36){this['allowedEvents_']=_0x590e36,this['listeners_']={},f(Array['isArray'](_0x590e36)&&_0x590e36['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x37ed61,..._0x15004e){if(Array['isArray'](this['listeners_'][_0x37ed61])){const _0x202f56=[...this['listeners_'][_0x37ed61]];for(let _0x3a5715=0x0;_0x3a5715<_0x202f56['length'];_0x3a5715++)_0x202f56[_0x3a5715]['callback']['apply'](_0x202f56[_0x3a5715]['context'],_0x15004e);}}['on'](_0x53a375,_0x55e006,_0x46842d){this['validateEventType_'](_0x53a375),this['listeners_'][_0x53a375]=this['listeners_'][_0x53a375]||[],this['listeners_'][_0x53a375]['push']({'callback':_0x55e006,'context':_0x46842d});const _0x563295=this['getInitialEvent'](_0x53a375);_0x563295&&_0x55e006['apply'](_0x46842d,_0x563295);}['off'](_0x25646e,_0x53f212,_0x2aeccf){this['validateEventType_'](_0x25646e);const _0x207738=this['listeners_'][_0x25646e]||[];for(let _0xc0a01=0x0;_0xc0a01<_0x207738['length'];_0xc0a01++)if(_0x207738[_0xc0a01]['callback']===_0x53f212&&(!_0x2aeccf||_0x2aeccf===_0x207738[_0xc0a01]['context'])){_0x207738['splice'](_0xc0a01,0x1);return;}}['validateEventType_'](_0x136775){f(this['allowedEvents_']['find'](_0x288a76=>_0x288a76===_0x136775),'Unknown\x20event:\x20'+_0x136775);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1ec479){return f(_0x1ec479==='online','Unknown\x20event\x20type:\x20'+_0x1ec479),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1b2362,_0x3e3ecd){if(_0x3e3ecd===void 0x0){this['pieces_']=_0x1b2362['split']('/');let _0x28c0fd=0x0;for(let _0x172fee=0x0;_0x172fee<this['pieces_']['length'];_0x172fee++)this['pieces_'][_0x172fee]['length']>0x0&&(this['pieces_'][_0x28c0fd]=this['pieces_'][_0x172fee],_0x28c0fd++);this['pieces_']['length']=_0x28c0fd,this['pieceNum_']=0x0;}else this['pieces_']=_0x1b2362,this['pieceNum_']=_0x3e3ecd;}['toString'](){let _0xa235d2='';for(let _0x43cda8=this['pieceNum_'];_0x43cda8<this['pieces_']['length'];_0x43cda8++)this['pieces_'][_0x43cda8]!==''&&(_0xa235d2+='/'+this['pieces_'][_0x43cda8]);return _0xa235d2||'/';}}function w(){return new C('');}function y(_0x51baa8){return _0x51baa8['pieceNum_']>=_0x51baa8['pieces_']['length']?null:_0x51baa8['pieces_'][_0x51baa8['pieceNum_']];}function Ce(_0x4132e2){return _0x4132e2['pieces_']['length']-_0x4132e2['pieceNum_'];}function S(_0x1d5be2){let _0x5b06d7=_0x1d5be2['pieceNum_'];return _0x5b06d7<_0x1d5be2['pieces_']['length']&&_0x5b06d7++,new C(_0x1d5be2['pieces_'],_0x5b06d7);}function ji(_0x2b054e){return _0x2b054e['pieceNum_']<_0x2b054e['pieces_']['length']?_0x2b054e['pieces_'][_0x2b054e['pieces_']['length']-0x1]:null;}function bh(_0x38e51c){let _0x462089='';for(let _0x3ae204=_0x38e51c['pieceNum_'];_0x3ae204<_0x38e51c['pieces_']['length'];_0x3ae204++)_0x38e51c['pieces_'][_0x3ae204]!==''&&(_0x462089+='/'+encodeURIComponent(String(_0x38e51c['pieces_'][_0x3ae204])));return _0x462089||'/';}function Mt(_0x20e581,_0x30f022=0x0){return _0x20e581['pieces_']['slice'](_0x20e581['pieceNum_']+_0x30f022);}function Ro(_0x4574f5){if(_0x4574f5['pieceNum_']>=_0x4574f5['pieces_']['length'])return null;const _0x48e3e2=[];for(let _0x4241c1=_0x4574f5['pieceNum_'];_0x4241c1<_0x4574f5['pieces_']['length']-0x1;_0x4241c1++)_0x48e3e2['push'](_0x4574f5['pieces_'][_0x4241c1]);return new C(_0x48e3e2,0x0);}function k(_0x5d28e7,_0x433f10){const _0xf44901=[];for(let _0x1a7891=_0x5d28e7['pieceNum_'];_0x1a7891<_0x5d28e7['pieces_']['length'];_0x1a7891++)_0xf44901['push'](_0x5d28e7['pieces_'][_0x1a7891]);if(_0x433f10 instanceof C){for(let _0x472c86=_0x433f10['pieceNum_'];_0x472c86<_0x433f10['pieces_']['length'];_0x472c86++)_0xf44901['push'](_0x433f10['pieces_'][_0x472c86]);}else{const _0x2c70fa=_0x433f10['split']('/');for(let _0x451cea=0x0;_0x451cea<_0x2c70fa['length'];_0x451cea++)_0x2c70fa[_0x451cea]['length']>0x0&&_0xf44901['push'](_0x2c70fa[_0x451cea]);}return new C(_0xf44901,0x0);}function v(_0x32abce){return _0x32abce['pieceNum_']>=_0x32abce['pieces_']['length'];}function F(_0x5aa7e6,_0x435004){const _0x49fa12=y(_0x5aa7e6),_0x4cdb74=y(_0x435004);if(_0x49fa12===null)return _0x435004;if(_0x49fa12===_0x4cdb74)return F(S(_0x5aa7e6),S(_0x435004));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x435004+')\x20is\x20not\x20within\x20outerPath\x20('+_0x5aa7e6+')');}function Rh(_0x1c56f4,_0x3c080d){const _0x4dcd9b=Mt(_0x1c56f4,0x0),_0x28d3d5=Mt(_0x3c080d,0x0);for(let _0x13806f=0x0;_0x13806f<_0x4dcd9b['length']&&_0x13806f<_0x28d3d5['length'];_0x13806f++){const _0x2d4e77=qe(_0x4dcd9b[_0x13806f],_0x28d3d5[_0x13806f]);if(_0x2d4e77!==0x0)return _0x2d4e77;}return _0x4dcd9b['length']===_0x28d3d5['length']?0x0:_0x4dcd9b['length']<_0x28d3d5['length']?-0x1:0x1;}function Ki(_0x1cefee,_0x4e48b0){if(Ce(_0x1cefee)!==Ce(_0x4e48b0))return!0x1;for(let _0x528702=_0x1cefee['pieceNum_'],_0x547eea=_0x4e48b0['pieceNum_'];_0x528702<=_0x1cefee['pieces_']['length'];_0x528702++,_0x547eea++)if(_0x1cefee['pieces_'][_0x528702]!==_0x4e48b0['pieces_'][_0x547eea])return!0x1;return!0x0;}function G(_0xc765d8,_0x578f48){let _0x5d4d35=_0xc765d8['pieceNum_'],_0x1ea332=_0x578f48['pieceNum_'];if(Ce(_0xc765d8)>Ce(_0x578f48))return!0x1;for(;_0x5d4d35<_0xc765d8['pieces_']['length'];){if(_0xc765d8['pieces_'][_0x5d4d35]!==_0x578f48['pieces_'][_0x1ea332])return!0x1;++_0x5d4d35,++_0x1ea332;}return!0x0;}class Ah{constructor(_0x5a3c9c,_0x43ad7f){this['errorPrefix_']=_0x43ad7f,this['parts_']=Mt(_0x5a3c9c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xd241c6=0x0;_0xd241c6<this['parts_']['length'];_0xd241c6++)this['byteLength_']+=Ln(this['parts_'][_0xd241c6]);Ao(this);}}function kh(_0x3c3dbe,_0x494094){_0x3c3dbe['parts_']['length']>0x0&&(_0x3c3dbe['byteLength_']+=0x1),_0x3c3dbe['parts_']['push'](_0x494094),_0x3c3dbe['byteLength_']+=Ln(_0x494094),Ao(_0x3c3dbe);}function Ph(_0x489e4f){const _0x4e88cc=_0x489e4f['parts_']['pop']();_0x489e4f['byteLength_']-=Ln(_0x4e88cc),_0x489e4f['parts_']['length']>0x0&&(_0x489e4f['byteLength_']-=0x1);}function Ao(_0x636b87){if(_0x636b87['byteLength_']>Zs)throw new Error(_0x636b87['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x636b87['byteLength_']+').');if(_0x636b87['parts_']['length']>Xs)throw new Error(_0x636b87['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x636b87));}function Oe(_0x312906){return _0x312906['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x312906['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x14315e,_0xc7ffd8;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xc7ffd8='visibilitychange',_0x14315e='hidden'):typeof document['mozHidden']<'u'?(_0xc7ffd8='mozvisibilitychange',_0x14315e='mozHidden'):typeof document['msHidden']<'u'?(_0xc7ffd8='msvisibilitychange',_0x14315e='msHidden'):typeof document['webkitHidden']<'u'&&(_0xc7ffd8='webkitvisibilitychange',_0x14315e='webkitHidden')),this['visible_']=!0x0,_0xc7ffd8&&document['addEventListener'](_0xc7ffd8,()=>{const _0x594ade=!document[_0x14315e];_0x594ade!==this['visible_']&&(this['visible_']=_0x594ade,this['trigger']('visible',_0x594ade));},!0x1);}['getInitialEvent'](_0x5a7373){return f(_0x5a7373==='visible','Unknown\x20event\x20type:\x20'+_0x5a7373),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x34f80c,_0x33ea5a,_0x35057f,_0x3094ea,_0x22be3c,_0x3287c7,_0x2828d3,_0x14ad92){if(super(),this['repoInfo_']=_0x34f80c,this['applicationId_']=_0x33ea5a,this['onDataUpdate_']=_0x35057f,this['onConnectStatus_']=_0x3094ea,this['onServerInfoUpdate_']=_0x22be3c,this['authTokenProvider_']=_0x3287c7,this['appCheckTokenProvider_']=_0x2828d3,this['authOverride_']=_0x14ad92,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x14ad92)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x34f80c['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x29ff1c,_0x562b08,_0x211989){const _0x3dafcc=++this['requestNumber_'],_0x46d951={'r':_0x3dafcc,'a':_0x29ff1c,'b':_0x562b08};this['log_'](O(_0x46d951)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x46d951),_0x211989&&(this['requestCBHash_'][_0x3dafcc]=_0x211989);}['get'](_0x34a451){this['initConnection_']();const _0x2e3ffe=new H(),_0x1e20ea={'action':'g','request':{'p':_0x34a451['_path']['toString'](),'q':_0x34a451['_queryObject']},'onComplete':_0x5ec5cd=>{const _0x8987a3=_0x5ec5cd['d'];_0x5ec5cd['s']==='ok'?_0x2e3ffe['resolve'](_0x8987a3):_0x2e3ffe['reject'](_0x8987a3);}};this['outstandingGets_']['push'](_0x1e20ea),this['outstandingGetCount_']++;const _0x576444=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x576444),_0x2e3ffe['promise'];}['listen'](_0x5b8f70,_0x35e177,_0x21233d,_0x3d9b82){this['initConnection_']();const _0x117c95=_0x5b8f70['_queryIdentifier'],_0x62f464=_0x5b8f70['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x62f464+'\x20'+_0x117c95),this['listens']['has'](_0x62f464)||this['listens']['set'](_0x62f464,new Map()),f(_0x5b8f70['_queryParams']['isDefault']()||!_0x5b8f70['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x62f464)['has'](_0x117c95),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x128e8f={'onComplete':_0x3d9b82,'hashFn':_0x35e177,'query':_0x5b8f70,'tag':_0x21233d};this['listens']['get'](_0x62f464)['set'](_0x117c95,_0x128e8f),this['connected_']&&this['sendListen_'](_0x128e8f);}['sendGet_'](_0x3eac4e){const _0x1d94c6=this['outstandingGets_'][_0x3eac4e];this['sendRequest']('g',_0x1d94c6['request'],_0x287ceb=>{delete this['outstandingGets_'][_0x3eac4e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1d94c6['onComplete']&&_0x1d94c6['onComplete'](_0x287ceb);});}['sendListen_'](_0x3e33aa){const _0x4a9af3=_0x3e33aa['query'],_0x449024=_0x4a9af3['_path']['toString'](),_0x34c2bd=_0x4a9af3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x449024+'\x20for\x20'+_0x34c2bd);const _0x202d9e={'p':_0x449024},_0x2596cc='q';_0x3e33aa['tag']&&(_0x202d9e['q']=_0x4a9af3['_queryObject'],_0x202d9e['t']=_0x3e33aa['tag']),_0x202d9e['h']=_0x3e33aa['hashFn'](),this['sendRequest'](_0x2596cc,_0x202d9e,_0x4946c8=>{const _0x2f8561=_0x4946c8['d'],_0x1bf293=_0x4946c8['s'];se['warnOnListenWarnings_'](_0x2f8561,_0x4a9af3),(this['listens']['get'](_0x449024)&&this['listens']['get'](_0x449024)['get'](_0x34c2bd))===_0x3e33aa&&(this['log_']('listen\x20response',_0x4946c8),_0x1bf293!=='ok'&&this['removeListen_'](_0x449024,_0x34c2bd),_0x3e33aa['onComplete']&&_0x3e33aa['onComplete'](_0x1bf293,_0x2f8561));});}static['warnOnListenWarnings_'](_0x34f6e8,_0x21fc68){if(_0x34f6e8&&typeof _0x34f6e8=='object'&&Q(_0x34f6e8,'w')){const _0x58085e=Le(_0x34f6e8,'w');if(Array['isArray'](_0x58085e)&&~_0x58085e['indexOf']('no_index')){const _0x29fd5c='\x22.indexOn\x22:\x20\x22'+_0x21fc68['_queryParams']['getIndex']()['toString']()+'\x22',_0x39ec2d=_0x21fc68['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x29fd5c+'\x20at\x20'+_0x39ec2d+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x23691b){this['authToken_']=_0x23691b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x23691b);}['reduceReconnectDelayIfAdminCredential_'](_0x4e0d2f){(_0x4e0d2f&&_0x4e0d2f['length']===0x28||wc(_0x4e0d2f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x18466b){this['appCheckToken_']=_0x18466b,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2b1311=this['authToken_'],_0x1fba7b=Ic(_0x2b1311)?'auth':'gauth',_0x362f49={'cred':_0x2b1311};this['authOverride_']===null?_0x362f49['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x362f49['authvar']=this['authOverride_']),this['sendRequest'](_0x1fba7b,_0x362f49,_0x302b2a=>{const _0x3e3a10=_0x302b2a['s'],_0x4efa14=_0x302b2a['d']||'error';this['authToken_']===_0x2b1311&&(_0x3e3a10==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3e3a10,_0x4efa14));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x22b348=>{const _0x2158c3=_0x22b348['s'],_0x560439=_0x22b348['d']||'error';_0x2158c3==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2158c3,_0x560439);});}['unlisten'](_0x546137,_0x39ed48){const _0x22a032=_0x546137['_path']['toString'](),_0x4336eb=_0x546137['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x22a032+'\x20'+_0x4336eb),f(_0x546137['_queryParams']['isDefault']()||!_0x546137['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x22a032,_0x4336eb)&&this['connected_']&&this['sendUnlisten_'](_0x22a032,_0x4336eb,_0x546137['_queryObject'],_0x39ed48);}['sendUnlisten_'](_0x584d2e,_0x1448b7,_0x1b19e7,_0x3bd6cf){this['log_']('Unlisten\x20on\x20'+_0x584d2e+'\x20for\x20'+_0x1448b7);const _0x16db31={'p':_0x584d2e},_0x5c6d72='n';_0x3bd6cf&&(_0x16db31['q']=_0x1b19e7,_0x16db31['t']=_0x3bd6cf),this['sendRequest'](_0x5c6d72,_0x16db31);}['onDisconnectPut'](_0x3ed7f6,_0x159582,_0x5b4a98){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3ed7f6,_0x159582,_0x5b4a98):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3ed7f6,'action':'o','data':_0x159582,'onComplete':_0x5b4a98});}['onDisconnectMerge'](_0xaf9e09,_0x53e74a,_0x415b45){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xaf9e09,_0x53e74a,_0x415b45):this['onDisconnectRequestQueue_']['push']({'pathString':_0xaf9e09,'action':'om','data':_0x53e74a,'onComplete':_0x415b45});}['onDisconnectCancel'](_0x4e26c4,_0x4f304f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4e26c4,null,_0x4f304f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4e26c4,'action':'oc','data':null,'onComplete':_0x4f304f});}['sendOnDisconnect_'](_0x295785,_0x296299,_0x54fab7,_0x4ea8d8){const _0x17ed83={'p':_0x296299,'d':_0x54fab7};this['log_']('onDisconnect\x20'+_0x295785,_0x17ed83),this['sendRequest'](_0x295785,_0x17ed83,_0x500d25=>{_0x4ea8d8&&setTimeout(()=>{_0x4ea8d8(_0x500d25['s'],_0x500d25['d']);},Math['floor'](0x0));});}['put'](_0x4c1ab6,_0x4540dd,_0x517a1f,_0x5406de){this['putInternal']('p',_0x4c1ab6,_0x4540dd,_0x517a1f,_0x5406de);}['merge'](_0x5268b2,_0x306272,_0x1a9ad3,_0x17d727){this['putInternal']('m',_0x5268b2,_0x306272,_0x1a9ad3,_0x17d727);}['putInternal'](_0x3e00d,_0x4d620c,_0x3cf752,_0x11d01d,_0xa9ece5){this['initConnection_']();const _0x2943a={'p':_0x4d620c,'d':_0x3cf752};_0xa9ece5!==void 0x0&&(_0x2943a['h']=_0xa9ece5),this['outstandingPuts_']['push']({'action':_0x3e00d,'request':_0x2943a,'onComplete':_0x11d01d}),this['outstandingPutCount_']++;const _0x3e48bb=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3e48bb):this['log_']('Buffering\x20put:\x20'+_0x4d620c);}['sendPut_'](_0x5a30da){const _0x1499d8=this['outstandingPuts_'][_0x5a30da]['action'],_0x16f92a=this['outstandingPuts_'][_0x5a30da]['request'],_0x158a11=this['outstandingPuts_'][_0x5a30da]['onComplete'];this['outstandingPuts_'][_0x5a30da]['queued']=this['connected_'],this['sendRequest'](_0x1499d8,_0x16f92a,_0x56a9df=>{this['log_'](_0x1499d8+'\x20response',_0x56a9df),delete this['outstandingPuts_'][_0x5a30da],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x158a11&&_0x158a11(_0x56a9df['s'],_0x56a9df['d']);});}['reportStats'](_0x7bb595){if(this['connected_']){const _0x251b35={'c':_0x7bb595};this['log_']('reportStats',_0x251b35),this['sendRequest']('s',_0x251b35,_0x518d49=>{if(_0x518d49['s']!=='ok'){const _0x5ceadb=_0x518d49['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5ceadb);}});}}['onDataMessage_'](_0x807e98){if('r'in _0x807e98){this['log_']('from\x20server:\x20'+O(_0x807e98));const _0x1f60d7=_0x807e98['r'],_0x391433=this['requestCBHash_'][_0x1f60d7];_0x391433&&(delete this['requestCBHash_'][_0x1f60d7],_0x391433(_0x807e98['b']));}else{if('error'in _0x807e98)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x807e98['error'];'a'in _0x807e98&&this['onDataPush_'](_0x807e98['a'],_0x807e98['b']);}}['onDataPush_'](_0xcbc36e,_0x2f3d97){this['log_']('handleServerMessage',_0xcbc36e,_0x2f3d97),_0xcbc36e==='d'?this['onDataUpdate_'](_0x2f3d97['p'],_0x2f3d97['d'],!0x1,_0x2f3d97['t']):_0xcbc36e==='m'?this['onDataUpdate_'](_0x2f3d97['p'],_0x2f3d97['d'],!0x0,_0x2f3d97['t']):_0xcbc36e==='c'?this['onListenRevoked_'](_0x2f3d97['p'],_0x2f3d97['q']):_0xcbc36e==='ac'?this['onAuthRevoked_'](_0x2f3d97['s'],_0x2f3d97['d']):_0xcbc36e==='apc'?this['onAppCheckRevoked_'](_0x2f3d97['s'],_0x2f3d97['d']):_0xcbc36e==='sd'?this['onSecurityDebugPacket_'](_0x2f3d97):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xcbc36e)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x30d2ec,_0x4a515d){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x30d2ec),this['lastSessionId']=_0x4a515d,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x318070){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x318070));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x156e1b){_0x156e1b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x156e1b;}['onOnline_'](_0x4c8760){_0x4c8760?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x40c71b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x29a8af=Math['max'](0x0,this['reconnectDelay_']-_0x40c71b);_0x29a8af=Math['random']()*_0x29a8af,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x29a8af+'ms'),this['scheduleConnect_'](_0x29a8af),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x415704=this['onDataMessage_']['bind'](this),_0x1a9b92=this['onReady_']['bind'](this),_0x46748a=this['onRealtimeDisconnect_']['bind'](this),_0x1c8410=this['id']+':'+se['nextConnectionId_']++,_0x525360=this['lastSessionId'];let _0x2bdd74=!0x1,_0x3fa90c=null;const _0x531f2d=function(){_0x3fa90c?_0x3fa90c['close']():(_0x2bdd74=!0x0,_0x46748a());},_0xd943ba=function(_0x5eb15b){f(_0x3fa90c,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3fa90c['sendRequest'](_0x5eb15b);};this['realtime_']={'close':_0x531f2d,'sendRequest':_0xd943ba};const _0x5bc253=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x19b64e,_0x456db8]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5bc253),this['appCheckTokenProvider_']['getToken'](_0x5bc253)]);_0x2bdd74?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x19b64e&&_0x19b64e['accessToken'],this['appCheckToken_']=_0x456db8&&_0x456db8['token'],_0x3fa90c=new Sh(_0x1c8410,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x415704,_0x1a9b92,_0x46748a,_0xe47378=>{U(_0xe47378+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x525360));}catch(_0x13c835){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x13c835),_0x2bdd74||(this['repoInfo_']['nodeAdmin']&&U(_0x13c835),_0x531f2d());}}}['interrupt'](_0x53a764){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x53a764),this['interruptReasons_'][_0x53a764]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x27ec5d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x27ec5d),delete this['interruptReasons_'][_0x27ec5d],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x391ab6){const _0x15f835=_0x391ab6-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x15f835});}['cancelSentTransactions_'](){for(let _0x1e629a=0x0;_0x1e629a<this['outstandingPuts_']['length'];_0x1e629a++){const _0x50fc8f=this['outstandingPuts_'][_0x1e629a];_0x50fc8f&&'h'in _0x50fc8f['request']&&_0x50fc8f['queued']&&(_0x50fc8f['onComplete']&&_0x50fc8f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1e629a],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2fcf64,_0x15cb45){let _0x2802d9;_0x15cb45?_0x2802d9=_0x15cb45['map'](_0x687b3d=>$i(_0x687b3d))['join']('$'):_0x2802d9='default';const _0x5a2d07=this['removeListen_'](_0x2fcf64,_0x2802d9);_0x5a2d07&&_0x5a2d07['onComplete']&&_0x5a2d07['onComplete']('permission_denied');}['removeListen_'](_0x5b6d77,_0x4210e5){const _0x503962=new C(_0x5b6d77)['toString']();let _0x4529f4;if(this['listens']['has'](_0x503962)){const _0x2e2057=this['listens']['get'](_0x503962);_0x4529f4=_0x2e2057['get'](_0x4210e5),_0x2e2057['delete'](_0x4210e5),_0x2e2057['size']===0x0&&this['listens']['delete'](_0x503962);}else _0x4529f4=void 0x0;return _0x4529f4;}['onAuthRevoked_'](_0x47d9c8,_0x23a028){L('Auth\x20token\x20revoked:\x20'+_0x47d9c8+'/'+_0x23a028),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x47d9c8==='invalid_token'||_0x47d9c8==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4b2fae,_0x4ae457){L('App\x20check\x20token\x20revoked:\x20'+_0x4b2fae+'/'+_0x4ae457),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4b2fae==='invalid_token'||_0x4b2fae==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4c3094){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4c3094):'msg'in _0x4c3094&&console['log']('FIREBASE:\x20'+_0x4c3094['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x7ef387 of this['listens']['values']())for(const _0x525fa7 of _0x7ef387['values']())this['sendListen_'](_0x525fa7);for(let _0x3ce709=0x0;_0x3ce709<this['outstandingPuts_']['length'];_0x3ce709++)this['outstandingPuts_'][_0x3ce709]&&this['sendPut_'](_0x3ce709);for(;this['onDisconnectRequestQueue_']['length'];){const _0x171176=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x171176['action'],_0x171176['pathString'],_0x171176['data'],_0x171176['onComplete']);}for(let _0x454db8=0x0;_0x454db8<this['outstandingGets_']['length'];_0x454db8++)this['outstandingGets_'][_0x454db8]&&this['sendGet_'](_0x454db8);}['sendConnectStats_'](){const _0x49478b={};let _0x103f33='js';_0x49478b['sdk.'+_0x103f33+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x49478b['framework.cordova']=0x1:Kr()&&(_0x49478b['framework.reactnative']=0x1),this['reportStats'](_0x49478b);}['shouldReconnect_'](){const _0x2dcfe3=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x2dcfe3;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4124a6,_0x4c5dc3){this['name']=_0x4124a6,this['node']=_0x4c5dc3;}static['Wrap'](_0x5df96b,_0x29d500){return new E(_0x5df96b,_0x29d500);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x25a8c3,_0x71d624){const _0x791668=new E(We,_0x25a8c3),_0x59f2a7=new E(We,_0x71d624);return this['compare'](_0x791668,_0x59f2a7)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x236a71){sn=_0x236a71;}['compare'](_0x91ef2e,_0x11b6cc){return qe(_0x91ef2e['name'],_0x11b6cc['name']);}['isDefinedOn'](_0x5452e4){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x468126,_0x22f7d5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x2812c2,_0x2f4c2b){return f(typeof _0x2812c2=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2812c2,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x408c68,_0x15a5b2,_0xe0fe49,_0x3ce2ac,_0x5df6b4=null){this['isReverse_']=_0x3ce2ac,this['resultGenerator_']=_0x5df6b4,this['nodeStack_']=[];let _0x23ca7b=0x1;for(;!_0x408c68['isEmpty']();)if(_0x408c68=_0x408c68,_0x23ca7b=_0x15a5b2?_0xe0fe49(_0x408c68['key'],_0x15a5b2):0x1,_0x3ce2ac&&(_0x23ca7b*=-0x1),_0x23ca7b<0x0)this['isReverse_']?_0x408c68=_0x408c68['left']:_0x408c68=_0x408c68['right'];else{if(_0x23ca7b===0x0){this['nodeStack_']['push'](_0x408c68);break;}else this['nodeStack_']['push'](_0x408c68),this['isReverse_']?_0x408c68=_0x408c68['right']:_0x408c68=_0x408c68['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x678234=this['nodeStack_']['pop'](),_0x3d6067;if(this['resultGenerator_']?_0x3d6067=this['resultGenerator_'](_0x678234['key'],_0x678234['value']):_0x3d6067={'key':_0x678234['key'],'value':_0x678234['value']},this['isReverse_']){for(_0x678234=_0x678234['left'];!_0x678234['isEmpty']();)this['nodeStack_']['push'](_0x678234),_0x678234=_0x678234['right'];}else{for(_0x678234=_0x678234['right'];!_0x678234['isEmpty']();)this['nodeStack_']['push'](_0x678234),_0x678234=_0x678234['left'];}return _0x3d6067;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1ba38b=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1ba38b['key'],_0x1ba38b['value']):{'key':_0x1ba38b['key'],'value':_0x1ba38b['value']};}}class M{constructor(_0x21f029,_0x48ed6b,_0x13afbf,_0x12c031,_0x113179){this['key']=_0x21f029,this['value']=_0x48ed6b,this['color']=_0x13afbf??M['RED'],this['left']=_0x12c031??B['EMPTY_NODE'],this['right']=_0x113179??B['EMPTY_NODE'];}['copy'](_0x2f3318,_0x267987,_0xdfd3e5,_0x1a6bee,_0x49adbc){return new M(_0x2f3318??this['key'],_0x267987??this['value'],_0xdfd3e5??this['color'],_0x1a6bee??this['left'],_0x49adbc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1ecd6e){return this['left']['inorderTraversal'](_0x1ecd6e)||!!_0x1ecd6e(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1ecd6e);}['reverseTraversal'](_0x47a58a){return this['right']['reverseTraversal'](_0x47a58a)||_0x47a58a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x47a58a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x22ea2d,_0x7d4f44,_0x33fd25){let _0x2667c8=this;const _0x46183c=_0x33fd25(_0x22ea2d,_0x2667c8['key']);return _0x46183c<0x0?_0x2667c8=_0x2667c8['copy'](null,null,null,_0x2667c8['left']['insert'](_0x22ea2d,_0x7d4f44,_0x33fd25),null):_0x46183c===0x0?_0x2667c8=_0x2667c8['copy'](null,_0x7d4f44,null,null,null):_0x2667c8=_0x2667c8['copy'](null,null,null,null,_0x2667c8['right']['insert'](_0x22ea2d,_0x7d4f44,_0x33fd25)),_0x2667c8['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x51123c=this;return!_0x51123c['left']['isRed_']()&&!_0x51123c['left']['left']['isRed_']()&&(_0x51123c=_0x51123c['moveRedLeft_']()),_0x51123c=_0x51123c['copy'](null,null,null,_0x51123c['left']['removeMin_'](),null),_0x51123c['fixUp_']();}['remove'](_0x3eb839,_0x13c95e){let _0x4b00f3,_0x19eeb8;if(_0x4b00f3=this,_0x13c95e(_0x3eb839,_0x4b00f3['key'])<0x0)!_0x4b00f3['left']['isEmpty']()&&!_0x4b00f3['left']['isRed_']()&&!_0x4b00f3['left']['left']['isRed_']()&&(_0x4b00f3=_0x4b00f3['moveRedLeft_']()),_0x4b00f3=_0x4b00f3['copy'](null,null,null,_0x4b00f3['left']['remove'](_0x3eb839,_0x13c95e),null);else{if(_0x4b00f3['left']['isRed_']()&&(_0x4b00f3=_0x4b00f3['rotateRight_']()),!_0x4b00f3['right']['isEmpty']()&&!_0x4b00f3['right']['isRed_']()&&!_0x4b00f3['right']['left']['isRed_']()&&(_0x4b00f3=_0x4b00f3['moveRedRight_']()),_0x13c95e(_0x3eb839,_0x4b00f3['key'])===0x0){if(_0x4b00f3['right']['isEmpty']())return B['EMPTY_NODE'];_0x19eeb8=_0x4b00f3['right']['min_'](),_0x4b00f3=_0x4b00f3['copy'](_0x19eeb8['key'],_0x19eeb8['value'],null,null,_0x4b00f3['right']['removeMin_']());}_0x4b00f3=_0x4b00f3['copy'](null,null,null,null,_0x4b00f3['right']['remove'](_0x3eb839,_0x13c95e));}return _0x4b00f3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x58e66b=this;return _0x58e66b['right']['isRed_']()&&!_0x58e66b['left']['isRed_']()&&(_0x58e66b=_0x58e66b['rotateLeft_']()),_0x58e66b['left']['isRed_']()&&_0x58e66b['left']['left']['isRed_']()&&(_0x58e66b=_0x58e66b['rotateRight_']()),_0x58e66b['left']['isRed_']()&&_0x58e66b['right']['isRed_']()&&(_0x58e66b=_0x58e66b['colorFlip_']()),_0x58e66b;}['moveRedLeft_'](){let _0x3fc30f=this['colorFlip_']();return _0x3fc30f['right']['left']['isRed_']()&&(_0x3fc30f=_0x3fc30f['copy'](null,null,null,null,_0x3fc30f['right']['rotateRight_']()),_0x3fc30f=_0x3fc30f['rotateLeft_'](),_0x3fc30f=_0x3fc30f['colorFlip_']()),_0x3fc30f;}['moveRedRight_'](){let _0x80d0ab=this['colorFlip_']();return _0x80d0ab['left']['left']['isRed_']()&&(_0x80d0ab=_0x80d0ab['rotateRight_'](),_0x80d0ab=_0x80d0ab['colorFlip_']()),_0x80d0ab;}['rotateLeft_'](){const _0xf41714=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xf41714,null);}['rotateRight_'](){const _0xd80403=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xd80403);}['colorFlip_'](){const _0x5ac867=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x236b5b=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5ac867,_0x236b5b);}['checkMaxDepth_'](){const _0x3bd75e=this['check_']();return Math['pow'](0x2,_0x3bd75e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x12b77a=this['left']['check_']();if(_0x12b77a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x12b77a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5c08f9,_0x3e85e1,_0x48a1ee,_0x5bc148,_0x5eba22){return this;}['insert'](_0x5a3704,_0x413d21,_0x4a6bf0){return new M(_0x5a3704,_0x413d21,null);}['remove'](_0x36b6b6,_0xd505d6){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xf631a1){return!0x1;}['reverseTraversal'](_0x21b0b7){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x525456,_0xde845c=B['EMPTY_NODE']){this['comparator_']=_0x525456,this['root_']=_0xde845c;}['insert'](_0x2c2227,_0x502255){return new B(this['comparator_'],this['root_']['insert'](_0x2c2227,_0x502255,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3d779d){return new B(this['comparator_'],this['root_']['remove'](_0x3d779d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x572fb4){let _0x3f682b,_0x4adbda=this['root_'];for(;!_0x4adbda['isEmpty']();){if(_0x3f682b=this['comparator_'](_0x572fb4,_0x4adbda['key']),_0x3f682b===0x0)return _0x4adbda['value'];_0x3f682b<0x0?_0x4adbda=_0x4adbda['left']:_0x3f682b>0x0&&(_0x4adbda=_0x4adbda['right']);}return null;}['getPredecessorKey'](_0x245a0f){let _0x34b95f,_0x273ca6=this['root_'],_0x23eaee=null;for(;!_0x273ca6['isEmpty']();)if(_0x34b95f=this['comparator_'](_0x245a0f,_0x273ca6['key']),_0x34b95f===0x0){if(_0x273ca6['left']['isEmpty']())return _0x23eaee?_0x23eaee['key']:null;for(_0x273ca6=_0x273ca6['left'];!_0x273ca6['right']['isEmpty']();)_0x273ca6=_0x273ca6['right'];return _0x273ca6['key'];}else _0x34b95f<0x0?_0x273ca6=_0x273ca6['left']:_0x34b95f>0x0&&(_0x23eaee=_0x273ca6,_0x273ca6=_0x273ca6['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x8c13c1){return this['root_']['inorderTraversal'](_0x8c13c1);}['reverseTraversal'](_0x53a637){return this['root_']['reverseTraversal'](_0x53a637);}['getIterator'](_0x4ba197){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x4ba197);}['getIteratorFrom'](_0x46aecb,_0x44ab9d){return new rn(this['root_'],_0x46aecb,this['comparator_'],!0x1,_0x44ab9d);}['getReverseIteratorFrom'](_0x532b9e,_0x23f248){return new rn(this['root_'],_0x532b9e,this['comparator_'],!0x0,_0x23f248);}['getReverseIterator'](_0x126c91){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x126c91);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5f02a5,_0xa51b73){return qe(_0x5f02a5['name'],_0xa51b73['name']);}function Qi(_0x4018be,_0x1e68b9){return qe(_0x4018be,_0x1e68b9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2f342f){Ci=_0x2f342f;}const Po=function(_0x5a504b){return typeof _0x5a504b=='number'?'number:'+ao(_0x5a504b):'string:'+_0x5a504b;},No=function(_0x4d3c89){if(_0x4d3c89['isLeafNode']()){const _0x175f44=_0x4d3c89['val']();f(typeof _0x175f44=='string'||typeof _0x175f44=='number'||typeof _0x175f44=='object'&&Q(_0x175f44,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4d3c89===Ci||_0x4d3c89['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4d3c89===Ci||_0x4d3c89['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x57195e){nr=_0x57195e;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x59d7f2,_0x2eeb28=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x59d7f2,this['priorityNode_']=_0x2eeb28,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3fa166){return new D(this['value_'],_0x3fa166);}['getImmediateChild'](_0x11bb54){return _0x11bb54==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4ae1f3){return v(_0x4ae1f3)?this:y(_0x4ae1f3)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2fb4b1,_0x370d2c){return null;}['updateImmediateChild'](_0x4e2bb9,_0x582a36){return _0x4e2bb9==='.priority'?this['updatePriority'](_0x582a36):_0x582a36['isEmpty']()&&_0x4e2bb9!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4e2bb9,_0x582a36)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3b01f8,_0x3dd866){const _0x305167=y(_0x3b01f8);return _0x305167===null?_0x3dd866:_0x3dd866['isEmpty']()&&_0x305167!=='.priority'?this:(f(_0x305167!=='.priority'||Ce(_0x3b01f8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x305167,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3b01f8),_0x3dd866)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5a9c4d,_0x29b4cb){return!0x1;}['val'](_0x9257c1){return _0x9257c1&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2ad718='';this['priorityNode_']['isEmpty']()||(_0x2ad718+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x42853d=typeof this['value_'];_0x2ad718+=_0x42853d+':',_0x42853d==='number'?_0x2ad718+=ao(this['value_']):_0x2ad718+=this['value_'],this['lazyHash_']=ro(_0x2ad718);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x348cd9){return _0x348cd9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x348cd9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x348cd9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x348cd9));}['compareToLeafNode_'](_0x41fb2d){const _0x18f4ab=typeof _0x41fb2d['value_'],_0x32c726=typeof this['value_'],_0x33831a=D['VALUE_TYPE_ORDER']['indexOf'](_0x18f4ab),_0x4ba270=D['VALUE_TYPE_ORDER']['indexOf'](_0x32c726);return f(_0x33831a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x18f4ab),f(_0x4ba270>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x32c726),_0x33831a===_0x4ba270?_0x32c726==='object'?0x0:this['value_']<_0x41fb2d['value_']?-0x1:this['value_']===_0x41fb2d['value_']?0x0:0x1:_0x4ba270-_0x33831a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2f6987){if(_0x2f6987===this)return!0x0;if(_0x2f6987['isLeafNode']()){const _0x280ee3=_0x2f6987;return this['value_']===_0x280ee3['value_']&&this['priorityNode_']['equals'](_0x280ee3['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x4ba1ef){Oo=_0x4ba1ef;}function Wh(_0x599238){Do=_0x599238;}class Bh extends Fn{['compare'](_0x25b57a,_0xc8f7a2){const _0x3241d9=_0x25b57a['node']['getPriority'](),_0x30de3e=_0xc8f7a2['node']['getPriority'](),_0x288f14=_0x3241d9['compareTo'](_0x30de3e);return _0x288f14===0x0?qe(_0x25b57a['name'],_0xc8f7a2['name']):_0x288f14;}['isDefinedOn'](_0x34b4b4){return!_0x34b4b4['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3a3154,_0x1a3ef3){return!_0x3a3154['getPriority']()['equals'](_0x1a3ef3['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5984ce,_0x37cb4c){const _0x23fa3d=Oo(_0x5984ce);return new E(_0x37cb4c,new D('[PRIORITY-POST]',_0x23fa3d));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x34e8dd){const _0x192271=_0x20b00c=>parseInt(Math['log'](_0x20b00c)/Vh,0xa),_0x1a3a05=_0x1124ac=>parseInt(Array(_0x1124ac+0x1)['join']('1'),0x2);this['count']=_0x192271(_0x34e8dd+0x1),this['current_']=this['count']-0x1;const _0xb12e4c=_0x1a3a05(this['count']);this['bits_']=_0x34e8dd+0x1&_0xb12e4c;}['nextBitIsOne'](){const _0x993341=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x993341;}}const yn=function(_0x34f3db,_0x53aaa4,_0x45ec4c,_0x16473d){_0x34f3db['sort'](_0x53aaa4);const _0x22890e=function(_0x375b7f,_0x5d022f){const _0x197272=_0x5d022f-_0x375b7f;let _0x35032b,_0x2dfb51;if(_0x197272===0x0)return null;if(_0x197272===0x1)return _0x35032b=_0x34f3db[_0x375b7f],_0x2dfb51=_0x45ec4c?_0x45ec4c(_0x35032b):_0x35032b,new M(_0x2dfb51,_0x35032b['node'],M['BLACK'],null,null);{const _0x501f09=parseInt(_0x197272/0x2,0xa)+_0x375b7f,_0x61c90f=_0x22890e(_0x375b7f,_0x501f09),_0x210cc1=_0x22890e(_0x501f09+0x1,_0x5d022f);return _0x35032b=_0x34f3db[_0x501f09],_0x2dfb51=_0x45ec4c?_0x45ec4c(_0x35032b):_0x35032b,new M(_0x2dfb51,_0x35032b['node'],M['BLACK'],_0x61c90f,_0x210cc1);}},_0x522b81=function(_0x554bcc){let _0x5b4f2f=null,_0x308121=null,_0x1771ef=_0x34f3db['length'];const _0x52eef0=function(_0x4561e6,_0x25eef3){const _0x32bf9f=_0x1771ef-_0x4561e6,_0x519c4c=_0x1771ef;_0x1771ef-=_0x4561e6;const _0x5f201c=_0x22890e(_0x32bf9f+0x1,_0x519c4c),_0x12d18d=_0x34f3db[_0x32bf9f],_0x59d3d5=_0x45ec4c?_0x45ec4c(_0x12d18d):_0x12d18d;_0x17eb56(new M(_0x59d3d5,_0x12d18d['node'],_0x25eef3,null,_0x5f201c));},_0x17eb56=function(_0x2fca79){_0x5b4f2f?(_0x5b4f2f['left']=_0x2fca79,_0x5b4f2f=_0x2fca79):(_0x308121=_0x2fca79,_0x5b4f2f=_0x2fca79);};for(let _0x1836b5=0x0;_0x1836b5<_0x554bcc['count'];++_0x1836b5){const _0x469b39=_0x554bcc['nextBitIsOne'](),_0xdca20b=Math['pow'](0x2,_0x554bcc['count']-(_0x1836b5+0x1));_0x469b39?_0x52eef0(_0xdca20b,M['BLACK']):(_0x52eef0(_0xdca20b,M['BLACK']),_0x52eef0(_0xdca20b,M['RED']));}return _0x308121;},_0x281018=new Hh(_0x34f3db['length']),_0xc7b3=_0x522b81(_0x281018);return new B(_0x16473d||_0x53aaa4,_0xc7b3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x904e07,_0x5d3dd5){this['indexes_']=_0x904e07,this['indexSet_']=_0x5d3dd5;}['get'](_0x5a359b){const _0x279575=Le(this['indexes_'],_0x5a359b);if(!_0x279575)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5a359b);return _0x279575 instanceof B?_0x279575:null;}['hasIndex'](_0x491441){return Q(this['indexSet_'],_0x491441['toString']());}['addIndex'](_0x42e889,_0xc0975){f(_0x42e889!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x36d818=[];let _0x460594=!0x1;const _0x9c7d74=_0xc0975['getIterator'](E['Wrap']);let _0x4c5d3f=_0x9c7d74['getNext']();for(;_0x4c5d3f;)_0x460594=_0x460594||_0x42e889['isDefinedOn'](_0x4c5d3f['node']),_0x36d818['push'](_0x4c5d3f),_0x4c5d3f=_0x9c7d74['getNext']();let _0x3034c5;_0x460594?_0x3034c5=yn(_0x36d818,_0x42e889['getCompare']()):_0x3034c5=Qe;const _0x4f5487=_0x42e889['toString'](),_0x3566f5={...this['indexSet_']};_0x3566f5[_0x4f5487]=_0x42e889;const _0xe09f68={...this['indexes_']};return _0xe09f68[_0x4f5487]=_0x3034c5,new te(_0xe09f68,_0x3566f5);}['addToIndexes'](_0xd53c20,_0x5f588e){const _0x2fe873=_n(this['indexes_'],(_0x2f83fa,_0x52a8e9)=>{const _0x17cbd0=Le(this['indexSet_'],_0x52a8e9);if(f(_0x17cbd0,'Missing\x20index\x20implementation\x20for\x20'+_0x52a8e9),_0x2f83fa===Qe){if(_0x17cbd0['isDefinedOn'](_0xd53c20['node'])){const _0xb8ca1d=[],_0x507f0e=_0x5f588e['getIterator'](E['Wrap']);let _0x1d05c4=_0x507f0e['getNext']();for(;_0x1d05c4;)_0x1d05c4['name']!==_0xd53c20['name']&&_0xb8ca1d['push'](_0x1d05c4),_0x1d05c4=_0x507f0e['getNext']();return _0xb8ca1d['push'](_0xd53c20),yn(_0xb8ca1d,_0x17cbd0['getCompare']());}else return Qe;}else{const _0x2de789=_0x5f588e['get'](_0xd53c20['name']);let _0x1c4746=_0x2f83fa;return _0x2de789&&(_0x1c4746=_0x1c4746['remove'](new E(_0xd53c20['name'],_0x2de789))),_0x1c4746['insert'](_0xd53c20,_0xd53c20['node']);}});return new te(_0x2fe873,this['indexSet_']);}['removeFromIndexes'](_0x49401e,_0x2a8ec6){const _0x1cf4c3=_n(this['indexes_'],_0x18cd4e=>{if(_0x18cd4e===Qe)return _0x18cd4e;{const _0x12d10e=_0x2a8ec6['get'](_0x49401e['name']);return _0x12d10e?_0x18cd4e['remove'](new E(_0x49401e['name'],_0x12d10e)):_0x18cd4e;}});return new te(_0x1cf4c3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x16626b,_0x4211c2,_0x224545){this['children_']=_0x16626b,this['priorityNode_']=_0x4211c2,this['indexMap_']=_0x224545,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x209bb7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x209bb7,this['indexMap_']);}['getImmediateChild'](_0x3d5d88){if(_0x3d5d88==='.priority')return this['getPriority']();{const _0x4a05dc=this['children_']['get'](_0x3d5d88);return _0x4a05dc===null?It:_0x4a05dc;}}['getChild'](_0x15ad52){const _0x5be8b4=y(_0x15ad52);return _0x5be8b4===null?this:this['getImmediateChild'](_0x5be8b4)['getChild'](S(_0x15ad52));}['hasChild'](_0xc5044d){return this['children_']['get'](_0xc5044d)!==null;}['updateImmediateChild'](_0x27ef97,_0x5df189){if(f(_0x5df189,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x27ef97==='.priority')return this['updatePriority'](_0x5df189);{const _0x3efdae=new E(_0x27ef97,_0x5df189);let _0x2813e0,_0x3762bc;_0x5df189['isEmpty']()?(_0x2813e0=this['children_']['remove'](_0x27ef97),_0x3762bc=this['indexMap_']['removeFromIndexes'](_0x3efdae,this['children_'])):(_0x2813e0=this['children_']['insert'](_0x27ef97,_0x5df189),_0x3762bc=this['indexMap_']['addToIndexes'](_0x3efdae,this['children_']));const _0x1b3c2c=_0x2813e0['isEmpty']()?It:this['priorityNode_'];return new g(_0x2813e0,_0x1b3c2c,_0x3762bc);}}['updateChild'](_0x53409d,_0x3ded10){const _0x342a4c=y(_0x53409d);if(_0x342a4c===null)return _0x3ded10;{f(y(_0x53409d)!=='.priority'||Ce(_0x53409d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2e8765=this['getImmediateChild'](_0x342a4c)['updateChild'](S(_0x53409d),_0x3ded10);return this['updateImmediateChild'](_0x342a4c,_0x2e8765);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xbde4d9){if(this['isEmpty']())return null;const _0x3176b3={};let _0x4dbf87=0x0,_0x76dcbc=0x0,_0xf1c824=!0x0;if(this['forEachChild'](R,(_0x505b8f,_0x2e9d7e)=>{_0x3176b3[_0x505b8f]=_0x2e9d7e['val'](_0xbde4d9),_0x4dbf87++,_0xf1c824&&g['INTEGER_REGEXP_']['test'](_0x505b8f)?_0x76dcbc=Math['max'](_0x76dcbc,Number(_0x505b8f)):_0xf1c824=!0x1;}),!_0xbde4d9&&_0xf1c824&&_0x76dcbc<0x2*_0x4dbf87){const _0x5f650d=[];for(const _0x5d4613 in _0x3176b3)_0x5f650d[_0x5d4613]=_0x3176b3[_0x5d4613];return _0x5f650d;}else return _0xbde4d9&&!this['getPriority']()['isEmpty']()&&(_0x3176b3['.priority']=this['getPriority']()['val']()),_0x3176b3;}['hash'](){if(this['lazyHash_']===null){let _0x2bf644='';this['getPriority']()['isEmpty']()||(_0x2bf644+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2c22a7,_0x1e1d60)=>{const _0x7bbea6=_0x1e1d60['hash']();_0x7bbea6!==''&&(_0x2bf644+=':'+_0x2c22a7+':'+_0x7bbea6);}),this['lazyHash_']=_0x2bf644===''?'':ro(_0x2bf644);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4c6bc2,_0xbd683,_0x23b475){const _0x395169=this['resolveIndex_'](_0x23b475);if(_0x395169){const _0x143862=_0x395169['getPredecessorKey'](new E(_0x4c6bc2,_0xbd683));return _0x143862?_0x143862['name']:null;}else return this['children_']['getPredecessorKey'](_0x4c6bc2);}['getFirstChildName'](_0x28ee86){const _0x5a1b04=this['resolveIndex_'](_0x28ee86);if(_0x5a1b04){const _0x23d24d=_0x5a1b04['minKey']();return _0x23d24d&&_0x23d24d['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4a9bbf){const _0x145f10=this['getFirstChildName'](_0x4a9bbf);return _0x145f10?new E(_0x145f10,this['children_']['get'](_0x145f10)):null;}['getLastChildName'](_0x3e1955){const _0x48778d=this['resolveIndex_'](_0x3e1955);if(_0x48778d){const _0x22493b=_0x48778d['maxKey']();return _0x22493b&&_0x22493b['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3dadb1){const _0x401e3b=this['getLastChildName'](_0x3dadb1);return _0x401e3b?new E(_0x401e3b,this['children_']['get'](_0x401e3b)):null;}['forEachChild'](_0x43fc3f,_0x27072c){const _0x437bad=this['resolveIndex_'](_0x43fc3f);return _0x437bad?_0x437bad['inorderTraversal'](_0x4f70ba=>_0x27072c(_0x4f70ba['name'],_0x4f70ba['node'])):this['children_']['inorderTraversal'](_0x27072c);}['getIterator'](_0x2d57c7){return this['getIteratorFrom'](_0x2d57c7['minPost'](),_0x2d57c7);}['getIteratorFrom'](_0x31ad25,_0x1b1305){const _0x55de08=this['resolveIndex_'](_0x1b1305);if(_0x55de08)return _0x55de08['getIteratorFrom'](_0x31ad25,_0x544591=>_0x544591);{const _0x4989e3=this['children_']['getIteratorFrom'](_0x31ad25['name'],E['Wrap']);let _0x2618e5=_0x4989e3['peek']();for(;_0x2618e5!=null&&_0x1b1305['compare'](_0x2618e5,_0x31ad25)<0x0;)_0x4989e3['getNext'](),_0x2618e5=_0x4989e3['peek']();return _0x4989e3;}}['getReverseIterator'](_0x236e0a){return this['getReverseIteratorFrom'](_0x236e0a['maxPost'](),_0x236e0a);}['getReverseIteratorFrom'](_0x382d29,_0x53b849){const _0x576498=this['resolveIndex_'](_0x53b849);if(_0x576498)return _0x576498['getReverseIteratorFrom'](_0x382d29,_0x4fa50d=>_0x4fa50d);{const _0x4fd67a=this['children_']['getReverseIteratorFrom'](_0x382d29['name'],E['Wrap']);let _0x595b28=_0x4fd67a['peek']();for(;_0x595b28!=null&&_0x53b849['compare'](_0x595b28,_0x382d29)>0x0;)_0x4fd67a['getNext'](),_0x595b28=_0x4fd67a['peek']();return _0x4fd67a;}}['compareTo'](_0x3fe969){return this['isEmpty']()?_0x3fe969['isEmpty']()?0x0:-0x1:_0x3fe969['isLeafNode']()||_0x3fe969['isEmpty']()?0x1:_0x3fe969===Kt?-0x1:0x0;}['withIndex'](_0x48f547){if(_0x48f547===ve||this['indexMap_']['hasIndex'](_0x48f547))return this;{const _0x52a02d=this['indexMap_']['addIndex'](_0x48f547,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x52a02d);}}['isIndexed'](_0x5e7162){return _0x5e7162===ve||this['indexMap_']['hasIndex'](_0x5e7162);}['equals'](_0xba8a57){if(_0xba8a57===this)return!0x0;if(_0xba8a57['isLeafNode']())return!0x1;{const _0x37485c=_0xba8a57;if(this['getPriority']()['equals'](_0x37485c['getPriority']())){if(this['children_']['count']()===_0x37485c['children_']['count']()){const _0x42753b=this['getIterator'](R),_0x51c922=_0x37485c['getIterator'](R);let _0x3f2acf=_0x42753b['getNext'](),_0x33b2ff=_0x51c922['getNext']();for(;_0x3f2acf&&_0x33b2ff;){if(_0x3f2acf['name']!==_0x33b2ff['name']||!_0x3f2acf['node']['equals'](_0x33b2ff['node']))return!0x1;_0x3f2acf=_0x42753b['getNext'](),_0x33b2ff=_0x51c922['getNext']();}return _0x3f2acf===null&&_0x33b2ff===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x495698){return _0x495698===ve?null:this['indexMap_']['get'](_0x495698['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3848e7){return _0x3848e7===this?0x0:0x1;}['equals'](_0x14692f){return _0x14692f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x743466){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x537a9b,_0x3f69bf=null){if(_0x537a9b===null)return g['EMPTY_NODE'];if(typeof _0x537a9b=='object'&&'.priority'in _0x537a9b&&(_0x3f69bf=_0x537a9b['.priority']),f(_0x3f69bf===null||typeof _0x3f69bf=='string'||typeof _0x3f69bf=='number'||typeof _0x3f69bf=='object'&&'.sv'in _0x3f69bf,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3f69bf),typeof _0x537a9b=='object'&&'.value'in _0x537a9b&&_0x537a9b['.value']!==null&&(_0x537a9b=_0x537a9b['.value']),typeof _0x537a9b!='object'||'.sv'in _0x537a9b){const _0x16a588=_0x537a9b;return new D(_0x16a588,A(_0x3f69bf));}if(!(_0x537a9b instanceof Array)&&Gh){const _0x52fcd0=[];let _0x1fe9c4=!0x1;if(x(_0x537a9b,(_0x36245c,_0x8ad55b)=>{if(_0x36245c['substring'](0x0,0x1)!=='.'){const _0xf7e3c0=A(_0x8ad55b);_0xf7e3c0['isEmpty']()||(_0x1fe9c4=_0x1fe9c4||!_0xf7e3c0['getPriority']()['isEmpty'](),_0x52fcd0['push'](new E(_0x36245c,_0xf7e3c0)));}}),_0x52fcd0['length']===0x0)return g['EMPTY_NODE'];const _0x53038c=yn(_0x52fcd0,xh,_0x1f9ceb=>_0x1f9ceb['name'],Qi);if(_0x1fe9c4){const _0x294d57=yn(_0x52fcd0,R['getCompare']());return new g(_0x53038c,A(_0x3f69bf),new te({'.priority':_0x294d57},{'.priority':R}));}else return new g(_0x53038c,A(_0x3f69bf),te['Default']);}else{let _0xa3fb6e=g['EMPTY_NODE'];return x(_0x537a9b,(_0x1ddb20,_0x766a0e)=>{if(Q(_0x537a9b,_0x1ddb20)&&_0x1ddb20['substring'](0x0,0x1)!=='.'){const _0x874dc6=A(_0x766a0e);(_0x874dc6['isLeafNode']()||!_0x874dc6['isEmpty']())&&(_0xa3fb6e=_0xa3fb6e['updateImmediateChild'](_0x1ddb20,_0x874dc6));}}),_0xa3fb6e['updatePriority'](A(_0x3f69bf));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x37bfab){super(),this['indexPath_']=_0x37bfab,f(!v(_0x37bfab)&&y(_0x37bfab)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x470311){return _0x470311['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1ed2dc){return!_0x1ed2dc['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1c721e,_0x36a626){const _0x384149=this['extractChild'](_0x1c721e['node']),_0x14c876=this['extractChild'](_0x36a626['node']),_0x5a6639=_0x384149['compareTo'](_0x14c876);return _0x5a6639===0x0?qe(_0x1c721e['name'],_0x36a626['name']):_0x5a6639;}['makePost'](_0x4b2ea3,_0x3944ab){const _0x78ff03=A(_0x4b2ea3),_0x274cd4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x78ff03);return new E(_0x3944ab,_0x274cd4);}['maxPost'](){const _0x4ffc4c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4ffc4c);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x4b99c0,_0x178f8a){const _0x3f54f1=_0x4b99c0['node']['compareTo'](_0x178f8a['node']);return _0x3f54f1===0x0?qe(_0x4b99c0['name'],_0x178f8a['name']):_0x3f54f1;}['isDefinedOn'](_0x6a9406){return!0x0;}['indexedValueChanged'](_0x2eba49,_0x53db60){return!_0x2eba49['equals'](_0x53db60);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x124a9e,_0x31cd56){const _0x585236=A(_0x124a9e);return new E(_0x31cd56,_0x585236);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x2c4d59){return{'type':'value','snapshotNode':_0x2c4d59};}function rt(_0x79da1c,_0x25b294){return{'type':'child_added','snapshotNode':_0x25b294,'childName':_0x79da1c};}function Lt(_0x2c569a,_0x9bdb68){return{'type':'child_removed','snapshotNode':_0x9bdb68,'childName':_0x2c569a};}function xt(_0x196049,_0x235afa,_0x4f53f7){return{'type':'child_changed','snapshotNode':_0x235afa,'childName':_0x196049,'oldSnap':_0x4f53f7};}function zh(_0x66c52b,_0x9b1d6a){return{'type':'child_moved','snapshotNode':_0x9b1d6a,'childName':_0x66c52b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x6ec638){this['index_']=_0x6ec638;}['updateChild'](_0x48298,_0x2b03c3,_0x2ed289,_0x4d5ed7,_0x13d03d,_0x2b8638){f(_0x48298['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5db497=_0x48298['getImmediateChild'](_0x2b03c3);return _0x5db497['getChild'](_0x4d5ed7)['equals'](_0x2ed289['getChild'](_0x4d5ed7))&&_0x5db497['isEmpty']()===_0x2ed289['isEmpty']()||(_0x2b8638!=null&&(_0x2ed289['isEmpty']()?_0x48298['hasChild'](_0x2b03c3)?_0x2b8638['trackChildChange'](Lt(_0x2b03c3,_0x5db497)):f(_0x48298['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5db497['isEmpty']()?_0x2b8638['trackChildChange'](rt(_0x2b03c3,_0x2ed289)):_0x2b8638['trackChildChange'](xt(_0x2b03c3,_0x2ed289,_0x5db497))),_0x48298['isLeafNode']()&&_0x2ed289['isEmpty']())?_0x48298:_0x48298['updateImmediateChild'](_0x2b03c3,_0x2ed289)['withIndex'](this['index_']);}['updateFullNode'](_0x14e3ca,_0xf0aaf6,_0x533415){return _0x533415!=null&&(_0x14e3ca['isLeafNode']()||_0x14e3ca['forEachChild'](R,(_0x455936,_0x2cd7b4)=>{_0xf0aaf6['hasChild'](_0x455936)||_0x533415['trackChildChange'](Lt(_0x455936,_0x2cd7b4));}),_0xf0aaf6['isLeafNode']()||_0xf0aaf6['forEachChild'](R,(_0x28c494,_0x40460f)=>{if(_0x14e3ca['hasChild'](_0x28c494)){const _0x477383=_0x14e3ca['getImmediateChild'](_0x28c494);_0x477383['equals'](_0x40460f)||_0x533415['trackChildChange'](xt(_0x28c494,_0x40460f,_0x477383));}else _0x533415['trackChildChange'](rt(_0x28c494,_0x40460f));})),_0xf0aaf6['withIndex'](this['index_']);}['updatePriority'](_0x5d4aea,_0x30e72a){return _0x5d4aea['isEmpty']()?g['EMPTY_NODE']:_0x5d4aea['updatePriority'](_0x30e72a);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x46dad6){this['indexedFilter_']=new Xi(_0x46dad6['getIndex']()),this['index_']=_0x46dad6['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x46dad6),this['endPost_']=Ft['getEndPost_'](_0x46dad6),this['startIsInclusive_']=!_0x46dad6['startAfterSet_'],this['endIsInclusive_']=!_0x46dad6['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xdb31e8){const _0x4d9354=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xdb31e8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xdb31e8)<0x0,_0x5afd3f=this['endIsInclusive_']?this['index_']['compare'](_0xdb31e8,this['getEndPost']())<=0x0:this['index_']['compare'](_0xdb31e8,this['getEndPost']())<0x0;return _0x4d9354&&_0x5afd3f;}['updateChild'](_0x8299ea,_0x544657,_0x1f3f93,_0x1bd5b2,_0xdfe602,_0x5bb4f6){return this['matches'](new E(_0x544657,_0x1f3f93))||(_0x1f3f93=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x8299ea,_0x544657,_0x1f3f93,_0x1bd5b2,_0xdfe602,_0x5bb4f6);}['updateFullNode'](_0x46e36d,_0x4fe7d9,_0x183dda){_0x4fe7d9['isLeafNode']()&&(_0x4fe7d9=g['EMPTY_NODE']);let _0x4b0036=_0x4fe7d9['withIndex'](this['index_']);_0x4b0036=_0x4b0036['updatePriority'](g['EMPTY_NODE']);const _0x1240b4=this;return _0x4fe7d9['forEachChild'](R,(_0x31c59e,_0x54895c)=>{_0x1240b4['matches'](new E(_0x31c59e,_0x54895c))||(_0x4b0036=_0x4b0036['updateImmediateChild'](_0x31c59e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x46e36d,_0x4b0036,_0x183dda);}['updatePriority'](_0x260db3,_0x27d8b8){return _0x260db3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x59e02b){if(_0x59e02b['hasStart']()){const _0x71b297=_0x59e02b['getIndexStartName']();return _0x59e02b['getIndex']()['makePost'](_0x59e02b['getIndexStartValue'](),_0x71b297);}else return _0x59e02b['getIndex']()['minPost']();}static['getEndPost_'](_0x395503){if(_0x395503['hasEnd']()){const _0x10e994=_0x395503['getIndexEndName']();return _0x395503['getIndex']()['makePost'](_0x395503['getIndexEndValue'](),_0x10e994);}else return _0x395503['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x50f887){this['withinDirectionalStart']=_0x4d1893=>this['reverse_']?this['withinEndPost'](_0x4d1893):this['withinStartPost'](_0x4d1893),this['withinDirectionalEnd']=_0x36508a=>this['reverse_']?this['withinStartPost'](_0x36508a):this['withinEndPost'](_0x36508a),this['withinStartPost']=_0x1911d0=>{const _0x1d4a74=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1911d0);return this['startIsInclusive_']?_0x1d4a74<=0x0:_0x1d4a74<0x0;},this['withinEndPost']=_0x4fce4d=>{const _0x4c6de7=this['index_']['compare'](_0x4fce4d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4c6de7<=0x0:_0x4c6de7<0x0;},this['rangedFilter_']=new Ft(_0x50f887),this['index_']=_0x50f887['getIndex'](),this['limit_']=_0x50f887['getLimit'](),this['reverse_']=!_0x50f887['isViewFromLeft'](),this['startIsInclusive_']=!_0x50f887['startAfterSet_'],this['endIsInclusive_']=!_0x50f887['endBeforeSet_'];}['updateChild'](_0x256e7b,_0xffa113,_0x4656cb,_0x599aa6,_0x9ec3d5,_0x51ac7c){return this['rangedFilter_']['matches'](new E(_0xffa113,_0x4656cb))||(_0x4656cb=g['EMPTY_NODE']),_0x256e7b['getImmediateChild'](_0xffa113)['equals'](_0x4656cb)?_0x256e7b:_0x256e7b['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x256e7b,_0xffa113,_0x4656cb,_0x599aa6,_0x9ec3d5,_0x51ac7c):this['fullLimitUpdateChild_'](_0x256e7b,_0xffa113,_0x4656cb,_0x9ec3d5,_0x51ac7c);}['updateFullNode'](_0x367758,_0x40bf0c,_0x387407){let _0x1bcac6;if(_0x40bf0c['isLeafNode']()||_0x40bf0c['isEmpty']())_0x1bcac6=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x40bf0c['numChildren']()&&_0x40bf0c['isIndexed'](this['index_'])){_0x1bcac6=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3612b4;this['reverse_']?_0x3612b4=_0x40bf0c['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3612b4=_0x40bf0c['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x53cdee=0x0;for(;_0x3612b4['hasNext']()&&_0x53cdee<this['limit_'];){const _0x4c743a=_0x3612b4['getNext']();if(this['withinDirectionalStart'](_0x4c743a)){if(this['withinDirectionalEnd'](_0x4c743a))_0x1bcac6=_0x1bcac6['updateImmediateChild'](_0x4c743a['name'],_0x4c743a['node']),_0x53cdee++;else break;}else continue;}}else{_0x1bcac6=_0x40bf0c['withIndex'](this['index_']),_0x1bcac6=_0x1bcac6['updatePriority'](g['EMPTY_NODE']);let _0x3566c9;this['reverse_']?_0x3566c9=_0x1bcac6['getReverseIterator'](this['index_']):_0x3566c9=_0x1bcac6['getIterator'](this['index_']);let _0x5ba623=0x0;for(;_0x3566c9['hasNext']();){const _0x196a57=_0x3566c9['getNext']();_0x5ba623<this['limit_']&&this['withinDirectionalStart'](_0x196a57)&&this['withinDirectionalEnd'](_0x196a57)?_0x5ba623++:_0x1bcac6=_0x1bcac6['updateImmediateChild'](_0x196a57['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x367758,_0x1bcac6,_0x387407);}['updatePriority'](_0x36425c,_0x27c17f){return _0x36425c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1e9e5a,_0x4813ba,_0xdc92bc,_0x1c6473,_0x2b31c9){let _0x1916ca;if(this['reverse_']){const _0x4ee16=this['index_']['getCompare']();_0x1916ca=(_0x5cda70,_0x2ba4de)=>_0x4ee16(_0x2ba4de,_0x5cda70);}else _0x1916ca=this['index_']['getCompare']();const _0x3236d0=_0x1e9e5a;f(_0x3236d0['numChildren']()===this['limit_'],'');const _0x2baad1=new E(_0x4813ba,_0xdc92bc),_0x54e659=this['reverse_']?_0x3236d0['getFirstChild'](this['index_']):_0x3236d0['getLastChild'](this['index_']),_0x548405=this['rangedFilter_']['matches'](_0x2baad1);if(_0x3236d0['hasChild'](_0x4813ba)){const _0x5751da=_0x3236d0['getImmediateChild'](_0x4813ba);let _0x5b41a9=_0x1c6473['getChildAfterChild'](this['index_'],_0x54e659,this['reverse_']);for(;_0x5b41a9!=null&&(_0x5b41a9['name']===_0x4813ba||_0x3236d0['hasChild'](_0x5b41a9['name']));)_0x5b41a9=_0x1c6473['getChildAfterChild'](this['index_'],_0x5b41a9,this['reverse_']);const _0x2e7ed4=_0x5b41a9==null?0x1:_0x1916ca(_0x5b41a9,_0x2baad1);if(_0x548405&&!_0xdc92bc['isEmpty']()&&_0x2e7ed4>=0x0)return _0x2b31c9!=null&&_0x2b31c9['trackChildChange'](xt(_0x4813ba,_0xdc92bc,_0x5751da)),_0x3236d0['updateImmediateChild'](_0x4813ba,_0xdc92bc);{_0x2b31c9!=null&&_0x2b31c9['trackChildChange'](Lt(_0x4813ba,_0x5751da));const _0x594e2f=_0x3236d0['updateImmediateChild'](_0x4813ba,g['EMPTY_NODE']);return _0x5b41a9!=null&&this['rangedFilter_']['matches'](_0x5b41a9)?(_0x2b31c9!=null&&_0x2b31c9['trackChildChange'](rt(_0x5b41a9['name'],_0x5b41a9['node'])),_0x594e2f['updateImmediateChild'](_0x5b41a9['name'],_0x5b41a9['node'])):_0x594e2f;}}else return _0xdc92bc['isEmpty']()?_0x1e9e5a:_0x548405&&_0x1916ca(_0x54e659,_0x2baad1)>=0x0?(_0x2b31c9!=null&&(_0x2b31c9['trackChildChange'](Lt(_0x54e659['name'],_0x54e659['node'])),_0x2b31c9['trackChildChange'](rt(_0x4813ba,_0xdc92bc))),_0x3236d0['updateImmediateChild'](_0x4813ba,_0xdc92bc)['updateImmediateChild'](_0x54e659['name'],g['EMPTY_NODE'])):_0x1e9e5a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1f9127=new Zi();return _0x1f9127['limitSet_']=this['limitSet_'],_0x1f9127['limit_']=this['limit_'],_0x1f9127['startSet_']=this['startSet_'],_0x1f9127['startAfterSet_']=this['startAfterSet_'],_0x1f9127['indexStartValue_']=this['indexStartValue_'],_0x1f9127['startNameSet_']=this['startNameSet_'],_0x1f9127['indexStartName_']=this['indexStartName_'],_0x1f9127['endSet_']=this['endSet_'],_0x1f9127['endBeforeSet_']=this['endBeforeSet_'],_0x1f9127['indexEndValue_']=this['indexEndValue_'],_0x1f9127['endNameSet_']=this['endNameSet_'],_0x1f9127['indexEndName_']=this['indexEndName_'],_0x1f9127['index_']=this['index_'],_0x1f9127['viewFrom_']=this['viewFrom_'],_0x1f9127;}}function Kh(_0x3f5141){return _0x3f5141['loadsAllData']()?new Xi(_0x3f5141['getIndex']()):_0x3f5141['hasLimit']()?new jh(_0x3f5141):new Ft(_0x3f5141);}function Yh(_0x54ab86,_0xaa2b05){const _0xe51705=_0x54ab86['copy']();return _0xe51705['limitSet_']=!0x0,_0xe51705['limit_']=_0xaa2b05,_0xe51705['viewFrom_']='l',_0xe51705;}function Qh(_0x2f8bf,_0x11cea9,_0x23f2e7){const _0x500573=_0x2f8bf['copy']();return _0x500573['startSet_']=!0x0,_0x11cea9===void 0x0&&(_0x11cea9=null),_0x500573['indexStartValue_']=_0x11cea9,_0x23f2e7!=null?(_0x500573['startNameSet_']=!0x0,_0x500573['indexStartName_']=_0x23f2e7):(_0x500573['startNameSet_']=!0x1,_0x500573['indexStartName_']=''),_0x500573;}function Jh(_0x56efc8,_0x30d308,_0x326587){const _0x5a23ab=_0x56efc8['copy']();return _0x5a23ab['endSet_']=!0x0,_0x30d308===void 0x0&&(_0x30d308=null),_0x5a23ab['indexEndValue_']=_0x30d308,_0x326587!==void 0x0?(_0x5a23ab['endNameSet_']=!0x0,_0x5a23ab['indexEndName_']=_0x326587):(_0x5a23ab['endNameSet_']=!0x1,_0x5a23ab['indexEndName_']=''),_0x5a23ab;}function xo(_0x1059ac,_0x4109b8){const _0x52d36a=_0x1059ac['copy']();return _0x52d36a['index_']=_0x4109b8,_0x52d36a;}function ir(_0x4fc8fa){const _0x281fac={};if(_0x4fc8fa['isDefault']())return _0x281fac;let _0xe1d5e6;if(_0x4fc8fa['index_']===R?_0xe1d5e6='$priority':_0x4fc8fa['index_']===Mo?_0xe1d5e6='$value':_0x4fc8fa['index_']===ve?_0xe1d5e6='$key':(f(_0x4fc8fa['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0xe1d5e6=_0x4fc8fa['index_']['toString']()),_0x281fac['orderBy']=O(_0xe1d5e6),_0x4fc8fa['startSet_']){const _0x49fec5=_0x4fc8fa['startAfterSet_']?'startAfter':'startAt';_0x281fac[_0x49fec5]=O(_0x4fc8fa['indexStartValue_']),_0x4fc8fa['startNameSet_']&&(_0x281fac[_0x49fec5]+=','+O(_0x4fc8fa['indexStartName_']));}if(_0x4fc8fa['endSet_']){const _0xaa1560=_0x4fc8fa['endBeforeSet_']?'endBefore':'endAt';_0x281fac[_0xaa1560]=O(_0x4fc8fa['indexEndValue_']),_0x4fc8fa['endNameSet_']&&(_0x281fac[_0xaa1560]+=','+O(_0x4fc8fa['indexEndName_']));}return _0x4fc8fa['limitSet_']&&(_0x4fc8fa['isViewFromLeft']()?_0x281fac['limitToFirst']=_0x4fc8fa['limit_']:_0x281fac['limitToLast']=_0x4fc8fa['limit_']),_0x281fac;}function sr(_0x9fcb75){const _0x500a40={};if(_0x9fcb75['startSet_']&&(_0x500a40['sp']=_0x9fcb75['indexStartValue_'],_0x9fcb75['startNameSet_']&&(_0x500a40['sn']=_0x9fcb75['indexStartName_']),_0x500a40['sin']=!_0x9fcb75['startAfterSet_']),_0x9fcb75['endSet_']&&(_0x500a40['ep']=_0x9fcb75['indexEndValue_'],_0x9fcb75['endNameSet_']&&(_0x500a40['en']=_0x9fcb75['indexEndName_']),_0x500a40['ein']=!_0x9fcb75['endBeforeSet_']),_0x9fcb75['limitSet_']){_0x500a40['l']=_0x9fcb75['limit_'];let _0x3b0f9e=_0x9fcb75['viewFrom_'];_0x3b0f9e===''&&(_0x9fcb75['isViewFromLeft']()?_0x3b0f9e='l':_0x3b0f9e='r'),_0x500a40['vf']=_0x3b0f9e;}return _0x9fcb75['index_']!==R&&(_0x500a40['i']=_0x9fcb75['index_']['toString']()),_0x500a40;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x39e1f6){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x155492,_0x46154f){return _0x46154f!==void 0x0?'tag$'+_0x46154f:(f(_0x155492['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x155492['_path']['toString']());}constructor(_0x16a4aa,_0x13406d,_0x4158af,_0x4302e8){super(),this['repoInfo_']=_0x16a4aa,this['onDataUpdate_']=_0x13406d,this['authTokenProvider_']=_0x4158af,this['appCheckTokenProvider_']=_0x4302e8,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x3d020d,_0x3ba0b8,_0xd5aa95,_0x19544d){const _0x3e4e61=_0x3d020d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e4e61+'\x20'+_0x3d020d['_queryIdentifier']);const _0x39958b=vn['getListenId_'](_0x3d020d,_0xd5aa95),_0x46d495={};this['listens_'][_0x39958b]=_0x46d495;const _0xcfd518=ir(_0x3d020d['_queryParams']);this['restRequest_'](_0x3e4e61+'.json',_0xcfd518,(_0x393653,_0x4a5485)=>{let _0x13e470=_0x4a5485;if(_0x393653===0x194&&(_0x13e470=null,_0x393653=null),_0x393653===null&&this['onDataUpdate_'](_0x3e4e61,_0x13e470,!0x1,_0xd5aa95),Le(this['listens_'],_0x39958b)===_0x46d495){let _0x5c6bb2;_0x393653?_0x393653===0x191?_0x5c6bb2='permission_denied':_0x5c6bb2='rest_error:'+_0x393653:_0x5c6bb2='ok',_0x19544d(_0x5c6bb2,null);}});}['unlisten'](_0xc425ad,_0x157a7){const _0x5a460f=vn['getListenId_'](_0xc425ad,_0x157a7);delete this['listens_'][_0x5a460f];}['get'](_0x2f573b){const _0x5d49f6=ir(_0x2f573b['_queryParams']),_0x499454=_0x2f573b['_path']['toString'](),_0x9b5784=new H();return this['restRequest_'](_0x499454+'.json',_0x5d49f6,(_0x30d43e,_0x4818d7)=>{let _0xdacc09=_0x4818d7;_0x30d43e===0x194&&(_0xdacc09=null,_0x30d43e=null),_0x30d43e===null?(this['onDataUpdate_'](_0x499454,_0xdacc09,!0x1,null),_0x9b5784['resolve'](_0xdacc09)):_0x9b5784['reject'](new Error(_0xdacc09));}),_0x9b5784['promise'];}['refreshAuthToken'](_0x18a30b){}['restRequest_'](_0x30840d,_0x213c23={},_0x2ba278){return _0x213c23['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xe06dd1,_0x1650b1])=>{_0xe06dd1&&_0xe06dd1['accessToken']&&(_0x213c23['auth']=_0xe06dd1['accessToken']),_0x1650b1&&_0x1650b1['token']&&(_0x213c23['ac']=_0x1650b1['token']);const _0x46ddf9=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x30840d+'?ns='+this['repoInfo_']['namespace']+ut(_0x213c23);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x46ddf9);const _0x23bfa2=new XMLHttpRequest();_0x23bfa2['onreadystatechange']=()=>{if(_0x2ba278&&_0x23bfa2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x46ddf9+'\x20received.\x20status:',_0x23bfa2['status'],'response:',_0x23bfa2['responseText']);let _0x3b32fe=null;if(_0x23bfa2['status']>=0xc8&&_0x23bfa2['status']<0x12c){try{_0x3b32fe=Nt(_0x23bfa2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x46ddf9+':\x20'+_0x23bfa2['responseText']);}_0x2ba278(null,_0x3b32fe);}else _0x23bfa2['status']!==0x191&&_0x23bfa2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x46ddf9+'\x20Status:\x20'+_0x23bfa2['status']),_0x2ba278(_0x23bfa2['status']);_0x2ba278=null;}},_0x23bfa2['open']('GET',_0x46ddf9,!0x0),_0x23bfa2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1228b0){return this['rootNode_']['getChild'](_0x1228b0);}['updateSnapshot'](_0x1b1086,_0x421695){this['rootNode_']=this['rootNode_']['updateChild'](_0x1b1086,_0x421695);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x427321,_0x2aed7b,_0x912849){if(v(_0x2aed7b))_0x427321['value']=_0x912849,_0x427321['children']['clear']();else{if(_0x427321['value']!==null)_0x427321['value']=_0x427321['value']['updateChild'](_0x2aed7b,_0x912849);else{const _0x40335d=y(_0x2aed7b);_0x427321['children']['has'](_0x40335d)||_0x427321['children']['set'](_0x40335d,En());const _0x4bf320=_0x427321['children']['get'](_0x40335d);_0x2aed7b=S(_0x2aed7b),pt(_0x4bf320,_0x2aed7b,_0x912849);}}}function Ti(_0x4e85a0,_0x242903){if(v(_0x242903))return _0x4e85a0['value']=null,_0x4e85a0['children']['clear'](),!0x0;if(_0x4e85a0['value']!==null){if(_0x4e85a0['value']['isLeafNode']())return!0x1;{const _0x4a29fb=_0x4e85a0['value'];return _0x4e85a0['value']=null,_0x4a29fb['forEachChild'](R,(_0x3f4c3a,_0x2fecaa)=>{pt(_0x4e85a0,new C(_0x3f4c3a),_0x2fecaa);}),Ti(_0x4e85a0,_0x242903);}}else{if(_0x4e85a0['children']['size']>0x0){const _0x30a1a7=y(_0x242903);return _0x242903=S(_0x242903),_0x4e85a0['children']['has'](_0x30a1a7)&&Ti(_0x4e85a0['children']['get'](_0x30a1a7),_0x242903)&&_0x4e85a0['children']['delete'](_0x30a1a7),_0x4e85a0['children']['size']===0x0;}else return!0x0;}}function Si(_0x1e6848,_0x3be483,_0x114d2e){_0x1e6848['value']!==null?_0x114d2e(_0x3be483,_0x1e6848['value']):Zh(_0x1e6848,(_0x1a79c5,_0x276c5b)=>{const _0x4f6c66=new C(_0x3be483['toString']()+'/'+_0x1a79c5);Si(_0x276c5b,_0x4f6c66,_0x114d2e);});}function Zh(_0x2f9d89,_0x37fd57){_0x2f9d89['children']['forEach']((_0x49a3cb,_0x3738b4)=>{_0x37fd57(_0x3738b4,_0x49a3cb);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1ea835){this['collection_']=_0x1ea835,this['last_']=null;}['get'](){const _0x1ebc9d=this['collection_']['get'](),_0x5d0e84={..._0x1ebc9d};return this['last_']&&x(this['last_'],(_0x5654a9,_0x33ed60)=>{_0x5d0e84[_0x5654a9]=_0x5d0e84[_0x5654a9]-_0x33ed60;}),this['last_']=_0x1ebc9d,_0x5d0e84;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x58354e,_0xd6450a){this['server_']=_0xd6450a,this['statsToReport_']={},this['statsListener_']=new eu(_0x58354e);const _0xa22bd8=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0xa22bd8));}['reportStats_'](){const _0x1c4f00=this['statsListener_']['get'](),_0x2a501f={};let _0x4350be=!0x1;x(_0x1c4f00,(_0x21acc5,_0x540a34)=>{_0x540a34>0x0&&Q(this['statsToReport_'],_0x21acc5)&&(_0x2a501f[_0x21acc5]=_0x540a34,_0x4350be=!0x0);}),_0x4350be&&this['server_']['reportStats'](_0x2a501f),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x784ba6){_0x784ba6[_0x784ba6['OVERWRITE']=0x0]='OVERWRITE',_0x784ba6[_0x784ba6['MERGE']=0x1]='MERGE',_0x784ba6[_0x784ba6['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x784ba6[_0x784ba6['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x390362){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x390362,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1947e4,_0x29269c,_0x4785cc){this['path']=_0x1947e4,this['affectedTree']=_0x29269c,this['revert']=_0x4785cc,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3d0742){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5a26a9=this['affectedTree']['subtree'](new C(_0x3d0742));return new In(w(),_0x5a26a9,this['revert']);}}else return f(y(this['path'])===_0x3d0742,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3368c2,_0x221fe1){this['source']=_0x3368c2,this['path']=_0x221fe1,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0xe6afb7){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x25903d,_0x1d48cd,_0x1563f8){this['source']=_0x25903d,this['path']=_0x1d48cd,this['snap']=_0x1563f8,this['type']=z['OVERWRITE'];}['operationForChild'](_0x2317c9){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x2317c9)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x21e0f2,_0x42ff51,_0x4ae729){this['source']=_0x21e0f2,this['path']=_0x42ff51,this['children']=_0x4ae729,this['type']=z['MERGE'];}['operationForChild'](_0x52111e){if(v(this['path'])){const _0x4456c0=this['children']['subtree'](new C(_0x52111e));return _0x4456c0['isEmpty']()?null:_0x4456c0['value']?new Be(this['source'],w(),_0x4456c0['value']):new ot(this['source'],w(),_0x4456c0);}else return f(y(this['path'])===_0x52111e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x5d27d7,_0x43c5ba,_0x2f7914){this['node_']=_0x5d27d7,this['fullyInitialized_']=_0x43c5ba,this['filtered_']=_0x2f7914;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x531836){if(v(_0x531836))return this['isFullyInitialized']()&&!this['filtered_'];const _0x8f2a3c=y(_0x531836);return this['isCompleteForChild'](_0x8f2a3c);}['isCompleteForChild'](_0x3c4232){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3c4232);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0xf7f393){this['query_']=_0xf7f393,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x2cf036,_0x16bb58,_0x1503bf,_0x48a2d5){const _0x4c5564=[],_0x3d2796=[];return _0x16bb58['forEach'](_0x2bc9b8=>{_0x2bc9b8['type']==='child_changed'&&_0x2cf036['index_']['indexedValueChanged'](_0x2bc9b8['oldSnap'],_0x2bc9b8['snapshotNode'])&&_0x3d2796['push'](zh(_0x2bc9b8['childName'],_0x2bc9b8['snapshotNode']));}),wt(_0x2cf036,_0x4c5564,'child_removed',_0x16bb58,_0x48a2d5,_0x1503bf),wt(_0x2cf036,_0x4c5564,'child_added',_0x16bb58,_0x48a2d5,_0x1503bf),wt(_0x2cf036,_0x4c5564,'child_moved',_0x3d2796,_0x48a2d5,_0x1503bf),wt(_0x2cf036,_0x4c5564,'child_changed',_0x16bb58,_0x48a2d5,_0x1503bf),wt(_0x2cf036,_0x4c5564,'value',_0x16bb58,_0x48a2d5,_0x1503bf),_0x4c5564;}function wt(_0x4d68b6,_0x51919f,_0x3fbfd8,_0x38f675,_0x56c996,_0x4e7a85){const _0x252053=_0x38f675['filter'](_0x1a3023=>_0x1a3023['type']===_0x3fbfd8);_0x252053['sort']((_0x43a240,_0x5e39a5)=>au(_0x4d68b6,_0x43a240,_0x5e39a5)),_0x252053['forEach'](_0x532d1f=>{const _0x215f6c=ou(_0x4d68b6,_0x532d1f,_0x4e7a85);_0x56c996['forEach'](_0x26e1d2=>{_0x26e1d2['respondsTo'](_0x532d1f['type'])&&_0x51919f['push'](_0x26e1d2['createEvent'](_0x215f6c,_0x4d68b6['query_']));});});}function ou(_0x4244bb,_0x5237c3,_0x2ab83a){return _0x5237c3['type']==='value'||_0x5237c3['type']==='child_removed'||(_0x5237c3['prevName']=_0x2ab83a['getPredecessorChildName'](_0x5237c3['childName'],_0x5237c3['snapshotNode'],_0x4244bb['index_'])),_0x5237c3;}function au(_0x3b0e47,_0x2eced9,_0x3aca3e){if(_0x2eced9['childName']==null||_0x3aca3e['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x48c7c9=new E(_0x2eced9['childName'],_0x2eced9['snapshotNode']),_0x15875e=new E(_0x3aca3e['childName'],_0x3aca3e['snapshotNode']);return _0x3b0e47['index_']['compare'](_0x48c7c9,_0x15875e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x3eaf5b,_0x57be17){return{'eventCache':_0x3eaf5b,'serverCache':_0x57be17};}function Rt(_0x137f88,_0x533c50,_0x335cc2,_0x59e915){return Un(new Te(_0x533c50,_0x335cc2,_0x59e915),_0x137f88['serverCache']);}function Fo(_0x27c7b1,_0x214845,_0x1d09be,_0x5a5eed){return Un(_0x27c7b1['eventCache'],new Te(_0x214845,_0x1d09be,_0x5a5eed));}function wn(_0x46cf1d){return _0x46cf1d['eventCache']['isFullyInitialized']()?_0x46cf1d['eventCache']['getNode']():null;}function Ve(_0x3daee9){return _0x3daee9['serverCache']['isFullyInitialized']()?_0x3daee9['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x27bca1){let _0x2486d4=new b(null);return x(_0x27bca1,(_0x3c276a,_0x3c7452)=>{_0x2486d4=_0x2486d4['set'](new C(_0x3c276a),_0x3c7452);}),_0x2486d4;}constructor(_0x2a98b1,_0x2c8956=cu()){this['value']=_0x2a98b1,this['children']=_0x2c8956;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x9f5305,_0x34e911){if(this['value']!=null&&_0x34e911(this['value']))return{'path':w(),'value':this['value']};if(v(_0x9f5305))return null;{const _0x457d69=y(_0x9f5305),_0x39ae29=this['children']['get'](_0x457d69);if(_0x39ae29!==null){const _0x261a75=_0x39ae29['findRootMostMatchingPathAndValue'](S(_0x9f5305),_0x34e911);return _0x261a75!=null?{'path':k(new C(_0x457d69),_0x261a75['path']),'value':_0x261a75['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x309241){return this['findRootMostMatchingPathAndValue'](_0x309241,()=>!0x0);}['subtree'](_0x1d11d0){if(v(_0x1d11d0))return this;{const _0x4f2e70=y(_0x1d11d0),_0x24ac0f=this['children']['get'](_0x4f2e70);return _0x24ac0f!==null?_0x24ac0f['subtree'](S(_0x1d11d0)):new b(null);}}['set'](_0x3322ea,_0x2ec62e){if(v(_0x3322ea))return new b(_0x2ec62e,this['children']);{const _0x45ebdf=y(_0x3322ea),_0x5f511d=(this['children']['get'](_0x45ebdf)||new b(null))['set'](S(_0x3322ea),_0x2ec62e),_0x39b91b=this['children']['insert'](_0x45ebdf,_0x5f511d);return new b(this['value'],_0x39b91b);}}['remove'](_0x3a18ef){if(v(_0x3a18ef))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x48d4ac=y(_0x3a18ef),_0x1e7d26=this['children']['get'](_0x48d4ac);if(_0x1e7d26){const _0x2d8d02=_0x1e7d26['remove'](S(_0x3a18ef));let _0x3a222d;return _0x2d8d02['isEmpty']()?_0x3a222d=this['children']['remove'](_0x48d4ac):_0x3a222d=this['children']['insert'](_0x48d4ac,_0x2d8d02),this['value']===null&&_0x3a222d['isEmpty']()?new b(null):new b(this['value'],_0x3a222d);}else return this;}}['get'](_0x26cdbc){if(v(_0x26cdbc))return this['value'];{const _0x2c02ec=y(_0x26cdbc),_0x4acbf9=this['children']['get'](_0x2c02ec);return _0x4acbf9?_0x4acbf9['get'](S(_0x26cdbc)):null;}}['setTree'](_0x3b3dce,_0x3c9fe6){if(v(_0x3b3dce))return _0x3c9fe6;{const _0x3c4192=y(_0x3b3dce),_0x407be7=(this['children']['get'](_0x3c4192)||new b(null))['setTree'](S(_0x3b3dce),_0x3c9fe6);let _0x4eabf7;return _0x407be7['isEmpty']()?_0x4eabf7=this['children']['remove'](_0x3c4192):_0x4eabf7=this['children']['insert'](_0x3c4192,_0x407be7),new b(this['value'],_0x4eabf7);}}['fold'](_0x5b32fc){return this['fold_'](w(),_0x5b32fc);}['fold_'](_0x23cd9f,_0x49c4cf){const _0x5c91c9={};return this['children']['inorderTraversal']((_0x282eaa,_0x1fe35a)=>{_0x5c91c9[_0x282eaa]=_0x1fe35a['fold_'](k(_0x23cd9f,_0x282eaa),_0x49c4cf);}),_0x49c4cf(_0x23cd9f,this['value'],_0x5c91c9);}['findOnPath'](_0x526746,_0xe7fc72){return this['findOnPath_'](_0x526746,w(),_0xe7fc72);}['findOnPath_'](_0x2c9468,_0x222faf,_0x25f024){const _0x34109b=this['value']?_0x25f024(_0x222faf,this['value']):!0x1;if(_0x34109b)return _0x34109b;if(v(_0x2c9468))return null;{const _0x5ba36f=y(_0x2c9468),_0x5c0137=this['children']['get'](_0x5ba36f);return _0x5c0137?_0x5c0137['findOnPath_'](S(_0x2c9468),k(_0x222faf,_0x5ba36f),_0x25f024):null;}}['foreachOnPath'](_0x5209a9,_0x163c58){return this['foreachOnPath_'](_0x5209a9,w(),_0x163c58);}['foreachOnPath_'](_0x2206a8,_0x1f3ac5,_0x5aa38f){if(v(_0x2206a8))return this;{this['value']&&_0x5aa38f(_0x1f3ac5,this['value']);const _0x67f537=y(_0x2206a8),_0x54115f=this['children']['get'](_0x67f537);return _0x54115f?_0x54115f['foreachOnPath_'](S(_0x2206a8),k(_0x1f3ac5,_0x67f537),_0x5aa38f):new b(null);}}['foreach'](_0x39c430){this['foreach_'](w(),_0x39c430);}['foreach_'](_0x6a96f0,_0x1fc436){this['children']['inorderTraversal']((_0x127943,_0x2f3d1b)=>{_0x2f3d1b['foreach_'](k(_0x6a96f0,_0x127943),_0x1fc436);}),this['value']&&_0x1fc436(_0x6a96f0,this['value']);}['foreachChild'](_0x37a43a){this['children']['inorderTraversal']((_0x3bb891,_0x3cdc1c)=>{_0x3cdc1c['value']&&_0x37a43a(_0x3bb891,_0x3cdc1c['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x5aeb53){this['writeTree_']=_0x5aeb53;}static['empty'](){return new K(new b(null));}}function At(_0x34e277,_0x4ec09e,_0x587b39){if(v(_0x4ec09e))return new K(new b(_0x587b39));{const _0x23e3b4=_0x34e277['writeTree_']['findRootMostValueAndPath'](_0x4ec09e);if(_0x23e3b4!=null){const _0x4b9ad0=_0x23e3b4['path'];let _0x2a763b=_0x23e3b4['value'];const _0x590a16=F(_0x4b9ad0,_0x4ec09e);return _0x2a763b=_0x2a763b['updateChild'](_0x590a16,_0x587b39),new K(_0x34e277['writeTree_']['set'](_0x4b9ad0,_0x2a763b));}else{const _0x51f41d=new b(_0x587b39),_0x196182=_0x34e277['writeTree_']['setTree'](_0x4ec09e,_0x51f41d);return new K(_0x196182);}}}function bi(_0x22df4f,_0xdf146f,_0xbab08d){let _0x1c5a12=_0x22df4f;return x(_0xbab08d,(_0x569575,_0x1619d0)=>{_0x1c5a12=At(_0x1c5a12,k(_0xdf146f,_0x569575),_0x1619d0);}),_0x1c5a12;}function or(_0x1d9f1f,_0x108e15){if(v(_0x108e15))return K['empty']();{const _0x1274b7=_0x1d9f1f['writeTree_']['setTree'](_0x108e15,new b(null));return new K(_0x1274b7);}}function Ri(_0x3c06a0,_0x2db009){return ze(_0x3c06a0,_0x2db009)!=null;}function ze(_0x4263a5,_0x2c6326){const _0x1979a0=_0x4263a5['writeTree_']['findRootMostValueAndPath'](_0x2c6326);return _0x1979a0!=null?_0x4263a5['writeTree_']['get'](_0x1979a0['path'])['getChild'](F(_0x1979a0['path'],_0x2c6326)):null;}function ar(_0x2b275d){const _0x2f7d75=[],_0x106050=_0x2b275d['writeTree_']['value'];return _0x106050!=null?_0x106050['isLeafNode']()||_0x106050['forEachChild'](R,(_0x3c5119,_0x5958c0)=>{_0x2f7d75['push'](new E(_0x3c5119,_0x5958c0));}):_0x2b275d['writeTree_']['children']['inorderTraversal']((_0x5e3619,_0x2c1721)=>{_0x2c1721['value']!=null&&_0x2f7d75['push'](new E(_0x5e3619,_0x2c1721['value']));}),_0x2f7d75;}function Ee(_0x3ce918,_0x305e0f){if(v(_0x305e0f))return _0x3ce918;{const _0x18a97c=ze(_0x3ce918,_0x305e0f);return _0x18a97c!=null?new K(new b(_0x18a97c)):new K(_0x3ce918['writeTree_']['subtree'](_0x305e0f));}}function Ai(_0x4a9d05){return _0x4a9d05['writeTree_']['isEmpty']();}function at(_0x2d2171,_0x12fa29){return Uo(w(),_0x2d2171['writeTree_'],_0x12fa29);}function Uo(_0x1dc651,_0x554a38,_0x4f639c){if(_0x554a38['value']!=null)return _0x4f639c['updateChild'](_0x1dc651,_0x554a38['value']);{let _0x5e6234=null;return _0x554a38['children']['inorderTraversal']((_0x468b9a,_0x855286)=>{_0x468b9a==='.priority'?(f(_0x855286['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5e6234=_0x855286['value']):_0x4f639c=Uo(k(_0x1dc651,_0x468b9a),_0x855286,_0x4f639c);}),!_0x4f639c['getChild'](_0x1dc651)['isEmpty']()&&_0x5e6234!==null&&(_0x4f639c=_0x4f639c['updateChild'](k(_0x1dc651,'.priority'),_0x5e6234)),_0x4f639c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x3e0f49,_0x5aa838){return Ho(_0x5aa838,_0x3e0f49);}function lu(_0x42358b,_0x4155d4,_0x345eea,_0x48bc7d,_0x38a70c){f(_0x48bc7d>_0x42358b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x38a70c===void 0x0&&(_0x38a70c=!0x0),_0x42358b['allWrites']['push']({'path':_0x4155d4,'snap':_0x345eea,'writeId':_0x48bc7d,'visible':_0x38a70c}),_0x38a70c&&(_0x42358b['visibleWrites']=At(_0x42358b['visibleWrites'],_0x4155d4,_0x345eea)),_0x42358b['lastWriteId']=_0x48bc7d;}function hu(_0x5338a8,_0x204732,_0x4eb5eb,_0x21f48e){f(_0x21f48e>_0x5338a8['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5338a8['allWrites']['push']({'path':_0x204732,'children':_0x4eb5eb,'writeId':_0x21f48e,'visible':!0x0}),_0x5338a8['visibleWrites']=bi(_0x5338a8['visibleWrites'],_0x204732,_0x4eb5eb),_0x5338a8['lastWriteId']=_0x21f48e;}function uu(_0x149398,_0x3864aa){for(let _0x546145=0x0;_0x546145<_0x149398['allWrites']['length'];_0x546145++){const _0xe9dc3b=_0x149398['allWrites'][_0x546145];if(_0xe9dc3b['writeId']===_0x3864aa)return _0xe9dc3b;}return null;}function du(_0x5e70dd,_0x4943be){const _0xd6ebb5=_0x5e70dd['allWrites']['findIndex'](_0xee3b78=>_0xee3b78['writeId']===_0x4943be);f(_0xd6ebb5>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1b9966=_0x5e70dd['allWrites'][_0xd6ebb5];_0x5e70dd['allWrites']['splice'](_0xd6ebb5,0x1);let _0x567505=_0x1b9966['visible'],_0x3c2159=!0x1,_0xaac18d=_0x5e70dd['allWrites']['length']-0x1;for(;_0x567505&&_0xaac18d>=0x0;){const _0x3932ac=_0x5e70dd['allWrites'][_0xaac18d];_0x3932ac['visible']&&(_0xaac18d>=_0xd6ebb5&&fu(_0x3932ac,_0x1b9966['path'])?_0x567505=!0x1:G(_0x1b9966['path'],_0x3932ac['path'])&&(_0x3c2159=!0x0)),_0xaac18d--;}if(_0x567505){if(_0x3c2159)return pu(_0x5e70dd),!0x0;if(_0x1b9966['snap'])_0x5e70dd['visibleWrites']=or(_0x5e70dd['visibleWrites'],_0x1b9966['path']);else{const _0x5e8342=_0x1b9966['children'];x(_0x5e8342,_0x3ed77b=>{_0x5e70dd['visibleWrites']=or(_0x5e70dd['visibleWrites'],k(_0x1b9966['path'],_0x3ed77b));});}return!0x0;}else return!0x1;}function fu(_0x264d2f,_0x18fbf4){if(_0x264d2f['snap'])return G(_0x264d2f['path'],_0x18fbf4);for(const _0x22d4d1 in _0x264d2f['children'])if(_0x264d2f['children']['hasOwnProperty'](_0x22d4d1)&&G(k(_0x264d2f['path'],_0x22d4d1),_0x18fbf4))return!0x0;return!0x1;}function pu(_0x3b8fc8){_0x3b8fc8['visibleWrites']=Wo(_0x3b8fc8['allWrites'],_u,w()),_0x3b8fc8['allWrites']['length']>0x0?_0x3b8fc8['lastWriteId']=_0x3b8fc8['allWrites'][_0x3b8fc8['allWrites']['length']-0x1]['writeId']:_0x3b8fc8['lastWriteId']=-0x1;}function _u(_0x25f56f){return _0x25f56f['visible'];}function Wo(_0x51d268,_0x73c5bd,_0xa25a4){let _0x2841c7=K['empty']();for(let _0x27079b=0x0;_0x27079b<_0x51d268['length'];++_0x27079b){const _0x2e5366=_0x51d268[_0x27079b];if(_0x73c5bd(_0x2e5366)){const _0x3579fc=_0x2e5366['path'];let _0x10196d;if(_0x2e5366['snap'])G(_0xa25a4,_0x3579fc)?(_0x10196d=F(_0xa25a4,_0x3579fc),_0x2841c7=At(_0x2841c7,_0x10196d,_0x2e5366['snap'])):G(_0x3579fc,_0xa25a4)&&(_0x10196d=F(_0x3579fc,_0xa25a4),_0x2841c7=At(_0x2841c7,w(),_0x2e5366['snap']['getChild'](_0x10196d)));else{if(_0x2e5366['children']){if(G(_0xa25a4,_0x3579fc))_0x10196d=F(_0xa25a4,_0x3579fc),_0x2841c7=bi(_0x2841c7,_0x10196d,_0x2e5366['children']);else{if(G(_0x3579fc,_0xa25a4)){if(_0x10196d=F(_0x3579fc,_0xa25a4),v(_0x10196d))_0x2841c7=bi(_0x2841c7,w(),_0x2e5366['children']);else{const _0x262307=Le(_0x2e5366['children'],y(_0x10196d));if(_0x262307){const _0x916e65=_0x262307['getChild'](S(_0x10196d));_0x2841c7=At(_0x2841c7,w(),_0x916e65);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2841c7;}function Bo(_0x4c787d,_0x887b31,_0x37f423,_0x29e0d2,_0x2bab60){if(!_0x29e0d2&&!_0x2bab60){const _0x546fb9=ze(_0x4c787d['visibleWrites'],_0x887b31);if(_0x546fb9!=null)return _0x546fb9;{const _0x480525=Ee(_0x4c787d['visibleWrites'],_0x887b31);if(Ai(_0x480525))return _0x37f423;if(_0x37f423==null&&!Ri(_0x480525,w()))return null;{const _0x3f6e6e=_0x37f423||g['EMPTY_NODE'];return at(_0x480525,_0x3f6e6e);}}}else{const _0xf2d5b3=Ee(_0x4c787d['visibleWrites'],_0x887b31);if(!_0x2bab60&&Ai(_0xf2d5b3))return _0x37f423;if(!_0x2bab60&&_0x37f423==null&&!Ri(_0xf2d5b3,w()))return null;{const _0x39ef40=function(_0x5d4c40){return(_0x5d4c40['visible']||_0x2bab60)&&(!_0x29e0d2||!~_0x29e0d2['indexOf'](_0x5d4c40['writeId']))&&(G(_0x5d4c40['path'],_0x887b31)||G(_0x887b31,_0x5d4c40['path']));},_0x1a41af=Wo(_0x4c787d['allWrites'],_0x39ef40,_0x887b31),_0x2111c1=_0x37f423||g['EMPTY_NODE'];return at(_0x1a41af,_0x2111c1);}}}function gu(_0x1b4b04,_0x2244a1,_0x2ad3d1){let _0x3d9388=g['EMPTY_NODE'];const _0x2669e4=ze(_0x1b4b04['visibleWrites'],_0x2244a1);if(_0x2669e4)return _0x2669e4['isLeafNode']()||_0x2669e4['forEachChild'](R,(_0x8463dd,_0x22b366)=>{_0x3d9388=_0x3d9388['updateImmediateChild'](_0x8463dd,_0x22b366);}),_0x3d9388;if(_0x2ad3d1){const _0x1df017=Ee(_0x1b4b04['visibleWrites'],_0x2244a1);return _0x2ad3d1['forEachChild'](R,(_0x963a6c,_0x15ee7b)=>{const _0x1d5aa6=at(Ee(_0x1df017,new C(_0x963a6c)),_0x15ee7b);_0x3d9388=_0x3d9388['updateImmediateChild'](_0x963a6c,_0x1d5aa6);}),ar(_0x1df017)['forEach'](_0x2bd2f7=>{_0x3d9388=_0x3d9388['updateImmediateChild'](_0x2bd2f7['name'],_0x2bd2f7['node']);}),_0x3d9388;}else{const _0x1acdfd=Ee(_0x1b4b04['visibleWrites'],_0x2244a1);return ar(_0x1acdfd)['forEach'](_0x54b5e8=>{_0x3d9388=_0x3d9388['updateImmediateChild'](_0x54b5e8['name'],_0x54b5e8['node']);}),_0x3d9388;}}function mu(_0x18e32d,_0x28599b,_0x442ea5,_0x2416cd,_0x15da01){f(_0x2416cd||_0x15da01,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x543293=k(_0x28599b,_0x442ea5);if(Ri(_0x18e32d['visibleWrites'],_0x543293))return null;{const _0x46ddf7=Ee(_0x18e32d['visibleWrites'],_0x543293);return Ai(_0x46ddf7)?_0x15da01['getChild'](_0x442ea5):at(_0x46ddf7,_0x15da01['getChild'](_0x442ea5));}}function yu(_0x1ccdc7,_0x3fe5f8,_0x5a7b3a,_0x270981){const _0x1da317=k(_0x3fe5f8,_0x5a7b3a),_0x2978de=ze(_0x1ccdc7['visibleWrites'],_0x1da317);if(_0x2978de!=null)return _0x2978de;if(_0x270981['isCompleteForChild'](_0x5a7b3a)){const _0x368aa7=Ee(_0x1ccdc7['visibleWrites'],_0x1da317);return at(_0x368aa7,_0x270981['getNode']()['getImmediateChild'](_0x5a7b3a));}else return null;}function vu(_0x53f3a4,_0x3aeb7b){return ze(_0x53f3a4['visibleWrites'],_0x3aeb7b);}function Eu(_0x4029c8,_0x4f2445,_0x5a6cb8,_0xe099f,_0x3089f3,_0x3f9e4f,_0x444fda){let _0x3531d9;const _0xdc55eb=Ee(_0x4029c8['visibleWrites'],_0x4f2445),_0x55d921=ze(_0xdc55eb,w());if(_0x55d921!=null)_0x3531d9=_0x55d921;else{if(_0x5a6cb8!=null)_0x3531d9=at(_0xdc55eb,_0x5a6cb8);else return[];}if(_0x3531d9=_0x3531d9['withIndex'](_0x444fda),!_0x3531d9['isEmpty']()&&!_0x3531d9['isLeafNode']()){const _0x7fe832=[],_0x38c93b=_0x444fda['getCompare'](),_0x41b112=_0x3f9e4f?_0x3531d9['getReverseIteratorFrom'](_0xe099f,_0x444fda):_0x3531d9['getIteratorFrom'](_0xe099f,_0x444fda);let _0x210bea=_0x41b112['getNext']();for(;_0x210bea&&_0x7fe832['length']<_0x3089f3;)_0x38c93b(_0x210bea,_0xe099f)!==0x0&&_0x7fe832['push'](_0x210bea),_0x210bea=_0x41b112['getNext']();return _0x7fe832;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x42488b,_0xd61b2b,_0x42e8b3,_0x16bb9b){return Bo(_0x42488b['writeTree'],_0x42488b['treePath'],_0xd61b2b,_0x42e8b3,_0x16bb9b);}function is(_0x3a7842,_0x39a677){return gu(_0x3a7842['writeTree'],_0x3a7842['treePath'],_0x39a677);}function cr(_0x384f8f,_0x2600b9,_0x5925ca,_0x4af9e0){return mu(_0x384f8f['writeTree'],_0x384f8f['treePath'],_0x2600b9,_0x5925ca,_0x4af9e0);}function Tn(_0x5c827f,_0x1e55f6){return vu(_0x5c827f['writeTree'],k(_0x5c827f['treePath'],_0x1e55f6));}function wu(_0x3a6bb8,_0xa06e46,_0x866292,_0x4f3ed6,_0x5858f3,_0x205155){return Eu(_0x3a6bb8['writeTree'],_0x3a6bb8['treePath'],_0xa06e46,_0x866292,_0x4f3ed6,_0x5858f3,_0x205155);}function ss(_0x6902f5,_0xabc400,_0x133653){return yu(_0x6902f5['writeTree'],_0x6902f5['treePath'],_0xabc400,_0x133653);}function Vo(_0x579f22,_0x3c9790){return Ho(k(_0x579f22['treePath'],_0x3c9790),_0x579f22['writeTree']);}function Ho(_0x754436,_0x34c52b){return{'treePath':_0x754436,'writeTree':_0x34c52b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4c0d13){const _0x2e2763=_0x4c0d13['type'],_0x2ef5cf=_0x4c0d13['childName'];f(_0x2e2763==='child_added'||_0x2e2763==='child_changed'||_0x2e2763==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2ef5cf!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4d86ad=this['changeMap']['get'](_0x2ef5cf);if(_0x4d86ad){const _0x3b175b=_0x4d86ad['type'];if(_0x2e2763==='child_added'&&_0x3b175b==='child_removed')this['changeMap']['set'](_0x2ef5cf,xt(_0x2ef5cf,_0x4c0d13['snapshotNode'],_0x4d86ad['snapshotNode']));else{if(_0x2e2763==='child_removed'&&_0x3b175b==='child_added')this['changeMap']['delete'](_0x2ef5cf);else{if(_0x2e2763==='child_removed'&&_0x3b175b==='child_changed')this['changeMap']['set'](_0x2ef5cf,Lt(_0x2ef5cf,_0x4d86ad['oldSnap']));else{if(_0x2e2763==='child_changed'&&_0x3b175b==='child_added')this['changeMap']['set'](_0x2ef5cf,rt(_0x2ef5cf,_0x4c0d13['snapshotNode']));else{if(_0x2e2763==='child_changed'&&_0x3b175b==='child_changed')this['changeMap']['set'](_0x2ef5cf,xt(_0x2ef5cf,_0x4c0d13['snapshotNode'],_0x4d86ad['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x4c0d13+'\x20occurred\x20after\x20'+_0x4d86ad);}}}}}else this['changeMap']['set'](_0x2ef5cf,_0x4c0d13);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x37922b){return null;}['getChildAfterChild'](_0x25f96e,_0x163183,_0x5c5285){return null;}}const $o=new Tu();class rs{constructor(_0x1ea602,_0x1f7e5f,_0x4bf183=null){this['writes_']=_0x1ea602,this['viewCache_']=_0x1f7e5f,this['optCompleteServerCache_']=_0x4bf183;}['getCompleteChild'](_0x8c8884){const _0x125204=this['viewCache_']['eventCache'];if(_0x125204['isCompleteForChild'](_0x8c8884))return _0x125204['getNode']()['getImmediateChild'](_0x8c8884);{const _0x26477e=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x8c8884,_0x26477e);}}['getChildAfterChild'](_0x52c118,_0x11fa14,_0x402350){const _0x170397=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x13cbb1=wu(this['writes_'],_0x170397,_0x11fa14,0x1,_0x402350,_0x52c118);return _0x13cbb1['length']===0x0?null:_0x13cbb1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4083f3){return{'filter':_0x4083f3};}function bu(_0xee6600,_0x578f49){f(_0x578f49['eventCache']['getNode']()['isIndexed'](_0xee6600['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x578f49['serverCache']['getNode']()['isIndexed'](_0xee6600['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x126df1,_0x14756e,_0x2df650,_0x466d7c,_0x37f981){const _0x14935c=new Cu();let _0x4b028b,_0x224433;if(_0x2df650['type']===z['OVERWRITE']){const _0x162deb=_0x2df650;_0x162deb['source']['fromUser']?_0x4b028b=ki(_0x126df1,_0x14756e,_0x162deb['path'],_0x162deb['snap'],_0x466d7c,_0x37f981,_0x14935c):(f(_0x162deb['source']['fromServer'],'Unknown\x20source.'),_0x224433=_0x162deb['source']['tagged']||_0x14756e['serverCache']['isFiltered']()&&!v(_0x162deb['path']),_0x4b028b=Sn(_0x126df1,_0x14756e,_0x162deb['path'],_0x162deb['snap'],_0x466d7c,_0x37f981,_0x224433,_0x14935c));}else{if(_0x2df650['type']===z['MERGE']){const _0x48f268=_0x2df650;_0x48f268['source']['fromUser']?_0x4b028b=ku(_0x126df1,_0x14756e,_0x48f268['path'],_0x48f268['children'],_0x466d7c,_0x37f981,_0x14935c):(f(_0x48f268['source']['fromServer'],'Unknown\x20source.'),_0x224433=_0x48f268['source']['tagged']||_0x14756e['serverCache']['isFiltered'](),_0x4b028b=Pi(_0x126df1,_0x14756e,_0x48f268['path'],_0x48f268['children'],_0x466d7c,_0x37f981,_0x224433,_0x14935c));}else{if(_0x2df650['type']===z['ACK_USER_WRITE']){const _0x55de6e=_0x2df650;_0x55de6e['revert']?_0x4b028b=Ou(_0x126df1,_0x14756e,_0x55de6e['path'],_0x466d7c,_0x37f981,_0x14935c):_0x4b028b=Pu(_0x126df1,_0x14756e,_0x55de6e['path'],_0x55de6e['affectedTree'],_0x466d7c,_0x37f981,_0x14935c);}else{if(_0x2df650['type']===z['LISTEN_COMPLETE'])_0x4b028b=Nu(_0x126df1,_0x14756e,_0x2df650['path'],_0x466d7c,_0x14935c);else throw ht('Unknown\x20operation\x20type:\x20'+_0x2df650['type']);}}}const _0x3ea113=_0x14935c['getChanges']();return Au(_0x14756e,_0x4b028b,_0x3ea113),{'viewCache':_0x4b028b,'changes':_0x3ea113};}function Au(_0xdc4254,_0x500b0b,_0x1bc3f5){const _0x366c85=_0x500b0b['eventCache'];if(_0x366c85['isFullyInitialized']()){const _0x85d855=_0x366c85['getNode']()['isLeafNode']()||_0x366c85['getNode']()['isEmpty'](),_0x481e13=wn(_0xdc4254);(_0x1bc3f5['length']>0x0||!_0xdc4254['eventCache']['isFullyInitialized']()||_0x85d855&&!_0x366c85['getNode']()['equals'](_0x481e13)||!_0x366c85['getNode']()['getPriority']()['equals'](_0x481e13['getPriority']()))&&_0x1bc3f5['push'](Lo(wn(_0x500b0b)));}}function Go(_0x519b9e,_0x2bbbce,_0x4f08a9,_0x3d03e3,_0xec08e1,_0x112ee9){const _0x338f32=_0x2bbbce['eventCache'];if(Tn(_0x3d03e3,_0x4f08a9)!=null)return _0x2bbbce;{let _0x20b342,_0x3e8355;if(v(_0x4f08a9)){if(f(_0x2bbbce['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2bbbce['serverCache']['isFiltered']()){const _0x17605c=Ve(_0x2bbbce),_0xf7c81=_0x17605c instanceof g?_0x17605c:g['EMPTY_NODE'],_0x226f71=is(_0x3d03e3,_0xf7c81);_0x20b342=_0x519b9e['filter']['updateFullNode'](_0x2bbbce['eventCache']['getNode'](),_0x226f71,_0x112ee9);}else{const _0x792bc9=Cn(_0x3d03e3,Ve(_0x2bbbce));_0x20b342=_0x519b9e['filter']['updateFullNode'](_0x2bbbce['eventCache']['getNode'](),_0x792bc9,_0x112ee9);}}else{const _0x30867c=y(_0x4f08a9);if(_0x30867c==='.priority'){f(Ce(_0x4f08a9)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x300ee8=_0x338f32['getNode']();_0x3e8355=_0x2bbbce['serverCache']['getNode']();const _0x4ea93c=cr(_0x3d03e3,_0x4f08a9,_0x300ee8,_0x3e8355);_0x4ea93c!=null?_0x20b342=_0x519b9e['filter']['updatePriority'](_0x300ee8,_0x4ea93c):_0x20b342=_0x338f32['getNode']();}else{const _0x1891cb=S(_0x4f08a9);let _0x6054a0;if(_0x338f32['isCompleteForChild'](_0x30867c)){_0x3e8355=_0x2bbbce['serverCache']['getNode']();const _0x174576=cr(_0x3d03e3,_0x4f08a9,_0x338f32['getNode'](),_0x3e8355);_0x174576!=null?_0x6054a0=_0x338f32['getNode']()['getImmediateChild'](_0x30867c)['updateChild'](_0x1891cb,_0x174576):_0x6054a0=_0x338f32['getNode']()['getImmediateChild'](_0x30867c);}else _0x6054a0=ss(_0x3d03e3,_0x30867c,_0x2bbbce['serverCache']);_0x6054a0!=null?_0x20b342=_0x519b9e['filter']['updateChild'](_0x338f32['getNode'](),_0x30867c,_0x6054a0,_0x1891cb,_0xec08e1,_0x112ee9):_0x20b342=_0x338f32['getNode']();}}return Rt(_0x2bbbce,_0x20b342,_0x338f32['isFullyInitialized']()||v(_0x4f08a9),_0x519b9e['filter']['filtersNodes']());}}function Sn(_0x99cc87,_0x4e9793,_0x250f1e,_0x3266b0,_0x9c24bb,_0x17cd31,_0x4812e8,_0x5b218d){const _0x48455a=_0x4e9793['serverCache'];let _0x5ec306;const _0x3cf758=_0x4812e8?_0x99cc87['filter']:_0x99cc87['filter']['getIndexedFilter']();if(v(_0x250f1e))_0x5ec306=_0x3cf758['updateFullNode'](_0x48455a['getNode'](),_0x3266b0,null);else{if(_0x3cf758['filtersNodes']()&&!_0x48455a['isFiltered']()){const _0x398324=_0x48455a['getNode']()['updateChild'](_0x250f1e,_0x3266b0);_0x5ec306=_0x3cf758['updateFullNode'](_0x48455a['getNode'](),_0x398324,null);}else{const _0x288ed1=y(_0x250f1e);if(!_0x48455a['isCompleteForPath'](_0x250f1e)&&Ce(_0x250f1e)>0x1)return _0x4e9793;const _0x4315eb=S(_0x250f1e),_0x3cfcce=_0x48455a['getNode']()['getImmediateChild'](_0x288ed1)['updateChild'](_0x4315eb,_0x3266b0);_0x288ed1==='.priority'?_0x5ec306=_0x3cf758['updatePriority'](_0x48455a['getNode'](),_0x3cfcce):_0x5ec306=_0x3cf758['updateChild'](_0x48455a['getNode'](),_0x288ed1,_0x3cfcce,_0x4315eb,$o,null);}}const _0x1dab4c=Fo(_0x4e9793,_0x5ec306,_0x48455a['isFullyInitialized']()||v(_0x250f1e),_0x3cf758['filtersNodes']()),_0x4a2a4a=new rs(_0x9c24bb,_0x1dab4c,_0x17cd31);return Go(_0x99cc87,_0x1dab4c,_0x250f1e,_0x9c24bb,_0x4a2a4a,_0x5b218d);}function ki(_0x5066ea,_0x1359ed,_0x1fcfdf,_0x7d39ad,_0x45cb2c,_0x1c1813,_0x2ba0bb){const _0x1d3ca7=_0x1359ed['eventCache'];let _0x5aea6c,_0x40a307;const _0x323226=new rs(_0x45cb2c,_0x1359ed,_0x1c1813);if(v(_0x1fcfdf))_0x40a307=_0x5066ea['filter']['updateFullNode'](_0x1359ed['eventCache']['getNode'](),_0x7d39ad,_0x2ba0bb),_0x5aea6c=Rt(_0x1359ed,_0x40a307,!0x0,_0x5066ea['filter']['filtersNodes']());else{const _0x1492b2=y(_0x1fcfdf);if(_0x1492b2==='.priority')_0x40a307=_0x5066ea['filter']['updatePriority'](_0x1359ed['eventCache']['getNode'](),_0x7d39ad),_0x5aea6c=Rt(_0x1359ed,_0x40a307,_0x1d3ca7['isFullyInitialized'](),_0x1d3ca7['isFiltered']());else{const _0x1ffee3=S(_0x1fcfdf),_0x2c1416=_0x1d3ca7['getNode']()['getImmediateChild'](_0x1492b2);let _0x1c2d57;if(v(_0x1ffee3))_0x1c2d57=_0x7d39ad;else{const _0x5b757a=_0x323226['getCompleteChild'](_0x1492b2);_0x5b757a!=null?ji(_0x1ffee3)==='.priority'&&_0x5b757a['getChild'](Ro(_0x1ffee3))['isEmpty']()?_0x1c2d57=_0x5b757a:_0x1c2d57=_0x5b757a['updateChild'](_0x1ffee3,_0x7d39ad):_0x1c2d57=g['EMPTY_NODE'];}if(_0x2c1416['equals'](_0x1c2d57))_0x5aea6c=_0x1359ed;else{const _0x4595d4=_0x5066ea['filter']['updateChild'](_0x1d3ca7['getNode'](),_0x1492b2,_0x1c2d57,_0x1ffee3,_0x323226,_0x2ba0bb);_0x5aea6c=Rt(_0x1359ed,_0x4595d4,_0x1d3ca7['isFullyInitialized'](),_0x5066ea['filter']['filtersNodes']());}}}return _0x5aea6c;}function lr(_0x39bdce,_0x4ce179){return _0x39bdce['eventCache']['isCompleteForChild'](_0x4ce179);}function ku(_0x5103d5,_0x2359a3,_0x45f1c7,_0x44cd12,_0x36baba,_0x17fd92,_0x160423){let _0x55d1ea=_0x2359a3;return _0x44cd12['foreach']((_0x44254d,_0x12a003)=>{const _0x2b255d=k(_0x45f1c7,_0x44254d);lr(_0x2359a3,y(_0x2b255d))&&(_0x55d1ea=ki(_0x5103d5,_0x55d1ea,_0x2b255d,_0x12a003,_0x36baba,_0x17fd92,_0x160423));}),_0x44cd12['foreach']((_0xb8db68,_0x2cfdda)=>{const _0x53f55e=k(_0x45f1c7,_0xb8db68);lr(_0x2359a3,y(_0x53f55e))||(_0x55d1ea=ki(_0x5103d5,_0x55d1ea,_0x53f55e,_0x2cfdda,_0x36baba,_0x17fd92,_0x160423));}),_0x55d1ea;}function hr(_0x35fdb9,_0x5dbf52,_0x1411fc){return _0x1411fc['foreach']((_0xc1aec8,_0x52d5a4)=>{_0x5dbf52=_0x5dbf52['updateChild'](_0xc1aec8,_0x52d5a4);}),_0x5dbf52;}function Pi(_0x29bc30,_0x16400e,_0x2d268f,_0x533ccd,_0x5a12bd,_0x47e9f2,_0x7ae9fa,_0x12d7a2){if(_0x16400e['serverCache']['getNode']()['isEmpty']()&&!_0x16400e['serverCache']['isFullyInitialized']())return _0x16400e;let _0x284e0b=_0x16400e,_0x698b2b;v(_0x2d268f)?_0x698b2b=_0x533ccd:_0x698b2b=new b(null)['setTree'](_0x2d268f,_0x533ccd);const _0x1117ae=_0x16400e['serverCache']['getNode']();return _0x698b2b['children']['inorderTraversal']((_0x3605f9,_0x282ee5)=>{if(_0x1117ae['hasChild'](_0x3605f9)){const _0x3830d8=_0x16400e['serverCache']['getNode']()['getImmediateChild'](_0x3605f9),_0x312656=hr(_0x29bc30,_0x3830d8,_0x282ee5);_0x284e0b=Sn(_0x29bc30,_0x284e0b,new C(_0x3605f9),_0x312656,_0x5a12bd,_0x47e9f2,_0x7ae9fa,_0x12d7a2);}}),_0x698b2b['children']['inorderTraversal']((_0x31510f,_0x75417a)=>{const _0x58490d=!_0x16400e['serverCache']['isCompleteForChild'](_0x31510f)&&_0x75417a['value']===null;if(!_0x1117ae['hasChild'](_0x31510f)&&!_0x58490d){const _0x2b1550=_0x16400e['serverCache']['getNode']()['getImmediateChild'](_0x31510f),_0x11410c=hr(_0x29bc30,_0x2b1550,_0x75417a);_0x284e0b=Sn(_0x29bc30,_0x284e0b,new C(_0x31510f),_0x11410c,_0x5a12bd,_0x47e9f2,_0x7ae9fa,_0x12d7a2);}}),_0x284e0b;}function Pu(_0x3e4152,_0x1d9bb5,_0xa830f2,_0x27781a,_0x5301e7,_0x3f9adf,_0x5837d8){if(Tn(_0x5301e7,_0xa830f2)!=null)return _0x1d9bb5;const _0x5e340b=_0x1d9bb5['serverCache']['isFiltered'](),_0x5e81eb=_0x1d9bb5['serverCache'];if(_0x27781a['value']!=null){if(v(_0xa830f2)&&_0x5e81eb['isFullyInitialized']()||_0x5e81eb['isCompleteForPath'](_0xa830f2))return Sn(_0x3e4152,_0x1d9bb5,_0xa830f2,_0x5e81eb['getNode']()['getChild'](_0xa830f2),_0x5301e7,_0x3f9adf,_0x5e340b,_0x5837d8);if(v(_0xa830f2)){let _0x4b3b58=new b(null);return _0x5e81eb['getNode']()['forEachChild'](ve,(_0x2a2b93,_0x38ae0d)=>{_0x4b3b58=_0x4b3b58['set'](new C(_0x2a2b93),_0x38ae0d);}),Pi(_0x3e4152,_0x1d9bb5,_0xa830f2,_0x4b3b58,_0x5301e7,_0x3f9adf,_0x5e340b,_0x5837d8);}else return _0x1d9bb5;}else{let _0x226420=new b(null);return _0x27781a['foreach']((_0x275239,_0x212865)=>{const _0x221a71=k(_0xa830f2,_0x275239);_0x5e81eb['isCompleteForPath'](_0x221a71)&&(_0x226420=_0x226420['set'](_0x275239,_0x5e81eb['getNode']()['getChild'](_0x221a71)));}),Pi(_0x3e4152,_0x1d9bb5,_0xa830f2,_0x226420,_0x5301e7,_0x3f9adf,_0x5e340b,_0x5837d8);}}function Nu(_0x3a73b5,_0x368a31,_0x13cccd,_0x37b73f,_0x1b0e92){const _0x4b1d44=_0x368a31['serverCache'],_0x351900=Fo(_0x368a31,_0x4b1d44['getNode'](),_0x4b1d44['isFullyInitialized']()||v(_0x13cccd),_0x4b1d44['isFiltered']());return Go(_0x3a73b5,_0x351900,_0x13cccd,_0x37b73f,$o,_0x1b0e92);}function Ou(_0x38643c,_0x1c96ea,_0x2ef972,_0x2e28a8,_0x1743ff,_0x5d0a79){let _0x236455;if(Tn(_0x2e28a8,_0x2ef972)!=null)return _0x1c96ea;{const _0xff3c60=new rs(_0x2e28a8,_0x1c96ea,_0x1743ff),_0x2898a2=_0x1c96ea['eventCache']['getNode']();let _0x33bbd3;if(v(_0x2ef972)||y(_0x2ef972)==='.priority'){let _0x173bc7;if(_0x1c96ea['serverCache']['isFullyInitialized']())_0x173bc7=Cn(_0x2e28a8,Ve(_0x1c96ea));else{const _0x306f14=_0x1c96ea['serverCache']['getNode']();f(_0x306f14 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x173bc7=is(_0x2e28a8,_0x306f14);}_0x173bc7=_0x173bc7,_0x33bbd3=_0x38643c['filter']['updateFullNode'](_0x2898a2,_0x173bc7,_0x5d0a79);}else{const _0x16a5d4=y(_0x2ef972);let _0x53ac5c=ss(_0x2e28a8,_0x16a5d4,_0x1c96ea['serverCache']);_0x53ac5c==null&&_0x1c96ea['serverCache']['isCompleteForChild'](_0x16a5d4)&&(_0x53ac5c=_0x2898a2['getImmediateChild'](_0x16a5d4)),_0x53ac5c!=null?_0x33bbd3=_0x38643c['filter']['updateChild'](_0x2898a2,_0x16a5d4,_0x53ac5c,S(_0x2ef972),_0xff3c60,_0x5d0a79):_0x1c96ea['eventCache']['getNode']()['hasChild'](_0x16a5d4)?_0x33bbd3=_0x38643c['filter']['updateChild'](_0x2898a2,_0x16a5d4,g['EMPTY_NODE'],S(_0x2ef972),_0xff3c60,_0x5d0a79):_0x33bbd3=_0x2898a2,_0x33bbd3['isEmpty']()&&_0x1c96ea['serverCache']['isFullyInitialized']()&&(_0x236455=Cn(_0x2e28a8,Ve(_0x1c96ea)),_0x236455['isLeafNode']()&&(_0x33bbd3=_0x38643c['filter']['updateFullNode'](_0x33bbd3,_0x236455,_0x5d0a79)));}return _0x236455=_0x1c96ea['serverCache']['isFullyInitialized']()||Tn(_0x2e28a8,w())!=null,Rt(_0x1c96ea,_0x33bbd3,_0x236455,_0x38643c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x2defcf,_0x1845f6){this['query_']=_0x2defcf,this['eventRegistrations_']=[];const _0x383306=this['query_']['_queryParams'],_0x6ba321=new Xi(_0x383306['getIndex']()),_0x182077=Kh(_0x383306);this['processor_']=Su(_0x182077);const _0x8eec50=_0x1845f6['serverCache'],_0x464a9e=_0x1845f6['eventCache'],_0x30d90f=_0x6ba321['updateFullNode'](g['EMPTY_NODE'],_0x8eec50['getNode'](),null),_0x3aee38=_0x182077['updateFullNode'](g['EMPTY_NODE'],_0x464a9e['getNode'](),null),_0x495628=new Te(_0x30d90f,_0x8eec50['isFullyInitialized'](),_0x6ba321['filtersNodes']()),_0x24386b=new Te(_0x3aee38,_0x464a9e['isFullyInitialized'](),_0x182077['filtersNodes']());this['viewCache_']=Un(_0x24386b,_0x495628),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x55909c){return _0x55909c['viewCache_']['serverCache']['getNode']();}function Lu(_0x323e6e){return wn(_0x323e6e['viewCache_']);}function xu(_0x15db6a,_0x5191e2){const _0x364104=Ve(_0x15db6a['viewCache_']);return _0x364104&&(_0x15db6a['query']['_queryParams']['loadsAllData']()||!v(_0x5191e2)&&!_0x364104['getImmediateChild'](y(_0x5191e2))['isEmpty']())?_0x364104['getChild'](_0x5191e2):null;}function ur(_0x5a09f6){return _0x5a09f6['eventRegistrations_']['length']===0x0;}function Fu(_0xd8a5d7,_0x57c863){_0xd8a5d7['eventRegistrations_']['push'](_0x57c863);}function dr(_0x19937b,_0x5e8341,_0x3a27ec){const _0x370180=[];if(_0x3a27ec){f(_0x5e8341==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x4330e6=_0x19937b['query']['_path'];_0x19937b['eventRegistrations_']['forEach'](_0x46fa82=>{const _0x4f0006=_0x46fa82['createCancelEvent'](_0x3a27ec,_0x4330e6);_0x4f0006&&_0x370180['push'](_0x4f0006);});}if(_0x5e8341){let _0x22f69d=[];for(let _0x48c4d3=0x0;_0x48c4d3<_0x19937b['eventRegistrations_']['length'];++_0x48c4d3){const _0xfe541b=_0x19937b['eventRegistrations_'][_0x48c4d3];if(!_0xfe541b['matches'](_0x5e8341))_0x22f69d['push'](_0xfe541b);else{if(_0x5e8341['hasAnyCallback']()){_0x22f69d=_0x22f69d['concat'](_0x19937b['eventRegistrations_']['slice'](_0x48c4d3+0x1));break;}}}_0x19937b['eventRegistrations_']=_0x22f69d;}else _0x19937b['eventRegistrations_']=[];return _0x370180;}function fr(_0x3f4a75,_0x18794d,_0x11be15,_0x14936f){_0x18794d['type']===z['MERGE']&&_0x18794d['source']['queryId']!==null&&(f(Ve(_0x3f4a75['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x3f4a75['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x23fa57=_0x3f4a75['viewCache_'],_0x47e4d2=Ru(_0x3f4a75['processor_'],_0x23fa57,_0x18794d,_0x11be15,_0x14936f);return bu(_0x3f4a75['processor_'],_0x47e4d2['viewCache']),f(_0x47e4d2['viewCache']['serverCache']['isFullyInitialized']()||!_0x23fa57['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x3f4a75['viewCache_']=_0x47e4d2['viewCache'],qo(_0x3f4a75,_0x47e4d2['changes'],_0x47e4d2['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x36a5ef,_0xf38ea0){const _0x158c82=_0x36a5ef['viewCache_']['eventCache'],_0x527795=[];return _0x158c82['getNode']()['isLeafNode']()||_0x158c82['getNode']()['forEachChild'](R,(_0x1d92a9,_0x4ecc64)=>{_0x527795['push'](rt(_0x1d92a9,_0x4ecc64));}),_0x158c82['isFullyInitialized']()&&_0x527795['push'](Lo(_0x158c82['getNode']())),qo(_0x36a5ef,_0x527795,_0x158c82['getNode'](),_0xf38ea0);}function qo(_0x36dd85,_0x4ae07c,_0x871b4b,_0x54765a){const _0x3c94bc=_0x54765a?[_0x54765a]:_0x36dd85['eventRegistrations_'];return ru(_0x36dd85['eventGenerator_'],_0x4ae07c,_0x871b4b,_0x3c94bc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x332262){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x332262;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x592c91){return _0x592c91['views']['size']===0x0;}function os(_0x372a95,_0xfee4ac,_0x534752,_0x5b8149){const _0x6a9550=_0xfee4ac['source']['queryId'];if(_0x6a9550!==null){const _0x3c5956=_0x372a95['views']['get'](_0x6a9550);return f(_0x3c5956!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x3c5956,_0xfee4ac,_0x534752,_0x5b8149);}else{let _0x5ba627=[];for(const _0x197bd8 of _0x372a95['views']['values']())_0x5ba627=_0x5ba627['concat'](fr(_0x197bd8,_0xfee4ac,_0x534752,_0x5b8149));return _0x5ba627;}}function jo(_0x217c80,_0x4e7b8c,_0x1950a9,_0x2b0636,_0x3311e2){const _0xe16299=_0x4e7b8c['_queryIdentifier'],_0x3f0490=_0x217c80['views']['get'](_0xe16299);if(!_0x3f0490){let _0x43e0ff=Cn(_0x1950a9,_0x3311e2?_0x2b0636:null),_0x5ef8d3=!0x1;_0x43e0ff?_0x5ef8d3=!0x0:_0x2b0636 instanceof g?(_0x43e0ff=is(_0x1950a9,_0x2b0636),_0x5ef8d3=!0x1):(_0x43e0ff=g['EMPTY_NODE'],_0x5ef8d3=!0x1);const _0x5d3076=Un(new Te(_0x43e0ff,_0x5ef8d3,!0x1),new Te(_0x2b0636,_0x3311e2,!0x1));return new Du(_0x4e7b8c,_0x5d3076);}return _0x3f0490;}function Hu(_0x279f49,_0x1f765c,_0x2397e1,_0x1ee14a,_0x3ae31d,_0x3da3c2){const _0x2e03da=jo(_0x279f49,_0x1f765c,_0x1ee14a,_0x3ae31d,_0x3da3c2);return _0x279f49['views']['has'](_0x1f765c['_queryIdentifier'])||_0x279f49['views']['set'](_0x1f765c['_queryIdentifier'],_0x2e03da),Fu(_0x2e03da,_0x2397e1),Uu(_0x2e03da,_0x2397e1);}function $u(_0x5eb76c,_0x2011f3,_0x5836af,_0x5e78ec){const _0x4e0f35=_0x2011f3['_queryIdentifier'],_0x2b3668=[];let _0x227a72=[];const _0x475be1=Se(_0x5eb76c);if(_0x4e0f35==='default'){for(const [_0x2fb27b,_0x532e8a]of _0x5eb76c['views']['entries']())_0x227a72=_0x227a72['concat'](dr(_0x532e8a,_0x5836af,_0x5e78ec)),ur(_0x532e8a)&&(_0x5eb76c['views']['delete'](_0x2fb27b),_0x532e8a['query']['_queryParams']['loadsAllData']()||_0x2b3668['push'](_0x532e8a['query']));}else{const _0x21577c=_0x5eb76c['views']['get'](_0x4e0f35);_0x21577c&&(_0x227a72=_0x227a72['concat'](dr(_0x21577c,_0x5836af,_0x5e78ec)),ur(_0x21577c)&&(_0x5eb76c['views']['delete'](_0x4e0f35),_0x21577c['query']['_queryParams']['loadsAllData']()||_0x2b3668['push'](_0x21577c['query'])));}return _0x475be1&&!Se(_0x5eb76c)&&_0x2b3668['push'](new(Bu())(_0x2011f3['_repo'],_0x2011f3['_path'])),{'removed':_0x2b3668,'events':_0x227a72};}function Ko(_0x57e8fb){const _0x37d07a=[];for(const _0x50bc67 of _0x57e8fb['views']['values']())_0x50bc67['query']['_queryParams']['loadsAllData']()||_0x37d07a['push'](_0x50bc67);return _0x37d07a;}function Ie(_0x4fe979,_0x353fe0){let _0x181bba=null;for(const _0x17ab1d of _0x4fe979['views']['values']())_0x181bba=_0x181bba||xu(_0x17ab1d,_0x353fe0);return _0x181bba;}function Yo(_0x4c02e4,_0xd547a4){if(_0xd547a4['_queryParams']['loadsAllData']())return Bn(_0x4c02e4);{const _0x522d9d=_0xd547a4['_queryIdentifier'];return _0x4c02e4['views']['get'](_0x522d9d);}}function Qo(_0x272411,_0x27ca5e){return Yo(_0x272411,_0x27ca5e)!=null;}function Se(_0x279c46){return Bn(_0x279c46)!=null;}function Bn(_0x20b344){for(const _0x442f28 of _0x20b344['views']['values']())if(_0x442f28['query']['_queryParams']['loadsAllData']())return _0x442f28;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2e7bd4){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2e7bd4;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x25cd36){this['listenProvider_']=_0x25cd36,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2ed994,_0x392594,_0x4f84df,_0x18c0a2,_0x22ef7a){return lu(_0x2ed994['pendingWriteTree_'],_0x392594,_0x4f84df,_0x18c0a2,_0x22ef7a),_0x22ef7a?_t(_0x2ed994,new Be(es(),_0x392594,_0x4f84df)):[];}function ju(_0x34295e,_0x47a10b,_0x3ccbeb,_0xb8499d){hu(_0x34295e['pendingWriteTree_'],_0x47a10b,_0x3ccbeb,_0xb8499d);const _0x11bb72=b['fromObject'](_0x3ccbeb);return _t(_0x34295e,new ot(es(),_0x47a10b,_0x11bb72));}function _e(_0x454f09,_0x4cacec,_0x4bd5f9=!0x1){const _0x369b1e=uu(_0x454f09['pendingWriteTree_'],_0x4cacec);if(du(_0x454f09['pendingWriteTree_'],_0x4cacec)){let _0x27565b=new b(null);return _0x369b1e['snap']!=null?_0x27565b=_0x27565b['set'](w(),!0x0):x(_0x369b1e['children'],_0x1a9f04=>{_0x27565b=_0x27565b['set'](new C(_0x1a9f04),!0x0);}),_t(_0x454f09,new In(_0x369b1e['path'],_0x27565b,_0x4bd5f9));}else return[];}function Yt(_0x57ab87,_0x1d0a49,_0x57b718){return _t(_0x57ab87,new Be(ts(),_0x1d0a49,_0x57b718));}function Ku(_0xa49da,_0x4b00ff,_0x417020){const _0x1b6cb9=b['fromObject'](_0x417020);return _t(_0xa49da,new ot(ts(),_0x4b00ff,_0x1b6cb9));}function Yu(_0x4e217c,_0x574830){return _t(_0x4e217c,new Ut(ts(),_0x574830));}function Qu(_0x23cdbf,_0x24e46e,_0x1e2cd7){const _0x33b9ba=cs(_0x23cdbf,_0x1e2cd7);if(_0x33b9ba){const _0x3b73ab=ls(_0x33b9ba),_0x80ca37=_0x3b73ab['path'],_0x179632=_0x3b73ab['queryId'],_0x4f75b2=F(_0x80ca37,_0x24e46e),_0x3e83ce=new Ut(ns(_0x179632),_0x4f75b2);return hs(_0x23cdbf,_0x80ca37,_0x3e83ce);}else return[];}function An(_0x2f8a54,_0x491cef,_0x38aeae,_0xae8a54,_0x4e2a19=!0x1){const _0x4e2279=_0x491cef['_path'],_0x3f1f5f=_0x2f8a54['syncPointTree_']['get'](_0x4e2279);let _0x4432ad=[];if(_0x3f1f5f&&(_0x491cef['_queryIdentifier']==='default'||Qo(_0x3f1f5f,_0x491cef))){const _0x4f6cc9=$u(_0x3f1f5f,_0x491cef,_0x38aeae,_0xae8a54);Vu(_0x3f1f5f)&&(_0x2f8a54['syncPointTree_']=_0x2f8a54['syncPointTree_']['remove'](_0x4e2279));const _0x49953d=_0x4f6cc9['removed'];if(_0x4432ad=_0x4f6cc9['events'],!_0x4e2a19){const _0x2256ae=_0x49953d['findIndex'](_0x26e974=>_0x26e974['_queryParams']['loadsAllData']())!==-0x1,_0x3e0fcf=_0x2f8a54['syncPointTree_']['findOnPath'](_0x4e2279,(_0x371b68,_0x37cbce)=>Se(_0x37cbce));if(_0x2256ae&&!_0x3e0fcf){const _0x3d4462=_0x2f8a54['syncPointTree_']['subtree'](_0x4e2279);if(!_0x3d4462['isEmpty']()){const _0x11b9a8=Zu(_0x3d4462);for(let _0xe478b1=0x0;_0xe478b1<_0x11b9a8['length'];++_0xe478b1){const _0x2ea82f=_0x11b9a8[_0xe478b1],_0x5db302=_0x2ea82f['query'],_0x485cbb=ea(_0x2f8a54,_0x2ea82f);_0x2f8a54['listenProvider_']['startListening'](kt(_0x5db302),Wt(_0x2f8a54,_0x5db302),_0x485cbb['hashFn'],_0x485cbb['onComplete']);}}}!_0x3e0fcf&&_0x49953d['length']>0x0&&!_0xae8a54&&(_0x2256ae?_0x2f8a54['listenProvider_']['stopListening'](kt(_0x491cef),null):_0x49953d['forEach'](_0x1af4cc=>{const _0x25c328=_0x2f8a54['queryToTagMap']['get'](Hn(_0x1af4cc));_0x2f8a54['listenProvider_']['stopListening'](kt(_0x1af4cc),_0x25c328);}));}ed(_0x2f8a54,_0x49953d);}return _0x4432ad;}function Jo(_0x5960e3,_0x4710df,_0x5e43ad,_0x51f51c){const _0x65339d=cs(_0x5960e3,_0x51f51c);if(_0x65339d!=null){const _0x777996=ls(_0x65339d),_0x4083ce=_0x777996['path'],_0x34a206=_0x777996['queryId'],_0x2e2fe6=F(_0x4083ce,_0x4710df),_0x1dfbd8=new Be(ns(_0x34a206),_0x2e2fe6,_0x5e43ad);return hs(_0x5960e3,_0x4083ce,_0x1dfbd8);}else return[];}function Ju(_0x38389a,_0x12fae6,_0x50f677,_0x59c08a){const _0x380d29=cs(_0x38389a,_0x59c08a);if(_0x380d29){const _0x3c7e4b=ls(_0x380d29),_0x1150bc=_0x3c7e4b['path'],_0x43d14c=_0x3c7e4b['queryId'],_0x5a4ed7=F(_0x1150bc,_0x12fae6),_0x3e0e61=b['fromObject'](_0x50f677),_0x230d98=new ot(ns(_0x43d14c),_0x5a4ed7,_0x3e0e61);return hs(_0x38389a,_0x1150bc,_0x230d98);}else return[];}function Ni(_0x109480,_0x42ec91,_0xd47993,_0x26e105=!0x1){const _0x378815=_0x42ec91['_path'];let _0x42a132=null,_0x51dd1d=!0x1;_0x109480['syncPointTree_']['foreachOnPath'](_0x378815,(_0x5a5090,_0x4e355d)=>{const _0x247a21=F(_0x5a5090,_0x378815);_0x42a132=_0x42a132||Ie(_0x4e355d,_0x247a21),_0x51dd1d=_0x51dd1d||Se(_0x4e355d);});let _0x4ecd17=_0x109480['syncPointTree_']['get'](_0x378815);_0x4ecd17?(_0x51dd1d=_0x51dd1d||Se(_0x4ecd17),_0x42a132=_0x42a132||Ie(_0x4ecd17,w())):(_0x4ecd17=new zo(),_0x109480['syncPointTree_']=_0x109480['syncPointTree_']['set'](_0x378815,_0x4ecd17));let _0x353b84;_0x42a132!=null?_0x353b84=!0x0:(_0x353b84=!0x1,_0x42a132=g['EMPTY_NODE'],_0x109480['syncPointTree_']['subtree'](_0x378815)['foreachChild']((_0x5270b7,_0x24fee8)=>{const _0x486d55=Ie(_0x24fee8,w());_0x486d55&&(_0x42a132=_0x42a132['updateImmediateChild'](_0x5270b7,_0x486d55));}));const _0x2db6d4=Qo(_0x4ecd17,_0x42ec91);if(!_0x2db6d4&&!_0x42ec91['_queryParams']['loadsAllData']()){const _0x42643f=Hn(_0x42ec91);f(!_0x109480['queryToTagMap']['has'](_0x42643f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x235be8=td();_0x109480['queryToTagMap']['set'](_0x42643f,_0x235be8),_0x109480['tagToQueryMap']['set'](_0x235be8,_0x42643f);}const _0x2065db=Wn(_0x109480['pendingWriteTree_'],_0x378815);let _0x3df7c1=Hu(_0x4ecd17,_0x42ec91,_0xd47993,_0x2065db,_0x42a132,_0x353b84);if(!_0x2db6d4&&!_0x51dd1d&&!_0x26e105){const _0x3474ad=Yo(_0x4ecd17,_0x42ec91);_0x3df7c1=_0x3df7c1['concat'](nd(_0x109480,_0x42ec91,_0x3474ad));}return _0x3df7c1;}function Vn(_0x443ca7,_0x22bd7b,_0x212624){const _0x187b0d=_0x443ca7['pendingWriteTree_'],_0x508bb1=_0x443ca7['syncPointTree_']['findOnPath'](_0x22bd7b,(_0x507730,_0x37bb2f)=>{const _0x175f50=F(_0x507730,_0x22bd7b),_0x29e3eb=Ie(_0x37bb2f,_0x175f50);if(_0x29e3eb)return _0x29e3eb;});return Bo(_0x187b0d,_0x22bd7b,_0x508bb1,_0x212624,!0x0);}function Xu(_0x19ead2,_0x338394){const _0x4472b4=_0x338394['_path'];let _0x34b291=null;_0x19ead2['syncPointTree_']['foreachOnPath'](_0x4472b4,(_0x24e7d6,_0x2eac81)=>{const _0x177645=F(_0x24e7d6,_0x4472b4);_0x34b291=_0x34b291||Ie(_0x2eac81,_0x177645);});let _0x1c0b17=_0x19ead2['syncPointTree_']['get'](_0x4472b4);_0x1c0b17?_0x34b291=_0x34b291||Ie(_0x1c0b17,w()):(_0x1c0b17=new zo(),_0x19ead2['syncPointTree_']=_0x19ead2['syncPointTree_']['set'](_0x4472b4,_0x1c0b17));const _0x2d610f=_0x34b291!=null,_0x35000c=_0x2d610f?new Te(_0x34b291,!0x0,!0x1):null,_0x55c75d=Wn(_0x19ead2['pendingWriteTree_'],_0x338394['_path']),_0x3d4879=jo(_0x1c0b17,_0x338394,_0x55c75d,_0x2d610f?_0x35000c['getNode']():g['EMPTY_NODE'],_0x2d610f);return Lu(_0x3d4879);}function _t(_0x17eb22,_0x49ca34){return Xo(_0x49ca34,_0x17eb22['syncPointTree_'],null,Wn(_0x17eb22['pendingWriteTree_'],w()));}function Xo(_0x2d1670,_0x570137,_0x178010,_0x5b5dd3){if(v(_0x2d1670['path']))return Zo(_0x2d1670,_0x570137,_0x178010,_0x5b5dd3);{const _0x477e87=_0x570137['get'](w());_0x178010==null&&_0x477e87!=null&&(_0x178010=Ie(_0x477e87,w()));let _0x29c847=[];const _0x3999dc=y(_0x2d1670['path']),_0x483059=_0x2d1670['operationForChild'](_0x3999dc),_0x349696=_0x570137['children']['get'](_0x3999dc);if(_0x349696&&_0x483059){const _0x446efb=_0x178010?_0x178010['getImmediateChild'](_0x3999dc):null,_0x4370c2=Vo(_0x5b5dd3,_0x3999dc);_0x29c847=_0x29c847['concat'](Xo(_0x483059,_0x349696,_0x446efb,_0x4370c2));}return _0x477e87&&(_0x29c847=_0x29c847['concat'](os(_0x477e87,_0x2d1670,_0x5b5dd3,_0x178010))),_0x29c847;}}function Zo(_0x42b110,_0x3940ed,_0x2c4702,_0x2e7ec1){const _0x14903a=_0x3940ed['get'](w());_0x2c4702==null&&_0x14903a!=null&&(_0x2c4702=Ie(_0x14903a,w()));let _0x5a2e41=[];return _0x3940ed['children']['inorderTraversal']((_0x3a4456,_0x1579ed)=>{const _0x98345d=_0x2c4702?_0x2c4702['getImmediateChild'](_0x3a4456):null,_0x5458e1=Vo(_0x2e7ec1,_0x3a4456),_0x172370=_0x42b110['operationForChild'](_0x3a4456);_0x172370&&(_0x5a2e41=_0x5a2e41['concat'](Zo(_0x172370,_0x1579ed,_0x98345d,_0x5458e1)));}),_0x14903a&&(_0x5a2e41=_0x5a2e41['concat'](os(_0x14903a,_0x42b110,_0x2e7ec1,_0x2c4702))),_0x5a2e41;}function ea(_0xa0d4bc,_0x1a8e22){const _0x32fd9a=_0x1a8e22['query'],_0xfb1397=Wt(_0xa0d4bc,_0x32fd9a);return{'hashFn':()=>(Mu(_0x1a8e22)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1cf397=>{if(_0x1cf397==='ok')return _0xfb1397?Qu(_0xa0d4bc,_0x32fd9a['_path'],_0xfb1397):Yu(_0xa0d4bc,_0x32fd9a['_path']);{const _0x2a828c=Kl(_0x1cf397,_0x32fd9a);return An(_0xa0d4bc,_0x32fd9a,null,_0x2a828c);}}};}function Wt(_0x53d738,_0x609898){const _0x1ca483=Hn(_0x609898);return _0x53d738['queryToTagMap']['get'](_0x1ca483);}function Hn(_0x315916){return _0x315916['_path']['toString']()+'$'+_0x315916['_queryIdentifier'];}function cs(_0xb7805a,_0x2b97b7){return _0xb7805a['tagToQueryMap']['get'](_0x2b97b7);}function ls(_0x53316a){const _0x4469cb=_0x53316a['indexOf']('$');return f(_0x4469cb!==-0x1&&_0x4469cb<_0x53316a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x53316a['substr'](_0x4469cb+0x1),'path':new C(_0x53316a['substr'](0x0,_0x4469cb))};}function hs(_0x5871eb,_0x580d55,_0xb2fe7){const _0x17fb36=_0x5871eb['syncPointTree_']['get'](_0x580d55);f(_0x17fb36,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x50bf2d=Wn(_0x5871eb['pendingWriteTree_'],_0x580d55);return os(_0x17fb36,_0xb2fe7,_0x50bf2d,null);}function Zu(_0x188d1f){return _0x188d1f['fold']((_0x407e88,_0x23a8b6,_0xcdc58b)=>{if(_0x23a8b6&&Se(_0x23a8b6))return[Bn(_0x23a8b6)];{let _0x4c0e71=[];return _0x23a8b6&&(_0x4c0e71=Ko(_0x23a8b6)),x(_0xcdc58b,(_0x3b2468,_0x1142e3)=>{_0x4c0e71=_0x4c0e71['concat'](_0x1142e3);}),_0x4c0e71;}});}function kt(_0x4196cd){return _0x4196cd['_queryParams']['loadsAllData']()&&!_0x4196cd['_queryParams']['isDefault']()?new(qu())(_0x4196cd['_repo'],_0x4196cd['_path']):_0x4196cd;}function ed(_0x5b63c2,_0x439e5c){for(let _0x3b0e88=0x0;_0x3b0e88<_0x439e5c['length'];++_0x3b0e88){const _0x1a4df9=_0x439e5c[_0x3b0e88];if(!_0x1a4df9['_queryParams']['loadsAllData']()){const _0x51583d=Hn(_0x1a4df9),_0x1ec772=_0x5b63c2['queryToTagMap']['get'](_0x51583d);_0x5b63c2['queryToTagMap']['delete'](_0x51583d),_0x5b63c2['tagToQueryMap']['delete'](_0x1ec772);}}}function td(){return zu++;}function nd(_0x1b5845,_0x5978c2,_0x81a40d){const _0x5d4d8b=_0x5978c2['_path'],_0x26786a=Wt(_0x1b5845,_0x5978c2),_0x11c792=ea(_0x1b5845,_0x81a40d),_0x4bd809=_0x1b5845['listenProvider_']['startListening'](kt(_0x5978c2),_0x26786a,_0x11c792['hashFn'],_0x11c792['onComplete']),_0x2e8309=_0x1b5845['syncPointTree_']['subtree'](_0x5d4d8b);if(_0x26786a)f(!Se(_0x2e8309['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5726b3=_0x2e8309['fold']((_0x32cf75,_0x40bcdc,_0x22c766)=>{if(!v(_0x32cf75)&&_0x40bcdc&&Se(_0x40bcdc))return[Bn(_0x40bcdc)['query']];{let _0x532eae=[];return _0x40bcdc&&(_0x532eae=_0x532eae['concat'](Ko(_0x40bcdc)['map'](_0xbd4b82=>_0xbd4b82['query']))),x(_0x22c766,(_0x2f3533,_0x5bf32e)=>{_0x532eae=_0x532eae['concat'](_0x5bf32e);}),_0x532eae;}});for(let _0x46d6bb=0x0;_0x46d6bb<_0x5726b3['length'];++_0x46d6bb){const _0x5bf233=_0x5726b3[_0x46d6bb];_0x1b5845['listenProvider_']['stopListening'](kt(_0x5bf233),Wt(_0x1b5845,_0x5bf233));}}return _0x4bd809;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x5e98e9){this['node_']=_0x5e98e9;}['getImmediateChild'](_0x2eb21f){const _0x36f45c=this['node_']['getImmediateChild'](_0x2eb21f);return new us(_0x36f45c);}['node'](){return this['node_'];}}class ds{constructor(_0x17eec1,_0xcc4129){this['syncTree_']=_0x17eec1,this['path_']=_0xcc4129;}['getImmediateChild'](_0x30104e){const _0x393c38=k(this['path_'],_0x30104e);return new ds(this['syncTree_'],_0x393c38);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x14e359){return _0x14e359=_0x14e359||{},_0x14e359['timestamp']=_0x14e359['timestamp']||new Date()['getTime'](),_0x14e359;},_r=function(_0x27ecd3,_0x21d064,_0x15c32b){if(!_0x27ecd3||typeof _0x27ecd3!='object')return _0x27ecd3;if(f('.sv'in _0x27ecd3,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x27ecd3['.sv']=='string')return sd(_0x27ecd3['.sv'],_0x21d064,_0x15c32b);if(typeof _0x27ecd3['.sv']=='object')return rd(_0x27ecd3['.sv'],_0x21d064);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x27ecd3,null,0x2));},sd=function(_0x573a30,_0x21a3f7,_0x40f162){switch(_0x573a30){case'timestamp':return _0x40f162['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x573a30);}},rd=function(_0x2c7b94,_0x2ce02c,_0x252d3d){_0x2c7b94['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2c7b94,null,0x2));const _0x3f85fa=_0x2c7b94['increment'];typeof _0x3f85fa!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3f85fa);const _0xd23e05=_0x2ce02c['node']();if(f(_0xd23e05!==null&&typeof _0xd23e05<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xd23e05['isLeafNode']())return _0x3f85fa;const _0x263f21=_0xd23e05['getValue']();return typeof _0x263f21!='number'?_0x3f85fa:_0x263f21+_0x3f85fa;},ta=function(_0x3521a2,_0x1c2253,_0x1fc6e2,_0x204173){return ps(_0x1c2253,new ds(_0x1fc6e2,_0x3521a2),_0x204173);},fs=function(_0x4d30a6,_0x5107f1,_0x480b6b){return ps(_0x4d30a6,new us(_0x5107f1),_0x480b6b);};function ps(_0x46f688,_0x213518,_0x5e7233){const _0x5ee61a=_0x46f688['getPriority']()['val'](),_0x1b6e6b=_r(_0x5ee61a,_0x213518['getImmediateChild']('.priority'),_0x5e7233);let _0x1951d5;if(_0x46f688['isLeafNode']()){const _0x2c3d32=_0x46f688,_0x2e77b6=_r(_0x2c3d32['getValue'](),_0x213518,_0x5e7233);return _0x2e77b6!==_0x2c3d32['getValue']()||_0x1b6e6b!==_0x2c3d32['getPriority']()['val']()?new D(_0x2e77b6,A(_0x1b6e6b)):_0x46f688;}else{const _0x35569b=_0x46f688;return _0x1951d5=_0x35569b,_0x1b6e6b!==_0x35569b['getPriority']()['val']()&&(_0x1951d5=_0x1951d5['updatePriority'](new D(_0x1b6e6b))),_0x35569b['forEachChild'](R,(_0x135047,_0xff46f0)=>{const _0x26373e=ps(_0xff46f0,_0x213518['getImmediateChild'](_0x135047),_0x5e7233);_0x26373e!==_0xff46f0&&(_0x1951d5=_0x1951d5['updateImmediateChild'](_0x135047,_0x26373e));}),_0x1951d5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x377e7d='',_0x38a7f0=null,_0x507624={'children':{},'childCount':0x0}){this['name']=_0x377e7d,this['parent']=_0x38a7f0,this['node']=_0x507624;}}function $n(_0x4645da,_0x2840de){let _0x26a760=_0x2840de instanceof C?_0x2840de:new C(_0x2840de),_0x25a487=_0x4645da,_0x19a23c=y(_0x26a760);for(;_0x19a23c!==null;){const _0x39eeb2=Le(_0x25a487['node']['children'],_0x19a23c)||{'children':{},'childCount':0x0};_0x25a487=new _s(_0x19a23c,_0x25a487,_0x39eeb2),_0x26a760=S(_0x26a760),_0x19a23c=y(_0x26a760);}return _0x25a487;}function je(_0x11d6eb){return _0x11d6eb['node']['value'];}function gs(_0x36ce55,_0x39ccd1){_0x36ce55['node']['value']=_0x39ccd1,Oi(_0x36ce55);}function na(_0x4611ff){return _0x4611ff['node']['childCount']>0x0;}function od(_0x144c52){return je(_0x144c52)===void 0x0&&!na(_0x144c52);}function Gn(_0xf4be7e,_0xfbb730){x(_0xf4be7e['node']['children'],(_0x15c924,_0x5623e9)=>{_0xfbb730(new _s(_0x15c924,_0xf4be7e,_0x5623e9));});}function ia(_0x1533ce,_0x2fa376,_0x50482f,_0x44155b){_0x50482f&&_0x2fa376(_0x1533ce),Gn(_0x1533ce,_0x3a6ace=>{ia(_0x3a6ace,_0x2fa376,!0x0);});}function ad(_0x588fa9,_0x85a412,_0x282240){let _0xdba295=_0x588fa9['parent'];for(;_0xdba295!==null;){if(_0x85a412(_0xdba295))return!0x0;_0xdba295=_0xdba295['parent'];}return!0x1;}function Qt(_0x35f1c5){return new C(_0x35f1c5['parent']===null?_0x35f1c5['name']:Qt(_0x35f1c5['parent'])+'/'+_0x35f1c5['name']);}function Oi(_0x33538f){_0x33538f['parent']!==null&&cd(_0x33538f['parent'],_0x33538f['name'],_0x33538f);}function cd(_0x1aa772,_0x2e0e59,_0x18584a){const _0x1c151b=od(_0x18584a),_0x12d670=Q(_0x1aa772['node']['children'],_0x2e0e59);_0x1c151b&&_0x12d670?(delete _0x1aa772['node']['children'][_0x2e0e59],_0x1aa772['node']['childCount']--,Oi(_0x1aa772)):!_0x1c151b&&!_0x12d670&&(_0x1aa772['node']['children'][_0x2e0e59]=_0x18584a['node'],_0x1aa772['node']['childCount']++,Oi(_0x1aa772));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0xa22821){return typeof _0xa22821=='string'&&_0xa22821['length']!==0x0&&!ld['test'](_0xa22821);},sa=function(_0x1c9d13){return typeof _0x1c9d13=='string'&&_0x1c9d13['length']!==0x0&&!hd['test'](_0x1c9d13);},ud=function(_0x5ecad4){return _0x5ecad4&&(_0x5ecad4=_0x5ecad4['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x5ecad4);},Bt=function(_0x1bfa5b){return _0x1bfa5b===null||typeof _0x1bfa5b=='string'||typeof _0x1bfa5b=='number'&&!xn(_0x1bfa5b)||_0x1bfa5b&&typeof _0x1bfa5b=='object'&&Q(_0x1bfa5b,'.sv');},He=function(_0x115fc9,_0x401022,_0x31b50e,_0x9ed732){_0x9ed732&&_0x401022===void 0x0||Jt(it(_0x115fc9,'value'),_0x401022,_0x31b50e);},Jt=function(_0x4225f4,_0x38927e,_0x3bb65d){const _0x3cfad5=_0x3bb65d instanceof C?new Ah(_0x3bb65d,_0x4225f4):_0x3bb65d;if(_0x38927e===void 0x0)throw new Error(_0x4225f4+'contains\x20undefined\x20'+Oe(_0x3cfad5));if(typeof _0x38927e=='function')throw new Error(_0x4225f4+'contains\x20a\x20function\x20'+Oe(_0x3cfad5)+'\x20with\x20contents\x20=\x20'+_0x38927e['toString']());if(xn(_0x38927e))throw new Error(_0x4225f4+'contains\x20'+_0x38927e['toString']()+'\x20'+Oe(_0x3cfad5));if(typeof _0x38927e=='string'&&_0x38927e['length']>ui/0x3&&Ln(_0x38927e)>ui)throw new Error(_0x4225f4+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x3cfad5)+'\x20(\x27'+_0x38927e['substring'](0x0,0x32)+'...\x27)');if(_0x38927e&&typeof _0x38927e=='object'){let _0x45e0c6=!0x1,_0x524ede=!0x1;if(x(_0x38927e,(_0x1d6c16,_0x1d920d)=>{if(_0x1d6c16==='.value')_0x45e0c6=!0x0;else{if(_0x1d6c16!=='.priority'&&_0x1d6c16!=='.sv'&&(_0x524ede=!0x0,!ms(_0x1d6c16)))throw new Error(_0x4225f4+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1d6c16+')\x20'+Oe(_0x3cfad5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3cfad5,_0x1d6c16),Jt(_0x4225f4,_0x1d920d,_0x3cfad5),Ph(_0x3cfad5);}),_0x45e0c6&&_0x524ede)throw new Error(_0x4225f4+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x3cfad5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x56dd03,_0x22fd94){let _0x46ad5d,_0xe5f44f;for(_0x46ad5d=0x0;_0x46ad5d<_0x22fd94['length'];_0x46ad5d++){_0xe5f44f=_0x22fd94[_0x46ad5d];const _0x310a44=Mt(_0xe5f44f);for(let _0x1fa0d1=0x0;_0x1fa0d1<_0x310a44['length'];_0x1fa0d1++)if(!(_0x310a44[_0x1fa0d1]==='.priority'&&_0x1fa0d1===_0x310a44['length']-0x1)){if(!ms(_0x310a44[_0x1fa0d1]))throw new Error(_0x56dd03+'contains\x20an\x20invalid\x20key\x20('+_0x310a44[_0x1fa0d1]+')\x20in\x20path\x20'+_0xe5f44f['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x22fd94['sort'](Rh);let _0x4d11bf=null;for(_0x46ad5d=0x0;_0x46ad5d<_0x22fd94['length'];_0x46ad5d++){if(_0xe5f44f=_0x22fd94[_0x46ad5d],_0x4d11bf!==null&&G(_0x4d11bf,_0xe5f44f))throw new Error(_0x56dd03+'contains\x20a\x20path\x20'+_0x4d11bf['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xe5f44f['toString']());_0x4d11bf=_0xe5f44f;}},ra=function(_0x55a7e8,_0x54eee8,_0x4b6fa3,_0x469a33){const _0x1e605f=it(_0x55a7e8,'values');if(!(_0x54eee8&&typeof _0x54eee8=='object')||Array['isArray'](_0x54eee8))throw new Error(_0x1e605f+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x262a73=[];x(_0x54eee8,(_0x19b410,_0x41b1a9)=>{const _0x2e3033=new C(_0x19b410);if(Jt(_0x1e605f,_0x41b1a9,k(_0x4b6fa3,_0x2e3033)),ji(_0x2e3033)==='.priority'&&!Bt(_0x41b1a9))throw new Error(_0x1e605f+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2e3033['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x262a73['push'](_0x2e3033);}),dd(_0x1e605f,_0x262a73);},fd=function(_0x1a6d67,_0x1e0cea,_0x354c93){if(xn(_0x1e0cea))throw new Error(it(_0x1a6d67,'priority')+'is\x20'+_0x1e0cea['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1e0cea))throw new Error(it(_0x1a6d67,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x48c2bd,_0xeec109,_0x587ab3,_0x14a5f7){if(!sa(_0x587ab3))throw new Error(it(_0x48c2bd,_0xeec109)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x587ab3+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xf479fc,_0x2aa37a,_0x4d70ca,_0x296be3){_0x4d70ca&&(_0x4d70ca=_0x4d70ca['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xf479fc,_0x2aa37a,_0x4d70ca);},Me=function(_0x4f4b24,_0x137a8c){if(y(_0x137a8c)==='.info')throw new Error(_0x4f4b24+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x977f75,_0x1d10b2){const _0x189fdf=_0x1d10b2['path']['toString']();if(typeof _0x1d10b2['repoInfo']['host']!='string'||_0x1d10b2['repoInfo']['host']['length']===0x0||!ms(_0x1d10b2['repoInfo']['namespace'])&&_0x1d10b2['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x189fdf['length']!==0x0&&!ud(_0x189fdf))throw new Error(it(_0x977f75,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x486aae,_0x56e104){let _0x3842f8=null;for(let _0x13ce68=0x0;_0x13ce68<_0x56e104['length'];_0x13ce68++){const _0x49061a=_0x56e104[_0x13ce68],_0x16da68=_0x49061a['getPath']();_0x3842f8!==null&&!Ki(_0x16da68,_0x3842f8['path'])&&(_0x486aae['eventLists_']['push'](_0x3842f8),_0x3842f8=null),_0x3842f8===null&&(_0x3842f8={'events':[],'path':_0x16da68}),_0x3842f8['events']['push'](_0x49061a);}_0x3842f8&&_0x486aae['eventLists_']['push'](_0x3842f8);}function oa(_0x3eb1f3,_0x170fdc,_0x4f7a84){qn(_0x3eb1f3,_0x4f7a84),aa(_0x3eb1f3,_0x528eb0=>Ki(_0x528eb0,_0x170fdc));}function V(_0x43091f,_0x419883,_0x173c19){qn(_0x43091f,_0x173c19),aa(_0x43091f,_0x33a083=>G(_0x33a083,_0x419883)||G(_0x419883,_0x33a083));}function aa(_0x22db85,_0x58aed6){_0x22db85['recursionDepth_']++;let _0x4dcb4b=!0x0;for(let _0x5b72c3=0x0;_0x5b72c3<_0x22db85['eventLists_']['length'];_0x5b72c3++){const _0x5e8162=_0x22db85['eventLists_'][_0x5b72c3];if(_0x5e8162){const _0x2e1b89=_0x5e8162['path'];_0x58aed6(_0x2e1b89)?(md(_0x22db85['eventLists_'][_0x5b72c3]),_0x22db85['eventLists_'][_0x5b72c3]=null):_0x4dcb4b=!0x1;}}_0x4dcb4b&&(_0x22db85['eventLists_']=[]),_0x22db85['recursionDepth_']--;}function md(_0x5b6a66){for(let _0x273b2d=0x0;_0x273b2d<_0x5b6a66['events']['length'];_0x273b2d++){const _0x3fbb3e=_0x5b6a66['events'][_0x273b2d];if(_0x3fbb3e!==null){_0x5b6a66['events'][_0x273b2d]=null;const _0x2dc401=_0x3fbb3e['getEventRunner']();St&&L('event:\x20'+_0x3fbb3e['toString']()),ft(_0x2dc401);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1497d9,_0x2d5136,_0x121407,_0x550a55){this['repoInfo_']=_0x1497d9,this['forceRestClient_']=_0x2d5136,this['authTokenProvider_']=_0x121407,this['appCheckProvider_']=_0x550a55,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x5e679b,_0x5ad6ef,_0x2468e2){if(_0x5e679b['stats_']=qi(_0x5e679b['repoInfo_']),_0x5e679b['forceRestClient_']||Xl())_0x5e679b['server_']=new vn(_0x5e679b['repoInfo_'],(_0x1fa09a,_0x2e944b,_0x4731e2,_0x3ab461)=>{gr(_0x5e679b,_0x1fa09a,_0x2e944b,_0x4731e2,_0x3ab461);},_0x5e679b['authTokenProvider_'],_0x5e679b['appCheckProvider_']),setTimeout(()=>mr(_0x5e679b,!0x0),0x0);else{if(typeof _0x2468e2<'u'&&_0x2468e2!==null){if(typeof _0x2468e2!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2468e2);}catch(_0x5b58f5){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5b58f5);}}_0x5e679b['persistentConnection_']=new se(_0x5e679b['repoInfo_'],_0x5ad6ef,(_0x3c64d9,_0x1cbf85,_0x2d7992,_0x5c1102)=>{gr(_0x5e679b,_0x3c64d9,_0x1cbf85,_0x2d7992,_0x5c1102);},_0xb558b5=>{mr(_0x5e679b,_0xb558b5);},_0x358522=>{Id(_0x5e679b,_0x358522);},_0x5e679b['authTokenProvider_'],_0x5e679b['appCheckProvider_'],_0x2468e2),_0x5e679b['server_']=_0x5e679b['persistentConnection_'];}_0x5e679b['authTokenProvider_']['addTokenChangeListener'](_0x1819b6=>{_0x5e679b['server_']['refreshAuthToken'](_0x1819b6);}),_0x5e679b['appCheckProvider_']['addTokenChangeListener'](_0xce581c=>{_0x5e679b['server_']['refreshAppCheckToken'](_0xce581c['token']);}),_0x5e679b['statsReporter_']=ih(_0x5e679b['repoInfo_'],()=>new iu(_0x5e679b['stats_'],_0x5e679b['server_'])),_0x5e679b['infoData_']=new Xh(),_0x5e679b['infoSyncTree_']=new pr({'startListening':(_0x31fba4,_0x70926c,_0x8b59fc,_0x1e4df3)=>{let _0x36b340=[];const _0x54802a=_0x5e679b['infoData_']['getNode'](_0x31fba4['_path']);return _0x54802a['isEmpty']()||(_0x36b340=Yt(_0x5e679b['infoSyncTree_'],_0x31fba4['_path'],_0x54802a),setTimeout(()=>{_0x1e4df3('ok');},0x0)),_0x36b340;},'stopListening':()=>{}}),vs(_0x5e679b,'connected',!0x1),_0x5e679b['serverSyncTree_']=new pr({'startListening':(_0x1d2b9f,_0x2b670d,_0x59bd5e,_0x293ba5)=>(_0x5e679b['server_']['listen'](_0x1d2b9f,_0x59bd5e,_0x2b670d,(_0x65ec5,_0x482970)=>{const _0x395412=_0x293ba5(_0x65ec5,_0x482970);V(_0x5e679b['eventQueue_'],_0x1d2b9f['_path'],_0x395412);}),[]),'stopListening':(_0x4109ac,_0x3da160)=>{_0x5e679b['server_']['unlisten'](_0x4109ac,_0x3da160);}});}function la(_0x507274){const _0x6f1abf=_0x507274['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x6f1abf;}function Xt(_0x1ee13e){return id({'timestamp':la(_0x1ee13e)});}function gr(_0x29d079,_0x36d686,_0x4638d0,_0x910d6a,_0x4cb9b9){_0x29d079['dataUpdateCount']++;const _0x4099d3=new C(_0x36d686);_0x4638d0=_0x29d079['interceptServerDataCallback_']?_0x29d079['interceptServerDataCallback_'](_0x36d686,_0x4638d0):_0x4638d0;let _0x335a97=[];if(_0x4cb9b9){if(_0x910d6a){const _0x2ea715=_n(_0x4638d0,_0xf5e876=>A(_0xf5e876));_0x335a97=Ju(_0x29d079['serverSyncTree_'],_0x4099d3,_0x2ea715,_0x4cb9b9);}else{const _0x3b0a2f=A(_0x4638d0);_0x335a97=Jo(_0x29d079['serverSyncTree_'],_0x4099d3,_0x3b0a2f,_0x4cb9b9);}}else{if(_0x910d6a){const _0x50f463=_n(_0x4638d0,_0x4cf5f9=>A(_0x4cf5f9));_0x335a97=Ku(_0x29d079['serverSyncTree_'],_0x4099d3,_0x50f463);}else{const _0xf8cfbc=A(_0x4638d0);_0x335a97=Yt(_0x29d079['serverSyncTree_'],_0x4099d3,_0xf8cfbc);}}let _0x5e4f40=_0x4099d3;_0x335a97['length']>0x0&&(_0x5e4f40=ct(_0x29d079,_0x4099d3)),V(_0x29d079['eventQueue_'],_0x5e4f40,_0x335a97);}function mr(_0xab3bd8,_0x1b0d26){vs(_0xab3bd8,'connected',_0x1b0d26),_0x1b0d26===!0x1&&Sd(_0xab3bd8);}function Id(_0x4fcdfe,_0x3de7c7){x(_0x3de7c7,(_0x3aa709,_0x1339e5)=>{vs(_0x4fcdfe,_0x3aa709,_0x1339e5);});}function vs(_0x27d9a2,_0x32de72,_0x588ad0){const _0x29c355=new C('/.info/'+_0x32de72),_0x15f959=A(_0x588ad0);_0x27d9a2['infoData_']['updateSnapshot'](_0x29c355,_0x15f959);const _0x315cf1=Yt(_0x27d9a2['infoSyncTree_'],_0x29c355,_0x15f959);V(_0x27d9a2['eventQueue_'],_0x29c355,_0x315cf1);}function zn(_0x10c48f){return _0x10c48f['nextWriteId_']++;}function wd(_0x14a257,_0xee63cf,_0x59259f){const _0x52f4e2=Xu(_0x14a257['serverSyncTree_'],_0xee63cf);return _0x52f4e2!=null?Promise['resolve'](_0x52f4e2):_0x14a257['server_']['get'](_0xee63cf)['then'](_0x52e48a=>{const _0x495f74=A(_0x52e48a)['withIndex'](_0xee63cf['_queryParams']['getIndex']());Ni(_0x14a257['serverSyncTree_'],_0xee63cf,_0x59259f,!0x0);let _0xf9765d;if(_0xee63cf['_queryParams']['loadsAllData']())_0xf9765d=Yt(_0x14a257['serverSyncTree_'],_0xee63cf['_path'],_0x495f74);else{const _0x2d72e5=Wt(_0x14a257['serverSyncTree_'],_0xee63cf);_0xf9765d=Jo(_0x14a257['serverSyncTree_'],_0xee63cf['_path'],_0x495f74,_0x2d72e5);}return V(_0x14a257['eventQueue_'],_0xee63cf['_path'],_0xf9765d),An(_0x14a257['serverSyncTree_'],_0xee63cf,_0x59259f,null,!0x0),_0x495f74;},_0x35c5a5=>(gt(_0x14a257,'get\x20for\x20query\x20'+O(_0xee63cf)+'\x20failed:\x20'+_0x35c5a5),Promise['reject'](new Error(_0x35c5a5))));}function Cd(_0xaa8081,_0x22c1b9,_0x9a43c6,_0x376a58,_0x328a9f){gt(_0xaa8081,'set',{'path':_0x22c1b9['toString'](),'value':_0x9a43c6,'priority':_0x376a58});const _0x2f8bd9=Xt(_0xaa8081),_0x4fe214=A(_0x9a43c6,_0x376a58),_0x27f62d=Vn(_0xaa8081['serverSyncTree_'],_0x22c1b9),_0x1d368f=fs(_0x4fe214,_0x27f62d,_0x2f8bd9),_0x3ceb03=zn(_0xaa8081),_0x4d2290=as(_0xaa8081['serverSyncTree_'],_0x22c1b9,_0x1d368f,_0x3ceb03,!0x0);qn(_0xaa8081['eventQueue_'],_0x4d2290),_0xaa8081['server_']['put'](_0x22c1b9['toString'](),_0x4fe214['val'](!0x0),(_0x3cf7e1,_0x5e146f)=>{const _0x13a093=_0x3cf7e1==='ok';_0x13a093||U('set\x20at\x20'+_0x22c1b9+'\x20failed:\x20'+_0x3cf7e1);const _0x3fc892=_e(_0xaa8081['serverSyncTree_'],_0x3ceb03,!_0x13a093);V(_0xaa8081['eventQueue_'],_0x22c1b9,_0x3fc892),be(_0xaa8081,_0x328a9f,_0x3cf7e1,_0x5e146f);});const _0x4454e3=Is(_0xaa8081,_0x22c1b9);ct(_0xaa8081,_0x4454e3),V(_0xaa8081['eventQueue_'],_0x4454e3,[]);}function Td(_0x8b9487,_0x1e334,_0x21da67,_0x3a19a7){gt(_0x8b9487,'update',{'path':_0x1e334['toString'](),'value':_0x21da67});let _0x3df0b2=!0x0;const _0x1eb205=Xt(_0x8b9487),_0x3768a4={};if(x(_0x21da67,(_0x1026c8,_0x8a62d3)=>{_0x3df0b2=!0x1,_0x3768a4[_0x1026c8]=ta(k(_0x1e334,_0x1026c8),A(_0x8a62d3),_0x8b9487['serverSyncTree_'],_0x1eb205);}),_0x3df0b2)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x8b9487,_0x3a19a7,'ok',void 0x0);else{const _0x3b85cd=zn(_0x8b9487),_0x58542c=ju(_0x8b9487['serverSyncTree_'],_0x1e334,_0x3768a4,_0x3b85cd);qn(_0x8b9487['eventQueue_'],_0x58542c),_0x8b9487['server_']['merge'](_0x1e334['toString'](),_0x21da67,(_0xf10494,_0x3e6c76)=>{const _0x1babe6=_0xf10494==='ok';_0x1babe6||U('update\x20at\x20'+_0x1e334+'\x20failed:\x20'+_0xf10494);const _0x436f11=_e(_0x8b9487['serverSyncTree_'],_0x3b85cd,!_0x1babe6),_0x470a96=_0x436f11['length']>0x0?ct(_0x8b9487,_0x1e334):_0x1e334;V(_0x8b9487['eventQueue_'],_0x470a96,_0x436f11),be(_0x8b9487,_0x3a19a7,_0xf10494,_0x3e6c76);}),x(_0x21da67,_0x15b2cc=>{const _0x27996d=Is(_0x8b9487,k(_0x1e334,_0x15b2cc));ct(_0x8b9487,_0x27996d);}),V(_0x8b9487['eventQueue_'],_0x1e334,[]);}}function Sd(_0xe3a46a){gt(_0xe3a46a,'onDisconnectEvents');const _0xc38be1=Xt(_0xe3a46a),_0xc109cc=En();Si(_0xe3a46a['onDisconnect_'],w(),(_0x498195,_0x4d721b)=>{const _0x53e13e=ta(_0x498195,_0x4d721b,_0xe3a46a['serverSyncTree_'],_0xc38be1);pt(_0xc109cc,_0x498195,_0x53e13e);});let _0x817ca3=[];Si(_0xc109cc,w(),(_0x129c67,_0x490fed)=>{_0x817ca3=_0x817ca3['concat'](Yt(_0xe3a46a['serverSyncTree_'],_0x129c67,_0x490fed));const _0x18fb74=Is(_0xe3a46a,_0x129c67);ct(_0xe3a46a,_0x18fb74);}),_0xe3a46a['onDisconnect_']=En(),V(_0xe3a46a['eventQueue_'],w(),_0x817ca3);}function bd(_0x31b1cc,_0x1ffc65,_0x43d865){_0x31b1cc['server_']['onDisconnectCancel'](_0x1ffc65['toString'](),(_0x36c1b4,_0x3cb931)=>{_0x36c1b4==='ok'&&Ti(_0x31b1cc['onDisconnect_'],_0x1ffc65),be(_0x31b1cc,_0x43d865,_0x36c1b4,_0x3cb931);});}function yr(_0x97cfc2,_0x38782b,_0x13928b,_0x18942f){const _0x18c29d=A(_0x13928b);_0x97cfc2['server_']['onDisconnectPut'](_0x38782b['toString'](),_0x18c29d['val'](!0x0),(_0x56cca4,_0x47b362)=>{_0x56cca4==='ok'&&pt(_0x97cfc2['onDisconnect_'],_0x38782b,_0x18c29d),be(_0x97cfc2,_0x18942f,_0x56cca4,_0x47b362);});}function Rd(_0x29790e,_0x228c1c,_0x13ee50,_0x537d2b,_0x318962){const _0x21ecb5=A(_0x13ee50,_0x537d2b);_0x29790e['server_']['onDisconnectPut'](_0x228c1c['toString'](),_0x21ecb5['val'](!0x0),(_0x4d8852,_0x59c0f5)=>{_0x4d8852==='ok'&&pt(_0x29790e['onDisconnect_'],_0x228c1c,_0x21ecb5),be(_0x29790e,_0x318962,_0x4d8852,_0x59c0f5);});}function Ad(_0x4ffd54,_0x41ae27,_0xa07e0f,_0x178861){if(pn(_0xa07e0f)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4ffd54,_0x178861,'ok',void 0x0);return;}_0x4ffd54['server_']['onDisconnectMerge'](_0x41ae27['toString'](),_0xa07e0f,(_0x46bcb8,_0x460e39)=>{_0x46bcb8==='ok'&&x(_0xa07e0f,(_0x783228,_0x2a5c04)=>{const _0x47c56d=A(_0x2a5c04);pt(_0x4ffd54['onDisconnect_'],k(_0x41ae27,_0x783228),_0x47c56d);}),be(_0x4ffd54,_0x178861,_0x46bcb8,_0x460e39);});}function kd(_0x4c72a5,_0x5add80,_0x2b4cd4){let _0x5ee69a;y(_0x5add80['_path'])==='.info'?_0x5ee69a=Ni(_0x4c72a5['infoSyncTree_'],_0x5add80,_0x2b4cd4):_0x5ee69a=Ni(_0x4c72a5['serverSyncTree_'],_0x5add80,_0x2b4cd4),oa(_0x4c72a5['eventQueue_'],_0x5add80['_path'],_0x5ee69a);}function Pd(_0x4b5140,_0x402cd7,_0x5bf684){let _0x242108;y(_0x402cd7['_path'])==='.info'?_0x242108=An(_0x4b5140['infoSyncTree_'],_0x402cd7,_0x5bf684):_0x242108=An(_0x4b5140['serverSyncTree_'],_0x402cd7,_0x5bf684),oa(_0x4b5140['eventQueue_'],_0x402cd7['_path'],_0x242108);}function ha(_0x43a3b7){_0x43a3b7['persistentConnection_']&&_0x43a3b7['persistentConnection_']['interrupt'](ca);}function Nd(_0x41d589){_0x41d589['persistentConnection_']&&_0x41d589['persistentConnection_']['resume'](ca);}function gt(_0xf81953,..._0xeb285){let _0x27db07='';_0xf81953['persistentConnection_']&&(_0x27db07=_0xf81953['persistentConnection_']['id']+':'),L(_0x27db07,..._0xeb285);}function be(_0x2e34fb,_0x261e41,_0x548b48,_0x222c82){_0x261e41&&ft(()=>{if(_0x548b48==='ok')_0x261e41(null);else{const _0x30ddf9=(_0x548b48||'error')['toUpperCase']();let _0x1886b3=_0x30ddf9;_0x222c82&&(_0x1886b3+=':\x20'+_0x222c82);const _0x366df5=new Error(_0x1886b3);_0x366df5['code']=_0x30ddf9,_0x261e41(_0x366df5);}});}function Od(_0x5dfd70,_0x377845,_0x45ba6c,_0x4b76ed,_0x56275c,_0x4e9dce){gt(_0x5dfd70,'transaction\x20on\x20'+_0x377845);const _0x589aca={'path':_0x377845,'update':_0x45ba6c,'onComplete':_0x4b76ed,'status':null,'order':so(),'applyLocally':_0x4e9dce,'retryCount':0x0,'unwatcher':_0x56275c,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x266f13=Es(_0x5dfd70,_0x377845,void 0x0);_0x589aca['currentInputSnapshot']=_0x266f13;const _0x3a7ab2=_0x589aca['update'](_0x266f13['val']());if(_0x3a7ab2===void 0x0)_0x589aca['unwatcher'](),_0x589aca['currentOutputSnapshotRaw']=null,_0x589aca['currentOutputSnapshotResolved']=null,_0x589aca['onComplete']&&_0x589aca['onComplete'](null,!0x1,_0x589aca['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3a7ab2,_0x589aca['path']),_0x589aca['status']=0x0;const _0x57d789=$n(_0x5dfd70['transactionQueueTree_'],_0x377845),_0xde0d95=je(_0x57d789)||[];_0xde0d95['push'](_0x589aca),gs(_0x57d789,_0xde0d95);let _0x5be4da;typeof _0x3a7ab2=='object'&&_0x3a7ab2!==null&&Q(_0x3a7ab2,'.priority')?(_0x5be4da=Le(_0x3a7ab2,'.priority'),f(Bt(_0x5be4da),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5be4da=(Vn(_0x5dfd70['serverSyncTree_'],_0x377845)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x55401f=Xt(_0x5dfd70),_0x391587=A(_0x3a7ab2,_0x5be4da),_0x504bc8=fs(_0x391587,_0x266f13,_0x55401f);_0x589aca['currentOutputSnapshotRaw']=_0x391587,_0x589aca['currentOutputSnapshotResolved']=_0x504bc8,_0x589aca['currentWriteId']=zn(_0x5dfd70);const _0x51cb2e=as(_0x5dfd70['serverSyncTree_'],_0x377845,_0x504bc8,_0x589aca['currentWriteId'],_0x589aca['applyLocally']);V(_0x5dfd70['eventQueue_'],_0x377845,_0x51cb2e),jn(_0x5dfd70,_0x5dfd70['transactionQueueTree_']);}}function Es(_0x3bbaf1,_0x48e893,_0x16c959){return Vn(_0x3bbaf1['serverSyncTree_'],_0x48e893,_0x16c959)||g['EMPTY_NODE'];}function jn(_0x5c346b,_0x4cdc1c=_0x5c346b['transactionQueueTree_']){if(_0x4cdc1c||Kn(_0x5c346b,_0x4cdc1c),je(_0x4cdc1c)){const _0x1e9199=da(_0x5c346b,_0x4cdc1c);f(_0x1e9199['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1e9199['every'](_0x5c89e7=>_0x5c89e7['status']===0x0)&&Dd(_0x5c346b,Qt(_0x4cdc1c),_0x1e9199);}else na(_0x4cdc1c)&&Gn(_0x4cdc1c,_0x3a67aa=>{jn(_0x5c346b,_0x3a67aa);});}function Dd(_0x8b97e,_0x503850,_0x455010){const _0x3f3b69=_0x455010['map'](_0xe4c32a=>_0xe4c32a['currentWriteId']),_0x2d4f25=Es(_0x8b97e,_0x503850,_0x3f3b69);let _0x10a8dd=_0x2d4f25;const _0x2dbd0f=_0x2d4f25['hash']();for(let _0x474909=0x0;_0x474909<_0x455010['length'];_0x474909++){const _0x3279b4=_0x455010[_0x474909];f(_0x3279b4['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3279b4['status']=0x1,_0x3279b4['retryCount']++;const _0x5228b9=F(_0x503850,_0x3279b4['path']);_0x10a8dd=_0x10a8dd['updateChild'](_0x5228b9,_0x3279b4['currentOutputSnapshotRaw']);}const _0x5c79f5=_0x10a8dd['val'](!0x0),_0x1cb0d6=_0x503850;_0x8b97e['server_']['put'](_0x1cb0d6['toString'](),_0x5c79f5,_0x138587=>{gt(_0x8b97e,'transaction\x20put\x20response',{'path':_0x1cb0d6['toString'](),'status':_0x138587});let _0x6ca2b3=[];if(_0x138587==='ok'){const _0x4edf11=[];for(let _0x344b4c=0x0;_0x344b4c<_0x455010['length'];_0x344b4c++)_0x455010[_0x344b4c]['status']=0x2,_0x6ca2b3=_0x6ca2b3['concat'](_e(_0x8b97e['serverSyncTree_'],_0x455010[_0x344b4c]['currentWriteId'])),_0x455010[_0x344b4c]['onComplete']&&_0x4edf11['push'](()=>_0x455010[_0x344b4c]['onComplete'](null,!0x0,_0x455010[_0x344b4c]['currentOutputSnapshotResolved'])),_0x455010[_0x344b4c]['unwatcher']();Kn(_0x8b97e,$n(_0x8b97e['transactionQueueTree_'],_0x503850)),jn(_0x8b97e,_0x8b97e['transactionQueueTree_']),V(_0x8b97e['eventQueue_'],_0x503850,_0x6ca2b3);for(let _0x398456=0x0;_0x398456<_0x4edf11['length'];_0x398456++)ft(_0x4edf11[_0x398456]);}else{if(_0x138587==='datastale'){for(let _0x3c2361=0x0;_0x3c2361<_0x455010['length'];_0x3c2361++)_0x455010[_0x3c2361]['status']===0x3?_0x455010[_0x3c2361]['status']=0x4:_0x455010[_0x3c2361]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1cb0d6['toString']()+'\x20failed:\x20'+_0x138587);for(let _0xb04999=0x0;_0xb04999<_0x455010['length'];_0xb04999++)_0x455010[_0xb04999]['status']=0x4,_0x455010[_0xb04999]['abortReason']=_0x138587;}ct(_0x8b97e,_0x503850);}},_0x2dbd0f);}function ct(_0x3a5259,_0x24ef94){const _0x2f05dd=ua(_0x3a5259,_0x24ef94),_0xf39ef5=Qt(_0x2f05dd),_0x11a24e=da(_0x3a5259,_0x2f05dd);return Md(_0x3a5259,_0x11a24e,_0xf39ef5),_0xf39ef5;}function Md(_0x48184f,_0xefe898,_0x174bb3){if(_0xefe898['length']===0x0)return;const _0x3fcc79=[];let _0x4f7f32=[];const _0x17bd51=_0xefe898['filter'](_0xae1077=>_0xae1077['status']===0x0)['map'](_0x15044a=>_0x15044a['currentWriteId']);for(let _0x2ad340=0x0;_0x2ad340<_0xefe898['length'];_0x2ad340++){const _0x2f7554=_0xefe898[_0x2ad340],_0x30ee3b=F(_0x174bb3,_0x2f7554['path']);let _0x27f489=!0x1,_0x42c59c;if(f(_0x30ee3b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2f7554['status']===0x4)_0x27f489=!0x0,_0x42c59c=_0x2f7554['abortReason'],_0x4f7f32=_0x4f7f32['concat'](_e(_0x48184f['serverSyncTree_'],_0x2f7554['currentWriteId'],!0x0));else{if(_0x2f7554['status']===0x0){if(_0x2f7554['retryCount']>=yd)_0x27f489=!0x0,_0x42c59c='maxretry',_0x4f7f32=_0x4f7f32['concat'](_e(_0x48184f['serverSyncTree_'],_0x2f7554['currentWriteId'],!0x0));else{const _0x28df44=Es(_0x48184f,_0x2f7554['path'],_0x17bd51);_0x2f7554['currentInputSnapshot']=_0x28df44;const _0x1c11f0=_0xefe898[_0x2ad340]['update'](_0x28df44['val']());if(_0x1c11f0!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1c11f0,_0x2f7554['path']);let _0x4f2ff6=A(_0x1c11f0);typeof _0x1c11f0=='object'&&_0x1c11f0!=null&&Q(_0x1c11f0,'.priority')||(_0x4f2ff6=_0x4f2ff6['updatePriority'](_0x28df44['getPriority']()));const _0x215683=_0x2f7554['currentWriteId'],_0xb7467a=Xt(_0x48184f),_0x4529d9=fs(_0x4f2ff6,_0x28df44,_0xb7467a);_0x2f7554['currentOutputSnapshotRaw']=_0x4f2ff6,_0x2f7554['currentOutputSnapshotResolved']=_0x4529d9,_0x2f7554['currentWriteId']=zn(_0x48184f),_0x17bd51['splice'](_0x17bd51['indexOf'](_0x215683),0x1),_0x4f7f32=_0x4f7f32['concat'](as(_0x48184f['serverSyncTree_'],_0x2f7554['path'],_0x4529d9,_0x2f7554['currentWriteId'],_0x2f7554['applyLocally'])),_0x4f7f32=_0x4f7f32['concat'](_e(_0x48184f['serverSyncTree_'],_0x215683,!0x0));}else _0x27f489=!0x0,_0x42c59c='nodata',_0x4f7f32=_0x4f7f32['concat'](_e(_0x48184f['serverSyncTree_'],_0x2f7554['currentWriteId'],!0x0));}}}V(_0x48184f['eventQueue_'],_0x174bb3,_0x4f7f32),_0x4f7f32=[],_0x27f489&&(_0xefe898[_0x2ad340]['status']=0x2,function(_0x37848a){setTimeout(_0x37848a,Math['floor'](0x0));}(_0xefe898[_0x2ad340]['unwatcher']),_0xefe898[_0x2ad340]['onComplete']&&(_0x42c59c==='nodata'?_0x3fcc79['push'](()=>_0xefe898[_0x2ad340]['onComplete'](null,!0x1,_0xefe898[_0x2ad340]['currentInputSnapshot'])):_0x3fcc79['push'](()=>_0xefe898[_0x2ad340]['onComplete'](new Error(_0x42c59c),!0x1,null))));}Kn(_0x48184f,_0x48184f['transactionQueueTree_']);for(let _0x497167=0x0;_0x497167<_0x3fcc79['length'];_0x497167++)ft(_0x3fcc79[_0x497167]);jn(_0x48184f,_0x48184f['transactionQueueTree_']);}function ua(_0xc3007a,_0xcc2e6e){let _0x8ced96,_0x11635b=_0xc3007a['transactionQueueTree_'];for(_0x8ced96=y(_0xcc2e6e);_0x8ced96!==null&&je(_0x11635b)===void 0x0;)_0x11635b=$n(_0x11635b,_0x8ced96),_0xcc2e6e=S(_0xcc2e6e),_0x8ced96=y(_0xcc2e6e);return _0x11635b;}function da(_0x57d56f,_0x2f2917){const _0x19735b=[];return fa(_0x57d56f,_0x2f2917,_0x19735b),_0x19735b['sort']((_0x25bdcb,_0x3352af)=>_0x25bdcb['order']-_0x3352af['order']),_0x19735b;}function fa(_0x3aed72,_0x308172,_0x28591e){const _0x3387ca=je(_0x308172);if(_0x3387ca){for(let _0x548f05=0x0;_0x548f05<_0x3387ca['length'];_0x548f05++)_0x28591e['push'](_0x3387ca[_0x548f05]);}Gn(_0x308172,_0x5029ea=>{fa(_0x3aed72,_0x5029ea,_0x28591e);});}function Kn(_0x23eb25,_0x50a034){const _0x5af6aa=je(_0x50a034);if(_0x5af6aa){let _0x1d1e58=0x0;for(let _0x35a9d6=0x0;_0x35a9d6<_0x5af6aa['length'];_0x35a9d6++)_0x5af6aa[_0x35a9d6]['status']!==0x2&&(_0x5af6aa[_0x1d1e58]=_0x5af6aa[_0x35a9d6],_0x1d1e58++);_0x5af6aa['length']=_0x1d1e58,gs(_0x50a034,_0x5af6aa['length']>0x0?_0x5af6aa:void 0x0);}Gn(_0x50a034,_0x4f9b88=>{Kn(_0x23eb25,_0x4f9b88);});}function Is(_0x9d8605,_0x453eb5){const _0x164ee7=Qt(ua(_0x9d8605,_0x453eb5)),_0x190ce9=$n(_0x9d8605['transactionQueueTree_'],_0x453eb5);return ad(_0x190ce9,_0xe425fa=>{di(_0x9d8605,_0xe425fa);}),di(_0x9d8605,_0x190ce9),ia(_0x190ce9,_0xcf145b=>{di(_0x9d8605,_0xcf145b);}),_0x164ee7;}function di(_0x7bf0d9,_0x32794e){const _0x3e0f7c=je(_0x32794e);if(_0x3e0f7c){const _0x3a32b6=[];let _0x516eac=[],_0xf945df=-0x1;for(let _0x1dd55f=0x0;_0x1dd55f<_0x3e0f7c['length'];_0x1dd55f++)_0x3e0f7c[_0x1dd55f]['status']===0x3||(_0x3e0f7c[_0x1dd55f]['status']===0x1?(f(_0xf945df===_0x1dd55f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xf945df=_0x1dd55f,_0x3e0f7c[_0x1dd55f]['status']=0x3,_0x3e0f7c[_0x1dd55f]['abortReason']='set'):(f(_0x3e0f7c[_0x1dd55f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3e0f7c[_0x1dd55f]['unwatcher'](),_0x516eac=_0x516eac['concat'](_e(_0x7bf0d9['serverSyncTree_'],_0x3e0f7c[_0x1dd55f]['currentWriteId'],!0x0)),_0x3e0f7c[_0x1dd55f]['onComplete']&&_0x3a32b6['push'](_0x3e0f7c[_0x1dd55f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xf945df===-0x1?gs(_0x32794e,void 0x0):_0x3e0f7c['length']=_0xf945df+0x1,V(_0x7bf0d9['eventQueue_'],Qt(_0x32794e),_0x516eac);for(let _0x1bd0b0=0x0;_0x1bd0b0<_0x3a32b6['length'];_0x1bd0b0++)ft(_0x3a32b6[_0x1bd0b0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3843df){let _0x5d0d99='';const _0x270d22=_0x3843df['split']('/');for(let _0x3b181f=0x0;_0x3b181f<_0x270d22['length'];_0x3b181f++)if(_0x270d22[_0x3b181f]['length']>0x0){let _0x144613=_0x270d22[_0x3b181f];try{_0x144613=decodeURIComponent(_0x144613['replace'](/\+/g,'\x20'));}catch{}_0x5d0d99+='/'+_0x144613;}return _0x5d0d99;}function xd(_0x3c6446){const _0x5e144b={};_0x3c6446['charAt'](0x0)==='?'&&(_0x3c6446=_0x3c6446['substring'](0x1));for(const _0x7321bc of _0x3c6446['split']('&')){if(_0x7321bc['length']===0x0)continue;const _0x4a52fd=_0x7321bc['split']('=');_0x4a52fd['length']===0x2?_0x5e144b[decodeURIComponent(_0x4a52fd[0x0])]=decodeURIComponent(_0x4a52fd[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x7321bc+'\x27\x20in\x20query\x20\x27'+_0x3c6446+'\x27');}return _0x5e144b;}const vr=function(_0x38aefd,_0x2e4d24){const _0x54d7f7=Fd(_0x38aefd),_0x225a97=_0x54d7f7['namespace'];_0x54d7f7['domain']==='firebase.com'&&ae(_0x54d7f7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x225a97||_0x225a97==='undefined')&&_0x54d7f7['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x54d7f7['secure']||$l();const _0x28baf5=_0x54d7f7['scheme']==='ws'||_0x54d7f7['scheme']==='wss';return{'repoInfo':new yo(_0x54d7f7['host'],_0x54d7f7['secure'],_0x225a97,_0x28baf5,_0x2e4d24,'',_0x225a97!==_0x54d7f7['subdomain']),'path':new C(_0x54d7f7['pathString'])};},Fd=function(_0x674c0a){let _0x47f352='',_0x2bc585='',_0x144698='',_0x4e8dc5='',_0x28cf0b='',_0x8f6254=!0x0,_0x68f397='https',_0xf079ee=0x1bb;if(typeof _0x674c0a=='string'){let _0x30f77b=_0x674c0a['indexOf']('//');_0x30f77b>=0x0&&(_0x68f397=_0x674c0a['substring'](0x0,_0x30f77b-0x1),_0x674c0a=_0x674c0a['substring'](_0x30f77b+0x2));let _0x188a1e=_0x674c0a['indexOf']('/');_0x188a1e===-0x1&&(_0x188a1e=_0x674c0a['length']);let _0x4f4138=_0x674c0a['indexOf']('?');_0x4f4138===-0x1&&(_0x4f4138=_0x674c0a['length']),_0x47f352=_0x674c0a['substring'](0x0,Math['min'](_0x188a1e,_0x4f4138)),_0x188a1e<_0x4f4138&&(_0x4e8dc5=Ld(_0x674c0a['substring'](_0x188a1e,_0x4f4138)));const _0x31ac70=xd(_0x674c0a['substring'](Math['min'](_0x674c0a['length'],_0x4f4138)));_0x30f77b=_0x47f352['indexOf'](':'),_0x30f77b>=0x0?(_0x8f6254=_0x68f397==='https'||_0x68f397==='wss',_0xf079ee=parseInt(_0x47f352['substring'](_0x30f77b+0x1),0xa)):_0x30f77b=_0x47f352['length'];const _0x47b50b=_0x47f352['slice'](0x0,_0x30f77b);if(_0x47b50b['toLowerCase']()==='localhost')_0x2bc585='localhost';else{if(_0x47b50b['split']('.')['length']<=0x2)_0x2bc585=_0x47b50b;else{const _0x47e3f0=_0x47f352['indexOf']('.');_0x144698=_0x47f352['substring'](0x0,_0x47e3f0)['toLowerCase'](),_0x2bc585=_0x47f352['substring'](_0x47e3f0+0x1),_0x28cf0b=_0x144698;}}'ns'in _0x31ac70&&(_0x28cf0b=_0x31ac70['ns']);}return{'host':_0x47f352,'port':_0xf079ee,'domain':_0x2bc585,'subdomain':_0x144698,'secure':_0x8f6254,'scheme':_0x68f397,'pathString':_0x4e8dc5,'namespace':_0x28cf0b};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x44d486=0x0;const _0x2eda84=[];return function(_0x39d912){const _0x4a1488=_0x39d912===_0x44d486;_0x44d486=_0x39d912;let _0x5510fc;const _0xb3a98f=new Array(0x8);for(_0x5510fc=0x7;_0x5510fc>=0x0;_0x5510fc--)_0xb3a98f[_0x5510fc]=Er['charAt'](_0x39d912%0x40),_0x39d912=Math['floor'](_0x39d912/0x40);f(_0x39d912===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x31ab5c=_0xb3a98f['join']('');if(_0x4a1488){for(_0x5510fc=0xb;_0x5510fc>=0x0&&_0x2eda84[_0x5510fc]===0x3f;_0x5510fc--)_0x2eda84[_0x5510fc]=0x0;_0x2eda84[_0x5510fc]++;}else{for(_0x5510fc=0x0;_0x5510fc<0xc;_0x5510fc++)_0x2eda84[_0x5510fc]=Math['floor'](Math['random']()*0x40);}for(_0x5510fc=0x0;_0x5510fc<0xc;_0x5510fc++)_0x31ab5c+=Er['charAt'](_0x2eda84[_0x5510fc]);return f(_0x31ab5c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x31ab5c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x175c4c,_0xc24ebc,_0x5e02cd,_0x183f7e){this['eventType']=_0x175c4c,this['eventRegistration']=_0xc24ebc,this['snapshot']=_0x5e02cd,this['prevName']=_0x183f7e;}['getPath'](){const _0x24151b=this['snapshot']['ref'];return this['eventType']==='value'?_0x24151b['_path']:_0x24151b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x3cd5c6,_0xbe172d,_0x45fdf6){this['eventRegistration']=_0x3cd5c6,this['error']=_0xbe172d,this['path']=_0x45fdf6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3c62fa,_0x172323){this['snapshotCallback']=_0x3c62fa,this['cancelCallback']=_0x172323;}['onValue'](_0x175d89,_0x411006){this['snapshotCallback']['call'](null,_0x175d89,_0x411006);}['onCancel'](_0x3ccb2c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3ccb2c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xc1848d){return this['snapshotCallback']===_0xc1848d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xc1848d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xc1848d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0xfad47b,_0x33581a){this['_repo']=_0xfad47b,this['_path']=_0x33581a;}['cancel'](){const _0x4826db=new H();return bd(this['_repo'],this['_path'],_0x4826db['wrapCallback'](()=>{})),_0x4826db['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x29bbb1=new H();return yr(this['_repo'],this['_path'],null,_0x29bbb1['wrapCallback'](()=>{})),_0x29bbb1['promise'];}['set'](_0x3c6124){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x3c6124,this['_path'],!0x1);const _0x51a941=new H();return yr(this['_repo'],this['_path'],_0x3c6124,_0x51a941['wrapCallback'](()=>{})),_0x51a941['promise'];}['setWithPriority'](_0x38dc9e,_0x10366d){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x38dc9e,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x10366d);const _0x17971a=new H();return Rd(this['_repo'],this['_path'],_0x38dc9e,_0x10366d,_0x17971a['wrapCallback'](()=>{})),_0x17971a['promise'];}['update'](_0x788dc9){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x788dc9,this['_path']);const _0x334d85=new H();return Ad(this['_repo'],this['_path'],_0x788dc9,_0x334d85['wrapCallback'](()=>{})),_0x334d85['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x305040,_0x14c113,_0x1510b7,_0x43bcb9){this['_repo']=_0x305040,this['_path']=_0x14c113,this['_queryParams']=_0x1510b7,this['_orderByCalled']=_0x43bcb9;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x76ad79=sr(this['_queryParams']),_0x12be32=$i(_0x76ad79);return _0x12be32==='{}'?'default':_0x12be32;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x48b1d7){if(_0x48b1d7=P(_0x48b1d7),!(_0x48b1d7 instanceof Ae))return!0x1;const _0x5d7422=this['_repo']===_0x48b1d7['_repo'],_0x4fe4ec=Ki(this['_path'],_0x48b1d7['_path']),_0x2a1d82=this['_queryIdentifier']===_0x48b1d7['_queryIdentifier'];return _0x5d7422&&_0x4fe4ec&&_0x2a1d82;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x405058,_0x5213b7){if(_0x405058['_orderByCalled']===!0x0)throw new Error(_0x5213b7+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x126977){let _0x22f2e6=null,_0x24f831=null;if(_0x126977['hasStart']()&&(_0x22f2e6=_0x126977['getIndexStartValue']()),_0x126977['hasEnd']()&&(_0x24f831=_0x126977['getIndexEndValue']()),_0x126977['getIndex']()===ve){const _0x42eec2='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2bea0f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x126977['hasStart']()){if(_0x126977['getIndexStartName']()!==We)throw new Error(_0x42eec2);if(typeof _0x22f2e6!='string')throw new Error(_0x2bea0f);}if(_0x126977['hasEnd']()){if(_0x126977['getIndexEndName']()!==we)throw new Error(_0x42eec2);if(typeof _0x24f831!='string')throw new Error(_0x2bea0f);}}else{if(_0x126977['getIndex']()===R){if(_0x22f2e6!=null&&!Bt(_0x22f2e6)||_0x24f831!=null&&!Bt(_0x24f831))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x126977['getIndex']()instanceof Ji||_0x126977['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x22f2e6!=null&&typeof _0x22f2e6=='object'||_0x24f831!=null&&typeof _0x24f831=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x412055){if(_0x412055['hasStart']()&&_0x412055['hasEnd']()&&_0x412055['hasLimit']()&&!_0x412055['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x3fa6ab,_0x1ecfd7){super(_0x3fa6ab,_0x1ecfd7,new Zi(),!0x1);}get['parent'](){const _0xff4e0e=Ro(this['_path']);return _0xff4e0e===null?null:new ee(this['_repo'],_0xff4e0e);}get['root'](){let _0x58f1bd=this;for(;_0x58f1bd['parent']!==null;)_0x58f1bd=_0x58f1bd['parent'];return _0x58f1bd;}}class lt{constructor(_0x1f737f,_0x35ade7,_0x21c56f){this['_node']=_0x1f737f,this['ref']=_0x35ade7,this['_index']=_0x21c56f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x94c737){const _0x52be4e=new C(_0x94c737),_0x37efb3=Vt(this['ref'],_0x94c737);return new lt(this['_node']['getChild'](_0x52be4e),_0x37efb3,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4790bd){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1bd16c,_0x53e93e)=>_0x4790bd(new lt(_0x53e93e,Vt(this['ref'],_0x1bd16c),R)));}['hasChild'](_0x373851){const _0x1f34c6=new C(_0x373851);return!this['_node']['getChild'](_0x1f34c6)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x47d337,_0x584e64){return _0x47d337=P(_0x47d337),_0x47d337['_checkNotDeleted']('ref'),_0x584e64!==void 0x0?Vt(_0x47d337['_root'],_0x584e64):_0x47d337['_root'];}function Vt(_0x1ba754,_0x24dc3b){return _0x1ba754=P(_0x1ba754),y(_0x1ba754['_path'])===null?pd('child','path',_0x24dc3b):ys('child','path',_0x24dc3b),new ee(_0x1ba754['_repo'],k(_0x1ba754['_path'],_0x24dc3b));}function v_(_0x18a767){return _0x18a767=P(_0x18a767),new Vd(_0x18a767['_repo'],_0x18a767['_path']);}function E_(_0x266a88,_0x583b88){_0x266a88=P(_0x266a88),Me('push',_0x266a88['_path']),He('push',_0x583b88,_0x266a88['_path'],!0x0);const _0x4eb401=la(_0x266a88['_repo']),_0x15169f=Ud(_0x4eb401),_0x1754b7=Vt(_0x266a88,_0x15169f),_0x43c5d0=Vt(_0x266a88,_0x15169f);let _0x426bb7;return _0x583b88!=null?_0x426bb7=Hd(_0x43c5d0,_0x583b88)['then'](()=>_0x43c5d0):_0x426bb7=Promise['resolve'](_0x43c5d0),_0x1754b7['then']=_0x426bb7['then']['bind'](_0x426bb7),_0x1754b7['catch']=_0x426bb7['then']['bind'](_0x426bb7,void 0x0),_0x1754b7;}function Hd(_0x54483f,_0x37a1c5){_0x54483f=P(_0x54483f),Me('set',_0x54483f['_path']),He('set',_0x37a1c5,_0x54483f['_path'],!0x1);const _0x48532=new H();return Cd(_0x54483f['_repo'],_0x54483f['_path'],_0x37a1c5,null,_0x48532['wrapCallback'](()=>{})),_0x48532['promise'];}function I_(_0x3dae62,_0x369805){ra('update',_0x369805,_0x3dae62['_path']);const _0x40aff5=new H();return Td(_0x3dae62['_repo'],_0x3dae62['_path'],_0x369805,_0x40aff5['wrapCallback'](()=>{})),_0x40aff5['promise'];}function w_(_0x5f3d65){_0x5f3d65=P(_0x5f3d65);const _0xc6095b=new pa(()=>{}),_0x4674dc=new Qn(_0xc6095b);return wd(_0x5f3d65['_repo'],_0x5f3d65,_0x4674dc)['then'](_0x52e6a5=>new lt(_0x52e6a5,new ee(_0x5f3d65['_repo'],_0x5f3d65['_path']),_0x5f3d65['_queryParams']['getIndex']()));}class Qn{constructor(_0x3afe4f){this['callbackContext']=_0x3afe4f;}['respondsTo'](_0x261d98){return _0x261d98==='value';}['createEvent'](_0x43296f,_0x545bd2){const _0x3af9c6=_0x545bd2['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x43296f['snapshotNode'],new ee(_0x545bd2['_repo'],_0x545bd2['_path']),_0x3af9c6));}['getEventRunner'](_0x5b67c4){return _0x5b67c4['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5b67c4['error']):()=>this['callbackContext']['onValue'](_0x5b67c4['snapshot'],null);}['createCancelEvent'](_0x3172f4,_0x4cc211){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x3172f4,_0x4cc211):null;}['matches'](_0x1dcd55){return _0x1dcd55 instanceof Qn?!_0x1dcd55['callbackContext']||!this['callbackContext']?!0x0:_0x1dcd55['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x50fa33,_0x2b8196,_0x5371f5,_0x348377,_0x464f09){const _0x50124b=new pa(_0x5371f5,void 0x0),_0x4bb594=new Qn(_0x50124b);return kd(_0x50fa33['_repo'],_0x50fa33,_0x4bb594),()=>Pd(_0x50fa33['_repo'],_0x50fa33,_0x4bb594);}function Gd(_0x53adba,_0xfc364c,_0x132865,_0x4d51d4){return $d(_0x53adba,'value',_0xfc364c);}class mt{}class ma extends mt{constructor(_0x54e7d2,_0x323338){super(),this['_value']=_0x54e7d2,this['_key']=_0x323338,this['type']='endAt';}['_apply'](_0x54bc41){He('endAt',this['_value'],_0x54bc41['_path'],!0x0);const _0x5b8c98=Jh(_0x54bc41['_queryParams'],this['_value'],this['_key']);if(ga(_0x5b8c98),Yn(_0x5b8c98),_0x54bc41['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x54bc41['_repo'],_0x54bc41['_path'],_0x5b8c98,_0x54bc41['_orderByCalled']);}}function C_(_0x3af648,_0x22c974){return new ma(_0x3af648,_0x22c974);}class ya extends mt{constructor(_0x474b3f,_0x496be9){super(),this['_value']=_0x474b3f,this['_key']=_0x496be9,this['type']='startAt';}['_apply'](_0x5668ed){He('startAt',this['_value'],_0x5668ed['_path'],!0x0);const _0xe5b438=Qh(_0x5668ed['_queryParams'],this['_value'],this['_key']);if(ga(_0xe5b438),Yn(_0xe5b438),_0x5668ed['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5668ed['_repo'],_0x5668ed['_path'],_0xe5b438,_0x5668ed['_orderByCalled']);}}function T_(_0x164820=null,_0x4782d4){return new ya(_0x164820,_0x4782d4);}class qd extends mt{constructor(_0x42b1b0){super(),this['_limit']=_0x42b1b0,this['type']='limitToFirst';}['_apply'](_0x12a1e0){if(_0x12a1e0['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x12a1e0['_repo'],_0x12a1e0['_path'],Yh(_0x12a1e0['_queryParams'],this['_limit']),_0x12a1e0['_orderByCalled']);}}function S_(_0x341837){if(Math['floor'](_0x341837)!==_0x341837||_0x341837<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x341837);}class zd extends mt{constructor(_0x43d47d){super(),this['_path']=_0x43d47d,this['type']='orderByChild';}['_apply'](_0x2ca886){_a(_0x2ca886,'orderByChild');const _0x38e91f=new C(this['_path']);if(v(_0x38e91f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x366a60=new Ji(_0x38e91f),_0x2974a8=xo(_0x2ca886['_queryParams'],_0x366a60);return Yn(_0x2974a8),new Ae(_0x2ca886['_repo'],_0x2ca886['_path'],_0x2974a8,!0x0);}}function b_(_0x1d3ac0){if(_0x1d3ac0==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1d3ac0==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1d3ac0==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x1d3ac0),new zd(_0x1d3ac0);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4e6777){_a(_0x4e6777,'orderByKey');const _0x454df7=xo(_0x4e6777['_queryParams'],ve);return Yn(_0x454df7),new Ae(_0x4e6777['_repo'],_0x4e6777['_path'],_0x454df7,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x510c5f,_0x385c41){super(),this['_value']=_0x510c5f,this['_key']=_0x385c41,this['type']='equalTo';}['_apply'](_0x5ef019){if(He('equalTo',this['_value'],_0x5ef019['_path'],!0x1),_0x5ef019['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5ef019['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x5ef019));}}function A_(_0x5338be,_0x4ff19f){return new Kd(_0x5338be,_0x4ff19f);}function k_(_0x2bc8c4,..._0x3efa0a){let _0x3b502a=P(_0x2bc8c4);for(const _0x4e7332 of _0x3efa0a)_0x3b502a=_0x4e7332['_apply'](_0x3b502a);return _0x3b502a;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x3b276b,_0x44971d,_0x516421,_0x158cff){const _0x3b4c97=_0x44971d['lastIndexOf'](':'),_0x24582d=_0x44971d['substring'](0x0,_0x3b4c97),_0x43a30c=qt(_0x24582d);_0x3b276b['repoInfo_']=new yo(_0x44971d,_0x43a30c,_0x3b276b['repoInfo_']['namespace'],_0x3b276b['repoInfo_']['webSocketOnly'],_0x3b276b['repoInfo_']['nodeAdmin'],_0x3b276b['repoInfo_']['persistenceKey'],_0x3b276b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x516421),_0x158cff&&(_0x3b276b['authTokenProvider_']=_0x158cff);}function Xd(_0x3d4faa,_0x2349e3,_0x54a619,_0x342e54,_0x105865){let _0x2a4e18=_0x342e54||_0x3d4faa['options']['databaseURL'];_0x2a4e18===void 0x0&&(_0x3d4faa['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3d4faa['options']['projectId']),_0x2a4e18=_0x3d4faa['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x38bbba=vr(_0x2a4e18,_0x105865),_0x180075=_0x38bbba['repoInfo'],_0x25a7ae;typeof process<'u'&&Bs&&(_0x25a7ae=Bs[Yd]),_0x25a7ae?(_0x2a4e18='http://'+_0x25a7ae+'?ns='+_0x180075['namespace'],_0x38bbba=vr(_0x2a4e18,_0x105865),_0x180075=_0x38bbba['repoInfo']):_0x38bbba['repoInfo']['secure'];const _0x2680e0=new eh(_0x3d4faa['name'],_0x3d4faa['options'],_0x2349e3);_d('Invalid\x20Firebase\x20Database\x20URL',_0x38bbba),v(_0x38bbba['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x106cb8=ef(_0x180075,_0x3d4faa,_0x2680e0,new Zl(_0x3d4faa,_0x54a619));return new tf(_0x106cb8,_0x3d4faa);}function Zd(_0x33160f,_0x4d9b04){const _0xfaae5b=Di[_0x4d9b04];(!_0xfaae5b||_0xfaae5b[_0x33160f['key']]!==_0x33160f)&&ae('Database\x20'+_0x4d9b04+'('+_0x33160f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x33160f),delete _0xfaae5b[_0x33160f['key']];}function ef(_0x194f49,_0x537fe5,_0x45619d,_0x124396){let _0xb5d786=Di[_0x537fe5['name']];_0xb5d786||(_0xb5d786={},Di[_0x537fe5['name']]=_0xb5d786);let _0x34f0f5=_0xb5d786[_0x194f49['toURLString']()];return _0x34f0f5&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x34f0f5=new vd(_0x194f49,Qd,_0x45619d,_0x124396),_0xb5d786[_0x194f49['toURLString']()]=_0x34f0f5,_0x34f0f5;}class tf{constructor(_0x140185,_0x239967){this['_repoInternal']=_0x140185,this['app']=_0x239967,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x33f3af){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x33f3af+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x5ec304=Zr(),_0x1d8216){const _0x344d20=Hi(_0x5ec304,'database')['getImmediate']({'identifier':_0x1d8216});if(!_0x344d20['_instanceStarted']){const _0x19d54c=hc('database');_0x19d54c&&nf(_0x344d20,..._0x19d54c);}return _0x344d20;}function nf(_0x542200,_0x18d0e5,_0x36862c,_0x4301a8={}){_0x542200=P(_0x542200),_0x542200['_checkNotDeleted']('useEmulator');const _0x12d7f2=_0x18d0e5+':'+_0x36862c,_0x191652=_0x542200['_repoInternal'];if(_0x542200['_instanceStarted']){if(_0x12d7f2===_0x542200['_repoInternal']['repoInfo_']['host']&&xe(_0x4301a8,_0x191652['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4c32a8;if(_0x191652['repoInfo_']['nodeAdmin'])_0x4301a8['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4c32a8=new an(an['OWNER']);else{if(_0x4301a8['mockUserToken']){const _0x214b28=typeof _0x4301a8['mockUserToken']=='string'?_0x4301a8['mockUserToken']:uc(_0x4301a8['mockUserToken'],_0x542200['app']['options']['projectId']);_0x4c32a8=new an(_0x214b28);}}qt(_0x18d0e5)&&Qr(_0x18d0e5),Jd(_0x191652,_0x12d7f2,_0x4301a8,_0x4c32a8);}function N_(_0x1d1e3f){_0x1d1e3f=P(_0x1d1e3f),_0x1d1e3f['_checkNotDeleted']('goOffline'),ha(_0x1d1e3f['_repo']);}function O_(_0x597a50){_0x597a50=P(_0x597a50),_0x597a50['_checkNotDeleted']('goOnline'),Nd(_0x597a50['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x2ec2cc){Ul(dt),st(new Fe('database',(_0x3b2219,{instanceIdentifier:_0x175e8a})=>{const _0x123e29=_0x3b2219['getProvider']('app')['getImmediate'](),_0x3df88c=_0x3b2219['getProvider']('auth-internal'),_0x1f9335=_0x3b2219['getProvider']('app-check-internal');return Xd(_0x123e29,_0x3df88c,_0x1f9335,_0x175e8a);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x2ec2cc),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x42b7b6,_0x2438bc){this['committed']=_0x42b7b6,this['snapshot']=_0x2438bc;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x379f12,_0x59e2a4,_0x132e15){if(_0x379f12=P(_0x379f12),Me('Reference.transaction',_0x379f12['_path']),_0x379f12['key']==='.length'||_0x379f12['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x379f12['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5315d2=!0x0,_0x2ad670=new H(),_0xcdfe6b=(_0x5e5031,_0x7bf3af,_0x241929)=>{let _0x5c0b92=null;_0x5e5031?_0x2ad670['reject'](_0x5e5031):(_0x5c0b92=new lt(_0x241929,new ee(_0x379f12['_repo'],_0x379f12['_path']),R),_0x2ad670['resolve'](new of(_0x7bf3af,_0x5c0b92)));},_0x4bac08=Gd(_0x379f12,()=>{});return Od(_0x379f12['_repo'],_0x379f12['_path'],_0x59e2a4,_0xcdfe6b,_0x4bac08,_0x5315d2),_0x2ad670['promise'];}se['prototype']['simpleListen']=function(_0x3369d3,_0x237b68){this['sendRequest']('q',{'p':_0x3369d3},_0x237b68);},se['prototype']['echo']=function(_0x4ce30f,_0x37fd7d){this['sendRequest']('echo',{'d':_0x4ce30f},_0x37fd7d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x6ef081,..._0x3bd838){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x6ef081,..._0x3bd838);}function cn(_0x14521a,..._0x2a5783){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x14521a,..._0x2a5783);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4ae59f,..._0x52a9ed){throw ws(_0x4ae59f,..._0x52a9ed);}function X(_0x330996,..._0x35016a){return ws(_0x330996,..._0x35016a);}function Ia(_0x10b314,_0x252ee0,_0x205246){const _0x53025f={...af(),[_0x252ee0]:_0x205246};return new Gt('auth','Firebase',_0x53025f)['create'](_0x252ee0,{'appName':_0x10b314['name']});}function re(_0xbd6e84){return Ia(_0xbd6e84,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x36348c,..._0x24d8b4){if(typeof _0x36348c!='string'){const _0x51de72=_0x24d8b4[0x0],_0x2843c2=[..._0x24d8b4['slice'](0x1)];return _0x2843c2[0x0]&&(_0x2843c2[0x0]['appName']=_0x36348c['name']),_0x36348c['_errorFactory']['create'](_0x51de72,..._0x2843c2);}return Ea['create'](_0x36348c,..._0x24d8b4);}function m(_0xe5bd1e,_0x41bce5,..._0x305b85){if(!_0xe5bd1e)throw ws(_0x41bce5,..._0x305b85);}function ne(_0x244af6){const _0x2aa2c5='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x244af6;throw cn(_0x2aa2c5),new Error(_0x2aa2c5);}function ce(_0x1e578d,_0x51a488){_0x1e578d||ne(_0x51a488);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0xd0fb;return typeof self<'u'&&((_0xd0fb=self['location'])==null?void 0x0:_0xd0fb['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5b73ea;return typeof self<'u'&&((_0x5b73ea=self['location'])==null?void 0x0:_0x5b73ea['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x61c15a=navigator;return _0x61c15a['languages']&&_0x61c15a['languages'][0x0]||_0x61c15a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x13efc8,_0x5cd4f3){this['shortDelay']=_0x13efc8,this['longDelay']=_0x5cd4f3,ce(_0x5cd4f3>_0x13efc8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2580b5,_0x2552c1){ce(_0x2580b5['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x120725}=_0x2580b5['emulator'];return _0x2552c1?''+_0x120725+(_0x2552c1['startsWith']('/')?_0x2552c1['slice'](0x1):_0x2552c1):_0x120725;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x97f0e6,_0x5a9bd0,_0x1e5b6e){this['fetchImpl']=_0x97f0e6,_0x5a9bd0&&(this['headersImpl']=_0x5a9bd0),_0x1e5b6e&&(this['responseImpl']=_0x1e5b6e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x9a0138,_0x593409){return _0x9a0138['tenantId']&&!_0x593409['tenantId']?{..._0x593409,'tenantId':_0x9a0138['tenantId']}:_0x593409;}async function Pe(_0x5918f9,_0x299a81,_0x48067b,_0x4c2306,_0x111c54={}){return Ca(_0x5918f9,_0x111c54,async()=>{let _0x432113={},_0x5b884e={};_0x4c2306&&(_0x299a81==='GET'?_0x5b884e=_0x4c2306:_0x432113={'body':JSON['stringify'](_0x4c2306)});const _0x18e4c0=ut({..._0x5b884e,'key':_0x5918f9['config']['apiKey']})['slice'](0x1),_0x141f6b=await _0x5918f9['_getAdditionalHeaders']();_0x141f6b['Content-Type']='application/json',_0x5918f9['languageCode']&&(_0x141f6b['X-Firebase-Locale']=_0x5918f9['languageCode']);const _0x138dcc={'method':_0x299a81,'headers':_0x141f6b,..._0x432113};return dc()||(_0x138dcc['referrerPolicy']='strict-origin-when-cross-origin'),_0x5918f9['emulatorConfig']&&qt(_0x5918f9['emulatorConfig']['host'])&&(_0x138dcc['credentials']='include'),wa['fetch']()(await Ta(_0x5918f9,_0x5918f9['config']['apiHost'],_0x48067b,_0x18e4c0),_0x138dcc);});}async function Ca(_0x219a2c,_0x4bb570,_0x5cbc8a){_0x219a2c['_canInitEmulator']=!0x1;const _0x38c66b={...df,..._0x4bb570};try{const _0xc0546f=new gf(_0x219a2c),_0x3c01e3=await Promise['race']([_0x5cbc8a(),_0xc0546f['promise']]);_0xc0546f['clearNetworkTimeout']();const _0x10257d=await _0x3c01e3['json']();if('needConfirmation'in _0x10257d)throw on(_0x219a2c,'account-exists-with-different-credential',_0x10257d);if(_0x3c01e3['ok']&&!('errorMessage'in _0x10257d))return _0x10257d;{const _0x131737=_0x3c01e3['ok']?_0x10257d['errorMessage']:_0x10257d['error']['message'],[_0x48fa18,_0x41fa43]=_0x131737['split']('\x20:\x20');if(_0x48fa18==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x219a2c,'credential-already-in-use',_0x10257d);if(_0x48fa18==='EMAIL_EXISTS')throw on(_0x219a2c,'email-already-in-use',_0x10257d);if(_0x48fa18==='USER_DISABLED')throw on(_0x219a2c,'user-disabled',_0x10257d);const _0x1c765a=_0x38c66b[_0x48fa18]||_0x48fa18['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x41fa43)throw Ia(_0x219a2c,_0x1c765a,_0x41fa43);Y(_0x219a2c,_0x1c765a);}}catch(_0x41d33d){if(_0x41d33d instanceof Re)throw _0x41d33d;Y(_0x219a2c,'network-request-failed',{'message':String(_0x41d33d)});}}async function en(_0x5ee787,_0x1b6ea2,_0x2dd543,_0x4d43b4,_0x239a2d={}){const _0xec943c=await Pe(_0x5ee787,_0x1b6ea2,_0x2dd543,_0x4d43b4,_0x239a2d);return'mfaPendingCredential'in _0xec943c&&Y(_0x5ee787,'multi-factor-auth-required',{'_serverResponse':_0xec943c}),_0xec943c;}async function Ta(_0x224600,_0x267980,_0x3e585d,_0x432770){const _0x14d26b=''+_0x267980+_0x3e585d+'?'+_0x432770,_0x1e4f7b=_0x224600,_0x18e723=_0x1e4f7b['config']['emulator']?Cs(_0x224600['config'],_0x14d26b):_0x224600['config']['apiScheme']+'://'+_0x14d26b;return ff['includes'](_0x3e585d)&&(await _0x1e4f7b['_persistenceManagerAvailable'],_0x1e4f7b['_getPersistenceType']()==='COOKIE')?_0x1e4f7b['_getPersistence']()['_getFinalTarget'](_0x18e723)['toString']():_0x18e723;}function _f(_0x52fd46){switch(_0x52fd46){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x357ddb){this['auth']=_0x357ddb,this['timer']=null,this['promise']=new Promise((_0x17de14,_0x4e6804)=>{this['timer']=setTimeout(()=>_0x4e6804(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0xa77925,_0x527fdf,_0x4b1ab8){const _0x1ba366={'appName':_0xa77925['name']};_0x4b1ab8['email']&&(_0x1ba366['email']=_0x4b1ab8['email']),_0x4b1ab8['phoneNumber']&&(_0x1ba366['phoneNumber']=_0x4b1ab8['phoneNumber']);const _0x2b988c=X(_0xa77925,_0x527fdf,_0x1ba366);return _0x2b988c['customData']['_tokenResponse']=_0x4b1ab8,_0x2b988c;}function wr(_0x1cdb00){return _0x1cdb00!==void 0x0&&_0x1cdb00['enterprise']!==void 0x0;}class mf{constructor(_0x1c0305){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1c0305['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1c0305['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1c0305['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x453c82){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x25e4a4 of this['recaptchaEnforcementState'])if(_0x25e4a4['provider']&&_0x25e4a4['provider']===_0x453c82)return _f(_0x25e4a4['enforcementState']);return null;}['isProviderEnabled'](_0x2ad9c7){return this['getProviderEnforcementState'](_0x2ad9c7)==='ENFORCE'||this['getProviderEnforcementState'](_0x2ad9c7)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x22504f,_0x57d2e5){return Pe(_0x22504f,'GET','/v2/recaptchaConfig',ke(_0x22504f,_0x57d2e5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x9ef4e1,_0xaee11e){return Pe(_0x9ef4e1,'POST','/v1/accounts:delete',_0xaee11e);}async function Pn(_0x34506a,_0xf46ef0){return Pe(_0x34506a,'POST','/v1/accounts:lookup',_0xf46ef0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2aa192){if(_0x2aa192)try{const _0x136dc6=new Date(Number(_0x2aa192));if(!isNaN(_0x136dc6['getTime']()))return _0x136dc6['toUTCString']();}catch{}}async function Ef(_0x19513e,_0x23da72=!0x1){const _0x2628c8=P(_0x19513e),_0x18e0b3=await _0x2628c8['getIdToken'](_0x23da72),_0x2b9e2c=Ts(_0x18e0b3);m(_0x2b9e2c&&_0x2b9e2c['exp']&&_0x2b9e2c['auth_time']&&_0x2b9e2c['iat'],_0x2628c8['auth'],'internal-error');const _0x4fa257=typeof _0x2b9e2c['firebase']=='object'?_0x2b9e2c['firebase']:void 0x0,_0x25cee3=_0x4fa257==null?void 0x0:_0x4fa257['sign_in_provider'];return{'claims':_0x2b9e2c,'token':_0x18e0b3,'authTime':Pt(fi(_0x2b9e2c['auth_time'])),'issuedAtTime':Pt(fi(_0x2b9e2c['iat'])),'expirationTime':Pt(fi(_0x2b9e2c['exp'])),'signInProvider':_0x25cee3||null,'signInSecondFactor':(_0x4fa257==null?void 0x0:_0x4fa257['sign_in_second_factor'])||null};}function fi(_0x4576e5){return Number(_0x4576e5)*0x3e8;}function Ts(_0x4a7d8e){const [_0x235978,_0x1a359e,_0x26bbd3]=_0x4a7d8e['split']('.');if(_0x235978===void 0x0||_0x1a359e===void 0x0||_0x26bbd3===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1f0552=fn(_0x1a359e);return _0x1f0552?JSON['parse'](_0x1f0552):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xd2e502){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xd2e502==null?void 0x0:_0xd2e502['toString']()),null;}}function Cr(_0x1591b5){const _0x4c4173=Ts(_0x1591b5);return m(_0x4c4173,'internal-error'),m(typeof _0x4c4173['exp']<'u','internal-error'),m(typeof _0x4c4173['iat']<'u','internal-error'),Number(_0x4c4173['exp'])-Number(_0x4c4173['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x557443,_0x553777,_0x1a67e8=!0x1){if(_0x1a67e8)return _0x553777;try{return await _0x553777;}catch(_0x57617e){throw _0x57617e instanceof Re&&If(_0x57617e)&&_0x557443['auth']['currentUser']===_0x557443&&await _0x557443['auth']['signOut'](),_0x57617e;}}function If({code:_0x1f52db}){return _0x1f52db==='auth/user-disabled'||_0x1f52db==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x26499d){this['user']=_0x26499d,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5a0184){if(_0x5a0184){const _0x1dd0ae=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1dd0ae;}else{this['errorBackoff']=0x7530;const _0x245520=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x245520);}}['schedule'](_0x2ccc9a=!0x1){if(!this['isRunning'])return;const _0x67551=this['getInterval'](_0x2ccc9a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x67551);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x17d0c0){(_0x17d0c0==null?void 0x0:_0x17d0c0['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x451e16,_0x483fc4){this['createdAt']=_0x451e16,this['lastLoginAt']=_0x483fc4,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x323084){this['createdAt']=_0x323084['createdAt'],this['lastLoginAt']=_0x323084['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x27b69b){var _0x551a1d;const _0x2fe76a=_0x27b69b['auth'],_0x2013cf=await _0x27b69b['getIdToken'](),_0x31ce48=await Ht(_0x27b69b,Pn(_0x2fe76a,{'idToken':_0x2013cf}));m(_0x31ce48==null?void 0x0:_0x31ce48['users']['length'],_0x2fe76a,'internal-error');const _0x1da3a9=_0x31ce48['users'][0x0];_0x27b69b['_notifyReloadListener'](_0x1da3a9);const _0x255758=(_0x551a1d=_0x1da3a9['providerUserInfo'])!=null&&_0x551a1d['length']?Sa(_0x1da3a9['providerUserInfo']):[],_0xc688a7=Tf(_0x27b69b['providerData'],_0x255758),_0x262ef7=_0x27b69b['isAnonymous'],_0x9cf447=!(_0x27b69b['email']&&_0x1da3a9['passwordHash'])&&!(_0xc688a7!=null&&_0xc688a7['length']),_0x98d7b1=_0x262ef7?_0x9cf447:!0x1,_0x3540e6={'uid':_0x1da3a9['localId'],'displayName':_0x1da3a9['displayName']||null,'photoURL':_0x1da3a9['photoUrl']||null,'email':_0x1da3a9['email']||null,'emailVerified':_0x1da3a9['emailVerified']||!0x1,'phoneNumber':_0x1da3a9['phoneNumber']||null,'tenantId':_0x1da3a9['tenantId']||null,'providerData':_0xc688a7,'metadata':new Li(_0x1da3a9['createdAt'],_0x1da3a9['lastLoginAt']),'isAnonymous':_0x98d7b1};Object['assign'](_0x27b69b,_0x3540e6);}async function Cf(_0x2ecf5e){const _0x1a1c07=P(_0x2ecf5e);await Nn(_0x1a1c07),await _0x1a1c07['auth']['_persistUserIfCurrent'](_0x1a1c07),_0x1a1c07['auth']['_notifyListenersIfCurrent'](_0x1a1c07);}function Tf(_0x41606d,_0x1349d1){return[..._0x41606d['filter'](_0x37330e=>!_0x1349d1['some'](_0x474070=>_0x474070['providerId']===_0x37330e['providerId'])),..._0x1349d1];}function Sa(_0x40908d){return _0x40908d['map'](({providerId:_0x5245d1,..._0x2818a1})=>({'providerId':_0x5245d1,'uid':_0x2818a1['rawId']||'','displayName':_0x2818a1['displayName']||null,'email':_0x2818a1['email']||null,'phoneNumber':_0x2818a1['phoneNumber']||null,'photoURL':_0x2818a1['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x3b423e,_0x2a1ded){const _0x5827b4=await Ca(_0x3b423e,{},async()=>{const _0x228c5d=ut({'grant_type':'refresh_token','refresh_token':_0x2a1ded})['slice'](0x1),{tokenApiHost:_0x25d50b,apiKey:_0x5bcc72}=_0x3b423e['config'],_0x5dc73b=await Ta(_0x3b423e,_0x25d50b,'/v1/token','key='+_0x5bcc72),_0x4b4146=await _0x3b423e['_getAdditionalHeaders']();_0x4b4146['Content-Type']='application/x-www-form-urlencoded';const _0x4c3d24={'method':'POST','headers':_0x4b4146,'body':_0x228c5d};return _0x3b423e['emulatorConfig']&&qt(_0x3b423e['emulatorConfig']['host'])&&(_0x4c3d24['credentials']='include'),wa['fetch']()(_0x5dc73b,_0x4c3d24);});return{'accessToken':_0x5827b4['access_token'],'expiresIn':_0x5827b4['expires_in'],'refreshToken':_0x5827b4['refresh_token']};}async function bf(_0x55926d,_0x16fee0){return Pe(_0x55926d,'POST','/v2/accounts:revokeToken',ke(_0x55926d,_0x16fee0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x459c0d){m(_0x459c0d['idToken'],'internal-error'),m(typeof _0x459c0d['idToken']<'u','internal-error'),m(typeof _0x459c0d['refreshToken']<'u','internal-error');const _0x50ddc6='expiresIn'in _0x459c0d&&typeof _0x459c0d['expiresIn']<'u'?Number(_0x459c0d['expiresIn']):Cr(_0x459c0d['idToken']);this['updateTokensAndExpiration'](_0x459c0d['idToken'],_0x459c0d['refreshToken'],_0x50ddc6);}['updateFromIdToken'](_0x45d98e){m(_0x45d98e['length']!==0x0,'internal-error');const _0x496df0=Cr(_0x45d98e);this['updateTokensAndExpiration'](_0x45d98e,null,_0x496df0);}async['getToken'](_0x53a046,_0x5b32b9=!0x1){return!_0x5b32b9&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x53a046,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x53a046,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x382b41,_0x462b58){const {accessToken:_0x1bae37,refreshToken:_0x17dcbd,expiresIn:_0xf2493}=await Sf(_0x382b41,_0x462b58);this['updateTokensAndExpiration'](_0x1bae37,_0x17dcbd,Number(_0xf2493));}['updateTokensAndExpiration'](_0x318854,_0x17f0d6,_0xcdfb24){this['refreshToken']=_0x17f0d6||null,this['accessToken']=_0x318854||null,this['expirationTime']=Date['now']()+_0xcdfb24*0x3e8;}static['fromJSON'](_0x1a39fd,_0x240393){const {refreshToken:_0x5b2a52,accessToken:_0x1b2fbf,expirationTime:_0x57e672}=_0x240393,_0x4a5a84=new et();return _0x5b2a52&&(m(typeof _0x5b2a52=='string','internal-error',{'appName':_0x1a39fd}),_0x4a5a84['refreshToken']=_0x5b2a52),_0x1b2fbf&&(m(typeof _0x1b2fbf=='string','internal-error',{'appName':_0x1a39fd}),_0x4a5a84['accessToken']=_0x1b2fbf),_0x57e672&&(m(typeof _0x57e672=='number','internal-error',{'appName':_0x1a39fd}),_0x4a5a84['expirationTime']=_0x57e672),_0x4a5a84;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x125f1d){this['accessToken']=_0x125f1d['accessToken'],this['refreshToken']=_0x125f1d['refreshToken'],this['expirationTime']=_0x125f1d['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3722ee,_0x1df63f){m(typeof _0x3722ee=='string'||typeof _0x3722ee>'u','internal-error',{'appName':_0x1df63f});}class j{constructor({uid:_0x1cab86,auth:_0x145a2d,stsTokenManager:_0x30408a,..._0x55b28d}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1cab86,this['auth']=_0x145a2d,this['stsTokenManager']=_0x30408a,this['accessToken']=_0x30408a['accessToken'],this['displayName']=_0x55b28d['displayName']||null,this['email']=_0x55b28d['email']||null,this['emailVerified']=_0x55b28d['emailVerified']||!0x1,this['phoneNumber']=_0x55b28d['phoneNumber']||null,this['photoURL']=_0x55b28d['photoURL']||null,this['isAnonymous']=_0x55b28d['isAnonymous']||!0x1,this['tenantId']=_0x55b28d['tenantId']||null,this['providerData']=_0x55b28d['providerData']?[..._0x55b28d['providerData']]:[],this['metadata']=new Li(_0x55b28d['createdAt']||void 0x0,_0x55b28d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x267661){const _0x57f263=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x267661));return m(_0x57f263,this['auth'],'internal-error'),this['accessToken']!==_0x57f263&&(this['accessToken']=_0x57f263,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x57f263;}['getIdTokenResult'](_0x4cf04b){return Ef(this,_0x4cf04b);}['reload'](){return Cf(this);}['_assign'](_0x40fb93){this!==_0x40fb93&&(m(this['uid']===_0x40fb93['uid'],this['auth'],'internal-error'),this['displayName']=_0x40fb93['displayName'],this['photoURL']=_0x40fb93['photoURL'],this['email']=_0x40fb93['email'],this['emailVerified']=_0x40fb93['emailVerified'],this['phoneNumber']=_0x40fb93['phoneNumber'],this['isAnonymous']=_0x40fb93['isAnonymous'],this['tenantId']=_0x40fb93['tenantId'],this['providerData']=_0x40fb93['providerData']['map'](_0x58866e=>({..._0x58866e})),this['metadata']['_copy'](_0x40fb93['metadata']),this['stsTokenManager']['_assign'](_0x40fb93['stsTokenManager']));}['_clone'](_0x48ef5e){const _0x1359f8=new j({...this,'auth':_0x48ef5e,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1359f8['metadata']['_copy'](this['metadata']),_0x1359f8;}['_onReload'](_0x4d955c){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4d955c,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4896b8){this['reloadListener']?this['reloadListener'](_0x4896b8):this['reloadUserInfo']=_0x4896b8;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x54101c,_0xcb85c3=!0x1){let _0x34c0d9=!0x1;_0x54101c['idToken']&&_0x54101c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x54101c),_0x34c0d9=!0x0),_0xcb85c3&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x34c0d9&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x5d4dac=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x5d4dac})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x46e4d6=>({..._0x46e4d6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x3004d2,_0x2fa019){const _0x970e70=_0x2fa019['displayName']??void 0x0,_0x38133c=_0x2fa019['email']??void 0x0,_0x1539bd=_0x2fa019['phoneNumber']??void 0x0,_0x3c50f9=_0x2fa019['photoURL']??void 0x0,_0x34fa23=_0x2fa019['tenantId']??void 0x0,_0x3015bb=_0x2fa019['_redirectEventId']??void 0x0,_0x2dc648=_0x2fa019['createdAt']??void 0x0,_0x581fcc=_0x2fa019['lastLoginAt']??void 0x0,{uid:_0x497d31,emailVerified:_0x562171,isAnonymous:_0xbba34,providerData:_0x21bcf3,stsTokenManager:_0x32d548}=_0x2fa019;m(_0x497d31&&_0x32d548,_0x3004d2,'internal-error');const _0x1f0db8=et['fromJSON'](this['name'],_0x32d548);m(typeof _0x497d31=='string',_0x3004d2,'internal-error'),le(_0x970e70,_0x3004d2['name']),le(_0x38133c,_0x3004d2['name']),m(typeof _0x562171=='boolean',_0x3004d2,'internal-error'),m(typeof _0xbba34=='boolean',_0x3004d2,'internal-error'),le(_0x1539bd,_0x3004d2['name']),le(_0x3c50f9,_0x3004d2['name']),le(_0x34fa23,_0x3004d2['name']),le(_0x3015bb,_0x3004d2['name']),le(_0x2dc648,_0x3004d2['name']),le(_0x581fcc,_0x3004d2['name']);const _0x5008a0=new j({'uid':_0x497d31,'auth':_0x3004d2,'email':_0x38133c,'emailVerified':_0x562171,'displayName':_0x970e70,'isAnonymous':_0xbba34,'photoURL':_0x3c50f9,'phoneNumber':_0x1539bd,'tenantId':_0x34fa23,'stsTokenManager':_0x1f0db8,'createdAt':_0x2dc648,'lastLoginAt':_0x581fcc});return _0x21bcf3&&Array['isArray'](_0x21bcf3)&&(_0x5008a0['providerData']=_0x21bcf3['map'](_0x9888e7=>({..._0x9888e7}))),_0x3015bb&&(_0x5008a0['_redirectEventId']=_0x3015bb),_0x5008a0;}static async['_fromIdTokenResponse'](_0x33378a,_0x171ad2,_0x37a6a2=!0x1){const _0x2f4996=new et();_0x2f4996['updateFromServerResponse'](_0x171ad2);const _0x46321c=new j({'uid':_0x171ad2['localId'],'auth':_0x33378a,'stsTokenManager':_0x2f4996,'isAnonymous':_0x37a6a2});return await Nn(_0x46321c),_0x46321c;}static async['_fromGetAccountInfoResponse'](_0x27164c,_0x2e24ea,_0x1bdcf1){const _0x56f7fa=_0x2e24ea['users'][0x0];m(_0x56f7fa['localId']!==void 0x0,'internal-error');const _0x2ee0a7=_0x56f7fa['providerUserInfo']!==void 0x0?Sa(_0x56f7fa['providerUserInfo']):[],_0x220bbe=!(_0x56f7fa['email']&&_0x56f7fa['passwordHash'])&&!(_0x2ee0a7!=null&&_0x2ee0a7['length']),_0x3d3f77=new et();_0x3d3f77['updateFromIdToken'](_0x1bdcf1);const _0x251c31=new j({'uid':_0x56f7fa['localId'],'auth':_0x27164c,'stsTokenManager':_0x3d3f77,'isAnonymous':_0x220bbe}),_0x362af9={'uid':_0x56f7fa['localId'],'displayName':_0x56f7fa['displayName']||null,'photoURL':_0x56f7fa['photoUrl']||null,'email':_0x56f7fa['email']||null,'emailVerified':_0x56f7fa['emailVerified']||!0x1,'phoneNumber':_0x56f7fa['phoneNumber']||null,'tenantId':_0x56f7fa['tenantId']||null,'providerData':_0x2ee0a7,'metadata':new Li(_0x56f7fa['createdAt'],_0x56f7fa['lastLoginAt']),'isAnonymous':!(_0x56f7fa['email']&&_0x56f7fa['passwordHash'])&&!(_0x2ee0a7!=null&&_0x2ee0a7['length'])};return Object['assign'](_0x251c31,_0x362af9),_0x251c31;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5c1faa){ce(_0x5c1faa instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4f1035=Tr['get'](_0x5c1faa);return _0x4f1035?(ce(_0x4f1035 instanceof _0x5c1faa,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4f1035):(_0x4f1035=new _0x5c1faa(),Tr['set'](_0x5c1faa,_0x4f1035),_0x4f1035);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x190d2b,_0x538eb0){this['storage'][_0x190d2b]=_0x538eb0;}async['_get'](_0x499f79){const _0x1bfc75=this['storage'][_0x499f79];return _0x1bfc75===void 0x0?null:_0x1bfc75;}async['_remove'](_0x47dc12){delete this['storage'][_0x47dc12];}['_addListener'](_0x1d8f31,_0x19634a){}['_removeListener'](_0x49b012,_0x21f85b){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x424bac,_0x24478d,_0x14194f){return'firebase:'+_0x424bac+':'+_0x24478d+':'+_0x14194f;}class tt{constructor(_0x3877bc,_0x6663c4,_0x3bc9db){this['persistence']=_0x3877bc,this['auth']=_0x6663c4,this['userKey']=_0x3bc9db;const {config:_0x41135e,name:_0x539acc}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x41135e['apiKey'],_0x539acc),this['fullPersistenceKey']=ln('persistence',_0x41135e['apiKey'],_0x539acc),this['boundEventHandler']=_0x6663c4['_onStorageEvent']['bind'](_0x6663c4),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3a320f){return this['persistence']['_set'](this['fullUserKey'],_0x3a320f['toJSON']());}async['getCurrentUser'](){const _0x143fb3=await this['persistence']['_get'](this['fullUserKey']);if(!_0x143fb3)return null;if(typeof _0x143fb3=='string'){const _0x123292=await Pn(this['auth'],{'idToken':_0x143fb3})['catch'](()=>{});return _0x123292?j['_fromGetAccountInfoResponse'](this['auth'],_0x123292,_0x143fb3):null;}return j['_fromJSON'](this['auth'],_0x143fb3);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4f4aae){if(this['persistence']===_0x4f4aae)return;const _0x86b172=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4f4aae,_0x86b172)return this['setCurrentUser'](_0x86b172);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x526503,_0x3d064e,_0x12e5f8='authUser'){if(!_0x3d064e['length'])return new tt(ie(Sr),_0x526503,_0x12e5f8);const _0x3dae05=(await Promise['all'](_0x3d064e['map'](async _0x88e4f7=>{if(await _0x88e4f7['_isAvailable']())return _0x88e4f7;})))['filter'](_0x11ec42=>_0x11ec42);let _0x5018a6=_0x3dae05[0x0]||ie(Sr);const _0x4c887d=ln(_0x12e5f8,_0x526503['config']['apiKey'],_0x526503['name']);let _0x392396=null;for(const _0x26b1a1 of _0x3d064e)try{const _0x2e771c=await _0x26b1a1['_get'](_0x4c887d);if(_0x2e771c){let _0x452e1c;if(typeof _0x2e771c=='string'){const _0xebfd77=await Pn(_0x526503,{'idToken':_0x2e771c})['catch'](()=>{});if(!_0xebfd77)break;_0x452e1c=await j['_fromGetAccountInfoResponse'](_0x526503,_0xebfd77,_0x2e771c);}else _0x452e1c=j['_fromJSON'](_0x526503,_0x2e771c);_0x26b1a1!==_0x5018a6&&(_0x392396=_0x452e1c),_0x5018a6=_0x26b1a1;break;}}catch{}const _0x27b288=_0x3dae05['filter'](_0x31b237=>_0x31b237['_shouldAllowMigration']);return!_0x5018a6['_shouldAllowMigration']||!_0x27b288['length']?new tt(_0x5018a6,_0x526503,_0x12e5f8):(_0x5018a6=_0x27b288[0x0],_0x392396&&await _0x5018a6['_set'](_0x4c887d,_0x392396['toJSON']()),await Promise['all'](_0x3d064e['map'](async _0x25b354=>{if(_0x25b354!==_0x5018a6)try{await _0x25b354['_remove'](_0x4c887d);}catch{}})),new tt(_0x5018a6,_0x526503,_0x12e5f8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x10c142){const _0x52b5a1=_0x10c142['toLowerCase']();if(_0x52b5a1['includes']('opera/')||_0x52b5a1['includes']('opr/')||_0x52b5a1['includes']('opios/'))return'Opera';if(Pa(_0x52b5a1))return'IEMobile';if(_0x52b5a1['includes']('msie')||_0x52b5a1['includes']('trident/'))return'IE';if(_0x52b5a1['includes']('edge/'))return'Edge';if(Ra(_0x52b5a1))return'Firefox';if(_0x52b5a1['includes']('silk/'))return'Silk';if(Oa(_0x52b5a1))return'Blackberry';if(Da(_0x52b5a1))return'Webos';if(Aa(_0x52b5a1))return'Safari';if((_0x52b5a1['includes']('chrome/')||ka(_0x52b5a1))&&!_0x52b5a1['includes']('edge/'))return'Chrome';if(Na(_0x52b5a1))return'Android';{const _0x25d202=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4e06da=_0x10c142['match'](_0x25d202);if((_0x4e06da==null?void 0x0:_0x4e06da['length'])===0x2)return _0x4e06da[0x1];}return'Other';}function Ra(_0x3e42cf=W()){return/firefox\//i['test'](_0x3e42cf);}function Aa(_0x275af7=W()){const _0x500871=_0x275af7['toLowerCase']();return _0x500871['includes']('safari/')&&!_0x500871['includes']('chrome/')&&!_0x500871['includes']('crios/')&&!_0x500871['includes']('android');}function ka(_0x128a63=W()){return/crios\//i['test'](_0x128a63);}function Pa(_0x2cd0f9=W()){return/iemobile/i['test'](_0x2cd0f9);}function Na(_0x4265b9=W()){return/android/i['test'](_0x4265b9);}function Oa(_0x62f44=W()){return/blackberry/i['test'](_0x62f44);}function Da(_0x19beae=W()){return/webos/i['test'](_0x19beae);}function Ss(_0x13ea4d=W()){return/iphone|ipad|ipod/i['test'](_0x13ea4d)||/macintosh/i['test'](_0x13ea4d)&&/mobile/i['test'](_0x13ea4d);}function Rf(_0x4bd10d=W()){var _0x5dd28b;return Ss(_0x4bd10d)&&!!((_0x5dd28b=window['navigator'])!=null&&_0x5dd28b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x25a5f0=W()){return Ss(_0x25a5f0)||Na(_0x25a5f0)||Da(_0x25a5f0)||Oa(_0x25a5f0)||/windows phone/i['test'](_0x25a5f0)||Pa(_0x25a5f0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5f575c,_0x1d08ff=[]){let _0x4e2872;switch(_0x5f575c){case'Browser':_0x4e2872=br(W());break;case'Worker':_0x4e2872=br(W())+'-'+_0x5f575c;break;default:_0x4e2872=_0x5f575c;}const _0x194ad0=_0x1d08ff['length']?_0x1d08ff['join'](','):'FirebaseCore-web';return _0x4e2872+'/JsCore/'+dt+'/'+_0x194ad0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3d391e){this['auth']=_0x3d391e,this['queue']=[];}['pushCallback'](_0x1a12f9,_0x5075b7){const _0x1069a4=_0x2434b3=>new Promise((_0x2f7e64,_0x5f7794)=>{try{const _0x50b5a9=_0x1a12f9(_0x2434b3);_0x2f7e64(_0x50b5a9);}catch(_0x50fb27){_0x5f7794(_0x50fb27);}});_0x1069a4['onAbort']=_0x5075b7,this['queue']['push'](_0x1069a4);const _0x333518=this['queue']['length']-0x1;return()=>{this['queue'][_0x333518]=()=>Promise['resolve']();};}async['runMiddleware'](_0xb1d34b){if(this['auth']['currentUser']===_0xb1d34b)return;const _0x2cb07d=[];try{for(const _0x32a2eb of this['queue'])await _0x32a2eb(_0xb1d34b),_0x32a2eb['onAbort']&&_0x2cb07d['push'](_0x32a2eb['onAbort']);}catch(_0x2aa3c0){_0x2cb07d['reverse']();for(const _0x36c73c of _0x2cb07d)try{_0x36c73c();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2aa3c0==null?void 0x0:_0x2aa3c0['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1e8712,_0x38acaa={}){return Pe(_0x1e8712,'GET','/v2/passwordPolicy',ke(_0x1e8712,_0x38acaa));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x37555c){var _0x13c3fa;const _0x21ef78=_0x37555c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x21ef78['minPasswordLength']??Nf,_0x21ef78['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x21ef78['maxPasswordLength']),_0x21ef78['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x21ef78['containsLowercaseCharacter']),_0x21ef78['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x21ef78['containsUppercaseCharacter']),_0x21ef78['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x21ef78['containsNumericCharacter']),_0x21ef78['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x21ef78['containsNonAlphanumericCharacter']),this['enforcementState']=_0x37555c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x13c3fa=_0x37555c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x13c3fa['join'](''))??'',this['forceUpgradeOnSignin']=_0x37555c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x37555c['schemaVersion'];}['validatePassword'](_0x342e66){const _0x469344={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x342e66,_0x469344),this['validatePasswordCharacterOptions'](_0x342e66,_0x469344),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['meetsMinPasswordLength']??!0x0),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['meetsMaxPasswordLength']??!0x0),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['containsLowercaseLetter']??!0x0),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['containsUppercaseLetter']??!0x0),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['containsNumericCharacter']??!0x0),_0x469344['isValid']&&(_0x469344['isValid']=_0x469344['containsNonAlphanumericCharacter']??!0x0),_0x469344;}['validatePasswordLengthOptions'](_0x4f206,_0x171557){const _0x6b83b6=this['customStrengthOptions']['minPasswordLength'],_0x453f23=this['customStrengthOptions']['maxPasswordLength'];_0x6b83b6&&(_0x171557['meetsMinPasswordLength']=_0x4f206['length']>=_0x6b83b6),_0x453f23&&(_0x171557['meetsMaxPasswordLength']=_0x4f206['length']<=_0x453f23);}['validatePasswordCharacterOptions'](_0xfea0bf,_0x418107){this['updatePasswordCharacterOptionsStatuses'](_0x418107,!0x1,!0x1,!0x1,!0x1);let _0x21f302;for(let _0x108ff9=0x0;_0x108ff9<_0xfea0bf['length'];_0x108ff9++)_0x21f302=_0xfea0bf['charAt'](_0x108ff9),this['updatePasswordCharacterOptionsStatuses'](_0x418107,_0x21f302>='a'&&_0x21f302<='z',_0x21f302>='A'&&_0x21f302<='Z',_0x21f302>='0'&&_0x21f302<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x21f302));}['updatePasswordCharacterOptionsStatuses'](_0x1bbda7,_0x435606,_0x4be9c9,_0xa289c1,_0x418d9f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1bbda7['containsLowercaseLetter']||(_0x1bbda7['containsLowercaseLetter']=_0x435606)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1bbda7['containsUppercaseLetter']||(_0x1bbda7['containsUppercaseLetter']=_0x4be9c9)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1bbda7['containsNumericCharacter']||(_0x1bbda7['containsNumericCharacter']=_0xa289c1)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1bbda7['containsNonAlphanumericCharacter']||(_0x1bbda7['containsNonAlphanumericCharacter']=_0x418d9f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5407c2,_0x79a178,_0x34302f,_0x1096a3){this['app']=_0x5407c2,this['heartbeatServiceProvider']=_0x79a178,this['appCheckServiceProvider']=_0x34302f,this['config']=_0x1096a3,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5407c2['name'],this['clientVersion']=_0x1096a3['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2dce96=>this['_resolvePersistenceManagerAvailable']=_0x2dce96);}['_initializeWithPersistence'](_0x2925e5,_0x129907){return _0x129907&&(this['_popupRedirectResolver']=ie(_0x129907)),this['_initializationPromise']=this['queue'](async()=>{var _0x170847,_0x43961e,_0x2eb430;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2925e5),(_0x170847=this['_resolvePersistenceManagerAvailable'])==null||_0x170847['call'](this),!this['_deleted'])){if((_0x43961e=this['_popupRedirectResolver'])!=null&&_0x43961e['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x129907),this['lastNotifiedUid']=((_0x2eb430=this['currentUser'])==null?void 0x0:_0x2eb430['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x29b306=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x29b306)){if(this['currentUser']&&_0x29b306&&this['currentUser']['uid']===_0x29b306['uid']){this['_currentUser']['_assign'](_0x29b306),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x29b306,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x133279){try{const _0x4abd3e=await Pn(this,{'idToken':_0x133279}),_0x408f16=await j['_fromGetAccountInfoResponse'](this,_0x4abd3e,_0x133279);await this['directlySetCurrentUser'](_0x408f16);}catch(_0x1bdf47){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1bdf47),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xd9aa3a){var _0x499f06;if($(this['app'])){const _0x4ab4a5=this['app']['settings']['authIdToken'];return _0x4ab4a5?new Promise(_0x3c81e3=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4ab4a5)['then'](_0x3c81e3,_0x3c81e3));}):this['directlySetCurrentUser'](null);}const _0x420b8f=await this['assertedPersistence']['getCurrentUser']();let _0x57f543=_0x420b8f,_0x3059e6=!0x1;if(_0xd9aa3a&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x277419=(_0x499f06=this['redirectUser'])==null?void 0x0:_0x499f06['_redirectEventId'],_0x2f3881=_0x57f543==null?void 0x0:_0x57f543['_redirectEventId'],_0x5ab444=await this['tryRedirectSignIn'](_0xd9aa3a);(!_0x277419||_0x277419===_0x2f3881)&&(_0x5ab444!=null&&_0x5ab444['user'])&&(_0x57f543=_0x5ab444['user'],_0x3059e6=!0x0);}if(!_0x57f543)return this['directlySetCurrentUser'](null);if(!_0x57f543['_redirectEventId']){if(_0x3059e6)try{await this['beforeStateQueue']['runMiddleware'](_0x57f543);}catch(_0x4161fc){_0x57f543=_0x420b8f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4161fc));}return _0x57f543?this['reloadAndSetCurrentUserOrClear'](_0x57f543):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x57f543['_redirectEventId']?this['directlySetCurrentUser'](_0x57f543):this['reloadAndSetCurrentUserOrClear'](_0x57f543);}async['tryRedirectSignIn'](_0x1efd33){let _0x19589b=null;try{_0x19589b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1efd33,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x19589b;}async['reloadAndSetCurrentUserOrClear'](_0x46436f){try{await Nn(_0x46436f);}catch(_0x19e022){if((_0x19e022==null?void 0x0:_0x19e022['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x46436f);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5efad0){if($(this['app']))return Promise['reject'](re(this));const _0x423495=_0x5efad0?P(_0x5efad0):null;return _0x423495&&m(_0x423495['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x423495&&_0x423495['_clone'](this));}async['_updateCurrentUser'](_0xaa6c28,_0x4cd78f=!0x1){if(!this['_deleted'])return _0xaa6c28&&m(this['tenantId']===_0xaa6c28['tenantId'],this,'tenant-id-mismatch'),_0x4cd78f||await this['beforeStateQueue']['runMiddleware'](_0xaa6c28),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xaa6c28),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x204caa){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x204caa));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5d22af){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x24ee27=this['_getPasswordPolicyInternal']();return _0x24ee27['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x24ee27['validatePassword'](_0x5d22af);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4dedd7=await Pf(this),_0x2ab9e9=new Of(_0x4dedd7);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2ab9e9:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2ab9e9;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x206b29){this['_errorFactory']=new Gt('auth','Firebase',_0x206b29());}['onAuthStateChanged'](_0x2e6eed,_0xa3d185,_0x47a1ca){return this['registerStateListener'](this['authStateSubscription'],_0x2e6eed,_0xa3d185,_0x47a1ca);}['beforeAuthStateChanged'](_0x4cef33,_0x48c56f){return this['beforeStateQueue']['pushCallback'](_0x4cef33,_0x48c56f);}['onIdTokenChanged'](_0x3bdc96,_0x455345,_0x31085b){return this['registerStateListener'](this['idTokenSubscription'],_0x3bdc96,_0x455345,_0x31085b);}['authStateReady'](){return new Promise((_0x53d10e,_0x35a895)=>{if(this['currentUser'])_0x53d10e();else{const _0x29d553=this['onAuthStateChanged'](()=>{_0x29d553(),_0x53d10e();},_0x35a895);}});}async['revokeAccessToken'](_0x58e029){if(this['currentUser']){const _0x38d259=await this['currentUser']['getIdToken'](),_0x2ed842={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x58e029,'idToken':_0x38d259};this['tenantId']!=null&&(_0x2ed842['tenantId']=this['tenantId']),await bf(this,_0x2ed842);}}['toJSON'](){var _0x4255e0;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4255e0=this['_currentUser'])==null?void 0x0:_0x4255e0['toJSON']()};}async['_setRedirectUser'](_0x2f7bf8,_0x51778b){const _0x182ebd=await this['getOrInitRedirectPersistenceManager'](_0x51778b);return _0x2f7bf8===null?_0x182ebd['removeCurrentUser']():_0x182ebd['setCurrentUser'](_0x2f7bf8);}async['getOrInitRedirectPersistenceManager'](_0x550c5b){if(!this['redirectPersistenceManager']){const _0x4c9197=_0x550c5b&&ie(_0x550c5b)||this['_popupRedirectResolver'];m(_0x4c9197,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x4c9197['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x464434){var _0x55abae,_0x4cdb51;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x55abae=this['_currentUser'])==null?void 0x0:_0x55abae['_redirectEventId'])===_0x464434?this['_currentUser']:((_0x4cdb51=this['redirectUser'])==null?void 0x0:_0x4cdb51['_redirectEventId'])===_0x464434?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5609b2){if(_0x5609b2===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5609b2));}['_notifyListenersIfCurrent'](_0x52f965){_0x52f965===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2f78a3;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xa5a9b7=((_0x2f78a3=this['currentUser'])==null?void 0x0:_0x2f78a3['uid'])??null;this['lastNotifiedUid']!==_0xa5a9b7&&(this['lastNotifiedUid']=_0xa5a9b7,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x318ae1,_0x1c01ca,_0x46dde8,_0xf085c8){if(this['_deleted'])return()=>{};const _0x4875c7=typeof _0x1c01ca=='function'?_0x1c01ca:_0x1c01ca['next']['bind'](_0x1c01ca);let _0xeef2e8=!0x1;const _0x2667cf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2667cf,this,'internal-error'),_0x2667cf['then'](()=>{_0xeef2e8||_0x4875c7(this['currentUser']);}),typeof _0x1c01ca=='function'){const _0x1c0f88=_0x318ae1['addObserver'](_0x1c01ca,_0x46dde8,_0xf085c8);return()=>{_0xeef2e8=!0x0,_0x1c0f88();};}else{const _0x215027=_0x318ae1['addObserver'](_0x1c01ca);return()=>{_0xeef2e8=!0x0,_0x215027();};}}async['directlySetCurrentUser'](_0x3241eb){this['currentUser']&&this['currentUser']!==_0x3241eb&&this['_currentUser']['_stopProactiveRefresh'](),_0x3241eb&&this['isProactiveRefreshEnabled']&&_0x3241eb['_startProactiveRefresh'](),this['currentUser']=_0x3241eb,_0x3241eb?await this['assertedPersistence']['setCurrentUser'](_0x3241eb):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x430b2d){return this['operations']=this['operations']['then'](_0x430b2d,_0x430b2d),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1ffc95){!_0x1ffc95||this['frameworks']['includes'](_0x1ffc95)||(this['frameworks']['push'](_0x1ffc95),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x733b4c;const _0xac06eb={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0xac06eb['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4d7e67=await((_0x733b4c=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x733b4c['getHeartbeatsHeader']());_0x4d7e67&&(_0xac06eb['X-Firebase-Client']=_0x4d7e67);const _0x7ddadf=await this['_getAppCheckToken']();return _0x7ddadf&&(_0xac06eb['X-Firebase-AppCheck']=_0x7ddadf),_0xac06eb;}async['_getAppCheckToken'](){var _0x3024e0;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x46cc1c=await((_0x3024e0=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3024e0['getToken']());return _0x46cc1c!=null&&_0x46cc1c['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x46cc1c['error']),_0x46cc1c==null?void 0x0:_0x46cc1c['token'];}}function Ke(_0x55c868){return P(_0x55c868);}class Rr{constructor(_0x22f946){this['auth']=_0x22f946,this['observer']=null,this['addObserver']=Tc(_0x432b42=>this['observer']=_0x432b42);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x19ebe9){Jn=_0x19ebe9;}function xa(_0x150186){return Jn['loadJS'](_0x150186);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x255144){return'__'+_0x255144+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x5464fa){_0x5464fa();}['execute'](_0x421450,_0x1910a9){return Promise['resolve']('token');}['render'](_0x4987eb,_0x1c082d){return'';}}class Wf{['ready'](_0x1c5243){_0x1c5243();}['execute'](_0x2eac38,_0xb69dc7){return Promise['resolve']('token');}['render'](_0x3139bc,_0x5255f3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x331b64){this['type']=Bf,this['auth']=Ke(_0x331b64);}async['verify'](_0x50226d='verify',_0x1cd10a=!0x1){async function _0x5767f0(_0x2d5f29){if(!_0x1cd10a){if(_0x2d5f29['tenantId']==null&&_0x2d5f29['_agentRecaptchaConfig']!=null)return _0x2d5f29['_agentRecaptchaConfig']['siteKey'];if(_0x2d5f29['tenantId']!=null&&_0x2d5f29['_tenantRecaptchaConfigs'][_0x2d5f29['tenantId']]!==void 0x0)return _0x2d5f29['_tenantRecaptchaConfigs'][_0x2d5f29['tenantId']]['siteKey'];}return new Promise(async(_0x449be9,_0x2dbeb5)=>{yf(_0x2d5f29,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xd124cd=>{if(_0xd124cd['recaptchaKey']===void 0x0)_0x2dbeb5(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x48ab64=new mf(_0xd124cd);return _0x2d5f29['tenantId']==null?_0x2d5f29['_agentRecaptchaConfig']=_0x48ab64:_0x2d5f29['_tenantRecaptchaConfigs'][_0x2d5f29['tenantId']]=_0x48ab64,_0x449be9(_0x48ab64['siteKey']);}})['catch'](_0x5f582d=>{_0x2dbeb5(_0x5f582d);});});}function _0x585eed(_0x46a9c1,_0x2ec3d2,_0x4aa95f){const _0x4390ae=window['grecaptcha'];wr(_0x4390ae)?_0x4390ae['enterprise']['ready'](()=>{_0x4390ae['enterprise']['execute'](_0x46a9c1,{'action':_0x50226d})['then'](_0x4c004e=>{_0x2ec3d2(_0x4c004e);})['catch'](()=>{_0x2ec3d2(Fa);});}):_0x4aa95f(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x19f8bd,_0x42ff26)=>{_0x5767f0(this['auth'])['then'](async _0x20a3c0=>{if(!_0x1cd10a&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x585eed(_0x20a3c0,_0x19f8bd,_0x42ff26);else{if(typeof window>'u'){_0x42ff26(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x47dfd6=Lf();_0x47dfd6['length']!==0x0&&(_0x47dfd6+=_0x20a3c0+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x31cfcb;(_0x31cfcb=he['scriptInjectionDeferred'])==null||_0x31cfcb['resolve']();},xa(_0x47dfd6)['then'](()=>{var _0x28bce8;return(_0x28bce8=he['scriptInjectionDeferred'])==null?void 0x0:_0x28bce8['promise'];})['then'](()=>{_0x585eed(_0x20a3c0,_0x19f8bd,_0x42ff26);})['catch'](_0x556d7b=>{_0x42ff26(_0x556d7b);});}})['catch'](_0x584675=>{_0x42ff26(_0x584675);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x201e84,_0x4cce4a,_0x2635c0,_0x48cc70=!0x1,_0x339286=!0x1){const _0x2d5cf4=new he(_0x201e84);let _0x246a83;if(_0x339286)_0x246a83=Fa;else try{_0x246a83=await _0x2d5cf4['verify'](_0x2635c0);}catch{_0x246a83=await _0x2d5cf4['verify'](_0x2635c0,!0x0);}const _0x5b8c79={..._0x4cce4a};if(_0x2635c0==='mfaSmsEnrollment'||_0x2635c0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5b8c79){const _0x34be69=_0x5b8c79['phoneEnrollmentInfo']['phoneNumber'],_0xd21d65=_0x5b8c79['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5b8c79,{'phoneEnrollmentInfo':{'phoneNumber':_0x34be69,'recaptchaToken':_0xd21d65,'captchaResponse':_0x246a83,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5b8c79){const _0x4701f8=_0x5b8c79['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5b8c79,{'phoneSignInInfo':{'recaptchaToken':_0x4701f8,'captchaResponse':_0x246a83,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5b8c79;}return _0x48cc70?Object['assign'](_0x5b8c79,{'captchaResp':_0x246a83}):Object['assign'](_0x5b8c79,{'captchaResponse':_0x246a83}),Object['assign'](_0x5b8c79,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5b8c79,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5b8c79;}async function xi(_0xda39de,_0x445e81,_0x3efd2c,_0x15e577,_0x67d758){var _0x19b35e;if((_0x19b35e=_0xda39de['_getRecaptchaConfig']())!=null&&_0x19b35e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x53be11=await kr(_0xda39de,_0x445e81,_0x3efd2c,_0x3efd2c==='getOobCode');return _0x15e577(_0xda39de,_0x53be11);}else return _0x15e577(_0xda39de,_0x445e81)['catch'](async _0x35a2c0=>{if(_0x35a2c0['code']==='auth/missing-recaptcha-token'){console['log'](_0x3efd2c+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x50a23c=await kr(_0xda39de,_0x445e81,_0x3efd2c,_0x3efd2c==='getOobCode');return _0x15e577(_0xda39de,_0x50a23c);}else return Promise['reject'](_0x35a2c0);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x11d700,_0x57b2c7){const _0xf7ef66=Hi(_0x11d700,'auth');if(_0xf7ef66['isInitialized']()){const _0x12c5d7=_0xf7ef66['getImmediate'](),_0xd8da33=_0xf7ef66['getOptions']();if(xe(_0xd8da33,_0x57b2c7??{}))return _0x12c5d7;Y(_0x12c5d7,'already-initialized');}return _0xf7ef66['initialize']({'options':_0x57b2c7});}function Hf(_0x31e8b1,_0x404073){const _0x2b5fd6=(_0x404073==null?void 0x0:_0x404073['persistence'])||[],_0x38aa2b=(Array['isArray'](_0x2b5fd6)?_0x2b5fd6:[_0x2b5fd6])['map'](ie);_0x404073!=null&&_0x404073['errorMap']&&_0x31e8b1['_updateErrorMap'](_0x404073['errorMap']),_0x31e8b1['_initializeWithPersistence'](_0x38aa2b,_0x404073==null?void 0x0:_0x404073['popupRedirectResolver']);}function $f(_0x2f6887,_0x58a1f8,_0x11ed04){const _0x259081=Ke(_0x2f6887);m(/^https?:\/\//['test'](_0x58a1f8),_0x259081,'invalid-emulator-scheme');const _0x5485f9=!0x1,_0x44db43=Ua(_0x58a1f8),{host:_0x231fe5,port:_0x402069}=Gf(_0x58a1f8),_0x448c00=_0x402069===null?'':':'+_0x402069,_0x58e019={'url':_0x44db43+'//'+_0x231fe5+_0x448c00+'/'},_0x499dd9=Object['freeze']({'host':_0x231fe5,'port':_0x402069,'protocol':_0x44db43['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5485f9})});if(!_0x259081['_canInitEmulator']){m(_0x259081['config']['emulator']&&_0x259081['emulatorConfig'],_0x259081,'emulator-config-failed'),m(xe(_0x58e019,_0x259081['config']['emulator'])&&xe(_0x499dd9,_0x259081['emulatorConfig']),_0x259081,'emulator-config-failed');return;}_0x259081['config']['emulator']=_0x58e019,_0x259081['emulatorConfig']=_0x499dd9,_0x259081['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x231fe5)?Qr(_0x44db43+'//'+_0x231fe5+_0x448c00):qf();}function Ua(_0x433465){const _0x2686e9=_0x433465['indexOf'](':');return _0x2686e9<0x0?'':_0x433465['substr'](0x0,_0x2686e9+0x1);}function Gf(_0x2f628c){const _0x400626=Ua(_0x2f628c),_0x53e32f=/(\/\/)?([^?#/]+)/['exec'](_0x2f628c['substr'](_0x400626['length']));if(!_0x53e32f)return{'host':'','port':null};const _0x811fb5=_0x53e32f[0x2]['split']('@')['pop']()||'',_0x29466e=/^(\[[^\]]+\])(:|$)/['exec'](_0x811fb5);if(_0x29466e){const _0x432fa8=_0x29466e[0x1];return{'host':_0x432fa8,'port':Pr(_0x811fb5['substr'](_0x432fa8['length']+0x1))};}else{const [_0x2d38d6,_0x399f3d]=_0x811fb5['split'](':');return{'host':_0x2d38d6,'port':Pr(_0x399f3d)};}}function Pr(_0x5541bd){if(!_0x5541bd)return null;const _0x5de3ef=Number(_0x5541bd);return isNaN(_0x5de3ef)?null:_0x5de3ef;}function qf(){function _0xfd4156(){const _0x33271d=document['createElement']('p'),_0x5512f6=_0x33271d['style'];_0x33271d['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5512f6['position']='fixed',_0x5512f6['width']='100%',_0x5512f6['backgroundColor']='#ffffff',_0x5512f6['border']='.1em\x20solid\x20#000000',_0x5512f6['color']='#b50000',_0x5512f6['bottom']='0px',_0x5512f6['left']='0px',_0x5512f6['margin']='0px',_0x5512f6['zIndex']='10000',_0x5512f6['textAlign']='center',_0x33271d['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x33271d);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xfd4156):_0xfd4156());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x47fe89,_0x5b21d9){this['providerId']=_0x47fe89,this['signInMethod']=_0x5b21d9;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3b7220){return ne('not\x20implemented');}['_linkToIdToken'](_0x552828,_0x36b278){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x209c29){return ne('not\x20implemented');}}async function zf(_0x3776b1,_0x9745aa){return Pe(_0x3776b1,'POST','/v1/accounts:signUp',_0x9745aa);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0xc2407e,_0x559509){return en(_0xc2407e,'POST','/v1/accounts:signInWithPassword',ke(_0xc2407e,_0x559509));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xafd5c8,_0x17743b){return en(_0xafd5c8,'POST','/v1/accounts:signInWithEmailLink',ke(_0xafd5c8,_0x17743b));}async function Yf(_0x213b99,_0x1e7ef1){return en(_0x213b99,'POST','/v1/accounts:signInWithEmailLink',ke(_0x213b99,_0x1e7ef1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x290757,_0x4312d1,_0x55c037,_0x5f46fc=null){super('password',_0x55c037),this['_email']=_0x290757,this['_password']=_0x4312d1,this['_tenantId']=_0x5f46fc;}static['_fromEmailAndPassword'](_0x4fcf3e,_0x17dd4f){return new $t(_0x4fcf3e,_0x17dd4f,'password');}static['_fromEmailAndCode'](_0x11cb5c,_0x3a918d,_0x2025fa=null){return new $t(_0x11cb5c,_0x3a918d,'emailLink',_0x2025fa);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x66738){const _0xfcbbdf=typeof _0x66738=='string'?JSON['parse'](_0x66738):_0x66738;if(_0xfcbbdf!=null&&_0xfcbbdf['email']&&(_0xfcbbdf!=null&&_0xfcbbdf['password'])){if(_0xfcbbdf['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xfcbbdf['email'],_0xfcbbdf['password']);if(_0xfcbbdf['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xfcbbdf['email'],_0xfcbbdf['password'],_0xfcbbdf['tenantId']);}return null;}async['_getIdTokenResponse'](_0x52320f){switch(this['signInMethod']){case'password':const _0x389ec0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x52320f,_0x389ec0,'signInWithPassword',jf);case'emailLink':return Kf(_0x52320f,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x52320f,'internal-error');}}async['_linkToIdToken'](_0x197a7a,_0x23969f){switch(this['signInMethod']){case'password':const _0xfdaf41={'idToken':_0x23969f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x197a7a,_0xfdaf41,'signUpPassword',zf);case'emailLink':return Yf(_0x197a7a,{'idToken':_0x23969f,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x197a7a,'internal-error');}}['_getReauthenticationResolver'](_0x1ced4d){return this['_getIdTokenResponse'](_0x1ced4d);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x379ac5,_0x90bf5b){return en(_0x379ac5,'POST','/v1/accounts:signInWithIdp',ke(_0x379ac5,_0x90bf5b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2762f4){const _0x17aa98=new $e(_0x2762f4['providerId'],_0x2762f4['signInMethod']);return _0x2762f4['idToken']||_0x2762f4['accessToken']?(_0x2762f4['idToken']&&(_0x17aa98['idToken']=_0x2762f4['idToken']),_0x2762f4['accessToken']&&(_0x17aa98['accessToken']=_0x2762f4['accessToken']),_0x2762f4['nonce']&&!_0x2762f4['pendingToken']&&(_0x17aa98['nonce']=_0x2762f4['nonce']),_0x2762f4['pendingToken']&&(_0x17aa98['pendingToken']=_0x2762f4['pendingToken'])):_0x2762f4['oauthToken']&&_0x2762f4['oauthTokenSecret']?(_0x17aa98['accessToken']=_0x2762f4['oauthToken'],_0x17aa98['secret']=_0x2762f4['oauthTokenSecret']):Y('argument-error'),_0x17aa98;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x128e68){const _0x39e4f0=typeof _0x128e68=='string'?JSON['parse'](_0x128e68):_0x128e68,{providerId:_0x22ae26,signInMethod:_0x115fe5,..._0x2c600a}=_0x39e4f0;if(!_0x22ae26||!_0x115fe5)return null;const _0x262a06=new $e(_0x22ae26,_0x115fe5);return _0x262a06['idToken']=_0x2c600a['idToken']||void 0x0,_0x262a06['accessToken']=_0x2c600a['accessToken']||void 0x0,_0x262a06['secret']=_0x2c600a['secret'],_0x262a06['nonce']=_0x2c600a['nonce'],_0x262a06['pendingToken']=_0x2c600a['pendingToken']||null,_0x262a06;}['_getIdTokenResponse'](_0x351c69){const _0x1be64a=this['buildRequest']();return nt(_0x351c69,_0x1be64a);}['_linkToIdToken'](_0x54dc43,_0x4f2259){const _0x5cd765=this['buildRequest']();return _0x5cd765['idToken']=_0x4f2259,nt(_0x54dc43,_0x5cd765);}['_getReauthenticationResolver'](_0x281942){const _0x43d410=this['buildRequest']();return _0x43d410['autoCreate']=!0x1,nt(_0x281942,_0x43d410);}['buildRequest'](){const _0x4e3599={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4e3599['pendingToken']=this['pendingToken'];else{const _0x243360={};this['idToken']&&(_0x243360['id_token']=this['idToken']),this['accessToken']&&(_0x243360['access_token']=this['accessToken']),this['secret']&&(_0x243360['oauth_token_secret']=this['secret']),_0x243360['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x243360['nonce']=this['nonce']),_0x4e3599['postBody']=ut(_0x243360);}return _0x4e3599;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x52e04d){switch(_0x52e04d){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x4c2239){const _0xc9392b=Ct(Tt(_0x4c2239))['link'],_0x4c5278=_0xc9392b?Ct(Tt(_0xc9392b))['deep_link_id']:null,_0x32f2b2=Ct(Tt(_0x4c2239))['deep_link_id'];return(_0x32f2b2?Ct(Tt(_0x32f2b2))['link']:null)||_0x32f2b2||_0x4c5278||_0xc9392b||_0x4c2239;}class Rs{constructor(_0x8395b0){const _0x235d44=Ct(Tt(_0x8395b0)),_0x3ee033=_0x235d44['apiKey']??null,_0x2767c7=_0x235d44['oobCode']??null,_0x1ebe4a=Jf(_0x235d44['mode']??null);m(_0x3ee033&&_0x2767c7&&_0x1ebe4a,'argument-error'),this['apiKey']=_0x3ee033,this['operation']=_0x1ebe4a,this['code']=_0x2767c7,this['continueUrl']=_0x235d44['continueUrl']??null,this['languageCode']=_0x235d44['lang']??null,this['tenantId']=_0x235d44['tenantId']??null;}static['parseLink'](_0x13567e){const _0x2261e5=Xf(_0x13567e);try{return new Rs(_0x2261e5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x47a7a5,_0x509935){return $t['_fromEmailAndPassword'](_0x47a7a5,_0x509935);}static['credentialWithLink'](_0x52b8ff,_0x259d62){const _0x13f839=Rs['parseLink'](_0x259d62);return m(_0x13f839,'argument-error'),$t['_fromEmailAndCode'](_0x52b8ff,_0x13f839['code'],_0x13f839['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x11bfa9){this['providerId']=_0x11bfa9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4e91f1){this['defaultLanguageCode']=_0x4e91f1;}['setCustomParameters'](_0x392ab4){return this['customParameters']=_0x392ab4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1466c2){return this['scopes']['includes'](_0x1466c2)||this['scopes']['push'](_0x1466c2),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x595142){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x595142});}static['credentialFromResult'](_0x137f69){return ue['credentialFromTaggedObject'](_0x137f69);}static['credentialFromError'](_0x8a9872){return ue['credentialFromTaggedObject'](_0x8a9872['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3ed7df}){if(!_0x3ed7df||!('oauthAccessToken'in _0x3ed7df)||!_0x3ed7df['oauthAccessToken'])return null;try{return ue['credential'](_0x3ed7df['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x7545c5,_0x54f407){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x7545c5,'accessToken':_0x54f407});}static['credentialFromResult'](_0x7678b5){return de['credentialFromTaggedObject'](_0x7678b5);}static['credentialFromError'](_0x4e8aa2){return de['credentialFromTaggedObject'](_0x4e8aa2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x46c544}){if(!_0x46c544)return null;const {oauthIdToken:_0x3b5e82,oauthAccessToken:_0x256d29}=_0x46c544;if(!_0x3b5e82&&!_0x256d29)return null;try{return de['credential'](_0x3b5e82,_0x256d29);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x2e9258){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2e9258});}static['credentialFromResult'](_0x2e1063){return fe['credentialFromTaggedObject'](_0x2e1063);}static['credentialFromError'](_0x4dbb1d){return fe['credentialFromTaggedObject'](_0x4dbb1d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1beda0}){if(!_0x1beda0||!('oauthAccessToken'in _0x1beda0)||!_0x1beda0['oauthAccessToken'])return null;try{return fe['credential'](_0x1beda0['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x2c2b94,_0x54db71){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2c2b94,'oauthTokenSecret':_0x54db71});}static['credentialFromResult'](_0x2225a6){return pe['credentialFromTaggedObject'](_0x2225a6);}static['credentialFromError'](_0x252773){return pe['credentialFromTaggedObject'](_0x252773['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x256628}){if(!_0x256628)return null;const {oauthAccessToken:_0x1bbaa6,oauthTokenSecret:_0x5a99a8}=_0x256628;if(!_0x1bbaa6||!_0x5a99a8)return null;try{return pe['credential'](_0x1bbaa6,_0x5a99a8);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2e1ca3,_0x246d7e){return en(_0x2e1ca3,'POST','/v1/accounts:signUp',ke(_0x2e1ca3,_0x246d7e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x45d182){this['user']=_0x45d182['user'],this['providerId']=_0x45d182['providerId'],this['_tokenResponse']=_0x45d182['_tokenResponse'],this['operationType']=_0x45d182['operationType'];}static async['_fromIdTokenResponse'](_0x459cef,_0x22f598,_0x1844d2,_0x363d79=!0x1){const _0x32fc9b=await j['_fromIdTokenResponse'](_0x459cef,_0x1844d2,_0x363d79),_0x19f5b4=Nr(_0x1844d2);return new Ge({'user':_0x32fc9b,'providerId':_0x19f5b4,'_tokenResponse':_0x1844d2,'operationType':_0x22f598});}static async['_forOperation'](_0x558fd2,_0x531ec0,_0x1f65fe){await _0x558fd2['_updateTokensIfNecessary'](_0x1f65fe,!0x0);const _0x1b4264=Nr(_0x1f65fe);return new Ge({'user':_0x558fd2,'providerId':_0x1b4264,'_tokenResponse':_0x1f65fe,'operationType':_0x531ec0});}}function Nr(_0x32d587){return _0x32d587['providerId']?_0x32d587['providerId']:'phoneNumber'in _0x32d587?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x1c6a8c,_0x459423,_0xac8c7a,_0x1916d3){super(_0x459423['code'],_0x459423['message']),this['operationType']=_0xac8c7a,this['user']=_0x1916d3,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x1c6a8c['name'],'tenantId':_0x1c6a8c['tenantId']??void 0x0,'_serverResponse':_0x459423['customData']['_serverResponse'],'operationType':_0xac8c7a};}static['_fromErrorAndOperation'](_0x10cd35,_0x2794dc,_0x4a60ca,_0x308e6b){return new On(_0x10cd35,_0x2794dc,_0x4a60ca,_0x308e6b);}}function Ba(_0x38fd46,_0x4d097b,_0x249675,_0x5e27ce){return(_0x4d097b==='reauthenticate'?_0x249675['_getReauthenticationResolver'](_0x38fd46):_0x249675['_getIdTokenResponse'](_0x38fd46))['catch'](_0x5cc32e=>{throw _0x5cc32e['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x38fd46,_0x5cc32e,_0x4d097b,_0x5e27ce):_0x5cc32e;});}async function ep(_0x6a24ec,_0x3ee9ae,_0x9b1652=!0x1){const _0x188bb8=await Ht(_0x6a24ec,_0x3ee9ae['_linkToIdToken'](_0x6a24ec['auth'],await _0x6a24ec['getIdToken']()),_0x9b1652);return Ge['_forOperation'](_0x6a24ec,'link',_0x188bb8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x5e181e,_0x2c4ebf,_0x398919=!0x1){const {auth:_0x506542}=_0x5e181e;if($(_0x506542['app']))return Promise['reject'](re(_0x506542));const _0x14cc5c='reauthenticate';try{const _0x349b3f=await Ht(_0x5e181e,Ba(_0x506542,_0x14cc5c,_0x2c4ebf,_0x5e181e),_0x398919);m(_0x349b3f['idToken'],_0x506542,'internal-error');const _0x4c5672=Ts(_0x349b3f['idToken']);m(_0x4c5672,_0x506542,'internal-error');const {sub:_0xdf4fc}=_0x4c5672;return m(_0x5e181e['uid']===_0xdf4fc,_0x506542,'user-mismatch'),Ge['_forOperation'](_0x5e181e,_0x14cc5c,_0x349b3f);}catch(_0x3dbaf5){throw(_0x3dbaf5==null?void 0x0:_0x3dbaf5['code'])==='auth/user-not-found'&&Y(_0x506542,'user-mismatch'),_0x3dbaf5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x30c4d5,_0x2ea20c,_0x1bbacb=!0x1){if($(_0x30c4d5['app']))return Promise['reject'](re(_0x30c4d5));const _0x11320a='signIn',_0x2e2fd7=await Ba(_0x30c4d5,_0x11320a,_0x2ea20c),_0x4a0cbe=await Ge['_fromIdTokenResponse'](_0x30c4d5,_0x11320a,_0x2e2fd7);return _0x1bbacb||await _0x30c4d5['_updateCurrentUser'](_0x4a0cbe['user']),_0x4a0cbe;}async function np(_0x5dec7b,_0x28541d){return Va(Ke(_0x5dec7b),_0x28541d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4b2764){const _0x25fee0=Ke(_0x4b2764);_0x25fee0['_getPasswordPolicyInternal']()&&await _0x25fee0['_updatePasswordPolicy']();}async function L_(_0x498c62,_0x4b7ddd,_0x5b8c06){if($(_0x498c62['app']))return Promise['reject'](re(_0x498c62));const _0x34ef2c=Ke(_0x498c62),_0x12a7ec=await xi(_0x34ef2c,{'returnSecureToken':!0x0,'email':_0x4b7ddd,'password':_0x5b8c06,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xa7f22=>{throw _0xa7f22['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x498c62),_0xa7f22;}),_0x4eb808=await Ge['_fromIdTokenResponse'](_0x34ef2c,'signIn',_0x12a7ec);return await _0x34ef2c['_updateCurrentUser'](_0x4eb808['user']),_0x4eb808;}function x_(_0x5ad6ed,_0x441107,_0x51e6a7){return $(_0x5ad6ed['app'])?Promise['reject'](re(_0x5ad6ed)):np(P(_0x5ad6ed),yt['credential'](_0x441107,_0x51e6a7))['catch'](async _0x3eeac4=>{throw _0x3eeac4['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5ad6ed),_0x3eeac4;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x7b93f,_0x288d46){return P(_0x7b93f)['setPersistence'](_0x288d46);}function ip(_0x4b4e95,_0x173d91,_0x1a4a20,_0x31dd31){return P(_0x4b4e95)['onIdTokenChanged'](_0x173d91,_0x1a4a20,_0x31dd31);}function sp(_0x5c97c1,_0x459674,_0x553fa4){return P(_0x5c97c1)['beforeAuthStateChanged'](_0x459674,_0x553fa4);}function U_(_0x1fcc3d,_0xd81ae5,_0x165b6e,_0x30c572){return P(_0x1fcc3d)['onAuthStateChanged'](_0xd81ae5,_0x165b6e,_0x30c572);}function W_(_0x7b07a9){return P(_0x7b07a9)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x52069d,_0x51a3d8){this['storageRetriever']=_0x52069d,this['type']=_0x51a3d8;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5daf08,_0x5931cb){return this['storage']['setItem'](_0x5daf08,JSON['stringify'](_0x5931cb)),Promise['resolve']();}['_get'](_0x35dddf){const _0x36623e=this['storage']['getItem'](_0x35dddf);return Promise['resolve'](_0x36623e?JSON['parse'](_0x36623e):null);}['_remove'](_0x4bf41a){return this['storage']['removeItem'](_0x4bf41a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x38ab9e,_0x51335c)=>this['onStorageEvent'](_0x38ab9e,_0x51335c),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x23819d){for(const _0x33f357 of Object['keys'](this['listeners'])){const _0x40c0e8=this['storage']['getItem'](_0x33f357),_0x113011=this['localCache'][_0x33f357];_0x40c0e8!==_0x113011&&_0x23819d(_0x33f357,_0x113011,_0x40c0e8);}}['onStorageEvent'](_0x4100cd,_0x189132=!0x1){if(!_0x4100cd['key']){this['forAllChangedKeys']((_0x2ef20f,_0xafd579,_0x6d932)=>{this['notifyListeners'](_0x2ef20f,_0x6d932);});return;}const _0x2d1954=_0x4100cd['key'];_0x189132?this['detachListener']():this['stopPolling']();const _0x2a3f23=()=>{const _0x197624=this['storage']['getItem'](_0x2d1954);!_0x189132&&this['localCache'][_0x2d1954]===_0x197624||this['notifyListeners'](_0x2d1954,_0x197624);},_0xcb487=this['storage']['getItem'](_0x2d1954);Af()&&_0xcb487!==_0x4100cd['newValue']&&_0x4100cd['newValue']!==_0x4100cd['oldValue']?setTimeout(_0x2a3f23,op):_0x2a3f23();}['notifyListeners'](_0x3d71c8,_0x5a9d75){this['localCache'][_0x3d71c8]=_0x5a9d75;const _0x369a7c=this['listeners'][_0x3d71c8];if(_0x369a7c){for(const _0x45247f of Array['from'](_0x369a7c))_0x45247f(_0x5a9d75&&JSON['parse'](_0x5a9d75));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x15b1ed,_0x1fbf42,_0x5de4cd)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x15b1ed,'oldValue':_0x1fbf42,'newValue':_0x5de4cd}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x35c0bd,_0x34708c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x35c0bd]||(this['listeners'][_0x35c0bd]=new Set(),this['localCache'][_0x35c0bd]=this['storage']['getItem'](_0x35c0bd)),this['listeners'][_0x35c0bd]['add'](_0x34708c);}['_removeListener'](_0x1799e2,_0x422a51){this['listeners'][_0x1799e2]&&(this['listeners'][_0x1799e2]['delete'](_0x422a51),this['listeners'][_0x1799e2]['size']===0x0&&delete this['listeners'][_0x1799e2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x44a270,_0x1936a9){await super['_set'](_0x44a270,_0x1936a9),this['localCache'][_0x44a270]=JSON['stringify'](_0x1936a9);}async['_get'](_0x5b8934){const _0x59adc2=await super['_get'](_0x5b8934);return this['localCache'][_0x5b8934]=JSON['stringify'](_0x59adc2),_0x59adc2;}async['_remove'](_0x3dba5f){await super['_remove'](_0x3dba5f),delete this['localCache'][_0x3dba5f];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x264fc0,_0x35291e){}['_removeListener'](_0x2acacc,_0x52ca7f){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x25b6b1){return Promise['all'](_0x25b6b1['map'](async _0x49ec70=>{try{return{'fulfilled':!0x0,'value':await _0x49ec70};}catch(_0xfd72f1){return{'fulfilled':!0x1,'reason':_0xfd72f1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xa0da1b){this['eventTarget']=_0xa0da1b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x20b222){const _0x3ed73a=this['receivers']['find'](_0x2b7f47=>_0x2b7f47['isListeningto'](_0x20b222));if(_0x3ed73a)return _0x3ed73a;const _0x3adc1f=new Xn(_0x20b222);return this['receivers']['push'](_0x3adc1f),_0x3adc1f;}['isListeningto'](_0x3866f4){return this['eventTarget']===_0x3866f4;}async['handleEvent'](_0x5220a9){const _0x2685a4=_0x5220a9,{eventId:_0x320cee,eventType:_0x1fe4cb,data:_0x60b677}=_0x2685a4['data'],_0x584b26=this['handlersMap'][_0x1fe4cb];if(!(_0x584b26!=null&&_0x584b26['size']))return;_0x2685a4['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x320cee,'eventType':_0x1fe4cb});const _0x4ee748=Array['from'](_0x584b26)['map'](async _0x3cd486=>_0x3cd486(_0x2685a4['origin'],_0x60b677)),_0x5e7557=await cp(_0x4ee748);_0x2685a4['ports'][0x0]['postMessage']({'status':'done','eventId':_0x320cee,'eventType':_0x1fe4cb,'response':_0x5e7557});}['_subscribe'](_0x18fc83,_0x5d2f99){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x18fc83]||(this['handlersMap'][_0x18fc83]=new Set()),this['handlersMap'][_0x18fc83]['add'](_0x5d2f99);}['_unsubscribe'](_0x5817e9,_0x4ac431){this['handlersMap'][_0x5817e9]&&_0x4ac431&&this['handlersMap'][_0x5817e9]['delete'](_0x4ac431),(!_0x4ac431||this['handlersMap'][_0x5817e9]['size']===0x0)&&delete this['handlersMap'][_0x5817e9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x8eb044='',_0x2a3048=0xa){let _0x29e9bc='';for(let _0x48235d=0x0;_0x48235d<_0x2a3048;_0x48235d++)_0x29e9bc+=Math['floor'](Math['random']()*0xa);return _0x8eb044+_0x29e9bc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x584934){this['target']=_0x584934,this['handlers']=new Set();}['removeMessageHandler'](_0x33b529){_0x33b529['messageChannel']&&(_0x33b529['messageChannel']['port1']['removeEventListener']('message',_0x33b529['onMessage']),_0x33b529['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x33b529);}async['_send'](_0x5ab7d6,_0x4223d8,_0x3f6102=0x32){const _0x11553f=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x11553f)throw new Error('connection_unavailable');let _0x8ba981,_0x3f8ae2;return new Promise((_0x5dbe25,_0xb3bba8)=>{const _0x42cd81=As('',0x14);_0x11553f['port1']['start']();const _0x3aad51=setTimeout(()=>{_0xb3bba8(new Error('unsupported_event'));},_0x3f6102);_0x3f8ae2={'messageChannel':_0x11553f,'onMessage'(_0x22142a){const _0x45c990=_0x22142a;if(_0x45c990['data']['eventId']===_0x42cd81)switch(_0x45c990['data']['status']){case'ack':clearTimeout(_0x3aad51),_0x8ba981=setTimeout(()=>{_0xb3bba8(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x8ba981),_0x5dbe25(_0x45c990['data']['response']);break;default:clearTimeout(_0x3aad51),clearTimeout(_0x8ba981),_0xb3bba8(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3f8ae2),_0x11553f['port1']['addEventListener']('message',_0x3f8ae2['onMessage']),this['target']['postMessage']({'eventType':_0x5ab7d6,'eventId':_0x42cd81,'data':_0x4223d8},[_0x11553f['port2']]);})['finally'](()=>{_0x3f8ae2&&this['removeMessageHandler'](_0x3f8ae2);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x2c1605){Z()['location']['href']=_0x2c1605;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4f8ceb;return((_0x4f8ceb=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4f8ceb['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x57d8ac){this['request']=_0x57d8ac;}['toPromise'](){return new Promise((_0x259eb6,_0xd1176d)=>{this['request']['addEventListener']('success',()=>{_0x259eb6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xd1176d(this['request']['error']);});});}}function Zn(_0x3e6b45,_0x304303){return _0x3e6b45['transaction']([Mn],_0x304303?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x129736=indexedDB['deleteDatabase'](Ka);return new nn(_0x129736)['toPromise']();}function Qa(){const _0x2b446f=indexedDB['open'](Ka,pp);return new Promise((_0x17b57e,_0x39ae4d)=>{_0x2b446f['addEventListener']('error',()=>{_0x39ae4d(_0x2b446f['error']);}),_0x2b446f['addEventListener']('upgradeneeded',()=>{const _0xcabf81=_0x2b446f['result'];try{_0xcabf81['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x11ebf0){_0x39ae4d(_0x11ebf0);}}),_0x2b446f['addEventListener']('success',async()=>{const _0x40a884=_0x2b446f['result'];_0x40a884['objectStoreNames']['contains'](Mn)?_0x17b57e(_0x40a884):(_0x40a884['close'](),await _p(),_0x17b57e(await Qa()));});});}async function Or(_0x5de5a4,_0x302ab1,_0x20aa09){const _0x5f0360=Zn(_0x5de5a4,!0x0)['put']({[Ya]:_0x302ab1,'value':_0x20aa09});return new nn(_0x5f0360)['toPromise']();}async function gp(_0x2c1113,_0x4fd41e){const _0x1c5650=Zn(_0x2c1113,!0x1)['get'](_0x4fd41e),_0x319fdf=await new nn(_0x1c5650)['toPromise']();return _0x319fdf===void 0x0?null:_0x319fdf['value'];}function Dr(_0x1eafbc,_0x18d88c){const _0x11a229=Zn(_0x1eafbc,!0x0)['delete'](_0x18d88c);return new nn(_0x11a229)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5519b5){let _0x196f3a=0x0;for(;;)try{const _0x58d3cc=await this['_openDb']();return await _0x5519b5(_0x58d3cc);}catch(_0x483cd9){if(_0x196f3a++>yp)throw _0x483cd9;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x559e28,_0xb3ce91)=>({'keyProcessed':(await this['_poll']())['includes'](_0xb3ce91['key'])})),this['receiver']['_subscribe']('ping',async(_0x60453a,_0x3351d3)=>['keyChanged']);}async['initializeSender'](){var _0x55b3a2,_0x55e71b;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2045d0=await this['sender']['_send']('ping',{},0x320);_0x2045d0&&(_0x55b3a2=_0x2045d0[0x0])!=null&&_0x55b3a2['fulfilled']&&(_0x55e71b=_0x2045d0[0x0])!=null&&_0x55e71b['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x241d9d){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x241d9d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x80217e=>{await Or(_0x80217e,Dn,'1'),await Dr(_0x80217e,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x8e25bd){this['pendingWrites']++;try{await _0x8e25bd();}finally{this['pendingWrites']--;}}async['_set'](_0x10715c,_0x1704b7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x89122b=>Or(_0x89122b,_0x10715c,_0x1704b7)),this['localCache'][_0x10715c]=_0x1704b7,this['notifyServiceWorker'](_0x10715c)));}async['_get'](_0x212ab1){const _0x409575=await this['_withRetries'](_0xcc69cc=>gp(_0xcc69cc,_0x212ab1));return this['localCache'][_0x212ab1]=_0x409575,_0x409575;}async['_remove'](_0xc1b4b6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x529789=>Dr(_0x529789,_0xc1b4b6)),delete this['localCache'][_0xc1b4b6],this['notifyServiceWorker'](_0xc1b4b6)));}async['_poll'](){const _0x486a98=await this['_withRetries'](_0x3d09d5=>{const _0x126e94=Zn(_0x3d09d5,!0x1)['getAll']();return new nn(_0x126e94)['toPromise']();});if(!_0x486a98)return[];if(this['pendingWrites']!==0x0)return[];const _0xea51ad=[],_0x316d06=new Set();if(_0x486a98['length']!==0x0){for(const {fbase_key:_0x3ecfba,value:_0x3f630e}of _0x486a98)_0x316d06['add'](_0x3ecfba),JSON['stringify'](this['localCache'][_0x3ecfba])!==JSON['stringify'](_0x3f630e)&&(this['notifyListeners'](_0x3ecfba,_0x3f630e),_0xea51ad['push'](_0x3ecfba));}for(const _0x338c46 of Object['keys'](this['localCache']))this['localCache'][_0x338c46]&&!_0x316d06['has'](_0x338c46)&&(this['notifyListeners'](_0x338c46,null),_0xea51ad['push'](_0x338c46));return _0xea51ad;}['notifyListeners'](_0x59f97a,_0x4d7453){this['localCache'][_0x59f97a]=_0x4d7453;const _0x5d9c19=this['listeners'][_0x59f97a];if(_0x5d9c19){for(const _0xdf0ec8 of Array['from'](_0x5d9c19))_0xdf0ec8(_0x4d7453);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xdc898f,_0x50f1c7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xdc898f]||(this['listeners'][_0xdc898f]=new Set(),this['_get'](_0xdc898f)),this['listeners'][_0xdc898f]['add'](_0x50f1c7);}['_removeListener'](_0x174686,_0x437412){this['listeners'][_0x174686]&&(this['listeners'][_0x174686]['delete'](_0x437412),this['listeners'][_0x174686]['size']===0x0&&delete this['listeners'][_0x174686]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1a8a82,_0x1e7599){return _0x1e7599?ie(_0x1e7599):(m(_0x1a8a82['_popupRedirectResolver'],_0x1a8a82,'argument-error'),_0x1a8a82['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x36d996){super('custom','custom'),this['params']=_0x36d996;}['_getIdTokenResponse'](_0x4e5965){return nt(_0x4e5965,this['_buildIdpRequest']());}['_linkToIdToken'](_0x30eba3,_0xd14cc5){return nt(_0x30eba3,this['_buildIdpRequest'](_0xd14cc5));}['_getReauthenticationResolver'](_0x56ce9){return nt(_0x56ce9,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x53a964){const _0x5e226b={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x53a964&&(_0x5e226b['idToken']=_0x53a964),_0x5e226b;}}function Ip(_0x3caf22){return Va(_0x3caf22['auth'],new ks(_0x3caf22),_0x3caf22['bypassAuthState']);}function wp(_0x6cd180){const {auth:_0x4e0f8b,user:_0xfb1ad7}=_0x6cd180;return m(_0xfb1ad7,_0x4e0f8b,'internal-error'),tp(_0xfb1ad7,new ks(_0x6cd180),_0x6cd180['bypassAuthState']);}async function Cp(_0x2842fe){const {auth:_0x21f4fc,user:_0x180382}=_0x2842fe;return m(_0x180382,_0x21f4fc,'internal-error'),ep(_0x180382,new ks(_0x2842fe),_0x2842fe['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x588438,_0x544877,_0x1dc4a5,_0x1245d9,_0x558a45=!0x1){this['auth']=_0x588438,this['resolver']=_0x1dc4a5,this['user']=_0x1245d9,this['bypassAuthState']=_0x558a45,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x544877)?_0x544877:[_0x544877];}['execute'](){return new Promise(async(_0x32f74a,_0x27c295)=>{this['pendingPromise']={'resolve':_0x32f74a,'reject':_0x27c295};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x638741){this['reject'](_0x638741);}});}async['onAuthEvent'](_0x221c45){const {urlResponse:_0x475ad9,sessionId:_0x492c1e,postBody:_0x1629b8,tenantId:_0x31f317,error:_0x534068,type:_0x8ee417}=_0x221c45;if(_0x534068){this['reject'](_0x534068);return;}const _0x22e5e7={'auth':this['auth'],'requestUri':_0x475ad9,'sessionId':_0x492c1e,'tenantId':_0x31f317||void 0x0,'postBody':_0x1629b8||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x8ee417)(_0x22e5e7));}catch(_0x218652){this['reject'](_0x218652);}}['onError'](_0x2634c0){this['reject'](_0x2634c0);}['getIdpTask'](_0x323dea){switch(_0x323dea){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x1c4456){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1c4456),this['unregisterAndCleanUp']();}['reject'](_0x3b8b96){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3b8b96),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5f3859,_0x22e482,_0x3e29c3,_0x13b576,_0x4d4f8d){super(_0x5f3859,_0x22e482,_0x13b576,_0x4d4f8d),this['provider']=_0x3e29c3,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x98bf54=await this['execute']();return m(_0x98bf54,this['auth'],'internal-error'),_0x98bf54;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3cae13=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3cae13),this['authWindow']['associatedEvent']=_0x3cae13,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1da884=>{this['reject'](_0x1da884);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1f6180=>{_0x1f6180||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5231df;return((_0x5231df=this['authWindow'])==null?void 0x0:_0x5231df['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3e207d=()=>{var _0x21bf6d,_0x310274;if((_0x310274=(_0x21bf6d=this['authWindow'])==null?void 0x0:_0x21bf6d['window'])!=null&&_0x310274['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3e207d,Tp['get']());};_0x3e207d();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2cee8a,_0x57b001,_0x246dc5=!0x1){super(_0x2cee8a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x57b001,void 0x0,_0x246dc5),this['eventId']=null;}async['execute'](){let _0x15f9ad=hn['get'](this['auth']['_key']());if(!_0x15f9ad){try{const _0x488e8b=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x15f9ad=()=>Promise['resolve'](_0x488e8b);}catch(_0x30070f){_0x15f9ad=()=>Promise['reject'](_0x30070f);}hn['set'](this['auth']['_key'](),_0x15f9ad);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x15f9ad();}async['onAuthEvent'](_0x17d9ce){if(_0x17d9ce['type']==='signInViaRedirect')return super['onAuthEvent'](_0x17d9ce);if(_0x17d9ce['type']==='unknown'){this['resolve'](null);return;}if(_0x17d9ce['eventId']){const _0x59d829=await this['auth']['_redirectUserForId'](_0x17d9ce['eventId']);if(_0x59d829)return this['user']=_0x59d829,super['onAuthEvent'](_0x17d9ce);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4f7a59,_0x4c7de8){const _0x56de0a=Pp(_0x4c7de8),_0x25a9ed=kp(_0x4f7a59);if(!await _0x25a9ed['_isAvailable']())return!0x1;const _0x211085=await _0x25a9ed['_get'](_0x56de0a)==='true';return await _0x25a9ed['_remove'](_0x56de0a),_0x211085;}function Ap(_0x2ee400,_0x394aaa){hn['set'](_0x2ee400['_key'](),_0x394aaa);}function kp(_0x332e06){return ie(_0x332e06['_redirectPersistence']);}function Pp(_0x345232){return ln(Sp,_0x345232['config']['apiKey'],_0x345232['name']);}async function Np(_0x42587d,_0x2e42da,_0x1f2aca=!0x1){if($(_0x42587d['app']))return Promise['reject'](re(_0x42587d));const _0x289b2e=Ke(_0x42587d),_0x5e01b6=Ep(_0x289b2e,_0x2e42da),_0x269ee4=await new bp(_0x289b2e,_0x5e01b6,_0x1f2aca)['execute']();return _0x269ee4&&!_0x1f2aca&&(delete _0x269ee4['user']['_redirectEventId'],await _0x289b2e['_persistUserIfCurrent'](_0x269ee4['user']),await _0x289b2e['_setRedirectUser'](null,_0x2e42da)),_0x269ee4;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x9d0c86){this['auth']=_0x9d0c86,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x31eda6){this['consumers']['add'](_0x31eda6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x31eda6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x31eda6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5184a1){this['consumers']['delete'](_0x5184a1);}['onEvent'](_0x3028be){if(this['hasEventBeenHandled'](_0x3028be))return!0x1;let _0x133fec=!0x1;return this['consumers']['forEach'](_0x2c1d83=>{this['isEventForConsumer'](_0x3028be,_0x2c1d83)&&(_0x133fec=!0x0,this['sendToConsumer'](_0x3028be,_0x2c1d83),this['saveEventToCache'](_0x3028be));}),this['hasHandledPotentialRedirect']||!Mp(_0x3028be)||(this['hasHandledPotentialRedirect']=!0x0,_0x133fec||(this['queuedRedirectEvent']=_0x3028be,_0x133fec=!0x0)),_0x133fec;}['sendToConsumer'](_0x29b254,_0x3724dd){var _0x1020f2;if(_0x29b254['error']&&!Za(_0x29b254)){const _0x2479c9=((_0x1020f2=_0x29b254['error']['code'])==null?void 0x0:_0x1020f2['split']('auth/')[0x1])||'internal-error';_0x3724dd['onError'](X(this['auth'],_0x2479c9));}else _0x3724dd['onAuthEvent'](_0x29b254);}['isEventForConsumer'](_0x300ed0,_0x20e44d){const _0x4a3f93=_0x20e44d['eventId']===null||!!_0x300ed0['eventId']&&_0x300ed0['eventId']===_0x20e44d['eventId'];return _0x20e44d['filter']['includes'](_0x300ed0['type'])&&_0x4a3f93;}['hasEventBeenHandled'](_0x334629){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x334629));}['saveEventToCache'](_0x4fa95b){this['cachedEventUids']['add'](Mr(_0x4fa95b)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x3098a6){return[_0x3098a6['type'],_0x3098a6['eventId'],_0x3098a6['sessionId'],_0x3098a6['tenantId']]['filter'](_0x26e354=>_0x26e354)['join']('-');}function Za({type:_0x5ce224,error:_0x199bca}){return _0x5ce224==='unknown'&&(_0x199bca==null?void 0x0:_0x199bca['code'])==='auth/no-auth-event';}function Mp(_0x30c58d){switch(_0x30c58d['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x30c58d);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x276a1c,_0x1d31f0={}){return Pe(_0x276a1c,'GET','/v1/projects',_0x1d31f0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x4aa15f){if(_0x4aa15f['config']['emulator'])return;const {authorizedDomains:_0x2193ed}=await Lp(_0x4aa15f);for(const _0x338a49 of _0x2193ed)try{if(Wp(_0x338a49))return;}catch{}Y(_0x4aa15f,'unauthorized-domain');}function Wp(_0xbb5333){const _0x1e8bd1=Mi(),{protocol:_0x537454,hostname:_0x54daad}=new URL(_0x1e8bd1);if(_0xbb5333['startsWith']('chrome-extension://')){const _0x17bd69=new URL(_0xbb5333);return _0x17bd69['hostname']===''&&_0x54daad===''?_0x537454==='chrome-extension:'&&_0xbb5333['replace']('chrome-extension://','')===_0x1e8bd1['replace']('chrome-extension://',''):_0x537454==='chrome-extension:'&&_0x17bd69['hostname']===_0x54daad;}if(!Fp['test'](_0x537454))return!0x1;if(xp['test'](_0xbb5333))return _0x54daad===_0xbb5333;const _0x47f181=_0xbb5333['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x47f181+'|'+_0x47f181+')$','i')['test'](_0x54daad);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x1dd542=Z()['___jsl'];if(_0x1dd542!=null&&_0x1dd542['H']){for(const _0x20f7d9 of Object['keys'](_0x1dd542['H']))if(_0x1dd542['H'][_0x20f7d9]['r']=_0x1dd542['H'][_0x20f7d9]['r']||[],_0x1dd542['H'][_0x20f7d9]['L']=_0x1dd542['H'][_0x20f7d9]['L']||[],_0x1dd542['H'][_0x20f7d9]['r']=[..._0x1dd542['H'][_0x20f7d9]['L']],_0x1dd542['CP']){for(let _0x4a53fc=0x0;_0x4a53fc<_0x1dd542['CP']['length'];_0x4a53fc++)_0x1dd542['CP'][_0x4a53fc]=null;}}}function Vp(_0x9990de){return new Promise((_0x4b61e5,_0x160c08)=>{var _0x3650df,_0x9c31f1,_0x51e8cc;function _0xd277d6(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4b61e5(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x160c08(X(_0x9990de,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x9c31f1=(_0x3650df=Z()['gapi'])==null?void 0x0:_0x3650df['iframes'])!=null&&_0x9c31f1['Iframe'])_0x4b61e5(gapi['iframes']['getContext']());else{if((_0x51e8cc=Z()['gapi'])!=null&&_0x51e8cc['load'])_0xd277d6();else{const _0x26723a=Ff('iframefcb');return Z()[_0x26723a]=()=>{gapi['load']?_0xd277d6():_0x160c08(X(_0x9990de,'network-request-failed'));},xa(xf()+'?onload='+_0x26723a)['catch'](_0x3dd39f=>_0x160c08(_0x3dd39f));}}})['catch'](_0x36e968=>{throw un=null,_0x36e968;});}let un=null;function Hp(_0x4f1451){return un=un||Vp(_0x4f1451),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x4934cb){const _0xabcd13=_0x4934cb['config'];m(_0xabcd13['authDomain'],_0x4934cb,'auth-domain-config-required');const _0x13c0a2=_0xabcd13['emulator']?Cs(_0xabcd13,qp):'https://'+_0x4934cb['config']['authDomain']+'/'+Gp,_0x5ae96a={'apiKey':_0xabcd13['apiKey'],'appName':_0x4934cb['name'],'v':dt},_0x1a3bda=jp['get'](_0x4934cb['config']['apiHost']);_0x1a3bda&&(_0x5ae96a['eid']=_0x1a3bda);const _0x50fbd9=_0x4934cb['_getFrameworks']();return _0x50fbd9['length']&&(_0x5ae96a['fw']=_0x50fbd9['join'](',')),_0x13c0a2+'?'+ut(_0x5ae96a)['slice'](0x1);}async function Yp(_0x2f204f){const _0x257314=await Hp(_0x2f204f),_0x4497a1=Z()['gapi'];return m(_0x4497a1,_0x2f204f,'internal-error'),_0x257314['open']({'where':document['body'],'url':Kp(_0x2f204f),'messageHandlersFilter':_0x4497a1['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x3b2d54=>new Promise(async(_0x1d658b,_0x62a52e)=>{await _0x3b2d54['restyle']({'setHideOnLeave':!0x1});const _0x10bd5f=X(_0x2f204f,'network-request-failed'),_0x56f92e=Z()['setTimeout'](()=>{_0x62a52e(_0x10bd5f);},$p['get']());function _0x4084b0(){Z()['clearTimeout'](_0x56f92e),_0x1d658b(_0x3b2d54);}_0x3b2d54['ping'](_0x4084b0)['then'](_0x4084b0,()=>{_0x62a52e(_0x10bd5f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3c5288){this['window']=_0x3c5288,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x3f2102,_0x12bb61,_0x430485,_0x4bc10f=Jp,_0x3fe477=Xp){const _0x2425a4=Math['max']((window['screen']['availHeight']-_0x3fe477)/0x2,0x0)['toString'](),_0x591fbe=Math['max']((window['screen']['availWidth']-_0x4bc10f)/0x2,0x0)['toString']();let _0x373e89='';const _0x344ef7={...Qp,'width':_0x4bc10f['toString'](),'height':_0x3fe477['toString'](),'top':_0x2425a4,'left':_0x591fbe},_0x9ead54=W()['toLowerCase']();_0x430485&&(_0x373e89=ka(_0x9ead54)?Zp:_0x430485),Ra(_0x9ead54)&&(_0x12bb61=_0x12bb61||e_,_0x344ef7['scrollbars']='yes');const _0x2c4c7c=Object['entries'](_0x344ef7)['reduce']((_0x57276b,[_0x119557,_0x4b4284])=>''+_0x57276b+_0x119557+'='+_0x4b4284+',','');if(Rf(_0x9ead54)&&_0x373e89!=='_self')return n_(_0x12bb61||'',_0x373e89),new xr(null);const _0x2c1f67=window['open'](_0x12bb61||'',_0x373e89,_0x2c4c7c);m(_0x2c1f67,_0x3f2102,'popup-blocked');try{_0x2c1f67['focus']();}catch{}return new xr(_0x2c1f67);}function n_(_0x3d8891,_0x3337e8){const _0x59b30e=document['createElement']('a');_0x59b30e['href']=_0x3d8891,_0x59b30e['target']=_0x3337e8;const _0x53efa4=document['createEvent']('MouseEvent');_0x53efa4['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x59b30e['dispatchEvent'](_0x53efa4);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x4ef0f1,_0x54871,_0x2bd16e,_0x6e080d,_0x2caa7e,_0x1797dc){m(_0x4ef0f1['config']['authDomain'],_0x4ef0f1,'auth-domain-config-required'),m(_0x4ef0f1['config']['apiKey'],_0x4ef0f1,'invalid-api-key');const _0x1f4ba7={'apiKey':_0x4ef0f1['config']['apiKey'],'appName':_0x4ef0f1['name'],'authType':_0x2bd16e,'redirectUrl':_0x6e080d,'v':dt,'eventId':_0x2caa7e};if(_0x54871 instanceof Wa){_0x54871['setDefaultLanguage'](_0x4ef0f1['languageCode']),_0x1f4ba7['providerId']=_0x54871['providerId']||'',pn(_0x54871['getCustomParameters']())||(_0x1f4ba7['customParameters']=JSON['stringify'](_0x54871['getCustomParameters']()));for(const [_0x2c1586,_0x136409]of Object['entries']({}))_0x1f4ba7[_0x2c1586]=_0x136409;}if(_0x54871 instanceof tn){const _0x1cafaf=_0x54871['getScopes']()['filter'](_0x12ab3f=>_0x12ab3f!=='');_0x1cafaf['length']>0x0&&(_0x1f4ba7['scopes']=_0x1cafaf['join'](','));}_0x4ef0f1['tenantId']&&(_0x1f4ba7['tid']=_0x4ef0f1['tenantId']);const _0x38c463=_0x1f4ba7;for(const _0x4eb29b of Object['keys'](_0x38c463))_0x38c463[_0x4eb29b]===void 0x0&&delete _0x38c463[_0x4eb29b];const _0x4c6c29=await _0x4ef0f1['_getAppCheckToken'](),_0x5d92b5=_0x4c6c29?'#'+r_+'='+encodeURIComponent(_0x4c6c29):'';return o_(_0x4ef0f1)+'?'+ut(_0x38c463)['slice'](0x1)+_0x5d92b5;}function o_({config:_0x59f58c}){return _0x59f58c['emulator']?Cs(_0x59f58c,s_):'https://'+_0x59f58c['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x5e32d3,_0xcf2d22,_0x40e537,_0x4116e0){var _0xdd5eb4;ce((_0xdd5eb4=this['eventManagers'][_0x5e32d3['_key']()])==null?void 0x0:_0xdd5eb4['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x142850=await Fr(_0x5e32d3,_0xcf2d22,_0x40e537,Mi(),_0x4116e0);return t_(_0x5e32d3,_0x142850,As());}async['_openRedirect'](_0x1e6276,_0x4d4ca6,_0x472db4,_0x2b8be0){await this['_originValidation'](_0x1e6276);const _0x7d6394=await Fr(_0x1e6276,_0x4d4ca6,_0x472db4,Mi(),_0x2b8be0);return hp(_0x7d6394),new Promise(()=>{});}['_initialize'](_0x415d1a){const _0x506621=_0x415d1a['_key']();if(this['eventManagers'][_0x506621]){const {manager:_0x9f0d29,promise:_0x2e2b80}=this['eventManagers'][_0x506621];return _0x9f0d29?Promise['resolve'](_0x9f0d29):(ce(_0x2e2b80,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2e2b80);}const _0x3c04ea=this['initAndGetManager'](_0x415d1a);return this['eventManagers'][_0x506621]={'promise':_0x3c04ea},_0x3c04ea['catch'](()=>{delete this['eventManagers'][_0x506621];}),_0x3c04ea;}async['initAndGetManager'](_0x4a6d08){const _0x476d43=await Yp(_0x4a6d08),_0x49a93a=new Dp(_0x4a6d08);return _0x476d43['register']('authEvent',_0x4a75a6=>(m(_0x4a75a6==null?void 0x0:_0x4a75a6['authEvent'],_0x4a6d08,'invalid-auth-event'),{'status':_0x49a93a['onEvent'](_0x4a75a6['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4a6d08['_key']()]={'manager':_0x49a93a},this['iframes'][_0x4a6d08['_key']()]=_0x476d43,_0x49a93a;}['_isIframeWebStorageSupported'](_0x46738b,_0x1f30c0){this['iframes'][_0x46738b['_key']()]['send'](pi,{'type':pi},_0x3fe0cc=>{var _0x1ac96d;const _0x1c49ef=(_0x1ac96d=_0x3fe0cc==null?void 0x0:_0x3fe0cc[0x0])==null?void 0x0:_0x1ac96d[pi];_0x1c49ef!==void 0x0&&_0x1f30c0(!!_0x1c49ef),Y(_0x46738b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x537954){const _0x344bc2=_0x537954['_key']();return this['originValidationPromises'][_0x344bc2]||(this['originValidationPromises'][_0x344bc2]=Up(_0x537954)),this['originValidationPromises'][_0x344bc2];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x592bbc){this['auth']=_0x592bbc,this['internalListeners']=new Map();}['getUid'](){var _0xd1abcf;return this['assertAuthConfigured'](),((_0xd1abcf=this['auth']['currentUser'])==null?void 0x0:_0xd1abcf['uid'])||null;}async['getToken'](_0x25e995){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x25e995)}:null;}['addAuthTokenListener'](_0x58a928){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x58a928))return;const _0x24b8d3=this['auth']['onIdTokenChanged'](_0x8af3cf=>{_0x58a928((_0x8af3cf==null?void 0x0:_0x8af3cf['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x58a928,_0x24b8d3),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xec49fb){this['assertAuthConfigured']();const _0x54f24d=this['internalListeners']['get'](_0xec49fb);_0x54f24d&&(this['internalListeners']['delete'](_0xec49fb),_0x54f24d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1379a1){switch(_0x1379a1){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x45645e){st(new Fe('auth',(_0x2deaa7,{options:_0x4d9e62})=>{const _0x293f95=_0x2deaa7['getProvider']('app')['getImmediate'](),_0xd215ff=_0x2deaa7['getProvider']('heartbeat'),_0x52a8b9=_0x2deaa7['getProvider']('app-check-internal'),{apiKey:_0x3390db,authDomain:_0x5b80de}=_0x293f95['options'];m(_0x3390db&&!_0x3390db['includes'](':'),'invalid-api-key',{'appName':_0x293f95['name']});const _0x5c248e={'apiKey':_0x3390db,'authDomain':_0x5b80de,'clientPlatform':_0x45645e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x45645e)},_0x28b4e0=new Df(_0x293f95,_0xd215ff,_0x52a8b9,_0x5c248e);return Hf(_0x28b4e0,_0x4d9e62),_0x28b4e0;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x332040,_0x2f6eff,_0x102733)=>{_0x332040['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x647e3d=>{const _0x1b508b=Ke(_0x647e3d['getProvider']('auth')['getImmediate']());return(_0x19945b=>new l_(_0x19945b))(_0x1b508b);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x45645e)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x4d2bd7=>async _0x33a06d=>{const _0x2e85dc=_0x33a06d&&await _0x33a06d['getIdTokenResult'](),_0x51d2cb=_0x2e85dc&&(new Date()['getTime']()-Date['parse'](_0x2e85dc['issuedAtTime']))/0x3e8;if(_0x51d2cb&&_0x51d2cb>f_)return;const _0x1cba8e=_0x2e85dc==null?void 0x0:_0x2e85dc['token'];Br!==_0x1cba8e&&(Br=_0x1cba8e,await fetch(_0x4d2bd7,{'method':_0x1cba8e?'POST':'DELETE','headers':_0x1cba8e?{'Authorization':'Bearer\x20'+_0x1cba8e}:{}}));};function B_(_0x482d9f=Zr()){const _0x17d716=Hi(_0x482d9f,'auth');if(_0x17d716['isInitialized']())return _0x17d716['getImmediate']();const _0x243899=Vf(_0x482d9f,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0xc5d82a=jr('authTokenSyncURL');if(_0xc5d82a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4fefd9=new URL(_0xc5d82a,location['origin']);if(location['origin']===_0x4fefd9['origin']){const _0x9b52af=p_(_0x4fefd9['toString']());sp(_0x243899,_0x9b52af,()=>_0x9b52af(_0x243899['currentUser'])),ip(_0x243899,_0x5675f8=>_0x9b52af(_0x5675f8));}}const _0x134148=qr('auth');return _0x134148&&$f(_0x243899,'http://'+_0x134148),_0x243899;}function __(){var _0x56e1f9;return((_0x56e1f9=document['getElementsByTagName']('head'))==null?void 0x0:_0x56e1f9[0x0])??document;}Mf({'loadJS'(_0x3ad950){return new Promise((_0x44ea11,_0x11d25c)=>{const _0x3aca52=document['createElement']('script');_0x3aca52['setAttribute']('src',_0x3ad950),_0x3aca52['onload']=_0x44ea11,_0x3aca52['onerror']=_0x532054=>{const _0xf46f46=X('internal-error');_0xf46f46['customData']=_0x532054,_0x11d25c(_0xf46f46);},_0x3aca52['type']='text/javascript',_0x3aca52['charset']='UTF-8',__()['appendChild'](_0x3aca52);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{T_ as A,C_ as B,S_ as C,L_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,W_ as h,Sl as i,m_ as j,Hd as k,D_ as l,Gd as m,N_ as n,v_ as o,U_ as p,O_ as q,y_ as r,F_ as s,k_ as t,I_ as u,b_ as v,A_ as w,Vt as x,E_ as y,M_ as z};