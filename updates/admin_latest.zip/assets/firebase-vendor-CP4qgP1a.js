const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1832d5,_0x208ee0){if(!_0x1832d5)throw ht(_0x208ee0);},ht=function(_0x1e238f){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1e238f);},Hr=function(_0x33bd1c){const _0xf95c90=[];let _0x3ecc02=0x0;for(let _0x353ccd=0x0;_0x353ccd<_0x33bd1c['length'];_0x353ccd++){let _0x179574=_0x33bd1c['charCodeAt'](_0x353ccd);_0x179574<0x80?_0xf95c90[_0x3ecc02++]=_0x179574:_0x179574<0x800?(_0xf95c90[_0x3ecc02++]=_0x179574>>0x6|0xc0,_0xf95c90[_0x3ecc02++]=_0x179574&0x3f|0x80):(_0x179574&0xfc00)===0xd800&&_0x353ccd+0x1<_0x33bd1c['length']&&(_0x33bd1c['charCodeAt'](_0x353ccd+0x1)&0xfc00)===0xdc00?(_0x179574=0x10000+((_0x179574&0x3ff)<<0xa)+(_0x33bd1c['charCodeAt'](++_0x353ccd)&0x3ff),_0xf95c90[_0x3ecc02++]=_0x179574>>0x12|0xf0,_0xf95c90[_0x3ecc02++]=_0x179574>>0xc&0x3f|0x80,_0xf95c90[_0x3ecc02++]=_0x179574>>0x6&0x3f|0x80,_0xf95c90[_0x3ecc02++]=_0x179574&0x3f|0x80):(_0xf95c90[_0x3ecc02++]=_0x179574>>0xc|0xe0,_0xf95c90[_0x3ecc02++]=_0x179574>>0x6&0x3f|0x80,_0xf95c90[_0x3ecc02++]=_0x179574&0x3f|0x80);}return _0xf95c90;},nc=function(_0x28ff62){const _0x5874f0=[];let _0x169379=0x0,_0x4cacb4=0x0;for(;_0x169379<_0x28ff62['length'];){const _0x31976f=_0x28ff62[_0x169379++];if(_0x31976f<0x80)_0x5874f0[_0x4cacb4++]=String['fromCharCode'](_0x31976f);else{if(_0x31976f>0xbf&&_0x31976f<0xe0){const _0x52cdeb=_0x28ff62[_0x169379++];_0x5874f0[_0x4cacb4++]=String['fromCharCode']((_0x31976f&0x1f)<<0x6|_0x52cdeb&0x3f);}else{if(_0x31976f>0xef&&_0x31976f<0x16d){const _0x519e06=_0x28ff62[_0x169379++],_0x43f341=_0x28ff62[_0x169379++],_0x110dff=_0x28ff62[_0x169379++],_0x434de6=((_0x31976f&0x7)<<0x12|(_0x519e06&0x3f)<<0xc|(_0x43f341&0x3f)<<0x6|_0x110dff&0x3f)-0x10000;_0x5874f0[_0x4cacb4++]=String['fromCharCode'](0xd800+(_0x434de6>>0xa)),_0x5874f0[_0x4cacb4++]=String['fromCharCode'](0xdc00+(_0x434de6&0x3ff));}else{const _0x905ca2=_0x28ff62[_0x169379++],_0x3c67f8=_0x28ff62[_0x169379++];_0x5874f0[_0x4cacb4++]=String['fromCharCode']((_0x31976f&0xf)<<0xc|(_0x905ca2&0x3f)<<0x6|_0x3c67f8&0x3f);}}}}return _0x5874f0['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x17510d,_0xc11cdc){if(!Array['isArray'](_0x17510d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x30906d=_0xc11cdc?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1b1240=[];for(let _0x42a3a3=0x0;_0x42a3a3<_0x17510d['length'];_0x42a3a3+=0x3){const _0x1887af=_0x17510d[_0x42a3a3],_0x569032=_0x42a3a3+0x1<_0x17510d['length'],_0x45afb6=_0x569032?_0x17510d[_0x42a3a3+0x1]:0x0,_0xef9a73=_0x42a3a3+0x2<_0x17510d['length'],_0x235c79=_0xef9a73?_0x17510d[_0x42a3a3+0x2]:0x0,_0x57e2ff=_0x1887af>>0x2,_0x1ff9b7=(_0x1887af&0x3)<<0x4|_0x45afb6>>0x4;let _0x3b21fe=(_0x45afb6&0xf)<<0x2|_0x235c79>>0x6,_0x2c32e7=_0x235c79&0x3f;_0xef9a73||(_0x2c32e7=0x40,_0x569032||(_0x3b21fe=0x40)),_0x1b1240['push'](_0x30906d[_0x57e2ff],_0x30906d[_0x1ff9b7],_0x30906d[_0x3b21fe],_0x30906d[_0x2c32e7]);}return _0x1b1240['join']('');},'encodeString'(_0x15471d,_0x2848cd){return this['HAS_NATIVE_SUPPORT']&&!_0x2848cd?btoa(_0x15471d):this['encodeByteArray'](Hr(_0x15471d),_0x2848cd);},'decodeString'(_0x46de1f,_0x5bdecb){return this['HAS_NATIVE_SUPPORT']&&!_0x5bdecb?atob(_0x46de1f):nc(this['decodeStringToByteArray'](_0x46de1f,_0x5bdecb));},'decodeStringToByteArray'(_0x202deb,_0x2d4b68){this['init_']();const _0x2564f1=_0x2d4b68?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x455b3d=[];for(let _0x886a81=0x0;_0x886a81<_0x202deb['length'];){const _0x1a4c1e=_0x2564f1[_0x202deb['charAt'](_0x886a81++)],_0x1ecdf2=_0x886a81<_0x202deb['length']?_0x2564f1[_0x202deb['charAt'](_0x886a81)]:0x0;++_0x886a81;const _0x28a276=_0x886a81<_0x202deb['length']?_0x2564f1[_0x202deb['charAt'](_0x886a81)]:0x40;++_0x886a81;const _0x41d506=_0x886a81<_0x202deb['length']?_0x2564f1[_0x202deb['charAt'](_0x886a81)]:0x40;if(++_0x886a81,_0x1a4c1e==null||_0x1ecdf2==null||_0x28a276==null||_0x41d506==null)throw new ic();const _0x56ea34=_0x1a4c1e<<0x2|_0x1ecdf2>>0x4;if(_0x455b3d['push'](_0x56ea34),_0x28a276!==0x40){const _0x4e3c4f=_0x1ecdf2<<0x4&0xf0|_0x28a276>>0x2;if(_0x455b3d['push'](_0x4e3c4f),_0x41d506!==0x40){const _0x1c5282=_0x28a276<<0x6&0xc0|_0x41d506;_0x455b3d['push'](_0x1c5282);}}}return _0x455b3d;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5dbf02=0x0;_0x5dbf02<this['ENCODED_VALS']['length'];_0x5dbf02++)this['byteToCharMap_'][_0x5dbf02]=this['ENCODED_VALS']['charAt'](_0x5dbf02),this['charToByteMap_'][this['byteToCharMap_'][_0x5dbf02]]=_0x5dbf02,this['byteToCharMapWebSafe_'][_0x5dbf02]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5dbf02),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5dbf02]]=_0x5dbf02,_0x5dbf02>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5dbf02)]=_0x5dbf02,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5dbf02)]=_0x5dbf02);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x500873){const _0x1446c0=Hr(_0x500873);return Fi['encodeByteArray'](_0x1446c0,!0x0);},dn=function(_0x1524cd){return $r(_0x1524cd)['replace'](/\./g,'');},fn=function(_0xf022ba){try{return Fi['decodeString'](_0xf022ba,!0x0);}catch(_0x56b431){console['error']('base64Decode\x20failed:\x20',_0x56b431);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3e1196){return Gr(void 0x0,_0x3e1196);}function Gr(_0x1bda10,_0x56a4f3){if(!(_0x56a4f3 instanceof Object))return _0x56a4f3;switch(_0x56a4f3['constructor']){case Date:const _0x263f8e=_0x56a4f3;return new Date(_0x263f8e['getTime']());case Object:_0x1bda10===void 0x0&&(_0x1bda10={});break;case Array:_0x1bda10=[];break;default:return _0x56a4f3;}for(const _0x442c4f in _0x56a4f3)!_0x56a4f3['hasOwnProperty'](_0x442c4f)||!rc(_0x442c4f)||(_0x1bda10[_0x442c4f]=Gr(_0x1bda10[_0x442c4f],_0x56a4f3[_0x442c4f]));return _0x1bda10;}function rc(_0x1fa7f4){return _0x1fa7f4!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x382ab8=Ps['__FIREBASE_DEFAULTS__'];if(_0x382ab8)return JSON['parse'](_0x382ab8);},lc=()=>{if(typeof document>'u')return;let _0x5f0619;try{_0x5f0619=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x58e80b=_0x5f0619&&fn(_0x5f0619[0x1]);return _0x58e80b&&JSON['parse'](_0x58e80b);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xebe4fb){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xebe4fb);return;}},qr=_0x3bcd62=>{var _0x139ed2,_0x5bacd0;return(_0x5bacd0=(_0x139ed2=Ui())==null?void 0x0:_0x139ed2['emulatorHosts'])==null?void 0x0:_0x5bacd0[_0x3bcd62];},hc=_0x25e69a=>{const _0x573783=qr(_0x25e69a);if(!_0x573783)return;const _0x3e13b2=_0x573783['lastIndexOf'](':');if(_0x3e13b2<=0x0||_0x3e13b2+0x1===_0x573783['length'])throw new Error('Invalid\x20host\x20'+_0x573783+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x10790c=parseInt(_0x573783['substring'](_0x3e13b2+0x1),0xa);return _0x573783[0x0]==='['?[_0x573783['substring'](0x1,_0x3e13b2-0x1),_0x10790c]:[_0x573783['substring'](0x0,_0x3e13b2),_0x10790c];},zr=()=>{var _0x3141df;return(_0x3141df=Ui())==null?void 0x0:_0x3141df['config'];},jr=_0x3efad4=>{var _0x554d31;return(_0x554d31=Ui())==null?void 0x0:_0x554d31['_'+_0x3efad4];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3bfacf,_0x104f6d)=>{this['resolve']=_0x3bfacf,this['reject']=_0x104f6d;});}['wrapCallback'](_0x3aacf0){return(_0x49df14,_0x37aa01)=>{_0x49df14?this['reject'](_0x49df14):this['resolve'](_0x37aa01),typeof _0x3aacf0=='function'&&(this['promise']['catch'](()=>{}),_0x3aacf0['length']===0x1?_0x3aacf0(_0x49df14):_0x3aacf0(_0x49df14,_0x37aa01));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x49eb91,_0xdb6809){if(_0x49eb91['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1c8085={'alg':'none','type':'JWT'},_0x738461=_0xdb6809||'demo-project',_0x3d5402=_0x49eb91['iat']||0x0,_0x3fbd89=_0x49eb91['sub']||_0x49eb91['user_id'];if(!_0x3fbd89)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x48e902={'iss':'https://securetoken.google.com/'+_0x738461,'aud':_0x738461,'iat':_0x3d5402,'exp':_0x3d5402+0xe10,'auth_time':_0x3d5402,'sub':_0x3fbd89,'user_id':_0x3fbd89,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x49eb91};return[dn(JSON['stringify'](_0x1c8085)),dn(JSON['stringify'](_0x48e902)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x439d5e=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x439d5e=='object'&&_0x439d5e['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1593dd=W();return _0x1593dd['indexOf']('MSIE\x20')>=0x0||_0x1593dd['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x246342,_0x3147f3)=>{try{let _0x28d8f4=!0x0;const _0x162715='validate-browser-context-for-indexeddb-analytics-module',_0x3abf39=self['indexedDB']['open'](_0x162715);_0x3abf39['onsuccess']=()=>{_0x3abf39['result']['close'](),_0x28d8f4||self['indexedDB']['deleteDatabase'](_0x162715),_0x246342(!0x0);},_0x3abf39['onupgradeneeded']=()=>{_0x28d8f4=!0x1;},_0x3abf39['onerror']=()=>{var _0x254eea;_0x3147f3(((_0x254eea=_0x3abf39['error'])==null?void 0x0:_0x254eea['message'])||'');};}catch(_0x3465f9){_0x3147f3(_0x3465f9);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x148cfc,_0x7b043c,_0x333800){super(_0x7b043c),this['code']=_0x148cfc,this['customData']=_0x333800,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0xc237dd,_0x3a0aa0,_0x559ad6){this['service']=_0xc237dd,this['serviceName']=_0x3a0aa0,this['errors']=_0x559ad6;}['create'](_0x4fda0a,..._0x434fce){const _0x2e3e2e=_0x434fce[0x0]||{},_0x3e4c20=this['service']+'/'+_0x4fda0a,_0x48d202=this['errors'][_0x4fda0a],_0x4f1e49=_0x48d202?vc(_0x48d202,_0x2e3e2e):'Error',_0x1e2c05=this['serviceName']+':\x20'+_0x4f1e49+'\x20('+_0x3e4c20+').';return new Re(_0x3e4c20,_0x1e2c05,_0x2e3e2e);}}function vc(_0x58459b,_0x25ca5f){return _0x58459b['replace'](Ec,(_0x558ce6,_0x49da80)=>{const _0x305b82=_0x25ca5f[_0x49da80];return _0x305b82!=null?String(_0x305b82):'<'+_0x49da80+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x254ec4){return JSON['parse'](_0x254ec4);}function O(_0x56d2af){return JSON['stringify'](_0x56d2af);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x12ecaa){let _0x564edc={},_0x2c2a1d={},_0x31c93f={},_0x349046='';try{const _0x2b2510=_0x12ecaa['split']('.');_0x564edc=Nt(fn(_0x2b2510[0x0])||''),_0x2c2a1d=Nt(fn(_0x2b2510[0x1])||''),_0x349046=_0x2b2510[0x2],_0x31c93f=_0x2c2a1d['d']||{},delete _0x2c2a1d['d'];}catch{}return{'header':_0x564edc,'claims':_0x2c2a1d,'data':_0x31c93f,'signature':_0x349046};},Ic=function(_0x2ff46b){const _0x5b96eb=Yr(_0x2ff46b),_0x5d0eb=_0x5b96eb['claims'];return!!_0x5d0eb&&typeof _0x5d0eb=='object'&&_0x5d0eb['hasOwnProperty']('iat');},wc=function(_0x1d2ca0){const _0x357596=Yr(_0x1d2ca0)['claims'];return typeof _0x357596=='object'&&_0x357596['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4a1c45,_0x29cb83){return Object['prototype']['hasOwnProperty']['call'](_0x4a1c45,_0x29cb83);}function Le(_0x57c7d4,_0x3ed03e){if(Object['prototype']['hasOwnProperty']['call'](_0x57c7d4,_0x3ed03e))return _0x57c7d4[_0x3ed03e];}function pn(_0x4be8f1){for(const _0x556041 in _0x4be8f1)if(Object['prototype']['hasOwnProperty']['call'](_0x4be8f1,_0x556041))return!0x1;return!0x0;}function _n(_0x417ddc,_0x2bb798,_0x3c8d0c){const _0xf9ff92={};for(const _0x22d443 in _0x417ddc)Object['prototype']['hasOwnProperty']['call'](_0x417ddc,_0x22d443)&&(_0xf9ff92[_0x22d443]=_0x2bb798['call'](_0x3c8d0c,_0x417ddc[_0x22d443],_0x22d443,_0x417ddc));return _0xf9ff92;}function xe(_0x2ba54c,_0x4f728a){if(_0x2ba54c===_0x4f728a)return!0x0;const _0x3206d9=Object['keys'](_0x2ba54c),_0x20e803=Object['keys'](_0x4f728a);for(const _0x4c065a of _0x3206d9){if(!_0x20e803['includes'](_0x4c065a))return!0x1;const _0x5205eb=_0x2ba54c[_0x4c065a],_0xf8f458=_0x4f728a[_0x4c065a];if(Ns(_0x5205eb)&&Ns(_0xf8f458)){if(!xe(_0x5205eb,_0xf8f458))return!0x1;}else{if(_0x5205eb!==_0xf8f458)return!0x1;}}for(const _0x4fcace of _0x20e803)if(!_0x3206d9['includes'](_0x4fcace))return!0x1;return!0x0;}function Ns(_0x3113b8){return _0x3113b8!==null&&typeof _0x3113b8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x13b41b){const _0x1aaf9a=[];for(const [_0x26fcd0,_0x359195]of Object['entries'](_0x13b41b))Array['isArray'](_0x359195)?_0x359195['forEach'](_0x2f5b5b=>{_0x1aaf9a['push'](encodeURIComponent(_0x26fcd0)+'='+encodeURIComponent(_0x2f5b5b));}):_0x1aaf9a['push'](encodeURIComponent(_0x26fcd0)+'='+encodeURIComponent(_0x359195));return _0x1aaf9a['length']?'&'+_0x1aaf9a['join']('&'):'';}function Ct(_0x497315){const _0x57db32={};return _0x497315['replace'](/^\?/,'')['split']('&')['forEach'](_0x47a66e=>{if(_0x47a66e){const [_0x35e8a1,_0x3b4f4e]=_0x47a66e['split']('=');_0x57db32[decodeURIComponent(_0x35e8a1)]=decodeURIComponent(_0x3b4f4e);}}),_0x57db32;}function Tt(_0x132a2b){const _0x47c0d9=_0x132a2b['indexOf']('?');if(!_0x47c0d9)return'';const _0x1c407c=_0x132a2b['indexOf']('#',_0x47c0d9);return _0x132a2b['substring'](_0x47c0d9,_0x1c407c>0x0?_0x1c407c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5df411=0x1;_0x5df411<this['blockSize'];++_0x5df411)this['pad_'][_0x5df411]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2ea10b,_0x46f1da){_0x46f1da||(_0x46f1da=0x0);const _0x18416b=this['W_'];if(typeof _0x2ea10b=='string'){for(let _0x47af65=0x0;_0x47af65<0x10;_0x47af65++)_0x18416b[_0x47af65]=_0x2ea10b['charCodeAt'](_0x46f1da)<<0x18|_0x2ea10b['charCodeAt'](_0x46f1da+0x1)<<0x10|_0x2ea10b['charCodeAt'](_0x46f1da+0x2)<<0x8|_0x2ea10b['charCodeAt'](_0x46f1da+0x3),_0x46f1da+=0x4;}else{for(let _0x41c2df=0x0;_0x41c2df<0x10;_0x41c2df++)_0x18416b[_0x41c2df]=_0x2ea10b[_0x46f1da]<<0x18|_0x2ea10b[_0x46f1da+0x1]<<0x10|_0x2ea10b[_0x46f1da+0x2]<<0x8|_0x2ea10b[_0x46f1da+0x3],_0x46f1da+=0x4;}for(let _0x233a8d=0x10;_0x233a8d<0x50;_0x233a8d++){const _0x94c31a=_0x18416b[_0x233a8d-0x3]^_0x18416b[_0x233a8d-0x8]^_0x18416b[_0x233a8d-0xe]^_0x18416b[_0x233a8d-0x10];_0x18416b[_0x233a8d]=(_0x94c31a<<0x1|_0x94c31a>>>0x1f)&0xffffffff;}let _0x334cbf=this['chain_'][0x0],_0x3cfc92=this['chain_'][0x1],_0x41e560=this['chain_'][0x2],_0xa65ecf=this['chain_'][0x3],_0x2d2b2e=this['chain_'][0x4],_0x25601e,_0x579f4d;for(let _0x1a183b=0x0;_0x1a183b<0x50;_0x1a183b++){_0x1a183b<0x28?_0x1a183b<0x14?(_0x25601e=_0xa65ecf^_0x3cfc92&(_0x41e560^_0xa65ecf),_0x579f4d=0x5a827999):(_0x25601e=_0x3cfc92^_0x41e560^_0xa65ecf,_0x579f4d=0x6ed9eba1):_0x1a183b<0x3c?(_0x25601e=_0x3cfc92&_0x41e560|_0xa65ecf&(_0x3cfc92|_0x41e560),_0x579f4d=0x8f1bbcdc):(_0x25601e=_0x3cfc92^_0x41e560^_0xa65ecf,_0x579f4d=0xca62c1d6);const _0x52dfbc=(_0x334cbf<<0x5|_0x334cbf>>>0x1b)+_0x25601e+_0x2d2b2e+_0x579f4d+_0x18416b[_0x1a183b]&0xffffffff;_0x2d2b2e=_0xa65ecf,_0xa65ecf=_0x41e560,_0x41e560=(_0x3cfc92<<0x1e|_0x3cfc92>>>0x2)&0xffffffff,_0x3cfc92=_0x334cbf,_0x334cbf=_0x52dfbc;}this['chain_'][0x0]=this['chain_'][0x0]+_0x334cbf&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3cfc92&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x41e560&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0xa65ecf&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2d2b2e&0xffffffff;}['update'](_0x27dd54,_0x4a5f5b){if(_0x27dd54==null)return;_0x4a5f5b===void 0x0&&(_0x4a5f5b=_0x27dd54['length']);const _0x3fcf64=_0x4a5f5b-this['blockSize'];let _0x19b391=0x0;const _0x3f0493=this['buf_'];let _0x3c4847=this['inbuf_'];for(;_0x19b391<_0x4a5f5b;){if(_0x3c4847===0x0){for(;_0x19b391<=_0x3fcf64;)this['compress_'](_0x27dd54,_0x19b391),_0x19b391+=this['blockSize'];}if(typeof _0x27dd54=='string'){for(;_0x19b391<_0x4a5f5b;)if(_0x3f0493[_0x3c4847]=_0x27dd54['charCodeAt'](_0x19b391),++_0x3c4847,++_0x19b391,_0x3c4847===this['blockSize']){this['compress_'](_0x3f0493),_0x3c4847=0x0;break;}}else{for(;_0x19b391<_0x4a5f5b;)if(_0x3f0493[_0x3c4847]=_0x27dd54[_0x19b391],++_0x3c4847,++_0x19b391,_0x3c4847===this['blockSize']){this['compress_'](_0x3f0493),_0x3c4847=0x0;break;}}}this['inbuf_']=_0x3c4847,this['total_']+=_0x4a5f5b;}['digest'](){const _0x20e152=[];let _0x4309cb=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x40a32c=this['blockSize']-0x1;_0x40a32c>=0x38;_0x40a32c--)this['buf_'][_0x40a32c]=_0x4309cb&0xff,_0x4309cb/=0x100;this['compress_'](this['buf_']);let _0x5f3305=0x0;for(let _0x1a16b5=0x0;_0x1a16b5<0x5;_0x1a16b5++)for(let _0x48c636=0x18;_0x48c636>=0x0;_0x48c636-=0x8)_0x20e152[_0x5f3305]=this['chain_'][_0x1a16b5]>>_0x48c636&0xff,++_0x5f3305;return _0x20e152;}}function Tc(_0x188008,_0x2258f6){const _0x161f62=new Sc(_0x188008,_0x2258f6);return _0x161f62['subscribe']['bind'](_0x161f62);}class Sc{constructor(_0x3eefd7,_0x1dea74){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1dea74,this['task']['then'](()=>{_0x3eefd7(this);})['catch'](_0x686041=>{this['error'](_0x686041);});}['next'](_0x389942){this['forEachObserver'](_0x1ad3ac=>{_0x1ad3ac['next'](_0x389942);});}['error'](_0x3b54a6){this['forEachObserver'](_0x49e88f=>{_0x49e88f['error'](_0x3b54a6);}),this['close'](_0x3b54a6);}['complete'](){this['forEachObserver'](_0x3ced22=>{_0x3ced22['complete']();}),this['close']();}['subscribe'](_0x5aba76,_0x1ac4b1,_0x5116d6){let _0x3c789b;if(_0x5aba76===void 0x0&&_0x1ac4b1===void 0x0&&_0x5116d6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x5aba76,['next','error','complete'])?_0x3c789b=_0x5aba76:_0x3c789b={'next':_0x5aba76,'error':_0x1ac4b1,'complete':_0x5116d6},_0x3c789b['next']===void 0x0&&(_0x3c789b['next']=ti),_0x3c789b['error']===void 0x0&&(_0x3c789b['error']=ti),_0x3c789b['complete']===void 0x0&&(_0x3c789b['complete']=ti);const _0x4c8e7d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3c789b['error'](this['finalError']):_0x3c789b['complete']();}catch{}}),this['observers']['push'](_0x3c789b),_0x4c8e7d;}['unsubscribeOne'](_0x3de2d3){this['observers']===void 0x0||this['observers'][_0x3de2d3]===void 0x0||(delete this['observers'][_0x3de2d3],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1ad591){if(!this['finalized']){for(let _0x126409=0x0;_0x126409<this['observers']['length'];_0x126409++)this['sendOne'](_0x126409,_0x1ad591);}}['sendOne'](_0x3206ac,_0x5e17f5){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3206ac]!==void 0x0)try{_0x5e17f5(this['observers'][_0x3206ac]);}catch(_0x2c7e2b){typeof console<'u'&&console['error']&&console['error'](_0x2c7e2b);}});}['close'](_0xad9f43){this['finalized']||(this['finalized']=!0x0,_0xad9f43!==void 0x0&&(this['finalError']=_0xad9f43),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x32fbcb,_0x1dac01){if(typeof _0x32fbcb!='object'||_0x32fbcb===null)return!0x1;for(const _0x39b0ba of _0x1dac01)if(_0x39b0ba in _0x32fbcb&&typeof _0x32fbcb[_0x39b0ba]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1e6aac,_0xb6577c){return _0x1e6aac+'\x20failed:\x20'+_0xb6577c+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3cc119){const _0x47e223=[];let _0x10a078=0x0;for(let _0x41c909=0x0;_0x41c909<_0x3cc119['length'];_0x41c909++){let _0x44806e=_0x3cc119['charCodeAt'](_0x41c909);if(_0x44806e>=0xd800&&_0x44806e<=0xdbff){const _0x15441d=_0x44806e-0xd800;_0x41c909++,f(_0x41c909<_0x3cc119['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0xceaa20=_0x3cc119['charCodeAt'](_0x41c909)-0xdc00;_0x44806e=0x10000+(_0x15441d<<0xa)+_0xceaa20;}_0x44806e<0x80?_0x47e223[_0x10a078++]=_0x44806e:_0x44806e<0x800?(_0x47e223[_0x10a078++]=_0x44806e>>0x6|0xc0,_0x47e223[_0x10a078++]=_0x44806e&0x3f|0x80):_0x44806e<0x10000?(_0x47e223[_0x10a078++]=_0x44806e>>0xc|0xe0,_0x47e223[_0x10a078++]=_0x44806e>>0x6&0x3f|0x80,_0x47e223[_0x10a078++]=_0x44806e&0x3f|0x80):(_0x47e223[_0x10a078++]=_0x44806e>>0x12|0xf0,_0x47e223[_0x10a078++]=_0x44806e>>0xc&0x3f|0x80,_0x47e223[_0x10a078++]=_0x44806e>>0x6&0x3f|0x80,_0x47e223[_0x10a078++]=_0x44806e&0x3f|0x80);}return _0x47e223;},Ln=function(_0x237ae8){let _0x1caf34=0x0;for(let _0x32e863=0x0;_0x32e863<_0x237ae8['length'];_0x32e863++){const _0x44aa50=_0x237ae8['charCodeAt'](_0x32e863);_0x44aa50<0x80?_0x1caf34++:_0x44aa50<0x800?_0x1caf34+=0x2:_0x44aa50>=0xd800&&_0x44aa50<=0xdbff?(_0x1caf34+=0x4,_0x32e863++):_0x1caf34+=0x3;}return _0x1caf34;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x21b324){return _0x21b324&&_0x21b324['_delegate']?_0x21b324['_delegate']:_0x21b324;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x11b3a1){try{return(_0x11b3a1['startsWith']('http://')||_0x11b3a1['startsWith']('https://')?new URL(_0x11b3a1)['hostname']:_0x11b3a1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x56179d){return(await fetch(_0x56179d,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x104978,_0x125283,_0x7f4a35){this['name']=_0x104978,this['instanceFactory']=_0x125283,this['type']=_0x7f4a35,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2c13fb){return this['instantiationMode']=_0x2c13fb,this;}['setMultipleInstances'](_0x40056f){return this['multipleInstances']=_0x40056f,this;}['setServiceProps'](_0x5ee27f){return this['serviceProps']=_0x5ee27f,this;}['setInstanceCreatedCallback'](_0x59677c){return this['onInstanceCreated']=_0x59677c,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5509bd,_0xb15abd){this['name']=_0x5509bd,this['container']=_0xb15abd,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x21c490){const _0x543fdc=this['normalizeInstanceIdentifier'](_0x21c490);if(!this['instancesDeferred']['has'](_0x543fdc)){const _0x181a05=new H();if(this['instancesDeferred']['set'](_0x543fdc,_0x181a05),this['isInitialized'](_0x543fdc)||this['shouldAutoInitialize']())try{const _0x51f353=this['getOrInitializeService']({'instanceIdentifier':_0x543fdc});_0x51f353&&_0x181a05['resolve'](_0x51f353);}catch{}}return this['instancesDeferred']['get'](_0x543fdc)['promise'];}['getImmediate'](_0x3b7b45){const _0x528cb8=this['normalizeInstanceIdentifier'](_0x3b7b45==null?void 0x0:_0x3b7b45['identifier']),_0x395a63=(_0x3b7b45==null?void 0x0:_0x3b7b45['optional'])??!0x1;if(this['isInitialized'](_0x528cb8)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x528cb8});}catch(_0x35f663){if(_0x395a63)return null;throw _0x35f663;}else{if(_0x395a63)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4d1a71){if(_0x4d1a71['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4d1a71['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4d1a71,!!this['shouldAutoInitialize']()){if(Pc(_0x4d1a71))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3023d5,_0x2c111f]of this['instancesDeferred']['entries']()){const _0x17ccb1=this['normalizeInstanceIdentifier'](_0x3023d5);try{const _0x575ec9=this['getOrInitializeService']({'instanceIdentifier':_0x17ccb1});_0x2c111f['resolve'](_0x575ec9);}catch{}}}}['clearInstance'](_0x370217=Ne){this['instancesDeferred']['delete'](_0x370217),this['instancesOptions']['delete'](_0x370217),this['instances']['delete'](_0x370217);}async['delete'](){const _0x27eb5e=Array['from'](this['instances']['values']());await Promise['all']([..._0x27eb5e['filter'](_0x4b2c1a=>'INTERNAL'in _0x4b2c1a)['map'](_0x4b1a00=>_0x4b1a00['INTERNAL']['delete']()),..._0x27eb5e['filter'](_0x4a576c=>'_delete'in _0x4a576c)['map'](_0x1d4279=>_0x1d4279['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2513f8=Ne){return this['instances']['has'](_0x2513f8);}['getOptions'](_0x341849=Ne){return this['instancesOptions']['get'](_0x341849)||{};}['initialize'](_0x202f85={}){const {options:_0x47634c={}}=_0x202f85,_0x4e0b10=this['normalizeInstanceIdentifier'](_0x202f85['instanceIdentifier']);if(this['isInitialized'](_0x4e0b10))throw Error(this['name']+'('+_0x4e0b10+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x6b2377=this['getOrInitializeService']({'instanceIdentifier':_0x4e0b10,'options':_0x47634c});for(const [_0x29c83c,_0x56a1d9]of this['instancesDeferred']['entries']()){const _0x4fa18c=this['normalizeInstanceIdentifier'](_0x29c83c);_0x4e0b10===_0x4fa18c&&_0x56a1d9['resolve'](_0x6b2377);}return _0x6b2377;}['onInit'](_0x57525f,_0x174529){const _0x1adce6=this['normalizeInstanceIdentifier'](_0x174529),_0x427d75=this['onInitCallbacks']['get'](_0x1adce6)??new Set();_0x427d75['add'](_0x57525f),this['onInitCallbacks']['set'](_0x1adce6,_0x427d75);const _0x24db29=this['instances']['get'](_0x1adce6);return _0x24db29&&_0x57525f(_0x24db29,_0x1adce6),()=>{_0x427d75['delete'](_0x57525f);};}['invokeOnInitCallbacks'](_0x3c6e6d,_0x713a0a){const _0x422498=this['onInitCallbacks']['get'](_0x713a0a);if(_0x422498){for(const _0x19ce9f of _0x422498)try{_0x19ce9f(_0x3c6e6d,_0x713a0a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x38f6c9,options:_0x5c9657={}}){let _0x1f2980=this['instances']['get'](_0x38f6c9);if(!_0x1f2980&&this['component']&&(_0x1f2980=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x38f6c9),'options':_0x5c9657}),this['instances']['set'](_0x38f6c9,_0x1f2980),this['instancesOptions']['set'](_0x38f6c9,_0x5c9657),this['invokeOnInitCallbacks'](_0x1f2980,_0x38f6c9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x38f6c9,_0x1f2980);}catch{}return _0x1f2980||null;}['normalizeInstanceIdentifier'](_0x51b8c4=Ne){return this['component']?this['component']['multipleInstances']?_0x51b8c4:Ne:_0x51b8c4;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4efb3c){return _0x4efb3c===Ne?void 0x0:_0x4efb3c;}function Pc(_0x5993c){return _0x5993c['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4ff2f4){this['name']=_0x4ff2f4,this['providers']=new Map();}['addComponent'](_0x51060a){const _0x4c9316=this['getProvider'](_0x51060a['name']);if(_0x4c9316['isComponentSet']())throw new Error('Component\x20'+_0x51060a['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4c9316['setComponent'](_0x51060a);}['addOrOverwriteComponent'](_0xa2e168){this['getProvider'](_0xa2e168['name'])['isComponentSet']()&&this['providers']['delete'](_0xa2e168['name']),this['addComponent'](_0xa2e168);}['getProvider'](_0x2ec638){if(this['providers']['has'](_0x2ec638))return this['providers']['get'](_0x2ec638);const _0x4b25ad=new Ac(_0x2ec638,this);return this['providers']['set'](_0x2ec638,_0x4b25ad),_0x4b25ad;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x33d04e){_0x33d04e[_0x33d04e['DEBUG']=0x0]='DEBUG',_0x33d04e[_0x33d04e['VERBOSE']=0x1]='VERBOSE',_0x33d04e[_0x33d04e['INFO']=0x2]='INFO',_0x33d04e[_0x33d04e['WARN']=0x3]='WARN',_0x33d04e[_0x33d04e['ERROR']=0x4]='ERROR',_0x33d04e[_0x33d04e['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x427a06,_0x20da57,..._0x15dbec)=>{if(_0x20da57<_0x427a06['logLevel'])return;const _0x4d85d7=new Date()['toISOString'](),_0x29a531=Mc[_0x20da57];if(_0x29a531)console[_0x29a531]('['+_0x4d85d7+']\x20\x20'+_0x427a06['name']+':',..._0x15dbec);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x20da57+')');};class Bi{constructor(_0x2af190){this['name']=_0x2af190,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4a44f3){if(!(_0x4a44f3 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4a44f3+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4a44f3;}['setLogLevel'](_0x3ae42a){this['_logLevel']=typeof _0x3ae42a=='string'?Oc[_0x3ae42a]:_0x3ae42a;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3776e3){if(typeof _0x3776e3!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3776e3;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3b17b5){this['_userLogHandler']=_0x3b17b5;}['debug'](..._0x53dd2e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x53dd2e),this['_logHandler'](this,T['DEBUG'],..._0x53dd2e);}['log'](..._0x5d366f){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5d366f),this['_logHandler'](this,T['VERBOSE'],..._0x5d366f);}['info'](..._0x16cb36){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x16cb36),this['_logHandler'](this,T['INFO'],..._0x16cb36);}['warn'](..._0x1dbd91){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1dbd91),this['_logHandler'](this,T['WARN'],..._0x1dbd91);}['error'](..._0x1f66d3){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1f66d3),this['_logHandler'](this,T['ERROR'],..._0x1f66d3);}}const xc=(_0x3601df,_0x33a6b8)=>_0x33a6b8['some'](_0x23ea81=>_0x3601df instanceof _0x23ea81);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x352c3e){const _0xfea8c5=new Promise((_0x2b35f4,_0x106141)=>{const _0x53404c=()=>{_0x352c3e['removeEventListener']('success',_0x240e16),_0x352c3e['removeEventListener']('error',_0x295672);},_0x240e16=()=>{_0x2b35f4(ge(_0x352c3e['result'])),_0x53404c();},_0x295672=()=>{_0x106141(_0x352c3e['error']),_0x53404c();};_0x352c3e['addEventListener']('success',_0x240e16),_0x352c3e['addEventListener']('error',_0x295672);});return _0xfea8c5['then'](_0xd0ac34=>{_0xd0ac34 instanceof IDBCursor&&Jr['set'](_0xd0ac34,_0x352c3e);})['catch'](()=>{}),Vi['set'](_0xfea8c5,_0x352c3e),_0xfea8c5;}function Bc(_0x180321){if(_i['has'](_0x180321))return;const _0x10083c=new Promise((_0x3805f5,_0xd8975d)=>{const _0x52b47d=()=>{_0x180321['removeEventListener']('complete',_0xaef80e),_0x180321['removeEventListener']('error',_0x43c996),_0x180321['removeEventListener']('abort',_0x43c996);},_0xaef80e=()=>{_0x3805f5(),_0x52b47d();},_0x43c996=()=>{_0xd8975d(_0x180321['error']||new DOMException('AbortError','AbortError')),_0x52b47d();};_0x180321['addEventListener']('complete',_0xaef80e),_0x180321['addEventListener']('error',_0x43c996),_0x180321['addEventListener']('abort',_0x43c996);});_i['set'](_0x180321,_0x10083c);}let gi={'get'(_0x9e6733,_0x38d13f,_0x2c99ef){if(_0x9e6733 instanceof IDBTransaction){if(_0x38d13f==='done')return _i['get'](_0x9e6733);if(_0x38d13f==='objectStoreNames')return _0x9e6733['objectStoreNames']||Xr['get'](_0x9e6733);if(_0x38d13f==='store')return _0x2c99ef['objectStoreNames'][0x1]?void 0x0:_0x2c99ef['objectStore'](_0x2c99ef['objectStoreNames'][0x0]);}return ge(_0x9e6733[_0x38d13f]);},'set'(_0x575336,_0x148c64,_0x577b96){return _0x575336[_0x148c64]=_0x577b96,!0x0;},'has'(_0x23a9af,_0x18871a){return _0x23a9af instanceof IDBTransaction&&(_0x18871a==='done'||_0x18871a==='store')?!0x0:_0x18871a in _0x23a9af;}};function Vc(_0x41587b){gi=_0x41587b(gi);}function Hc(_0x36e60e){return _0x36e60e===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2a6a17,..._0x2082b7){const _0x1fcddd=_0x36e60e['call'](ii(this),_0x2a6a17,..._0x2082b7);return Xr['set'](_0x1fcddd,_0x2a6a17['sort']?_0x2a6a17['sort']():[_0x2a6a17]),ge(_0x1fcddd);}:Uc()['includes'](_0x36e60e)?function(..._0xfbb37c){return _0x36e60e['apply'](ii(this),_0xfbb37c),ge(Jr['get'](this));}:function(..._0x1b6ff2){return ge(_0x36e60e['apply'](ii(this),_0x1b6ff2));};}function $c(_0x3ca61b){return typeof _0x3ca61b=='function'?Hc(_0x3ca61b):(_0x3ca61b instanceof IDBTransaction&&Bc(_0x3ca61b),xc(_0x3ca61b,Fc())?new Proxy(_0x3ca61b,gi):_0x3ca61b);}function ge(_0x3a66d2){if(_0x3a66d2 instanceof IDBRequest)return Wc(_0x3a66d2);if(ni['has'](_0x3a66d2))return ni['get'](_0x3a66d2);const _0xde09a9=$c(_0x3a66d2);return _0xde09a9!==_0x3a66d2&&(ni['set'](_0x3a66d2,_0xde09a9),Vi['set'](_0xde09a9,_0x3a66d2)),_0xde09a9;}const ii=_0x243f99=>Vi['get'](_0x243f99);function Gc(_0x266ed5,_0x479592,{blocked:_0x103de8,upgrade:_0x29973d,blocking:_0x3d404d,terminated:_0x28604f}={}){const _0x5d84b6=indexedDB['open'](_0x266ed5,_0x479592),_0x141138=ge(_0x5d84b6);return _0x29973d&&_0x5d84b6['addEventListener']('upgradeneeded',_0x250674=>{_0x29973d(ge(_0x5d84b6['result']),_0x250674['oldVersion'],_0x250674['newVersion'],ge(_0x5d84b6['transaction']),_0x250674);}),_0x103de8&&_0x5d84b6['addEventListener']('blocked',_0x50bd26=>_0x103de8(_0x50bd26['oldVersion'],_0x50bd26['newVersion'],_0x50bd26)),_0x141138['then'](_0x5b6988=>{_0x28604f&&_0x5b6988['addEventListener']('close',()=>_0x28604f()),_0x3d404d&&_0x5b6988['addEventListener']('versionchange',_0x2b63d1=>_0x3d404d(_0x2b63d1['oldVersion'],_0x2b63d1['newVersion'],_0x2b63d1));})['catch'](()=>{}),_0x141138;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x10e55e,_0x214754){if(!(_0x10e55e instanceof IDBDatabase&&!(_0x214754 in _0x10e55e)&&typeof _0x214754=='string'))return;if(si['get'](_0x214754))return si['get'](_0x214754);const _0xc9bfcf=_0x214754['replace'](/FromIndex$/,''),_0x21b5e2=_0x214754!==_0xc9bfcf,_0x485d1f=zc['includes'](_0xc9bfcf);if(!(_0xc9bfcf in(_0x21b5e2?IDBIndex:IDBObjectStore)['prototype'])||!(_0x485d1f||qc['includes'](_0xc9bfcf)))return;const _0x35122b=async function(_0x5b8368,..._0x337294){const _0x4a2d2e=this['transaction'](_0x5b8368,_0x485d1f?'readwrite':'readonly');let _0x5624f9=_0x4a2d2e['store'];return _0x21b5e2&&(_0x5624f9=_0x5624f9['index'](_0x337294['shift']())),(await Promise['all']([_0x5624f9[_0xc9bfcf](..._0x337294),_0x485d1f&&_0x4a2d2e['done']]))[0x0];};return si['set'](_0x214754,_0x35122b),_0x35122b;}Vc(_0x323c7=>({..._0x323c7,'get':(_0x1347cc,_0x220d7d,_0x3197d9)=>Ms(_0x1347cc,_0x220d7d)||_0x323c7['get'](_0x1347cc,_0x220d7d,_0x3197d9),'has':(_0x28c343,_0x5214d3)=>!!Ms(_0x28c343,_0x5214d3)||_0x323c7['has'](_0x28c343,_0x5214d3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x106e45){this['container']=_0x106e45;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xfc0807=>{if(Kc(_0xfc0807)){const _0x330f46=_0xfc0807['getImmediate']();return _0x330f46['library']+'/'+_0x330f46['version'];}else return null;})['filter'](_0x4fa009=>_0x4fa009)['join']('\x20');}}function Kc(_0x4ea703){const _0x2433c=_0x4ea703['getComponent']();return(_0x2433c==null?void 0x0:_0x2433c['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xb2ab7c,_0x15e645){try{_0xb2ab7c['container']['addComponent'](_0x15e645);}catch(_0x5705bc){oe['debug']('Component\x20'+_0x15e645['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xb2ab7c['name'],_0x5705bc);}}function st(_0x46c489){const _0x272c6b=_0x46c489['name'];if(Ei['has'](_0x272c6b))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x272c6b+'.'),!0x1;Ei['set'](_0x272c6b,_0x46c489);for(const _0x149b5a of Ue['values']())xs(_0x149b5a,_0x46c489);for(const _0x139d4f of vi['values']())xs(_0x139d4f,_0x46c489);return!0x0;}function Hi(_0x58efc2,_0x4548a8){const _0x2c5f3c=_0x58efc2['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2c5f3c&&_0x2c5f3c['triggerHeartbeat'](),_0x58efc2['container']['getProvider'](_0x4548a8);}function $(_0x5e76e6){return _0x5e76e6==null?!0x1:_0x5e76e6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1e3f2e,_0x5ac1be,_0x221676){this['_isDeleted']=!0x1,this['_options']={..._0x1e3f2e},this['_config']={..._0x5ac1be},this['_name']=_0x5ac1be['name'],this['_automaticDataCollectionEnabled']=_0x5ac1be['automaticDataCollectionEnabled'],this['_container']=_0x221676,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4593e8){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4593e8;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x261a73){this['_isDeleted']=_0x261a73;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x48f71a,_0x100a11={}){let _0x2d1591=_0x48f71a;typeof _0x100a11!='object'&&(_0x100a11={'name':_0x100a11});const _0x2ad8b0={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x100a11},_0x10fd0f=_0x2ad8b0['name'];if(typeof _0x10fd0f!='string'||!_0x10fd0f)throw me['create']('bad-app-name',{'appName':String(_0x10fd0f)});if(_0x2d1591||(_0x2d1591=zr()),!_0x2d1591)throw me['create']('no-options');const _0x37777a=Ue['get'](_0x10fd0f);if(_0x37777a){if(xe(_0x2d1591,_0x37777a['options'])&&xe(_0x2ad8b0,_0x37777a['config']))return _0x37777a;throw me['create']('duplicate-app',{'appName':_0x10fd0f});}const _0x55d16e=new Nc(_0x10fd0f);for(const _0x422132 of Ei['values']())_0x55d16e['addComponent'](_0x422132);const _0xaa59c7=new Tl(_0x2d1591,_0x2ad8b0,_0x55d16e);return Ue['set'](_0x10fd0f,_0xaa59c7),_0xaa59c7;}function Zr(_0x1d0e17=yi){const _0x265ee3=Ue['get'](_0x1d0e17);if(!_0x265ee3&&_0x1d0e17===yi&&zr())return Sl();if(!_0x265ee3)throw me['create']('no-app',{'appName':_0x1d0e17});return _0x265ee3;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x529e11){let _0x26904b=!0x1;const _0x4daad1=_0x529e11['name'];Ue['has'](_0x4daad1)?(_0x26904b=!0x0,Ue['delete'](_0x4daad1)):vi['has'](_0x4daad1)&&_0x529e11['decRefCount']()<=0x0&&(vi['delete'](_0x4daad1),_0x26904b=!0x0),_0x26904b&&(await Promise['all'](_0x529e11['container']['getProviders']()['map'](_0x4c8673=>_0x4c8673['delete']())),_0x529e11['isDeleted']=!0x0);}function ye(_0x213b79,_0x4cc27d,_0x5b6d24){let _0x2cc110=wl[_0x213b79]??_0x213b79;_0x5b6d24&&(_0x2cc110+='-'+_0x5b6d24);const _0x13e337=_0x2cc110['match'](/\s|\//),_0x20ad75=_0x4cc27d['match'](/\s|\//);if(_0x13e337||_0x20ad75){const _0x25490c=['Unable\x20to\x20register\x20library\x20\x22'+_0x2cc110+'\x22\x20with\x20version\x20\x22'+_0x4cc27d+'\x22:'];_0x13e337&&_0x25490c['push']('library\x20name\x20\x22'+_0x2cc110+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x13e337&&_0x20ad75&&_0x25490c['push']('and'),_0x20ad75&&_0x25490c['push']('version\x20name\x20\x22'+_0x4cc27d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x25490c['join']('\x20'));return;}st(new Fe(_0x2cc110+'-version',()=>({'library':_0x2cc110,'version':_0x4cc27d}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x5ce742,_0x1d1c9e)=>{switch(_0x1d1c9e){case 0x0:try{_0x5ce742['createObjectStore'](Ot);}catch(_0x116151){console['warn'](_0x116151);}}}})['catch'](_0x48cd3c=>{throw me['create']('idb-open',{'originalErrorMessage':_0x48cd3c['message']});})),ri;}async function Al(_0x3b9505){try{const _0x1be01c=(await eo())['transaction'](Ot),_0x4b16a6=await _0x1be01c['objectStore'](Ot)['get'](to(_0x3b9505));return await _0x1be01c['done'],_0x4b16a6;}catch(_0x50ce83){if(_0x50ce83 instanceof Re)oe['warn'](_0x50ce83['message']);else{const _0x37bc1f=me['create']('idb-get',{'originalErrorMessage':_0x50ce83==null?void 0x0:_0x50ce83['message']});oe['warn'](_0x37bc1f['message']);}}}async function Fs(_0x2a2b8b,_0x3fe5f9){try{const _0x1b849f=(await eo())['transaction'](Ot,'readwrite');await _0x1b849f['objectStore'](Ot)['put'](_0x3fe5f9,to(_0x2a2b8b)),await _0x1b849f['done'];}catch(_0x21986e){if(_0x21986e instanceof Re)oe['warn'](_0x21986e['message']);else{const _0xd9c040=me['create']('idb-set',{'originalErrorMessage':_0x21986e==null?void 0x0:_0x21986e['message']});oe['warn'](_0xd9c040['message']);}}}function to(_0x5385b5){return _0x5385b5['name']+'!'+_0x5385b5['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x10c3ed){this['container']=_0x10c3ed,this['_heartbeatsCache']=null;const _0x1975ef=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1975ef),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x474a6a=>(this['_heartbeatsCache']=_0x474a6a,_0x474a6a));}async['triggerHeartbeat'](){var _0x261672,_0x4b59f7;try{const _0x112086=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3666d2=Us();if(((_0x261672=this['_heartbeatsCache'])==null?void 0x0:_0x261672['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4b59f7=this['_heartbeatsCache'])==null?void 0x0:_0x4b59f7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3666d2||this['_heartbeatsCache']['heartbeats']['some'](_0x448b5e=>_0x448b5e['date']===_0x3666d2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3666d2,'agent':_0x112086}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0xf77601=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0xf77601,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2298a8){oe['warn'](_0x2298a8);}}async['getHeartbeatsHeader'](){var _0x545ec5;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x545ec5=this['_heartbeatsCache'])==null?void 0x0:_0x545ec5['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5c149f=Us(),{heartbeatsToSend:_0x48ba1e,unsentEntries:_0x437342}=Ol(this['_heartbeatsCache']['heartbeats']),_0x561ccb=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x48ba1e}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5c149f,_0x437342['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x437342,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x561ccb;}catch(_0x5d4503){return oe['warn'](_0x5d4503),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x30f24f,_0x3edc6a=kl){const _0x349018=[];let _0x4ac693=_0x30f24f['slice']();for(const _0x5b6c14 of _0x30f24f){const _0x483b63=_0x349018['find'](_0x312e76=>_0x312e76['agent']===_0x5b6c14['agent']);if(_0x483b63){if(_0x483b63['dates']['push'](_0x5b6c14['date']),Ws(_0x349018)>_0x3edc6a){_0x483b63['dates']['pop']();break;}}else{if(_0x349018['push']({'agent':_0x5b6c14['agent'],'dates':[_0x5b6c14['date']]}),Ws(_0x349018)>_0x3edc6a){_0x349018['pop']();break;}}_0x4ac693=_0x4ac693['slice'](0x1);}return{'heartbeatsToSend':_0x349018,'unsentEntries':_0x4ac693};}class Dl{constructor(_0x25c05a){this['app']=_0x25c05a,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4bd942=await Al(this['app']);return _0x4bd942!=null&&_0x4bd942['heartbeats']?_0x4bd942:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3a80e4){if(await this['_canUseIndexedDBPromise']){const _0x8b2d6=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3a80e4['lastSentHeartbeatDate']??_0x8b2d6['lastSentHeartbeatDate'],'heartbeats':_0x3a80e4['heartbeats']});}else return;}async['add'](_0x5ddb5a){if(await this['_canUseIndexedDBPromise']){const _0x1c8d81=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5ddb5a['lastSentHeartbeatDate']??_0x1c8d81['lastSentHeartbeatDate'],'heartbeats':[..._0x1c8d81['heartbeats'],..._0x5ddb5a['heartbeats']]});}else return;}}function Ws(_0x2977a1){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2977a1}))['length'];}function Ml(_0x107ef5){if(_0x107ef5['length']===0x0)return-0x1;let _0x4ece47=0x0,_0x5ca1d7=_0x107ef5[0x0]['date'];for(let _0x5c1d14=0x1;_0x5c1d14<_0x107ef5['length'];_0x5c1d14++)_0x107ef5[_0x5c1d14]['date']<_0x5ca1d7&&(_0x5ca1d7=_0x107ef5[_0x5c1d14]['date'],_0x4ece47=_0x5c1d14);return _0x4ece47;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0xa05e0a){st(new Fe('platform-logger',_0x2da0c7=>new jc(_0x2da0c7),'PRIVATE')),st(new Fe('heartbeat',_0x5a719d=>new Nl(_0x5a719d),'PRIVATE')),ye(mi,Ls,_0xa05e0a),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x26d845){no=_0x26d845;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x36865c){this['domStorage_']=_0x36865c,this['prefix_']='firebase:';}['set'](_0x216a3a,_0x5b1f43){_0x5b1f43==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x216a3a)):this['domStorage_']['setItem'](this['prefixedName_'](_0x216a3a),O(_0x5b1f43));}['get'](_0x4b6cef){const _0xf74a2a=this['domStorage_']['getItem'](this['prefixedName_'](_0x4b6cef));return _0xf74a2a==null?null:Nt(_0xf74a2a);}['remove'](_0x473e48){this['domStorage_']['removeItem'](this['prefixedName_'](_0x473e48));}['prefixedName_'](_0x21ef66){return this['prefix_']+_0x21ef66;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1138d7,_0x357f0f){_0x357f0f==null?delete this['cache_'][_0x1138d7]:this['cache_'][_0x1138d7]=_0x357f0f;}['get'](_0x5c3869){return Q(this['cache_'],_0x5c3869)?this['cache_'][_0x5c3869]:null;}['remove'](_0x53c676){delete this['cache_'][_0x53c676];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x166eb7){try{if(typeof window<'u'&&typeof window[_0x166eb7]<'u'){const _0x3f4866=window[_0x166eb7];return _0x3f4866['setItem']('firebase:sentinel','cache'),_0x3f4866['removeItem']('firebase:sentinel'),new Wl(_0x3f4866);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x82c585=0x1;return function(){return _0x82c585++;};}()),ro=function(_0x577f40){const _0x1d897e=Rc(_0x577f40),_0x48a7c4=new Cc();_0x48a7c4['update'](_0x1d897e);const _0x360585=_0x48a7c4['digest']();return Fi['encodeByteArray'](_0x360585);},zt=function(..._0xb73d87){let _0x31b3f9='';for(let _0x2a7820=0x0;_0x2a7820<_0xb73d87['length'];_0x2a7820++){const _0x83ae8b=_0xb73d87[_0x2a7820];Array['isArray'](_0x83ae8b)||_0x83ae8b&&typeof _0x83ae8b=='object'&&typeof _0x83ae8b['length']=='number'?_0x31b3f9+=zt['apply'](null,_0x83ae8b):typeof _0x83ae8b=='object'?_0x31b3f9+=O(_0x83ae8b):_0x31b3f9+=_0x83ae8b,_0x31b3f9+='\x20';}return _0x31b3f9;};let St=null,$s=!0x0;const Hl=function(_0x266936,_0x3c1809){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x3b9885){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x4d2729=zt['apply'](null,_0x3b9885);St(_0x4d2729);}},jt=function(_0x47576b){return function(..._0x29355b){L(_0x47576b,..._0x29355b);};},Ii=function(..._0x2685da){const _0x3a2ade='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2685da);Ze['error'](_0x3a2ade);},ae=function(..._0x45f24b){const _0x12bd91='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x45f24b);throw Ze['error'](_0x12bd91),new Error(_0x12bd91);},U=function(..._0x5f34a8){const _0x265675='FIREBASE\x20WARNING:\x20'+zt(..._0x5f34a8);Ze['warn'](_0x265675);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x186a6a){return typeof _0x186a6a=='number'&&(_0x186a6a!==_0x186a6a||_0x186a6a===Number['POSITIVE_INFINITY']||_0x186a6a===Number['NEGATIVE_INFINITY']);},Gl=function(_0x132293){if(document['readyState']==='complete')_0x132293();else{let _0x3789e1=!0x1;const _0x172145=function(){if(!document['body']){setTimeout(_0x172145,Math['floor'](0xa));return;}_0x3789e1||(_0x3789e1=!0x0,_0x132293());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x172145,!0x1),window['addEventListener']('load',_0x172145,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x172145();}),window['attachEvent']('onload',_0x172145));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x440672,_0x21c805){if(_0x440672===_0x21c805)return 0x0;if(_0x440672===We||_0x21c805===we)return-0x1;if(_0x21c805===We||_0x440672===we)return 0x1;{const _0x23a2df=Gs(_0x440672),_0x5ade7b=Gs(_0x21c805);return _0x23a2df!==null?_0x5ade7b!==null?_0x23a2df-_0x5ade7b===0x0?_0x440672['length']-_0x21c805['length']:_0x23a2df-_0x5ade7b:-0x1:_0x5ade7b!==null?0x1:_0x440672<_0x21c805?-0x1:0x1;}},ql=function(_0x584a6e,_0x1d876e){return _0x584a6e===_0x1d876e?0x0:_0x584a6e<_0x1d876e?-0x1:0x1;},vt=function(_0x2b0008,_0x48b4a5){if(_0x48b4a5&&_0x2b0008 in _0x48b4a5)return _0x48b4a5[_0x2b0008];throw new Error('Missing\x20required\x20key\x20('+_0x2b0008+')\x20in\x20object:\x20'+O(_0x48b4a5));},$i=function(_0x280e32){if(typeof _0x280e32!='object'||_0x280e32===null)return O(_0x280e32);const _0x2be803=[];for(const _0x52da3e in _0x280e32)_0x2be803['push'](_0x52da3e);_0x2be803['sort']();let _0x452a7d='{';for(let _0x5d40d8=0x0;_0x5d40d8<_0x2be803['length'];_0x5d40d8++)_0x5d40d8!==0x0&&(_0x452a7d+=','),_0x452a7d+=O(_0x2be803[_0x5d40d8]),_0x452a7d+=':',_0x452a7d+=$i(_0x280e32[_0x2be803[_0x5d40d8]]);return _0x452a7d+='}',_0x452a7d;},oo=function(_0x2a3e28,_0x1d8627){const _0x22524c=_0x2a3e28['length'];if(_0x22524c<=_0x1d8627)return[_0x2a3e28];const _0x3c148a=[];for(let _0x221300=0x0;_0x221300<_0x22524c;_0x221300+=_0x1d8627)_0x221300+_0x1d8627>_0x22524c?_0x3c148a['push'](_0x2a3e28['substring'](_0x221300,_0x22524c)):_0x3c148a['push'](_0x2a3e28['substring'](_0x221300,_0x221300+_0x1d8627));return _0x3c148a;};function x(_0x24e471,_0x565527){for(const _0x1ea63f in _0x24e471)_0x24e471['hasOwnProperty'](_0x1ea63f)&&_0x565527(_0x1ea63f,_0x24e471[_0x1ea63f]);}const ao=function(_0x34ec69){f(!xn(_0x34ec69),'Invalid\x20JSON\x20number');const _0x7346d1=0xb,_0x40de7c=0x34,_0x43407d=(0x1<<_0x7346d1-0x1)-0x1;let _0x4cf2fe,_0x4290c4,_0x45b5b9,_0xf2706e,_0x114b58;_0x34ec69===0x0?(_0x4290c4=0x0,_0x45b5b9=0x0,_0x4cf2fe=0x1/_0x34ec69===-0x1/0x0?0x1:0x0):(_0x4cf2fe=_0x34ec69<0x0,_0x34ec69=Math['abs'](_0x34ec69),_0x34ec69>=Math['pow'](0x2,0x1-_0x43407d)?(_0xf2706e=Math['min'](Math['floor'](Math['log'](_0x34ec69)/Math['LN2']),_0x43407d),_0x4290c4=_0xf2706e+_0x43407d,_0x45b5b9=Math['round'](_0x34ec69*Math['pow'](0x2,_0x40de7c-_0xf2706e)-Math['pow'](0x2,_0x40de7c))):(_0x4290c4=0x0,_0x45b5b9=Math['round'](_0x34ec69/Math['pow'](0x2,0x1-_0x43407d-_0x40de7c))));const _0x4bb98b=[];for(_0x114b58=_0x40de7c;_0x114b58;_0x114b58-=0x1)_0x4bb98b['push'](_0x45b5b9%0x2?0x1:0x0),_0x45b5b9=Math['floor'](_0x45b5b9/0x2);for(_0x114b58=_0x7346d1;_0x114b58;_0x114b58-=0x1)_0x4bb98b['push'](_0x4290c4%0x2?0x1:0x0),_0x4290c4=Math['floor'](_0x4290c4/0x2);_0x4bb98b['push'](_0x4cf2fe?0x1:0x0),_0x4bb98b['reverse']();const _0x210ce9=_0x4bb98b['join']('');let _0x2316d0='';for(_0x114b58=0x0;_0x114b58<0x40;_0x114b58+=0x8){let _0x23d635=parseInt(_0x210ce9['substr'](_0x114b58,0x8),0x2)['toString'](0x10);_0x23d635['length']===0x1&&(_0x23d635='0'+_0x23d635),_0x2316d0=_0x2316d0+_0x23d635;}return _0x2316d0['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x294a88,_0x2ae480){let _0x2d401b='Unknown\x20Error';_0x294a88==='too_big'?_0x2d401b='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x294a88==='permission_denied'?_0x2d401b='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x294a88==='unavailable'&&(_0x2d401b='The\x20service\x20is\x20unavailable');const _0x2b5caf=new Error(_0x294a88+'\x20at\x20'+_0x2ae480['_path']['toString']()+':\x20'+_0x2d401b);return _0x2b5caf['code']=_0x294a88['toUpperCase'](),_0x2b5caf;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x5afd1f){if(Yl['test'](_0x5afd1f)){const _0x5c9966=Number(_0x5afd1f);if(_0x5c9966>=Ql&&_0x5c9966<=Jl)return _0x5c9966;}return null;},ft=function(_0x5c70f1){try{_0x5c70f1();}catch(_0xa14c95){setTimeout(()=>{const _0x23c452=_0xa14c95['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x23c452),_0xa14c95;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x3e16de,_0x4f4450){const _0x4896ce=setTimeout(_0x3e16de,_0x4f4450);return typeof _0x4896ce=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4896ce):typeof _0x4896ce=='object'&&_0x4896ce['unref']&&_0x4896ce['unref'](),_0x4896ce;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x276b5c,_0x5dd43c){this['appCheckProvider']=_0x5dd43c,this['appName']=_0x276b5c['name'],$(_0x276b5c)&&_0x276b5c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x276b5c['settings']['appCheckToken']),this['appCheck']=_0x5dd43c==null?void 0x0:_0x5dd43c['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5dd43c==null||_0x5dd43c['get']()['then'](_0x3071a2=>this['appCheck']=_0x3071a2);}['getToken'](_0xcf7e99){if(this['serverAppAppCheckToken']){if(_0xcf7e99)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xcf7e99):new Promise((_0x5bd3ca,_0x2234fa)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xcf7e99)['then'](_0x5bd3ca,_0x2234fa):_0x5bd3ca(null);},0x0);});}['addTokenChangeListener'](_0x58aceb){var _0x5e560c;(_0x5e560c=this['appCheckProvider'])==null||_0x5e560c['get']()['then'](_0x4ff00e=>_0x4ff00e['addTokenListener'](_0x58aceb));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1b7508,_0x3fb30e,_0x3518f8){this['appName_']=_0x1b7508,this['firebaseOptions_']=_0x3fb30e,this['authProvider_']=_0x3518f8,this['auth_']=null,this['auth_']=_0x3518f8['getImmediate']({'optional':!0x0}),this['auth_']||_0x3518f8['onInit'](_0x17f9fc=>this['auth_']=_0x17f9fc);}['getToken'](_0x34b918){return this['auth_']?this['auth_']['getToken'](_0x34b918)['catch'](_0x39179c=>_0x39179c&&_0x39179c['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x39179c)):new Promise((_0x408218,_0x326cd0)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x34b918)['then'](_0x408218,_0x326cd0):_0x408218(null);},0x0);});}['addTokenChangeListener'](_0x196b1a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x196b1a):this['authProvider_']['get']()['then'](_0x358bbf=>_0x358bbf['addAuthTokenListener'](_0x196b1a));}['removeTokenChangeListener'](_0x36e852){this['authProvider_']['get']()['then'](_0x2bfc57=>_0x2bfc57['removeAuthTokenListener'](_0x36e852));}['notifyForInvalidToken'](){let _0x1aa213='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1aa213+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1aa213+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1aa213+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1aa213);}}class an{constructor(_0x141821){this['accessToken']=_0x141821;}['getToken'](_0x23620c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3d3250){_0x3d3250(this['accessToken']);}['removeTokenChangeListener'](_0x3effa9){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4304a9,_0x2085f5,_0x5d56c9,_0x12a0cd,_0x27bc42=!0x1,_0x573f79='',_0x5cbb0a=!0x1,_0x4a6a7e=!0x1,_0x403ae2=null){this['secure']=_0x2085f5,this['namespace']=_0x5d56c9,this['webSocketOnly']=_0x12a0cd,this['nodeAdmin']=_0x27bc42,this['persistenceKey']=_0x573f79,this['includeNamespaceInQueryParams']=_0x5cbb0a,this['isUsingEmulator']=_0x4a6a7e,this['emulatorOptions']=_0x403ae2,this['_host']=_0x4304a9['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4304a9)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x22646e){_0x22646e!==this['internalHost']&&(this['internalHost']=_0x22646e,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3859d8=this['toURLString']();return this['persistenceKey']&&(_0x3859d8+='<'+this['persistenceKey']+'>'),_0x3859d8;}['toURLString'](){const _0x2c740e=this['secure']?'https://':'http://',_0x222a3b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2c740e+this['host']+'/'+_0x222a3b;}}function th(_0x548194){return _0x548194['host']!==_0x548194['internalHost']||_0x548194['isCustomHost']()||_0x548194['includeNamespaceInQueryParams'];}function vo(_0x529eaa,_0x228bb9,_0x6bc9cf){f(typeof _0x228bb9=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x6bc9cf=='object','typeof\x20params\x20must\x20==\x20object');let _0x4e73ec;if(_0x228bb9===go)_0x4e73ec=(_0x529eaa['secure']?'wss://':'ws://')+_0x529eaa['internalHost']+'/.ws?';else{if(_0x228bb9===mo)_0x4e73ec=(_0x529eaa['secure']?'https://':'http://')+_0x529eaa['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x228bb9);}th(_0x529eaa)&&(_0x6bc9cf['ns']=_0x529eaa['namespace']);const _0xed7fe1=[];return x(_0x6bc9cf,(_0x401c2d,_0x3297c6)=>{_0xed7fe1['push'](_0x401c2d+'='+_0x3297c6);}),_0x4e73ec+_0xed7fe1['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3ad4d4,_0x40473c=0x1){Q(this['counters_'],_0x3ad4d4)||(this['counters_'][_0x3ad4d4]=0x0),this['counters_'][_0x3ad4d4]+=_0x40473c;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x469d12){const _0x1ed278=_0x469d12['toString']();return oi[_0x1ed278]||(oi[_0x1ed278]=new nh()),oi[_0x1ed278];}function ih(_0x4edcf5,_0x435cf5){const _0x3098c7=_0x4edcf5['toString']();return ai[_0x3098c7]||(ai[_0x3098c7]=_0x435cf5()),ai[_0x3098c7];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x49ee33){this['onMessage_']=_0x49ee33,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xde1317,_0x4ac5ea){this['closeAfterResponse']=_0xde1317,this['onClose']=_0x4ac5ea,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x190c19,_0x27fc81){for(this['pendingResponses'][_0x190c19]=_0x27fc81;this['pendingResponses'][this['currentResponseNum']];){const _0x22aedc=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2d8ab1=0x0;_0x2d8ab1<_0x22aedc['length'];++_0x2d8ab1)_0x22aedc[_0x2d8ab1]&&ft(()=>{this['onMessage_'](_0x22aedc[_0x2d8ab1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2e8f69,_0x485aa8,_0x55273f,_0x986e72,_0x3688ef,_0x50d4f7,_0x5ec332){this['connId']=_0x2e8f69,this['repoInfo']=_0x485aa8,this['applicationId']=_0x55273f,this['appCheckToken']=_0x986e72,this['authToken']=_0x3688ef,this['transportSessionId']=_0x50d4f7,this['lastSessionId']=_0x5ec332,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2e8f69),this['stats_']=qi(_0x485aa8),this['urlFn']=_0x4b9bca=>(this['appCheckToken']&&(_0x4b9bca[wi]=this['appCheckToken']),vo(_0x485aa8,mo,_0x4b9bca));}['open'](_0x387a2e,_0x5a6b88){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5a6b88,this['myPacketOrderer']=new sh(_0x387a2e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x2278b6)=>{const [_0x171db1,_0xff376a,_0x3ec9bf,_0x7bd97,_0x1cf076]=_0x2278b6;if(this['incrementIncomingBytes_'](_0x2278b6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x171db1===qs)this['id']=_0xff376a,this['password']=_0x3ec9bf;else{if(_0x171db1===rh)_0xff376a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xff376a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x171db1);}}},(..._0x56f6cb)=>{const [_0x5b797f,_0x3c5315]=_0x56f6cb;this['incrementIncomingBytes_'](_0x56f6cb),this['myPacketOrderer']['handleResponse'](_0x5b797f,_0x3c5315);},()=>{this['onClosed_']();},this['urlFn']);const _0x1a0973={};_0x1a0973[qs]='t',_0x1a0973[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1a0973[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1a0973[co]=Gi,this['transportSessionId']&&(_0x1a0973[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1a0973[po]=this['lastSessionId']),this['applicationId']&&(_0x1a0973[_o]=this['applicationId']),this['appCheckToken']&&(_0x1a0973[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1a0973[ho]=uo);const _0x51f7ff=this['urlFn'](_0x1a0973);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x51f7ff),this['scriptTagHolder']['addTag'](_0x51f7ff,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x57be51){const _0x1dfe91=O(_0x57be51);this['bytesSent']+=_0x1dfe91['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1dfe91['length']);const _0x5816f8=$r(_0x1dfe91),_0x15d255=oo(_0x5816f8,fh);for(let _0x3a44e5=0x0;_0x3a44e5<_0x15d255['length'];_0x3a44e5++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x15d255['length'],_0x15d255[_0x3a44e5]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x55e3c8,_0x2a7874){this['myDisconnFrame']=document['createElement']('iframe');const _0x4b3d6f={};_0x4b3d6f[dh]='t',_0x4b3d6f[Eo]=_0x55e3c8,_0x4b3d6f[Io]=_0x2a7874,this['myDisconnFrame']['src']=this['urlFn'](_0x4b3d6f),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x58a1d0){const _0x44de1e=O(_0x58a1d0)['length'];this['bytesReceived']+=_0x44de1e,this['stats_']['incrementCounter']('bytes_received',_0x44de1e);}}class zi{constructor(_0x1d17fc,_0x367837,_0x5575a3,_0x4717a9){this['onDisconnect']=_0x5575a3,this['urlFn']=_0x4717a9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1d17fc,window[ah+this['uniqueCallbackIdentifier']]=_0x367837,this['myIFrame']=zi['createIFrame_']();let _0x8b6f68='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x8b6f68='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x258af1='<html><body>'+_0x8b6f68+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x258af1),this['myIFrame']['doc']['close']();}catch(_0x30bd87){L('frame\x20writing\x20exception'),_0x30bd87['stack']&&L(_0x30bd87['stack']),L(_0x30bd87);}}}static['createIFrame_'](){const _0x1bfe99=document['createElement']('iframe');if(_0x1bfe99['style']['display']='none',document['body']){document['body']['appendChild'](_0x1bfe99);try{_0x1bfe99['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4b4764=document['domain'];_0x1bfe99['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4b4764+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1bfe99['contentDocument']?_0x1bfe99['doc']=_0x1bfe99['contentDocument']:_0x1bfe99['contentWindow']?_0x1bfe99['doc']=_0x1bfe99['contentWindow']['document']:_0x1bfe99['document']&&(_0x1bfe99['doc']=_0x1bfe99['document']),_0x1bfe99;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x6fc60b=this['onDisconnect'];_0x6fc60b&&(this['onDisconnect']=null,_0x6fc60b());}['startLongPoll'](_0x258317,_0x4a8e84){for(this['myID']=_0x258317,this['myPW']=_0x4a8e84,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x402f93={};_0x402f93[Eo]=this['myID'],_0x402f93[Io]=this['myPW'],_0x402f93[wo]=this['currentSerial'];let _0x51e8fe=this['urlFn'](_0x402f93),_0x3b1f83='',_0x4527d6=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x3b1f83['length']<=Co;){const _0x56bebf=this['pendingSegs']['shift']();_0x3b1f83=_0x3b1f83+'&'+lh+_0x4527d6+'='+_0x56bebf['seg']+'&'+hh+_0x4527d6+'='+_0x56bebf['ts']+'&'+uh+_0x4527d6+'='+_0x56bebf['d'],_0x4527d6++;}return _0x51e8fe=_0x51e8fe+_0x3b1f83,this['addLongPollTag_'](_0x51e8fe,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x377c00,_0x404d15,_0x5a9fe8){this['pendingSegs']['push']({'seg':_0x377c00,'ts':_0x404d15,'d':_0x5a9fe8}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x53bf5,_0x3dc8f9){this['outstandingRequests']['add'](_0x3dc8f9);const _0x1b3531=()=>{this['outstandingRequests']['delete'](_0x3dc8f9),this['newRequest_']();},_0x59bf25=setTimeout(_0x1b3531,Math['floor'](ph)),_0xfa57=()=>{clearTimeout(_0x59bf25),_0x1b3531();};this['addTag'](_0x53bf5,_0xfa57);}['addTag'](_0x5988ab,_0x3000f2){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x580990=this['myIFrame']['doc']['createElement']('script');_0x580990['type']='text/javascript',_0x580990['async']=!0x0,_0x580990['src']=_0x5988ab,_0x580990['onload']=_0x580990['onreadystatechange']=function(){const _0x70f23=_0x580990['readyState'];(!_0x70f23||_0x70f23==='loaded'||_0x70f23==='complete')&&(_0x580990['onload']=_0x580990['onreadystatechange']=null,_0x580990['parentNode']&&_0x580990['parentNode']['removeChild'](_0x580990),_0x3000f2());},_0x580990['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5988ab),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x580990);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x4bb35f,_0x43c7f2,_0x423e69,_0x2ecbb8,_0x4d3c16,_0x14e8cd,_0x5f5282){this['connId']=_0x4bb35f,this['applicationId']=_0x423e69,this['appCheckToken']=_0x2ecbb8,this['authToken']=_0x4d3c16,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x43c7f2),this['connURL']=q['connectionURL_'](_0x43c7f2,_0x14e8cd,_0x5f5282,_0x2ecbb8,_0x423e69),this['nodeAdmin']=_0x43c7f2['nodeAdmin'];}static['connectionURL_'](_0x2f4d43,_0x1688b1,_0x4f4401,_0x362962,_0x4129af){const _0x26cbb3={};return _0x26cbb3[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x26cbb3[ho]=uo),_0x1688b1&&(_0x26cbb3[lo]=_0x1688b1),_0x4f4401&&(_0x26cbb3[po]=_0x4f4401),_0x362962&&(_0x26cbb3[wi]=_0x362962),_0x4129af&&(_0x26cbb3[_o]=_0x4129af),vo(_0x2f4d43,go,_0x26cbb3);}['open'](_0x202560,_0x462eec){this['onDisconnect']=_0x462eec,this['onMessage']=_0x202560,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x9d4fcc;_c(),this['mySock']=new gn(this['connURL'],[],_0x9d4fcc);}catch(_0x4dcdf8){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x55b8f8=_0x4dcdf8['message']||_0x4dcdf8['data'];_0x55b8f8&&this['log_'](_0x55b8f8),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xbf4f26=>{this['handleIncomingFrame'](_0xbf4f26);},this['mySock']['onerror']=_0x2d5c4e=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x246f53=_0x2d5c4e['message']||_0x2d5c4e['data'];_0x246f53&&this['log_'](_0x246f53),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xed8692=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x315b3c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x376949=navigator['userAgent']['match'](_0x315b3c);_0x376949&&_0x376949['length']>0x1&&parseFloat(_0x376949[0x1])<4.4&&(_0xed8692=!0x0);}return!_0xed8692&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x566031){if(this['frames']['push'](_0x566031),this['frames']['length']===this['totalFrames']){const _0x1c0dce=this['frames']['join']('');this['frames']=null;const _0x56813b=Nt(_0x1c0dce);this['onMessage'](_0x56813b);}}['handleNewFrameCount_'](_0xffe057){this['totalFrames']=_0xffe057,this['frames']=[];}['extractFrameCount_'](_0x3bc129){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3bc129['length']<=0x6){const _0x4879a9=Number(_0x3bc129);if(!isNaN(_0x4879a9))return this['handleNewFrameCount_'](_0x4879a9),null;}return this['handleNewFrameCount_'](0x1),_0x3bc129;}['handleIncomingFrame'](_0x1231e7){if(this['mySock']===null)return;const _0x25a553=_0x1231e7['data'];if(this['bytesReceived']+=_0x25a553['length'],this['stats_']['incrementCounter']('bytes_received',_0x25a553['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x25a553);else{const _0x101d9d=this['extractFrameCount_'](_0x25a553);_0x101d9d!==null&&this['appendFrame_'](_0x101d9d);}}['send'](_0x5b9723){this['resetKeepAlive']();const _0x4f1181=O(_0x5b9723);this['bytesSent']+=_0x4f1181['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4f1181['length']);const _0x27f5c2=oo(_0x4f1181,gh);_0x27f5c2['length']>0x1&&this['sendString_'](String(_0x27f5c2['length']));for(let _0x52ad84=0x0;_0x52ad84<_0x27f5c2['length'];_0x52ad84++)this['sendString_'](_0x27f5c2[_0x52ad84]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x244b85){try{this['mySock']['send'](_0x244b85);}catch(_0x5d16e6){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5d16e6['message']||_0x5d16e6['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x25d010){this['initTransports_'](_0x25d010);}['initTransports_'](_0x5da323){const _0xc8e3ab=q&&q['isAvailable']();let _0x18dcea=_0xc8e3ab&&!q['previouslyFailed']();if(_0x5da323['webSocketOnly']&&(_0xc8e3ab||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x18dcea=!0x0),_0x18dcea)this['transports_']=[q];else{const _0x4038f1=this['transports_']=[];for(const _0x205335 of Dt['ALL_TRANSPORTS'])_0x205335&&_0x205335['isAvailable']()&&_0x4038f1['push'](_0x205335);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x104763,_0x30903e,_0x5c4d49,_0x2d892a,_0x2bac4d,_0xb4cce2,_0x467d8b,_0x148045,_0x43f921,_0x4e4996){this['id']=_0x104763,this['repoInfo_']=_0x30903e,this['applicationId_']=_0x5c4d49,this['appCheckToken_']=_0x2d892a,this['authToken_']=_0x2bac4d,this['onMessage_']=_0xb4cce2,this['onReady_']=_0x467d8b,this['onDisconnect_']=_0x148045,this['onKill_']=_0x43f921,this['lastSessionId']=_0x4e4996,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x30903e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x31f881=this['transportManager_']['initialTransport']();this['conn_']=new _0x31f881(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x31f881['responsesRequiredToBeHealthy']||0x0;const _0x2217d3=this['connReceiver_'](this['conn_']),_0x4322ea=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2217d3,_0x4322ea);},Math['floor'](0x0));const _0x579c38=_0x31f881['healthyTimeout']||0x0;_0x579c38>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x579c38)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2c2b98){return _0x57ebce=>{_0x2c2b98===this['conn_']?this['onConnectionLost_'](_0x57ebce):_0x2c2b98===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x446ce7){return _0x4b097d=>{this['state_']!==0x2&&(_0x446ce7===this['rx_']?this['onPrimaryMessageReceived_'](_0x4b097d):_0x446ce7===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4b097d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5de8ff){const _0x5596b2={'t':'d','d':_0x5de8ff};this['sendData_'](_0x5596b2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x131377){if(ci in _0x131377){const _0x156a26=_0x131377[ci];_0x156a26===Ys?this['upgradeIfSecondaryHealthy_']():_0x156a26===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x156a26===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x103b1d){const _0x382592=vt('t',_0x103b1d),_0x934eba=vt('d',_0x103b1d);if(_0x382592==='c')this['onSecondaryControl_'](_0x934eba);else{if(_0x382592==='d')this['pendingDataMessages']['push'](_0x934eba);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x382592);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2be5d1){const _0x3fa4a2=vt('t',_0x2be5d1),_0x26f78f=vt('d',_0x2be5d1);_0x3fa4a2==='c'?this['onControl_'](_0x26f78f):_0x3fa4a2==='d'&&this['onDataMessage_'](_0x26f78f);}['onDataMessage_'](_0x3819db){this['onPrimaryResponse_'](),this['onMessage_'](_0x3819db);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2482ba){const _0x52d28e=vt(ci,_0x2482ba);if(zs in _0x2482ba){const _0x3515ad=_0x2482ba[zs];if(_0x52d28e===Th){const _0xe21e2c={..._0x3515ad};this['repoInfo_']['isUsingEmulator']&&(_0xe21e2c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xe21e2c);}else{if(_0x52d28e===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x468996=0x0;_0x468996<this['pendingDataMessages']['length'];++_0x468996)this['onDataMessage_'](this['pendingDataMessages'][_0x468996]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x52d28e===wh?this['onConnectionShutdown_'](_0x3515ad):_0x52d28e===js?this['onReset_'](_0x3515ad):_0x52d28e===Ch?Ii('Server\x20Error:\x20'+_0x3515ad):_0x52d28e===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x52d28e);}}}['onHandshake_'](_0x3e94cf){const _0x38cc7d=_0x3e94cf['ts'],_0x3d07bd=_0x3e94cf['v'],_0x4437f5=_0x3e94cf['h'];this['sessionId']=_0x3e94cf['s'],this['repoInfo_']['host']=_0x4437f5,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x38cc7d),Gi!==_0x3d07bd&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1e1959=this['transportManager_']['upgradeTransport']();_0x1e1959&&this['startUpgrade_'](_0x1e1959);}['startUpgrade_'](_0x96a191){this['secondaryConn_']=new _0x96a191(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x96a191['responsesRequiredToBeHealthy']||0x0;const _0xecb7ec=this['connReceiver_'](this['secondaryConn_']),_0xe49355=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xecb7ec,_0xe49355),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5c8831){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5c8831),this['repoInfo_']['host']=_0x5c8831,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x27830c,_0x7e93b2){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x27830c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x7e93b2,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3c93c6=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3c93c6||this['rx_']===_0x3c93c6)&&this['close']();}['onConnectionLost_'](_0x552389){this['conn_']=null,!_0x552389&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x53381f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x53381f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x50a0dc){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x50a0dc);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x382b33,_0xe08ff7,_0x1390c1,_0x2e82f8){}['merge'](_0x4c2fe2,_0x123d37,_0x329279,_0x8b4329){}['refreshAuthToken'](_0x301dd6){}['refreshAppCheckToken'](_0x12eef4){}['onDisconnectPut'](_0x3d8aa0,_0xd7637,_0x148ef7){}['onDisconnectMerge'](_0xb878ed,_0x2faf85,_0x58cbde){}['onDisconnectCancel'](_0x1803be,_0x6a4e59){}['reportStats'](_0x23293a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x4626e0){this['allowedEvents_']=_0x4626e0,this['listeners_']={},f(Array['isArray'](_0x4626e0)&&_0x4626e0['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5a965d,..._0x37f74a){if(Array['isArray'](this['listeners_'][_0x5a965d])){const _0x368442=[...this['listeners_'][_0x5a965d]];for(let _0x2650a2=0x0;_0x2650a2<_0x368442['length'];_0x2650a2++)_0x368442[_0x2650a2]['callback']['apply'](_0x368442[_0x2650a2]['context'],_0x37f74a);}}['on'](_0x59e086,_0x32836d,_0x40d841){this['validateEventType_'](_0x59e086),this['listeners_'][_0x59e086]=this['listeners_'][_0x59e086]||[],this['listeners_'][_0x59e086]['push']({'callback':_0x32836d,'context':_0x40d841});const _0x2a5b29=this['getInitialEvent'](_0x59e086);_0x2a5b29&&_0x32836d['apply'](_0x40d841,_0x2a5b29);}['off'](_0x26226b,_0x228b3e,_0x5bdca1){this['validateEventType_'](_0x26226b);const _0x39ff7d=this['listeners_'][_0x26226b]||[];for(let _0x18e8b0=0x0;_0x18e8b0<_0x39ff7d['length'];_0x18e8b0++)if(_0x39ff7d[_0x18e8b0]['callback']===_0x228b3e&&(!_0x5bdca1||_0x5bdca1===_0x39ff7d[_0x18e8b0]['context'])){_0x39ff7d['splice'](_0x18e8b0,0x1);return;}}['validateEventType_'](_0x306003){f(this['allowedEvents_']['find'](_0x534862=>_0x534862===_0x306003),'Unknown\x20event:\x20'+_0x306003);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1ef15b){return f(_0x1ef15b==='online','Unknown\x20event\x20type:\x20'+_0x1ef15b),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x385913,_0x37985e){if(_0x37985e===void 0x0){this['pieces_']=_0x385913['split']('/');let _0x2b715c=0x0;for(let _0x3102e9=0x0;_0x3102e9<this['pieces_']['length'];_0x3102e9++)this['pieces_'][_0x3102e9]['length']>0x0&&(this['pieces_'][_0x2b715c]=this['pieces_'][_0x3102e9],_0x2b715c++);this['pieces_']['length']=_0x2b715c,this['pieceNum_']=0x0;}else this['pieces_']=_0x385913,this['pieceNum_']=_0x37985e;}['toString'](){let _0x3c6693='';for(let _0x462ef6=this['pieceNum_'];_0x462ef6<this['pieces_']['length'];_0x462ef6++)this['pieces_'][_0x462ef6]!==''&&(_0x3c6693+='/'+this['pieces_'][_0x462ef6]);return _0x3c6693||'/';}}function w(){return new C('');}function y(_0x5785af){return _0x5785af['pieceNum_']>=_0x5785af['pieces_']['length']?null:_0x5785af['pieces_'][_0x5785af['pieceNum_']];}function Ce(_0x3c1133){return _0x3c1133['pieces_']['length']-_0x3c1133['pieceNum_'];}function S(_0x4a1f0c){let _0x2da83b=_0x4a1f0c['pieceNum_'];return _0x2da83b<_0x4a1f0c['pieces_']['length']&&_0x2da83b++,new C(_0x4a1f0c['pieces_'],_0x2da83b);}function ji(_0x24a53d){return _0x24a53d['pieceNum_']<_0x24a53d['pieces_']['length']?_0x24a53d['pieces_'][_0x24a53d['pieces_']['length']-0x1]:null;}function bh(_0x30703a){let _0x597d67='';for(let _0x7ab829=_0x30703a['pieceNum_'];_0x7ab829<_0x30703a['pieces_']['length'];_0x7ab829++)_0x30703a['pieces_'][_0x7ab829]!==''&&(_0x597d67+='/'+encodeURIComponent(String(_0x30703a['pieces_'][_0x7ab829])));return _0x597d67||'/';}function Mt(_0x4521c3,_0x3dd882=0x0){return _0x4521c3['pieces_']['slice'](_0x4521c3['pieceNum_']+_0x3dd882);}function Ro(_0xebecb8){if(_0xebecb8['pieceNum_']>=_0xebecb8['pieces_']['length'])return null;const _0x23a930=[];for(let _0x179d3c=_0xebecb8['pieceNum_'];_0x179d3c<_0xebecb8['pieces_']['length']-0x1;_0x179d3c++)_0x23a930['push'](_0xebecb8['pieces_'][_0x179d3c]);return new C(_0x23a930,0x0);}function k(_0x2b15c2,_0x467c24){const _0x317414=[];for(let _0x3daa06=_0x2b15c2['pieceNum_'];_0x3daa06<_0x2b15c2['pieces_']['length'];_0x3daa06++)_0x317414['push'](_0x2b15c2['pieces_'][_0x3daa06]);if(_0x467c24 instanceof C){for(let _0x2cdec9=_0x467c24['pieceNum_'];_0x2cdec9<_0x467c24['pieces_']['length'];_0x2cdec9++)_0x317414['push'](_0x467c24['pieces_'][_0x2cdec9]);}else{const _0x49f66f=_0x467c24['split']('/');for(let _0x919923=0x0;_0x919923<_0x49f66f['length'];_0x919923++)_0x49f66f[_0x919923]['length']>0x0&&_0x317414['push'](_0x49f66f[_0x919923]);}return new C(_0x317414,0x0);}function v(_0x30d5e1){return _0x30d5e1['pieceNum_']>=_0x30d5e1['pieces_']['length'];}function F(_0x29c25f,_0x2399f4){const _0x203458=y(_0x29c25f),_0x563acb=y(_0x2399f4);if(_0x203458===null)return _0x2399f4;if(_0x203458===_0x563acb)return F(S(_0x29c25f),S(_0x2399f4));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2399f4+')\x20is\x20not\x20within\x20outerPath\x20('+_0x29c25f+')');}function Rh(_0x164871,_0x1bbbda){const _0x21bbf5=Mt(_0x164871,0x0),_0x43a55f=Mt(_0x1bbbda,0x0);for(let _0x13aa57=0x0;_0x13aa57<_0x21bbf5['length']&&_0x13aa57<_0x43a55f['length'];_0x13aa57++){const _0x7a5878=qe(_0x21bbf5[_0x13aa57],_0x43a55f[_0x13aa57]);if(_0x7a5878!==0x0)return _0x7a5878;}return _0x21bbf5['length']===_0x43a55f['length']?0x0:_0x21bbf5['length']<_0x43a55f['length']?-0x1:0x1;}function Ki(_0x206a7b,_0x4d57cd){if(Ce(_0x206a7b)!==Ce(_0x4d57cd))return!0x1;for(let _0x5c1d9b=_0x206a7b['pieceNum_'],_0x15b4e9=_0x4d57cd['pieceNum_'];_0x5c1d9b<=_0x206a7b['pieces_']['length'];_0x5c1d9b++,_0x15b4e9++)if(_0x206a7b['pieces_'][_0x5c1d9b]!==_0x4d57cd['pieces_'][_0x15b4e9])return!0x1;return!0x0;}function G(_0x9455d6,_0x5165d1){let _0x54398f=_0x9455d6['pieceNum_'],_0x29938a=_0x5165d1['pieceNum_'];if(Ce(_0x9455d6)>Ce(_0x5165d1))return!0x1;for(;_0x54398f<_0x9455d6['pieces_']['length'];){if(_0x9455d6['pieces_'][_0x54398f]!==_0x5165d1['pieces_'][_0x29938a])return!0x1;++_0x54398f,++_0x29938a;}return!0x0;}class Ah{constructor(_0x454296,_0x5359f7){this['errorPrefix_']=_0x5359f7,this['parts_']=Mt(_0x454296,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x19316a=0x0;_0x19316a<this['parts_']['length'];_0x19316a++)this['byteLength_']+=Ln(this['parts_'][_0x19316a]);Ao(this);}}function kh(_0x5432f8,_0x4866f1){_0x5432f8['parts_']['length']>0x0&&(_0x5432f8['byteLength_']+=0x1),_0x5432f8['parts_']['push'](_0x4866f1),_0x5432f8['byteLength_']+=Ln(_0x4866f1),Ao(_0x5432f8);}function Ph(_0xdc500c){const _0x5bcb29=_0xdc500c['parts_']['pop']();_0xdc500c['byteLength_']-=Ln(_0x5bcb29),_0xdc500c['parts_']['length']>0x0&&(_0xdc500c['byteLength_']-=0x1);}function Ao(_0xb607a){if(_0xb607a['byteLength_']>Zs)throw new Error(_0xb607a['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0xb607a['byteLength_']+').');if(_0xb607a['parts_']['length']>Xs)throw new Error(_0xb607a['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0xb607a));}function Oe(_0xad084){return _0xad084['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xad084['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x2c6c82,_0x258ef3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x258ef3='visibilitychange',_0x2c6c82='hidden'):typeof document['mozHidden']<'u'?(_0x258ef3='mozvisibilitychange',_0x2c6c82='mozHidden'):typeof document['msHidden']<'u'?(_0x258ef3='msvisibilitychange',_0x2c6c82='msHidden'):typeof document['webkitHidden']<'u'&&(_0x258ef3='webkitvisibilitychange',_0x2c6c82='webkitHidden')),this['visible_']=!0x0,_0x258ef3&&document['addEventListener'](_0x258ef3,()=>{const _0x1872bf=!document[_0x2c6c82];_0x1872bf!==this['visible_']&&(this['visible_']=_0x1872bf,this['trigger']('visible',_0x1872bf));},!0x1);}['getInitialEvent'](_0x18cd08){return f(_0x18cd08==='visible','Unknown\x20event\x20type:\x20'+_0x18cd08),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x43be2e,_0x4b85b2,_0x3d42dc,_0x4ef4d4,_0x2152cf,_0x139f8d,_0x5e7036,_0x511d8c){if(super(),this['repoInfo_']=_0x43be2e,this['applicationId_']=_0x4b85b2,this['onDataUpdate_']=_0x3d42dc,this['onConnectStatus_']=_0x4ef4d4,this['onServerInfoUpdate_']=_0x2152cf,this['authTokenProvider_']=_0x139f8d,this['appCheckTokenProvider_']=_0x5e7036,this['authOverride_']=_0x511d8c,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x511d8c)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x43be2e['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x400448,_0x4748e9,_0x586d65){const _0x3960d0=++this['requestNumber_'],_0x16e562={'r':_0x3960d0,'a':_0x400448,'b':_0x4748e9};this['log_'](O(_0x16e562)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x16e562),_0x586d65&&(this['requestCBHash_'][_0x3960d0]=_0x586d65);}['get'](_0x2899e5){this['initConnection_']();const _0x2d6623=new H(),_0x415f66={'action':'g','request':{'p':_0x2899e5['_path']['toString'](),'q':_0x2899e5['_queryObject']},'onComplete':_0x482ac9=>{const _0x4e9c48=_0x482ac9['d'];_0x482ac9['s']==='ok'?_0x2d6623['resolve'](_0x4e9c48):_0x2d6623['reject'](_0x4e9c48);}};this['outstandingGets_']['push'](_0x415f66),this['outstandingGetCount_']++;const _0xbb7dbb=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xbb7dbb),_0x2d6623['promise'];}['listen'](_0x10b62e,_0x550746,_0x1f0eef,_0x3fcd08){this['initConnection_']();const _0x2f9808=_0x10b62e['_queryIdentifier'],_0x568e1c=_0x10b62e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x568e1c+'\x20'+_0x2f9808),this['listens']['has'](_0x568e1c)||this['listens']['set'](_0x568e1c,new Map()),f(_0x10b62e['_queryParams']['isDefault']()||!_0x10b62e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x568e1c)['has'](_0x2f9808),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4779c6={'onComplete':_0x3fcd08,'hashFn':_0x550746,'query':_0x10b62e,'tag':_0x1f0eef};this['listens']['get'](_0x568e1c)['set'](_0x2f9808,_0x4779c6),this['connected_']&&this['sendListen_'](_0x4779c6);}['sendGet_'](_0x90b5bd){const _0xcf0b45=this['outstandingGets_'][_0x90b5bd];this['sendRequest']('g',_0xcf0b45['request'],_0x233d3a=>{delete this['outstandingGets_'][_0x90b5bd],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xcf0b45['onComplete']&&_0xcf0b45['onComplete'](_0x233d3a);});}['sendListen_'](_0x2e564b){const _0x39c1c9=_0x2e564b['query'],_0x5f2981=_0x39c1c9['_path']['toString'](),_0x118f08=_0x39c1c9['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5f2981+'\x20for\x20'+_0x118f08);const _0x22620c={'p':_0x5f2981},_0x270fce='q';_0x2e564b['tag']&&(_0x22620c['q']=_0x39c1c9['_queryObject'],_0x22620c['t']=_0x2e564b['tag']),_0x22620c['h']=_0x2e564b['hashFn'](),this['sendRequest'](_0x270fce,_0x22620c,_0x25a53c=>{const _0xbe6d4=_0x25a53c['d'],_0x3a18f7=_0x25a53c['s'];se['warnOnListenWarnings_'](_0xbe6d4,_0x39c1c9),(this['listens']['get'](_0x5f2981)&&this['listens']['get'](_0x5f2981)['get'](_0x118f08))===_0x2e564b&&(this['log_']('listen\x20response',_0x25a53c),_0x3a18f7!=='ok'&&this['removeListen_'](_0x5f2981,_0x118f08),_0x2e564b['onComplete']&&_0x2e564b['onComplete'](_0x3a18f7,_0xbe6d4));});}static['warnOnListenWarnings_'](_0x41e70e,_0x507f5c){if(_0x41e70e&&typeof _0x41e70e=='object'&&Q(_0x41e70e,'w')){const _0x1f326d=Le(_0x41e70e,'w');if(Array['isArray'](_0x1f326d)&&~_0x1f326d['indexOf']('no_index')){const _0x42ba94='\x22.indexOn\x22:\x20\x22'+_0x507f5c['_queryParams']['getIndex']()['toString']()+'\x22',_0x74e434=_0x507f5c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x42ba94+'\x20at\x20'+_0x74e434+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x549910){this['authToken_']=_0x549910,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x549910);}['reduceReconnectDelayIfAdminCredential_'](_0x5916d0){(_0x5916d0&&_0x5916d0['length']===0x28||wc(_0x5916d0))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x391829){this['appCheckToken_']=_0x391829,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x16bf84=this['authToken_'],_0x4aa4fb=Ic(_0x16bf84)?'auth':'gauth',_0x1b475e={'cred':_0x16bf84};this['authOverride_']===null?_0x1b475e['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1b475e['authvar']=this['authOverride_']),this['sendRequest'](_0x4aa4fb,_0x1b475e,_0x57d2f8=>{const _0x5e7a9e=_0x57d2f8['s'],_0x1d453f=_0x57d2f8['d']||'error';this['authToken_']===_0x16bf84&&(_0x5e7a9e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5e7a9e,_0x1d453f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x81e895=>{const _0x17ea11=_0x81e895['s'],_0x43341b=_0x81e895['d']||'error';_0x17ea11==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x17ea11,_0x43341b);});}['unlisten'](_0x26136e,_0x36aaa1){const _0x36ff0f=_0x26136e['_path']['toString'](),_0x959e8a=_0x26136e['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x36ff0f+'\x20'+_0x959e8a),f(_0x26136e['_queryParams']['isDefault']()||!_0x26136e['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x36ff0f,_0x959e8a)&&this['connected_']&&this['sendUnlisten_'](_0x36ff0f,_0x959e8a,_0x26136e['_queryObject'],_0x36aaa1);}['sendUnlisten_'](_0x5b35d9,_0x563081,_0x14feec,_0x49617f){this['log_']('Unlisten\x20on\x20'+_0x5b35d9+'\x20for\x20'+_0x563081);const _0x1fcf25={'p':_0x5b35d9},_0x512958='n';_0x49617f&&(_0x1fcf25['q']=_0x14feec,_0x1fcf25['t']=_0x49617f),this['sendRequest'](_0x512958,_0x1fcf25);}['onDisconnectPut'](_0x58c6b5,_0x2c4d81,_0x4ddf66){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x58c6b5,_0x2c4d81,_0x4ddf66):this['onDisconnectRequestQueue_']['push']({'pathString':_0x58c6b5,'action':'o','data':_0x2c4d81,'onComplete':_0x4ddf66});}['onDisconnectMerge'](_0x942ac8,_0x4f4f96,_0x2496ed){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x942ac8,_0x4f4f96,_0x2496ed):this['onDisconnectRequestQueue_']['push']({'pathString':_0x942ac8,'action':'om','data':_0x4f4f96,'onComplete':_0x2496ed});}['onDisconnectCancel'](_0xc9b7c9,_0x36e4bd){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xc9b7c9,null,_0x36e4bd):this['onDisconnectRequestQueue_']['push']({'pathString':_0xc9b7c9,'action':'oc','data':null,'onComplete':_0x36e4bd});}['sendOnDisconnect_'](_0x3cf0d9,_0x47c71e,_0x53b26a,_0x5589f4){const _0x3b7422={'p':_0x47c71e,'d':_0x53b26a};this['log_']('onDisconnect\x20'+_0x3cf0d9,_0x3b7422),this['sendRequest'](_0x3cf0d9,_0x3b7422,_0x40c15e=>{_0x5589f4&&setTimeout(()=>{_0x5589f4(_0x40c15e['s'],_0x40c15e['d']);},Math['floor'](0x0));});}['put'](_0x1c9f9f,_0x2983a0,_0x2bbb27,_0xfd6a2b){this['putInternal']('p',_0x1c9f9f,_0x2983a0,_0x2bbb27,_0xfd6a2b);}['merge'](_0x2af5d4,_0xd00f45,_0x29e078,_0x34fbf4){this['putInternal']('m',_0x2af5d4,_0xd00f45,_0x29e078,_0x34fbf4);}['putInternal'](_0x111e9f,_0x24605e,_0x1865db,_0x2bf61a,_0x49ad22){this['initConnection_']();const _0x51ee51={'p':_0x24605e,'d':_0x1865db};_0x49ad22!==void 0x0&&(_0x51ee51['h']=_0x49ad22),this['outstandingPuts_']['push']({'action':_0x111e9f,'request':_0x51ee51,'onComplete':_0x2bf61a}),this['outstandingPutCount_']++;const _0x279ee8=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x279ee8):this['log_']('Buffering\x20put:\x20'+_0x24605e);}['sendPut_'](_0x5e6f70){const _0x756223=this['outstandingPuts_'][_0x5e6f70]['action'],_0x770dc0=this['outstandingPuts_'][_0x5e6f70]['request'],_0x32ba31=this['outstandingPuts_'][_0x5e6f70]['onComplete'];this['outstandingPuts_'][_0x5e6f70]['queued']=this['connected_'],this['sendRequest'](_0x756223,_0x770dc0,_0x4a7cf6=>{this['log_'](_0x756223+'\x20response',_0x4a7cf6),delete this['outstandingPuts_'][_0x5e6f70],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x32ba31&&_0x32ba31(_0x4a7cf6['s'],_0x4a7cf6['d']);});}['reportStats'](_0x50440f){if(this['connected_']){const _0x1d9654={'c':_0x50440f};this['log_']('reportStats',_0x1d9654),this['sendRequest']('s',_0x1d9654,_0x18ff9a=>{if(_0x18ff9a['s']!=='ok'){const _0x571fee=_0x18ff9a['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x571fee);}});}}['onDataMessage_'](_0x5a46e7){if('r'in _0x5a46e7){this['log_']('from\x20server:\x20'+O(_0x5a46e7));const _0x3f0a20=_0x5a46e7['r'],_0xc9f875=this['requestCBHash_'][_0x3f0a20];_0xc9f875&&(delete this['requestCBHash_'][_0x3f0a20],_0xc9f875(_0x5a46e7['b']));}else{if('error'in _0x5a46e7)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5a46e7['error'];'a'in _0x5a46e7&&this['onDataPush_'](_0x5a46e7['a'],_0x5a46e7['b']);}}['onDataPush_'](_0x2880ae,_0x227069){this['log_']('handleServerMessage',_0x2880ae,_0x227069),_0x2880ae==='d'?this['onDataUpdate_'](_0x227069['p'],_0x227069['d'],!0x1,_0x227069['t']):_0x2880ae==='m'?this['onDataUpdate_'](_0x227069['p'],_0x227069['d'],!0x0,_0x227069['t']):_0x2880ae==='c'?this['onListenRevoked_'](_0x227069['p'],_0x227069['q']):_0x2880ae==='ac'?this['onAuthRevoked_'](_0x227069['s'],_0x227069['d']):_0x2880ae==='apc'?this['onAppCheckRevoked_'](_0x227069['s'],_0x227069['d']):_0x2880ae==='sd'?this['onSecurityDebugPacket_'](_0x227069):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2880ae)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x47422c,_0x3db925){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x47422c),this['lastSessionId']=_0x3db925,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4de7b0){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4de7b0));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2fcaab){_0x2fcaab&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2fcaab;}['onOnline_'](_0x2b4b3f){_0x2b4b3f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xdf63db=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3a054b=Math['max'](0x0,this['reconnectDelay_']-_0xdf63db);_0x3a054b=Math['random']()*_0x3a054b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3a054b+'ms'),this['scheduleConnect_'](_0x3a054b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1cbee1=this['onDataMessage_']['bind'](this),_0x401150=this['onReady_']['bind'](this),_0x40743e=this['onRealtimeDisconnect_']['bind'](this),_0x39d09c=this['id']+':'+se['nextConnectionId_']++,_0x8aa932=this['lastSessionId'];let _0x2fdbfa=!0x1,_0x2dec41=null;const _0x9f7077=function(){_0x2dec41?_0x2dec41['close']():(_0x2fdbfa=!0x0,_0x40743e());},_0x1adc4c=function(_0x5f1c2c){f(_0x2dec41,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2dec41['sendRequest'](_0x5f1c2c);};this['realtime_']={'close':_0x9f7077,'sendRequest':_0x1adc4c};const _0x5c5861=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x59a3f9,_0x4a81ea]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5c5861),this['appCheckTokenProvider_']['getToken'](_0x5c5861)]);_0x2fdbfa?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x59a3f9&&_0x59a3f9['accessToken'],this['appCheckToken_']=_0x4a81ea&&_0x4a81ea['token'],_0x2dec41=new Sh(_0x39d09c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1cbee1,_0x401150,_0x40743e,_0x519c84=>{U(_0x519c84+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x8aa932));}catch(_0x3b0415){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3b0415),_0x2fdbfa||(this['repoInfo_']['nodeAdmin']&&U(_0x3b0415),_0x9f7077());}}}['interrupt'](_0x162908){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x162908),this['interruptReasons_'][_0x162908]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4ee4fe){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4ee4fe),delete this['interruptReasons_'][_0x4ee4fe],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1c70a7){const _0x2713fc=_0x1c70a7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2713fc});}['cancelSentTransactions_'](){for(let _0x54674e=0x0;_0x54674e<this['outstandingPuts_']['length'];_0x54674e++){const _0x54a71a=this['outstandingPuts_'][_0x54674e];_0x54a71a&&'h'in _0x54a71a['request']&&_0x54a71a['queued']&&(_0x54a71a['onComplete']&&_0x54a71a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x54674e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3daaa8,_0x5f1bae){let _0x511921;_0x5f1bae?_0x511921=_0x5f1bae['map'](_0x246d45=>$i(_0x246d45))['join']('$'):_0x511921='default';const _0x2478f0=this['removeListen_'](_0x3daaa8,_0x511921);_0x2478f0&&_0x2478f0['onComplete']&&_0x2478f0['onComplete']('permission_denied');}['removeListen_'](_0xa76dea,_0x47ef94){const _0x484665=new C(_0xa76dea)['toString']();let _0x548039;if(this['listens']['has'](_0x484665)){const _0x3c2d1c=this['listens']['get'](_0x484665);_0x548039=_0x3c2d1c['get'](_0x47ef94),_0x3c2d1c['delete'](_0x47ef94),_0x3c2d1c['size']===0x0&&this['listens']['delete'](_0x484665);}else _0x548039=void 0x0;return _0x548039;}['onAuthRevoked_'](_0x43450c,_0x32df7c){L('Auth\x20token\x20revoked:\x20'+_0x43450c+'/'+_0x32df7c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x43450c==='invalid_token'||_0x43450c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x93edb,_0x355cd1){L('App\x20check\x20token\x20revoked:\x20'+_0x93edb+'/'+_0x355cd1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x93edb==='invalid_token'||_0x93edb==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x47acfd){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x47acfd):'msg'in _0x47acfd&&console['log']('FIREBASE:\x20'+_0x47acfd['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x21e901 of this['listens']['values']())for(const _0x5d5f6b of _0x21e901['values']())this['sendListen_'](_0x5d5f6b);for(let _0x19ae5c=0x0;_0x19ae5c<this['outstandingPuts_']['length'];_0x19ae5c++)this['outstandingPuts_'][_0x19ae5c]&&this['sendPut_'](_0x19ae5c);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2f2dd2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2f2dd2['action'],_0x2f2dd2['pathString'],_0x2f2dd2['data'],_0x2f2dd2['onComplete']);}for(let _0x35b9ab=0x0;_0x35b9ab<this['outstandingGets_']['length'];_0x35b9ab++)this['outstandingGets_'][_0x35b9ab]&&this['sendGet_'](_0x35b9ab);}['sendConnectStats_'](){const _0x369b24={};let _0x5ce4f8='js';_0x369b24['sdk.'+_0x5ce4f8+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x369b24['framework.cordova']=0x1:Kr()&&(_0x369b24['framework.reactnative']=0x1),this['reportStats'](_0x369b24);}['shouldReconnect_'](){const _0x388a81=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x388a81;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1c3076,_0x3e061a){this['name']=_0x1c3076,this['node']=_0x3e061a;}static['Wrap'](_0x20e599,_0x4614b2){return new E(_0x20e599,_0x4614b2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2595c0,_0x1ec262){const _0x50f435=new E(We,_0x2595c0),_0x3d00f4=new E(We,_0x1ec262);return this['compare'](_0x50f435,_0x3d00f4)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x29a9cd){sn=_0x29a9cd;}['compare'](_0xcde211,_0x2627ea){return qe(_0xcde211['name'],_0x2627ea['name']);}['isDefinedOn'](_0x26d93d){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x13a74c,_0x15101e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x1c40f5,_0x4af6a5){return f(typeof _0x1c40f5=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1c40f5,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x465385,_0x6cd93c,_0x2a54b4,_0x4b4438,_0xd41c45=null){this['isReverse_']=_0x4b4438,this['resultGenerator_']=_0xd41c45,this['nodeStack_']=[];let _0x1d2886=0x1;for(;!_0x465385['isEmpty']();)if(_0x465385=_0x465385,_0x1d2886=_0x6cd93c?_0x2a54b4(_0x465385['key'],_0x6cd93c):0x1,_0x4b4438&&(_0x1d2886*=-0x1),_0x1d2886<0x0)this['isReverse_']?_0x465385=_0x465385['left']:_0x465385=_0x465385['right'];else{if(_0x1d2886===0x0){this['nodeStack_']['push'](_0x465385);break;}else this['nodeStack_']['push'](_0x465385),this['isReverse_']?_0x465385=_0x465385['right']:_0x465385=_0x465385['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x498d70=this['nodeStack_']['pop'](),_0x1e72bf;if(this['resultGenerator_']?_0x1e72bf=this['resultGenerator_'](_0x498d70['key'],_0x498d70['value']):_0x1e72bf={'key':_0x498d70['key'],'value':_0x498d70['value']},this['isReverse_']){for(_0x498d70=_0x498d70['left'];!_0x498d70['isEmpty']();)this['nodeStack_']['push'](_0x498d70),_0x498d70=_0x498d70['right'];}else{for(_0x498d70=_0x498d70['right'];!_0x498d70['isEmpty']();)this['nodeStack_']['push'](_0x498d70),_0x498d70=_0x498d70['left'];}return _0x1e72bf;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x556a2c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x556a2c['key'],_0x556a2c['value']):{'key':_0x556a2c['key'],'value':_0x556a2c['value']};}}class M{constructor(_0x4735d7,_0xfd305c,_0x498659,_0x16bdc7,_0x390ef4){this['key']=_0x4735d7,this['value']=_0xfd305c,this['color']=_0x498659??M['RED'],this['left']=_0x16bdc7??B['EMPTY_NODE'],this['right']=_0x390ef4??B['EMPTY_NODE'];}['copy'](_0xbe4f4a,_0x3dff6a,_0x4f9946,_0x14cffd,_0x47e95f){return new M(_0xbe4f4a??this['key'],_0x3dff6a??this['value'],_0x4f9946??this['color'],_0x14cffd??this['left'],_0x47e95f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4bedf6){return this['left']['inorderTraversal'](_0x4bedf6)||!!_0x4bedf6(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4bedf6);}['reverseTraversal'](_0x2ef96c){return this['right']['reverseTraversal'](_0x2ef96c)||_0x2ef96c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2ef96c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4ea7f8,_0x341485,_0x1e7729){let _0x577940=this;const _0x16f083=_0x1e7729(_0x4ea7f8,_0x577940['key']);return _0x16f083<0x0?_0x577940=_0x577940['copy'](null,null,null,_0x577940['left']['insert'](_0x4ea7f8,_0x341485,_0x1e7729),null):_0x16f083===0x0?_0x577940=_0x577940['copy'](null,_0x341485,null,null,null):_0x577940=_0x577940['copy'](null,null,null,null,_0x577940['right']['insert'](_0x4ea7f8,_0x341485,_0x1e7729)),_0x577940['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1e15e7=this;return!_0x1e15e7['left']['isRed_']()&&!_0x1e15e7['left']['left']['isRed_']()&&(_0x1e15e7=_0x1e15e7['moveRedLeft_']()),_0x1e15e7=_0x1e15e7['copy'](null,null,null,_0x1e15e7['left']['removeMin_'](),null),_0x1e15e7['fixUp_']();}['remove'](_0x38d0f2,_0x37e17e){let _0x2ef5b4,_0x51391c;if(_0x2ef5b4=this,_0x37e17e(_0x38d0f2,_0x2ef5b4['key'])<0x0)!_0x2ef5b4['left']['isEmpty']()&&!_0x2ef5b4['left']['isRed_']()&&!_0x2ef5b4['left']['left']['isRed_']()&&(_0x2ef5b4=_0x2ef5b4['moveRedLeft_']()),_0x2ef5b4=_0x2ef5b4['copy'](null,null,null,_0x2ef5b4['left']['remove'](_0x38d0f2,_0x37e17e),null);else{if(_0x2ef5b4['left']['isRed_']()&&(_0x2ef5b4=_0x2ef5b4['rotateRight_']()),!_0x2ef5b4['right']['isEmpty']()&&!_0x2ef5b4['right']['isRed_']()&&!_0x2ef5b4['right']['left']['isRed_']()&&(_0x2ef5b4=_0x2ef5b4['moveRedRight_']()),_0x37e17e(_0x38d0f2,_0x2ef5b4['key'])===0x0){if(_0x2ef5b4['right']['isEmpty']())return B['EMPTY_NODE'];_0x51391c=_0x2ef5b4['right']['min_'](),_0x2ef5b4=_0x2ef5b4['copy'](_0x51391c['key'],_0x51391c['value'],null,null,_0x2ef5b4['right']['removeMin_']());}_0x2ef5b4=_0x2ef5b4['copy'](null,null,null,null,_0x2ef5b4['right']['remove'](_0x38d0f2,_0x37e17e));}return _0x2ef5b4['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x46e125=this;return _0x46e125['right']['isRed_']()&&!_0x46e125['left']['isRed_']()&&(_0x46e125=_0x46e125['rotateLeft_']()),_0x46e125['left']['isRed_']()&&_0x46e125['left']['left']['isRed_']()&&(_0x46e125=_0x46e125['rotateRight_']()),_0x46e125['left']['isRed_']()&&_0x46e125['right']['isRed_']()&&(_0x46e125=_0x46e125['colorFlip_']()),_0x46e125;}['moveRedLeft_'](){let _0x25cd80=this['colorFlip_']();return _0x25cd80['right']['left']['isRed_']()&&(_0x25cd80=_0x25cd80['copy'](null,null,null,null,_0x25cd80['right']['rotateRight_']()),_0x25cd80=_0x25cd80['rotateLeft_'](),_0x25cd80=_0x25cd80['colorFlip_']()),_0x25cd80;}['moveRedRight_'](){let _0xf5cf17=this['colorFlip_']();return _0xf5cf17['left']['left']['isRed_']()&&(_0xf5cf17=_0xf5cf17['rotateRight_'](),_0xf5cf17=_0xf5cf17['colorFlip_']()),_0xf5cf17;}['rotateLeft_'](){const _0x576374=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x576374,null);}['rotateRight_'](){const _0xfc5b75=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xfc5b75);}['colorFlip_'](){const _0x3e5a8c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x59d185=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3e5a8c,_0x59d185);}['checkMaxDepth_'](){const _0x361cd7=this['check_']();return Math['pow'](0x2,_0x361cd7)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2a3406=this['left']['check_']();if(_0x2a3406!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2a3406+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1348a8,_0x59c51d,_0x118df6,_0xbc63e9,_0x4d305b){return this;}['insert'](_0x255194,_0x478acb,_0x3ac20b){return new M(_0x255194,_0x478acb,null);}['remove'](_0x18366e,_0x550d57){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3c240f){return!0x1;}['reverseTraversal'](_0xdb2b4a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1e0cae,_0x49fe33=B['EMPTY_NODE']){this['comparator_']=_0x1e0cae,this['root_']=_0x49fe33;}['insert'](_0x1e4c68,_0x65a862){return new B(this['comparator_'],this['root_']['insert'](_0x1e4c68,_0x65a862,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5d7580){return new B(this['comparator_'],this['root_']['remove'](_0x5d7580,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x577b9f){let _0x100f72,_0x145a93=this['root_'];for(;!_0x145a93['isEmpty']();){if(_0x100f72=this['comparator_'](_0x577b9f,_0x145a93['key']),_0x100f72===0x0)return _0x145a93['value'];_0x100f72<0x0?_0x145a93=_0x145a93['left']:_0x100f72>0x0&&(_0x145a93=_0x145a93['right']);}return null;}['getPredecessorKey'](_0x234cf1){let _0x2ede1e,_0x4c161b=this['root_'],_0x519f29=null;for(;!_0x4c161b['isEmpty']();)if(_0x2ede1e=this['comparator_'](_0x234cf1,_0x4c161b['key']),_0x2ede1e===0x0){if(_0x4c161b['left']['isEmpty']())return _0x519f29?_0x519f29['key']:null;for(_0x4c161b=_0x4c161b['left'];!_0x4c161b['right']['isEmpty']();)_0x4c161b=_0x4c161b['right'];return _0x4c161b['key'];}else _0x2ede1e<0x0?_0x4c161b=_0x4c161b['left']:_0x2ede1e>0x0&&(_0x519f29=_0x4c161b,_0x4c161b=_0x4c161b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x23289d){return this['root_']['inorderTraversal'](_0x23289d);}['reverseTraversal'](_0x569aa0){return this['root_']['reverseTraversal'](_0x569aa0);}['getIterator'](_0x1d6365){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x1d6365);}['getIteratorFrom'](_0x4a8604,_0x221b06){return new rn(this['root_'],_0x4a8604,this['comparator_'],!0x1,_0x221b06);}['getReverseIteratorFrom'](_0x34d142,_0x1b8536){return new rn(this['root_'],_0x34d142,this['comparator_'],!0x0,_0x1b8536);}['getReverseIterator'](_0x8930fd){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x8930fd);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2313f0,_0x4b78f0){return qe(_0x2313f0['name'],_0x4b78f0['name']);}function Qi(_0x2588d7,_0x42e7c1){return qe(_0x2588d7,_0x42e7c1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4107d1){Ci=_0x4107d1;}const Po=function(_0x51659b){return typeof _0x51659b=='number'?'number:'+ao(_0x51659b):'string:'+_0x51659b;},No=function(_0x51710a){if(_0x51710a['isLeafNode']()){const _0x315ad0=_0x51710a['val']();f(typeof _0x315ad0=='string'||typeof _0x315ad0=='number'||typeof _0x315ad0=='object'&&Q(_0x315ad0,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x51710a===Ci||_0x51710a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x51710a===Ci||_0x51710a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1fcf5b){nr=_0x1fcf5b;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x2918dc,_0x2faf0c=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2918dc,this['priorityNode_']=_0x2faf0c,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xa3d362){return new D(this['value_'],_0xa3d362);}['getImmediateChild'](_0xdc3547){return _0xdc3547==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x15c835){return v(_0x15c835)?this:y(_0x15c835)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x165863,_0x5186c6){return null;}['updateImmediateChild'](_0xa7f1c6,_0x2136a0){return _0xa7f1c6==='.priority'?this['updatePriority'](_0x2136a0):_0x2136a0['isEmpty']()&&_0xa7f1c6!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xa7f1c6,_0x2136a0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x48dbb2,_0x17308a){const _0x366bd7=y(_0x48dbb2);return _0x366bd7===null?_0x17308a:_0x17308a['isEmpty']()&&_0x366bd7!=='.priority'?this:(f(_0x366bd7!=='.priority'||Ce(_0x48dbb2)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x366bd7,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x48dbb2),_0x17308a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1eb7eb,_0x37c390){return!0x1;}['val'](_0x11c51a){return _0x11c51a&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x45720e='';this['priorityNode_']['isEmpty']()||(_0x45720e+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x58a1ce=typeof this['value_'];_0x45720e+=_0x58a1ce+':',_0x58a1ce==='number'?_0x45720e+=ao(this['value_']):_0x45720e+=this['value_'],this['lazyHash_']=ro(_0x45720e);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x47c298){return _0x47c298===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x47c298 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x47c298['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x47c298));}['compareToLeafNode_'](_0x5a54c8){const _0x98c0e6=typeof _0x5a54c8['value_'],_0x4ab8da=typeof this['value_'],_0x2612df=D['VALUE_TYPE_ORDER']['indexOf'](_0x98c0e6),_0x3ea37b=D['VALUE_TYPE_ORDER']['indexOf'](_0x4ab8da);return f(_0x2612df>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x98c0e6),f(_0x3ea37b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4ab8da),_0x2612df===_0x3ea37b?_0x4ab8da==='object'?0x0:this['value_']<_0x5a54c8['value_']?-0x1:this['value_']===_0x5a54c8['value_']?0x0:0x1:_0x3ea37b-_0x2612df;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4d8edd){if(_0x4d8edd===this)return!0x0;if(_0x4d8edd['isLeafNode']()){const _0x23c883=_0x4d8edd;return this['value_']===_0x23c883['value_']&&this['priorityNode_']['equals'](_0x23c883['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x28859d){Oo=_0x28859d;}function Wh(_0x2f1e5a){Do=_0x2f1e5a;}class Bh extends Fn{['compare'](_0x285937,_0x26d2c9){const _0xd52da3=_0x285937['node']['getPriority'](),_0x3113d1=_0x26d2c9['node']['getPriority'](),_0x3a1cd8=_0xd52da3['compareTo'](_0x3113d1);return _0x3a1cd8===0x0?qe(_0x285937['name'],_0x26d2c9['name']):_0x3a1cd8;}['isDefinedOn'](_0x1e308c){return!_0x1e308c['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xe1b31e,_0x1219ad){return!_0xe1b31e['getPriority']()['equals'](_0x1219ad['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x95a7de,_0x5c3f16){const _0x26f4d4=Oo(_0x95a7de);return new E(_0x5c3f16,new D('[PRIORITY-POST]',_0x26f4d4));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x11cbad){const _0x45aad3=_0x3587eb=>parseInt(Math['log'](_0x3587eb)/Vh,0xa),_0x3c29b6=_0x3f7bd8=>parseInt(Array(_0x3f7bd8+0x1)['join']('1'),0x2);this['count']=_0x45aad3(_0x11cbad+0x1),this['current_']=this['count']-0x1;const _0x589b9e=_0x3c29b6(this['count']);this['bits_']=_0x11cbad+0x1&_0x589b9e;}['nextBitIsOne'](){const _0x3289ac=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3289ac;}}const yn=function(_0x3f04f2,_0x5a4208,_0x28bee4,_0x4b32b2){_0x3f04f2['sort'](_0x5a4208);const _0x4d8175=function(_0x2b09d1,_0x361567){const _0x30eb69=_0x361567-_0x2b09d1;let _0x5b482f,_0x10ecbc;if(_0x30eb69===0x0)return null;if(_0x30eb69===0x1)return _0x5b482f=_0x3f04f2[_0x2b09d1],_0x10ecbc=_0x28bee4?_0x28bee4(_0x5b482f):_0x5b482f,new M(_0x10ecbc,_0x5b482f['node'],M['BLACK'],null,null);{const _0x3de4a0=parseInt(_0x30eb69/0x2,0xa)+_0x2b09d1,_0x4efa3c=_0x4d8175(_0x2b09d1,_0x3de4a0),_0x29d676=_0x4d8175(_0x3de4a0+0x1,_0x361567);return _0x5b482f=_0x3f04f2[_0x3de4a0],_0x10ecbc=_0x28bee4?_0x28bee4(_0x5b482f):_0x5b482f,new M(_0x10ecbc,_0x5b482f['node'],M['BLACK'],_0x4efa3c,_0x29d676);}},_0x4cf0bf=function(_0x1820f6){let _0x4d9e1b=null,_0x4c1e08=null,_0x49ea05=_0x3f04f2['length'];const _0x46996c=function(_0x219c4,_0x763d53){const _0xb60165=_0x49ea05-_0x219c4,_0x42c154=_0x49ea05;_0x49ea05-=_0x219c4;const _0x160381=_0x4d8175(_0xb60165+0x1,_0x42c154),_0x378cc0=_0x3f04f2[_0xb60165],_0x15fa9f=_0x28bee4?_0x28bee4(_0x378cc0):_0x378cc0;_0x43e7fc(new M(_0x15fa9f,_0x378cc0['node'],_0x763d53,null,_0x160381));},_0x43e7fc=function(_0x13591e){_0x4d9e1b?(_0x4d9e1b['left']=_0x13591e,_0x4d9e1b=_0x13591e):(_0x4c1e08=_0x13591e,_0x4d9e1b=_0x13591e);};for(let _0x591680=0x0;_0x591680<_0x1820f6['count'];++_0x591680){const _0x517840=_0x1820f6['nextBitIsOne'](),_0x4f67d0=Math['pow'](0x2,_0x1820f6['count']-(_0x591680+0x1));_0x517840?_0x46996c(_0x4f67d0,M['BLACK']):(_0x46996c(_0x4f67d0,M['BLACK']),_0x46996c(_0x4f67d0,M['RED']));}return _0x4c1e08;},_0x9dec40=new Hh(_0x3f04f2['length']),_0x2abb18=_0x4cf0bf(_0x9dec40);return new B(_0x4b32b2||_0x5a4208,_0x2abb18);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x16928c,_0x39e078){this['indexes_']=_0x16928c,this['indexSet_']=_0x39e078;}['get'](_0x2a3d8b){const _0x253783=Le(this['indexes_'],_0x2a3d8b);if(!_0x253783)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2a3d8b);return _0x253783 instanceof B?_0x253783:null;}['hasIndex'](_0x4b6b20){return Q(this['indexSet_'],_0x4b6b20['toString']());}['addIndex'](_0x5e9e6c,_0x1a5d08){f(_0x5e9e6c!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4c42af=[];let _0x4ba468=!0x1;const _0x5967fd=_0x1a5d08['getIterator'](E['Wrap']);let _0x43a435=_0x5967fd['getNext']();for(;_0x43a435;)_0x4ba468=_0x4ba468||_0x5e9e6c['isDefinedOn'](_0x43a435['node']),_0x4c42af['push'](_0x43a435),_0x43a435=_0x5967fd['getNext']();let _0x59f0f9;_0x4ba468?_0x59f0f9=yn(_0x4c42af,_0x5e9e6c['getCompare']()):_0x59f0f9=Qe;const _0x1b4861=_0x5e9e6c['toString'](),_0x193042={...this['indexSet_']};_0x193042[_0x1b4861]=_0x5e9e6c;const _0x2d0333={...this['indexes_']};return _0x2d0333[_0x1b4861]=_0x59f0f9,new te(_0x2d0333,_0x193042);}['addToIndexes'](_0x3a5ba6,_0x1638d9){const _0x5d5b95=_n(this['indexes_'],(_0x22d266,_0x140485)=>{const _0x9e7432=Le(this['indexSet_'],_0x140485);if(f(_0x9e7432,'Missing\x20index\x20implementation\x20for\x20'+_0x140485),_0x22d266===Qe){if(_0x9e7432['isDefinedOn'](_0x3a5ba6['node'])){const _0x2142ea=[],_0x4f55e5=_0x1638d9['getIterator'](E['Wrap']);let _0x2415d6=_0x4f55e5['getNext']();for(;_0x2415d6;)_0x2415d6['name']!==_0x3a5ba6['name']&&_0x2142ea['push'](_0x2415d6),_0x2415d6=_0x4f55e5['getNext']();return _0x2142ea['push'](_0x3a5ba6),yn(_0x2142ea,_0x9e7432['getCompare']());}else return Qe;}else{const _0x5cff65=_0x1638d9['get'](_0x3a5ba6['name']);let _0x1b683b=_0x22d266;return _0x5cff65&&(_0x1b683b=_0x1b683b['remove'](new E(_0x3a5ba6['name'],_0x5cff65))),_0x1b683b['insert'](_0x3a5ba6,_0x3a5ba6['node']);}});return new te(_0x5d5b95,this['indexSet_']);}['removeFromIndexes'](_0x624b7b,_0x77ca79){const _0x506c46=_n(this['indexes_'],_0x2ea191=>{if(_0x2ea191===Qe)return _0x2ea191;{const _0x4b9aa3=_0x77ca79['get'](_0x624b7b['name']);return _0x4b9aa3?_0x2ea191['remove'](new E(_0x624b7b['name'],_0x4b9aa3)):_0x2ea191;}});return new te(_0x506c46,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0xfd0f5a,_0x405947,_0x2fbbcb){this['children_']=_0xfd0f5a,this['priorityNode_']=_0x405947,this['indexMap_']=_0x2fbbcb,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x46b958){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x46b958,this['indexMap_']);}['getImmediateChild'](_0x20a27c){if(_0x20a27c==='.priority')return this['getPriority']();{const _0x9f5537=this['children_']['get'](_0x20a27c);return _0x9f5537===null?It:_0x9f5537;}}['getChild'](_0x5adf66){const _0xa7809=y(_0x5adf66);return _0xa7809===null?this:this['getImmediateChild'](_0xa7809)['getChild'](S(_0x5adf66));}['hasChild'](_0x453abe){return this['children_']['get'](_0x453abe)!==null;}['updateImmediateChild'](_0x479975,_0x3e330b){if(f(_0x3e330b,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x479975==='.priority')return this['updatePriority'](_0x3e330b);{const _0x2cfd58=new E(_0x479975,_0x3e330b);let _0x5d54cc,_0x2658cf;_0x3e330b['isEmpty']()?(_0x5d54cc=this['children_']['remove'](_0x479975),_0x2658cf=this['indexMap_']['removeFromIndexes'](_0x2cfd58,this['children_'])):(_0x5d54cc=this['children_']['insert'](_0x479975,_0x3e330b),_0x2658cf=this['indexMap_']['addToIndexes'](_0x2cfd58,this['children_']));const _0x7d04fa=_0x5d54cc['isEmpty']()?It:this['priorityNode_'];return new g(_0x5d54cc,_0x7d04fa,_0x2658cf);}}['updateChild'](_0x32d28b,_0x72849f){const _0x2a18a9=y(_0x32d28b);if(_0x2a18a9===null)return _0x72849f;{f(y(_0x32d28b)!=='.priority'||Ce(_0x32d28b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5e8fdd=this['getImmediateChild'](_0x2a18a9)['updateChild'](S(_0x32d28b),_0x72849f);return this['updateImmediateChild'](_0x2a18a9,_0x5e8fdd);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x7a2759){if(this['isEmpty']())return null;const _0x334800={};let _0x3eca46=0x0,_0x567381=0x0,_0xd0e96d=!0x0;if(this['forEachChild'](R,(_0xff57f6,_0x4cd4c0)=>{_0x334800[_0xff57f6]=_0x4cd4c0['val'](_0x7a2759),_0x3eca46++,_0xd0e96d&&g['INTEGER_REGEXP_']['test'](_0xff57f6)?_0x567381=Math['max'](_0x567381,Number(_0xff57f6)):_0xd0e96d=!0x1;}),!_0x7a2759&&_0xd0e96d&&_0x567381<0x2*_0x3eca46){const _0xce122f=[];for(const _0x50dde8 in _0x334800)_0xce122f[_0x50dde8]=_0x334800[_0x50dde8];return _0xce122f;}else return _0x7a2759&&!this['getPriority']()['isEmpty']()&&(_0x334800['.priority']=this['getPriority']()['val']()),_0x334800;}['hash'](){if(this['lazyHash_']===null){let _0xf7f193='';this['getPriority']()['isEmpty']()||(_0xf7f193+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x552e73,_0x2465cb)=>{const _0x3f88ee=_0x2465cb['hash']();_0x3f88ee!==''&&(_0xf7f193+=':'+_0x552e73+':'+_0x3f88ee);}),this['lazyHash_']=_0xf7f193===''?'':ro(_0xf7f193);}return this['lazyHash_'];}['getPredecessorChildName'](_0x52d33c,_0x2138cd,_0x3a4e82){const _0x2cc455=this['resolveIndex_'](_0x3a4e82);if(_0x2cc455){const _0x208c8d=_0x2cc455['getPredecessorKey'](new E(_0x52d33c,_0x2138cd));return _0x208c8d?_0x208c8d['name']:null;}else return this['children_']['getPredecessorKey'](_0x52d33c);}['getFirstChildName'](_0x25fa30){const _0x39a571=this['resolveIndex_'](_0x25fa30);if(_0x39a571){const _0xe55d81=_0x39a571['minKey']();return _0xe55d81&&_0xe55d81['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x280508){const _0x533b60=this['getFirstChildName'](_0x280508);return _0x533b60?new E(_0x533b60,this['children_']['get'](_0x533b60)):null;}['getLastChildName'](_0x4bc8fc){const _0x587593=this['resolveIndex_'](_0x4bc8fc);if(_0x587593){const _0x546864=_0x587593['maxKey']();return _0x546864&&_0x546864['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x592344){const _0x5250ff=this['getLastChildName'](_0x592344);return _0x5250ff?new E(_0x5250ff,this['children_']['get'](_0x5250ff)):null;}['forEachChild'](_0x408dab,_0x2d6597){const _0x1700e2=this['resolveIndex_'](_0x408dab);return _0x1700e2?_0x1700e2['inorderTraversal'](_0x3e78f7=>_0x2d6597(_0x3e78f7['name'],_0x3e78f7['node'])):this['children_']['inorderTraversal'](_0x2d6597);}['getIterator'](_0x209b9d){return this['getIteratorFrom'](_0x209b9d['minPost'](),_0x209b9d);}['getIteratorFrom'](_0x3bd21d,_0x3952fd){const _0x1e7dfc=this['resolveIndex_'](_0x3952fd);if(_0x1e7dfc)return _0x1e7dfc['getIteratorFrom'](_0x3bd21d,_0x184288=>_0x184288);{const _0x573f30=this['children_']['getIteratorFrom'](_0x3bd21d['name'],E['Wrap']);let _0x310291=_0x573f30['peek']();for(;_0x310291!=null&&_0x3952fd['compare'](_0x310291,_0x3bd21d)<0x0;)_0x573f30['getNext'](),_0x310291=_0x573f30['peek']();return _0x573f30;}}['getReverseIterator'](_0x1e55a8){return this['getReverseIteratorFrom'](_0x1e55a8['maxPost'](),_0x1e55a8);}['getReverseIteratorFrom'](_0x33727f,_0x5f2ef9){const _0x503bfc=this['resolveIndex_'](_0x5f2ef9);if(_0x503bfc)return _0x503bfc['getReverseIteratorFrom'](_0x33727f,_0x307187=>_0x307187);{const _0x3971ef=this['children_']['getReverseIteratorFrom'](_0x33727f['name'],E['Wrap']);let _0x506412=_0x3971ef['peek']();for(;_0x506412!=null&&_0x5f2ef9['compare'](_0x506412,_0x33727f)>0x0;)_0x3971ef['getNext'](),_0x506412=_0x3971ef['peek']();return _0x3971ef;}}['compareTo'](_0x1d99fd){return this['isEmpty']()?_0x1d99fd['isEmpty']()?0x0:-0x1:_0x1d99fd['isLeafNode']()||_0x1d99fd['isEmpty']()?0x1:_0x1d99fd===Kt?-0x1:0x0;}['withIndex'](_0x38f002){if(_0x38f002===ve||this['indexMap_']['hasIndex'](_0x38f002))return this;{const _0x517edb=this['indexMap_']['addIndex'](_0x38f002,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x517edb);}}['isIndexed'](_0x31bcdd){return _0x31bcdd===ve||this['indexMap_']['hasIndex'](_0x31bcdd);}['equals'](_0x2d796a){if(_0x2d796a===this)return!0x0;if(_0x2d796a['isLeafNode']())return!0x1;{const _0x305f4c=_0x2d796a;if(this['getPriority']()['equals'](_0x305f4c['getPriority']())){if(this['children_']['count']()===_0x305f4c['children_']['count']()){const _0x14eea1=this['getIterator'](R),_0x56fdb8=_0x305f4c['getIterator'](R);let _0x834ead=_0x14eea1['getNext'](),_0x47c48c=_0x56fdb8['getNext']();for(;_0x834ead&&_0x47c48c;){if(_0x834ead['name']!==_0x47c48c['name']||!_0x834ead['node']['equals'](_0x47c48c['node']))return!0x1;_0x834ead=_0x14eea1['getNext'](),_0x47c48c=_0x56fdb8['getNext']();}return _0x834ead===null&&_0x47c48c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x423e01){return _0x423e01===ve?null:this['indexMap_']['get'](_0x423e01['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x9c0ebf){return _0x9c0ebf===this?0x0:0x1;}['equals'](_0x49817c){return _0x49817c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x16bac3){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x2db209,_0x2a29df=null){if(_0x2db209===null)return g['EMPTY_NODE'];if(typeof _0x2db209=='object'&&'.priority'in _0x2db209&&(_0x2a29df=_0x2db209['.priority']),f(_0x2a29df===null||typeof _0x2a29df=='string'||typeof _0x2a29df=='number'||typeof _0x2a29df=='object'&&'.sv'in _0x2a29df,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2a29df),typeof _0x2db209=='object'&&'.value'in _0x2db209&&_0x2db209['.value']!==null&&(_0x2db209=_0x2db209['.value']),typeof _0x2db209!='object'||'.sv'in _0x2db209){const _0x17d30d=_0x2db209;return new D(_0x17d30d,A(_0x2a29df));}if(!(_0x2db209 instanceof Array)&&Gh){const _0x3f31a1=[];let _0x5a00cf=!0x1;if(x(_0x2db209,(_0x2519b5,_0x3c6d05)=>{if(_0x2519b5['substring'](0x0,0x1)!=='.'){const _0x42d278=A(_0x3c6d05);_0x42d278['isEmpty']()||(_0x5a00cf=_0x5a00cf||!_0x42d278['getPriority']()['isEmpty'](),_0x3f31a1['push'](new E(_0x2519b5,_0x42d278)));}}),_0x3f31a1['length']===0x0)return g['EMPTY_NODE'];const _0x52afe7=yn(_0x3f31a1,xh,_0x51a994=>_0x51a994['name'],Qi);if(_0x5a00cf){const _0x57b2e1=yn(_0x3f31a1,R['getCompare']());return new g(_0x52afe7,A(_0x2a29df),new te({'.priority':_0x57b2e1},{'.priority':R}));}else return new g(_0x52afe7,A(_0x2a29df),te['Default']);}else{let _0x465fb4=g['EMPTY_NODE'];return x(_0x2db209,(_0x46cefd,_0x107bdc)=>{if(Q(_0x2db209,_0x46cefd)&&_0x46cefd['substring'](0x0,0x1)!=='.'){const _0x146a83=A(_0x107bdc);(_0x146a83['isLeafNode']()||!_0x146a83['isEmpty']())&&(_0x465fb4=_0x465fb4['updateImmediateChild'](_0x46cefd,_0x146a83));}}),_0x465fb4['updatePriority'](A(_0x2a29df));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x47efad){super(),this['indexPath_']=_0x47efad,f(!v(_0x47efad)&&y(_0x47efad)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x52ad43){return _0x52ad43['getChild'](this['indexPath_']);}['isDefinedOn'](_0x54f5ce){return!_0x54f5ce['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x462b71,_0x545e65){const _0x328236=this['extractChild'](_0x462b71['node']),_0x14cf11=this['extractChild'](_0x545e65['node']),_0x65c98a=_0x328236['compareTo'](_0x14cf11);return _0x65c98a===0x0?qe(_0x462b71['name'],_0x545e65['name']):_0x65c98a;}['makePost'](_0xa4313,_0x25f058){const _0x2aee4a=A(_0xa4313),_0x4ba7af=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2aee4a);return new E(_0x25f058,_0x4ba7af);}['maxPost'](){const _0x3c9be1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x3c9be1);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x58928a,_0x153873){const _0x385dcd=_0x58928a['node']['compareTo'](_0x153873['node']);return _0x385dcd===0x0?qe(_0x58928a['name'],_0x153873['name']):_0x385dcd;}['isDefinedOn'](_0x23d428){return!0x0;}['indexedValueChanged'](_0x4806b0,_0x553619){return!_0x4806b0['equals'](_0x553619);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x32065a,_0x3144f9){const _0x42ce78=A(_0x32065a);return new E(_0x3144f9,_0x42ce78);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x44a5ac){return{'type':'value','snapshotNode':_0x44a5ac};}function rt(_0x4d08f6,_0x1ce995){return{'type':'child_added','snapshotNode':_0x1ce995,'childName':_0x4d08f6};}function Lt(_0x529c01,_0x30886f){return{'type':'child_removed','snapshotNode':_0x30886f,'childName':_0x529c01};}function xt(_0x4ee1ee,_0x2b16fe,_0x3c5539){return{'type':'child_changed','snapshotNode':_0x2b16fe,'childName':_0x4ee1ee,'oldSnap':_0x3c5539};}function zh(_0x384325,_0x215a7e){return{'type':'child_moved','snapshotNode':_0x215a7e,'childName':_0x384325};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x525e4c){this['index_']=_0x525e4c;}['updateChild'](_0x5227fd,_0x1bf742,_0x122bf7,_0x433df0,_0x4f94ab,_0x1fe933){f(_0x5227fd['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3db5c9=_0x5227fd['getImmediateChild'](_0x1bf742);return _0x3db5c9['getChild'](_0x433df0)['equals'](_0x122bf7['getChild'](_0x433df0))&&_0x3db5c9['isEmpty']()===_0x122bf7['isEmpty']()||(_0x1fe933!=null&&(_0x122bf7['isEmpty']()?_0x5227fd['hasChild'](_0x1bf742)?_0x1fe933['trackChildChange'](Lt(_0x1bf742,_0x3db5c9)):f(_0x5227fd['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3db5c9['isEmpty']()?_0x1fe933['trackChildChange'](rt(_0x1bf742,_0x122bf7)):_0x1fe933['trackChildChange'](xt(_0x1bf742,_0x122bf7,_0x3db5c9))),_0x5227fd['isLeafNode']()&&_0x122bf7['isEmpty']())?_0x5227fd:_0x5227fd['updateImmediateChild'](_0x1bf742,_0x122bf7)['withIndex'](this['index_']);}['updateFullNode'](_0x2f7319,_0x10ac08,_0x272d57){return _0x272d57!=null&&(_0x2f7319['isLeafNode']()||_0x2f7319['forEachChild'](R,(_0x2c88b3,_0x270fcc)=>{_0x10ac08['hasChild'](_0x2c88b3)||_0x272d57['trackChildChange'](Lt(_0x2c88b3,_0x270fcc));}),_0x10ac08['isLeafNode']()||_0x10ac08['forEachChild'](R,(_0x3c96d2,_0x400b40)=>{if(_0x2f7319['hasChild'](_0x3c96d2)){const _0x2270fc=_0x2f7319['getImmediateChild'](_0x3c96d2);_0x2270fc['equals'](_0x400b40)||_0x272d57['trackChildChange'](xt(_0x3c96d2,_0x400b40,_0x2270fc));}else _0x272d57['trackChildChange'](rt(_0x3c96d2,_0x400b40));})),_0x10ac08['withIndex'](this['index_']);}['updatePriority'](_0x358222,_0x315e0e){return _0x358222['isEmpty']()?g['EMPTY_NODE']:_0x358222['updatePriority'](_0x315e0e);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0xd52000){this['indexedFilter_']=new Xi(_0xd52000['getIndex']()),this['index_']=_0xd52000['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0xd52000),this['endPost_']=Ft['getEndPost_'](_0xd52000),this['startIsInclusive_']=!_0xd52000['startAfterSet_'],this['endIsInclusive_']=!_0xd52000['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x83cb39){const _0x5222a7=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x83cb39)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x83cb39)<0x0,_0x57ec91=this['endIsInclusive_']?this['index_']['compare'](_0x83cb39,this['getEndPost']())<=0x0:this['index_']['compare'](_0x83cb39,this['getEndPost']())<0x0;return _0x5222a7&&_0x57ec91;}['updateChild'](_0x55315d,_0x51724c,_0x51a614,_0x3edbd3,_0x38d986,_0x220e65){return this['matches'](new E(_0x51724c,_0x51a614))||(_0x51a614=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x55315d,_0x51724c,_0x51a614,_0x3edbd3,_0x38d986,_0x220e65);}['updateFullNode'](_0x1f8955,_0x57926d,_0x5d8ac1){_0x57926d['isLeafNode']()&&(_0x57926d=g['EMPTY_NODE']);let _0x48fd0f=_0x57926d['withIndex'](this['index_']);_0x48fd0f=_0x48fd0f['updatePriority'](g['EMPTY_NODE']);const _0x5b55f7=this;return _0x57926d['forEachChild'](R,(_0x3a97aa,_0x3f5621)=>{_0x5b55f7['matches'](new E(_0x3a97aa,_0x3f5621))||(_0x48fd0f=_0x48fd0f['updateImmediateChild'](_0x3a97aa,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1f8955,_0x48fd0f,_0x5d8ac1);}['updatePriority'](_0x1af841,_0x33c7a1){return _0x1af841;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x315359){if(_0x315359['hasStart']()){const _0x4f76f2=_0x315359['getIndexStartName']();return _0x315359['getIndex']()['makePost'](_0x315359['getIndexStartValue'](),_0x4f76f2);}else return _0x315359['getIndex']()['minPost']();}static['getEndPost_'](_0x2b75c8){if(_0x2b75c8['hasEnd']()){const _0x24b1bc=_0x2b75c8['getIndexEndName']();return _0x2b75c8['getIndex']()['makePost'](_0x2b75c8['getIndexEndValue'](),_0x24b1bc);}else return _0x2b75c8['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1984e8){this['withinDirectionalStart']=_0x18e3e0=>this['reverse_']?this['withinEndPost'](_0x18e3e0):this['withinStartPost'](_0x18e3e0),this['withinDirectionalEnd']=_0x506be5=>this['reverse_']?this['withinStartPost'](_0x506be5):this['withinEndPost'](_0x506be5),this['withinStartPost']=_0x522ef7=>{const _0x139783=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x522ef7);return this['startIsInclusive_']?_0x139783<=0x0:_0x139783<0x0;},this['withinEndPost']=_0x1252d8=>{const _0x280aa8=this['index_']['compare'](_0x1252d8,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x280aa8<=0x0:_0x280aa8<0x0;},this['rangedFilter_']=new Ft(_0x1984e8),this['index_']=_0x1984e8['getIndex'](),this['limit_']=_0x1984e8['getLimit'](),this['reverse_']=!_0x1984e8['isViewFromLeft'](),this['startIsInclusive_']=!_0x1984e8['startAfterSet_'],this['endIsInclusive_']=!_0x1984e8['endBeforeSet_'];}['updateChild'](_0x2bd75d,_0x3f889b,_0x4cf24c,_0x348294,_0x3a2534,_0x4c99a9){return this['rangedFilter_']['matches'](new E(_0x3f889b,_0x4cf24c))||(_0x4cf24c=g['EMPTY_NODE']),_0x2bd75d['getImmediateChild'](_0x3f889b)['equals'](_0x4cf24c)?_0x2bd75d:_0x2bd75d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2bd75d,_0x3f889b,_0x4cf24c,_0x348294,_0x3a2534,_0x4c99a9):this['fullLimitUpdateChild_'](_0x2bd75d,_0x3f889b,_0x4cf24c,_0x3a2534,_0x4c99a9);}['updateFullNode'](_0x39ff3f,_0x2ff896,_0xa63019){let _0x678b28;if(_0x2ff896['isLeafNode']()||_0x2ff896['isEmpty']())_0x678b28=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2ff896['numChildren']()&&_0x2ff896['isIndexed'](this['index_'])){_0x678b28=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xb878e2;this['reverse_']?_0xb878e2=_0x2ff896['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xb878e2=_0x2ff896['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x37441e=0x0;for(;_0xb878e2['hasNext']()&&_0x37441e<this['limit_'];){const _0xa70087=_0xb878e2['getNext']();if(this['withinDirectionalStart'](_0xa70087)){if(this['withinDirectionalEnd'](_0xa70087))_0x678b28=_0x678b28['updateImmediateChild'](_0xa70087['name'],_0xa70087['node']),_0x37441e++;else break;}else continue;}}else{_0x678b28=_0x2ff896['withIndex'](this['index_']),_0x678b28=_0x678b28['updatePriority'](g['EMPTY_NODE']);let _0x526a1a;this['reverse_']?_0x526a1a=_0x678b28['getReverseIterator'](this['index_']):_0x526a1a=_0x678b28['getIterator'](this['index_']);let _0x4e0a43=0x0;for(;_0x526a1a['hasNext']();){const _0x56927b=_0x526a1a['getNext']();_0x4e0a43<this['limit_']&&this['withinDirectionalStart'](_0x56927b)&&this['withinDirectionalEnd'](_0x56927b)?_0x4e0a43++:_0x678b28=_0x678b28['updateImmediateChild'](_0x56927b['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x39ff3f,_0x678b28,_0xa63019);}['updatePriority'](_0x482ea6,_0x1b7a61){return _0x482ea6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x498551,_0x243ca6,_0x4b2cda,_0x520ebe,_0x1c8f85){let _0x252d95;if(this['reverse_']){const _0x290220=this['index_']['getCompare']();_0x252d95=(_0x201ec8,_0x108610)=>_0x290220(_0x108610,_0x201ec8);}else _0x252d95=this['index_']['getCompare']();const _0x21005e=_0x498551;f(_0x21005e['numChildren']()===this['limit_'],'');const _0x3ca70d=new E(_0x243ca6,_0x4b2cda),_0x45ced7=this['reverse_']?_0x21005e['getFirstChild'](this['index_']):_0x21005e['getLastChild'](this['index_']),_0x1dd8a4=this['rangedFilter_']['matches'](_0x3ca70d);if(_0x21005e['hasChild'](_0x243ca6)){const _0xa40495=_0x21005e['getImmediateChild'](_0x243ca6);let _0x4a2191=_0x520ebe['getChildAfterChild'](this['index_'],_0x45ced7,this['reverse_']);for(;_0x4a2191!=null&&(_0x4a2191['name']===_0x243ca6||_0x21005e['hasChild'](_0x4a2191['name']));)_0x4a2191=_0x520ebe['getChildAfterChild'](this['index_'],_0x4a2191,this['reverse_']);const _0x44faf2=_0x4a2191==null?0x1:_0x252d95(_0x4a2191,_0x3ca70d);if(_0x1dd8a4&&!_0x4b2cda['isEmpty']()&&_0x44faf2>=0x0)return _0x1c8f85!=null&&_0x1c8f85['trackChildChange'](xt(_0x243ca6,_0x4b2cda,_0xa40495)),_0x21005e['updateImmediateChild'](_0x243ca6,_0x4b2cda);{_0x1c8f85!=null&&_0x1c8f85['trackChildChange'](Lt(_0x243ca6,_0xa40495));const _0x2bb7fb=_0x21005e['updateImmediateChild'](_0x243ca6,g['EMPTY_NODE']);return _0x4a2191!=null&&this['rangedFilter_']['matches'](_0x4a2191)?(_0x1c8f85!=null&&_0x1c8f85['trackChildChange'](rt(_0x4a2191['name'],_0x4a2191['node'])),_0x2bb7fb['updateImmediateChild'](_0x4a2191['name'],_0x4a2191['node'])):_0x2bb7fb;}}else return _0x4b2cda['isEmpty']()?_0x498551:_0x1dd8a4&&_0x252d95(_0x45ced7,_0x3ca70d)>=0x0?(_0x1c8f85!=null&&(_0x1c8f85['trackChildChange'](Lt(_0x45ced7['name'],_0x45ced7['node'])),_0x1c8f85['trackChildChange'](rt(_0x243ca6,_0x4b2cda))),_0x21005e['updateImmediateChild'](_0x243ca6,_0x4b2cda)['updateImmediateChild'](_0x45ced7['name'],g['EMPTY_NODE'])):_0x498551;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3b48f6=new Zi();return _0x3b48f6['limitSet_']=this['limitSet_'],_0x3b48f6['limit_']=this['limit_'],_0x3b48f6['startSet_']=this['startSet_'],_0x3b48f6['startAfterSet_']=this['startAfterSet_'],_0x3b48f6['indexStartValue_']=this['indexStartValue_'],_0x3b48f6['startNameSet_']=this['startNameSet_'],_0x3b48f6['indexStartName_']=this['indexStartName_'],_0x3b48f6['endSet_']=this['endSet_'],_0x3b48f6['endBeforeSet_']=this['endBeforeSet_'],_0x3b48f6['indexEndValue_']=this['indexEndValue_'],_0x3b48f6['endNameSet_']=this['endNameSet_'],_0x3b48f6['indexEndName_']=this['indexEndName_'],_0x3b48f6['index_']=this['index_'],_0x3b48f6['viewFrom_']=this['viewFrom_'],_0x3b48f6;}}function Kh(_0x5c3792){return _0x5c3792['loadsAllData']()?new Xi(_0x5c3792['getIndex']()):_0x5c3792['hasLimit']()?new jh(_0x5c3792):new Ft(_0x5c3792);}function Yh(_0x45ca79,_0x451a42){const _0x4673a1=_0x45ca79['copy']();return _0x4673a1['limitSet_']=!0x0,_0x4673a1['limit_']=_0x451a42,_0x4673a1['viewFrom_']='l',_0x4673a1;}function Qh(_0x198ce6,_0x371a82,_0x5c7fa6){const _0x4785d0=_0x198ce6['copy']();return _0x4785d0['startSet_']=!0x0,_0x371a82===void 0x0&&(_0x371a82=null),_0x4785d0['indexStartValue_']=_0x371a82,_0x5c7fa6!=null?(_0x4785d0['startNameSet_']=!0x0,_0x4785d0['indexStartName_']=_0x5c7fa6):(_0x4785d0['startNameSet_']=!0x1,_0x4785d0['indexStartName_']=''),_0x4785d0;}function Jh(_0x1774eb,_0x374d0b,_0x288bc7){const _0x57255e=_0x1774eb['copy']();return _0x57255e['endSet_']=!0x0,_0x374d0b===void 0x0&&(_0x374d0b=null),_0x57255e['indexEndValue_']=_0x374d0b,_0x288bc7!==void 0x0?(_0x57255e['endNameSet_']=!0x0,_0x57255e['indexEndName_']=_0x288bc7):(_0x57255e['endNameSet_']=!0x1,_0x57255e['indexEndName_']=''),_0x57255e;}function xo(_0x1baff1,_0x23f5c4){const _0x493d97=_0x1baff1['copy']();return _0x493d97['index_']=_0x23f5c4,_0x493d97;}function ir(_0x345b06){const _0x223f00={};if(_0x345b06['isDefault']())return _0x223f00;let _0x332413;if(_0x345b06['index_']===R?_0x332413='$priority':_0x345b06['index_']===Mo?_0x332413='$value':_0x345b06['index_']===ve?_0x332413='$key':(f(_0x345b06['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x332413=_0x345b06['index_']['toString']()),_0x223f00['orderBy']=O(_0x332413),_0x345b06['startSet_']){const _0xfe67ce=_0x345b06['startAfterSet_']?'startAfter':'startAt';_0x223f00[_0xfe67ce]=O(_0x345b06['indexStartValue_']),_0x345b06['startNameSet_']&&(_0x223f00[_0xfe67ce]+=','+O(_0x345b06['indexStartName_']));}if(_0x345b06['endSet_']){const _0x570e01=_0x345b06['endBeforeSet_']?'endBefore':'endAt';_0x223f00[_0x570e01]=O(_0x345b06['indexEndValue_']),_0x345b06['endNameSet_']&&(_0x223f00[_0x570e01]+=','+O(_0x345b06['indexEndName_']));}return _0x345b06['limitSet_']&&(_0x345b06['isViewFromLeft']()?_0x223f00['limitToFirst']=_0x345b06['limit_']:_0x223f00['limitToLast']=_0x345b06['limit_']),_0x223f00;}function sr(_0x38066c){const _0x1d50fe={};if(_0x38066c['startSet_']&&(_0x1d50fe['sp']=_0x38066c['indexStartValue_'],_0x38066c['startNameSet_']&&(_0x1d50fe['sn']=_0x38066c['indexStartName_']),_0x1d50fe['sin']=!_0x38066c['startAfterSet_']),_0x38066c['endSet_']&&(_0x1d50fe['ep']=_0x38066c['indexEndValue_'],_0x38066c['endNameSet_']&&(_0x1d50fe['en']=_0x38066c['indexEndName_']),_0x1d50fe['ein']=!_0x38066c['endBeforeSet_']),_0x38066c['limitSet_']){_0x1d50fe['l']=_0x38066c['limit_'];let _0x134d23=_0x38066c['viewFrom_'];_0x134d23===''&&(_0x38066c['isViewFromLeft']()?_0x134d23='l':_0x134d23='r'),_0x1d50fe['vf']=_0x134d23;}return _0x38066c['index_']!==R&&(_0x1d50fe['i']=_0x38066c['index_']['toString']()),_0x1d50fe;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x1190dd){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x8889e5,_0x438941){return _0x438941!==void 0x0?'tag$'+_0x438941:(f(_0x8889e5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x8889e5['_path']['toString']());}constructor(_0x350172,_0x533cf3,_0xca8b1f,_0x17ce89){super(),this['repoInfo_']=_0x350172,this['onDataUpdate_']=_0x533cf3,this['authTokenProvider_']=_0xca8b1f,this['appCheckTokenProvider_']=_0x17ce89,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x261917,_0x3a11f1,_0x25af81,_0x4a1f5c){const _0x183375=_0x261917['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x183375+'\x20'+_0x261917['_queryIdentifier']);const _0x2850cd=vn['getListenId_'](_0x261917,_0x25af81),_0x524f79={};this['listens_'][_0x2850cd]=_0x524f79;const _0x43bf77=ir(_0x261917['_queryParams']);this['restRequest_'](_0x183375+'.json',_0x43bf77,(_0x28713b,_0x3967c3)=>{let _0x25f8fc=_0x3967c3;if(_0x28713b===0x194&&(_0x25f8fc=null,_0x28713b=null),_0x28713b===null&&this['onDataUpdate_'](_0x183375,_0x25f8fc,!0x1,_0x25af81),Le(this['listens_'],_0x2850cd)===_0x524f79){let _0x40ac29;_0x28713b?_0x28713b===0x191?_0x40ac29='permission_denied':_0x40ac29='rest_error:'+_0x28713b:_0x40ac29='ok',_0x4a1f5c(_0x40ac29,null);}});}['unlisten'](_0x592409,_0xabb874){const _0x3612b7=vn['getListenId_'](_0x592409,_0xabb874);delete this['listens_'][_0x3612b7];}['get'](_0x18a628){const _0x5dfda1=ir(_0x18a628['_queryParams']),_0x591f0a=_0x18a628['_path']['toString'](),_0x2300e8=new H();return this['restRequest_'](_0x591f0a+'.json',_0x5dfda1,(_0x6a0c49,_0x3d75ed)=>{let _0x20c7e3=_0x3d75ed;_0x6a0c49===0x194&&(_0x20c7e3=null,_0x6a0c49=null),_0x6a0c49===null?(this['onDataUpdate_'](_0x591f0a,_0x20c7e3,!0x1,null),_0x2300e8['resolve'](_0x20c7e3)):_0x2300e8['reject'](new Error(_0x20c7e3));}),_0x2300e8['promise'];}['refreshAuthToken'](_0x790ba2){}['restRequest_'](_0x4726ed,_0x281106={},_0x2669fd){return _0x281106['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3a229d,_0x11da14])=>{_0x3a229d&&_0x3a229d['accessToken']&&(_0x281106['auth']=_0x3a229d['accessToken']),_0x11da14&&_0x11da14['token']&&(_0x281106['ac']=_0x11da14['token']);const _0xa87e62=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4726ed+'?ns='+this['repoInfo_']['namespace']+ut(_0x281106);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xa87e62);const _0x2c4fc3=new XMLHttpRequest();_0x2c4fc3['onreadystatechange']=()=>{if(_0x2669fd&&_0x2c4fc3['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xa87e62+'\x20received.\x20status:',_0x2c4fc3['status'],'response:',_0x2c4fc3['responseText']);let _0x4f0404=null;if(_0x2c4fc3['status']>=0xc8&&_0x2c4fc3['status']<0x12c){try{_0x4f0404=Nt(_0x2c4fc3['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xa87e62+':\x20'+_0x2c4fc3['responseText']);}_0x2669fd(null,_0x4f0404);}else _0x2c4fc3['status']!==0x191&&_0x2c4fc3['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xa87e62+'\x20Status:\x20'+_0x2c4fc3['status']),_0x2669fd(_0x2c4fc3['status']);_0x2669fd=null;}},_0x2c4fc3['open']('GET',_0xa87e62,!0x0),_0x2c4fc3['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x457e14){return this['rootNode_']['getChild'](_0x457e14);}['updateSnapshot'](_0x3aa38f,_0x106940){this['rootNode_']=this['rootNode_']['updateChild'](_0x3aa38f,_0x106940);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x1209f5,_0x15d30,_0x5ee705){if(v(_0x15d30))_0x1209f5['value']=_0x5ee705,_0x1209f5['children']['clear']();else{if(_0x1209f5['value']!==null)_0x1209f5['value']=_0x1209f5['value']['updateChild'](_0x15d30,_0x5ee705);else{const _0x125d56=y(_0x15d30);_0x1209f5['children']['has'](_0x125d56)||_0x1209f5['children']['set'](_0x125d56,En());const _0x27a6d4=_0x1209f5['children']['get'](_0x125d56);_0x15d30=S(_0x15d30),pt(_0x27a6d4,_0x15d30,_0x5ee705);}}}function Ti(_0x1f3882,_0x2267c1){if(v(_0x2267c1))return _0x1f3882['value']=null,_0x1f3882['children']['clear'](),!0x0;if(_0x1f3882['value']!==null){if(_0x1f3882['value']['isLeafNode']())return!0x1;{const _0x370b09=_0x1f3882['value'];return _0x1f3882['value']=null,_0x370b09['forEachChild'](R,(_0x888729,_0x551a5e)=>{pt(_0x1f3882,new C(_0x888729),_0x551a5e);}),Ti(_0x1f3882,_0x2267c1);}}else{if(_0x1f3882['children']['size']>0x0){const _0x478eae=y(_0x2267c1);return _0x2267c1=S(_0x2267c1),_0x1f3882['children']['has'](_0x478eae)&&Ti(_0x1f3882['children']['get'](_0x478eae),_0x2267c1)&&_0x1f3882['children']['delete'](_0x478eae),_0x1f3882['children']['size']===0x0;}else return!0x0;}}function Si(_0x2522b8,_0x388c8a,_0x502ff2){_0x2522b8['value']!==null?_0x502ff2(_0x388c8a,_0x2522b8['value']):Zh(_0x2522b8,(_0x25e8ee,_0x42b19f)=>{const _0x3bb3d8=new C(_0x388c8a['toString']()+'/'+_0x25e8ee);Si(_0x42b19f,_0x3bb3d8,_0x502ff2);});}function Zh(_0x15f26b,_0x4ceede){_0x15f26b['children']['forEach']((_0x252168,_0x1a13d3)=>{_0x4ceede(_0x1a13d3,_0x252168);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4d937a){this['collection_']=_0x4d937a,this['last_']=null;}['get'](){const _0xb6e26=this['collection_']['get'](),_0x59b25e={..._0xb6e26};return this['last_']&&x(this['last_'],(_0x2cf8bf,_0x538aa5)=>{_0x59b25e[_0x2cf8bf]=_0x59b25e[_0x2cf8bf]-_0x538aa5;}),this['last_']=_0xb6e26,_0x59b25e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x144a90,_0x4205bf){this['server_']=_0x4205bf,this['statsToReport_']={},this['statsListener_']=new eu(_0x144a90);const _0x3b6c87=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3b6c87));}['reportStats_'](){const _0x553065=this['statsListener_']['get'](),_0xfaab93={};let _0xe5a7d4=!0x1;x(_0x553065,(_0x53b1a3,_0x15f8c1)=>{_0x15f8c1>0x0&&Q(this['statsToReport_'],_0x53b1a3)&&(_0xfaab93[_0x53b1a3]=_0x15f8c1,_0xe5a7d4=!0x0);}),_0xe5a7d4&&this['server_']['reportStats'](_0xfaab93),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2ca79a){_0x2ca79a[_0x2ca79a['OVERWRITE']=0x0]='OVERWRITE',_0x2ca79a[_0x2ca79a['MERGE']=0x1]='MERGE',_0x2ca79a[_0x2ca79a['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2ca79a[_0x2ca79a['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x506314){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x506314,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x37fa53,_0x4ab88c,_0x57b05f){this['path']=_0x37fa53,this['affectedTree']=_0x4ab88c,this['revert']=_0x57b05f,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x171db9){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5342d7=this['affectedTree']['subtree'](new C(_0x171db9));return new In(w(),_0x5342d7,this['revert']);}}else return f(y(this['path'])===_0x171db9,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x5d6096,_0x5545f1){this['source']=_0x5d6096,this['path']=_0x5545f1,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x35193d){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x26619a,_0x3bae04,_0x438b30){this['source']=_0x26619a,this['path']=_0x3bae04,this['snap']=_0x438b30,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3f812a){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3f812a)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x21faaf,_0x10462f,_0x40ceeb){this['source']=_0x21faaf,this['path']=_0x10462f,this['children']=_0x40ceeb,this['type']=z['MERGE'];}['operationForChild'](_0x3011a3){if(v(this['path'])){const _0x44266c=this['children']['subtree'](new C(_0x3011a3));return _0x44266c['isEmpty']()?null:_0x44266c['value']?new Be(this['source'],w(),_0x44266c['value']):new ot(this['source'],w(),_0x44266c);}else return f(y(this['path'])===_0x3011a3,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x59a24a,_0xd2f94c,_0x5c5ed3){this['node_']=_0x59a24a,this['fullyInitialized_']=_0xd2f94c,this['filtered_']=_0x5c5ed3;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1d3fc3){if(v(_0x1d3fc3))return this['isFullyInitialized']()&&!this['filtered_'];const _0x52454a=y(_0x1d3fc3);return this['isCompleteForChild'](_0x52454a);}['isCompleteForChild'](_0x504061){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x504061);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x315236){this['query_']=_0x315236,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x3a62da,_0x368c8e,_0x4d7307,_0x2421b6){const _0x3b99f=[],_0x520658=[];return _0x368c8e['forEach'](_0x5be5e3=>{_0x5be5e3['type']==='child_changed'&&_0x3a62da['index_']['indexedValueChanged'](_0x5be5e3['oldSnap'],_0x5be5e3['snapshotNode'])&&_0x520658['push'](zh(_0x5be5e3['childName'],_0x5be5e3['snapshotNode']));}),wt(_0x3a62da,_0x3b99f,'child_removed',_0x368c8e,_0x2421b6,_0x4d7307),wt(_0x3a62da,_0x3b99f,'child_added',_0x368c8e,_0x2421b6,_0x4d7307),wt(_0x3a62da,_0x3b99f,'child_moved',_0x520658,_0x2421b6,_0x4d7307),wt(_0x3a62da,_0x3b99f,'child_changed',_0x368c8e,_0x2421b6,_0x4d7307),wt(_0x3a62da,_0x3b99f,'value',_0x368c8e,_0x2421b6,_0x4d7307),_0x3b99f;}function wt(_0x1d86cd,_0x3e2c76,_0x968ad9,_0x4225b0,_0x620b16,_0x5b0f8d){const _0x33b4f1=_0x4225b0['filter'](_0x426926=>_0x426926['type']===_0x968ad9);_0x33b4f1['sort']((_0x3ae6e0,_0x478dd1)=>au(_0x1d86cd,_0x3ae6e0,_0x478dd1)),_0x33b4f1['forEach'](_0xa044d9=>{const _0x437ccd=ou(_0x1d86cd,_0xa044d9,_0x5b0f8d);_0x620b16['forEach'](_0x29b1a4=>{_0x29b1a4['respondsTo'](_0xa044d9['type'])&&_0x3e2c76['push'](_0x29b1a4['createEvent'](_0x437ccd,_0x1d86cd['query_']));});});}function ou(_0x316410,_0x2438a8,_0x10d5e5){return _0x2438a8['type']==='value'||_0x2438a8['type']==='child_removed'||(_0x2438a8['prevName']=_0x10d5e5['getPredecessorChildName'](_0x2438a8['childName'],_0x2438a8['snapshotNode'],_0x316410['index_'])),_0x2438a8;}function au(_0xda1c0b,_0x5d0107,_0x2f15d5){if(_0x5d0107['childName']==null||_0x2f15d5['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1966a5=new E(_0x5d0107['childName'],_0x5d0107['snapshotNode']),_0x181915=new E(_0x2f15d5['childName'],_0x2f15d5['snapshotNode']);return _0xda1c0b['index_']['compare'](_0x1966a5,_0x181915);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2af49a,_0x1ce37f){return{'eventCache':_0x2af49a,'serverCache':_0x1ce37f};}function Rt(_0x1db47a,_0x85e112,_0x188e61,_0x493831){return Un(new Te(_0x85e112,_0x188e61,_0x493831),_0x1db47a['serverCache']);}function Fo(_0x1058f4,_0x2e42c8,_0x35a61f,_0x3c7621){return Un(_0x1058f4['eventCache'],new Te(_0x2e42c8,_0x35a61f,_0x3c7621));}function wn(_0x28083a){return _0x28083a['eventCache']['isFullyInitialized']()?_0x28083a['eventCache']['getNode']():null;}function Ve(_0x1a072d){return _0x1a072d['serverCache']['isFullyInitialized']()?_0x1a072d['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x528aba){let _0x4077d2=new b(null);return x(_0x528aba,(_0xe11dfe,_0x5cd81c)=>{_0x4077d2=_0x4077d2['set'](new C(_0xe11dfe),_0x5cd81c);}),_0x4077d2;}constructor(_0x502966,_0x19e4b4=cu()){this['value']=_0x502966,this['children']=_0x19e4b4;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x439b8d,_0x5b1dd8){if(this['value']!=null&&_0x5b1dd8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x439b8d))return null;{const _0xd6105=y(_0x439b8d),_0x91962a=this['children']['get'](_0xd6105);if(_0x91962a!==null){const _0x263930=_0x91962a['findRootMostMatchingPathAndValue'](S(_0x439b8d),_0x5b1dd8);return _0x263930!=null?{'path':k(new C(_0xd6105),_0x263930['path']),'value':_0x263930['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xbaa74d){return this['findRootMostMatchingPathAndValue'](_0xbaa74d,()=>!0x0);}['subtree'](_0x13ce2b){if(v(_0x13ce2b))return this;{const _0x4f861e=y(_0x13ce2b),_0x5577a3=this['children']['get'](_0x4f861e);return _0x5577a3!==null?_0x5577a3['subtree'](S(_0x13ce2b)):new b(null);}}['set'](_0x38db9a,_0x2084c2){if(v(_0x38db9a))return new b(_0x2084c2,this['children']);{const _0x275b2e=y(_0x38db9a),_0x227eb1=(this['children']['get'](_0x275b2e)||new b(null))['set'](S(_0x38db9a),_0x2084c2),_0x1c442c=this['children']['insert'](_0x275b2e,_0x227eb1);return new b(this['value'],_0x1c442c);}}['remove'](_0x22ea93){if(v(_0x22ea93))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x38b8c2=y(_0x22ea93),_0x180b5b=this['children']['get'](_0x38b8c2);if(_0x180b5b){const _0x5d9827=_0x180b5b['remove'](S(_0x22ea93));let _0x4f5989;return _0x5d9827['isEmpty']()?_0x4f5989=this['children']['remove'](_0x38b8c2):_0x4f5989=this['children']['insert'](_0x38b8c2,_0x5d9827),this['value']===null&&_0x4f5989['isEmpty']()?new b(null):new b(this['value'],_0x4f5989);}else return this;}}['get'](_0x535c8f){if(v(_0x535c8f))return this['value'];{const _0x3494a3=y(_0x535c8f),_0x445b50=this['children']['get'](_0x3494a3);return _0x445b50?_0x445b50['get'](S(_0x535c8f)):null;}}['setTree'](_0x4db9d6,_0x5b2bff){if(v(_0x4db9d6))return _0x5b2bff;{const _0x59ee08=y(_0x4db9d6),_0x5068a7=(this['children']['get'](_0x59ee08)||new b(null))['setTree'](S(_0x4db9d6),_0x5b2bff);let _0x318997;return _0x5068a7['isEmpty']()?_0x318997=this['children']['remove'](_0x59ee08):_0x318997=this['children']['insert'](_0x59ee08,_0x5068a7),new b(this['value'],_0x318997);}}['fold'](_0x210482){return this['fold_'](w(),_0x210482);}['fold_'](_0xbe430c,_0xbff77b){const _0x23e08c={};return this['children']['inorderTraversal']((_0x4bde03,_0x3c7c5d)=>{_0x23e08c[_0x4bde03]=_0x3c7c5d['fold_'](k(_0xbe430c,_0x4bde03),_0xbff77b);}),_0xbff77b(_0xbe430c,this['value'],_0x23e08c);}['findOnPath'](_0x2627d9,_0x137ac9){return this['findOnPath_'](_0x2627d9,w(),_0x137ac9);}['findOnPath_'](_0x35542a,_0x2892eb,_0x442932){const _0x3cd13a=this['value']?_0x442932(_0x2892eb,this['value']):!0x1;if(_0x3cd13a)return _0x3cd13a;if(v(_0x35542a))return null;{const _0x291dbf=y(_0x35542a),_0x4c605e=this['children']['get'](_0x291dbf);return _0x4c605e?_0x4c605e['findOnPath_'](S(_0x35542a),k(_0x2892eb,_0x291dbf),_0x442932):null;}}['foreachOnPath'](_0x385207,_0x4ce456){return this['foreachOnPath_'](_0x385207,w(),_0x4ce456);}['foreachOnPath_'](_0x4be33c,_0x220fca,_0x1d2145){if(v(_0x4be33c))return this;{this['value']&&_0x1d2145(_0x220fca,this['value']);const _0xce8e32=y(_0x4be33c),_0xa8e72c=this['children']['get'](_0xce8e32);return _0xa8e72c?_0xa8e72c['foreachOnPath_'](S(_0x4be33c),k(_0x220fca,_0xce8e32),_0x1d2145):new b(null);}}['foreach'](_0x3dfcb8){this['foreach_'](w(),_0x3dfcb8);}['foreach_'](_0x427ef3,_0x2c20e4){this['children']['inorderTraversal']((_0x2b9355,_0x530dd6)=>{_0x530dd6['foreach_'](k(_0x427ef3,_0x2b9355),_0x2c20e4);}),this['value']&&_0x2c20e4(_0x427ef3,this['value']);}['foreachChild'](_0x36ebfa){this['children']['inorderTraversal']((_0x1f2599,_0x42b257)=>{_0x42b257['value']&&_0x36ebfa(_0x1f2599,_0x42b257['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x3da015){this['writeTree_']=_0x3da015;}static['empty'](){return new K(new b(null));}}function At(_0x230209,_0x5a810b,_0x45c4c7){if(v(_0x5a810b))return new K(new b(_0x45c4c7));{const _0x368104=_0x230209['writeTree_']['findRootMostValueAndPath'](_0x5a810b);if(_0x368104!=null){const _0x445183=_0x368104['path'];let _0x4cb4f5=_0x368104['value'];const _0x51d828=F(_0x445183,_0x5a810b);return _0x4cb4f5=_0x4cb4f5['updateChild'](_0x51d828,_0x45c4c7),new K(_0x230209['writeTree_']['set'](_0x445183,_0x4cb4f5));}else{const _0x2d324e=new b(_0x45c4c7),_0x661e17=_0x230209['writeTree_']['setTree'](_0x5a810b,_0x2d324e);return new K(_0x661e17);}}}function bi(_0x14f72c,_0xf52331,_0x104cf2){let _0x3c2c45=_0x14f72c;return x(_0x104cf2,(_0x26c565,_0x473908)=>{_0x3c2c45=At(_0x3c2c45,k(_0xf52331,_0x26c565),_0x473908);}),_0x3c2c45;}function or(_0x385200,_0x3186df){if(v(_0x3186df))return K['empty']();{const _0x5d5c87=_0x385200['writeTree_']['setTree'](_0x3186df,new b(null));return new K(_0x5d5c87);}}function Ri(_0x2c8b58,_0x23937d){return ze(_0x2c8b58,_0x23937d)!=null;}function ze(_0x8e62cc,_0x481064){const _0x33bb68=_0x8e62cc['writeTree_']['findRootMostValueAndPath'](_0x481064);return _0x33bb68!=null?_0x8e62cc['writeTree_']['get'](_0x33bb68['path'])['getChild'](F(_0x33bb68['path'],_0x481064)):null;}function ar(_0x9c9f86){const _0x27d717=[],_0x194a85=_0x9c9f86['writeTree_']['value'];return _0x194a85!=null?_0x194a85['isLeafNode']()||_0x194a85['forEachChild'](R,(_0x177814,_0x45a61d)=>{_0x27d717['push'](new E(_0x177814,_0x45a61d));}):_0x9c9f86['writeTree_']['children']['inorderTraversal']((_0x3c6536,_0x5b79bd)=>{_0x5b79bd['value']!=null&&_0x27d717['push'](new E(_0x3c6536,_0x5b79bd['value']));}),_0x27d717;}function Ee(_0x3fbbee,_0xcfa1cb){if(v(_0xcfa1cb))return _0x3fbbee;{const _0x1df3b6=ze(_0x3fbbee,_0xcfa1cb);return _0x1df3b6!=null?new K(new b(_0x1df3b6)):new K(_0x3fbbee['writeTree_']['subtree'](_0xcfa1cb));}}function Ai(_0x4f3020){return _0x4f3020['writeTree_']['isEmpty']();}function at(_0x2152e,_0x21131d){return Uo(w(),_0x2152e['writeTree_'],_0x21131d);}function Uo(_0x2065c8,_0xb6fe09,_0x453613){if(_0xb6fe09['value']!=null)return _0x453613['updateChild'](_0x2065c8,_0xb6fe09['value']);{let _0x236a11=null;return _0xb6fe09['children']['inorderTraversal']((_0x563300,_0x4f4ab6)=>{_0x563300==='.priority'?(f(_0x4f4ab6['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x236a11=_0x4f4ab6['value']):_0x453613=Uo(k(_0x2065c8,_0x563300),_0x4f4ab6,_0x453613);}),!_0x453613['getChild'](_0x2065c8)['isEmpty']()&&_0x236a11!==null&&(_0x453613=_0x453613['updateChild'](k(_0x2065c8,'.priority'),_0x236a11)),_0x453613;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x18802c,_0x31c1a8){return Ho(_0x31c1a8,_0x18802c);}function lu(_0xa887e,_0x2e0f52,_0x50ae98,_0x1bd6fc,_0x1adf7a){f(_0x1bd6fc>_0xa887e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1adf7a===void 0x0&&(_0x1adf7a=!0x0),_0xa887e['allWrites']['push']({'path':_0x2e0f52,'snap':_0x50ae98,'writeId':_0x1bd6fc,'visible':_0x1adf7a}),_0x1adf7a&&(_0xa887e['visibleWrites']=At(_0xa887e['visibleWrites'],_0x2e0f52,_0x50ae98)),_0xa887e['lastWriteId']=_0x1bd6fc;}function hu(_0x42cf6a,_0x1b2b3b,_0x168f70,_0x258eb8){f(_0x258eb8>_0x42cf6a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x42cf6a['allWrites']['push']({'path':_0x1b2b3b,'children':_0x168f70,'writeId':_0x258eb8,'visible':!0x0}),_0x42cf6a['visibleWrites']=bi(_0x42cf6a['visibleWrites'],_0x1b2b3b,_0x168f70),_0x42cf6a['lastWriteId']=_0x258eb8;}function uu(_0x3330b6,_0xdfb8){for(let _0x3beca1=0x0;_0x3beca1<_0x3330b6['allWrites']['length'];_0x3beca1++){const _0x211704=_0x3330b6['allWrites'][_0x3beca1];if(_0x211704['writeId']===_0xdfb8)return _0x211704;}return null;}function du(_0x191cb3,_0x7af234){const _0x266461=_0x191cb3['allWrites']['findIndex'](_0x5da0af=>_0x5da0af['writeId']===_0x7af234);f(_0x266461>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1c8e99=_0x191cb3['allWrites'][_0x266461];_0x191cb3['allWrites']['splice'](_0x266461,0x1);let _0x13c5c6=_0x1c8e99['visible'],_0x3f08f5=!0x1,_0x4c5a1c=_0x191cb3['allWrites']['length']-0x1;for(;_0x13c5c6&&_0x4c5a1c>=0x0;){const _0x437c9f=_0x191cb3['allWrites'][_0x4c5a1c];_0x437c9f['visible']&&(_0x4c5a1c>=_0x266461&&fu(_0x437c9f,_0x1c8e99['path'])?_0x13c5c6=!0x1:G(_0x1c8e99['path'],_0x437c9f['path'])&&(_0x3f08f5=!0x0)),_0x4c5a1c--;}if(_0x13c5c6){if(_0x3f08f5)return pu(_0x191cb3),!0x0;if(_0x1c8e99['snap'])_0x191cb3['visibleWrites']=or(_0x191cb3['visibleWrites'],_0x1c8e99['path']);else{const _0x102743=_0x1c8e99['children'];x(_0x102743,_0x1dbd18=>{_0x191cb3['visibleWrites']=or(_0x191cb3['visibleWrites'],k(_0x1c8e99['path'],_0x1dbd18));});}return!0x0;}else return!0x1;}function fu(_0x3f4595,_0x48f6ca){if(_0x3f4595['snap'])return G(_0x3f4595['path'],_0x48f6ca);for(const _0x11921a in _0x3f4595['children'])if(_0x3f4595['children']['hasOwnProperty'](_0x11921a)&&G(k(_0x3f4595['path'],_0x11921a),_0x48f6ca))return!0x0;return!0x1;}function pu(_0x225567){_0x225567['visibleWrites']=Wo(_0x225567['allWrites'],_u,w()),_0x225567['allWrites']['length']>0x0?_0x225567['lastWriteId']=_0x225567['allWrites'][_0x225567['allWrites']['length']-0x1]['writeId']:_0x225567['lastWriteId']=-0x1;}function _u(_0x3ddbf2){return _0x3ddbf2['visible'];}function Wo(_0x2eeaa8,_0x3e7ecf,_0x5cb100){let _0x13a600=K['empty']();for(let _0x275a06=0x0;_0x275a06<_0x2eeaa8['length'];++_0x275a06){const _0x21d935=_0x2eeaa8[_0x275a06];if(_0x3e7ecf(_0x21d935)){const _0x5bd9cf=_0x21d935['path'];let _0xf3d7b7;if(_0x21d935['snap'])G(_0x5cb100,_0x5bd9cf)?(_0xf3d7b7=F(_0x5cb100,_0x5bd9cf),_0x13a600=At(_0x13a600,_0xf3d7b7,_0x21d935['snap'])):G(_0x5bd9cf,_0x5cb100)&&(_0xf3d7b7=F(_0x5bd9cf,_0x5cb100),_0x13a600=At(_0x13a600,w(),_0x21d935['snap']['getChild'](_0xf3d7b7)));else{if(_0x21d935['children']){if(G(_0x5cb100,_0x5bd9cf))_0xf3d7b7=F(_0x5cb100,_0x5bd9cf),_0x13a600=bi(_0x13a600,_0xf3d7b7,_0x21d935['children']);else{if(G(_0x5bd9cf,_0x5cb100)){if(_0xf3d7b7=F(_0x5bd9cf,_0x5cb100),v(_0xf3d7b7))_0x13a600=bi(_0x13a600,w(),_0x21d935['children']);else{const _0x16d77f=Le(_0x21d935['children'],y(_0xf3d7b7));if(_0x16d77f){const _0x26e608=_0x16d77f['getChild'](S(_0xf3d7b7));_0x13a600=At(_0x13a600,w(),_0x26e608);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x13a600;}function Bo(_0x5e2a59,_0x803342,_0x338459,_0x30d8f3,_0x34a604){if(!_0x30d8f3&&!_0x34a604){const _0x5c9eb7=ze(_0x5e2a59['visibleWrites'],_0x803342);if(_0x5c9eb7!=null)return _0x5c9eb7;{const _0x42c23d=Ee(_0x5e2a59['visibleWrites'],_0x803342);if(Ai(_0x42c23d))return _0x338459;if(_0x338459==null&&!Ri(_0x42c23d,w()))return null;{const _0x531bc4=_0x338459||g['EMPTY_NODE'];return at(_0x42c23d,_0x531bc4);}}}else{const _0x2925a0=Ee(_0x5e2a59['visibleWrites'],_0x803342);if(!_0x34a604&&Ai(_0x2925a0))return _0x338459;if(!_0x34a604&&_0x338459==null&&!Ri(_0x2925a0,w()))return null;{const _0x4bc76e=function(_0x5afda6){return(_0x5afda6['visible']||_0x34a604)&&(!_0x30d8f3||!~_0x30d8f3['indexOf'](_0x5afda6['writeId']))&&(G(_0x5afda6['path'],_0x803342)||G(_0x803342,_0x5afda6['path']));},_0x4f03f9=Wo(_0x5e2a59['allWrites'],_0x4bc76e,_0x803342),_0x21f8b2=_0x338459||g['EMPTY_NODE'];return at(_0x4f03f9,_0x21f8b2);}}}function gu(_0x526be3,_0x47a579,_0x54ad68){let _0x24f7fb=g['EMPTY_NODE'];const _0x4d10dd=ze(_0x526be3['visibleWrites'],_0x47a579);if(_0x4d10dd)return _0x4d10dd['isLeafNode']()||_0x4d10dd['forEachChild'](R,(_0x545340,_0x4bdd66)=>{_0x24f7fb=_0x24f7fb['updateImmediateChild'](_0x545340,_0x4bdd66);}),_0x24f7fb;if(_0x54ad68){const _0x94846c=Ee(_0x526be3['visibleWrites'],_0x47a579);return _0x54ad68['forEachChild'](R,(_0x22ece5,_0x254ab0)=>{const _0x1b5122=at(Ee(_0x94846c,new C(_0x22ece5)),_0x254ab0);_0x24f7fb=_0x24f7fb['updateImmediateChild'](_0x22ece5,_0x1b5122);}),ar(_0x94846c)['forEach'](_0x325156=>{_0x24f7fb=_0x24f7fb['updateImmediateChild'](_0x325156['name'],_0x325156['node']);}),_0x24f7fb;}else{const _0x54d646=Ee(_0x526be3['visibleWrites'],_0x47a579);return ar(_0x54d646)['forEach'](_0x9377d9=>{_0x24f7fb=_0x24f7fb['updateImmediateChild'](_0x9377d9['name'],_0x9377d9['node']);}),_0x24f7fb;}}function mu(_0x323955,_0x538b61,_0x6376ff,_0x28e33,_0x2a8349){f(_0x28e33||_0x2a8349,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x50c83d=k(_0x538b61,_0x6376ff);if(Ri(_0x323955['visibleWrites'],_0x50c83d))return null;{const _0x9e8b6b=Ee(_0x323955['visibleWrites'],_0x50c83d);return Ai(_0x9e8b6b)?_0x2a8349['getChild'](_0x6376ff):at(_0x9e8b6b,_0x2a8349['getChild'](_0x6376ff));}}function yu(_0x342eb0,_0xb5d2ff,_0x398895,_0x5e8a11){const _0xe26cf9=k(_0xb5d2ff,_0x398895),_0x58d5d3=ze(_0x342eb0['visibleWrites'],_0xe26cf9);if(_0x58d5d3!=null)return _0x58d5d3;if(_0x5e8a11['isCompleteForChild'](_0x398895)){const _0x38888a=Ee(_0x342eb0['visibleWrites'],_0xe26cf9);return at(_0x38888a,_0x5e8a11['getNode']()['getImmediateChild'](_0x398895));}else return null;}function vu(_0x188ebe,_0xfcb8d){return ze(_0x188ebe['visibleWrites'],_0xfcb8d);}function Eu(_0x2b119e,_0x31c559,_0x38c1d7,_0x5f1a6b,_0x4abb0c,_0x474481,_0x2f7804){let _0x901903;const _0x116a3a=Ee(_0x2b119e['visibleWrites'],_0x31c559),_0x186424=ze(_0x116a3a,w());if(_0x186424!=null)_0x901903=_0x186424;else{if(_0x38c1d7!=null)_0x901903=at(_0x116a3a,_0x38c1d7);else return[];}if(_0x901903=_0x901903['withIndex'](_0x2f7804),!_0x901903['isEmpty']()&&!_0x901903['isLeafNode']()){const _0x14f103=[],_0x28cfff=_0x2f7804['getCompare'](),_0x4343ab=_0x474481?_0x901903['getReverseIteratorFrom'](_0x5f1a6b,_0x2f7804):_0x901903['getIteratorFrom'](_0x5f1a6b,_0x2f7804);let _0x3d11eb=_0x4343ab['getNext']();for(;_0x3d11eb&&_0x14f103['length']<_0x4abb0c;)_0x28cfff(_0x3d11eb,_0x5f1a6b)!==0x0&&_0x14f103['push'](_0x3d11eb),_0x3d11eb=_0x4343ab['getNext']();return _0x14f103;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x4cf530,_0x45414b,_0x532052,_0x475ff4){return Bo(_0x4cf530['writeTree'],_0x4cf530['treePath'],_0x45414b,_0x532052,_0x475ff4);}function is(_0x1daa79,_0x46ccd0){return gu(_0x1daa79['writeTree'],_0x1daa79['treePath'],_0x46ccd0);}function cr(_0x6bc4ad,_0x3e42eb,_0x3555ef,_0xea3e60){return mu(_0x6bc4ad['writeTree'],_0x6bc4ad['treePath'],_0x3e42eb,_0x3555ef,_0xea3e60);}function Tn(_0x44ced5,_0x4d2964){return vu(_0x44ced5['writeTree'],k(_0x44ced5['treePath'],_0x4d2964));}function wu(_0x120a56,_0xdc6a42,_0x4f9be0,_0x372fe9,_0x5e92c9,_0x5b40d6){return Eu(_0x120a56['writeTree'],_0x120a56['treePath'],_0xdc6a42,_0x4f9be0,_0x372fe9,_0x5e92c9,_0x5b40d6);}function ss(_0x58efe6,_0x4d2266,_0x23dc7d){return yu(_0x58efe6['writeTree'],_0x58efe6['treePath'],_0x4d2266,_0x23dc7d);}function Vo(_0x2d013e,_0x3642a3){return Ho(k(_0x2d013e['treePath'],_0x3642a3),_0x2d013e['writeTree']);}function Ho(_0x5be797,_0x3d0623){return{'treePath':_0x5be797,'writeTree':_0x3d0623};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1bd3b1){const _0x454aac=_0x1bd3b1['type'],_0x5e0486=_0x1bd3b1['childName'];f(_0x454aac==='child_added'||_0x454aac==='child_changed'||_0x454aac==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5e0486!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x452be3=this['changeMap']['get'](_0x5e0486);if(_0x452be3){const _0x47970e=_0x452be3['type'];if(_0x454aac==='child_added'&&_0x47970e==='child_removed')this['changeMap']['set'](_0x5e0486,xt(_0x5e0486,_0x1bd3b1['snapshotNode'],_0x452be3['snapshotNode']));else{if(_0x454aac==='child_removed'&&_0x47970e==='child_added')this['changeMap']['delete'](_0x5e0486);else{if(_0x454aac==='child_removed'&&_0x47970e==='child_changed')this['changeMap']['set'](_0x5e0486,Lt(_0x5e0486,_0x452be3['oldSnap']));else{if(_0x454aac==='child_changed'&&_0x47970e==='child_added')this['changeMap']['set'](_0x5e0486,rt(_0x5e0486,_0x1bd3b1['snapshotNode']));else{if(_0x454aac==='child_changed'&&_0x47970e==='child_changed')this['changeMap']['set'](_0x5e0486,xt(_0x5e0486,_0x1bd3b1['snapshotNode'],_0x452be3['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x1bd3b1+'\x20occurred\x20after\x20'+_0x452be3);}}}}}else this['changeMap']['set'](_0x5e0486,_0x1bd3b1);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1e7bf0){return null;}['getChildAfterChild'](_0x53cf4d,_0x5370c7,_0x1ef4c9){return null;}}const $o=new Tu();class rs{constructor(_0x27e4e5,_0xb3561a,_0x24f60b=null){this['writes_']=_0x27e4e5,this['viewCache_']=_0xb3561a,this['optCompleteServerCache_']=_0x24f60b;}['getCompleteChild'](_0x24c69f){const _0x1c8b2d=this['viewCache_']['eventCache'];if(_0x1c8b2d['isCompleteForChild'](_0x24c69f))return _0x1c8b2d['getNode']()['getImmediateChild'](_0x24c69f);{const _0x5c70f4=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x24c69f,_0x5c70f4);}}['getChildAfterChild'](_0x29912c,_0x2d0578,_0x1b081c){const _0xc5714f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x27bf99=wu(this['writes_'],_0xc5714f,_0x2d0578,0x1,_0x1b081c,_0x29912c);return _0x27bf99['length']===0x0?null:_0x27bf99[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2c8a38){return{'filter':_0x2c8a38};}function bu(_0x5b398d,_0x22527f){f(_0x22527f['eventCache']['getNode']()['isIndexed'](_0x5b398d['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x22527f['serverCache']['getNode']()['isIndexed'](_0x5b398d['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x3e7d45,_0x34ffd2,_0x3bc15f,_0x500dea,_0x148b83){const _0x458b16=new Cu();let _0x55e6f0,_0x17c58c;if(_0x3bc15f['type']===z['OVERWRITE']){const _0x6b987c=_0x3bc15f;_0x6b987c['source']['fromUser']?_0x55e6f0=ki(_0x3e7d45,_0x34ffd2,_0x6b987c['path'],_0x6b987c['snap'],_0x500dea,_0x148b83,_0x458b16):(f(_0x6b987c['source']['fromServer'],'Unknown\x20source.'),_0x17c58c=_0x6b987c['source']['tagged']||_0x34ffd2['serverCache']['isFiltered']()&&!v(_0x6b987c['path']),_0x55e6f0=Sn(_0x3e7d45,_0x34ffd2,_0x6b987c['path'],_0x6b987c['snap'],_0x500dea,_0x148b83,_0x17c58c,_0x458b16));}else{if(_0x3bc15f['type']===z['MERGE']){const _0x17203c=_0x3bc15f;_0x17203c['source']['fromUser']?_0x55e6f0=ku(_0x3e7d45,_0x34ffd2,_0x17203c['path'],_0x17203c['children'],_0x500dea,_0x148b83,_0x458b16):(f(_0x17203c['source']['fromServer'],'Unknown\x20source.'),_0x17c58c=_0x17203c['source']['tagged']||_0x34ffd2['serverCache']['isFiltered'](),_0x55e6f0=Pi(_0x3e7d45,_0x34ffd2,_0x17203c['path'],_0x17203c['children'],_0x500dea,_0x148b83,_0x17c58c,_0x458b16));}else{if(_0x3bc15f['type']===z['ACK_USER_WRITE']){const _0x2adaeb=_0x3bc15f;_0x2adaeb['revert']?_0x55e6f0=Ou(_0x3e7d45,_0x34ffd2,_0x2adaeb['path'],_0x500dea,_0x148b83,_0x458b16):_0x55e6f0=Pu(_0x3e7d45,_0x34ffd2,_0x2adaeb['path'],_0x2adaeb['affectedTree'],_0x500dea,_0x148b83,_0x458b16);}else{if(_0x3bc15f['type']===z['LISTEN_COMPLETE'])_0x55e6f0=Nu(_0x3e7d45,_0x34ffd2,_0x3bc15f['path'],_0x500dea,_0x458b16);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3bc15f['type']);}}}const _0xbd5a86=_0x458b16['getChanges']();return Au(_0x34ffd2,_0x55e6f0,_0xbd5a86),{'viewCache':_0x55e6f0,'changes':_0xbd5a86};}function Au(_0x45d1d7,_0x25bd88,_0x466aa){const _0x3e4583=_0x25bd88['eventCache'];if(_0x3e4583['isFullyInitialized']()){const _0x3baf8f=_0x3e4583['getNode']()['isLeafNode']()||_0x3e4583['getNode']()['isEmpty'](),_0x5ce726=wn(_0x45d1d7);(_0x466aa['length']>0x0||!_0x45d1d7['eventCache']['isFullyInitialized']()||_0x3baf8f&&!_0x3e4583['getNode']()['equals'](_0x5ce726)||!_0x3e4583['getNode']()['getPriority']()['equals'](_0x5ce726['getPriority']()))&&_0x466aa['push'](Lo(wn(_0x25bd88)));}}function Go(_0x4d2d68,_0x2a72ec,_0x1bd2bf,_0x416d4c,_0x822d00,_0xc2542a){const _0x3172c7=_0x2a72ec['eventCache'];if(Tn(_0x416d4c,_0x1bd2bf)!=null)return _0x2a72ec;{let _0x3adf6b,_0x2da779;if(v(_0x1bd2bf)){if(f(_0x2a72ec['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2a72ec['serverCache']['isFiltered']()){const _0x1a71da=Ve(_0x2a72ec),_0x4b1d58=_0x1a71da instanceof g?_0x1a71da:g['EMPTY_NODE'],_0x54545c=is(_0x416d4c,_0x4b1d58);_0x3adf6b=_0x4d2d68['filter']['updateFullNode'](_0x2a72ec['eventCache']['getNode'](),_0x54545c,_0xc2542a);}else{const _0x22ae83=Cn(_0x416d4c,Ve(_0x2a72ec));_0x3adf6b=_0x4d2d68['filter']['updateFullNode'](_0x2a72ec['eventCache']['getNode'](),_0x22ae83,_0xc2542a);}}else{const _0x5caf45=y(_0x1bd2bf);if(_0x5caf45==='.priority'){f(Ce(_0x1bd2bf)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4413bb=_0x3172c7['getNode']();_0x2da779=_0x2a72ec['serverCache']['getNode']();const _0x4e82b4=cr(_0x416d4c,_0x1bd2bf,_0x4413bb,_0x2da779);_0x4e82b4!=null?_0x3adf6b=_0x4d2d68['filter']['updatePriority'](_0x4413bb,_0x4e82b4):_0x3adf6b=_0x3172c7['getNode']();}else{const _0x52b4b3=S(_0x1bd2bf);let _0x314f9a;if(_0x3172c7['isCompleteForChild'](_0x5caf45)){_0x2da779=_0x2a72ec['serverCache']['getNode']();const _0x32b195=cr(_0x416d4c,_0x1bd2bf,_0x3172c7['getNode'](),_0x2da779);_0x32b195!=null?_0x314f9a=_0x3172c7['getNode']()['getImmediateChild'](_0x5caf45)['updateChild'](_0x52b4b3,_0x32b195):_0x314f9a=_0x3172c7['getNode']()['getImmediateChild'](_0x5caf45);}else _0x314f9a=ss(_0x416d4c,_0x5caf45,_0x2a72ec['serverCache']);_0x314f9a!=null?_0x3adf6b=_0x4d2d68['filter']['updateChild'](_0x3172c7['getNode'](),_0x5caf45,_0x314f9a,_0x52b4b3,_0x822d00,_0xc2542a):_0x3adf6b=_0x3172c7['getNode']();}}return Rt(_0x2a72ec,_0x3adf6b,_0x3172c7['isFullyInitialized']()||v(_0x1bd2bf),_0x4d2d68['filter']['filtersNodes']());}}function Sn(_0x159594,_0x1a5cfe,_0x97e691,_0x14b1f8,_0x1c92d2,_0xe52bcf,_0x132b10,_0x1ef98c){const _0x484d07=_0x1a5cfe['serverCache'];let _0x2cbe19;const _0xcc4c1f=_0x132b10?_0x159594['filter']:_0x159594['filter']['getIndexedFilter']();if(v(_0x97e691))_0x2cbe19=_0xcc4c1f['updateFullNode'](_0x484d07['getNode'](),_0x14b1f8,null);else{if(_0xcc4c1f['filtersNodes']()&&!_0x484d07['isFiltered']()){const _0x6809d0=_0x484d07['getNode']()['updateChild'](_0x97e691,_0x14b1f8);_0x2cbe19=_0xcc4c1f['updateFullNode'](_0x484d07['getNode'](),_0x6809d0,null);}else{const _0x346860=y(_0x97e691);if(!_0x484d07['isCompleteForPath'](_0x97e691)&&Ce(_0x97e691)>0x1)return _0x1a5cfe;const _0x40de00=S(_0x97e691),_0x71d71f=_0x484d07['getNode']()['getImmediateChild'](_0x346860)['updateChild'](_0x40de00,_0x14b1f8);_0x346860==='.priority'?_0x2cbe19=_0xcc4c1f['updatePriority'](_0x484d07['getNode'](),_0x71d71f):_0x2cbe19=_0xcc4c1f['updateChild'](_0x484d07['getNode'](),_0x346860,_0x71d71f,_0x40de00,$o,null);}}const _0x30d616=Fo(_0x1a5cfe,_0x2cbe19,_0x484d07['isFullyInitialized']()||v(_0x97e691),_0xcc4c1f['filtersNodes']()),_0x3969f6=new rs(_0x1c92d2,_0x30d616,_0xe52bcf);return Go(_0x159594,_0x30d616,_0x97e691,_0x1c92d2,_0x3969f6,_0x1ef98c);}function ki(_0x4ea740,_0x42b81b,_0x5914c7,_0x452685,_0x251428,_0x3a774a,_0xd097d6){const _0x3dbca2=_0x42b81b['eventCache'];let _0x531634,_0x534888;const _0x534ea7=new rs(_0x251428,_0x42b81b,_0x3a774a);if(v(_0x5914c7))_0x534888=_0x4ea740['filter']['updateFullNode'](_0x42b81b['eventCache']['getNode'](),_0x452685,_0xd097d6),_0x531634=Rt(_0x42b81b,_0x534888,!0x0,_0x4ea740['filter']['filtersNodes']());else{const _0x24dd90=y(_0x5914c7);if(_0x24dd90==='.priority')_0x534888=_0x4ea740['filter']['updatePriority'](_0x42b81b['eventCache']['getNode'](),_0x452685),_0x531634=Rt(_0x42b81b,_0x534888,_0x3dbca2['isFullyInitialized'](),_0x3dbca2['isFiltered']());else{const _0x10988c=S(_0x5914c7),_0x33b479=_0x3dbca2['getNode']()['getImmediateChild'](_0x24dd90);let _0x15e003;if(v(_0x10988c))_0x15e003=_0x452685;else{const _0x424c80=_0x534ea7['getCompleteChild'](_0x24dd90);_0x424c80!=null?ji(_0x10988c)==='.priority'&&_0x424c80['getChild'](Ro(_0x10988c))['isEmpty']()?_0x15e003=_0x424c80:_0x15e003=_0x424c80['updateChild'](_0x10988c,_0x452685):_0x15e003=g['EMPTY_NODE'];}if(_0x33b479['equals'](_0x15e003))_0x531634=_0x42b81b;else{const _0x230f1c=_0x4ea740['filter']['updateChild'](_0x3dbca2['getNode'](),_0x24dd90,_0x15e003,_0x10988c,_0x534ea7,_0xd097d6);_0x531634=Rt(_0x42b81b,_0x230f1c,_0x3dbca2['isFullyInitialized'](),_0x4ea740['filter']['filtersNodes']());}}}return _0x531634;}function lr(_0x40c631,_0x4d186a){return _0x40c631['eventCache']['isCompleteForChild'](_0x4d186a);}function ku(_0x534e79,_0x20cd88,_0x50aa66,_0x4a66fc,_0x311dd3,_0x1b8b19,_0x4b8087){let _0x328171=_0x20cd88;return _0x4a66fc['foreach']((_0x1ca07e,_0x595457)=>{const _0x544206=k(_0x50aa66,_0x1ca07e);lr(_0x20cd88,y(_0x544206))&&(_0x328171=ki(_0x534e79,_0x328171,_0x544206,_0x595457,_0x311dd3,_0x1b8b19,_0x4b8087));}),_0x4a66fc['foreach']((_0x298173,_0xef0cdd)=>{const _0x37a1c5=k(_0x50aa66,_0x298173);lr(_0x20cd88,y(_0x37a1c5))||(_0x328171=ki(_0x534e79,_0x328171,_0x37a1c5,_0xef0cdd,_0x311dd3,_0x1b8b19,_0x4b8087));}),_0x328171;}function hr(_0x5c4ad3,_0x3c91da,_0xe33a14){return _0xe33a14['foreach']((_0x3655fd,_0x5bab6f)=>{_0x3c91da=_0x3c91da['updateChild'](_0x3655fd,_0x5bab6f);}),_0x3c91da;}function Pi(_0x5779fa,_0x11e010,_0x4fcae5,_0x19c549,_0x500b18,_0x98140b,_0xe25458,_0x28e31c){if(_0x11e010['serverCache']['getNode']()['isEmpty']()&&!_0x11e010['serverCache']['isFullyInitialized']())return _0x11e010;let _0x2129ae=_0x11e010,_0x4918eb;v(_0x4fcae5)?_0x4918eb=_0x19c549:_0x4918eb=new b(null)['setTree'](_0x4fcae5,_0x19c549);const _0x1875f6=_0x11e010['serverCache']['getNode']();return _0x4918eb['children']['inorderTraversal']((_0x8116f9,_0x1544e5)=>{if(_0x1875f6['hasChild'](_0x8116f9)){const _0x5b3992=_0x11e010['serverCache']['getNode']()['getImmediateChild'](_0x8116f9),_0x16787e=hr(_0x5779fa,_0x5b3992,_0x1544e5);_0x2129ae=Sn(_0x5779fa,_0x2129ae,new C(_0x8116f9),_0x16787e,_0x500b18,_0x98140b,_0xe25458,_0x28e31c);}}),_0x4918eb['children']['inorderTraversal']((_0x4ee3f7,_0x2d5e9b)=>{const _0x3db5ef=!_0x11e010['serverCache']['isCompleteForChild'](_0x4ee3f7)&&_0x2d5e9b['value']===null;if(!_0x1875f6['hasChild'](_0x4ee3f7)&&!_0x3db5ef){const _0xdb6a04=_0x11e010['serverCache']['getNode']()['getImmediateChild'](_0x4ee3f7),_0xe9af2a=hr(_0x5779fa,_0xdb6a04,_0x2d5e9b);_0x2129ae=Sn(_0x5779fa,_0x2129ae,new C(_0x4ee3f7),_0xe9af2a,_0x500b18,_0x98140b,_0xe25458,_0x28e31c);}}),_0x2129ae;}function Pu(_0x33ddf0,_0x5e15c6,_0x4edd1d,_0x1b432a,_0x1f45a7,_0x39e85b,_0x2269f5){if(Tn(_0x1f45a7,_0x4edd1d)!=null)return _0x5e15c6;const _0x5cc75a=_0x5e15c6['serverCache']['isFiltered'](),_0x5dbeb2=_0x5e15c6['serverCache'];if(_0x1b432a['value']!=null){if(v(_0x4edd1d)&&_0x5dbeb2['isFullyInitialized']()||_0x5dbeb2['isCompleteForPath'](_0x4edd1d))return Sn(_0x33ddf0,_0x5e15c6,_0x4edd1d,_0x5dbeb2['getNode']()['getChild'](_0x4edd1d),_0x1f45a7,_0x39e85b,_0x5cc75a,_0x2269f5);if(v(_0x4edd1d)){let _0x289d44=new b(null);return _0x5dbeb2['getNode']()['forEachChild'](ve,(_0x412f3c,_0x8d506)=>{_0x289d44=_0x289d44['set'](new C(_0x412f3c),_0x8d506);}),Pi(_0x33ddf0,_0x5e15c6,_0x4edd1d,_0x289d44,_0x1f45a7,_0x39e85b,_0x5cc75a,_0x2269f5);}else return _0x5e15c6;}else{let _0x5b8eb5=new b(null);return _0x1b432a['foreach']((_0x5e95d5,_0x31d079)=>{const _0x97bf0b=k(_0x4edd1d,_0x5e95d5);_0x5dbeb2['isCompleteForPath'](_0x97bf0b)&&(_0x5b8eb5=_0x5b8eb5['set'](_0x5e95d5,_0x5dbeb2['getNode']()['getChild'](_0x97bf0b)));}),Pi(_0x33ddf0,_0x5e15c6,_0x4edd1d,_0x5b8eb5,_0x1f45a7,_0x39e85b,_0x5cc75a,_0x2269f5);}}function Nu(_0x425aff,_0x45d1d6,_0x16a278,_0x3541b1,_0x5ec7c0){const _0xd30043=_0x45d1d6['serverCache'],_0x4e977f=Fo(_0x45d1d6,_0xd30043['getNode'](),_0xd30043['isFullyInitialized']()||v(_0x16a278),_0xd30043['isFiltered']());return Go(_0x425aff,_0x4e977f,_0x16a278,_0x3541b1,$o,_0x5ec7c0);}function Ou(_0x2d4eaf,_0x22d5bf,_0x155ec0,_0x2233e3,_0x218a07,_0x3e17a8){let _0x43f19c;if(Tn(_0x2233e3,_0x155ec0)!=null)return _0x22d5bf;{const _0x5d5e51=new rs(_0x2233e3,_0x22d5bf,_0x218a07),_0x5822c3=_0x22d5bf['eventCache']['getNode']();let _0x57fd48;if(v(_0x155ec0)||y(_0x155ec0)==='.priority'){let _0x5b7bd4;if(_0x22d5bf['serverCache']['isFullyInitialized']())_0x5b7bd4=Cn(_0x2233e3,Ve(_0x22d5bf));else{const _0xdd7ac3=_0x22d5bf['serverCache']['getNode']();f(_0xdd7ac3 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5b7bd4=is(_0x2233e3,_0xdd7ac3);}_0x5b7bd4=_0x5b7bd4,_0x57fd48=_0x2d4eaf['filter']['updateFullNode'](_0x5822c3,_0x5b7bd4,_0x3e17a8);}else{const _0x48853a=y(_0x155ec0);let _0x32a1f2=ss(_0x2233e3,_0x48853a,_0x22d5bf['serverCache']);_0x32a1f2==null&&_0x22d5bf['serverCache']['isCompleteForChild'](_0x48853a)&&(_0x32a1f2=_0x5822c3['getImmediateChild'](_0x48853a)),_0x32a1f2!=null?_0x57fd48=_0x2d4eaf['filter']['updateChild'](_0x5822c3,_0x48853a,_0x32a1f2,S(_0x155ec0),_0x5d5e51,_0x3e17a8):_0x22d5bf['eventCache']['getNode']()['hasChild'](_0x48853a)?_0x57fd48=_0x2d4eaf['filter']['updateChild'](_0x5822c3,_0x48853a,g['EMPTY_NODE'],S(_0x155ec0),_0x5d5e51,_0x3e17a8):_0x57fd48=_0x5822c3,_0x57fd48['isEmpty']()&&_0x22d5bf['serverCache']['isFullyInitialized']()&&(_0x43f19c=Cn(_0x2233e3,Ve(_0x22d5bf)),_0x43f19c['isLeafNode']()&&(_0x57fd48=_0x2d4eaf['filter']['updateFullNode'](_0x57fd48,_0x43f19c,_0x3e17a8)));}return _0x43f19c=_0x22d5bf['serverCache']['isFullyInitialized']()||Tn(_0x2233e3,w())!=null,Rt(_0x22d5bf,_0x57fd48,_0x43f19c,_0x2d4eaf['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5c9263,_0x219c1a){this['query_']=_0x5c9263,this['eventRegistrations_']=[];const _0x588762=this['query_']['_queryParams'],_0x16dbb5=new Xi(_0x588762['getIndex']()),_0xb31a2=Kh(_0x588762);this['processor_']=Su(_0xb31a2);const _0x3c9375=_0x219c1a['serverCache'],_0x3d9ab9=_0x219c1a['eventCache'],_0x2b2848=_0x16dbb5['updateFullNode'](g['EMPTY_NODE'],_0x3c9375['getNode'](),null),_0xd8c0e8=_0xb31a2['updateFullNode'](g['EMPTY_NODE'],_0x3d9ab9['getNode'](),null),_0x1e9222=new Te(_0x2b2848,_0x3c9375['isFullyInitialized'](),_0x16dbb5['filtersNodes']()),_0x52df7a=new Te(_0xd8c0e8,_0x3d9ab9['isFullyInitialized'](),_0xb31a2['filtersNodes']());this['viewCache_']=Un(_0x52df7a,_0x1e9222),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1f8cba){return _0x1f8cba['viewCache_']['serverCache']['getNode']();}function Lu(_0x50562c){return wn(_0x50562c['viewCache_']);}function xu(_0x48076e,_0x2d3212){const _0x3252a9=Ve(_0x48076e['viewCache_']);return _0x3252a9&&(_0x48076e['query']['_queryParams']['loadsAllData']()||!v(_0x2d3212)&&!_0x3252a9['getImmediateChild'](y(_0x2d3212))['isEmpty']())?_0x3252a9['getChild'](_0x2d3212):null;}function ur(_0x44ca89){return _0x44ca89['eventRegistrations_']['length']===0x0;}function Fu(_0x56562c,_0x4dcab5){_0x56562c['eventRegistrations_']['push'](_0x4dcab5);}function dr(_0x2ea12b,_0x20be49,_0x182c99){const _0x24bf03=[];if(_0x182c99){f(_0x20be49==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3fa69b=_0x2ea12b['query']['_path'];_0x2ea12b['eventRegistrations_']['forEach'](_0x19451c=>{const _0x4e6357=_0x19451c['createCancelEvent'](_0x182c99,_0x3fa69b);_0x4e6357&&_0x24bf03['push'](_0x4e6357);});}if(_0x20be49){let _0x10d90c=[];for(let _0x39bd58=0x0;_0x39bd58<_0x2ea12b['eventRegistrations_']['length'];++_0x39bd58){const _0x1eef19=_0x2ea12b['eventRegistrations_'][_0x39bd58];if(!_0x1eef19['matches'](_0x20be49))_0x10d90c['push'](_0x1eef19);else{if(_0x20be49['hasAnyCallback']()){_0x10d90c=_0x10d90c['concat'](_0x2ea12b['eventRegistrations_']['slice'](_0x39bd58+0x1));break;}}}_0x2ea12b['eventRegistrations_']=_0x10d90c;}else _0x2ea12b['eventRegistrations_']=[];return _0x24bf03;}function fr(_0x2c596e,_0x82f9ba,_0x22bfa6,_0x2dcc57){_0x82f9ba['type']===z['MERGE']&&_0x82f9ba['source']['queryId']!==null&&(f(Ve(_0x2c596e['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2c596e['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5cc81b=_0x2c596e['viewCache_'],_0x3c069e=Ru(_0x2c596e['processor_'],_0x5cc81b,_0x82f9ba,_0x22bfa6,_0x2dcc57);return bu(_0x2c596e['processor_'],_0x3c069e['viewCache']),f(_0x3c069e['viewCache']['serverCache']['isFullyInitialized']()||!_0x5cc81b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2c596e['viewCache_']=_0x3c069e['viewCache'],qo(_0x2c596e,_0x3c069e['changes'],_0x3c069e['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x41f238,_0x3c181c){const _0x403cef=_0x41f238['viewCache_']['eventCache'],_0x40d1ce=[];return _0x403cef['getNode']()['isLeafNode']()||_0x403cef['getNode']()['forEachChild'](R,(_0x506038,_0x3cf1f5)=>{_0x40d1ce['push'](rt(_0x506038,_0x3cf1f5));}),_0x403cef['isFullyInitialized']()&&_0x40d1ce['push'](Lo(_0x403cef['getNode']())),qo(_0x41f238,_0x40d1ce,_0x403cef['getNode'](),_0x3c181c);}function qo(_0x3f1516,_0x5abf2b,_0x1c23eb,_0x4f1e21){const _0xc535cd=_0x4f1e21?[_0x4f1e21]:_0x3f1516['eventRegistrations_'];return ru(_0x3f1516['eventGenerator_'],_0x5abf2b,_0x1c23eb,_0xc535cd);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x5682cd){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x5682cd;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x2d2b23){return _0x2d2b23['views']['size']===0x0;}function os(_0x258336,_0x18f1d3,_0x408406,_0xd1bfe0){const _0x508d08=_0x18f1d3['source']['queryId'];if(_0x508d08!==null){const _0x32fa55=_0x258336['views']['get'](_0x508d08);return f(_0x32fa55!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x32fa55,_0x18f1d3,_0x408406,_0xd1bfe0);}else{let _0x25fd10=[];for(const _0x39f912 of _0x258336['views']['values']())_0x25fd10=_0x25fd10['concat'](fr(_0x39f912,_0x18f1d3,_0x408406,_0xd1bfe0));return _0x25fd10;}}function jo(_0x250d2b,_0x1b120c,_0x4b6181,_0x29e857,_0x4b6ec7){const _0x33a9c5=_0x1b120c['_queryIdentifier'],_0x239058=_0x250d2b['views']['get'](_0x33a9c5);if(!_0x239058){let _0x279cf7=Cn(_0x4b6181,_0x4b6ec7?_0x29e857:null),_0x5b9d11=!0x1;_0x279cf7?_0x5b9d11=!0x0:_0x29e857 instanceof g?(_0x279cf7=is(_0x4b6181,_0x29e857),_0x5b9d11=!0x1):(_0x279cf7=g['EMPTY_NODE'],_0x5b9d11=!0x1);const _0x38b90c=Un(new Te(_0x279cf7,_0x5b9d11,!0x1),new Te(_0x29e857,_0x4b6ec7,!0x1));return new Du(_0x1b120c,_0x38b90c);}return _0x239058;}function Hu(_0x506709,_0x1b23e3,_0x21f726,_0x231d77,_0x5dad65,_0xb437e7){const _0x2a8a62=jo(_0x506709,_0x1b23e3,_0x231d77,_0x5dad65,_0xb437e7);return _0x506709['views']['has'](_0x1b23e3['_queryIdentifier'])||_0x506709['views']['set'](_0x1b23e3['_queryIdentifier'],_0x2a8a62),Fu(_0x2a8a62,_0x21f726),Uu(_0x2a8a62,_0x21f726);}function $u(_0x59ed93,_0x15d4ff,_0x26de6f,_0xce9b0c){const _0x1e63a3=_0x15d4ff['_queryIdentifier'],_0x1cf71c=[];let _0x1d862b=[];const _0x53cdea=Se(_0x59ed93);if(_0x1e63a3==='default'){for(const [_0x25b812,_0x4f3110]of _0x59ed93['views']['entries']())_0x1d862b=_0x1d862b['concat'](dr(_0x4f3110,_0x26de6f,_0xce9b0c)),ur(_0x4f3110)&&(_0x59ed93['views']['delete'](_0x25b812),_0x4f3110['query']['_queryParams']['loadsAllData']()||_0x1cf71c['push'](_0x4f3110['query']));}else{const _0x595beb=_0x59ed93['views']['get'](_0x1e63a3);_0x595beb&&(_0x1d862b=_0x1d862b['concat'](dr(_0x595beb,_0x26de6f,_0xce9b0c)),ur(_0x595beb)&&(_0x59ed93['views']['delete'](_0x1e63a3),_0x595beb['query']['_queryParams']['loadsAllData']()||_0x1cf71c['push'](_0x595beb['query'])));}return _0x53cdea&&!Se(_0x59ed93)&&_0x1cf71c['push'](new(Bu())(_0x15d4ff['_repo'],_0x15d4ff['_path'])),{'removed':_0x1cf71c,'events':_0x1d862b};}function Ko(_0x273d76){const _0x5a5352=[];for(const _0x5ebb86 of _0x273d76['views']['values']())_0x5ebb86['query']['_queryParams']['loadsAllData']()||_0x5a5352['push'](_0x5ebb86);return _0x5a5352;}function Ie(_0x42a2d1,_0x1086ba){let _0x3f5049=null;for(const _0x31f1f6 of _0x42a2d1['views']['values']())_0x3f5049=_0x3f5049||xu(_0x31f1f6,_0x1086ba);return _0x3f5049;}function Yo(_0x3bad60,_0x5635bb){if(_0x5635bb['_queryParams']['loadsAllData']())return Bn(_0x3bad60);{const _0x2262cf=_0x5635bb['_queryIdentifier'];return _0x3bad60['views']['get'](_0x2262cf);}}function Qo(_0x57cc3b,_0x4cd8dd){return Yo(_0x57cc3b,_0x4cd8dd)!=null;}function Se(_0x2d2b16){return Bn(_0x2d2b16)!=null;}function Bn(_0x1487f7){for(const _0x694359 of _0x1487f7['views']['values']())if(_0x694359['query']['_queryParams']['loadsAllData']())return _0x694359;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x4ab3b0){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x4ab3b0;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3941a5){this['listenProvider_']=_0x3941a5,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x586c5a,_0x1ebe6b,_0x54e225,_0x5cd1c1,_0x14c0c5){return lu(_0x586c5a['pendingWriteTree_'],_0x1ebe6b,_0x54e225,_0x5cd1c1,_0x14c0c5),_0x14c0c5?_t(_0x586c5a,new Be(es(),_0x1ebe6b,_0x54e225)):[];}function ju(_0x5dc360,_0x140d70,_0x39579b,_0x3cd3fa){hu(_0x5dc360['pendingWriteTree_'],_0x140d70,_0x39579b,_0x3cd3fa);const _0x1955b1=b['fromObject'](_0x39579b);return _t(_0x5dc360,new ot(es(),_0x140d70,_0x1955b1));}function _e(_0x1500ef,_0xa8d791,_0x281111=!0x1){const _0x52b62e=uu(_0x1500ef['pendingWriteTree_'],_0xa8d791);if(du(_0x1500ef['pendingWriteTree_'],_0xa8d791)){let _0xb84c96=new b(null);return _0x52b62e['snap']!=null?_0xb84c96=_0xb84c96['set'](w(),!0x0):x(_0x52b62e['children'],_0x5105c2=>{_0xb84c96=_0xb84c96['set'](new C(_0x5105c2),!0x0);}),_t(_0x1500ef,new In(_0x52b62e['path'],_0xb84c96,_0x281111));}else return[];}function Yt(_0x4094d1,_0x46ed0f,_0xb97b12){return _t(_0x4094d1,new Be(ts(),_0x46ed0f,_0xb97b12));}function Ku(_0x57837b,_0x432f5d,_0x49151e){const _0x483ef0=b['fromObject'](_0x49151e);return _t(_0x57837b,new ot(ts(),_0x432f5d,_0x483ef0));}function Yu(_0x507e7f,_0x3a074d){return _t(_0x507e7f,new Ut(ts(),_0x3a074d));}function Qu(_0x7c9d52,_0xc3c87d,_0x2b74c){const _0x33ee88=cs(_0x7c9d52,_0x2b74c);if(_0x33ee88){const _0x2fe101=ls(_0x33ee88),_0x171886=_0x2fe101['path'],_0x53f5a3=_0x2fe101['queryId'],_0x34bbbc=F(_0x171886,_0xc3c87d),_0x1ec87c=new Ut(ns(_0x53f5a3),_0x34bbbc);return hs(_0x7c9d52,_0x171886,_0x1ec87c);}else return[];}function An(_0x5abab2,_0x405c4c,_0x2368b6,_0x4723bb,_0x5c0240=!0x1){const _0x4a2c17=_0x405c4c['_path'],_0x516d6a=_0x5abab2['syncPointTree_']['get'](_0x4a2c17);let _0x498c49=[];if(_0x516d6a&&(_0x405c4c['_queryIdentifier']==='default'||Qo(_0x516d6a,_0x405c4c))){const _0x1f3a94=$u(_0x516d6a,_0x405c4c,_0x2368b6,_0x4723bb);Vu(_0x516d6a)&&(_0x5abab2['syncPointTree_']=_0x5abab2['syncPointTree_']['remove'](_0x4a2c17));const _0x3c37de=_0x1f3a94['removed'];if(_0x498c49=_0x1f3a94['events'],!_0x5c0240){const _0x2b97be=_0x3c37de['findIndex'](_0x541160=>_0x541160['_queryParams']['loadsAllData']())!==-0x1,_0xc998f5=_0x5abab2['syncPointTree_']['findOnPath'](_0x4a2c17,(_0x1031ce,_0x39ba6e)=>Se(_0x39ba6e));if(_0x2b97be&&!_0xc998f5){const _0xabdfa=_0x5abab2['syncPointTree_']['subtree'](_0x4a2c17);if(!_0xabdfa['isEmpty']()){const _0x58ed9f=Zu(_0xabdfa);for(let _0x4df331=0x0;_0x4df331<_0x58ed9f['length'];++_0x4df331){const _0x1f1158=_0x58ed9f[_0x4df331],_0x3fc045=_0x1f1158['query'],_0x708b3e=ea(_0x5abab2,_0x1f1158);_0x5abab2['listenProvider_']['startListening'](kt(_0x3fc045),Wt(_0x5abab2,_0x3fc045),_0x708b3e['hashFn'],_0x708b3e['onComplete']);}}}!_0xc998f5&&_0x3c37de['length']>0x0&&!_0x4723bb&&(_0x2b97be?_0x5abab2['listenProvider_']['stopListening'](kt(_0x405c4c),null):_0x3c37de['forEach'](_0x4d353d=>{const _0x563696=_0x5abab2['queryToTagMap']['get'](Hn(_0x4d353d));_0x5abab2['listenProvider_']['stopListening'](kt(_0x4d353d),_0x563696);}));}ed(_0x5abab2,_0x3c37de);}return _0x498c49;}function Jo(_0x16759e,_0x2edecc,_0x35719b,_0x229774){const _0x5251a0=cs(_0x16759e,_0x229774);if(_0x5251a0!=null){const _0x3db8c8=ls(_0x5251a0),_0x440d7b=_0x3db8c8['path'],_0x3315a5=_0x3db8c8['queryId'],_0x24d836=F(_0x440d7b,_0x2edecc),_0x3696d3=new Be(ns(_0x3315a5),_0x24d836,_0x35719b);return hs(_0x16759e,_0x440d7b,_0x3696d3);}else return[];}function Ju(_0x1a4f0f,_0x24f3f3,_0x117dfe,_0xf0545f){const _0x4a33ba=cs(_0x1a4f0f,_0xf0545f);if(_0x4a33ba){const _0x1905e8=ls(_0x4a33ba),_0x55b2bd=_0x1905e8['path'],_0x2f9140=_0x1905e8['queryId'],_0x4f71e1=F(_0x55b2bd,_0x24f3f3),_0x2c0767=b['fromObject'](_0x117dfe),_0x3b2912=new ot(ns(_0x2f9140),_0x4f71e1,_0x2c0767);return hs(_0x1a4f0f,_0x55b2bd,_0x3b2912);}else return[];}function Ni(_0x4929d2,_0x38282e,_0x41fd9c,_0x490006=!0x1){const _0x153fd1=_0x38282e['_path'];let _0x4c3d13=null,_0x25ca71=!0x1;_0x4929d2['syncPointTree_']['foreachOnPath'](_0x153fd1,(_0x42dc41,_0x37c7da)=>{const _0x7b08ec=F(_0x42dc41,_0x153fd1);_0x4c3d13=_0x4c3d13||Ie(_0x37c7da,_0x7b08ec),_0x25ca71=_0x25ca71||Se(_0x37c7da);});let _0xa9815d=_0x4929d2['syncPointTree_']['get'](_0x153fd1);_0xa9815d?(_0x25ca71=_0x25ca71||Se(_0xa9815d),_0x4c3d13=_0x4c3d13||Ie(_0xa9815d,w())):(_0xa9815d=new zo(),_0x4929d2['syncPointTree_']=_0x4929d2['syncPointTree_']['set'](_0x153fd1,_0xa9815d));let _0x14e5dc;_0x4c3d13!=null?_0x14e5dc=!0x0:(_0x14e5dc=!0x1,_0x4c3d13=g['EMPTY_NODE'],_0x4929d2['syncPointTree_']['subtree'](_0x153fd1)['foreachChild']((_0x11b5ac,_0x57d831)=>{const _0x41c411=Ie(_0x57d831,w());_0x41c411&&(_0x4c3d13=_0x4c3d13['updateImmediateChild'](_0x11b5ac,_0x41c411));}));const _0x162ae6=Qo(_0xa9815d,_0x38282e);if(!_0x162ae6&&!_0x38282e['_queryParams']['loadsAllData']()){const _0x3dc3d6=Hn(_0x38282e);f(!_0x4929d2['queryToTagMap']['has'](_0x3dc3d6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x366068=td();_0x4929d2['queryToTagMap']['set'](_0x3dc3d6,_0x366068),_0x4929d2['tagToQueryMap']['set'](_0x366068,_0x3dc3d6);}const _0x3583a4=Wn(_0x4929d2['pendingWriteTree_'],_0x153fd1);let _0x7c13a3=Hu(_0xa9815d,_0x38282e,_0x41fd9c,_0x3583a4,_0x4c3d13,_0x14e5dc);if(!_0x162ae6&&!_0x25ca71&&!_0x490006){const _0x25fe0d=Yo(_0xa9815d,_0x38282e);_0x7c13a3=_0x7c13a3['concat'](nd(_0x4929d2,_0x38282e,_0x25fe0d));}return _0x7c13a3;}function Vn(_0x77610d,_0x11a221,_0x13d4df){const _0x660e99=_0x77610d['pendingWriteTree_'],_0x88d4fa=_0x77610d['syncPointTree_']['findOnPath'](_0x11a221,(_0x28d4f7,_0xd47f1)=>{const _0x26420d=F(_0x28d4f7,_0x11a221),_0x2f709f=Ie(_0xd47f1,_0x26420d);if(_0x2f709f)return _0x2f709f;});return Bo(_0x660e99,_0x11a221,_0x88d4fa,_0x13d4df,!0x0);}function Xu(_0x3f3cb4,_0xd3e880){const _0x4bfc15=_0xd3e880['_path'];let _0x29c484=null;_0x3f3cb4['syncPointTree_']['foreachOnPath'](_0x4bfc15,(_0x960efb,_0x3a7d0e)=>{const _0x508cb4=F(_0x960efb,_0x4bfc15);_0x29c484=_0x29c484||Ie(_0x3a7d0e,_0x508cb4);});let _0x3e1c10=_0x3f3cb4['syncPointTree_']['get'](_0x4bfc15);_0x3e1c10?_0x29c484=_0x29c484||Ie(_0x3e1c10,w()):(_0x3e1c10=new zo(),_0x3f3cb4['syncPointTree_']=_0x3f3cb4['syncPointTree_']['set'](_0x4bfc15,_0x3e1c10));const _0x555941=_0x29c484!=null,_0xc9deaa=_0x555941?new Te(_0x29c484,!0x0,!0x1):null,_0x33ebb2=Wn(_0x3f3cb4['pendingWriteTree_'],_0xd3e880['_path']),_0x3cd465=jo(_0x3e1c10,_0xd3e880,_0x33ebb2,_0x555941?_0xc9deaa['getNode']():g['EMPTY_NODE'],_0x555941);return Lu(_0x3cd465);}function _t(_0x2e6850,_0x47c0b7){return Xo(_0x47c0b7,_0x2e6850['syncPointTree_'],null,Wn(_0x2e6850['pendingWriteTree_'],w()));}function Xo(_0x217b30,_0x43c070,_0x23495d,_0x19aecd){if(v(_0x217b30['path']))return Zo(_0x217b30,_0x43c070,_0x23495d,_0x19aecd);{const _0x5f397a=_0x43c070['get'](w());_0x23495d==null&&_0x5f397a!=null&&(_0x23495d=Ie(_0x5f397a,w()));let _0x18c757=[];const _0x6eb91d=y(_0x217b30['path']),_0x45e18d=_0x217b30['operationForChild'](_0x6eb91d),_0x6adadb=_0x43c070['children']['get'](_0x6eb91d);if(_0x6adadb&&_0x45e18d){const _0x105d94=_0x23495d?_0x23495d['getImmediateChild'](_0x6eb91d):null,_0x2dfb0b=Vo(_0x19aecd,_0x6eb91d);_0x18c757=_0x18c757['concat'](Xo(_0x45e18d,_0x6adadb,_0x105d94,_0x2dfb0b));}return _0x5f397a&&(_0x18c757=_0x18c757['concat'](os(_0x5f397a,_0x217b30,_0x19aecd,_0x23495d))),_0x18c757;}}function Zo(_0x534e07,_0x54f36f,_0x30d4c1,_0x490a29){const _0x3d2b20=_0x54f36f['get'](w());_0x30d4c1==null&&_0x3d2b20!=null&&(_0x30d4c1=Ie(_0x3d2b20,w()));let _0x4b2514=[];return _0x54f36f['children']['inorderTraversal']((_0x432a75,_0x39efe5)=>{const _0x3065dc=_0x30d4c1?_0x30d4c1['getImmediateChild'](_0x432a75):null,_0x22eb58=Vo(_0x490a29,_0x432a75),_0x588362=_0x534e07['operationForChild'](_0x432a75);_0x588362&&(_0x4b2514=_0x4b2514['concat'](Zo(_0x588362,_0x39efe5,_0x3065dc,_0x22eb58)));}),_0x3d2b20&&(_0x4b2514=_0x4b2514['concat'](os(_0x3d2b20,_0x534e07,_0x490a29,_0x30d4c1))),_0x4b2514;}function ea(_0x3613b4,_0x425338){const _0x5291d5=_0x425338['query'],_0x408e1d=Wt(_0x3613b4,_0x5291d5);return{'hashFn':()=>(Mu(_0x425338)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x55060a=>{if(_0x55060a==='ok')return _0x408e1d?Qu(_0x3613b4,_0x5291d5['_path'],_0x408e1d):Yu(_0x3613b4,_0x5291d5['_path']);{const _0x111c86=Kl(_0x55060a,_0x5291d5);return An(_0x3613b4,_0x5291d5,null,_0x111c86);}}};}function Wt(_0x15da43,_0x46f757){const _0x93accb=Hn(_0x46f757);return _0x15da43['queryToTagMap']['get'](_0x93accb);}function Hn(_0x3b1423){return _0x3b1423['_path']['toString']()+'$'+_0x3b1423['_queryIdentifier'];}function cs(_0x58bcda,_0x2f28ca){return _0x58bcda['tagToQueryMap']['get'](_0x2f28ca);}function ls(_0x434261){const _0x122a14=_0x434261['indexOf']('$');return f(_0x122a14!==-0x1&&_0x122a14<_0x434261['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x434261['substr'](_0x122a14+0x1),'path':new C(_0x434261['substr'](0x0,_0x122a14))};}function hs(_0x4e0158,_0x3da209,_0x19019c){const _0x31a059=_0x4e0158['syncPointTree_']['get'](_0x3da209);f(_0x31a059,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x147f38=Wn(_0x4e0158['pendingWriteTree_'],_0x3da209);return os(_0x31a059,_0x19019c,_0x147f38,null);}function Zu(_0x17bd53){return _0x17bd53['fold']((_0x15fda9,_0x35e501,_0x1c569a)=>{if(_0x35e501&&Se(_0x35e501))return[Bn(_0x35e501)];{let _0x1ebe42=[];return _0x35e501&&(_0x1ebe42=Ko(_0x35e501)),x(_0x1c569a,(_0x3f0532,_0x2f50c8)=>{_0x1ebe42=_0x1ebe42['concat'](_0x2f50c8);}),_0x1ebe42;}});}function kt(_0xeee2bd){return _0xeee2bd['_queryParams']['loadsAllData']()&&!_0xeee2bd['_queryParams']['isDefault']()?new(qu())(_0xeee2bd['_repo'],_0xeee2bd['_path']):_0xeee2bd;}function ed(_0x40f3b9,_0x13a4d6){for(let _0x5984fb=0x0;_0x5984fb<_0x13a4d6['length'];++_0x5984fb){const _0xebfa68=_0x13a4d6[_0x5984fb];if(!_0xebfa68['_queryParams']['loadsAllData']()){const _0x4c23fe=Hn(_0xebfa68),_0x4bb615=_0x40f3b9['queryToTagMap']['get'](_0x4c23fe);_0x40f3b9['queryToTagMap']['delete'](_0x4c23fe),_0x40f3b9['tagToQueryMap']['delete'](_0x4bb615);}}}function td(){return zu++;}function nd(_0x1b47e8,_0xc0e92c,_0x4ec579){const _0x4a6c1c=_0xc0e92c['_path'],_0x29ee41=Wt(_0x1b47e8,_0xc0e92c),_0x2be14c=ea(_0x1b47e8,_0x4ec579),_0x5b7985=_0x1b47e8['listenProvider_']['startListening'](kt(_0xc0e92c),_0x29ee41,_0x2be14c['hashFn'],_0x2be14c['onComplete']),_0x33849d=_0x1b47e8['syncPointTree_']['subtree'](_0x4a6c1c);if(_0x29ee41)f(!Se(_0x33849d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3887b0=_0x33849d['fold']((_0x3496d6,_0x716352,_0x225eea)=>{if(!v(_0x3496d6)&&_0x716352&&Se(_0x716352))return[Bn(_0x716352)['query']];{let _0x35e775=[];return _0x716352&&(_0x35e775=_0x35e775['concat'](Ko(_0x716352)['map'](_0x14911b=>_0x14911b['query']))),x(_0x225eea,(_0x55f28a,_0x3f4dd6)=>{_0x35e775=_0x35e775['concat'](_0x3f4dd6);}),_0x35e775;}});for(let _0x5e4ac8=0x0;_0x5e4ac8<_0x3887b0['length'];++_0x5e4ac8){const _0x2818e5=_0x3887b0[_0x5e4ac8];_0x1b47e8['listenProvider_']['stopListening'](kt(_0x2818e5),Wt(_0x1b47e8,_0x2818e5));}}return _0x5b7985;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x2948bd){this['node_']=_0x2948bd;}['getImmediateChild'](_0x1b4fc7){const _0x594eb0=this['node_']['getImmediateChild'](_0x1b4fc7);return new us(_0x594eb0);}['node'](){return this['node_'];}}class ds{constructor(_0x2b1717,_0x373721){this['syncTree_']=_0x2b1717,this['path_']=_0x373721;}['getImmediateChild'](_0x1ec405){const _0x2f8511=k(this['path_'],_0x1ec405);return new ds(this['syncTree_'],_0x2f8511);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x4eeb94){return _0x4eeb94=_0x4eeb94||{},_0x4eeb94['timestamp']=_0x4eeb94['timestamp']||new Date()['getTime'](),_0x4eeb94;},_r=function(_0x22a195,_0x431a83,_0x241165){if(!_0x22a195||typeof _0x22a195!='object')return _0x22a195;if(f('.sv'in _0x22a195,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x22a195['.sv']=='string')return sd(_0x22a195['.sv'],_0x431a83,_0x241165);if(typeof _0x22a195['.sv']=='object')return rd(_0x22a195['.sv'],_0x431a83);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x22a195,null,0x2));},sd=function(_0x2b284b,_0x2426e5,_0x528d55){switch(_0x2b284b){case'timestamp':return _0x528d55['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2b284b);}},rd=function(_0x4a4e76,_0x48fa59,_0x21b105){_0x4a4e76['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4a4e76,null,0x2));const _0x49550e=_0x4a4e76['increment'];typeof _0x49550e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x49550e);const _0x4c9402=_0x48fa59['node']();if(f(_0x4c9402!==null&&typeof _0x4c9402<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4c9402['isLeafNode']())return _0x49550e;const _0x467d33=_0x4c9402['getValue']();return typeof _0x467d33!='number'?_0x49550e:_0x467d33+_0x49550e;},ta=function(_0x5b3293,_0x32155b,_0x54020e,_0xc47a5){return ps(_0x32155b,new ds(_0x54020e,_0x5b3293),_0xc47a5);},fs=function(_0x228167,_0x45aa31,_0xdb3ae7){return ps(_0x228167,new us(_0x45aa31),_0xdb3ae7);};function ps(_0x4ef0fe,_0x323368,_0x333404){const _0x20ded7=_0x4ef0fe['getPriority']()['val'](),_0x5a337d=_r(_0x20ded7,_0x323368['getImmediateChild']('.priority'),_0x333404);let _0x33bf1f;if(_0x4ef0fe['isLeafNode']()){const _0x42aead=_0x4ef0fe,_0xc33d9f=_r(_0x42aead['getValue'](),_0x323368,_0x333404);return _0xc33d9f!==_0x42aead['getValue']()||_0x5a337d!==_0x42aead['getPriority']()['val']()?new D(_0xc33d9f,A(_0x5a337d)):_0x4ef0fe;}else{const _0x1e3adb=_0x4ef0fe;return _0x33bf1f=_0x1e3adb,_0x5a337d!==_0x1e3adb['getPriority']()['val']()&&(_0x33bf1f=_0x33bf1f['updatePriority'](new D(_0x5a337d))),_0x1e3adb['forEachChild'](R,(_0x3757f0,_0xdb335d)=>{const _0x37aea1=ps(_0xdb335d,_0x323368['getImmediateChild'](_0x3757f0),_0x333404);_0x37aea1!==_0xdb335d&&(_0x33bf1f=_0x33bf1f['updateImmediateChild'](_0x3757f0,_0x37aea1));}),_0x33bf1f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x239424='',_0x516b25=null,_0x3c4ab9={'children':{},'childCount':0x0}){this['name']=_0x239424,this['parent']=_0x516b25,this['node']=_0x3c4ab9;}}function $n(_0x8af291,_0x44dda3){let _0x2b22ce=_0x44dda3 instanceof C?_0x44dda3:new C(_0x44dda3),_0x2417fc=_0x8af291,_0x14715f=y(_0x2b22ce);for(;_0x14715f!==null;){const _0x472798=Le(_0x2417fc['node']['children'],_0x14715f)||{'children':{},'childCount':0x0};_0x2417fc=new _s(_0x14715f,_0x2417fc,_0x472798),_0x2b22ce=S(_0x2b22ce),_0x14715f=y(_0x2b22ce);}return _0x2417fc;}function je(_0x2872ca){return _0x2872ca['node']['value'];}function gs(_0x4994f9,_0x406028){_0x4994f9['node']['value']=_0x406028,Oi(_0x4994f9);}function na(_0x199b59){return _0x199b59['node']['childCount']>0x0;}function od(_0xd85bc8){return je(_0xd85bc8)===void 0x0&&!na(_0xd85bc8);}function Gn(_0x33974b,_0x1e4dca){x(_0x33974b['node']['children'],(_0x444835,_0xcd4d7c)=>{_0x1e4dca(new _s(_0x444835,_0x33974b,_0xcd4d7c));});}function ia(_0x23adf1,_0x179871,_0x371992,_0x4c2cb5){_0x371992&&_0x179871(_0x23adf1),Gn(_0x23adf1,_0x399310=>{ia(_0x399310,_0x179871,!0x0);});}function ad(_0x5c214b,_0x28184f,_0x2e9524){let _0x17d887=_0x5c214b['parent'];for(;_0x17d887!==null;){if(_0x28184f(_0x17d887))return!0x0;_0x17d887=_0x17d887['parent'];}return!0x1;}function Qt(_0x2d72fb){return new C(_0x2d72fb['parent']===null?_0x2d72fb['name']:Qt(_0x2d72fb['parent'])+'/'+_0x2d72fb['name']);}function Oi(_0xb25025){_0xb25025['parent']!==null&&cd(_0xb25025['parent'],_0xb25025['name'],_0xb25025);}function cd(_0x822243,_0x205142,_0x53634f){const _0x379bfc=od(_0x53634f),_0x4281ef=Q(_0x822243['node']['children'],_0x205142);_0x379bfc&&_0x4281ef?(delete _0x822243['node']['children'][_0x205142],_0x822243['node']['childCount']--,Oi(_0x822243)):!_0x379bfc&&!_0x4281ef&&(_0x822243['node']['children'][_0x205142]=_0x53634f['node'],_0x822243['node']['childCount']++,Oi(_0x822243));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x5b53e0){return typeof _0x5b53e0=='string'&&_0x5b53e0['length']!==0x0&&!ld['test'](_0x5b53e0);},sa=function(_0x3d65e1){return typeof _0x3d65e1=='string'&&_0x3d65e1['length']!==0x0&&!hd['test'](_0x3d65e1);},ud=function(_0x3d5410){return _0x3d5410&&(_0x3d5410=_0x3d5410['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3d5410);},Bt=function(_0x230b28){return _0x230b28===null||typeof _0x230b28=='string'||typeof _0x230b28=='number'&&!xn(_0x230b28)||_0x230b28&&typeof _0x230b28=='object'&&Q(_0x230b28,'.sv');},He=function(_0x1e64a5,_0x590b7c,_0x4b79ed,_0x3ea877){_0x3ea877&&_0x590b7c===void 0x0||Jt(it(_0x1e64a5,'value'),_0x590b7c,_0x4b79ed);},Jt=function(_0x4cefee,_0x3bc919,_0x1bfd8b){const _0x257c82=_0x1bfd8b instanceof C?new Ah(_0x1bfd8b,_0x4cefee):_0x1bfd8b;if(_0x3bc919===void 0x0)throw new Error(_0x4cefee+'contains\x20undefined\x20'+Oe(_0x257c82));if(typeof _0x3bc919=='function')throw new Error(_0x4cefee+'contains\x20a\x20function\x20'+Oe(_0x257c82)+'\x20with\x20contents\x20=\x20'+_0x3bc919['toString']());if(xn(_0x3bc919))throw new Error(_0x4cefee+'contains\x20'+_0x3bc919['toString']()+'\x20'+Oe(_0x257c82));if(typeof _0x3bc919=='string'&&_0x3bc919['length']>ui/0x3&&Ln(_0x3bc919)>ui)throw new Error(_0x4cefee+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x257c82)+'\x20(\x27'+_0x3bc919['substring'](0x0,0x32)+'...\x27)');if(_0x3bc919&&typeof _0x3bc919=='object'){let _0x2932ea=!0x1,_0x5952ad=!0x1;if(x(_0x3bc919,(_0xdc4f74,_0xc7c208)=>{if(_0xdc4f74==='.value')_0x2932ea=!0x0;else{if(_0xdc4f74!=='.priority'&&_0xdc4f74!=='.sv'&&(_0x5952ad=!0x0,!ms(_0xdc4f74)))throw new Error(_0x4cefee+'\x20contains\x20an\x20invalid\x20key\x20('+_0xdc4f74+')\x20'+Oe(_0x257c82)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x257c82,_0xdc4f74),Jt(_0x4cefee,_0xc7c208,_0x257c82),Ph(_0x257c82);}),_0x2932ea&&_0x5952ad)throw new Error(_0x4cefee+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x257c82)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1a3462,_0x470d75){let _0x5ee1a3,_0x1d10bb;for(_0x5ee1a3=0x0;_0x5ee1a3<_0x470d75['length'];_0x5ee1a3++){_0x1d10bb=_0x470d75[_0x5ee1a3];const _0x3b27e2=Mt(_0x1d10bb);for(let _0x4b629b=0x0;_0x4b629b<_0x3b27e2['length'];_0x4b629b++)if(!(_0x3b27e2[_0x4b629b]==='.priority'&&_0x4b629b===_0x3b27e2['length']-0x1)){if(!ms(_0x3b27e2[_0x4b629b]))throw new Error(_0x1a3462+'contains\x20an\x20invalid\x20key\x20('+_0x3b27e2[_0x4b629b]+')\x20in\x20path\x20'+_0x1d10bb['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x470d75['sort'](Rh);let _0x27ad85=null;for(_0x5ee1a3=0x0;_0x5ee1a3<_0x470d75['length'];_0x5ee1a3++){if(_0x1d10bb=_0x470d75[_0x5ee1a3],_0x27ad85!==null&&G(_0x27ad85,_0x1d10bb))throw new Error(_0x1a3462+'contains\x20a\x20path\x20'+_0x27ad85['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1d10bb['toString']());_0x27ad85=_0x1d10bb;}},ra=function(_0x21cbf1,_0x2d3919,_0x2322c1,_0x3c9d2c){const _0x263253=it(_0x21cbf1,'values');if(!(_0x2d3919&&typeof _0x2d3919=='object')||Array['isArray'](_0x2d3919))throw new Error(_0x263253+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x153ebd=[];x(_0x2d3919,(_0x409210,_0x34c766)=>{const _0x29818e=new C(_0x409210);if(Jt(_0x263253,_0x34c766,k(_0x2322c1,_0x29818e)),ji(_0x29818e)==='.priority'&&!Bt(_0x34c766))throw new Error(_0x263253+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x29818e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x153ebd['push'](_0x29818e);}),dd(_0x263253,_0x153ebd);},fd=function(_0x52a216,_0x1a01b9,_0x19abe2){if(xn(_0x1a01b9))throw new Error(it(_0x52a216,'priority')+'is\x20'+_0x1a01b9['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1a01b9))throw new Error(it(_0x52a216,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x5806a9,_0x593084,_0x4d193c,_0x569c89){if(!sa(_0x4d193c))throw new Error(it(_0x5806a9,_0x593084)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4d193c+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x519b47,_0x541892,_0x10fabd,_0x3f85d1){_0x10fabd&&(_0x10fabd=_0x10fabd['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x519b47,_0x541892,_0x10fabd);},Me=function(_0x4417c2,_0x19d804){if(y(_0x19d804)==='.info')throw new Error(_0x4417c2+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x2a9fe2,_0x3c58cc){const _0x441e91=_0x3c58cc['path']['toString']();if(typeof _0x3c58cc['repoInfo']['host']!='string'||_0x3c58cc['repoInfo']['host']['length']===0x0||!ms(_0x3c58cc['repoInfo']['namespace'])&&_0x3c58cc['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x441e91['length']!==0x0&&!ud(_0x441e91))throw new Error(it(_0x2a9fe2,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x2a9fe8,_0x502f7a){let _0x35ed98=null;for(let _0x550d2c=0x0;_0x550d2c<_0x502f7a['length'];_0x550d2c++){const _0x397f25=_0x502f7a[_0x550d2c],_0x1382cb=_0x397f25['getPath']();_0x35ed98!==null&&!Ki(_0x1382cb,_0x35ed98['path'])&&(_0x2a9fe8['eventLists_']['push'](_0x35ed98),_0x35ed98=null),_0x35ed98===null&&(_0x35ed98={'events':[],'path':_0x1382cb}),_0x35ed98['events']['push'](_0x397f25);}_0x35ed98&&_0x2a9fe8['eventLists_']['push'](_0x35ed98);}function oa(_0x4ddf9b,_0xaa3164,_0x588786){qn(_0x4ddf9b,_0x588786),aa(_0x4ddf9b,_0x4e52a5=>Ki(_0x4e52a5,_0xaa3164));}function V(_0x3b5c03,_0x2663ff,_0x2534d9){qn(_0x3b5c03,_0x2534d9),aa(_0x3b5c03,_0x492a95=>G(_0x492a95,_0x2663ff)||G(_0x2663ff,_0x492a95));}function aa(_0x58c54e,_0xd4275f){_0x58c54e['recursionDepth_']++;let _0x38233d=!0x0;for(let _0x11e3c9=0x0;_0x11e3c9<_0x58c54e['eventLists_']['length'];_0x11e3c9++){const _0x1c4e07=_0x58c54e['eventLists_'][_0x11e3c9];if(_0x1c4e07){const _0x19e2dc=_0x1c4e07['path'];_0xd4275f(_0x19e2dc)?(md(_0x58c54e['eventLists_'][_0x11e3c9]),_0x58c54e['eventLists_'][_0x11e3c9]=null):_0x38233d=!0x1;}}_0x38233d&&(_0x58c54e['eventLists_']=[]),_0x58c54e['recursionDepth_']--;}function md(_0x1a466e){for(let _0x59ff8c=0x0;_0x59ff8c<_0x1a466e['events']['length'];_0x59ff8c++){const _0x393197=_0x1a466e['events'][_0x59ff8c];if(_0x393197!==null){_0x1a466e['events'][_0x59ff8c]=null;const _0x5732bc=_0x393197['getEventRunner']();St&&L('event:\x20'+_0x393197['toString']()),ft(_0x5732bc);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x145746,_0x39a398,_0x2a2a1e,_0x2959a9){this['repoInfo_']=_0x145746,this['forceRestClient_']=_0x39a398,this['authTokenProvider_']=_0x2a2a1e,this['appCheckProvider_']=_0x2959a9,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x19411a,_0x535ee3,_0x19e053){if(_0x19411a['stats_']=qi(_0x19411a['repoInfo_']),_0x19411a['forceRestClient_']||Xl())_0x19411a['server_']=new vn(_0x19411a['repoInfo_'],(_0x44929a,_0x45e2de,_0x2e69be,_0xa36502)=>{gr(_0x19411a,_0x44929a,_0x45e2de,_0x2e69be,_0xa36502);},_0x19411a['authTokenProvider_'],_0x19411a['appCheckProvider_']),setTimeout(()=>mr(_0x19411a,!0x0),0x0);else{if(typeof _0x19e053<'u'&&_0x19e053!==null){if(typeof _0x19e053!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x19e053);}catch(_0x4ee93d){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4ee93d);}}_0x19411a['persistentConnection_']=new se(_0x19411a['repoInfo_'],_0x535ee3,(_0x5340e4,_0x129924,_0x42ab4b,_0x5885c6)=>{gr(_0x19411a,_0x5340e4,_0x129924,_0x42ab4b,_0x5885c6);},_0x55e588=>{mr(_0x19411a,_0x55e588);},_0x1b0927=>{Id(_0x19411a,_0x1b0927);},_0x19411a['authTokenProvider_'],_0x19411a['appCheckProvider_'],_0x19e053),_0x19411a['server_']=_0x19411a['persistentConnection_'];}_0x19411a['authTokenProvider_']['addTokenChangeListener'](_0x3a06e5=>{_0x19411a['server_']['refreshAuthToken'](_0x3a06e5);}),_0x19411a['appCheckProvider_']['addTokenChangeListener'](_0x8ec19c=>{_0x19411a['server_']['refreshAppCheckToken'](_0x8ec19c['token']);}),_0x19411a['statsReporter_']=ih(_0x19411a['repoInfo_'],()=>new iu(_0x19411a['stats_'],_0x19411a['server_'])),_0x19411a['infoData_']=new Xh(),_0x19411a['infoSyncTree_']=new pr({'startListening':(_0x2a9cbb,_0x59f74e,_0x311a8f,_0x41c023)=>{let _0x24c8c2=[];const _0x37ab95=_0x19411a['infoData_']['getNode'](_0x2a9cbb['_path']);return _0x37ab95['isEmpty']()||(_0x24c8c2=Yt(_0x19411a['infoSyncTree_'],_0x2a9cbb['_path'],_0x37ab95),setTimeout(()=>{_0x41c023('ok');},0x0)),_0x24c8c2;},'stopListening':()=>{}}),vs(_0x19411a,'connected',!0x1),_0x19411a['serverSyncTree_']=new pr({'startListening':(_0x1c18f3,_0x2c8dab,_0x2ce6e2,_0x2bfb01)=>(_0x19411a['server_']['listen'](_0x1c18f3,_0x2ce6e2,_0x2c8dab,(_0x1b225b,_0x21fc3f)=>{const _0xa18006=_0x2bfb01(_0x1b225b,_0x21fc3f);V(_0x19411a['eventQueue_'],_0x1c18f3['_path'],_0xa18006);}),[]),'stopListening':(_0x1e8fd6,_0x4aa059)=>{_0x19411a['server_']['unlisten'](_0x1e8fd6,_0x4aa059);}});}function la(_0x172791){const _0x222b08=_0x172791['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x222b08;}function Xt(_0x520891){return id({'timestamp':la(_0x520891)});}function gr(_0x2f96a6,_0x46b35b,_0x3841cd,_0x3f6545,_0x2ed319){_0x2f96a6['dataUpdateCount']++;const _0x31491b=new C(_0x46b35b);_0x3841cd=_0x2f96a6['interceptServerDataCallback_']?_0x2f96a6['interceptServerDataCallback_'](_0x46b35b,_0x3841cd):_0x3841cd;let _0x39d287=[];if(_0x2ed319){if(_0x3f6545){const _0x1c0f08=_n(_0x3841cd,_0x172b4c=>A(_0x172b4c));_0x39d287=Ju(_0x2f96a6['serverSyncTree_'],_0x31491b,_0x1c0f08,_0x2ed319);}else{const _0x587edf=A(_0x3841cd);_0x39d287=Jo(_0x2f96a6['serverSyncTree_'],_0x31491b,_0x587edf,_0x2ed319);}}else{if(_0x3f6545){const _0x4b74ee=_n(_0x3841cd,_0x1858db=>A(_0x1858db));_0x39d287=Ku(_0x2f96a6['serverSyncTree_'],_0x31491b,_0x4b74ee);}else{const _0x34ee30=A(_0x3841cd);_0x39d287=Yt(_0x2f96a6['serverSyncTree_'],_0x31491b,_0x34ee30);}}let _0x570cfd=_0x31491b;_0x39d287['length']>0x0&&(_0x570cfd=ct(_0x2f96a6,_0x31491b)),V(_0x2f96a6['eventQueue_'],_0x570cfd,_0x39d287);}function mr(_0x17404b,_0x1e1bab){vs(_0x17404b,'connected',_0x1e1bab),_0x1e1bab===!0x1&&Sd(_0x17404b);}function Id(_0x5b2cdf,_0x5d6fa2){x(_0x5d6fa2,(_0x472962,_0x253f4d)=>{vs(_0x5b2cdf,_0x472962,_0x253f4d);});}function vs(_0x3d1796,_0x490cad,_0x49ce4f){const _0x5a1421=new C('/.info/'+_0x490cad),_0xb890b7=A(_0x49ce4f);_0x3d1796['infoData_']['updateSnapshot'](_0x5a1421,_0xb890b7);const _0x5b58d7=Yt(_0x3d1796['infoSyncTree_'],_0x5a1421,_0xb890b7);V(_0x3d1796['eventQueue_'],_0x5a1421,_0x5b58d7);}function zn(_0x29c718){return _0x29c718['nextWriteId_']++;}function wd(_0x53caf6,_0x255709,_0x23d652){const _0x9aa339=Xu(_0x53caf6['serverSyncTree_'],_0x255709);return _0x9aa339!=null?Promise['resolve'](_0x9aa339):_0x53caf6['server_']['get'](_0x255709)['then'](_0x11aae5=>{const _0x5547ae=A(_0x11aae5)['withIndex'](_0x255709['_queryParams']['getIndex']());Ni(_0x53caf6['serverSyncTree_'],_0x255709,_0x23d652,!0x0);let _0x40f779;if(_0x255709['_queryParams']['loadsAllData']())_0x40f779=Yt(_0x53caf6['serverSyncTree_'],_0x255709['_path'],_0x5547ae);else{const _0x3b321a=Wt(_0x53caf6['serverSyncTree_'],_0x255709);_0x40f779=Jo(_0x53caf6['serverSyncTree_'],_0x255709['_path'],_0x5547ae,_0x3b321a);}return V(_0x53caf6['eventQueue_'],_0x255709['_path'],_0x40f779),An(_0x53caf6['serverSyncTree_'],_0x255709,_0x23d652,null,!0x0),_0x5547ae;},_0x4b3eae=>(gt(_0x53caf6,'get\x20for\x20query\x20'+O(_0x255709)+'\x20failed:\x20'+_0x4b3eae),Promise['reject'](new Error(_0x4b3eae))));}function Cd(_0x31e57c,_0x36189c,_0xe873c1,_0x17564d,_0x347773){gt(_0x31e57c,'set',{'path':_0x36189c['toString'](),'value':_0xe873c1,'priority':_0x17564d});const _0x2ffbec=Xt(_0x31e57c),_0x1528fc=A(_0xe873c1,_0x17564d),_0xd60325=Vn(_0x31e57c['serverSyncTree_'],_0x36189c),_0x3d0e45=fs(_0x1528fc,_0xd60325,_0x2ffbec),_0x44078c=zn(_0x31e57c),_0x4fc79b=as(_0x31e57c['serverSyncTree_'],_0x36189c,_0x3d0e45,_0x44078c,!0x0);qn(_0x31e57c['eventQueue_'],_0x4fc79b),_0x31e57c['server_']['put'](_0x36189c['toString'](),_0x1528fc['val'](!0x0),(_0x141943,_0x2f4ad5)=>{const _0x2ddd88=_0x141943==='ok';_0x2ddd88||U('set\x20at\x20'+_0x36189c+'\x20failed:\x20'+_0x141943);const _0x2d41e2=_e(_0x31e57c['serverSyncTree_'],_0x44078c,!_0x2ddd88);V(_0x31e57c['eventQueue_'],_0x36189c,_0x2d41e2),be(_0x31e57c,_0x347773,_0x141943,_0x2f4ad5);});const _0x106fd6=Is(_0x31e57c,_0x36189c);ct(_0x31e57c,_0x106fd6),V(_0x31e57c['eventQueue_'],_0x106fd6,[]);}function Td(_0x2e030f,_0x1102ad,_0x48e4f5,_0x401578){gt(_0x2e030f,'update',{'path':_0x1102ad['toString'](),'value':_0x48e4f5});let _0x16b1ce=!0x0;const _0x247f43=Xt(_0x2e030f),_0x309344={};if(x(_0x48e4f5,(_0x2e3213,_0x113ce2)=>{_0x16b1ce=!0x1,_0x309344[_0x2e3213]=ta(k(_0x1102ad,_0x2e3213),A(_0x113ce2),_0x2e030f['serverSyncTree_'],_0x247f43);}),_0x16b1ce)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2e030f,_0x401578,'ok',void 0x0);else{const _0x1b5c63=zn(_0x2e030f),_0x2d45ce=ju(_0x2e030f['serverSyncTree_'],_0x1102ad,_0x309344,_0x1b5c63);qn(_0x2e030f['eventQueue_'],_0x2d45ce),_0x2e030f['server_']['merge'](_0x1102ad['toString'](),_0x48e4f5,(_0x5d8a98,_0x5b4c7b)=>{const _0x1a65fa=_0x5d8a98==='ok';_0x1a65fa||U('update\x20at\x20'+_0x1102ad+'\x20failed:\x20'+_0x5d8a98);const _0x40e5ef=_e(_0x2e030f['serverSyncTree_'],_0x1b5c63,!_0x1a65fa),_0x1207e5=_0x40e5ef['length']>0x0?ct(_0x2e030f,_0x1102ad):_0x1102ad;V(_0x2e030f['eventQueue_'],_0x1207e5,_0x40e5ef),be(_0x2e030f,_0x401578,_0x5d8a98,_0x5b4c7b);}),x(_0x48e4f5,_0x3c51d7=>{const _0x3003d4=Is(_0x2e030f,k(_0x1102ad,_0x3c51d7));ct(_0x2e030f,_0x3003d4);}),V(_0x2e030f['eventQueue_'],_0x1102ad,[]);}}function Sd(_0x2d476c){gt(_0x2d476c,'onDisconnectEvents');const _0x387969=Xt(_0x2d476c),_0x42bc45=En();Si(_0x2d476c['onDisconnect_'],w(),(_0x1cad41,_0x4eff21)=>{const _0x420725=ta(_0x1cad41,_0x4eff21,_0x2d476c['serverSyncTree_'],_0x387969);pt(_0x42bc45,_0x1cad41,_0x420725);});let _0x2eac31=[];Si(_0x42bc45,w(),(_0x69486b,_0x329445)=>{_0x2eac31=_0x2eac31['concat'](Yt(_0x2d476c['serverSyncTree_'],_0x69486b,_0x329445));const _0x6517e7=Is(_0x2d476c,_0x69486b);ct(_0x2d476c,_0x6517e7);}),_0x2d476c['onDisconnect_']=En(),V(_0x2d476c['eventQueue_'],w(),_0x2eac31);}function bd(_0x59eee0,_0xd7c02a,_0x553437){_0x59eee0['server_']['onDisconnectCancel'](_0xd7c02a['toString'](),(_0x5d2857,_0x131184)=>{_0x5d2857==='ok'&&Ti(_0x59eee0['onDisconnect_'],_0xd7c02a),be(_0x59eee0,_0x553437,_0x5d2857,_0x131184);});}function yr(_0x1fc87c,_0x40b0b1,_0x52b667,_0x341d8c){const _0x460a9c=A(_0x52b667);_0x1fc87c['server_']['onDisconnectPut'](_0x40b0b1['toString'](),_0x460a9c['val'](!0x0),(_0x5cecae,_0x41bc7d)=>{_0x5cecae==='ok'&&pt(_0x1fc87c['onDisconnect_'],_0x40b0b1,_0x460a9c),be(_0x1fc87c,_0x341d8c,_0x5cecae,_0x41bc7d);});}function Rd(_0x5d4865,_0x51e83b,_0x4a3c38,_0x4b0aac,_0x5d6fb1){const _0x299255=A(_0x4a3c38,_0x4b0aac);_0x5d4865['server_']['onDisconnectPut'](_0x51e83b['toString'](),_0x299255['val'](!0x0),(_0x488391,_0x174f80)=>{_0x488391==='ok'&&pt(_0x5d4865['onDisconnect_'],_0x51e83b,_0x299255),be(_0x5d4865,_0x5d6fb1,_0x488391,_0x174f80);});}function Ad(_0x3951af,_0x434640,_0x5d4a35,_0x5092b5){if(pn(_0x5d4a35)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3951af,_0x5092b5,'ok',void 0x0);return;}_0x3951af['server_']['onDisconnectMerge'](_0x434640['toString'](),_0x5d4a35,(_0x50f1c7,_0x28f0db)=>{_0x50f1c7==='ok'&&x(_0x5d4a35,(_0x362fa4,_0x4d726a)=>{const _0x213659=A(_0x4d726a);pt(_0x3951af['onDisconnect_'],k(_0x434640,_0x362fa4),_0x213659);}),be(_0x3951af,_0x5092b5,_0x50f1c7,_0x28f0db);});}function kd(_0x21e714,_0x310d2a,_0x25f494){let _0x1e12c0;y(_0x310d2a['_path'])==='.info'?_0x1e12c0=Ni(_0x21e714['infoSyncTree_'],_0x310d2a,_0x25f494):_0x1e12c0=Ni(_0x21e714['serverSyncTree_'],_0x310d2a,_0x25f494),oa(_0x21e714['eventQueue_'],_0x310d2a['_path'],_0x1e12c0);}function Pd(_0x180c18,_0xb569f5,_0x2f3779){let _0x56db19;y(_0xb569f5['_path'])==='.info'?_0x56db19=An(_0x180c18['infoSyncTree_'],_0xb569f5,_0x2f3779):_0x56db19=An(_0x180c18['serverSyncTree_'],_0xb569f5,_0x2f3779),oa(_0x180c18['eventQueue_'],_0xb569f5['_path'],_0x56db19);}function ha(_0x1ace0d){_0x1ace0d['persistentConnection_']&&_0x1ace0d['persistentConnection_']['interrupt'](ca);}function Nd(_0x296322){_0x296322['persistentConnection_']&&_0x296322['persistentConnection_']['resume'](ca);}function gt(_0x542994,..._0x83999d){let _0x59e203='';_0x542994['persistentConnection_']&&(_0x59e203=_0x542994['persistentConnection_']['id']+':'),L(_0x59e203,..._0x83999d);}function be(_0x243bbf,_0x382b93,_0x1dc299,_0x8b0970){_0x382b93&&ft(()=>{if(_0x1dc299==='ok')_0x382b93(null);else{const _0x4f63a2=(_0x1dc299||'error')['toUpperCase']();let _0x5ed062=_0x4f63a2;_0x8b0970&&(_0x5ed062+=':\x20'+_0x8b0970);const _0x2a9c4b=new Error(_0x5ed062);_0x2a9c4b['code']=_0x4f63a2,_0x382b93(_0x2a9c4b);}});}function Od(_0x274c07,_0x43048a,_0x3385d5,_0x2846f0,_0x32950d,_0x322335){gt(_0x274c07,'transaction\x20on\x20'+_0x43048a);const _0x161072={'path':_0x43048a,'update':_0x3385d5,'onComplete':_0x2846f0,'status':null,'order':so(),'applyLocally':_0x322335,'retryCount':0x0,'unwatcher':_0x32950d,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x79ce21=Es(_0x274c07,_0x43048a,void 0x0);_0x161072['currentInputSnapshot']=_0x79ce21;const _0x3084a9=_0x161072['update'](_0x79ce21['val']());if(_0x3084a9===void 0x0)_0x161072['unwatcher'](),_0x161072['currentOutputSnapshotRaw']=null,_0x161072['currentOutputSnapshotResolved']=null,_0x161072['onComplete']&&_0x161072['onComplete'](null,!0x1,_0x161072['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3084a9,_0x161072['path']),_0x161072['status']=0x0;const _0x84ec47=$n(_0x274c07['transactionQueueTree_'],_0x43048a),_0x4fa6fd=je(_0x84ec47)||[];_0x4fa6fd['push'](_0x161072),gs(_0x84ec47,_0x4fa6fd);let _0x2d5e73;typeof _0x3084a9=='object'&&_0x3084a9!==null&&Q(_0x3084a9,'.priority')?(_0x2d5e73=Le(_0x3084a9,'.priority'),f(Bt(_0x2d5e73),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2d5e73=(Vn(_0x274c07['serverSyncTree_'],_0x43048a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4c84a8=Xt(_0x274c07),_0x37b3a5=A(_0x3084a9,_0x2d5e73),_0x301de2=fs(_0x37b3a5,_0x79ce21,_0x4c84a8);_0x161072['currentOutputSnapshotRaw']=_0x37b3a5,_0x161072['currentOutputSnapshotResolved']=_0x301de2,_0x161072['currentWriteId']=zn(_0x274c07);const _0x2780e1=as(_0x274c07['serverSyncTree_'],_0x43048a,_0x301de2,_0x161072['currentWriteId'],_0x161072['applyLocally']);V(_0x274c07['eventQueue_'],_0x43048a,_0x2780e1),jn(_0x274c07,_0x274c07['transactionQueueTree_']);}}function Es(_0x262c9d,_0x1a9548,_0x3139bc){return Vn(_0x262c9d['serverSyncTree_'],_0x1a9548,_0x3139bc)||g['EMPTY_NODE'];}function jn(_0x359dbb,_0x1d7d27=_0x359dbb['transactionQueueTree_']){if(_0x1d7d27||Kn(_0x359dbb,_0x1d7d27),je(_0x1d7d27)){const _0x86266a=da(_0x359dbb,_0x1d7d27);f(_0x86266a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x86266a['every'](_0x1ca712=>_0x1ca712['status']===0x0)&&Dd(_0x359dbb,Qt(_0x1d7d27),_0x86266a);}else na(_0x1d7d27)&&Gn(_0x1d7d27,_0x324335=>{jn(_0x359dbb,_0x324335);});}function Dd(_0x5705ae,_0x40581b,_0x477470){const _0x4d1a3e=_0x477470['map'](_0x4aff87=>_0x4aff87['currentWriteId']),_0x158a12=Es(_0x5705ae,_0x40581b,_0x4d1a3e);let _0x3f24ba=_0x158a12;const _0x23e513=_0x158a12['hash']();for(let _0x388c65=0x0;_0x388c65<_0x477470['length'];_0x388c65++){const _0x2c4302=_0x477470[_0x388c65];f(_0x2c4302['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2c4302['status']=0x1,_0x2c4302['retryCount']++;const _0x19fb19=F(_0x40581b,_0x2c4302['path']);_0x3f24ba=_0x3f24ba['updateChild'](_0x19fb19,_0x2c4302['currentOutputSnapshotRaw']);}const _0x53f001=_0x3f24ba['val'](!0x0),_0x55e96a=_0x40581b;_0x5705ae['server_']['put'](_0x55e96a['toString'](),_0x53f001,_0x5c63c7=>{gt(_0x5705ae,'transaction\x20put\x20response',{'path':_0x55e96a['toString'](),'status':_0x5c63c7});let _0x937ede=[];if(_0x5c63c7==='ok'){const _0x299d85=[];for(let _0x7b94cc=0x0;_0x7b94cc<_0x477470['length'];_0x7b94cc++)_0x477470[_0x7b94cc]['status']=0x2,_0x937ede=_0x937ede['concat'](_e(_0x5705ae['serverSyncTree_'],_0x477470[_0x7b94cc]['currentWriteId'])),_0x477470[_0x7b94cc]['onComplete']&&_0x299d85['push'](()=>_0x477470[_0x7b94cc]['onComplete'](null,!0x0,_0x477470[_0x7b94cc]['currentOutputSnapshotResolved'])),_0x477470[_0x7b94cc]['unwatcher']();Kn(_0x5705ae,$n(_0x5705ae['transactionQueueTree_'],_0x40581b)),jn(_0x5705ae,_0x5705ae['transactionQueueTree_']),V(_0x5705ae['eventQueue_'],_0x40581b,_0x937ede);for(let _0x5617d8=0x0;_0x5617d8<_0x299d85['length'];_0x5617d8++)ft(_0x299d85[_0x5617d8]);}else{if(_0x5c63c7==='datastale'){for(let _0x53f6f6=0x0;_0x53f6f6<_0x477470['length'];_0x53f6f6++)_0x477470[_0x53f6f6]['status']===0x3?_0x477470[_0x53f6f6]['status']=0x4:_0x477470[_0x53f6f6]['status']=0x0;}else{U('transaction\x20at\x20'+_0x55e96a['toString']()+'\x20failed:\x20'+_0x5c63c7);for(let _0x5ccb45=0x0;_0x5ccb45<_0x477470['length'];_0x5ccb45++)_0x477470[_0x5ccb45]['status']=0x4,_0x477470[_0x5ccb45]['abortReason']=_0x5c63c7;}ct(_0x5705ae,_0x40581b);}},_0x23e513);}function ct(_0xf417f2,_0x386095){const _0x1f8a39=ua(_0xf417f2,_0x386095),_0x54dd8a=Qt(_0x1f8a39),_0x72c32b=da(_0xf417f2,_0x1f8a39);return Md(_0xf417f2,_0x72c32b,_0x54dd8a),_0x54dd8a;}function Md(_0xbf4e92,_0x25d3e8,_0x591f90){if(_0x25d3e8['length']===0x0)return;const _0x341f4e=[];let _0x3e3e5e=[];const _0x509676=_0x25d3e8['filter'](_0x596350=>_0x596350['status']===0x0)['map'](_0x3a7a24=>_0x3a7a24['currentWriteId']);for(let _0x50175f=0x0;_0x50175f<_0x25d3e8['length'];_0x50175f++){const _0x49024c=_0x25d3e8[_0x50175f],_0x14cd81=F(_0x591f90,_0x49024c['path']);let _0x1aee70=!0x1,_0x2af1cf;if(f(_0x14cd81!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x49024c['status']===0x4)_0x1aee70=!0x0,_0x2af1cf=_0x49024c['abortReason'],_0x3e3e5e=_0x3e3e5e['concat'](_e(_0xbf4e92['serverSyncTree_'],_0x49024c['currentWriteId'],!0x0));else{if(_0x49024c['status']===0x0){if(_0x49024c['retryCount']>=yd)_0x1aee70=!0x0,_0x2af1cf='maxretry',_0x3e3e5e=_0x3e3e5e['concat'](_e(_0xbf4e92['serverSyncTree_'],_0x49024c['currentWriteId'],!0x0));else{const _0xa63a11=Es(_0xbf4e92,_0x49024c['path'],_0x509676);_0x49024c['currentInputSnapshot']=_0xa63a11;const _0x5df9cc=_0x25d3e8[_0x50175f]['update'](_0xa63a11['val']());if(_0x5df9cc!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5df9cc,_0x49024c['path']);let _0x55e436=A(_0x5df9cc);typeof _0x5df9cc=='object'&&_0x5df9cc!=null&&Q(_0x5df9cc,'.priority')||(_0x55e436=_0x55e436['updatePriority'](_0xa63a11['getPriority']()));const _0x44f61f=_0x49024c['currentWriteId'],_0x68da90=Xt(_0xbf4e92),_0x5ac46f=fs(_0x55e436,_0xa63a11,_0x68da90);_0x49024c['currentOutputSnapshotRaw']=_0x55e436,_0x49024c['currentOutputSnapshotResolved']=_0x5ac46f,_0x49024c['currentWriteId']=zn(_0xbf4e92),_0x509676['splice'](_0x509676['indexOf'](_0x44f61f),0x1),_0x3e3e5e=_0x3e3e5e['concat'](as(_0xbf4e92['serverSyncTree_'],_0x49024c['path'],_0x5ac46f,_0x49024c['currentWriteId'],_0x49024c['applyLocally'])),_0x3e3e5e=_0x3e3e5e['concat'](_e(_0xbf4e92['serverSyncTree_'],_0x44f61f,!0x0));}else _0x1aee70=!0x0,_0x2af1cf='nodata',_0x3e3e5e=_0x3e3e5e['concat'](_e(_0xbf4e92['serverSyncTree_'],_0x49024c['currentWriteId'],!0x0));}}}V(_0xbf4e92['eventQueue_'],_0x591f90,_0x3e3e5e),_0x3e3e5e=[],_0x1aee70&&(_0x25d3e8[_0x50175f]['status']=0x2,function(_0x40ab98){setTimeout(_0x40ab98,Math['floor'](0x0));}(_0x25d3e8[_0x50175f]['unwatcher']),_0x25d3e8[_0x50175f]['onComplete']&&(_0x2af1cf==='nodata'?_0x341f4e['push'](()=>_0x25d3e8[_0x50175f]['onComplete'](null,!0x1,_0x25d3e8[_0x50175f]['currentInputSnapshot'])):_0x341f4e['push'](()=>_0x25d3e8[_0x50175f]['onComplete'](new Error(_0x2af1cf),!0x1,null))));}Kn(_0xbf4e92,_0xbf4e92['transactionQueueTree_']);for(let _0x4fd3aa=0x0;_0x4fd3aa<_0x341f4e['length'];_0x4fd3aa++)ft(_0x341f4e[_0x4fd3aa]);jn(_0xbf4e92,_0xbf4e92['transactionQueueTree_']);}function ua(_0x4bae67,_0x1f6fc5){let _0xf1bac5,_0x5c9dda=_0x4bae67['transactionQueueTree_'];for(_0xf1bac5=y(_0x1f6fc5);_0xf1bac5!==null&&je(_0x5c9dda)===void 0x0;)_0x5c9dda=$n(_0x5c9dda,_0xf1bac5),_0x1f6fc5=S(_0x1f6fc5),_0xf1bac5=y(_0x1f6fc5);return _0x5c9dda;}function da(_0x1e9172,_0x8f7f50){const _0x286e65=[];return fa(_0x1e9172,_0x8f7f50,_0x286e65),_0x286e65['sort']((_0x30e5c1,_0x2c82ce)=>_0x30e5c1['order']-_0x2c82ce['order']),_0x286e65;}function fa(_0x22c0d3,_0x34f64d,_0x47108a){const _0x5a428f=je(_0x34f64d);if(_0x5a428f){for(let _0x11f57a=0x0;_0x11f57a<_0x5a428f['length'];_0x11f57a++)_0x47108a['push'](_0x5a428f[_0x11f57a]);}Gn(_0x34f64d,_0x452f34=>{fa(_0x22c0d3,_0x452f34,_0x47108a);});}function Kn(_0x2d5d0f,_0x30f527){const _0xee6be2=je(_0x30f527);if(_0xee6be2){let _0x230dfc=0x0;for(let _0x10febd=0x0;_0x10febd<_0xee6be2['length'];_0x10febd++)_0xee6be2[_0x10febd]['status']!==0x2&&(_0xee6be2[_0x230dfc]=_0xee6be2[_0x10febd],_0x230dfc++);_0xee6be2['length']=_0x230dfc,gs(_0x30f527,_0xee6be2['length']>0x0?_0xee6be2:void 0x0);}Gn(_0x30f527,_0x3e8ecf=>{Kn(_0x2d5d0f,_0x3e8ecf);});}function Is(_0x5808e2,_0x526cf2){const _0x52c3b6=Qt(ua(_0x5808e2,_0x526cf2)),_0x3b4c36=$n(_0x5808e2['transactionQueueTree_'],_0x526cf2);return ad(_0x3b4c36,_0x2ef204=>{di(_0x5808e2,_0x2ef204);}),di(_0x5808e2,_0x3b4c36),ia(_0x3b4c36,_0x535cca=>{di(_0x5808e2,_0x535cca);}),_0x52c3b6;}function di(_0x579dc9,_0x730861){const _0x40c459=je(_0x730861);if(_0x40c459){const _0x2c99f3=[];let _0x561406=[],_0x138c4c=-0x1;for(let _0x1b5909=0x0;_0x1b5909<_0x40c459['length'];_0x1b5909++)_0x40c459[_0x1b5909]['status']===0x3||(_0x40c459[_0x1b5909]['status']===0x1?(f(_0x138c4c===_0x1b5909-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x138c4c=_0x1b5909,_0x40c459[_0x1b5909]['status']=0x3,_0x40c459[_0x1b5909]['abortReason']='set'):(f(_0x40c459[_0x1b5909]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x40c459[_0x1b5909]['unwatcher'](),_0x561406=_0x561406['concat'](_e(_0x579dc9['serverSyncTree_'],_0x40c459[_0x1b5909]['currentWriteId'],!0x0)),_0x40c459[_0x1b5909]['onComplete']&&_0x2c99f3['push'](_0x40c459[_0x1b5909]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x138c4c===-0x1?gs(_0x730861,void 0x0):_0x40c459['length']=_0x138c4c+0x1,V(_0x579dc9['eventQueue_'],Qt(_0x730861),_0x561406);for(let _0x1a1b00=0x0;_0x1a1b00<_0x2c99f3['length'];_0x1a1b00++)ft(_0x2c99f3[_0x1a1b00]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x17d6a6){let _0x8189ce='';const _0x1c033f=_0x17d6a6['split']('/');for(let _0x4d415c=0x0;_0x4d415c<_0x1c033f['length'];_0x4d415c++)if(_0x1c033f[_0x4d415c]['length']>0x0){let _0x24a66a=_0x1c033f[_0x4d415c];try{_0x24a66a=decodeURIComponent(_0x24a66a['replace'](/\+/g,'\x20'));}catch{}_0x8189ce+='/'+_0x24a66a;}return _0x8189ce;}function xd(_0x2d638c){const _0x57c4d9={};_0x2d638c['charAt'](0x0)==='?'&&(_0x2d638c=_0x2d638c['substring'](0x1));for(const _0x46fd0f of _0x2d638c['split']('&')){if(_0x46fd0f['length']===0x0)continue;const _0x486731=_0x46fd0f['split']('=');_0x486731['length']===0x2?_0x57c4d9[decodeURIComponent(_0x486731[0x0])]=decodeURIComponent(_0x486731[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x46fd0f+'\x27\x20in\x20query\x20\x27'+_0x2d638c+'\x27');}return _0x57c4d9;}const vr=function(_0x11bcd9,_0x4fd5e8){const _0x4b2ada=Fd(_0x11bcd9),_0xf349d5=_0x4b2ada['namespace'];_0x4b2ada['domain']==='firebase.com'&&ae(_0x4b2ada['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xf349d5||_0xf349d5==='undefined')&&_0x4b2ada['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4b2ada['secure']||$l();const _0x368391=_0x4b2ada['scheme']==='ws'||_0x4b2ada['scheme']==='wss';return{'repoInfo':new yo(_0x4b2ada['host'],_0x4b2ada['secure'],_0xf349d5,_0x368391,_0x4fd5e8,'',_0xf349d5!==_0x4b2ada['subdomain']),'path':new C(_0x4b2ada['pathString'])};},Fd=function(_0x120e34){let _0x33464a='',_0x5f435c='',_0x8aaa19='',_0x117389='',_0x5f32b7='',_0x39b4ee=!0x0,_0x1ac501='https',_0x55b67e=0x1bb;if(typeof _0x120e34=='string'){let _0x56605f=_0x120e34['indexOf']('//');_0x56605f>=0x0&&(_0x1ac501=_0x120e34['substring'](0x0,_0x56605f-0x1),_0x120e34=_0x120e34['substring'](_0x56605f+0x2));let _0x3b0368=_0x120e34['indexOf']('/');_0x3b0368===-0x1&&(_0x3b0368=_0x120e34['length']);let _0x584955=_0x120e34['indexOf']('?');_0x584955===-0x1&&(_0x584955=_0x120e34['length']),_0x33464a=_0x120e34['substring'](0x0,Math['min'](_0x3b0368,_0x584955)),_0x3b0368<_0x584955&&(_0x117389=Ld(_0x120e34['substring'](_0x3b0368,_0x584955)));const _0x3b7e5b=xd(_0x120e34['substring'](Math['min'](_0x120e34['length'],_0x584955)));_0x56605f=_0x33464a['indexOf'](':'),_0x56605f>=0x0?(_0x39b4ee=_0x1ac501==='https'||_0x1ac501==='wss',_0x55b67e=parseInt(_0x33464a['substring'](_0x56605f+0x1),0xa)):_0x56605f=_0x33464a['length'];const _0x30fbae=_0x33464a['slice'](0x0,_0x56605f);if(_0x30fbae['toLowerCase']()==='localhost')_0x5f435c='localhost';else{if(_0x30fbae['split']('.')['length']<=0x2)_0x5f435c=_0x30fbae;else{const _0x48d59b=_0x33464a['indexOf']('.');_0x8aaa19=_0x33464a['substring'](0x0,_0x48d59b)['toLowerCase'](),_0x5f435c=_0x33464a['substring'](_0x48d59b+0x1),_0x5f32b7=_0x8aaa19;}}'ns'in _0x3b7e5b&&(_0x5f32b7=_0x3b7e5b['ns']);}return{'host':_0x33464a,'port':_0x55b67e,'domain':_0x5f435c,'subdomain':_0x8aaa19,'secure':_0x39b4ee,'scheme':_0x1ac501,'pathString':_0x117389,'namespace':_0x5f32b7};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x394d1f=0x0;const _0x56943d=[];return function(_0x208854){const _0x486d68=_0x208854===_0x394d1f;_0x394d1f=_0x208854;let _0x3c0bed;const _0x516674=new Array(0x8);for(_0x3c0bed=0x7;_0x3c0bed>=0x0;_0x3c0bed--)_0x516674[_0x3c0bed]=Er['charAt'](_0x208854%0x40),_0x208854=Math['floor'](_0x208854/0x40);f(_0x208854===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x464861=_0x516674['join']('');if(_0x486d68){for(_0x3c0bed=0xb;_0x3c0bed>=0x0&&_0x56943d[_0x3c0bed]===0x3f;_0x3c0bed--)_0x56943d[_0x3c0bed]=0x0;_0x56943d[_0x3c0bed]++;}else{for(_0x3c0bed=0x0;_0x3c0bed<0xc;_0x3c0bed++)_0x56943d[_0x3c0bed]=Math['floor'](Math['random']()*0x40);}for(_0x3c0bed=0x0;_0x3c0bed<0xc;_0x3c0bed++)_0x464861+=Er['charAt'](_0x56943d[_0x3c0bed]);return f(_0x464861['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x464861;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x226078,_0x9a497a,_0x26088f,_0xef02d1){this['eventType']=_0x226078,this['eventRegistration']=_0x9a497a,this['snapshot']=_0x26088f,this['prevName']=_0xef02d1;}['getPath'](){const _0x2c59b4=this['snapshot']['ref'];return this['eventType']==='value'?_0x2c59b4['_path']:_0x2c59b4['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x438d8a,_0x461daa,_0x4896c6){this['eventRegistration']=_0x438d8a,this['error']=_0x461daa,this['path']=_0x4896c6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3f8fd3,_0xbfd95b){this['snapshotCallback']=_0x3f8fd3,this['cancelCallback']=_0xbfd95b;}['onValue'](_0x3e1d0f,_0x3d8b4b){this['snapshotCallback']['call'](null,_0x3e1d0f,_0x3d8b4b);}['onCancel'](_0x2852d5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2852d5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x114262){return this['snapshotCallback']===_0x114262['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x114262['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x114262['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2f4317,_0x4a5166){this['_repo']=_0x2f4317,this['_path']=_0x4a5166;}['cancel'](){const _0x22d44a=new H();return bd(this['_repo'],this['_path'],_0x22d44a['wrapCallback'](()=>{})),_0x22d44a['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x28b85d=new H();return yr(this['_repo'],this['_path'],null,_0x28b85d['wrapCallback'](()=>{})),_0x28b85d['promise'];}['set'](_0x380f46){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x380f46,this['_path'],!0x1);const _0x504eff=new H();return yr(this['_repo'],this['_path'],_0x380f46,_0x504eff['wrapCallback'](()=>{})),_0x504eff['promise'];}['setWithPriority'](_0x256dbe,_0x41d965){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x256dbe,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x41d965);const _0x7bb812=new H();return Rd(this['_repo'],this['_path'],_0x256dbe,_0x41d965,_0x7bb812['wrapCallback'](()=>{})),_0x7bb812['promise'];}['update'](_0x45d173){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x45d173,this['_path']);const _0x1f9e13=new H();return Ad(this['_repo'],this['_path'],_0x45d173,_0x1f9e13['wrapCallback'](()=>{})),_0x1f9e13['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x14616c,_0x5333bf,_0x5b04a7,_0xbab876){this['_repo']=_0x14616c,this['_path']=_0x5333bf,this['_queryParams']=_0x5b04a7,this['_orderByCalled']=_0xbab876;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x51720b=sr(this['_queryParams']),_0xfdb7b=$i(_0x51720b);return _0xfdb7b==='{}'?'default':_0xfdb7b;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xc84751){if(_0xc84751=P(_0xc84751),!(_0xc84751 instanceof Ae))return!0x1;const _0x504df8=this['_repo']===_0xc84751['_repo'],_0x1ed429=Ki(this['_path'],_0xc84751['_path']),_0x46fa01=this['_queryIdentifier']===_0xc84751['_queryIdentifier'];return _0x504df8&&_0x1ed429&&_0x46fa01;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x52c643,_0x15a04b){if(_0x52c643['_orderByCalled']===!0x0)throw new Error(_0x15a04b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x35a9f0){let _0x1f19cd=null,_0x109dcb=null;if(_0x35a9f0['hasStart']()&&(_0x1f19cd=_0x35a9f0['getIndexStartValue']()),_0x35a9f0['hasEnd']()&&(_0x109dcb=_0x35a9f0['getIndexEndValue']()),_0x35a9f0['getIndex']()===ve){const _0x57947c='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1e9b20='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x35a9f0['hasStart']()){if(_0x35a9f0['getIndexStartName']()!==We)throw new Error(_0x57947c);if(typeof _0x1f19cd!='string')throw new Error(_0x1e9b20);}if(_0x35a9f0['hasEnd']()){if(_0x35a9f0['getIndexEndName']()!==we)throw new Error(_0x57947c);if(typeof _0x109dcb!='string')throw new Error(_0x1e9b20);}}else{if(_0x35a9f0['getIndex']()===R){if(_0x1f19cd!=null&&!Bt(_0x1f19cd)||_0x109dcb!=null&&!Bt(_0x109dcb))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x35a9f0['getIndex']()instanceof Ji||_0x35a9f0['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x1f19cd!=null&&typeof _0x1f19cd=='object'||_0x109dcb!=null&&typeof _0x109dcb=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x387d78){if(_0x387d78['hasStart']()&&_0x387d78['hasEnd']()&&_0x387d78['hasLimit']()&&!_0x387d78['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x398608,_0x23a596){super(_0x398608,_0x23a596,new Zi(),!0x1);}get['parent'](){const _0x1c36e2=Ro(this['_path']);return _0x1c36e2===null?null:new ee(this['_repo'],_0x1c36e2);}get['root'](){let _0x17bfbd=this;for(;_0x17bfbd['parent']!==null;)_0x17bfbd=_0x17bfbd['parent'];return _0x17bfbd;}}class lt{constructor(_0x5e16dc,_0x37bebb,_0x2c308f){this['_node']=_0x5e16dc,this['ref']=_0x37bebb,this['_index']=_0x2c308f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3af5fd){const _0x424757=new C(_0x3af5fd),_0x1bfae7=Vt(this['ref'],_0x3af5fd);return new lt(this['_node']['getChild'](_0x424757),_0x1bfae7,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2b9a7b){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x361dd8,_0x57c94d)=>_0x2b9a7b(new lt(_0x57c94d,Vt(this['ref'],_0x361dd8),R)));}['hasChild'](_0x550662){const _0x13c247=new C(_0x550662);return!this['_node']['getChild'](_0x13c247)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x18d060,_0x591df3){return _0x18d060=P(_0x18d060),_0x18d060['_checkNotDeleted']('ref'),_0x591df3!==void 0x0?Vt(_0x18d060['_root'],_0x591df3):_0x18d060['_root'];}function Vt(_0x51ed1a,_0x15224d){return _0x51ed1a=P(_0x51ed1a),y(_0x51ed1a['_path'])===null?pd('child','path',_0x15224d):ys('child','path',_0x15224d),new ee(_0x51ed1a['_repo'],k(_0x51ed1a['_path'],_0x15224d));}function v_(_0x5b8c4d){return _0x5b8c4d=P(_0x5b8c4d),new Vd(_0x5b8c4d['_repo'],_0x5b8c4d['_path']);}function E_(_0x55ccbd,_0x2ff8d3){_0x55ccbd=P(_0x55ccbd),Me('push',_0x55ccbd['_path']),He('push',_0x2ff8d3,_0x55ccbd['_path'],!0x0);const _0x5854a0=la(_0x55ccbd['_repo']),_0x51fca8=Ud(_0x5854a0),_0x1a9880=Vt(_0x55ccbd,_0x51fca8),_0x168b9c=Vt(_0x55ccbd,_0x51fca8);let _0x28860f;return _0x2ff8d3!=null?_0x28860f=Hd(_0x168b9c,_0x2ff8d3)['then'](()=>_0x168b9c):_0x28860f=Promise['resolve'](_0x168b9c),_0x1a9880['then']=_0x28860f['then']['bind'](_0x28860f),_0x1a9880['catch']=_0x28860f['then']['bind'](_0x28860f,void 0x0),_0x1a9880;}function Hd(_0x50ef44,_0x86274b){_0x50ef44=P(_0x50ef44),Me('set',_0x50ef44['_path']),He('set',_0x86274b,_0x50ef44['_path'],!0x1);const _0x5052af=new H();return Cd(_0x50ef44['_repo'],_0x50ef44['_path'],_0x86274b,null,_0x5052af['wrapCallback'](()=>{})),_0x5052af['promise'];}function I_(_0x1f5158,_0x11764f){ra('update',_0x11764f,_0x1f5158['_path']);const _0x1f85f1=new H();return Td(_0x1f5158['_repo'],_0x1f5158['_path'],_0x11764f,_0x1f85f1['wrapCallback'](()=>{})),_0x1f85f1['promise'];}function w_(_0x345efa){_0x345efa=P(_0x345efa);const _0x2e20e9=new pa(()=>{}),_0x5b75df=new Qn(_0x2e20e9);return wd(_0x345efa['_repo'],_0x345efa,_0x5b75df)['then'](_0x3597d8=>new lt(_0x3597d8,new ee(_0x345efa['_repo'],_0x345efa['_path']),_0x345efa['_queryParams']['getIndex']()));}class Qn{constructor(_0x18cfb4){this['callbackContext']=_0x18cfb4;}['respondsTo'](_0x25d876){return _0x25d876==='value';}['createEvent'](_0x958b23,_0x20a09e){const _0x4fe11d=_0x20a09e['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x958b23['snapshotNode'],new ee(_0x20a09e['_repo'],_0x20a09e['_path']),_0x4fe11d));}['getEventRunner'](_0x42a7df){return _0x42a7df['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x42a7df['error']):()=>this['callbackContext']['onValue'](_0x42a7df['snapshot'],null);}['createCancelEvent'](_0x5ea864,_0x230ac2){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5ea864,_0x230ac2):null;}['matches'](_0x235094){return _0x235094 instanceof Qn?!_0x235094['callbackContext']||!this['callbackContext']?!0x0:_0x235094['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x23a3bd,_0x661c56,_0x5e39f2,_0x193bad,_0x13d2da){const _0x8e34b8=new pa(_0x5e39f2,void 0x0),_0x46cac0=new Qn(_0x8e34b8);return kd(_0x23a3bd['_repo'],_0x23a3bd,_0x46cac0),()=>Pd(_0x23a3bd['_repo'],_0x23a3bd,_0x46cac0);}function Gd(_0x37b6f8,_0x5dd0ef,_0x1adf28,_0x96f14){return $d(_0x37b6f8,'value',_0x5dd0ef);}class mt{}class ma extends mt{constructor(_0x48e464,_0x3c490a){super(),this['_value']=_0x48e464,this['_key']=_0x3c490a,this['type']='endAt';}['_apply'](_0x322e1d){He('endAt',this['_value'],_0x322e1d['_path'],!0x0);const _0x2806b4=Jh(_0x322e1d['_queryParams'],this['_value'],this['_key']);if(ga(_0x2806b4),Yn(_0x2806b4),_0x322e1d['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x322e1d['_repo'],_0x322e1d['_path'],_0x2806b4,_0x322e1d['_orderByCalled']);}}function C_(_0x3e8564,_0x2f8fe0){return new ma(_0x3e8564,_0x2f8fe0);}class ya extends mt{constructor(_0x245800,_0xa8f5){super(),this['_value']=_0x245800,this['_key']=_0xa8f5,this['type']='startAt';}['_apply'](_0x5aea82){He('startAt',this['_value'],_0x5aea82['_path'],!0x0);const _0x42526e=Qh(_0x5aea82['_queryParams'],this['_value'],this['_key']);if(ga(_0x42526e),Yn(_0x42526e),_0x5aea82['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5aea82['_repo'],_0x5aea82['_path'],_0x42526e,_0x5aea82['_orderByCalled']);}}function T_(_0xef80c6=null,_0x397c83){return new ya(_0xef80c6,_0x397c83);}class qd extends mt{constructor(_0xd85c9f){super(),this['_limit']=_0xd85c9f,this['type']='limitToFirst';}['_apply'](_0x554b13){if(_0x554b13['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x554b13['_repo'],_0x554b13['_path'],Yh(_0x554b13['_queryParams'],this['_limit']),_0x554b13['_orderByCalled']);}}function S_(_0xfe59d){if(Math['floor'](_0xfe59d)!==_0xfe59d||_0xfe59d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0xfe59d);}class zd extends mt{constructor(_0x3dd321){super(),this['_path']=_0x3dd321,this['type']='orderByChild';}['_apply'](_0x3b1bd1){_a(_0x3b1bd1,'orderByChild');const _0x36b9da=new C(this['_path']);if(v(_0x36b9da))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x48c7ce=new Ji(_0x36b9da),_0x43c224=xo(_0x3b1bd1['_queryParams'],_0x48c7ce);return Yn(_0x43c224),new Ae(_0x3b1bd1['_repo'],_0x3b1bd1['_path'],_0x43c224,!0x0);}}function b_(_0x781b6c){if(_0x781b6c==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x781b6c==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x781b6c==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x781b6c),new zd(_0x781b6c);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x133155){_a(_0x133155,'orderByKey');const _0x1ef285=xo(_0x133155['_queryParams'],ve);return Yn(_0x1ef285),new Ae(_0x133155['_repo'],_0x133155['_path'],_0x1ef285,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x7723f9,_0x3b2525){super(),this['_value']=_0x7723f9,this['_key']=_0x3b2525,this['type']='equalTo';}['_apply'](_0x9ec468){if(He('equalTo',this['_value'],_0x9ec468['_path'],!0x1),_0x9ec468['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x9ec468['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x9ec468));}}function A_(_0x40afdb,_0x334113){return new Kd(_0x40afdb,_0x334113);}function k_(_0x2fda8d,..._0x479269){let _0x586572=P(_0x2fda8d);for(const _0x33ce64 of _0x479269)_0x586572=_0x33ce64['_apply'](_0x586572);return _0x586572;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4e1303,_0x3e58ea,_0x99bfa8,_0x6530c7){const _0x2411e6=_0x3e58ea['lastIndexOf'](':'),_0x4d7983=_0x3e58ea['substring'](0x0,_0x2411e6),_0x11c670=qt(_0x4d7983);_0x4e1303['repoInfo_']=new yo(_0x3e58ea,_0x11c670,_0x4e1303['repoInfo_']['namespace'],_0x4e1303['repoInfo_']['webSocketOnly'],_0x4e1303['repoInfo_']['nodeAdmin'],_0x4e1303['repoInfo_']['persistenceKey'],_0x4e1303['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x99bfa8),_0x6530c7&&(_0x4e1303['authTokenProvider_']=_0x6530c7);}function Xd(_0x44a85c,_0x517585,_0x143a8b,_0x3d7706,_0x196b30){let _0x4bc6f4=_0x3d7706||_0x44a85c['options']['databaseURL'];_0x4bc6f4===void 0x0&&(_0x44a85c['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x44a85c['options']['projectId']),_0x4bc6f4=_0x44a85c['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2d7a20=vr(_0x4bc6f4,_0x196b30),_0x3ee04e=_0x2d7a20['repoInfo'],_0x2a0328;typeof process<'u'&&Bs&&(_0x2a0328=Bs[Yd]),_0x2a0328?(_0x4bc6f4='http://'+_0x2a0328+'?ns='+_0x3ee04e['namespace'],_0x2d7a20=vr(_0x4bc6f4,_0x196b30),_0x3ee04e=_0x2d7a20['repoInfo']):_0x2d7a20['repoInfo']['secure'];const _0x5560b6=new eh(_0x44a85c['name'],_0x44a85c['options'],_0x517585);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2d7a20),v(_0x2d7a20['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x328dc5=ef(_0x3ee04e,_0x44a85c,_0x5560b6,new Zl(_0x44a85c,_0x143a8b));return new tf(_0x328dc5,_0x44a85c);}function Zd(_0x291b77,_0x4bb64f){const _0x99476c=Di[_0x4bb64f];(!_0x99476c||_0x99476c[_0x291b77['key']]!==_0x291b77)&&ae('Database\x20'+_0x4bb64f+'('+_0x291b77['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x291b77),delete _0x99476c[_0x291b77['key']];}function ef(_0x4d91cf,_0x1aff8a,_0x2a4d55,_0x4e231b){let _0x518b05=Di[_0x1aff8a['name']];_0x518b05||(_0x518b05={},Di[_0x1aff8a['name']]=_0x518b05);let _0x1cee98=_0x518b05[_0x4d91cf['toURLString']()];return _0x1cee98&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1cee98=new vd(_0x4d91cf,Qd,_0x2a4d55,_0x4e231b),_0x518b05[_0x4d91cf['toURLString']()]=_0x1cee98,_0x1cee98;}class tf{constructor(_0x190ecc,_0x6fd986){this['_repoInternal']=_0x190ecc,this['app']=_0x6fd986,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2a4628){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x2a4628+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x1e784d=Zr(),_0x516d3f){const _0x3c22b9=Hi(_0x1e784d,'database')['getImmediate']({'identifier':_0x516d3f});if(!_0x3c22b9['_instanceStarted']){const _0x4272ee=hc('database');_0x4272ee&&nf(_0x3c22b9,..._0x4272ee);}return _0x3c22b9;}function nf(_0x16a67c,_0x300d8d,_0x5215fd,_0x48ed2e={}){_0x16a67c=P(_0x16a67c),_0x16a67c['_checkNotDeleted']('useEmulator');const _0x48fd59=_0x300d8d+':'+_0x5215fd,_0x5dd7e3=_0x16a67c['_repoInternal'];if(_0x16a67c['_instanceStarted']){if(_0x48fd59===_0x16a67c['_repoInternal']['repoInfo_']['host']&&xe(_0x48ed2e,_0x5dd7e3['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x34aa81;if(_0x5dd7e3['repoInfo_']['nodeAdmin'])_0x48ed2e['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x34aa81=new an(an['OWNER']);else{if(_0x48ed2e['mockUserToken']){const _0x26499c=typeof _0x48ed2e['mockUserToken']=='string'?_0x48ed2e['mockUserToken']:uc(_0x48ed2e['mockUserToken'],_0x16a67c['app']['options']['projectId']);_0x34aa81=new an(_0x26499c);}}qt(_0x300d8d)&&Qr(_0x300d8d),Jd(_0x5dd7e3,_0x48fd59,_0x48ed2e,_0x34aa81);}function N_(_0x523bdd){_0x523bdd=P(_0x523bdd),_0x523bdd['_checkNotDeleted']('goOffline'),ha(_0x523bdd['_repo']);}function O_(_0x122dcb){_0x122dcb=P(_0x122dcb),_0x122dcb['_checkNotDeleted']('goOnline'),Nd(_0x122dcb['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x170a87){Ul(dt),st(new Fe('database',(_0x259d85,{instanceIdentifier:_0x33bd9e})=>{const _0x5e25bd=_0x259d85['getProvider']('app')['getImmediate'](),_0x26598b=_0x259d85['getProvider']('auth-internal'),_0x1d09a3=_0x259d85['getProvider']('app-check-internal');return Xd(_0x5e25bd,_0x26598b,_0x1d09a3,_0x33bd9e);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x170a87),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x5a506e,_0x1723a6){this['committed']=_0x5a506e,this['snapshot']=_0x1723a6;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x90bd40,_0x1ac461,_0x2c8e34){if(_0x90bd40=P(_0x90bd40),Me('Reference.transaction',_0x90bd40['_path']),_0x90bd40['key']==='.length'||_0x90bd40['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x90bd40['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3543c3=!0x0,_0x3146c3=new H(),_0x46ef81=(_0xc970ca,_0x49eea6,_0x5f3dac)=>{let _0x40a6f3=null;_0xc970ca?_0x3146c3['reject'](_0xc970ca):(_0x40a6f3=new lt(_0x5f3dac,new ee(_0x90bd40['_repo'],_0x90bd40['_path']),R),_0x3146c3['resolve'](new of(_0x49eea6,_0x40a6f3)));},_0x3a7690=Gd(_0x90bd40,()=>{});return Od(_0x90bd40['_repo'],_0x90bd40['_path'],_0x1ac461,_0x46ef81,_0x3a7690,_0x3543c3),_0x3146c3['promise'];}se['prototype']['simpleListen']=function(_0x2c55c1,_0x22d97f){this['sendRequest']('q',{'p':_0x2c55c1},_0x22d97f);},se['prototype']['echo']=function(_0x460779,_0x58ccac){this['sendRequest']('echo',{'d':_0x460779},_0x58ccac);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2cabdf,..._0x2f04d2){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2cabdf,..._0x2f04d2);}function cn(_0x5d44f1,..._0x5e43fc){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5d44f1,..._0x5e43fc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5cf501,..._0x4f260c){throw ws(_0x5cf501,..._0x4f260c);}function X(_0x2f5f18,..._0xa5cc5f){return ws(_0x2f5f18,..._0xa5cc5f);}function Ia(_0x17b486,_0x3cc951,_0xf383e){const _0x5ce4d3={...af(),[_0x3cc951]:_0xf383e};return new Gt('auth','Firebase',_0x5ce4d3)['create'](_0x3cc951,{'appName':_0x17b486['name']});}function re(_0x1c76cc){return Ia(_0x1c76cc,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x8bc8e1,..._0x5eb7ab){if(typeof _0x8bc8e1!='string'){const _0x1f1965=_0x5eb7ab[0x0],_0x4b7aca=[..._0x5eb7ab['slice'](0x1)];return _0x4b7aca[0x0]&&(_0x4b7aca[0x0]['appName']=_0x8bc8e1['name']),_0x8bc8e1['_errorFactory']['create'](_0x1f1965,..._0x4b7aca);}return Ea['create'](_0x8bc8e1,..._0x5eb7ab);}function m(_0x2e80e2,_0x3d5bfc,..._0x528711){if(!_0x2e80e2)throw ws(_0x3d5bfc,..._0x528711);}function ne(_0x5edea4){const _0x2393b6='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5edea4;throw cn(_0x2393b6),new Error(_0x2393b6);}function ce(_0x3f44dd,_0x1be2e2){_0x3f44dd||ne(_0x1be2e2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x22f912;return typeof self<'u'&&((_0x22f912=self['location'])==null?void 0x0:_0x22f912['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2038a3;return typeof self<'u'&&((_0x2038a3=self['location'])==null?void 0x0:_0x2038a3['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x49bfe3=navigator;return _0x49bfe3['languages']&&_0x49bfe3['languages'][0x0]||_0x49bfe3['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x452639,_0x17b4b5){this['shortDelay']=_0x452639,this['longDelay']=_0x17b4b5,ce(_0x17b4b5>_0x452639,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x21378b,_0x59920e){ce(_0x21378b['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x366b32}=_0x21378b['emulator'];return _0x59920e?''+_0x366b32+(_0x59920e['startsWith']('/')?_0x59920e['slice'](0x1):_0x59920e):_0x366b32;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x34c2ef,_0x3679be,_0x20d13a){this['fetchImpl']=_0x34c2ef,_0x3679be&&(this['headersImpl']=_0x3679be),_0x20d13a&&(this['responseImpl']=_0x20d13a);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x42ea5a,_0x1797b7){return _0x42ea5a['tenantId']&&!_0x1797b7['tenantId']?{..._0x1797b7,'tenantId':_0x42ea5a['tenantId']}:_0x1797b7;}async function Pe(_0x430a73,_0x2cca17,_0xeb2546,_0x79260a,_0x59fa61={}){return Ca(_0x430a73,_0x59fa61,async()=>{let _0x28d7c0={},_0x503c07={};_0x79260a&&(_0x2cca17==='GET'?_0x503c07=_0x79260a:_0x28d7c0={'body':JSON['stringify'](_0x79260a)});const _0x26cbee=ut({..._0x503c07,'key':_0x430a73['config']['apiKey']})['slice'](0x1),_0x427f8c=await _0x430a73['_getAdditionalHeaders']();_0x427f8c['Content-Type']='application/json',_0x430a73['languageCode']&&(_0x427f8c['X-Firebase-Locale']=_0x430a73['languageCode']);const _0x32adfa={'method':_0x2cca17,'headers':_0x427f8c,..._0x28d7c0};return dc()||(_0x32adfa['referrerPolicy']='strict-origin-when-cross-origin'),_0x430a73['emulatorConfig']&&qt(_0x430a73['emulatorConfig']['host'])&&(_0x32adfa['credentials']='include'),wa['fetch']()(await Ta(_0x430a73,_0x430a73['config']['apiHost'],_0xeb2546,_0x26cbee),_0x32adfa);});}async function Ca(_0x5e97b0,_0x3718bf,_0xd49d8f){_0x5e97b0['_canInitEmulator']=!0x1;const _0x49421f={...df,..._0x3718bf};try{const _0x28b320=new gf(_0x5e97b0),_0xad20db=await Promise['race']([_0xd49d8f(),_0x28b320['promise']]);_0x28b320['clearNetworkTimeout']();const _0x367186=await _0xad20db['json']();if('needConfirmation'in _0x367186)throw on(_0x5e97b0,'account-exists-with-different-credential',_0x367186);if(_0xad20db['ok']&&!('errorMessage'in _0x367186))return _0x367186;{const _0x3ed95a=_0xad20db['ok']?_0x367186['errorMessage']:_0x367186['error']['message'],[_0x481e1c,_0x20d14f]=_0x3ed95a['split']('\x20:\x20');if(_0x481e1c==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x5e97b0,'credential-already-in-use',_0x367186);if(_0x481e1c==='EMAIL_EXISTS')throw on(_0x5e97b0,'email-already-in-use',_0x367186);if(_0x481e1c==='USER_DISABLED')throw on(_0x5e97b0,'user-disabled',_0x367186);const _0xb5dd9f=_0x49421f[_0x481e1c]||_0x481e1c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x20d14f)throw Ia(_0x5e97b0,_0xb5dd9f,_0x20d14f);Y(_0x5e97b0,_0xb5dd9f);}}catch(_0x53b46a){if(_0x53b46a instanceof Re)throw _0x53b46a;Y(_0x5e97b0,'network-request-failed',{'message':String(_0x53b46a)});}}async function en(_0x2bf4f9,_0x263a64,_0x2518e3,_0x43195f,_0xef26a1={}){const _0x54281e=await Pe(_0x2bf4f9,_0x263a64,_0x2518e3,_0x43195f,_0xef26a1);return'mfaPendingCredential'in _0x54281e&&Y(_0x2bf4f9,'multi-factor-auth-required',{'_serverResponse':_0x54281e}),_0x54281e;}async function Ta(_0x1ca2b2,_0x356b3b,_0x45b6f8,_0x37fe9b){const _0x5ed809=''+_0x356b3b+_0x45b6f8+'?'+_0x37fe9b,_0x5aded1=_0x1ca2b2,_0x8e1e2c=_0x5aded1['config']['emulator']?Cs(_0x1ca2b2['config'],_0x5ed809):_0x1ca2b2['config']['apiScheme']+'://'+_0x5ed809;return ff['includes'](_0x45b6f8)&&(await _0x5aded1['_persistenceManagerAvailable'],_0x5aded1['_getPersistenceType']()==='COOKIE')?_0x5aded1['_getPersistence']()['_getFinalTarget'](_0x8e1e2c)['toString']():_0x8e1e2c;}function _f(_0x17d3e0){switch(_0x17d3e0){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x215048){this['auth']=_0x215048,this['timer']=null,this['promise']=new Promise((_0x1d2fe0,_0x2b7bd9)=>{this['timer']=setTimeout(()=>_0x2b7bd9(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x5570df,_0x45f561,_0x3264dc){const _0x2923e1={'appName':_0x5570df['name']};_0x3264dc['email']&&(_0x2923e1['email']=_0x3264dc['email']),_0x3264dc['phoneNumber']&&(_0x2923e1['phoneNumber']=_0x3264dc['phoneNumber']);const _0x36e5c7=X(_0x5570df,_0x45f561,_0x2923e1);return _0x36e5c7['customData']['_tokenResponse']=_0x3264dc,_0x36e5c7;}function wr(_0x3440f1){return _0x3440f1!==void 0x0&&_0x3440f1['enterprise']!==void 0x0;}class mf{constructor(_0x35d020){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x35d020['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x35d020['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x35d020['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x23d90f){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3b8809 of this['recaptchaEnforcementState'])if(_0x3b8809['provider']&&_0x3b8809['provider']===_0x23d90f)return _f(_0x3b8809['enforcementState']);return null;}['isProviderEnabled'](_0x164a5b){return this['getProviderEnforcementState'](_0x164a5b)==='ENFORCE'||this['getProviderEnforcementState'](_0x164a5b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2716ce,_0x5656a4){return Pe(_0x2716ce,'GET','/v2/recaptchaConfig',ke(_0x2716ce,_0x5656a4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x16be74,_0x38915c){return Pe(_0x16be74,'POST','/v1/accounts:delete',_0x38915c);}async function Pn(_0x367d57,_0x175424){return Pe(_0x367d57,'POST','/v1/accounts:lookup',_0x175424);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x228b76){if(_0x228b76)try{const _0x1193d6=new Date(Number(_0x228b76));if(!isNaN(_0x1193d6['getTime']()))return _0x1193d6['toUTCString']();}catch{}}async function Ef(_0x4703a6,_0x125958=!0x1){const _0x363afb=P(_0x4703a6),_0x6a3442=await _0x363afb['getIdToken'](_0x125958),_0x51a2cf=Ts(_0x6a3442);m(_0x51a2cf&&_0x51a2cf['exp']&&_0x51a2cf['auth_time']&&_0x51a2cf['iat'],_0x363afb['auth'],'internal-error');const _0x103ed3=typeof _0x51a2cf['firebase']=='object'?_0x51a2cf['firebase']:void 0x0,_0x2b0945=_0x103ed3==null?void 0x0:_0x103ed3['sign_in_provider'];return{'claims':_0x51a2cf,'token':_0x6a3442,'authTime':Pt(fi(_0x51a2cf['auth_time'])),'issuedAtTime':Pt(fi(_0x51a2cf['iat'])),'expirationTime':Pt(fi(_0x51a2cf['exp'])),'signInProvider':_0x2b0945||null,'signInSecondFactor':(_0x103ed3==null?void 0x0:_0x103ed3['sign_in_second_factor'])||null};}function fi(_0x365fd5){return Number(_0x365fd5)*0x3e8;}function Ts(_0x410f51){const [_0x144ff8,_0x27792e,_0x2aa877]=_0x410f51['split']('.');if(_0x144ff8===void 0x0||_0x27792e===void 0x0||_0x2aa877===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x495767=fn(_0x27792e);return _0x495767?JSON['parse'](_0x495767):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x34b0b9){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x34b0b9==null?void 0x0:_0x34b0b9['toString']()),null;}}function Cr(_0x3f4dd1){const _0x2dba41=Ts(_0x3f4dd1);return m(_0x2dba41,'internal-error'),m(typeof _0x2dba41['exp']<'u','internal-error'),m(typeof _0x2dba41['iat']<'u','internal-error'),Number(_0x2dba41['exp'])-Number(_0x2dba41['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x5a78bc,_0x21921e,_0x1f1798=!0x1){if(_0x1f1798)return _0x21921e;try{return await _0x21921e;}catch(_0x1f4d66){throw _0x1f4d66 instanceof Re&&If(_0x1f4d66)&&_0x5a78bc['auth']['currentUser']===_0x5a78bc&&await _0x5a78bc['auth']['signOut'](),_0x1f4d66;}}function If({code:_0x589534}){return _0x589534==='auth/user-disabled'||_0x589534==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x11ba96){this['user']=_0x11ba96,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x262b4c){if(_0x262b4c){const _0xf6ea05=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xf6ea05;}else{this['errorBackoff']=0x7530;const _0x47fb61=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x47fb61);}}['schedule'](_0x481c02=!0x1){if(!this['isRunning'])return;const _0x4e342e=this['getInterval'](_0x481c02);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4e342e);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1569e5){(_0x1569e5==null?void 0x0:_0x1569e5['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x43b6c5,_0x37546e){this['createdAt']=_0x43b6c5,this['lastLoginAt']=_0x37546e,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x49a749){this['createdAt']=_0x49a749['createdAt'],this['lastLoginAt']=_0x49a749['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x20d1c0){var _0x57c872;const _0x5e4132=_0x20d1c0['auth'],_0x39c2ab=await _0x20d1c0['getIdToken'](),_0x3b6c30=await Ht(_0x20d1c0,Pn(_0x5e4132,{'idToken':_0x39c2ab}));m(_0x3b6c30==null?void 0x0:_0x3b6c30['users']['length'],_0x5e4132,'internal-error');const _0x470af6=_0x3b6c30['users'][0x0];_0x20d1c0['_notifyReloadListener'](_0x470af6);const _0x11c262=(_0x57c872=_0x470af6['providerUserInfo'])!=null&&_0x57c872['length']?Sa(_0x470af6['providerUserInfo']):[],_0x3e03c5=Tf(_0x20d1c0['providerData'],_0x11c262),_0x5bc382=_0x20d1c0['isAnonymous'],_0x154b83=!(_0x20d1c0['email']&&_0x470af6['passwordHash'])&&!(_0x3e03c5!=null&&_0x3e03c5['length']),_0x243c3b=_0x5bc382?_0x154b83:!0x1,_0x297834={'uid':_0x470af6['localId'],'displayName':_0x470af6['displayName']||null,'photoURL':_0x470af6['photoUrl']||null,'email':_0x470af6['email']||null,'emailVerified':_0x470af6['emailVerified']||!0x1,'phoneNumber':_0x470af6['phoneNumber']||null,'tenantId':_0x470af6['tenantId']||null,'providerData':_0x3e03c5,'metadata':new Li(_0x470af6['createdAt'],_0x470af6['lastLoginAt']),'isAnonymous':_0x243c3b};Object['assign'](_0x20d1c0,_0x297834);}async function Cf(_0x160c75){const _0x5c7c79=P(_0x160c75);await Nn(_0x5c7c79),await _0x5c7c79['auth']['_persistUserIfCurrent'](_0x5c7c79),_0x5c7c79['auth']['_notifyListenersIfCurrent'](_0x5c7c79);}function Tf(_0x373ea3,_0x46ae64){return[..._0x373ea3['filter'](_0x59dde2=>!_0x46ae64['some'](_0x29ca33=>_0x29ca33['providerId']===_0x59dde2['providerId'])),..._0x46ae64];}function Sa(_0xf516e){return _0xf516e['map'](({providerId:_0x5aafe3,..._0x2e6c1f})=>({'providerId':_0x5aafe3,'uid':_0x2e6c1f['rawId']||'','displayName':_0x2e6c1f['displayName']||null,'email':_0x2e6c1f['email']||null,'phoneNumber':_0x2e6c1f['phoneNumber']||null,'photoURL':_0x2e6c1f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x6e6e8b,_0x12b1de){const _0x186019=await Ca(_0x6e6e8b,{},async()=>{const _0x3bc58d=ut({'grant_type':'refresh_token','refresh_token':_0x12b1de})['slice'](0x1),{tokenApiHost:_0x361bf2,apiKey:_0x451d05}=_0x6e6e8b['config'],_0x1c367d=await Ta(_0x6e6e8b,_0x361bf2,'/v1/token','key='+_0x451d05),_0x207f6f=await _0x6e6e8b['_getAdditionalHeaders']();_0x207f6f['Content-Type']='application/x-www-form-urlencoded';const _0xb6819b={'method':'POST','headers':_0x207f6f,'body':_0x3bc58d};return _0x6e6e8b['emulatorConfig']&&qt(_0x6e6e8b['emulatorConfig']['host'])&&(_0xb6819b['credentials']='include'),wa['fetch']()(_0x1c367d,_0xb6819b);});return{'accessToken':_0x186019['access_token'],'expiresIn':_0x186019['expires_in'],'refreshToken':_0x186019['refresh_token']};}async function bf(_0x25c60c,_0x200209){return Pe(_0x25c60c,'POST','/v2/accounts:revokeToken',ke(_0x25c60c,_0x200209));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3ff75b){m(_0x3ff75b['idToken'],'internal-error'),m(typeof _0x3ff75b['idToken']<'u','internal-error'),m(typeof _0x3ff75b['refreshToken']<'u','internal-error');const _0x1bb051='expiresIn'in _0x3ff75b&&typeof _0x3ff75b['expiresIn']<'u'?Number(_0x3ff75b['expiresIn']):Cr(_0x3ff75b['idToken']);this['updateTokensAndExpiration'](_0x3ff75b['idToken'],_0x3ff75b['refreshToken'],_0x1bb051);}['updateFromIdToken'](_0x1ef147){m(_0x1ef147['length']!==0x0,'internal-error');const _0x54737a=Cr(_0x1ef147);this['updateTokensAndExpiration'](_0x1ef147,null,_0x54737a);}async['getToken'](_0x17c5fa,_0x311b5d=!0x1){return!_0x311b5d&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x17c5fa,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x17c5fa,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x238106,_0x536941){const {accessToken:_0xdb1a98,refreshToken:_0x56dedf,expiresIn:_0x444d28}=await Sf(_0x238106,_0x536941);this['updateTokensAndExpiration'](_0xdb1a98,_0x56dedf,Number(_0x444d28));}['updateTokensAndExpiration'](_0x9e6f08,_0x38efa3,_0x984f77){this['refreshToken']=_0x38efa3||null,this['accessToken']=_0x9e6f08||null,this['expirationTime']=Date['now']()+_0x984f77*0x3e8;}static['fromJSON'](_0x20c9bb,_0x48a953){const {refreshToken:_0x14eb6b,accessToken:_0x334bcb,expirationTime:_0x20e492}=_0x48a953,_0x1d1a4a=new et();return _0x14eb6b&&(m(typeof _0x14eb6b=='string','internal-error',{'appName':_0x20c9bb}),_0x1d1a4a['refreshToken']=_0x14eb6b),_0x334bcb&&(m(typeof _0x334bcb=='string','internal-error',{'appName':_0x20c9bb}),_0x1d1a4a['accessToken']=_0x334bcb),_0x20e492&&(m(typeof _0x20e492=='number','internal-error',{'appName':_0x20c9bb}),_0x1d1a4a['expirationTime']=_0x20e492),_0x1d1a4a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x30d61c){this['accessToken']=_0x30d61c['accessToken'],this['refreshToken']=_0x30d61c['refreshToken'],this['expirationTime']=_0x30d61c['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x28c1dd,_0xb99b7f){m(typeof _0x28c1dd=='string'||typeof _0x28c1dd>'u','internal-error',{'appName':_0xb99b7f});}class j{constructor({uid:_0x19de1e,auth:_0x5ce3bd,stsTokenManager:_0x2d70a5,..._0x755172}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x19de1e,this['auth']=_0x5ce3bd,this['stsTokenManager']=_0x2d70a5,this['accessToken']=_0x2d70a5['accessToken'],this['displayName']=_0x755172['displayName']||null,this['email']=_0x755172['email']||null,this['emailVerified']=_0x755172['emailVerified']||!0x1,this['phoneNumber']=_0x755172['phoneNumber']||null,this['photoURL']=_0x755172['photoURL']||null,this['isAnonymous']=_0x755172['isAnonymous']||!0x1,this['tenantId']=_0x755172['tenantId']||null,this['providerData']=_0x755172['providerData']?[..._0x755172['providerData']]:[],this['metadata']=new Li(_0x755172['createdAt']||void 0x0,_0x755172['lastLoginAt']||void 0x0);}async['getIdToken'](_0x17a375){const _0x6f9893=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x17a375));return m(_0x6f9893,this['auth'],'internal-error'),this['accessToken']!==_0x6f9893&&(this['accessToken']=_0x6f9893,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x6f9893;}['getIdTokenResult'](_0x470490){return Ef(this,_0x470490);}['reload'](){return Cf(this);}['_assign'](_0x51e91d){this!==_0x51e91d&&(m(this['uid']===_0x51e91d['uid'],this['auth'],'internal-error'),this['displayName']=_0x51e91d['displayName'],this['photoURL']=_0x51e91d['photoURL'],this['email']=_0x51e91d['email'],this['emailVerified']=_0x51e91d['emailVerified'],this['phoneNumber']=_0x51e91d['phoneNumber'],this['isAnonymous']=_0x51e91d['isAnonymous'],this['tenantId']=_0x51e91d['tenantId'],this['providerData']=_0x51e91d['providerData']['map'](_0x4aa412=>({..._0x4aa412})),this['metadata']['_copy'](_0x51e91d['metadata']),this['stsTokenManager']['_assign'](_0x51e91d['stsTokenManager']));}['_clone'](_0x4666eb){const _0x47f2f5=new j({...this,'auth':_0x4666eb,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x47f2f5['metadata']['_copy'](this['metadata']),_0x47f2f5;}['_onReload'](_0x2934a2){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2934a2,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3fe141){this['reloadListener']?this['reloadListener'](_0x3fe141):this['reloadUserInfo']=_0x3fe141;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5046be,_0x21ed17=!0x1){let _0x25b2f8=!0x1;_0x5046be['idToken']&&_0x5046be['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5046be),_0x25b2f8=!0x0),_0x21ed17&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x25b2f8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x14cce4=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x14cce4})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4ec016=>({..._0x4ec016})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2d204d,_0x28febf){const _0x43c28f=_0x28febf['displayName']??void 0x0,_0x2e617e=_0x28febf['email']??void 0x0,_0x509713=_0x28febf['phoneNumber']??void 0x0,_0x539b75=_0x28febf['photoURL']??void 0x0,_0x264ff5=_0x28febf['tenantId']??void 0x0,_0x5996d0=_0x28febf['_redirectEventId']??void 0x0,_0x4748cb=_0x28febf['createdAt']??void 0x0,_0x139e88=_0x28febf['lastLoginAt']??void 0x0,{uid:_0x264469,emailVerified:_0x58dfe4,isAnonymous:_0x6d4ea1,providerData:_0x506480,stsTokenManager:_0x2f0623}=_0x28febf;m(_0x264469&&_0x2f0623,_0x2d204d,'internal-error');const _0x2c8ac8=et['fromJSON'](this['name'],_0x2f0623);m(typeof _0x264469=='string',_0x2d204d,'internal-error'),le(_0x43c28f,_0x2d204d['name']),le(_0x2e617e,_0x2d204d['name']),m(typeof _0x58dfe4=='boolean',_0x2d204d,'internal-error'),m(typeof _0x6d4ea1=='boolean',_0x2d204d,'internal-error'),le(_0x509713,_0x2d204d['name']),le(_0x539b75,_0x2d204d['name']),le(_0x264ff5,_0x2d204d['name']),le(_0x5996d0,_0x2d204d['name']),le(_0x4748cb,_0x2d204d['name']),le(_0x139e88,_0x2d204d['name']);const _0x2e7e0c=new j({'uid':_0x264469,'auth':_0x2d204d,'email':_0x2e617e,'emailVerified':_0x58dfe4,'displayName':_0x43c28f,'isAnonymous':_0x6d4ea1,'photoURL':_0x539b75,'phoneNumber':_0x509713,'tenantId':_0x264ff5,'stsTokenManager':_0x2c8ac8,'createdAt':_0x4748cb,'lastLoginAt':_0x139e88});return _0x506480&&Array['isArray'](_0x506480)&&(_0x2e7e0c['providerData']=_0x506480['map'](_0x12937d=>({..._0x12937d}))),_0x5996d0&&(_0x2e7e0c['_redirectEventId']=_0x5996d0),_0x2e7e0c;}static async['_fromIdTokenResponse'](_0x5bb87e,_0x10acfb,_0x4c61db=!0x1){const _0x8fe09c=new et();_0x8fe09c['updateFromServerResponse'](_0x10acfb);const _0x4e28d3=new j({'uid':_0x10acfb['localId'],'auth':_0x5bb87e,'stsTokenManager':_0x8fe09c,'isAnonymous':_0x4c61db});return await Nn(_0x4e28d3),_0x4e28d3;}static async['_fromGetAccountInfoResponse'](_0x347421,_0x27d216,_0x287b6f){const _0x4a78e8=_0x27d216['users'][0x0];m(_0x4a78e8['localId']!==void 0x0,'internal-error');const _0x1bc193=_0x4a78e8['providerUserInfo']!==void 0x0?Sa(_0x4a78e8['providerUserInfo']):[],_0x4691b6=!(_0x4a78e8['email']&&_0x4a78e8['passwordHash'])&&!(_0x1bc193!=null&&_0x1bc193['length']),_0x4f9d1b=new et();_0x4f9d1b['updateFromIdToken'](_0x287b6f);const _0xfaaf57=new j({'uid':_0x4a78e8['localId'],'auth':_0x347421,'stsTokenManager':_0x4f9d1b,'isAnonymous':_0x4691b6}),_0x216b8c={'uid':_0x4a78e8['localId'],'displayName':_0x4a78e8['displayName']||null,'photoURL':_0x4a78e8['photoUrl']||null,'email':_0x4a78e8['email']||null,'emailVerified':_0x4a78e8['emailVerified']||!0x1,'phoneNumber':_0x4a78e8['phoneNumber']||null,'tenantId':_0x4a78e8['tenantId']||null,'providerData':_0x1bc193,'metadata':new Li(_0x4a78e8['createdAt'],_0x4a78e8['lastLoginAt']),'isAnonymous':!(_0x4a78e8['email']&&_0x4a78e8['passwordHash'])&&!(_0x1bc193!=null&&_0x1bc193['length'])};return Object['assign'](_0xfaaf57,_0x216b8c),_0xfaaf57;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x29492a){ce(_0x29492a instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2de007=Tr['get'](_0x29492a);return _0x2de007?(ce(_0x2de007 instanceof _0x29492a,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2de007):(_0x2de007=new _0x29492a(),Tr['set'](_0x29492a,_0x2de007),_0x2de007);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x553fad,_0x366814){this['storage'][_0x553fad]=_0x366814;}async['_get'](_0x33b129){const _0x5da0e0=this['storage'][_0x33b129];return _0x5da0e0===void 0x0?null:_0x5da0e0;}async['_remove'](_0x59e399){delete this['storage'][_0x59e399];}['_addListener'](_0x341400,_0x52d5fd){}['_removeListener'](_0x51beee,_0x334120){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3ac11e,_0x3922c1,_0x4bd3d2){return'firebase:'+_0x3ac11e+':'+_0x3922c1+':'+_0x4bd3d2;}class tt{constructor(_0x2487be,_0xab2846,_0x14f33c){this['persistence']=_0x2487be,this['auth']=_0xab2846,this['userKey']=_0x14f33c;const {config:_0x2eaf3a,name:_0x348f3a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2eaf3a['apiKey'],_0x348f3a),this['fullPersistenceKey']=ln('persistence',_0x2eaf3a['apiKey'],_0x348f3a),this['boundEventHandler']=_0xab2846['_onStorageEvent']['bind'](_0xab2846),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4237de){return this['persistence']['_set'](this['fullUserKey'],_0x4237de['toJSON']());}async['getCurrentUser'](){const _0x1b8e57=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1b8e57)return null;if(typeof _0x1b8e57=='string'){const _0x591021=await Pn(this['auth'],{'idToken':_0x1b8e57})['catch'](()=>{});return _0x591021?j['_fromGetAccountInfoResponse'](this['auth'],_0x591021,_0x1b8e57):null;}return j['_fromJSON'](this['auth'],_0x1b8e57);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x6b9488){if(this['persistence']===_0x6b9488)return;const _0x3b5d60=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x6b9488,_0x3b5d60)return this['setCurrentUser'](_0x3b5d60);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xfb1dea,_0x49bc80,_0x1dea54='authUser'){if(!_0x49bc80['length'])return new tt(ie(Sr),_0xfb1dea,_0x1dea54);const _0x45b3d0=(await Promise['all'](_0x49bc80['map'](async _0x1d0fc6=>{if(await _0x1d0fc6['_isAvailable']())return _0x1d0fc6;})))['filter'](_0x550c74=>_0x550c74);let _0x1f76e9=_0x45b3d0[0x0]||ie(Sr);const _0x5c5f81=ln(_0x1dea54,_0xfb1dea['config']['apiKey'],_0xfb1dea['name']);let _0x2c10d2=null;for(const _0xc3af43 of _0x49bc80)try{const _0x563cea=await _0xc3af43['_get'](_0x5c5f81);if(_0x563cea){let _0x435d11;if(typeof _0x563cea=='string'){const _0x213485=await Pn(_0xfb1dea,{'idToken':_0x563cea})['catch'](()=>{});if(!_0x213485)break;_0x435d11=await j['_fromGetAccountInfoResponse'](_0xfb1dea,_0x213485,_0x563cea);}else _0x435d11=j['_fromJSON'](_0xfb1dea,_0x563cea);_0xc3af43!==_0x1f76e9&&(_0x2c10d2=_0x435d11),_0x1f76e9=_0xc3af43;break;}}catch{}const _0x250c51=_0x45b3d0['filter'](_0x5b0f15=>_0x5b0f15['_shouldAllowMigration']);return!_0x1f76e9['_shouldAllowMigration']||!_0x250c51['length']?new tt(_0x1f76e9,_0xfb1dea,_0x1dea54):(_0x1f76e9=_0x250c51[0x0],_0x2c10d2&&await _0x1f76e9['_set'](_0x5c5f81,_0x2c10d2['toJSON']()),await Promise['all'](_0x49bc80['map'](async _0x154174=>{if(_0x154174!==_0x1f76e9)try{await _0x154174['_remove'](_0x5c5f81);}catch{}})),new tt(_0x1f76e9,_0xfb1dea,_0x1dea54));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4d110a){const _0x5d122a=_0x4d110a['toLowerCase']();if(_0x5d122a['includes']('opera/')||_0x5d122a['includes']('opr/')||_0x5d122a['includes']('opios/'))return'Opera';if(Pa(_0x5d122a))return'IEMobile';if(_0x5d122a['includes']('msie')||_0x5d122a['includes']('trident/'))return'IE';if(_0x5d122a['includes']('edge/'))return'Edge';if(Ra(_0x5d122a))return'Firefox';if(_0x5d122a['includes']('silk/'))return'Silk';if(Oa(_0x5d122a))return'Blackberry';if(Da(_0x5d122a))return'Webos';if(Aa(_0x5d122a))return'Safari';if((_0x5d122a['includes']('chrome/')||ka(_0x5d122a))&&!_0x5d122a['includes']('edge/'))return'Chrome';if(Na(_0x5d122a))return'Android';{const _0x1f0fe9=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x294f26=_0x4d110a['match'](_0x1f0fe9);if((_0x294f26==null?void 0x0:_0x294f26['length'])===0x2)return _0x294f26[0x1];}return'Other';}function Ra(_0x40b35f=W()){return/firefox\//i['test'](_0x40b35f);}function Aa(_0x14288d=W()){const _0x5e6b51=_0x14288d['toLowerCase']();return _0x5e6b51['includes']('safari/')&&!_0x5e6b51['includes']('chrome/')&&!_0x5e6b51['includes']('crios/')&&!_0x5e6b51['includes']('android');}function ka(_0x15d6e4=W()){return/crios\//i['test'](_0x15d6e4);}function Pa(_0x378fa4=W()){return/iemobile/i['test'](_0x378fa4);}function Na(_0x5dfebd=W()){return/android/i['test'](_0x5dfebd);}function Oa(_0x15a39a=W()){return/blackberry/i['test'](_0x15a39a);}function Da(_0x31fb89=W()){return/webos/i['test'](_0x31fb89);}function Ss(_0x3438d=W()){return/iphone|ipad|ipod/i['test'](_0x3438d)||/macintosh/i['test'](_0x3438d)&&/mobile/i['test'](_0x3438d);}function Rf(_0xebf4b3=W()){var _0x4af20d;return Ss(_0xebf4b3)&&!!((_0x4af20d=window['navigator'])!=null&&_0x4af20d['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2795e3=W()){return Ss(_0x2795e3)||Na(_0x2795e3)||Da(_0x2795e3)||Oa(_0x2795e3)||/windows phone/i['test'](_0x2795e3)||Pa(_0x2795e3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x127766,_0xfa2926=[]){let _0xd7178c;switch(_0x127766){case'Browser':_0xd7178c=br(W());break;case'Worker':_0xd7178c=br(W())+'-'+_0x127766;break;default:_0xd7178c=_0x127766;}const _0x4a2565=_0xfa2926['length']?_0xfa2926['join'](','):'FirebaseCore-web';return _0xd7178c+'/JsCore/'+dt+'/'+_0x4a2565;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x16fcc6){this['auth']=_0x16fcc6,this['queue']=[];}['pushCallback'](_0xdd6ba7,_0x396c43){const _0x57ce3e=_0x37dce8=>new Promise((_0x3edc48,_0xd0dcd3)=>{try{const _0x379c76=_0xdd6ba7(_0x37dce8);_0x3edc48(_0x379c76);}catch(_0x884606){_0xd0dcd3(_0x884606);}});_0x57ce3e['onAbort']=_0x396c43,this['queue']['push'](_0x57ce3e);const _0x588a17=this['queue']['length']-0x1;return()=>{this['queue'][_0x588a17]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1063d6){if(this['auth']['currentUser']===_0x1063d6)return;const _0x226325=[];try{for(const _0xfc8804 of this['queue'])await _0xfc8804(_0x1063d6),_0xfc8804['onAbort']&&_0x226325['push'](_0xfc8804['onAbort']);}catch(_0x10d658){_0x226325['reverse']();for(const _0x5c766e of _0x226325)try{_0x5c766e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x10d658==null?void 0x0:_0x10d658['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x2061ae,_0x47c9e3={}){return Pe(_0x2061ae,'GET','/v2/passwordPolicy',ke(_0x2061ae,_0x47c9e3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x57d2fe){var _0x455df1;const _0x327f7a=_0x57d2fe['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x327f7a['minPasswordLength']??Nf,_0x327f7a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x327f7a['maxPasswordLength']),_0x327f7a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x327f7a['containsLowercaseCharacter']),_0x327f7a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x327f7a['containsUppercaseCharacter']),_0x327f7a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x327f7a['containsNumericCharacter']),_0x327f7a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x327f7a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x57d2fe['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x455df1=_0x57d2fe['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x455df1['join'](''))??'',this['forceUpgradeOnSignin']=_0x57d2fe['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x57d2fe['schemaVersion'];}['validatePassword'](_0x35dbfb){const _0x1deac0={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x35dbfb,_0x1deac0),this['validatePasswordCharacterOptions'](_0x35dbfb,_0x1deac0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['meetsMinPasswordLength']??!0x0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['meetsMaxPasswordLength']??!0x0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['containsLowercaseLetter']??!0x0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['containsUppercaseLetter']??!0x0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['containsNumericCharacter']??!0x0),_0x1deac0['isValid']&&(_0x1deac0['isValid']=_0x1deac0['containsNonAlphanumericCharacter']??!0x0),_0x1deac0;}['validatePasswordLengthOptions'](_0x130ba1,_0x5833b5){const _0x1dfea2=this['customStrengthOptions']['minPasswordLength'],_0x494f1a=this['customStrengthOptions']['maxPasswordLength'];_0x1dfea2&&(_0x5833b5['meetsMinPasswordLength']=_0x130ba1['length']>=_0x1dfea2),_0x494f1a&&(_0x5833b5['meetsMaxPasswordLength']=_0x130ba1['length']<=_0x494f1a);}['validatePasswordCharacterOptions'](_0x1057e6,_0x2c7c2d){this['updatePasswordCharacterOptionsStatuses'](_0x2c7c2d,!0x1,!0x1,!0x1,!0x1);let _0x1cf437;for(let _0x1f80f=0x0;_0x1f80f<_0x1057e6['length'];_0x1f80f++)_0x1cf437=_0x1057e6['charAt'](_0x1f80f),this['updatePasswordCharacterOptionsStatuses'](_0x2c7c2d,_0x1cf437>='a'&&_0x1cf437<='z',_0x1cf437>='A'&&_0x1cf437<='Z',_0x1cf437>='0'&&_0x1cf437<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1cf437));}['updatePasswordCharacterOptionsStatuses'](_0xe0f3b7,_0x193d67,_0xc24328,_0x8c08bb,_0x4540c6){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xe0f3b7['containsLowercaseLetter']||(_0xe0f3b7['containsLowercaseLetter']=_0x193d67)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xe0f3b7['containsUppercaseLetter']||(_0xe0f3b7['containsUppercaseLetter']=_0xc24328)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xe0f3b7['containsNumericCharacter']||(_0xe0f3b7['containsNumericCharacter']=_0x8c08bb)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xe0f3b7['containsNonAlphanumericCharacter']||(_0xe0f3b7['containsNonAlphanumericCharacter']=_0x4540c6));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5dee36,_0x487cf5,_0x594736,_0x2a051a){this['app']=_0x5dee36,this['heartbeatServiceProvider']=_0x487cf5,this['appCheckServiceProvider']=_0x594736,this['config']=_0x2a051a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5dee36['name'],this['clientVersion']=_0x2a051a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4f185c=>this['_resolvePersistenceManagerAvailable']=_0x4f185c);}['_initializeWithPersistence'](_0xac2e86,_0x5bc67f){return _0x5bc67f&&(this['_popupRedirectResolver']=ie(_0x5bc67f)),this['_initializationPromise']=this['queue'](async()=>{var _0x2c57af,_0x576abb,_0x51646e;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0xac2e86),(_0x2c57af=this['_resolvePersistenceManagerAvailable'])==null||_0x2c57af['call'](this),!this['_deleted'])){if((_0x576abb=this['_popupRedirectResolver'])!=null&&_0x576abb['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5bc67f),this['lastNotifiedUid']=((_0x51646e=this['currentUser'])==null?void 0x0:_0x51646e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x35cf31=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x35cf31)){if(this['currentUser']&&_0x35cf31&&this['currentUser']['uid']===_0x35cf31['uid']){this['_currentUser']['_assign'](_0x35cf31),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x35cf31,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x42265c){try{const _0x2ee454=await Pn(this,{'idToken':_0x42265c}),_0x1e490b=await j['_fromGetAccountInfoResponse'](this,_0x2ee454,_0x42265c);await this['directlySetCurrentUser'](_0x1e490b);}catch(_0x14106d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x14106d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3d8337){var _0x59d48d;if($(this['app'])){const _0x179d0b=this['app']['settings']['authIdToken'];return _0x179d0b?new Promise(_0x43f2f3=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x179d0b)['then'](_0x43f2f3,_0x43f2f3));}):this['directlySetCurrentUser'](null);}const _0x36625a=await this['assertedPersistence']['getCurrentUser']();let _0x42a783=_0x36625a,_0x45ce20=!0x1;if(_0x3d8337&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x12b22b=(_0x59d48d=this['redirectUser'])==null?void 0x0:_0x59d48d['_redirectEventId'],_0x308c0d=_0x42a783==null?void 0x0:_0x42a783['_redirectEventId'],_0x5c78f9=await this['tryRedirectSignIn'](_0x3d8337);(!_0x12b22b||_0x12b22b===_0x308c0d)&&(_0x5c78f9!=null&&_0x5c78f9['user'])&&(_0x42a783=_0x5c78f9['user'],_0x45ce20=!0x0);}if(!_0x42a783)return this['directlySetCurrentUser'](null);if(!_0x42a783['_redirectEventId']){if(_0x45ce20)try{await this['beforeStateQueue']['runMiddleware'](_0x42a783);}catch(_0x38d363){_0x42a783=_0x36625a,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x38d363));}return _0x42a783?this['reloadAndSetCurrentUserOrClear'](_0x42a783):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x42a783['_redirectEventId']?this['directlySetCurrentUser'](_0x42a783):this['reloadAndSetCurrentUserOrClear'](_0x42a783);}async['tryRedirectSignIn'](_0x268616){let _0x3ad559=null;try{_0x3ad559=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x268616,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3ad559;}async['reloadAndSetCurrentUserOrClear'](_0x107ba8){try{await Nn(_0x107ba8);}catch(_0x32f6e8){if((_0x32f6e8==null?void 0x0:_0x32f6e8['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x107ba8);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x570367){if($(this['app']))return Promise['reject'](re(this));const _0x3c352a=_0x570367?P(_0x570367):null;return _0x3c352a&&m(_0x3c352a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3c352a&&_0x3c352a['_clone'](this));}async['_updateCurrentUser'](_0x3304bb,_0x2620ec=!0x1){if(!this['_deleted'])return _0x3304bb&&m(this['tenantId']===_0x3304bb['tenantId'],this,'tenant-id-mismatch'),_0x2620ec||await this['beforeStateQueue']['runMiddleware'](_0x3304bb),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3304bb),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4dbd20){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4dbd20));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x14ed69){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4fa992=this['_getPasswordPolicyInternal']();return _0x4fa992['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4fa992['validatePassword'](_0x14ed69);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x40de42=await Pf(this),_0x28caa2=new Of(_0x40de42);this['tenantId']===null?this['_projectPasswordPolicy']=_0x28caa2:this['_tenantPasswordPolicies'][this['tenantId']]=_0x28caa2;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xa9b556){this['_errorFactory']=new Gt('auth','Firebase',_0xa9b556());}['onAuthStateChanged'](_0x238b7c,_0x1ff122,_0x1d0b52){return this['registerStateListener'](this['authStateSubscription'],_0x238b7c,_0x1ff122,_0x1d0b52);}['beforeAuthStateChanged'](_0x16572f,_0xfd2357){return this['beforeStateQueue']['pushCallback'](_0x16572f,_0xfd2357);}['onIdTokenChanged'](_0x4bd5bc,_0x23c863,_0x1ae932){return this['registerStateListener'](this['idTokenSubscription'],_0x4bd5bc,_0x23c863,_0x1ae932);}['authStateReady'](){return new Promise((_0x482e96,_0x2e7cb4)=>{if(this['currentUser'])_0x482e96();else{const _0x54a02f=this['onAuthStateChanged'](()=>{_0x54a02f(),_0x482e96();},_0x2e7cb4);}});}async['revokeAccessToken'](_0x2fdce1){if(this['currentUser']){const _0x2972e3=await this['currentUser']['getIdToken'](),_0x5348f5={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2fdce1,'idToken':_0x2972e3};this['tenantId']!=null&&(_0x5348f5['tenantId']=this['tenantId']),await bf(this,_0x5348f5);}}['toJSON'](){var _0x162aa8;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x162aa8=this['_currentUser'])==null?void 0x0:_0x162aa8['toJSON']()};}async['_setRedirectUser'](_0x57d8f6,_0x2efd3f){const _0x4a9e38=await this['getOrInitRedirectPersistenceManager'](_0x2efd3f);return _0x57d8f6===null?_0x4a9e38['removeCurrentUser']():_0x4a9e38['setCurrentUser'](_0x57d8f6);}async['getOrInitRedirectPersistenceManager'](_0x59f85b){if(!this['redirectPersistenceManager']){const _0x13da88=_0x59f85b&&ie(_0x59f85b)||this['_popupRedirectResolver'];m(_0x13da88,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x13da88['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x53bc5d){var _0x17d620,_0x395a83;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x17d620=this['_currentUser'])==null?void 0x0:_0x17d620['_redirectEventId'])===_0x53bc5d?this['_currentUser']:((_0x395a83=this['redirectUser'])==null?void 0x0:_0x395a83['_redirectEventId'])===_0x53bc5d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1140a2){if(_0x1140a2===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1140a2));}['_notifyListenersIfCurrent'](_0x5e3b79){_0x5e3b79===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2d19af;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x489e6c=((_0x2d19af=this['currentUser'])==null?void 0x0:_0x2d19af['uid'])??null;this['lastNotifiedUid']!==_0x489e6c&&(this['lastNotifiedUid']=_0x489e6c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2e4928,_0x3c47f5,_0x1b602e,_0x43b866){if(this['_deleted'])return()=>{};const _0x1c05f9=typeof _0x3c47f5=='function'?_0x3c47f5:_0x3c47f5['next']['bind'](_0x3c47f5);let _0x5cd05e=!0x1;const _0x336e06=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x336e06,this,'internal-error'),_0x336e06['then'](()=>{_0x5cd05e||_0x1c05f9(this['currentUser']);}),typeof _0x3c47f5=='function'){const _0x2277e9=_0x2e4928['addObserver'](_0x3c47f5,_0x1b602e,_0x43b866);return()=>{_0x5cd05e=!0x0,_0x2277e9();};}else{const _0x14d313=_0x2e4928['addObserver'](_0x3c47f5);return()=>{_0x5cd05e=!0x0,_0x14d313();};}}async['directlySetCurrentUser'](_0x908107){this['currentUser']&&this['currentUser']!==_0x908107&&this['_currentUser']['_stopProactiveRefresh'](),_0x908107&&this['isProactiveRefreshEnabled']&&_0x908107['_startProactiveRefresh'](),this['currentUser']=_0x908107,_0x908107?await this['assertedPersistence']['setCurrentUser'](_0x908107):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4cd734){return this['operations']=this['operations']['then'](_0x4cd734,_0x4cd734),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4df119){!_0x4df119||this['frameworks']['includes'](_0x4df119)||(this['frameworks']['push'](_0x4df119),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x24b795;const _0x53e8bd={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x53e8bd['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3280e0=await((_0x24b795=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x24b795['getHeartbeatsHeader']());_0x3280e0&&(_0x53e8bd['X-Firebase-Client']=_0x3280e0);const _0x3eaa23=await this['_getAppCheckToken']();return _0x3eaa23&&(_0x53e8bd['X-Firebase-AppCheck']=_0x3eaa23),_0x53e8bd;}async['_getAppCheckToken'](){var _0xb256d7;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5aa7e8=await((_0xb256d7=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xb256d7['getToken']());return _0x5aa7e8!=null&&_0x5aa7e8['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5aa7e8['error']),_0x5aa7e8==null?void 0x0:_0x5aa7e8['token'];}}function Ke(_0xe8bc26){return P(_0xe8bc26);}class Rr{constructor(_0x2f6310){this['auth']=_0x2f6310,this['observer']=null,this['addObserver']=Tc(_0x566d4b=>this['observer']=_0x566d4b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2b0a98){Jn=_0x2b0a98;}function xa(_0x581c67){return Jn['loadJS'](_0x581c67);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0xa0aa08){return'__'+_0xa0aa08+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x225e5f){_0x225e5f();}['execute'](_0x11d5fc,_0x179e4c){return Promise['resolve']('token');}['render'](_0x4aef99,_0x51ef9b){return'';}}class Wf{['ready'](_0x4db768){_0x4db768();}['execute'](_0xfdae9c,_0x5e233f){return Promise['resolve']('token');}['render'](_0x2b6d42,_0x3531c6){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3efbbb){this['type']=Bf,this['auth']=Ke(_0x3efbbb);}async['verify'](_0x93811c='verify',_0xa7a37d=!0x1){async function _0x24d600(_0x2470de){if(!_0xa7a37d){if(_0x2470de['tenantId']==null&&_0x2470de['_agentRecaptchaConfig']!=null)return _0x2470de['_agentRecaptchaConfig']['siteKey'];if(_0x2470de['tenantId']!=null&&_0x2470de['_tenantRecaptchaConfigs'][_0x2470de['tenantId']]!==void 0x0)return _0x2470de['_tenantRecaptchaConfigs'][_0x2470de['tenantId']]['siteKey'];}return new Promise(async(_0x1eadde,_0x3dffc3)=>{yf(_0x2470de,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2c7b09=>{if(_0x2c7b09['recaptchaKey']===void 0x0)_0x3dffc3(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3ef47a=new mf(_0x2c7b09);return _0x2470de['tenantId']==null?_0x2470de['_agentRecaptchaConfig']=_0x3ef47a:_0x2470de['_tenantRecaptchaConfigs'][_0x2470de['tenantId']]=_0x3ef47a,_0x1eadde(_0x3ef47a['siteKey']);}})['catch'](_0x3fbae5=>{_0x3dffc3(_0x3fbae5);});});}function _0x34bd72(_0x487d70,_0x2cfa42,_0x55ae9b){const _0x123402=window['grecaptcha'];wr(_0x123402)?_0x123402['enterprise']['ready'](()=>{_0x123402['enterprise']['execute'](_0x487d70,{'action':_0x93811c})['then'](_0x15f3f1=>{_0x2cfa42(_0x15f3f1);})['catch'](()=>{_0x2cfa42(Fa);});}):_0x55ae9b(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1493b3,_0x1cd757)=>{_0x24d600(this['auth'])['then'](async _0x521536=>{if(!_0xa7a37d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x34bd72(_0x521536,_0x1493b3,_0x1cd757);else{if(typeof window>'u'){_0x1cd757(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2a5a7a=Lf();_0x2a5a7a['length']!==0x0&&(_0x2a5a7a+=_0x521536+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x3c2564;(_0x3c2564=he['scriptInjectionDeferred'])==null||_0x3c2564['resolve']();},xa(_0x2a5a7a)['then'](()=>{var _0x553563;return(_0x553563=he['scriptInjectionDeferred'])==null?void 0x0:_0x553563['promise'];})['then'](()=>{_0x34bd72(_0x521536,_0x1493b3,_0x1cd757);})['catch'](_0xe0edc3=>{_0x1cd757(_0xe0edc3);});}})['catch'](_0x4f5d45=>{_0x1cd757(_0x4f5d45);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x50d0ff,_0x453653,_0x352a42,_0x4650bd=!0x1,_0x3e253c=!0x1){const _0x24c541=new he(_0x50d0ff);let _0x53e64c;if(_0x3e253c)_0x53e64c=Fa;else try{_0x53e64c=await _0x24c541['verify'](_0x352a42);}catch{_0x53e64c=await _0x24c541['verify'](_0x352a42,!0x0);}const _0x40036f={..._0x453653};if(_0x352a42==='mfaSmsEnrollment'||_0x352a42==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x40036f){const _0x2475c4=_0x40036f['phoneEnrollmentInfo']['phoneNumber'],_0x5c39ec=_0x40036f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x40036f,{'phoneEnrollmentInfo':{'phoneNumber':_0x2475c4,'recaptchaToken':_0x5c39ec,'captchaResponse':_0x53e64c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x40036f){const _0xcfe887=_0x40036f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x40036f,{'phoneSignInInfo':{'recaptchaToken':_0xcfe887,'captchaResponse':_0x53e64c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x40036f;}return _0x4650bd?Object['assign'](_0x40036f,{'captchaResp':_0x53e64c}):Object['assign'](_0x40036f,{'captchaResponse':_0x53e64c}),Object['assign'](_0x40036f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x40036f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x40036f;}async function xi(_0x4c81e5,_0x460124,_0x1a5ec1,_0x4f541e,_0x33d133){var _0x20cb34;if((_0x20cb34=_0x4c81e5['_getRecaptchaConfig']())!=null&&_0x20cb34['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2c15bf=await kr(_0x4c81e5,_0x460124,_0x1a5ec1,_0x1a5ec1==='getOobCode');return _0x4f541e(_0x4c81e5,_0x2c15bf);}else return _0x4f541e(_0x4c81e5,_0x460124)['catch'](async _0x4419c1=>{if(_0x4419c1['code']==='auth/missing-recaptcha-token'){console['log'](_0x1a5ec1+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xb5ad3f=await kr(_0x4c81e5,_0x460124,_0x1a5ec1,_0x1a5ec1==='getOobCode');return _0x4f541e(_0x4c81e5,_0xb5ad3f);}else return Promise['reject'](_0x4419c1);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x4a94fd,_0x3a31d9){const _0x3bf44c=Hi(_0x4a94fd,'auth');if(_0x3bf44c['isInitialized']()){const _0x4e87d0=_0x3bf44c['getImmediate'](),_0x1cb2b1=_0x3bf44c['getOptions']();if(xe(_0x1cb2b1,_0x3a31d9??{}))return _0x4e87d0;Y(_0x4e87d0,'already-initialized');}return _0x3bf44c['initialize']({'options':_0x3a31d9});}function Hf(_0x1534da,_0x4dbe4d){const _0x149848=(_0x4dbe4d==null?void 0x0:_0x4dbe4d['persistence'])||[],_0x1dcfd8=(Array['isArray'](_0x149848)?_0x149848:[_0x149848])['map'](ie);_0x4dbe4d!=null&&_0x4dbe4d['errorMap']&&_0x1534da['_updateErrorMap'](_0x4dbe4d['errorMap']),_0x1534da['_initializeWithPersistence'](_0x1dcfd8,_0x4dbe4d==null?void 0x0:_0x4dbe4d['popupRedirectResolver']);}function $f(_0x1dd4cf,_0x1abbed,_0x5225a6){const _0x5214f3=Ke(_0x1dd4cf);m(/^https?:\/\//['test'](_0x1abbed),_0x5214f3,'invalid-emulator-scheme');const _0x154c9b=!0x1,_0x52dca2=Ua(_0x1abbed),{host:_0x2353ea,port:_0x4f91cc}=Gf(_0x1abbed),_0x1b7fc1=_0x4f91cc===null?'':':'+_0x4f91cc,_0x435792={'url':_0x52dca2+'//'+_0x2353ea+_0x1b7fc1+'/'},_0x568865=Object['freeze']({'host':_0x2353ea,'port':_0x4f91cc,'protocol':_0x52dca2['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x154c9b})});if(!_0x5214f3['_canInitEmulator']){m(_0x5214f3['config']['emulator']&&_0x5214f3['emulatorConfig'],_0x5214f3,'emulator-config-failed'),m(xe(_0x435792,_0x5214f3['config']['emulator'])&&xe(_0x568865,_0x5214f3['emulatorConfig']),_0x5214f3,'emulator-config-failed');return;}_0x5214f3['config']['emulator']=_0x435792,_0x5214f3['emulatorConfig']=_0x568865,_0x5214f3['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x2353ea)?Qr(_0x52dca2+'//'+_0x2353ea+_0x1b7fc1):qf();}function Ua(_0x51e0a9){const _0x6ece6f=_0x51e0a9['indexOf'](':');return _0x6ece6f<0x0?'':_0x51e0a9['substr'](0x0,_0x6ece6f+0x1);}function Gf(_0x1233c2){const _0x4c9c8b=Ua(_0x1233c2),_0x3382fb=/(\/\/)?([^?#/]+)/['exec'](_0x1233c2['substr'](_0x4c9c8b['length']));if(!_0x3382fb)return{'host':'','port':null};const _0x586f62=_0x3382fb[0x2]['split']('@')['pop']()||'',_0x81f55d=/^(\[[^\]]+\])(:|$)/['exec'](_0x586f62);if(_0x81f55d){const _0x476a2d=_0x81f55d[0x1];return{'host':_0x476a2d,'port':Pr(_0x586f62['substr'](_0x476a2d['length']+0x1))};}else{const [_0x350fb3,_0x291e12]=_0x586f62['split'](':');return{'host':_0x350fb3,'port':Pr(_0x291e12)};}}function Pr(_0xae79d9){if(!_0xae79d9)return null;const _0x351079=Number(_0xae79d9);return isNaN(_0x351079)?null:_0x351079;}function qf(){function _0x255fea(){const _0x594605=document['createElement']('p'),_0x4d7de8=_0x594605['style'];_0x594605['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4d7de8['position']='fixed',_0x4d7de8['width']='100%',_0x4d7de8['backgroundColor']='#ffffff',_0x4d7de8['border']='.1em\x20solid\x20#000000',_0x4d7de8['color']='#b50000',_0x4d7de8['bottom']='0px',_0x4d7de8['left']='0px',_0x4d7de8['margin']='0px',_0x4d7de8['zIndex']='10000',_0x4d7de8['textAlign']='center',_0x594605['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x594605);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x255fea):_0x255fea());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x568851,_0x5f39c0){this['providerId']=_0x568851,this['signInMethod']=_0x5f39c0;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x25a9e4){return ne('not\x20implemented');}['_linkToIdToken'](_0x53c458,_0x1f82d1){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x28ac46){return ne('not\x20implemented');}}async function zf(_0xeaa658,_0xde287c){return Pe(_0xeaa658,'POST','/v1/accounts:signUp',_0xde287c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x43c2ee,_0x47c0ad){return en(_0x43c2ee,'POST','/v1/accounts:signInWithPassword',ke(_0x43c2ee,_0x47c0ad));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x8b82b8,_0x1c6a6c){return en(_0x8b82b8,'POST','/v1/accounts:signInWithEmailLink',ke(_0x8b82b8,_0x1c6a6c));}async function Yf(_0x241c05,_0x122260){return en(_0x241c05,'POST','/v1/accounts:signInWithEmailLink',ke(_0x241c05,_0x122260));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x11a441,_0x4dc164,_0x1bec2d,_0x33cb27=null){super('password',_0x1bec2d),this['_email']=_0x11a441,this['_password']=_0x4dc164,this['_tenantId']=_0x33cb27;}static['_fromEmailAndPassword'](_0xf4a52,_0x201a65){return new $t(_0xf4a52,_0x201a65,'password');}static['_fromEmailAndCode'](_0x10d013,_0x810e3f,_0x40efcf=null){return new $t(_0x10d013,_0x810e3f,'emailLink',_0x40efcf);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xadc377){const _0x435eb7=typeof _0xadc377=='string'?JSON['parse'](_0xadc377):_0xadc377;if(_0x435eb7!=null&&_0x435eb7['email']&&(_0x435eb7!=null&&_0x435eb7['password'])){if(_0x435eb7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x435eb7['email'],_0x435eb7['password']);if(_0x435eb7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x435eb7['email'],_0x435eb7['password'],_0x435eb7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5567f7){switch(this['signInMethod']){case'password':const _0xae27d7={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5567f7,_0xae27d7,'signInWithPassword',jf);case'emailLink':return Kf(_0x5567f7,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5567f7,'internal-error');}}async['_linkToIdToken'](_0x2c6fb1,_0xaffb7c){switch(this['signInMethod']){case'password':const _0x395468={'idToken':_0xaffb7c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2c6fb1,_0x395468,'signUpPassword',zf);case'emailLink':return Yf(_0x2c6fb1,{'idToken':_0xaffb7c,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2c6fb1,'internal-error');}}['_getReauthenticationResolver'](_0x6bdc62){return this['_getIdTokenResponse'](_0x6bdc62);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x5c77c8,_0x12b694){return en(_0x5c77c8,'POST','/v1/accounts:signInWithIdp',ke(_0x5c77c8,_0x12b694));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2212f6){const _0x4148e1=new $e(_0x2212f6['providerId'],_0x2212f6['signInMethod']);return _0x2212f6['idToken']||_0x2212f6['accessToken']?(_0x2212f6['idToken']&&(_0x4148e1['idToken']=_0x2212f6['idToken']),_0x2212f6['accessToken']&&(_0x4148e1['accessToken']=_0x2212f6['accessToken']),_0x2212f6['nonce']&&!_0x2212f6['pendingToken']&&(_0x4148e1['nonce']=_0x2212f6['nonce']),_0x2212f6['pendingToken']&&(_0x4148e1['pendingToken']=_0x2212f6['pendingToken'])):_0x2212f6['oauthToken']&&_0x2212f6['oauthTokenSecret']?(_0x4148e1['accessToken']=_0x2212f6['oauthToken'],_0x4148e1['secret']=_0x2212f6['oauthTokenSecret']):Y('argument-error'),_0x4148e1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1cb387){const _0x3a8573=typeof _0x1cb387=='string'?JSON['parse'](_0x1cb387):_0x1cb387,{providerId:_0x3e172c,signInMethod:_0x5e6540,..._0x3e7072}=_0x3a8573;if(!_0x3e172c||!_0x5e6540)return null;const _0x393b03=new $e(_0x3e172c,_0x5e6540);return _0x393b03['idToken']=_0x3e7072['idToken']||void 0x0,_0x393b03['accessToken']=_0x3e7072['accessToken']||void 0x0,_0x393b03['secret']=_0x3e7072['secret'],_0x393b03['nonce']=_0x3e7072['nonce'],_0x393b03['pendingToken']=_0x3e7072['pendingToken']||null,_0x393b03;}['_getIdTokenResponse'](_0x581acc){const _0x15b212=this['buildRequest']();return nt(_0x581acc,_0x15b212);}['_linkToIdToken'](_0x9b37e8,_0xb520f0){const _0x291b83=this['buildRequest']();return _0x291b83['idToken']=_0xb520f0,nt(_0x9b37e8,_0x291b83);}['_getReauthenticationResolver'](_0x3a0f79){const _0x253066=this['buildRequest']();return _0x253066['autoCreate']=!0x1,nt(_0x3a0f79,_0x253066);}['buildRequest'](){const _0x318c53={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x318c53['pendingToken']=this['pendingToken'];else{const _0x28a1bd={};this['idToken']&&(_0x28a1bd['id_token']=this['idToken']),this['accessToken']&&(_0x28a1bd['access_token']=this['accessToken']),this['secret']&&(_0x28a1bd['oauth_token_secret']=this['secret']),_0x28a1bd['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x28a1bd['nonce']=this['nonce']),_0x318c53['postBody']=ut(_0x28a1bd);}return _0x318c53;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x3ca5d1){switch(_0x3ca5d1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x31f85f){const _0x4779d5=Ct(Tt(_0x31f85f))['link'],_0x41475b=_0x4779d5?Ct(Tt(_0x4779d5))['deep_link_id']:null,_0x4fee45=Ct(Tt(_0x31f85f))['deep_link_id'];return(_0x4fee45?Ct(Tt(_0x4fee45))['link']:null)||_0x4fee45||_0x41475b||_0x4779d5||_0x31f85f;}class Rs{constructor(_0x238cc2){const _0x290547=Ct(Tt(_0x238cc2)),_0x4085d7=_0x290547['apiKey']??null,_0x4038a3=_0x290547['oobCode']??null,_0x177bd0=Jf(_0x290547['mode']??null);m(_0x4085d7&&_0x4038a3&&_0x177bd0,'argument-error'),this['apiKey']=_0x4085d7,this['operation']=_0x177bd0,this['code']=_0x4038a3,this['continueUrl']=_0x290547['continueUrl']??null,this['languageCode']=_0x290547['lang']??null,this['tenantId']=_0x290547['tenantId']??null;}static['parseLink'](_0x45c9c5){const _0xeda98e=Xf(_0x45c9c5);try{return new Rs(_0xeda98e);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x534f0e,_0x51e200){return $t['_fromEmailAndPassword'](_0x534f0e,_0x51e200);}static['credentialWithLink'](_0x5439ef,_0x45836c){const _0x470b72=Rs['parseLink'](_0x45836c);return m(_0x470b72,'argument-error'),$t['_fromEmailAndCode'](_0x5439ef,_0x470b72['code'],_0x470b72['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5cbe0c){this['providerId']=_0x5cbe0c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x45a164){this['defaultLanguageCode']=_0x45a164;}['setCustomParameters'](_0x56a396){return this['customParameters']=_0x56a396,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x49af14){return this['scopes']['includes'](_0x49af14)||this['scopes']['push'](_0x49af14),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5d9823){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5d9823});}static['credentialFromResult'](_0x584cf5){return ue['credentialFromTaggedObject'](_0x584cf5);}static['credentialFromError'](_0x439d2e){return ue['credentialFromTaggedObject'](_0x439d2e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e1960}){if(!_0x5e1960||!('oauthAccessToken'in _0x5e1960)||!_0x5e1960['oauthAccessToken'])return null;try{return ue['credential'](_0x5e1960['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x58eba9,_0x62d0a){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x58eba9,'accessToken':_0x62d0a});}static['credentialFromResult'](_0x428c13){return de['credentialFromTaggedObject'](_0x428c13);}static['credentialFromError'](_0x358dd7){return de['credentialFromTaggedObject'](_0x358dd7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x139a75}){if(!_0x139a75)return null;const {oauthIdToken:_0xb9452a,oauthAccessToken:_0x1b4d27}=_0x139a75;if(!_0xb9452a&&!_0x1b4d27)return null;try{return de['credential'](_0xb9452a,_0x1b4d27);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x1e65e0){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1e65e0});}static['credentialFromResult'](_0x5eafe8){return fe['credentialFromTaggedObject'](_0x5eafe8);}static['credentialFromError'](_0x3d67ef){return fe['credentialFromTaggedObject'](_0x3d67ef['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x23574b}){if(!_0x23574b||!('oauthAccessToken'in _0x23574b)||!_0x23574b['oauthAccessToken'])return null;try{return fe['credential'](_0x23574b['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0xf2dd88,_0x1af5df){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0xf2dd88,'oauthTokenSecret':_0x1af5df});}static['credentialFromResult'](_0x3e1a1f){return pe['credentialFromTaggedObject'](_0x3e1a1f);}static['credentialFromError'](_0x19d5e6){return pe['credentialFromTaggedObject'](_0x19d5e6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd06aed}){if(!_0xd06aed)return null;const {oauthAccessToken:_0x411495,oauthTokenSecret:_0x63b53e}=_0xd06aed;if(!_0x411495||!_0x63b53e)return null;try{return pe['credential'](_0x411495,_0x63b53e);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4f207e,_0x4af59b){return en(_0x4f207e,'POST','/v1/accounts:signUp',ke(_0x4f207e,_0x4af59b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x1fb1e0){this['user']=_0x1fb1e0['user'],this['providerId']=_0x1fb1e0['providerId'],this['_tokenResponse']=_0x1fb1e0['_tokenResponse'],this['operationType']=_0x1fb1e0['operationType'];}static async['_fromIdTokenResponse'](_0x32be97,_0x49d21b,_0x18e90e,_0x2bbfa1=!0x1){const _0x11bf85=await j['_fromIdTokenResponse'](_0x32be97,_0x18e90e,_0x2bbfa1),_0x22d73f=Nr(_0x18e90e);return new Ge({'user':_0x11bf85,'providerId':_0x22d73f,'_tokenResponse':_0x18e90e,'operationType':_0x49d21b});}static async['_forOperation'](_0xbe726a,_0x4f174c,_0x106d8d){await _0xbe726a['_updateTokensIfNecessary'](_0x106d8d,!0x0);const _0x5973f4=Nr(_0x106d8d);return new Ge({'user':_0xbe726a,'providerId':_0x5973f4,'_tokenResponse':_0x106d8d,'operationType':_0x4f174c});}}function Nr(_0x291d66){return _0x291d66['providerId']?_0x291d66['providerId']:'phoneNumber'in _0x291d66?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x217e58,_0x1c4697,_0x2e1008,_0x378239){super(_0x1c4697['code'],_0x1c4697['message']),this['operationType']=_0x2e1008,this['user']=_0x378239,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x217e58['name'],'tenantId':_0x217e58['tenantId']??void 0x0,'_serverResponse':_0x1c4697['customData']['_serverResponse'],'operationType':_0x2e1008};}static['_fromErrorAndOperation'](_0xc0c23,_0x54bf9e,_0x3be309,_0x2735fd){return new On(_0xc0c23,_0x54bf9e,_0x3be309,_0x2735fd);}}function Ba(_0x575004,_0x502134,_0x29e4c9,_0x294d7c){return(_0x502134==='reauthenticate'?_0x29e4c9['_getReauthenticationResolver'](_0x575004):_0x29e4c9['_getIdTokenResponse'](_0x575004))['catch'](_0x24504f=>{throw _0x24504f['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x575004,_0x24504f,_0x502134,_0x294d7c):_0x24504f;});}async function ep(_0x296531,_0x2c0f39,_0x5ee1e8=!0x1){const _0x4c1313=await Ht(_0x296531,_0x2c0f39['_linkToIdToken'](_0x296531['auth'],await _0x296531['getIdToken']()),_0x5ee1e8);return Ge['_forOperation'](_0x296531,'link',_0x4c1313);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3f27bb,_0x344700,_0x2985c6=!0x1){const {auth:_0x334949}=_0x3f27bb;if($(_0x334949['app']))return Promise['reject'](re(_0x334949));const _0x3186f8='reauthenticate';try{const _0x50c650=await Ht(_0x3f27bb,Ba(_0x334949,_0x3186f8,_0x344700,_0x3f27bb),_0x2985c6);m(_0x50c650['idToken'],_0x334949,'internal-error');const _0x1c6fe8=Ts(_0x50c650['idToken']);m(_0x1c6fe8,_0x334949,'internal-error');const {sub:_0x746c5b}=_0x1c6fe8;return m(_0x3f27bb['uid']===_0x746c5b,_0x334949,'user-mismatch'),Ge['_forOperation'](_0x3f27bb,_0x3186f8,_0x50c650);}catch(_0x2f9d50){throw(_0x2f9d50==null?void 0x0:_0x2f9d50['code'])==='auth/user-not-found'&&Y(_0x334949,'user-mismatch'),_0x2f9d50;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x57ce64,_0x9bcb42,_0x9951bf=!0x1){if($(_0x57ce64['app']))return Promise['reject'](re(_0x57ce64));const _0x22cf62='signIn',_0x348433=await Ba(_0x57ce64,_0x22cf62,_0x9bcb42),_0x2299aa=await Ge['_fromIdTokenResponse'](_0x57ce64,_0x22cf62,_0x348433);return _0x9951bf||await _0x57ce64['_updateCurrentUser'](_0x2299aa['user']),_0x2299aa;}async function np(_0x116bf0,_0x53bdee){return Va(Ke(_0x116bf0),_0x53bdee);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x255886){const _0x39cd68=Ke(_0x255886);_0x39cd68['_getPasswordPolicyInternal']()&&await _0x39cd68['_updatePasswordPolicy']();}async function L_(_0x320d35,_0x1381b1,_0x1ce7f6){if($(_0x320d35['app']))return Promise['reject'](re(_0x320d35));const _0x2131c2=Ke(_0x320d35),_0x2f1589=await xi(_0x2131c2,{'returnSecureToken':!0x0,'email':_0x1381b1,'password':_0x1ce7f6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x243cc1=>{throw _0x243cc1['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x320d35),_0x243cc1;}),_0x3c4dec=await Ge['_fromIdTokenResponse'](_0x2131c2,'signIn',_0x2f1589);return await _0x2131c2['_updateCurrentUser'](_0x3c4dec['user']),_0x3c4dec;}function x_(_0x44dd7a,_0x5709f6,_0x34f6f7){return $(_0x44dd7a['app'])?Promise['reject'](re(_0x44dd7a)):np(P(_0x44dd7a),yt['credential'](_0x5709f6,_0x34f6f7))['catch'](async _0x2f3657=>{throw _0x2f3657['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x44dd7a),_0x2f3657;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2b44d7,_0x472aa8){return P(_0x2b44d7)['setPersistence'](_0x472aa8);}function ip(_0x53bfa0,_0x443f85,_0x5f5bc8,_0x35d1ca){return P(_0x53bfa0)['onIdTokenChanged'](_0x443f85,_0x5f5bc8,_0x35d1ca);}function sp(_0x1ec20f,_0x4e7f7e,_0x11321e){return P(_0x1ec20f)['beforeAuthStateChanged'](_0x4e7f7e,_0x11321e);}function U_(_0xd48a51,_0x5bca36,_0xff4f19,_0x2aae69){return P(_0xd48a51)['onAuthStateChanged'](_0x5bca36,_0xff4f19,_0x2aae69);}function W_(_0x51cd49){return P(_0x51cd49)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x7b4699,_0xdf1fd){this['storageRetriever']=_0x7b4699,this['type']=_0xdf1fd;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2abfca,_0x3a7704){return this['storage']['setItem'](_0x2abfca,JSON['stringify'](_0x3a7704)),Promise['resolve']();}['_get'](_0x509e32){const _0x55b5ad=this['storage']['getItem'](_0x509e32);return Promise['resolve'](_0x55b5ad?JSON['parse'](_0x55b5ad):null);}['_remove'](_0x259282){return this['storage']['removeItem'](_0x259282),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3e9ea9,_0x16a167)=>this['onStorageEvent'](_0x3e9ea9,_0x16a167),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1816c8){for(const _0x54b9c8 of Object['keys'](this['listeners'])){const _0xd2785d=this['storage']['getItem'](_0x54b9c8),_0x4a9d34=this['localCache'][_0x54b9c8];_0xd2785d!==_0x4a9d34&&_0x1816c8(_0x54b9c8,_0x4a9d34,_0xd2785d);}}['onStorageEvent'](_0x3a1709,_0x27a375=!0x1){if(!_0x3a1709['key']){this['forAllChangedKeys']((_0x5c79ea,_0x142232,_0x2dc6cb)=>{this['notifyListeners'](_0x5c79ea,_0x2dc6cb);});return;}const _0x1b02fe=_0x3a1709['key'];_0x27a375?this['detachListener']():this['stopPolling']();const _0x207b02=()=>{const _0x3fb9e6=this['storage']['getItem'](_0x1b02fe);!_0x27a375&&this['localCache'][_0x1b02fe]===_0x3fb9e6||this['notifyListeners'](_0x1b02fe,_0x3fb9e6);},_0x515815=this['storage']['getItem'](_0x1b02fe);Af()&&_0x515815!==_0x3a1709['newValue']&&_0x3a1709['newValue']!==_0x3a1709['oldValue']?setTimeout(_0x207b02,op):_0x207b02();}['notifyListeners'](_0x5de470,_0x5ed457){this['localCache'][_0x5de470]=_0x5ed457;const _0x4f330e=this['listeners'][_0x5de470];if(_0x4f330e){for(const _0x3963d3 of Array['from'](_0x4f330e))_0x3963d3(_0x5ed457&&JSON['parse'](_0x5ed457));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1e5f6c,_0x1e7396,_0x1b1cb8)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1e5f6c,'oldValue':_0x1e7396,'newValue':_0x1b1cb8}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xa42431,_0x324ff3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xa42431]||(this['listeners'][_0xa42431]=new Set(),this['localCache'][_0xa42431]=this['storage']['getItem'](_0xa42431)),this['listeners'][_0xa42431]['add'](_0x324ff3);}['_removeListener'](_0x57f13f,_0x31444f){this['listeners'][_0x57f13f]&&(this['listeners'][_0x57f13f]['delete'](_0x31444f),this['listeners'][_0x57f13f]['size']===0x0&&delete this['listeners'][_0x57f13f]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1554da,_0x3ff57e){await super['_set'](_0x1554da,_0x3ff57e),this['localCache'][_0x1554da]=JSON['stringify'](_0x3ff57e);}async['_get'](_0x2d25e9){const _0x380d4e=await super['_get'](_0x2d25e9);return this['localCache'][_0x2d25e9]=JSON['stringify'](_0x380d4e),_0x380d4e;}async['_remove'](_0x3ebc94){await super['_remove'](_0x3ebc94),delete this['localCache'][_0x3ebc94];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x385c2a,_0x34d638){}['_removeListener'](_0x50f525,_0x3a6a44){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2b949c){return Promise['all'](_0x2b949c['map'](async _0x1e6d99=>{try{return{'fulfilled':!0x0,'value':await _0x1e6d99};}catch(_0x35f022){return{'fulfilled':!0x1,'reason':_0x35f022};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x51665a){this['eventTarget']=_0x51665a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5b63b1){const _0x309586=this['receivers']['find'](_0x271c86=>_0x271c86['isListeningto'](_0x5b63b1));if(_0x309586)return _0x309586;const _0x1ccf6b=new Xn(_0x5b63b1);return this['receivers']['push'](_0x1ccf6b),_0x1ccf6b;}['isListeningto'](_0x316bbd){return this['eventTarget']===_0x316bbd;}async['handleEvent'](_0x12ba87){const _0x316f3b=_0x12ba87,{eventId:_0x25388b,eventType:_0x3017aa,data:_0x340a1b}=_0x316f3b['data'],_0x4a255b=this['handlersMap'][_0x3017aa];if(!(_0x4a255b!=null&&_0x4a255b['size']))return;_0x316f3b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x25388b,'eventType':_0x3017aa});const _0x51837f=Array['from'](_0x4a255b)['map'](async _0x35d311=>_0x35d311(_0x316f3b['origin'],_0x340a1b)),_0x664f4=await cp(_0x51837f);_0x316f3b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x25388b,'eventType':_0x3017aa,'response':_0x664f4});}['_subscribe'](_0x1095a7,_0x22a1aa){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1095a7]||(this['handlersMap'][_0x1095a7]=new Set()),this['handlersMap'][_0x1095a7]['add'](_0x22a1aa);}['_unsubscribe'](_0xd11d93,_0x9e7099){this['handlersMap'][_0xd11d93]&&_0x9e7099&&this['handlersMap'][_0xd11d93]['delete'](_0x9e7099),(!_0x9e7099||this['handlersMap'][_0xd11d93]['size']===0x0)&&delete this['handlersMap'][_0xd11d93],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4c6c06='',_0x544d3c=0xa){let _0x55b5b8='';for(let _0x1483b4=0x0;_0x1483b4<_0x544d3c;_0x1483b4++)_0x55b5b8+=Math['floor'](Math['random']()*0xa);return _0x4c6c06+_0x55b5b8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x33c250){this['target']=_0x33c250,this['handlers']=new Set();}['removeMessageHandler'](_0x32e6a3){_0x32e6a3['messageChannel']&&(_0x32e6a3['messageChannel']['port1']['removeEventListener']('message',_0x32e6a3['onMessage']),_0x32e6a3['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x32e6a3);}async['_send'](_0xddbd96,_0xfa77fc,_0x95d90d=0x32){const _0x2be29a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2be29a)throw new Error('connection_unavailable');let _0x312b9d,_0x544e22;return new Promise((_0x5c727f,_0x25a19d)=>{const _0x3289aa=As('',0x14);_0x2be29a['port1']['start']();const _0x5775d8=setTimeout(()=>{_0x25a19d(new Error('unsupported_event'));},_0x95d90d);_0x544e22={'messageChannel':_0x2be29a,'onMessage'(_0x7e3383){const _0xb2d4b=_0x7e3383;if(_0xb2d4b['data']['eventId']===_0x3289aa)switch(_0xb2d4b['data']['status']){case'ack':clearTimeout(_0x5775d8),_0x312b9d=setTimeout(()=>{_0x25a19d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x312b9d),_0x5c727f(_0xb2d4b['data']['response']);break;default:clearTimeout(_0x5775d8),clearTimeout(_0x312b9d),_0x25a19d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x544e22),_0x2be29a['port1']['addEventListener']('message',_0x544e22['onMessage']),this['target']['postMessage']({'eventType':_0xddbd96,'eventId':_0x3289aa,'data':_0xfa77fc},[_0x2be29a['port2']]);})['finally'](()=>{_0x544e22&&this['removeMessageHandler'](_0x544e22);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x44f48f){Z()['location']['href']=_0x44f48f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1c1eee;return((_0x1c1eee=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1c1eee['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1077b6){this['request']=_0x1077b6;}['toPromise'](){return new Promise((_0xf80dc4,_0x1344e1)=>{this['request']['addEventListener']('success',()=>{_0xf80dc4(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1344e1(this['request']['error']);});});}}function Zn(_0x3b0790,_0xdb76e9){return _0x3b0790['transaction']([Mn],_0xdb76e9?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x596e83=indexedDB['deleteDatabase'](Ka);return new nn(_0x596e83)['toPromise']();}function Qa(){const _0x2f7a3f=indexedDB['open'](Ka,pp);return new Promise((_0x5a9a19,_0x57cd37)=>{_0x2f7a3f['addEventListener']('error',()=>{_0x57cd37(_0x2f7a3f['error']);}),_0x2f7a3f['addEventListener']('upgradeneeded',()=>{const _0x46e644=_0x2f7a3f['result'];try{_0x46e644['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4be5f9){_0x57cd37(_0x4be5f9);}}),_0x2f7a3f['addEventListener']('success',async()=>{const _0x28a38f=_0x2f7a3f['result'];_0x28a38f['objectStoreNames']['contains'](Mn)?_0x5a9a19(_0x28a38f):(_0x28a38f['close'](),await _p(),_0x5a9a19(await Qa()));});});}async function Or(_0x26b516,_0x31cd83,_0x362e18){const _0x3251e1=Zn(_0x26b516,!0x0)['put']({[Ya]:_0x31cd83,'value':_0x362e18});return new nn(_0x3251e1)['toPromise']();}async function gp(_0x34f473,_0x5ebeec){const _0x5c7f8f=Zn(_0x34f473,!0x1)['get'](_0x5ebeec),_0x452d33=await new nn(_0x5c7f8f)['toPromise']();return _0x452d33===void 0x0?null:_0x452d33['value'];}function Dr(_0x502750,_0x30b3a4){const _0x2b479b=Zn(_0x502750,!0x0)['delete'](_0x30b3a4);return new nn(_0x2b479b)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x36b916){let _0xb50aae=0x0;for(;;)try{const _0x587949=await this['_openDb']();return await _0x36b916(_0x587949);}catch(_0x450a2d){if(_0xb50aae++>yp)throw _0x450a2d;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x18a178,_0xb463a)=>({'keyProcessed':(await this['_poll']())['includes'](_0xb463a['key'])})),this['receiver']['_subscribe']('ping',async(_0x5d0c45,_0x3a4c58)=>['keyChanged']);}async['initializeSender'](){var _0x1bc87b,_0x544cae;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x26a9e0=await this['sender']['_send']('ping',{},0x320);_0x26a9e0&&(_0x1bc87b=_0x26a9e0[0x0])!=null&&_0x1bc87b['fulfilled']&&(_0x544cae=_0x26a9e0[0x0])!=null&&_0x544cae['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2f60ed){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2f60ed},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2d3290=>{await Or(_0x2d3290,Dn,'1'),await Dr(_0x2d3290,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x17bba2){this['pendingWrites']++;try{await _0x17bba2();}finally{this['pendingWrites']--;}}async['_set'](_0x57ab18,_0x29cbae){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5f1b60=>Or(_0x5f1b60,_0x57ab18,_0x29cbae)),this['localCache'][_0x57ab18]=_0x29cbae,this['notifyServiceWorker'](_0x57ab18)));}async['_get'](_0x40a421){const _0x53e27a=await this['_withRetries'](_0x3c7ed5=>gp(_0x3c7ed5,_0x40a421));return this['localCache'][_0x40a421]=_0x53e27a,_0x53e27a;}async['_remove'](_0x24a18c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x46f9e2=>Dr(_0x46f9e2,_0x24a18c)),delete this['localCache'][_0x24a18c],this['notifyServiceWorker'](_0x24a18c)));}async['_poll'](){const _0x38dee9=await this['_withRetries'](_0x234fc0=>{const _0x2467db=Zn(_0x234fc0,!0x1)['getAll']();return new nn(_0x2467db)['toPromise']();});if(!_0x38dee9)return[];if(this['pendingWrites']!==0x0)return[];const _0x169d2e=[],_0x18bcdc=new Set();if(_0x38dee9['length']!==0x0){for(const {fbase_key:_0x5e7ad4,value:_0x4606f7}of _0x38dee9)_0x18bcdc['add'](_0x5e7ad4),JSON['stringify'](this['localCache'][_0x5e7ad4])!==JSON['stringify'](_0x4606f7)&&(this['notifyListeners'](_0x5e7ad4,_0x4606f7),_0x169d2e['push'](_0x5e7ad4));}for(const _0xfdc233 of Object['keys'](this['localCache']))this['localCache'][_0xfdc233]&&!_0x18bcdc['has'](_0xfdc233)&&(this['notifyListeners'](_0xfdc233,null),_0x169d2e['push'](_0xfdc233));return _0x169d2e;}['notifyListeners'](_0x37a219,_0xe4535c){this['localCache'][_0x37a219]=_0xe4535c;const _0x30a6b5=this['listeners'][_0x37a219];if(_0x30a6b5){for(const _0xa573aa of Array['from'](_0x30a6b5))_0xa573aa(_0xe4535c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x74123d,_0x25533f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x74123d]||(this['listeners'][_0x74123d]=new Set(),this['_get'](_0x74123d)),this['listeners'][_0x74123d]['add'](_0x25533f);}['_removeListener'](_0x1f5136,_0x1d7abd){this['listeners'][_0x1f5136]&&(this['listeners'][_0x1f5136]['delete'](_0x1d7abd),this['listeners'][_0x1f5136]['size']===0x0&&delete this['listeners'][_0x1f5136]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x249c0c,_0x53c7a9){return _0x53c7a9?ie(_0x53c7a9):(m(_0x249c0c['_popupRedirectResolver'],_0x249c0c,'argument-error'),_0x249c0c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x674782){super('custom','custom'),this['params']=_0x674782;}['_getIdTokenResponse'](_0x4923be){return nt(_0x4923be,this['_buildIdpRequest']());}['_linkToIdToken'](_0x211ce0,_0x1ed5eb){return nt(_0x211ce0,this['_buildIdpRequest'](_0x1ed5eb));}['_getReauthenticationResolver'](_0x9310e4){return nt(_0x9310e4,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x20d99d){const _0xe63d5d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x20d99d&&(_0xe63d5d['idToken']=_0x20d99d),_0xe63d5d;}}function Ip(_0x57ec17){return Va(_0x57ec17['auth'],new ks(_0x57ec17),_0x57ec17['bypassAuthState']);}function wp(_0x1c138c){const {auth:_0x5ee720,user:_0x4cc5e6}=_0x1c138c;return m(_0x4cc5e6,_0x5ee720,'internal-error'),tp(_0x4cc5e6,new ks(_0x1c138c),_0x1c138c['bypassAuthState']);}async function Cp(_0xb50f89){const {auth:_0x10ae5a,user:_0x1d817c}=_0xb50f89;return m(_0x1d817c,_0x10ae5a,'internal-error'),ep(_0x1d817c,new ks(_0xb50f89),_0xb50f89['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x50f044,_0x3263d1,_0x45edf7,_0x17c246,_0x5c7af0=!0x1){this['auth']=_0x50f044,this['resolver']=_0x45edf7,this['user']=_0x17c246,this['bypassAuthState']=_0x5c7af0,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3263d1)?_0x3263d1:[_0x3263d1];}['execute'](){return new Promise(async(_0x540bfa,_0x443ee5)=>{this['pendingPromise']={'resolve':_0x540bfa,'reject':_0x443ee5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5ab1e9){this['reject'](_0x5ab1e9);}});}async['onAuthEvent'](_0x14eb07){const {urlResponse:_0x19bd5a,sessionId:_0x2c9f86,postBody:_0x29ba5b,tenantId:_0x57f189,error:_0x5630fe,type:_0x555f76}=_0x14eb07;if(_0x5630fe){this['reject'](_0x5630fe);return;}const _0x1d89d2={'auth':this['auth'],'requestUri':_0x19bd5a,'sessionId':_0x2c9f86,'tenantId':_0x57f189||void 0x0,'postBody':_0x29ba5b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x555f76)(_0x1d89d2));}catch(_0x189f18){this['reject'](_0x189f18);}}['onError'](_0x38d34c){this['reject'](_0x38d34c);}['getIdpTask'](_0x5330f4){switch(_0x5330f4){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x2be720){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2be720),this['unregisterAndCleanUp']();}['reject'](_0x5de9ed){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5de9ed),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x451abb,_0x1d1dc3,_0xd29413,_0x1a6603,_0x24ce52){super(_0x451abb,_0x1d1dc3,_0x1a6603,_0x24ce52),this['provider']=_0xd29413,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x2b57df=await this['execute']();return m(_0x2b57df,this['auth'],'internal-error'),_0x2b57df;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x365858=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x365858),this['authWindow']['associatedEvent']=_0x365858,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4d9c8f=>{this['reject'](_0x4d9c8f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x52b14b=>{_0x52b14b||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3c2b84;return((_0x3c2b84=this['authWindow'])==null?void 0x0:_0x3c2b84['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0xa32053=()=>{var _0x854e68,_0x4e05e6;if((_0x4e05e6=(_0x854e68=this['authWindow'])==null?void 0x0:_0x854e68['window'])!=null&&_0x4e05e6['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xa32053,Tp['get']());};_0xa32053();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x2fe52e,_0x3cb340,_0x594e29=!0x1){super(_0x2fe52e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3cb340,void 0x0,_0x594e29),this['eventId']=null;}async['execute'](){let _0x82ce31=hn['get'](this['auth']['_key']());if(!_0x82ce31){try{const _0x2b286a=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x82ce31=()=>Promise['resolve'](_0x2b286a);}catch(_0x233276){_0x82ce31=()=>Promise['reject'](_0x233276);}hn['set'](this['auth']['_key'](),_0x82ce31);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x82ce31();}async['onAuthEvent'](_0x2adeb4){if(_0x2adeb4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2adeb4);if(_0x2adeb4['type']==='unknown'){this['resolve'](null);return;}if(_0x2adeb4['eventId']){const _0x29b14e=await this['auth']['_redirectUserForId'](_0x2adeb4['eventId']);if(_0x29b14e)return this['user']=_0x29b14e,super['onAuthEvent'](_0x2adeb4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4d56bb,_0x4d3b8){const _0x11b535=Pp(_0x4d3b8),_0x142cfa=kp(_0x4d56bb);if(!await _0x142cfa['_isAvailable']())return!0x1;const _0x38ca68=await _0x142cfa['_get'](_0x11b535)==='true';return await _0x142cfa['_remove'](_0x11b535),_0x38ca68;}function Ap(_0x5b0cb8,_0x217d69){hn['set'](_0x5b0cb8['_key'](),_0x217d69);}function kp(_0x334bed){return ie(_0x334bed['_redirectPersistence']);}function Pp(_0x51b213){return ln(Sp,_0x51b213['config']['apiKey'],_0x51b213['name']);}async function Np(_0x17a675,_0x178ab3,_0x5703e8=!0x1){if($(_0x17a675['app']))return Promise['reject'](re(_0x17a675));const _0x420683=Ke(_0x17a675),_0x25eb2c=Ep(_0x420683,_0x178ab3),_0x9d30f7=await new bp(_0x420683,_0x25eb2c,_0x5703e8)['execute']();return _0x9d30f7&&!_0x5703e8&&(delete _0x9d30f7['user']['_redirectEventId'],await _0x420683['_persistUserIfCurrent'](_0x9d30f7['user']),await _0x420683['_setRedirectUser'](null,_0x178ab3)),_0x9d30f7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x475b86){this['auth']=_0x475b86,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x31040c){this['consumers']['add'](_0x31040c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x31040c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x31040c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x19ff61){this['consumers']['delete'](_0x19ff61);}['onEvent'](_0x392580){if(this['hasEventBeenHandled'](_0x392580))return!0x1;let _0x3d7a03=!0x1;return this['consumers']['forEach'](_0x27a9c0=>{this['isEventForConsumer'](_0x392580,_0x27a9c0)&&(_0x3d7a03=!0x0,this['sendToConsumer'](_0x392580,_0x27a9c0),this['saveEventToCache'](_0x392580));}),this['hasHandledPotentialRedirect']||!Mp(_0x392580)||(this['hasHandledPotentialRedirect']=!0x0,_0x3d7a03||(this['queuedRedirectEvent']=_0x392580,_0x3d7a03=!0x0)),_0x3d7a03;}['sendToConsumer'](_0x3928bc,_0xe0588f){var _0x59c6cb;if(_0x3928bc['error']&&!Za(_0x3928bc)){const _0xf7c443=((_0x59c6cb=_0x3928bc['error']['code'])==null?void 0x0:_0x59c6cb['split']('auth/')[0x1])||'internal-error';_0xe0588f['onError'](X(this['auth'],_0xf7c443));}else _0xe0588f['onAuthEvent'](_0x3928bc);}['isEventForConsumer'](_0x2ead87,_0x5dee52){const _0xf4e670=_0x5dee52['eventId']===null||!!_0x2ead87['eventId']&&_0x2ead87['eventId']===_0x5dee52['eventId'];return _0x5dee52['filter']['includes'](_0x2ead87['type'])&&_0xf4e670;}['hasEventBeenHandled'](_0x119b5b){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x119b5b));}['saveEventToCache'](_0x2128c1){this['cachedEventUids']['add'](Mr(_0x2128c1)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2baa99){return[_0x2baa99['type'],_0x2baa99['eventId'],_0x2baa99['sessionId'],_0x2baa99['tenantId']]['filter'](_0x4f00d4=>_0x4f00d4)['join']('-');}function Za({type:_0xe644,error:_0x385c20}){return _0xe644==='unknown'&&(_0x385c20==null?void 0x0:_0x385c20['code'])==='auth/no-auth-event';}function Mp(_0x1d2cc6){switch(_0x1d2cc6['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1d2cc6);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3fb32a,_0x589b15={}){return Pe(_0x3fb32a,'GET','/v1/projects',_0x589b15);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x33a831){if(_0x33a831['config']['emulator'])return;const {authorizedDomains:_0x189b2a}=await Lp(_0x33a831);for(const _0x2f07fd of _0x189b2a)try{if(Wp(_0x2f07fd))return;}catch{}Y(_0x33a831,'unauthorized-domain');}function Wp(_0x5ae56d){const _0x314507=Mi(),{protocol:_0x309c02,hostname:_0xad79f2}=new URL(_0x314507);if(_0x5ae56d['startsWith']('chrome-extension://')){const _0x3a0620=new URL(_0x5ae56d);return _0x3a0620['hostname']===''&&_0xad79f2===''?_0x309c02==='chrome-extension:'&&_0x5ae56d['replace']('chrome-extension://','')===_0x314507['replace']('chrome-extension://',''):_0x309c02==='chrome-extension:'&&_0x3a0620['hostname']===_0xad79f2;}if(!Fp['test'](_0x309c02))return!0x1;if(xp['test'](_0x5ae56d))return _0xad79f2===_0x5ae56d;const _0x21bd58=_0x5ae56d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x21bd58+'|'+_0x21bd58+')$','i')['test'](_0xad79f2);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x2408c7=Z()['___jsl'];if(_0x2408c7!=null&&_0x2408c7['H']){for(const _0x5e5fdb of Object['keys'](_0x2408c7['H']))if(_0x2408c7['H'][_0x5e5fdb]['r']=_0x2408c7['H'][_0x5e5fdb]['r']||[],_0x2408c7['H'][_0x5e5fdb]['L']=_0x2408c7['H'][_0x5e5fdb]['L']||[],_0x2408c7['H'][_0x5e5fdb]['r']=[..._0x2408c7['H'][_0x5e5fdb]['L']],_0x2408c7['CP']){for(let _0x4fc577=0x0;_0x4fc577<_0x2408c7['CP']['length'];_0x4fc577++)_0x2408c7['CP'][_0x4fc577]=null;}}}function Vp(_0xa6e113){return new Promise((_0x9ea3e8,_0x5d4fe4)=>{var _0x3e06e0,_0x4ffb3b,_0x345c75;function _0x5d56f1(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x9ea3e8(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x5d4fe4(X(_0xa6e113,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4ffb3b=(_0x3e06e0=Z()['gapi'])==null?void 0x0:_0x3e06e0['iframes'])!=null&&_0x4ffb3b['Iframe'])_0x9ea3e8(gapi['iframes']['getContext']());else{if((_0x345c75=Z()['gapi'])!=null&&_0x345c75['load'])_0x5d56f1();else{const _0x31684a=Ff('iframefcb');return Z()[_0x31684a]=()=>{gapi['load']?_0x5d56f1():_0x5d4fe4(X(_0xa6e113,'network-request-failed'));},xa(xf()+'?onload='+_0x31684a)['catch'](_0x2cec90=>_0x5d4fe4(_0x2cec90));}}})['catch'](_0x5d5d17=>{throw un=null,_0x5d5d17;});}let un=null;function Hp(_0xb60fa1){return un=un||Vp(_0xb60fa1),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x26e7cd){const _0x4730d3=_0x26e7cd['config'];m(_0x4730d3['authDomain'],_0x26e7cd,'auth-domain-config-required');const _0x2804ad=_0x4730d3['emulator']?Cs(_0x4730d3,qp):'https://'+_0x26e7cd['config']['authDomain']+'/'+Gp,_0x5d1299={'apiKey':_0x4730d3['apiKey'],'appName':_0x26e7cd['name'],'v':dt},_0x2069f2=jp['get'](_0x26e7cd['config']['apiHost']);_0x2069f2&&(_0x5d1299['eid']=_0x2069f2);const _0x2259b1=_0x26e7cd['_getFrameworks']();return _0x2259b1['length']&&(_0x5d1299['fw']=_0x2259b1['join'](',')),_0x2804ad+'?'+ut(_0x5d1299)['slice'](0x1);}async function Yp(_0x4f0a4f){const _0x5a4055=await Hp(_0x4f0a4f),_0x41bcd6=Z()['gapi'];return m(_0x41bcd6,_0x4f0a4f,'internal-error'),_0x5a4055['open']({'where':document['body'],'url':Kp(_0x4f0a4f),'messageHandlersFilter':_0x41bcd6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x337e26=>new Promise(async(_0x3a97b0,_0x48a84b)=>{await _0x337e26['restyle']({'setHideOnLeave':!0x1});const _0x3850b2=X(_0x4f0a4f,'network-request-failed'),_0x4cde27=Z()['setTimeout'](()=>{_0x48a84b(_0x3850b2);},$p['get']());function _0x10d50e(){Z()['clearTimeout'](_0x4cde27),_0x3a97b0(_0x337e26);}_0x337e26['ping'](_0x10d50e)['then'](_0x10d50e,()=>{_0x48a84b(_0x3850b2);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x19aed1){this['window']=_0x19aed1,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x2cda63,_0x2cf245,_0x49f443,_0x65a31a=Jp,_0x47711d=Xp){const _0x5ef02c=Math['max']((window['screen']['availHeight']-_0x47711d)/0x2,0x0)['toString'](),_0x3cf97a=Math['max']((window['screen']['availWidth']-_0x65a31a)/0x2,0x0)['toString']();let _0x593467='';const _0x2b602d={...Qp,'width':_0x65a31a['toString'](),'height':_0x47711d['toString'](),'top':_0x5ef02c,'left':_0x3cf97a},_0x2237a0=W()['toLowerCase']();_0x49f443&&(_0x593467=ka(_0x2237a0)?Zp:_0x49f443),Ra(_0x2237a0)&&(_0x2cf245=_0x2cf245||e_,_0x2b602d['scrollbars']='yes');const _0x372c48=Object['entries'](_0x2b602d)['reduce']((_0x339c7b,[_0x185004,_0x1548be])=>''+_0x339c7b+_0x185004+'='+_0x1548be+',','');if(Rf(_0x2237a0)&&_0x593467!=='_self')return n_(_0x2cf245||'',_0x593467),new xr(null);const _0x20a49e=window['open'](_0x2cf245||'',_0x593467,_0x372c48);m(_0x20a49e,_0x2cda63,'popup-blocked');try{_0x20a49e['focus']();}catch{}return new xr(_0x20a49e);}function n_(_0x40b072,_0x49314f){const _0x263ae8=document['createElement']('a');_0x263ae8['href']=_0x40b072,_0x263ae8['target']=_0x49314f;const _0x23eb7d=document['createEvent']('MouseEvent');_0x23eb7d['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x263ae8['dispatchEvent'](_0x23eb7d);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x3e93af,_0x2b9d7b,_0x40d788,_0x3641b6,_0x52f160,_0x39a8f2){m(_0x3e93af['config']['authDomain'],_0x3e93af,'auth-domain-config-required'),m(_0x3e93af['config']['apiKey'],_0x3e93af,'invalid-api-key');const _0x4c076c={'apiKey':_0x3e93af['config']['apiKey'],'appName':_0x3e93af['name'],'authType':_0x40d788,'redirectUrl':_0x3641b6,'v':dt,'eventId':_0x52f160};if(_0x2b9d7b instanceof Wa){_0x2b9d7b['setDefaultLanguage'](_0x3e93af['languageCode']),_0x4c076c['providerId']=_0x2b9d7b['providerId']||'',pn(_0x2b9d7b['getCustomParameters']())||(_0x4c076c['customParameters']=JSON['stringify'](_0x2b9d7b['getCustomParameters']()));for(const [_0x104773,_0x5246e8]of Object['entries']({}))_0x4c076c[_0x104773]=_0x5246e8;}if(_0x2b9d7b instanceof tn){const _0x36c0a4=_0x2b9d7b['getScopes']()['filter'](_0x20a5be=>_0x20a5be!=='');_0x36c0a4['length']>0x0&&(_0x4c076c['scopes']=_0x36c0a4['join'](','));}_0x3e93af['tenantId']&&(_0x4c076c['tid']=_0x3e93af['tenantId']);const _0x1e4619=_0x4c076c;for(const _0x19ff78 of Object['keys'](_0x1e4619))_0x1e4619[_0x19ff78]===void 0x0&&delete _0x1e4619[_0x19ff78];const _0x6fa866=await _0x3e93af['_getAppCheckToken'](),_0x2b3132=_0x6fa866?'#'+r_+'='+encodeURIComponent(_0x6fa866):'';return o_(_0x3e93af)+'?'+ut(_0x1e4619)['slice'](0x1)+_0x2b3132;}function o_({config:_0x25a39e}){return _0x25a39e['emulator']?Cs(_0x25a39e,s_):'https://'+_0x25a39e['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x58d4d5,_0x1e2ebf,_0x2ba66c,_0x443488){var _0x11a075;ce((_0x11a075=this['eventManagers'][_0x58d4d5['_key']()])==null?void 0x0:_0x11a075['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x40e687=await Fr(_0x58d4d5,_0x1e2ebf,_0x2ba66c,Mi(),_0x443488);return t_(_0x58d4d5,_0x40e687,As());}async['_openRedirect'](_0x20a4c3,_0x45dc0f,_0x19c8d2,_0xc31faf){await this['_originValidation'](_0x20a4c3);const _0x5a8730=await Fr(_0x20a4c3,_0x45dc0f,_0x19c8d2,Mi(),_0xc31faf);return hp(_0x5a8730),new Promise(()=>{});}['_initialize'](_0x3e02b2){const _0x398302=_0x3e02b2['_key']();if(this['eventManagers'][_0x398302]){const {manager:_0x21bdd9,promise:_0x1142ac}=this['eventManagers'][_0x398302];return _0x21bdd9?Promise['resolve'](_0x21bdd9):(ce(_0x1142ac,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1142ac);}const _0xaad06b=this['initAndGetManager'](_0x3e02b2);return this['eventManagers'][_0x398302]={'promise':_0xaad06b},_0xaad06b['catch'](()=>{delete this['eventManagers'][_0x398302];}),_0xaad06b;}async['initAndGetManager'](_0x4f281c){const _0x1355c2=await Yp(_0x4f281c),_0x1dac3d=new Dp(_0x4f281c);return _0x1355c2['register']('authEvent',_0x27afc9=>(m(_0x27afc9==null?void 0x0:_0x27afc9['authEvent'],_0x4f281c,'invalid-auth-event'),{'status':_0x1dac3d['onEvent'](_0x27afc9['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4f281c['_key']()]={'manager':_0x1dac3d},this['iframes'][_0x4f281c['_key']()]=_0x1355c2,_0x1dac3d;}['_isIframeWebStorageSupported'](_0x4455b1,_0x50bc80){this['iframes'][_0x4455b1['_key']()]['send'](pi,{'type':pi},_0x5582d7=>{var _0x56b6c;const _0x2f326f=(_0x56b6c=_0x5582d7==null?void 0x0:_0x5582d7[0x0])==null?void 0x0:_0x56b6c[pi];_0x2f326f!==void 0x0&&_0x50bc80(!!_0x2f326f),Y(_0x4455b1,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x58808e){const _0x875db6=_0x58808e['_key']();return this['originValidationPromises'][_0x875db6]||(this['originValidationPromises'][_0x875db6]=Up(_0x58808e)),this['originValidationPromises'][_0x875db6];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4766ae){this['auth']=_0x4766ae,this['internalListeners']=new Map();}['getUid'](){var _0x58348d;return this['assertAuthConfigured'](),((_0x58348d=this['auth']['currentUser'])==null?void 0x0:_0x58348d['uid'])||null;}async['getToken'](_0x3d7ffc){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3d7ffc)}:null;}['addAuthTokenListener'](_0x51f37c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x51f37c))return;const _0x365be0=this['auth']['onIdTokenChanged'](_0x53d4c9=>{_0x51f37c((_0x53d4c9==null?void 0x0:_0x53d4c9['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x51f37c,_0x365be0),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x389f01){this['assertAuthConfigured']();const _0x2314ed=this['internalListeners']['get'](_0x389f01);_0x2314ed&&(this['internalListeners']['delete'](_0x389f01),_0x2314ed(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x31a903){switch(_0x31a903){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x3d90aa){st(new Fe('auth',(_0x431c74,{options:_0x5592b7})=>{const _0x48eea7=_0x431c74['getProvider']('app')['getImmediate'](),_0x8dbb1a=_0x431c74['getProvider']('heartbeat'),_0xcec984=_0x431c74['getProvider']('app-check-internal'),{apiKey:_0x55ce7b,authDomain:_0x4e802c}=_0x48eea7['options'];m(_0x55ce7b&&!_0x55ce7b['includes'](':'),'invalid-api-key',{'appName':_0x48eea7['name']});const _0x5abf35={'apiKey':_0x55ce7b,'authDomain':_0x4e802c,'clientPlatform':_0x3d90aa,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3d90aa)},_0x22339f=new Df(_0x48eea7,_0x8dbb1a,_0xcec984,_0x5abf35);return Hf(_0x22339f,_0x5592b7),_0x22339f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3dde9c,_0x22b86c,_0xd55684)=>{_0x3dde9c['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x286312=>{const _0x3b1817=Ke(_0x286312['getProvider']('auth')['getImmediate']());return(_0xe6f2fd=>new l_(_0xe6f2fd))(_0x3b1817);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x3d90aa)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x546acd=>async _0x460ba5=>{const _0x14762b=_0x460ba5&&await _0x460ba5['getIdTokenResult'](),_0x32dcc3=_0x14762b&&(new Date()['getTime']()-Date['parse'](_0x14762b['issuedAtTime']))/0x3e8;if(_0x32dcc3&&_0x32dcc3>f_)return;const _0x199db7=_0x14762b==null?void 0x0:_0x14762b['token'];Br!==_0x199db7&&(Br=_0x199db7,await fetch(_0x546acd,{'method':_0x199db7?'POST':'DELETE','headers':_0x199db7?{'Authorization':'Bearer\x20'+_0x199db7}:{}}));};function B_(_0x34c49d=Zr()){const _0x49a4a6=Hi(_0x34c49d,'auth');if(_0x49a4a6['isInitialized']())return _0x49a4a6['getImmediate']();const _0x496137=Vf(_0x34c49d,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0xa7244c=jr('authTokenSyncURL');if(_0xa7244c&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x44783b=new URL(_0xa7244c,location['origin']);if(location['origin']===_0x44783b['origin']){const _0x5d76fb=p_(_0x44783b['toString']());sp(_0x496137,_0x5d76fb,()=>_0x5d76fb(_0x496137['currentUser'])),ip(_0x496137,_0xf498db=>_0x5d76fb(_0xf498db));}}const _0x48a004=qr('auth');return _0x48a004&&$f(_0x496137,'http://'+_0x48a004),_0x496137;}function __(){var _0x1e7c61;return((_0x1e7c61=document['getElementsByTagName']('head'))==null?void 0x0:_0x1e7c61[0x0])??document;}Mf({'loadJS'(_0x3528b8){return new Promise((_0x24e0e2,_0xf7a8aa)=>{const _0x14acfb=document['createElement']('script');_0x14acfb['setAttribute']('src',_0x3528b8),_0x14acfb['onload']=_0x24e0e2,_0x14acfb['onerror']=_0x2c68c4=>{const _0xdc8f9a=X('internal-error');_0xdc8f9a['customData']=_0x2c68c4,_0xf7a8aa(_0xdc8f9a);},_0x14acfb['type']='text/javascript',_0x14acfb['charset']='UTF-8',__()['appendChild'](_0x14acfb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{T_ as A,C_ as B,S_ as C,L_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,W_ as h,Sl as i,m_ as j,Hd as k,D_ as l,Gd as m,N_ as n,v_ as o,U_ as p,O_ as q,y_ as r,F_ as s,k_ as t,I_ as u,b_ as v,A_ as w,Vt as x,E_ as y,M_ as z};